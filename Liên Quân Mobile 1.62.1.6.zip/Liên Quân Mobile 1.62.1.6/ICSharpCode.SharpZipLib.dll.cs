// Namespace: 
internal class <Module>
{
}

// Namespace: ICSharpCode.SharpZipLib
public class SharpZipBaseException
{

	// Methods

	// RVA: 0x36652CC
	public object .ctor() { }

	// RVA: 0x3665354
	public object .ctor(object message) { }

	// RVA: 0x36653C0
	protected object .ctor(object info, object context) { }

}

// Namespace: ICSharpCode.SharpZipLib
public class StreamDecodingException
{

	// Methods

	// RVA: 0x3665444
	public object .ctor() { }

	// RVA: 0x3665500
	public object .ctor(object message) { }

	// RVA: 0x366556C
	protected object .ctor(object info, object context) { }

}

// Namespace: ICSharpCode.SharpZipLib
public class ValueOutOfRangeException
{

	// Methods

	// RVA: 0x36655F0
	public object .ctor(object nameOfValue) { }

	// RVA: 0x3665698
	private object .ctor() { }

	// RVA: 0x3665754
	protected object .ctor(object info, object context) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public interface IEntryFactory
{
}

// Namespace: ICSharpCode.SharpZipLib.Zip
public enum UseZip64
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object On;
	public const object Dynamic;
}

// Namespace: ICSharpCode.SharpZipLib.Zip
public enum CompressionMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Stored;
	public const object Deflated;
	public const object Deflate64;
	public const object BZip2;
	public const object LZMA;
	public const object PPMd;
	public const object WinZipAES;
}

// Namespace: ICSharpCode.SharpZipLib.Zip
public enum GeneralBitFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Encrypted;
	public const object Method;
	public const object Descriptor;
	public const object ReservedPKware4;
	public const object Patched;
	public const object StrongEncryption;
	public const object Unused7;
	public const object Unused8;
	public const object Unused9;
	public const object Unused10;
	public const object UnicodeText;
	public const object EnhancedCompress;
	public const object HeaderMasked;
	public const object ReservedPkware14;
	public const object ReservedPkware15;
}

// Namespace: ICSharpCode.SharpZipLib.Zip
public static class ZipConstants
{

	// Properties
	public static object DefaultCodePage { set; }

	// Methods

	// RVA: 0x36657D8
	public static object set_DefaultCodePage(object value) { }

}

// Namespace: 
private enum Known
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Size;
	public const object CompressedSize;
	public const object Crc;
	public const object Time;
	public const object ExternalAttributes;
}

// Namespace: ICSharpCode.SharpZipLib.Zip
public class ZipEntry
{

	// Fields
	private object known; // 0x8
	private object externalFileAttributes; // 0xC
	private object versionMadeBy; // 0x10
	private object name; // 0x18
	private object size; // 0x20
	private object compressedSize; // 0x28
	private object versionToExtract; // 0x30
	private object crc; // 0x34
	private object dateTime; // 0x38
	private object method; // 0x40
	private object extra; // 0x48
	private object comment; // 0x50
	private object flags; // 0x58
	private object zipFileIndex; // 0x60
	private object offset; // 0x68
	private object forceZip64_; // 0x70
	private object cryptoCheckValue_; // 0x71
	private object _aesVer; // 0x74
	private object _aesEncryptionStrength; // 0x78

	// Properties
	public object IsCrypted { get; }
	public object IsUnicodeText { set; }
	internal object CryptoCheckValue { get; set; }
	public object Flags { get; set; }
	public object ZipFileIndex { get; set; }
	public object Offset { get; set; }
	public object ExternalFileAttributes { get; set; }
	public object HostSystem { get; }
	public object Version { get; }
	public object LocalHeaderRequiresZip64 { get; }
	public object CentralHeaderRequiresZip64 { get; }
	public object DosTime { set; }
	public object DateTime { get; set; }
	public object Name { get; }
	public object Size { get; set; }
	public object CompressedSize { get; set; }
	public object Crc { get; set; }
	public object CompressionMethod { get; }
	internal object CompressionMethodForHeader { get; }
	public object ExtraData { set; }
	public object AESKeySize { get; }
	internal object AESSaltLen { get; }
	internal object AESOverheadSize { get; }
	internal object EncryptionOverheadSize { get; }
	public object Comment { set; }
	public object IsDirectory { get; }
	public object IsFile { get; }

	// Methods

	// RVA: 0x3665944
	internal object .ctor(object name, object versionRequiredToExtract, object madeByInfo, object method) { }

	// RVA: 0x3665C84
	public object get_IsCrypted() { }

	// RVA: 0x3665C30
	public object set_IsUnicodeText(object value) { }

	// RVA: 0x3665D24
	internal object get_CryptoCheckValue() { }

	// RVA: 0x3665D2C
	internal object set_CryptoCheckValue(object value) { }

	// RVA: 0x3665D34
	public object get_Flags() { }

	// RVA: 0x3665D3C
	public object set_Flags(object value) { }

	// RVA: 0x3665D44
	public object get_ZipFileIndex() { }

	// RVA: 0x3665D4C
	public object set_ZipFileIndex(object value) { }

	// RVA: 0x3665D54
	public object get_Offset() { }

	// RVA: 0x3665D5C
	public object set_Offset(object value) { }

	// RVA: 0x3665D64
	public object get_ExternalFileAttributes() { }

	// RVA: 0x3665D7C
	public object set_ExternalFileAttributes(object value) { }

	// RVA: 0x3665D90
	private object HasDosAttributes(object attributes) { }

	// RVA: 0x3665DD0
	public object get_HostSystem() { }

	// RVA: 0x3665DD8
	public object get_Version() { }

	// RVA: 0x366616C
	public object get_LocalHeaderRequiresZip64() { }

	// RVA: 0x3665FD4
	public object get_CentralHeaderRequiresZip64() { }

	// RVA: 0x3666274
	public object set_DosTime(object value) { }

	// RVA: 0x36663DC
	public object get_DateTime() { }

	// RVA: 0x3665B50
	public object set_DateTime(object value) { }

	// RVA: 0x36663E4
	public object get_Name() { }

	// RVA: 0x36663EC
	public object get_Size() { }

	// RVA: 0x3666404
	public object set_Size(object value) { }

	// RVA: 0x3666418
	public object get_CompressedSize() { }

	// RVA: 0x3666430
	public object set_CompressedSize(object value) { }

	// RVA: 0x3666444
	public object get_Crc() { }

	// RVA: 0x366645C
	public object set_Crc(object value) { }

	// RVA: 0x3666470
	public object get_CompressionMethod() { }

	// RVA: 0x3666478
	internal object get_CompressionMethodForHeader() { }

	// RVA: 0x36664B4
	public object set_ExtraData(object value) { }

	// RVA: 0x3665F50
	public object get_AESKeySize() { }

	// RVA: 0x3666600
	internal object get_AESSaltLen() { }

	// RVA: 0x3666624
	internal object get_AESOverheadSize() { }

	// RVA: 0x3666214
	internal object get_EncryptionOverheadSize() { }

	// RVA: 0x366664C
	internal object ProcessExtraData(object localHeader) { }

	// RVA: 0x3666AB8
	private static object GetDateTime(object extraData) { }

	// RVA: 0x3666B74
	private object ProcessAESExtraData(object extraData) { }

	// RVA: 0x3666E9C
	public object set_Comment(object value) { }

	// RVA: 0x366608C
	public object get_IsDirectory() { }

	// RVA: 0x3666F1C
	public object get_IsFile() { }

	// RVA: 0x3666F9C
	public object IsCompressionMethodSupported() { }

	// RVA: 0x3666FD0
	public override object ToString() { }

	// RVA: 0x3666FB8
	public static object IsCompressionMethodSupported(object method) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public static class ZipEntryExtensions
{

	// Methods

	// RVA: 0x3665CA8
	public static object HasFlag(object entry, object flag) { }

	// RVA: 0x3665CD0
	public static object SetFlag(object entry, object flag, object enabled) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public class ZipEntryFactory
{

	// Fields
	private object nameTransform_; // 0x8
	private object fixedDateTime_; // 0x10
	private object isUnicodeText_; // 0x18
	private object getAttributes_; // 0x1C

	// Methods

	// RVA: 0x3666FD8
	public object .ctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public class ZipException
{

	// Methods

	// RVA: 0x36670CC
	public object .ctor() { }

	// RVA: 0x3666594
	public object .ctor(object message) { }

	// RVA: 0x3667154
	protected object .ctor(object info, object context) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public interface ITaggedData
{

	// Properties
	public abstract object TagID { get; }

	// Methods

	// RVA: -1
	public abstract object get_TagID() { }

	// RVA: -1
	public abstract object SetData(object data, object offset, object count) { }

}

// Namespace: 
public enum Flags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ModificationTime;
	public const object AccessTime;
	public const object CreateTime;
}

// Namespace: ICSharpCode.SharpZipLib.Zip
public class ExtendedUnixData
{

	// Fields
	private object _flags; // 0x8
	private object _modificationTime; // 0x10
	private object _lastAccessTime; // 0x18
	private object _createTime; // 0x20

	// Properties
	public object TagID { get; }
	public object ModificationTime { get; }
	public object Include { get; }

	// Methods

	// RVA: 0x36671D8
	public object get_TagID() { }

	// RVA: 0x36671E0
	public object SetData(object data, object index, object count) { }

	// RVA: 0x3667814
	public object get_ModificationTime() { }

	// RVA: 0x366781C
	public object get_Include() { }

	// RVA: 0x3667824
	public object .ctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public sealed class ZipExtraData
{

	// Fields
	private object _index; // 0x8
	private object _readValueStart; // 0xC
	private object _readValueLength; // 0x10
	private object _newEntry; // 0x18
	private object _data; // 0x20

	// Properties
	public object ValueLength { get; }

	// Methods

	// RVA: 0x3666904
	public object .ctor(object data) { }

	// RVA: -1
	public object GetData() { }

	// RVA: 0x36678C0
	public object get_ValueLength() { }

	// RVA: 0x3666994
	public object Find(object headerID) { }

	// RVA: 0x3666A78
	public object ReadLong() { }

	// RVA: 0x3667A64
	public object ReadInt() { }

	// RVA: 0x3666DBC
	public object ReadShort() { }

	// RVA: 0x3666E2C
	public object ReadByte() { }

	// RVA: 0x366797C
	private object ReadCheck(object length) { }

	// RVA: 0x36678C8
	private object ReadShortInternal() { }

	// RVA: 0x3667AFC
	public object Dispose() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public class KeysRequiredEventArgs
{

	// Fields
	private readonly object fileName; // 0x8
	private object key; // 0x10

	// Properties
	public object Key { get; }

	// Methods

	// RVA: 0x3667B10
	public object .ctor(object name, object keyValue) { }

	// RVA: 0x3667B8C
	public object get_Key() { }

}

// Namespace: 
public sealed class KeysRequiredEventHandler
{

	// Methods

	// RVA: 0x366CA64
	public object .ctor(object object, object method) { }

	// RVA: 0x366CB70
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: 
private enum HeaderTest
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Extract;
	public const object Header;
}

// Namespace: 
private class ZipUpdate
{
}

// Namespace: 
private class ZipEntryEnumerator
{

	// Fields
	private object array; // 0x8
	private object index; // 0x10

	// Properties
	public object Current { get; }

	// Methods

	// RVA: 0x3669148
	public object .ctor(object entries) { }

	// RVA: 0x366CB84
	public object get_Current() { }

	// RVA: 0x366CBC4
	public object Reset() { }

	// RVA: 0x366CBD0
	public object MoveNext() { }

}

// Namespace: 
private class PartialInputStream
{

	// Fields
	private object zipFile_; // 0x20
	private object baseStream_; // 0x28
	private readonly object start_; // 0x30
	private readonly object length_; // 0x38
	private object readPos_; // 0x40
	private readonly object end_; // 0x48

	// Properties
	public override object Position { get; set; }
	public override object Length { get; }
	public override object CanWrite { get; }
	public override object CanSeek { get; }
	public override object CanRead { get; }
	public override object CanTimeout { get; }

	// Methods

	// RVA: 0x3669804
	public object .ctor(object zipFile, object start, object length) { }

	// RVA: 0x366CC08
	public override object ReadByte() { }

	// RVA: 0x366CDB0
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x366CFFC
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x366D03C
	public override object SetLength(object value) { }

	// RVA: 0x366D07C
	public override object Seek(object offset, object origin) { }

	// RVA: 0x366D16C
	public override object Flush() { }

	// RVA: 0x366D170
	public override object get_Position() { }

	// RVA: 0x366D180
	public override object set_Position(object value) { }

	// RVA: 0x366D248
	public override object get_Length() { }

	// RVA: 0x366D250
	public override object get_CanWrite() { }

	// RVA: 0x366D258
	public override object get_CanSeek() { }

	// RVA: 0x366D260
	public override object get_CanRead() { }

	// RVA: 0x366D268
	public override object get_CanTimeout() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public class ZipFile
{

	// Fields
	public object KeysRequired; // 0x8
	private object isDisposed_; // 0x10
	private object name_; // 0x18
	private object comment_; // 0x20
	private object rawPassword_; // 0x28
	private object baseStream_; // 0x30
	private object isStreamOwner; // 0x38
	private object offsetOfFirstEntry; // 0x40
	private object entries_; // 0x48
	private object key; // 0x50
	private object isNewArchive_; // 0x58
	private object useZip64_; // 0x5C
	private object updates_; // 0x60
	private object updateIndex_; // 0x68
	private object archiveStorage_; // 0x70
	private object updateDataSource_; // 0x78
	private object bufferSize_; // 0x80
	private object updateEntryFactory_; // 0x88

	// Properties
	private object HaveKeys { get; }
	public object IsStreamOwner { get; }

	// Methods

	// RVA: 0x3667B94
	private object OnKeysRequired(object fileName) { }

	// RVA: 0x3667CA4
	private object get_HaveKeys() { }

	// RVA: 0x3667CB4
	public object .ctor(object name) { }

	// RVA: 0x3668AD0
	public object .ctor(object stream) { }

	// RVA: 0x3668AD8
	public object .ctor(object stream, object leaveOpen) { }

	// RVA: 0x3668D38
	internal object .ctor() { }

	// RVA: 0x3668DDC
	protected override object Finalize() { }

	// RVA: 0x3668E94
	public object Close() { }

	// RVA: 0x3668F34
	public static object Create(object fileName) { }

	// RVA: 0x3669080
	public object get_IsStreamOwner() { }

	// RVA: 0x3669088
	public object GetEnumerator() { }

	// RVA: 0x366917C
	public object FindEntry(object name, object ignoreCase) { }

	// RVA: 0x36692D8
	public object GetInputStream(object entry) { }

	// RVA: 0x3669488
	public object GetInputStream(object entryIndex) { }

	// RVA: 0x366A348
	private object TestLocalHeader(object entry, object tests) { }

	// RVA: 0x366B898
	private object PostUpdateCleanup() { }

	// RVA: 0x366B968
	private object System.IDisposable.Dispose() { }

	// RVA: 0x36688C0
	private object DisposeInternal(object disposing) { }

	// RVA: 0x366BA08
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x366B60C
	private object ReadLEUshort() { }

	// RVA: 0x366B5DC
	private object ReadLEUint() { }

	// RVA: 0x366BA10
	private object ReadLEUlong() { }

	// RVA: 0x366BA70
	private object LocateBlockWithSignature(object signature, object endLocation, object minimumBlockSize, object maximumVariableData) { }

	// RVA: 0x3667E38
	private object ReadEntries() { }

	// RVA: 0x36697FC
	private object LocateEntry(object entry) { }

	// RVA: 0x36698CC
	private object CreateAndInitDecryptionStream(object baseStream, object entry) { }

	// RVA: 0x366C668
	private static object CheckClassicPassword(object classicCryptoStream, object entry) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public interface IDynamicDataSource
{
}

// Namespace: ICSharpCode.SharpZipLib.Zip
public interface IArchiveStorage
{

	// Methods

	// RVA: -1
	public abstract object Dispose() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
internal class ZipHelperStream
{

	// Fields
	private object isOwner_; // 0x20
	private object stream_; // 0x28

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanTimeout { get; }
	public override object Length { get; }
	public override object Position { get; set; }
	public override object CanWrite { get; }

	// Methods

	// RVA: 0x3667774
	public object .ctor(object stream) { }

	// RVA: 0x366D2B4
	public override object get_CanRead() { }

	// RVA: 0x366D300
	public override object get_CanSeek() { }

	// RVA: 0x366D34C
	public override object get_CanTimeout() { }

	// RVA: 0x366D398
	public override object get_Length() { }

	// RVA: 0x366D3E4
	public override object get_Position() { }

	// RVA: 0x366D434
	public override object set_Position(object value) { }

	// RVA: 0x366D48C
	public override object get_CanWrite() { }

	// RVA: 0x366D4D8
	public override object Flush() { }

	// RVA: 0x366D528
	public override object Seek(object offset, object origin) { }

	// RVA: 0x366D590
	public override object SetLength(object value) { }

	// RVA: 0x366D5E8
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x366D658
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x366D6C8
	protected override object Dispose(object disposing) { }

	// RVA: 0x366BC50
	public object LocateBlockWithSignature(object signature, object endLocation, object minimumBlockSize, object maximumVariableData) { }

	// RVA: 0x366D6F4
	public object ReadLEShort() { }

	// RVA: 0x36677E4
	public object ReadLEInt() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public class ZipNameTransform
{

	// Fields
	private static readonly object InvalidEntryChars; // 0x0
	private static readonly object InvalidEntryCharsRelaxed; // 0x8

	// Methods

	// RVA: 0x36670C4
	public object .ctor() { }

	// RVA: 0x366D7CC
	private static object .cctor() { }

	// RVA: 0x366B79C
	public static object IsValidName(object name, object relaxed) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip
public static class ZipStrings
{

	// Fields
	private static object codePage; // 0x0
	private static readonly object <SystemDefaultCodePage>k__BackingField; // 0x4

	// Properties
	public static object CodePage { get; set; }
	public static object SystemDefaultCodePage { get; }
	public static object UseUnicode { get; }

	// Methods

	// RVA: 0x366D9AC
	private static object .cctor() { }

	// RVA: 0x366DB10
	public static object get_CodePage() { }

	// RVA: 0x3665858
	public static object set_CodePage(object value) { }

	// RVA: 0x366DC0C
	public static object get_SystemDefaultCodePage() { }

	// RVA: 0x3665B64
	public static object get_UseUnicode() { }

	// RVA: 0x366DC88
	public static object ConvertToString(object data, object count) { }

	// RVA: 0x366BD80
	public static object ConvertToString(object data) { }

	// RVA: 0x366DD70
	private static object EncodingFromFlag(object flags) { }

	// RVA: 0x366BFA8
	public static object ConvertToStringExt(object flags, object data, object count) { }

	// RVA: 0x366B720
	public static object ConvertToStringExt(object flags, object data) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip.Compression
public class DeflaterHuffman
{

	// Fields
	private static readonly object BL_ORDER; // 0x0
	private static readonly object bit4Reverse; // 0x8
	private static object staticLCodes; // 0x10
	private static object staticLLength; // 0x18
	private static object staticDCodes; // 0x20
	private static object staticDLength; // 0x28

	// Methods

	// RVA: 0x366DEA0
	private static object .cctor() { }

	// RVA: 0x366E424
	public static object BitReverse(object toReverse) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip.Compression
public class Inflater
{

	// Fields
	private static readonly object CPLENS; // 0x0
	private static readonly object CPLEXT; // 0x8
	private static readonly object CPDIST; // 0x10
	private static readonly object CPDEXT; // 0x18
	private object mode; // 0x8
	private object readAdler; // 0xC
	private object neededBits; // 0x10
	private object repLength; // 0x14
	private object repDist; // 0x18
	private object uncomprLen; // 0x1C
	private object isLastBlock; // 0x20
	private object totalOut; // 0x28
	private object totalIn; // 0x30
	private object noHeader; // 0x38
	private readonly object input; // 0x40
	private object outputWindow; // 0x48
	private object dynHeader; // 0x50
	private object litlenTree; // 0x58
	private object distTree; // 0x60
	private object adler; // 0x68

	// Properties
	public object IsNeedingInput { get; }
	public object IsNeedingDictionary { get; }
	public object IsFinished { get; }

	// Methods

	// RVA: 0x3669D3C
	public object .ctor(object noHeader) { }

	// RVA: 0x366E5AC
	private object DecodeHeader() { }

	// RVA: 0x366E804
	private object DecodeDict() { }

	// RVA: 0x366E8E8
	private object DecodeHuffman() { }

	// RVA: 0x366F3AC
	private object DecodeChksum() { }

	// RVA: 0x366F63C
	private object Decode() { }

	// RVA: 0x36701A4
	public object SetInput(object buffer, object index, object count) { }

	// RVA: 0x36703BC
	public object Inflate(object buffer, object offset, object count) { }

	// RVA: 0x36709A0
	public object get_IsNeedingInput() { }

	// RVA: 0x36709CC
	public object get_IsNeedingDictionary() { }

	// RVA: 0x3670668
	public object get_IsFinished() { }

	// RVA: 0x36709F0
	private static object .cctor() { }

}

// Namespace: 
private sealed class <CreateStateMachine>d__7
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x10
	public object <>4__this; // 0x18
	private object <dataCodeCount>5__2; // 0x20
	private object <metaCodeTree>5__3; // 0x28
	private object <index>5__4; // 0x30
	private object <i>5__5; // 0x34
	private object <codeLength>5__6; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Boolean>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x3670BC8
	public object .ctor(object <>1__state) { }

	// RVA: 0x3670C98
	private object System.IDisposable.Dispose() { }

	// RVA: 0x3670C9C
	private object MoveNext() { }

	// RVA: 0x36718D4
	private object System.Collections.Generic.IEnumerator<System.Boolean>.get_Current() { }

	// RVA: 0x36718DC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x367191C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x3671984
	private object System.Collections.Generic.IEnumerable<System.Boolean>.GetEnumerator() { }

	// RVA: 0x3671A30
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip.Compression
internal class InflaterDynHeader
{

	// Fields
	private static readonly object MetaCodeLengthIndex; // 0x0
	private readonly object input; // 0x8
	private readonly object state; // 0x10
	private readonly object stateMachine; // 0x18
	private object codeLengths; // 0x20
	private object litLenTree; // 0x28
	private object distTree; // 0x30
	private object litLenCodeCount; // 0x38
	private object distanceCodeCount; // 0x3C
	private object metaCodeCount; // 0x40

	// Properties
	public object LiteralLengthTree { get; }
	public object DistanceTree { get; }

	// Methods

	// RVA: 0x366FF50
	public object AttemptRead() { }

	// RVA: 0x366FCB8
	public object .ctor(object input) { }

	// RVA: 0x3670B4C
	private object CreateStateMachine() { }

	// RVA: 0x36700EC
	public object get_LiteralLengthTree() { }

	// RVA: 0x3670148
	public object get_DistanceTree() { }

	// RVA: 0x3670C00
	private static object .cctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip.Compression
public class InflaterHuffmanTree
{

	// Fields
	private object tree; // 0x8
	public static object defLitLenTree; // 0x0
	public static object defDistTree; // 0x8

	// Methods

	// RVA: 0x3671ADC
	private static object .cctor() { }

	// RVA: 0x36718A4
	public object .ctor(object codeLengths) { }

	// RVA: 0x367205C
	private object BuildTree(object codeLengths) { }

	// RVA: 0x366EF80
	public object GetSymbol(object input) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip.Compression.Streams
public class InflaterInputBuffer
{

	// Fields
	private object rawLength; // 0x8
	private object rawData; // 0x10
	private object clearTextLength; // 0x18
	private object clearText; // 0x20
	private object available; // 0x28
	private object cryptoTransform; // 0x30
	private object inputStream; // 0x38

	// Properties
	public object Available { get; }

	// Methods

	// RVA: 0x36728E8
	public object .ctor(object stream, object bufferSize) { }

	// RVA: 0x3672970
	public object get_Available() { }

	// RVA: 0x3672978
	public object SetInflaterInput(object inflater) { }

	// RVA: 0x36729F8
	public object Fill() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip.Compression.Streams
public class InflaterInputStream
{

	// Fields
	private object <IsStreamOwner>k__BackingField; // 0x20
	protected object inf; // 0x28
	protected object inputBuffer; // 0x30
	private object baseInputStream; // 0x38
	private object isClosed; // 0x40

	// Properties
	public object IsStreamOwner { get; }
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x3669E6C
	public object .ctor(object baseInputStream, object inf) { }

	// RVA: 0x3672BD0
	public object .ctor(object baseInputStream, object inflater, object bufferSize) { }

	// RVA: 0x3672DB8
	public object get_IsStreamOwner() { }

	// RVA: 0x3672DC0
	protected object Fill() { }

	// RVA: 0x3672EB4
	public override object get_CanRead() { }

	// RVA: 0x3672F00
	public override object get_CanSeek() { }

	// RVA: 0x3672F08
	public override object get_CanWrite() { }

	// RVA: 0x3672F10
	public override object get_Length() { }

	// RVA: 0x3672F64
	public override object get_Position() { }

	// RVA: 0x3672FB4
	public override object set_Position(object value) { }

	// RVA: 0x3673008
	public override object Flush() { }

	// RVA: 0x3673058
	public override object Seek(object offset, object origin) { }

	// RVA: 0x36730AC
	public override object SetLength(object value) { }

	// RVA: 0x3673100
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x3673154
	public override object WriteByte(object value) { }

	// RVA: 0x36731A8
	protected override object Dispose(object disposing) { }

	// RVA: 0x36731EC
	public override object Read(object buffer, object offset, object count) { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip.Compression.Streams
public class OutputWindow
{

	// Fields
	private object window; // 0x8
	private object windowEnd; // 0x10
	private object windowFilled; // 0x14

	// Methods

	// RVA: 0x366EEC8
	public object Write(object value) { }

	// RVA: 0x3673374
	private object SlowRepeat(object repStart, object length, object distance) { }

	// RVA: 0x366F210
	public object Repeat(object length, object distance) { }

	// RVA: 0x366FE08
	public object CopyStored(object input, object length) { }

	// RVA: 0x366EEB8
	public object GetFreeSpace() { }

	// RVA: 0x36735E0
	public object GetAvailable() { }

	// RVA: 0x36706A8
	public object CopyOutput(object output, object offset, object len) { }

	// RVA: 0x366E548
	public object .ctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Zip.Compression.Streams
public class StreamManipulator
{

	// Fields
	private object window_; // 0x8
	private object windowStart_; // 0x10
	private object windowEnd_; // 0x14
	private object buffer_; // 0x18
	private object bitsInBuffer_; // 0x1C

	// Properties
	public object AvailableBits { get; }
	public object AvailableBytes { get; }
	public object IsNeedingInput { get; }

	// Methods

	// RVA: 0x366E734
	public object PeekBits(object bitCount) { }

	// RVA: 0x36716F0
	public object TryGetBits(object bitCount, object output, object outputOffset) { }

	// RVA: 0x36717B8
	public object TryGetBits(object bitCount, object array, object index) { }

	// RVA: 0x366E7F0
	public object DropBits(object bitCount) { }

	// RVA: 0x36735E8
	public object get_AvailableBits() { }

	// RVA: 0x36733F4
	public object get_AvailableBytes() { }

	// RVA: 0x366FCA0
	public object SkipToByteBoundary() { }

	// RVA: 0x366FF40
	public object get_IsNeedingInput() { }

	// RVA: 0x3673408
	public object CopyBytes(object output, object offset, object length) { }

	// RVA: 0x36701E8
	public object SetInput(object buffer, object offset, object count) { }

	// RVA: 0x366E540
	public object .ctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Encryption
public abstract class PkzipClassic
{

	// Methods

	// RVA: 0x36735F0
	protected object .ctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Encryption
internal class PkzipClassicCryptoBase
{

	// Fields
	private object keys; // 0x8

	// Methods

	// RVA: 0x36735F8
	protected object TransformByte() { }

	// RVA: 0x3673644
	protected object SetKeys(object keyData) { }

	// RVA: 0x36737A4
	protected object UpdateKeys(object ch) { }

	// RVA: 0x3673998
	protected object Reset() { }

	// RVA: 0x36739E4
	public object .ctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Encryption
internal class PkzipClassicEncryptCryptoTransform
{

	// Properties
	public object InputBlockSize { get; }
	public object OutputBlockSize { get; }
	public object CanTransformMultipleBlocks { get; }

	// Methods

	// RVA: 0x36739EC
	internal object .ctor(object keyBlock) { }

	// RVA: 0x3673A1C
	public object TransformFinalBlock(object inputBuffer, object inputOffset, object inputCount) { }

	// RVA: 0x3673AAC
	public object TransformBlock(object inputBuffer, object inputOffset, object inputCount, object outputBuffer, object outputOffset) { }

	// RVA: 0x3673BD8
	public object get_InputBlockSize() { }

	// RVA: 0x3673BE0
	public object get_OutputBlockSize() { }

	// RVA: 0x3673BE8
	public object get_CanTransformMultipleBlocks() { }

	// RVA: 0x3673BF0
	public object Dispose() { }

}

// Namespace: ICSharpCode.SharpZipLib.Encryption
internal class PkzipClassicDecryptCryptoTransform
{

	// Properties
	public object InputBlockSize { get; }
	public object OutputBlockSize { get; }
	public object CanTransformMultipleBlocks { get; }

	// Methods

	// RVA: 0x3673C3C
	internal object .ctor(object keyBlock) { }

	// RVA: 0x3673C6C
	public object TransformFinalBlock(object inputBuffer, object inputOffset, object inputCount) { }

	// RVA: 0x3673CFC
	public object TransformBlock(object inputBuffer, object inputOffset, object inputCount, object outputBuffer, object outputOffset) { }

	// RVA: 0x3673E30
	public object get_InputBlockSize() { }

	// RVA: 0x3673E38
	public object get_OutputBlockSize() { }

	// RVA: 0x3673E40
	public object get_CanTransformMultipleBlocks() { }

	// RVA: 0x3673E48
	public object Dispose() { }

}

// Namespace: ICSharpCode.SharpZipLib.Encryption
public sealed class PkzipClassicManaged
{

	// Fields
	private object key_; // 0x40

	// Properties
	public override object BlockSize { get; set; }
	public override object LegalKeySizes { get; }
	public override object Key { get; set; }

	// Methods

	// RVA: 0x3673E94
	public override object get_BlockSize() { }

	// RVA: 0x3673E9C
	public override object set_BlockSize(object value) { }

	// RVA: 0x3673EFC
	public override object get_LegalKeySizes() { }

	// RVA: 0x3673FAC
	public override object GenerateIV() { }

	// RVA: 0x3673FB0
	public override object get_Key() { }

	// RVA: 0x3674064
	public override object set_Key(object value) { }

	// RVA: 0x36741BC
	public override object GenerateKey() { }

	// RVA: 0x367437C
	public override object CreateEncryptor(object rgbKey, object rgbIV) { }

	// RVA: 0x367441C
	public override object CreateDecryptor(object rgbKey, object rgbIV) { }

	// RVA: 0x366C660
	public object .ctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Encryption
internal class ZipAESStream
{

	// Fields
	private object _stream; // 0x70
	private object _transform; // 0x78
	private object _slideBuffer; // 0x80
	private object _slideBufStartPos; // 0x88
	private object _slideBufFreePos; // 0x8C
	private object _transformBuffer; // 0x90
	private object _transformBufferFreePos; // 0x98
	private object _transformBufferStartPos; // 0x9C

	// Properties
	private object HasBufferedData { get; }

	// Methods

	// RVA: 0x366C588
	public object .ctor(object stream, object transform, object mode) { }

	// RVA: 0x36744BC
	private object get_HasBufferedData() { }

	// RVA: 0x36744DC
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x3674A88
	public override object ReadAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x36746C4
	private object ReadAndTransform(object buffer, object offset, object count) { }

	// RVA: 0x3674608
	private object ReadBufferedData(object buffer, object offset, object count) { }

	// RVA: 0x3674B68
	private object TransformAndBufferBlock(object buffer, object offset, object count, object blockSize) { }

	// RVA: 0x3674FA4
	public override object Write(object buffer, object offset, object count) { }

}

// Namespace: ICSharpCode.SharpZipLib.Encryption
internal class ZipAESTransform
{

	// Fields
	private object _blockSize; // 0x8
	private readonly object _encryptor; // 0x10
	private readonly object _counterNonce; // 0x18
	private object _encryptBuffer; // 0x20
	private object _encrPos; // 0x28
	private object _pwdVerifier; // 0x30
	private object _hmacsha1; // 0x38
	private object _authCode; // 0x40
	private object _writeMode; // 0x48

	// Properties
	public object PwdVerifier { get; }
	public object InputBlockSize { get; }
	public object OutputBlockSize { get; }
	public object CanTransformMultipleBlocks { get; }

	// Methods

	// RVA: 0x366C234
	public object .ctor(object key, object saltBytes, object blockSize, object writeMode) { }

	// RVA: 0x3674CF0
	public object TransformBlock(object inputBuffer, object inputOffset, object inputCount, object outputBuffer, object outputOffset) { }

	// RVA: 0x3674FE4
	public object get_PwdVerifier() { }

	// RVA: 0x3674C9C
	public object GetAuthCode() { }

	// RVA: 0x3674FEC
	public object TransformFinalBlock(object inputBuffer, object inputOffset, object inputCount) { }

	// RVA: 0x3675084
	public object get_InputBlockSize() { }

	// RVA: 0x367508C
	public object get_OutputBlockSize() { }

	// RVA: 0x3675094
	public object get_CanTransformMultipleBlocks() { }

	// RVA: 0x367509C
	public object Dispose() { }

}

// Namespace: ICSharpCode.SharpZipLib.Core
internal static class Empty
{

	// Methods

	// RVA: -1
	public static object Array() { }

}

// Namespace: ICSharpCode.SharpZipLib.Core
public interface INameTransform
{
}

// Namespace: ICSharpCode.SharpZipLib.Core
public sealed class StreamUtils
{

	// Methods

	// RVA: 0x366B6FC
	public static object ReadFully(object stream, object buffer) { }

	// RVA: 0x366BE00
	public static object ReadFully(object stream, object buffer, object offset, object count) { }

	// RVA: 0x366C090
	public static object ReadRequestedBytes(object stream, object buffer, object offset, object count) { }

}

// Namespace: ICSharpCode.SharpZipLib.Checksum
public sealed class Adler32
{

	// Fields
	private static readonly object BASE; // 0x0
	private object checkValue; // 0x8

	// Properties
	public object Value { get; }

	// Methods

	// RVA: 0x366E514
	public object .ctor() { }

	// RVA: 0x367517C
	public object Reset() { }

	// RVA: 0x366F630
	public object get_Value() { }

	// RVA: 0x3675188
	public object Update(object bval) { }

	// RVA: 0x3670794
	public object Update(object segment) { }

	// RVA: 0x367521C
	private static object .cctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Checksum
public sealed class BZip2Crc
{

	// Fields
	private static readonly object crcTable; // 0x0
	private object checkValue; // 0x8

	// Properties
	public object Value { get; }

	// Methods

	// RVA: 0x367526C
	public object .ctor() { }

	// RVA: 0x3675298
	public object Reset() { }

	// RVA: 0x36752A4
	public object get_Value() { }

	// RVA: 0x36752B0
	public object Update(object bval) { }

	// RVA: 0x3675370
	private static object .cctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Checksum
public sealed class Crc32
{

	// Fields
	private static readonly object crcInit; // 0x0
	private static readonly object crcXor; // 0x4
	private static readonly object crcTable; // 0x8

	// Methods

	// RVA: 0x3675564
	internal static object ComputeCrc32(object oldCrc, object bval) { }

	// RVA: 0x3675618
	private static object .cctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.Checksum
internal static class CrcUtilities
{

	// Methods

	// RVA: 0x36753CC
	internal static object GenerateSlicingLookupTable(object polynomial, object isReversed) { }

}

// Namespace: ICSharpCode.SharpZipLib.Checksum
public interface IChecksum
{

	// Properties
	public abstract object Value { get; }

	// Methods

	// RVA: -1
	public abstract object Reset() { }

	// RVA: -1
	public abstract object get_Value() { }

	// RVA: -1
	public abstract object Update(object bval) { }

}

// Namespace: ICSharpCode.SharpZipLib.BZip2
internal static class BZip2Constants
{

	// Fields
	public static readonly object RandomNumbers; // 0x0

	// Methods

	// RVA: 0x3675684
	private static object .cctor() { }

}

// Namespace: ICSharpCode.SharpZipLib.BZip2
public class BZip2Exception
{

	// Methods

	// RVA: 0x367571C
	public object .ctor() { }

	// RVA: 0x36757A4
	public object .ctor(object message) { }

	// RVA: 0x3675810
	protected object .ctor(object info, object context) { }

}

// Namespace: ICSharpCode.SharpZipLib.BZip2
public class BZip2InputStream
{

	// Fields
	private object last; // 0x20
	private object origPtr; // 0x24
	private object blockSize100k; // 0x28
	private object blockRandomised; // 0x2C
	private object bsBuff; // 0x30
	private object bsLive; // 0x34
	private object mCrc; // 0x38
	private object inUse; // 0x40
	private object nInUse; // 0x48
	private object seqToUnseq; // 0x50
	private object unseqToSeq; // 0x58
	private object selector; // 0x60
	private object selectorMtf; // 0x68
	private object tt; // 0x70
	private object ll8; // 0x78
	private object unzftab; // 0x80
	private object limit; // 0x88
	private object baseArray; // 0x90
	private object perm; // 0x98
	private object minLens; // 0xA0
	private readonly object baseStream; // 0xA8
	private object streamEnd; // 0xB0
	private object currentChar; // 0xB4
	private object currentState; // 0xB8
	private object storedBlockCRC; // 0xBC
	private object storedCombinedCRC; // 0xC0
	private object computedBlockCRC; // 0xC4
	private object computedCombinedCRC; // 0xC8
	private object count; // 0xCC
	private object chPrev; // 0xD0
	private object ch2; // 0xD4
	private object tPos; // 0xD8
	private object rNToGo; // 0xDC
	private object rTPos; // 0xE0
	private object i2; // 0xE4
	private object j2; // 0xE8
	private object z; // 0xEC
	private object <IsStreamOwner>k__BackingField; // 0xED

	// Properties
	public object IsStreamOwner { get; }
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x3669E74
	public object .ctor(object stream) { }

	// RVA: 0x3675F28
	public object get_IsStreamOwner() { }

	// RVA: 0x3675F30
	public override object get_CanRead() { }

	// RVA: 0x3675F7C
	public override object get_CanSeek() { }

	// RVA: 0x3675F84
	public override object get_CanWrite() { }

	// RVA: 0x3675F8C
	public override object get_Length() { }

	// RVA: 0x3675FD8
	public override object get_Position() { }

	// RVA: 0x3676028
	public override object set_Position(object value) { }

	// RVA: 0x367607C
	public override object Flush() { }

	// RVA: 0x36760CC
	public override object Seek(object offset, object origin) { }

	// RVA: 0x3676120
	public override object SetLength(object value) { }

	// RVA: 0x3676174
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x36761C8
	public override object WriteByte(object value) { }

	// RVA: 0x367621C
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x3676328
	protected override object Dispose(object disposing) { }

	// RVA: 0x3676360
	public override object ReadByte() { }

	// RVA: 0x36768BC
	private object MakeMaps() { }

	// RVA: 0x3675894
	private object Initialize() { }

	// RVA: 0x3675A08
	private object InitBlock() { }

	// RVA: 0x3677740
	private object EndBlock() { }

	// RVA: 0x3676AB8
	private object Complete() { }

	// RVA: 0x36778C4
	private object FillBuffer() { }

	// RVA: 0x3676CB0
	private object BsR(object n) { }

	// RVA: 0x3676978
	private object BsGetUChar() { }

	// RVA: 0x3677A4C
	private object BsGetIntVS(object numBits) { }

	// RVA: 0x3676B84
	private object BsGetInt32() { }

	// RVA: 0x3677AA8
	private object RecvDecodingTables() { }

	// RVA: 0x3676D0C
	private object GetAndMoveToFrontDecode() { }

	// RVA: 0x3675D68
	private object SetupBlock() { }

	// RVA: 0x3678B5C
	private object SetupRandPartA() { }

	// RVA: 0x3678D6C
	private object SetupNoRandPartA() { }

	// RVA: 0x3676404
	private object SetupRandPartB() { }

	// RVA: 0x3676590
	private object SetupRandPartC() { }

	// RVA: 0x36766C4
	private object SetupNoRandPartB() { }

	// RVA: 0x3676788
	private object SetupNoRandPartC() { }

	// RVA: 0x36769C8
	private object SetDecompressStructureSizes(object newSize100k) { }

	// RVA: 0x36779F8
	private static object CompressedStreamEOF() { }

	// RVA: 0x3678B0C
	private static object BlockOverrun() { }

	// RVA: 0x3676B34
	private static object BadBlockHeader() { }

	// RVA: 0x3677874
	private static object CrcError() { }

	// RVA: 0x3678414
	private static object HbCreateDecodeTables(object limit, object baseArray, object perm, object length, object minLen, object maxLen, object alphaSize) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=16
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=76
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=116
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=120
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=2048
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 52AA14DBFAD385CC0A67E081C133BE3C353A46E2260E564186F0FEF33B8874E5; // 0x0
	internal static readonly object A7BECD43C1DE3B2E78F02487AF261536EF05E65091673703AE6BC720345CCF2D; // 0x74
	internal static readonly object B23D510F520CB4BA8AFA847F8A40E757C40CB6A55B237EFA1AC6D3984911B114; // 0x84
	internal static readonly object C133E473E5E653C5C4AEDB8BCC1C1A3A44D384FC0B6C0FCF04672B1B325EC01B; // 0xFC
	internal static readonly object F8D7861760C88CC514F66095AF0AED47ECBA063ADB65F47125ED07BCC2CF9842; // 0x148
	internal static readonly object FA6F7D5596F6084EE582060B76239C49C1BF8567F7EA556E2D83971C75E26951; // 0x1BC
	internal static readonly object FC216F5C5AE2947D800794ECD5F752EE8381073C2E5D0D095FDA040F541702F3; // 0x9BC
}

