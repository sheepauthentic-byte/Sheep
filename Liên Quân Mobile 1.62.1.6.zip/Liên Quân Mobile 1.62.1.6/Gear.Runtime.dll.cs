// Namespace: 
internal class <Module>
{
}

// Namespace: 
public static class MaterialExt
{

	// Methods

	// RVA: 0x1020A54
	public static object TryGetTexture(object mat, object propName, object defaultValue) { }

}

// Namespace: 
public enum Level
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Production;
	public const object Development;
}

// Namespace: Gear
public class Verbose
{

	// Fields
	public readonly object level; // 0x8
	public readonly object show; // 0xC

	// Methods

	// RVA: 0x1020C2C
	public object .ctor(object level) { }

	// RVA: 0x1020C5C
	public object .ctor(object level, object show) { }

}

// Namespace: Gear
public class WarningAttribute
{

	// Fields
	public object warning; // 0x8

	// Methods

	// RVA: 0x1020C98
	public object .ctor(object warning) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__2_0; // 0x8

	// Methods

	// RVA: 0x1020E34
	private static object .cctor() { }

	// RVA: 0x1020E94
	public object .ctor() { }

	// RVA: 0x1020E9C
	internal object <GetAllAssemblyTypes>b__2_0(object t) { }

}

// Namespace: 
private sealed class <>c__3<T0>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <GetAllTypesDerivedFrom>b__3_0(object t) { }

}

// Namespace: Gear
public class CSharpUtils
{

	// Fields
	private static object m_AssemblyTypes; // 0x0

	// Methods

	// RVA: 0x1020CC4
	public static object GetAllAssemblyTypes() { }

	// RVA: -1
	public static object GetAllTypesDerivedFrom() { }

}

// Namespace: Gear
public class GPUChecker
{

	// Methods

	// RVA: 0x1020FBC
	public static object CheckGPUPowerVR() { }

}

// Namespace: 
public sealed class LogCallback
{

	// Methods

	// RVA: 0x1021720
	public object .ctor(object object, object method) { }

	// RVA: 0x1021934
	public virtual object Invoke(object msg) { }

}

// Namespace: 
public sealed class LogFormatCallback
{

	// Methods

	// RVA: 0x10217C8
	public object .ctor(object object, object method) { }

	// RVA: 0x10219E4
	public virtual object Invoke(object format, object args) { }

}

// Namespace: Gear
public static class Logger
{

	// Fields
	public static object LogError; // 0x0
	public static object LogInfo; // 0x8
	public static object LogWarning; // 0x10
	public static object LogErrorInEditor; // 0x18
	public static object ForceLogError; // 0x20
	public static object ForceLogWarning; // 0x28
	public static object LogInfoFormat; // 0x30
	public static object LogErrorFormat; // 0x38

	// Methods

	// RVA: 0x1020FC4
	public static object LogErrorDefault(object msg) { }

	// RVA: 0x102104C
	public static object LogInfoDefault(object msg) { }

	// RVA: 0x10210D4
	public static object LogWarningDefault(object msg) { }

	// RVA: 0x102115C
	public static object LogInfoFormatDefault(object format, object args) { }

	// RVA: 0x10211C8
	public static object LogErrorFormatDefault(object format, object args) { }

	// RVA: 0x1021234
	private static object LogErrorInEditorDefault(object msg) { }

	// RVA: 0x1021238
	private static object .cctor() { }

}

// Namespace: Gear
public static class Math3D
{

	// Methods

	// RVA: 0x10219F8
	public static object LookAtRH(object from, object to, object up) { }

	// RVA: 0x1021A10
	public static object OrthoRH(object left, object right, object bottom, object top, object zNear, object zFar) { }

	// RVA: 0x1021A18
	public static object FlipZ(object m) { }

	// RVA: 0x1021A4C
	public static object FlipY(object m) { }

	// RVA: 0x1021A80
	public static object ScaleOffsetMatrix(object scale, object offset) { }

	// RVA: 0x1021B1C
	public static object SphereFitViewFrustum(object frustumCorners) { }

	// RVA: 0x1021CB4
	public static object TransformPlane(object m, object plane) { }

	// RVA: 0x1021E04
	public static object CalculateRoundingMatrix(object projMat, object viewMat, object shadowMapSize) { }

	// RVA: 0x10220F0
	public static object CalculateObliqueMatrix(object projection, object clipPlane) { }

}

// Namespace: Gear
public static class BoundingSphereExt
{

	// Methods

	// RVA: 0x1022290
	public static object Transform(object sphere, object m) { }

}

// Namespace: Gear
public static class RectExt
{

	// Methods

	// RVA: 0x10222D8
	public static object Scale(object rect, object dx, object dy) { }

	// RVA: 0x10222F0
	public static object Move(object rect, object dX, object dY) { }

	// RVA: 0x1022304
	public static object GetXMax(object rect) { }

	// RVA: 0x102230C
	public static object GetYMax(object rect) { }

}

// Namespace: Gear
public static class VectorExt
{

	// Methods

	// RVA: 0x1022314
	public static object Rcp(object a) { }

	// RVA: 0x1022324
	public static object Add(object a, object b) { }

	// RVA: 0x1022330
	public static object Dot3(object a, object b) { }

	// RVA: 0x1022348
	public static object Mul(object a, object b) { }

	// RVA: 0x1022358
	public static object ToVec3(object c) { }

	// RVA: 0x102235C
	public static object MaxComponent(object a) { }

	// RVA: 0x1022370
	public static object Equal(object a, object b) { }

	// RVA: 0x10223C8
	public static object Abs(object lhs) { }

}

// Namespace: Gear
public static class QuaternionExt
{

	// Methods

	// RVA: 0x10223D8
	public static object Equal(object a, object b) { }

}

// Namespace: Gear
public static class Vector4Ext
{

	// Methods

	// RVA: 0x1022448
	public static object xyz(object v) { }

}

// Namespace: Gear
public class Singleton<T0>
{

	// Fields
	private static object s_instance; // 0x0

	// Properties
	public static object Instance { get; }

	// Methods

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	public static object CreateInstance() { }

	// RVA: -1
	public static object DestroyInstance() { }

	// RVA: -1
	public static object get_Instance() { }

	// RVA: -1
	public static object GetInstance() { }

	// RVA: -1
	protected virtual object Init() { }

	// RVA: -1
	protected virtual object UnInit() { }

}

// Namespace: 
public struct Desc
{

	// Fields
	public object ArrayIndex; // 0xFFFFFFFFFFFFFFF8
	public object MipLevel; // 0xFFFFFFFFFFFFFFFC
	public object DataOffset; // 0x0
}

// Namespace: Gear
public class TextureRawData
{

	// Fields
	public object Dimension; // 0x10
	public object Width; // 0x14
	public object Height; // 0x18
	public object ArraySize; // 0x1C
	public object NumOfMipLevels; // 0x20
	public object sRGB; // 0x24
	public object Format; // 0x28
	public object filterMode; // 0x2C
	public object DataLayout; // 0x30
	public object RawData; // 0x38

	// Methods

	// RVA: 0x102244C
	public object Deserialize() { }

	// RVA: 0x1022694
	public object .ctor() { }

}

