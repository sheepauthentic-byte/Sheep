// Namespace: 
internal class <Module>
{
}

// Namespace: System.Configuration
public abstract class ConfigurationElement
{

	// Properties
	protected internal virtual object Properties { get; }

	// Methods

	// RVA: 0x6CC57C8
	protected internal virtual object get_Properties() { }

	// RVA: 0x6CC5804
	protected internal virtual object IsModified() { }

	// RVA: 0x6CC5840
	protected internal virtual object Reset(object parentElement) { }

	// RVA: 0x6CC587C
	protected internal virtual object ResetModified() { }

}

// Namespace: System.Configuration
public abstract class ConfigurationSection
{

	// Methods

	// RVA: 0x6CC58B8
	protected internal virtual object DeserializeSection(object reader) { }

	// RVA: 0x6CC58F4
	protected internal override object IsModified() { }

	// RVA: 0x6CC5930
	protected internal override object ResetModified() { }

	// RVA: 0x6CC596C
	protected internal virtual object SerializeSection(object parentElement, object name, object saveMode) { }

}

// Namespace: System.Configuration
public enum ConfigurationSaveMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Full;
	public const object Minimal;
	public const object Modified;
}

// Namespace: System.Configuration
public class ConfigurationPropertyCollection
{
}

// Namespace: System.Configuration
public abstract class ConfigurationElementCollection
{
}

// Namespace: System.Configuration
public sealed class ConfigurationCollectionAttribute
{

	// Methods

	// RVA: 0x6CC59A8
	public object .ctor(object itemType) { }

}

// Namespace: System.Configuration
public class ConfigurationSectionGroup
{
}

// Namespace: System.Configuration
public sealed class IgnoreSection
{

	// Properties
	protected internal override object Properties { get; }

	// Methods

	// RVA: 0x6CC59AC
	public object .ctor() { }

	// RVA: 0x6CC59E8
	protected internal override object get_Properties() { }

	// RVA: 0x6CC5A24
	protected internal override object DeserializeSection(object xmlReader) { }

	// RVA: 0x6CC5A60
	protected internal override object IsModified() { }

	// RVA: 0x6CC5A9C
	protected internal override object Reset(object parentSection) { }

	// RVA: 0x6CC5AD8
	protected internal override object ResetModified() { }

	// RVA: 0x6CC5B14
	protected internal override object SerializeSection(object parentSection, object name, object saveMode) { }

}

// Namespace: Unity
internal sealed class ThrowStub
{

	// Methods

	// RVA: 0x6CC5B50
	public static object ThrowNotSupportedException() { }

}

