// Namespace: 
internal class <Module>
{
}

// Namespace: 
public interface IVarList<T0>
{

	// Properties
	public abstract object Count { get; }
	public abstract object Item { get; }

	// Methods

	// RVA: -1
	public abstract object get_Count() { }

	// RVA: -1
	public abstract object get_Item(object index) { }

}

// Namespace: 
public class PendingRemove<T0>
{

	// Fields
	private object pendingContainer; // 0x0
	private object targetListToRemove; // 0x0
	private object delegateRemove; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object listToRemove) { }

	// RVA: -1
	public object .ctor(object deleRemove) { }

	// RVA: -1
	public object AddRemove(object obj) { }

	// RVA: -1
	public object Update() { }

}

// Namespace: 
public abstract class ListViewBase
{

	// Fields
	protected object Context; // 0x8

	// Properties
	public object Capacity { get; set; }
	public object Count { get; }

	// Methods

	// RVA: 0x100D694
	public object get_Capacity() { }

	// RVA: 0x100D6F0
	public object set_Capacity(object value) { }

	// RVA: 0x100D75C
	public object get_Count() { }

	// RVA: 0x100D7B0
	public object Clear() { }

	// RVA: 0x100D82C
	public object Trim() { }

	// RVA: 0x100D888
	public object RemoveAt(object index) { }

	// RVA: 0x100D8F4
	public object RemoveRange(object index, object count) { }

	// RVA: 0x100D968
	public object Reverse() { }

	// RVA: 0x100D9C4
	public object Sort() { }

	// RVA: -1
	public static object DotNet2Sort(object array, object comparer) { }

	// RVA: -1
	public static object DotNet2Sort(object array, object comparison) { }

	// RVA: -1
	private static object qsort(object array, object low0, object high0, object comparer) { }

	// RVA: -1
	private static object qsort(object array, object low0, object high0, object comparison) { }

	// RVA: -1
	private static object swap(object array, object i, object j) { }

	// RVA: 0x100DA3C
	protected object .ctor() { }

}

// Namespace: 
private struct ComparerConverter
{

	// Fields
	private object ComparerRef; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	public object Compare(object x, object y) { }

}

// Namespace: 
private struct ComparisonConverter
{

	// Fields
	private object ComparerRef; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	public object Compare(object x, object y) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object Reference; // 0x0
	private object Iter; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object InReference) { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

}

// Namespace: 
private sealed class <>c__DisplayClass24_0
{

	// Fields
	public object comparers; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <SortByMultiCompare>b__0(object left, object right) { }

}

// Namespace: 
public class ListView<T0>
{

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object collection) { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object AddRange(object collection) { }

	// RVA: -1
	public object Exists(object match) { }

	// RVA: -1
	public object Find(object match) { }

	// RVA: -1
	public object FindAll(object match) { }

	// RVA: -1
	public object FindIndex(object match) { }

	// RVA: -1
	public object FindIndex(object startIndex, object match) { }

	// RVA: -1
	public object FindIndex(object startIndex, object count, object match) { }

	// RVA: -1
	public object BinarySearch(object item, object comparer) { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object IndexOf(object item) { }

	// RVA: -1
	public object Insert(object index, object item) { }

	// RVA: -1
	public object LastIndexOf(object item) { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	public object Sort(object comparer) { }

	// RVA: -1
	public object Sort(object comparison) { }

	// RVA: -1
	public object SortByMultiCompare(object comparers) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
public class ListLinqView<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object ToArray() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object Reference; // 0x0
	private object Iter; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object InReference) { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

}

// Namespace: 
public class DictionaryView<T0, T1>
{

	// Fields
	protected object Context; // 0x0

	// Properties
	public object Count { get; }
	public object Item { get; set; }
	public object Keys { get; }
	public object Values { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object get_Keys() { }

	// RVA: -1
	public object get_Values() { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object Reference; // 0x0
	private object Iter; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object InReference) { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

}

// Namespace: 
public class DictionaryObjectView<T0, T1>
{

	// Fields
	protected object Context; // 0x0

	// Properties
	public object Count { get; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
public abstract class ListValueViewBase
{

	// Fields
	protected object _size; // 0x8
	protected object _version; // 0xC
	protected const object DefaultCapacity;

	// Properties
	public object Count { get; }

	// Methods

	// RVA: 0x100DA44
	public object get_Count() { }

	// RVA: 0x100DA4C
	protected object .ctor() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object l; // 0x0
	private object next; // 0x0
	private object ver; // 0x0
	private object current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object l) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object VerifyState() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
public class ListValueView<T0>
{

	// Fields
	private object _items; // 0x0
	private static readonly object EmptyArray; // 0x0

	// Properties
	public object Capacity { get; set; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	private object GrowIfNeeded(object newCount) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object get_Capacity() { }

	// RVA: -1
	public object set_Capacity(object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	private object Shift(object start, object delta) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	private object CheckRange(object idx, object count) { }

	// RVA: -1
	public object RemoveRange(object index, object count) { }

	// RVA: -1
	public object IndexOf(object item) { }

	// RVA: -1
	public object IndexOf(object item, object index) { }

	// RVA: -1
	public object IndexOf(object item, object index, object count) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object Reference; // 0x0
	private object IterReference; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object InRefernce) { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

}

// Namespace: 
public struct ReadonlyContext<T0>
{

	// Fields
	private object Reference; // 0x0

	// Properties
	public object isValidReference { get; }
	public object Item { get; }
	public object Count { get; }

	// Methods

	// RVA: -1
	public object .ctor(object InReference) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	public object get_isValidReference() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object get_Count() { }

}

// Namespace: 
public static class ReadonlyContextExtension
{

	// Methods

	// RVA: -1
	public static object AddRange(object InListRef, object InTarget) { }

}

// Namespace: 
public static class QueueEx
{

	// Methods

	// RVA: -1
	public static object ContainsEx(object queue, object item) { }

}

// Namespace: 
public class ListKeyValueView<T0, T1>
{

	// Fields
	private object KeySelector; // 0x0
	private object m_List; // 0x0
	private object m_Key2Index; // 0x0

	// Properties
	public object Count { get; }
	public object Item { get; set; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor(object keySelector) { }

	// RVA: -1
	public virtual object Clear() { }

	// RVA: -1
	public object GetKey(object value) { }

	// RVA: -1
	public object GetKeys(object keys) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Item(object i) { }

	// RVA: -1
	public object set_Item(object i, object value) { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	private object UpdateIndexData(object i, object value) { }

	// RVA: -1
	public object AddRange(object list) { }

	// RVA: -1
	public object AddRange(object collection) { }

	// RVA: -1
	public object Add(object value) { }

	// RVA: -1
	public object GetIndex(object key) { }

	// RVA: -1
	public object GetIndexData(object i) { }

	// RVA: -1
	public object GetKeyData(object key) { }

	// RVA: -1
	public object Insert(object i, object value) { }

	// RVA: -1
	public object RemoveAt(object i) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object Remove(object value) { }

	// RVA: -1
	private object UpdateIndex() { }

	// RVA: -1
	protected virtual object OnBeforeUpdateIndex() { }

	// RVA: -1
	protected virtual object OnAfterUpdateIndex() { }

	// RVA: -1
	protected virtual object OnUpdateIndex(object i, object key, object value) { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object Contains(object key) { }

	// RVA: -1
	public object IndexOf(object item) { }

	// RVA: -1
	public object Sort(object comparer) { }

	// RVA: -1
	public object Sort(object comparison) { }

	// RVA: -1
	public object GetEnumerator() { }

}

// Namespace: 
public sealed class RefWrapper<T0>
{

	// Fields
	private object <RefObj>k__BackingField; // 0x0

	// Properties
	public object RefObj { get; set; }

	// Methods

	// RVA: -1
	public object get_RefObj() { }

	// RVA: -1
	private object set_RefObj(object value) { }

	// RVA: -1
	public object .ctor(object holder) { }

	// RVA: -1
	public object BreakRef() { }

}

// Namespace: 
public class IL2CPPForceInlineAttribute
{

	// Methods

	// RVA: 0x100DA54
	public object .ctor() { }

}

// Namespace: 
public class MyStringBuilder
{

	// Fields
	private const object DEFAULT_BUFFER_SIZE;
	public object B; // 0x18

	// Methods

	// RVA: 0x100DA5C
	public object .ctor() { }

	// RVA: 0x100DAD8
	public override object OnUse() { }

	// RVA: 0x100DB30
	public override object OnRelease() { }

}

// Namespace: 
public class Singleton<T0>
{

	// Fields
	private static object s_instance; // 0x0

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	public static object CreateInstance() { }

	// RVA: -1
	public static object DestroyInstance() { }

	// RVA: -1
	public static object get_instance() { }

	// RVA: -1
	public static object GetInstance() { }

	// RVA: -1
	public static object HasInstance() { }

	// RVA: -1
	public virtual object Init() { }

	// RVA: -1
	public virtual object UnInit() { }

}

// Namespace: 
public class StringHelper
{

	// Fields
	private const object c_CharBufferInitSize;
	private static object s_CharBuffer; // 0xFFFFFFFF80000000
	private static object strCache; // 0x0
	private static object mCapacity; // 0x8
	public static object Formater; // 0x10
	private static object s_NativeHandle; // 0x18
	private static object s_OptHandle; // 0x20
	private static object s_MainThreadId; // 0x28

	// Properties
	private static object Handle { get; }

	// Methods

	// RVA: 0x100DB5C
	public static object GetCharBuffer(object size) { }

	// RVA: 0x100DCF4
	private static object NextPowerOfTwo(object x) { }

	// RVA: 0x100DD14
	public static object ClearCharBuffer() { }

	// RVA: 0x100DD98
	public static object BytesToString(object bytes, object index, object count) { }

	// RVA: 0x100DF28
	public static object BytesToString(object bytes) { }

	// RVA: 0x100E010
	public static object GetCutString(object orgStr, object newLength, object isPreCut) { }

	// RVA: 0x100E0EC
	public static object BytesToStringCutAtFirstNUL(object bytes) { }

	// RVA: 0x100E1B8
	public static object BytesToString(object str) { }

	// RVA: 0x100E1BC
	public static object SetCapacity(object capacity) { }

	// RVA: 0x100E248
	public static object GetStringCacheCount() { }

	// RVA: 0x100E308
	public static object ClearStringCache() { }

	// RVA: 0x100E3B4
	public static object SimpleFormat(object src, object args) { }

	// RVA: 0x100E3BC
	public static object Concat(object str1, object str2) { }

	// RVA: 0x100E3C4
	public static object Concat(object str1, object str2, object str3) { }

	// RVA: 0x100E3CC
	public static object Concat(object str1, object str2, object str3, object str4) { }

	// RVA: 0x100E3D4
	public static object Concat(object strs) { }

	// RVA: 0x100E3DC
	public static object ClearFormater() { }

	// RVA: 0x100E47C
	public static object GetStringBuilderShared() { }

	// RVA: 0x100E574
	public static object AccquireFormater() { }

	// RVA: 0x100E66C
	public static object GetCachedString(object str) { }

	// RVA: 0x100E990
	public static object UTF8BytesToString(object szBytes) { }

	// RVA: 0x100EB88
	public static object ASCIIBytesToString(object data) { }

	// RVA: 0x100ED0C
	public static object TruncateStringByBytesCount(object str, object count) { }

	// RVA: 0x100EEAC
	public static object StringToUTF8Bytes(object str, object buffer) { }

	// RVA: 0x100F4C0
	public static object LuaStringToUTF8Bytes(object str, object byteLen) { }

	// RVA: 0x100F084
	private static object FillErrorCodeToBuf(object buffer) { }

	// RVA: 0x100F568
	private static object FillErrorCodeToSBuf(object buffer) { }

	// RVA: 0x100F9A4
	public static object IsAvailableString(object str) { }

	// RVA: 0x100FADC
	public static object StringToUTF8Bytes(object str, object buffer) { }

	// RVA: 0x100FC38
	public static object ShortName(object Name, object maxLen) { }

	// RVA: 0x100FDE8
	public static object U16StrToU8Str(object str) { }

	// RVA: 0x1010114
	private static object get_Handle() { }

	// RVA: 0x1010238
	public static object InitMainThread() { }

	// RVA: 0x10102CC
	public static object FormatOpt(object src, object arg1) { }

	// RVA: 0x1010464
	public static object FormatOpt(object src, object arg1, object arg2) { }

	// RVA: 0x1010610
	public static object FormatOpt(object src, object arg1, object arg2, object arg3) { }

	// RVA: 0x10107C4
	public static object FormatOpt(object src, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x1010988
	public static object FormatOpt(object src, object arg1, object arg2, object arg3, object arg4, object arg5) { }

	// RVA: 0x1010B54
	public static object FormatOpt(object src, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6) { }

	// RVA: 0x1010D30
	public static object FormatOpt(object src, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7) { }

	// RVA: 0x1010F14
	public static object FormatOpt(object src, object args) { }

	// RVA: 0x1011034
	public static object Format(object src, object args) { }

	// RVA: 0x101103C
	public object .ctor() { }

	// RVA: 0x1011044
	private static object .cctor() { }

}

// Namespace: 
public interface IStringHelperHandle
{

	// Methods

	// RVA: -1
	public abstract object FillArgs(object arg1) { }

	// RVA: -1
	public abstract object FillArgs(object arg1, object arg2) { }

	// RVA: -1
	public abstract object FillArgs(object arg1, object arg2, object arg3) { }

	// RVA: -1
	public abstract object FillArgs(object arg1, object arg2, object arg3, object arg4) { }

	// RVA: -1
	public abstract object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5) { }

	// RVA: -1
	public abstract object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6) { }

	// RVA: -1
	public abstract object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7) { }

	// RVA: -1
	public abstract object Format(object format, object args) { }

	// RVA: -1
	public abstract object Concat(object args) { }

}

// Namespace: 
public class NativeStringHelperHandle
{

	// Methods

	// RVA: 0x10113F0
	public object FillArgs(object arg1) { }

	// RVA: 0x1011498
	public object FillArgs(object arg1, object arg2) { }

	// RVA: 0x1011568
	public object FillArgs(object arg1, object arg2, object arg3) { }

	// RVA: 0x101166C
	public object FillArgs(object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x101179C
	public object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5) { }

	// RVA: 0x1011900
	public object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6) { }

	// RVA: 0x1011A90
	public object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7) { }

	// RVA: 0x1011C54
	public object Format(object format, object args) { }

	// RVA: 0x1011D2C
	public object Concat(object args) { }

	// RVA: 0x101115C
	public object .ctor() { }

}

// Namespace: 
public class OptStringHelperHandle
{

	// Fields
	public const object PARAM_CNT;
	public object Args; // 0x8
	private object stringBuilder; // 0x10

	// Methods

	// RVA: 0x1011164
	public object .ctor() { }

	// RVA: 0x1011D38
	public object FillArgs(object arg1) { }

	// RVA: 0x1011DE4
	public object FillArgs(object arg1, object arg2) { }

	// RVA: 0x1011EF8
	public object FillArgs(object arg1, object arg2, object arg3) { }

	// RVA: 0x1012074
	public object FillArgs(object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x1012250
	public object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5) { }

	// RVA: 0x1012494
	public object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6) { }

	// RVA: 0x1012738
	public object FillArgs(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7) { }

	// RVA: 0x1012A44
	public object Format(object format, object args) { }

	// RVA: 0x1012A48
	public object SimpleFormat(object format, object args) { }

	// RVA: 0x1012AF0
	public object Concat(object args) { }

}

// Namespace: 
public sealed class LogPostProcessor
{

	// Methods

	// RVA: 0x1015590
	public object .ctor(object object, object method) { }

	// RVA: 0x1015640
	public virtual object Invoke(object strLog, object stack, object level) { }

	// RVA: 0x1015654
	public virtual object BeginInvoke(object strLog, object stack, object level, object callback, object object) { }

	// RVA: 0x1015724
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public enum Module
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Begin;
	public const object Achievement;
	public const object Actor;
	public const object Age;
	public const object AI;
	public const object AssetLoad;
	public const object Astar;
	public const object AutoChess;
	public const object Battle;
	public const object BattleGuide;
	public const object Behaviac;
	public const object BuildSystem;
	public const object Clip;
	public const object Collision;
	public const object Communicate;
	public const object Component;
	public const object Databin;
	public const object DataCenter;
	public const object Dom;
	public const object Drama;
	public const object DSCheck;
	public const object DSSession;
	public const object DSGame;
	public const object Equip;
	public const object Event;
	public const object FileMgr;
	public const object FrameSynchr;
	public const object GameBuilder;
	public const object GameMode;
	public const object Ladder;
	public const object Level;
	public const object LiteBullet;
	public const object Load;
	public const object Math;
	public const object MainBattle;
	public const object Misc;
	public const object Monster;
	public const object MoWen;
	public const object Move;
	public const object Network;
	public const object OB;
	public const object Organ;
	public const object Path;
	public const object Player;
	public const object PlentyMode;
	public const object Polar;
	public const object Profiler;
	public const object Proto;
	public const object Resource;
	public const object Replay;
	public const object Shenfu;
	public const object Skill;
	public const object Snake;
	public const object StarSys;
	public const object StateSyncActionMgr;
	public const object Statistics;
	public const object System;
	public const object TargetSearch;
	public const object Tdr;
	public const object Test;
	public const object Trigger;
	public const object UI;
	public const object UpdateLogic;
	public const object ValueProp;
	public const object Version;
	public const object VirtualEngine;
	public const object XLua;
	public const object StateSynchr;
	public const object TimeLine;
	public const object HighlightCaptureSys;
	public const object NewbieAbilityEval;
	public const object PassiveSignal;
	public const object GraphLogic;
	public const object Max;
}

// Namespace: 
public enum LogLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object eLogVerbose;
	public const object eLogDebug;
	public const object eLogWarning;
	public const object eLogAssert;
	public const object eLogError;
	public const object eLogException;
	public const object eLogClosed;
}

// Namespace: 
private class MsgUsagePerThread
{

	// Fields
	public object ThreadID; // 0x8
	public object PrefixList; // 0x10
	public object Builder; // 0x18
	public object postProcessor; // 0x20

	// Methods

	// RVA: 0x10131F4
	public object .ctor(object InThreaID) { }

}

// Namespace: 
public class NDLog
{

	// Fields
	public static object IsShowErrorLogToScreenFromGM; // 0x0
	public static object IsShowWhiteLogToScreenFromGM; // 0x1
	private static object <FrameSyncDebugFileRootPath>k__BackingField; // 0x8
	private static object <PerfDebugFileRootPath>k__BackingField; // 0x10
	public static object DebugObjID; // 0x18
	private static object MainThreadID; // 0x1C
	private static object scDictMsgUsagePerThread; // 0x20
	private static object scLogFilter; // 0x28
	private static object scLogLevel; // 0x30

	// Properties
	public static object FrameSyncDebugFileRootPath { get; set; }
	public static object PerfDebugFileRootPath { get; set; }

	// Methods

	// RVA: 0x1012BC0
	public static object get_FrameSyncDebugFileRootPath() { }

	// RVA: 0x1012C3C
	private static object set_FrameSyncDebugFileRootPath(object value) { }

	// RVA: 0x1012CC8
	public static object get_PerfDebugFileRootPath() { }

	// RVA: 0x1012D44
	private static object set_PerfDebugFileRootPath(object value) { }

	// RVA: 0x1012DD0
	public static object GetMainThreadID() { }

	// RVA: 0x1012E4C
	public static object RegThreadLog(object InThread, object postProcessor) { }

	// RVA: 0x10132B8
	public static object UnRegThreadLog(object InThread) { }

	// RVA: 0x1013368
	public static object InitOnMainThreadStart(object strFileNamePrefix) { }

	// RVA: 0x1013450
	public static object CreateThreadLogger(object strFileNamePrefix) { }

	// RVA: 0x1013454
	public static object ReleaseThreadLoggerIfExsit() { }

	// RVA: 0x1013458
	public static object Init() { }

	// RVA: 0x10134C0
	private static object InitDebugEnv() { }

	// RVA: 0x1013B80
	public static object ForbidLogModule(object mod, object bForbid) { }

	// RVA: 0x1013C2C
	public static object SetLogLevel(object level) { }

	// RVA: 0x1013CB8
	public static object GetLogLevel() { }

	// RVA: 0x1013D34
	private static object CheckSkip(object mod, object level) { }

	// RVA: 0x1013E20
	public static object ExceptionIfNotFinal(object ieModule, object message, object args) { }

	// RVA: 0x1013E24
	public static object ErroIfNotFinal(object ieModule, object message, object args) { }

	// RVA: 0x1013E28
	public static object ReportCriticalException(object ieModule, object message, object args) { }

	// RVA: 0x101453C
	public static object Assert(object ieModule, object InCondition) { }

	// RVA: 0x10145C4
	public static object Assert(object ieModule, object InCondition, object InFormat) { }

	// RVA: 0x101464C
	public static object Assert(object ieModule, object InCondition, object InFormat, object InParameters) { }

	// RVA: 0x1013FDC
	private static object ConstructLog(object ieModule, object logLevel, object iContent, object iArgs) { }

	// RVA: 0x1014878
	public static object Error(object ieModule, object iContent, object iArgs) { }

	// RVA: 0x1014A20
	public static object ErrorObJID(object ieModule, object ObjID, object iContent, object iArgs) { }

	// RVA: 0x1014B88
	public static object Error(object ieModule, object iObj) { }

	// RVA: 0x1014B8C
	public static object ErrorEd(object ieModule, object iContent, object iArgs) { }

	// RVA: 0x1014C30
	public static object ErrorEd(object ieModule, object iObj) { }

	// RVA: 0x1014C34
	public static object ErrorProfile(object ieModule, object iContent, object iArgs) { }

	// RVA: 0x1014D64
	public static object ErrorProfile(object ieModule, object iObj) { }

	// RVA: 0x1014DEC
	public static object Debug(object ieModule, object iContent, object iArgs) { }

	// RVA: 0x1014F94
	public static object Verbose(object ieModule, object iContent, object iArgs) { }

	// RVA: 0x10150C4
	public static object Debug(object ieModule, object iObj) { }

	// RVA: 0x10150C8
	public static object Warning(object ieModule, object iObj) { }

	// RVA: 0x10150CC
	public static object Warning(object ieModule, object iContent, object iArgs) { }

	// RVA: 0x10151FC
	public static object Info(object ieModule, object iContent, object iArgs) { }

	// RVA: 0x1015294
	public static object Info(object ieModule, object iObj) { }

	// RVA: 0x101535C
	public object .ctor() { }

	// RVA: 0x1015364
	private static object .cctor() { }

}

// Namespace: 
public interface IObjectPool
{

	// Properties
	public abstract object total { get; }
	public abstract object RTAllocCnt { get; }
	public abstract object Count { get; }
	public abstract object Capacity { get; }

	// Methods

	// RVA: -1
	public abstract object Get(object constructData) { }

	// RVA: -1
	public abstract object AdjustCapcity(object count) { }

	// RVA: -1
	public abstract object Init(object wrapper) { }

	// RVA: -1
	public abstract object Release(object obj) { }

	// RVA: -1
	public abstract object ClearUnused() { }

	// RVA: -1
	public abstract object ClearAll(object clearRef) { }

	// RVA: -1
	public abstract object get_total() { }

	// RVA: -1
	public abstract object get_RTAllocCnt() { }

	// RVA: -1
	public abstract object get_Count() { }

	// RVA: -1
	public abstract object get_Capacity() { }

	// RVA: -1
	public abstract object ExtendCaptain(object extCount) { }

	// RVA: -1
	public abstract object GetElemType() { }

}

// Namespace: 
public struct PoolObjHandle<T0>
{

	// Fields
	public object _handleSeq; // 0x0
	public object _handleObj; // 0x0
	public static object NullHandle; // 0x0

	// Properties
	public object HasValue { get; }
	public object handle { get; }

	// Methods

	// RVA: -1
	public object .ctor(object obj) { }

	// RVA: -1
	public object Validate() { }

	// RVA: -1
	public object Release() { }

	// RVA: -1
	public static object op_Implicit(object ptr) { }

	// RVA: -1
	public object get_HasValue() { }

	// RVA: -1
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: -1
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public static object op_Implicit(object ptr) { }

	// RVA: -1
	public object get_handle() { }

}

// Namespace: 
public class StatElem
{

	// Fields
	public object ElemType; // 0x8
	public object TotalAllocCnt; // 0x10
	public object RTAllocCnt; // 0x14
	public object InPoolCnt; // 0x18
	public object Capacity; // 0x1C

	// Methods

	// RVA: 0x1016A10
	public static object GetHeaderString() { }

	// RVA: 0x1016A54
	public object ToString(object Idx) { }

	// RVA: 0x10175B4
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__15_0; // 0x8
	public static object <>9__15_1; // 0x10
	public static object <>9__15_2; // 0x18

	// Methods

	// RVA: 0x10177C4
	private static object .cctor() { }

	// RVA: 0x1017824
	public object .ctor() { }

	// RVA: 0x101782C
	internal object <PrintStat>b__15_0(object x, object y) { }

	// RVA: 0x1017870
	internal object <PrintStat>b__15_1(object x, object y) { }

	// RVA: 0x10178B4
	internal object <PrintStat>b__15_2(object x, object y) { }

}

// Namespace: 
public class ObjectPoolRepository
{

	// Fields
	private const object cThreadCount;
	private object mRepositories; // 0x8
	private object mMainThreadID; // 0x10
	private object <bRunTime>k__BackingField; // 0x14

	// Properties
	public object bRunTime { get; set; }

	// Methods

	// RVA: 0x1015730
	public object get_bRunTime() { }

	// RVA: 0x1015738
	private object set_bRunTime(object value) { }

	// RVA: 0x1015740
	public override object Init() { }

	// RVA: 0x101579C
	private object InitAllObjectPoolTypesInMainThread() { }

	// RVA: 0x1015F9C
	public object ClearAll(object clearRef) { }

	// RVA: 0x10162C4
	public object ClearUnUsed() { }

	// RVA: 0x10162BC
	public object SetRuntimeFlag(object InbRunTime) { }

	// RVA: 0x1016534
	public object GetPool(object InClassID) { }

	// RVA: 0x101671C
	public static object SortAndPrint(object strPrintKey, object InList, object InSortFuncName, object comparison) { }

	// RVA: 0x1016D4C
	public object PrintStat() { }

	// RVA: 0x10175BC
	public object .ctor() { }

}

// Namespace: 
public class ClassObjPool<T0>
{

	// Fields
	public static object CLASS_ID; // 0x0
	protected object pool; // 0x0
	public object reqSeq; // 0x0
	private object Ref; // 0x0
	private object <total>k__BackingField; // 0x0
	private object <RTAllocCnt>k__BackingField; // 0x0

	// Properties
	public object Capacity { get; }
	public object total { get; set; }
	public object RTAllocCnt { get; set; }
	public object Count { get; }

	// Methods

	// RVA: -1
	public object Init(object wrapper) { }

	// RVA: -1
	public static object NewSeq() { }

	// RVA: -1
	public object get_Capacity() { }

	// RVA: -1
	public object get_total() { }

	// RVA: -1
	private object set_total(object value) { }

	// RVA: -1
	public object get_RTAllocCnt() { }

	// RVA: -1
	private object set_RTAllocCnt(object value) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public static object GetPool() { }

	// RVA: -1
	private object IObjectPool.Get(object constructData) { }

	// RVA: -1
	public static object Get() { }

	// RVA: -1
	public object GetObject() { }

	// RVA: -1
	protected object RecordAlloc() { }

	// RVA: -1
	private object ClearAllocRecords() { }

	// RVA: -1
	public object Release(object obj) { }

	// RVA: -1
	public object ClearAll(object clearRef) { }

	// RVA: -1
	public object ClearUnused() { }

	// RVA: -1
	public static object AdjustCaptain(object count) { }

	// RVA: -1
	private object AdjustCapcity(object count) { }

	// RVA: -1
	private object IObjectPool.AdjustCapcity(object count) { }

	// RVA: -1
	private object IObjectPool.ExtendCaptain(object extCount) { }

	// RVA: -1
	public static object ExtendCaptain(object extCount) { }

	// RVA: -1
	public object GetElemType() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
public class IgnoreInPoolUse
{

	// Methods

	// RVA: 0x10178F8
	public object .ctor() { }

}

// Namespace: 
public abstract class PooledClassObjectBase
{

	// Fields
	public object usingSeq; // 0x8
	private object holderRef; // 0x10

	// Properties
	public object holder { get; }
	public virtual object bChkReset { get; }

	// Methods

	// RVA: 0x1017900
	public object get_holder() { }

	// RVA: 0x1017958
	public object BindRef(object poolRef) { }

	// RVA: 0x1017960
	public virtual object get_bChkReset() { }

	// RVA: 0x1017968
	public virtual object OnUse() { }

	// RVA: 0x100DB58
	public virtual object OnRelease() { }

	// RVA: 0x101796C
	public virtual object SetClassID(object InClassID) { }

	// RVA: 0x101763C
	public object Release() { }

	// RVA: 0x1017970
	protected object .ctor() { }

}

// Namespace: 
public abstract class PooledClassObject
{

	// Methods

	// RVA: 0x100DAD0
	protected object .ctor() { }

}

// Namespace: 
public class PoolWrapper
{

	// Fields
	public object CLASS_ID; // 0x8
	public object PoolType; // 0x10
	public object Pool; // 0x18

	// Methods

	// RVA: 0x1015F70
	public object .ctor(object InType) { }

}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0x1017978
	private static object Get() { }

	// RVA: 0x1017A48
	public object .ctor() { }

}

// Namespace: NucleusDrive.Share
public sealed class DeleGetThreadIdString
{

	// Methods

	// RVA: 0x1017C1C
	public object .ctor(object object, object method) { }

	// RVA: 0x1017CB0
	public virtual object Invoke() { }

	// RVA: 0x1017CC4
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0x1017D1C
	public virtual object EndInvoke(object result) { }

}

// Namespace: NucleusDrive.Share
public static class Application
{

	// Fields
	public static object DisableAllPerformanceEvents; // 0x0
	private static object <dataPath>k__BackingField; // 0x8
	private static object <streamingAssetsPath>k__BackingField; // 0x10
	private static object <writablePath>k__BackingField; // 0x18
	private static object <isPlaying>k__BackingField; // 0x20
	private static object <isPaused_EditorApp>k__BackingField; // 0x21
	private static object <isPlayingOrWillChangePlaymode_EditorApp>k__BackingField; // 0x22
	private static object <isUseCSAgeSystem>k__BackingField; // 0x23
	private static object <isUseCSPosViewportChopping>k__BackingField; // 0x24
	private static object <isUsePolarLocation>k__BackingField; // 0x25
	private static object <isSyncActionName>k__BackingField; // 0x26
	private static object <isSyncActorName>k__BackingField; // 0x27
	public const object MIN_FRAME_SPEED;
	public const object MAX_FRAME_SPEED;
	public static object IntParam0; // 0x28
	public static object IntParam1; // 0x2C
	public static object IntParam2; // 0x30
	public static object IntParam3; // 0x34
	public static object IntParam4; // 0x38
	public static object ObjParam0; // 0x40
	public static object ObjParam1; // 0x48
	public static object ObjParam2; // 0x50
	public static object ObjParam3; // 0x58
	public static object ObjParam4; // 0x60
	public const object LOGIC_FPS;
	private static object <c_limitFPSCount>k__BackingField; // 0x68
	private static object <c_targetFrameTime>k__BackingField; // 0x6C
	public const object c_logic_frameDelta;
	public const object c_ac_frameDelta;
	private static object <crcErrorCount>k__BackingField; // 0x70
	private static object <bEnableStateRecover>k__BackingField; // 0x74
	public static object GetThreadIdString; // 0x78

	// Properties
	public static object dataPath { get; set; }
	public static object streamingAssetsPath { get; set; }
	public static object writablePath { get; set; }
	public static object isPlaying { get; set; }
	public static object isPaused_EditorApp { get; set; }
	public static object isPlayingOrWillChangePlaymode_EditorApp { get; set; }
	public static object isUseCSAgeSystem { get; set; }
	public static object isUseCSPosViewportChopping { get; set; }
	public static object isUsePolarLocation { get; set; }
	public static object isSyncActionName { get; set; }
	public static object isSyncActorName { get; set; }
	public static object c_limitFPSCount { get; set; }
	public static object c_targetFrameTime { get; set; }
	public static object crcErrorCount { get; set; }
	public static object bEnableStateRecover { get; set; }

	// Methods

	// RVA: 0x1017D28
	public static object get_dataPath() { }

	// RVA: 0x1017D74
	private static object set_dataPath(object value) { }

	// RVA: 0x1017DCC
	public static object get_streamingAssetsPath() { }

	// RVA: 0x1017E18
	private static object set_streamingAssetsPath(object value) { }

	// RVA: 0x1017E70
	public static object get_writablePath() { }

	// RVA: 0x1017EBC
	private static object set_writablePath(object value) { }

	// RVA: 0x1017F14
	public static object get_isPlaying() { }

	// RVA: 0x1017F60
	private static object set_isPlaying(object value) { }

	// RVA: 0x1017FB8
	public static object get_isPaused_EditorApp() { }

	// RVA: 0x1018004
	private static object set_isPaused_EditorApp(object value) { }

	// RVA: 0x101805C
	public static object get_isPlayingOrWillChangePlaymode_EditorApp() { }

	// RVA: 0x10180A8
	private static object set_isPlayingOrWillChangePlaymode_EditorApp(object value) { }

	// RVA: 0x1018100
	public static object get_isUseCSAgeSystem() { }

	// RVA: 0x101814C
	private static object set_isUseCSAgeSystem(object value) { }

	// RVA: 0x10181A4
	public static object get_isUseCSPosViewportChopping() { }

	// RVA: 0x10181F0
	private static object set_isUseCSPosViewportChopping(object value) { }

	// RVA: 0x1018248
	public static object get_isUsePolarLocation() { }

	// RVA: 0x1018294
	private static object set_isUsePolarLocation(object value) { }

	// RVA: 0x10182EC
	public static object get_isSyncActionName() { }

	// RVA: 0x1018338
	private static object set_isSyncActionName(object value) { }

	// RVA: 0x1018390
	public static object get_isSyncActorName() { }

	// RVA: 0x10183DC
	private static object set_isSyncActorName(object value) { }

	// RVA: 0x1018434
	public static object Init(object InDataPath, object InStreamingAssetsPath, object InWritablePath) { }

	// RVA: 0x1018750
	public static object SetDataPath(object InDataPath) { }

	// RVA: 0x10187A8
	public static object SetPlaying(object InIsPlaying, object InIsPaused, object InIsPlayingOrWillChangePlaymode) { }

	// RVA: 0x10188A0
	public static object get_c_limitFPSCount() { }

	// RVA: 0x10188EC
	private static object set_c_limitFPSCount(object value) { }

	// RVA: 0x1018944
	public static object get_c_targetFrameTime() { }

	// RVA: 0x1018990
	private static object set_c_targetFrameTime(object value) { }

	// RVA: 0x10186AC
	public static object SetRenderFPS(object renderFPS) { }

	// RVA: 0x10189E8
	public static object get_crcErrorCount() { }

	// RVA: 0x1018A34
	private static object set_crcErrorCount(object value) { }

	// RVA: 0x1018A8C
	public static object SetCrcErrorCount(object errorCount) { }

	// RVA: 0x1018AE4
	public static object get_bEnableStateRecover() { }

	// RVA: 0x1018B30
	private static object set_bEnableStateRecover(object value) { }

	// RVA: 0x1018B88
	public static object SetEnableStateRecover(object inEnable) { }

	// RVA: 0x1018BE0
	public static object SetEnableCSAgeSystem(object bEnable) { }

	// RVA: 0x1018C38
	public static object SetEnableCSPosViewportChopping(object bEnable) { }

	// RVA: 0x1018C90
	public static object SetEnablePolarLocation(object bEnable) { }

	// RVA: 0x1018CE8
	public static object SetEnableSyncName(object bEnable) { }

}

// Namespace: NucleusDrive.Share
public enum ReportBugType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object NotSync;
	public const object Exception;
	public const object HotFix;
	public const object Jank;
	public const object Other;
}

// Namespace: NucleusDrive.Share
public static class ReportBugForAbs
{

	// Fields
	private static object _bugId; // 0x0

	// Properties
	public static object BugId { get; }
	public static object BugType { get; }

	// Methods

	// RVA: 0x1018D94
	public static object get_BugId() { }

	// RVA: 0x1018DE8
	public static object get_BugType() { }

	// RVA: 0x1018ED4
	public static object Reset() { }

	// RVA: 0x10144C4
	public static object AddReportBug(object reportBugType) { }

}

// Namespace: NucleusDrive.Share
public interface ILoggerProxy
{

	// Methods

	// RVA: -1
	public abstract object WriteLine(object line) { }

}

// Namespace: NucleusDrive.Share
public interface ILogger
{

	// Methods

	// RVA: -1
	public abstract object Open() { }

	// RVA: -1
	public abstract object Close() { }

}

// Namespace: 
private class LocalFileAsyncLogger
{

	// Fields
	private object streamWriter; // 0x8
	public object m_strLogPathName; // 0x10

	// Properties
	public object Valid { get; }

	// Methods

	// RVA: 0x101911C
	public object get_Valid() { }

	// RVA: 0x1019FAC
	public virtual object WriteLine(object str) { }

	// RVA: 0x101900C
	public object .ctor(object strLogName) { }

	// RVA: 0x101A13C
	public object DoWriteLine(object strLine) { }

	// RVA: 0x101A1F0
	public virtual object Open() { }

	// RVA: 0x101A3E8
	public object Close() { }

	// RVA: 0x101A4AC
	public object DoClose() { }

}

// Namespace: 
public enum Op
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object eWriteLine;
	public const object eClose;
}

// Namespace: 
private struct AsyncLogCmd
{

	// Fields
	private object op; // 0xFFFFFFFFFFFFFFF8
	private object m_logger; // 0x0
	private object m_content; // 0x8

	// Methods

	// RVA: 0x101A058
	public object .ctor(object logger, object content, object inOp) { }

	// RVA: 0x1019D54
	public object Execute() { }

}

// Namespace: NucleusDrive.Share
public class AsyncLoggerThread
{

	// Fields
	public object m_lock; // 0x8
	private object m_started; // 0x10
	private object m_workingThread; // 0x18
	private object bRequestExit; // 0x20
	private object PendingWork; // 0x28
	private object WorkingList; // 0x30
	public object m_threadID; // 0x38
	private object registeredLoggers; // 0x40

	// Properties
	public object Lock { get; }
	public object Started { get; }

	// Methods

	// RVA: 0x1018F24
	public object get_Lock() { }

	// RVA: 0x1018F2C
	public object get_Started() { }

	// RVA: 0x1018F34
	public object CreateLoggerProxy(object strLogName) { }

	// RVA: 0x10194B0
	public object ReleaseLoggerProxy(object logger) { }

	// RVA: 0x10191F0
	public object Start(object logger) { }

	// RVA: 0x10195AC
	public object Stop(object logger) { }

	// RVA: 0x1019784
	private object FlushForStop() { }

	// RVA: 0x1019A0C
	private object AddBackgroudOperation(object InDelegate) { }

	// RVA: 0x1019C0C
	protected object StaticEntry() { }

	// RVA: -1
	private object Swap(object a, object b) { }

	// RVA: 0x1019858
	private object _ExecuteList(object list) { }

	// RVA: 0x1019E84
	public object .ctor() { }

}

// Namespace: 
private class FakeEnumerator
{

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: NucleusDrive.Collections.Generric
internal class FakeCollection<T0>
{

	// Fields
	private object <Count>k__BackingField; // 0x0

	// Properties
	public object Count { get; set; }
	public object IsReadOnly { get; }

	// Methods

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object set_Count(object value) { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: NucleusDrive.Collections.Generric
internal class KeepLastComparer<T0>
{

	// Fields
	public object LastX; // 0x0
	public object LastY; // 0x0
	private object m_Comp; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	public object Equals(object x, object y) { }

	// RVA: -1
	public object GetHashCode(object obj) { }

}

// Namespace: NucleusDrive.Collections.Generric
public class HashSetEx<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object .ctor(object capacity, object comparer) { }

	// RVA: -1
	public object TryGetValue(object equalValue, object actualValue) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=1402
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=2548
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 8D301CDD2AE7F1691D09134DA21C25483A9ADE1842980E14FF381970C6BADD42; // 0x0
	internal static readonly object DEFAC78E490A574195ADE7DC13B598169186246C7D204BE10A00EA63FB2BBBD8; // 0x9F4
}

