// Namespace: 
internal class <Module>
{
}

// Namespace: ImGuiNET
public static class ImGuiUn
{

	// Fields
	private static object Layout; // 0x0
	internal static object s_currentUnityContext; // 0x8

	// Methods

	// RVA: 0x6C3FE18
	public static object ScreenToImGui(object point) { }

	// RVA: 0x6C3FEB0
	public static object add_Layout(object value) { }

	// RVA: 0x6C3FF70
	public static object remove_Layout(object value) { }

	// RVA: 0x6C40030
	internal static object DoLayout() { }

	// RVA: 0x6C40098
	public static object GetTextureId(object texture) { }

	// RVA: 0x6C40248
	internal static object CreateUnityContext() { }

	// RVA: 0x6C404B8
	internal static object DestroyUnityContext(object context) { }

	// RVA: 0x6C404DC
	internal static object SetUnityContext(object context) { }

}

// Namespace: ImGuiNET
internal sealed class ImGuiUnityContext
{

	// Fields
	public object state; // 0x8
	public object textures; // 0x10

	// Methods

	// RVA: 0x6C402E4
	public object .ctor() { }

}

// Namespace: 
public struct CursorShape
{

	// Fields
	public object texture; // 0xFFFFFFFFFFFFFFF8
	public object hotspot; // 0x0
}

// Namespace: ImGuiNET.Unity
internal sealed class CursorShapesAsset
{

	// Fields
	public object Arrow; // 0x10
	public object TextInput; // 0x20
	public object ResizeAll; // 0x30
	public object ResizeEW; // 0x40
	public object ResizeNS; // 0x50
	public object ResizeNESW; // 0x60
	public object ResizeNWSE; // 0x70
	public object Hand; // 0x80
	public object NotAllowed; // 0x90

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x6C40558
	public object get_Item(object cursor) { }

	// RVA: 0x6C40584
	public object .ctor() { }

}

// Namespace: ImGuiNET.Unity
internal sealed class FontAtlasConfigAsset
{

	// Fields
	public object Rasterizer; // 0x10
	public object RasterizerFlags; // 0x14
	public object Fonts; // 0x18

	// Methods

	// RVA: 0x6C405C8
	public object .ctor() { }

}

// Namespace: ImGuiNET.Unity
internal enum FontRasterizerType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object StbTrueType;
	public const object FreeType;
}

// Namespace: ImGuiNET.Unity
internal sealed class IniSettingsAsset
{

	// Fields
	private object _data; // 0x10

	// Methods

	// RVA: 0x6C405D0
	public object Save(object data) { }

	// RVA: 0x6C405D8
	public object Load() { }

	// RVA: 0x6C405E0
	public object .ctor() { }

}

// Namespace: 
public class Shaders
{

	// Fields
	public object mesh; // 0x8
	public object procedural; // 0x10

	// Methods

	// RVA: 0x6C405F0
	public object .ctor() { }

}

// Namespace: 
public class PropertyNames
{

	// Fields
	public object tex; // 0x8
	public object vertices; // 0x10
	public object baseVertex; // 0x18

	// Methods

	// RVA: 0x6C405F8
	public object .ctor() { }

}

// Namespace: ImGuiNET.Unity
internal sealed class ShaderResourcesAsset
{

	// Fields
	public object shaders; // 0x10
	public object propertyNames; // 0x18

	// Methods

	// RVA: 0x6C405E8
	public object .ctor() { }

}

// Namespace: ImGuiNET.Unity
internal sealed class StyleAsset
{

	// Fields
	public object Alpha; // 0x10
	public object WindowPadding; // 0x14
	public object WindowRounding; // 0x1C
	public object WindowBorderSize; // 0x20
	public object WindowMinSize; // 0x24
	public object WindowTitleAlign; // 0x2C
	public object WindowMenuButtonPosition; // 0x34
	public object ChildRounding; // 0x38
	public object ChildBorderSize; // 0x3C
	public object PopupRounding; // 0x40
	public object PopupBorderSize; // 0x44
	public object FramePadding; // 0x48
	public object FrameRounding; // 0x50
	public object FrameBorderSize; // 0x54
	public object ItemSpacing; // 0x58
	public object ItemInnerSpacing; // 0x60
	public object TouchExtraPadding; // 0x68
	public object IndentSpacing; // 0x70
	public object ColumnsMinSpacing; // 0x74
	public object ScrollbarSize; // 0x78
	public object ScrollbarRounding; // 0x7C
	public object GrabMinSize; // 0x80
	public object GrabRounding; // 0x84
	public object TabRounding; // 0x88
	public object TabBorderSize; // 0x8C
	public object ColorButtonPosition; // 0x90
	public object ButtonTextAlign; // 0x94
	public object SelectableTextAlign; // 0x9C
	public object DisplayWindowPadding; // 0xA4
	public object DisplaySafeAreaPadding; // 0xAC
	public object MouseCursorScale; // 0xB4
	public object AntiAliasedLines; // 0xB8
	public object AntiAliasedFill; // 0xB9
	public object CurveTessellationTol; // 0xBC
	public object CircleTessellationMaxError; // 0xC0
	public object Colors; // 0xC8

	// Methods

	// RVA: 0x6C40600
	public object ApplyTo(object s) { }

	// RVA: 0x6C409BC
	public object SetFrom(object s) { }

	// RVA: 0x6C40D7C
	private object Reset() { }

	// RVA: 0x6C40DC8
	public object .ctor() { }

}

// Namespace: 
internal enum ScriptGlyphRanges
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Cyrillic;
	public const object Japanese;
	public const object Korean;
	public const object Thai;
	public const object Vietnamese;
	public const object ChineseSimplified;
	public const object ChineseFull;
	public const object Custom;
}

// Namespace: 
internal struct Range
{

	// Fields
	public object Start; // 0xFFFFFFFFFFFFFFF8
	public object End; // 0xFFFFFFFFFFFFFFFA
}

// Namespace: 
private struct <>c__DisplayClass17_0
{

	// Fields
	public object ranges; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: ImGuiNET.Unity
internal struct FontConfig
{

	// Fields
	public object FontIndexInFile; // 0xFFFFFFFFFFFFFFF8
	public object SizeInPixels; // 0xFFFFFFFFFFFFFFFC
	public object Oversample; // 0x0
	public object PixelSnapH; // 0x8
	public object GlyphExtraSpacing; // 0xC
	public object GlyphOffset; // 0x14
	public object GlyphRanges; // 0x1C
	public object GlyphMinAdvanceX; // 0x20
	public object GlyphMaxAdvanceX; // 0x24
	public object MergeIntoPrevious; // 0x28
	public object FontBuilderFlags; // 0x2C
	public object RasterizerMultiply; // 0x30
	public object EllipsisChar; // 0x34
	public object CustomGlyphRanges; // 0x38

	// Methods

	// RVA: 0x6C41060
	public object ApplyTo(object im) { }

	// RVA: 0x6C41194
	public object BuildRanges() { }

	// RVA: 0x6C41434
	internal static object <BuildRanges>g__AddRangePtr|17_0(object r, object ) { }

}

// Namespace: ImGuiNET.Unity
internal struct FontDefinition
{

	// Fields
	private object _fontAsset; // 0xFFFFFFFFFFFFFFF8
	public object FontPath; // 0x0
	public object Config; // 0x8
}

// Namespace: ImGuiNET.Unity
internal struct IOConfig
{

	// Fields
	public object KeyboardNavigation; // 0xFFFFFFFFFFFFFFF8
	public object GamepadNavigation; // 0xFFFFFFFFFFFFFFF9
	public object NavSetMousePos; // 0xFFFFFFFFFFFFFFFA
	public object NavNoCaptureKeyboard; // 0xFFFFFFFFFFFFFFFB
	public object DoubleClickTime; // 0xFFFFFFFFFFFFFFFC
	public object DoubleClickMaxDist; // 0x0
	public object DragThreshold; // 0x4
	public object KeyRepeatDelay; // 0x8
	public object KeyRepeatRate; // 0xC
	public object FontGlobalScale; // 0x10
	public object FontAllowUserScaling; // 0x14
	public object TextCursorBlink; // 0x15
	public object ResizeFromEdges; // 0x16
	public object MoveFromTitleOnly; // 0x17
	public object ConfigMemoryCompactTimer; // 0x18

	// Methods

	// RVA: 0x6C4181C
	public object SetDefaults() { }

	// RVA: 0x6C41A48
	public object ApplyTo(object io) { }

	// RVA: 0x6C41868
	public object SetFrom(object io) { }

}

// Namespace: ImGuiNET.Unity
public class DearImGui
{

	// Fields
	private object _context; // 0x18
	private object _renderer; // 0x20
	private object _platform; // 0x28
	private object _cmd; // 0x30
	private object _usingURP; // 0x38
	public static object _getCamera; // 0x0
	private object Layout; // 0x40
	private object _doGlobalLayout; // 0x48
	private object _camera; // 0x50
	private object _renderFeature; // 0x58
	private object _rendererType; // 0x60
	private object _platformType; // 0x64
	private object _initialConfiguration; // 0x68
	private object _fontAtlasConfiguration; // 0x90
	private object _iniSettings; // 0x98
	private object _shaders; // 0xA0
	private object _style; // 0xA8
	private object _cursorShapes; // 0xB0
	private object _autoResizeOnMobile; // 0xB8
	private object _usingSRP; // 0xB9
	private const object CommandBufferTag;
	private static readonly object s_prepareFramePerfMarker; // 0x8
	private static readonly object s_layoutPerfMarker; // 0x10
	private static readonly object s_drawListPerfMarker; // 0x18

	// Properties
	public object RenderCamera { get; set; }

	// Methods

	// RVA: 0x6C41C9C
	public object add_Layout(object value) { }

	// RVA: 0x6C41D40
	public object remove_Layout(object value) { }

	// RVA: 0x6C41DE4
	public object get_RenderCamera() { }

	// RVA: 0x6C41DEC
	public object set_RenderCamera(object value) { }

	// RVA: 0x6C41DF4
	private object Awake() { }

	// RVA: 0x6C41E18
	private object OnDestroy() { }

	// RVA: 0x6C41E40
	public object SetUsingSRP(object b) { }

	// RVA: 0x6C41E48
	public static object WantCaptureMouse() { }

	// RVA: 0x6C41EC4
	public static object WantCaptureKeyboard() { }

	// RVA: 0x6C41F40
	private object OnEnable() { }

	// RVA: 0x6C43078
	private object OnDisable() { }

	// RVA: 0x6C43644
	public object SetDefaults() { }

	// RVA: 0x6C439CC
	private object Reset() { }

	// RVA: 0x6C439D0
	public object Reload() { }

	// RVA: 0x6C439F4
	public object UpdateWithCommandBuffer(object commandBuffer, object pixelRect) { }

	// RVA: 0x6C43EC0
	public object UpdateWithCommandBuffer(object commandBuffer, object camera) { }

	// RVA: 0x6C43F98
	public object UpdateSRP(object commandBuffer, object camera) { }

	// RVA: 0x6C43FAC
	private object Update() { }

	// RVA: 0x6C42F04
	private object SetRenderer(object renderer, object io) { }

	// RVA: 0x6C42CBC
	private object SetPlatform(object platform, object io) { }

	// RVA: 0x6C44004
	private object OnGUI() { }

	// RVA: 0x6C441E4
	public object .ctor() { }

	// RVA: 0x6C441F8
	private static object .cctor() { }

	// RVA: 0x6C424B4
	private object <OnEnable>g__Fail|34_0(object reason) { }

}

// Namespace: ImGuiNET.Unity
internal interface IImGuiPlatform
{

	// Fields
	protected static readonly object m_keyCodeMap; // 0x0

	// Methods

	// RVA: -1
	public abstract object Initialize(object io) { }

	// RVA: -1
	public abstract object Shutdown(object io) { }

	// RVA: -1
	public abstract object PrepareFrame(object io, object displayRect) { }

	// RVA: 0x6C442F0
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__5_0; // 0x8
	public static object <>9__5_1; // 0x10
	public static object <>9__5_2; // 0x18

	// Methods

	// RVA: 0x6C46130
	private static object .cctor() { }

	// RVA: 0x6C46190
	public object .ctor() { }

	// RVA: 0x6C46198
	internal object <.ctor>b__5_0(object x, object y) { }

	// RVA: 0x6C461A8
	internal object <.ctor>b__5_1(object _) { }

	// RVA: 0x6C461B0
	internal object <.ctor>b__5_2(object _, object text) { }

}

// Namespace: ImGuiNET.Unity
internal sealed class ImGuiPlatformInputManager
{

	// Fields
	private readonly object m_e; // 0x8
	private readonly object _cursorShapes; // 0x10
	private object _lastCursor; // 0x18
	private readonly object _iniSettings; // 0x20
	private readonly object _callbacks; // 0x28

	// Methods

	// RVA: 0x6C44E58
	public object .ctor(object cursorShapes, object iniSettings) { }

	// RVA: 0x6C45738
	public object Initialize(object io) { }

	// RVA: 0x6C458D8
	public object Shutdown(object io) { }

	// RVA: 0x6C45960
	public object PrepareFrame(object io, object displayRect) { }

	// RVA: 0x6C45B4C
	private object UpdateKeyboard(object io) { }

	// RVA: 0x6C45E08
	private static object UpdateMouse(object io) { }

	// RVA: 0x6C45F78
	private object UpdateCursor(object io, object cursor) { }

}

// Namespace: 
public enum Type
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object InputManager;
	public const object InputSystem;
	public const object EditorWindow;
}

// Namespace: ImGuiNET.Unity
public static class Platform
{

	// Methods

	// RVA: 0x6C42BA8
	internal static object Create(object type, object cursors, object iniSettings) { }

}

// Namespace: ImGuiNET.Unity
internal sealed class GetClipboardTextCallback
{

	// Methods

	// RVA: 0x6C46298
	public object .ctor(object object, object method) { }

	// RVA: 0x6C46340
	public virtual object Invoke(object user_data) { }

}

// Namespace: ImGuiNET.Unity
internal sealed class GetClipboardTextSafeCallback
{

	// Methods

	// RVA: 0x6C4523C
	public object .ctor(object object, object method) { }

	// RVA: 0x6C46408
	public virtual object Invoke(object user_data) { }

}

// Namespace: ImGuiNET.Unity
internal sealed class SetClipboardTextCallback
{

	// Methods

	// RVA: 0x6C464C8
	public object .ctor(object object, object method) { }

	// RVA: 0x6C46578
	public virtual object Invoke(object user_data, object text) { }

}

// Namespace: ImGuiNET.Unity
internal sealed class SetClipboardTextSafeCallback
{

	// Methods

	// RVA: 0x6C453E8
	public object .ctor(object object, object method) { }

	// RVA: 0x6C46640
	public virtual object Invoke(object user_data, object text) { }

}

// Namespace: ImGuiNET.Unity
internal sealed class ImeSetInputScreenPosCallback
{

	// Methods

	// RVA: 0x6C4559C
	public object .ctor(object object, object method) { }

	// RVA: 0x6C466D4
	public virtual object Invoke(object x, object y) { }

}

// Namespace: 
private sealed class <>c__DisplayClass10_0
{

	// Fields
	public object value; // 0x8

	// Methods

	// RVA: 0x6C466F8
	public object .ctor() { }

	// RVA: 0x6C46700
	internal object <set_ImeSetInputScreenPos>b__0(object x, object y) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object value; // 0x8

	// Methods

	// RVA: 0x6C466E8
	public object .ctor() { }

	// RVA: 0x6C467E0
	internal object <set_GetClipboardText>b__0(object user_data) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object value; // 0x8

	// Methods

	// RVA: 0x6C466F0
	public object .ctor() { }

	// RVA: 0x6C468CC
	internal object <set_SetClipboardText>b__0(object user_data, object text) { }

}

// Namespace: ImGuiNET.Unity
internal class PlatformCallbacks
{

	// Fields
	private object _getClipboardText; // 0x8
	private object _setClipboardText; // 0x10
	private object _imeSetInputScreenPos; // 0x18

	// Properties
	public object GetClipboardText { set; }
	public object SetClipboardText { set; }
	public object ImeSetInputScreenPos { set; }

	// Methods

	// RVA: 0x6C458D4
	public object Assign(object io) { }

	// RVA: 0x6C4595C
	public object Unset(object io) { }

	// RVA: 0x6C452D4
	public object set_GetClipboardText(object value) { }

	// RVA: 0x6C45480
	public object set_SetClipboardText(object value) { }

	// RVA: 0x6C45634
	public object set_ImeSetInputScreenPos(object value) { }

	// RVA: 0x6C45234
	public object .ctor() { }

}

// Namespace: ImGuiNET.Unity
internal class SpriteInfo
{

	// Fields
	public object texture; // 0x8
	public object size; // 0x10
	public object uv0; // 0x18
	public object uv1; // 0x20
}

// Namespace: ImGuiNET.Unity
internal class TextureManager
{

	// Fields
	private object _atlasTex; // 0x8
	private object _currentTextureId; // 0x10
	private readonly object _textures; // 0x18
	private readonly object _textureIds; // 0x20
	private readonly object _spriteData; // 0x28
	private readonly object _allocatedGlyphRangeArrays; // 0x30

	// Methods

	// RVA: 0x6C43D8C
	public object PrepareFrame(object io) { }

	// RVA: 0x6C469C4
	private object RegisterTexture(object texture) { }

	// RVA: 0x6C46A7C
	public object GetTexture(object id) { }

	// RVA: 0x6C401A0
	public object GetTextureId(object texture) { }

	// RVA: 0x6C46B00
	private object AllocateGlyphRangeArray(object fontConfig) { }

	// RVA: 0x6C46C5C
	private object FreeGlyphRangeArrays() { }

	// RVA: 0x6C425B4
	public object BuildFontAtlas(object io, object settings) { }

	// RVA: 0x6C4357C
	public object DestroyFontAtlas(object io) { }

	// RVA: 0x6C42B28
	public object Initialize(object io) { }

	// RVA: 0x6C43420
	public object Shutdown() { }

	// RVA: 0x6C46E14
	private object CreateAtlasTexture(object atlas) { }

	// RVA: 0x6C402EC
	public object .ctor() { }

}

// Namespace: ImGuiNET.Unity
internal interface IImGuiRenderer
{

	// Methods

	// RVA: -1
	public abstract object Initialize(object io) { }

	// RVA: -1
	public abstract object Shutdown(object io) { }

	// RVA: -1
	public abstract object RenderDrawLists(object cmd, object drawData) { }

}

// Namespace: ImGuiNET.Unity
internal sealed class ImGuiRendererMesh
{

	// Fields
	private readonly object _shader; // 0x8
	private readonly object _texID; // 0x10
	private object _material; // 0x18
	private readonly object _properties; // 0x20
	private readonly object _texManager; // 0x28
	private object _mesh; // 0x30
	private static readonly object s_attributes; // 0x0
	private object _prevSubMeshCount; // 0x38
	private static readonly object s_updateMeshPerfMarker; // 0x8
	private static readonly object s_createDrawComandsPerfMarker; // 0x10

	// Methods

	// RVA: 0x6C46FDC
	public object .ctor(object resources, object texManager) { }

	// RVA: 0x6C470B8
	public object Initialize(object io) { }

	// RVA: 0x6C4722C
	public object Shutdown(object io) { }

	// RVA: 0x6C4739C
	public object RenderDrawLists(object cmd, object drawData) { }

	// RVA: 0x6C474A4
	private object UpdateMesh(object drawData, object fbSize) { }

	// RVA: 0x6C47980
	private object CreateDrawCommands(object cmd, object drawData, object fbSize) { }

	// RVA: 0x6C47E38
	private static object .cctor() { }

}

// Namespace: ImGuiNET.Unity
internal sealed class ImGuiRendererProcedural
{

	// Fields
	private readonly object _shader; // 0x8
	private readonly object _texID; // 0x10
	private readonly object _verticesID; // 0x14
	private readonly object _baseVertexID; // 0x18
	private object _material; // 0x20
	private readonly object _properties; // 0x28
	private readonly object _texManager; // 0x30
	private object _vtxBuf; // 0x38
	private object _idxBuf; // 0x40
	private object _argBuf; // 0x48
	private readonly object _drawArgs; // 0x50
	private static readonly object s_updateBuffersPerfMarker; // 0x0
	private static readonly object s_createDrawComandsPerfMarker; // 0x8

	// Methods

	// RVA: 0x6C47FD4
	public object .ctor(object resources, object texManager) { }

	// RVA: 0x6C48194
	public object Initialize(object io) { }

	// RVA: 0x6C4828C
	public object Shutdown(object io) { }

	// RVA: 0x6C483C0
	public object RenderDrawLists(object cmd, object drawData) { }

	// RVA: 0x6C48FEC
	private object CreateOrResizeVtxBuffer(object buffer, object count) { }

	// RVA: 0x6C4908C
	private object CreateOrResizeIdxBuffer(object buffer, object count) { }

	// RVA: 0x6C49130
	private object CreateOrResizeArgBuffer(object buffer, object count) { }

	// RVA: 0x6C484C8
	private object UpdateBuffers(object drawData) { }

	// RVA: 0x6C48AB8
	private object CreateDrawCommands(object cmd, object drawData, object fbSize) { }

	// RVA: 0x6C491D4
	private static object .cctor() { }

}

// Namespace: 
public enum RenderType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Mesh;
	public const object Procedural;
}

// Namespace: ImGuiNET.Unity
public static class RenderUtils
{

	// Methods

	// RVA: 0x6C42E30
	internal static object Create(object type, object shaders, object textures) { }

	// RVA: 0x6C42498
	public static object IsUsingURP() { }

	// RVA: 0x6C42530
	public static object GetCommandBuffer(object name) { }

	// RVA: 0x6C43624
	public static object ReleaseCommandBuffer(object cmd) { }

}

// Namespace: ImGuiNET.Unity
public class RenderImGuiFeature
{

	// Fields
	public object commandBuffer; // 0x10

	// Methods

	// RVA: 0x6C4928C
	public object .ctor() { }

}

