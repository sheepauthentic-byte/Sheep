// Namespace: 
internal class <Module>
{
}

// Namespace: Ionic.Zlib
internal enum BlockState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NeedMore;
	public const object BlockDone;
	public const object FinishStarted;
	public const object FinishDone;
}

// Namespace: Ionic.Zlib
internal enum DeflateFlavor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Store;
	public const object Fast;
	public const object Slow;
}

// Namespace: 
internal sealed class CompressFunc
{

	// Methods

	// RVA: 0x39370F8
	public object .ctor(object object, object method) { }

	// RVA: 0x3937F30
	public virtual object Invoke(object flush) { }

}

// Namespace: 
internal class Config
{

	// Fields
	internal object GoodLength; // 0x8
	internal object MaxLazy; // 0xC
	internal object NiceLength; // 0x10
	internal object MaxChainLength; // 0x14
	internal object Flavor; // 0x18
	private static readonly object Table; // 0x0

	// Methods

	// RVA: 0x3937F44
	private object .ctor(object goodLength, object maxLazy, object niceLength, object maxChainLength, object flavor) { }

	// RVA: 0x3932048
	public static object Lookup(object level) { }

	// RVA: 0x3937F98
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
internal sealed class DeflateManager
{

	// Fields
	private static readonly object MEM_LEVEL_MAX; // 0x0
	private static readonly object MEM_LEVEL_DEFAULT; // 0x4
	private object DeflateFunction; // 0x8
	private static readonly object _ErrorMessage; // 0x8
	private static readonly object PRESET_DICT; // 0x10
	private static readonly object INIT_STATE; // 0x14
	private static readonly object BUSY_STATE; // 0x18
	private static readonly object FINISH_STATE; // 0x1C
	private static readonly object Z_DEFLATED; // 0x20
	private static readonly object STORED_BLOCK; // 0x24
	private static readonly object STATIC_TREES; // 0x28
	private static readonly object DYN_TREES; // 0x2C
	private static readonly object Z_BINARY; // 0x30
	private static readonly object Z_ASCII; // 0x34
	private static readonly object Z_UNKNOWN; // 0x38
	private static readonly object Buf_size; // 0x3C
	private static readonly object MIN_MATCH; // 0x40
	private static readonly object MAX_MATCH; // 0x44
	private static readonly object MIN_LOOKAHEAD; // 0x48
	private static readonly object HEAP_SIZE; // 0x4C
	private static readonly object END_BLOCK; // 0x50
	internal object _codec; // 0x10
	internal object status; // 0x18
	internal object pending; // 0x20
	internal object nextPending; // 0x28
	internal object pendingCount; // 0x2C
	internal object data_type; // 0x30
	internal object last_flush; // 0x34
	internal object w_size; // 0x38
	internal object w_bits; // 0x3C
	internal object w_mask; // 0x40
	internal object window; // 0x48
	internal object window_size; // 0x50
	internal object prev; // 0x58
	internal object head; // 0x60
	internal object ins_h; // 0x68
	internal object hash_size; // 0x6C
	internal object hash_bits; // 0x70
	internal object hash_mask; // 0x74
	internal object hash_shift; // 0x78
	internal object block_start; // 0x7C
	private object config; // 0x80
	internal object match_length; // 0x88
	internal object prev_match; // 0x8C
	internal object match_available; // 0x90
	internal object strstart; // 0x94
	internal object match_start; // 0x98
	internal object lookahead; // 0x9C
	internal object prev_length; // 0xA0
	internal object compressionLevel; // 0xA4
	internal object compressionStrategy; // 0xA8
	internal object dyn_ltree; // 0xB0
	internal object dyn_dtree; // 0xB8
	internal object bl_tree; // 0xC0
	internal object treeLiterals; // 0xC8
	internal object treeDistances; // 0xD0
	internal object treeBitLengths; // 0xD8
	internal object bl_count; // 0xE0
	internal object heap; // 0xE8
	internal object heap_len; // 0xF0
	internal object heap_max; // 0xF4
	internal object depth; // 0xF8
	internal object _lengthOffset; // 0x100
	internal object lit_bufsize; // 0x104
	internal object last_lit; // 0x108
	internal object _distanceOffset; // 0x10C
	internal object opt_len; // 0x110
	internal object static_len; // 0x114
	internal object matches; // 0x118
	internal object last_eob_len; // 0x11C
	internal object bi_buf; // 0x120
	internal object bi_valid; // 0x124
	private object Rfc1950BytesEmitted; // 0x128
	private object _WantRfc1950HeaderBytes; // 0x129

	// Properties
	internal object WantRfc1950HeaderBytes { get; set; }

	// Methods

	// RVA: 0x3931CF4
	internal object .ctor() { }

	// RVA: 0x3931EE4
	private object _InitializeLazyMatch() { }

	// RVA: 0x3932238
	private object _InitializeTreeData() { }

	// RVA: 0x393231C
	internal object _InitializeBlocks() { }

	// RVA: 0x393276C
	internal object pqdownheap(object tree, object k) { }

	// RVA: 0x393294C
	internal static object _IsSmaller(object tree, object n, object m, object depth) { }

	// RVA: 0x39329F4
	internal object scan_tree(object tree, object max_code) { }

	// RVA: 0x3932C94
	internal object build_bl_tree() { }

	// RVA: 0x3933460
	internal object send_all_trees(object lcodes, object dcodes, object blcodes) { }

	// RVA: 0x3933714
	internal object send_tree(object tree, object max_code) { }

	// RVA: 0x3933BFC
	private object put_bytes(object p, object start, object len) { }

	// RVA: 0x3933BAC
	internal object send_code(object c, object tree) { }

	// RVA: 0x39335B4
	internal object send_bits(object value, object length) { }

	// RVA: 0x3933C48
	internal object _tr_align() { }

	// RVA: 0x3933EF0
	internal object _tr_tally(object dist, object lc) { }

	// RVA: 0x3934360
	internal object send_compressed_block(object ltree, object dtree) { }

	// RVA: 0x3934760
	internal object set_data_type() { }

	// RVA: 0x3933E00
	internal object bi_flush() { }

	// RVA: 0x3934AB0
	internal object bi_windup() { }

	// RVA: 0x3934B84
	internal object copy_block(object buf, object len, object header) { }

	// RVA: 0x3934CCC
	internal object flush_block_only(object eof) { }

	// RVA: 0x3934FE8
	internal object DeflateNone(object flush) { }

	// RVA: 0x3935564
	internal object _tr_stored_block(object buf, object stored_len, object eof) { }

	// RVA: 0x3934D24
	internal object _tr_flush_block(object buf, object stored_len, object eof) { }

	// RVA: 0x3935268
	private object _fillWindow() { }

	// RVA: 0x3935620
	internal object DeflateFast(object flush) { }

	// RVA: 0x393613C
	internal object DeflateSlow(object flush) { }

	// RVA: 0x3935BFC
	internal object longest_match(object cur_match) { }

	// RVA: 0x393687C
	internal object get_WantRfc1950HeaderBytes() { }

	// RVA: 0x3936884
	internal object set_WantRfc1950HeaderBytes(object value) { }

	// RVA: 0x393688C
	internal object Initialize(object codec, object level, object bits, object compressionStrategy) { }

	// RVA: 0x3936930
	internal object Initialize(object codec, object level, object windowBits, object memLevel, object strategy) { }

	// RVA: 0x3936C40
	internal object Reset() { }

	// RVA: 0x39320F0
	private object SetDeflater() { }

	// RVA: 0x3937190
	internal object Deflate(object flush) { }

	// RVA: 0x3937C40
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
public class DeflateStream
{

	// Fields
	internal object _baseStream; // 0x20
	internal object _innerStream; // 0x28
	private object _disposed; // 0x30

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x3938318
	public object .ctor(object stream, object mode, object level) { }

	// RVA: 0x3938320
	public object .ctor(object stream, object mode, object level, object leaveOpen) { }

	// RVA: 0x3938578
	protected override object Dispose(object disposing) { }

	// RVA: 0x39386A8
	public override object get_CanRead() { }

	// RVA: 0x393875C
	public override object get_CanSeek() { }

	// RVA: 0x3938764
	public override object get_CanWrite() { }

	// RVA: 0x3938818
	public override object Flush() { }

	// RVA: 0x39388BC
	public override object get_Length() { }

	// RVA: 0x39388FC
	public override object get_Position() { }

	// RVA: 0x3938974
	public override object set_Position(object value) { }

	// RVA: 0x39389B4
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x3938AE4
	public override object Seek(object offset, object origin) { }

	// RVA: 0x3938B24
	public override object SetLength(object value) { }

	// RVA: 0x3938B64
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x3938C28
	public static object CompressString(object s) { }

	// RVA: 0x3939008
	public static object CompressBuffer(object b) { }

}

// Namespace: Ionic.Zlib
public class GZipStream
{

	// Fields
	public object LastModified; // 0x20
	private object _headerByteCount; // 0x30
	internal object _baseStream; // 0x38
	private object _disposed; // 0x40
	private object _firstReadDone; // 0x41
	private object _FileName; // 0x48
	private object _Comment; // 0x50
	private object _Crc32; // 0x58
	internal static readonly object _unixEpoch; // 0x0
	internal static readonly object iso8859dash1; // 0x8

	// Properties
	public object Comment { get; set; }
	public object FileName { get; set; }
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x3939398
	public object get_Comment() { }

	// RVA: 0x39393A0
	public object set_Comment(object value) { }

	// RVA: 0x3939408
	public object get_FileName() { }

	// RVA: 0x3939410
	public object set_FileName(object value) { }

	// RVA: 0x39395E4
	public object .ctor(object stream, object mode) { }

	// RVA: 0x3939698
	public object .ctor(object stream, object mode, object level, object leaveOpen) { }

	// RVA: 0x393975C
	protected override object Dispose(object disposing) { }

	// RVA: 0x39398A0
	public override object get_CanRead() { }

	// RVA: 0x3939954
	public override object get_CanSeek() { }

	// RVA: 0x393995C
	public override object get_CanWrite() { }

	// RVA: 0x3939A10
	public override object Flush() { }

	// RVA: 0x3939AB4
	public override object get_Length() { }

	// RVA: 0x3939AF4
	public override object get_Position() { }

	// RVA: 0x3939B8C
	public override object set_Position(object value) { }

	// RVA: 0x3939BCC
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x3939D48
	public override object Seek(object offset, object origin) { }

	// RVA: 0x3939D88
	public override object SetLength(object value) { }

	// RVA: 0x3939DC8
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x3939F04
	private object EmitHeader() { }

	// RVA: 0x393A3B4
	public static object UncompressBuffer(object compressed) { }

	// RVA: 0x393A948
	private static object .cctor() { }

}

// Namespace: 
private enum InflateBlockMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TYPE;
	public const object LENS;
	public const object STORED;
	public const object TABLE;
	public const object BTREE;
	public const object DTREE;
	public const object CODES;
	public const object DRY;
	public const object DONE;
	public const object BAD;
}

// Namespace: Ionic.Zlib
internal sealed class InflateBlocks
{

	// Fields
	internal static readonly object border; // 0x0
	private object mode; // 0x8
	internal object left; // 0xC
	internal object table; // 0x10
	internal object index; // 0x14
	internal object blens; // 0x18
	internal object bb; // 0x20
	internal object tb; // 0x28
	internal object codes; // 0x30
	internal object last; // 0x38
	internal object _codec; // 0x40
	internal object bitk; // 0x48
	internal object bitb; // 0x4C
	internal object hufts; // 0x50
	internal object window; // 0x58
	internal object end; // 0x60
	internal object readAt; // 0x64
	internal object writeAt; // 0x68
	internal object checkfn; // 0x70
	internal object check; // 0x78
	internal object inftree; // 0x80

	// Methods

	// RVA: 0x393A9FC
	internal object .ctor(object codec, object checkfn, object w) { }

	// RVA: 0x393ABEC
	internal object Reset() { }

	// RVA: 0x393ACC0
	internal object Process(object r) { }

	// RVA: 0x393D71C
	internal object Free() { }

	// RVA: 0x393C3CC
	internal object Flush(object r) { }

	// RVA: 0x393D7EC
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
internal static class InternalInflateConstants
{

	// Fields
	internal static readonly object InflateMask; // 0x0

	// Methods

	// RVA: 0x393D884
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
internal sealed class InflateCodes
{

	// Fields
	internal object mode; // 0x8
	internal object len; // 0xC
	internal object tree; // 0x10
	internal object tree_index; // 0x18
	internal object need; // 0x1C
	internal object lit; // 0x20
	internal object bitsToGet; // 0x24
	internal object dist; // 0x28
	internal object lbits; // 0x2C
	internal object dbits; // 0x2D
	internal object ltree; // 0x30
	internal object ltree_index; // 0x38
	internal object dtree; // 0x40
	internal object dtree_index; // 0x48

	// Methods

	// RVA: 0x393ABDC
	internal object .ctor() { }

	// RVA: 0x393C694
	internal object Init(object bl, object bd, object tl, object tl_index, object td, object td_index) { }

	// RVA: 0x393CAB4
	internal object Process(object blocks, object r) { }

	// RVA: 0x393D91C
	internal object InflateFast(object bl, object bd, object tl, object tl_index, object td, object td_index, object s, object z) { }

}

// Namespace: 
private enum InflateManagerMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object METHOD;
	public const object FLAG;
	public const object DICT4;
	public const object DICT3;
	public const object DICT2;
	public const object DICT1;
	public const object DICT0;
	public const object BLOCKS;
	public const object CHECK4;
	public const object CHECK3;
	public const object CHECK2;
	public const object CHECK1;
	public const object DONE;
	public const object BAD;
}

// Namespace: Ionic.Zlib
internal sealed class InflateManager
{

	// Fields
	private object mode; // 0x8
	internal object _codec; // 0x10
	internal object method; // 0x18
	internal object computedCheck; // 0x1C
	internal object expectedCheck; // 0x20
	internal object marker; // 0x24
	private object _handleRfc1950HeaderBytes; // 0x28
	internal object wbits; // 0x2C
	internal object blocks; // 0x30
	private static readonly object mark; // 0x0

	// Properties
	internal object HandleRfc1950HeaderBytes { get; }

	// Methods

	// RVA: 0x393E7F0
	internal object get_HandleRfc1950HeaderBytes() { }

	// RVA: 0x393E7F8
	public object .ctor(object expectRfc1950HeaderBytes) { }

	// RVA: 0x393E82C
	internal object Reset() { }

	// RVA: 0x393E93C
	internal object End() { }

	// RVA: 0x393EA1C
	internal object Initialize(object codec, object w) { }

	// RVA: 0x393EB2C
	internal object Inflate(object flush) { }

	// RVA: 0x393F44C
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
internal sealed class InfTree
{

	// Fields
	internal static readonly object fixed_tl; // 0x0
	internal static readonly object fixed_td; // 0x8
	internal static readonly object cplens; // 0x10
	internal static readonly object cplext; // 0x18
	internal static readonly object cpdist; // 0x20
	internal static readonly object cpdext; // 0x28
	internal object hn; // 0x8
	internal object v; // 0x10
	internal object c; // 0x18
	internal object r; // 0x20
	internal object u; // 0x28
	internal object x; // 0x30

	// Methods

	// RVA: 0x393F4EC
	private object huft_build(object b, object bindex, object n, object s, object d, object e, object t, object m, object hp, object hn, object v) { }

	// RVA: 0x393C6B8
	internal object inflate_trees_bits(object c, object bb, object tb, object hp, object z) { }

	// RVA: 0x393C804
	internal object inflate_trees_dynamic(object nl, object nd, object c, object bl, object bd, object tl, object td, object hp, object z) { }

	// RVA: 0x393C594
	internal static object inflate_trees_fixed(object bl, object bd, object tl, object td, object z) { }

	// RVA: 0x3940140
	private object initWorkArea(object vsize) { }

	// RVA: 0x393ABE4
	public object .ctor() { }

	// RVA: 0x39402C4
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
internal sealed class Tree
{

	// Fields
	private static readonly object HEAP_SIZE; // 0x0
	internal static readonly object ExtraLengthBits; // 0x8
	internal static readonly object ExtraDistanceBits; // 0x10
	internal static readonly object extra_blbits; // 0x18
	internal static readonly object bl_order; // 0x20
	private static readonly object _dist_code; // 0x28
	internal static readonly object LengthCode; // 0x30
	internal static readonly object LengthBase; // 0x38
	internal static readonly object DistanceBase; // 0x40
	internal object dyn_tree; // 0x8
	internal object max_code; // 0x10
	internal object staticTree; // 0x18

	// Methods

	// RVA: 0x3934274
	internal static object DistanceCode(object dist) { }

	// RVA: 0x39404A0
	internal object gen_bitlen(object s) { }

	// RVA: 0x3932E44
	internal object build_tree(object s) { }

	// RVA: 0x39409B0
	internal static object gen_codes(object tree, object max_code, object bl_count) { }

	// RVA: 0x3940C90
	internal static object bi_reverse(object code, object len) { }

	// RVA: 0x3931EDC
	public object .ctor() { }

	// RVA: 0x3940CB8
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
public enum FlushType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Partial;
	public const object Sync;
	public const object Full;
	public const object Finish;
}

// Namespace: Ionic.Zlib
public enum CompressionLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Level0;
	public const object BestSpeed;
	public const object Level1;
	public const object Level2;
	public const object Level3;
	public const object Level4;
	public const object Level5;
	public const object Default;
	public const object Level6;
	public const object Level7;
	public const object Level8;
	public const object BestCompression;
	public const object Level9;
}

// Namespace: Ionic.Zlib
public enum CompressionStrategy
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Filtered;
	public const object HuffmanOnly;
}

// Namespace: Ionic.Zlib
public enum CompressionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Compress;
	public const object Decompress;
}

// Namespace: Ionic.Zlib
public class ZlibException
{

	// Methods

	// RVA: 0x3936BD4
	public object .ctor(object s) { }

}

// Namespace: Ionic.Zlib
internal class SharedUtils
{

	// Methods

	// RVA: 0x3940138
	public static object URShift(object number, object bits) { }

}

// Namespace: Ionic.Zlib
internal static class InternalConstants
{

	// Fields
	internal static readonly object MAX_BITS; // 0x0
	internal static readonly object BL_CODES; // 0x4
	internal static readonly object D_CODES; // 0x8
	internal static readonly object LITERALS; // 0xC
	internal static readonly object LENGTH_CODES; // 0x10
	internal static readonly object L_CODES; // 0x14
	internal static readonly object MAX_BL_BITS; // 0x18
	internal static readonly object REP_3_6; // 0x1C
	internal static readonly object REPZ_3_10; // 0x20
	internal static readonly object REPZ_11_138; // 0x24

	// Methods

	// RVA: 0x3940F64
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
internal sealed class StaticTree
{

	// Fields
	internal static readonly object lengthAndLiteralsTreeCodes; // 0x0
	internal static readonly object distTreeCodes; // 0x8
	internal static readonly object Literals; // 0x10
	internal static readonly object Distances; // 0x18
	internal static readonly object BitLengths; // 0x20
	internal object treeCodes; // 0x8
	internal object extraBits; // 0x10
	internal object extraBase; // 0x18
	internal object elems; // 0x1C
	internal object maxLength; // 0x20

	// Methods

	// RVA: 0x3940FCC
	private object .ctor(object treeCodes, object extraBits, object extraBase, object elems, object maxLength) { }

	// RVA: 0x3941020
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
public sealed class Adler
{

	// Fields
	private static readonly object BASE; // 0x0
	private static readonly object NMAX; // 0x4

	// Methods

	// RVA: 0x3936D64
	public static object Adler32(object adler, object buf, object index, object len) { }

	// RVA: 0x394124C
	private static object .cctor() { }

}

// Namespace: Ionic.Zlib
internal enum ZlibStreamFlavor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ZLIB;
	public const object DEFLATE;
	public const object GZIP;
}

// Namespace: 
internal enum StreamMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Writer;
	public const object Reader;
	public const object Undefined;
}

// Namespace: Ionic.Zlib
internal class ZlibBaseStream
{

	// Fields
	protected internal object _z; // 0x20
	protected internal object _streamMode; // 0x28
	protected internal object _flushMode; // 0x2C
	protected internal object _flavor; // 0x30
	protected internal object _compressionMode; // 0x34
	protected internal object _level; // 0x38
	protected internal object _leaveOpen; // 0x3C
	protected internal object _workingBuffer; // 0x40
	protected internal object _bufferSize; // 0x48
	protected internal object _buf1; // 0x50
	protected internal object _stream; // 0x58
	protected internal object Strategy; // 0x60
	private object crc; // 0x68
	protected internal object _GzipFileName; // 0x70
	protected internal object _GzipComment; // 0x78
	protected internal object _GzipMtime; // 0x80
	protected internal object _gzipHeaderByteCount; // 0x88
	private object nomoreinput; // 0x8C

	// Properties
	internal object Crc32 { get; }
	protected internal object _wantCompress { get; }
	private object z { get; }
	private object workingBuffer { get; }
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x393988C
	internal object get_Crc32() { }

	// RVA: 0x393846C
	public object .ctor(object stream, object compressionMode, object level, object flavor, object leaveOpen) { }

	// RVA: 0x3939EF4
	protected internal object get__wantCompress() { }

	// RVA: 0x39412A0
	private object get_z() { }

	// RVA: 0x394139C
	private object get_workingBuffer() { }

	// RVA: 0x394140C
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x3941724
	private object finish() { }

	// RVA: 0x3941E1C
	private object end() { }

	// RVA: 0x3941E84
	public override object Close() { }

	// RVA: 0x3941FD0
	public override object Flush() { }

	// RVA: 0x3942020
	public override object Seek(object offset, object origin) { }

	// RVA: 0x3942060
	public override object SetLength(object value) { }

	// RVA: 0x39420B8
	private object ReadZeroTerminatedString() { }

	// RVA: 0x3942408
	private object _ReadAndValidateGzipHeader() { }

	// RVA: 0x39427E0
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x3942D78
	public override object get_CanRead() { }

	// RVA: 0x3942DC4
	public override object get_CanSeek() { }

	// RVA: 0x3942E10
	public override object get_CanWrite() { }

	// RVA: 0x3942E5C
	public override object get_Length() { }

	// RVA: 0x3942EA8
	public override object get_Position() { }

	// RVA: 0x3942EE8
	public override object set_Position(object value) { }

	// RVA: 0x3938E24
	public static object CompressString(object s, object compressor) { }

	// RVA: 0x3939204
	public static object CompressBuffer(object b, object compressor) { }

	// RVA: 0x393A5D4
	public static object UncompressBuffer(object compressed, object decompressor) { }

}

// Namespace: Ionic.Zlib
public sealed class ZlibCodec
{

	// Fields
	public object InputBuffer; // 0x8
	public object NextIn; // 0x10
	public object AvailableBytesIn; // 0x14
	public object TotalBytesIn; // 0x18
	public object OutputBuffer; // 0x20
	public object NextOut; // 0x28
	public object AvailableBytesOut; // 0x2C
	public object TotalBytesOut; // 0x30
	public object Message; // 0x38
	internal object dstate; // 0x40
	internal object istate; // 0x48
	internal object _Adler32; // 0x50
	public object CompressLevel; // 0x54
	public object WindowBits; // 0x58
	public object Strategy; // 0x5C

	// Methods

	// RVA: 0x3942F28
	public object .ctor() { }

	// RVA: 0x3942F3C
	public object InitializeInflate(object expectRfc1950Header) { }

	// RVA: 0x3942F48
	public object InitializeInflate(object windowBits, object expectRfc1950Header) { }

	// RVA: 0x394302C
	public object Inflate(object flush) { }

	// RVA: 0x3943090
	public object EndInflate() { }

	// RVA: 0x3943108
	public object InitializeDeflate(object level, object wantRfc1950Header) { }

	// RVA: 0x3943114
	private object _InternalInitializeDeflate(object wantRfc1950Header) { }

	// RVA: 0x39431F4
	public object Deflate(object flush) { }

	// RVA: 0x3943258
	public object EndDeflate() { }

	// RVA: 0x39432C0
	internal object flush_pending() { }

	// RVA: 0x394349C
	internal object read_buf(object buf, object start, object size) { }

}

// Namespace: Ionic.Crc
public class CRC32
{

	// Fields
	private object dwPolynomial; // 0x8
	private object _TotalBytesRead; // 0x10
	private object reverseBits; // 0x18
	private object crc32Table; // 0x20
	private object _register; // 0x28

	// Properties
	public object TotalBytesRead { get; }
	public object Crc32Result { get; }

	// Methods

	// RVA: 0x39435AC
	public object get_TotalBytesRead() { }

	// RVA: 0x39435B4
	public object get_Crc32Result() { }

	// RVA: 0x39435C0
	public object GetCrc32(object input) { }

	// RVA: 0x39435C8
	public object GetCrc32AndCopy(object input, object output) { }

	// RVA: 0x3943824
	public object SlurpBlock(object block, object offset, object count) { }

	// RVA: 0x394394C
	private static object ReverseBits(object data) { }

	// RVA: 0x3943954
	private static object ReverseBits(object data) { }

	// RVA: 0x394399C
	private object GenerateLookupTable() { }

	// RVA: 0x3943BF8
	public object .ctor() { }

	// RVA: 0x3943C38
	public object .ctor(object reverseBits) { }

	// RVA: 0x3943C7C
	public object .ctor(object polynomial, object reverseBits) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=76
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=68
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=6144
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=384
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=124
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=120
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=116
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=19
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=512
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=256
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=1152
{
}

// Namespace: 
internal class <PrivateImplementationDetails>{02134F98-739C-44D1-A1F4-BF457D86AE9E}
{

	// Fields
	internal static object $$method0x600010f-1; // 0x0
	internal static object $$method0x6000110-1; // 0x4C
	internal static object $$method0x6000112-1; // 0x90
	internal static object $$method0x6000112-2; // 0x1890
	internal static object $$method0x6000112-3; // 0x1A10
	internal static object $$method0x6000112-4; // 0x1A8C
	internal static object $$method0x6000112-5; // 0x1B08
	internal static object $$method0x6000112-6; // 0x1B80
	internal static object $$method0x6000113-1; // 0x1BF8
	internal static object $$method0x6000113-2; // 0x1C6C
	internal static object $$method0x6000113-3; // 0x1CE4
	internal static object $$method0x6000113-4; // 0x1D30
	internal static object $$method0x6000113-5; // 0x1D43
	internal static object $$method0x6000113-6; // 0x1F43
	internal static object $$method0x6000113-7; // 0x2043
	internal static object $$method0x6000113-8; // 0x20B7
	internal static object $$method0x6000096-1; // 0x212F
	internal static object $$method0x6000096-2; // 0x25AF
}

