// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.Tilemaps
public sealed class Tilemap
{
}

// Namespace: UnityEngine.Tilemaps
public sealed class TilemapRenderer
{
}

