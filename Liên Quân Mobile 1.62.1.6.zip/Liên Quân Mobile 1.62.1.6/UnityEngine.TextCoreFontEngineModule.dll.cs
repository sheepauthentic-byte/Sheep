// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.TextCore
public struct FaceInfo
{

	// Fields
	private object m_FaceIndex; // 0xFFFFFFFFFFFFFFF8
	private object m_FamilyName; // 0x0
	private object m_StyleName; // 0x8
	private object m_PointSize; // 0x10
	private object m_Scale; // 0x14
	private object m_UnitsPerEM; // 0x18
	private object m_LineHeight; // 0x1C
	private object m_AscentLine; // 0x20
	private object m_CapLine; // 0x24
	private object m_MeanLine; // 0x28
	private object m_Baseline; // 0x2C
	private object m_DescentLine; // 0x30
	private object m_SuperscriptOffset; // 0x34
	private object m_SuperscriptSize; // 0x38
	private object m_SubscriptOffset; // 0x3C
	private object m_SubscriptSize; // 0x40
	private object m_UnderlineOffset; // 0x44
	private object m_UnderlineThickness; // 0x48
	private object m_StrikethroughOffset; // 0x4C
	private object m_StrikethroughThickness; // 0x50
	private object m_TabWidth; // 0x54

	// Properties
	internal object faceIndex { get; }
	public object familyName { get; set; }
	public object styleName { get; set; }
	public object pointSize { get; set; }
	public object scale { get; set; }
	public object lineHeight { get; set; }
	public object ascentLine { get; set; }
	public object capLine { get; set; }
	public object meanLine { get; set; }
	public object baseline { get; set; }
	public object descentLine { get; set; }
	public object superscriptOffset { get; set; }
	public object superscriptSize { get; set; }
	public object subscriptOffset { get; set; }
	public object subscriptSize { get; set; }
	public object underlineOffset { get; set; }
	public object underlineThickness { get; set; }
	public object strikethroughOffset { get; set; }
	public object strikethroughThickness { set; }
	public object tabWidth { get; set; }

	// Methods

	// RVA: 0x749C7C4
	internal object get_faceIndex() { }

	// RVA: 0x749C7D4
	public object get_familyName() { }

	// RVA: 0x749C7E4
	public object set_familyName(object value) { }

	// RVA: 0x749C7F4
	public object get_styleName() { }

	// RVA: 0x749C804
	public object set_styleName(object value) { }

	// RVA: 0x749C814
	public object get_pointSize() { }

	// RVA: 0x749C824
	public object set_pointSize(object value) { }

	// RVA: 0x749C834
	public object get_scale() { }

	// RVA: 0x749C844
	public object set_scale(object value) { }

	// RVA: 0x749C854
	public object get_lineHeight() { }

	// RVA: 0x749C864
	public object set_lineHeight(object value) { }

	// RVA: 0x749C874
	public object get_ascentLine() { }

	// RVA: 0x749C884
	public object set_ascentLine(object value) { }

	// RVA: 0x749C894
	public object get_capLine() { }

	// RVA: 0x749C8A4
	public object set_capLine(object value) { }

	// RVA: 0x749C8B4
	public object get_meanLine() { }

	// RVA: 0x749C8C4
	public object set_meanLine(object value) { }

	// RVA: 0x749C8D4
	public object get_baseline() { }

	// RVA: 0x749C8E4
	public object set_baseline(object value) { }

	// RVA: 0x749C8F4
	public object get_descentLine() { }

	// RVA: 0x749C904
	public object set_descentLine(object value) { }

	// RVA: 0x749C914
	public object get_superscriptOffset() { }

	// RVA: 0x749C924
	public object set_superscriptOffset(object value) { }

	// RVA: 0x749C934
	public object get_superscriptSize() { }

	// RVA: 0x749C944
	public object set_superscriptSize(object value) { }

	// RVA: 0x749C954
	public object get_subscriptOffset() { }

	// RVA: 0x749C964
	public object set_subscriptOffset(object value) { }

	// RVA: 0x749C974
	public object get_subscriptSize() { }

	// RVA: 0x749C984
	public object set_subscriptSize(object value) { }

	// RVA: 0x749C994
	public object get_underlineOffset() { }

	// RVA: 0x749C9A4
	public object set_underlineOffset(object value) { }

	// RVA: 0x749C9B4
	public object get_underlineThickness() { }

	// RVA: 0x749C9C4
	public object set_underlineThickness(object value) { }

	// RVA: 0x749C9D4
	public object get_strikethroughOffset() { }

	// RVA: 0x749C9E4
	public object set_strikethroughOffset(object value) { }

	// RVA: 0x749C9F4
	public object set_strikethroughThickness(object value) { }

	// RVA: 0x749CA04
	public object get_tabWidth() { }

	// RVA: 0x749CA14
	public object set_tabWidth(object value) { }

}

// Namespace: UnityEngine.TextCore
public enum GlyphClassDefinitionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undefined;
	public const object Base;
	public const object Ligature;
	public const object Mark;
	public const object Component;
}

// Namespace: UnityEngine.TextCore
public struct GlyphRect
{

	// Fields
	private object m_X; // 0xFFFFFFFFFFFFFFF8
	private object m_Y; // 0xFFFFFFFFFFFFFFFC
	private object m_Width; // 0x0
	private object m_Height; // 0x4
	private static readonly object s_ZeroGlyphRect; // 0x0

	// Properties
	public object x { get; }
	public object y { get; }
	public object width { get; }
	public object height { get; }
	public static object zero { get; }

	// Methods

	// RVA: 0x749CA24
	public object get_x() { }

	// RVA: 0x749CA34
	public object get_y() { }

	// RVA: 0x749CA44
	public object get_width() { }

	// RVA: 0x749CA54
	public object get_height() { }

	// RVA: 0x749CA64
	public static object get_zero() { }

	// RVA: 0x749CAE0
	public object .ctor(object x, object y, object width, object height) { }

	// RVA: 0x749CAF8
	public override object GetHashCode() { }

	// RVA: 0x749CBD8
	public override object Equals(object obj) { }

	// RVA: 0x749CCC8
	public object Equals(object other) { }

	// RVA: 0x749CE00
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore
public struct GlyphMetrics
{

	// Fields
	private object m_Width; // 0xFFFFFFFFFFFFFFF8
	private object m_Height; // 0xFFFFFFFFFFFFFFFC
	private object m_HorizontalBearingX; // 0x0
	private object m_HorizontalBearingY; // 0x4
	private object m_HorizontalAdvance; // 0x8

	// Properties
	public object width { get; }
	public object height { get; }
	public object horizontalBearingX { get; }
	public object horizontalBearingY { get; }
	public object horizontalAdvance { get; }

	// Methods

	// RVA: 0x749CE4C
	public object get_width() { }

	// RVA: 0x749CE5C
	public object get_height() { }

	// RVA: 0x749CE6C
	public object get_horizontalBearingX() { }

	// RVA: 0x749CE7C
	public object get_horizontalBearingY() { }

	// RVA: 0x749CE8C
	public object get_horizontalAdvance() { }

	// RVA: 0x749CE9C
	public object .ctor(object width, object height, object bearingX, object bearingY, object advance) { }

	// RVA: 0x749CEBC
	public override object GetHashCode() { }

	// RVA: 0x749CFAC
	public override object Equals(object obj) { }

	// RVA: 0x749D0AC
	public object Equals(object other) { }

}

// Namespace: UnityEngine.TextCore
public class Glyph
{

	// Fields
	private object m_Index; // 0x8
	private object m_Unicode; // 0xC
	private object m_Metrics; // 0x10
	private object m_GlyphRect; // 0x24
	private object m_Scale; // 0x34
	private object m_AtlasIndex; // 0x38
	private object m_ClassDefinitionType; // 0x3C

	// Properties
	public object index { get; set; }
	public object metrics { get; set; }
	public object glyphRect { get; set; }
	public object scale { get; set; }
	public object atlasIndex { get; set; }

	// Methods

	// RVA: 0x749D26C
	public object get_index() { }

	// RVA: 0x749D274
	public object set_index(object value) { }

	// RVA: 0x749D27C
	public object get_metrics() { }

	// RVA: 0x749D290
	public object set_metrics(object value) { }

	// RVA: 0x749D2A4
	public object get_glyphRect() { }

	// RVA: 0x749D2B4
	public object set_glyphRect(object value) { }

	// RVA: 0x749D2C0
	public object get_scale() { }

	// RVA: 0x749D2C8
	public object set_scale(object value) { }

	// RVA: 0x749D2D0
	public object get_atlasIndex() { }

	// RVA: 0x749D2D8
	public object set_atlasIndex(object value) { }

	// RVA: 0x749D2E0
	public object .ctor() { }

	// RVA: 0x749D31C
	internal object .ctor(object glyphStruct) { }

	// RVA: 0x749D37C
	public object .ctor(object index, object metrics, object glyphRect, object scale, object atlasIndex) { }

}

// Namespace: UnityEngine.TextCore.LowLevel
public enum GlyphLoadFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LOAD_DEFAULT;
	public const object LOAD_NO_SCALE;
	public const object LOAD_NO_HINTING;
	public const object LOAD_RENDER;
	public const object LOAD_NO_BITMAP;
	public const object LOAD_FORCE_AUTOHINT;
	public const object LOAD_MONOCHROME;
	public const object LOAD_NO_AUTOHINT;
	public const object LOAD_COLOR;
	public const object LOAD_COMPUTE_METRICS;
	public const object LOAD_BITMAP_METRICS_ONLY;
}

// Namespace: UnityEngine.TextCore.LowLevel
public enum FontEngineError
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Success;
	public const object Invalid_File_Path;
	public const object Invalid_File_Format;
	public const object Invalid_File_Structure;
	public const object Invalid_File;
	public const object Invalid_Table;
	public const object Invalid_Glyph_Index;
	public const object Invalid_Character_Code;
	public const object Invalid_Pixel_Size;
	public const object Invalid_Library;
	public const object Invalid_Face;
	public const object Invalid_Library_or_Face;
	public const object Atlas_Generation_Cancelled;
	public const object Invalid_SharedTextureData;
	public const object OpenTypeLayoutLookup_Mismatch;
}

// Namespace: UnityEngine.TextCore.LowLevel
public enum GlyphRenderMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SMOOTH_HINTED;
	public const object SMOOTH;
	public const object COLOR_HINTED;
	public const object COLOR;
	public const object RASTER_HINTED;
	public const object RASTER;
	public const object SDF;
	public const object SDF8;
	public const object SDF16;
	public const object SDF32;
	public const object SDFAA_HINTED;
	public const object SDFAA;
}

// Namespace: UnityEngine.TextCore.LowLevel
public enum GlyphPackingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BestShortSideFit;
	public const object BestLongSideFit;
	public const object BestAreaFit;
	public const object BottomLeftRule;
	public const object ContactPointRule;
}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct FontReference
{

	// Fields
	public object familyName; // 0xFFFFFFFFFFFFFFF8
	public object styleName; // 0x0
	public object faceIndex; // 0x8
	public object filePath; // 0x10
}

// Namespace: UnityEngine.TextCore.LowLevel
public sealed class FontEngine
{

	// Fields
	private static object s_Glyphs; // 0x0
	private static object s_GlyphIndexes_MarshallingArray_A; // 0x8
	private static object s_GlyphMarshallingStruct_IN; // 0x10
	private static object s_GlyphMarshallingStruct_OUT; // 0x18
	private static object s_FreeGlyphRects; // 0x20
	private static object s_UsedGlyphRects; // 0x28
	private static object s_PairAdjustmentRecords_MarshallingArray; // 0x30
	private static object s_GlyphLookupDictionary; // 0x38

	// Methods

	// RVA: 0x749D4E4
	public static object InitializeFontEngine() { }

	// RVA: 0x749D574
	private static object InitializeFontEngine_Internal() { }

	// RVA: 0x749D5B4
	public static object LoadFontFace(object filePath, object pointSize) { }

	// RVA: 0x749D66C
	private static object LoadFontFace_With_Size_Internal(object filePath, object pointSize) { }

	// RVA: 0x749D6D0
	public static object LoadFontFace(object filePath, object pointSize, object faceIndex) { }

	// RVA: 0x749D784
	private static object LoadFontFace_With_Size_And_FaceIndex_Internal(object filePath, object pointSize, object faceIndex) { }

	// RVA: 0x749D7F0
	public static object LoadFontFace(object font, object pointSize) { }

	// RVA: 0x749D8A8
	private static object LoadFontFace_With_Size_FromFont_Internal(object font, object pointSize) { }

	// RVA: 0x749D90C
	public static object LoadFontFace(object font, object pointSize, object faceIndex) { }

	// RVA: 0x749D9C0
	private static object LoadFontFace_With_Size_and_FaceIndex_FromFont_Internal(object font, object pointSize, object faceIndex) { }

	// RVA: 0x749DA2C
	public static object LoadFontFace(object familyName, object styleName, object pointSize) { }

	// RVA: 0x749DAE0
	private static object LoadFontFace_With_Size_by_FamilyName_and_StyleName_Internal(object familyName, object styleName, object pointSize) { }

	// RVA: 0x749DB4C
	internal static object TryGetSystemFontReference(object familyName, object styleName, object fontRef) { }

	// RVA: 0x749DC00
	private static object TryGetSystemFontReference_Internal(object familyName, object styleName, object fontRef) { }

	// RVA: 0x749DC6C
	public static object GetFaceInfo() { }

	// RVA: 0x749DD30
	private static object GetFaceInfo_Internal(object faceInfo) { }

	// RVA: 0x749DD80
	internal static object GetGlyphIndex(object unicode) { }

	// RVA: 0x749DDD0
	public static object TryGetGlyphWithUnicodeValue(object unicode, object flags, object glyph) { }

	// RVA: 0x749DF30
	private static object TryGetGlyphWithUnicodeValue_Internal(object unicode, object loadFlags, object glyphStruct) { }

	// RVA: 0x749DF9C
	public static object TryGetGlyphWithIndexValue(object glyphIndex, object flags, object glyph) { }

	// RVA: 0x749E0FC
	private static object TryGetGlyphWithIndexValue_Internal(object glyphIndex, object loadFlags, object glyphStruct) { }

	// RVA: 0x749E168
	internal static object SetTextureUploadMode(object shouldUploadImmediately) { }

	// RVA: 0x749E1B8
	internal static object TryAddGlyphToTexture(object glyphIndex, object padding, object packingMode, object freeGlyphRects, object usedGlyphRects, object renderMode, object texture, object glyph) { }

	// RVA: 0x749E7BC
	private static object TryAddGlyphToTexture_Internal(object glyphIndex, object padding, object packingMode, object freeGlyphRects, object freeGlyphRectCount, object usedGlyphRects, object usedGlyphRectCount, object renderMode, object texture, object glyph) { }

	// RVA: 0x749E868
	internal static object TryAddGlyphsToTexture(object glyphIndexes, object padding, object packingMode, object freeGlyphRects, object usedGlyphRects, object renderMode, object texture, object glyphs) { }

	// RVA: 0x749F2C4
	private static object TryAddGlyphsToTexture_Internal(object glyphIndex, object padding, object packingMode, object freeGlyphRects, object freeGlyphRectCount, object usedGlyphRects, object usedGlyphRectCount, object renderMode, object texture, object glyphs, object glyphCount) { }

	// RVA: 0x749F378
	internal static object GetGlyphPairAdjustmentTable(object glyphIndexes) { }

	// RVA: 0x749F5D4
	internal static object GetGlyphPairAdjustmentRecords(object glyphIndexes, object recordCount) { }

	// RVA: 0x749F520
	private static object PopulatePairAdjustmentRecordMarshallingArray_from_KernTable(object glyphIndexes, object recordCount) { }

	// RVA: 0x749F584
	private static object GetPairAdjustmentRecordsFromMarshallingArray(object glyphPairAdjustmentRecords) { }

	// RVA: -1
	private static object GenericListToMarshallingArray(object srcList, object dstArray) { }

	// RVA: -1
	private static object SetMarshallingArraySize(object marshallingArray, object recordCount) { }

	// RVA: 0x749F798
	public static object ResetAtlasTexture(object texture) { }

	// RVA: 0x749F7E8
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct FontEngineUtilities
{

	// Methods

	// RVA: 0x749F2B0
	internal static object MaxValue(object a, object b, object c) { }

}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct GlyphMarshallingStruct
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object unicode; // 0xFFFFFFFFFFFFFFFC
	public object metrics; // 0x0
	public object glyphRect; // 0x14
	public object scale; // 0x24
	public object atlasIndex; // 0x28
	public object classDefinitionType; // 0x2C
}

// Namespace: UnityEngine.TextCore.LowLevel
public enum FontFeatureLookupFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object IgnoreLigatures;
	public const object IgnoreSpacingAdjustments;
}

// Namespace: UnityEngine.TextCore.LowLevel
public struct GlyphValueRecord
{

	// Fields
	private object m_XPlacement; // 0xFFFFFFFFFFFFFFF8
	private object m_YPlacement; // 0xFFFFFFFFFFFFFFFC
	private object m_XAdvance; // 0x0
	private object m_YAdvance; // 0x4

	// Properties
	public object xPlacement { get; set; }
	public object yPlacement { get; set; }
	public object xAdvance { get; }
	public object yAdvance { get; }

	// Methods

	// RVA: 0x749F93C
	public object get_xPlacement() { }

	// RVA: 0x749F94C
	public object set_xPlacement(object value) { }

	// RVA: 0x749F95C
	public object get_yPlacement() { }

	// RVA: 0x749F96C
	public object set_yPlacement(object value) { }

	// RVA: 0x749F97C
	public object get_xAdvance() { }

	// RVA: 0x749F98C
	public object get_yAdvance() { }

	// RVA: 0x749F99C
	public static object op_Addition(object a, object b) { }

	// RVA: 0x749F9B0
	public override object GetHashCode() { }

	// RVA: 0x749FA90
	public override object Equals(object obj) { }

	// RVA: 0x749FB80
	public object Equals(object other) { }

}

// Namespace: UnityEngine.TextCore.LowLevel
public struct GlyphAdjustmentRecord
{

	// Fields
	private object m_GlyphIndex; // 0xFFFFFFFFFFFFFFF8
	private object m_GlyphValueRecord; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object glyphIndex { get; }
	public object glyphValueRecord { get; }

	// Methods

	// RVA: 0x749FCE0
	public object get_glyphIndex() { }

	// RVA: 0x749FCF0
	public object get_glyphValueRecord() { }

	// RVA: 0x749FD08
	public override object GetHashCode() { }

	// RVA: 0x749FDF8
	public override object Equals(object obj) { }

	// RVA: 0x749FEF8
	public object Equals(object other) { }

}

// Namespace: UnityEngine.TextCore.LowLevel
public struct GlyphPairAdjustmentRecord
{

	// Fields
	private object m_FirstAdjustmentRecord; // 0xFFFFFFFFFFFFFFF8
	private object m_SecondAdjustmentRecord; // 0xC
	private object m_FeatureLookupFlags; // 0x20

	// Properties
	public object firstAdjustmentRecord { get; }
	public object secondAdjustmentRecord { get; }
	public object featureLookupFlags { get; }

	// Methods

	// RVA: 0x74A004C
	public object get_firstAdjustmentRecord() { }

	// RVA: 0x74A0074
	public object get_secondAdjustmentRecord() { }

	// RVA: 0x74A009C
	public object get_featureLookupFlags() { }

	// RVA: 0x74A00AC
	public override object GetHashCode() { }

	// RVA: 0x74A01A0
	public override object Equals(object obj) { }

	// RVA: 0x74A02A4
	public object Equals(object other) { }

}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct GlyphAnchorPoint
{

	// Fields
	private object m_XCoordinate; // 0xFFFFFFFFFFFFFFF8
	private object m_YCoordinate; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object xCoordinate { get; }
	public object yCoordinate { get; }

	// Methods

	// RVA: 0x74A03FC
	public object get_xCoordinate() { }

	// RVA: 0x74A040C
	public object get_yCoordinate() { }

}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct MarkPositionAdjustment
{

	// Fields
	private object m_XPositionAdjustment; // 0xFFFFFFFFFFFFFFF8
	private object m_YPositionAdjustment; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object xPositionAdjustment { get; }
	public object yPositionAdjustment { get; }

	// Methods

	// RVA: 0x74A041C
	public object get_xPositionAdjustment() { }

	// RVA: 0x74A042C
	public object get_yPositionAdjustment() { }

}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct MarkToBaseAdjustmentRecord
{

	// Fields
	private object m_BaseGlyphID; // 0xFFFFFFFFFFFFFFF8
	private object m_BaseGlyphAnchorPoint; // 0xFFFFFFFFFFFFFFFC
	private object m_MarkGlyphID; // 0x4
	private object m_MarkPositionAdjustment; // 0x8

	// Properties
	public object baseGlyphID { get; }
	public object baseGlyphAnchorPoint { get; }
	public object markGlyphID { get; }
	public object markPositionAdjustment { get; }

	// Methods

	// RVA: 0x74A043C
	public object get_baseGlyphID() { }

	// RVA: 0x74A044C
	public object get_baseGlyphAnchorPoint() { }

	// RVA: 0x74A045C
	public object get_markGlyphID() { }

	// RVA: 0x74A046C
	public object get_markPositionAdjustment() { }

}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct MarkToMarkAdjustmentRecord
{

	// Fields
	private object m_BaseMarkGlyphID; // 0xFFFFFFFFFFFFFFF8
	private object m_BaseMarkGlyphAnchorPoint; // 0xFFFFFFFFFFFFFFFC
	private object m_CombiningMarkGlyphID; // 0x4
	private object m_CombiningMarkPositionAdjustment; // 0x8

	// Properties
	public object baseMarkGlyphID { get; }
	public object baseMarkGlyphAnchorPoint { get; }
	public object combiningMarkGlyphID { get; }
	public object combiningMarkPositionAdjustment { get; }

	// Methods

	// RVA: 0x74A047C
	public object get_baseMarkGlyphID() { }

	// RVA: 0x74A048C
	public object get_baseMarkGlyphAnchorPoint() { }

	// RVA: 0x74A049C
	public object get_combiningMarkGlyphID() { }

	// RVA: 0x74A04AC
	public object get_combiningMarkPositionAdjustment() { }

}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct MultipleSubstitutionRecord
{

	// Fields
	private object m_TargetGlyphID; // 0xFFFFFFFFFFFFFFF8
	private object m_SubstituteGlyphIDs; // 0x0
}

// Namespace: UnityEngine.TextCore.LowLevel
internal struct LigatureSubstitutionRecord
{

	// Fields
	private object m_ComponentGlyphIDs; // 0xFFFFFFFFFFFFFFF8
	private object m_LigatureGlyphID; // 0x0

	// Properties
	public object componentGlyphIDs { get; }
	public object ligatureGlyphID { get; }

	// Methods

	// RVA: 0x74A066C
	public object get_componentGlyphIDs() { }

	// RVA: 0x74A067C
	public object get_ligatureGlyphID() { }

}

