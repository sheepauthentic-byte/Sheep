// Namespace: 
internal class <Module>
{
}

// Namespace: Unity.Burst
internal static class Unsafe
{

	// Methods

	// RVA: -1
	public static object AsRef(object source) { }

}

// Namespace: System.Runtime.Versioning
internal sealed class NonVersionableAttribute
{

	// Methods

	// RVA: 0x7266F0C
	public object .ctor() { }

}

