// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.SocialPlatforms
public interface ISocialPlatform
{

	// Methods

	// RVA: -1
	public abstract object Authenticate(object user, object callback) { }

	// RVA: -1
	public abstract object Authenticate(object user, object callback) { }

	// RVA: -1
	public abstract object LoadFriends(object user, object callback) { }

}

// Namespace: UnityEngine.SocialPlatforms
public interface ILocalUser
{

	// Properties
	public abstract object authenticated { get; }

	// Methods

	// RVA: -1
	public abstract object get_authenticated() { }

}

// Namespace: UnityEngine.SocialPlatforms
public enum UserState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Online;
	public const object OnlineAndAway;
	public const object OnlineAndBusy;
	public const object Offline;
	public const object Playing;
}

// Namespace: UnityEngine.SocialPlatforms
public interface IUserProfile
{
}

// Namespace: UnityEngine.SocialPlatforms
public interface IAchievement
{
}

// Namespace: UnityEngine.SocialPlatforms
public interface IAchievementDescription
{
}

// Namespace: UnityEngine.SocialPlatforms
public interface IScore
{
}

// Namespace: UnityEngine.SocialPlatforms
public enum UserScope
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Global;
	public const object FriendsOnly;
}

// Namespace: UnityEngine.SocialPlatforms
public enum TimeScope
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Today;
	public const object Week;
	public const object AllTime;
}

// Namespace: UnityEngine.SocialPlatforms
public struct Range
{

	// Fields
	public object from; // 0xFFFFFFFFFFFFFFF8
	public object count; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x73F6A24
	public object .ctor(object fromValue, object valueCount) { }

}

// Namespace: UnityEngine.SocialPlatforms
public interface ILeaderboard
{

	// Properties
	public abstract object id { get; }
	public abstract object userScope { get; }
	public abstract object range { get; }
	public abstract object timeScope { get; }

	// Methods

	// RVA: -1
	public abstract object get_id() { }

	// RVA: -1
	public abstract object get_userScope() { }

	// RVA: -1
	public abstract object get_range() { }

	// RVA: -1
	public abstract object get_timeScope() { }

}

// Namespace: UnityEngine.SocialPlatforms.Impl
public class LocalUser
{

	// Fields
	private object m_Friends; // 0x38
	private object m_Authenticated; // 0x40
	private object m_Underage; // 0x41

	// Properties
	public object authenticated { get; }

	// Methods

	// RVA: 0x73F6A34
	public object .ctor() { }

	// RVA: 0x73F6B60
	public object SetFriends(object friends) { }

	// RVA: 0x73F6B68
	public object SetAuthenticated(object value) { }

	// RVA: 0x73F6B70
	public object SetUnderage(object value) { }

	// RVA: 0x73F6B78
	public object get_authenticated() { }

}

// Namespace: UnityEngine.SocialPlatforms.Impl
public class UserProfile
{

	// Fields
	protected object m_UserName; // 0x8
	protected object m_ID; // 0x10
	private object m_legacyID; // 0x18
	protected object m_IsFriend; // 0x20
	protected object m_State; // 0x24
	protected object m_Image; // 0x28
	private object m_gameID; // 0x30

	// Properties
	public object userName { get; }
	public object id { get; }
	public object isFriend { get; }
	public object state { get; }

	// Methods

	// RVA: 0x73F6A9C
	public object .ctor() { }

	// RVA: 0x73F6B80
	public object .ctor(object name, object teamId, object gameId, object friend, object state, object image) { }

	// RVA: 0x73F6BE4
	public override object ToString() { }

	// RVA: 0x73F6D80
	public object SetUserName(object name) { }

	// RVA: 0x73F6D88
	public object SetUserID(object id) { }

	// RVA: 0x73F6D90
	public object SetLegacyUserID(object id) { }

	// RVA: 0x73F6D98
	public object SetUserGameID(object id) { }

	// RVA: 0x73F6DA0
	public object SetImage(object image) { }

	// RVA: 0x73F6D68
	public object get_userName() { }

	// RVA: 0x73F6D60
	public object get_id() { }

	// RVA: 0x73F6D70
	public object get_isFriend() { }

	// RVA: 0x73F6D78
	public object get_state() { }

}

// Namespace: UnityEngine.SocialPlatforms.Impl
public class Achievement
{

	// Fields
	private object m_Completed; // 0x8
	private object m_Hidden; // 0x9
	private object m_LastReportedDate; // 0x10
	private object <id>k__BackingField; // 0x18
	private object <percentCompleted>k__BackingField; // 0x20

	// Properties
	public object id { get; set; }
	public object percentCompleted { get; set; }
	public object completed { get; }
	public object hidden { get; }
	public object lastReportedDate { get; }

	// Methods

	// RVA: 0x73F6DA8
	public object .ctor(object id, object percentCompleted, object completed, object hidden, object lastReportedDate) { }

	// RVA: 0x73F6E08
	public object .ctor(object id, object percent) { }

	// RVA: 0x73F6E9C
	public object .ctor() { }

	// RVA: 0x73F6F48
	public override object ToString() { }

	// RVA: 0x73F7120
	public object get_id() { }

	// RVA: 0x73F7128
	public object set_id(object value) { }

	// RVA: 0x73F7130
	public object get_percentCompleted() { }

	// RVA: 0x73F7138
	public object set_percentCompleted(object value) { }

	// RVA: 0x73F7108
	public object get_completed() { }

	// RVA: 0x73F7110
	public object get_hidden() { }

	// RVA: 0x73F7118
	public object get_lastReportedDate() { }

}

// Namespace: UnityEngine.SocialPlatforms.Impl
public class AchievementDescription
{

	// Fields
	private object m_Title; // 0x8
	private object m_Image; // 0x10
	private object m_AchievedDescription; // 0x18
	private object m_UnachievedDescription; // 0x20
	private object m_Hidden; // 0x28
	private object m_Points; // 0x2C
	private object <id>k__BackingField; // 0x30

	// Properties
	public object id { get; set; }
	public object title { get; }
	public object achievedDescription { get; }
	public object unachievedDescription { get; }
	public object hidden { get; }
	public object points { get; }

	// Methods

	// RVA: 0x73F7140
	public object .ctor(object id, object title, object image, object achievedDescription, object unachievedDescription, object hidden, object points) { }

	// RVA: 0x73F71AC
	public override object ToString() { }

	// RVA: 0x73F7368
	public object SetImage(object image) { }

	// RVA: 0x73F7370
	public object get_id() { }

	// RVA: 0x73F7378
	public object set_id(object value) { }

	// RVA: 0x73F7340
	public object get_title() { }

	// RVA: 0x73F7348
	public object get_achievedDescription() { }

	// RVA: 0x73F7350
	public object get_unachievedDescription() { }

	// RVA: 0x73F7360
	public object get_hidden() { }

	// RVA: 0x73F7358
	public object get_points() { }

}

// Namespace: UnityEngine.SocialPlatforms.Impl
public class Score
{

	// Fields
	private object m_Date; // 0x8
	private object m_FormattedValue; // 0x10
	private object m_UserID; // 0x18
	private object m_Rank; // 0x20
	private object <leaderboardID>k__BackingField; // 0x28
	private object <value>k__BackingField; // 0x30

	// Properties
	public object leaderboardID { get; set; }
	public object value { get; set; }

	// Methods

	// RVA: 0x73F7380
	public object .ctor(object leaderboardID, object value) { }

	// RVA: 0x73F7448
	public object .ctor(object leaderboardID, object value, object userID, object date, object formattedValue, object rank) { }

	// RVA: 0x73F74AC
	public override object ToString() { }

	// RVA: 0x73F7684
	public object get_leaderboardID() { }

	// RVA: 0x73F768C
	public object set_leaderboardID(object value) { }

	// RVA: 0x73F7694
	public object get_value() { }

	// RVA: 0x73F769C
	public object set_value(object value) { }

}

// Namespace: UnityEngine.SocialPlatforms.Impl
public class Leaderboard
{

	// Fields
	private object m_Loading; // 0x8
	private object m_LocalUserScore; // 0x10
	private object m_MaxRange; // 0x18
	private object m_Scores; // 0x20
	private object m_Title; // 0x28
	private object m_UserIDs; // 0x30
	private object <id>k__BackingField; // 0x38
	private object <userScope>k__BackingField; // 0x40
	private object <range>k__BackingField; // 0x44
	private object <timeScope>k__BackingField; // 0x4C

	// Properties
	public object id { get; set; }
	public object userScope { get; set; }
	public object range { get; set; }
	public object timeScope { get; set; }

	// Methods

	// RVA: 0x73F76A4
	public object .ctor() { }

	// RVA: 0x73F7844
	public override object ToString() { }

	// RVA: 0x73F7C04
	public object SetLocalUserScore(object score) { }

	// RVA: 0x73F7C0C
	public object SetMaxRange(object maxRange) { }

	// RVA: 0x73F7C14
	public object SetScores(object scores) { }

	// RVA: 0x73F7C1C
	public object SetTitle(object title) { }

	// RVA: 0x73F7C24
	public object GetUserFilter() { }

	// RVA: 0x73F7C2C
	public object get_id() { }

	// RVA: 0x73F7C34
	public object set_id(object value) { }

	// RVA: 0x73F7C3C
	public object get_userScope() { }

	// RVA: 0x73F7C44
	public object set_userScope(object value) { }

	// RVA: 0x73F7C4C
	public object get_range() { }

	// RVA: 0x73F7C54
	public object set_range(object value) { }

	// RVA: 0x73F7C5C
	public object get_timeScope() { }

	// RVA: 0x73F7C64
	public object set_timeScope(object value) { }

}

// Namespace: UnityEngine.SocialPlatforms.GameCenter
internal struct GcUserProfileData
{

	// Fields
	public object userName; // 0xFFFFFFFFFFFFFFF8
	public object teamID; // 0x0
	public object gameID; // 0x8
	public object isFriend; // 0x10
	public object image; // 0x18

	// Methods

	// RVA: 0x73F7CA8
	public object ToUserProfile() { }

	// RVA: 0x73F7DF8
	public object AddToArray(object array, object number) { }

}

// Namespace: UnityEngine.SocialPlatforms.GameCenter
internal struct GcAchievementDescriptionData
{

	// Fields
	public object m_Identifier; // 0xFFFFFFFFFFFFFFF8
	public object m_Title; // 0x0
	public object m_Image; // 0x8
	public object m_AchievedDescription; // 0x10
	public object m_UnachievedDescription; // 0x18
	public object m_Hidden; // 0x20
	public object m_Points; // 0x24

	// Methods

	// RVA: 0x73F7FBC
	public object ToAchievementDescription() { }

}

// Namespace: UnityEngine.SocialPlatforms.GameCenter
internal struct GcAchievementData
{

	// Fields
	public object m_Identifier; // 0xFFFFFFFFFFFFFFF8
	public object m_PercentCompleted; // 0x0
	public object m_Completed; // 0x8
	public object m_Hidden; // 0xC
	public object m_LastReportedDate; // 0x10

	// Methods

	// RVA: 0x73F81B0
	public object ToAchievement() { }

}

// Namespace: UnityEngine.SocialPlatforms.GameCenter
internal struct GcScoreData
{

	// Fields
	public object m_Category; // 0xFFFFFFFFFFFFFFF8
	public object m_ValueLow; // 0x0
	public object m_ValueHigh; // 0x4
	public object m_Date; // 0x8
	public object m_FormattedValue; // 0x10
	public object m_PlayerID; // 0x18
	public object m_Rank; // 0x20

	// Methods

	// RVA: 0x73F83E0
	public object ToScore() { }

}

// Namespace: 
private sealed class <>c__DisplayClass21_0
{

	// Fields
	public object callback; // 0x8

	// Methods

	// RVA: 0x73F9838
	public object .ctor() { }

	// RVA: 0x73FB898
	internal object <UnityEngine.SocialPlatforms.ISocialPlatform.Authenticate>b__0(object success, object error) { }

}

// Namespace: UnityEngine.SocialPlatforms.GameCenter
public class GameCenterPlatform
{

	// Fields
	private static object s_AuthenticateCallback; // 0x0
	private static object s_adCache; // 0x8
	private static object s_friends; // 0x10
	private static object s_users; // 0x18
	private static object s_ResetAchievements; // 0x20
	private static object m_LocalUser; // 0x28
	private static object m_GcBoards; // 0x30

	// Properties
	public object localUser { get; }

	// Methods

	// RVA: 0x73F8508
	private static object ClearAchievementDescriptions(object size) { }

	// RVA: 0x73F8604
	private static object SetAchievementDescription(object data, object number) { }

	// RVA: 0x73F8740
	private static object SetAchievementDescriptionImage(object texture, object number) { }

	// RVA: 0x73F8888
	private static object TriggerAchievementDescriptionCallback(object callback) { }

	// RVA: 0x73F89B0
	private static object AuthenticateCallbackWrapper(object result, object error) { }

	// RVA: 0x73F8D0C
	private static object ClearFriends(object size) { }

	// RVA: 0x73F8E58
	private static object SetFriends(object data, object number) { }

	// RVA: 0x73F8ECC
	private static object SetFriendImage(object texture, object number) { }

	// RVA: 0x73F909C
	private static object TriggerFriendsCallbackWrapper(object callback, object result) { }

	// RVA: 0x73F9180
	private static object AchievementCallbackWrapper(object callback, object result) { }

	// RVA: 0x73F9310
	private static object ProgressCallbackWrapper(object callback, object success) { }

	// RVA: 0x73F932C
	private static object ScoreCallbackWrapper(object callback, object success) { }

	// RVA: 0x73F9348
	private static object ScoreLoaderCallbackWrapper(object callback, object result) { }

	// RVA: 0x73F9470
	private object UnityEngine.SocialPlatforms.ISocialPlatform.LoadFriends(object user, object callback) { }

	// RVA: 0x73F96E4
	private object UnityEngine.SocialPlatforms.ISocialPlatform.Authenticate(object user, object callback) { }

	// RVA: 0x73F9840
	private object UnityEngine.SocialPlatforms.ISocialPlatform.Authenticate(object user, object callback) { }

	// RVA: 0x73F9934
	public object get_localUser() { }

	// RVA: 0x73F8ACC
	private static object PopulateLocalUser() { }

	// RVA: 0x73F9CF4
	public object LoadAchievementDescriptions(object callback) { }

	// RVA: 0x73F9E4C
	public object ReportProgress(object id, object progress, object callback) { }

	// RVA: 0x73F9FBC
	public object LoadAchievements(object callback) { }

	// RVA: 0x73FA114
	public object ReportScore(object score, object board, object callback) { }

	// RVA: 0x73FA278
	public object LoadScores(object category, object callback) { }

	// RVA: 0x73FA3F0
	public object LoadScores(object board, object callback) { }

	// RVA: 0x73FA9C0
	private static object LeaderboardCallbackWrapper(object callback, object success) { }

	// RVA: 0x73FA9DC
	public object GetLoading(object board) { }

	// RVA: 0x73F9558
	private object VerifyAuthentication() { }

	// RVA: 0x73FAD00
	public object ShowAchievementsUI() { }

	// RVA: 0x73FADE4
	public object ShowLeaderboardUI() { }

	// RVA: 0x73FAEC8
	private static object ClearUsers(object size) { }

	// RVA: 0x73FAFA0
	private static object SetUser(object data, object number) { }

	// RVA: 0x73FB014
	private static object SetUserImage(object texture, object number) { }

	// RVA: 0x73FB088
	private static object TriggerUsersCallbackWrapper(object callback) { }

	// RVA: 0x73FB104
	public object LoadUsers(object userIds, object callback) { }

	// RVA: 0x73F8F40
	private static object SafeSetUserImage(object array, object texture, object number) { }

	// RVA: 0x73F8DE4
	private static object SafeClearArray(object array, object size) { }

	// RVA: 0x73FB27C
	public object CreateLeaderboard() { }

	// RVA: 0x73FB2D0
	public object CreateAchievement() { }

	// RVA: 0x73FB3B0
	private static object TriggerResetAchievementCallback(object result) { }

	// RVA: 0x73F98F4
	internal static object Authenticate() { }

	// RVA: 0x73F9B34
	internal static object GetAuthenticated() { }

	// RVA: 0x73F9B74
	internal static object Internal_UserName() { }

	// RVA: 0x73F9BB4
	internal static object Internal_UserID() { }

	// RVA: 0x73F9BF4
	internal static object Internal_UserGameID() { }

	// RVA: 0x73F9C34
	internal static object Internal_LegacyUserID() { }

	// RVA: 0x73F9C74
	internal static object GetIsUnderage() { }

	// RVA: 0x73F9CB4
	internal static object GetUserImage() { }

	// RVA: 0x73F9694
	internal static object LoadFriends(object callback) { }

	// RVA: 0x73F9DFC
	internal static object InternalLoadAchievementDescriptions(object callback) { }

	// RVA: 0x73FA0C4
	internal static object InternalLoadAchievements(object callback) { }

	// RVA: 0x73F9F44
	internal static object InternalReportProgress(object id, object progress, object callback) { }

	// RVA: 0x73FA20C
	internal static object InternalReportScore(object score, object category, object callback) { }

	// RVA: 0x73FA38C
	internal static object InternalLoadScores(object category, object callback) { }

	// RVA: 0x73FADA4
	internal static object Internal_ShowAchievementsUI() { }

	// RVA: 0x73FAE88
	internal static object Internal_ShowLeaderboardUI() { }

	// RVA: 0x73FB218
	internal static object Internal_LoadUsers(object userIds, object callback) { }

	// RVA: 0x73FB47C
	internal static object ResetAllAchievements() { }

	// RVA: 0x73FB4BC
	internal static object ShowDefaultAchievementBanner(object value) { }

	// RVA: 0x73FB50C
	public static object ResetAllAchievements(object callback) { }

	// RVA: 0x73FB5C0
	public static object ShowDefaultAchievementCompletionBanner(object value) { }

	// RVA: 0x73FB66C
	public static object ShowLeaderboardUI(object leaderboardID, object timeScope) { }

	// RVA: 0x73FB724
	internal static object ShowSpecificLeaderboardUI(object leaderboardID, object timeScope) { }

	// RVA: 0x73FB788
	public object .ctor() { }

	// RVA: 0x73FB790
	private static object .cctor() { }

}

// Namespace: UnityEngine.SocialPlatforms.GameCenter
internal class GcLeaderboard
{

	// Fields
	private object m_InternalLeaderboard; // 0x8
	private object m_GenericLeaderboard; // 0x10

	// Methods

	// RVA: 0x73FA8F4
	internal object .ctor(object board) { }

	// RVA: 0x73FB900
	protected override object Finalize() { }

	// RVA: 0x73FAC60
	internal object Contains(object board) { }

	// RVA: 0x73FBA1C
	internal object SetScores(object scoreDatas) { }

	// RVA: 0x73FBB3C
	internal object SetLocalScore(object scoreData) { }

	// RVA: 0x73FBB68
	internal object SetMaxRange(object maxRange) { }

	// RVA: 0x73FBB78
	internal object SetTitle(object title) { }

	// RVA: 0x73FA920
	internal object Internal_LoadScores(object category, object from, object count, object userIDs, object playerScope, object timeScope, object callback) { }

	// RVA: 0x73FBB88
	private static object GcLeaderboard_LoadScores(object self, object category, object from, object count, object userIDs, object playerScope, object timeScope, object callback) { }

	// RVA: 0x73FAC70
	internal object Loading() { }

	// RVA: 0x73FBC24
	private static object GcLeaderboard_Loading(object leaderboard) { }

	// RVA: 0x73FB9C8
	internal object Dispose() { }

	// RVA: 0x73FBC74
	private static object GcLeaderboard_Dispose(object leaderboard) { }

}

