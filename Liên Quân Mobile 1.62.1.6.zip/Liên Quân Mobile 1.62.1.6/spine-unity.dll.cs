// Namespace: 
internal class <Module>
{
}

// Namespace: 
public enum AdditionalShaderChannelFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object TexCoord1;
	public const object Color;
	public const object All;
}

// Namespace: 
public interface IRender3D
{

	// Properties
	public abstract object AdditionalShaderChannelFlags { get; }
	public abstract object Depth { get; }

	// Methods

	// RVA: -1
	public abstract object get_AdditionalShaderChannelFlags() { }

	// RVA: -1
	public abstract object SetDepth(object startDepth) { }

	// RVA: -1
	public abstract object get_Depth() { }

	// RVA: -1
	public abstract object OnCanvasSizeChanged() { }

	// RVA: -1
	public abstract object SetMaterialDirty() { }

	// RVA: -1
	public abstract object SetGraphicDirty() { }

	// RVA: -1
	public abstract object PreUpdate() { }

}

// Namespace: 
public interface IGraphic3DGroup
{

	// Properties
	public abstract object AdditionalShaderChannelFlags { get; }

	// Methods

	// RVA: -1
	public abstract object get_AdditionalShaderChannelFlags() { }

	// RVA: -1
	public abstract object SetAdditionalShaderChannelFlag(object flag) { }

	// RVA: -1
	public abstract object GetAdditionalShaderChannelFlag(object flag) { }

	// RVA: -1
	public abstract object MarkNeedRefresh() { }

	// RVA: -1
	public abstract object AddGraphic3D(object graphic, object instanceID) { }

	// RVA: -1
	public abstract object RemoveGraphic3D(object graphic, object instanceID) { }

	// RVA: -1
	public abstract object AddGroup3D(object group, object instanceID) { }

	// RVA: -1
	public abstract object RemoveGroup3D(object instanceID) { }

	// RVA: -1
	public abstract object GetSortingOrder() { }

	// RVA: -1
	public abstract object OnCanvasSizeChanged() { }

	// RVA: -1
	public abstract object SetDepth(object startDepth) { }

	// RVA: -1
	public abstract object OnChildGraphicsEnabled(object graphic3D) { }

	// RVA: -1
	public abstract object OnChildGraphicsDisabled(object graphic3D) { }

	// RVA: -1
	public abstract object OnChildGraphicsChanged(object graphic3D) { }

}

// Namespace: 
public abstract class UI3DBehaviour
{

	// Methods

	// RVA: 0x6C8C0E4
	public virtual object OnCanvasHierarchyChanged() { }

	// RVA: 0x6C8C0E8
	protected object .ctor() { }

}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0x6C8C0F0
	private static object Get() { }

	// RVA: 0x6C8C1C0
	public object .ctor() { }

}

// Namespace: Spine
public struct BoneMatrix
{

	// Fields
	public object a; // 0xFFFFFFFFFFFFFFF8
	public object b; // 0xFFFFFFFFFFFFFFFC
	public object c; // 0x0
	public object d; // 0x4
	public object x; // 0x8
	public object y; // 0xC

	// Methods

	// RVA: 0x6C8C2FC
	public static object CalculateSetupWorld(object boneData) { }

	// RVA: 0x6C8C39C
	private static object GetInheritedInternal(object boneData, object parentMatrix) { }

	// RVA: 0x6C8CA20
	public object .ctor(object boneData) { }

	// RVA: 0x6C8CB2C
	public object .ctor(object bone) { }

	// RVA: 0x6C8CC38
	public object TransformMatrix(object local) { }

}

// Namespace: Spine
public static class SpineSkeletonExtensions
{

	// Methods

	// RVA: 0x6C8CCF8
	public static object IsWeighted(object va) { }

	// RVA: 0x6C8CD30
	public static object InheritsRotation(object mode) { }

	// RVA: 0x6C8CD3C
	public static object InheritsScale(object mode) { }

}

// Namespace: Spine.Unity
public class AnimationReferenceAsset
{

	// Fields
	private const object QuietSkeletonData;
	protected object skeletonDataAsset; // 0x10
	protected object animationName; // 0x18
	private object animation; // 0x20

	// Properties
	public object SkeletonDataAsset { get; }
	public object Animation { get; }

	// Methods

	// RVA: 0x6C8CD48
	public object get_SkeletonDataAsset() { }

	// RVA: 0x6C8CD50
	public object get_Animation() { }

	// RVA: 0x6C8CD8C
	public object Initialize() { }

	// RVA: 0x6C8D5DC
	public static object op_Implicit(object asset) { }

	// RVA: 0x6C8D62C
	public object .ctor() { }

}

// Namespace: Spine.Unity
public abstract class AtlasAssetBase
{

	// Properties
	public abstract object PrimaryMaterial { get; }
	public abstract object Materials { get; }
	public abstract object MaterialCount { get; }
	public abstract object IsLoaded { get; }

	// Methods

	// RVA: -1
	public abstract object get_PrimaryMaterial() { }

	// RVA: -1
	public abstract object get_Materials() { }

	// RVA: -1
	public abstract object get_MaterialCount() { }

	// RVA: -1
	public abstract object get_IsLoaded() { }

	// RVA: -1
	public abstract object Clear() { }

	// RVA: -1
	public abstract object GetAtlas(object onlyMetaData) { }

	// RVA: 0x6C8D634
	protected object .ctor() { }

}

// Namespace: 
public class ReplacementMaterial
{

	// Fields
	public object pageName; // 0x8
	public object material; // 0x10

	// Methods

	// RVA: 0x6C8E350
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class BlendModeMaterials
{

	// Fields
	protected object requiresBlendModeMaterials; // 0x8
	public object applyAdditiveMaterial; // 0x9
	public object additiveMaterials; // 0x10
	public object multiplyMaterials; // 0x18
	public object screenMaterials; // 0x20

	// Properties
	public object RequiresBlendModeMaterials { get; set; }

	// Methods

	// RVA: 0x6C8D63C
	public object get_RequiresBlendModeMaterials() { }

	// RVA: 0x6C8D644
	public object set_RequiresBlendModeMaterials(object value) { }

	// RVA: 0x6C8D64C
	public object BlendModeForMaterial(object material) { }

	// RVA: 0x6C8DA40
	public object ApplyMaterials(object skeletonData) { }

	// RVA: 0x6C8E06C
	protected object CloneAtlasRegionWithMaterial(object originalRegion, object replacementMaterials) { }

	// RVA: 0x6C8E2A0
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class EventDataReferenceAsset
{

	// Fields
	private const object QuietSkeletonData;
	protected object skeletonDataAsset; // 0x10
	protected object eventName; // 0x18
	private object eventData; // 0x20

	// Properties
	public object EventData { get; }

	// Methods

	// RVA: 0x6C8E358
	public object get_EventData() { }

	// RVA: 0x6C8E394
	public object Initialize() { }

	// RVA: 0x6C8E578
	public static object op_Implicit(object asset) { }

	// RVA: 0x6C8E5C8
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class RegionlessAttachmentLoader
{

	// Fields
	private static object emptyRegion; // 0x0

	// Properties
	private static object EmptyRegion { get; }

	// Methods

	// RVA: 0x6C8E5D0
	private static object get_EmptyRegion() { }

	// RVA: 0x6C8E78C
	public object NewRegionAttachment(object skin, object name, object path) { }

	// RVA: 0x6C8E80C
	public object NewMeshAttachment(object skin, object name, object path) { }

	// RVA: 0x6C8E88C
	public object NewBoundingBoxAttachment(object skin, object name) { }

	// RVA: 0x6C8E8F4
	public object NewPathAttachment(object skin, object name) { }

	// RVA: 0x6C8E95C
	public object NewPointAttachment(object skin, object name) { }

	// RVA: 0x6C8E9C4
	public object NewClippingAttachment(object skin, object name) { }

	// RVA: 0x6C8EA2C
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class SkeletonDataAsset
{

	// Fields
	public object atlasAssets; // 0x10
	public object scale; // 0x18
	public object skeletonJSON; // 0x20
	public object isUpgradingBlendModeMaterials; // 0x28
	public object blendModeMaterials; // 0x30
	public object skeletonDataModifiers; // 0x38
	public object fromAnimation; // 0x40
	public object toAnimation; // 0x48
	public object duration; // 0x50
	public object defaultMix; // 0x58
	public object controller; // 0x60
	private object skeletonData; // 0x68
	private object stateData; // 0x70

	// Properties
	public object IsLoaded { get; }

	// Methods

	// RVA: 0x6C8EA34
	public object get_IsLoaded() { }

	// RVA: 0x6C8EA44
	private object Reset() { }

	// RVA: 0x6C8EA54
	public static object CreateRuntimeInstance(object skeletonDataFile, object atlasAsset, object initialize, object scale) { }

	// RVA: 0x6C8EB74
	public static object CreateRuntimeInstance(object skeletonDataFile, object atlasAssets, object initialize, object scale) { }

	// RVA: 0x6C8EA4C
	public object Clear() { }

	// RVA: 0x6C8EC18
	public object GetAnimationStateData() { }

	// RVA: 0x6C8CF68
	public object GetSkeletonData(object quiet) { }

	// RVA: 0x6C8F248
	internal object InitializeWithData(object sd) { }

	// RVA: 0x6C8F2BC
	public object FillStateData() { }

	// RVA: 0x6C8EC58
	internal object GetAtlasArray() { }

	// RVA: 0x6C8EF48
	internal static object ReadSkeletonData(object bytes, object attachmentLoader, object scale) { }

	// RVA: 0x6C8F134
	internal static object ReadSkeletonData(object text, object attachmentLoader, object scale) { }

	// RVA: 0x6C8F3EC
	public object .ctor() { }

}

// Namespace: 
public enum SourceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Json;
	public const object Binary;
}

// Namespace: 
public class VersionInfo
{

	// Fields
	public object rawVersion; // 0x8
	public object version; // 0x10
	public object sourceType; // 0x18

	// Methods

	// RVA: 0x6C8F52C
	public object .ctor() { }

}

// Namespace: 
public class CompatibilityProblemInfo
{

	// Fields
	public object actualVersion; // 0x8
	public object compatibleVersions; // 0x10
	public object explicitProblemDescription; // 0x18

	// Methods

	// RVA: 0x6C8F534
	public object DescriptionString() { }

	// RVA: 0x6C8F878
	public object .ctor() { }

}

// Namespace: Spine.Unity
public static class SkeletonDataCompatibility
{
}

// Namespace: Spine.Unity
public abstract class SkeletonDataModifierAsset
{

	// Methods

	// RVA: -1
	public abstract object Apply(object skeletonData) { }

	// RVA: 0x6C8F880
	protected object .ctor() { }

}

// Namespace: Spine.Unity
public class SpineAtlasAsset
{

	// Fields
	public object atlasFile; // 0x10
	public object materials; // 0x18
	protected object atlas; // 0x20

	// Properties
	public override object IsLoaded { get; }
	public override object Materials { get; }
	public override object MaterialCount { get; }
	public override object PrimaryMaterial { get; }

	// Methods

	// RVA: 0x6C8F888
	public override object get_IsLoaded() { }

	// RVA: 0x6C8F898
	public override object get_Materials() { }

	// RVA: 0x6C8F8A0
	public override object get_MaterialCount() { }

	// RVA: 0x6C8F8B8
	public override object get_PrimaryMaterial() { }

	// RVA: 0x6C8F8EC
	public static object CreateRuntimeInstance(object atlasText, object materials, object initialize) { }

	// RVA: 0x6C8F9FC
	public static object CreateRuntimeInstance(object atlasText, object textures, object materialPropertySource, object initialize) { }

	// RVA: 0x6C8FF80
	public static object CreateRuntimeInstance(object atlasText, object textures, object shader, object initialize) { }

	// RVA: 0x6C8F9BC
	private object Reset() { }

	// RVA: 0x6C90064
	public override object Clear() { }

	// RVA: 0x6C9006C
	public override object GetAtlas(object onlyMetaData) { }

	// RVA: 0x6C9050C
	public object GenerateMesh(object name, object mesh, object material, object scale) { }

	// RVA: 0x6C90964
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class NoOpTextureLoader
{

	// Methods

	// RVA: 0x6C9096C
	public object Load(object page, object path) { }

	// RVA: 0x6C90970
	public object Unload(object texture) { }

	// RVA: 0x6C90504
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class MaterialsTextureLoader
{

	// Fields
	private object atlasAsset; // 0x8

	// Methods

	// RVA: 0x6C904D8
	public object .ctor(object atlasAsset) { }

	// RVA: 0x6C90974
	public object Load(object page, object path) { }

	// RVA: 0x6C90D18
	public object Unload(object texture) { }

}

// Namespace: 
protected class SavedRegionInfo
{

	// Fields
	public object x; // 0x8
	public object y; // 0xC
	public object width; // 0x10
	public object height; // 0x14
	public object packingRotation; // 0x18

	// Methods

	// RVA: 0x6C91D60
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class SpineSpriteAtlasAsset
{

	// Fields
	public object spriteAtlasFile; // 0x10
	public object materials; // 0x18
	protected object atlas; // 0x20
	public object updateRegionsInPlayMode; // 0x28
	protected object savedRegions; // 0x30

	// Properties
	public override object IsLoaded { get; }
	public override object Materials { get; }
	public override object MaterialCount { get; }
	public override object PrimaryMaterial { get; }

	// Methods

	// RVA: 0x6C90D1C
	public override object get_IsLoaded() { }

	// RVA: 0x6C90D2C
	public override object get_Materials() { }

	// RVA: 0x6C90D34
	public override object get_MaterialCount() { }

	// RVA: 0x6C90D4C
	public override object get_PrimaryMaterial() { }

	// RVA: 0x6C90D80
	public static object CreateRuntimeInstance(object spriteAtlasFile, object materials, object initialize) { }

	// RVA: 0x6C90E50
	private object Reset() { }

	// RVA: 0x6C90E90
	public override object Clear() { }

	// RVA: 0x6C90E98
	public override object GetAtlas(object onlyMetaData) { }

	// RVA: 0x6C91818
	protected object AssignRegionsFromSavedRegions(object sprites, object usedAtlas) { }

	// RVA: 0x6C911B0
	private object LoadAtlas(object spriteAtlas) { }

	// RVA: 0x6C91C78
	public static object AccessPackedTexture(object sprites) { }

	// RVA: 0x6C91CBC
	public static object AccessPackedSprites(object spriteAtlas) { }

	// RVA: 0x6C91D58
	public object .ctor() { }

}

// Namespace: 
public enum AxisOrientation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object XAxis;
	public const object YAxis;
}

// Namespace: Spine.Unity
public class BoneFollower
{

	// Fields
	public object skeletonRenderer; // 0x18
	public object boneName; // 0x20
	public object followXYPosition; // 0x28
	public object followZPosition; // 0x29
	public object followBoneRotation; // 0x2A
	public object followSkeletonFlip; // 0x2B
	public object followLocalScale; // 0x2C
	public object maintainedAxisOrientation; // 0x30
	public object initializeOnAwake; // 0x34
	public object valid; // 0x35
	public object bone; // 0x38
	private object skeletonTransform; // 0x40
	private object skeletonTransformIsParent; // 0x48

	// Properties
	public object SkeletonRenderer { get; set; }

	// Methods

	// RVA: 0x6C91D68
	public object get_SkeletonRenderer() { }

	// RVA: 0x6C91D70
	public object set_SkeletonRenderer(object value) { }

	// RVA: 0x6C91F88
	public object SetBone(object name) { }

	// RVA: 0x6C92088
	public object Awake() { }

	// RVA: 0x6C9209C
	public object HandleRebuildRenderer(object skeletonRenderer) { }

	// RVA: 0x6C91D78
	public object Initialize() { }

	// RVA: 0x6C920A0
	private object OnDestroy() { }

	// RVA: 0x6C921AC
	public object LateUpdate() { }

	// RVA: 0x6C927E0
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class BoneFollowerGraphic
{

	// Fields
	public object skeletonGraphic; // 0x18
	public object initializeOnAwake; // 0x20
	public object boneName; // 0x28
	public object followBoneRotation; // 0x30
	public object followSkeletonFlip; // 0x31
	public object followLocalScale; // 0x32
	public object followXYPosition; // 0x33
	public object followZPosition; // 0x34
	public object maintainedAxisOrientation; // 0x38
	public object bone; // 0x40
	private object skeletonTransform; // 0x48
	private object skeletonTransformIsParent; // 0x50
	public object valid; // 0x51

	// Properties
	public object SkeletonGraphic { get; set; }

	// Methods

	// RVA: 0x6C927FC
	public object get_SkeletonGraphic() { }

	// RVA: 0x6C92804
	public object set_SkeletonGraphic(object value) { }

	// RVA: 0x6C9297C
	public object SetBone(object name) { }

	// RVA: 0x6C92AB0
	public object Awake() { }

	// RVA: 0x6C9280C
	public object Initialize() { }

	// RVA: 0x6C92AD4
	public object LateUpdate() { }

	// RVA: 0x6C93234
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class BoundingBoxFollower
{

	// Fields
	internal static object DebugMessages; // 0x0
	public object skeletonRenderer; // 0x18
	public object slotName; // 0x20
	public object isTrigger; // 0x28
	public object usedByEffector; // 0x29
	public object usedByComposite; // 0x2A
	public object clearStateOnDisable; // 0x2B
	private object slot; // 0x30
	private object currentAttachment; // 0x38
	private object currentAttachmentName; // 0x40
	private object currentCollider; // 0x48
	public readonly object colliderTable; // 0x50
	public readonly object nameTable; // 0x58

	// Properties
	public object Slot { get; }
	public object CurrentAttachment { get; }
	public object CurrentAttachmentName { get; }
	public object CurrentCollider { get; }
	public object IsTrigger { get; }

	// Methods

	// RVA: 0x6C93254
	public object get_Slot() { }

	// RVA: 0x6C9325C
	public object get_CurrentAttachment() { }

	// RVA: 0x6C93264
	public object get_CurrentAttachmentName() { }

	// RVA: 0x6C9326C
	public object get_CurrentCollider() { }

	// RVA: 0x6C93274
	public object get_IsTrigger() { }

	// RVA: 0x6C9327C
	private object Start() { }

	// RVA: 0x6C93880
	private object OnEnable() { }

	// RVA: 0x6C939D4
	private object HandleRebuild(object sr) { }

	// RVA: 0x6C93284
	public object Initialize(object overwrite) { }

	// RVA: 0x6C939DC
	private object AddCollidersForSkin(object skin, object slotIndex, object previousColliders, object collidersCount) { }

	// RVA: 0x6C93FF8
	private object OnDisable() { }

	// RVA: 0x6C9412C
	public object ClearState() { }

	// RVA: 0x6C93ED0
	private object DisposeExcessCollidersAfter(object requiredCount) { }

	// RVA: 0x6C942E8
	private object LateUpdate() { }

	// RVA: 0x6C94308
	private object MatchAttachment(object attachment) { }

	// RVA: 0x6C946B0
	public object .ctor() { }

	// RVA: 0x6C94780
	private static object .cctor() { }

}

// Namespace: Spine.Unity
public class BoundingBoxFollowerGraphic
{

	// Fields
	internal static object DebugMessages; // 0x0
	public object skeletonGraphic; // 0x18
	public object slotName; // 0x20
	public object isTrigger; // 0x28
	public object usedByEffector; // 0x29
	public object usedByComposite; // 0x2A
	public object clearStateOnDisable; // 0x2B
	private object slot; // 0x30
	private object currentAttachment; // 0x38
	private object currentAttachmentName; // 0x40
	private object currentCollider; // 0x48
	public readonly object colliderTable; // 0x50
	public readonly object nameTable; // 0x58

	// Properties
	public object Slot { get; }
	public object CurrentAttachment { get; }
	public object CurrentAttachmentName { get; }
	public object CurrentCollider { get; }
	public object IsTrigger { get; }

	// Methods

	// RVA: 0x6C947D0
	public object get_Slot() { }

	// RVA: 0x6C947D8
	public object get_CurrentAttachment() { }

	// RVA: 0x6C947E0
	public object get_CurrentAttachmentName() { }

	// RVA: 0x6C947E8
	public object get_CurrentCollider() { }

	// RVA: 0x6C947F0
	public object get_IsTrigger() { }

	// RVA: 0x6C947F8
	private object Start() { }

	// RVA: 0x6C94EE0
	private object OnEnable() { }

	// RVA: 0x6C95354
	private object HandleRebuild(object sr) { }

	// RVA: 0x6C94800
	public object Initialize(object overwrite) { }

	// RVA: 0x6C95860
	private object AddCollidersForSkin(object skin, object slotIndex, object previousColliders, object scale, object collidersCount) { }

	// RVA: 0x6C95E88
	private object OnDisable() { }

	// RVA: 0x6C9601C
	public object ClearState() { }

	// RVA: 0x6C95D60
	private object DisposeExcessCollidersAfter(object requiredCount) { }

	// RVA: 0x6C96198
	private object LateUpdate() { }

	// RVA: 0x6C961B8
	private object MatchAttachment(object attachment) { }

	// RVA: 0x6C96560
	public object .ctor() { }

	// RVA: 0x6C96630
	private static object .cctor() { }

}

// Namespace: Spine.Unity
public class PointFollower
{

	// Fields
	public object skeletonRenderer; // 0x18
	public object slotName; // 0x20
	public object pointAttachmentName; // 0x28
	public object followRotation; // 0x30
	public object followSkeletonFlip; // 0x31
	public object followSkeletonZPosition; // 0x32
	private object skeletonTransform; // 0x38
	private object skeletonTransformIsParent; // 0x40
	private object point; // 0x48
	private object bone; // 0x50
	private object valid; // 0x58

	// Properties
	public object SkeletonRenderer { get; }
	public object SkeletonComponent { get; }
	public object IsValid { get; }

	// Methods

	// RVA: 0x6C96680
	public object get_SkeletonRenderer() { }

	// RVA: 0x6C96688
	public object get_SkeletonComponent() { }

	// RVA: 0x6C96690
	public object get_IsValid() { }

	// RVA: 0x6C96698
	public object Initialize() { }

	// RVA: 0x6C96980
	private object HandleRebuildRenderer(object skeletonRenderer) { }

	// RVA: 0x6C96768
	private object UpdateReferences() { }

	// RVA: 0x6C96A50
	private object OnDestroy() { }

	// RVA: 0x6C96B5C
	public object LateUpdate() { }

	// RVA: 0x6C96F40
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class SkeletonSubmeshGraphic
{

	// Methods

	// RVA: 0x6C96F50
	public override object SetMaterialDirty() { }

	// RVA: 0x6C96F54
	public override object SetVerticesDirty() { }

	// RVA: 0x6C96F58
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x6C96F7C
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class SkeletonMecanimRootMotion
{

	// Fields
	private const object DefaultMecanimLayerFlags;
	public object mecanimLayerFlags; // 0x88
	protected object movementDelta; // 0x8C
	private object skeletonMecanim; // 0x98

	// Properties
	public object SkeletonMecanim { get; }

	// Methods

	// RVA: 0x6C96F84
	public object get_SkeletonMecanim() { }

	// RVA: 0x6C97094
	public override object GetRemainingRootMotion(object layerIndex) { }

	// RVA: 0x6C9747C
	public override object GetRootMotionInfo(object layerIndex) { }

	// RVA: 0x6C97670
	protected override object Reset() { }

	// RVA: 0x6C9769C
	protected override object Start() { }

	// RVA: 0x6C97D94
	private object OnClipApplied(object animation, object layerIndex, object weight, object time, object lastTime, object playsBackward) { }

	// RVA: 0x6C97EE0
	protected override object CalculateAnimationsMovementDelta() { }

	// RVA: 0x6C97F50
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class SkeletonRootMotion
{

	// Fields
	private const object DefaultAnimationTrackFlags;
	public object animationTrackFlags; // 0x88
	private object animationState; // 0x90
	private object canvas; // 0x98

	// Properties
	protected override object AdditionalScale { get; }

	// Methods

	// RVA: 0x6C98048
	public override object GetRemainingRootMotion(object trackIndex) { }

	// RVA: 0x6C98160
	public override object GetRootMotionInfo(object trackIndex) { }

	// RVA: 0x6C981DC
	protected override object get_AdditionalScale() { }

	// RVA: 0x6C982E0
	protected override object Reset() { }

	// RVA: 0x6C98308
	protected override object Start() { }

	// RVA: 0x6C984A4
	protected override object CalculateAnimationsMovementDelta() { }

	// RVA: 0x6C987CC
	private object ApplyMixAlphaToDelta(object currentDelta, object next, object track) { }

	// RVA: 0x6C9888C
	public object .ctor() { }

}

// Namespace: 
public struct RootMotionInfo
{

	// Fields
	public object start; // 0xFFFFFFFFFFFFFFF8
	public object current; // 0x0
	public object mid; // 0x8
	public object end; // 0x10
	public object timeIsPastMid; // 0x18
}

// Namespace: Spine.Unity
public abstract class SkeletonRootMotionBase
{

	// Fields
	protected object rootMotionBoneName; // 0x18
	public object transformPositionX; // 0x20
	public object transformPositionY; // 0x21
	public object rootMotionScaleX; // 0x24
	public object rootMotionScaleY; // 0x28
	public object rootMotionTranslateXPerY; // 0x2C
	public object rootMotionTranslateYPerX; // 0x30
	public object rigidBody2D; // 0x38
	public object applyRigidbody2DGravity; // 0x40
	public object rigidBody; // 0x48
	protected object skeletonComponent; // 0x50
	protected object rootMotionBone; // 0x58
	protected object rootMotionBoneIndex; // 0x60
	protected object topLevelBones; // 0x68
	protected object initialOffset; // 0x70
	protected object tempSkeletonDisplacement; // 0x78
	protected object rigidbodyDisplacement; // 0x80

	// Properties
	public object UsesRigidbody { get; }
	protected virtual object AdditionalScale { get; }

	// Methods

	// RVA: 0x6C98898
	public object get_UsesRigidbody() { }

	// RVA: 0x6C97698
	protected virtual object Reset() { }

	// RVA: 0x6C97928
	protected virtual object Start() { }

	// RVA: 0x6C99144
	protected virtual object FixedUpdate() { }

	// RVA: 0x6C99798
	protected virtual object OnDisable() { }

	// RVA: 0x6C98964
	protected object FindRigidbodyComponent() { }

	// RVA: 0x6C997FC
	protected virtual object get_AdditionalScale() { }

	// RVA: -1
	protected abstract object CalculateAnimationsMovementDelta() { }

	// RVA: -1
	public abstract object GetRemainingRootMotion(object trackIndex) { }

	// RVA: -1
	public abstract object GetRootMotionInfo(object trackIndex) { }

	// RVA: 0x6C98F78
	public object SetRootMotionBone(object name) { }

	// RVA: 0x6C99804
	public object AdjustRootMotionToDistance(object distanceToTarget, object trackIndex, object adjustX, object adjustY, object minX, object maxX, object minY, object maxY, object allowXTranslation, object allowYTranslation) { }

	// RVA: 0x6C99AF8
	public object GetAnimationRootMotion(object animation) { }

	// RVA: 0x6C973E4
	public object GetAnimationRootMotion(object startTime, object endTime, object animation) { }

	// RVA: 0x6C97538
	public object GetAnimationRootMotionInfo(object animation, object currentTime) { }

	// RVA: 0x6C99B9C
	private object GetTimelineMovementDelta(object startTime, object endTime, object timeline, object animation) { }

	// RVA: 0x6C98C38
	private object GatherTopLevelBones() { }

	// RVA: 0x6C99CF8
	private object HandleUpdateLocal(object animatedSkeletonComponent) { }

	// RVA: 0x6C99E40
	private object ApplyRootMotion(object skeletonDelta, object parentBoneScale) { }

	// RVA: 0x6C99AD8
	private object GetScaleAffectingRootMotion() { }

	// RVA: 0x6C994F4
	private object GetScaleAffectingRootMotion(object parentBoneScale) { }

	// RVA: 0x6C99DCC
	private object GetSkeletonSpaceMovementDelta(object boneLocalDelta, object parentBoneScale) { }

	// RVA: 0x6C9A058
	private object SetEffectiveBoneOffsetsTo(object displacementSkeletonSpace, object parentBoneScale) { }

	// RVA: 0x6C99720
	private object ClearEffectiveBoneOffsets(object parentBoneScale) { }

	// RVA: 0x6C97F5C
	protected object .ctor() { }

}

// Namespace: Spine.Unity
public class SkeletonAnimation
{

	// Fields
	public object state; // 0xF0
	private object wasUpdatedAfterInit; // 0xF8
	private object _BeforeApply; // 0x100
	private object _UpdateLocal; // 0x108
	private object _UpdateWorld; // 0x110
	private object _UpdateComplete; // 0x118
	private object _animationName; // 0x120
	public object loop; // 0x128
	public object timeScale; // 0x12C

	// Properties
	public object AnimationState { get; }
	public object AnimationName { get; set; }

	// Methods

	// RVA: 0x6C9A4B0
	public object get_AnimationState() { }

	// RVA: 0x6C9A500
	protected object add__BeforeApply(object value) { }

	// RVA: 0x6C9A5A4
	protected object remove__BeforeApply(object value) { }

	// RVA: 0x6C9A648
	protected object add__UpdateLocal(object value) { }

	// RVA: 0x6C9A6EC
	protected object remove__UpdateLocal(object value) { }

	// RVA: 0x6C9A790
	protected object add__UpdateWorld(object value) { }

	// RVA: 0x6C9A834
	protected object remove__UpdateWorld(object value) { }

	// RVA: 0x6C9A8D8
	protected object add__UpdateComplete(object value) { }

	// RVA: 0x6C9A97C
	protected object remove__UpdateComplete(object value) { }

	// RVA: 0x6C9AA20
	public object add_BeforeApply(object value) { }

	// RVA: 0x6C9AAC4
	public object remove_BeforeApply(object value) { }

	// RVA: 0x6C9AB68
	public object add_UpdateLocal(object value) { }

	// RVA: 0x6C9AC0C
	public object remove_UpdateLocal(object value) { }

	// RVA: 0x6C9ACB0
	public object add_UpdateWorld(object value) { }

	// RVA: 0x6C9AD54
	public object remove_UpdateWorld(object value) { }

	// RVA: 0x6C9ADF8
	public object add_UpdateComplete(object value) { }

	// RVA: 0x6C9AE9C
	public object remove_UpdateComplete(object value) { }

	// RVA: 0x6C9AF40
	public object get_AnimationName() { }

	// RVA: 0x6C9AFA0
	public object set_AnimationName(object value) { }

	// RVA: 0x6C9B0E0
	public static object AddToGameObject(object gameObject, object skeletonDataAsset, object quiet) { }

	// RVA: 0x6C9B170
	public static object NewSkeletonAnimationGameObject(object skeletonDataAsset, object quiet) { }

	// RVA: 0x6C9B1F0
	public override object ClearState() { }

	// RVA: 0x6C9B22C
	public override object Initialize(object overwrite, object quiet) { }

	// RVA: 0x6C9B37C
	private object Update() { }

	// RVA: 0x6C9B3A4
	public object Update(object deltaTime) { }

	// RVA: 0x6C9B494
	protected object UpdateAnimationStatus(object deltaTime) { }

	// RVA: 0x6C9B4FC
	protected object ApplyAnimation() { }

	// RVA: 0x6C9B620
	public override object LateUpdate() { }

	// RVA: 0x6C9B654
	public override object OnBecameVisible() { }

	// RVA: 0x6C9B6CC
	public object .ctor() { }

}

// Namespace: 
public sealed class SkeletonRendererDelegate
{

	// Methods

	// RVA: 0x6C950F0
	public object .ctor(object object, object method) { }

	// RVA: 0x6CA06B8
	public virtual object Invoke(object skeletonGraphic) { }

	// RVA: 0x6CA06CC
	public virtual object BeginInvoke(object skeletonGraphic, object callback, object object) { }

	// RVA: 0x6CA071C
	public virtual object EndInvoke(object result) { }

}

// Namespace: Spine.Unity
public class SkeletonGraphic
{

	// Fields
	public object skeletonDataAsset; // 0xD0
	public object additiveMaterial; // 0xD8
	public object multiplyMaterial; // 0xE0
	public object screenMaterial; // 0xE8
	public object initialSkinName; // 0xF0
	public object initialFlipX; // 0xF8
	public object initialFlipY; // 0xF9
	public object startingAnimation; // 0x100
	public object startingLoop; // 0x108
	public object timeScale; // 0x10C
	public object freeze; // 0x110
	protected object updateMode; // 0x114
	public object updateWhenInvisible; // 0x118
	public object unscaledTime; // 0x11C
	public object allowMultipleCanvasRenderers; // 0x11D
	public object canvasRenderers; // 0x120
	protected object submeshGraphics; // 0x128
	protected object usedRenderersCount; // 0x130
	public const object SeparatorPartGameObjectName;
	protected object separatorSlotNames; // 0x138
	public readonly object separatorSlots; // 0x140
	public object enableSeparatorSlots; // 0x148
	protected object separatorParts; // 0x150
	public object updateSeparatorPartLocation; // 0x158
	private object wasUpdatedAfterInit; // 0x159
	private object baseTexture; // 0x160
	private readonly object customTextureOverride; // 0x168
	private readonly object customMaterialOverride; // 0x170
	private object overrideTexture; // 0x178
	protected object skeleton; // 0x180
	private object OnRebuild; // 0x188
	private object OnMeshAndMaterialsUpdated; // 0x190
	protected object state; // 0x198
	protected object meshGenerator; // 0x1A0
	private object meshBuffers; // 0x1A8
	private object currentInstructions; // 0x1B0
	private readonly object meshes; // 0x1B8
	private object BeforeApply; // 0x1C0
	private object UpdateLocal; // 0x1C8
	private object UpdateWorld; // 0x1D0
	private object UpdateComplete; // 0x1D8
	private object OnPostProcessVertices; // 0x1E0

	// Properties
	public object SkeletonDataAsset { get; }
	public object UpdateMode { get; set; }
	public object SeparatorParts { get; }
	public object CustomTextureOverride { get; }
	public object CustomMaterialOverride { get; }
	public object OverrideTexture { get; set; }
	public override object mainTexture { get; }
	public object Skeleton { get; set; }
	public object SkeletonData { get; }
	public object IsValid { get; }
	public object AnimationState { get; }
	public object MeshGenerator { get; }

	// Methods

	// RVA: 0x6C9B758
	public object get_SkeletonDataAsset() { }

	// RVA: 0x6C9B760
	public object get_UpdateMode() { }

	// RVA: 0x6C9B768
	public object set_UpdateMode(object value) { }

	// RVA: 0x6C9B770
	public object get_SeparatorParts() { }

	// RVA: 0x6C9B778
	public static object NewSkeletonGraphicGameObject(object skeletonDataAsset, object parent, object material) { }

	// RVA: 0x6C9B8AC
	public static object AddSkeletonGraphicComponent(object gameObject, object skeletonDataAsset, object material) { }

	// RVA: 0x6C9B9D4
	public object get_CustomTextureOverride() { }

	// RVA: 0x6C9B9DC
	public object get_CustomMaterialOverride() { }

	// RVA: 0x6C9B9E4
	public object get_OverrideTexture() { }

	// RVA: 0x6C9B9EC
	public object set_OverrideTexture(object value) { }

	// RVA: 0x6C9BA5C
	public override object get_mainTexture() { }

	// RVA: 0x6C9BAE0
	protected override object Awake() { }

	// RVA: 0x6C9BF90
	protected override object OnDestroy() { }

	// RVA: 0x6C9C098
	public override object Rebuild(object update) { }

	// RVA: 0x6C9C1E8
	protected override object OnDisable() { }

	// RVA: 0x6C9C384
	public virtual object Update() { }

	// RVA: 0x6C9C40C
	public virtual object Update(object deltaTime) { }

	// RVA: 0x6C9BBF4
	protected object SyncSubmeshGraphicsWithCanvasRenderers() { }

	// RVA: 0x6C9C4C4
	protected object UpdateAnimationStatus(object deltaTime) { }

	// RVA: 0x6C9C52C
	protected object ApplyAnimation() { }

	// RVA: 0x6C9C650
	public object LateUpdate() { }

	// RVA: 0x6C9C6C8
	protected object OnCullStateChanged(object culled) { }

	// RVA: 0x6C9C6F0
	public object OnBecameVisible() { }

	// RVA: 0x6C9C6E4
	public object OnBecameInvisible() { }

	// RVA: 0x6C9C6FC
	public object ReapplySeparatorSlotNames() { }

	// RVA: 0x6C92A88
	public object get_Skeleton() { }

	// RVA: 0x6C9CBDC
	public object set_Skeleton(object value) { }

	// RVA: 0x6C9CBE4
	public object get_SkeletonData() { }

	// RVA: 0x6C92AC4
	public object get_IsValid() { }

	// RVA: 0x6C952B0
	public object add_OnRebuild(object value) { }

	// RVA: 0x6C9520C
	public object remove_OnRebuild(object value) { }

	// RVA: 0x6C9CBFC
	public object add_OnMeshAndMaterialsUpdated(object value) { }

	// RVA: 0x6C9CCA0
	public object remove_OnMeshAndMaterialsUpdated(object value) { }

	// RVA: 0x6C9CD44
	public object get_AnimationState() { }

	// RVA: 0x6C9CD6C
	public object get_MeshGenerator() { }

	// RVA: 0x6C9CD74
	public object GetLastMesh() { }

	// RVA: 0x6C9CDE8
	public object MatchRectTransformWithBounds() { }

	// RVA: 0x6C9CE60
	protected object MatchRectTransformSingleRenderer() { }

	// RVA: 0x6C9D030
	protected object MatchRectTransformMultipleRenderers() { }

	// RVA: 0x6C9D36C
	private object SetRectTransformBounds(object combinedBounds) { }

	// RVA: 0x6C9D5F0
	public object add_BeforeApply(object value) { }

	// RVA: 0x6C9D694
	public object remove_BeforeApply(object value) { }

	// RVA: 0x6C9D738
	public object add_UpdateLocal(object value) { }

	// RVA: 0x6C9D7DC
	public object remove_UpdateLocal(object value) { }

	// RVA: 0x6C9D880
	public object add_UpdateWorld(object value) { }

	// RVA: 0x6C9D924
	public object remove_UpdateWorld(object value) { }

	// RVA: 0x6C9D9C8
	public object add_UpdateComplete(object value) { }

	// RVA: 0x6C9DA6C
	public object remove_UpdateComplete(object value) { }

	// RVA: 0x6C9DB10
	public object add_OnPostProcessVertices(object value) { }

	// RVA: 0x6C9DBB4
	public object remove_OnPostProcessVertices(object value) { }

	// RVA: 0x6C9BFB8
	public object Clear() { }

	// RVA: 0x6C9DE9C
	public object TrimRenderers() { }

	// RVA: 0x6C9535C
	public object Initialize(object overwrite) { }

	// RVA: 0x6C9C134
	public object UpdateMesh(object keepRendererCount) { }

	// RVA: 0x6C9F63C
	public object HasMultipleSubmeshInstructions() { }

	// RVA: 0x6C9E230
	protected object InitMeshBuffers() { }

	// RVA: 0x6C9DDF8
	protected object DisposeMeshBuffers() { }

	// RVA: 0x6C9E318
	protected object UpdateMeshSingleCanvasRenderer() { }

	// RVA: 0x6C9E85C
	protected object UpdateMeshMultipleCanvasRenderers(object currentInstructions, object keepRendererCount) { }

	// RVA: 0x6C9F7C4
	protected object EnsureCanvasRendererCount(object targetCount) { }

	// RVA: 0x6C9F6C4
	protected object DisableUnusedCanvasRenderers(object usedCount) { }

	// RVA: 0x6C9FC94
	protected object EnsureMeshesCount(object targetCount) { }

	// RVA: 0x6C9DC58
	protected object DestroyMeshes() { }

	// RVA: 0x6C9FD58
	protected object EnsureSeparatorPartCount() { }

	// RVA: 0x6C9C938
	protected object UpdateSeparatorPartParents() { }

	// RVA: 0x6CA0130
	public object .ctor() { }

}

// Namespace: 
public sealed class OnClipAppliedDelegate
{

	// Methods

	// RVA: 0x6C97B40
	public object .ctor(object object, object method) { }

	// RVA: 0x6CA44B0
	public virtual object Invoke(object clip, object layerIndex, object weight, object time, object lastTime, object playsBackward) { }

	// RVA: 0x6CA44C4
	public virtual object BeginInvoke(object clip, object layerIndex, object weight, object time, object lastTime, object playsBackward, object callback, object object) { }

	// RVA: 0x6CA4604
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public enum MixMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AlwaysMix;
	public const object MixNext;
	public const object Hard;
}

// Namespace: 
protected class ClipInfos
{

	// Fields
	public object isInterruptionActive; // 0x8
	public object isLastFrameOfInterruption; // 0x9
	public object clipInfoCount; // 0xC
	public object nextClipInfoCount; // 0x10
	public object interruptingClipInfoCount; // 0x14
	public readonly object clipInfos; // 0x18
	public readonly object nextClipInfos; // 0x20
	public readonly object interruptingClipInfos; // 0x28
	public object stateInfo; // 0x30
	public object nextStateInfo; // 0x54
	public object interruptingStateInfo; // 0x78
	public object interruptingClipTimeAddition; // 0x9C

	// Methods

	// RVA: 0x6CA4610
	public object .ctor() { }

}

// Namespace: 
private class AnimationClipEqualityComparer
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Methods

	// RVA: 0x6CA46C0
	public object Equals(object x, object y) { }

	// RVA: 0x6CA4720
	public object GetHashCode(object o) { }

	// RVA: 0x6CA4744
	public object .ctor() { }

	// RVA: 0x6CA474C
	private static object .cctor() { }

}

// Namespace: 
private class IntEqualityComparer
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Methods

	// RVA: 0x6CA47AC
	public object Equals(object x, object y) { }

	// RVA: 0x6CA47B8
	public object GetHashCode(object o) { }

	// RVA: 0x6CA47C0
	public object .ctor() { }

	// RVA: 0x6CA47C8
	private static object .cctor() { }

}

// Namespace: 
public class MecanimTranslator
{

	// Fields
	private const object WeightEpsilon;
	public object autoReset; // 0x8
	public object useCustomMixMode; // 0x9
	public object layerMixModes; // 0x10
	public object layerBlendModes; // 0x18
	private object _OnClipApplied; // 0x20
	private readonly object animationTable; // 0x28
	private readonly object clipNameHashCodeTable; // 0x30
	private readonly object previousAnimations; // 0x38
	protected object layerClipInfos; // 0x40
	private object animator; // 0x48

	// Properties
	public object Animator { get; }
	public object MecanimLayerCount { get; }
	public object MecanimLayerNames { get; }

	// Methods

	// RVA: 0x6CA2C88
	protected object add__OnClipApplied(object value) { }

	// RVA: 0x6CA2D2C
	protected object remove__OnClipApplied(object value) { }

	// RVA: 0x6C97CF0
	public object add_OnClipApplied(object value) { }

	// RVA: 0x6C97C4C
	public object remove_OnClipApplied(object value) { }

	// RVA: 0x6CA2DD0
	public object get_Animator() { }

	// RVA: 0x6CA2DD8
	public object get_MecanimLayerCount() { }

	// RVA: 0x6CA2EDC
	public object get_MecanimLayerNames() { }

	// RVA: 0x6CA1460
	public object Initialize(object animator, object skeletonDataAsset) { }

	// RVA: 0x6CA3284
	private object ApplyAnimation(object skeleton, object info, object stateInfo, object layerIndex, object layerWeight, object layerBlendMode, object useClipWeight1) { }

	// RVA: 0x6CA3774
	private object ApplyInterruptionAnimation(object skeleton, object interpolateWeightTo1, object info, object stateInfo, object layerIndex, object layerWeight, object layerBlendMode, object interruptingClipTimeAddition, object useClipWeight1) { }

	// RVA: 0x6CA3668
	private object OnClipAppliedCallback(object clip, object stateInfo, object layerIndex, object time, object isLooping, object weight) { }

	// RVA: 0x6CA1830
	public object Apply(object skeleton) { }

	// RVA: 0x6C971CC
	public object GetActiveAnimationAndTime(object layer) { }

	// RVA: 0x6CA3614
	private static object AnimationTime(object normalizedTime, object clipLength, object loop, object reversed) { }

	// RVA: 0x6CA39A0
	private static object AnimationTime(object normalizedTime, object clipLength, object reversed) { }

	// RVA: 0x6CA39D4
	private object InitClipInfosForLayers() { }

	// RVA: 0x6CA30F8
	private object ClearClipInfosForLayers() { }

	// RVA: 0x6CA402C
	private object GetMixMode(object layer, object layerBlendMode) { }

	// RVA: 0x6CA3B64
	private object GetStateUpdatesFromAnimator(object layer) { }

	// RVA: 0x6CA3EDC
	private object GetAnimatorClipInfos(object layer, object isInterruptionActive, object clipInfoCount, object nextClipInfoCount, object interruptingClipInfoCount, object clipInfo, object nextClipInfo, object interruptingClipInfo, object shallInterpolateWeightTo1) { }

	// RVA: 0x6CA3F88
	private object GetAnimatorStateInfos(object layer, object isInterruptionActive, object stateInfo, object nextStateInfo, object interruptingStateInfo, object interruptingClipTimeAddition) { }

	// RVA: 0x6CA34BC
	private object GetAnimation(object clip) { }

	// RVA: 0x6CA126C
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class SkeletonMecanim
{

	// Fields
	protected object translator; // 0xF0
	private object wasUpdatedAfterInit; // 0xF8
	private object _BeforeApply; // 0x100
	private object _UpdateLocal; // 0x108
	private object _UpdateWorld; // 0x110
	private object _UpdateComplete; // 0x118

	// Properties
	public object Translator { get; }

	// Methods

	// RVA: 0x6CA0728
	public object get_Translator() { }

	// RVA: 0x6CA0730
	protected object add__BeforeApply(object value) { }

	// RVA: 0x6CA07D4
	protected object remove__BeforeApply(object value) { }

	// RVA: 0x6CA0878
	protected object add__UpdateLocal(object value) { }

	// RVA: 0x6CA091C
	protected object remove__UpdateLocal(object value) { }

	// RVA: 0x6CA09C0
	protected object add__UpdateWorld(object value) { }

	// RVA: 0x6CA0A64
	protected object remove__UpdateWorld(object value) { }

	// RVA: 0x6CA0B08
	protected object add__UpdateComplete(object value) { }

	// RVA: 0x6CA0BAC
	protected object remove__UpdateComplete(object value) { }

	// RVA: 0x6CA0C50
	public object add_BeforeApply(object value) { }

	// RVA: 0x6CA0CF4
	public object remove_BeforeApply(object value) { }

	// RVA: 0x6CA0D98
	public object add_UpdateLocal(object value) { }

	// RVA: 0x6CA0E3C
	public object remove_UpdateLocal(object value) { }

	// RVA: 0x6CA0EE0
	public object add_UpdateWorld(object value) { }

	// RVA: 0x6CA0F84
	public object remove_UpdateWorld(object value) { }

	// RVA: 0x6CA1028
	public object add_UpdateComplete(object value) { }

	// RVA: 0x6CA10CC
	public object remove_UpdateComplete(object value) { }

	// RVA: 0x6CA1170
	public override object Initialize(object overwrite, object quiet) { }

	// RVA: 0x6CA1724
	public object Update() { }

	// RVA: 0x6CA1748
	protected object ApplyAnimation() { }

	// RVA: 0x6CA2B20
	public override object LateUpdate() { }

	// RVA: 0x6CA2B6C
	public override object OnBecameVisible() { }

	// RVA: 0x6CA2BF0
	public object .ctor() { }

}

// Namespace: 
public sealed class FindParentCanvas
{

	// Methods

	// RVA: 0x6CADE14
	public object .ctor(object object, object method) { }

	// RVA: 0x6CADF30
	public virtual object Invoke(object transform) { }

	// RVA: 0x6CADF44
	public virtual object BeginInvoke(object transform, object callback, object object) { }

	// RVA: 0x6CADF94
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public class SpriteMaskInteractionMaterials
{

	// Fields
	public object materialsMaskDisabled; // 0x8
	public object materialsInsideMask; // 0x10
	public object materialsOutsideMask; // 0x18

	// Properties
	public object AnyMaterialCreated { get; }

	// Methods

	// RVA: 0x6CABB58
	public object get_AnyMaterialCreated() { }

	// RVA: 0x6CABBD8
	public object .ctor() { }

}

// Namespace: 
public sealed class InstructionDelegate
{

	// Methods

	// RVA: 0x6CAE278
	public object .ctor(object object, object method) { }

	// RVA: 0x6CAE394
	public virtual object Invoke(object instruction) { }

	// RVA: 0x6CAE3A8
	public virtual object BeginInvoke(object instruction, object callback, object object) { }

	// RVA: 0x6CAE3F8
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class SkeletonRendererDelegate
{

	// Methods

	// RVA: 0x6CAE6DC
	public object .ctor(object object, object method) { }

	// RVA: 0x6CAE7F8
	public virtual object Invoke(object skeletonRenderer) { }

	// RVA: 0x6CAE80C
	public virtual object BeginInvoke(object skeletonRenderer, object callback, object object) { }

	// RVA: 0x6CAE85C
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
private sealed class <>c__DisplayClass94_0
{

	// Fields
	public object startsWith; // 0x8

	// Methods

	// RVA: 0x6CAC924
	public object .ctor() { }

	// RVA: 0x6CAE868
	internal object <FindAndApplySeparatorSlots>b__0(object slotName) { }

}

// Namespace: Spine.Unity
public class SkeletonRenderer
{

	// Fields
	public object skeletonDataAsset; // 0x18
	public static object findParentCanvas; // 0x0
	private object m_canvas; // 0x20
	private readonly object <AdditionalShaderChannelFlags>k__BackingField; // 0x28
	private readonly object <Depth>k__BackingField; // 0x2C
	public object initialSkinName; // 0x30
	public object initialFlipX; // 0x38
	public object initialFlipY; // 0x39
	protected object updateMode; // 0x3C
	public object updateWhenInvisible; // 0x40
	protected object separatorSlotNames; // 0x48
	public readonly object separatorSlots; // 0x50
	public object zSpacing; // 0x58
	public object useClipping; // 0x5C
	public object immutableTriangles; // 0x5D
	public object pmaVertexColors; // 0x5E
	public object clearStateOnDisable; // 0x5F
	public object tintBlack; // 0x60
	public object singleSubmesh; // 0x61
	public object fixDrawOrder; // 0x62
	public object addNormals; // 0x63
	public object calculateTangents; // 0x64
	public object maskInteraction; // 0x68
	public object maskMaterials; // 0x70
	public static readonly object STENCIL_COMP_PARAM_ID; // 0x8
	public const object STENCIL_COMP_MASKINTERACTION_NONE;
	public const object STENCIL_COMP_MASKINTERACTION_VISIBLE_INSIDE;
	public const object STENCIL_COMP_MASKINTERACTION_VISIBLE_OUTSIDE;
	public object disableRenderingOnOverride; // 0x78
	private object generateMeshOverride; // 0x80
	private object OnPostProcessVertices; // 0x88
	private readonly object customMaterialOverride; // 0x90
	private readonly object customSlotMaterials; // 0x98
	private readonly object currentInstructions; // 0xA0
	private readonly object meshGenerator; // 0xA8
	private readonly object rendererBuffers; // 0xB0
	private object meshRenderer; // 0xB8
	private object meshFilter; // 0xC0
	public object valid; // 0xC8
	public object skeleton; // 0xD0
	private object OnRebuild; // 0xD8
	private object OnMeshAndMaterialsUpdated; // 0xE0
	private object reusedPropertyBlock; // 0xE8
	public static readonly object SUBMESH_DUMMY_PARAM_ID; // 0xC

	// Properties
	public object AdditionalShaderChannelFlags { get; }
	public object Depth { get; }
	public object UpdateMode { get; set; }
	public object CustomMaterialOverride { get; }
	public object CustomSlotMaterials { get; }
	public object Skeleton { get; }
	public object SkeletonDataAsset { get; }

	// Methods

	// RVA: 0x6CA4828
	public object get_AdditionalShaderChannelFlags() { }

	// RVA: 0x6CA4830
	public object SetDepth(object startDepth) { }

	// RVA: 0x6CA4AF8
	public object get_Depth() { }

	// RVA: 0x6CA4B00
	public object OnCanvasSizeChanged() { }

	// RVA: 0x6CA4B04
	public object SetMaterialDirty() { }

	// RVA: 0x6CA4B08
	public object SetGraphicDirty() { }

	// RVA: 0x6CA4B0C
	public object PreUpdate() { }

	// RVA: 0x6CA4B10
	private object OnTransformParentChanged() { }

	// RVA: 0x6CA4EF0
	public override object OnCanvasHierarchyChanged() { }

	// RVA: 0x6CA4A30
	private object SetSortingOrder(object sortingOrder) { }

	// RVA: 0x6CA4C0C
	private object SetCanvas(object canvas) { }

	// RVA: 0x6CA4FEC
	public object get_UpdateMode() { }

	// RVA: 0x6CA4FF4
	public object set_UpdateMode(object value) { }

	// RVA: 0x6CA4FFC
	private object add_generateMeshOverride(object value) { }

	// RVA: 0x6CA50A0
	private object remove_generateMeshOverride(object value) { }

	// RVA: 0x6CA5144
	public object add_GenerateMeshOverride(object value) { }

	// RVA: 0x6CA530C
	public object remove_GenerateMeshOverride(object value) { }

	// RVA: 0x6CA54C4
	public object add_OnPostProcessVertices(object value) { }

	// RVA: 0x6CA5568
	public object remove_OnPostProcessVertices(object value) { }

	// RVA: 0x6CA560C
	public object get_CustomMaterialOverride() { }

	// RVA: 0x6CA5614
	public object get_CustomSlotMaterials() { }

	// RVA: 0x6CA561C
	public object get_Skeleton() { }

	// RVA: 0x6CA566C
	public object add_OnRebuild(object value) { }

	// RVA: 0x6CA5710
	public object remove_OnRebuild(object value) { }

	// RVA: 0x6CA57B4
	public object add_OnMeshAndMaterialsUpdated(object value) { }

	// RVA: 0x6CA5858
	public object remove_OnMeshAndMaterialsUpdated(object value) { }

	// RVA: 0x6CA58FC
	public object get_SkeletonDataAsset() { }

	// RVA: -1
	public static object NewSpineGameObject(object skeletonDataAsset, object quiet) { }

	// RVA: -1
	public static object AddSpineComponent(object gameObject, object skeletonDataAsset, object quiet) { }

	// RVA: 0x6CA5904
	public object SetMeshSettings(object settings) { }

	// RVA: 0x6CA595C
	public virtual object Awake() { }

	// RVA: 0x6CA59B4
	private object OnDisable() { }

	// RVA: 0x6CA5A14
	private object OnDestroy() { }

	// RVA: 0x6CA5C38
	public virtual object ClearState() { }

	// RVA: 0x6CA5DD8
	public object EnsureMeshGeneratorCapacity(object minimumVertexCount) { }

	// RVA: 0x6CA60A8
	public virtual object Initialize(object overwrite, object quiet) { }

	// RVA: 0x6CA68D4
	public virtual object LateUpdate() { }

	// RVA: 0x6CA6D10
	public virtual object LateUpdateMesh() { }

	// RVA: 0x6CAC7BC
	public virtual object OnBecameVisible() { }

	// RVA: 0x6CAC818
	public object OnBecameInvisible() { }

	// RVA: 0x6CAC824
	public object FindAndApplySeparatorSlots(object startsWith, object clearExistingSeparators, object updateStringArray) { }

	// RVA: 0x6CAC92C
	public object FindAndApplySeparatorSlots(object slotNamePredicate, object clearExistingSeparators, object updateStringArray) { }

	// RVA: 0x6CAD020
	public object ReapplySeparatorSlotNames() { }

	// RVA: 0x6CAC16C
	private object AssignSpriteMaskMaterials() { }

	// RVA: 0x6CAD200
	private object InitSpriteMaskMaterialsInsideMask() { }

	// RVA: 0x6CAD234
	private object InitSpriteMaskMaterialsOutsideMask() { }

	// RVA: 0x6CAD268
	private object InitSpriteMaskMaterialsForMaskType(object maskFunction, object materialsToFill) { }

	// RVA: 0x6CAC4D8
	private object SetMaterialSettingsToFixDrawOrder() { }

	// RVA: 0x6CAD404
	public object .ctor() { }

	// RVA: 0x6CADA7C
	private static object .cctor() { }

}

// Namespace: 
public struct AtlasMaterialOverride
{

	// Fields
	public object overrideEnabled; // 0xFFFFFFFFFFFFFFF8
	public object originalTexture; // 0x0
	public object replacementMaterial; // 0x8

	// Methods

	// RVA: 0x6CAF45C
	public object Equals(object other) { }

}

// Namespace: 
public struct AtlasTextureOverride
{

	// Fields
	public object overrideEnabled; // 0xFFFFFFFFFFFFFFF8
	public object originalTexture; // 0x0
	public object replacementTexture; // 0x8

	// Methods

	// RVA: 0x6CAF660
	public object Equals(object other) { }

}

// Namespace: Spine.Unity
public class SkeletonGraphicCustomMaterials
{

	// Fields
	public object skeletonGraphic; // 0x18
	protected object customMaterialOverrides; // 0x20
	protected object customTextureOverrides; // 0x28

	// Methods

	// RVA: 0x6CAE894
	private object SetCustomMaterialOverrides() { }

	// RVA: 0x6CAEA40
	private object RemoveCustomMaterialOverrides() { }

	// RVA: 0x6CAECA0
	private object SetCustomTextureOverrides() { }

	// RVA: 0x6CAEE4C
	private object RemoveCustomTextureOverrides() { }

	// RVA: 0x6CAF0AC
	private object OnEnable() { }

	// RVA: 0x6CAF24C
	private object OnDisable() { }

	// RVA: 0x6CAF358
	public object .ctor() { }

}

// Namespace: 
public struct SlotMaterialOverride
{

	// Fields
	public object overrideDisabled; // 0xFFFFFFFFFFFFFFF8
	public object slotName; // 0x0
	public object material; // 0x8

	// Methods

	// RVA: 0x6CB04B4
	public object Equals(object other) { }

}

// Namespace: 
public struct AtlasMaterialOverride
{

	// Fields
	public object overrideDisabled; // 0xFFFFFFFFFFFFFFF8
	public object originalMaterial; // 0x0
	public object replacementMaterial; // 0x8

	// Methods

	// RVA: 0x6CB0658
	public object Equals(object other) { }

}

// Namespace: Spine.Unity
public class SkeletonRendererCustomMaterials
{

	// Fields
	public object skeletonRenderer; // 0x18
	protected object customSlotMaterials; // 0x20
	protected object customMaterialOverrides; // 0x28

	// Methods

	// RVA: 0x6CAF828
	private object SetCustomSlotMaterials() { }

	// RVA: 0x6CAFA28
	private object RemoveCustomSlotMaterials() { }

	// RVA: 0x6CAFCD4
	private object SetCustomMaterialOverrides() { }

	// RVA: 0x6CAFE80
	private object RemoveCustomMaterialOverrides() { }

	// RVA: 0x6CB00E0
	private object OnEnable() { }

	// RVA: 0x6CB02A4
	private object OnDisable() { }

	// RVA: 0x6CB03B0
	public object .ctor() { }

}

// Namespace: 
public sealed class SkeletonPartsRendererDelegate
{

	// Methods

	// RVA: 0x6CB18E0
	public object .ctor(object object, object method) { }

	// RVA: 0x6CB19FC
	public virtual object Invoke(object skeletonPartsRenderer) { }

	// RVA: 0x6CB1A10
	public virtual object BeginInvoke(object skeletonPartsRenderer, object callback, object object) { }

	// RVA: 0x6CB1A60
	public virtual object EndInvoke(object result) { }

}

// Namespace: Spine.Unity
public class SkeletonPartsRenderer
{

	// Fields
	private object meshGenerator; // 0x18
	private object meshRenderer; // 0x20
	private object meshFilter; // 0x28
	private object OnMeshAndMaterialsUpdated; // 0x30
	private object buffers; // 0x38
	private object currentInstructions; // 0x40

	// Properties
	public object MeshGenerator { get; }
	public object MeshRenderer { get; }
	public object MeshFilter { get; }

	// Methods

	// RVA: 0x6CB0820
	public object get_MeshGenerator() { }

	// RVA: 0x6CB0954
	public object get_MeshRenderer() { }

	// RVA: 0x6CB0978
	public object get_MeshFilter() { }

	// RVA: 0x6CB099C
	public object add_OnMeshAndMaterialsUpdated(object value) { }

	// RVA: 0x6CB0A40
	public object remove_OnMeshAndMaterialsUpdated(object value) { }

	// RVA: 0x6CB0844
	private object LazyIntialize() { }

	// RVA: 0x6CB0AE4
	public object ClearMesh() { }

	// RVA: 0x6CB0B20
	public object RenderParts(object instructions, object startSubmesh, object endSubmesh) { }

	// RVA: 0x6CB1348
	public object SetPropertyBlock(object block) { }

	// RVA: 0x6CB1388
	public static object NewPartsRendererGameObject(object parent, object name, object sortingOrder) { }

	// RVA: 0x6CB15A0
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class SkeletonRenderSeparator
{

	// Fields
	public const object DefaultSortingOrderIncrement;
	protected object skeletonRenderer; // 0x18
	private object mainMeshRenderer; // 0x20
	public object copyPropertyBlock; // 0x28
	public object copyMeshRendererFlags; // 0x29
	public object partsRenderers; // 0x30
	private object OnMeshAndMaterialsUpdated; // 0x38
	private object copiedBlock; // 0x40

	// Properties
	public object SkeletonRenderer { get; set; }

	// Methods

	// RVA: 0x6CB1A6C
	public object get_SkeletonRenderer() { }

	// RVA: 0x6CB1A74
	public object set_SkeletonRenderer(object value) { }

	// RVA: 0x6CB1BE4
	public object add_OnMeshAndMaterialsUpdated(object value) { }

	// RVA: 0x6CB1C88
	public object remove_OnMeshAndMaterialsUpdated(object value) { }

	// RVA: 0x6CB1D2C
	public static object AddToSkeletonRenderer(object skeletonRenderer, object sortingLayerID, object extraPartsRenderers, object sortingOrderIncrement, object baseSortingOrder, object addMinimumPartsRenderers) { }

	// RVA: 0x6CB249C
	public object AddPartsRenderer(object sortingOrderIncrement, object name) { }

	// RVA: 0x6CB20DC
	public object OnEnable() { }

	// RVA: 0x6CB2724
	public object OnDisable() { }

	// RVA: 0x6CB2A30
	private object HandleRender(object instruction) { }

	// RVA: 0x6CB2E80
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class ActivateBasedOnFlipDirection
{

	// Fields
	public object skeletonRenderer; // 0x18
	public object skeletonGraphic; // 0x20
	public object activeOnNormalX; // 0x28
	public object activeOnFlippedX; // 0x30
	private object jointsNormalX; // 0x38
	private object jointsFlippedX; // 0x40
	private object skeletonComponent; // 0x48
	private object wasFlippedXBefore; // 0x50

	// Methods

	// RVA: 0x6CB2F08
	private object Start() { }

	// RVA: 0x6CB2FE4
	private object FixedUpdate() { }

	// RVA: 0x6CB3100
	private object HandleFlip(object isFlippedX) { }

	// RVA: 0x6CB31DC
	private object ResetJointPositions(object joints) { }

	// RVA: 0x6CB32D0
	private object CompensateMovementAfterFlipX(object toActivate, object toDeactivate) { }

	// RVA: 0x6CB33D0
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class FollowLocationRigidbody
{

	// Fields
	public object reference; // 0x18
	private object ownRigidbody; // 0x20

	// Methods

	// RVA: 0x6CB33D8
	private object Awake() { }

	// RVA: 0x6CB3434
	private object FixedUpdate() { }

	// RVA: 0x6CB34C4
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class FollowLocationRigidbody2D
{

	// Fields
	public object reference; // 0x18
	public object followFlippedX; // 0x20
	private object ownRigidbody; // 0x28

	// Methods

	// RVA: 0x6CB34CC
	private object Awake() { }

	// RVA: 0x6CB3528
	private object FixedUpdate() { }

	// RVA: 0x6CB3668
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class FollowSkeletonUtilityRootRotation
{

	// Fields
	private const object FLIP_ANGLE_THRESHOLD;
	public object reference; // 0x18
	private object prevLocalEulerAngles; // 0x20

	// Methods

	// RVA: 0x6CB3670
	private object Start() { }

	// RVA: 0x6CB36B4
	private object FixedUpdate() { }

	// RVA: 0x6CB37F4
	private object CompensatePositionToYRotation() { }

	// RVA: 0x6CB3900
	private object CompensatePositionToXRotation() { }

	// RVA: 0x6CB3A0C
	public object .ctor() { }

}

// Namespace: 
public sealed class SkeletonUtilityDelegate
{

	// Methods

	// RVA: 0x6CB8038
	public object .ctor(object object, object method) { }

	// RVA: 0x6CB80CC
	public virtual object Invoke() { }

	// RVA: 0x6CB80E0
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0x6CB8138
	public virtual object EndInvoke(object result) { }

}

// Namespace: Spine.Unity
public sealed class SkeletonUtility
{

	// Fields
	private object OnReset; // 0x18
	public object boneRoot; // 0x20
	public object flipBy180DegreeRotation; // 0x28
	public object skeletonRenderer; // 0x30
	public object skeletonGraphic; // 0x38
	private object canvas; // 0x40
	public object skeletonAnimation; // 0x48
	private object skeletonComponent; // 0x50
	public object boneComponents; // 0x58
	public object constraintComponents; // 0x60
	private object positionScale; // 0x68
	private object hasOverrideBones; // 0x6C
	private object hasConstraints; // 0x6D
	private object needToReprocessBones; // 0x6E

	// Properties
	public object SkeletonComponent { get; }
	public object Skeleton { get; }
	public object IsValid { get; }
	public object PositionScale { get; }

	// Methods

	// RVA: 0x6CB3A14
	public static object AddBoundingBoxGameObject(object skeleton, object skinName, object slotName, object attachmentName, object parent, object isTrigger) { }

	// RVA: 0x6CB3D8C
	public static object AddBoundingBoxGameObject(object name, object box, object slot, object parent, object isTrigger) { }

	// RVA: 0x6CB3FCC
	public static object AddBoundingBoxAsComponent(object box, object slot, object gameObject, object isTrigger) { }

	// RVA: 0x6CB40A0
	public static object SetColliderPointsLocal(object collider, object slot, object box, object scale) { }

	// RVA: 0x6CB424C
	public static object GetBoundingBoxBounds(object boundingBox, object depth) { }

	// RVA: 0x6CB4320
	public static object AddBoneRigidbody2D(object gameObject, object isKinematic, object gravityScale) { }

	// RVA: 0x6CB4454
	public object add_OnReset(object value) { }

	// RVA: 0x6CB44F8
	public object remove_OnReset(object value) { }

	// RVA: 0x6CB459C
	private object Update() { }

	// RVA: 0x6CB4838
	public object get_SkeletonComponent() { }

	// RVA: 0x6CB4950
	public object get_Skeleton() { }

	// RVA: 0x6CB4A50
	public object get_IsValid() { }

	// RVA: 0x6CB4B80
	public object get_PositionScale() { }

	// RVA: 0x6CB4B88
	public object ResubscribeEvents() { }

	// RVA: 0x6CB5028
	private object OnEnable() { }

	// RVA: 0x6CB6234
	private object Start() { }

	// RVA: 0x6CB4BAC
	private object OnDisable() { }

	// RVA: 0x6CB6238
	private object HandleRendererReset(object r) { }

	// RVA: 0x6CB6274
	private object HandleRendererReset(object g) { }

	// RVA: 0x6CB62B0
	public object RegisterBone(object bone) { }

	// RVA: 0x6CB63FC
	public object UnregisterBone(object bone) { }

	// RVA: 0x6CB6468
	public object RegisterConstraint(object constraint) { }

	// RVA: 0x6CB65B4
	public object UnregisterConstraint(object constraint) { }

	// RVA: 0x6CB58F4
	public object CollectBones() { }

	// RVA: 0x6CB7000
	private object UpdateLocal(object anim) { }

	// RVA: 0x6CB7214
	private object UpdateWorld(object anim) { }

	// RVA: 0x6CB7314
	private object UpdateComplete(object anim) { }

	// RVA: 0x6CB70EC
	private object UpdateAllBones(object phase) { }

	// RVA: 0x6CB731C
	public object GetBoneRoot() { }

	// RVA: 0x6CB75CC
	public object SpawnRoot(object mode, object pos, object rot, object sca) { }

	// RVA: 0x6CB79B0
	public object SpawnHierarchy(object mode, object pos, object rot, object sca) { }

	// RVA: 0x6CB7B00
	public object SpawnBoneRecursively(object bone, object parent, object mode, object pos, object rot, object sca) { }

	// RVA: 0x6CB771C
	public object SpawnBone(object bone, object parent, object mode, object pos, object rot, object sca) { }

	// RVA: 0x6CB7F10
	public object .ctor() { }

}

// Namespace: 
public enum Mode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Follow;
	public const object Override;
}

// Namespace: 
public enum UpdatePhase
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Local;
	public const object World;
	public const object Complete;
}

// Namespace: Spine.Unity
public class SkeletonUtilityBone
{

	// Fields
	public object boneName; // 0x18
	public object parentReference; // 0x20
	public object mode; // 0x28
	public object position; // 0x2C
	public object rotation; // 0x2D
	public object scale; // 0x2E
	public object zPosition; // 0x2F
	public object overrideAlpha; // 0x30
	public object hierarchy; // 0x38
	public object bone; // 0x40
	public object transformLerpComplete; // 0x48
	public object valid; // 0x49
	private object cachedTransform; // 0x50
	private object skeletonTransform; // 0x58
	private object incompatibleTransformMode; // 0x60

	// Properties
	public object IncompatibleTransformMode { get; }

	// Methods

	// RVA: 0x6CB8144
	public object get_IncompatibleTransformMode() { }

	// RVA: 0x6CB7C14
	public object Reset() { }

	// RVA: 0x6CB814C
	private object OnEnable() { }

	// RVA: 0x6CB83A4
	private object HandleOnReset() { }

	// RVA: 0x6CB83A8
	private object OnDisable() { }

	// RVA: 0x6CB6620
	public object DoUpdate(object phase) { }

	// RVA: 0x6CB85C8
	public static object BoneTransformModeIncompatible(object bone) { }

	// RVA: 0x6CB860C
	public object AddBoundingBox(object skinName, object slotName, object attachmentName) { }

	// RVA: 0x6CB86AC
	public object .ctor() { }

}

// Namespace: Spine.Unity
public abstract class SkeletonUtilityConstraint
{

	// Fields
	protected object bone; // 0x18
	protected object hierarchy; // 0x20

	// Methods

	// RVA: 0x6CB86C4
	protected virtual object OnEnable() { }

	// RVA: 0x6CB8770
	protected virtual object OnDisable() { }

	// RVA: -1
	public abstract object DoUpdate() { }

	// RVA: 0x6CB87E0
	protected object .ctor() { }

}

// Namespace: Spine.Unity
public enum UpdateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Nothing;
	public const object OnlyAnimationStatus;
	public const object OnlyEventTimelines;
	public const object EverythingExceptMesh;
	public const object FullUpdate;
}

// Namespace: Spine.Unity
public sealed class UpdateBonesDelegate
{

	// Methods

	// RVA: 0x6CB57D8
	public object .ctor(object object, object method) { }

	// RVA: 0x6CB8AC0
	public virtual object Invoke(object animated) { }

	// RVA: 0x6CB8AD4
	public virtual object BeginInvoke(object animated, object callback, object object) { }

	// RVA: 0x6CB8B24
	public virtual object EndInvoke(object result) { }

}

// Namespace: Spine.Unity
public interface ISpineComponent
{
}

// Namespace: Spine.Unity
public static class ISpineComponentExtensions
{

	// Methods

	// RVA: 0x6CB8B30
	public static object IsNullOrDestroyed(object component) { }

}

// Namespace: Spine.Unity
public interface ISkeletonAnimation
{

	// Properties
	public abstract object Skeleton { get; }

	// Methods

	// RVA: -1
	public abstract object add_UpdateLocal(object value) { }

	// RVA: -1
	public abstract object remove_UpdateLocal(object value) { }

	// RVA: -1
	public abstract object add_UpdateWorld(object value) { }

	// RVA: -1
	public abstract object remove_UpdateWorld(object value) { }

	// RVA: -1
	public abstract object add_UpdateComplete(object value) { }

	// RVA: -1
	public abstract object remove_UpdateComplete(object value) { }

	// RVA: -1
	public abstract object get_Skeleton() { }

}

// Namespace: Spine.Unity
public interface IHasSkeletonDataAsset
{

	// Properties
	public abstract object SkeletonDataAsset { get; }

	// Methods

	// RVA: -1
	public abstract object get_SkeletonDataAsset() { }

}

// Namespace: Spine.Unity
public interface ISkeletonComponent
{

	// Properties
	public abstract object SkeletonDataAsset { get; }
	public abstract object Skeleton { get; }

	// Methods

	// RVA: -1
	public abstract object get_SkeletonDataAsset() { }

	// RVA: -1
	public abstract object get_Skeleton() { }

}

// Namespace: Spine.Unity
public interface IAnimationStateComponent
{

	// Properties
	public abstract object AnimationState { get; }

	// Methods

	// RVA: -1
	public abstract object get_AnimationState() { }

}

// Namespace: Spine.Unity
public interface IHasSkeletonRenderer
{

	// Properties
	public abstract object SkeletonRenderer { get; }

	// Methods

	// RVA: -1
	public abstract object get_SkeletonRenderer() { }

}

// Namespace: Spine.Unity
public interface IHasSkeletonComponent
{

	// Properties
	public abstract object SkeletonComponent { get; }

	// Methods

	// RVA: -1
	public abstract object get_SkeletonComponent() { }

}

// Namespace: Spine.Unity
public class DoubleBuffered<T0>
{

	// Fields
	private readonly object a; // 0x0
	private readonly object b; // 0x0
	private object usingA; // 0x0

	// Methods

	// RVA: -1
	public object GetCurrent() { }

	// RVA: -1
	public object GetNext() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Spine.Unity
public sealed class MeshGeneratorDelegate
{

	// Methods

	// RVA: 0x6CB8C80
	public object .ctor(object object, object method) { }

	// RVA: 0x6CB8D18
	public virtual object Invoke(object buffers) { }

	// RVA: 0x6CB8D58
	public virtual object BeginInvoke(object buffers, object callback, object object) { }

	// RVA: 0x6CB8E14
	public virtual object EndInvoke(object result) { }

}

// Namespace: Spine.Unity
public struct MeshGeneratorBuffers
{

	// Fields
	public object vertexCount; // 0xFFFFFFFFFFFFFFF8
	public object vertexBuffer; // 0x0
	public object uvBuffer; // 0x8
	public object colorBuffer; // 0x10
	public object meshGenerator; // 0x18
}

// Namespace: 
public struct Settings
{

	// Fields
	public object useClipping; // 0xFFFFFFFFFFFFFFF8
	public object zSpacing; // 0xFFFFFFFFFFFFFFFC
	public object pmaVertexColors; // 0x0
	public object tintBlack; // 0x1
	public object canvasGroupTintBlack; // 0x2
	public object calculateTangents; // 0x3
	public object addNormals; // 0x4
	public object immutableTriangles; // 0x5

	// Properties
	public static object Default { get; }

	// Methods

	// RVA: 0x6CB8EC0
	public static object get_Default() { }

}

// Namespace: Spine.Unity
public class MeshGenerator
{

	// Fields
	public object settings; // 0x8
	private const object BoundsMinDefault;
	private const object BoundsMaxDefault;
	protected readonly object vertexBuffer; // 0x18
	protected readonly object uvBuffer; // 0x20
	protected readonly object colorBuffer; // 0x28
	protected readonly object submeshes; // 0x30
	private object meshBoundsMin; // 0x38
	private object meshBoundsMax; // 0x40
	private object meshBoundsThickness; // 0x48
	private object submeshIndex; // 0x4C
	private object clipper; // 0x50
	private object tempVerts; // 0x58
	private object regionTriangles; // 0x60
	private object normals; // 0x68
	private object tangents; // 0x70
	private object tempTanBuffer; // 0x78
	private object uv2; // 0x80
	private object uv3; // 0x88
	private static object AttachmentVerts; // 0x0
	private static object AttachmentUVs; // 0x8
	private static object AttachmentColors32; // 0x10
	private static object AttachmentIndices; // 0x18

	// Properties
	public object VertexCount { get; }
	public object Buffers { get; }

	// Methods

	// RVA: 0x6CB1324
	public object get_VertexCount() { }

	// RVA: 0x6CB8E5C
	public object SubmeshIndexCount(object submeshIndex) { }

	// RVA: 0x6CAB178
	public object get_Buffers() { }

	// RVA: 0x6CAD724
	public object .ctor() { }

	// RVA: 0x6CA77A8
	public static object GenerateSingleSubmeshInstruction(object instructionOutput, object skeleton, object material) { }

	// RVA: 0x6CB8ECC
	public static object RequiresMultipleSubmeshesByDrawOrder(object skeleton) { }

	// RVA: 0x6CAA734
	public static object GenerateSkeletonRendererInstruction(object instructionOutput, object skeleton, object customSlotMaterials, object separatorSlots, object generateMeshOverride, object immutableTriangles) { }

	// RVA: 0x6CA7D14
	public static object TryReplaceMaterials(object workingSubmeshInstructions, object customMaterialOverride) { }

	// RVA: 0x6CA6650
	public object Begin() { }

	// RVA: 0x6CA8044
	public object AddSubmesh(object instruction, object updateTriangles) { }

	// RVA: 0x6CAB0B4
	public object BuildMesh(object instruction, object updateTriangles) { }

	// RVA: 0x6CA910C
	public object BuildMeshWithArrays(object instruction, object updateTriangles) { }

	// RVA: 0x6CB93FC
	public object ScaleVertexData(object scale) { }

	// RVA: 0x6CB952C
	public object GetMeshBounds() { }

	// RVA: 0x6CB91D4
	private object AddAttachmentTintBlack(object r2, object g2, object b2, object a, object vertexCount) { }

	// RVA: 0x6CAB1E0
	public object FillVertexData(object mesh) { }

	// RVA: 0x6CABC5C
	public object FillLateVertexData(object mesh) { }

	// RVA: 0x6CAB9C8
	public object FillTriangles(object mesh) { }

	// RVA: 0x6CA5E04
	public object EnsureVertexCapacity(object minimumVertexCount, object inlcudeTintBlack, object includeTangents, object includeNormals) { }

	// RVA: 0x6CB9994
	public object TrimExcess() { }

	// RVA: 0x6CB95B0
	internal static object SolveTangents2DEnsureSize(object tangentBuffer, object tempTanBuffer, object vertexCount, object vertexBufferLength) { }

	// RVA: 0x6CB9684
	internal static object SolveTangents2DTriangles(object tempTanBuffer, object triangles, object triangleCount, object vertices, object uvs, object vertexCount) { }

	// RVA: 0x6CB9898
	internal static object SolveTangents2DBuffer(object tangents, object tempTanBuffer, object vertexCount) { }

	// RVA: 0x6CB9B00
	public static object FillMeshLocal(object mesh, object regionAttachment) { }

	// RVA: 0x6CBA8FC
	public static object FillMeshLocal(object mesh, object meshAttachment, object skeletonData) { }

	// RVA: 0x6CBB2F4
	private static object .cctor() { }

}

// Namespace: 
public class SmartMesh
{

	// Fields
	public object mesh; // 0x8
	public object instructionUsed; // 0x10

	// Methods

	// RVA: 0x6CBB4FC
	public object Clear() { }

	// RVA: 0x6CBB548
	public object Dispose() { }

	// RVA: 0x6CBB618
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class MeshRendererBuffers
{

	// Fields
	private object doubleBufferedMesh; // 0x8
	internal readonly object submeshMaterials; // 0x10
	internal object sharedMaterials; // 0x18

	// Methods

	// RVA: 0x6CA6764
	public object Initialize() { }

	// RVA: 0x6CABAA4
	public object GetUpdatedSharedMaterialsArray() { }

	// RVA: 0x6CAB918
	public object MaterialsChangedInLastUpdate() { }

	// RVA: 0x6CAB7B4
	public object UpdateSharedMaterials(object instructions) { }

	// RVA: 0x6CA774C
	public object GetNextMesh() { }

	// RVA: 0x6CA65C4
	public object Clear() { }

	// RVA: 0x6CA5A4C
	public object Dispose() { }

	// RVA: 0x6CAD9D0
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class SkeletonRendererInstruction
{

	// Fields
	public readonly object submeshInstructions; // 0x8
	public object immutableTriangles; // 0x10
	public object hasActiveClipping; // 0x11
	public object rawVertexCount; // 0x14
	public readonly object attachments; // 0x18

	// Methods

	// RVA: 0x6CA5D38
	public object Clear() { }

	// RVA: 0x6CBB68C
	public object Dispose() { }

	// RVA: 0x6CB0F38
	public object SetWithSubset(object instructions, object startSubmesh, object endSubmesh) { }

	// RVA: 0x6CABF3C
	public object Set(object other) { }

	// RVA: 0x6CA7E20
	public static object GeometryNotEqual(object a, object b) { }

	// RVA: 0x6CAD654
	public object .ctor() { }

}

// Namespace: Spine.Unity
public static class SpineMesh
{

	// Fields
	internal const object MeshHideflags;

	// Methods

	// RVA: 0x6CBB6EC
	public static object NewSkeletonMesh() { }

}

// Namespace: Spine.Unity
public struct SubmeshInstruction
{

	// Fields
	public object skeleton; // 0xFFFFFFFFFFFFFFF8
	public object startSlot; // 0x0
	public object endSlot; // 0x4
	public object material; // 0x8
	public object forceSeparate; // 0x10
	public object preActiveClippingSlotSource; // 0x14
	public object rawTriangleCount; // 0x18
	public object rawVertexCount; // 0x1C
	public object rawFirstVertexIndex; // 0x20
	public object hasClipping; // 0x24
	public object hasPMAAdditiveSlot; // 0x25

	// Properties
	public object SlotCount { get; }

	// Methods

	// RVA: 0x6CBB7D0
	public object get_SlotCount() { }

	// RVA: 0x6CBB7E8
	public override object ToString() { }

}

// Namespace: 
private class AtlasMaterialCache
{

	// Fields
	private readonly object cache; // 0x8

	// Methods

	// RVA: 0x6CBC334
	public object CloneAtlasRegionWithMaterial(object originalRegion, object materialTemplate) { }

	// RVA: 0x6CBC3B8
	private object GetAtlasPageWithMaterial(object originalPage, object materialTemplate) { }

	// RVA: 0x6CBC658
	public object Dispose() { }

	// RVA: 0x6CBC2B4
	public object .ctor() { }

}

// Namespace: Spine.Unity
public class BlendModeMaterialsAsset
{

	// Fields
	public object multiplyMaterialTemplate; // 0x10
	public object screenMaterialTemplate; // 0x18
	public object additiveMaterialTemplate; // 0x20
	public object applyAdditiveMaterial; // 0x28

	// Methods

	// RVA: 0x6CBBA38
	public override object Apply(object skeletonData) { }

	// RVA: 0x6CBBA50
	public static object ApplyMaterials(object skeletonData, object multiplyTemplate, object screenTemplate, object additiveTemplate, object includeAdditiveSlots) { }

	// RVA: 0x6CBC3A8
	public object .ctor() { }

}

// Namespace: Spine.Unity
public abstract class SpineAttributeBase
{

	// Fields
	public object dataField; // 0x8
	public object startsWith; // 0x10
	public object includeNone; // 0x18
	public object fallbackToTextField; // 0x19

	// Methods

	// RVA: 0x6CBC6B4
	protected object .ctor() { }

}

// Namespace: Spine.Unity
public class SpineBone
{

	// Methods

	// RVA: 0x6CBC71C
	public object .ctor(object startsWith, object dataField, object includeNone, object fallbackToTextField) { }

	// RVA: 0x6CBC7B0
	public static object GetBone(object boneName, object renderer) { }

	// RVA: 0x6CBC7E4
	public static object GetBoneData(object boneName, object skeletonDataAsset) { }

}

// Namespace: Spine.Unity
public class SpineSlot
{

	// Fields
	public object containsBoundingBoxes; // 0x1A

	// Methods

	// RVA: 0x6CBC838
	public object .ctor(object startsWith, object dataField, object containsBoundingBoxes, object includeNone, object fallbackToTextField) { }

}

// Namespace: Spine.Unity
public class SpineAnimation
{

	// Methods

	// RVA: 0x6CBC8D4
	public object .ctor(object startsWith, object dataField, object includeNone, object fallbackToTextField) { }

}

// Namespace: Spine.Unity
public class SpineEvent
{

	// Fields
	public object audioOnly; // 0x1A

	// Methods

	// RVA: 0x6CBC968
	public object .ctor(object startsWith, object dataField, object includeNone, object fallbackToTextField, object audioOnly) { }

}

// Namespace: Spine.Unity
public class SpineIkConstraint
{

	// Methods

	// RVA: 0x6CBCA04
	public object .ctor(object startsWith, object dataField, object includeNone, object fallbackToTextField) { }

}

// Namespace: Spine.Unity
public class SpineTransformConstraint
{

	// Methods

	// RVA: 0x6CBCA98
	public object .ctor(object startsWith, object dataField, object includeNone, object fallbackToTextField) { }

}

// Namespace: Spine.Unity
public class SpinePathConstraint
{

	// Methods

	// RVA: 0x6CBCB2C
	public object .ctor(object startsWith, object dataField, object includeNone, object fallbackToTextField) { }

}

// Namespace: Spine.Unity
public class SpineSkin
{

	// Fields
	public object defaultAsEmptyString; // 0x1A

	// Methods

	// RVA: 0x6CBCBC0
	public object .ctor(object startsWith, object dataField, object includeNone, object fallbackToTextField, object defaultAsEmptyString) { }

}

// Namespace: 
public struct Hierarchy
{

	// Fields
	public object skin; // 0xFFFFFFFFFFFFFFF8
	public object slot; // 0x0
	public object name; // 0x8

	// Methods

	// RVA: 0x6CBCD5C
	public object .ctor(object fullPath) { }

}

// Namespace: Spine.Unity
public class SpineAttachment
{

	// Fields
	public object returnAttachmentPath; // 0x1A
	public object currentSkinOnly; // 0x1B
	public object placeholdersOnly; // 0x1C
	public object skinField; // 0x20
	public object slotField; // 0x28

	// Methods

	// RVA: 0x6CBCC5C
	public object .ctor(object currentSkinOnly, object returnAttachmentPath, object placeholdersOnly, object slotField, object dataField, object skinField, object includeNone, object fallbackToTextField) { }

	// RVA: 0x6CBCD48
	public static object GetHierarchy(object fullPath) { }

	// RVA: 0x6CBCF0C
	public static object GetAttachment(object attachmentPath, object skeletonData) { }

	// RVA: 0x6CBCFD0
	public static object GetAttachment(object attachmentPath, object skeletonDataAsset) { }

}

// Namespace: Spine.Unity
public class SpineAtlasRegion
{

	// Fields
	public object atlasAssetField; // 0x8

	// Methods

	// RVA: 0x6CBD0F8
	public object .ctor(object atlasAssetField) { }

}

// Namespace: Spine.Unity
public static class SkeletonExtensions
{

	// Fields
	private const object ByteToFloat;

	// Methods

	// RVA: 0x6CBD124
	public static object GetColor(object s) { }

	// RVA: 0x6CBD148
	public static object GetColor(object a) { }

	// RVA: 0x6CBD16C
	public static object GetColor(object a) { }

	// RVA: 0x6CBD190
	public static object GetColor(object s) { }

	// RVA: 0x6CBD1B4
	public static object GetColorTintBlack(object s) { }

	// RVA: 0x6CBD1DC
	public static object SetColor(object skeleton, object color) { }

	// RVA: 0x6CBD200
	public static object SetColor(object skeleton, object color) { }

	// RVA: 0x6CBD268
	public static object SetColor(object slot, object color) { }

	// RVA: 0x6CBD28C
	public static object SetColor(object slot, object color) { }

	// RVA: 0x6CBD2F4
	public static object SetColor(object attachment, object color) { }

	// RVA: 0x6CBD318
	public static object SetColor(object attachment, object color) { }

	// RVA: 0x6CBD380
	public static object SetColor(object attachment, object color) { }

	// RVA: 0x6CBD3A4
	public static object SetColor(object attachment, object color) { }

	// RVA: 0x6CBD40C
	public static object SetLocalScale(object skeleton, object scale) { }

	// RVA: 0x6CBD42C
	public static object GetMatrix4x4(object bone) { }

	// RVA: 0x6CBD474
	public static object SetLocalPosition(object bone, object position) { }

	// RVA: 0x6CBD494
	public static object SetLocalPosition(object bone, object position) { }

	// RVA: 0x6CBD4B4
	public static object GetLocalPosition(object bone) { }

	// RVA: 0x6CBD4D4
	public static object GetSkeletonSpacePosition(object bone) { }

	// RVA: 0x6CBD4F8
	public static object GetSkeletonSpacePosition(object bone, object boneLocal) { }

	// RVA: 0x6CBD53C
	public static object GetWorldPosition(object bone, object spineGameObjectTransform) { }

	// RVA: 0x6CBD580
	public static object GetWorldPosition(object bone, object spineGameObjectTransform, object positionScale) { }

	// RVA: 0x6CBD5CC
	public static object GetQuaternion(object bone) { }

	// RVA: 0x6CBD614
	public static object GetLocalQuaternion(object bone) { }

	// RVA: 0x6CBD664
	public static object GetLocalScale(object skeleton) { }

	// RVA: 0x6CBD6A0
	public static object GetWorldToLocalMatrix(object bone, object ia, object ib, object ic, object id) { }

	// RVA: 0x6CBD6F8
	public static object WorldToLocal(object bone, object worldPosition) { }

	// RVA: 0x6CBD73C
	public static object SetPositionSkeletonSpace(object bone, object skeletonSpacePosition) { }

	// RVA: 0x6CBD798
	public static object GetMaterial(object a) { }

	// RVA: 0x6CBD920
	public static object GetLocalVertices(object va, object slot, object buffer) { }

	// RVA: 0x6CBDC88
	public static object GetWorldVertices(object a, object slot, object buffer) { }

	// RVA: 0x6CBDE7C
	public static object GetWorldPosition(object attachment, object slot, object spineGameObjectTransform) { }

	// RVA: 0x6CBDF04
	public static object GetWorldPosition(object attachment, object bone, object spineGameObjectTransform) { }

}

// Namespace: 
public enum AnimationEventTypes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object Interrupt;
	public const object End;
	public const object Dispose;
	public const object Complete;
}

// Namespace: Spine.Unity
public class WaitForSpineAnimation
{

	// Fields
	private object m_WasFired; // 0x8

	// Properties
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6CBDF78
	public object .ctor(object trackEntry, object eventsToWaitFor) { }

	// RVA: 0x6CBE1CC
	public object NowWaitFor(object trackEntry, object eventsToWaitFor) { }

	// RVA: 0x6CBE1F0
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x6CBE2E0
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6CBE2E8
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x6CBDFB8
	protected object SafeSubscribe(object trackEntry, object eventsToWaitFor) { }

	// RVA: 0x6CBE2F0
	private object HandleComplete(object trackEntry) { }

}

// Namespace: Spine.Unity
public class WaitForSpineAnimationComplete
{

	// Methods

	// RVA: 0x6CBE2FC
	public object .ctor(object trackEntry, object includeEndEvent) { }

	// RVA: 0x6CBE348
	public object NowWaitFor(object trackEntry, object includeEndEvent) { }

}

// Namespace: Spine.Unity
public class WaitForSpineAnimationEnd
{

	// Methods

	// RVA: 0x6CBE38C
	public object .ctor(object trackEntry) { }

	// RVA: 0x6CBE3C0
	public object NowWaitFor(object trackEntry) { }

}

// Namespace: Spine.Unity
public class WaitForSpineEvent
{

	// Fields
	private object m_TargetEvent; // 0x8
	private object m_EventName; // 0x10
	private object m_AnimationState; // 0x18
	private object m_WasFired; // 0x20
	private object m_unsubscribeAfterFiring; // 0x21

	// Properties
	public object WillUnsubscribeAfterFiring { get; set; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6CBE3E8
	private object Subscribe(object state, object eventDataReference, object unsubscribe) { }

	// RVA: 0x6CBE52C
	private object SubscribeByName(object state, object eventName, object unsubscribe) { }

	// RVA: 0x6CBE678
	public object .ctor(object state, object eventDataReference, object unsubscribeAfterFiring) { }

	// RVA: 0x6CBE6C0
	public object .ctor(object skeletonAnimation, object eventDataReference, object unsubscribeAfterFiring) { }

	// RVA: 0x6CBE718
	public object .ctor(object state, object eventName, object unsubscribeAfterFiring) { }

	// RVA: 0x6CBE760
	public object .ctor(object skeletonAnimation, object eventName, object unsubscribeAfterFiring) { }

	// RVA: 0x6CBE7B8
	private object HandleAnimationStateEventByName(object trackEntry, object e) { }

	// RVA: 0x6CBE8B8
	private object HandleAnimationStateEvent(object trackEntry, object e) { }

	// RVA: 0x6CBE9A4
	public object get_WillUnsubscribeAfterFiring() { }

	// RVA: 0x6CBE9AC
	public object set_WillUnsubscribeAfterFiring(object value) { }

	// RVA: 0x6CBE9B4
	public object NowWaitFor(object state, object eventDataReference, object unsubscribeAfterFiring) { }

	// RVA: 0x6CBEB90
	public object NowWaitFor(object state, object eventName, object unsubscribeAfterFiring) { }

	// RVA: 0x6CBEAAC
	private object Clear(object state) { }

	// RVA: 0x6CBEC88
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x6CBED78
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6CBED80
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Spine.Unity
public class WaitForSpineTrackEntryEnd
{

	// Fields
	private object m_WasFired; // 0x8

	// Properties
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6CBED88
	public object .ctor(object trackEntry) { }

	// RVA: 0x6CBEEA4
	private object HandleEnd(object trackEntry) { }

	// RVA: 0x6CBEDB8
	private object SafeSubscribe(object trackEntry) { }

	// RVA: 0x6CBEEB0
	public object NowWaitFor(object trackEntry) { }

	// RVA: 0x6CBEED4
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x6CBEFC4
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6CBEFCC
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Spine.Unity.AnimationTools
public static class TimelineExtensions
{

	// Methods

	// RVA: 0x6CBEFD4
	public static object Evaluate(object timeline, object time, object skeletonData) { }

	// RVA: 0x6CBF10C
	public static object FindTranslateTimelineForBone(object a, object boneIndex) { }

}

// Namespace: 
private struct IntAndAtlasRegionKey
{

	// Fields
	private object i; // 0xFFFFFFFFFFFFFFF8
	private object region; // 0x0

	// Methods

	// RVA: 0x6CC4000
	public object .ctor(object i, object region) { }

	// RVA: 0x6CC4980
	public override object GetHashCode() { }

}

// Namespace: Spine.Unity.AttachmentTools
public static class AtlasUtilities
{

	// Fields
	internal const object SpineTextureFormat;
	internal const object DefaultMipmapBias;
	internal const object UseMipMaps;
	internal const object DefaultScale;
	private const object NonrenderingRegion;
	private static readonly object existingRegions; // 0x0
	private static readonly object regionIndices; // 0x8
	private static readonly object originalRegions; // 0x10
	private static readonly object repackedRegions; // 0x18
	private static object texturesToPackAtParam; // 0x20
	private static object inoutAttachments; // 0x28
	private static object CachedRegionTextures; // 0x30
	private static object CachedRegionTexturesList; // 0x38

	// Methods

	// RVA: 0x6CBF3CC
	private static object Init() { }

	// RVA: 0x6CBF67C
	public static object ToAtlasRegion(object t, object materialPropertySource, object scale) { }

	// RVA: 0x6CBF718
	public static object ToAtlasRegion(object t, object shader, object scale, object materialPropertySource) { }

	// RVA: 0x6CBFB2C
	public static object ToAtlasRegionPMAClone(object t, object materialPropertySource, object textureFormat, object mipmaps) { }

	// RVA: 0x6CBFBD0
	public static object ToAtlasRegionPMAClone(object t, object shader, object textureFormat, object mipmaps, object materialPropertySource) { }

	// RVA: 0x6CBF9B4
	public static object ToSpineAtlasPage(object m) { }

	// RVA: 0x6CC007C
	public static object ToAtlasRegion(object s, object page) { }

	// RVA: 0x6CC04F8
	public static object ToAtlasRegion(object s, object material) { }

	// RVA: 0x6CC0588
	public static object ToAtlasRegionPMAClone(object s, object materialPropertySource, object textureFormat, object mipmaps) { }

	// RVA: 0x6CC062C
	public static object ToAtlasRegionPMAClone(object s, object shader, object textureFormat, object mipmaps, object materialPropertySource) { }

	// RVA: 0x6CC015C
	internal static object ToAtlasRegion(object s, object isolatedTexture) { }

	// RVA: 0x6CC0DBC
	public static object GetRepackedAttachments(object sourceAttachments, object outputAttachments, object materialPropertySource, object outputMaterial, object outputTexture, object maxAtlasSize, object padding, object textureFormat, object mipmaps, object newAssetName, object clearCache, object useOriginalNonrenderables, object additionalTexturePropertyIDsToCopy, object additionalOutputTextures, object additionalTextureFormats, object additionalTextureIsLinear) { }

	// RVA: 0x6CC0F2C
	public static object GetRepackedAttachments(object sourceAttachments, object outputAttachments, object shader, object outputMaterial, object outputTexture, object maxAtlasSize, object padding, object textureFormat, object mipmaps, object newAssetName, object materialPropertySource, object clearCache, object useOriginalNonrenderables, object additionalTexturePropertyIDsToCopy, object additionalOutputTextures, object additionalTextureFormats, object additionalTextureIsLinear) { }

	// RVA: 0x6CC32E8
	public static object GetRepackedSkin(object o, object newName, object materialPropertySource, object outputMaterial, object outputTexture, object maxAtlasSize, object padding, object textureFormat, object mipmaps, object useOriginalNonrenderables, object clearCache, object additionalTexturePropertyIDsToCopy, object additionalOutputTextures, object additionalTextureFormats, object additionalTextureIsLinear) { }

	// RVA: 0x6CC33D8
	public static object GetRepackedSkin(object o, object newName, object shader, object outputMaterial, object outputTexture, object maxAtlasSize, object padding, object textureFormat, object mipmaps, object materialPropertySource, object clearCache, object useOriginalNonrenderables, object additionalTexturePropertyIDsToCopy, object additionalOutputTextures, object additionalTextureFormats, object additionalTextureIsLinear) { }

	// RVA: 0x6CC3D70
	public static object ToSprite(object ar, object pixelsPerUnit) { }

	// RVA: 0x6CBF434
	public static object ClearCache() { }

	// RVA: 0x6CC2710
	public static object ToTexture(object ar, object textureFormat, object mipmaps, object texturePropertyId, object linear, object applyPMA) { }

	// RVA: 0x6CC0894
	private static object ToTexture(object s, object textureFormat, object mipmaps, object linear, object applyPMA) { }

	// RVA: 0x6CBFE48
	private static object GetClone(object t, object textureFormat, object mipmaps, object linear, object applyPMA) { }

	// RVA: 0x6CC42A0
	private static object CopyTexture(object source, object sourceRect, object destination) { }

	// RVA: 0x6CC40F4
	private static object CopyTextureApplyPMA(object source, object sourceRect, object destination) { }

	// RVA: 0x6CC4428
	private static object IsRenderable(object a) { }

	// RVA: 0x6CC0D00
	private static object SpineUnityFlipRect(object rect, object textureHeight) { }

	// RVA: 0x6CC3ED8
	private static object GetUnityRect(object region) { }

	// RVA: 0x6CC4504
	private static object GetUnityRect(object region, object textureHeight) { }

	// RVA: 0x6CC448C
	private static object GetSpineAtlasRect(object region, object includeRotate) { }

	// RVA: 0x6CC45D8
	private static object UVRectToTextureRect(object uvRect, object texWidth, object texHeight) { }

	// RVA: 0x6CC0D10
	private static object TextureRectToUVRect(object textureRect, object texWidth, object texHeight) { }

	// RVA: 0x6CC2C14
	private static object UVRectToAtlasRegion(object uvRect, object referenceRegion, object page) { }

	// RVA: 0x6CC3E00
	private static object GetMainTexture(object region) { }

	// RVA: 0x6CC45F4
	private static object GetTexture(object region, object texturePropertyName) { }

	// RVA: 0x6CC400C
	private static object GetTexture(object region, object texturePropertyId) { }

	// RVA: 0x6CC2B4C
	private static object CopyTextureAttributesFrom(object destination, object source) { }

	// RVA: 0x6CBFB1C
	private static object InverseLerp(object a, object b, object value) { }

	// RVA: 0x6CC46DC
	private static object .cctor() { }

}

// Namespace: Spine.Unity.AttachmentTools
public static class AttachmentCloneExtensions
{

	// Methods

	// RVA: 0x6CC4A5C
	public static object GetRemappedClone(object o, object sprite, object sourceMaterial, object premultiplyAlpha, object cloneMeshAsLinked, object useOriginalRegionSize, object pivotShiftsMeshUVCoords, object useOriginalRegionScale) { }

	// RVA: 0x6CC4D48
	public static object GetRemappedClone(object o, object atlasRegion, object cloneMeshAsLinked, object useOriginalRegionSize, object scale) { }

}

// Namespace: Spine.Unity.AttachmentTools
public static class AttachmentRegionExtensions
{

	// Methods

	// RVA: 0x6CC31E8
	public static object SetRegion(object attachment, object region, object updateOffset) { }

	// RVA: 0x6CC4FAC
	public static object SetRegion(object attachment, object region, object updateOffset) { }

	// RVA: 0x6CC5084
	public static object SetRegion(object attachment, object region, object updateUVs) { }

	// RVA: 0x6CC5138
	public static object ToRegionAttachment(object sprite, object material, object rotation) { }

	// RVA: 0x6CC51B8
	public static object ToRegionAttachment(object sprite, object page, object rotation) { }

	// RVA: 0x6CC54F0
	public static object ToRegionAttachmentPMAClone(object sprite, object shader, object textureFormat, object mipmaps, object materialPropertySource, object rotation) { }

	// RVA: 0x6CC56B8
	public static object ToRegionAttachmentPMAClone(object sprite, object materialPropertySource, object textureFormat, object mipmaps, object rotation) { }

	// RVA: 0x6CC5338
	public static object ToRegionAttachment(object region, object attachmentName, object scale, object rotation) { }

	// RVA: 0x6CC5728
	public static object SetScale(object regionAttachment, object scale) { }

	// RVA: 0x6CC5748
	public static object SetScale(object regionAttachment, object x, object y) { }

	// RVA: 0x6CC5768
	public static object SetPositionOffset(object regionAttachment, object offset) { }

	// RVA: 0x6CC5788
	public static object SetPositionOffset(object regionAttachment, object x, object y) { }

	// RVA: 0x6CC57A8
	public static object SetRotation(object regionAttachment, object rotation) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=24
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=3992
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=6652
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 0C6A9A02BE5F7EB53FB20C6B5B3C610B857B50E630614FEC5F4BFCD7FC6F1567; // 0x0
	internal static readonly object 2FCD0F3D3B024E5F693BEBB1F5181ACD85E77CF54CD56B108A54A6550E6101BA; // 0x18
	internal static readonly object 753D5E1ADA77B20B9959A1030B8E0BA5CF925F2881D3635C3F791E5A0AE0EEB1; // 0x1A14
	internal static readonly object F592DA30DDCD559583987F72DD1B1C700F659590EEECE3C793C6B259E54B8148; // 0x1A2C
}

