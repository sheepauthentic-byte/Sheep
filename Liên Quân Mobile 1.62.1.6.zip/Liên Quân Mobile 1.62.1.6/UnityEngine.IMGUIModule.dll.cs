// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public sealed class Event
{

	// Fields
	internal object m_Ptr; // 0x8
	private static object s_Current; // 0x0
	private static object s_MasterEvent; // 0x8

	// Properties
	public object rawType { get; }
	public object mousePosition { get; set; }
	public object delta { get; set; }
	public object pointerType { get; }
	public object button { get; }
	public object modifiers { get; set; }
	public object pressure { get; }
	public object twist { get; }
	public object tilt { get; }
	public object penStatus { get; }
	public object clickCount { get; }
	public object character { get; set; }
	public object keyCode { get; set; }
	public object displayIndex { get; set; }
	public object type { get; set; }
	public object commandName { get; set; }
	public object shift { get; }
	public object control { get; }
	public object alt { get; }
	public object command { get; }
	public object functionKey { get; }
	public static object current { get; set; }
	public object isKey { get; }
	public object isMouse { get; }
	internal object isDirectManipulationDevice { get; }

	// Methods

	// RVA: 0x73FBF30
	public object get_rawType() { }

	// RVA: 0x73FBF80
	public object get_mousePosition() { }

	// RVA: 0x73FC040
	public object set_mousePosition(object value) { }

	// RVA: 0x73FC114
	public object get_delta() { }

	// RVA: 0x73FC1D4
	public object set_delta(object value) { }

	// RVA: 0x73FC2A8
	public object get_pointerType() { }

	// RVA: 0x73FC2F8
	public object get_button() { }

	// RVA: 0x73FC348
	public object get_modifiers() { }

	// RVA: 0x73FC398
	public object set_modifiers(object value) { }

	// RVA: 0x73FC3FC
	public object get_pressure() { }

	// RVA: 0x73FC44C
	public object get_twist() { }

	// RVA: 0x73FC49C
	public object get_tilt() { }

	// RVA: 0x73FC55C
	public object get_penStatus() { }

	// RVA: 0x73FC5AC
	public object get_clickCount() { }

	// RVA: 0x73FC5FC
	public object get_character() { }

	// RVA: 0x73FC64C
	public object set_character(object value) { }

	// RVA: 0x73FC6B0
	public object get_keyCode() { }

	// RVA: 0x73FC700
	public object set_keyCode(object value) { }

	// RVA: 0x73FC764
	public object get_displayIndex() { }

	// RVA: 0x73FC7B4
	public object set_displayIndex(object value) { }

	// RVA: 0x73FC818
	public object get_type() { }

	// RVA: 0x73FC868
	public object set_type(object value) { }

	// RVA: 0x73FC8CC
	public object get_commandName() { }

	// RVA: 0x73FC91C
	public object set_commandName(object value) { }

	// RVA: 0x73FC980
	private object Internal_Use() { }

	// RVA: 0x73FC9D0
	private static object Internal_Create(object displayIndex) { }

	// RVA: 0x73FCA20
	private static object Internal_Destroy(object ptr) { }

	// RVA: 0x73FCA70
	public object GetTypeForControl(object controlID) { }

	// RVA: 0x73FCAD4
	internal object CopyFromPtr(object ptr) { }

	// RVA: 0x73FCB38
	public static object PopEvent(object outEvent) { }

	// RVA: 0x73FCB88
	private static object Internal_SetNativeEvent(object ptr) { }

	// RVA: 0x73FCBD8
	internal static object Internal_MakeMasterEventCurrent(object displayIndex) { }

	// RVA: 0x73FCD80
	internal static object GetDoubleClickTime() { }

	// RVA: 0x73FCDC0
	public object .ctor() { }

	// RVA: 0x73FCD24
	public object .ctor(object displayIndex) { }

	// RVA: 0x73FCE28
	protected override object Finalize() { }

	// RVA: 0x73FCF04
	internal object CopyFrom(object e) { }

	// RVA: 0x73FCFA4
	public object get_shift() { }

	// RVA: 0x73FD004
	public object get_control() { }

	// RVA: 0x73FD064
	public object get_alt() { }

	// RVA: 0x73FD0C4
	public object get_command() { }

	// RVA: 0x73FD124
	public object get_functionKey() { }

	// RVA: 0x73FD184
	public static object get_current() { }

	// RVA: 0x73FD1D0
	public static object set_current(object value) { }

	// RVA: 0x73FD284
	public object get_isKey() { }

	// RVA: 0x73FD2D8
	public object get_isMouse() { }

	// RVA: 0x73FD364
	internal object get_isDirectManipulationDevice() { }

	// RVA: 0x73FD3FC
	public static object KeyboardEvent(object key) { }

	// RVA: 0x73FF3BC
	public override object GetHashCode() { }

	// RVA: 0x73FF538
	public override object Equals(object obj) { }

	// RVA: 0x73FF88C
	public override object ToString() { }

	// RVA: 0x7400118
	public object Use() { }

	// RVA: 0x73FBFDC
	private object get_mousePosition_Injected(object ret) { }

	// RVA: 0x73FC0B0
	private object set_mousePosition_Injected(object value) { }

	// RVA: 0x73FC170
	private object get_delta_Injected(object ret) { }

	// RVA: 0x73FC244
	private object set_delta_Injected(object value) { }

	// RVA: 0x73FC4F8
	private object get_tilt_Injected(object ret) { }

}

// Namespace: UnityEngine
public enum EventType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MouseDown;
	public const object MouseUp;
	public const object MouseMove;
	public const object MouseDrag;
	public const object KeyDown;
	public const object KeyUp;
	public const object ScrollWheel;
	public const object Repaint;
	public const object Layout;
	public const object DragUpdated;
	public const object DragPerform;
	public const object DragExited;
	public const object Ignore;
	public const object Used;
	public const object ValidateCommand;
	public const object ExecuteCommand;
	public const object ContextClick;
	public const object MouseEnterWindow;
	public const object MouseLeaveWindow;
	public const object TouchDown;
	public const object TouchUp;
	public const object TouchMove;
	public const object TouchEnter;
	public const object TouchLeave;
	public const object TouchStationary;
	public const object mouseDown;
	public const object mouseUp;
	public const object mouseMove;
	public const object mouseDrag;
	public const object keyDown;
	public const object keyUp;
	public const object scrollWheel;
	public const object repaint;
	public const object layout;
	public const object dragUpdated;
	public const object dragPerform;
	public const object ignore;
	public const object used;
}

// Namespace: UnityEngine
public enum EventModifiers
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Shift;
	public const object Control;
	public const object Alt;
	public const object Command;
	public const object Numeric;
	public const object CapsLock;
	public const object FunctionKey;
}

// Namespace: UnityEngine
public enum PointerType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Mouse;
	public const object Touch;
	public const object Pen;
}

// Namespace: UnityEngine
internal struct EventInterests
{

	// Fields
	private object <wantsMouseMove>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <wantsMouseEnterLeaveWindow>k__BackingField; // 0xFFFFFFFFFFFFFFF9
	private object <wantsLessLayoutEvents>k__BackingField; // 0xFFFFFFFFFFFFFFFA

	// Properties
	public object wantsMouseMove { get; set; }
	public object wantsMouseEnterLeaveWindow { get; set; }
	public object wantsLessLayoutEvents { get; }

	// Methods

	// RVA: 0x7400390
	public object get_wantsMouseMove() { }

	// RVA: 0x74003A0
	public object set_wantsMouseMove(object value) { }

	// RVA: 0x74003B0
	public object get_wantsMouseEnterLeaveWindow() { }

	// RVA: 0x74003C0
	public object set_wantsMouseEnterLeaveWindow(object value) { }

	// RVA: 0x74003D0
	public object get_wantsLessLayoutEvents() { }

	// RVA: 0x74003E0
	public object WantsEvent(object type) { }

	// RVA: 0x7400450
	public object WantsLayoutPass(object type) { }

}

// Namespace: 
public sealed class WindowFunction
{

	// Methods

	// RVA: 0x740EFB8
	public object .ctor(object object, object method) { }

	// RVA: 0x740F050
	public virtual object Invoke(object id) { }

}

// Namespace: UnityEngine
public class GUI
{

	// Fields
	private static object s_ScrollControlId; // 0x0
	private static object s_HotTextField; // 0x4
	private static readonly object s_BoxHash; // 0x8
	private static readonly object s_ButonHash; // 0xC
	private static readonly object s_RepeatButtonHash; // 0x10
	private static readonly object s_ToggleHash; // 0x14
	private static readonly object s_ButtonGridHash; // 0x18
	private static readonly object s_SliderHash; // 0x1C
	private static readonly object s_BeginGroupHash; // 0x20
	private static readonly object s_ScrollviewHash; // 0x24
	private static object <scrollTroughSide>k__BackingField; // 0x28
	private static object <nextScrollStepTime>k__BackingField; // 0x30
	private static object s_Skin; // 0x38
	internal static object s_ToolTipRect; // 0x40
	private static object <scrollViewStates>k__BackingField; // 0x50

	// Properties
	public static object color { get; set; }
	public static object backgroundColor { get; set; }
	public static object contentColor { get; set; }
	public static object changed { get; set; }
	public static object enabled { get; set; }
	internal static object usePageScrollbars { get; }
	internal static object blendMaterial { get; }
	internal static object blitMaterial { get; }
	internal static object roundedRectMaterial { get; }
	internal static object roundedRectWithColorPerBorderMaterial { get; }
	internal static object scrollTroughSide { get; set; }
	internal static object nextScrollStepTime { get; set; }
	public static object skin { get; set; }
	public static object matrix { get; set; }
	internal static object scrollViewStates { get; }

	// Methods

	// RVA: 0x7400628
	public static object get_color() { }

	// RVA: 0x7400724
	public static object set_color(object value) { }

	// RVA: 0x740082C
	public static object get_backgroundColor() { }

	// RVA: 0x7400928
	public static object set_backgroundColor(object value) { }

	// RVA: 0x7400A30
	public static object get_contentColor() { }

	// RVA: 0x7400B2C
	public static object set_contentColor(object value) { }

	// RVA: 0x7400C34
	public static object get_changed() { }

	// RVA: 0x7400C74
	public static object set_changed(object value) { }

	// RVA: 0x7400CC4
	public static object get_enabled() { }

	// RVA: 0x7400D04
	public static object set_enabled(object value) { }

	// RVA: 0x7400D54
	internal static object get_usePageScrollbars() { }

	// RVA: 0x7400D94
	internal static object get_blendMaterial() { }

	// RVA: 0x7400DD4
	internal static object get_blitMaterial() { }

	// RVA: 0x7400E14
	internal static object get_roundedRectMaterial() { }

	// RVA: 0x7400E54
	internal static object get_roundedRectWithColorPerBorderMaterial() { }

	// RVA: 0x7400E94
	internal static object GrabMouseControl(object id) { }

	// RVA: 0x7400EE4
	internal static object HasMouseControl(object id) { }

	// RVA: 0x7400F34
	internal static object ReleaseMouseControl() { }

	// RVA: 0x7400F74
	internal static object InternalRepaintEditorWindow() { }

	// RVA: 0x7400FB4
	private static object Internal_DoWindow(object id, object instanceID, object clientRect, object func, object title, object style, object skin, object forceRectOnLayout) { }

	// RVA: 0x740116C
	private static object .cctor() { }

	// RVA: 0x7401560
	internal static object get_scrollTroughSide() { }

	// RVA: 0x74015DC
	internal static object set_scrollTroughSide(object value) { }

	// RVA: 0x7401668
	internal static object get_nextScrollStepTime() { }

	// RVA: 0x74016E4
	internal static object set_nextScrollStepTime(object value) { }

	// RVA: 0x7401770
	public static object set_skin(object value) { }

	// RVA: 0x7401B40
	public static object get_skin() { }

	// RVA: 0x7401880
	internal static object DoSetSkin(object newSkin) { }

	// RVA: 0x7401D80
	public static object get_matrix() { }

	// RVA: 0x7401E58
	public static object set_matrix(object value) { }

	// RVA: 0x7401F18
	public static object Label(object position, object text) { }

	// RVA: 0x7402224
	public static object Label(object position, object text, object style) { }

	// RVA: 0x7402188
	public static object Label(object position, object content, object style) { }

	// RVA: 0x7402854
	public static object DrawTexture(object position, object image) { }

	// RVA: 0x7402990
	public static object DrawTexture(object position, object image, object scaleMode) { }

	// RVA: 0x7402A88
	public static object DrawTexture(object position, object image, object scaleMode, object alphaBlend) { }

	// RVA: 0x7402B34
	public static object DrawTexture(object position, object image, object scaleMode, object alphaBlend, object imageAspect) { }

	// RVA: 0x7402D50
	public static object DrawTexture(object position, object image, object scaleMode, object alphaBlend, object imageAspect, object color, object borderWidth, object borderRadius) { }

	// RVA: 0x7402E70
	public static object DrawTexture(object position, object image, object scaleMode, object alphaBlend, object imageAspect, object color, object borderWidths, object borderRadius) { }

	// RVA: 0x7403048
	public static object DrawTexture(object position, object image, object scaleMode, object alphaBlend, object imageAspect, object color, object borderWidths, object borderRadiuses) { }

	// RVA: 0x74031AC
	internal static object DrawTexture(object position, object image, object scaleMode, object alphaBlend, object imageAspect, object color, object borderWidths, object borderRadiuses, object drawSmoothCorners) { }

	// RVA: 0x74032F8
	internal static object DrawTexture(object position, object image, object scaleMode, object alphaBlend, object imageAspect, object leftColor, object topColor, object rightColor, object bottomColor, object borderWidths, object borderRadiuses, object drawSmoothCorners) { }

	// RVA: 0x7403A3C
	internal static object CalculateScaledTextureRects(object position, object scaleMode, object imageAspect, object outScreenRect, object outSourceRect) { }

	// RVA: 0x7403B30
	public static object DrawTextureWithTexCoords(object position, object image, object texCoords) { }

	// RVA: 0x7403BF4
	public static object DrawTextureWithTexCoords(object position, object image, object texCoords, object alphaBlend) { }

	// RVA: 0x7404100
	public static object Box(object position, object text) { }

	// RVA: 0x7404520
	public static object Box(object position, object content) { }

	// RVA: 0x7404280
	public static object Box(object position, object content, object style) { }

	// RVA: 0x7404898
	public static object Button(object position, object text) { }

	// RVA: 0x7404B80
	public static object Button(object position, object text, object style) { }

	// RVA: 0x7404A18
	public static object Button(object position, object content, object style) { }

	// RVA: 0x7404DA4
	internal static object Button(object position, object id, object content, object style) { }

	// RVA: 0x7404FC8
	private static object DoRepeatButton(object position, object content, object style, object focusType) { }

	// RVA: 0x7405640
	public static object TextField(object position, object text) { }

	// RVA: 0x7405B2C
	public static object TextField(object position, object text, object style) { }

	// RVA: 0x7405DC4
	internal static object PasswordFieldGetStrToShow(object password, object maskChar) { }

	// RVA: 0x7405A04
	internal static object DoTextField(object position, object id, object content, object multiline, object maxLength, object style) { }

	// RVA: 0x7405F7C
	internal static object DoTextField(object position, object id, object content, object multiline, object maxLength, object style, object secureText) { }

	// RVA: 0x7406048
	internal static object DoTextField(object position, object id, object content, object multiline, object maxLength, object style, object secureText, object maskChar) { }

	// RVA: 0x74069D4
	private static object HandleTextFieldEventForTouchscreen(object position, object id, object content, object multiline, object maxLength, object style, object secureText, object maskChar, object editor) { }

	// RVA: 0x74070B0
	private static object HandleTextFieldEventForDesktop(object position, object id, object content, object multiline, object maxLength, object style, object editor) { }

	// RVA: 0x7406514
	private static object HandleTextFieldEventForDesktopWithForcedKeyboard(object position, object id, object content, object multiline, object maxLength, object style, object secureText, object editor) { }

	// RVA: 0x740805C
	public static object Toggle(object position, object value, object content, object style) { }

	// RVA: 0x7408318
	internal static object DoControl(object position, object id, object on, object hover, object content, object style) { }

	// RVA: 0x74023D8
	private static object DoLabel(object position, object content, object style) { }

	// RVA: 0x7408194
	internal static object DoToggle(object position, object id, object value, object content, object style) { }

	// RVA: 0x7404E50
	internal static object DoButton(object position, object id, object content, object style) { }

	// RVA: 0x7408B80
	public static object HorizontalSlider(object position, object value, object leftValue, object rightValue, object slider, object thumb) { }

	// RVA: 0x7408C50
	public static object Slider(object position, object value, object size, object start, object end, object slider, object thumb, object horiz, object id, object thumbExtent) { }

	// RVA: 0x7408E08
	public static object HorizontalScrollbar(object position, object value, object size, object leftValue, object rightValue, object style) { }

	// RVA: 0x7409B40
	internal static object ScrollerRepeatButton(object scrollerID, object rect, object style) { }

	// RVA: 0x7409F0C
	public static object VerticalScrollbar(object position, object value, object size, object topValue, object bottomValue, object style) { }

	// RVA: 0x74094C0
	internal static object Scroller(object position, object value, object size, object leftValue, object rightValue, object slider, object thumb, object leftButton, object rightButton, object horiz) { }

	// RVA: 0x740A348
	public static object BeginGroup(object position, object content, object style) { }

	// RVA: 0x740A42C
	internal static object BeginGroup(object position, object content, object style, object scrollOffset) { }

	// RVA: 0x740AB94
	public static object EndGroup() { }

	// RVA: 0x740AC18
	internal static object get_scrollViewStates() { }

	// RVA: 0x740AC94
	public static object BeginScrollView(object position, object scrollPosition, object viewRect) { }

	// RVA: 0x740AED4
	internal static object BeginScrollView(object position, object scrollPosition, object viewRect, object alwaysShowHorizontal, object alwaysShowVertical, object horizontalScrollbar, object verticalScrollbar, object background) { }

	// RVA: 0x740CA18
	public static object EndScrollView() { }

	// RVA: 0x740CA88
	public static object EndScrollView(object handleScrollWheel) { }

	// RVA: 0x740DC14
	public static object Window(object id, object clientRect, object func, object text) { }

	// RVA: 0x740DE54
	private static object DoWindow(object id, object clientRect, object func, object title, object style, object skin, object forceRectOnLayout) { }

	// RVA: 0x740E000
	internal static object CallWindowDelegate(object func, object id, object instanceID, object _skin, object forceRect, object width, object height, object style) { }

	// RVA: 0x74006D4
	private static object get_color_Injected(object ret) { }

	// RVA: 0x74007DC
	private static object set_color_Injected(object value) { }

	// RVA: 0x74008D8
	private static object get_backgroundColor_Injected(object ret) { }

	// RVA: 0x74009E0
	private static object set_backgroundColor_Injected(object value) { }

	// RVA: 0x7400ADC
	private static object get_contentColor_Injected(object ret) { }

	// RVA: 0x7400BE4
	private static object set_contentColor_Injected(object value) { }

	// RVA: 0x74010C8
	private static object Internal_DoWindow_Injected(object id, object instanceID, object clientRect, object func, object title, object style, object skin, object forceRectOnLayout, object ret) { }

}

// Namespace: 
internal struct ParentClipScope
{

	// Fields
	private object m_Disposed; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x740F658
	public object .ctor(object objectTransform, object clipRect) { }

	// RVA: 0x740F750
	public object Dispose() { }

}

// Namespace: UnityEngine
internal sealed class GUIClip
{

	// Properties
	internal static object visibleRect { get; }

	// Methods

	// RVA: 0x7408A28
	internal static object get_visibleRect() { }

	// RVA: 0x740F0B4
	internal static object Internal_Push(object screenRect, object scrollOffset, object renderOffset, object resetOffset) { }

	// RVA: 0x740ABD8
	internal static object Internal_Pop() { }

	// RVA: 0x740F19C
	internal static object Internal_GetCount() { }

	// RVA: 0x740F1DC
	private static object Unclip_Vector2(object pos) { }

	// RVA: 0x740F298
	private static object UnclipToWindow_Vector2(object pos) { }

	// RVA: 0x7401DF0
	internal static object GetMatrix() { }

	// RVA: 0x7401EC8
	internal static object SetMatrix(object m) { }

	// RVA: 0x740F3F4
	internal static object Internal_PushParentClip(object objectTransform, object clipRect) { }

	// RVA: 0x740F46C
	internal static object Internal_PushParentClip(object renderTransform, object inputTransform, object clipRect) { }

	// RVA: 0x740F544
	internal static object Internal_PopParentClip() { }

	// RVA: 0x740AB2C
	internal static object Push(object screenRect, object scrollOffset, object renderOffset, object resetOffset) { }

	// RVA: 0x740DBD4
	internal static object Pop() { }

	// RVA: 0x740F584
	public static object Unclip(object pos) { }

	// RVA: 0x740F5DC
	public static object UnclipToWindow(object pos) { }

	// RVA: 0x740F064
	private static object get_visibleRect_Injected(object ret) { }

	// RVA: 0x740F11C
	private static object Internal_Push_Injected(object screenRect, object scrollOffset, object renderOffset, object resetOffset) { }

	// RVA: 0x740F234
	private static object Unclip_Vector2_Injected(object pos, object ret) { }

	// RVA: 0x740F2F0
	private static object UnclipToWindow_Vector2_Injected(object pos, object ret) { }

	// RVA: 0x740F354
	private static object GetMatrix_Injected(object ret) { }

	// RVA: 0x740F3A4
	private static object SetMatrix_Injected(object m) { }

	// RVA: 0x740F4D8
	private static object Internal_PushParentClip_Injected(object renderTransform, object inputTransform, object clipRect) { }

}

// Namespace: UnityEngine
public class GUIContent
{

	// Fields
	private object m_Text; // 0x8
	private object m_Image; // 0x10
	private object m_Tooltip; // 0x18
	private object OnTextChanged; // 0x20
	private static readonly object s_Text; // 0x0
	private static readonly object s_Image; // 0x8
	private static readonly object s_TextImage; // 0x10
	public static object none; // 0x18

	// Properties
	public object text { get; set; }
	public object image { get; set; }
	public object tooltip { get; set; }

	// Methods

	// RVA: 0x7405B24
	public object get_text() { }

	// RVA: 0x7406430
	public object set_text(object value) { }

	// RVA: 0x740F834
	public object get_image() { }

	// RVA: 0x740F83C
	public object set_image(object value) { }

	// RVA: 0x7408A20
	public object get_tooltip() { }

	// RVA: 0x740F844
	public object set_tooltip(object value) { }

	// RVA: 0x740F84C
	public object .ctor() { }

	// RVA: 0x740F8B8
	public object .ctor(object text) { }

	// RVA: 0x740FA44
	public object .ctor(object text, object tooltip) { }

	// RVA: 0x740FAF4
	public object .ctor(object image, object tooltip) { }

	// RVA: 0x740F990
	public object .ctor(object text, object image, object tooltip) { }

	// RVA: 0x740FBD0
	public object .ctor(object src) { }

	// RVA: 0x74020C8
	public static object Temp(object t) { }

	// RVA: 0x740FC8C
	internal static object ClearStaticCache() { }

	// RVA: 0x740FD68
	public override object ToString() { }

	// RVA: 0x740FD88
	private static object .cctor() { }

}

// Namespace: UnityEngine
public enum ScaleMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object StretchToFill;
	public const object ScaleAndCrop;
	public const object ScaleToFit;
}

// Namespace: UnityEngine
public enum FocusType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Native;
	public const object Keyboard;
	public const object Passive;
}

// Namespace: UnityEngine
public class GUILayout
{

	// Methods

	// RVA: 0x740FF08
	public static object Label(object text, object options) { }

	// RVA: 0x7410240
	public static object Label(object text, object style, object options) { }

	// RVA: 0x74100B4
	private static object DoLabel(object content, object style, object options) { }

	// RVA: 0x74103D0
	public static object Box(object text, object options) { }

	// RVA: 0x74106B4
	public static object Box(object text, object style, object options) { }

	// RVA: 0x74107CC
	public static object Box(object content, object style, object options) { }

	// RVA: 0x741057C
	private static object DoBox(object content, object style, object options) { }

	// RVA: 0x74107D0
	public static object Button(object text, object options) { }

	// RVA: 0x7410AB4
	public static object Button(object text, object style, object options) { }

	// RVA: 0x7410BCC
	public static object Button(object content, object style, object options) { }

	// RVA: 0x741097C
	private static object DoButton(object content, object style, object options) { }

	// RVA: 0x7410BD0
	public static object TextField(object text, object options) { }

	// RVA: 0x7411280
	public static object TextField(object text, object style, object options) { }

	// RVA: 0x7411294
	public static object TextArea(object text, object options) { }

	// RVA: 0x7411394
	public static object TextArea(object text, object style, object options) { }

	// RVA: 0x7410CC8
	private static object DoTextField(object text, object maxLength, object multiline, object style, object options) { }

	// RVA: 0x7411470
	public static object Toggle(object value, object text, object options) { }

	// RVA: 0x7411774
	public static object Toggle(object value, object text, object style, object options) { }

	// RVA: 0x7411634
	private static object DoToggle(object value, object content, object style, object options) { }

	// RVA: 0x7411894
	public static object HorizontalSlider(object value, object leftValue, object rightValue, object slider, object thumb, object options) { }

	// RVA: 0x7411898
	private static object DoHorizontalSlider(object value, object leftValue, object rightValue, object slider, object thumb, object options) { }

	// RVA: 0x7411B34
	public static object Space(object pixels) { }

	// RVA: 0x74121A4
	public static object FlexibleSpace() { }

	// RVA: 0x74126E4
	public static object BeginHorizontal(object options) { }

	// RVA: 0x7412984
	public static object BeginHorizontal(object style, object options) { }

	// RVA: 0x74127AC
	public static object BeginHorizontal(object content, object style, object options) { }

	// RVA: 0x7412E68
	public static object EndHorizontal() { }

	// RVA: 0x741329C
	public static object BeginVertical(object options) { }

	// RVA: 0x7413364
	public static object BeginVertical(object content, object style, object options) { }

	// RVA: 0x7413540
	public static object EndVertical() { }

	// RVA: 0x74135A8
	public static object BeginArea(object screenRect) { }

	// RVA: 0x741395C
	public static object BeginArea(object screenRect, object style) { }

	// RVA: 0x7413690
	public static object BeginArea(object screenRect, object content, object style) { }

	// RVA: 0x7413E24
	public static object EndArea() { }

	// RVA: 0x74141F4
	public static object BeginScrollView(object scrollPosition, object options) { }

	// RVA: 0x74143E4
	public static object BeginScrollView(object scrollPosition, object alwaysShowHorizontal, object alwaysShowVertical, object horizontalScrollbar, object verticalScrollbar, object background, object options) { }

	// RVA: 0x74146B4
	public static object EndScrollView() { }

	// RVA: 0x7414764
	internal static object EndScrollView(object handleScrollWheel) { }

	// RVA: 0x740E6F4
	public static object Width(object width) { }

	// RVA: 0x7414824
	public static object MinWidth(object minWidth) { }

	// RVA: 0x740E798
	public static object Height(object height) { }

	// RVA: 0x74148CC
	public static object MinHeight(object minHeight) { }

	// RVA: 0x7412608
	public static object ExpandWidth(object expand) { }

	// RVA: 0x7412568
	public static object ExpandHeight(object expand) { }

}

// Namespace: 
internal enum Type
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object fixedWidth;
	public const object fixedHeight;
	public const object minWidth;
	public const object maxWidth;
	public const object minHeight;
	public const object maxHeight;
	public const object stretchWidth;
	public const object stretchHeight;
	public const object alignStart;
	public const object alignMiddle;
	public const object alignEnd;
	public const object alignJustify;
	public const object equalSize;
	public const object spacing;
}

// Namespace: UnityEngine
public sealed class GUILayoutOption
{

	// Fields
	internal object type; // 0x8
	internal object value; // 0x10

	// Methods

	// RVA: 0x74126A8
	internal object .ctor(object type, object value) { }

}

// Namespace: 
internal sealed class LayoutCache
{

	// Fields
	private object <id>k__BackingField; // 0x8
	internal object topLevel; // 0x10
	internal object layoutGroups; // 0x18
	internal object windows; // 0x20

	// Properties
	private object id { set; }

	// Methods

	// RVA: 0x7416CCC
	private object set_id(object value) { }

	// RVA: 0x7414CB4
	internal object .ctor(object instanceID) { }

	// RVA: 0x7416CD4
	public object ResetCursor() { }

}

// Namespace: UnityEngine
public class GUILayoutUtility
{

	// Fields
	private static readonly object s_StoredLayouts; // 0x0
	private static readonly object s_StoredWindows; // 0x8
	internal static object current; // 0x10
	internal static readonly object kDummyRect; // 0x18
	private static object <unbalancedgroupscount>k__BackingField; // 0x28
	private static object s_SpaceStyle; // 0x30

	// Properties
	internal static object unbalancedgroupscount { get; set; }
	internal static object spaceStyle { get; }

	// Methods

	// RVA: 0x7414974
	private static object Internal_GetWindowRect(object windowID) { }

	// RVA: 0x7414A94
	private static object Internal_MoveWindow(object windowID, object r) { }

	// RVA: 0x7414BAC
	internal static object get_unbalancedgroupscount() { }

	// RVA: 0x7414C28
	internal static object set_unbalancedgroupscount(object value) { }

	// RVA: 0x740E568
	internal static object SelectIDList(object instanceID, object isWindow) { }

	// RVA: 0x7414DB8
	internal static object Begin(object instanceID) { }

	// RVA: 0x7415058
	internal static object BeginContainer(object cache) { }

	// RVA: 0x740E840
	internal static object BeginWindow(object windowID, object style, object options) { }

	// RVA: 0x740EBE4
	internal static object Layout() { }

	// RVA: 0x7415848
	internal static object LayoutFromEditorWindow() { }

	// RVA: 0x7415B28
	internal static object LayoutFromContainer(object w, object h) { }

	// RVA: 0x7415310
	internal static object LayoutFreeGroup(object toplevel) { }

	// RVA: 0x74154E8
	private static object LayoutSingleGroup(object i) { }

	// RVA: 0x7415DE0
	private static object CreateGUILayoutGroupInstanceOfType(object LayoutType) { }

	// RVA: 0x74129F8
	internal static object BeginLayoutGroup(object style, object options, object layoutType) { }

	// RVA: 0x7412ED0
	internal static object EndLayoutGroup() { }

	// RVA: 0x74139F8
	internal static object BeginLayoutArea(object style, object layoutType) { }

	// RVA: 0x7413FA4
	internal static object EndLayoutArea() { }

	// RVA: 0x7410358
	public static object GetRect(object content, object style, object options) { }

	// RVA: 0x7416020
	private static object DoGetRect(object content, object style, object options) { }

	// RVA: 0x741211C
	public static object GetRect(object width, object height, object style, object options) { }

	// RVA: 0x741674C
	private static object DoGetRect(object minWidth, object maxWidth, object minHeight, object maxHeight, object style, object options) { }

	// RVA: 0x7416964
	public static object GetLastRect() { }

	// RVA: 0x7411F34
	internal static object get_spaceStyle() { }

	// RVA: 0x7416BD4
	private static object .cctor() { }

	// RVA: 0x7414A30
	private static object Internal_GetWindowRect_Injected(object windowID, object ret) { }

	// RVA: 0x7414B48
	private static object Internal_MoveWindow_Injected(object windowID, object r) { }

}

// Namespace: UnityEngine
public sealed class GUISettings
{

	// Fields
	private object m_DoubleClickSelectsWord; // 0x8
	private object m_TripleClickSelectsLine; // 0x9
	private object m_CursorColor; // 0xC
	private object m_CursorFlashSpeed; // 0x1C
	private object m_SelectionColor; // 0x20

	// Properties
	public object doubleClickSelectsWord { get; }
	public object tripleClickSelectsLine { get; }
	public object cursorColor { get; }
	public object cursorFlashSpeed { get; }
	public object selectionColor { get; }

	// Methods

	// RVA: 0x7417050
	private static object Internal_GetCursorFlashSpeed() { }

	// RVA: 0x7407F64
	public object get_doubleClickSelectsWord() { }

	// RVA: 0x7407F6C
	public object get_tripleClickSelectsLine() { }

	// RVA: 0x7417090
	public object get_cursorColor() { }

	// RVA: 0x741709C
	public object get_cursorFlashSpeed() { }

	// RVA: 0x74170EC
	public object get_selectionColor() { }

	// RVA: 0x74170F8
	public object .ctor() { }

}

// Namespace: 
internal sealed class SkinChangedDelegate
{

	// Methods

	// RVA: 0x741A988
	public object .ctor(object object, object method) { }

	// RVA: 0x741AA1C
	public virtual object Invoke() { }

}

// Namespace: UnityEngine
public sealed class GUISkin
{

	// Fields
	private object m_Font; // 0x10
	private object m_box; // 0x18
	private object m_button; // 0x20
	private object m_toggle; // 0x28
	private object m_label; // 0x30
	private object m_textField; // 0x38
	private object m_textArea; // 0x40
	private object m_window; // 0x48
	private object m_horizontalSlider; // 0x50
	private object m_horizontalSliderThumb; // 0x58
	private object m_horizontalSliderThumbExtent; // 0x60
	private object m_verticalSlider; // 0x68
	private object m_verticalSliderThumb; // 0x70
	private object m_verticalSliderThumbExtent; // 0x78
	private object m_SliderMixed; // 0x80
	private object m_horizontalScrollbar; // 0x88
	private object m_horizontalScrollbarThumb; // 0x90
	private object m_horizontalScrollbarLeftButton; // 0x98
	private object m_horizontalScrollbarRightButton; // 0xA0
	private object m_verticalScrollbar; // 0xA8
	private object m_verticalScrollbarThumb; // 0xB0
	private object m_verticalScrollbarUpButton; // 0xB8
	private object m_verticalScrollbarDownButton; // 0xC0
	private object m_ScrollView; // 0xC8
	internal object m_CustomStyles; // 0xD0
	private object m_Settings; // 0xD8
	internal static object ms_Error; // 0x0
	private object m_Styles; // 0xE0
	internal static object m_SkinChanged; // 0x8
	internal static object current; // 0x10

	// Properties
	public object font { get; set; }
	public object box { get; set; }
	public object label { get; set; }
	public object textField { get; set; }
	public object textArea { get; set; }
	public object button { get; set; }
	public object toggle { get; set; }
	public object window { get; set; }
	public object horizontalSlider { get; set; }
	public object horizontalSliderThumb { get; set; }
	internal object horizontalSliderThumbExtent { get; set; }
	internal object sliderMixed { get; set; }
	public object verticalSlider { get; set; }
	public object verticalSliderThumb { get; set; }
	internal object verticalSliderThumbExtent { get; set; }
	public object horizontalScrollbar { get; set; }
	public object horizontalScrollbarThumb { get; set; }
	public object horizontalScrollbarLeftButton { get; set; }
	public object horizontalScrollbarRightButton { get; set; }
	public object verticalScrollbar { get; set; }
	public object verticalScrollbarThumb { get; set; }
	public object verticalScrollbarUpButton { get; set; }
	public object verticalScrollbarDownButton { get; set; }
	public object scrollView { get; set; }
	public object customStyles { get; set; }
	public object settings { get; }
	internal static object error { get; }

	// Methods

	// RVA: 0x7417124
	public object .ctor() { }

	// RVA: 0x74171DC
	internal object OnEnable() { }

	// RVA: 0x741730C
	internal static object CleanupRoots() { }

	// RVA: 0x7407FC4
	public object get_font() { }

	// RVA: 0x741735C
	public object set_font(object value) { }

	// RVA: 0x7404278
	public object get_box() { }

	// RVA: 0x7417564
	public object set_box(object value) { }

	// RVA: 0x7402180
	public object get_label() { }

	// RVA: 0x7417600
	public object set_label(object value) { }

	// RVA: 0x74059FC
	public object get_textField() { }

	// RVA: 0x741769C
	public object set_textField(object value) { }

	// RVA: 0x741138C
	public object get_textArea() { }

	// RVA: 0x7417738
	public object set_textArea(object value) { }

	// RVA: 0x7404A10
	public object get_button() { }

	// RVA: 0x74177D4
	public object set_button(object value) { }

	// RVA: 0x741162C
	public object get_toggle() { }

	// RVA: 0x7417870
	public object set_toggle(object value) { }

	// RVA: 0x740DE4C
	public object get_window() { }

	// RVA: 0x741790C
	public object set_window(object value) { }

	// RVA: 0x74179A8
	public object get_horizontalSlider() { }

	// RVA: 0x74179B0
	public object set_horizontalSlider(object value) { }

	// RVA: 0x7417A4C
	public object get_horizontalSliderThumb() { }

	// RVA: 0x7417A54
	public object set_horizontalSliderThumb(object value) { }

	// RVA: 0x7417AF0
	internal object get_horizontalSliderThumbExtent() { }

	// RVA: 0x7417AF8
	internal object set_horizontalSliderThumbExtent(object value) { }

	// RVA: 0x7417B94
	internal object get_sliderMixed() { }

	// RVA: 0x7417B9C
	internal object set_sliderMixed(object value) { }

	// RVA: 0x7417C38
	public object get_verticalSlider() { }

	// RVA: 0x7417C40
	public object set_verticalSlider(object value) { }

	// RVA: 0x7417CDC
	public object get_verticalSliderThumb() { }

	// RVA: 0x7417CE4
	public object set_verticalSliderThumb(object value) { }

	// RVA: 0x7417D80
	internal object get_verticalSliderThumbExtent() { }

	// RVA: 0x7417D88
	internal object set_verticalSliderThumbExtent(object value) { }

	// RVA: 0x740AEBC
	public object get_horizontalScrollbar() { }

	// RVA: 0x7417E24
	public object set_horizontalScrollbar(object value) { }

	// RVA: 0x7417EC0
	public object get_horizontalScrollbarThumb() { }

	// RVA: 0x7417EC8
	public object set_horizontalScrollbarThumb(object value) { }

	// RVA: 0x7417F64
	public object get_horizontalScrollbarLeftButton() { }

	// RVA: 0x7417F6C
	public object set_horizontalScrollbarLeftButton(object value) { }

	// RVA: 0x7418008
	public object get_horizontalScrollbarRightButton() { }

	// RVA: 0x7418010
	public object set_horizontalScrollbarRightButton(object value) { }

	// RVA: 0x740AEC4
	public object get_verticalScrollbar() { }

	// RVA: 0x74180AC
	public object set_verticalScrollbar(object value) { }

	// RVA: 0x7418148
	public object get_verticalScrollbarThumb() { }

	// RVA: 0x7418150
	public object set_verticalScrollbarThumb(object value) { }

	// RVA: 0x74181EC
	public object get_verticalScrollbarUpButton() { }

	// RVA: 0x74181F4
	public object set_verticalScrollbarUpButton(object value) { }

	// RVA: 0x7418290
	public object get_verticalScrollbarDownButton() { }

	// RVA: 0x7418298
	public object set_verticalScrollbarDownButton(object value) { }

	// RVA: 0x740AECC
	public object get_scrollView() { }

	// RVA: 0x7418334
	public object set_scrollView(object value) { }

	// RVA: 0x74183D0
	public object get_customStyles() { }

	// RVA: 0x74183D8
	public object set_customStyles(object value) { }

	// RVA: 0x7407F5C
	public object get_settings() { }

	// RVA: 0x7418470
	internal static object get_error() { }

	// RVA: 0x7417274
	internal object Apply() { }

	// RVA: 0x7418660
	private object BuildStyleCache() { }

	// RVA: 0x7409204
	public object GetStyle(object styleName) { }

	// RVA: 0x741A7BC
	public object FindStyle(object styleName) { }

	// RVA: 0x7401C88
	internal object MakeCurrent() { }

	// RVA: 0x741A858
	public object GetEnumerator() { }

}

// Namespace: UnityEngine
internal class GUIStateObjects
{

	// Fields
	private static object s_StateCache; // 0x0

	// Methods

	// RVA: 0x741AA30
	internal static object GetStateObject(object t, object controlID) { }

	// RVA: 0x741ABE4
	private static object .cctor() { }

}

// Namespace: UnityEngine
public sealed class GUIStyleState
{

	// Fields
	internal object m_Ptr; // 0x8
	private readonly object m_SourceStyle; // 0x10

	// Properties
	public object background { set; }
	public object textColor { get; set; }

	// Methods

	// RVA: 0x741ACB0
	public object set_background(object value) { }

	// RVA: 0x741AD14
	public object get_textColor() { }

	// RVA: 0x741A748
	public object set_textColor(object value) { }

	// RVA: 0x741AE3C
	private static object Init() { }

	// RVA: 0x741AE7C
	private object Cleanup() { }

	// RVA: 0x741AECC
	public object .ctor() { }

	// RVA: 0x741AF28
	private object .ctor(object sourceStyle, object source) { }

	// RVA: 0x741AF60
	internal static object GetGUIStyleState(object sourceStyle, object source) { }

	// RVA: 0x741AFCC
	protected override object Finalize() { }

	// RVA: 0x741AD74
	private object get_textColor_Injected(object ret) { }

	// RVA: 0x741ADD8
	private object set_textColor_Injected(object value) { }

}

// Namespace: UnityEngine
public sealed class GUIStyle
{

	// Fields
	internal object m_Ptr; // 0x8
	private object m_Normal; // 0x10
	private object m_Hover; // 0x18
	private object m_Active; // 0x20
	private object m_Focused; // 0x28
	private object m_OnNormal; // 0x30
	private object m_OnHover; // 0x38
	private object m_OnActive; // 0x40
	private object m_OnFocused; // 0x48
	private object m_Border; // 0x50
	private object m_Padding; // 0x58
	private object m_Margin; // 0x60
	private object m_Overflow; // 0x68
	private object m_Name; // 0x70
	internal static object showKeyboardFocus; // 0x0
	private static object s_None; // 0x8

	// Properties
	internal object rawName { get; set; }
	public object font { get; }
	public object imagePosition { get; set; }
	public object alignment { set; }
	public object wordWrap { get; set; }
	public object clipping { set; }
	public object contentOffset { get; set; }
	public object fixedWidth { get; set; }
	public object fixedHeight { get; set; }
	public object stretchWidth { get; set; }
	public object stretchHeight { get; set; }
	public object fontSize { set; }
	public object fontStyle { set; }
	internal object Internal_clipOffset { set; }
	public object name { get; set; }
	public object normal { get; }
	public object active { get; }
	public object border { set; }
	public object margin { get; set; }
	public object padding { get; set; }
	public object lineHeight { get; }
	public static object none { get; }
	public object isHeightDependantOnWidth { get; }

	// Methods

	// RVA: 0x741B0D0
	internal object get_rawName() { }

	// RVA: 0x741B120
	internal object set_rawName(object value) { }

	// RVA: 0x7407F74
	public object get_font() { }

	// RVA: 0x741B184
	public object get_imagePosition() { }

	// RVA: 0x741B1D4
	public object set_imagePosition(object value) { }

	// RVA: 0x741B238
	public object set_alignment(object value) { }

	// RVA: 0x741B29C
	public object get_wordWrap() { }

	// RVA: 0x741B2EC
	public object set_wordWrap(object value) { }

	// RVA: 0x741B350
	public object set_clipping(object value) { }

	// RVA: 0x741B3B4
	public object get_contentOffset() { }

	// RVA: 0x741B474
	public object set_contentOffset(object value) { }

	// RVA: 0x740A2A8
	public object get_fixedWidth() { }

	// RVA: 0x741B548
	public object set_fixedWidth(object value) { }

	// RVA: 0x740A2F8
	public object get_fixedHeight() { }

	// RVA: 0x741B5AC
	public object set_fixedHeight(object value) { }

	// RVA: 0x741B610
	public object get_stretchWidth() { }

	// RVA: 0x7416B70
	public object set_stretchWidth(object value) { }

	// RVA: 0x741B660
	public object get_stretchHeight() { }

	// RVA: 0x741A630
	public object set_stretchHeight(object value) { }

	// RVA: 0x741B6B0
	public object set_fontSize(object value) { }

	// RVA: 0x741B714
	public object set_fontStyle(object value) { }

	// RVA: 0x741B778
	internal object set_Internal_clipOffset(object value) { }

	// RVA: 0x741B84C
	private static object Internal_Create(object self) { }

	// RVA: 0x741B89C
	private static object Internal_Copy(object self, object other) { }

	// RVA: 0x741B900
	private static object Internal_Destroy(object self) { }

	// RVA: 0x741B950
	private object GetStyleStatePtr(object idx) { }

	// RVA: 0x741B9B4
	private object GetRectOffsetPtr(object idx) { }

	// RVA: 0x741BA18
	private object AssignRectOffset(object idx, object srcRectOffset) { }

	// RVA: 0x741BA84
	private static object Internal_GetLineHeight(object target) { }

	// RVA: 0x741BAD4
	private object Internal_Draw(object screenRect, object content, object isHover, object isActive, object on, object hasKeyboardFocus) { }

	// RVA: 0x741BC14
	private object Internal_Draw2(object position, object content, object controlID, object on) { }

	// RVA: 0x741BD20
	private object Internal_DrawCursor(object position, object content, object pos, object cursorColor) { }

	// RVA: 0x741BE28
	private object Internal_DrawWithTextSelection(object screenRect, object content, object isHover, object isActive, object on, object hasKeyboardFocus, object drawSelectionAsComposition, object cursorFirst, object cursorLast, object cursorColor, object selectionColor) { }

	// RVA: 0x741BFA8
	internal object Internal_GetCursorPixelPosition(object position, object content, object cursorStringIndex) { }

	// RVA: 0x741C0B0
	internal object Internal_GetCursorStringIndex(object position, object content, object cursorPixelPosition) { }

	// RVA: 0x741C1A4
	internal object Internal_GetSelectedRenderedText(object localPosition, object mContent, object selectIndex, object cursorIndex) { }

	// RVA: 0x741C2B0
	internal object Internal_CalcSize(object content) { }

	// RVA: 0x741C388
	internal object Internal_CalcSizeWithConstraints(object content, object maxSize) { }

	// RVA: 0x741C47C
	private object Internal_CalcHeight(object content, object width) { }

	// RVA: 0x741C4F4
	private object Internal_CalcMinMaxWidth(object content) { }

	// RVA: 0x7408ACC
	internal static object SetMouseTooltip(object tooltip, object screenRect) { }

	// RVA: 0x7408A7C
	internal static object IsTooltipActive(object tooltip) { }

	// RVA: 0x741C630
	private static object Internal_GetCursorFlashOffset() { }

	// RVA: 0x7417514
	internal static object SetDefaultFont(object font) { }

	// RVA: 0x7416AB4
	public object .ctor() { }

	// RVA: 0x741C670
	public object .ctor(object other) { }

	// RVA: 0x741C790
	protected override object Finalize() { }

	// RVA: 0x74091A4
	public object get_name() { }

	// RVA: 0x74185F8
	public object set_name(object value) { }

	// RVA: 0x741A694
	public object get_normal() { }

	// RVA: 0x741C8A8
	public object get_active() { }

	// RVA: 0x741C95C
	public object set_border(object value) { }

	// RVA: 0x740C860
	public object get_margin() { }

	// RVA: 0x741C9DC
	public object set_margin(object value) { }

	// RVA: 0x741CA5C
	public object get_padding() { }

	// RVA: 0x741CB1C
	public object set_padding(object value) { }

	// RVA: 0x741CB9C
	public object get_lineHeight() { }

	// RVA: 0x740C920
	public object Draw(object position, object isHover, object isActive, object on, object hasKeyboardFocus) { }

	// RVA: 0x7408984
	public object Draw(object position, object content, object isHover, object isActive, object on, object hasKeyboardFocus) { }

	// RVA: 0x740A9F8
	public object Draw(object position, object content, object controlID) { }

	// RVA: 0x7407E68
	public object Draw(object position, object content, object controlID, object on) { }

	// RVA: 0x74046B4
	public object Draw(object position, object content, object controlID, object on, object hover) { }

	// RVA: 0x741CCFC
	private object Draw(object position, object content, object controlId, object isHover, object isActive, object on, object hasKeyboardFocus) { }

	// RVA: 0x741CEB8
	public object DrawCursor(object position, object content, object controlID, object character) { }

	// RVA: 0x741D254
	internal object DrawWithTextSelection(object position, object content, object isActive, object hasKeyboardFocus, object firstSelectedCharacter, object lastSelectedCharacter, object drawSelectionAsComposition, object selectionColor) { }

	// RVA: 0x741D66C
	internal object DrawWithTextSelection(object position, object content, object controlID, object firstSelectedCharacter, object lastSelectedCharacter, object drawSelectionAsComposition) { }

	// RVA: 0x741D8A0
	public object DrawWithTextSelection(object position, object content, object controlID, object firstSelectedCharacter, object lastSelectedCharacter) { }

	// RVA: 0x740A894
	public static object get_none() { }

	// RVA: 0x741D8A8
	public object GetCursorPixelPosition(object position, object content, object cursorStringIndex) { }

	// RVA: 0x741D928
	public object GetCursorStringIndex(object position, object content, object cursorPixelPosition) { }

	// RVA: 0x741D99C
	public object CalcSize(object content) { }

	// RVA: 0x74165D0
	internal object CalcSizeWithConstraints(object content, object constraints) { }

	// RVA: 0x741DA08
	public object CalcHeight(object content, object width) { }

	// RVA: 0x74164F0
	public object get_isHeightDependantOnWidth() { }

	// RVA: 0x741DA80
	public object CalcMinMaxWidth(object content, object minWidth, object maxWidth) { }

	// RVA: 0x741DB04
	public override object ToString() { }

	// RVA: 0x741DC30
	private static object .cctor() { }

	// RVA: 0x741B410
	private object get_contentOffset_Injected(object ret) { }

	// RVA: 0x741B4E4
	private object set_contentOffset_Injected(object value) { }

	// RVA: 0x741B7E8
	private object set_Internal_clipOffset_Injected(object value) { }

	// RVA: 0x741BB70
	private object Internal_Draw_Injected(object screenRect, object content, object isHover, object isActive, object on, object hasKeyboardFocus) { }

	// RVA: 0x741BC98
	private object Internal_Draw2_Injected(object position, object content, object controlID, object on) { }

	// RVA: 0x741BDA0
	private object Internal_DrawCursor_Injected(object position, object content, object pos, object cursorColor) { }

	// RVA: 0x741BEFC
	private object Internal_DrawWithTextSelection_Injected(object screenRect, object content, object isHover, object isActive, object on, object hasKeyboardFocus, object drawSelectionAsComposition, object cursorFirst, object cursorLast, object cursorColor, object selectionColor) { }

	// RVA: 0x741C028
	private object Internal_GetCursorPixelPosition_Injected(object position, object content, object cursorStringIndex, object ret) { }

	// RVA: 0x741C124
	private object Internal_GetCursorStringIndex_Injected(object position, object content, object cursorPixelPosition) { }

	// RVA: 0x741C228
	private object Internal_GetSelectedRenderedText_Injected(object localPosition, object mContent, object selectIndex, object cursorIndex) { }

	// RVA: 0x741C31C
	private object Internal_CalcSize_Injected(object content, object ret) { }

	// RVA: 0x741C3FC
	private object Internal_CalcSizeWithConstraints_Injected(object content, object maxSize, object ret) { }

	// RVA: 0x741C560
	private object Internal_CalcMinMaxWidth_Injected(object content, object ret) { }

	// RVA: 0x741C5CC
	private static object SetMouseTooltip_Injected(object tooltip, object screenRect) { }

}

// Namespace: UnityEngine
public enum ImagePosition
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ImageLeft;
	public const object ImageAbove;
	public const object ImageOnly;
	public const object TextOnly;
}

// Namespace: UnityEngine
public enum TextClipping
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Overflow;
	public const object Clip;
}

// Namespace: UnityEngine
public class GUITargetAttribute
{

	// Fields
	internal object displayMask; // 0x8

	// Methods

	// RVA: 0x741DC80
	private static object GetGUITargetAttrValue(object klass, object methodName) { }

}

// Namespace: UnityEngine
public class GUIUtility
{

	// Fields
	internal static object s_ControlCount; // 0x0
	internal static object s_SkinMode; // 0x4
	internal static object s_OriginalID; // 0x8
	internal static object takeCapture; // 0x10
	internal static object releaseCapture; // 0x18
	internal static object processEvent; // 0x20
	internal static object cleanupRoots; // 0x28
	internal static object endContainerGUIFromException; // 0x30
	internal static object guiChanged; // 0x38
	private static object <guiIsExiting>k__BackingField; // 0x40
	internal static object s_HasCurrentWindowKeyFocusFunc; // 0x48

	// Properties
	internal static object pixelsPerPoint { get; }
	internal static object guiDepth { get; }
	internal static object mouseUsed { set; }
	internal static object textFieldInput { get; set; }
	public static object systemCopyBuffer { get; set; }
	internal static object compositionString { get; }
	internal static object imeCompositionMode { set; }
	internal static object compositionCursorPos { set; }
	internal static object guiIsExiting { set; }
	public static object hotControl { get; set; }
	public static object keyboardControl { get; set; }

	// Methods

	// RVA: 0x74152D0
	internal static object get_pixelsPerPoint() { }

	// RVA: 0x741DE6C
	internal static object get_guiDepth() { }

	// RVA: 0x740AADC
	internal static object set_mouseUsed(object value) { }

	// RVA: 0x740051C
	internal static object get_textFieldInput() { }

	// RVA: 0x740800C
	internal static object set_textFieldInput(object value) { }

	// RVA: 0x741DEAC
	public static object get_systemCopyBuffer() { }

	// RVA: 0x741DEEC
	public static object set_systemCopyBuffer(object value) { }

	// RVA: 0x741DF3C
	private static object Internal_GetControlID(object hint, object focusType, object rect) { }

	// RVA: 0x7404CE0
	public static object GetControlID(object hint, object focusType, object rect) { }

	// RVA: 0x741E014
	internal static object BeginContainerFromOwner(object owner) { }

	// RVA: 0x741E064
	internal static object BeginContainer(object objectGUIState) { }

	// RVA: 0x741E0B4
	internal static object Internal_EndContainer() { }

	// RVA: 0x741E0F4
	internal static object CheckForTabEvent(object evt) { }

	// RVA: 0x741E144
	internal static object SetKeyboardControlToFirstControlId() { }

	// RVA: 0x741E184
	internal static object SetKeyboardControlToLastControlId() { }

	// RVA: 0x741E1C4
	internal static object HasFocusableControls() { }

	// RVA: 0x741E204
	internal static object OwnsId(object id) { }

	// RVA: 0x741E254
	public static object AlignRectToDevice(object rect, object widthInPixels, object heightInPixels) { }

	// RVA: 0x7407FCC
	internal static object get_compositionString() { }

	// RVA: 0x741E34C
	internal static object set_imeCompositionMode(object value) { }

	// RVA: 0x741E39C
	internal static object set_compositionCursorPos(object value) { }

	// RVA: 0x741E450
	private static object Internal_GetHotControl() { }

	// RVA: 0x741E490
	private static object Internal_GetKeyboardControl() { }

	// RVA: 0x741E4D0
	private static object Internal_SetHotControl(object value) { }

	// RVA: 0x741E520
	private static object Internal_SetKeyboardControl(object value) { }

	// RVA: 0x741E570
	private static object Internal_GetDefaultSkin(object skinMode) { }

	// RVA: 0x741E5C0
	private static object Internal_ExitGUI() { }

	// RVA: 0x741E600
	private static object MarkGUIChanged() { }

	// RVA: 0x74113A8
	public static object GetControlID(object focus) { }

	// RVA: 0x740593C
	public static object GetControlID(object focus, object position) { }

	// RVA: 0x74045E8
	public static object GetControlID(object hint, object focus) { }

	// RVA: 0x7406488
	public static object GetStateObject(object t, object controlID) { }

	// RVA: 0x741E668
	internal static object set_guiIsExiting(object value) { }

	// RVA: 0x7405600
	public static object get_hotControl() { }

	// RVA: 0x74055B0
	public static object set_hotControl(object value) { }

	// RVA: 0x741E6C0
	internal static object TakeCapture() { }

	// RVA: 0x741E728
	internal static object RemoveCapture() { }

	// RVA: 0x7407DD8
	public static object get_keyboardControl() { }

	// RVA: 0x7407E18
	public static object set_keyboardControl(object value) { }

	// RVA: 0x741CDF8
	internal static object HasKeyFocus(object controlID) { }

	// RVA: 0x741E790
	public static object ExitGUI() { }

	// RVA: 0x7401BC4
	internal static object GetDefaultSkin() { }

	// RVA: 0x741E86C
	internal static object ProcessEvent(object instanceID, object nativeEventPtr, object result) { }

	// RVA: 0x741E8F8
	internal static object EndContainer() { }

	// RVA: 0x741E968
	internal static object BeginGUI(object skinMode, object instanceID, object useGUILayout) { }

	// RVA: 0x741EBFC
	internal static object EndGUI(object layoutType) { }

	// RVA: 0x741EE70
	internal static object EndGUIFromException(object exception) { }

	// RVA: 0x741EFF4
	internal static object EndContainerGUIFromException(object exception) { }

	// RVA: 0x741EA2C
	internal static object ResetGlobalState() { }

	// RVA: 0x741F074
	internal static object IsExitGUIException(object exception) { }

	// RVA: 0x741EF50
	internal static object ShouldRethrowException(object exception) { }

	// RVA: 0x74017F8
	internal static object CheckOnGUI() { }

	// RVA: 0x741F110
	internal static object RoundToPixelGrid(object v) { }

	// RVA: 0x741F1A4
	public static object RotateAroundPivot(object angle, object pivotPoint) { }

	// RVA: 0x741F510
	public static object AlignRectToDevice(object rect) { }

	// RVA: 0x741F57C
	internal static object HitTest(object rect, object point, object offset) { }

	// RVA: 0x741F5C8
	internal static object HitTest(object rect, object point, object isDirectManipulationDevice) { }

	// RVA: 0x7408844
	internal static object HitTest(object rect, object evt) { }

	// RVA: 0x741DFA8
	private static object Internal_GetControlID_Injected(object hint, object focusType, object rect) { }

	// RVA: 0x741E2CC
	private static object AlignRectToDevice_Injected(object rect, object widthInPixels, object heightInPixels, object ret) { }

	// RVA: 0x741E400
	private static object set_compositionCursorPos_Injected(object value) { }

}

// Namespace: UnityEngine
public sealed class ExitGUIException
{

	// Methods

	// RVA: 0x741E7CC
	public object .ctor() { }

	// RVA: 0x7415F78
	internal object .ctor(object message) { }

}

// Namespace: UnityEngine
internal class GUILayoutEntry
{

	// Fields
	public object minWidth; // 0x8
	public object maxWidth; // 0xC
	public object minHeight; // 0x10
	public object maxHeight; // 0x14
	public object rect; // 0x18
	public object stretchWidth; // 0x28
	public object stretchHeight; // 0x2C
	public object consideredForMargin; // 0x30
	private object m_Style; // 0x38
	internal static object kDummyRect; // 0x0
	protected static object indent; // 0x10

	// Properties
	public object style { get; set; }
	public virtual object marginLeft { get; }
	public virtual object marginRight { get; }
	public virtual object marginTop { get; }
	public virtual object marginBottom { get; }
	public object marginHorizontal { get; }
	public object marginVertical { get; }

	// Methods

	// RVA: 0x741F600
	public object get_style() { }

	// RVA: 0x7415284
	public object set_style(object value) { }

	// RVA: 0x741F608
	public virtual object get_marginLeft() { }

	// RVA: 0x741F6D4
	public virtual object get_marginRight() { }

	// RVA: 0x741F7A0
	public virtual object get_marginTop() { }

	// RVA: 0x741F86C
	public virtual object get_marginBottom() { }

	// RVA: 0x741F938
	public object get_marginHorizontal() { }

	// RVA: 0x741F9A4
	public object get_marginVertical() { }

	// RVA: 0x741FA10
	public object .ctor(object _minWidth, object _maxWidth, object _minHeight, object _maxHeight, object _style) { }

	// RVA: 0x7416644
	public object .ctor(object _minWidth, object _maxWidth, object _minHeight, object _maxHeight, object _style, object options) { }

	// RVA: 0x741FAFC
	public virtual object CalcWidth() { }

	// RVA: 0x741FB00
	public virtual object CalcHeight() { }

	// RVA: 0x741FB04
	public virtual object SetHorizontal(object x, object width) { }

	// RVA: 0x741FB10
	public virtual object SetVertical(object y, object height) { }

	// RVA: 0x741FB1C
	protected virtual object ApplyStyleSettings(object style) { }

	// RVA: 0x741FC64
	public virtual object ApplyOptions(object options) { }

	// RVA: 0x741FF90
	public override object ToString() { }

	// RVA: 0x742045C
	private static object .cctor() { }

}

// Namespace: UnityEngine
internal sealed class GUIWordWrapSizer
{

	// Fields
	private readonly object m_Content; // 0x40
	private readonly object m_ForcedMinHeight; // 0x48
	private readonly object m_ForcedMaxHeight; // 0x4C

	// Methods

	// RVA: 0x74204B4
	public object .ctor(object style, object content, object options) { }

	// RVA: 0x74205A8
	public override object CalcWidth() { }

	// RVA: 0x7420658
	public override object CalcHeight() { }

}

// Namespace: UnityEngine
internal class GUILayoutGroup
{

	// Fields
	public object entries; // 0x40
	public object isVertical; // 0x48
	public object resetCoords; // 0x49
	public object spacing; // 0x4C
	public object sameSize; // 0x50
	public object isWindow; // 0x51
	public object windowID; // 0x54
	private object m_Cursor; // 0x58
	protected object m_StretchableCountX; // 0x5C
	protected object m_StretchableCountY; // 0x60
	protected object m_UserSpecifiedWidth; // 0x64
	protected object m_UserSpecifiedHeight; // 0x65
	protected object m_ChildMinWidth; // 0x68
	protected object m_ChildMaxWidth; // 0x6C
	protected object m_ChildMinHeight; // 0x70
	protected object m_ChildMaxHeight; // 0x74
	protected object m_MarginLeft; // 0x78
	protected object m_MarginRight; // 0x7C
	protected object m_MarginTop; // 0x80
	protected object m_MarginBottom; // 0x84
	private static readonly object none; // 0x0

	// Properties
	public override object marginLeft { get; }
	public override object marginRight { get; }
	public override object marginTop { get; }
	public override object marginBottom { get; }

	// Methods

	// RVA: 0x74206D8
	public override object get_marginLeft() { }

	// RVA: 0x74206E0
	public override object get_marginRight() { }

	// RVA: 0x74206E8
	public override object get_marginTop() { }

	// RVA: 0x74206F0
	public override object get_marginBottom() { }

	// RVA: 0x74206F8
	public object .ctor() { }

	// RVA: 0x7420830
	public override object ApplyOptions(object options) { }

	// RVA: 0x7420964
	protected override object ApplyStyleSettings(object style) { }

	// RVA: 0x74209F8
	public object ResetCursor() { }

	// RVA: 0x7420A00
	public object GetNext() { }

	// RVA: 0x7420B48
	public object GetLast() { }

	// RVA: 0x7420E78
	public object Add(object e) { }

	// RVA: 0x7420F98
	public override object CalcWidth() { }

	// RVA: 0x7421768
	public override object SetHorizontal(object x, object width) { }

	// RVA: 0x74221E4
	public override object CalcHeight() { }

	// RVA: 0x7422928
	public override object SetVertical(object y, object height) { }

	// RVA: 0x74233BC
	public override object ToString() { }

	// RVA: 0x7423760
	private static object .cctor() { }

}

// Namespace: UnityEngine
internal sealed class GUIScrollGroup
{

	// Fields
	public object calcMinWidth; // 0x88
	public object calcMaxWidth; // 0x8C
	public object calcMinHeight; // 0x90
	public object calcMaxHeight; // 0x94
	public object clientWidth; // 0x98
	public object clientHeight; // 0x9C
	public object allowHorizontalScroll; // 0xA0
	public object allowVerticalScroll; // 0xA1
	public object needsHorizontalScrollbar; // 0xA2
	public object needsVerticalScrollbar; // 0xA3
	public object horizontalScrollbar; // 0xA8
	public object verticalScrollbar; // 0xB0

	// Methods

	// RVA: 0x7423834
	public object .ctor() { }

	// RVA: 0x74238C4
	public override object CalcWidth() { }

	// RVA: 0x7423948
	public override object SetHorizontal(object x, object width) { }

	// RVA: 0x7423A68
	public override object CalcHeight() { }

	// RVA: 0x7423B6C
	public override object SetVertical(object y, object height) { }

}

// Namespace: UnityEngine
internal class ObjectGUIState
{

	// Fields
	internal object m_Ptr; // 0x8

	// Methods

	// RVA: 0x7423D68
	public object .ctor() { }

	// RVA: 0x7423E04
	public object Dispose() { }

	// RVA: 0x7423F38
	protected override object Finalize() { }

	// RVA: 0x7423ED0
	private object Destroy() { }

	// RVA: 0x7423DC4
	private static object Internal_Create() { }

	// RVA: 0x7424014
	private static object Internal_Destroy(object ptr) { }

}

// Namespace: UnityEngine
internal class ScrollViewState
{

	// Fields
	public object position; // 0x8
	public object visibleRect; // 0x18
	public object viewRect; // 0x28
	public object scrollPosition; // 0x38
	public object apply; // 0x40
	public object isDuringTouchScroll; // 0x41
	public object touchScrollStartMousePosition; // 0x44
	public object touchScrollStartPosition; // 0x4C
	public object velocity; // 0x54
	public object previousTimeSinceStartup; // 0x5C

	// Methods

	// RVA: 0x7424064
	public object .ctor() { }

}

// Namespace: UnityEngine
internal class SliderState
{

	// Fields
	public object dragStartPos; // 0x8
	public object dragStartValue; // 0xC
	public object isDragging; // 0x10

	// Methods

	// RVA: 0x742406C
	public object .ctor() { }

}

// Namespace: UnityEngine
internal struct SliderHandler
{

	// Fields
	private readonly object position; // 0xFFFFFFFFFFFFFFF8
	private readonly object currentValue; // 0x8
	private readonly object size; // 0xC
	private readonly object start; // 0x10
	private readonly object end; // 0x14
	private readonly object slider; // 0x18
	private readonly object thumb; // 0x20
	private readonly object thumbExtent; // 0x28
	private readonly object horiz; // 0x30
	private readonly object id; // 0x34

	// Methods

	// RVA: 0x74240B0
	public object .ctor(object position, object currentValue, object size, object start, object end, object slider, object thumb, object horiz, object id, object thumbExtent) { }

	// RVA: 0x74240F8
	public object Handle() { }

	// RVA: 0x7424220
	private object OnMouseDown() { }

	// RVA: 0x742468C
	private object OnMouseDrag() { }

	// RVA: 0x7424804
	private object OnMouseUp() { }

	// RVA: 0x7424864
	private object OnRepaint() { }

	// RVA: 0x74241E4
	private object CurrentEventType() { }

	// RVA: 0x7425168
	private object CurrentScrollTroughSide() { }

	// RVA: 0x7424F28
	private object IsEmptySlider() { }

	// RVA: 0x7425010
	private object SupportsPageMovements() { }

	// RVA: 0x7425208
	private object PageMovementValue() { }

	// RVA: 0x74257A4
	private object PageUpMovementBound() { }

	// RVA: 0x7424F20
	private object CurrentEvent() { }

	// RVA: 0x7425324
	private object ValueForCurrentMousePosition() { }

	// RVA: 0x7425418
	private object Clamp(object value) { }

	// RVA: 0x7424EC4
	private object ThumbSelectionRect() { }

	// RVA: 0x7424F64
	private object StartDraggingWithValue(object dragStartValue) { }

	// RVA: 0x7425094
	private object SliderState() { }

	// RVA: 0x7425608
	private object ThumbExtRect() { }

	// RVA: 0x74256B4
	private object ThumbRect() { }

	// RVA: 0x7425940
	private object VerticalThumbRect() { }

	// RVA: 0x7425AA8
	private object HorizontalThumbRect() { }

	// RVA: 0x7424F38
	private object ClampedCurrentValue() { }

	// RVA: 0x742544C
	private object MousePosition() { }

	// RVA: 0x74254C8
	private object ValuesPerPixel() { }

	// RVA: 0x7425C28
	private object ThumbSize() { }

	// RVA: 0x7425880
	private object MaxValue() { }

	// RVA: 0x7425870
	private object MinValue() { }

}

// Namespace: UnityEngine
internal enum TextEditOp
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MoveLeft;
	public const object MoveRight;
	public const object MoveUp;
	public const object MoveDown;
	public const object MoveLineStart;
	public const object MoveLineEnd;
	public const object MoveTextStart;
	public const object MoveTextEnd;
	public const object MovePageUp;
	public const object MovePageDown;
	public const object MoveGraphicalLineStart;
	public const object MoveGraphicalLineEnd;
	public const object MoveWordLeft;
	public const object MoveWordRight;
	public const object MoveParagraphForward;
	public const object MoveParagraphBackward;
	public const object MoveToStartOfNextWord;
	public const object MoveToEndOfPreviousWord;
	public const object Delete;
	public const object Backspace;
	public const object DeleteWordBack;
	public const object DeleteWordForward;
	public const object DeleteLineBack;
	public const object Cut;
	public const object Paste;
	public const object ScrollStart;
	public const object ScrollEnd;
	public const object ScrollPageUp;
	public const object ScrollPageDown;
}

// Namespace: UnityEngine
internal enum TextSelectOp
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SelectLeft;
	public const object SelectRight;
	public const object SelectUp;
	public const object SelectDown;
	public const object SelectTextStart;
	public const object SelectTextEnd;
	public const object SelectPageUp;
	public const object SelectPageDown;
	public const object ExpandSelectGraphicalLineStart;
	public const object ExpandSelectGraphicalLineEnd;
	public const object SelectGraphicalLineStart;
	public const object SelectGraphicalLineEnd;
	public const object SelectWordLeft;
	public const object SelectWordRight;
	public const object SelectToEndOfPreviousWord;
	public const object SelectToStartOfNextWord;
	public const object SelectParagraphBackward;
	public const object SelectParagraphForward;
	public const object Copy;
	public const object SelectAll;
	public const object SelectNone;
}

// Namespace: UnityEngine
internal class TextEditingUtilities
{

	// Fields
	private object m_TextSelectingUtility; // 0x8
	private object m_TextHandle; // 0x10
	private object m_CursorIndexSavedState; // 0x18
	internal object isCompositionActive; // 0x1C
	private object m_UpdateImeWindowPosition; // 0x1D
	public object multiline; // 0x1E
	private object m_Text; // 0x20
	private static object s_KeyEditOps; // 0x0

	// Properties
	private object hasSelection { get; }
	internal object revealCursor { set; }
	private object cursorIndex { get; set; }
	private object selectIndex { get; set; }
	public object text { get; set; }

	// Methods

	// RVA: 0x7425E40
	private object get_hasSelection() { }

	// RVA: 0x7425F00
	internal object set_revealCursor(object value) { }

	// RVA: 0x7425F74
	private object get_cursorIndex() { }

	// RVA: 0x7426040
	private object set_cursorIndex(object value) { }

	// RVA: 0x74260B4
	private object get_selectIndex() { }

	// RVA: 0x7426180
	private object set_selectIndex(object value) { }

	// RVA: 0x74261F4
	public object get_text() { }

	// RVA: 0x74261FC
	public object set_text(object value) { }

	// RVA: 0x74262AC
	public object .ctor(object selectingUtilities, object textHandle, object text) { }

	// RVA: 0x74262F8
	public object UpdateImeState() { }

	// RVA: 0x74265C4
	public object ShouldUpdateImeWindowPosition() { }

	// RVA: 0x74265CC
	public object SetImeWindowPosition(object worldPosition) { }

	// RVA: 0x7426674
	public object GeneratePreviewString(object richText) { }

	// RVA: 0x7426910
	public object EnableCursorPreviewState() { }

	// RVA: 0x7426874
	public object RestoreCursorState() { }

	// RVA: 0x7426A2C
	internal object HandleKeyEvent(object e) { }

	// RVA: 0x7428018
	private object PerformOperation(object operation) { }

	// RVA: 0x742B1D0
	private static object MapKey(object key, object action) { }

	// RVA: 0x7426BD8
	private object InitKeyActions() { }

	// RVA: 0x742AC30
	public object DeleteLineBack() { }

	// RVA: 0x742A958
	public object DeleteWordBack() { }

	// RVA: 0x742AF30
	public object DeleteWordForward() { }

	// RVA: 0x742A2C8
	public object Delete() { }

	// RVA: 0x742A568
	public object Backspace() { }

	// RVA: 0x742B270
	public object DeleteSelection() { }

	// RVA: 0x74263A0
	public object ReplaceSelection(object replace) { }

	// RVA: 0x742BE04
	public object Insert(object c) { }

	// RVA: 0x742BE84
	public object CanPaste() { }

	// RVA: 0x742A810
	public object Cut() { }

	// RVA: 0x742A848
	public object Paste() { }

	// RVA: 0x742BF74
	private static object ReplaceNewlinesWithSpaces(object value) { }

	// RVA: 0x742C030
	internal object OnBlur() { }

	// RVA: 0x742C184
	internal object TouchScreenKeyboardShouldBeUsed() { }

}

// Namespace: 
public enum DblClickSnapping
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WORDS;
	public const object PARAGRAPHS;
}

// Namespace: 
private enum CharacterType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LetterLike;
	public const object Symbol;
	public const object Symbol2;
	public const object WhiteSpace;
}

// Namespace: 
private enum Direction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Forward;
	public const object Backward;
}

// Namespace: 
private enum TextEditOp
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MoveLeft;
	public const object MoveRight;
	public const object MoveUp;
	public const object MoveDown;
	public const object MoveLineStart;
	public const object MoveLineEnd;
	public const object MoveTextStart;
	public const object MoveTextEnd;
	public const object MovePageUp;
	public const object MovePageDown;
	public const object MoveGraphicalLineStart;
	public const object MoveGraphicalLineEnd;
	public const object MoveWordLeft;
	public const object MoveWordRight;
	public const object MoveParagraphForward;
	public const object MoveParagraphBackward;
	public const object MoveToStartOfNextWord;
	public const object MoveToEndOfPreviousWord;
	public const object SelectLeft;
	public const object SelectRight;
	public const object SelectUp;
	public const object SelectDown;
	public const object SelectTextStart;
	public const object SelectTextEnd;
	public const object SelectPageUp;
	public const object SelectPageDown;
	public const object ExpandSelectGraphicalLineStart;
	public const object ExpandSelectGraphicalLineEnd;
	public const object SelectGraphicalLineStart;
	public const object SelectGraphicalLineEnd;
	public const object SelectWordLeft;
	public const object SelectWordRight;
	public const object SelectToEndOfPreviousWord;
	public const object SelectToStartOfNextWord;
	public const object SelectParagraphBackward;
	public const object SelectParagraphForward;
	public const object Delete;
	public const object Backspace;
	public const object DeleteWordBack;
	public const object DeleteWordForward;
	public const object DeleteLineBack;
	public const object Cut;
	public const object Copy;
	public const object Paste;
	public const object SelectAll;
	public const object SelectNone;
	public const object ScrollStart;
	public const object ScrollEnd;
	public const object ScrollPageUp;
	public const object ScrollPageDown;
}

// Namespace: UnityEngine
public class TextEditor
{

	// Fields
	public object keyboardOnScreen; // 0x8
	public object controlID; // 0x10
	public object style; // 0x18
	public object multiline; // 0x20
	public object hasHorizontalCursorPos; // 0x21
	public object isPasswordField; // 0x22
	internal object m_HasFocus; // 0x23
	public object scrollOffset; // 0x24
	private object m_Content; // 0x30
	private object m_Position; // 0x38
	private object m_CursorIndex; // 0x48
	private object m_SelectIndex; // 0x4C
	private object m_RevealCursor; // 0x50
	public object graphicalCursorPos; // 0x54
	public object graphicalSelectCursorPos; // 0x5C
	private object m_MouseDragSelectsWholeWords; // 0x64
	private object m_DblClickInitPos; // 0x68
	private object m_DblClickSnap; // 0x6C
	private object m_bJustSelected; // 0x6D
	private object m_iAltCursorPos; // 0x70
	private object oldText; // 0x78
	private object oldPos; // 0x80
	private object oldSelectPos; // 0x84
	private static object s_Keyactions; // 0x0

	// Properties
	public object text { get; set; }
	public object position { get; set; }
	internal virtual object localPosition { get; }
	public object cursorIndex { get; set; }
	public object selectIndex { get; set; }
	public object hasSelection { get; }

	// Methods

	// RVA: 0x742C228
	public object get_text() { }

	// RVA: 0x742C24C
	public object set_text(object value) { }

	// RVA: 0x742C414
	public object get_position() { }

	// RVA: 0x742C420
	public object set_position(object value) { }

	// RVA: 0x742C88C
	internal virtual object get_localPosition() { }

	// RVA: 0x742C898
	public object get_cursorIndex() { }

	// RVA: 0x742C8A0
	public object set_cursorIndex(object value) { }

	// RVA: 0x742C97C
	public object get_selectIndex() { }

	// RVA: 0x742C984
	public object set_selectIndex(object value) { }

	// RVA: 0x742CA50
	private object ClearCursorPos() { }

	// RVA: 0x742CA60
	public object .ctor() { }

	// RVA: 0x742CB60
	public object OnFocus() { }

	// RVA: 0x742CC54
	public object OnLostFocus() { }

	// RVA: 0x742CCB4
	private object GrabGraphicalCursorPos() { }

	// RVA: 0x742CD88
	public object HandleKeyEvent(object e) { }

	// RVA: 0x742CD90
	internal object HandleKeyEvent(object e, object textIsReadOnly) { }

	// RVA: 0x742F6B8
	public object DeleteLineBack() { }

	// RVA: 0x742F9D8
	public object DeleteWordBack() { }

	// RVA: 0x742FBC4
	public object DeleteWordForward() { }

	// RVA: 0x742FEC8
	public object Delete() { }

	// RVA: 0x74300E0
	public object Backspace() { }

	// RVA: 0x742CBF8
	public object SelectAll() { }

	// RVA: 0x74302AC
	public object SelectNone() { }

	// RVA: 0x742F7D4
	public object get_hasSelection() { }

	// RVA: 0x742F7E4
	public object DeleteSelection() { }

	// RVA: 0x74302DC
	public object ReplaceSelection(object replace) { }

	// RVA: 0x7430394
	public object Insert(object c) { }

	// RVA: 0x7430414
	public object MoveRight() { }

	// RVA: 0x74304EC
	public object MoveLeft() { }

	// RVA: 0x7430564
	public object MoveUp() { }

	// RVA: 0x7430640
	public object MoveDown() { }

	// RVA: 0x7430768
	public object MoveLineStart() { }

	// RVA: 0x74307FC
	public object MoveLineEnd() { }

	// RVA: 0x74308C0
	public object MoveGraphicalLineStart() { }

	// RVA: 0x74309E4
	public object MoveGraphicalLineEnd() { }

	// RVA: 0x7430B20
	public object MoveTextStart() { }

	// RVA: 0x7430B4C
	public object MoveTextEnd() { }

	// RVA: 0x7430BA0
	private object IndexOfEndOfLine(object startIndex) { }

	// RVA: 0x7430C28
	public object MoveParagraphForward() { }

	// RVA: 0x7430CC4
	public object MoveParagraphBackward() { }

	// RVA: 0x7430D5C
	public object MoveCursorToPosition(object cursorPosition) { }

	// RVA: 0x7430DB8
	protected internal object MoveCursorToPosition_Internal(object cursorPosition, object shift) { }

	// RVA: 0x7430E80
	public object SelectToPosition(object cursorPosition) { }

	// RVA: 0x74313E8
	public object SelectLeft() { }

	// RVA: 0x7431448
	public object SelectRight() { }

	// RVA: 0x74314A8
	public object SelectUp() { }

	// RVA: 0x743152C
	public object SelectDown() { }

	// RVA: 0x74315D8
	public object SelectTextEnd() { }

	// RVA: 0x743161C
	public object SelectTextStart() { }

	// RVA: 0x7431624
	public object MouseDragSelectsWholeWords(object on) { }

	// RVA: 0x7431634
	public object DblClickSnap(object snapping) { }

	// RVA: 0x7430904
	private object GetGraphicalLineStart(object p) { }

	// RVA: 0x7430A28
	private object GetGraphicalLineEnd(object p) { }

	// RVA: 0x743163C
	private object FindNextSeperator(object startPos) { }

	// RVA: 0x7431840
	private object FindPrevSeperator(object startPos) { }

	// RVA: 0x74318EC
	public object MoveWordRight() { }

	// RVA: 0x743194C
	public object MoveToStartOfNextWord() { }

	// RVA: 0x74319A0
	public object MoveToEndOfPreviousWord() { }

	// RVA: 0x7431A34
	public object SelectToStartOfNextWord() { }

	// RVA: 0x7431A6C
	public object SelectToEndOfPreviousWord() { }

	// RVA: 0x74316EC
	private object ClassifyChar(object index) { }

	// RVA: 0x742FCB4
	public object FindStartOfNextWord(object p) { }

	// RVA: 0x742FAC0
	private object FindEndOfPreviousWord(object p) { }

	// RVA: 0x7431AA4
	public object MoveWordLeft() { }

	// RVA: 0x7431AF0
	public object SelectWordRight() { }

	// RVA: 0x7431BB0
	public object SelectWordLeft() { }

	// RVA: 0x7431C58
	public object ExpandSelectGraphicalLineStart() { }

	// RVA: 0x7431CC0
	public object ExpandSelectGraphicalLineEnd() { }

	// RVA: 0x7431D28
	public object SelectGraphicalLineStart() { }

	// RVA: 0x7431D60
	public object SelectGraphicalLineEnd() { }

	// RVA: 0x7431D98
	public object SelectParagraphForward() { }

	// RVA: 0x7431E48
	public object SelectParagraphBackward() { }

	// RVA: 0x7431F20
	public object SelectCurrentWord() { }

	// RVA: 0x7431224
	private object FindEndOfClassification(object p, object dir) { }

	// RVA: 0x7431F98
	public object SelectCurrentParagraph() { }

	// RVA: 0x7432054
	public object UpdateScrollOffsetIfNeeded(object evt) { }

	// RVA: 0x742C4E8
	internal object UpdateScrollOffset() { }

	// RVA: 0x74320BC
	public object DrawCursor(object newText) { }

	// RVA: 0x742EF6C
	private object PerformOperation(object operation, object textIsReadOnly) { }

	// RVA: 0x7432608
	public object SaveBackup() { }

	// RVA: 0x74324B8
	public object Cut() { }

	// RVA: 0x74324EC
	public object Copy() { }

	// RVA: 0x743264C
	private static object ReplaceNewlinesWithSpaces(object value) { }

	// RVA: 0x7432578
	public object Paste() { }

	// RVA: 0x7432708
	private static object MapKey(object key, object action) { }

	// RVA: 0x742CED0
	private object InitKeyActions() { }

	// RVA: 0x74304AC
	public object DetectFocusChange() { }

	// RVA: 0x74327A8
	internal virtual object OnDetectFocusChange() { }

	// RVA: 0x7432858
	internal virtual object OnCursorIndexChange() { }

	// RVA: 0x743285C
	internal virtual object OnSelectIndexChange() { }

	// RVA: 0x7432860
	private object ClampTextIndex(object index) { }

	// RVA: 0x742C388
	private object EnsureValidCodePointIndex(object index) { }

	// RVA: 0x74328C4
	private object IsValidCodePointIndex(object index) { }

	// RVA: 0x74301D0
	private object PreviousCodePointIndex(object index) { }

	// RVA: 0x742FFC4
	private object NextCodePointIndex(object index) { }

}

// Namespace: 
private enum CharacterType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LetterLike;
	public const object Symbol;
	public const object Symbol2;
	public const object WhiteSpace;
	public const object NewLine;
}

// Namespace: 
private enum Direction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Forward;
	public const object Backward;
}

// Namespace: UnityEngine
internal class TextSelectingUtilities
{

	// Fields
	public object dblClickSnap; // 0x8
	public object iAltCursorPos; // 0xC
	public object hasHorizontalCursorPos; // 0x10
	private object m_bJustSelected; // 0x11
	private object m_MouseDragSelectsWholeWords; // 0x12
	private object m_DblClickInitPos; // 0x14
	private object m_TextHandle; // 0x18
	private const object kMoveDownHeight;
	private const object kNewLineChar;
	private object m_RevealCursor; // 0x20
	private object m_CursorIndex; // 0x24
	internal object m_SelectIndex; // 0x28
	private static object s_KeySelectOps; // 0x0
	internal object OnCursorIndexChange; // 0x30
	internal object OnSelectIndexChange; // 0x38
	internal object OnRevealCursorChange; // 0x40

	// Properties
	public object hasSelection { get; }
	public object revealCursor { get; set; }
	private object m_CharacterCount { get; }
	private object characterCount { get; }
	private object m_TextElementInfos { get; }
	public object cursorIndex { get; set; }
	public object selectIndex { get; set; }
	public object selectedText { get; }

	// Methods

	// RVA: 0x7425E60
	public object get_hasSelection() { }

	// RVA: 0x74329FC
	public object get_revealCursor() { }

	// RVA: 0x7425F48
	public object set_revealCursor(object value) { }

	// RVA: 0x7432A04
	private object get_m_CharacterCount() { }

	// RVA: 0x7432A44
	private object get_characterCount() { }

	// RVA: 0x7432B54
	private object get_m_TextElementInfos() { }

	// RVA: 0x7425FE4
	public object get_cursorIndex() { }

	// RVA: 0x7426088
	public object set_cursorIndex(object value) { }

	// RVA: 0x742BDE4
	internal object SetCursorIndexWithoutNotify(object index) { }

	// RVA: 0x7426124
	public object get_selectIndex() { }

	// RVA: 0x74261C8
	public object set_selectIndex(object value) { }

	// RVA: 0x742BDEC
	internal object SetSelectIndexWithoutNotify(object index) { }

	// RVA: 0x7432BF0
	public object get_selectedText() { }

	// RVA: 0x7432EF8
	public object .ctor(object textHandle) { }

	// RVA: 0x7432F40
	internal object HandleKeyEvent(object e) { }

	// RVA: 0x7433D6C
	private object PerformOperation(object operation) { }

	// RVA: 0x7435B8C
	private static object MapKey(object key, object action) { }

	// RVA: 0x7433078
	private object InitKeyActions() { }

	// RVA: 0x742BDF4
	public object ClearCursorPos() { }

	// RVA: 0x7435C2C
	public object OnFocus(object selectAll) { }

	// RVA: 0x7435B14
	public object SelectAll() { }

	// RVA: 0x742C0FC
	public object SelectNone() { }

	// RVA: 0x74341F0
	public object SelectLeft() { }

	// RVA: 0x74343E8
	public object SelectRight() { }

	// RVA: 0x74345E0
	public object SelectUp() { }

	// RVA: 0x7434694
	public object SelectDown() { }

	// RVA: 0x7434E68
	public object SelectTextEnd() { }

	// RVA: 0x7434E40
	public object SelectTextStart() { }

	// RVA: 0x7434DA4
	public object SelectToStartOfNextWord() { }

	// RVA: 0x7434D08
	public object SelectToEndOfPreviousWord() { }

	// RVA: 0x7434748
	public object SelectWordRight() { }

	// RVA: 0x7434A28
	public object SelectWordLeft() { }

	// RVA: 0x7435900
	public object SelectGraphicalLineStart() { }

	// RVA: 0x7435A00
	public object SelectGraphicalLineEnd() { }

	// RVA: 0x74353B8
	public object SelectParagraphForward() { }

	// RVA: 0x7435648
	public object SelectParagraphBackward() { }

	// RVA: 0x7435E58
	public object SelectCurrentWord() { }

	// RVA: 0x7436154
	public object SelectCurrentParagraph() { }

	// RVA: 0x742876C
	public object MoveRight() { }

	// RVA: 0x742850C
	public object MoveLeft() { }

	// RVA: 0x74289D8
	public object MoveUp() { }

	// RVA: 0x7428C50
	public object MoveDown() { }

	// RVA: 0x7428ED8
	public object MoveLineStart() { }

	// RVA: 0x74290CC
	public object MoveLineEnd() { }

	// RVA: 0x7429F3C
	public object MoveGraphicalLineStart() { }

	// RVA: 0x742A0F8
	public object MoveGraphicalLineEnd() { }

	// RVA: 0x74299BC
	public object MoveTextStart() { }

	// RVA: 0x7429A28
	public object MoveTextEnd() { }

	// RVA: 0x7429AAC
	public object MoveParagraphForward() { }

	// RVA: 0x7429CEC
	public object MoveParagraphBackward() { }

	// RVA: 0x74292DC
	public object MoveWordRight() { }

	// RVA: 0x74294EC
	public object MoveToStartOfNextWord() { }

	// RVA: 0x742965C
	public object MoveToEndOfPreviousWord() { }

	// RVA: 0x74297CC
	public object MoveWordLeft() { }

	// RVA: 0x7434EB8
	public object ExpandSelectGraphicalLineStart() { }

	// RVA: 0x7435124
	public object ExpandSelectGraphicalLineEnd() { }

	// RVA: 0x7436494
	protected internal object MoveCursorToPosition_Internal(object cursorPosition, object shift) { }

	// RVA: 0x743656C
	public object SelectToPosition(object cursorPosition) { }

	// RVA: 0x7436354
	private object FindNextSeperator(object startPos) { }

	// RVA: 0x74363E8
	private object FindPrevSeperator(object startPos) { }

	// RVA: 0x742B92C
	public object FindStartOfNextWord(object p) { }

	// RVA: 0x742B804
	public object FindEndOfPreviousWord(object p) { }

	// RVA: 0x7436004
	private object FindEndOfClassification(object p, object dir) { }

	// RVA: 0x7436A78
	private object ClampTextIndex(object index) { }

	// RVA: 0x7432B94
	internal object EnsureValidCodePointIndex(object index) { }

	// RVA: 0x7436AA8
	private object IsValidCodePointIndex(object index) { }

	// RVA: 0x7435E00
	private object IndexOfEndOfLine(object startIndex) { }

	// RVA: 0x742BCC8
	public object PreviousCodePointIndex(object index) { }

	// RVA: 0x742BBA4
	public object NextCodePointIndex(object index) { }

	// RVA: 0x7435CEC
	private object GetGraphicalLineStart(object p) { }

	// RVA: 0x7435D6C
	private object GetGraphicalLineEnd(object p) { }

	// RVA: 0x742BEB8
	public object Copy() { }

	// RVA: 0x74368D0
	private object ClassifyChar(object index) { }

}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Methods

	// RVA: 0x7436BCC
	internal static object ComputeStringHash(object s) { }

}

