// Namespace: 
internal class <Module>
{
}

// Namespace: 
public class AnimatorControlAsset
{

	// Fields
	public object sourceGameObject; // 0x10
	public object controlChildren; // 0x20
	public object simulateWhenActived; // 0x21

	// Properties
	public object clipCaps { get; }

	// Methods

	// RVA: 0x72EE18C
	public object get_clipCaps() { }

	// RVA: 0x72EE194
	public override object CreatePlayable(object graph, object go) { }

	// RVA: -1
	internal object GetComponent(object gameObject) { }

	// RVA: 0x72EE204
	private static object ConnectPlayablesToMixer(object graph, object playables) { }

	// RVA: 0x72EE3C0
	private static object ConnectMixerAndPlayable(object graph, object mixer, object playable, object portIndex) { }

	// RVA: 0x72EE48C
	public object .ctor() { }

}

// Namespace: 
public class AnimatorControlTrack
{

	// Methods

	// RVA: 0x72EE49C
	public object .ctor() { }

}

// Namespace: 
public class ParticleSystemControlAsset
{

	// Fields
	private const object k_MaxRandInt;
	public object sourceGameObject; // 0x10
	public object particleRandomSeed; // 0x20
	public object bindingPath; // 0x28

	// Properties
	public object clipCaps { get; }

	// Methods

	// RVA: 0x72EE5F4
	public object get_clipCaps() { }

	// RVA: 0x72EE5FC
	public object OnEnable() { }

	// RVA: 0x72EE638
	public override object CreatePlayable(object graph, object go) { }

	// RVA: 0x72EE8E4
	public object GatherProperties(object director, object driver) { }

	// RVA: 0x72EEFFC
	public object .ctor() { }

}

// Namespace: 
public class ParticleSystemControlPlayable
{

	// Fields
	private const object kUnsetTime;
	private object m_particleSystemArray; // 0x8
	private object m_activeStartTime; // 0x10
	private object m_lastPlayableTime; // 0x18
	private object m_lastParticleTime; // 0x20
	private const object kDefaultActiveStartTime;
	private object m_PlayableDirector; // 0x28
	private object m_FPS; // 0x30

	// Methods

	// RVA: 0x72EE7B0
	public static object Create(object graph, object particles, object randomSeed) { }

	// RVA: 0x72EF004
	public object Initialize(object particles, object randomSeed) { }

	// RVA: 0x72EF4C8
	public override object OnPlayableCreate(object playable) { }

	// RVA: 0x72EF6E0
	private object InitDirector(object playable) { }

	// RVA: 0x72EF3A0
	private object SetRandomSeed(object particles, object randomSeed) { }

	// RVA: 0x72EF82C
	public override object OnGraphStart(object playable) { }

	// RVA: 0x72EF95C
	public override object PrepareFrame(object playable, object data) { }

	// RVA: 0x72EFE2C
	public override object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x72EF9F0
	private object ProcessParticles(object playableTime, object evaluationType, object startPlay) { }

	// RVA: 0x72EFEC0
	private static object Simulate(object particleSystem, object time, object restart) { }

	// RVA: 0x72EFFA8
	public object .ctor() { }

}

// Namespace: 
public class ParticleSystemControlTrack
{

	// Methods

	// RVA: 0x72EFFB8
	protected override object CreatePlayable(object graph, object gameObject, object clip) { }

	// RVA: 0x72F00A4
	private object BindingRuntimeObject(object graph, object gameObject, object clip) { }

	// RVA: 0x72F08B4
	protected override object OnCreateClip(object clip) { }

	// RVA: 0x72F08BC
	public object .ctor() { }

}

// Namespace: 
public class AnimatorControlPlayable
{

	// Fields
	private object <animator>k__BackingField; // 0x8
	private const object kUnsetTime;
	private object m_LastPlayableTime; // 0x10
	private object m_LastAnimatorTime; // 0x14
	private object m_UndoSimulateTime; // 0x18
	private object m_StateNameHash; // 0x1C
	private const object kDefaultActiveStartTime;
	private object m_ActiveStartTime; // 0x20
	private object m_SimulateWhenActived; // 0x24

	// Properties
	public object animator { get; set; }

	// Methods

	// RVA: 0x72F093C
	public object get_animator() { }

	// RVA: 0x72F0944
	private object set_animator(object value) { }

	// RVA: 0x72F094C
	public static object Create(object graph, object component, object simulateWhenActived) { }

	// RVA: 0x72F0AA8
	public object Initialize(object component, object simulateWhenActived) { }

	// RVA: 0x72F0AB8
	public override object PrepareFrame(object playable, object data) { }

	// RVA: 0x72F0D54
	private object InitStateNameHash() { }

	// RVA: 0x72F1114
	public override object OnBehaviourPlay(object playable, object info) { }

	// RVA: 0x72F1120
	public override object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x72F0FA4
	private object Simulate(object time, object restart) { }

	// RVA: 0x72F0E78
	private object GetCurStateTime() { }

	// RVA: 0x72F112C
	public object .ctor() { }

}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0x72F1140
	private static object Get() { }

	// RVA: 0x72F1210
	public object .ctor() { }

}

// Namespace: Unity.Timeline
public static class TimelineRunTimeHelpersEx
{

	// Methods

	// RVA: 0x72F134C
	public static object ToFrames(object time) { }

}

// Namespace: UnityEngine.Timeline
internal class ActivationMixerPlayable
{

	// Fields
	private object m_PostPlaybackState; // 0x8
	private object m_BoundGameObjectInitialStateIsActive; // 0xC
	private object m_BoundGameObject; // 0x10

	// Properties
	public object postPlaybackState { get; set; }

	// Methods

	// RVA: 0x72F13B8
	public static object Create(object graph, object inputCount) { }

	// RVA: 0x72F1448
	public object get_postPlaybackState() { }

	// RVA: 0x72F1450
	public object set_postPlaybackState(object value) { }

	// RVA: 0x72F1458
	public override object OnPlayableDestroy(object playable) { }

	// RVA: 0x72F1590
	public override object ProcessFrame(object playable, object info, object playerData) { }

	// RVA: 0x72F1804
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
internal class ActivationPlayableAsset
{

	// Properties
	public object clipCaps { get; }

	// Methods

	// RVA: 0x72F180C
	public object get_clipCaps() { }

	// RVA: 0x72F1814
	public override object CreatePlayable(object graph, object go) { }

	// RVA: 0x72F1884
	public object .ctor() { }

}

// Namespace: 
public enum PostPlaybackState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Active;
	public const object Inactive;
	public const object Revert;
	public const object LeaveAsIs;
}

// Namespace: UnityEngine.Timeline
public class ActivationTrack
{

	// Fields
	private object m_PostPlaybackState; // 0x98
	private object m_ActivationMixer; // 0xA0

	// Properties
	public object postPlaybackState { get; set; }

	// Methods

	// RVA: 0x72F188C
	internal override object CanCompileClips() { }

	// RVA: 0x72F1A50
	public object get_postPlaybackState() { }

	// RVA: 0x72F1A58
	public object set_postPlaybackState(object value) { }

	// RVA: 0x72F1A80
	public override object CreateTrackMixer(object graph, object go, object inputCount) { }

	// RVA: 0x72F1A6C
	internal object UpdateTrackMode() { }

	// RVA: 0x72F1BD8
	public override object GatherProperties(object director, object driver) { }

	// RVA: 0x72F1F58
	protected override object OnCreateClip(object clip) { }

	// RVA: 0x72F1FB4
	public object .ctor() { }

}

// Namespace: 
private struct WeightInfo
{

	// Fields
	public object mixer; // 0xFFFFFFFFFFFFFFF8
	public object parentMixer; // 0x8
	public object port; // 0x18
}

// Namespace: UnityEngine.Timeline
internal class AnimationOutputWeightProcessor
{

	// Fields
	private object m_Output; // 0x8
	private object m_MotionXPlayable; // 0x18
	private readonly object m_Mixers; // 0x28

	// Methods

	// RVA: 0x72F2044
	public object .ctor(object output) { }

	// RVA: 0x72F2110
	private object FindMixers() { }

	// RVA: 0x72F2200
	private object FindMixers(object parent, object port, object node) { }

	// RVA: 0x72F256C
	public object Evaluate() { }

}

// Namespace: 
public enum LoopMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UseSourceAsset;
	public const object On;
	public const object Off;
}

// Namespace: 
private enum Versions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Initial;
	public const object RotationAsEuler;
}

// Namespace: 
private static class AnimationPlayableAssetUpgrade
{

	// Methods

	// RVA: 0x72F3704
	public static object ConvertRotationToEuler(object asset) { }

}

// Namespace: 
private sealed class <get_outputs>d__45
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x30
	public object <>4__this; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x72F2C10
	public object .ctor(object <>1__state) { }

	// RVA: 0x72F38DC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x72F38E0
	private object MoveNext() { }

	// RVA: 0x72F3978
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.get_Current() { }

	// RVA: 0x72F3984
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x72F39C4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x72F3A2C
	private object System.Collections.Generic.IEnumerable<UnityEngine.Playables.PlayableBinding>.GetEnumerator() { }

	// RVA: 0x72F3AD8
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.Timeline
public class AnimationPlayableAsset
{

	// Fields
	private object m_Clip; // 0x10
	private object m_Position; // 0x18
	private object m_EulerAngles; // 0x24
	private object m_UseTrackMatchFields; // 0x30
	private object m_MatchTargetFields; // 0x34
	private object m_RemoveStartOffset; // 0x38
	private object m_ApplyFootIK; // 0x39
	private object m_Loop; // 0x3C
	private object <appliedOffsetMode>k__BackingField; // 0x40
	private static readonly object k_LatestVersion; // 0x0
	private object m_Version; // 0x44
	private object m_Rotation; // 0x48

	// Properties
	public object position { get; set; }
	public object rotation { get; set; }
	public object eulerAngles { get; set; }
	public object useTrackMatchFields { get; set; }
	public object matchTargetFields { get; set; }
	public object removeStartOffset { get; set; }
	public object applyFootIK { get; set; }
	public object loop { get; set; }
	internal object hasRootTransforms { get; }
	internal object appliedOffsetMode { get; set; }
	public object clip { get; set; }
	public override object duration { get; }
	public override object outputs { get; }
	public object clipCaps { get; }

	// Methods

	// RVA: 0x72F26E8
	public object get_position() { }

	// RVA: 0x72F26F4
	public object set_position(object value) { }

	// RVA: 0x72F2700
	public object get_rotation() { }

	// RVA: 0x72F272C
	public object set_rotation(object value) { }

	// RVA: 0x72F2778
	public object get_eulerAngles() { }

	// RVA: 0x72F2784
	public object set_eulerAngles(object value) { }

	// RVA: 0x72F2790
	public object get_useTrackMatchFields() { }

	// RVA: 0x72F2798
	public object set_useTrackMatchFields(object value) { }

	// RVA: 0x72F27A0
	public object get_matchTargetFields() { }

	// RVA: 0x72F27A8
	public object set_matchTargetFields(object value) { }

	// RVA: 0x72F27B0
	public object get_removeStartOffset() { }

	// RVA: 0x72F27B8
	public object set_removeStartOffset(object value) { }

	// RVA: 0x72F27C0
	public object get_applyFootIK() { }

	// RVA: 0x72F27C8
	public object set_applyFootIK(object value) { }

	// RVA: 0x72F27D0
	public object get_loop() { }

	// RVA: 0x72F27D8
	public object set_loop(object value) { }

	// RVA: 0x72F27E0
	internal object get_hasRootTransforms() { }

	// RVA: 0x72F29EC
	internal object get_appliedOffsetMode() { }

	// RVA: 0x72F29F4
	internal object set_appliedOffsetMode(object value) { }

	// RVA: 0x72F29FC
	public object get_clip() { }

	// RVA: 0x72F2A04
	public object set_clip(object value) { }

	// RVA: 0x72F2B00
	public override object get_duration() { }

	// RVA: 0x72F2B94
	public override object get_outputs() { }

	// RVA: 0x72F2C48
	public override object CreatePlayable(object graph, object go) { }

	// RVA: 0x72F2D34
	internal static object CreatePlayable(object graph, object clip, object positionOffset, object eulerOffset, object removeStartOffset, object mode, object applyFootIK, object loop, object cacheDefaultPos) { }

	// RVA: 0x72F31D8
	private static object ShouldApplyOffset(object mode, object clip) { }

	// RVA: 0x72F31C0
	private static object ShouldApplyScaleRemove(object mode) { }

	// RVA: 0x72F3270
	public object get_clipCaps() { }

	// RVA: 0x72F33D0
	public object ResetOffsets() { }

	// RVA: 0x72F3460
	public object GatherProperties(object director, object driver) { }

	// RVA: 0x72F28C8
	internal static object HasRootTransforms(object clip) { }

	// RVA: 0x72F3538
	private object UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize() { }

	// RVA: 0x72F35A4
	private object UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize() { }

	// RVA: 0x72F368C
	private object OnUpgradeFromVersion(object oldVersion) { }

	// RVA: 0x72F3768
	public object .ctor() { }

	// RVA: 0x72F388C
	private static object .cctor() { }

}

// Namespace: UnityEngine.Timeline
internal class AnimationPreviewUpdateCallback
{

	// Fields
	private object m_Output; // 0x8
	private object m_Graph; // 0x18
	private object m_PreviewComponents; // 0x28

	// Methods

	// RVA: 0x72F3B84
	public object .ctor(object output) { }

	// RVA: 0x72F3C50
	public object Evaluate() { }

	// RVA: 0x72F3E50
	private object FetchPreviewComponents() { }

}

// Namespace: UnityEngine.Timeline
public enum MatchTargetFields
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PositionX;
	public const object PositionY;
	public const object PositionZ;
	public const object RotationX;
	public const object RotationY;
	public const object RotationZ;
}

// Namespace: UnityEngine.Timeline
public enum TrackOffset
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ApplyTransformOffsets;
	public const object ApplySceneOffsets;
	public const object Auto;
}

// Namespace: UnityEngine.Timeline
internal enum AppliedOffsetMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoRootTransform;
	public const object TransformOffset;
	public const object SceneOffset;
	public const object TransformOffsetLegacy;
	public const object SceneOffsetLegacy;
	public const object SceneOffsetEditor;
	public const object SceneOffsetLegacyEditor;
}

// Namespace: UnityEngine.Timeline
internal static class MatchTargetFieldConstants
{

	// Fields
	public static object All; // 0x0
	public static object None; // 0x4
	public static object Position; // 0x8
	public static object Rotation; // 0xC

	// Methods

	// RVA: 0x72F3FFC
	public static object HasAny(object me, object fields) { }

	// RVA: 0x72F4074
	public static object Toggle(object me, object flag) { }

	// RVA: 0x72F407C
	private static object .cctor() { }

}

// Namespace: 
private static class AnimationTrackUpgrade
{

	// Methods

	// RVA: 0x72F9324
	public static object ConvertRotationsToEuler(object track) { }

	// RVA: 0x72F93CC
	public static object ConvertRootMotion(object track) { }

	// RVA: 0x72F947C
	public static object ConvertInfiniteTrack(object track) { }

}

// Namespace: 
private sealed class <get_outputs>d__56
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x30
	public object <>4__this; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x72F43B4
	public object .ctor(object <>1__state) { }

	// RVA: 0x72F9738
	private object System.IDisposable.Dispose() { }

	// RVA: 0x72F973C
	private object MoveNext() { }

	// RVA: 0x72F97D4
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.get_Current() { }

	// RVA: 0x72F97E0
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x72F9820
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x72F9888
	private object System.Collections.Generic.IEnumerable<UnityEngine.Playables.PlayableBinding>.GetEnumerator() { }

	// RVA: 0x72F9934
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.Timeline
public class AnimationTrack
{

	// Fields
	private const object k_DefaultInfiniteClipName;
	private const object k_DefaultRecordableClipName;
	private object m_InfiniteClipPreExtrapolation; // 0x98
	private object m_InfiniteClipPostExtrapolation; // 0x9C
	private object m_InfiniteClipOffsetPosition; // 0xA0
	private object m_InfiniteClipOffsetEulerAngles; // 0xAC
	private object m_InfiniteClipTimeOffset; // 0xB8
	private object m_InfiniteClipRemoveOffset; // 0xC0
	private object m_InfiniteClipApplyFootIK; // 0xC1
	private object mInfiniteClipLoop; // 0xC4
	private object m_MatchTargetFields; // 0xC8
	private object m_Position; // 0xCC
	private object m_EulerAngles; // 0xD8
	private object m_AvatarMask; // 0xE8
	private object m_ApplyAvatarMask; // 0xF0
	private object m_TrackOffset; // 0xF4
	private object m_InfiniteClip; // 0xF8
	private object m_cacheDefaultPos; // 0x100
	public object m_CompiledTrackPlayable; // 0x108
	public object m_UseOuterPlayableGraph; // 0x118
	public object m_OuterPlayableGraph; // 0x120
	public object m_ApplyRootMotion; // 0x130
	private static readonly object s_CachedQueue; // 0x0
	private object m_OpenClipOffsetRotation; // 0x134
	private object m_Rotation; // 0x144
	private object m_ApplyOffsets; // 0x154

	// Properties
	public object position { get; set; }
	public object rotation { get; set; }
	public object eulerAngles { get; set; }
	public object applyOffsets { get; set; }
	public object trackOffset { get; set; }
	public object matchTargetFields { get; set; }
	public object infiniteClip { get; set; }
	internal object infiniteClipRemoveOffset { get; set; }
	public object avatarMask { get; set; }
	public object applyAvatarMask { get; set; }
	public object cacheDefaultPos { get; }
	public override object outputs { get; }
	public object inClipMode { get; }
	public object infiniteClipOffsetPosition { get; set; }
	public object infiniteClipOffsetRotation { get; set; }
	public object infiniteClipOffsetEulerAngles { get; set; }
	internal object infiniteClipApplyFootIK { get; set; }
	internal object infiniteClipTimeOffset { get; set; }
	public object infiniteClipPreExtrapolation { get; set; }
	public object infiniteClipPostExtrapolation { get; set; }
	internal object infiniteClipLoop { get; set; }
	public object openClipOffsetPosition { get; set; }
	public object openClipOffsetRotation { get; set; }
	public object openClipOffsetEulerAngles { get; set; }
	public object openClipPreExtrapolation { get; set; }
	public object openClipPostExtrapolation { get; set; }

	// Methods

	// RVA: 0x72F40D0
	public object get_position() { }

	// RVA: 0x72F40DC
	public object set_position(object value) { }

	// RVA: 0x72F40E8
	public object get_rotation() { }

	// RVA: 0x72F4114
	public object set_rotation(object value) { }

	// RVA: 0x72F4160
	public object get_eulerAngles() { }

	// RVA: 0x72F416C
	public object set_eulerAngles(object value) { }

	// RVA: 0x72F4178
	public object get_applyOffsets() { }

	// RVA: 0x72F4180
	public object set_applyOffsets(object value) { }

	// RVA: 0x72F4184
	public object get_trackOffset() { }

	// RVA: 0x72F418C
	public object set_trackOffset(object value) { }

	// RVA: 0x72F4194
	public object get_matchTargetFields() { }

	// RVA: 0x72F419C
	public object set_matchTargetFields(object value) { }

	// RVA: 0x72F4210
	public object get_infiniteClip() { }

	// RVA: 0x72F4218
	internal object set_infiniteClip(object value) { }

	// RVA: 0x72F4220
	internal object get_infiniteClipRemoveOffset() { }

	// RVA: 0x72F4228
	internal object set_infiniteClipRemoveOffset(object value) { }

	// RVA: 0x72F4230
	public object get_avatarMask() { }

	// RVA: 0x72F4238
	public object set_avatarMask(object value) { }

	// RVA: 0x72F4240
	public object get_applyAvatarMask() { }

	// RVA: 0x72F4248
	public object set_applyAvatarMask(object value) { }

	// RVA: 0x72F4250
	public object get_cacheDefaultPos() { }

	// RVA: 0x72F4258
	internal override object CanCompileClips() { }

	// RVA: 0x72F4338
	public override object get_outputs() { }

	// RVA: 0x72F43EC
	public object get_inClipMode() { }

	// RVA: 0x72F450C
	public object get_infiniteClipOffsetPosition() { }

	// RVA: 0x72F4518
	public object set_infiniteClipOffsetPosition(object value) { }

	// RVA: 0x72F4524
	public object get_infiniteClipOffsetRotation() { }

	// RVA: 0x72F4550
	public object set_infiniteClipOffsetRotation(object value) { }

	// RVA: 0x72F459C
	public object get_infiniteClipOffsetEulerAngles() { }

	// RVA: 0x72F45A8
	public object set_infiniteClipOffsetEulerAngles(object value) { }

	// RVA: 0x72F45B4
	internal object get_infiniteClipApplyFootIK() { }

	// RVA: 0x72F45BC
	internal object set_infiniteClipApplyFootIK(object value) { }

	// RVA: 0x72F45C4
	internal object get_infiniteClipTimeOffset() { }

	// RVA: 0x72F45CC
	internal object set_infiniteClipTimeOffset(object value) { }

	// RVA: 0x72F45D4
	public object get_infiniteClipPreExtrapolation() { }

	// RVA: 0x72F45DC
	public object set_infiniteClipPreExtrapolation(object value) { }

	// RVA: 0x72F45E4
	public object get_infiniteClipPostExtrapolation() { }

	// RVA: 0x72F45EC
	public object set_infiniteClipPostExtrapolation(object value) { }

	// RVA: 0x72F45F4
	internal object get_infiniteClipLoop() { }

	// RVA: 0x72F45FC
	internal object set_infiniteClipLoop(object value) { }

	// RVA: 0x72F4604
	private object ResetOffsets() { }

	// RVA: 0x72F4698
	public object CreateClip(object clip) { }

	// RVA: 0x72F49DC
	public object CreateInfiniteClip(object infiniteClipName) { }

	// RVA: 0x72F4B34
	public object CreateRecordableClip(object animClipName) { }

	// RVA: 0x72F4FB0
	protected override object OnCreateClip(object clip) { }

	// RVA: 0x72F51DC
	protected internal override object CalculateItemsHash() { }

	// RVA: 0x72F4694
	internal object UpdateClipOffsets() { }

	// RVA: 0x72F54C0
	private object CompileTrackPlayable(object graph, object track, object go, object tree, object mode) { }

	// RVA: 0x72F61B8
	private object UnityEngine.Timeline.ILayerable.CreateLayerMixer(object graph, object go, object inputCount) { }

	// RVA: 0x72F6228
	internal override object CreateMixerPlayableGraph(object graph, object go, object tree) { }

	// RVA: 0x72F75BC
	private object GetDefaultBlendCount() { }

	// RVA: 0x72F7B80
	private object AttachDefaultBlend(object graph, object mixer, object requireOffset) { }

	// RVA: 0x72F7B94
	private object AttachOffsetPlayable(object graph, object playable, object pos, object rot) { }

	// RVA: 0x72F7A10
	private object RequiresMotionXPlayable(object mode, object gameObject) { }

	// RVA: 0x72F7B84
	private static object UsesAbsoluteMotion(object mode) { }

	// RVA: 0x72F7F9C
	private object HasController(object gameObject) { }

	// RVA: 0x72F7CF8
	internal object GetBinding(object director) { }

	// RVA: 0x72F75C4
	private static object CreateGroupMixer(object graph, object go, object inputCount) { }

	// RVA: 0x72F7644
	private object CreateInfiniteTrackPlayable(object graph, object go, object tree, object mode) { }

	// RVA: 0x72F5FF0
	private object ApplyTrackOffset(object graph, object root, object go, object mode) { }

	// RVA: 0x72F8164
	internal override object GetEvaluationTime(object outStart, object outDuration) { }

	// RVA: 0x72F84D4
	internal override object GetSequenceTime(object outStart, object outDuration) { }

	// RVA: 0x72F4748
	private object AssignAnimationClip(object clip, object animClip) { }

	// RVA: 0x72F8870
	public override object GatherProperties(object director, object driver) { }

	// RVA: 0x72F8874
	private object GetAnimationClips(object animClips) { }

	// RVA: 0x72F74A0
	private object GetOffsetMode(object go, object animatesRootTransform) { }

	// RVA: 0x72F7124
	private object IsRootTransformDisabledByMask(object gameObject, object genericRootNode) { }

	// RVA: 0x72F6E74
	private object GetGenericRootNode(object gameObject) { }

	// RVA: 0x72F5B6C
	internal object AnimatesRootTransform() { }

	// RVA: 0x72F8F4C
	private static object FindInHierarchyBreadthFirst(object t, object name) { }

	// RVA: 0x72F918C
	public object get_openClipOffsetPosition() { }

	// RVA: 0x72F9198
	public object set_openClipOffsetPosition(object value) { }

	// RVA: 0x72F91A4
	public object get_openClipOffsetRotation() { }

	// RVA: 0x72F91D0
	public object set_openClipOffsetRotation(object value) { }

	// RVA: 0x72F921C
	public object get_openClipOffsetEulerAngles() { }

	// RVA: 0x72F9228
	public object set_openClipOffsetEulerAngles(object value) { }

	// RVA: 0x72F9234
	public object get_openClipPreExtrapolation() { }

	// RVA: 0x72F923C
	public object set_openClipPreExtrapolation(object value) { }

	// RVA: 0x72F9244
	public object get_openClipPostExtrapolation() { }

	// RVA: 0x72F924C
	public object set_openClipPostExtrapolation(object value) { }

	// RVA: 0x72F9254
	internal override object OnUpgradeFromVersion(object oldVersion) { }

	// RVA: 0x72F94A4
	public object .ctor() { }

	// RVA: 0x72F96A4
	private static object .cctor() { }

}

// Namespace: UnityEngine.Timeline
internal interface ICurvesOwner
{

	// Properties
	public abstract object curves { get; }
	public abstract object hasCurves { get; }
	public abstract object duration { get; }
	public abstract object defaultCurvesName { get; }
	public abstract object asset { get; }
	public abstract object assetOwner { get; }
	public abstract object targetTrack { get; }

	// Methods

	// RVA: -1
	public abstract object get_curves() { }

	// RVA: -1
	public abstract object get_hasCurves() { }

	// RVA: -1
	public abstract object get_duration() { }

	// RVA: -1
	public abstract object CreateCurves(object curvesClipName) { }

	// RVA: -1
	public abstract object get_defaultCurvesName() { }

	// RVA: -1
	public abstract object get_asset() { }

	// RVA: -1
	public abstract object get_assetOwner() { }

	// RVA: -1
	public abstract object get_targetTrack() { }

}

// Namespace: 
private enum Versions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Initial;
	public const object ClipInFromGlobalToLocal;
}

// Namespace: 
private static class TimelineClipUpgrade
{

	// Methods

	// RVA: 0x72F9A1C
	public static object UpgradeClipInFromGlobalToLocal(object clip) { }

}

// Namespace: 
public enum ClipExtrapolation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Hold;
	public const object Loop;
	public const object PingPong;
	public const object Continue;
}

// Namespace: 
public enum BlendCurveMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object Manual;
}

// Namespace: UnityEngine.Timeline
public class TimelineClip
{

	// Fields
	private const object k_LatestVersion;
	private object m_Version; // 0x8
	public static readonly object kDefaultClipCaps; // 0x0
	public static readonly object kDefaultClipDurationInSeconds; // 0x4
	public static readonly object kTimeScaleMin; // 0x8
	public static readonly object kTimeScaleMax; // 0x10
	internal static readonly object kDefaultCurvesName; // 0x18
	internal static readonly object kMinDuration; // 0x20
	internal static readonly object kMaxTimeValue; // 0x28
	private object m_Start; // 0x10
	private object m_ClipIn; // 0x18
	private object m_Asset; // 0x20
	private object m_Duration; // 0x28
	private object m_TimeScale; // 0x30
	private object m_ParentTrack; // 0x38
	private object m_EaseInDuration; // 0x40
	private object m_EaseOutDuration; // 0x48
	private object m_BlendInDuration; // 0x50
	private object m_BlendOutDuration; // 0x58
	private object m_MixInCurve; // 0x60
	private object m_MixOutCurve; // 0x68
	private object m_BlendInCurveMode; // 0x70
	private object m_BlendOutCurveMode; // 0x74
	private object m_ExposedParameterNames; // 0x78
	private object m_AnimationCurves; // 0x80
	private object m_Recordable; // 0x88
	private object m_PostExtrapolationMode; // 0x8C
	private object m_PreExtrapolationMode; // 0x90
	private object m_PostExtrapolationTime; // 0x98
	private object m_PreExtrapolationTime; // 0xA0
	private object m_DisplayName; // 0xA8

	// Properties
	public object hasPreExtrapolation { get; }
	public object hasPostExtrapolation { get; }
	public object timeScale { get; set; }
	public object start { get; set; }
	public object duration { get; set; }
	public object end { get; }
	public object clipIn { get; set; }
	public object displayName { get; set; }
	public object clipAssetDuration { get; }
	public object curves { get; set; }
	private object UnityEngine.Timeline.ICurvesOwner.defaultCurvesName { get; }
	public object hasCurves { get; }
	public object asset { get; set; }
	private object UnityEngine.Timeline.ICurvesOwner.assetOwner { get; }
	private object UnityEngine.Timeline.ICurvesOwner.targetTrack { get; }
	public object underlyingAsset { get; set; }
	public object parentTrack { get; set; }
	public object easeInDuration { get; set; }
	public object easeOutDuration { get; set; }
	public object eastOutTime { get; }
	public object easeOutTime { get; }
	public object blendInDuration { get; set; }
	public object blendOutDuration { get; set; }
	public object blendInCurveMode { get; set; }
	public object blendOutCurveMode { get; set; }
	public object hasBlendIn { get; }
	public object hasBlendOut { get; }
	public object mixInCurve { get; set; }
	public object mixInPercentage { get; }
	public object mixInDuration { get; }
	public object mixOutCurve { get; set; }
	public object mixOutTime { get; }
	public object mixOutDuration { get; }
	public object mixOutPercentage { get; }
	public object recordable { get; set; }
	public object exposedParameters { get; }
	public object clipCaps { get; }
	public object animationClip { get; }
	public object postExtrapolationMode { get; set; }
	public object preExtrapolationMode { get; set; }
	public object extrapolatedStart { get; }
	public object extrapolatedDuration { get; }

	// Methods

	// RVA: 0x72F99E0
	private object UpgradeToLatestVersion() { }

	// RVA: 0x72F9A60
	internal object .ctor(object parent) { }

	// RVA: 0x72F9C54
	public object get_hasPreExtrapolation() { }

	// RVA: 0x72F9C74
	public object get_hasPostExtrapolation() { }

	// RVA: 0x72F9C94
	public object get_timeScale() { }

	// RVA: 0x72F9ED8
	public object set_timeScale(object value) { }

	// RVA: 0x72F9FEC
	public object get_start() { }

	// RVA: 0x72F4D58
	public object set_start(object value) { }

	// RVA: 0x72FA13C
	public object get_duration() { }

	// RVA: 0x72F4EC4
	public object set_duration(object value) { }

	// RVA: 0x72FA144
	public object get_end() { }

	// RVA: 0x72FA154
	public object get_clipIn() { }

	// RVA: 0x72FA180
	public object set_clipIn(object value) { }

	// RVA: 0x72FA284
	public object get_displayName() { }

	// RVA: 0x72FA28C
	public object set_displayName(object value) { }

	// RVA: 0x72FA294
	public object get_clipAssetDuration() { }

	// RVA: 0x72FA390
	public object get_curves() { }

	// RVA: 0x72FA398
	internal object set_curves(object value) { }

	// RVA: 0x72FA3A0
	private object UnityEngine.Timeline.ICurvesOwner.get_defaultCurvesName() { }

	// RVA: 0x72FA41C
	public object get_hasCurves() { }

	// RVA: 0x72FA4E4
	public object get_asset() { }

	// RVA: 0x72FA4EC
	public object set_asset(object value) { }

	// RVA: 0x72FA4F4
	private object UnityEngine.Timeline.ICurvesOwner.get_assetOwner() { }

	// RVA: 0x72FA4FC
	private object UnityEngine.Timeline.ICurvesOwner.get_targetTrack() { }

	// RVA: 0x72FA504
	public object get_underlyingAsset() { }

	// RVA: 0x72FA50C
	public object set_underlyingAsset(object value) { }

	// RVA: 0x72FA510
	public object get_parentTrack() { }

	// RVA: 0x72FA518
	public object set_parentTrack(object value) { }

	// RVA: 0x72FA51C
	public object GetParentTrack() { }

	// RVA: 0x72F9AA0
	internal object SetParentTrack_Internal(object newParentTrack) { }

	// RVA: 0x72FA524
	public object get_easeInDuration() { }

	// RVA: 0x72FA62C
	public object set_easeInDuration(object value) { }

	// RVA: 0x72FA768
	public object get_easeOutDuration() { }

	// RVA: 0x72FA870
	public object set_easeOutDuration(object value) { }

	// RVA: 0x72FA9AC
	public object get_eastOutTime() { }

	// RVA: 0x72FA9E4
	public object get_easeOutTime() { }

	// RVA: 0x72FAA1C
	public object get_blendInDuration() { }

	// RVA: 0x72FAA48
	public object set_blendInDuration(object value) { }

	// RVA: 0x72FAAF0
	public object get_blendOutDuration() { }

	// RVA: 0x72FAB1C
	public object set_blendOutDuration(object value) { }

	// RVA: 0x72FABC4
	public object get_blendInCurveMode() { }

	// RVA: 0x72FABCC
	public object set_blendInCurveMode(object value) { }

	// RVA: 0x72FABD4
	public object get_blendOutCurveMode() { }

	// RVA: 0x72FABDC
	public object set_blendOutCurveMode(object value) { }

	// RVA: 0x72FA830
	public object get_hasBlendIn() { }

	// RVA: 0x72FA5EC
	public object get_hasBlendOut() { }

	// RVA: 0x72FABE4
	public object get_mixInCurve() { }

	// RVA: 0x72FAC94
	public object set_mixInCurve(object value) { }

	// RVA: 0x72FAC9C
	public object get_mixInPercentage() { }

	// RVA: 0x72FAD0C
	public object get_mixInDuration() { }

	// RVA: 0x72FAD60
	public object get_mixOutCurve() { }

	// RVA: 0x72FAE10
	public object set_mixOutCurve(object value) { }

	// RVA: 0x72FAE18
	public object get_mixOutTime() { }

	// RVA: 0x72FAE80
	public object get_mixOutDuration() { }

	// RVA: 0x72FAED4
	public object get_mixOutPercentage() { }

	// RVA: 0x72FAF44
	public object get_recordable() { }

	// RVA: 0x72FAF4C
	internal object set_recordable(object value) { }

	// RVA: 0x72FAF54
	public object get_exposedParameters() { }

	// RVA: 0x72F9D94
	public object get_clipCaps() { }

	// RVA: 0x72FAFE4
	internal object Hash() { }

	// RVA: 0x72FB0CC
	public object EvaluateMixOut(object time) { }

	// RVA: 0x72FB318
	public object EvaluateMixIn(object time) { }

	// RVA: 0x72FAC7C
	private static object GetDefaultMixInCurve() { }

	// RVA: 0x72FADF8
	private static object GetDefaultMixOutCurve() { }

	// RVA: 0x72FB518
	public object ToLocalTime(object time) { }

	// RVA: 0x72FB89C
	public object ToLocalTimeUnbound(object time) { }

	// RVA: 0x72FB8F8
	internal object FromLocalTimeUnbound(object time) { }

	// RVA: 0x72FB948
	public object get_animationClip() { }

	// RVA: 0x72F9FF4
	private static object SanitizeTimeValue(object value, object defaultValue) { }

	// RVA: 0x72FBAAC
	public object get_postExtrapolationMode() { }

	// RVA: 0x72F519C
	internal object set_postExtrapolationMode(object value) { }

	// RVA: 0x72FBAE4
	public object get_preExtrapolationMode() { }

	// RVA: 0x72F515C
	internal object set_preExtrapolationMode(object value) { }

	// RVA: 0x72FBB1C
	internal object SetPostExtrapolationTime(object time) { }

	// RVA: 0x72FBB24
	internal object SetPreExtrapolationTime(object time) { }

	// RVA: 0x72FBB2C
	public object IsExtrapolatedTime(object sequenceTime) { }

	// RVA: 0x72FB65C
	public object IsPreExtrapolatedTime(object sequenceTime) { }

	// RVA: 0x72FB82C
	public object IsPostExtrapolatedTime(object sequenceTime) { }

	// RVA: 0x72FBBE0
	public object get_extrapolatedStart() { }

	// RVA: 0x72FBBF8
	public object get_extrapolatedDuration() { }

	// RVA: 0x72FB6C4
	private static object GetExtrapolatedTime(object time, object mode, object duration) { }

	// RVA: 0x72FBCE4
	public object CreateCurves(object curvesClipName) { }

	// RVA: 0x72FBDE8
	private object UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize() { }

	// RVA: 0x72FBDF4
	private object UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize() { }

	// RVA: 0x72FBE30
	public override object ToString() { }

	// RVA: 0x72FC018
	public object ConformEaseValues() { }

	// RVA: 0x72FC1C0
	private static object CalculateEasingRatio(object easeIn, object easeOut) { }

	// RVA: 0x72F9FE8
	private object UpdateDirty(object oldValue, object newValue) { }

	// RVA: 0x72FC2D4
	private static object .cctor() { }

}

// Namespace: 
private enum Versions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Initial;
}

// Namespace: 
private static class TimelineAssetUpgrade
{
}

// Namespace: 
public enum MediaType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Animation;
	public const object Audio;
	public const object Texture;
	public const object Video;
	public const object Script;
	public const object Hybrid;
	public const object Group;
}

// Namespace: 
public enum DurationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BasedOnClips;
	public const object FixedLength;
}

// Namespace: 
public class EditorSettings
{

	// Fields
	internal static readonly object kMinFrameRate; // 0x0
	internal static readonly object kMaxFrameRate; // 0x8
	internal static readonly object kDefaultFrameRate; // 0x10
	private object m_Framerate; // 0x8
	private object m_ScenePreview; // 0x10

	// Properties
	public object fps { get; set; }
	public object frameRate { get; set; }
	public object scenePreview { get; set; }

	// Methods

	// RVA: 0x7300DD4
	public object get_fps() { }

	// RVA: 0x7300DE0
	public object set_fps(object value) { }

	// RVA: 0x7300E74
	public object get_frameRate() { }

	// RVA: 0x72FDB6C
	public object set_frameRate(object value) { }

	// RVA: 0x7300E7C
	public object SetStandardFrameRate(object enumValue) { }

	// RVA: 0x7300FCC
	public object get_scenePreview() { }

	// RVA: 0x7300FD4
	public object set_scenePreview(object value) { }

	// RVA: 0x7300D58
	public object .ctor() { }

	// RVA: 0x7300FDC
	private static object .cctor() { }

}

// Namespace: 
private sealed class <get_outputs>d__27
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x30
	public object <>4__this; // 0x38
	private object <>7__wrap1; // 0x40
	private object <>7__wrap2; // 0x48

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x72FCCC8
	public object .ctor(object <>1__state) { }

	// RVA: 0x7301064
	private object System.IDisposable.Dispose() { }

	// RVA: 0x7301364
	private object MoveNext() { }

	// RVA: 0x7301B0C
	private object <>m__Finally1() { }

	// RVA: 0x7301A20
	private object <>m__Finally2() { }

	// RVA: 0x7301C2C
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.get_Current() { }

	// RVA: 0x7301C38
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x7301C78
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x7301CE0
	private object System.Collections.Generic.IEnumerable<UnityEngine.Playables.PlayableBinding>.GetEnumerator() { }

	// RVA: 0x7301D8C
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.Timeline
public class TimelineAsset
{

	// Fields
	private const object k_LatestVersion;
	private object m_Version; // 0x10
	private object m_Tracks; // 0x18
	private object m_FixedDuration; // 0x20
	private object m_CacheOutputTracks; // 0x28
	private object m_CacheRootTracks; // 0x30
	private object m_CacheFlattenedTracks; // 0x38
	private object m_EditorSettings; // 0x40
	private object m_DurationMode; // 0x48
	private object m_MarkerTrack; // 0x50

	// Properties
	public object editorSettings { get; }
	public override object duration { get; }
	public object fixedDuration { get; set; }
	public object durationMode { get; set; }
	public override object outputs { get; }
	public object clipCaps { get; }
	public object outputTrackCount { get; }
	public object rootTrackCount { get; }
	internal object flattenedTracks { get; }
	public object markerTrack { get; }
	internal object trackObjects { get; }

	// Methods

	// RVA: 0x72FC364
	private object UpgradeToLatestVersion() { }

	// RVA: 0x72FC368
	public object get_editorSettings() { }

	// RVA: 0x72FC370
	public override object get_duration() { }

	// RVA: 0x72FC9F8
	public object get_fixedDuration() { }

	// RVA: 0x72FCBC0
	public object set_fixedDuration(object value) { }

	// RVA: 0x72FCC3C
	public object get_durationMode() { }

	// RVA: 0x72FCC44
	public object set_durationMode(object value) { }

	// RVA: 0x72FCC4C
	public override object get_outputs() { }

	// RVA: 0x72FCD00
	public object get_clipCaps() { }

	// RVA: 0x72FD1D0
	public object get_outputTrackCount() { }

	// RVA: 0x72FD594
	public object get_rootTrackCount() { }

	// RVA: 0x72FDA58
	private object OnValidate() { }

	// RVA: 0x72FDB90
	public object GetRootTrack(object index) { }

	// RVA: 0x72FD1AC
	public object GetRootTracks() { }

	// RVA: 0x72FDC04
	public object GetOutputTrack(object index) { }

	// RVA: 0x72FDC54
	public object GetOutputTracks() { }

	// RVA: 0x72FDA94
	private static object GetValidFrameRate(object frameRate) { }

	// RVA: 0x72FD5F0
	private object UpdateRootTrackCache() { }

	// RVA: 0x72FD208
	private object UpdateOutputTrackCache() { }

	// RVA: 0x72FDCB8
	internal object get_flattenedTracks() { }

	// RVA: 0x72FE224
	public object get_markerTrack() { }

	// RVA: 0x72FE22C
	internal object get_trackObjects() { }

	// RVA: 0x72FE234
	internal object AddTrackInternal(object track) { }

	// RVA: 0x72FE368
	internal object RemoveTrack(object track) { }

	// RVA: 0x72FE5C0
	public override object CreatePlayable(object graph, object go) { }

	// RVA: 0x72FE7A0
	private object UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize() { }

	// RVA: 0x72FE7A8
	private object UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize() { }

	// RVA: 0x72FE7B4
	private object __internalAwake() { }

	// RVA: 0x72FE950
	public object GatherProperties(object director, object driver) { }

	// RVA: 0x72FEEBC
	public object CreateMarkerTrack() { }

	// RVA: 0x72FE35C
	internal object Invalidate() { }

	// RVA: 0x72FEFD0
	internal object UpdateFixedDurationWithItemsDuration() { }

	// RVA: 0x72FC518
	private object CalculateItemsDuration() { }

	// RVA: 0x72FDE40
	private static object AddSubTracksRecursive(object track, object allTracks) { }

	// RVA: 0x72FF264
	public object CreateTrack(object type, object parent, object name) { }

	// RVA: -1
	public object CreateTrack(object parent, object trackName) { }

	// RVA: -1
	public object CreateTrack(object trackName) { }

	// RVA: -1
	public object CreateTrack() { }

	// RVA: 0x72FFAB8
	public object DeleteClip(object clip) { }

	// RVA: 0x72FFF00
	public object DeleteClipEx(object clip) { }

	// RVA: 0x730007C
	public object DeleteTrack(object track) { }

	// RVA: 0x7300824
	internal object MoveLastTrackBefore(object asset) { }

	// RVA: 0x72FF7AC
	private object AllocateTrack(object trackAssetParent, object trackName, object trackType) { }

	// RVA: 0x7300628
	private object DeleteRecordedAnimation(object track) { }

	// RVA: 0x72FFD40
	private object DeleteRecordedAnimation(object clip) { }

	// RVA: 0x7300C78
	public object .ctor() { }

}

// Namespace: 
internal enum Versions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Initial;
	public const object RotationAsEuler;
	public const object RootMotionUpgrade;
	public const object AnimatedTrackProperties;
}

// Namespace: 
private static class TrackAssetUpgrade
{
}

// Namespace: 
private struct TransientBuildData
{

	// Fields
	public object trackList; // 0xFFFFFFFFFFFFFFF8
	public object clipList; // 0x0
	public object markerList; // 0x8

	// Methods

	// RVA: 0x73098B4
	public static object Create() { }

	// RVA: 0x7306C54
	public object Clear() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__121_0; // 0x8

	// Methods

	// RVA: 0x7309A08
	private static object .cctor() { }

	// RVA: 0x7309A68
	public object .ctor() { }

	// RVA: 0x7309A70
	internal object <SortClips>b__121_0(object clip1, object clip2) { }

}

// Namespace: 
private sealed class <get_outputs>d__65
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x30
	public object <>4__this; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x730304C
	public object .ctor(object <>1__state) { }

	// RVA: 0x7309AC0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x7309AC4
	private object MoveNext() { }

	// RVA: 0x7309D20
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.get_Current() { }

	// RVA: 0x7309D2C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x7309D6C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x7309DD4
	private object System.Collections.Generic.IEnumerable<UnityEngine.Playables.PlayableBinding>.GetEnumerator() { }

	// RVA: 0x7309E80
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.Timeline
public abstract class TrackAsset
{

	// Fields
	private const object k_LatestVersion;
	private object m_Version; // 0x10
	internal object m_AnimClip; // 0x18
	private static object s_BuildData; // 0x0
	internal const object kDefaultCurvesName;
	private static object OnClipPlayableCreate; // 0x18
	private static object OnTrackAnimationPlayableCreate; // 0x20
	private object m_Locked; // 0x20
	private object m_Muted; // 0x21
	private object m_CustomPlayableFullTypename; // 0x28
	private object m_Curves; // 0x30
	private object m_Parent; // 0x38
	private object m_Children; // 0x40
	private object m_ItemsHash; // 0x48
	private object m_ClipsCache; // 0x50
	private object m_Start; // 0x58
	private object m_End; // 0x60
	private object m_CacheSorted; // 0x68
	private object m_SupportsNotifications; // 0x69
	private static object s_EmptyCache; // 0x28
	private object m_ChildTrackCache; // 0x70
	private static object s_TrackBindingTypeAttributeCache; // 0x30
	protected internal object m_Clips; // 0x78
	private object m_Markers; // 0x80

	// Properties
	public object start { get; }
	public object end { get; }
	public sealed override object duration { get; }
	public object muted { get; set; }
	public object mutedInHierarchy { get; }
	public object timelineAsset { get; }
	public object parent { get; set; }
	internal object clips { get; }
	public virtual object isEmpty { get; }
	public object hasClips { get; }
	public object hasCurves { get; }
	public object isSubTrack { get; }
	public override object outputs { get; }
	internal object customPlayableTypename { get; set; }
	public object curves { get; set; }
	private object UnityEngine.Timeline.ICurvesOwner.defaultCurvesName { get; }
	private object UnityEngine.Timeline.ICurvesOwner.asset { get; }
	private object UnityEngine.Timeline.ICurvesOwner.assetOwner { get; }
	private object UnityEngine.Timeline.ICurvesOwner.targetTrack { get; }
	internal object subTracksObjects { get; }
	public object locked { get; set; }
	public object lockedInHierarchy { get; }
	public object supportsNotifications { get; }

	// Methods

	// RVA: 0x7301E38
	protected virtual object OnBeforeTrackSerialize() { }

	// RVA: 0x7301E3C
	protected virtual object OnAfterTrackDeserialize() { }

	// RVA: 0x7301E40
	internal virtual object OnUpgradeFromVersion(object oldVersion) { }

	// RVA: 0x7301E44
	private object UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize() { }

	// RVA: 0x7302004
	private object UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize() { }

	// RVA: 0x73025C4
	private object UpgradeToLatestVersion() { }

	// RVA: 0x73025F0
	internal static object add_OnClipPlayableCreate(object value) { }

	// RVA: 0x7302704
	internal static object remove_OnClipPlayableCreate(object value) { }

	// RVA: 0x7302818
	internal static object add_OnTrackAnimationPlayableCreate(object value) { }

	// RVA: 0x730292C
	internal static object remove_OnTrackAnimationPlayableCreate(object value) { }

	// RVA: 0x7302A40
	public object get_start() { }

	// RVA: 0x72FF11C
	public object get_end() { }

	// RVA: 0x7302C5C
	public sealed override object get_duration() { }

	// RVA: 0x7302D44
	public object get_muted() { }

	// RVA: 0x7302D4C
	public object set_muted(object value) { }

	// RVA: 0x72FECF0
	public object get_mutedInHierarchy() { }

	// RVA: 0x72FF620
	public object get_timelineAsset() { }

	// RVA: 0x7302D54
	public object get_parent() { }

	// RVA: 0x7302D5C
	internal object set_parent(object value) { }

	// RVA: 0x72F9188
	public object GetClips() { }

	// RVA: 0x72F4434
	internal object get_clips() { }

	// RVA: 0x7302D64
	public virtual object get_isEmpty() { }

	// RVA: 0x72F18F0
	public object get_hasClips() { }

	// RVA: 0x7302EAC
	public object get_hasCurves() { }

	// RVA: 0x72F5004
	public object get_isSubTrack() { }

	// RVA: 0x7302FD0
	public override object get_outputs() { }

	// RVA: 0x72F747C
	public object GetChildTracks() { }

	// RVA: 0x73033B8
	internal object get_customPlayableTypename() { }

	// RVA: 0x73033C0
	internal object set_customPlayableTypename(object value) { }

	// RVA: 0x73033C8
	public object get_curves() { }

	// RVA: 0x73033D0
	internal object set_curves(object value) { }

	// RVA: 0x73033D8
	private object UnityEngine.Timeline.ICurvesOwner.get_defaultCurvesName() { }

	// RVA: 0x730341C
	private object UnityEngine.Timeline.ICurvesOwner.get_asset() { }

	// RVA: 0x7303420
	private object UnityEngine.Timeline.ICurvesOwner.get_assetOwner() { }

	// RVA: 0x7303424
	private object UnityEngine.Timeline.ICurvesOwner.get_targetTrack() { }

	// RVA: 0x7303428
	internal object get_subTracksObjects() { }

	// RVA: 0x7303430
	public object get_locked() { }

	// RVA: 0x7303438
	public object set_locked(object value) { }

	// RVA: 0x7303440
	public object get_lockedInHierarchy() { }

	// RVA: 0x730360C
	public object get_supportsNotifications() { }

	// RVA: 0x73036C8
	private object __internalAwake() { }

	// RVA: 0x73037A8
	public object CreateCurves(object curvesClipName) { }

	// RVA: 0x7303894
	public virtual object CreateTrackMixer(object graph, object go, object inputCount) { }

	// RVA: 0x7303910
	public sealed override object CreatePlayable(object graph, object go) { }

	// RVA: 0x7303980
	public object CreateDefaultClip() { }

	// RVA: -1
	public object CreateClip() { }

	// RVA: 0x7303D88
	public object DeleteClip(object clip) { }

	// RVA: 0x7303EC8
	public object CreateMarker(object type, object time) { }

	// RVA: -1
	public object CreateMarker(object time) { }

	// RVA: 0x73042C8
	public object DeleteMarker(object marker) { }

	// RVA: 0x73025C8
	public object GetMarkers() { }

	// RVA: 0x7302F74
	public object GetMarkerCount() { }

	// RVA: 0x7304580
	public object GetMarker(object idx) { }

	// RVA: 0x7304668
	internal object CreateClip(object requestedType) { }

	// RVA: 0x7303D34
	internal object CreateAndAddNewClipOfType(object requestedType) { }

	// RVA: 0x7304B04
	internal object CreateClipOfType(object requestedType) { }

	// RVA: 0x73050AC
	internal object CreateClipFromPlayableAsset(object asset) { }

	// RVA: 0x7304D04
	private object CreateClipFromAsset(object playableAsset) { }

	// RVA: 0x7305598
	internal object GetMarkersRaw() { }

	// RVA: 0x73055A0
	internal object ClearMarkers() { }

	// RVA: 0x7305698
	internal object AddMarker(object e) { }

	// RVA: 0x7305820
	internal object DeleteMarkerRaw(object marker) { }

	// RVA: 0x7305930
	private object GetTimeRangeHash() { }

	// RVA: 0x7305D10
	public virtual object AddClip(object newClip) { }

	// RVA: 0x7305E58
	private object CreateNotificationsPlayable(object graph, object mixerPlayable, object go, object timelinePlayable) { }

	// RVA: 0x730659C
	public virtual object CreatePlayableGraph(object graph, object go, object tree, object timelinePlayable) { }

	// RVA: 0x7306D58
	internal virtual object CompileClips(object graph, object go, object timelineClips, object tree) { }

	// RVA: 0x73074B4
	private object GatherCompilableTracks(object tracks) { }

	// RVA: 0x7306190
	private object GatherNotifications(object markers) { }

	// RVA: 0x7307974
	internal virtual object CreateMixerPlayableGraph(object graph, object go, object tree) { }

	// RVA: 0x730728C
	internal object ConfigureTrackAnimation(object tree, object go, object blend) { }

	// RVA: 0x7308060
	internal object SortClips() { }

	// RVA: 0x73081C0
	internal object ClearClipsInternal() { }

	// RVA: 0x730823C
	internal object ClearSubTracksInternal() { }

	// RVA: 0x72FA134
	internal object OnClipMove() { }

	// RVA: 0x730834C
	public virtual object OnClipMovePost() { }

	// RVA: 0x730534C
	internal object CreateNewClipContainerInternal() { }

	// RVA: 0x7300A74
	internal object AddChild(object child) { }

	// RVA: 0x7308350
	internal object MoveLastTrackBefore(object asset) { }

	// RVA: 0x72FE4BC
	internal object RemoveSubTrack(object child) { }

	// RVA: 0x73085B8
	public virtual object RemoveClip(object clip) { }

	// RVA: 0x72F8224
	internal virtual object GetEvaluationTime(object outStart, object outDuration) { }

	// RVA: 0x72F8614
	internal virtual object GetSequenceTime(object outStart, object outDuration) { }

	// RVA: 0x7308654
	public virtual object GatherProperties(object director, object driver) { }

	// RVA: 0x72F1D5C
	internal object GetGameObjectBinding(object director) { }

	// RVA: 0x73047A4
	internal object ValidateClipType(object clipType) { }

	// RVA: 0x72F08B8
	protected virtual object OnCreateClip(object clip) { }

	// RVA: 0x7302B1C
	private object UpdateDuration() { }

	// RVA: 0x72F5430
	protected internal virtual object CalculateItemsHash() { }

	// RVA: 0x72F0510
	protected virtual object CreatePlayable(object graph, object gameObject, object clip) { }

	// RVA: 0x73024EC
	internal object Invalidate() { }

	// RVA: 0x72F8670
	internal object GetNotificationDuration() { }

	// RVA: 0x72F1950
	internal virtual object CanCompileClips() { }

	// RVA: 0x7309198
	public virtual object CanCreateTrackMixer() { }

	// RVA: 0x73091DC
	internal object IsCompilable() { }

	// RVA: 0x7303084
	private object UpdateChildTrackCache() { }

	// RVA: 0x7309650
	internal virtual object Hash() { }

	// RVA: 0x7308F7C
	private object GetClipsHash() { }

	// RVA: 0x72F52F0
	protected static object GetAnimationClipHash(object clip) { }

	// RVA: 0x730862C
	private object HasNotifications() { }

	// RVA: 0x730792C
	private object CanCompileNotifications() { }

	// RVA: 0x73068B0
	private object CanCreateMixerRecursive() { }

	// RVA: 0x72EE51C
	protected object .ctor() { }

	// RVA: 0x73097C8
	private static object .cctor() { }

}

// Namespace: UnityEngine.Timeline
internal class TimelineHelpURLAttribute
{

	// Methods

	// RVA: 0x7309F2C
	public object .ctor(object type) { }

}

// Namespace: UnityEngine.Timeline
public class TrackColorAttribute
{

	// Fields
	private object m_Color; // 0x8

	// Properties
	public object color { get; }

	// Methods

	// RVA: 0x7309F34
	public object get_color() { }

	// RVA: 0x7309F40
	public object .ctor(object r, object g, object b) { }

}

// Namespace: UnityEngine.Timeline
internal class AudioClipProperties
{

	// Fields
	public object volume; // 0x8

	// Methods

	// RVA: 0x7309F90
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
internal class AudioMixerProperties
{

	// Fields
	public object volume; // 0x8
	public object stereoPan; // 0xC
	public object spatialBlend; // 0x10

	// Methods

	// RVA: 0x7309FA0
	public override object PrepareFrame(object playable, object info) { }

	// RVA: 0x730A288
	public object .ctor() { }

}

// Namespace: 
private sealed class <get_outputs>d__16
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x30
	public object <>4__this; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x730A43C
	public object .ctor(object <>1__state) { }

	// RVA: 0x730A69C
	private object System.IDisposable.Dispose() { }

	// RVA: 0x730A6A0
	private object MoveNext() { }

	// RVA: 0x730A738
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.get_Current() { }

	// RVA: 0x730A744
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x730A784
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x730A7EC
	private object System.Collections.Generic.IEnumerable<UnityEngine.Playables.PlayableBinding>.GetEnumerator() { }

	// RVA: 0x730A898
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.Timeline
public class AudioPlayableAsset
{

	// Fields
	private object m_Clip; // 0x10
	private object m_Loop; // 0x18
	private object m_bufferingTime; // 0x1C
	private object m_ClipProperties; // 0x20

	// Properties
	internal object bufferingTime { get; set; }
	public object clip { get; set; }
	public object loop { get; set; }
	public override object duration { get; }
	public override object outputs { get; }
	public object clipCaps { get; }

	// Methods

	// RVA: 0x730A298
	internal object get_bufferingTime() { }

	// RVA: 0x730A2A0
	internal object set_bufferingTime(object value) { }

	// RVA: 0x730A2A8
	public object get_clip() { }

	// RVA: 0x730A2B0
	public object set_clip(object value) { }

	// RVA: 0x730A2B8
	public object get_loop() { }

	// RVA: 0x730A2C0
	public object set_loop(object value) { }

	// RVA: 0x730A2C8
	public override object get_duration() { }

	// RVA: 0x730A3C0
	public override object get_outputs() { }

	// RVA: 0x730A474
	public override object CreatePlayable(object graph, object go) { }

	// RVA: 0x730A610
	public object get_clipCaps() { }

	// RVA: 0x730A61C
	public object .ctor() { }

}

// Namespace: 
private sealed class <get_outputs>d__4
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x30
	public object <>4__this; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x730B4D8
	public object .ctor(object <>1__state) { }

	// RVA: 0x730B61C
	private object System.IDisposable.Dispose() { }

	// RVA: 0x730B620
	private object MoveNext() { }

	// RVA: 0x730B6B8
	private object System.Collections.Generic.IEnumerator<UnityEngine.Playables.PlayableBinding>.get_Current() { }

	// RVA: 0x730B6C4
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x730B704
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x730B76C
	private object System.Collections.Generic.IEnumerable<UnityEngine.Playables.PlayableBinding>.GetEnumerator() { }

	// RVA: 0x730B818
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.Timeline
public class AudioTrack
{

	// Fields
	private object m_TrackProperties; // 0x98

	// Properties
	public override object outputs { get; }

	// Methods

	// RVA: 0x730A944
	public object CreateClip(object clip) { }

	// RVA: 0x730AAF4
	internal override object CompileClips(object graph, object go, object timelineClips, object tree) { }

	// RVA: 0x730B45C
	public override object get_outputs() { }

	// RVA: 0x730B510
	private object OnValidate() { }

	// RVA: 0x730B574
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public enum ClipCaps
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Looping;
	public const object Extrapolation;
	public const object ClipIn;
	public const object SpeedMultiplier;
	public const object Blending;
	public const object AutoScale;
	public const object All;
}

// Namespace: UnityEngine.Timeline
internal static class TimelineClipCapsExtensions
{

	// Methods

	// RVA: 0x730B8C4
	public static object SupportsLooping(object clip) { }

	// RVA: 0x730B8E0
	public static object SupportsExtrapolation(object clip) { }

	// RVA: 0x730B8FC
	public static object SupportsClipIn(object clip) { }

	// RVA: 0x730B918
	public static object SupportsSpeedMultiplier(object clip) { }

	// RVA: 0x730B934
	public static object SupportsBlending(object clip) { }

	// RVA: 0x730B950
	public static object HasAll(object caps, object flags) { }

	// RVA: 0x72F9ECC
	public static object HasAny(object caps, object flags) { }

}

// Namespace: UnityEngine.Timeline
public abstract class ClipPlayableAsset
{

	// Fields
	private object <timelineClip>k__BackingField; // 0x10

	// Properties
	public object timelineClip { get; set; }

	// Methods

	// RVA: 0x730B95C
	public object get_timelineClip() { }

	// RVA: 0x730B964
	public object set_timelineClip(object value) { }

	// RVA: 0x730B96C
	protected object .ctor() { }

}

// Namespace: 
private sealed class <GetControlableScripts>d__40
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	private object root; // 0x20
	public object <>3__root; // 0x28
	private object <>7__wrap1; // 0x30
	private object <>7__wrap2; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.MonoBehaviour>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x730E508
	public object .ctor(object <>1__state) { }

	// RVA: 0x7310100
	private object System.IDisposable.Dispose() { }

	// RVA: 0x7310104
	private object MoveNext() { }

	// RVA: 0x731028C
	private object System.Collections.Generic.IEnumerator<UnityEngine.MonoBehaviour>.get_Current() { }

	// RVA: 0x7310294
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x73102D4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x73102DC
	private object System.Collections.Generic.IEnumerable<UnityEngine.MonoBehaviour>.GetEnumerator() { }

	// RVA: 0x7310390
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.Timeline
public class ControlPlayableAsset
{

	// Fields
	private const object k_MaxRandInt;
	private static readonly object k_EmptyDirectorsList; // 0x0
	private static readonly object k_EmptyParticlesList; // 0x8
	private static readonly object s_SubEmitterCollector; // 0x10
	public object sourceGameObject; // 0x10
	public object prefabGameObject; // 0x20
	public object updateParticle; // 0x28
	public object particleRandomSeed; // 0x2C
	public object updateDirector; // 0x30
	public object updateITimeControl; // 0x31
	public object searchHierarchy; // 0x32
	public object active; // 0x33
	public object postPlayback; // 0x34
	public object simulateWhenActived; // 0x38
	private object m_ControlDirectorAsset; // 0x40
	private object m_Duration; // 0x48
	private object m_SupportLoop; // 0x50
	private static object s_ProcessedDirectors; // 0x18
	private static object s_CreatedPrefabs; // 0x20
	private object <controllingDirectors>k__BackingField; // 0x51
	private object <controllingParticles>k__BackingField; // 0x52

	// Properties
	internal object controllingDirectors { get; set; }
	internal object controllingParticles { get; set; }
	public override object duration { get; }
	public object clipCaps { get; }

	// Methods

	// RVA: 0x730B974
	internal object get_controllingDirectors() { }

	// RVA: 0x730B97C
	private object set_controllingDirectors(object value) { }

	// RVA: 0x730B984
	internal object get_controllingParticles() { }

	// RVA: 0x730B98C
	private object set_controllingParticles(object value) { }

	// RVA: 0x730B994
	public object OnEnable() { }

	// RVA: 0x730B9D0
	public override object get_duration() { }

	// RVA: 0x730B9D8
	public object get_clipCaps() { }

	// RVA: 0x730B9E4
	public override object CreatePlayable(object graph, object go) { }

	// RVA: 0x730E248
	private static object ConnectPlayablesToMixer(object graph, object playables) { }

	// RVA: 0x730D0E4
	private object CreateActivationPlayable(object root, object graph, object outplayables) { }

	// RVA: 0x730D814
	private object SearchHierarchyAndConnectParticleSystem(object particleSystems, object graph, object outplayables) { }

	// RVA: 0x730D2B8
	private object SearchHierarchyAndConnectDirector(object directors, object graph, object outplayables, object disableSelfReferences) { }

	// RVA: 0x730DD74
	private static object SearchHierarchyAndConnectControlableScripts(object controlableScripts, object graph, object outplayables) { }

	// RVA: 0x730E43C
	private static object ConnectMixerAndPlayable(object graph, object mixer, object playable, object portIndex) { }

	// RVA: -1
	internal object GetComponent(object gameObject) { }

	// RVA: 0x730DCF8
	internal static object GetControlableScripts(object root) { }

	// RVA: 0x730C64C
	internal object UpdateDurationAndLoopFlag(object directors, object particleSystems) { }

	// RVA: 0x730C490
	private object GetControllableParticleSystems(object go) { }

	// RVA: 0x730E54C
	private static object GetControllableParticleSystems(object t, object roots, object subEmitters) { }

	// RVA: 0x730E77C
	private static object CacheSubEmitters(object ps, object subEmitters) { }

	// RVA: 0x730E900
	public object GatherProperties(object director, object driver) { }

	// RVA: 0x730ECBC
	internal static object PreviewParticles(object driver, object particles) { }

	// RVA: 0x730F1AC
	internal static object PreviewActivation(object driver, object objects) { }

	// RVA: 0x730F5A0
	internal static object PreviewTimeControl(object driver, object director, object scripts) { }

	// RVA: 0x730FA5C
	internal static object PreviewDirectors(object driver, object directors) { }

	// RVA: 0x730FEA4
	public object .ctor() { }

	// RVA: 0x730FF30
	private static object .cctor() { }

}

// Namespace: UnityEngine.Timeline
public class ControlTrack
{

	// Methods

	// RVA: 0x7310444
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
internal struct DiscreteTime
{

	// Fields
	private const object k_Tick;
	public static readonly object kMaxTime; // 0x0
	private readonly object m_DiscreteTime; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public static object tickValue { get; }

	// Methods

	// RVA: 0x73104C4
	public static object get_tickValue() { }

	// RVA: 0x73104D0
	public object .ctor(object time) { }

	// RVA: 0x73104E0
	private object .ctor(object time) { }

	// RVA: 0x73104F0
	public object .ctor(object time) { }

	// RVA: 0x731065C
	public object .ctor(object time) { }

	// RVA: 0x72FF0B0
	public object .ctor(object time) { }

	// RVA: 0x7310908
	public object .ctor(object frame, object fps) { }

	// RVA: 0x72FC980
	public object OneTickBefore() { }

	// RVA: 0x730E540
	public object OneTickAfter() { }

	// RVA: 0x7310A14
	public object GetTick() { }

	// RVA: 0x7310A24
	public static object FromTicks(object ticks) { }

	// RVA: 0x7310A28
	public object CompareTo(object obj) { }

	// RVA: 0x7310B68
	public object Equals(object other) { }

	// RVA: 0x7310B88
	public override object Equals(object obj) { }

	// RVA: 0x73105D0
	private static object DoubleToDiscreteTime(object time) { }

	// RVA: 0x731073C
	private static object FloatToDiscreteTime(object time) { }

	// RVA: 0x73107C8
	private static object IntToDiscreteTime(object time) { }

	// RVA: 0x7310D00
	private static object ToDouble(object time) { }

	// RVA: 0x7310D14
	private static object ToFloat(object time) { }

	// RVA: 0x72FC98C
	public static object op_Explicit(object b) { }

	// RVA: 0x7310D84
	public static object op_Explicit(object b) { }

	// RVA: 0x7310E4C
	public static object op_Explicit(object b) { }

	// RVA: 0x72FCB98
	public static object op_Explicit(object time) { }

	// RVA: 0x7310E50
	public static object op_Explicit(object time) { }

	// RVA: 0x72FC8F4
	public static object op_Implicit(object time) { }

	// RVA: 0x7310E78
	public static object op_Explicit(object time) { }

	// RVA: 0x7310E7C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7310E88
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7310F14
	public static object op_GreaterThan(object lhs, object rhs) { }

	// RVA: 0x7310F20
	public static object op_LessThan(object lhs, object rhs) { }

	// RVA: 0x72FC974
	public static object op_LessThanOrEqual(object lhs, object rhs) { }

	// RVA: 0x7310F2C
	public static object op_GreaterThanOrEqual(object lhs, object rhs) { }

	// RVA: 0x7310F38
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x7302D3C
	public static object op_Subtraction(object lhs, object rhs) { }

	// RVA: 0x7310F40
	public override object ToString() { }

	// RVA: 0x7310F54
	public override object GetHashCode() { }

	// RVA: 0x7310F68
	public static object Min(object lhs, object rhs) { }

	// RVA: 0x72FF1F8
	public static object Max(object lhs, object rhs) { }

	// RVA: 0x7310FD4
	public static object SnapToNearestTick(object time) { }

	// RVA: 0x73110AC
	public static object SnapToNearestTick(object time) { }

	// RVA: 0x73111C0
	public static object GetNearestTick(object time) { }

	// RVA: 0x7311290
	private static object .cctor() { }

}

// Namespace: UnityEngine.Timeline
internal class InfiniteRuntimeClip
{

	// Fields
	private object m_Playable; // 0x10
	private static readonly object kIntervalEnd; // 0x0

	// Properties
	public override object intervalStart { get; }
	public override object intervalEnd { get; }
	public override object enable { set; }

	// Methods

	// RVA: 0x72F812C
	public object .ctor(object playable) { }

	// RVA: 0x73112E8
	public override object get_intervalStart() { }

	// RVA: 0x73112F0
	public override object get_intervalEnd() { }

	// RVA: 0x731136C
	public override object set_enable(object value) { }

	// RVA: 0x73113F0
	public override object EvaluateAt(object localTime, object frameData) { }

	// RVA: 0x7311454
	public override object DisableAt(object localTime, object rootDuration, object frameData) { }

	// RVA: 0x73114E0
	private static object .cctor() { }

}

// Namespace: UnityEngine.Timeline
public interface IInterval
{

	// Properties
	public abstract object intervalStart { get; }
	public abstract object intervalEnd { get; }

	// Methods

	// RVA: -1
	public abstract object get_intervalStart() { }

	// RVA: -1
	public abstract object get_intervalEnd() { }

}

// Namespace: UnityEngine.Timeline
internal struct IntervalTreeNode
{

	// Fields
	public object center; // 0xFFFFFFFFFFFFFFF8
	public object first; // 0x0
	public object last; // 0x4
	public object left; // 0x8
	public object right; // 0xC
}

// Namespace: 
internal struct Entry
{

	// Fields
	public object intervalStart; // 0x0
	public object intervalEnd; // 0x0
	public object item; // 0x0
}

// Namespace: UnityEngine.Timeline
public class IntervalTree<T0>
{

	// Fields
	private const object kMinNodeSize;
	private const object kInvalidNode;
	private const object kCenterUnknown;
	private readonly object m_Entries; // 0x0
	private readonly object m_Nodes; // 0x0
	private object <dirty>k__BackingField; // 0x0

	// Properties
	public object dirty { get; set; }

	// Methods

	// RVA: -1
	public object get_dirty() { }

	// RVA: -1
	internal object set_dirty(object value) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object IntersectsWith(object value, object results) { }

	// RVA: -1
	public object IntersectsWithRange(object start, object end, object results) { }

	// RVA: -1
	public object UpdateIntervals() { }

	// RVA: -1
	private object Query(object intervalTreeNode, object value, object results) { }

	// RVA: -1
	private object QueryRange(object intervalTreeNode, object start, object end, object results) { }

	// RVA: -1
	private object Rebuild() { }

	// RVA: -1
	private object Rebuild(object start, object end) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
internal class RuntimeClip
{

	// Fields
	private object m_Clip; // 0x10
	private object m_Playable; // 0x18
	private object m_ParentMixer; // 0x28

	// Properties
	public override object start { get; }
	public override object duration { get; }
	public object clip { get; }
	public object mixer { get; }
	public object playable { get; }
	public override object enable { set; }

	// Methods

	// RVA: 0x7311590
	public override object get_start() { }

	// RVA: 0x73115C4
	public override object get_duration() { }

	// RVA: 0x72F5ADC
	public object .ctor(object clip, object clipPlayable, object parentMixer) { }

	// RVA: 0x73115EC
	private object Create(object clip, object clipPlayable, object parentMixer) { }

	// RVA: 0x7311674
	public object get_clip() { }

	// RVA: 0x731167C
	public object get_mixer() { }

	// RVA: 0x7311688
	public object get_playable() { }

	// RVA: 0x7311694
	public override object set_enable(object value) { }

	// RVA: 0x7311814
	public object SetTime(object time) { }

	// RVA: 0x7311878
	public object SetDuration(object duration) { }

	// RVA: 0x73118DC
	public override object EvaluateAt(object localTime, object frameData) { }

	// RVA: 0x7311CD0
	public override object DisableAt(object localTime, object rootDuration, object frameData) { }

}

// Namespace: UnityEngine.Timeline
internal abstract class RuntimeClipBase
{

	// Properties
	public abstract object start { get; }
	public abstract object duration { get; }
	public override object intervalStart { get; }
	public override object intervalEnd { get; }

	// Methods

	// RVA: -1
	public abstract object get_start() { }

	// RVA: -1
	public abstract object get_duration() { }

	// RVA: 0x7311F08
	public override object get_intervalStart() { }

	// RVA: 0x7311FA0
	public override object get_intervalEnd() { }

	// RVA: 0x73115E4
	protected object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public abstract class RuntimeElement
{

	// Fields
	private object <intervalBit>k__BackingField; // 0x8

	// Properties
	public abstract object intervalStart { get; }
	public abstract object intervalEnd { get; }
	public object intervalBit { get; set; }
	public abstract object enable { set; }

	// Methods

	// RVA: -1
	public abstract object get_intervalStart() { }

	// RVA: -1
	public abstract object get_intervalEnd() { }

	// RVA: 0x7312064
	public object get_intervalBit() { }

	// RVA: 0x731206C
	public object set_intervalBit(object value) { }

	// RVA: -1
	public abstract object set_enable(object value) { }

	// RVA: -1
	public abstract object EvaluateAt(object localTime, object frameData) { }

	// RVA: -1
	public abstract object DisableAt(object localTime, object rootDuration, object frameData) { }

	// RVA: 0x73112E0
	protected object .ctor() { }

}

// Namespace: UnityEngine.Timeline
internal class ScheduleRuntimeClip
{

	// Fields
	private object m_Clip; // 0x10
	private object m_Playable; // 0x18
	private object m_ParentMixer; // 0x28
	private object m_StartDelay; // 0x38
	private object m_FinishTail; // 0x40
	private object m_Started; // 0x48

	// Properties
	public override object start { get; }
	public override object duration { get; }
	public object clip { get; }
	public object mixer { get; }
	public object playable { get; }
	public override object enable { set; }

	// Methods

	// RVA: 0x7312074
	public override object get_start() { }

	// RVA: 0x73120F8
	public override object get_duration() { }

	// RVA: 0x7312178
	public object SetTime(object time) { }

	// RVA: 0x73121DC
	public object get_clip() { }

	// RVA: 0x73121E4
	public object get_mixer() { }

	// RVA: 0x73121F0
	public object get_playable() { }

	// RVA: 0x730B3B8
	public object .ctor(object clip, object clipPlayable, object parentMixer, object startDelay, object finishTail) { }

	// RVA: 0x73121FC
	private object Create(object clip, object clipPlayable, object parentMixer, object startDelay, object finishTail) { }

	// RVA: 0x7312298
	public override object set_enable(object value) { }

	// RVA: 0x73123A0
	public override object EvaluateAt(object localTime, object frameData) { }

	// RVA: 0x73126E4
	public override object DisableAt(object localTime, object rootDuration, object frameData) { }

}

// Namespace: UnityEngine.Timeline
public interface IMarker
{

	// Properties
	public abstract object time { get; set; }
	public abstract object parent { get; }

	// Methods

	// RVA: -1
	public abstract object get_time() { }

	// RVA: -1
	public abstract object set_time(object value) { }

	// RVA: -1
	public abstract object get_parent() { }

	// RVA: -1
	public abstract object Initialize(object parent) { }

}

// Namespace: UnityEngine.Timeline
public interface INotificationOptionProvider
{

	// Properties
	public abstract object flags { get; }

	// Methods

	// RVA: -1
	public abstract object get_flags() { }

}

// Namespace: UnityEngine.Timeline
public abstract class Marker
{

	// Fields
	private object m_Time; // 0x10
	private object <parent>k__BackingField; // 0x18

	// Properties
	public object parent { get; set; }
	public object time { get; set; }

	// Methods

	// RVA: 0x7312728
	public object get_parent() { }

	// RVA: 0x7312730
	private object set_parent(object value) { }

	// RVA: 0x7312738
	public object get_time() { }

	// RVA: 0x7312740
	public object set_time(object value) { }

	// RVA: 0x73127BC
	private object UnityEngine.Timeline.IMarker.Initialize(object parentTrack) { }

	// RVA: 0x7312950
	public virtual object OnInitialize(object aPent) { }

	// RVA: 0x7312954
	protected object .ctor() { }

}

// Namespace: UnityEngine.Timeline
internal struct MarkerList
{

	// Fields
	private object m_Objects; // 0xFFFFFFFFFFFFFFF8
	private object m_Cache; // 0x0
	private object m_CacheDirty; // 0x8
	private object m_HasNotifications; // 0x9

	// Properties
	public object markers { get; }
	public object Count { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x7312998
	public object get_markers() { }

	// RVA: 0x73096EC
	public object .ctor(object capacity) { }

	// RVA: 0x73056A0
	public object Add(object item) { }

	// RVA: 0x73042D0
	public object Remove(object item) { }

	// RVA: 0x7305854
	public object Remove(object item, object timelineAsset, object thingToDirty) { }

	// RVA: 0x730561C
	public object Clear() { }

	// RVA: 0x7312DC0
	public object Contains(object item) { }

	// RVA: 0x7304500
	public object GetMarkers() { }

	// RVA: 0x7304524
	public object get_Count() { }

	// RVA: 0x73045F4
	public object get_Item(object idx) { }

	// RVA: 0x7312F90
	public object GetRawMarkerList() { }

	// RVA: 0x7303ED4
	public object CreateMarker(object type, object time, object owner) { }

	// RVA: 0x73096C8
	public object HasNotifications() { }

	// RVA: 0x7312FD0
	private object UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize() { }

	// RVA: 0x7312FD8
	private object UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize() { }

	// RVA: 0x73129BC
	private object BuildCache() { }

}

// Namespace: UnityEngine.Timeline
public class MarkerTrack
{

	// Properties
	public override object outputs { get; }

	// Methods

	// RVA: 0x7312FFC
	public override object get_outputs() { }

	// RVA: 0x7313268
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
internal class CustomSignalEventDrawer
{

	// Methods

	// RVA: 0x73132F0
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class SignalAsset
{

	// Fields
	private static object OnEnableCallback; // 0x0

	// Methods

	// RVA: 0x73132F8
	internal static object add_OnEnableCallback(object value) { }

	// RVA: 0x73133C8
	internal static object remove_OnEnableCallback(object value) { }

	// RVA: 0x7313498
	private object OnEnable() { }

	// RVA: 0x7313514
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class SignalEmitter
{

	// Fields
	private object m_Retroactive; // 0x20
	private object m_EmitOnce; // 0x21
	private object m_Asset; // 0x28

	// Properties
	public object retroactive { get; set; }
	public object emitOnce { get; set; }
	public object asset { get; set; }
	private object UnityEngine.Playables.INotification.id { get; }
	private object UnityEngine.Timeline.INotificationOptionProvider.flags { get; }

	// Methods

	// RVA: 0x731351C
	public object get_retroactive() { }

	// RVA: 0x7313524
	public object set_retroactive(object value) { }

	// RVA: 0x731352C
	public object get_emitOnce() { }

	// RVA: 0x7313534
	public object set_emitOnce(object value) { }

	// RVA: 0x731353C
	public object get_asset() { }

	// RVA: 0x7313544
	public object set_asset(object value) { }

	// RVA: 0x731354C
	private object UnityEngine.Playables.INotification.get_id() { }

	// RVA: 0x7313644
	private object UnityEngine.Timeline.INotificationOptionProvider.get_flags() { }

	// RVA: 0x731366C
	public object .ctor() { }

}

// Namespace: 
private class EventKeyValue
{

	// Fields
	private object m_Signals; // 0x8
	private object m_Events; // 0x10

	// Properties
	public object signals { get; }
	public object events { get; }

	// Methods

	// RVA: 0x7313858
	public object TryGetValue(object key, object value) { }

	// RVA: 0x7313ABC
	public object Append(object key, object value) { }

	// RVA: 0x731440C
	public object Remove(object idx) { }

	// RVA: 0x7313E2C
	public object Remove(object key) { }

	// RVA: 0x731487C
	public object get_signals() { }

	// RVA: 0x7314884
	public object get_events() { }

	// RVA: 0x73147B4
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class SignalReceiver
{

	// Fields
	private object m_Events; // 0x18

	// Methods

	// RVA: 0x7313674
	public object OnNotify(object origin, object notification, object context) { }

	// RVA: 0x7313924
	public object AddReaction(object asset, object reaction) { }

	// RVA: 0x7313CAC
	public object AddEmptyReaction(object reaction) { }

	// RVA: 0x7313D44
	public object Remove(object asset) { }

	// RVA: 0x7313F1C
	public object GetRegisteredSignals() { }

	// RVA: 0x7313F40
	public object GetReaction(object key) { }

	// RVA: 0x7314000
	public object Count() { }

	// RVA: 0x7314068
	public object ChangeSignalAtIndex(object idx, object newKey) { }

	// RVA: 0x7314350
	public object RemoveAtIndex(object idx) { }

	// RVA: 0x73144C4
	public object ChangeReactionAtIndex(object idx, object reaction) { }

	// RVA: 0x73145A0
	public object GetReactionAtIndex(object idx) { }

	// RVA: 0x7314674
	public object GetSignalAssetAtIndex(object idx) { }

	// RVA: 0x7314748
	private object OnEnable() { }

	// RVA: 0x731474C
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class SignalTrack
{

	// Methods

	// RVA: 0x731488C
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public static class TrackAssetExtensions
{

	// Methods

	// RVA: 0x7314914
	public static object GetGroup(object asset) { }

	// RVA: 0x7314A14
	public static object SetGroup(object asset, object group) { }

}

// Namespace: UnityEngine.Timeline
public class GroupTrack
{

	// Properties
	public override object outputs { get; }

	// Methods

	// RVA: 0x7314E60
	internal override object CanCompileClips() { }

	// RVA: 0x7314E68
	public override object get_outputs() { }

	// RVA: 0x7314EE4
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public interface ILayerable
{

	// Methods

	// RVA: -1
	public abstract object CreateLayerMixer(object graph, object go, object inputCount) { }

}

// Namespace: 
public enum PostPlaybackState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Active;
	public const object Inactive;
	public const object Revert;
}

// Namespace: 
private enum InitialState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unset;
	public const object Active;
	public const object Inactive;
}

// Namespace: UnityEngine.Timeline
public class ActivationControlPlayable
{

	// Fields
	public object gameObject; // 0x8
	public object postPlayback; // 0x10
	private object m_InitialState; // 0x14

	// Methods

	// RVA: 0x7314F6C
	public static object Create(object graph, object gameObject, object postPlaybackState) { }

	// RVA: 0x73150C4
	public override object OnBehaviourPlay(object playable, object info) { }

	// RVA: 0x7315188
	public override object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x7315264
	public override object ProcessFrame(object playable, object info, object userData) { }

	// RVA: 0x7315328
	public override object OnGraphStart(object playable) { }

	// RVA: 0x7315404
	public override object OnPlayableDestroy(object playable) { }

	// RVA: 0x7315548
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class BasicPlayableBehaviour
{

	// Properties
	public virtual object duration { get; }
	public virtual object outputs { get; }

	// Methods

	// RVA: 0x7315558
	public virtual object get_duration() { }

	// RVA: 0x73155D4
	public virtual object get_outputs() { }

	// RVA: 0x7315650
	public virtual object OnGraphStart(object playable) { }

	// RVA: 0x7315654
	public virtual object OnGraphStop(object playable) { }

	// RVA: 0x7315658
	public virtual object OnPlayableCreate(object playable) { }

	// RVA: 0x731565C
	public virtual object OnPlayableDestroy(object playable) { }

	// RVA: 0x7315660
	public virtual object OnBehaviourPlay(object playable, object info) { }

	// RVA: 0x7315664
	public virtual object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x7315668
	public virtual object PrepareFrame(object playable, object info) { }

	// RVA: 0x731566C
	public virtual object ProcessFrame(object playable, object info, object playerData) { }

	// RVA: 0x7315670
	public virtual object CreatePlayable(object graph, object owner) { }

	// RVA: 0x7315720
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class DirectorControlPlayable
{

	// Fields
	public object director; // 0x8
	private object m_SyncTime; // 0x10
	private object m_AssetDuration; // 0x18

	// Methods

	// RVA: 0x7315728
	public static object Create(object graph, object director) { }

	// RVA: 0x7315878
	public override object OnPlayableDestroy(object playable) { }

	// RVA: 0x7315994
	public override object PrepareFrame(object playable, object info) { }

	// RVA: 0x7315F28
	public override object OnBehaviourPlay(object playable, object info) { }

	// RVA: 0x7316098
	public override object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x73161F4
	public override object ProcessFrame(object playable, object info, object playerData) { }

	// RVA: 0x7315CC4
	private object SyncSpeed(object speed) { }

	// RVA: 0x7315E20
	private object SyncStart(object graph, object time) { }

	// RVA: 0x73169D4
	private object SyncStop(object graph, object time) { }

	// RVA: 0x7315B94
	private object DetectDiscontinuity(object playable, object info) { }

	// RVA: 0x73165FC
	private object DetectOutOfSync(object playable) { }

	// RVA: 0x7316774
	private object UpdateTime(object playable) { }

	// RVA: 0x7316AE4
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public interface ITimeControl
{

	// Methods

	// RVA: -1
	public abstract object SetTime(object time) { }

	// RVA: -1
	public abstract object OnControlTimeStart() { }

	// RVA: -1
	public abstract object OnControlTimeStop() { }

}

// Namespace: UnityEngine.Timeline
public enum NotificationFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TriggerInEditMode;
	public const object Retroactive;
	public const object TriggerOnce;
}

// Namespace: UnityEngine.Timeline
public class ParticleControlPlayable
{

	// Fields
	private const object kUnsetTime;
	private object m_LastPlayableTime; // 0x8
	private object m_LastParticleTime; // 0xC
	private object m_RandomSeed; // 0x10
	private const object kDefaultActiveStartTime;
	private object m_ActiveStartTime; // 0x14
	private object m_SimulateWhenActived; // 0x18
	private object m_UndoSimulateTime; // 0x1C
	private object <particleSystem>k__BackingField; // 0x20

	// Properties
	public object particleSystem { get; set; }

	// Methods

	// RVA: 0x7316AF4
	public static object Create(object graph, object component, object randomSeed, object simulateWhenActived) { }

	// RVA: 0x7316D40
	public object get_particleSystem() { }

	// RVA: 0x7316D48
	private object set_particleSystem(object value) { }

	// RVA: 0x7316CA4
	public object Initialize(object ps, object randomSeed, object simulateWhenActived) { }

	// RVA: 0x7316D50
	private static object SetRandomSeed(object particleSystem, object randomSeed) { }

	// RVA: 0x7316EC4
	public override object PrepareFrame(object playable, object data) { }

	// RVA: 0x73172EC
	public override object OnBehaviourPlay(object playable, object info) { }

	// RVA: 0x73172F8
	public override object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x7317204
	private object Simulate(object time, object restart) { }

	// RVA: 0x7317304
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class PrefabControlPlayable
{

	// Fields
	private object m_Instance; // 0x8

	// Properties
	public object prefabInstance { get; }

	// Methods

	// RVA: 0x7317320
	public static object Create(object graph, object prefabGameObject, object parentTransform) { }

	// RVA: 0x7317798
	public object get_prefabInstance() { }

	// RVA: 0x731747C
	public object Initialize(object prefabGameObject, object parentTransform) { }

	// RVA: 0x7317BA4
	public override object OnPlayableDestroy(object playable) { }

	// RVA: 0x7317D2C
	public override object OnBehaviourPlay(object playable, object info) { }

	// RVA: 0x7317DF0
	public override object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x73177A0
	private static object SetHideFlagsRecursive(object gameObject) { }

	// RVA: 0x7317ECC
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class TimeControlPlayable
{

	// Fields
	private object m_timeControl; // 0x8
	private object m_started; // 0x10

	// Methods

	// RVA: 0x7317ED4
	public static object Create(object graph, object timeControl) { }

	// RVA: 0x7317FEC
	public object Initialize(object timeControl) { }

	// RVA: 0x7317FF4
	public override object PrepareFrame(object playable, object info) { }

	// RVA: 0x7318104
	public override object OnBehaviourPlay(object playable, object info) { }

	// RVA: 0x73181DC
	public override object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x73182B4
	public object .ctor() { }

}

// Namespace: 
private struct NotificationEntry
{

	// Fields
	public object time; // 0xFFFFFFFFFFFFFFF8
	public object payload; // 0x0
	public object notificationFired; // 0x8
	public object flags; // 0xA

	// Properties
	public object triggerInEditor { get; }
	public object prewarm { get; }
	public object triggerOnce { get; }

	// Methods

	// RVA: 0x731930C
	public object get_triggerInEditor() { }

	// RVA: 0x7319300
	public object get_prewarm() { }

	// RVA: 0x7318860
	public object get_triggerOnce() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__12_0; // 0x8

	// Methods

	// RVA: 0x73193F8
	private static object .cctor() { }

	// RVA: 0x7319458
	public object .ctor() { }

	// RVA: 0x7319460
	internal object <SortNotifications>b__12_0(object x, object y) { }

}

// Namespace: UnityEngine.Timeline
public class TimeNotificationBehaviour
{

	// Fields
	private readonly object m_Notifications; // 0x8
	private object m_PreviousTime; // 0x10
	private object m_NeedSortNotifications; // 0x18
	private object m_TimeSource; // 0x20

	// Properties
	public object timeSource { set; }

	// Methods

	// RVA: 0x73182BC
	public object set_timeSource(object value) { }

	// RVA: 0x73182C4
	public static object Create(object graph, object duration, object loopMode) { }

	// RVA: 0x73183EC
	public object AddNotification(object time, object payload, object flags) { }

	// RVA: 0x7318554
	public override object OnGraphStart(object playable) { }

	// RVA: 0x731886C
	public override object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x7318B38
	public override object PrepareFrame(object playable, object info) { }

	// RVA: 0x731872C
	private object SortNotifications() { }

	// RVA: 0x7319270
	private static object CanRestoreNotification(object e, object info, object currentTime, object previousTime) { }

	// RVA: 0x7318FB8
	private object TriggerNotificationsInRange(object start, object end, object info, object playable, object checkState) { }

	// RVA: 0x7318EB0
	private object SyncDurationWithExternalSource(object playable) { }

	// RVA: 0x7318AA4
	private static object Trigger_internal(object playable, object output, object e) { }

	// RVA: 0x73192F8
	private static object Restore_internal(object e) { }

	// RVA: 0x7319318
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class PlayableTrack
{

	// Methods

	// RVA: 0x7319470
	protected override object OnCreateClip(object clip) { }

	// RVA: 0x7319568
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class TrackMediaType
{

	// Fields
	public readonly object m_MediaType; // 0x8

	// Methods

	// RVA: 0x73195F0
	public object .ctor(object mt) { }

}

// Namespace: UnityEngine.Timeline
public class TrackClipTypeAttribute
{

	// Fields
	public readonly object inspectedType; // 0x8
	public readonly object allowAutoCreate; // 0x10

	// Methods

	// RVA: 0x731961C
	public object .ctor(object clipClass) { }

	// RVA: 0x7319650
	public object .ctor(object clipClass, object allowAutoCreate) { }

}

// Namespace: UnityEngine.Timeline
public class NotKeyableAttribute
{

	// Methods

	// RVA: 0x731967C
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public enum TrackBindingFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object AllowCreateComponent;
	public const object All;
}

// Namespace: UnityEngine.Timeline
public class TrackBindingTypeAttribute
{

	// Fields
	public readonly object type; // 0x8
	public readonly object flags; // 0x10

	// Methods

	// RVA: 0x7319684
	public object .ctor(object type) { }

	// RVA: 0x73196B8
	public object .ctor(object type, object flags) { }

}

// Namespace: UnityEngine.Timeline
public class SupportsChildTracksAttribute
{

	// Fields
	public readonly object childType; // 0x8
	public readonly object levels; // 0x10

	// Methods

	// RVA: 0x73196F4
	public object .ctor(object childType, object levels) { }

}

// Namespace: UnityEngine.Timeline
internal class IgnoreOnPlayableTrackAttribute
{

	// Methods

	// RVA: 0x7319730
	public object .ctor() { }

}

// Namespace: 
public enum UseEditMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ApplyEditMode;
}

// Namespace: UnityEngine.Timeline
internal class TimeFieldAttribute
{

	// Fields
	private readonly object <useEditMode>k__BackingField; // 0x8

	// Properties
	public object useEditMode { get; }

	// Methods

	// RVA: 0x7319738
	public object get_useEditMode() { }

	// RVA: 0x7319740
	public object .ctor(object useEditMode) { }

}

// Namespace: UnityEngine.Timeline
internal class FrameRateFieldAttribute
{

	// Methods

	// RVA: 0x731976C
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class HideInMenuAttribute
{

	// Methods

	// RVA: 0x7319774
	public object .ctor() { }

}

// Namespace: UnityEngine.Timeline
public class CustomStyleAttribute
{

	// Fields
	public readonly object ussStyle; // 0x8

	// Methods

	// RVA: 0x731977C
	public object .ctor(object ussStyle) { }

}

// Namespace: UnityEngine.Timeline
internal class MenuCategoryAttribute
{

	// Fields
	public readonly object category; // 0x8

	// Methods

	// RVA: 0x73197A8
	public object .ctor(object category) { }

}

// Namespace: UnityEngine.Timeline
public interface ITimelineClipAsset
{

	// Properties
	public abstract object clipCaps { get; }

	// Methods

	// RVA: -1
	public abstract object get_clipCaps() { }

}

// Namespace: UnityEngine.Timeline
internal interface ITimelineEvaluateCallback
{

	// Methods

	// RVA: -1
	public abstract object Evaluate() { }

}

// Namespace: UnityEngine.Timeline
public class TimelinePlayable
{

	// Fields
	private object m_IntervalTree; // 0x8
	private object m_ActiveClips; // 0x10
	private object m_CurrentListOfActiveClips; // 0x18
	private object m_ActiveBit; // 0x20
	private object m_EvaluateCallbacks; // 0x28
	private object m_PlayableCache; // 0x30
	internal static object muteAudioScrubbing; // 0x0

	// Methods

	// RVA: 0x731983C
	public static object Create(object graph, object tracks, object go, object autoRebalance, object createOutputs) { }

	// RVA: 0x7319A5C
	public object Compile(object graph, object timelinePlayable, object tracks, object go, object autoRebalance, object createOutputs) { }

	// RVA: 0x7319D08
	private object CompileTrackList(object graph, object timelinePlayable, object tracks, object go, object createOutputs) { }

	// RVA: 0x731A588
	private object CreateTrackOutput(object graph, object track, object go, object playable, object port) { }

	// RVA: 0x731ACBC
	private object EvaluateWeightsForAnimationPlayableOutput(object track, object animOutput) { }

	// RVA: 0x731AE1C
	private object EvaluateAnimationPreviewUpdateCallback(object track, object animOutput) { }

	// RVA: 0x731A0F8
	private object CreateTrackPlayable(object graph, object timelinePlayable, object track, object go, object createOutputs) { }

	// RVA: 0x731B000
	public override object PrepareFrame(object playable, object info) { }

	// RVA: 0x731B030
	private object Evaluate(object playable, object frameData) { }

	// RVA: 0x731AF7C
	private object CacheTrack(object track, object playable, object port, object parent) { }

	// RVA: 0x731B790
	private static object ForAOTCompilationOnly() { }

	// RVA: 0x731B7F8
	public object .ctor() { }

	// RVA: 0x731B950
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__2_0; // 0x8

	// Methods

	// RVA: 0x731C040
	private static object .cctor() { }

	// RVA: 0x731C0A0
	public object .ctor() { }

	// RVA: 0x731C0A8
	internal object <SortClipsByStartTime>b__2_0(object clip1, object clip2) { }

}

// Namespace: UnityEngine.Timeline
internal static class Extrapolation
{

	// Fields
	internal static readonly object kMinExtrapolationTime; // 0x0

	// Methods

	// RVA: 0x731B9A0
	internal static object CalculateExtrapolationTimes(object asset) { }

	// RVA: 0x731BE50
	private static object SortClipsByStartTime(object clips) { }

	// RVA: 0x731BFB4
	private static object .cctor() { }

}

// Namespace: UnityEngine.Timeline
internal static class HashUtility
{

	// Methods

	// RVA: 0x731C0F8
	public static object CombineHash(object h1, object h2) { }

	// RVA: 0x731C114
	public static object CombineHash(object h1, object h2, object h3) { }

	// RVA: 0x731C140
	public static object CombineHash(object h1, object h2, object h3, object h4) { }

	// RVA: 0x731C17C
	public static object CombineHash(object h1, object h2, object h3, object h4, object h5) { }

	// RVA: 0x731C1C8
	public static object CombineHash(object h1, object h2, object h3, object h4, object h5, object h6) { }

	// RVA: 0x731C224
	public static object CombineHash(object h1, object h2, object h3, object h4, object h5, object h6, object h7) { }

	// RVA: 0x731C290
	public static object CombineHash(object hashes) { }

}

// Namespace: UnityEngine.Timeline
public interface IPropertyCollector
{

	// Methods

	// RVA: -1
	public abstract object PushActiveGameObject(object gameObject) { }

	// RVA: -1
	public abstract object PopActiveGameObject() { }

	// RVA: -1
	public abstract object AddFromClip(object clip) { }

	// RVA: -1
	public abstract object AddFromClips(object clips) { }

	// RVA: -1
	public abstract object AddFromName(object name) { }

	// RVA: -1
	public abstract object AddFromName(object name) { }

	// RVA: -1
	public abstract object AddFromClip(object obj, object clip) { }

	// RVA: -1
	public abstract object AddFromClips(object obj, object clips) { }

	// RVA: -1
	public abstract object AddFromName(object obj, object name) { }

	// RVA: -1
	public abstract object AddFromName(object obj, object name) { }

	// RVA: -1
	public abstract object AddFromName(object component, object name) { }

	// RVA: -1
	public abstract object AddFromComponent(object obj, object component) { }

	// RVA: -1
	public abstract object AddObjectProperties(object obj, object clip) { }

}

// Namespace: UnityEngine.Timeline
public interface IPropertyPreview
{

	// Methods

	// RVA: -1
	public abstract object GatherProperties(object director, object driver) { }

}

// Namespace: UnityEngine.Timeline
internal static class NotificationUtilities
{

	// Methods

	// RVA: 0x731C304
	public static object CreateNotificationsPlayable(object graph, object markers, object director) { }

	// RVA: 0x731CCD0
	public static object CreateNotificationsPlayable(object graph, object markers, object timelineAsset) { }

	// RVA: 0x731C310
	private static object CreateNotificationsPlayable(object graph, object markers, object asset, object director) { }

	// RVA: 0x731CCD8
	public static object TrackTypeSupportsNotifications(object type) { }

}

// Namespace: UnityEngine.Timeline
public static class TimelineClipExtensions
{

	// Fields
	private static readonly object k_UndoSetParentTrackText; // 0x0

	// Methods

	// RVA: 0x731CECC
	public static object MoveToTrack(object clip, object destinationTrack) { }

	// RVA: 0x731D484
	public static object TryMoveToTrack(object clip, object destinationTrack) { }

	// RVA: 0x731D290
	private static object MoveToTrack_Impl(object clip, object destinationTrack, object asset, object parentTrack) { }

	// RVA: 0x731D888
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass0_0
{

	// Fields
	public object name; // 0x8

	// Methods

	// RVA: 0x731DC30
	public object .ctor() { }

	// RVA: 0x731E294
	internal object <GenerateUniqueActorName>b__0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass0_1
{

	// Fields
	public object result; // 0x8

	// Methods

	// RVA: 0x731DC38
	public object .ctor() { }

	// RVA: 0x731E2D0
	internal object <GenerateUniqueActorName>b__1(object x) { }

}

// Namespace: UnityEngine.Timeline
internal static class TimelineCreateUtilities
{

	// Methods

	// RVA: 0x731D8F4
	public static object GenerateUniqueActorName(object tracks, object name) { }

	// RVA: 0x731D67C
	public static object SaveAssetIntoObject(object childAsset, object masterAsset) { }

	// RVA: 0x731D7C8
	public static object RemoveAssetFromObject(object childAsset, object masterAsset) { }

	// RVA: 0x731DC40
	public static object CreateAnimationClipForTrack(object name, object track, object isLegacy) { }

	// RVA: 0x731DE94
	public static object ValidateParentTrack(object parent, object childType) { }

}

// Namespace: UnityEngine.Timeline
internal static class TimelineUndo
{

	// Properties
	internal static object undoEnabled { get; }

	// Methods

	// RVA: 0x731E30C
	internal static object get_undoEnabled() { }

	// RVA: 0x731E314
	public static object PushDestroyUndo(object timeline, object thingToDirty, object objectToDestroy) { }

	// RVA: 0x731E3E4
	public static object PushUndo(object thingsToDirty, object operation) { }

	// RVA: 0x731E3E8
	public static object PushUndo(object thingToDirty, object operation) { }

	// RVA: 0x731E3EC
	public static object RegisterCreatedObjectUndo(object thingCreated, object operation) { }

	// RVA: 0x731E3F0
	internal static object UndoName(object name) { }

}

// Namespace: UnityEngine.Timeline
public enum StandardFrameRates
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Fps24;
	public const object Fps23_97;
	public const object Fps25;
	public const object Fps30;
	public const object Fps29_97;
	public const object Fps50;
	public const object Fps60;
	public const object Fps59_94;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__19_0; // 0x8
	public static object <>9__19_1; // 0x10
	public static object <>9__20_0; // 0x18

	// Methods

	// RVA: 0x73208AC
	private static object .cctor() { }

	// RVA: 0x732090C
	public object .ctor() { }

	// RVA: 0x7320914
	internal object <ParseTimeCode>b__19_0(object c) { }

	// RVA: 0x732099C
	internal object <ParseTimeCode>b__19_1(object c) { }

	// RVA: 0x73209B0
	internal object <ParseTimeSeconds>b__20_0(object c) { }

}

// Namespace: UnityEngine.Timeline
internal static class TimeUtility
{

	// Fields
	public static readonly object kTimeEpsilon; // 0x0
	public static readonly object kFrameRateEpsilon; // 0x8
	public static readonly object k_MaxTimelineDurationInSeconds; // 0x10
	public static readonly object kFrameRateRounding; // 0x18

	// Methods

	// RVA: 0x731E448
	private static object ValidateFrameRate(object frameRate) { }

	// RVA: 0x731E51C
	public static object ToFrames(object time, object frameRate) { }

	// RVA: 0x731E760
	public static object ToExactFrames(object time, object frameRate) { }

	// RVA: 0x731E7CC
	public static object FromFrames(object frames, object frameRate) { }

	// RVA: 0x731E844
	public static object FromFrames(object frames, object frameRate) { }

	// RVA: 0x731E8B0
	public static object OnFrameBoundary(object time, object frameRate) { }

	// RVA: 0x731E6B4
	public static object GetEpsilon(object time, object frameRate) { }

	// RVA: 0x731EB88
	public static object PreviousFrame(object time, object frameRate) { }

	// RVA: 0x731EC28
	public static object NextFrame(object time, object frameRate) { }

	// RVA: 0x731EC98
	public static object PreviousFrameTime(object time, object frameRate) { }

	// RVA: 0x731EDE8
	public static object NextFrameTime(object time, object frameRate) { }

	// RVA: 0x731E9D4
	public static object OnFrameBoundary(object time, object frameRate, object epsilon) { }

	// RVA: 0x731EEFC
	public static object RoundToFrame(object time, object frameRate) { }

	// RVA: 0x731F008
	public static object TimeAsFrames(object timeValue, object frameRate, object format) { }

	// RVA: 0x731F148
	public static object TimeAsTimeCode(object timeValue, object frameRate, object format) { }

	// RVA: 0x731F614
	public static object ParseTimeCode(object timeCode, object frameRate, object defaultValue) { }

	// RVA: 0x731FC7C
	public static object ParseTimeSeconds(object timeCode, object frameRate, object defaultValue) { }

	// RVA: 0x7320058
	public static object GetAnimationClipLength(object clip) { }

	// RVA: 0x731FB80
	private static object RemoveChar(object str, object charToRemoveFunc) { }

	// RVA: 0x7320208
	public static object GetClosestFrameRate(object frameRate) { }

	// RVA: 0x7320300
	public static object ToFrameRate(object enumValue) { }

	// RVA: 0x73204D0
	internal static object ToStandardFrameRate(object rate, object standard) { }

	// RVA: 0x7320850
	private static object .cctor() { }

}

// Namespace: UnityEngine.Timeline
internal static class WeightUtility
{

	// Methods

	// RVA: 0x7320A38
	public static object NormalizeMixer(object mixer) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=4515
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=12931
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object C11E3352A3B66DB6A3774678D698E2747883742B9DB05A08586D0614746DE40A; // 0x0
	internal static readonly object C35BF20212C0375281353CB8EFC5E59EC993401499182DB7B9BD6B5851F9D1E8; // 0x3283
}

