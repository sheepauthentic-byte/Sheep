// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.U2D
public class SpriteShapeRenderer
{
}

