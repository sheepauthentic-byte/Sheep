// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.AI
public struct NavMeshHit
{

	// Fields
	private object m_Position; // 0xFFFFFFFFFFFFFFF8
	private object m_Normal; // 0x4
	private object m_Distance; // 0x10
	private object m_Mask; // 0x14
	private object m_Hit; // 0x18

	// Properties
	public object position { get; }

	// Methods

	// RVA: 0x73210B0
	public object get_position() { }

}

// Namespace: 
public sealed class OnNavMeshPreUpdate
{

	// Methods

	// RVA: 0x7321280
	public object .ctor(object object, object method) { }

	// RVA: 0x7321314
	public virtual object Invoke() { }

}

// Namespace: UnityEngine.AI
public static class NavMesh
{

	// Fields
	public static object onPreUpdate; // 0x0

	// Methods

	// RVA: 0x73210C8
	private static object Internal_CallOnNavMeshPreUpdate() { }

	// RVA: 0x7321130
	public static object SamplePosition(object sourcePosition, object hit, object maxDistance, object areaMask) { }

	// RVA: 0x73211A8
	private static object SamplePosition_Injected(object sourcePosition, object hit, object maxDistance, object areaMask) { }

}

