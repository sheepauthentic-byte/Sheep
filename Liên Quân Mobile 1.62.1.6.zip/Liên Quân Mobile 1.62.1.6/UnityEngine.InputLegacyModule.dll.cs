// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public enum TouchPhase
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Began;
	public const object Moved;
	public const object Stationary;
	public const object Ended;
	public const object Canceled;
}

// Namespace: UnityEngine
public enum IMECompositionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object On;
	public const object Off;
}

// Namespace: UnityEngine
public enum TouchType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Direct;
	public const object Indirect;
	public const object Stylus;
}

// Namespace: UnityEngine
public struct Touch
{

	// Fields
	private object m_FingerId; // 0xFFFFFFFFFFFFFFF8
	private object m_Position; // 0xFFFFFFFFFFFFFFFC
	private object m_RawPosition; // 0x4
	private object m_PositionDelta; // 0xC
	private object m_TimeDelta; // 0x14
	private object m_TapCount; // 0x18
	private object m_Phase; // 0x1C
	private object m_Type; // 0x20
	private object m_Pressure; // 0x24
	private object m_maximumPossiblePressure; // 0x28
	private object m_Radius; // 0x2C
	private object m_RadiusVariance; // 0x30
	private object m_AltitudeAngle; // 0x34
	private object m_AzimuthAngle; // 0x38

	// Properties
	public object fingerId { get; }
	public object position { get; set; }
	public object rawPosition { get; set; }
	public object deltaPosition { get; set; }
	public object deltaTime { get; }
	public object tapCount { get; }
	public object phase { get; }
	public object pressure { get; }
	public object maximumPossiblePressure { get; }
	public object type { get; }
	public object altitudeAngle { get; }
	public object azimuthAngle { get; }
	public object radius { get; }
	public object radiusVariance { get; }

	// Methods

	// RVA: 0x7436C58
	public object get_fingerId() { }

	// RVA: 0x7436C68
	public object get_position() { }

	// RVA: 0x7436C78
	public object set_position(object value) { }

	// RVA: 0x7436C88
	public object get_rawPosition() { }

	// RVA: 0x7436C98
	public object set_rawPosition(object value) { }

	// RVA: 0x7436CA8
	public object get_deltaPosition() { }

	// RVA: 0x7436CB8
	public object set_deltaPosition(object value) { }

	// RVA: 0x7436CC8
	public object get_deltaTime() { }

	// RVA: 0x7436CD8
	public object get_tapCount() { }

	// RVA: 0x7436CE8
	public object get_phase() { }

	// RVA: 0x7436CF8
	public object get_pressure() { }

	// RVA: 0x7436D08
	public object get_maximumPossiblePressure() { }

	// RVA: 0x7436D18
	public object get_type() { }

	// RVA: 0x7436D28
	public object get_altitudeAngle() { }

	// RVA: 0x7436D38
	public object get_azimuthAngle() { }

	// RVA: 0x7436D48
	public object get_radius() { }

	// RVA: 0x7436D58
	public object get_radiusVariance() { }

}

// Namespace: UnityEngine
public enum PenStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Contact;
	public const object Barrel;
	public const object Inverted;
	public const object Eraser;
}

// Namespace: UnityEngine
public enum PenEventType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoContact;
	public const object PenDown;
	public const object PenUp;
}

// Namespace: UnityEngine
public struct PenData
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object tilt; // 0x0
	public object penStatus; // 0x8
	public object twist; // 0xC
	public object pressure; // 0x10
	public object contactType; // 0x14
	public object deltaPos; // 0x18
}

// Namespace: UnityEngine
public class Gyroscope
{

	// Fields
	private object m_GyroIndex; // 0x8

	// Properties
	public object rotationRateUnbiased { get; }
	public object gravity { get; }
	public object attitude { get; }
	public object enabled { get; set; }
	public object updateInterval { set; }

	// Methods

	// RVA: 0x7436D68
	internal object .ctor(object index) { }

	// RVA: 0x7436D94
	private static object rotationRateUnbiased_Internal(object idx) { }

	// RVA: 0x7436E5C
	private static object gravity_Internal(object idx) { }

	// RVA: 0x7436F24
	private static object attitude_Internal(object idx) { }

	// RVA: 0x7436FE8
	private static object getEnabled_Internal(object idx) { }

	// RVA: 0x7437038
	private static object setEnabled_Internal(object idx, object enabled) { }

	// RVA: 0x743709C
	private static object setUpdateInterval_Internal(object idx, object interval) { }

	// RVA: 0x7437100
	public object get_rotationRateUnbiased() { }

	// RVA: 0x7437160
	public object get_gravity() { }

	// RVA: 0x74371C0
	public object get_attitude() { }

	// RVA: 0x743721C
	public object get_enabled() { }

	// RVA: 0x743726C
	public object set_enabled(object value) { }

	// RVA: 0x74372D0
	public object set_updateInterval(object value) { }

	// RVA: 0x7436DF8
	private static object rotationRateUnbiased_Internal_Injected(object idx, object ret) { }

	// RVA: 0x7436EC0
	private static object gravity_Internal_Injected(object idx, object ret) { }

	// RVA: 0x7436F84
	private static object attitude_Internal_Injected(object idx, object ret) { }

}

// Namespace: UnityEngine
public struct LocationInfo
{

	// Fields
	internal object m_Timestamp; // 0xFFFFFFFFFFFFFFF8
	internal object m_Latitude; // 0x0
	internal object m_Longitude; // 0x4
	internal object m_Altitude; // 0x8
	internal object m_HorizontalAccuracy; // 0xC
	internal object m_VerticalAccuracy; // 0x10

	// Properties
	public object latitude { get; }
	public object longitude { get; }

	// Methods

	// RVA: 0x7437334
	public object get_latitude() { }

	// RVA: 0x7437344
	public object get_longitude() { }

}

// Namespace: UnityEngine
public enum LocationServiceStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Stopped;
	public const object Initializing;
	public const object Running;
	public const object Failed;
}

// Namespace: UnityEngine
public class LocationService
{

	// Properties
	public object isEnabledByUser { get; }
	public object status { get; }
	public object lastData { get; }

	// Methods

	// RVA: 0x7437354
	internal static object IsServiceEnabledByUser() { }

	// RVA: 0x7437394
	internal static object GetLocationStatus() { }

	// RVA: 0x74373D4
	internal static object GetLastLocation() { }

	// RVA: 0x7437480
	internal static object SetDesiredAccuracy(object value) { }

	// RVA: 0x74374D4
	internal static object SetDistanceFilter(object value) { }

	// RVA: 0x7437528
	internal static object StartUpdatingLocation() { }

	// RVA: 0x7437568
	internal static object StopUpdatingLocation() { }

	// RVA: 0x74375A8
	public object get_isEnabledByUser() { }

	// RVA: 0x74375E8
	public object get_status() { }

	// RVA: 0x7437628
	public object get_lastData() { }

	// RVA: 0x7437738
	public object Start(object desiredAccuracyInMeters, object updateDistanceInMeters) { }

	// RVA: 0x74377F8
	public object Stop() { }

	// RVA: 0x7437838
	public object .ctor() { }

	// RVA: 0x7437430
	private static object GetLastLocation_Injected(object ret) { }

}

// Namespace: UnityEngine
internal class CameraRaycastHelper
{

	// Methods

	// RVA: 0x7437840
	internal static object RaycastTry(object cam, object ray, object distance, object layerMask) { }

	// RVA: 0x7437940
	internal static object RaycastTry2D(object cam, object ray, object distance, object layerMask) { }

	// RVA: 0x74378C0
	private static object RaycastTry_Injected(object cam, object ray, object distance, object layerMask) { }

	// RVA: 0x74379C0
	private static object RaycastTry2D_Injected(object cam, object ray, object distance, object layerMask) { }

}

// Namespace: UnityEngine
public class Input
{

	// Fields
	private static object locationServiceInstance; // 0x0
	private static object s_MainGyro; // 0x8

	// Properties
	public static object anyKey { get; }
	public static object mousePosition { get; }
	public static object mouseScrollDelta { get; }
	public static object imeCompositionMode { get; set; }
	public static object compositionString { get; }
	public static object compositionCursorPos { get; set; }
	public static object mousePresent { get; }
	public static object touchCount { get; }
	public static object touchSupported { get; }
	public static object acceleration { get; }
	public static object location { get; }
	public static object gyro { get; }
	public static object touches { get; }

	// Methods

	// RVA: 0x7437A40
	public static object GetAxis(object axisName) { }

	// RVA: 0x7437AE0
	public static object GetAxisRaw(object axisName) { }

	// RVA: 0x7437B80
	public static object GetButton(object buttonName) { }

	// RVA: 0x7437C20
	public static object GetButtonDown(object buttonName) { }

	// RVA: 0x7437CC0
	private static object GetKeyInt(object key) { }

	// RVA: 0x7437D10
	private static object GetKeyUpInt(object key) { }

	// RVA: 0x7437D60
	private static object GetKeyDownInt(object key) { }

	// RVA: 0x7437DB0
	public static object GetMouseButton(object button) { }

	// RVA: 0x7437E00
	public static object GetMouseButtonDown(object button) { }

	// RVA: 0x7437E50
	public static object GetMouseButtonUp(object button) { }

	// RVA: 0x7437EA0
	public static object GetTouch(object index) { }

	// RVA: 0x7437F8C
	public static object GetLastPenContactEvent() { }

	// RVA: 0x7438044
	public static object ClearLastPenContactEvent() { }

	// RVA: 0x7438084
	public static object GetKey(object key) { }

	// RVA: 0x74380D4
	public static object GetKeyUp(object key) { }

	// RVA: 0x7438124
	public static object GetKeyDown(object key) { }

	// RVA: 0x7438174
	public static object get_anyKey() { }

	// RVA: 0x74381B4
	public static object get_mousePosition() { }

	// RVA: 0x743825C
	public static object get_mouseScrollDelta() { }

	// RVA: 0x74382FC
	public static object get_imeCompositionMode() { }

	// RVA: 0x743833C
	public static object set_imeCompositionMode(object value) { }

	// RVA: 0x743838C
	public static object get_compositionString() { }

	// RVA: 0x74383CC
	public static object get_compositionCursorPos() { }

	// RVA: 0x743846C
	public static object set_compositionCursorPos(object value) { }

	// RVA: 0x7438520
	public static object get_mousePresent() { }

	// RVA: 0x7438560
	public static object get_touchCount() { }

	// RVA: 0x74385A0
	public static object get_touchSupported() { }

	// RVA: 0x74385E0
	public static object get_acceleration() { }

	// RVA: 0x7438688
	public static object get_location() { }

	// RVA: 0x743872C
	private static object GetGyroInternal() { }

	// RVA: 0x743876C
	public static object get_gyro() { }

	// RVA: 0x7438844
	public static object get_touches() { }

	// RVA: 0x74389C8
	internal static object CheckDisabled() { }

	// RVA: 0x7437F28
	private static object GetTouch_Injected(object index, object ret) { }

	// RVA: 0x7437FF4
	private static object GetLastPenContactEvent_Injected(object ret) { }

	// RVA: 0x743820C
	private static object get_mousePosition_Injected(object ret) { }

	// RVA: 0x74382AC
	private static object get_mouseScrollDelta_Injected(object ret) { }

	// RVA: 0x743841C
	private static object get_compositionCursorPos_Injected(object ret) { }

	// RVA: 0x74384D0
	private static object set_compositionCursorPos_Injected(object value) { }

	// RVA: 0x7438638
	private static object get_acceleration_Injected(object ret) { }

}

// Namespace: 
private struct HitInfo
{

	// Fields
	public object target; // 0xFFFFFFFFFFFFFFF8
	public object camera; // 0x0

	// Methods

	// RVA: 0x743A174
	public object SendMessage(object name) { }

	// RVA: 0x743A0B4
	public static object op_Implicit(object exists) { }

	// RVA: 0x743A1A0
	public static object Compare(object lhs, object rhs) { }

}

// Namespace: UnityEngine
internal class SendMouseEvents
{

	// Fields
	private static object s_MouseUsed; // 0x0
	private static readonly object m_LastHit; // 0x8
	private static readonly object m_MouseDownHit; // 0x10
	private static readonly object m_CurrentHit; // 0x18
	private static object m_Cameras; // 0x20
	public static object s_GetMouseState; // 0x28
	private static object s_MousePosition; // 0x30
	private static object s_MouseButtonPressedThisFrame; // 0x38
	private static object s_MouseButtonIsPressed; // 0x39

	// Methods

	// RVA: 0x7438A08
	private static object UpdateMouse() { }

	// RVA: 0x7438C68
	private static object SetMouseMoved() { }

	// RVA: 0x7438CEC
	private static object DoSendMouseEvents(object skipRTCameras) { }

	// RVA: 0x74396E8
	private static object SendEvents(object i, object hit) { }

	// RVA: 0x743A274
	private static object .cctor() { }

}

// Namespace: UnityEngine.Internal
internal static class InputUnsafeUtility
{

	// Methods

	// RVA: 0x743A38C
	internal static object GetKeyString__Unmanaged(object name, object nameLen) { }

	// RVA: 0x743A3F0
	internal static object GetKeyUpString__Unmanaged(object name, object nameLen) { }

	// RVA: 0x743A454
	internal static object GetKeyDownString__Unmanaged(object name, object nameLen) { }

	// RVA: 0x7437A90
	internal static object GetAxis(object axisName) { }

	// RVA: 0x743A4B8
	internal static object GetAxis__Unmanaged(object axisName, object axisNameLen) { }

	// RVA: 0x7437B30
	internal static object GetAxisRaw(object axisName) { }

	// RVA: 0x743A51C
	internal static object GetAxisRaw__Unmanaged(object axisName, object axisNameLen) { }

	// RVA: 0x7437BD0
	internal static object GetButton(object buttonName) { }

	// RVA: 0x743A580
	internal static object GetButton__Unmanaged(object buttonName, object buttonNameLen) { }

	// RVA: 0x7437C70
	internal static object GetButtonDown(object buttonName) { }

	// RVA: 0x743A5E4
	internal static object GetButtonDown__Unmanaged(object buttonName, object buttonNameLen) { }

	// RVA: 0x743A648
	internal static object GetButtonUp__Unmanaged(object buttonName, object buttonNameLen) { }

}

