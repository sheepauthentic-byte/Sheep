// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public sealed class Terrain
{

	// Properties
	public object terrainData { get; }
	public object lightmapIndex { get; set; }
	public object lightmapScaleOffset { set; }
	public object allowAutoConnect { get; }
	public object groupingID { get; }
	public static object activeTerrains { get; }

	// Methods

	// RVA: 0x7498BF4
	public object get_terrainData() { }

	// RVA: 0x7498C44
	public object get_lightmapIndex() { }

	// RVA: 0x7498C94
	public object set_lightmapIndex(object value) { }

	// RVA: 0x7498CF8
	public object set_lightmapScaleOffset(object value) { }

	// RVA: 0x7498DD0
	public object get_allowAutoConnect() { }

	// RVA: 0x7498E20
	public object get_groupingID() { }

	// RVA: 0x7498E70
	public object SetNeighbors(object left, object top, object right, object bottom) { }

	// RVA: 0x7498EF8
	public object SetSplatMaterialPropertyBlock(object properties) { }

	// RVA: 0x7498F5C
	public static object get_activeTerrains() { }

	// RVA: 0x7498F9C
	public object .ctor() { }

	// RVA: 0x7498D6C
	private object set_lightmapScaleOffset_Injected(object value) { }

}

// Namespace: 
public sealed class HeightmapChangedCallback
{

	// Methods

	// RVA: 0x7499308
	public object .ctor(object object, object method) { }

	// RVA: 0x74993B8
	public virtual object Invoke(object terrain, object heightRegion, object synched) { }

}

// Namespace: 
public sealed class TextureChangedCallback
{

	// Methods

	// RVA: 0x74994A8
	public object .ctor(object object, object method) { }

	// RVA: 0x7499558
	public virtual object Invoke(object terrain, object textureName, object texelRegion, object synched) { }

}

// Namespace: UnityEngine
public static class TerrainCallbacks
{

	// Fields
	private static object heightmapChanged; // 0x0
	private static object textureChanged; // 0x8

	// Methods

	// RVA: 0x7498FA4
	internal static object InvokeHeightmapChangedCallback(object terrainData, object heightRegion, object synched) { }

	// RVA: 0x7499118
	internal static object InvokeTextureChangedCallback(object terrainData, object textureName, object texelRegion, object synched) { }

}

// Namespace: UnityEngine
public sealed class TreePrototype
{

	// Fields
	internal object m_Prefab; // 0x8
	internal object m_BendFactor; // 0x10
	internal object m_NavMeshLod; // 0x14

	// Properties
	public object prefab { get; }
	public object bendFactor { get; }
	public object navMeshLod { get; }

	// Methods

	// RVA: 0x74995A8
	public object get_prefab() { }

	// RVA: 0x74995B0
	public object get_bendFactor() { }

	// RVA: 0x74995B8
	public object get_navMeshLod() { }

	// RVA: 0x74995C0
	public object .ctor() { }

	// RVA: 0x74995C8
	public override object Equals(object obj) { }

	// RVA: 0x74997BC
	public override object GetHashCode() { }

	// RVA: 0x7499648
	private object Equals(object other) { }

}

// Namespace: UnityEngine
public struct TreeInstance
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object widthScale; // 0x4
	public object heightScale; // 0x8
	public object rotation; // 0xC
	public object color; // 0x10
	public object lightmapColor; // 0x14
	public object prototypeIndex; // 0x18
	internal object temporaryDistance; // 0x1C
}

// Namespace: 
private enum BoundaryValueType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MaxHeightmapRes;
	public const object MinDetailResPerPatch;
	public const object MaxDetailResPerPatch;
	public const object MaxDetailPatchCount;
	public const object MaxCoveragePerRes;
	public const object MinAlphamapRes;
	public const object MaxAlphamapRes;
	public const object MinBaseMapRes;
	public const object MaxBaseMapRes;
}

// Namespace: UnityEngine
public sealed class TerrainData
{

	// Fields
	internal static readonly object k_MaximumResolution; // 0x0
	internal static readonly object k_MinimumDetailResolutionPerPatch; // 0x4
	internal static readonly object k_MaximumDetailResolutionPerPatch; // 0x8
	internal static readonly object k_MaximumDetailPatchCount; // 0xC
	internal static readonly object k_MinimumAlphamapResolution; // 0x10
	internal static readonly object k_MaximumAlphamapResolution; // 0x14
	internal static readonly object k_MinimumBaseMapResolution; // 0x18
	internal static readonly object k_MaximumBaseMapResolution; // 0x1C

	// Properties
	public object size { get; }
	public object treeInstances { get; }
	public object treePrototypes { get; }
	internal object users { get; }

	// Methods

	// RVA: 0x74997C4
	private static object GetBoundaryValue(object type) { }

	// RVA: 0x7499814
	public object .ctor() { }

	// RVA: 0x7499910
	private static object Internal_Create(object terrainData) { }

	// RVA: 0x7499960
	public object get_size() { }

	// RVA: 0x7499A28
	public object get_treeInstances() { }

	// RVA: 0x7499A78
	private object Internal_GetTreeInstances() { }

	// RVA: 0x7499AC8
	public object get_treePrototypes() { }

	// RVA: 0x7499B18
	internal object GetAlphamapResolutionInternal() { }

	// RVA: 0x74990C8
	internal object get_users() { }

	// RVA: 0x7499B68
	private static object .cctor() { }

	// RVA: 0x74999C4
	private object get_size_Injected(object ret) { }

}

// Namespace: UnityEngine.TerrainUtils
internal enum TerrainMapStatusCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OK;
	public const object Overlapping;
	public const object SizeMismatch;
	public const object EdgeAlignmentMismatch;
}

// Namespace: UnityEngine.TerrainUtils
public struct TerrainTileCoord
{

	// Fields
	public readonly object tileX; // 0xFFFFFFFFFFFFFFF8
	public readonly object tileZ; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x7499D2C
	public object .ctor(object tileX, object tileZ) { }

}

// Namespace: 
private sealed class <>c__DisplayClass3_0
{

	// Fields
	public object groupID; // 0x8

	// Methods

	// RVA: 0x749A194
	public object .ctor() { }

	// RVA: 0x749B8AC
	internal object <CreateFromPlacement>b__0(object x) { }

}

// Namespace: UnityEngine.TerrainUtils
public class TerrainMap
{

	// Fields
	private object m_patchSize; // 0x8
	private object m_errorCode; // 0x14
	private object m_terrainTiles; // 0x18

	// Properties
	public object terrainTiles { get; }

	// Methods

	// RVA: 0x7499D3C
	public object GetTerrain(object tileX, object tileZ) { }

	// RVA: 0x7499DC8
	public static object CreateFromPlacement(object originTerrain, object filter, object fullValidation) { }

	// RVA: 0x749A19C
	public static object CreateFromPlacement(object gridOrigin, object gridSize, object filter, object fullValidation) { }

	// RVA: 0x749A9F8
	public object get_terrainTiles() { }

	// RVA: 0x749A650
	public object .ctor() { }

	// RVA: 0x749AA00
	private object AddTerrainInternal(object x, object z, object terrain) { }

	// RVA: 0x749A6D8
	private object TryToAddTerrain(object tileX, object tileZ, object terrain) { }

	// RVA: 0x749AC28
	private object ValidateTerrain(object tileX, object tileZ) { }

	// RVA: 0x749A890
	private object Validate() { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object onlyAutoConnectedTerrains; // 0x8

	// Methods

	// RVA: 0x749BF8C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_1
{

	// Fields
	public object t; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0x749BF94
	public object .ctor() { }

	// RVA: 0x749C538
	internal object <CollectTerrains>b__0(object x) { }

}

// Namespace: UnityEngine.TerrainUtils
public static class TerrainUtility
{

	// Methods

	// RVA: 0x749B91C
	internal static object ValidTerrainsExist() { }

	// RVA: 0x749B9A4
	internal static object ClearConnectivity() { }

	// RVA: 0x749BAC4
	internal static object CollectTerrains(object onlyAutoConnectedTerrains) { }

	// RVA: 0x749BF9C
	public static object AutoConnect() { }

}

