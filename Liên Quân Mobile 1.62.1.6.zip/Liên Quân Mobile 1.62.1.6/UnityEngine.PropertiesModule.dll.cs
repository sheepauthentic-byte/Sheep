// Namespace: 
internal class <Module>
{
}

// Namespace: Unity.Properties
public class CreatePropertyAttribute
{

	// Methods

	// RVA: 0x749259C
	public object .ctor() { }

}

// Namespace: Unity.Properties
public class DontCreatePropertyAttribute
{
}

// Namespace: Unity.Properties
public sealed class PropertyGetter<T0, T1>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object container) { }

}

// Namespace: Unity.Properties
public sealed class PropertySetter<T0, T1>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object container, object value) { }

}

// Namespace: Unity.Properties
public class DelegateProperty<T0, T1>
{

	// Fields
	private readonly object m_Getter; // 0x0
	private readonly object m_Setter; // 0x0
	private readonly object <Name>k__BackingField; // 0x0

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: -1
	public override object get_Name() { }

	// RVA: -1
	public object .ctor(object name, object getter, object setter) { }

}

// Namespace: Unity.Properties
public interface IProperty
{

	// Methods

	// RVA: -1
	public abstract object DeclaredValueType() { }

}

// Namespace: Unity.Properties
public interface IProperty<T0>
{
}

// Namespace: Unity.Properties
public abstract class Property<T0, T1>
{

	// Fields
	private object m_Attributes; // 0x0

	// Properties
	public abstract object Name { get; }

	// Methods

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: -1
	public object DeclaredValueType() { }

	// RVA: -1
	protected object AddAttribute(object attribute) { }

	// RVA: -1
	protected object AddAttributes(object attributes) { }

	// RVA: -1
	private object Unity.Properties.Internal.IAttributes.AddAttribute(object attribute) { }

	// RVA: -1
	private object Unity.Properties.Internal.IAttributes.AddAttributes(object attributes) { }

	// RVA: -1
	public object HasAttribute() { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: Unity.Properties
internal interface IMemberInfo
{

	// Properties
	public abstract object Name { get; }
	public abstract object IsReadOnly { get; }
	public abstract object ValueType { get; }

	// Methods

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: -1
	public abstract object get_IsReadOnly() { }

	// RVA: -1
	public abstract object get_ValueType() { }

	// RVA: -1
	public abstract object GetCustomAttributes() { }

}

// Namespace: Unity.Properties
internal struct FieldMember
{

	// Fields
	internal readonly object m_FieldInfo; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object Name { get; }
	public object IsReadOnly { get; }
	public object ValueType { get; }

	// Methods

	// RVA: 0x74925E0
	public object .ctor(object fieldInfo) { }

	// RVA: 0x74925F0
	public object get_Name() { }

	// RVA: 0x7492688
	public object get_IsReadOnly() { }

	// RVA: 0x74926D0
	public object get_ValueType() { }

	// RVA: 0x7492770
	public object GetCustomAttributes() { }

}

// Namespace: Unity.Properties
internal struct PropertyMember
{

	// Fields
	internal readonly object m_PropertyInfo; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object Name { get; }
	public object IsReadOnly { get; }
	public object ValueType { get; }

	// Methods

	// RVA: 0x74927C4
	public object get_Name() { }

	// RVA: 0x749285C
	public object get_IsReadOnly() { }

	// RVA: 0x749290C
	public object get_ValueType() { }

	// RVA: 0x74929AC
	public object .ctor(object propertyInfo) { }

	// RVA: 0x74929BC
	public object GetCustomAttributes() { }

}

// Namespace: 
private sealed class GetStructValueAction
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object container) { }

}

// Namespace: 
private sealed class SetStructValueAction
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object container, object value) { }

}

// Namespace: 
private sealed class GetClassValueAction
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object container) { }

}

// Namespace: 
private sealed class SetClassValueAction
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object container, object value) { }

}

// Namespace: Unity.Properties
public class ReflectedMemberProperty<T0, T1>
{

	// Fields
	private readonly object m_Info; // 0x0
	private readonly object m_IsStructContainerType; // 0x0
	private object m_GetStructValueAction; // 0x0
	private object m_SetStructValueAction; // 0x0
	private object m_GetClassValueAction; // 0x0
	private object m_SetClassValueAction; // 0x0
	private readonly object <Name>k__BackingField; // 0x0
	private readonly object <IsReadOnly>k__BackingField; // 0x0

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: -1
	public override object get_Name() { }

	// RVA: -1
	internal object .ctor(object info, object name) { }

}

// Namespace: Unity.Properties
public sealed class ArrayPropertyBag<T0>
{

	// Properties
	protected override object InstantiationKind { get; }

	// Methods

	// RVA: -1
	protected override object get_InstantiationKind() { }

	// RVA: -1
	protected override object InstantiateWithCount(object count) { }

	// RVA: -1
	protected override object Instantiate() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Unity.Properties
public abstract class ContainerPropertyBag<T0>
{

	// Fields
	private readonly object m_PropertiesList; // 0x0
	private readonly object m_PropertiesHash; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	protected object AddProperty(object property) { }

	// RVA: -1
	public object TryGetProperty(object container, object name, object property) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: Unity.Properties
public class DictionaryPropertyBag<T0, T1>
{

	// Properties
	protected override object InstantiationKind { get; }

	// Methods

	// RVA: -1
	protected override object get_InstantiationKind() { }

	// RVA: -1
	protected override object Instantiate() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Unity.Properties
public class HashSetPropertyBag<T0>
{

	// Properties
	protected override object InstantiationKind { get; }

	// Methods

	// RVA: -1
	protected override object get_InstantiationKind() { }

	// RVA: -1
	protected override object Instantiate() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private class ListElementProperty
{

	// Fields
	internal object m_Index; // 0x0

	// Properties
	public object Index { get; }
	public override object Name { get; }

	// Methods

	// RVA: -1
	public object get_Index() { }

	// RVA: -1
	public override object get_Name() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Unity.Properties
public class IndexedCollectionPropertyBag<T0, T1>
{

	// Fields
	private readonly object m_Property; // 0x0

	// Methods

	// RVA: -1
	private object Unity.Properties.IConstructorWithCount<TList>.InstantiateWithCount(object count) { }

	// RVA: -1
	protected virtual object InstantiateWithCount(object count) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Unity.Properties
public interface IPropertyBag
{

	// Methods

	// RVA: -1
	public abstract object Accept(object visitor) { }

}

// Namespace: Unity.Properties
public interface IPropertyBag<T0>
{
}

// Namespace: 
private class KeyValuePairProperty
{

	// Fields
	private object <Key>k__BackingField; // 0x0

	// Properties
	public override object Name { get; }
	public object Key { get; }

	// Methods

	// RVA: -1
	public override object get_Name() { }

	// RVA: -1
	public object get_Key() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Unity.Properties
public class KeyValueCollectionPropertyBag<T0, T1, T2>
{

	// Fields
	private readonly object m_KeyValuePairProperty; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__7_0(object container) { }

	// RVA: -1
	internal object <.cctor>b__7_1(object container) { }

}

// Namespace: Unity.Properties
public class KeyValuePairPropertyBag<T0, T1>
{

	// Fields
	private static readonly object s_KeyProperty; // 0x0
	private static readonly object s_ValueProperty; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Unity.Properties
public class ListPropertyBag<T0>
{

	// Properties
	protected override object InstantiationKind { get; }

	// Methods

	// RVA: -1
	protected override object get_InstantiationKind() { }

	// RVA: -1
	protected override object InstantiateWithCount(object count) { }

	// RVA: -1
	protected override object Instantiate() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Unity.Properties
public static class PropertyBag
{

	// Methods

	// RVA: -1
	public static object Register(object propertyBag) { }

}

// Namespace: Unity.Properties
public abstract class PropertyBag<T0>
{

	// Fields
	private readonly object <InstantiationKind>k__BackingField; // 0x0

	// Properties
	private object Unity.Properties.IConstructor.InstantiationKind { get; }
	protected virtual object InstantiationKind { get; }

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	private object Unity.Properties.Internal.IPropertyBagRegister.Register() { }

	// RVA: -1
	public object Accept(object visitor) { }

	// RVA: -1
	private object Unity.Properties.IConstructor.get_InstantiationKind() { }

	// RVA: -1
	private object Unity.Properties.IConstructor<TContainer>.Instantiate() { }

	// RVA: -1
	protected virtual object get_InstantiationKind() { }

	// RVA: -1
	protected virtual object Instantiate() { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private class SetElementProperty
{

	// Fields
	internal object m_Value; // 0x0

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: -1
	public override object get_Name() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Unity.Properties
public class SetPropertyBagBase<T0, T1>
{

	// Fields
	private readonly object m_Property; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Unity.Properties
public interface ITypeVisitor
{

	// Methods

	// RVA: -1
	public abstract object Visit() { }

}

// Namespace: Unity.Properties
public static class TypeTraits
{

	// Methods

	// RVA: 0x74929D4
	public static object IsContainer(object type) { }

}

// Namespace: Unity.Properties
public static class TypeTraits<T0>
{

	// Fields
	private static readonly object <IsValueType>k__BackingField; // 0x0
	private static readonly object <IsPrimitive>k__BackingField; // 0x0
	private static readonly object <IsInterface>k__BackingField; // 0x0
	private static readonly object <IsAbstract>k__BackingField; // 0x0
	private static readonly object <IsArray>k__BackingField; // 0x0
	private static readonly object <IsMultidimensionalArray>k__BackingField; // 0x0
	private static readonly object <IsEnum>k__BackingField; // 0x0
	private static readonly object <IsEnumFlags>k__BackingField; // 0x0
	private static readonly object <IsNullable>k__BackingField; // 0x0
	private static readonly object <IsObject>k__BackingField; // 0x0
	private static readonly object <IsString>k__BackingField; // 0x0
	private static readonly object <IsContainer>k__BackingField; // 0x0
	private static readonly object <CanBeNull>k__BackingField; // 0x0
	private static readonly object <IsPrimitiveOrString>k__BackingField; // 0x0
	private static readonly object <IsAbstractOrInterface>k__BackingField; // 0x0
	private static readonly object <IsUnityObject>k__BackingField; // 0x0
	private static readonly object <IsLazyLoadReference>k__BackingField; // 0x0

	// Properties
	public static object IsValueType { get; }
	public static object IsPrimitive { get; }
	public static object IsInterface { get; }
	public static object IsAbstract { get; }
	public static object IsArray { get; }
	public static object IsEnum { get; }
	public static object IsNullable { get; }
	public static object IsObject { get; }
	public static object IsString { get; }
	public static object IsContainer { get; }
	public static object CanBeNull { get; }
	public static object IsAbstractOrInterface { get; }

	// Methods

	// RVA: -1
	public static object get_IsValueType() { }

	// RVA: -1
	public static object get_IsPrimitive() { }

	// RVA: -1
	public static object get_IsInterface() { }

	// RVA: -1
	public static object get_IsAbstract() { }

	// RVA: -1
	public static object get_IsArray() { }

	// RVA: -1
	public static object get_IsEnum() { }

	// RVA: -1
	public static object get_IsNullable() { }

	// RVA: -1
	public static object get_IsObject() { }

	// RVA: -1
	public static object get_IsString() { }

	// RVA: -1
	public static object get_IsContainer() { }

	// RVA: -1
	public static object get_CanBeNull() { }

	// RVA: -1
	public static object get_IsAbstractOrInterface() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Unity.Properties
public enum InstantiationKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Activator;
	public const object PropertyBagOverride;
	public const object NotInstantiatable;
}

// Namespace: Unity.Properties
internal interface IConstructor
{

	// Properties
	public abstract object InstantiationKind { get; }

	// Methods

	// RVA: -1
	public abstract object get_InstantiationKind() { }

}

// Namespace: Unity.Properties
internal interface IConstructor<T0>
{

	// Methods

	// RVA: -1
	public abstract object Instantiate() { }

}

// Namespace: Unity.Properties
internal interface IConstructorWithCount<T0>
{

	// Methods

	// RVA: -1
	public abstract object InstantiateWithCount(object count) { }

}

// Namespace: 
private interface ITypeConstructor
{

	// Properties
	public abstract object CanBeInstantiated { get; }

	// Methods

	// RVA: -1
	public abstract object get_CanBeInstantiated() { }

	// RVA: -1
	public abstract object Instantiate() { }

}

// Namespace: 
private interface ITypeConstructor<T0>
{

	// Methods

	// RVA: -1
	public abstract object Instantiate() { }

	// RVA: -1
	public abstract object SetExplicitConstructor(object constructor) { }

}

// Namespace: 
private class TypeConstructor<T0>
{

	// Fields
	private object m_ExplicitConstructor; // 0x0
	private object m_ImplicitConstructor; // 0x0
	private object m_OverrideConstructor; // 0x0

	// Properties
	private object Unity.Properties.TypeUtility.ITypeConstructor.CanBeInstantiated { get; }

	// Methods

	// RVA: -1
	private object Unity.Properties.TypeUtility.ITypeConstructor.get_CanBeInstantiated() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private object SetImplicitConstructor() { }

	// RVA: -1
	private static object CreateValueTypeInstance() { }

	// RVA: -1
	private static object CreateScriptableObjectInstance() { }

	// RVA: -1
	private static object CreateClassInstance() { }

	// RVA: -1
	public object SetExplicitConstructor(object constructor) { }

	// RVA: -1
	private object Unity.Properties.TypeUtility.ITypeConstructor<T>.Instantiate() { }

	// RVA: -1
	private object Unity.Properties.TypeUtility.ITypeConstructor.Instantiate() { }

}

// Namespace: 
private class NonConstructable
{

	// Properties
	private object Unity.Properties.TypeUtility.ITypeConstructor.CanBeInstantiated { get; }

	// Methods

	// RVA: 0x7494940
	private object Unity.Properties.TypeUtility.ITypeConstructor.get_CanBeInstantiated() { }

	// RVA: 0x7494948
	public object Instantiate() { }

	// RVA: 0x74943E8
	public object .ctor() { }

}

// Namespace: 
private struct Cache<T0>
{

	// Fields
	public static object TypeConstructor; // 0x0
}

// Namespace: 
private class TypeConstructorVisitor
{

	// Fields
	public object TypeConstructor; // 0x8

	// Methods

	// RVA: -1
	public object Visit() { }

	// RVA: 0x74943E0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x749499C
	private static object .cctor() { }

	// RVA: 0x74949FC
	public object .ctor() { }

	// RVA: 0x7494A04
	internal object <.cctor>b__11_0() { }

	// RVA: 0x7494A5C
	internal object <.cctor>b__11_1(object sb) { }

	// RVA: 0x7494A80
	internal object <.cctor>b__11_2() { }

}

// Namespace: Unity.Properties
public static class TypeUtility
{

	// Fields
	private static readonly object s_TypeConstructors; // 0x0
	private static readonly object s_CreateTypeConstructor; // 0x8
	private static readonly object s_CachedResolvedName; // 0x10
	private static readonly object s_Builders; // 0x18
	private static readonly object syncedPoolObject; // 0x20

	// Methods

	// RVA: 0x7492B8C
	private static object .cctor() { }

	// RVA: 0x7493004
	public static object GetTypeDisplayName(object type) { }

	// RVA: 0x7493174
	private static object GetTypeDisplayName(object type, object args, object argIndex) { }

	// RVA: 0x7493C60
	public static object GetRootType(object type) { }

	// RVA: 0x7493DD8
	private static object CreateTypeConstructor(object type) { }

	// RVA: -1
	private static object CreateTypeConstructor() { }

	// RVA: 0x74943F0
	private static object GetTypeConstructor(object type) { }

	// RVA: -1
	private static object GetTypeConstructor() { }

	// RVA: 0x74944E8
	public static object CanBeInstantiated(object type) { }

	// RVA: -1
	public static object CanBeInstantiated() { }

	// RVA: -1
	public static object SetExplicitInstantiationMethod(object constructor) { }

	// RVA: -1
	public static object Instantiate() { }

	// RVA: -1
	public static object TryInstantiate(object instance) { }

	// RVA: -1
	public static object Instantiate(object derivedType) { }

	// RVA: -1
	public static object TryInstantiate(object derivedType, object value) { }

	// RVA: -1
	public static object InstantiateArray(object count) { }

	// RVA: -1
	public static object TryInstantiateArray(object count, object instance) { }

	// RVA: -1
	public static object InstantiateArray(object derivedType, object count) { }

	// RVA: 0x749460C
	private static object CheckIsAssignableFrom(object type, object derivedType) { }

	// RVA: -1
	private static object CheckCanBeInstantiated(object constructor) { }

	// RVA: 0x74947D4
	private static object CheckCanBeInstantiated(object constructor, object type) { }

}

// Namespace: Unity.Properties.Internal
internal interface IAttributes
{

	// Methods

	// RVA: -1
	public abstract object AddAttribute(object attribute) { }

	// RVA: -1
	public abstract object AddAttributes(object attributes) { }

}

// Namespace: Unity.Properties.Internal
internal static class DefaultPropertyBagInitializer
{

	// Methods

	// RVA: 0x7494ACC
	internal static object Initialize() { }

}

// Namespace: 
private class XProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x74958D0
	public override object get_Name() { }

	// RVA: 0x7495820
	public object .ctor() { }

}

// Namespace: 
private class YProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495914
	public override object get_Name() { }

	// RVA: 0x7495878
	public object .ctor() { }

}

// Namespace: Unity.Properties.Internal
internal class Vector2IntPropertyBag
{

	// Methods

	// RVA: 0x7494CF0
	public object .ctor() { }

}

// Namespace: 
private class XProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495A60
	public override object get_Name() { }

	// RVA: 0x7495958
	public object .ctor() { }

}

// Namespace: 
private class YProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495AA4
	public override object get_Name() { }

	// RVA: 0x74959B0
	public object .ctor() { }

}

// Namespace: 
private class ZProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495AE8
	public override object get_Name() { }

	// RVA: 0x7495A08
	public object .ctor() { }

}

// Namespace: Unity.Properties.Internal
internal class Vector3IntPropertyBag
{

	// Methods

	// RVA: 0x7494E44
	public object .ctor() { }

}

// Namespace: 
private class XProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495C8C
	public override object get_Name() { }

	// RVA: 0x7495B2C
	public object .ctor() { }

}

// Namespace: 
private class YProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495CD0
	public override object get_Name() { }

	// RVA: 0x7495B84
	public object .ctor() { }

}

// Namespace: 
private class WidthProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495D14
	public override object get_Name() { }

	// RVA: 0x7495BDC
	public object .ctor() { }

}

// Namespace: 
private class HeightProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495D58
	public override object get_Name() { }

	// RVA: 0x7495C34
	public object .ctor() { }

}

// Namespace: Unity.Properties.Internal
internal class RectPropertyBag
{

	// Methods

	// RVA: 0x7494FF4
	public object .ctor() { }

}

// Namespace: 
private class XProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495EFC
	public override object get_Name() { }

	// RVA: 0x7495D9C
	public object .ctor() { }

}

// Namespace: 
private class YProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495F40
	public override object get_Name() { }

	// RVA: 0x7495DF4
	public object .ctor() { }

}

// Namespace: 
private class WidthProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495F84
	public override object get_Name() { }

	// RVA: 0x7495E4C
	public object .ctor() { }

}

// Namespace: 
private class HeightProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7495FC8
	public override object get_Name() { }

	// RVA: 0x7495EA4
	public object .ctor() { }

}

// Namespace: Unity.Properties.Internal
internal class RectIntPropertyBag
{

	// Methods

	// RVA: 0x7495200
	public object .ctor() { }

}

// Namespace: 
private class CenterProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x74960BC
	public override object get_Name() { }

	// RVA: 0x749600C
	public object .ctor() { }

}

// Namespace: 
private class ExtentsProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7496100
	public override object get_Name() { }

	// RVA: 0x7496064
	public object .ctor() { }

}

// Namespace: Unity.Properties.Internal
internal class BoundsPropertyBag
{

	// Methods

	// RVA: 0x749540C
	public object .ctor() { }

}

// Namespace: 
private class PositionProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x74961F4
	public override object get_Name() { }

	// RVA: 0x7496144
	public object .ctor() { }

}

// Namespace: 
private class SizeProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7496238
	public override object get_Name() { }

	// RVA: 0x749619C
	public object .ctor() { }

}

// Namespace: Unity.Properties.Internal
internal class BoundsIntPropertyBag
{

	// Methods

	// RVA: 0x7495560
	public object .ctor() { }

}

// Namespace: 
private class MajorProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x749627C
	public object .ctor() { }

	// RVA: 0x749652C
	public override object get_Name() { }

}

// Namespace: 
private class MinorProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7496328
	public object .ctor() { }

	// RVA: 0x7496570
	public override object get_Name() { }

}

// Namespace: 
private class BuildProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x74963D4
	public object .ctor() { }

	// RVA: 0x74965B4
	public override object get_Name() { }

}

// Namespace: 
private class RevisionProperty
{

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x7496480
	public object .ctor() { }

	// RVA: 0x74965F8
	public override object get_Name() { }

}

// Namespace: Unity.Properties.Internal
internal class SystemVersionPropertyBag
{

	// Methods

	// RVA: 0x74956B4
	public object .ctor() { }

}

// Namespace: Unity.Properties.Internal
internal interface IPropertyBagRegister
{

	// Methods

	// RVA: -1
	public abstract object Register() { }

}

// Namespace: 
internal struct TypedStore<T0>
{

	// Fields
	public static object PropertyBag; // 0x0
}

// Namespace: Unity.Properties.Internal
internal static class PropertyBagStore
{

	// Fields
	private static readonly object s_PropertyBags; // 0x0
	private static readonly object s_RegisteredTypes; // 0x8
	private static object NewTypeRegistered; // 0x10
	private static object s_PropertyBagProvider; // 0x18

	// Methods

	// RVA: 0x749663C
	private static object .cctor() { }

	// RVA: -1
	internal static object AddPropertyBag(object propertyBag) { }

	// RVA: -1
	internal static object GetPropertyBag() { }

	// RVA: 0x7494118
	internal static object GetPropertyBag(object type) { }

}

// Namespace: Unity.Properties.Internal
internal class ReflectedPropertyBagAttribute
{

	// Methods

	// RVA: 0x7496D18
	public object .ctor() { }

}

// Namespace: Unity.Properties.Internal
internal class ReflectedPropertyBag<T0>
{

	// Methods

	// RVA: -1
	internal object AddProperty(object property) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__10_0; // 0x8
	public static object <>9__22_0; // 0x10

	// Methods

	// RVA: 0x74970A0
	private static object .cctor() { }

	// RVA: 0x7497100
	public object .ctor() { }

	// RVA: 0x7497108
	internal object <.ctor>b__10_0(object x) { }

	// RVA: 0x74971C0
	internal object <GetPropertyMembers>b__22_0(object x) { }

}

// Namespace: 
private sealed class <GetPropertyMembers>d__22
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	private object type; // 0x20
	public object <>3__type; // 0x28
	private object <members>5__1; // 0x30
	private object <>s__2; // 0x38
	private object <member>5__3; // 0x40
	private object <hasDontCreatePropertyAttribute>5__4; // 0x48
	private object <hasCreatePropertyAttribute>5__5; // 0x49
	private object <hasNonSerializedAttribute>5__6; // 0x4A
	private object <hasSerializedFieldAttribute>5__7; // 0x4B
	private object <field>5__8; // 0x50

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Reflection.MemberInfo>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x7496D9C
	public object .ctor(object <>1__state) { }

	// RVA: 0x7497210
	private object System.IDisposable.Dispose() { }

	// RVA: 0x7497320
	private object MoveNext() { }

	// RVA: 0x7497C14
	private object <>m__Finally1() { }

	// RVA: 0x7497D34
	private object System.Collections.Generic.IEnumerator<System.Reflection.MemberInfo>.get_Current() { }

	// RVA: 0x7497D3C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x7497D7C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x7497D84
	private object System.Collections.Generic.IEnumerable<System.Reflection.MemberInfo>.GetEnumerator() { }

	// RVA: 0x7497E38
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: Unity.Properties.Internal
internal class ReflectedPropertyBagProvider
{

	// Fields
	private readonly object m_CreatePropertyMethod; // 0x8
	private readonly object m_CreatePropertyBagMethod; // 0x10
	private readonly object m_CreateIndexedCollectionPropertyBagMethod; // 0x18
	private readonly object m_CreateSetPropertyBagMethod; // 0x20
	private readonly object m_CreateKeyValueCollectionPropertyBagMethod; // 0x28
	private readonly object m_CreateKeyValuePairPropertyBagMethod; // 0x30
	private readonly object m_CreateArrayPropertyBagMethod; // 0x38
	private readonly object m_CreateListPropertyBagMethod; // 0x40
	private readonly object m_CreateHashSetPropertyBagMethod; // 0x48
	private readonly object m_CreateDictionaryPropertyBagMethod; // 0x50

	// Methods

	// RVA: 0x7496758
	public object .ctor() { }

	// RVA: 0x7496B90
	public object CreatePropertyBag(object type) { }

	// RVA: -1
	public object CreatePropertyBag() { }

	// RVA: -1
	private object CreateProperty(object member, object propertyBag) { }

	// RVA: -1
	private object CreateIndexedCollectionPropertyBag() { }

	// RVA: -1
	private object CreateSetPropertyBag() { }

	// RVA: -1
	private object CreateKeyValueCollectionPropertyBag() { }

	// RVA: -1
	private object CreateKeyValuePairPropertyBag() { }

	// RVA: -1
	private object CreateArrayPropertyBag() { }

	// RVA: -1
	private object CreateListPropertyBag() { }

	// RVA: -1
	private object CreateHashSetPropertyBag() { }

	// RVA: -1
	private object CreateDictionaryPropertyBag() { }

	// RVA: 0x7496D20
	private static object GetPropertyMembers(object type) { }

	// RVA: 0x7496DD4
	private static object IsValidMember(object memberInfo) { }

	// RVA: 0x7496F74
	private static object IsValidPropertyType(object type) { }

}

