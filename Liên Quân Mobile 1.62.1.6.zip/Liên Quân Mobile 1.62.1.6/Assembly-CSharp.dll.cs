// Namespace: 
internal class <Module>
{
}

// Namespace: 
public class BoyanActor
{

	// Fields
	public object materials; // 0x18
	public object keyLightAngles; // 0x20
	public object keyLightColor; // 0x28
	public object fillLightAngles; // 0x38
	public object fillLightColor; // 0x40
	public object lightWeights; // 0x50
	public object LightPower; // 0x58
	public object adjustParams; // 0x5C
	public object cubemap; // 0x70
	public object shParams; // 0x78

	// Methods

	// RVA: 0xF5B09C
	public object .ctor() { }

}

// Namespace: 
public class ScenePrefabInfo
{

	// Fields
	public object InstancePathMap; // 0x18

	// Methods

	// RVA: 0xF5B150
	public object GetPath(object instanceId, object path) { }

	// RVA: 0xF5B230
	public object Add(object instanceId, object path) { }

	// RVA: 0xF5B374
	public object .ctor() { }

}

// Namespace: 
public struct InstancePathData
{

	// Fields
	public object instanceId; // 0xFFFFFFFFFFFFFFF8
	public object path; // 0x0

	// Methods

	// RVA: 0xF5B368
	public object .ctor(object i, object p) { }

}

// Namespace: 
public class AnimationFramePrinter
{

	// Fields
	private object position; // 0x18
	private object size; // 0x20
	private object parentGO; // 0x28
	private object isAnimator; // 0x30
	private object animator; // 0x38
	private object animation; // 0x40

	// Methods

	// RVA: 0xF5B490
	private object Start() { }

	// RVA: 0xF5B4EC
	private object Update() { }

	// RVA: 0xF5B6BC
	private object OnGUI() { }

	// RVA: 0xF5B4F0
	private object RefrashSelectState() { }

	// RVA: 0xF5B6C0
	private object DrawAnimationInfo() { }

	// RVA: 0xF5BB8C
	private object GetPlayingAnimationClip(object animation) { }

	// RVA: 0xF5BEE0
	public object .ctor() { }

}

// Namespace: 
public class Billboard
{

	// Fields
	public object m_isLightDarkLockParticleRotationXZ; // 0x18
	public object rotationAdjust; // 0x1C
	public object lockPosition; // 0x28
	public object bAlwaysFind; // 0x29
	public object XRotateWithParent; // 0x2A
	public object YRotateWithParent; // 0x2B
	public object ZRotateWithParent; // 0x2C
	private object referenceCamera; // 0x30
	private object t; // 0x38
	private object ct; // 0x40
	private object targetDir; // 0x48
	private object targetPos; // 0x54
	private object foundReferenceCamera; // 0x60
	private static object exceptLightDarkLockEffectList; // 0x0

	// Methods

	// RVA: 0xF5BEF4
	private object Start() { }

	// RVA: 0xF5C344
	private object ExceptLightDarkLockEffectListContains(object InputValue) { }

	// RVA: 0xF5C05C
	public object FindReferenceCamera() { }

	// RVA: 0xF5C56C
	private object Update() { }

	// RVA: 0xF5CBA8
	public object .ctor() { }

	// RVA: 0xF5CBB0
	private static object .cctor() { }

}

// Namespace: 
public class BillboardOnLateUpdate
{

	// Fields
	public object rotationAdjust; // 0x18
	public object lockPosition; // 0x24
	public object bAlwaysFind; // 0x25
	public object XRotateWithParent; // 0x26
	public object YRotateWithParent; // 0x27
	public object ZRotateWithParent; // 0x28
	private object referenceCamera; // 0x30
	private object t; // 0x38
	private object ct; // 0x40
	private object targetDir; // 0x48
	private object targetPos; // 0x54
	private object foundReferenceCamera; // 0x60

	// Methods

	// RVA: 0xF5CDE8
	private object Start() { }

	// RVA: 0xF5CE34
	public object FindReferenceCamera() { }

	// RVA: 0xF5D11C
	private object LateUpdate() { }

	// RVA: 0xF5D6CC
	public object .ctor() { }

}

// Namespace: 
public class BoneBinder
{

	// Fields
	public object ResetTransform; // 0x18
	public object bindBone; // 0x20
	private object child; // 0x28

	// Methods

	// RVA: 0xF5D6D4
	private object Reset() { }

	// RVA: 0xF5D8E8
	private object FindChild(object parent, object name) { }

	// RVA: 0xF5DCD4
	private object Start() { }

	// RVA: 0xF5E090
	private object OnEnable() { }

	// RVA: 0xF5E118
	private object OnDisable() { }

	// RVA: 0xF5E1A0
	public object .ctor() { }

}

// Namespace: 
public class ActorInfo
{

	// Fields
	public object name; // 0x8
	public object skins; // 0x10

	// Methods

	// RVA: 0xF5E7A8
	public object .ctor() { }

}

// Namespace: 
public enum LODLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LOD1;
	public const object LOD2;
	public const object LOD2_5;
	public const object LOD3;
	public const object Show1;
	public const object Show2;
	public const object Show3;
}

// Namespace: 
public enum BoneLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object _1Bone;
	public const object _2Bones;
	public const object _4Bones;
	public const object Unlimited;
}

// Namespace: 
public class NaturalComparer
{

	// Methods

	// RVA: 0xF64A60
	public object Compare(object x, object y) { }

	// RVA: 0xF5E7B0
	public object .ctor() { }

}

// Namespace: 
public enum TestEffect
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Freeze;
	public const object Stone;
	public const object Hurt;
	public const object Rim;
	public const object Translucent;
	public const object Dissolve;
}

// Namespace: 
private sealed class <>c__DisplayClass98_0
{

	// Fields
	public object outlineColor; // 0x8

	// Methods

	// RVA: 0xF63DC0
	public object .ctor() { }

	// RVA: 0xF64D2C
	internal object <TestReset>b__0(object m) { }

}

// Namespace: 
public class HeroSceneOffline
{

	// Fields
	private const object heroPrefab;
	private const object heroPrefabRoot;
	private const object bgPrefabRoot;
	private const object tablePrefabRoot;
	public object actors; // 0x18
	public object lodLevel; // 0x20
	public object _skinWeights; // 0x24
	public object targetHero; // 0x28
	public object posOffsetX; // 0x30
	public object posOffsetY; // 0x34
	public object posCountY; // 0x38
	public object isSpawning; // 0x3C
	private object spawnCount; // 0x40
	private object spawnLOD; // 0x48
	private object spawnCharIndex; // 0x50
	public object skinFilter; // 0x58
	private object actorNames; // 0x60
	private object iconContents; // 0x68
	private object iconSkinContents; // 0x70
	private object oldActorIconIndex; // 0x78
	public static object s_SrcBlendPropertyID; // 0x0
	public static object s_DestBlendPropertyID; // 0x4
	public static object s_SrcAlphaBlendPropertyID; // 0x8
	public static object s_DestAlphaBlendPropertyID; // 0xC
	public readonly object s_BLOOM_ON; // 0x80
	public object enableBloom; // 0x88
	public object testMode; // 0x8C
	private object aniPause; // 0x90
	private object _curve; // 0x94
	private static object freezeEffectTex; // 0x10
	private static object stoneEffectTex; // 0x18
	private static object dissolveMaskTex; // 0x20
	private object oldVisibleLayers; // 0x98
	private object affectedGos; // 0xA0
	private object opaqueMaterials; // 0xA8

	// Properties
	public object skinWeights { get; set; }
	public object progressStr { get; }
	public object curve { get; set; }

	// Methods

	// RVA: 0xF5E1B0
	public object get_skinWeights() { }

	// RVA: 0xF5E1B8
	public object set_skinWeights(object value) { }

	// RVA: 0xF5E1C8
	public object GetHeroPrefabs() { }

	// RVA: 0xF5E7B8
	public object GetSkinName(object index, object skin) { }

	// RVA: 0xF5E8B4
	public object GetSkinFullID(object name, object checkSkinInfo) { }

	// RVA: 0xF5EF80
	public object SpawnAllSkin(object lod) { }

	// RVA: 0xF5F070
	public object SpawnSkin(object lod, object target) { }

	// RVA: 0xF5F714
	public object get_progressStr() { }

	// RVA: 0xF5F7AC
	private object SpawnSkin() { }

	// RVA: 0xF5F48C
	public object SpawnStop() { }

	// RVA: 0xF5F368
	public object LoadSkin(object charName, object skinName, object pos) { }

	// RVA: 0xF5FC40
	public object ClearAll() { }

	// RVA: 0xF5FDDC
	public object FindSkin(object name) { }

	// RVA: 0xF5FF00
	private object LoadAsset(object path) { }

	// RVA: 0xF5F8DC
	private object GetPrefab(object path) { }

	// RVA: 0xF5E9BC
	private object GetActorInfo(object name) { }

	// RVA: 0xF5FFFC
	private object GetSkinName(object name) { }

	// RVA: 0xF60130
	private object CompareName(object a, object b) { }

	// RVA: 0xF601C8
	private object GetSkinNode(object info, object name) { }

	// RVA: 0xF5ECC8
	private object GetFullSkinId(object info, object name) { }

	// RVA: 0xF60360
	private object GetSkinCfgId(object info, object name) { }

	// RVA: 0xF60544
	public object GetBoneWeights(object level) { }

	// RVA: 0xF60564
	private static object GetChildObject(object parent, object ignore) { }

	// RVA: 0xF606A0
	private static object GetChildName(object parent, object ignore) { }

	// RVA: 0xF5FC7C
	private object RemoveChildren(object parent, object ignore) { }

	// RVA: 0xF60804
	private object SetCameraLayer(object obj) { }

	// RVA: 0xF60A1C
	private object SetSkinLayer(object obj) { }

	// RVA: 0xF60A9C
	private object SetParent(object obj, object parent) { }

	// RVA: 0xF60C0C
	public object GetActorNames() { }

	// RVA: 0xF60E10
	public object GetActorName(object index) { }

	// RVA: 0xF5FF08
	public object GetActorInfoPath(object name) { }

	// RVA: 0xF60E60
	public object GetSkinNames(object index) { }

	// RVA: 0xF60EB0
	public object SelectActorByName(object name) { }

	// RVA: 0xF60F50
	public object SelectActorBySkinName(object name, object actorIndex, object skinIndex) { }

	// RVA: 0xF61100
	public object SelectActorByCode(object code, object actorIndex, object skinIndex) { }

	// RVA: 0xF612BC
	public object PosTurn(object angle) { }

	// RVA: 0xF614B0
	public object PosReset() { }

	// RVA: 0xF615C8
	public object GetIconGUIContents() { }

	// RVA: 0xF61E8C
	public object GetIconSkinGUIContents(object i) { }

	// RVA: 0xF61D70
	public static object GetExistFilePath(object paths) { }

	// RVA: 0xF626B8
	private object Awake() { }

	// RVA: 0xF62808
	private object Start() { }

	// RVA: 0xF6280C
	private object DestroyObj(object name) { }

	// RVA: 0xF62920
	private object OnDisable() { }

	// RVA: 0xF62964
	public object EnableBloom(object enable) { }

	// RVA: 0xF5F9F4
	private object EnableBloom(object go, object enable) { }

	// RVA: 0xF6299C
	private object OnEnable() { }

	// RVA: 0xF62BAC
	private object CacheTexIfNeed(object target, object path) { }

	// RVA: 0xF62D60
	private object ApplyAllMaterials(object action) { }

	// RVA: 0xF62F9C
	public object PlayPauseAni() { }

	// RVA: 0xF630D8
	public object get_curve() { }

	// RVA: 0xF630E0
	public object set_curve(object value) { }

	// RVA: 0xF632D8
	public object Test(object mode) { }

	// RVA: 0xF638A4
	public object TestDissolve() { }

	// RVA: 0xF63994
	private object SetAlpha(object m) { }

	// RVA: 0xF6356C
	public object TestReset() { }

	// RVA: 0xF63E08
	public object .ctor() { }

	// RVA: 0xF63F24
	private static object .cctor() { }

	// RVA: 0xF6402C
	private object <set_curve>b__88_0(object m) { }

	// RVA: 0xF640AC
	private object <set_curve>b__88_1(object m) { }

	// RVA: 0xF64128
	private object <set_curve>b__88_2(object m) { }

	// RVA: 0xF6420C
	private object <set_curve>b__88_3(object m) { }

	// RVA: 0xF642A4
	private object <set_curve>b__88_4(object m) { }

	// RVA: 0xF64388
	private object <Test>b__91_0(object m) { }

	// RVA: 0xF64488
	private object <Test>b__91_1(object m) { }

	// RVA: 0xF64588
	private object <Test>b__91_2(object m) { }

	// RVA: 0xF64604
	private object <Test>b__91_3(object m) { }

	// RVA: 0xF6470C
	private object <Test>b__91_4(object m) { }

	// RVA: 0xF64830
	private object <TestDissolve>b__96_0(object m) { }

}

// Namespace: 
public class ActorInfo
{

	// Fields
	public object name; // 0x8
	public object skins; // 0x10

	// Methods

	// RVA: 0xF7BEC8
	public object .ctor() { }

}

// Namespace: 
public class NaturalComparer
{

	// Methods

	// RVA: 0xF7BED0
	public object Compare(object x, object y) { }

	// RVA: 0xF7C19C
	public object .ctor() { }

}

// Namespace: 
public struct BGPreset
{

	// Fields
	public object button; // 0xFFFFFFFFFFFFFFF8
	public object name; // 0x0
	public object bg; // 0x8
	public object table; // 0x10

	// Methods

	// RVA: 0xF7C2AC
	public object .ctor(object button, object name, object bg, object table) { }

}

// Namespace: 
public enum IconMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Icon;
	public const object Hero;
	public const object Skin;
	public const object Recently;
}

// Namespace: 
public enum LightShadows
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Hard;
	public const object Hardx2;
	public const object Soft;
	public const object Softx2;
	public const object Editor;
}

// Namespace: 
public sealed class OnTime
{

	// Methods

	// RVA: 0xF7C828
	public object .ctor(object object, object method) { }

	// RVA: 0xF7C8C0
	public virtual object Invoke(object delta) { }

	// RVA: 0xF7C8D4
	public virtual object BeginInvoke(object delta, object callback, object object) { }

	// RVA: 0xF7C990
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
internal class Timer
{

	// Fields
	public object finished; // 0x8
	private object length; // 0xC
	private object time; // 0x10
	private object fade; // 0x14
	public object onTimeDelegate; // 0x18

	// Methods

	// RVA: 0xF7C4B0
	public object Update(object deltaTime) { }

	// RVA: 0xF7C674
	public object .ctor(object length, object fade, object onTimeDelegate) { }

}

// Namespace: 
internal class FadeTimer
{

	// Fields
	private object timers; // 0x8
	public object sincePlay; // 0x10
	public object skip; // 0x14

	// Methods

	// RVA: 0xF7C2C4
	public object Update(object deltaTime) { }

	// RVA: 0xF7C510
	public object Add(object onTimeDelegate, object length, object fade) { }

	// RVA: 0xF7C6C0
	public object Clear() { }

	// RVA: 0xF7C740
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__262_0; // 0x8

	// Methods

	// RVA: 0xF7C99C
	private static object .cctor() { }

	// RVA: 0xF7C9FC
	public object .ctor() { }

	// RVA: 0xF7CA04
	internal object <GetQueuedAnimations>b__262_0(object a, object b) { }

}

// Namespace: 
private sealed class <>c__DisplayClass60_0
{

	// Fields
	public object bg; // 0x8
	public object table; // 0x10

	// Methods

	// RVA: 0xF7CA64
	public object .ctor() { }

	// RVA: 0xF7CA6C
	internal object <LoadTableBG>b__0(object p) { }

}

// Namespace: 
private sealed class <>c__DisplayClass81_0
{

	// Fields
	public object lowName; // 0x8
	public object <>9__1; // 0x10

	// Methods

	// RVA: 0xF7CAB8
	public object .ctor() { }

	// RVA: 0xF7CAC0
	internal object <GetCameraPrefabPath>b__0(object n) { }

	// RVA: 0xF7CB0C
	internal object <GetCameraPrefabPath>b__1(object n) { }

}

// Namespace: 
public class LobbySceneOffline
{

	// Fields
	private const object heroPrefab;
	private const object heroPrefabRoot;
	private const object bgPrefabRoot;
	private const object tablePrefabRoot;
	public object actors; // 0x18
	private readonly object naturalComp; // 0x20
	public readonly object BGOldPresets; // 0x28
	public readonly object BGPresets; // 0x30
	public object backgroundSync; // 0x38
	public object bgs; // 0x40
	public object tables; // 0x48
	public object _CamPath; // 0x50
	public object _SkinPath; // 0x58
	public object _NodePath; // 0x60
	public object _TablePath; // 0x68
	public object _BGPath; // 0x70
	public object bFilterDefaultLight; // 0x78
	public object quality; // 0x80
	private static object originalPos; // 0x0
	private static object originalRot; // 0xC
	private static object originalFov; // 0x18
	private static object originalNearClipDist; // 0x1C
	private static object originalClearColor; // 0x20
	public object isHokSkin; // 0x88
	public object isHokSkinShow; // 0x89
	public object isIdleShow; // 0x8A
	public object hasHokCameraAnim; // 0x8B
	public object skinID; // 0x8C
	public object info; // 0x90
	private object m_heroAnimaView; // 0x98
	public object _HeroTimeline; // 0xA0
	private object m_yaVirtualCameraOriginEnable; // 0xA8
	private object m_yaVirtualCamera; // 0xB0
	private const object LobbySceneOffline_LoadedSkins;
	private object _PrepareBG; // 0xB8
	private object _characterModelView; // 0xC0
	private object _root; // 0xC8
	private object _root1; // 0xD0
	private object _root_add; // 0xD8
	private object _HeroCustomCam; // 0xE0
	private object _HeroBG; // 0xE8
	private object _formHero; // 0xF0
	private object _3DImage; // 0xF8
	public object _Cam; // 0x100
	public object _Skin; // 0x108
	public object _Model; // 0x110
	public object _Node; // 0x118
	public object _Table; // 0x120
	public object _BG; // 0x128
	public object _Light; // 0x130
	public object _DefaultLight; // 0x138
	public object _SkinAnim; // 0x140
	public object _EffectAnim; // 0x148
	public object _CamAnim; // 0x150
	public object _SkinCamAnimation; // 0x158
	public object _Hero_Camera_Root; // 0x160
	private object _image; // 0x168
	public object _Timeline; // 0x170
	public object _Camera; // 0x178
	public object currActorIndex; // 0x180
	public object currSkinIndex; // 0x184
	public object skinFilter; // 0x188
	private object actorNames; // 0x190
	public object currTableIndex; // 0x198
	public object currBgIndex; // 0x19C
	public object bgFilter; // 0x1A0
	private object _showIcon; // 0x1A8
	private object oldIconMode; // 0x1AC
	private object iconContents; // 0x1B0
	private object oldActorIconIndex; // 0x1B8
	private object iconSkinContents; // 0x1C0
	public object animationFold; // 0x1C8
	public object camAnimationFold; // 0x1C9
	public object enableSpringNode; // 0x1CA
	public object isPlayInfo; // 0x1CB
	private object playIdleshow; // 0x1CC
	private object playStandby; // 0x1CD
	private object playIdleshowTime; // 0x1D0
	private object playIdleshowRestTime; // 0x1D4
	private object fadeTime; // 0x1D8
	public object waitIdleshowRest; // 0x1DC
	private object _CamDefaultFov; // 0x1E0
	private object _CamDefaultPos; // 0x1E4
	private object _CamDefaultRot; // 0x1F0
	private object _CamDefaultScale; // 0x200
	private object playCamComeTime; // 0x20C
	public object _CamInterpolateTime; // 0x210
	public object _Cam02InterpolateTime; // 0x214
	public object _Cam02InterpolateDuration; // 0x218
	private object oldMouseX; // 0x21C
	internal static readonly object _ReflectPos_ID; // 0x30
	private object m_canvasScale; // 0x220
	private object oldQualityLevel; // 0x22C
	private object oldRenderQuality; // 0x230
	private object runLateStart; // 0x234
	public object showGUI; // 0x235
	private object showBGPreset; // 0x236
	private object showCharList; // 0x237
	private object charListSelected; // 0x238
	private static object iconCoord; // 0x34
	private static object defaultIconCoord; // 0x44
	private static object timelineIcon; // 0x58
	private object charSVPos; // 0x23C
	public object m_shadowCamera; // 0x248
	public object shadowPlaneOffset; // 0x250
	public object shadowFakeObjectSize; // 0x254
	public object _RealtimeOn; // 0x260
	public object _shadows; // 0x264
	private object _bloomCamera; // 0x268
	private object aniTimer; // 0x270
	public object queuedAnimations; // 0x278
	private object m_actorDisplayState; // 0x280

	// Properties
	public object showIcon { get; set; }
	public object shadows { get; set; }
	private object fadeLength { get; }

	// Methods

	// RVA: 0xF64EAC
	private object IsShowPrefab(object name) { }

	// RVA: 0xF65024
	public object GetHeroPrefabs() { }

	// RVA: 0xF659A4
	public object GetBgPrefabs() { }

	// RVA: 0xF65CBC
	public object GetTablePrefabs() { }

	// RVA: 0xF659FC
	public object GetPrefabs(object path) { }

	// RVA: 0xF65D14
	public object GetSkinName(object index, object skin) { }

	// RVA: 0xF65E10
	public object GetSkinName() { }

	// RVA: 0xF65EB8
	public object GetSkinFullID(object name, object checkSkinInfo) { }

	// RVA: 0xF666F8
	public object IsHokSkin(object actorInfo, object skinId) { }

	// RVA: 0xF66770
	public object hasHokSkinCamAnim(object actorInfo, object skinId) { }

	// RVA: 0xF667E8
	public object LoadSkin(object name) { }

	// RVA: 0xF69A28
	private object InitCamera() { }

	// RVA: 0xF6ABDC
	private object AfterLoadSkin() { }

	// RVA: 0xF681C8
	private object GetSkinId(object skinName) { }

	// RVA: 0xF6B718
	private object InitCameraAnimFromPrefab() { }

	// RVA: 0xF6C3D8
	private object ClearAnimClip() { }

	// RVA: 0xF6BD18
	private object CopyCameraAnim(object to, object from) { }

	// RVA: 0xF6BAD4
	private object YAVirtualCamerasSetTarget(object hero, object cam) { }

	// RVA: 0xF68E10
	public object GetLobbyModelScale(object actorInfo, object skinId) { }

	// RVA: 0xF6CA20
	public object LoadDefaultCamera() { }

	// RVA: 0xF6CBBC
	public object GetLoadedSkines() { }

	// RVA: 0xF67990
	public object AddLoadedSkines(object name) { }

	// RVA: 0xF6A23C
	private object LoadSyncedBackgound(object info, object skinName) { }

	// RVA: 0xF6CE30
	public object LoadTableBG(object name, object bg, object table) { }

	// RVA: 0xF6A10C
	public object LoadPreset(object preset) { }

	// RVA: 0xF6D3DC
	public object LoadTable(object name, object postfix) { }

	// RVA: 0xF6D8A4
	private object UnloadPrefabBG() { }

	// RVA: 0xF6D99C
	private object LoadPrepareBG() { }

	// RVA: 0xF6D058
	public object LoadBG(object name, object postfix) { }

	// RVA: 0xF6D700
	private object LoadAsset(object path) { }

	// RVA: 0xF68258
	private object GetPrefab(object path) { }

	// RVA: 0xF660FC
	public object GetActorInfo(object name) { }

	// RVA: 0xF665CC
	public object UnloadActorInfo(object info) { }

	// RVA: 0xF6DBE8
	private object GetSkinName(object name) { }

	// RVA: 0xF6DD1C
	private object CompareName(object a, object b) { }

	// RVA: 0xF68A4C
	private object GetSkinNode(object info, object name) { }

	// RVA: 0xF65FF8
	private object ParseSkinID(object name) { }

	// RVA: 0xF66408
	private object GetFullSkinId(object info, object name) { }

	// RVA: 0xF6CC48
	private object GetSkinCfgId(object info, object name) { }

	// RVA: 0xF6DDB4
	private object GetLobbyScale(object info, object name) { }

	// RVA: 0xF69E20
	private object GetCamScaleInterpolateTime(object info, object name) { }

	// RVA: 0xF6849C
	private object GetUseTimeline(object info, object name) { }

	// RVA: 0xF6DF54
	private object GetSkinId(object info, object name) { }

	// RVA: 0xF685F8
	private object GetCameraPrefabPath(object info, object name) { }

	// RVA: 0xF6E0B0
	public object ToggleUnityLight() { }

	// RVA: 0xF6E10C
	private static object GetChildObject(object parent, object ignore) { }

	// RVA: 0xF6E248
	private static object GetChildName(object parent, object ignore) { }

	// RVA: 0xF68BE4
	private object RemoveChildren(object parent, object ignore) { }

	// RVA: 0xF680D8
	private object SetActiveImpl(object obj, object value) { }

	// RVA: 0xF6E3AC
	private object DestroyImpl(object obj) { }

	// RVA: 0xF69BA8
	private object SetCameraLayer(object obj) { }

	// RVA: 0xF68D68
	private object SetSkinLayer(object obj) { }

	// RVA: 0xF67994
	private object FindGameObjects() { }

	// RVA: 0xF6E63C
	public object ReloadObject() { }

	// RVA: 0xF6E6F8
	public static object FindHighModel(object parent) { }

	// RVA: 0xF6EBAC
	public object GetActorNames() { }

	// RVA: 0xF6EDB0
	public object GetActorName(object index) { }

	// RVA: 0xF6DAF4
	public object GetActorInfoPath(object name) { }

	// RVA: 0xF6EE00
	public object GetSkinNames(object index) { }

	// RVA: 0xF6EE50
	public object SelectActorByName(object name) { }

	// RVA: 0xF6EF24
	public object SelectActorBySkinName(object name, object actorIndex, object skinIndex) { }

	// RVA: 0xF6F0D4
	public object SelectActorByCode(object code, object actorIndex, object skinIndex) { }

	// RVA: 0xF6F210
	public object FindSkinName() { }

	// RVA: 0xF6F430
	public object GetBgNames() { }

	// RVA: 0xF6F4A0
	public object GetBgName(object index) { }

	// RVA: 0xF6F4DC
	public object GetTableNames() { }

	// RVA: 0xF6F54C
	public object GetTableName(object index) { }

	// RVA: 0xF6F588
	public object GetTableByBgName(object name) { }

	// RVA: 0xF6F8B4
	public object SelectBgByName(object name, object ret) { }

	// RVA: 0xF6F96C
	public object SelectTableByName(object name, object ret) { }

	// RVA: 0xF6FA24
	public object FindBgName() { }

	// RVA: 0xF6FAC4
	public object FindTableName() { }

	// RVA: 0xF6FB50
	public object set_showIcon(object value) { }

	// RVA: 0xF6FB68
	public object get_showIcon() { }

	// RVA: 0xF6FB70
	private object GetFileTime(object obj) { }

	// RVA: 0xF6FBE0
	public object GetIconGUIContents() { }

	// RVA: 0xF70670
	private object SubstringShow(object s) { }

	// RVA: 0xF706F8
	public object GetIconSkinGUIContents(object actorIndex) { }

	// RVA: 0xF700F0
	private object GetSkinIcon(object name) { }

	// RVA: 0xF70CBC
	public object GetSkinIconPath(object name) { }

	// RVA: 0xF70F6C
	public object GetSkinSelectpath(object name) { }

	// RVA: 0xF70E50
	public static object GetExistFilePath(object paths) { }

	// RVA: 0xF71100
	public object GetAnimationNames() { }

	// RVA: 0xF68F8C
	private object FindSkinAnimation(object skin) { }

	// RVA: 0xF71FD4
	public object GetCamAnimationNames() { }

	// RVA: 0xF72648
	public object GetPlayingAnimationName() { }

	// RVA: 0xF72778
	private object AnimPlay(object anim, object name, object fadeLength, object playNow) { }

	// RVA: 0xF69954
	private object SetSpringEnable(object go, object enable) { }

	// RVA: 0xF72DF8
	private object ResetSpring(object go) { }

	// RVA: 0xF72DFC
	private object EnableComeObjects(object enable) { }

	// RVA: 0xF73160
	public object PlayAnimation(object name, object fadeLength) { }

	// RVA: 0xF73B00
	private static object PlayTimeline(object timeline, object name) { }

	// RVA: 0xF741F0
	public object ReplayComeAnimation() { }

	// RVA: 0xF74C10
	private object PlayComeAnimation() { }

	// RVA: 0xF749D8
	private object onComeEnd(object fade) { }

	// RVA: 0xF74E20
	private object onIdleshowEnd(object fade) { }

	// RVA: 0xF75078
	private object GetActorInfoIdlePlay() { }

	// RVA: 0xF750BC
	private static object GetPlayingAnimation(object anim) { }

	// RVA: 0xF754E4
	private object PlayIdleshowAnimation(object playCamera) { }

	// RVA: 0xF755D0
	private object UpdateIdleshowAnimation() { }

	// RVA: 0xF75B2C
	public object PlayStandbyAnimation() { }

	// RVA: 0xF741EC
	public static object RepaintInspector(object t) { }

	// RVA: 0xF72FE0
	private object EnableComeObject(object obj, object enable) { }

	// RVA: 0xF75E0C
	public object DisableShadow() { }

	// RVA: 0xF75F40
	public object StopAnimation() { }

	// RVA: 0xF6A8D8
	private object SaveDefaultCamInfo() { }

	// RVA: 0xF74714
	private object RestoreDefaultCamInfo() { }

	// RVA: 0xF7618C
	public static object GetCurrentAninatmion(object anim) { }

	// RVA: 0xF76558
	private object UpdateCameraScale() { }

	// RVA: 0xF76988
	private object Update() { }

	// RVA: 0xF77098
	private object GetHokSkinPlatformRoot() { }

	// RVA: 0xF773FC
	private object OnCanvasSizeChangedImpl() { }

	// RVA: 0xF7767C
	private object OnEnable() { }

	// RVA: 0xF777C4
	private object DestroyTempObjects() { }

	// RVA: 0xF77FE4
	private object OnDisable() { }

	// RVA: 0xF7807C
	private object Reset() { }

	// RVA: 0xF78080
	private object Awake() { }

	// RVA: 0xF78084
	private object Start() { }

	// RVA: 0xF78254
	internal object OnDestroy() { }

	// RVA: 0xF76D34
	private object LateStart() { }

	// RVA: 0xF780B0
	private object Init() { }

	// RVA: 0xF782E4
	private object UnInit() { }

	// RVA: 0xF7857C
	private object OnChgSceneVisible(object displayState, object bHide) { }

	// RVA: 0xF78634
	private object OnResetRotate(object model) { }

	// RVA: 0xF78824
	private object OnGUI() { }

	// RVA: 0xF797CC
	public static object IconButton(object r, object icon, object bs, object ts) { }

	// RVA: 0xF7920C
	private object CharacterListGUI(object position) { }

	// RVA: 0xF7730C
	private object CharacterListUpdate() { }

	// RVA: 0xF6E434
	private object FindLightObject() { }

	// RVA: 0xF6A384
	public object InitShadowMappingCamera() { }

	// RVA: 0xF69F88
	private object IsSkinDisableLight(object info, object skinName) { }

	// RVA: 0xF79FE4
	private object GetLightingInfo(object info, object skinName, object ignoreAABB, object bUnityLight, object bFilterDefaultLight) { }

	// RVA: 0xF6ABB0
	public object InitLightInfo(object info, object skinName) { }

	// RVA: 0xF79C84
	public object InitShadowMappingCamera(object info, object skinName) { }

	// RVA: 0xF7A210
	private object InitShadowMappingObject(object obj, object ignoreAABB, object bUnityLight, object bFilterDefaultLight, object light, object camera) { }

	// RVA: 0xF7A360
	private object CreateShadowMappingCamera(object obj, object bFilterDefaultLight, object bUnityLight, object renderLight, object renderCamera, object ignoreAABB, object frustumSizeScale) { }

	// RVA: 0xF7A5BC
	private object UpdateShadowMapSize() { }

	// RVA: 0xF7A690
	public object set_shadows(object value) { }

	// RVA: 0xF7A73C
	public object get_shadows() { }

	// RVA: 0xF6A518
	private object InitPostProcessing() { }

	// RVA: 0xF78078
	private object TeriminatePostProcessing() { }

	// RVA: 0xF7171C
	public static object FindChildRecursively(object parent, object name) { }

	// RVA: 0xF71B24
	private static object FindAnimation(object obj, object ignoreName) { }

	// RVA: 0xF78488
	private static object SetTimeScale(object f) { }

	// RVA: 0xF7A744
	public object GetQueuedAnimations() { }

	// RVA: 0xF7A908
	private object onCustomEnd(object fade) { }

	// RVA: 0xF76DF8
	private object IsEnableRotate() { }

	// RVA: 0xF7B284
	private static object IsLoopClip(object clip) { }

	// RVA: -1
	private static object IsPlaying(object director, object key) { }

	// RVA: 0xF7ABE0
	private object GetPlayingClipName() { }

	// RVA: -1
	private static object GetTrack(object director, object key) { }

	// RVA: 0xF74DF8
	private object get_fadeLength() { }

	// RVA: 0xF7B3A4
	public object .ctor() { }

	// RVA: 0xF7BC20
	private static object .cctor() { }

	// RVA: 0xF7BCD8
	private object <GetIconGUIContents>b__149_0(object a, object b) { }

	// RVA: 0xF7BE40
	private object <GetIconSkinGUIContents>b__153_0(object p) { }

}

// Namespace: 
public class MaterialRenderQueue
{

	// Fields
	public object renderQueueOffset; // 0x18
	private object shaderQueue; // 0x1C
	private object mat; // 0x20

	// Methods

	// RVA: 0xF7CB58
	private object Start() { }

	// RVA: 0xF7CD40
	public object SetQueue() { }

	// RVA: 0xF7CFE4
	private object OnDestroy() { }

	// RVA: 0xF7D0C0
	public object .ctor() { }

}

// Namespace: 
public class StretchedBillboard
{

	// Fields
	public object _rotation; // 0x18
	private object _localRotation; // 0x24
	private object hasRenderer; // 0x34
	private object cam; // 0x38

	// Methods

	// RVA: 0xF7D0C8
	private object Reset() { }

	// RVA: 0xF7D274
	private object OnDestroy() { }

	// RVA: 0xF7D2B4
	private object Awake() { }

	// RVA: 0xF7D304
	private object OnValidate() { }

	// RVA: 0xF7D354
	private object OnWillRenderObject() { }

	// RVA: 0xF7D750
	private object LateUpdate() { }

	// RVA: 0xF7D454
	private object UpdateBillboard(object cam) { }

	// RVA: 0xF7D84C
	private object FindCamera() { }

	// RVA: 0xF7DA54
	public object .ctor() { }

}

// Namespace: 
public enum TextureSize
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object _512;
	public const object _1024;
	public const object _2048;
	public const object _4096;
	public const object _8182;
	public const object _16384;
}

// Namespace: 
public enum TextureTile
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object _1x1;
	public const object _2x2;
	public const object _4x4;
}

// Namespace: 
public enum BakeMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Camera;
	public const object Albedo;
	public const object Mixture;
	public const object Lightmap;
}

// Namespace: 
public class CameraBake
{

	// Fields
	public object tempLayer; // 0x18
	public object cameraSize; // 0x1C
	public object texPadding; // 0x20
	public object texPaddingNum; // 0x24
	public object texSharpen; // 0x28
	public object texSize; // 0x2C
	public object texTile; // 0x30
	public object renderers; // 0x38
	public object repaint; // 0x40
	public object nightMode; // 0x41
	public object bakeMode; // 0x44

	// Methods

	// RVA: 0xF7DA5C
	public object OnValidate() { }

	// RVA: 0xF7DB5C
	public object Validate(object cam) { }

	// RVA: 0xF7DC78
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__8_0; // 0x8

	// Methods

	// RVA: 0xF7DED4
	private static object .cctor() { }

	// RVA: 0xF7DF34
	public object .ctor() { }

	// RVA: 0xF7DF3C
	internal object <Reset>b__8_0(object r) { }

}

// Namespace: 
public class CullingGizmo
{

	// Fields
	public object root; // 0x18
	public object cullingCount; // 0x20
	public object culling; // 0x28
	private const object cameraPlaneHeight;
	public object selectedInBound; // 0x30
	public object selectedOutBound; // 0x40
	public object unselected; // 0x50
	public object cameraCulling2D; // 0x60

	// Methods

	// RVA: 0xF7DCAC
	private object Reset() { }

	// RVA: 0xF7DE2C
	public object .ctor() { }

}

// Namespace: 
public class FixedMeshTrail
{

	// Fields
	public object length; // 0x18
	public object lengthSegs; // 0x1C
	public object width; // 0x20
	public object waveLength; // 0x24
	public object waveHeight; // 0x28
	public object waveSpeed; // 0x2C
	private object points; // 0x30
	private object prePos; // 0x38
	private object dir; // 0x44
	private object clipLength; // 0x50
	private object t; // 0x58
	private object tail; // 0x60
	private object vertices; // 0x68
	private object step; // 0x70
	private object waveFadeIn; // 0x74
	private object fadeInTime; // 0x78
	public object textureAnimation; // 0x7C
	public object textureChannel; // 0x80
	public object tilesX; // 0x88
	public object tilesY; // 0x8C
	public object frameRate; // 0x90
	public object mirrorX; // 0x94
	public object mirrorY; // 0x95
	private object mat; // 0x98

	// Methods

	// RVA: 0xF7DFA4
	private object Awake() { }

	// RVA: 0xF7E5A4
	private object Update() { }

	// RVA: 0xF7E2C4
	private object BuildVertices(object length, object width, object lengthSegs) { }

	// RVA: 0xF7E3C4
	private object BuildUVs(object lengthSegs) { }

	// RVA: 0xF7E4A0
	private object BuildTriangles(object lengthSegs) { }

	// RVA: 0xF7F0F0
	private object UVAnim() { }

	// RVA: 0xF7F224
	private object OnDestroy() { }

	// RVA: 0xF7F300
	public object .ctor() { }

}

// Namespace: 
private struct TrailSection
{

	// Fields
	public object point; // 0xFFFFFFFFFFFFFFF8
	public object upDir; // 0x4
	public object time; // 0x10
}

// Namespace: 
public class MeshTrail
{

	// Fields
	public object width; // 0x18
	public object time; // 0x1C
	public object minDistance; // 0x20
	public object startColor; // 0x24
	public object endColor; // 0x34
	private object sections; // 0x48
	private object prePos; // 0x50

	// Methods

	// RVA: 0xF7F388
	private object Awake() { }

	// RVA: 0xF7F3DC
	private object LateUpdate() { }

	// RVA: 0xF7FF84
	public object .ctor() { }

}

// Namespace: 
private struct TrailSection
{

	// Fields
	public object point; // 0xFFFFFFFFFFFFFFF8
	public object upDir; // 0x4
	public object time; // 0x10
}

// Namespace: 
public class MeshTrailAngle
{

	// Fields
	public object width; // 0x18
	public object time; // 0x1C
	public object minDistance; // 0x20
	public object startColor; // 0x24
	public object endColor; // 0x34
	private object sections; // 0x48
	private object currPos; // 0x50
	private object prePos; // 0x5C
	private object t; // 0x68
	private object mesh; // 0x70

	// Methods

	// RVA: 0xF80024
	private object Awake() { }

	// RVA: 0xF80158
	private object LateUpdate() { }

	// RVA: 0xF80A8C
	public object OnCreate() { }

	// RVA: 0xF80A90
	public object OnPrepare() { }

	// RVA: 0xF80A94
	public object OnGet() { }

	// RVA: 0xF80BF0
	public object OnRecycle() { }

	// RVA: 0xF80A98
	private object Reset() { }

	// RVA: 0xF80BF4
	public object .ctor() { }

}

// Namespace: 
public sealed class UIMaterialAnimation
{

	// Fields
	public object name1; // 0x18
	public object id1; // 0x20
	public object float1; // 0x24
	public object name2; // 0x28
	public object id2; // 0x30
	public object float2; // 0x34
	public object name3; // 0x38
	public object id3; // 0x40
	public object float3; // 0x44
	public object name4; // 0x48
	public object id4; // 0x50
	public object float4; // 0x54
	public object vectorname1; // 0x58
	public object vectorid1; // 0x60
	public object vector1; // 0x64
	public object vectorname2; // 0x78
	public object vectorid2; // 0x80
	public object vector2; // 0x84
	public object vectorname3; // 0x98
	public object vectorid3; // 0xA0
	public object vector3; // 0xA4
	public object vectorname4; // 0xB8
	public object vectorid4; // 0xC0
	public object vector4; // 0xC4
	public object colorname1; // 0xD8
	public object colorid1; // 0xE0
	public object color1; // 0xE4
	public object colorname2; // 0xF8
	public object colorid2; // 0x100
	public object color2; // 0x104
	public object colorname3; // 0x118
	public object colorid3; // 0x120
	public object color3; // 0x124
	public object colorname4; // 0x138
	public object colorid4; // 0x140
	public object color4; // 0x144
	public object texScaleOffsetname1; // 0x158
	public object texScaleOffsetid1; // 0x160
	public object texScaleOffset1; // 0x164
	public object texScaleOffsetname2; // 0x178
	public object texScaleOffsetid2; // 0x180
	public object texScaleOffset2; // 0x184
	public object texScaleOffsetname3; // 0x198
	public object texScaleOffsetid3; // 0x1A0
	public object texScaleOffset3; // 0x1A4
	public object texScaleOffsetname4; // 0x1B8
	public object texScaleOffsetid4; // 0x1C0
	public object texScaleOffset4; // 0x1C4
	public object rangename1; // 0x1D8
	public object rangeid1; // 0x1E0
	public object range1; // 0x1E4
	public object rangename2; // 0x1E8
	public object rangeid2; // 0x1F0
	public object range2; // 0x1F4
	public object rangename3; // 0x1F8
	public object rangeid3; // 0x200
	public object range3; // 0x204
	public object rangename4; // 0x208
	public object rangeid4; // 0x210
	public object range4; // 0x214
	public object graphic; // 0x218
	public object m_mat; // 0x220

	// Methods

	// RVA: 0xF80C94
	public static object TryGetID(object name, object id) { }

	// RVA: 0xF80D48
	public static object SetupValue(object mat, object name, object id, object value) { }

	// RVA: 0xF80E4C
	public static object SetupValue(object mat, object name, object id, object value) { }

	// RVA: 0xF80F74
	public static object SetupValue(object mat, object name, object id, object value) { }

	// RVA: 0xF8109C
	public static object SetupTexValue(object mat, object name, object id, object value) { }

	// RVA: 0xF811D4
	public object Update() { }

	// RVA: 0xF813F8
	public object IsValidMaterial() { }

	// RVA: 0xF816F4
	public object .ctor() { }

}

// Namespace: 
public class HeroLightConflictFix
{

	// Fields
	private static readonly object eventKey; // 0x0
	public object MyLight; // 0x18

	// Methods

	// RVA: 0xF8176C
	private object Process(object source, object enable) { }

	// RVA: 0xF8183C
	private object OnEnable() { }

	// RVA: 0xF81960
	private object OnDisable() { }

	// RVA: 0xF81A94
	public object .ctor() { }

	// RVA: 0xF81A9C
	private static object .cctor() { }

}

// Namespace: 
public class UIHeroFogSetting
{

	// Fields
	public object overrideFog; // 0x18
	public object m_bFog; // 0x19
	public object m_FogColor; // 0x1C
	public object m_FogMode; // 0x2C
	public object m_FogDensity; // 0x30
	public object m_LinearFogStart; // 0x34
	public object m_LinearFogEnd; // 0x38
	public object m_AmbientLight; // 0x3C

	// Methods

	// RVA: 0xF81B2C
	public object .ctor() { }

}

// Namespace: 
public enum test
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object once;
	public const object loop;
}

// Namespace: 
public class AnimationControl
{

	// Fields
	public object animationName; // 0x8
	public object playMode; // 0x10
	public object useCustomDuration; // 0x14
	public object durationTime; // 0x18
	public object timeScale; // 0x1C
	public object animDuration; // 0x20

	// Methods

	// RVA: 0xF81EAC
	public object .ctor() { }

}

// Namespace: 
private sealed class <DoDemoRoutine>d__7
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <i>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xF81C74
	public object .ctor(object <>1__state) { }

	// RVA: 0xF81EBC
	private object System.IDisposable.Dispose() { }

	// RVA: 0xF81EC0
	private object MoveNext() { }

	// RVA: 0xF822AC
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xF822B4
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xF822F4
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
public class SpineUIAnimaController
{

	// Fields
	private object isLoop; // 0x18
	private object skeletonGraphic; // 0x20
	private object spineAnimationState; // 0x28
	public object controls; // 0x30

	// Methods

	// RVA: 0xF81B40
	private object OnEnable() { }

	// RVA: 0xF81C08
	private object DoDemoRoutine() { }

	// RVA: 0xF81CA0
	public object GetDuration(object ani) { }

	// RVA: 0xF81D30
	public object .ctor() { }

}

// Namespace: 
public class Distortion
{

	// Fields
	private static object s_enableCnt; // 0x0
	private static object s_Mat; // 0x8
	private static object s_DistortionRT; // 0x10
	private static object s_HostGo; // 0x18
	private static object s_CamDistortion; // 0x20
	private static object s_Intensity; // 0x28
	private static object s_ID_DistortTex; // 0x2C
	private static object s_ID_Intensity; // 0x30
	private static object s_layerMask; // 0x34
	public object m_ShowDistortionRt; // 0x18
	private const object hero3DImageName;
	private const object heroCameraName;

	// Methods

	// RVA: 0xF822FC
	private object OnDestroy() { }

	// RVA: 0xF82630
	private static object InitMaterial() { }

	// RVA: 0xF829C4
	private static object GetCamera(object obj) { }

	// RVA: 0xF82B58
	private static object PrepareCamera() { }

	// RVA: 0xF82DB0
	private static object PrepareHostGameObject(object cam) { }

	// RVA: 0xF83144
	public static object EnableDistortion(object obj, object distortIntensity) { }

	// RVA: 0xF835F8
	public static object DisableDistortion(object byWhoID) { }

	// RVA: 0xF82430
	public static object RealDisableDistortion() { }

	// RVA: 0xF83660
	private object Update() { }

	// RVA: 0xF837D4
	public static object SetProjMatrix(object camera) { }

	// RVA: 0xF83938
	public static object Render(object src, object dst) { }

	// RVA: 0xF83AD8
	public object .ctor() { }

}

// Namespace: 
public class DistortionNotifyer
{

	// Fields
	public object m_Intensity; // 0x18
	private object m_started; // 0x1C
	private object m_ended; // 0x1D
	private object m_ps; // 0x20
	private object m_isSupported; // 0x28
	private object m_renderer; // 0x30

	// Methods

	// RVA: 0xF83AE0
	private object OnEnable() { }

	// RVA: 0xF83E10
	private object OnDisable() { }

	// RVA: 0xF83CD8
	private object EnableDistortion() { }

	// RVA: 0xF83EAC
	private object DisableDistortion() { }

	// RVA: 0xF83F48
	private object Update() { }

	// RVA: 0xF84184
	private object OnDestroy() { }

	// RVA: 0xF84220
	public object .ctor() { }

}

// Namespace: 
public class DistortionRenderer
{

	// Fields
	private object m_camera; // 0x18

	// Methods

	// RVA: 0xF84230
	private object OnEnable() { }

	// RVA: 0xF8428C
	private object OnRenderImage(object src, object dst) { }

	// RVA: 0xF84298
	private object Update() { }

	// RVA: 0xF842E4
	public object .ctor() { }

}

// Namespace: 
public struct HeroBloomConfig
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_BloomThreshold; // 0xFFFFFFFFFFFFFFFC
	public object m_BloomIntensity; // 0x0
	public object m_BloomColor; // 0x4
	public object m_BlurNum; // 0x14

	// Methods

	// RVA: 0xF84340
	public object Init() { }

	// RVA: 0xF84388
	public object Update(object obj) { }

	// RVA: 0xF84480
	public object Disable() { }

	// RVA: 0xF84560
	public object IsEnable() { }

}

// Namespace: 
public struct HeroChromaticAberrationConfig
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_Intensity; // 0xFFFFFFFFFFFFFFFC
	public object m_CenterPosX; // 0x0
	public object m_CenterPosY; // 0x4
	public object m_RedOffsetU; // 0x8
	public object m_RedOffsetV; // 0xC
	public object m_GreenOffsetU; // 0x10
	public object m_GreenOffsetV; // 0x14
	public object m_BlueOffsetU; // 0x18
	public object m_BlueOffsetV; // 0x1C
	public object m_ColorInverse; // 0x20
	public object m_VignetteSize; // 0x24
	public object m_VignetteColor; // 0x28

	// Methods

	// RVA: 0xF8461C
	public object Init() { }

	// RVA: 0xF84664
	public object Update(object obj) { }

	// RVA: 0xF84808
	public object Disable() { }

	// RVA: 0xF848F0
	public object IsEnable() { }

	// RVA: 0xF847FC
	private object Pow3(object x) { }

}

// Namespace: 
public struct HeroOverlayConfig
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_Intensity; // 0xFFFFFFFFFFFFFFFC
	public object m_Lighten; // 0x0
	public object m_Darken; // 0x4
	public object m_LightenTexture; // 0x8
	public object m_DarkenTexture; // 0x10
	private object m_oldLighten; // 0x18

	// Methods

	// RVA: 0xF849D0
	public object Init() { }

	// RVA: 0xF849F8
	public object Validate() { }

	// RVA: 0xF84A68
	public object Update(object obj) { }

	// RVA: 0xF84B58
	public object Disable() { }

	// RVA: 0xF84C40
	public object IsEnable() { }

}

// Namespace: 
public struct HeroRadialBlurConfig
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_Intensity; // 0xFFFFFFFFFFFFFFFC
	public object m_Extend; // 0x0
	public object m_CenterPosX; // 0x4
	public object m_CenterPosY; // 0x8
	public object m_BlurNum; // 0xC

	// Methods

	// RVA: 0xF84CCC
	public object Init() { }

	// RVA: 0xF84CFC
	public object Update(object obj) { }

	// RVA: 0xF84F78
	public object Disable() { }

	// RVA: 0xF85060
	public object IsEnable() { }

}

// Namespace: 
public struct HeroMotionBlurConfig
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_Intensity; // 0xFFFFFFFFFFFFFFFC
	public object m_Extend; // 0x0
	public object m_DirectionX; // 0x4
	public object m_DirectionY; // 0x8
	public object m_BlurNum; // 0xC

	// Methods

	// RVA: 0xF850EC
	public object Init() { }

	// RVA: 0xF8511C
	public object Update(object obj) { }

	// RVA: 0xF852CC
	public object Disable() { }

	// RVA: 0xF853B4
	public object IsEnable() { }

}

// Namespace: 
public struct HeroBWFilterConfig
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_Intensity; // 0xFFFFFFFFFFFFFFFC
	public object m_Lighten; // 0x0
	public object m_Darken; // 0x4
	public object m_LightenColor; // 0x8
	public object m_DarkenColor; // 0x18
	private object m_oldLighten; // 0x28

	// Methods

	// RVA: 0xF85470
	public object Init() { }

	// RVA: 0xF854A8
	public object Validate() { }

	// RVA: 0xF85518
	public object Update(object obj) { }

	// RVA: 0xF85650
	public object Disable() { }

	// RVA: 0xF85738
	public object IsEnable() { }

}

// Namespace: 
public struct HeroDoFConfig
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_EnableOnUltra; // 0xFFFFFFFFFFFFFFF9
	public object m_FocusDistance; // 0xFFFFFFFFFFFFFFFC
	public object m_Aperture; // 0x0
	public object m_BlurScale; // 0x4

	// Methods

	// RVA: 0xF857D4
	public object Init() { }

	// RVA: 0xF85814
	public object Update(object obj) { }

	// RVA: 0xF85960
	public object Disable() { }

	// RVA: 0xF85A48
	public object IsEnable() { }

}

// Namespace: 
public class HeroConfigProxy
{

	// Fields
	public object BloomConfig; // 0x18
	public object CAConfig; // 0x38
	public object OverlayConfig; // 0x78
	public object RadialBlurConfig; // 0xA0
	public object MotionBlurConfig; // 0xB8
	public object BWFilterConfig; // 0xD0
	public object DoFConfig; // 0x104
	private object ui3DController; // 0x118
	protected object enableConfig; // 0x120

	// Methods

	// RVA: 0xF85A58
	public object Reset() { }

	// RVA: 0xF85AFC
	public object Start() { }

	// RVA: 0xF85E00
	private object UsePostProcessing() { }

	// RVA: 0xF85B5C
	private object Update() { }

	// RVA: 0xF85F4C
	private object SetEnable() { }

	// RVA: 0xF85FBC
	public object OnDisable() { }

	// RVA: 0xF8604C
	public override object PreRender(object cam) { }

	// RVA: 0xF860F4
	public override object PostRender() { }

	// RVA: 0xF86294
	public override object IsCameraTrace() { }

	// RVA: 0xF8629C
	public object GetGameObject() { }

	// RVA: 0xF862A4
	private object OnValidate() { }

	// RVA: 0xF86488
	public object .ctor() { }

}

// Namespace: 
public struct HeroBloomConfig2
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_PyramidBloom; // 0xFFFFFFFFFFFFFFF9
	public object m_BloomThreshold; // 0xFFFFFFFFFFFFFFFC
	public object m_BloomIntensity; // 0x0
	public object m_BloomColor; // 0x4
	public object m_BlurNum; // 0x14

	// Methods

	// RVA: 0xF864F4
	public object Init() { }

	// RVA: 0xF8653C
	public object Update(object obj) { }

	// RVA: 0xF86638
	public object Disable() { }

	// RVA: 0xF86718
	public object IsEnable() { }

}

// Namespace: 
public struct HeroBloomStyleConfig
{

	// Fields
	public object m_PointTiling; // 0xFFFFFFFFFFFFFFF8
	public object m_PointRot; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object Enable { get; }

	// Methods

	// RVA: 0xF86760
	public object get_Enable() { }

	// RVA: 0xF867A8
	public object Init() { }

	// RVA: 0xF867B8
	public object Update(object obj) { }

	// RVA: 0xF868A0
	public object Disable() { }

}

// Namespace: 
public struct HeroOutlineConfig
{

	// Fields
	public object Enable; // 0xFFFFFFFFFFFFFFF8
	public object m_OutlineColor; // 0xFFFFFFFFFFFFFFFC
	public object m_OutlineFalloff; // 0xC
	public object m_GlowColor; // 0x10
	public object m_GlowFalloff; // 0x20
	public object m_BlurNum; // 0x24

	// Methods

	// RVA: 0xF86A14
	public object Init() { }

	// RVA: 0xF86A74
	public object Update(object obj) { }

	// RVA: 0xF86B90
	public object Disable() { }

	// RVA: 0xF86C70
	public object IsEnable() { }

}

// Namespace: 
public class HeroConfigProxy2
{

	// Fields
	public object ToneMapping; // 0x18
	public object BloomConfig; // 0x1C
	public object BloomStyle; // 0x3C
	public object OutlineConfig; // 0x44
	private object ui3DController; // 0x78
	public object showData; // 0x80
	public object HeroConfigShowData_TestValue; // 0x88
	protected object enableConfig; // 0x8C

	// Methods

	// RVA: 0xF86C80
	private object Reset() { }

	// RVA: 0xF86CD4
	private object Start() { }

	// RVA: 0xF86F5C
	private object LoadFromScriptableObj() { }

	// RVA: 0xF87020
	private object UsePostProcessing() { }

	// RVA: 0xF86DD8
	private object Update() { }

	// RVA: 0xF8716C
	private object SetEnable() { }

	// RVA: 0xF871DC
	public object OnDisable() { }

	// RVA: 0xF8726C
	public override object PreRender(object cam) { }

	// RVA: 0xF87360
	public override object PostRender() { }

	// RVA: 0xF874F0
	public override object IsCameraTrace() { }

	// RVA: 0xF874F8
	public object GetGameObject() { }

	// RVA: 0xF87500
	private object OnValidate() { }

	// RVA: 0xF8760C
	public object .ctor() { }

}

// Namespace: 
public class HeroConfigShowData
{

	// Fields
	public object TestValue; // 0x10
	private static object s_defaultName; // 0x0

	// Methods

	// RVA: 0xF87614
	public object .ctor() { }

	// RVA: 0xF8761C
	private static object .cctor() { }

}

// Namespace: 
public abstract class PPS_Component
{

	// Methods

	// RVA: -1
	public abstract object Init() { }

	// RVA: -1
	public abstract object DoUpdate(object obj) { }

	// RVA: -1
	public abstract object IsEnable() { }

	// RVA: -1
	public abstract object Disable() { }

	// RVA: -1
	public abstract object SetDeactive() { }

	// RVA: 0xF87688
	protected object Deactive(object types) { }

	// RVA: 0xF8768C
	protected object DeactiveOthers(object types) { }

	// RVA: 0xF87690
	protected object .ctor() { }

}

// Namespace: 
public class PostProcessingSetting
{

	// Fields
	public object configs; // 0x18
	protected object uiCamera; // 0x20
	private object bloom; // 0x28
	private object outline; // 0x30
	private object ui3DController; // 0x38
	protected object enableConfig; // 0x40

	// Methods

	// RVA: 0xF87698
	private object Start() { }

	// RVA: 0xF87834
	protected virtual object UsePostProcessing() { }

	// RVA: 0xF87A04
	public object Update() { }

	// RVA: 0xF87D24
	private object SetEnable() { }

	// RVA: 0xF87C94
	public object OnDisable() { }

	// RVA: 0xF87DAC
	public override object PreRender(object cam) { }

	// RVA: 0xF88020
	public override object PostRender() { }

	// RVA: 0xF8822C
	public override object IsCameraTrace() { }

	// RVA: 0xF88234
	public object GetGameObject() { }

	// RVA: 0xF876F8
	public object UpdateConfigs() { }

	// RVA: 0xF8823C
	public object .ctor() { }

}

// Namespace: 
public class PPS_Bloom
{

	// Fields
	public object Enable; // 0x18
	public object m_PyramidBloom; // 0x19
	public object m_BloomThreshold; // 0x1C
	public object m_BloomIntensity; // 0x20
	public object m_BloomFalloff; // 0x24
	public object m_BloomColor; // 0x28
	public object m_BlurNum; // 0x38

	// Methods

	// RVA: 0xF882A0
	public override object Init() { }

	// RVA: 0xF883D4
	public override object IsEnable() { }

	// RVA: 0xF88424
	public override object DoUpdate(object obj) { }

	// RVA: 0xF88528
	public override object Disable() { }

	// RVA: 0xF88598
	public override object SetDeactive() { }

	// RVA: 0xF885A0
	private object OnValidate() { }

	// RVA: 0xF886E4
	public object .ctor() { }

}

// Namespace: 
public class PPS_BWFilter
{

	// Fields
	public object Enable; // 0x18
	public object m_Intensity; // 0x1C
	public object m_Range; // 0x20
	public object m_LightenColor; // 0x28
	public object m_DarkenColor; // 0x38

	// Methods

	// RVA: 0xF886EC
	public override object Init() { }

	// RVA: 0xF8870C
	public override object DoUpdate(object obj) { }

	// RVA: 0xF88830
	public override object IsEnable() { }

	// RVA: 0xF88880
	public override object Disable() { }

	// RVA: 0xF888F0
	public override object SetDeactive() { }

	// RVA: 0xF888F8
	private object OnValidate() { }

	// RVA: 0xF88A3C
	public object .ctor() { }

}

// Namespace: 
public class PPS_Camera
{

	// Fields
	public object camera; // 0x18

	// Methods

	// RVA: 0xF88A44
	public override object Init() { }

	// RVA: 0xF88B10
	public override object DoUpdate(object obj) { }

	// RVA: 0xF88B14
	public override object IsEnable() { }

	// RVA: 0xF88B1C
	public override object Disable() { }

	// RVA: 0xF88B20
	public override object SetDeactive() { }

	// RVA: 0xF88B24
	public object .ctor() { }

}

// Namespace: 
public class PPS_CameraMotionBlur
{

	// Fields
	public object Enable; // 0x18
	public object m_Intensity; // 0x1C
	public object m_Extend; // 0x20
	public object m_Distance; // 0x24
	public object m_BlurNum; // 0x28

	// Methods

	// RVA: 0xF88B2C
	public override object Init() { }

	// RVA: 0xF88B44
	public override object DoUpdate(object obj) { }

	// RVA: 0xF88C1C
	public override object IsEnable() { }

	// RVA: 0xF88C6C
	public override object Disable() { }

	// RVA: 0xF88CDC
	public override object SetDeactive() { }

	// RVA: 0xF88CE4
	private object OnValidate() { }

	// RVA: 0xF88E74
	public object .ctor() { }

}

// Namespace: 
public class PPS_ChromaticAberration
{

	// Fields
	public object CAConfig; // 0x18

	// Methods

	// RVA: 0xF88E7C
	public override object Init() { }

	// RVA: 0xF88EA0
	public override object DoUpdate(object obj) { }

	// RVA: 0xF88EA8
	public override object IsEnable() { }

	// RVA: 0xF88F30
	public override object Disable() { }

	// RVA: 0xF88FA0
	public override object SetDeactive() { }

	// RVA: 0xF88FA8
	private object OnValidate() { }

	// RVA: 0xF890EC
	public object .ctor() { }

}

// Namespace: 
public class PPS_ColorGrading
{

	// Fields
	public object Enable; // 0x18
	public object m_Intensity; // 0x1C
	public object m_Lut; // 0x20

	// Methods

	// RVA: 0xF890F4
	public override object Init() { }

	// RVA: 0xF89104
	public override object DoUpdate(object obj) { }

	// RVA: 0xF891C4
	public override object IsEnable() { }

	// RVA: 0xF89214
	public override object Disable() { }

	// RVA: 0xF89284
	public override object SetDeactive() { }

	// RVA: 0xF8928C
	private object OnValidate() { }

	// RVA: 0xF89560
	public object .ctor() { }

}

// Namespace: 
public class PPS_Debug
{

	// Fields
	public object datas; // 0x18

	// Methods

	// RVA: 0xF89568
	public override object Init() { }

	// RVA: 0xF895C4
	public override object DoUpdate(object obj) { }

	// RVA: 0xF89654
	public override object IsEnable() { }

	// RVA: 0xF8965C
	public override object Disable() { }

	// RVA: 0xF896CC
	public override object SetDeactive() { }

	// RVA: 0xF896D0
	public object .ctor() { }

}

// Namespace: 
public class PPS_DoF
{

	// Fields
	public object DoFConfig; // 0x18

	// Methods

	// RVA: 0xF896D8
	public override object Init() { }

	// RVA: 0xF896F8
	public override object DoUpdate(object obj) { }

	// RVA: 0xF89700
	public override object IsEnable() { }

	// RVA: 0xF89744
	public override object Disable() { }

	// RVA: 0xF897B4
	public override object SetDeactive() { }

	// RVA: 0xF897BC
	private object OnValidate() { }

	// RVA: 0xF89900
	public object .ctor() { }

}

// Namespace: 
public class PPS_MotionBlur
{

	// Fields
	public object MotionBlurConfig; // 0x18

	// Methods

	// RVA: 0xF89908
	public override object Init() { }

	// RVA: 0xF89920
	public override object DoUpdate(object obj) { }

	// RVA: 0xF89928
	public override object Disable() { }

	// RVA: 0xF89998
	public override object IsEnable() { }

	// RVA: 0xF899E8
	public override object SetDeactive() { }

	// RVA: 0xF899F0
	private object OnValidate() { }

	// RVA: 0xF89B80
	public object .ctor() { }

}

// Namespace: 
public class PPS_Outline
{

	// Fields
	public object OutlineConfig; // 0x18

	// Methods

	// RVA: 0xF89B88
	public override object Init() { }

	// RVA: 0xF89BB8
	public override object DoUpdate(object obj) { }

	// RVA: 0xF89BC0
	public override object Disable() { }

	// RVA: 0xF89C30
	public override object IsEnable() { }

	// RVA: 0xF89C74
	public override object SetDeactive() { }

	// RVA: 0xF89C7C
	private object OnValidate() { }

	// RVA: 0xF89E0C
	public object .ctor() { }

}

// Namespace: 
public class PPS_Overlay
{

	// Fields
	public object Enable; // 0x18
	public object m_Intensity; // 0x1C
	public object m_Range; // 0x20
	public object m_LightenTexture; // 0x28
	public object m_DarkenTexture; // 0x30

	// Methods

	// RVA: 0xF89E14
	public override object Init() { }

	// RVA: 0xF89E30
	public override object DoUpdate(object obj) { }

	// RVA: 0xF89F0C
	public override object IsEnable() { }

	// RVA: 0xF89F5C
	public override object Disable() { }

	// RVA: 0xF89FCC
	public override object SetDeactive() { }

	// RVA: 0xF89FD4
	private object OnValidate() { }

	// RVA: 0xF8A118
	public object .ctor() { }

}

// Namespace: 
public class PPS_Pixelize
{

	// Fields
	public object Enable; // 0x18
	public object m_Intensity; // 0x1C
	public object m_PixelSlice; // 0x20

	// Methods

	// RVA: 0xF8A120
	public override object Init() { }

	// RVA: 0xF8A130
	public override object DoUpdate(object obj) { }

	// RVA: 0xF8A210
	public override object IsEnable() { }

	// RVA: 0xF8A260
	public override object Disable() { }

	// RVA: 0xF8A2D0
	public override object SetDeactive() { }

	// RVA: 0xF8A2D8
	private object OnValidate() { }

	// RVA: 0xF8A41C
	public object .ctor() { }

}

// Namespace: 
public class PPS_PointStyleBloom
{

	// Fields
	public object Enable; // 0x18
	public object m_PyramidBloom; // 0x19
	public object m_BloomThreshold; // 0x1C
	public object m_BloomIntensity; // 0x20
	public object m_BloomFalloff; // 0x24
	public object m_BloomColor; // 0x28
	public object m_BlurNum; // 0x38
	public object m_PointTiling; // 0x3C
	public object m_PointRot; // 0x40

	// Methods

	// RVA: 0xF8A424
	public override object Init() { }

	// RVA: 0xF8A450
	public override object DoUpdate(object obj) { }

	// RVA: 0xF8A560
	public override object IsEnable() { }

	// RVA: 0xF8A5B0
	public override object Disable() { }

	// RVA: 0xF8A614
	public override object SetDeactive() { }

	// RVA: 0xF8A61C
	private object OnValidate() { }

	// RVA: 0xF8A6D0
	public object .ctor() { }

}

// Namespace: 
public class PPS_RadialBlur
{

	// Fields
	public object RadialBlurConfig; // 0x18

	// Methods

	// RVA: 0xF8A6D8
	public override object Init() { }

	// RVA: 0xF8A6F0
	public override object DoUpdate(object obj) { }

	// RVA: 0xF8A6F8
	public override object Disable() { }

	// RVA: 0xF8A768
	public override object IsEnable() { }

	// RVA: 0xF8A7B8
	public override object SetDeactive() { }

	// RVA: 0xF8A7C0
	private object OnValidate() { }

	// RVA: 0xF8A950
	public object .ctor() { }

}

// Namespace: 
public class PPS_Tonemap
{

	// Fields
	public object tonemap; // 0x18

	// Methods

	// RVA: 0xF8A958
	public override object Init() { }

	// RVA: 0xF8A960
	public override object DoUpdate(object obj) { }

	// RVA: 0xF8A9F0
	public override object IsEnable() { }

	// RVA: 0xF8A9F8
	public override object Disable() { }

	// RVA: 0xF8AA70
	public override object SetDeactive() { }

	// RVA: 0xF8AA74
	public object .ctor() { }

}

// Namespace: 
public class UIPostProcessingSetting
{

	// Fields
	public object supportLowQuality; // 0x41

	// Methods

	// RVA: 0xF8AA7C
	private object Start() { }

	// RVA: 0xF8ABD0
	public override object IsCameraTrace() { }

	// RVA: 0xF8ABD8
	protected override object UsePostProcessing() { }

	// RVA: 0xF8AAA0
	public object GetCamera() { }

	// RVA: 0xF8AD28
	public override object PreRender(object cam) { }

	// RVA: 0xF8AD2C
	public object .ctor() { }

}

// Namespace: 
public class SkillTestProxy
{

	// Fields
	public object SkillTestFramework; // 0x18

	// Methods

	// RVA: 0xF8AD90
	private object Awake() { }

	// RVA: 0xF8AE70
	private object Start() { }

	// RVA: 0xF8AE98
	public object .ctor() { }

}

// Namespace: 
public class WinUtility
{

	// Methods

	// RVA: 0xF8AEA0
	public object .ctor() { }

}

// Namespace: 
public class LiquidController
{

	// Fields
	public object speedCorrect; // 0x18
	public object animMinIntensity; // 0x1C
	public object animMaxIntensity; // 0x20
	public object liquidObject; // 0x28
	private object liquidMaterial; // 0x30
	private object lastFramePos; // 0x38
	private object lastSpeeds; // 0x48

	// Methods

	// RVA: 0xF8AEA8
	private object Start() { }

	// RVA: 0xF8B050
	private object OnEnable() { }

	// RVA: 0xF8B088
	private object Update() { }

	// RVA: 0xF8B2E4
	public object .ctor() { }

}

// Namespace: 
public class Rotation
{

	// Fields
	public object rotateSpeed; // 0x18
	public object rotateDirection; // 0x1C

	// Methods

	// RVA: 0xF8B358
	private object Update() { }

	// RVA: 0xF8B428
	public object .ctor() { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _VFXStencilId1; // 0x0
	public static readonly object _VFXStencilId2; // 0x4

	// Methods

	// RVA: 0xF8BC88
	private static object .cctor() { }

}

// Namespace: 
public class UniqueVFXStencilId
{

	// Fields
	private static object s_stencilId; // 0x0
	private object m_materialsWithStencilId1; // 0x18
	private object m_materialsWithStencilId2; // 0x20
	private object m_stencilID; // 0x28

	// Methods

	// RVA: 0xF8B438
	public object OnEnable() { }

	// RVA: 0xF8BBBC
	public object OnDisable() { }

	// RVA: 0xF8B464
	private object InitMaterialsWithStencilId() { }

	// RVA: 0xF8BA24
	private object SetStencilIdToMaterials() { }

	// RVA: 0xF8B80C
	private object GetStencileID() { }

	// RVA: 0xF8BC30
	public object .ctor() { }

	// RVA: 0xF8BC38
	private static object .cctor() { }

}

// Namespace: 
public class WorldPosToMat
{

	// Fields
	public object PropName; // 0x18

	// Methods

	// RVA: 0xF8BD28
	private object Update() { }

	// RVA: 0xF8BD2C
	private object SetPosInfoToMaterials() { }

	// RVA: 0xF8BDD8
	public object .ctor() { }

}

// Namespace: 
public class ShadowMappingObject
{

	// Methods

	// RVA: 0xF8BDE0
	public object .ctor() { }

}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0xF8BDE8
	private static object Get() { }

	// RVA: 0xF8BEB8
	public object .ctor() { }

}

// Namespace: UnityEngine
public class MinMaxSliderAttribute
{

	// Fields
	public readonly object min; // 0x8
	public readonly object max; // 0xC

	// Methods

	// RVA: 0xF8BFF4
	public object .ctor() { }

	// RVA: 0xF8C024
	public object .ctor(object min, object max) { }

}

// Namespace: ArtTools
public class CameraDepth
{

	// Fields
	public object mode; // 0x18

	// Methods

	// RVA: 0xF8C05C
	private object Start() { }

	// RVA: 0xF8C160
	private object OnValidate() { }

	// RVA: 0xF8C164
	public object .ctor() { }

}

// Namespace: ArtTools
public class CameraPosition
{

	// Fields
	public object data; // 0x18

	// Methods

	// RVA: 0xF8C174
	public object .ctor() { }

}

// Namespace: ArtTools
public class CameraPositionData
{

	// Fields
	public object names; // 0x10
	public object positions; // 0x18

	// Methods

	// RVA: 0xF8C17C
	public object .ctor() { }

}

// Namespace: ArtTools
public class DrawBones
{

	// Methods

	// RVA: 0xF8C204
	public object .ctor() { }

}

// Namespace: 
public enum TrailAlignment
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object View;
	public const object Velocity;
	public const object Local;
}

// Namespace: 
public enum TrailSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object World;
	public const object Self;
	public const object Custom;
	public const object LocalGravity;
}

// Namespace: 
public enum TrailSorting
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OlderOnTop;
	public const object NewerOnTop;
}

// Namespace: 
public enum Timescale
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Unscaled;
}

// Namespace: 
public enum TextureMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Stretch;
	public const object Tile;
	public const object WorldTile;
}

// Namespace: 
public struct CurveFrame
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object normal; // 0x4
	public object bitangent; // 0x10
	public object tangent; // 0x1C

	// Methods

	// RVA: 0xF92078
	public object .ctor(object position, object normal, object bitangent, object tangent) { }

	// RVA: 0xF920D8
	public object Transport(object newTangent, object newPosition) { }

}

// Namespace: 
public struct Point
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object velocity; // 0x4
	public object tangent; // 0x10
	public object normal; // 0x1C
	public object color; // 0x28
	public object thickness; // 0x38
	public object life; // 0x3C
	public object texcoord; // 0x40
	public object discontinuous; // 0x44

	// Methods

	// RVA: 0xF92304
	public object .ctor(object position, object velocity, object tangent, object normal, object color, object thickness, object texcoord, object lifetime) { }

	// RVA: 0xF9239C
	public static object CatmullRom(object p0, object p1, object p2, object p3, object t) { }

	// RVA: 0xF92408
	public static object op_Addition(object p1, object p2) { }

	// RVA: 0xF92458
	public static object op_Subtraction(object p1, object p2) { }

}

// Namespace: 
public enum MaterialPropType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Color;
	public const object Vector;
	public const object Float;
	public const object Range;
	public const object None;
}

// Namespace: 
public struct MaterialProp
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object value; // 0xFFFFFFFFFFFFFFFC
	public object name; // 0x10
	public object id; // 0x18
}

// Namespace: Ara
public class AraTrail
{

	// Fields
	public const object epsilon;
	public const object section;
	public object space; // 0x18
	public object customSpace; // 0x20
	public const object timescale;
	public object alignment; // 0x28
	public object sorting; // 0x2C
	public object thickness; // 0x30
	public object dynamicSmoothness; // 0x34
	public object smoothness; // 0x38
	private const object highQualityCorners;
	public object cornerRoundness; // 0x3C
	public object removeOverdraw; // 0x40
	public object thicknessOverLength; // 0x48
	public object colorOverLength; // 0x68
	public object maxLength; // 0xA0
	public object truncatingLength; // 0xA4
	public object thicknessOverTime; // 0xA8
	public object colorOverTime; // 0xC8
	public object emit; // 0x100
	public const object initialThickness;
	public readonly object initialColor; // 0x104
	public object initialVelocity; // 0x114
	public object initialVelocityCustomSpace; // 0x120
	public object timeInterval; // 0x128
	public object minVertexDistance; // 0x12C
	public object time; // 0x130
	public object enablePhysics; // 0x134
	public object warmup; // 0x138
	public object flow; // 0x13C
	public object flowRandomFrequency; // 0x140
	public object flowRandomAngle; // 0x148
	public object gravity; // 0x168
	public object inertia; // 0x174
	public object velocitySmoothing; // 0x178
	public object damping; // 0x17C
	public object materials; // 0x180
	public const object castShadows;
	public const object receiveShadows;
	public const object useLightProbes;
	public const object quadMapping;
	public object textureMode; // 0x188
	public object uvFactor; // 0x18C
	public object uvWidthFactor; // 0x190
	public object tileAnchor; // 0x194
	public object propUpdate; // 0x198
	public object prop1; // 0x1A0
	public object prop2; // 0x1C8
	public object prop3; // 0x1F0
	public object prop4; // 0x218
	private object onUpdatePoints; // 0x240
	public object points; // 0x248
	private object renderablePoints; // 0x250
	private object discontinuities; // 0x258
	private object mesh_; // 0x260
	private object velocity; // 0x268
	private object prevPosition; // 0x274
	private object accumTime; // 0x280
	private object vertices; // 0x288
	private object normals; // 0x290
	private object tangents; // 0x298
	private object uvs; // 0x2A0
	private object vertColors; // 0x2A8
	private object tris; // 0x2B0
	private object nextV; // 0x2B8
	private object prevV; // 0x2C4
	private object vertex; // 0x2D0
	private object normal; // 0x2DC
	private object bitangent; // 0x2E8
	private object tangent; // 0x2F4
	private object texTangent; // 0x304
	private object uv; // 0x314
	private object color; // 0x324
	private object prevL; // 0x334
	private object prevR; // 0x340
	private readonly object meshDefaultName; // 0x350
	private object renderCallback; // 0x358
	private object attached; // 0x360

	// Properties
	public object vertCount { get; }
	public object Velocity { get; }
	private object DeltaTime { get; }
	private object FixedDeltaTime { get; }
	public object mesh { get; }
	public object worldToTrail { get; }

	// Methods

	// RVA: 0xF8C20C
	private object SetMaterialProp(object mat, object prop) { }

	// RVA: 0xF8C308
	private object MaterialPropUpdate() { }

	// RVA: 0xF8C46C
	public object add_onUpdatePoints(object value) { }

	// RVA: 0xF8C510
	public object remove_onUpdatePoints(object value) { }

	// RVA: 0xF8C5B4
	public object get_vertCount() { }

	// RVA: 0xF8C608
	public object get_Velocity() { }

	// RVA: 0xF8C618
	private object get_DeltaTime() { }

	// RVA: 0xF8C620
	private object get_FixedDeltaTime() { }

	// RVA: 0xF8C628
	public object get_mesh() { }

	// RVA: 0xF8C630
	public object get_worldToTrail() { }

	// RVA: 0xF8C78C
	public object Awake() { }

	// RVA: 0xF8C790
	public object Start() { }

	// RVA: 0xF8C8E8
	private object OnGet() { }

	// RVA: 0xF8CA64
	private object OnRecyle() { }

	// RVA: 0xF8C8EC
	private object OnEnable() { }

	// RVA: 0xF8CAC8
	private object OnDisable() { }

	// RVA: 0xF8CE68
	private object OnDestroy() { }

	// RVA: 0xF8CB2C
	private object AttachToCameraRendering() { }

	// RVA: 0xF8CD20
	private object DetachFromCameraRendering() { }

	// RVA: 0xF8CCC4
	public object Clear() { }

	// RVA: 0xF8CEF8
	private object UpdateVelocity() { }

	// RVA: 0xF8CFF0
	private object LateUpdate() { }

	// RVA: 0xF8D060
	private object EmissionStep(object time) { }

	// RVA: 0xF8C794
	private object Warmup() { }

	// RVA: 0xF8E160
	private object rotSpace(object v) { }

	// RVA: 0xF8DBEC
	private object PhysicsStep(object timeStep) { }

	// RVA: 0xF8E1CC
	private object FixedUpdate() { }

	// RVA: 0xF8D82C
	public object EmitPoint(object position) { }

	// RVA: 0xF8D1C0
	private object SnapLastPointToTransform() { }

	// RVA: 0xF8D504
	private object UpdatePointsLifecycle(object deltaLife) { }

	// RVA: 0xF8E384
	private object ClearMeshData() { }

	// RVA: 0xF8E4C0
	private object CommitMeshData() { }

	// RVA: 0xF8E5A4
	private object RenderMesh(object cam) { }

	// RVA: 0xF8E704
	public object GetLenght(object input) { }

	// RVA: 0xF8E204
	public object GetValidLength(object input) { }

	// RVA: 0xF8DBC0
	public static object SqrDistance(object a, object b) { }

	// RVA: 0xF8DBE4
	public static object Sqr(object a) { }

	// RVA: 0xF8E860
	private object GetRenderablePoints(object start, object end, object fSmoothness) { }

	// RVA: 0xF8F4F0
	private object InitializeCurveFrame(object point, object nextPoint) { }

	// RVA: 0xF8F790
	private object UpdateTrailMesh(object cam) { }

	// RVA: 0xF907F8
	private object Max(object a, object b) { }

	// RVA: 0xF8E378
	private object Min(object a, object b) { }

	// RVA: 0xF8FD08
	private object UpdateSegmentMesh(object start, object end, object localCamPosition) { }

	// RVA: 0xF90804
	private object AppendSection(object data, object frame, object i, object count, object sectionThickness, object vCoord) { }

	// RVA: 0xF9086C
	private object AppendFlatTrail(object data, object frame, object i, object count, object sectionThickness, object vCoord, object va, object vb) { }

	// RVA: 0xF91ACC
	public object .ctor() { }

	// RVA: 0xF92070
	private object <AttachToCameraRendering>b__110_0(object cntxt, object cam) { }

}

// Namespace: 
private sealed class <GetEnumerator>d__2
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	public object <>4__this; // 0x0
	private object <i>5__2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<T>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<T>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Ara
public class ElasticArray<T0>
{

	// Fields
	private object data; // 0x0
	private object count; // 0x0

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }
	public object Item { get; set; }
	public object Data { get; }

	// Methods

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	public object IndexOf(object item) { }

	// RVA: -1
	public object Insert(object index, object item) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object get_Data() { }

	// RVA: -1
	public object SetCount(object count) { }

	// RVA: -1
	public object EnsureCapacity(object capacity) { }

	// RVA: -1
	public object Reverse() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: Ara
public class TrailSection
{

	// Fields
	public object vertices; // 0x10
	public object snapX; // 0x18
	public object snapY; // 0x1C

	// Properties
	public object Segments { get; }

	// Methods

	// RVA: 0xF92560
	public object get_Segments() { }

	// RVA: 0xF925B8
	public object OnEnable() { }

	// RVA: 0xF92644
	public object CirclePreset(object segments) { }

	// RVA: 0xF92870
	public static object SnapTo(object val, object snapInterval, object threshold) { }

	// RVA: 0xF92968
	public object .ctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=1974
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=2908
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 30F2A9155FEC7F28B9DB4418A727FA154F6467D08899005C3AC5297FF43CEB16; // 0x0
	internal static readonly object E52E8BBD8F0EE183C0F844892E3DA7AD7B4BC6CCB621E948523970E9F213ED8A; // 0x7B6
}

