// Namespace: 
internal class <Module>
{
}

// Namespace: Assets.Scripts.UI
public class GraphicWrapperBase
{

	// Methods

	// RVA: 0xD041C4
	public object IsRaycastLocationValid(object sp, object eventCamera) { }

	// RVA: 0xD04248
	public override object Rebuild(object Rebuild) { }

	// RVA: 0xD042AC
	public object .ctor() { }

	// RVA: 0xD04334
	public object <>iFixBaseProxy_Rebuild(object P0) { }

}

// Namespace: Assets.Scripts.UI
public interface IManagerAdapter
{

	// Methods

	// RVA: -1
	public abstract object Update() { }

	// RVA: -1
	public abstract object LateUpdate() { }

	// RVA: -1
	public abstract object DestroyUIForm(object uiForm) { }

	// RVA: -1
	public abstract object OpenFormAdapter(object formPath, object uiForm, object recycleToPool, object useCameraRenderMode, object needCache) { }

	// RVA: -1
	public abstract object ClearFormPoolAdapter() { }

}

// Namespace: Assets.Scripts.UI
public abstract class UIComponent
{

	// Fields
	public object m_indexInlist; // 0x18
	public object m_widgets; // 0x20
	protected object uiForm; // 0x28
	protected object uiList; // 0x30
	protected object m_isInitialized; // 0x38
	protected static object s_selfWidgetEnum; // 0x0
	private object m_isPosInitilized; // 0x39

	// Properties
	public object m_isFormFadeIn { get; }

	// Methods

	// RVA: 0xD0433C
	public object get_m_isFormFadeIn() { }

	// RVA: 0xD04420
	public object GetUIForm() { }

	// RVA: 0xD04480
	protected virtual object OnViewInited() { }

	// RVA: 0xD044DC
	public virtual object Close() { }

	// RVA: 0xD04538
	public virtual object OnFormDestroyed() { }

	// RVA: 0xD04594
	public virtual object Hide() { }

	// RVA: 0xD045F0
	public virtual object Appear() { }

	// RVA: 0xD0464C
	public virtual object SetSortingOrder(object sortingOrder) { }

	// RVA: 0xD046B0
	public virtual object OnCanvasSizeChanged() { }

	// RVA: 0xD0470C
	public virtual object OnStartFadeIn() { }

	// RVA: 0xD04768
	public virtual object OnEndFadeIn() { }

	// RVA: 0xD047C4
	public virtual object OnStartFadeOut() { }

	// RVA: 0xD04820
	protected virtual object OnDestroy() { }

	// RVA: 0xD048A0
	public object InstantiateUI(object obj, object parent) { }

	// RVA: 0xD04C14
	public virtual object Initialize(object formScript) { }

	// RVA: 0xD04CB8
	protected virtual object InitializeUIForm(object formScript) { }

	// RVA: 0xD04E14
	public virtual object UnInitialize() { }

	// RVA: 0xD04E98
	protected virtual object UnInitializeUIForm() { }

	// RVA: 0xD04FA0
	public object PostInitialize() { }

	// RVA: 0xD05038
	public virtual object SetBelongedList(object belongedListScript, object index) { }

	// RVA: 0xD04998
	protected object InitializeComponent(object root) { }

	// RVA: -1
	protected object AddComponent(object t) { }

	// RVA: 0xD050B8
	public static object DuplicateGO(object srcGameObject) { }

	// RVA: 0xD05250
	public object GetWidget(object index) { }

	// RVA: -1
	public object GetWidget(object widgetEnum) { }

	// RVA: -1
	public object GetWidgetComponent(object index) { }

	// RVA: -1
	protected object GetComponentInChildren(object go) { }

	// RVA: 0xD052F0
	public virtual object InitForm(object form) { }

	// RVA: 0xD05438
	public virtual object UnInitForm() { }

	// RVA: 0xD0552C
	protected object .ctor() { }

	// RVA: 0xD05590
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.UI
public enum enUIListType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Vertical;
	public const object Horizontal;
	public const object VerticalGrid;
	public const object HorizontalGrid;
}

// Namespace: 
private sealed class OnUIListDelegate
{

	// Methods

	// RVA: 0xD16A0C
	public object .ctor(object object, object method) { }

	// RVA: 0xD16B28
	public virtual object Invoke(object list) { }

}

// Namespace: 
private sealed class OnUIListElementCreatedDelegate
{

	// Methods

	// RVA: 0xD16E14
	public object .ctor(object object, object method) { }

	// RVA: 0xD16F30
	public virtual object Invoke(object element) { }

}

// Namespace: 
private sealed class <DelayUpdateElements>d__111
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <i>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xD059A4
	public object .ctor(object <>1__state) { }

	// RVA: 0xD16F44
	private object System.IDisposable.Dispose() { }

	// RVA: 0xD16F48
	private object MoveNext() { }

	// RVA: 0xD17140
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xD17148
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xD17188
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <InsAsyncCoroutine>d__196
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <offset>5__2; // 0x20
	private object <i>5__3; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xD0FE7C
	public object .ctor(object <>1__state) { }

	// RVA: 0xD17190
	private object System.IDisposable.Dispose() { }

	// RVA: 0xD17194
	private object MoveNext() { }

	// RVA: 0xD17690
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xD17698
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xD176D8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <UpdateOnEndOfFrame>d__130
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xD08234
	public object .ctor(object <>1__state) { }

	// RVA: 0xD176E0
	private object System.IDisposable.Dispose() { }

	// RVA: 0xD176E4
	private object MoveNext() { }

	// RVA: 0xD17854
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xD1785C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xD1789C
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.UI
public abstract class UIList
{

	// Fields
	private object OnUIListCreated; // 0x40
	private object OnUIListSelectedChanged; // 0x48
	private object OnUIListElementCreatedEvent; // 0x50
	private object OnUIListElementStatusCreatedEvent; // 0x58
	private object OnUIListElementDataUpdateEvent; // 0x60
	public object DontBlockScroll; // 0x68
	public object m_useScrollOptimized; // 0x69
	public object m_scrollAreaSize; // 0x6C
	public object m_listType; // 0x74
	public object bCanScroll; // 0x78
	public object SetupScrollBar; // 0x79
	public object CreateElementInterval; // 0x7C
	public object m_useExternalElement; // 0x80
	public object m_externalElementPrefabPath; // 0x88
	public object BeUpdateOnEndOfFrame; // 0x90
	public object m_elementAmount; // 0x94
	public object m_TopLoadingTips; // 0x98
	public object m_BottomLoadingTips; // 0xA0
	public object m_elementsSize; // 0xA8
	public object m_childLayoutInfo; // 0xB0
	public object IsAutoSetElementWidthToEdge; // 0xB8
	public object m_autoAdjustScrollAreaSize; // 0xB9
	public object m_scrollRectAreaMaxSize; // 0xBC
	public object SqrDistThresholdOnStopScroll; // 0xC4
	public object m_autoAdjustElementWidth; // 0xC8
	public object AutoAdjustSpaceHeight; // 0xC9
	public object m_elementSpacing; // 0xCC
	public object m_batchCount; // 0xD4
	public object m_extraContent; // 0xD8
	public object m_elementLayoutOffset; // 0xE0
	public object m_autoCenteredElements; // 0xE4
	public object m_ScrollTogetherList; // 0xE8
	public object m_isLimitEdge; // 0xF0
	public object m_scrollExternal; // 0xF1
	public object m_isDisableScrollRect; // 0xF2
	public static object bEnableBatchSplit; // 0x0
	public object m_StartCheckIndex; // 0xF4
	public object CheckLayoutInterval; // 0xF8
	public object m_useOptimized; // 0xFC
	public object ScrollAreaPadding; // 0x100
	public object m_ZeroTipsObj; // 0x110
	public object ElementNoToPool; // 0x118
	public object m_alwaysDispatchSelectedChangeEvent; // 0x119
	protected object m_parentScrollRect; // 0x120
	protected object m_elementsRect; // 0x128
	protected object m_poolParent; // 0x130
	protected object m_selectedElementIndex; // 0x138
	protected object m_elementDefaultSize; // 0x13C
	protected object m_lastSelectedElementIndex; // 0x144
	protected object m_contentRectTransform; // 0x148
	protected object m_elementScripts; // 0x150
	protected object m_unUsedElementScripts; // 0x158
	protected object m_lastCreatedDynamicSizedElementToLayout; // 0x160
	protected object m_contentFixScrollTargetPosition; // 0x168
	protected object m_stepListCenter; // 0x16C
	private object NeedCheckCrazyClick; // 0x170
	private object m_bHaveClick; // 0x171
	private object m_fClickStamp; // 0x174
	private object m_fClickCD; // 0x178
	public object m_fixScrollTime; // 0x17C
	public object m_scrollRect; // 0x180
	protected object m_scrollRectRectTrans; // 0x188
	protected object mNeedSetParent; // 0x190
	protected object m_scrollRectContent; // 0x198
	protected object m_parentScrollRectContent; // 0x1A0
	protected object m_scrollBar; // 0x1A8
	protected object m_parentCUIList; // 0x1B0
	protected object m_elementTemplate; // 0x1B8
	protected object m_elementName; // 0x1C0
	protected object m_parentElementIndex; // 0x1C8
	protected object m_elementTemplateHasDynamicSize; // 0x1CC
	protected object m_lastContentPosition; // 0x1D0
	protected object m_lastInfluencedDynamicSizedElementToLayoutList; // 0x1D8
	protected object m_lastInfluencedDynamicSizedElementToLayoutFrameList; // 0x1E0
	protected object m_lastInfluencedDynamicSizedElementCheckTimes; // 0x1E8
	protected object m_contentSize; // 0x1EC
	protected object m_lastCreatedDynamicSizedElementToLayoutFrame; // 0x1F4
	protected object m_scrollValue; // 0x1F8
	protected object m_fixingScroll; // 0x200
	protected object m_fixScrollSpeed; // 0x204
	protected object m_scrollRectIsDragged; // 0x208
	private object FixAutoCenter; // 0x209
	private object autoCenteredContentAnchorPos; // 0x20C
	private object poolRoot; // 0x218
	protected object _clipElementEfx; // 0x220
	public object m_currentDraggedElementIndex; // 0x224
	private object IsScrollToSideEventSended; // 0x228
	public object UseSideEvent; // 0x229
	public object OnDragToLeftSide; // 0x230
	public object OnDragToRightSide; // 0x238
	protected object m_isLowDevice; // 0x240
	public object m_isUseInscAsync; // 0x241
	public object m_isUseLowDeviceInsAsync; // 0x242
	public object m_insAsyncCount; // 0x244
	private object m_insAsyncCoroutine; // 0x248
	public object m_isUseFromObjectPool; // 0x250
	private object m_delayUpdateElementCoroutine; // 0x258
	private object m_delayUpdateQueue; // 0x260
	public object m_delayUpdateElement; // 0x268
	public object m_delayUpdateOnlyOnLowDevice; // 0x269
	public object m_updateElementNumPerFrame; // 0x26C
	private object LastOffset; // 0x270

	// Properties
	private object HaveClick { get; set; }
	public object DelayUpdateElementCoroutine { get; }
	public object IsClipElementEfx { get; }

	// Methods

	// RVA: 0xD055E0
	public object IsUseInsAsync() { }

	// RVA: 0xD05680
	private object get_HaveClick() { }

	// RVA: 0xD056E0
	private object set_HaveClick(object value) { }

	// RVA: 0xD05758
	public object get_DelayUpdateElementCoroutine() { }

	// RVA: 0xD057B8
	public virtual object IsEnableDelayUpdateElement() { }

	// RVA: 0xD05814
	public object PushDelayUpdateElement(object elementScript) { }

	// RVA: 0xD05900
	private object DelayUpdateElements() { }

	// RVA: 0xD059D0
	private object OnDisable() { }

	// RVA: 0xD05A88
	private object checkCrazyClick() { }

	// RVA: 0xD05BDC
	protected virtual object ButtonClickFastTips() { }

	// RVA: 0xD05C38
	public object SetCrayzClickInfo(object checkCrazyClick, object cdTime) { }

	// RVA: 0xD05CB8
	public object get_IsClipElementEfx() { }

	// RVA: 0xD05D18
	private object GetEnabledScrollRect(object obj) { }

	// RVA: 0xD05E4C
	public override object Initialize(object formScript) { }

	// RVA: 0xD077CC
	public override object InitForm(object form) { }

	// RVA: 0xD07954
	protected virtual object SetOnUIListSelectedChangedCallbackNull() { }

	// RVA: 0xD079B4
	protected virtual object SetPool() { }

	// RVA: 0xD07BA4
	protected virtual object DebugHelperAssert(object InCondition, object InFormat) { }

	// RVA: 0xD07C1C
	protected virtual object SetExternalElementEvent(object listElementScript) { }

	// RVA: 0xD07C80
	protected override object OnDestroy() { }

	// RVA: 0xD07D78
	protected virtual object LeanTweenCancel() { }

	// RVA: 0xD07DD4
	public override object OnFormDestroyed() { }

	// RVA: 0xD07FD8
	public override object Appear() { }

	// RVA: 0xD080BC
	public override object Hide() { }

	// RVA: 0xD08190
	protected object UpdateOnEndOfFrame() { }

	// RVA: 0xD08260
	private object UpdateImpl() { }

	// RVA: 0xD08D00
	protected virtual object IntMathExfAbs(object f) { }

	// RVA: 0xD08DC0
	protected virtual object SetSqrDistThresholdOnStopScrollCommandFun() { }

	// RVA: 0xD08E1C
	protected virtual object Update() { }

	// RVA: 0xD08FA4
	protected object ScrollOnly() { }

	// RVA: 0xD088C8
	protected object DetectScroll() { }

	// RVA: 0xD09E04
	protected virtual object ActivityOnChangeScrollBG() { }

	// RVA: 0xD09A30
	private object HandleLoadingTips(object anchoredPosition, object contentSize) { }

	// RVA: 0xD09700
	protected object HandlerHorizontalDragToEnd() { }

	// RVA: 0xD09E60
	protected virtual object ListScrollTopPullDownEvent() { }

	// RVA: 0xD09EBC
	protected virtual object ListScrollBottomPullUpEvent() { }

	// RVA: 0xD09528
	protected object OnScrollValueChanged(object value) { }

	// RVA: 0xD0773C
	public object SetElementAmount(object amount) { }

	// RVA: 0xD075A4
	public object IsNestedNoScrollCUIlist() { }

	// RVA: 0xD09F18
	private object EnlargeChildLayoutCacheInfo(object elementIndex, object childAmount) { }

	// RVA: 0xD0A190
	private object EnlargeLayoutCacheInfo(object amount) { }

	// RVA: 0xD0A530
	private object ClearSelfLayoutInfo() { }

	// RVA: 0xD0A5C4
	private object ClearSelfDisplayInfo() { }

	// RVA: 0xD0A654
	private object ClearSelfChildrenLayoutInfo() { }

	// RVA: 0xD0A700
	private object ClearChildListLayoutInfo() { }

	// RVA: 0xD0A874
	public object ClearLayoutInfo() { }

	// RVA: 0xD0AA48
	private object SetLastInfluencedDynamicSizedElementToLayout(object elementIndex) { }

	// RVA: 0xD0AE34
	private object DealLayoutInfo(object amount, object elementsSize) { }

	// RVA: 0xD0B20C
	public object ExpandAllElement(object amount) { }

	// RVA: 0xD0B320
	public object CollapseElementToAmount(object amount) { }

	// RVA: 0xD0B450
	public virtual object SetElementAmount(object amount, object elementsSize) { }

	// RVA: 0xD0C0E4
	protected virtual object ParticleClip() { }

	// RVA: 0xD0C140
	protected virtual object OnUIListCreatedCallbackFun() { }

	// RVA: 0xD0C1C0
	public virtual object SelectElement(object index, object isDispatchSelectedChangeEvent, object isFromClickEvent) { }

	// RVA: 0xD0C2B4
	private object BaseSelectElement(object index, object isDispatchSelectedChangeEvent) { }

	// RVA: 0xD0C5D0
	public object SelectElementAndScrollToElement(object index, object isDispatchSelectedChangeEvent) { }

	// RVA: 0xD0CB30
	protected virtual object GetRenderFPS() { }

	// RVA: 0xD0CB90
	public object GetElementAmount() { }

	// RVA: 0xD0CBF0
	public object GetElementGo(object index) { }

	// RVA: 0xD0AC84
	public object GetElemenet(object index, object isUIListElement) { }

	// RVA: 0xD0CD00
	public object GetCurShowElementIndex(object startIndex, object endIndex) { }

	// RVA: 0xD0CEB8
	public object GetElementPositionY(object index) { }

	// RVA: 0xD0CFBC
	public object GetSelectedElement(object isUIListElement) { }

	// RVA: 0xD0D02C
	public object GetLastSelectedElement(object isUIListElement) { }

	// RVA: 0xD0D09C
	public object GetSelectedIndex() { }

	// RVA: 0xD0D0FC
	public object GetLastSelectedIndex() { }

	// RVA: 0xD0D15C
	public object IsElementInScrollAreaBottom(object index) { }

	// RVA: 0xD0D594
	public object IsElementInScrollArea(object index) { }

	// RVA: 0xD0D9C0
	public object IsElementInScrollArea(object elem) { }

	// RVA: 0xD0DBA4
	public object GetScrollValue() { }

	// RVA: 0xD0B8A0
	public object ResetContentPosition() { }

	// RVA: 0xD0DC0C
	public object CorrectionContentPosition(object h) { }

	// RVA: 0xD087B4
	public object MoveElementInScrollArea(object index, object moveImmediately) { }

	// RVA: 0xD0E8C0
	public object MoveElementToCenter(object index, object moveImmediately) { }

	// RVA: 0xD0E9D4
	public object MoveElementToTop(object index, object moveImmediately) { }

	// RVA: 0xD0DCC8
	private object MoveElement(object index, object moveImmediately, object locate) { }

	// RVA: 0xD0EAC0
	protected virtual object LeanTweenContentRect(object contentTargetAnchoredPosition) { }

	// RVA: 0xD0EB58
	public virtual object IsSelectedIndex(object index) { }

	// RVA: 0xD0EBC8
	public object ShowExtraContent() { }

	// RVA: 0xD0ECD4
	public object HideExtraContent() { }

	// RVA: 0xD0EDE0
	public object MoveContent(object offset) { }

	// RVA: 0xD0EFB4
	public object GetEelementDefaultSize() { }

	// RVA: 0xD0F01C
	public object SetEelementDefaultSize(object vec) { }

	// RVA: 0xD0F09C
	public object GetContentSize() { }

	// RVA: 0xD0F104
	public object GetScrollAreaSize() { }

	// RVA: 0xD0F168
	public object GetContentPosition() { }

	// RVA: 0xD0F1D0
	public object IsNeedScroll() { }

	// RVA: 0xD0F25C
	private object ProcessContent() { }

	// RVA: 0xD0F3F8
	protected virtual object ProcessElements() { }

	// RVA: 0xD0FDD8
	private object InsAsyncCoroutine() { }

	// RVA: 0xD0FEA8
	public virtual object RelayoutElements() { }

	// RVA: 0xD0FC2C
	private object ProcessExtraContent(object contentSize, object offset) { }

	// RVA: 0xD10748
	public object SetDynimicSizedElementToLayout(object e) { }

	// RVA: 0xD107C8
	private object SetChildLayoutInfo(object elementIndex, object childElementIndex, object rect, object childAmount) { }

	// RVA: 0xD10DEC
	private object GetChildLayoutInfo(object parentElementIndex, object childElementIndex, object rect, object childAmount) { }

	// RVA: 0xD10FA0
	private object CheckLayoutElement() { }

	// RVA: 0xD11394
	private object CheckLayoutCacheSize() { }

	// RVA: 0xD1167C
	private object HandleLastCreatedDynamicSizedElementToLayout(object frameCount) { }

	// RVA: 0xD11C2C
	private object HandleLastInfluencedDynamicSizedElementToLayout(object frameCount) { }

	// RVA: 0xD0DF30
	protected object UpdateElementsCrollWithRecyle() { }

	// RVA: 0xD12B40
	private object UpdateElementsScrollNormal() { }

	// RVA: 0xD086E8
	protected object UpdateElementsScroll() { }

	// RVA: 0xD0F874
	protected object LayoutElement(object index, object contentSize, object offset) { }

	// RVA: 0xD13810
	protected virtual object ResizeContent(object size, object resetPosition) { }

	// RVA: 0xD0C964
	protected object GetContentTargetPosition(object selectedIndex) { }

	// RVA: 0xD13E98
	private object GetScrollPosition(object rect, object index, object position) { }

	// RVA: 0xD0D73C
	protected object IsRectInScrollArea(object rect, object index) { }

	// RVA: 0xD0D304
	protected object IsRectInScrollAreaBottom(object rect, object index) { }

	// RVA: 0xD126D0
	public object GetStartIndexInScrollArea(object startIndex, object endIndex) { }

	// RVA: 0xD0BBC0
	protected object RecycleElement() { }

	// RVA: 0xD123FC
	protected object RecycleElement(object elementScript) { }

	// RVA: 0xD141DC
	protected virtual object CreateElement(object index, object rect) { }

	// RVA: 0xD14DD0
	protected virtual object ParticleUIHide(object elementScript) { }

	// RVA: 0xD14E34
	protected virtual object OnUIListElementCreatedFun(object elementScript) { }

	// RVA: 0xD14EBC
	protected virtual object ProcessElementStatus(object elementScript) { }

	// RVA: 0xD14F44
	public object ProcessElementStatusImmediately() { }

	// RVA: 0xD15060
	protected virtual object ProcessElementDataUpdate(object elementScript) { }

	// RVA: 0xD150E8
	public object ProcessElementDataImmediately() { }

	// RVA: 0xD10428
	protected object ProcessElementWidth() { }

	// RVA: 0xD0BEA4
	protected object ProcessUnUsedElement() { }

	// RVA: 0xD15204
	public object GetTemplate(object isUIListElement) { }

	// RVA: 0xD15358
	public virtual object ResetScrollAreaSize() { }

	// RVA: 0xD156E0
	protected virtual object InstantiateOptimize(object srcGameObject, object parent) { }

	// RVA: 0xD15848
	protected virtual object DispatchScrollChangedEvent() { }

	// RVA: 0xD158A4
	protected virtual object DispatchElementSelectChangedEvent() { }

	// RVA: 0xD15900
	public object PrepareElements(object amount) { }

	// RVA: 0xD14BB0
	private object InitializeComponentUIForm(object root) { }

	// RVA: 0xD15FBC
	protected object .ctor() { }

	// RVA: 0xD161AC
	private static object .cctor() { }

	// RVA: 0xD161FC
	private object <MoveElementInScrollArea>b__179_0(object rect) { }

	// RVA: 0xD16350
	private object <MoveElementToCenter>b__180_0(object rect) { }

	// RVA: 0xD16408
	private object <MoveElementToTop>b__181_0(object rect) { }

	// RVA: 0xD164F8
	public object <>iFixBaseProxy_Initialize(object P0) { }

	// RVA: 0xD1659C
	public object <>iFixBaseProxy_InitForm(object P0) { }

	// RVA: 0xD165A0
	public object <>iFixBaseProxy_OnDestroy() { }

	// RVA: 0xD16620
	public object <>iFixBaseProxy_OnFormDestroyed() { }

	// RVA: 0xD1667C
	public object <>iFixBaseProxy_Appear() { }

	// RVA: 0xD166D8
	public object <>iFixBaseProxy_Hide() { }

}

// Namespace: Assets.Scripts.UI
public struct stRect
{

	// Fields
	public object m_width; // 0xFFFFFFFFFFFFFFF8
	public object m_height; // 0xFFFFFFFFFFFFFFFC
	public object m_top; // 0x0
	public object m_bottom; // 0x4
	public object m_left; // 0x8
	public object m_right; // 0xC
	public object m_center; // 0x10
	public static object sharedRect; // 0x0
}

// Namespace: 
public sealed class OnSelectedDelegate
{

	// Methods

	// RVA: 0xD1A014
	public object .ctor(object object, object method) { }

	// RVA: 0xD1A0A8
	public virtual object Invoke() { }

}

// Namespace: Assets.Scripts.UI
public abstract class UIListElement
{

	// Fields
	public static object s_Common_List_DefautFontColor; // 0x0
	public static object s_Common_List_SelectFontColor; // 0x10
	public static object s_Common_Title_OutLineColor; // 0x20
	public static object s_Common_Title_EffectDistance; // 0x30
	public static readonly object OutOfViewAnchoredPosition; // 0x38
	public object m_defaultSprite; // 0x40
	public object m_defaultAlphaSprite; // 0x48
	public object m_defaultColor; // 0x50
	public object m_autoAddUIEventScript; // 0x60
	public object m_useSetActiveForDisplay; // 0x61
	public object m_defaultSize; // 0x64
	public object m_IsSetDefaultRotation; // 0x6C
	public object ClickByOtherObject; // 0x6D
	public object singleClickObject; // 0x70
	public object m_textObj; // 0x78
	public object m_defaultTextColor; // 0x80
	public object OnListItemEnable; // 0x90
	public object OnListItemDisable; // 0x98
	public object m_textOtherObj; // 0xA0
	public object onSelected; // 0xA8
	public object m_seletedBackObj; // 0xB0
	public object m_selectFrontObj; // 0xB8
	public object m_selectedSprite; // 0xC0
	public object m_selectedAlphaSprite; // 0xC8
	public object m_unselectedObj; // 0xD0
	public object selectedObj; // 0xD8
	public object unselectedObj; // 0xE0
	public object m_needChangeScaleObj; // 0xE8
	public object m_needChangeScaleObjs; // 0xF0
	public object m_index; // 0xF8
	public object m_rect; // 0xFC
	public object m_IsSetTextObjOutline; // 0x11C
	public object DisableOnRecyle; // 0x11D
	public object OutOfViewRecyle; // 0x11E
	private object <Enabled>k__BackingField; // 0x11F
	public object isOutOfView; // 0x120
	public object m_selectTextColor; // 0x124
	public object m_useCustomSelectTextColor; // 0x134
	protected object m_image; // 0x138
	protected object m_canvasGroup; // 0x140
	private object flag; // 0x148

	// Properties
	public object Enabled { get; set; }

	// Methods

	// RVA: 0xD178A4
	public object get_Enabled() { }

	// RVA: 0xD178AC
	public object set_Enabled(object value) { }

	// RVA: 0xD178B4
	public override object Initialize(object formScript) { }

	// RVA: 0xD17EC0
	protected virtual object SetImageEx() { }

	// RVA: 0xD17F1C
	protected virtual object AddUIEventScript() { }

	// RVA: 0xD17F78
	protected virtual object GetDefaultSize() { }

	// RVA: 0xD1826C
	public virtual object Enable(object belongedList, object index, object name, object rect, object selected) { }

	// RVA: 0xD133F0
	public object EnableShow() { }

	// RVA: 0xD187BC
	protected virtual object SetParticleActiveTrue() { }

	// RVA: 0xD18818
	public virtual object Disable(object hide) { }

	// RVA: 0xD18980
	protected virtual object SetParticleActiveFalse() { }

	// RVA: 0xD1363C
	public object DisableOutOfView() { }

	// RVA: 0xD189DC
	public object OnSelected(object baseEventData) { }

	// RVA: 0xD18A88
	public virtual object ChangeDisplay(object selected) { }

	// RVA: 0xD19174
	protected virtual object ImageSetSprite(object image, object sprite, object alphaSprite) { }

	// RVA: 0xD19210
	protected virtual object SetSelectedTextStyle(object txt, object bSelected) { }

	// RVA: 0xD185E0
	public object SetComponentBelongedList(object gameObject) { }

	// RVA: 0xD13544
	public object ReLocation() { }

	// RVA: 0xD106D0
	public object SetRect(object rect) { }

	// RVA: 0xD17D38
	private object InitRectTransform() { }

	// RVA: 0xD102BC
	public object SetRectWidth(object width) { }

	// RVA: 0xD19580
	public virtual object DispatchOnEnableEvent() { }

	// RVA: 0xD195DC
	public virtual object DispatchOnDisableEvent() { }

	// RVA: 0xD19638
	public object SetFlag(object flg) { }

	// RVA: 0xD196A0
	public object GetFlag() { }

	// RVA: 0xD19700
	public virtual object GetItemText() { }

	// RVA: 0xD198C4
	public override object OnFormDestroyed() { }

	// RVA: 0xD19964
	protected override object OnDestroy() { }

	// RVA: 0xD19A58
	protected virtual object LeanTweenCancel() { }

	// RVA: 0xD19AB4
	public virtual object SetItemText(object key) { }

	// RVA: 0xD19C7C
	protected object .ctor() { }

	// RVA: 0xD19D70
	private static object .cctor() { }

	// RVA: 0xD19E3C
	public object <>iFixBaseProxy_Initialize(object P0) { }

	// RVA: 0xD19EE0
	public object <>iFixBaseProxy_OnFormDestroyed() { }

	// RVA: 0xD19F3C
	public object <>iFixBaseProxy_OnDestroy() { }

}

// Namespace: Assets.Scripts.UI
public interface IFormParam
{
}

// Namespace: Assets.Scripts.UI
public abstract class UIForm
{

	// Fields
	public object m_isSingleton; // 0x18
	public object m_priority; // 0x1C
	protected object m_defaultPriority; // 0x20
	protected object m_defaultSubPriority; // 0x24
	public object m_subPriority; // 0x28
	public object OptimizeSetCanvasOrder; // 0x2C
	public object m_disableInput; // 0x2D
	public object m_referenceResolution; // 0x30
	public object m_isModal; // 0x38
	public object m_hideUnderForms; // 0x39
	public object m_fullScreenBG; // 0x3A
	public object m_openedWwiseEvents; // 0x40
	public object m_closedWwiseEvents; // 0x48
	public object allNeedDisableAnimators; // 0x50
	public object m_formPath; // 0x58
	public object m_canvasPixelPerfect; // 0x60
	public object m_formWidgets; // 0x68
	public object m_useFormPool; // 0x70
	public object m_group; // 0x74
	protected object m_relatedScenes; // 0x78
	protected object m_relatedSceneCamera; // 0x80
	protected object m_canvas; // 0x88
	protected object m_canvasScaler; // 0x90
	protected object m_graphicRaycaster; // 0x98
	protected object m_sortingOrder; // 0xA0
	protected object m_openOrder; // 0xA4
	protected object m_bIsFixed; // 0xA8
	protected object m_iFixedBaseLevel; // 0xAC
	protected object component_cache; // 0xB0
	protected object m_uiComponents; // 0xB8
	protected object m_isInitialized; // 0xC0
	protected object m_isNeedClose; // 0xC1
	protected object m_isClosed; // 0xC2
	protected object m_isInFadeIn; // 0xC3
	protected object m_isInFadeOut; // 0xC4
	protected object m_isOpening; // 0xC5
	protected object m_OpenStartTime; // 0xC8
	protected object m_OpenCostTime; // 0xD0
	protected object m_sequence; // 0xD8
	protected object m_renderFrameStamp; // 0xDC
	protected object m_isHided; // 0xE0
	protected object m_hideFlags; // 0xE4
	public object m_alwaysKeepVisible; // 0xE8
	protected object m_uiUpdateComponents; // 0xF0
	protected object m_uiLateUpdateComponents; // 0xF8
	public object m_formFadeInAnimationType; // 0x100
	public object m_formFadeInAnimationName; // 0x108
	protected object m_formFadeInAnimationScript; // 0x110
	private static object _cacheComponentList; // 0x0
	private object m_oldSysPriority; // 0x118
	public static object ms_EnableFormActionLog; // 0x8

	// Properties
	public object Priority { get; }
	public object OldSysPriority { get; }

	// Methods

	// RVA: 0xD1A0BC
	public object CompareTo(object obj) { }

	// RVA: 0xD1A684
	public object get_Priority() { }

	// RVA: 0xD1A808
	public object get_OldSysPriority() { }

	// RVA: 0xD1A4F0
	public static object op_GreaterThan(object left, object right) { }

	// RVA: 0xD1AC44
	public static object op_LessThan(object left, object right) { }

	// RVA: 0xD1ADE0
	private object Awake() { }

	// RVA: 0xD1B3C8
	protected virtual object NewEventCompoent() { }

	// RVA: 0xD1B504
	public object Initialize() { }

	// RVA: 0xD1B688
	public object InitializeComponent(object root) { }

	// RVA: 0xD1BCEC
	protected virtual object SProfilerBeginSampleShallow(object strt) { }

	// RVA: 0xD1BDC8
	protected virtual object SProfilerEndSampleShallow(object strt) { }

	// RVA: 0xD1BEA4
	protected virtual object ProfilerUtilityBeginUISample(object strt) { }

	// RVA: 0xD1BF80
	protected virtual object ProfilerUtilityEndUISample(object strt) { }

	// RVA: 0xD1C05C
	public object GetCamera() { }

	// RVA: 0xD1C2C0
	public object AddUIComponent(object uiComponent) { }

	// RVA: 0xD1C760
	public object RemoveUIComponent(object uiComponent) { }

	// RVA: 0xD1C9F4
	protected virtual object PathfindingUtilListPoolClaim() { }

	// RVA: 0xD1CC00
	protected virtual object PathfindingUtilListPoolRelease(object uiComponents) { }

	// RVA: 0xD1B0C0
	public object InitializeCanvas() { }

	// RVA: 0xD1CFB4
	protected virtual object SetSGameGraphicRaycaster() { }

	// RVA: 0xD1D0F0
	public object DestroyUIComponent(object uiComponent) { }

	// RVA: 0xD1CD3C
	public object MatchScreen() { }

	// RVA: 0xD1D208
	public object GetSortingOrder() { }

	// RVA: 0xD1D38C
	public object SetDisplayOrder(object openOrder) { }

	// RVA: 0xD1AA6C
	private object IsOverlay() { }

	// RVA: 0xD1D77C
	private object SetComponentSortingOrder(object sortingOrder) { }

	// RVA: 0xD1DA88
	protected object FetchComps() { }

	// RVA: 0xD1DF90
	public object Open(object formPath, object camera, object sequence, object openOrder, object exist, object param, object isPandora, object pandoraObj, object priority) { }

	// RVA: 0xD1EB7C
	public object SetPandoraForm() { }

	// RVA: 0xD1ECB8
	public object OpenSort(object sequence, object openOrder, object exist) { }

	// RVA: 0xD1E514
	public object Open(object sequence, object openOrder, object exist, object param) { }

	// RVA: 0xD1F18C
	protected virtual object CostReport(object cost) { }

	// RVA: 0xD1F32C
	protected virtual object SetFormparam(object param) { }

	// RVA: 0xD1F408
	public virtual object GameBuilderHelperMarkFormOpened() { }

	// RVA: 0xD1F544
	protected virtual object DispatchFormPreOpenUIEvent() { }

	// RVA: 0xD1F680
	protected virtual object DispatchFormOpenedUIEvent() { }

	// RVA: 0xD1F7BC
	protected virtual object PostUIEvent(object eventStr) { }

	// RVA: 0xD1F898
	protected virtual object GetFormPriority(object formPath) { }

	// RVA: 0xD1FB40
	protected virtual object LuaFixFun() { }

	// RVA: 0xD1FC7C
	protected virtual object DispatchFormEvent(object formEventType) { }

	// RVA: 0xD1F08C
	public object IsNeedFadeIn() { }

	// RVA: 0xD1FE10
	public virtual object StartFadeIn() { }

	// RVA: 0xD1E2B4
	public object SetCamera(object camera) { }

	// RVA: 0xD1FF4C
	public object RefreshCanvasScaler() { }

	// RVA: 0xD20150
	public object GetSequence() { }

	// RVA: 0xD20228
	public virtual object CustomUpdate() { }

	// RVA: 0xD20364
	public object IsNeedClose() { }

	// RVA: 0xD2043C
	public virtual object TurnToClosed(object ignoreFadeOut) { }

	// RVA: 0xD205E4
	public object IsClosed() { }

	// RVA: 0xD206BC
	public object IsInFadeIn() { }

	// RVA: 0xD20794
	public object IsInFadeOut() { }

	// RVA: 0xD2086C
	public virtual object Hide(object hideFlag, object dispatchVisibleChangedEvent) { }

	// RVA: 0xD20D7C
	protected virtual object HideOverrideTodo(object dispatchVisibleChangedEvent) { }

	// RVA: 0xD21224
	protected virtual object DispatchVisibleChangedEvent() { }

	// RVA: 0xD20F50
	protected object HideComponent() { }

	// RVA: 0xD20B28
	public object SetCanvasEnable(object enable) { }

	// RVA: 0xD21360
	public virtual object OnCanvasSizeChanged() { }

	// RVA: 0xD2149C
	public virtual object CustomLateUpdate() { }

	// RVA: 0xD215D8
	public object Close() { }

	// RVA: 0xD21A80
	private object CloseComponent() { }

	// RVA: 0xD21D54
	protected virtual object OnFormClose() { }

	// RVA: 0xD21E90
	public object IsHided() { }

	// RVA: 0xD21F68
	public object IsOpened() { }

	// RVA: 0xD22040
	public object GetGraphicRaycaster() { }

	// RVA: 0xD221F4
	public virtual object Appear(object hideFlag, object dispatchVisibleChangedEvent) { }

	// RVA: 0xD2236C
	protected virtual object AppearOverrideToDo(object dispatchVisibleChangedEvent) { }

	// RVA: 0xD224CC
	protected object AppearComponent() { }

	// RVA: 0xD227A0
	protected virtual object DispatchAppearEvent() { }

	// RVA: 0xD1EFAC
	public object SetOpenOrder(object order) { }

	// RVA: 0xD228DC
	public object GetOpenOrder() { }

	// RVA: 0xD229B4
	public object GetDisplayOrder() { }

	// RVA: 0xD22B14
	public object SetCanvasScaler(object scaler) { }

	// RVA: -1
	public object GetWidgetComponent(object index) { }

	// RVA: 0xD22D44
	public object GetWidget(object index) { }

	// RVA: 0xD22F50
	protected object .ctor() { }

	// RVA: 0xD230D4
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.UI
public enum OLDSYS_enFormHideFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object HideByCustom;
	public const object HideByOtherForm;
}

// Namespace: Assets.Scripts.UI
public enum OLDSYS_enFormPriority
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PriorityLobby_Down;
	public const object PriorityLobby_Down1;
	public const object PriorityLobby_Down2;
	public const object PriorityLobby_Down3;
	public const object PriorityLobby_Down4;
	public const object PriorityLobby_Down5;
	public const object PriorityLobby_Down6;
	public const object PriorityLobby_Down7;
	public const object PriorityLobby_Down8;
	public const object PriorityLobby_Down9;
	public const object PriorityLobby;
	public const object PriorityLobby1;
	public const object PriorityLobby2;
	public const object PriorityLobby3;
	public const object PriorityLobby4;
	public const object PriorityLobbyFace0;
	public const object PriorityLobbyFace1;
	public const object PriorityLobbyFace2;
	public const object PriorityLobbyFace3;
	public const object PriorityLobbyFace4;
	public const object PriorityLobbyForSystem0;
	public const object PriorityLobbyForSystem1;
	public const object PriorityLobbyForSystem2;
	public const object PriorityLobbyForSystem3;
	public const object PriorityLobbyForSystem4;
	public const object PriorityLobbyForSystem5;
	public const object PriorityLobbyForSystem6;
	public const object PriorityLobbyForSystem7;
	public const object PriorityLobbyForSystem8;
	public const object PriorityLobbyForSystem9;
	public const object PriorityLobbyForSystem10;
	public const object PriorityLobbyForMatchingSystem0;
	public const object PriorityLobbyForMatchingSystem1;
	public const object PriorityLobbyForMatchingSystem2;
	public const object PriorityLobbyForMatchingSystem3;
	public const object PriorityLobbyForMatchingSystem4;
	public const object PriorityLobbyForMatchingSystem5;
	public const object PriorityLobbyForMatchingSystem6;
	public const object PriorityLobbyForMatchingSystem7;
	public const object PriorityLobbyForMatchingSystem8;
	public const object PriorityLobbyForMatchingSystem9;
	public const object PriorityLowLoadingCommonMessageBoxTips0;
	public const object PriorityLowLoadingCommonMessageBoxTips1;
	public const object PriorityLowLoadingCommonMessageBoxTips2;
	public const object PriorityLowLoadingCommonMessageBoxTips3;
	public const object PriorityLowLoadingCommonMessageBoxTips4;
	public const object PriorityLobbyForLoading0;
	public const object PriorityLobbyForLoading1;
	public const object PriorityLobbyForLoading2;
	public const object PriorityLobbyForLoading3;
	public const object PriorityLobbyForLoading4;
	public const object PriorityUpLoadingCommonMessageBoxTips0;
	public const object PriorityUpLoadingCommonMessageBoxTips1;
	public const object PriorityUpLoadingCommonMessageBoxTips2;
	public const object PriorityUpLoadingCommonMessageBoxTips3;
	public const object PriorityUpLoadingCommonMessageBoxTips4;
	public const object PriorityLobbyForNewPlayerGuide0;
	public const object PriorityLobbyForNewPlayerGuide1;
	public const object PriorityLobbyForNewPlayerGuide2;
	public const object PriorityLobbyForNewPlayerGuide3;
	public const object PriorityLobbyForNewPlayerGuide4;
	public const object PriorityCount;
}

// Namespace: Assets.Scripts.UI
public enum enFormPriority
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Priority0;
	public const object Priority1;
	public const object Priority2;
	public const object Priority3;
	public const object Priority4;
	public const object Priority5;
	public const object Priority6;
	public const object Priority7;
	public const object Priority8;
	public const object Priority9;
	public const object Priority10;
}

// Namespace: Assets.Scripts.UI
public enum OLDSYS_enFormEventType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Open;
	public const object Close;
	public const object Deployed;
}

// Namespace: Assets.Scripts.UI
public enum OLDSYS_enFormFadeAnimationType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Animation;
	public const object Animator;
	public const object Timeline;
}

// Namespace: Assets.Scripts.UI
public interface IComponentUpdate
{

	// Methods

	// RVA: -1
	public abstract object CustomUpdate() { }

}

// Namespace: Assets.Scripts.UI
public interface IComponentLateUpdate
{

	// Methods

	// RVA: -1
	public abstract object CustomLateUpdate() { }

}

// Namespace: Assets.Scripts.UI
public static class FromSortingOrderUtil
{

	// Methods

	// RVA: 0xD23164
	public static object OLD_CalculateSortingOrder(object priority, object openOrder, object isOverlay) { }

	// RVA: 0xD1D5F0
	public static object CalculateSortingOrder(object openOrder) { }

}

// Namespace: Assets.Scripts.UI
public class FormPriority
{

	// Fields
	public object m_sFormName; // 0x8
	public object m_iPriority; // 0x10
	public object m_bIsFixed; // 0x14
	public object m_iFixedBaseLevel; // 0x18

	// Methods

	// RVA: 0xD1FADC
	public object .ctor() { }

}

// Namespace: 
public sealed class OnFormSorted
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object inForms) { }

}

// Namespace: Assets.Scripts.UI
public abstract class UIManagerBase<T0>
{

	// Fields
	public static object s_uiSystemRenderFrameCounter; // 0x0
	private static object s_formCameraName; // 0x0
	protected object m_uiRoot; // 0x0
	private object <poolRoot>k__BackingField; // 0x0
	protected object m_formCamera; // 0x0
	private object <LastOpenFormFrameCount>k__BackingField; // 0x0
	public object onFormSorted; // 0x0
	protected object m_uiInputEventSystem; // 0x0
	protected object m_AllFormPriorityMap; // 0x0
	protected object m_OverlayFromPriorityMap; // 0x0
	protected object m_existFormSequences; // 0x0
	protected object m_forms; // 0x0
	protected object m_pooledForms; // 0x0
	protected object m_formOpenOrder; // 0x0
	protected object m_formSequence; // 0x0
	protected object m_curWidth; // 0x0
	protected object m_curHeight; // 0x0
	protected object m_needSortForms; // 0x0
	protected object m_uguiActive; // 0x0
	protected object rootObjectName; // 0x0
	protected object m_needUpdateRaycasterAndHide; // 0x0

	// Properties
	public object uiRoot { get; }
	public object poolRoot { get; set; }
	public object FormCamera { get; }
	public abstract object MgrAdapter { get; }
	public object LastOpenFormFrameCount { get; set; }

	// Methods

	// RVA: -1
	public object get_uiRoot() { }

	// RVA: -1
	public object get_poolRoot() { }

	// RVA: -1
	private object set_poolRoot(object value) { }

	// RVA: -1
	public object get_FormCamera() { }

	// RVA: -1
	public abstract object get_MgrAdapter() { }

	// RVA: -1
	public object get_LastOpenFormFrameCount() { }

	// RVA: -1
	private object set_LastOpenFormFrameCount(object value) { }

	// RVA: -1
	public override object Init() { }

	// RVA: -1
	protected virtual object CUIEventListener() { }

	// RVA: -1
	protected virtual object OtherUISysInit() { }

	// RVA: -1
	public virtual object Update() { }

	// RVA: -1
	protected virtual object GameSettingsUpdateResolution() { }

	// RVA: -1
	protected virtual object OnCanvasSizeChanged(object timerSequence) { }

	// RVA: -1
	protected virtual object CreateUIRoot() { }

	// RVA: -1
	protected object CreateEventSystem() { }

	// RVA: -1
	protected virtual object AddInputComponent(object eventSystem) { }

	// RVA: -1
	protected virtual object CreateUISecene() { }

	// RVA: -1
	protected object CreateCamera() { }

	// RVA: -1
	protected virtual object CreateUIFormInfo() { }

	// RVA: -1
	public object OpenFormOnlySort(object formPath) { }

	// RVA: -1
	public object OpenForm(object formPath, object useFormPool, object useCameraRenderMode, object needSortImmediately, object param, object bUseCachedResource, object assetBundlePath, object isPandora, object pandoraObj, object priority) { }

	// RVA: -1
	private object CreateForm(object formPrefabPath, object useFormPool, object bUseCachedResource, object assetBundlePath, object parent, object fromPool) { }

	// RVA: -1
	public object GetFormPriority(object formPath) { }

	// RVA: -1
	protected virtual object CostReport(object name, object cost) { }

	// RVA: -1
	protected virtual object PriorityConfigCheck(object formPath) { }

	// RVA: -1
	protected virtual object LoadingProfilerBeginSampleWrapper(object str) { }

	// RVA: -1
	protected virtual object LoadingProfilerEndSampleWrapper(object str) { }

	// RVA: -1
	protected virtual object DebugHelperLog(object str) { }

	// RVA: -1
	protected virtual object DebugHelperLogError(object str, object str2) { }

	// RVA: -1
	protected virtual object SProfilerBeginSampleShallow(object str) { }

	// RVA: -1
	protected virtual object SProfilerEndSampleShallow(object str) { }

	// RVA: -1
	protected virtual object SProfilerBeginSample(object str) { }

	// RVA: -1
	protected virtual object SProfilerEndSample(object str) { }

	// RVA: -1
	protected virtual object ProfilerUtilityBeginUISample(object strt) { }

	// RVA: -1
	protected virtual object ProfilerUtilityEndUISample(object strt) { }

	// RVA: -1
	protected virtual object OtherSysDoSomething(object formPath) { }

	// RVA: -1
	protected virtual object DebugHelperConsoleLogError(object str) { }

	// RVA: -1
	protected virtual object CAndriodBackBtnManagerFun(object formScript) { }

	// RVA: -1
	protected virtual object RedPointSystemFun(object formScript) { }

	// RVA: -1
	protected virtual object GameLoaderOptimizeUtilInstantiate(object formPrefabPath) { }

	// RVA: -1
	protected virtual object _OnLoadFormInit(object formPrefabPath, object formScript) { }

	// RVA: -1
	protected virtual object CommonToolsInstantiate(object obj, object parent, object worldPositionStays) { }

	// RVA: -1
	protected virtual object SetFormActive(object form) { }

	// RVA: -1
	private object GetFormName(object formPath) { }

	// RVA: -1
	private object GetUnClosedForm(object formPath) { }

	// RVA: -1
	public object CloseGroupForm(object group) { }

	// RVA: -1
	public virtual object CloseForm(object formPath) { }

	// RVA: -1
	public object CloseForm(object formScript) { }

	// RVA: -1
	public virtual object CloseForm(object formSequence) { }

	// RVA: -1
	public object RemoveFromExistFormSequenceList(object formSequence) { }

	// RVA: -1
	public object AddToExistFormSequenceList(object formSequence) { }

	// RVA: -1
	public object GetFormOpenOrder(object formSequence) { }

	// RVA: -1
	protected object ProcessFormList(object sort, object handleInputAndHide) { }

	// RVA: -1
	protected virtual object preprocessFormList() { }

	// RVA: -1
	private object UpdateFormHided() { }

	// RVA: -1
	private object UpdateFormRaycaster() { }

	// RVA: -1
	protected object RecycleForm(object formScript) { }

	// RVA: -1
	public object PrepareForm(object formPath, object useCameraRenderMode, object needSortImmediately, object param, object bUseCachedResource, object assetBundlePath, object isPandora, object pandoraObj, object priority) { }

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.UI
public class UIUtility
{

	// Fields
	public static object InstantiateNtf; // 0x0

	// Methods

	// RVA: 0xD23424
	public static object NotifyInstantiate(object name) { }

	// RVA: 0xD235C0
	public static object CopyRectTransform(object srcRectTransform, object dstRectTransform) { }

	// RVA: 0xD23824
	public static object WorldToScreenPoint(object camera, object worldPoint) { }

	// RVA: 0xD23B04
	public static object CommonToolsInstantiate(object obj) { }

	// RVA: 0xD23D78
	public static object CommonToolsInstantiate(object obj, object parent, object worldPositionStays) { }

	// RVA: -1
	public static object Instantiate(object obj) { }

	// RVA: -1
	public static object Instantiate(object obj, object parent, object worldPositionStays) { }

	// RVA: -1
	public static object Instantiate(object obj, object parent) { }

	// RVA: 0xD2402C
	public object .ctor() { }

}

// Namespace: IFix
public class ILFixDynamicMethodWrapper
{

	// Fields
	private object virtualMachine; // 0x8
	private object methodId; // 0x10
	private object anonObj; // 0x18
	public static object wrapperArray; // 0x0

	// Methods

	// RVA: 0xD24034
	public object __Gen_Wrap_0(object P0, object P1, object P2) { }

	// RVA: 0xD24154
	public object __Gen_Wrap_1(object P0, object P1) { }

	// RVA: 0xD1D9DC
	public object __Gen_Wrap_2(object P0) { }

	// RVA: 0xD2420C
	public object __Gen_Wrap_3(object P0) { }

	// RVA: 0xD1B024
	public object __Gen_Wrap_4(object P0) { }

	// RVA: 0xD1D538
	public object __Gen_Wrap_5(object P0, object P1) { }

	// RVA: 0xD1BC34
	public object __Gen_Wrap_6(object P0, object P1) { }

	// RVA: 0xD1D2E0
	public object __Gen_Wrap_7(object P0) { }

	// RVA: 0xD242E8
	public object __Gen_Wrap_8(object P0, object P1, object P2) { }

	// RVA: 0xD243F4
	public object __Gen_Wrap_9(object P0, object P1, object P2) { }

	// RVA: 0xD23C9C
	public object __Gen_Wrap_10(object P0) { }

	// RVA: 0xD244C0
	public object __Gen_Wrap_11(object P0) { }

	// RVA: 0xD22E60
	public object __Gen_Wrap_12(object P0, object P1) { }

	// RVA: 0xD20E98
	public object __Gen_Wrap_13(object P0, object P1) { }

	// RVA: 0xD2459C
	public object __Gen_Wrap_14(object P0) { }

	// RVA: 0xD24678
	public object __Gen_Wrap_15(object P0) { }

	// RVA: 0xD24754
	public object __Gen_Wrap_16(object P0, object P1, object P2) { }

	// RVA: 0xD24828
	public object __Gen_Wrap_17(object P0, object P1) { }

	// RVA: 0xD24918
	public object __Gen_Wrap_18(object P0, object P1, object P2) { }

	// RVA: 0xD249E4
	public object __Gen_Wrap_19(object P0, object P1, object P2) { }

	// RVA: 0xD24AB0
	public object __Gen_Wrap_20(object P0, object P1, object P2) { }

	// RVA: 0xD24BA8
	public object __Gen_Wrap_21(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xD24D44
	public object __Gen_Wrap_22(object P0, object P1, object P2, object P3) { }

	// RVA: 0xD24F14
	public object __Gen_Wrap_23(object P0, object P1, object P2, object P3) { }

	// RVA: 0xD250EC
	public object __Gen_Wrap_24(object P0, object P1, object P2) { }

	// RVA: 0xD23F20
	public object __Gen_Wrap_25(object P0, object P1, object P2) { }

	// RVA: 0xD25258
	public object __Gen_Wrap_26(object P0, object P1) { }

	// RVA: 0xD25320
	public object __Gen_Wrap_27(object P0, object P1) { }

	// RVA: 0xD25468
	public object __Gen_Wrap_28(object P0, object P1, object P2, object P3) { }

	// RVA: 0xD25550
	public object __Gen_Wrap_29(object P0, object P1, object P2) { }

	// RVA: 0xD2561C
	public object __Gen_Wrap_30(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xD22C8C
	public object __Gen_Wrap_31(object P0, object P1) { }

	// RVA: 0xD257C4
	public object __Gen_Wrap_32(object P0, object P1, object P2) { }

	// RVA: 0xD25944
	public object __Gen_Wrap_33(object P0, object P1, object P2) { }

	// RVA: 0xD25AB0
	public object __Gen_Wrap_34(object P0, object P1, object P2) { }

	// RVA: 0xD25C00
	public object __Gen_Wrap_35(object P0, object P1, object P2) { }

	// RVA: 0xD25CCC
	public object __Gen_Wrap_36(object P0, object P1, object P2) { }

	// RVA: 0xD25DD8
	public object __Gen_Wrap_37(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xD25F64
	public object __Gen_Wrap_38(object P0, object P1, object P2) { }

	// RVA: 0xD26080
	public object __Gen_Wrap_39(object P0, object P1) { }

	// RVA: 0xD26148
	public object __Gen_Wrap_41(object P0, object P1) { }

	// RVA: 0xD26244
	public object __Gen_Wrap_42(object P0, object P1, object P2, object P3) { }

	// RVA: 0xD2632C
	public object __Gen_Wrap_43(object P0, object P1, object P2) { }

	// RVA: 0xD263F8
	public object __Gen_Wrap_44(object P0, object P1, object P2) { }

	// RVA: 0xD26580
	public object __Gen_Wrap_45(object P0, object P1, object P2, object P3) { }

	// RVA: 0xD26668
	public object __Gen_Wrap_46(object P0, object P1) { }

	// RVA: 0xD26730
	public object __Gen_Wrap_47(object P0, object P1, object P2) { }

	// RVA: 0xD2684C
	public object __Gen_Wrap_48(object P0, object P1) { }

	// RVA: 0xD1A9A4
	public object __Gen_Wrap_49(object P0, object P1) { }

	// RVA: 0xD2693C
	public object __Gen_Wrap_50(object P0) { }

	// RVA: 0xD26A18
	public object __Gen_Wrap_51(object P0, object P1) { }

	// RVA: 0xD26AD0
	public object __Gen_Wrap_52(object P0) { }

	// RVA: 0xD26B7C
	public object __Gen_Wrap_53(object P0) { }

	// RVA: 0xD1A75C
	public object __Gen_Wrap_54(object P0) { }

	// RVA: 0xD1A428
	public object __Gen_Wrap_55(object P0, object P1) { }

	// RVA: 0xD1A8F8
	public object __Gen_Wrap_56(object P0) { }

	// RVA: 0xD1CB24
	public object __Gen_Wrap_57(object P0) { }

	// RVA: 0xD1C1E4
	public object __Gen_Wrap_58(object P0) { }

	// RVA: 0xD23378
	public object __Gen_Wrap_59(object P0) { }

	// RVA: 0xD1DEB4
	public object __Gen_Wrap_60(object P0) { }

	// RVA: 0xD1FD58
	public object __Gen_Wrap_61(object P0, object P1) { }

	// RVA: 0xD1F274
	public object __Gen_Wrap_62(object P0, object P1) { }

	// RVA: 0xD1EEB0
	public object __Gen_Wrap_63(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xD1E140
	public object __Gen_Wrap_64(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9) { }

	// RVA: 0xD1EDC8
	public object __Gen_Wrap_65(object P0, object P1, object P2, object P3) { }

	// RVA: 0xD1F9EC
	public object __Gen_Wrap_66(object P0, object P1) { }

	// RVA: 0xD2051C
	public object __Gen_Wrap_67(object P0, object P1) { }

	// RVA: 0xD20A5C
	public object __Gen_Wrap_68(object P0, object P1, object P2) { }

	// RVA: 0xD22118
	public object __Gen_Wrap_69(object P0) { }

	// RVA: 0xD2329C
	public object __Gen_Wrap_70(object P0, object P1, object P2) { }

	// RVA: 0xD239D4
	public object __Gen_Wrap_71(object P0, object P1) { }

	// RVA: 0xD26C58
	private static object .cctor() { }

}

// Namespace: IFix
public class WrappersManagerImpl
{

	// Methods

	// RVA: 0xD1A380
	public static object GetPatch(object id) { }

	// RVA: 0xD1A288
	public static object IsPatched(object id) { }

}

