// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public sealed class SpriteMask
{
}

