// Namespace: 
internal class <Module>
{
}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0x74DD774
	private static object Get() { }

	// RVA: 0x74DD844
	public object .ctor() { }

}

// Namespace: UnityEngine.UI
public class AnimationTriggers
{

	// Fields
	private const object kDefaultNormalAnimName;
	private const object kDefaultHighlightedAnimName;
	private const object kDefaultPressedAnimName;
	private const object kDefaultSelectedAnimName;
	private const object kDefaultDisabledAnimName;
	private object m_NormalTrigger; // 0x8
	private object m_HighlightedTrigger; // 0x10
	private object m_PressedTrigger; // 0x18
	private object m_SelectedTrigger; // 0x20
	private object m_DisabledTrigger; // 0x28

	// Properties
	public object normalTrigger { get; set; }
	public object highlightedTrigger { get; set; }
	public object pressedTrigger { get; set; }
	public object selectedTrigger { get; set; }
	public object disabledTrigger { get; set; }

	// Methods

	// RVA: 0x74DD980
	public object get_normalTrigger() { }

	// RVA: 0x74DD988
	public object set_normalTrigger(object value) { }

	// RVA: 0x74DD990
	public object get_highlightedTrigger() { }

	// RVA: 0x74DD998
	public object set_highlightedTrigger(object value) { }

	// RVA: 0x74DD9A0
	public object get_pressedTrigger() { }

	// RVA: 0x74DD9A8
	public object set_pressedTrigger(object value) { }

	// RVA: 0x74DD9B0
	public object get_selectedTrigger() { }

	// RVA: 0x74DD9B8
	public object set_selectedTrigger(object value) { }

	// RVA: 0x74DD9C0
	public object get_disabledTrigger() { }

	// RVA: 0x74DD9C8
	public object set_disabledTrigger(object value) { }

	// RVA: 0x74DD9D0
	public object .ctor() { }

}

// Namespace: 
public class ButtonClickedEvent
{

	// Methods

	// RVA: 0x74DDB50
	public object .ctor() { }

}

// Namespace: 
private sealed class <OnFinishSubmit>d__9
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <fadeTime>5__2; // 0x20
	private object <elapsedTime>5__3; // 0x24

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x74DDDD4
	public object .ctor(object <>1__state) { }

	// RVA: 0x74DDE00
	private object System.IDisposable.Dispose() { }

	// RVA: 0x74DDE04
	private object MoveNext() { }

	// RVA: 0x74DDF38
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x74DDF40
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x74DDF80
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: UnityEngine.UI
public class Button
{

	// Fields
	private object m_OnClick; // 0xF8

	// Properties
	public object onClick { get; set; }

	// Methods

	// RVA: 0x74DDAA8
	protected object .ctor() { }

	// RVA: 0x74DDB58
	public object get_onClick() { }

	// RVA: 0x74DDB60
	public object set_onClick(object value) { }

	// RVA: 0x74DDB68
	private object Press() { }

	// RVA: 0x74DDC34
	public virtual object OnPointerClick(object eventData) { }

	// RVA: 0x74DDC5C
	public virtual object OnSubmit(object eventData) { }

	// RVA: 0x74DDD68
	private object OnFinishSubmit() { }

}

// Namespace: UnityEngine.UI
public enum CanvasUpdate
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Prelayout;
	public const object Layout;
	public const object PostLayout;
	public const object PreRender;
	public const object LatePreRender;
	public const object MaxUpdateValue;
}

// Namespace: UnityEngine.UI
public interface ICanvasElement
{

	// Properties
	public abstract object transform { get; }

	// Methods

	// RVA: -1
	public abstract object Rebuild(object executing) { }

	// RVA: -1
	public abstract object get_transform() { }

	// RVA: -1
	public abstract object LayoutComplete() { }

	// RVA: -1
	public abstract object GraphicUpdateComplete() { }

	// RVA: -1
	public abstract object IsDestroyed() { }

}

// Namespace: UnityEngine.UI
public class CanvasUpdateRegistry
{

	// Fields
	private static object s_Instance; // 0x0
	private object m_PerformingLayoutUpdate; // 0x8
	private object m_PerformingGraphicUpdate; // 0x9
	private object m_CanvasUpdateProfilerStrings; // 0x10
	private const object m_CullingUpdateProfilerString;
	private readonly object m_LayoutRebuildQueue; // 0x18
	private readonly object m_GraphicRebuildQueue; // 0x20
	private static readonly object s_SortLayoutFunction; // 0x8

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: 0x74DDF88
	protected object .ctor() { }

	// RVA: 0x74DE164
	public static object get_instance() { }

	// RVA: 0x74DE24C
	private object ObjectValidForUpdate(object element) { }

	// RVA: 0x74DE350
	private object CleanInvalidItems() { }

	// RVA: 0x74DE718
	private object PerformUpdate() { }

	// RVA: 0x74DF3DC
	private static object ParentCount(object child) { }

	// RVA: 0x74DF4D4
	private static object SortLayoutList(object x, object y) { }

	// RVA: 0x74DF684
	public static object RegisterCanvasElementForLayoutRebuild(object element) { }

	// RVA: 0x74DF7C8
	public static object TryRegisterCanvasElementForLayoutRebuild(object element) { }

	// RVA: 0x74DF70C
	private object InternalRegisterCanvasElementForLayoutRebuild(object element) { }

	// RVA: 0x74DF850
	public static object RegisterCanvasElementForGraphicRebuild(object element) { }

	// RVA: 0x74DF9C0
	public static object TryRegisterCanvasElementForGraphicRebuild(object element) { }

	// RVA: 0x74DF8D8
	private object InternalRegisterCanvasElementForGraphicRebuild(object element) { }

	// RVA: 0x74DFA48
	public static object UnRegisterCanvasElementForRebuild(object element) { }

	// RVA: 0x74DFE74
	public static object DisableCanvasElementForRebuild(object element) { }

	// RVA: 0x74DFAEC
	private object InternalUnRegisterCanvasElementForLayoutRebuild(object element) { }

	// RVA: 0x74DFCB0
	private object InternalUnRegisterCanvasElementForGraphicRebuild(object element) { }

	// RVA: 0x74DFF18
	private object InternalDisableCanvasElementForLayoutRebuild(object element) { }

	// RVA: 0x74E00DC
	private object InternalDisableCanvasElementForGraphicRebuild(object element) { }

	// RVA: 0x74E02A0
	public static object IsRebuildingLayout() { }

	// RVA: 0x74E031C
	public static object IsRebuildingGraphics() { }

	// RVA: 0x74E0398
	private static object .cctor() { }

}

// Namespace: UnityEngine.UI
public struct ColorBlock
{

	// Fields
	private object m_NormalColor; // 0xFFFFFFFFFFFFFFF8
	private object m_HighlightedColor; // 0x8
	private object m_PressedColor; // 0x18
	private object m_SelectedColor; // 0x28
	private object m_DisabledColor; // 0x38
	private object m_ColorMultiplier; // 0x48
	private object m_FadeDuration; // 0x4C
	public static object defaultColorBlock; // 0x0

	// Properties
	public object normalColor { get; set; }
	public object highlightedColor { get; set; }
	public object pressedColor { get; set; }
	public object selectedColor { get; set; }
	public object disabledColor { get; set; }
	public object colorMultiplier { get; set; }
	public object fadeDuration { get; set; }

	// Methods

	// RVA: 0x74E0430
	public object get_normalColor() { }

	// RVA: 0x74E0448
	public object set_normalColor(object value) { }

	// RVA: 0x74E0460
	public object get_highlightedColor() { }

	// RVA: 0x74E0478
	public object set_highlightedColor(object value) { }

	// RVA: 0x74E0490
	public object get_pressedColor() { }

	// RVA: 0x74E04A8
	public object set_pressedColor(object value) { }

	// RVA: 0x74E04C0
	public object get_selectedColor() { }

	// RVA: 0x74E04D8
	public object set_selectedColor(object value) { }

	// RVA: 0x74E04F0
	public object get_disabledColor() { }

	// RVA: 0x74E0508
	public object set_disabledColor(object value) { }

	// RVA: 0x74E0520
	public object get_colorMultiplier() { }

	// RVA: 0x74E0530
	public object set_colorMultiplier(object value) { }

	// RVA: 0x74E0540
	public object get_fadeDuration() { }

	// RVA: 0x74E0550
	public object set_fadeDuration(object value) { }

	// RVA: 0x74E0560
	private static object .cctor() { }

	// RVA: 0x74E05DC
	public override object Equals(object obj) { }

	// RVA: 0x74E06C0
	public object Equals(object other) { }

	// RVA: 0x74E0A1C
	public static object op_Equality(object point1, object point2) { }

	// RVA: 0x74E0AB0
	public static object op_Inequality(object point1, object point2) { }

	// RVA: 0x74E0B48
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UI
public class ClipperRegistry
{

	// Fields
	private static object s_Instance; // 0x0
	private readonly object m_Clippers; // 0x8

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: 0x74E0C60
	protected object .ctor() { }

	// RVA: 0x74DF170
	public static object get_instance() { }

	// RVA: 0x74DF270
	public object Cull() { }

	// RVA: 0x74E0CE0
	public static object Register(object c) { }

	// RVA: 0x74E0D68
	public static object Unregister(object c) { }

	// RVA: 0x74E0DDC
	public static object Disable(object c) { }

}

// Namespace: UnityEngine.UI
public static class Clipping
{

	// Methods

	// RVA: 0x74E0E50
	public static object FindCullAndClipWorldRect(object rectMaskParents, object validRect) { }

}

// Namespace: UnityEngine.UI
public interface IClipper
{

	// Methods

	// RVA: -1
	public abstract object PerformClipping() { }

}

// Namespace: UnityEngine.UI
public interface IClippable
{

	// Properties
	public abstract object gameObject { get; }
	public abstract object rectTransform { get; }

	// Methods

	// RVA: -1
	public abstract object get_gameObject() { }

	// RVA: -1
	public abstract object RecalculateClipping() { }

	// RVA: -1
	public abstract object get_rectTransform() { }

	// RVA: -1
	public abstract object Cull(object clipRect, object validRect) { }

	// RVA: -1
	public abstract object SetClipRect(object value, object validRect) { }

	// RVA: -1
	public abstract object SetClipSoftness(object clipSoftness) { }

}

// Namespace: UnityEngine.UI
internal class RectangularVertexClipper
{

	// Fields
	private readonly object m_WorldCorners; // 0x8
	private readonly object m_CanvasCorners; // 0x10

	// Methods

	// RVA: 0x74E1038
	public object GetCanvasRect(object t, object c) { }

	// RVA: 0x74E1290
	public object .ctor() { }

}

// Namespace: 
public interface IFactoryControls
{

	// Methods

	// RVA: -1
	public abstract object CreateGameObject(object name, object components) { }

}

// Namespace: 
private class DefaultRuntimeFactory
{

	// Fields
	public static object Default; // 0x0

	// Methods

	// RVA: 0x74E70E4
	public object CreateGameObject(object name, object components) { }

	// RVA: 0x74E7154
	public object .ctor() { }

	// RVA: 0x74E715C
	private static object .cctor() { }

}

// Namespace: 
public struct Resources
{

	// Fields
	public object standard; // 0xFFFFFFFFFFFFFFF8
	public object background; // 0x0
	public object inputField; // 0x8
	public object knob; // 0x10
	public object checkmark; // 0x18
	public object dropdown; // 0x20
	public object mask; // 0x28
}

// Namespace: UnityEngine.UI
public static class DefaultControls
{

	// Fields
	private static object m_CurrentFactory; // 0x0
	private const object kWidth;
	private const object kThickHeight;
	private const object kThinHeight;
	private static object s_ThickElementSize; // 0x8
	private static object s_ThinElementSize; // 0x10
	private static object s_ImageElementSize; // 0x18
	private static object s_DefaultSelectableColor; // 0x20
	private static object s_PanelColor; // 0x30
	private static object s_TextColor; // 0x40

	// Properties
	public static object factory { get; }

	// Methods

	// RVA: 0x74E1304
	public static object get_factory() { }

	// RVA: 0x74E1380
	private static object CreateUIElementRoot(object name, object size, object components) { }

	// RVA: 0x74E1568
	private static object CreateUIObject(object name, object parent, object components) { }

	// RVA: 0x74E1844
	private static object SetDefaultTextValues(object lbl) { }

	// RVA: 0x74E1994
	private static object SetDefaultColorTransitionValues(object slider) { }

	// RVA: 0x74E16EC
	private static object SetParentAndAlign(object child, object parent) { }

	// RVA: 0x74E1A00
	private static object SetLayerRecursively(object go, object layer) { }

	// RVA: 0x74E1B18
	public static object CreatePanel(object resources) { }

	// RVA: 0x74E2388
	public static object CreateButton(object resources) { }

	// RVA: 0x74E28AC
	public static object CreateText(object resources) { }

	// RVA: 0x74E2A88
	public static object CreateImage(object resources) { }

	// RVA: 0x74E2BCC
	public static object CreateRawImage(object resources) { }

	// RVA: 0x74E2D10
	public static object CreateSlider(object resources) { }

	// RVA: 0x74E3608
	public static object CreateScrollbar(object resources) { }

	// RVA: 0x74E3C28
	public static object CreateToggle(object resources) { }

	// RVA: 0x74E4348
	public static object CreateInputField(object resources) { }

	// RVA: 0x74E4B1C
	public static object CreateDropdown(object resources) { }

	// RVA: 0x74E65A4
	public static object CreateScrollView(object resources) { }

	// RVA: 0x74E701C
	private static object .cctor() { }

}

// Namespace: 
protected internal class DropdownItem
{

	// Fields
	private object m_Text; // 0x18
	private object m_Image; // 0x20
	private object m_RectTransform; // 0x28
	private object m_Toggle; // 0x30

	// Properties
	public object text { get; set; }
	public object image { get; set; }
	public object rectTransform { get; set; }
	public object toggle { get; set; }

	// Methods

	// RVA: 0x74EAF78
	public object get_text() { }

	// RVA: 0x74EAF80
	public object set_text(object value) { }

	// RVA: 0x74EAF88
	public object get_image() { }

	// RVA: 0x74EAF90
	public object set_image(object value) { }

	// RVA: 0x74EAF98
	public object get_rectTransform() { }

	// RVA: 0x74EAFA0
	public object set_rectTransform(object value) { }

	// RVA: 0x74EAFA8
	public object get_toggle() { }

	// RVA: 0x74EAFB0
	public object set_toggle(object value) { }

	// RVA: 0x74EAFB8
	public virtual object OnPointerEnter(object eventData) { }

	// RVA: 0x74EB048
	public virtual object OnCancel(object eventData) { }

	// RVA: 0x74EB160
	public object .ctor() { }

}

// Namespace: 
public class OptionData
{

	// Fields
	private object m_Text; // 0x8
	private object m_Image; // 0x10

	// Properties
	public object text { get; set; }
	public object image { get; set; }

	// Methods

	// RVA: 0x74EB168
	public object get_text() { }

	// RVA: 0x74EB170
	public object set_text(object value) { }

	// RVA: 0x74EB178
	public object get_image() { }

	// RVA: 0x74EB180
	public object set_image(object value) { }

	// RVA: 0x74E622C
	public object .ctor() { }

	// RVA: 0x74E7E74
	public object .ctor(object text) { }

	// RVA: 0x74E8060
	public object .ctor(object image) { }

	// RVA: 0x74EB188
	public object .ctor(object text, object image) { }

}

// Namespace: 
public class OptionDataList
{

	// Fields
	private object m_Options; // 0x8

	// Properties
	public object options { get; set; }

	// Methods

	// RVA: 0x74EB1C0
	public object get_options() { }

	// RVA: 0x74EB1C8
	public object set_options(object value) { }

	// RVA: 0x74E75B0
	public object .ctor() { }

}

// Namespace: 
public class DropdownEvent
{

	// Methods

	// RVA: 0x74E7634
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass63_0
{

	// Fields
	public object item; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x74E9CFC
	public object .ctor() { }

	// RVA: 0x74EB1D0
	internal object <Show>b__0(object x) { }

}

// Namespace: 
private sealed class <DelayedDestroyDropdownList>d__75
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object delay; // 0x18
	public object <>4__this; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x74EAD7C
	public object .ctor(object <>1__state) { }

	// RVA: 0x74EB20C
	private object System.IDisposable.Dispose() { }

	// RVA: 0x74EB210
	private object MoveNext() { }

	// RVA: 0x74EB2D0
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x74EB2D8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x74EB318
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: UnityEngine.UI
public class Dropdown
{

	// Fields
	private object m_Template; // 0xF8
	private object m_CaptionText; // 0x100
	private object m_CaptionImage; // 0x108
	private object m_ItemText; // 0x110
	private object m_ItemImage; // 0x118
	private object m_Value; // 0x120
	private object m_Options; // 0x128
	private object m_OnValueChanged; // 0x130
	private object m_AlphaFadeSpeed; // 0x138
	private object m_Dropdown; // 0x140
	private object m_Blocker; // 0x148
	private object m_Items; // 0x150
	private object m_AlphaTweenRunner; // 0x158
	private object validTemplate; // 0x160
	private const object kHighSortingLayer;
	private static object s_NoOptionData; // 0x0

	// Properties
	public object template { get; set; }
	public object captionText { get; set; }
	public object captionImage { get; set; }
	public object itemText { get; set; }
	public object itemImage { get; set; }
	public object options { get; set; }
	public object onValueChanged { get; set; }
	public object alphaFadeSpeed { get; set; }
	public object value { get; set; }

	// Methods

	// RVA: 0x74E71F8
	public object get_template() { }

	// RVA: 0x74E61F0
	public object set_template(object value) { }

	// RVA: 0x74E7200
	public object get_captionText() { }

	// RVA: 0x74E61F8
	public object set_captionText(object value) { }

	// RVA: 0x74E7208
	public object get_captionImage() { }

	// RVA: 0x74E7210
	public object set_captionImage(object value) { }

	// RVA: 0x74E7218
	public object get_itemText() { }

	// RVA: 0x74E6200
	public object set_itemText(object value) { }

	// RVA: 0x74E7220
	public object get_itemImage() { }

	// RVA: 0x74E7228
	public object set_itemImage(object value) { }

	// RVA: 0x74E6208
	public object get_options() { }

	// RVA: 0x74E7230
	public object set_options(object value) { }

	// RVA: 0x74E7254
	public object get_onValueChanged() { }

	// RVA: 0x74E725C
	public object set_onValueChanged(object value) { }

	// RVA: 0x74E7264
	public object get_alphaFadeSpeed() { }

	// RVA: 0x74E726C
	public object set_alphaFadeSpeed(object value) { }

	// RVA: 0x74E7274
	public object get_value() { }

	// RVA: 0x74E727C
	public object set_value(object value) { }

	// RVA: 0x74E740C
	public object SetValueWithoutNotify(object input) { }

	// RVA: 0x74E7284
	private object Set(object value, object sendCallback) { }

	// RVA: 0x74E7414
	protected object .ctor() { }

	// RVA: 0x74E768C
	protected override object Awake() { }

	// RVA: 0x74E7880
	protected override object Start() { }

	// RVA: 0x74E7928
	protected override object OnDisable() { }

	// RVA: 0x74E6234
	public object RefreshShownValue() { }

	// RVA: 0x74E7C38
	public object AddOptions(object options) { }

	// RVA: 0x74E7CB4
	public object AddOptions(object options) { }

	// RVA: 0x74E7EA0
	public object AddOptions(object options) { }

	// RVA: 0x74E808C
	public object ClearOptions() { }

	// RVA: 0x74E8110
	private object SetupTemplate(object rootCanvas) { }

	// RVA: -1
	private static object GetOrAddComponent(object go) { }

	// RVA: 0x74E8998
	public virtual object OnPointerClick(object eventData) { }

	// RVA: 0x74E9AAC
	public virtual object OnSubmit(object eventData) { }

	// RVA: 0x74E9AB0
	public virtual object OnCancel(object eventData) { }

	// RVA: 0x74E899C
	public object Show() { }

	// RVA: 0x74EA310
	protected virtual object CreateBlocker(object rootCanvas) { }

	// RVA: 0x74EA8CC
	protected virtual object DestroyBlocker(object blocker) { }

	// RVA: 0x74EA954
	protected virtual object CreateDropdownList(object template) { }

	// RVA: 0x74EA9F8
	protected virtual object DestroyDropdownList(object dropdownList) { }

	// RVA: 0x74EAA80
	protected virtual object CreateItem(object itemTemplate) { }

	// RVA: 0x74EAB24
	protected virtual object DestroyItem(object item) { }

	// RVA: 0x74E9D04
	private object AddItem(object data, object selected, object itemTemplate, object items) { }

	// RVA: 0x74EAB28
	private object AlphaFadeList(object duration, object alpha) { }

	// RVA: 0x74EA1F4
	private object AlphaFadeList(object duration, object start, object end) { }

	// RVA: 0x74EABC0
	private object SetAlpha(object alpha) { }

	// RVA: 0x74E9AB4
	public object Hide() { }

	// RVA: 0x74EAD00
	private object DelayedDestroyDropdownList(object delay) { }

	// RVA: 0x74E7A10
	private object ImmediateDestroyDropdownList() { }

	// RVA: 0x74EADA8
	private object OnSelectItem(object toggle) { }

	// RVA: 0x74EAEFC
	private static object .cctor() { }

}

// Namespace: UnityEngine.UI
public class FontData
{

	// Fields
	private object m_Font; // 0x8
	private object m_FontSize; // 0x10
	private object m_FontStyle; // 0x14
	private object m_BestFit; // 0x18
	private object m_MinSize; // 0x1C
	private object m_MaxSize; // 0x20
	private object m_Alignment; // 0x24
	private object m_AlignByGeometry; // 0x28
	private object m_RichText; // 0x29
	private object m_HorizontalOverflow; // 0x2C
	private object m_VerticalOverflow; // 0x30
	private object m_LineSpacing; // 0x34

	// Properties
	public static object defaultFontData { get; }
	public object font { get; set; }
	public object fontSize { get; set; }
	public object fontStyle { get; set; }
	public object bestFit { get; set; }
	public object minSize { get; set; }
	public object maxSize { get; set; }
	public object alignment { get; set; }
	public object alignByGeometry { get; set; }
	public object richText { get; set; }
	public object horizontalOverflow { get; set; }
	public object verticalOverflow { get; set; }
	public object lineSpacing { get; set; }

	// Methods

	// RVA: 0x74EB320
	public static object get_defaultFontData() { }

	// RVA: 0x74EB3C4
	public object get_font() { }

	// RVA: 0x74EB3CC
	public object set_font(object value) { }

	// RVA: 0x74EB3D4
	public object get_fontSize() { }

	// RVA: 0x74EB3DC
	public object set_fontSize(object value) { }

	// RVA: 0x74EB3E4
	public object get_fontStyle() { }

	// RVA: 0x74EB3EC
	public object set_fontStyle(object value) { }

	// RVA: 0x74EB3F4
	public object get_bestFit() { }

	// RVA: 0x74EB3FC
	public object set_bestFit(object value) { }

	// RVA: 0x74EB404
	public object get_minSize() { }

	// RVA: 0x74EB40C
	public object set_minSize(object value) { }

	// RVA: 0x74EB414
	public object get_maxSize() { }

	// RVA: 0x74EB41C
	public object set_maxSize(object value) { }

	// RVA: 0x74EB424
	public object get_alignment() { }

	// RVA: 0x74EB42C
	public object set_alignment(object value) { }

	// RVA: 0x74EB434
	public object get_alignByGeometry() { }

	// RVA: 0x74EB43C
	public object set_alignByGeometry(object value) { }

	// RVA: 0x74EB444
	public object get_richText() { }

	// RVA: 0x74EB44C
	public object set_richText(object value) { }

	// RVA: 0x74EB454
	public object get_horizontalOverflow() { }

	// RVA: 0x74EB45C
	public object set_horizontalOverflow(object value) { }

	// RVA: 0x74EB464
	public object get_verticalOverflow() { }

	// RVA: 0x74EB46C
	public object set_verticalOverflow(object value) { }

	// RVA: 0x74EB474
	public object get_lineSpacing() { }

	// RVA: 0x74EB47C
	public object set_lineSpacing(object value) { }

	// RVA: 0x74EB484
	private object UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize() { }

	// RVA: 0x74EB488
	private object UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize() { }

	// RVA: 0x74EB3BC
	public object .ctor() { }

}

// Namespace: UnityEngine.UI
public static class FontUpdateTracker
{

	// Fields
	private static object m_Tracked; // 0x0

	// Methods

	// RVA: 0x74EB4C8
	public static object TrackText(object t) { }

	// RVA: 0x74EB778
	private static object RebuildForFont(object f) { }

	// RVA: 0x74EB980
	public static object UntrackText(object t) { }

	// RVA: 0x74EBBF0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UI
public abstract class Graphic
{

	// Fields
	protected static object s_DefaultUI; // 0x0
	protected static object s_WhiteTexture; // 0x8
	protected object m_Material; // 0x18
	private object m_Color; // 0x20
	protected object m_SkipLayoutUpdate; // 0x30
	protected object m_SkipMaterialUpdate; // 0x31
	private object m_RaycastTarget; // 0x32
	private object m_RaycastTargetCache; // 0x33
	private object m_RaycastPadding; // 0x34
	private object m_RectTransform; // 0x48
	private object m_CanvasRenderer; // 0x50
	private object m_Canvas; // 0x58
	private object m_VertsDirty; // 0x60
	private object m_MaterialDirty; // 0x61
	protected object m_OnDirtyLayoutCallback; // 0x68
	protected object m_OnDirtyVertsCallback; // 0x70
	protected object m_OnDirtyMaterialCallback; // 0x78
	protected static object s_Mesh; // 0x10
	private static readonly object s_VertexHelper; // 0x18
	protected object m_CachedMesh; // 0x80
	protected object m_CachedUvs; // 0x88
	private readonly object m_ColorTweenRunner; // 0x90
	private object <useLegacyMeshGeneration>k__BackingField; // 0x98

	// Properties
	public static object defaultGraphicMaterial { get; }
	public virtual object color { get; set; }
	public virtual object raycastTarget { get; set; }
	public object raycastPadding { get; set; }
	protected object useLegacyMeshGeneration { get; set; }
	public object depth { get; }
	public object rectTransform { get; }
	public object canvas { get; }
	public object canvasRenderer { get; }
	public virtual object defaultMaterial { get; }
	public virtual object material { get; set; }
	public virtual object materialForRendering { get; }
	public virtual object mainTexture { get; }
	protected static object workerMesh { get; }

	// Methods

	// RVA: 0x74EBC80
	public static object get_defaultGraphicMaterial() { }

	// RVA: 0x74EBDC0
	public virtual object get_color() { }

	// RVA: 0x74EBDCC
	public virtual object set_color(object value) { }

	// RVA: 0x74EBE28
	public virtual object get_raycastTarget() { }

	// RVA: 0x74EBE30
	public virtual object set_raycastTarget(object value) { }

	// RVA: 0x74EC5B0
	public object get_raycastPadding() { }

	// RVA: 0x74EC5BC
	public object set_raycastPadding(object value) { }

	// RVA: 0x74EC5C8
	protected object get_useLegacyMeshGeneration() { }

	// RVA: 0x74EC5D0
	protected object set_useLegacyMeshGeneration(object value) { }

	// RVA: 0x74EC5D8
	protected object .ctor() { }

	// RVA: 0x74EC694
	public virtual object SetAllDirty() { }

	// RVA: 0x74EC984
	public virtual object SetLayoutDirty() { }

	// RVA: 0x74ECB10
	public virtual object SetVerticesDirty() { }

	// RVA: 0x74ECC2C
	public virtual object SetMaterialDirty() { }

	// RVA: 0x74EC76C
	public object SetRaycastDirty() { }

	// RVA: 0x74ECD48
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x74ECEAC
	protected override object OnBeforeTransformParentChanged() { }

	// RVA: 0x74ED2A8
	protected override object OnTransformParentChanged() { }

	// RVA: 0x74ED814
	public object get_depth() { }

	// RVA: 0x74ECAA0
	public object get_rectTransform() { }

	// RVA: 0x74EC02C
	public object get_canvas() { }

	// RVA: 0x74ED3E0
	private object CacheCanvas() { }

	// RVA: 0x74ED83C
	public object get_canvasRenderer() { }

	// RVA: 0x74ED8E4
	public virtual object get_defaultMaterial() { }

	// RVA: 0x74ED94C
	public virtual object get_material() { }

	// RVA: 0x74EDA1C
	public virtual object set_material(object value) { }

	// RVA: 0x74EDAF0
	public virtual object get_materialForRendering() { }

	// RVA: 0x74EDD10
	public virtual object get_mainTexture() { }

	// RVA: 0x74EDD8C
	protected override object OnEnable() { }

	// RVA: 0x74EDF84
	protected override object OnDisable() { }

	// RVA: 0x74EE40C
	protected override object OnDestroy() { }

	// RVA: 0x74EE62C
	protected override object OnCanvasHierarchyChanged() { }

	// RVA: 0x74EE834
	public virtual object OnCullingChanged() { }

	// RVA: 0x74EE934
	public virtual object Rebuild(object update) { }

	// RVA: 0x74EEA88
	public virtual object LayoutComplete() { }

	// RVA: 0x74EEA8C
	public virtual object GraphicUpdateComplete() { }

	// RVA: 0x74EEA90
	protected virtual object UpdateMaterial() { }

	// RVA: 0x74EEBAC
	protected virtual object UpdateGeometry() { }

	// RVA: 0x74EF08C
	private object DoMeshGeneration() { }

	// RVA: 0x74EEBC0
	private object DoLegacyMeshGeneration() { }

	// RVA: 0x74EF5C4
	protected static object get_workerMesh() { }

	// RVA: 0x74EF754
	protected virtual object OnFillVBO(object vbo) { }

	// RVA: 0x74EF758
	protected virtual object OnPopulateMesh(object m) { }

	// RVA: 0x74EF83C
	protected virtual object OnPopulateMesh(object vh) { }

	// RVA: 0x74EFE70
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x74EFEB4
	public virtual object SetNativeSize() { }

	// RVA: 0x74EFEB8
	public virtual object Raycast(object sp, object eventCamera) { }

	// RVA: 0x74F0468
	public object PixelAdjustPoint(object point) { }

	// RVA: 0x74EF9B8
	public object GetPixelAdjustedRect() { }

	// RVA: 0x74F08A0
	public virtual object CrossFadeColor(object targetColor, object duration, object ignoreTimeScale, object useAlpha) { }

	// RVA: 0x74F0940
	public virtual object CrossFadeColor(object targetColor, object duration, object ignoreTimeScale, object useAlpha, object useRGB) { }

	// RVA: 0x74F0BFC
	private static object CreateColorFromAlpha(object alpha) { }

	// RVA: 0x74F0C10
	public virtual object CrossFadeAlpha(object alpha, object duration, object ignoreTimeScale) { }

	// RVA: 0x74F0CE4
	public object RegisterDirtyLayoutCallback(object action) { }

	// RVA: 0x74F0D80
	public object UnregisterDirtyLayoutCallback(object action) { }

	// RVA: 0x74F0E1C
	public object RegisterDirtyVerticesCallback(object action) { }

	// RVA: 0x74F0EB8
	public object UnregisterDirtyVerticesCallback(object action) { }

	// RVA: 0x74F0F54
	public object RegisterDirtyMaterialCallback(object action) { }

	// RVA: 0x74F0FF0
	public object UnregisterDirtyMaterialCallback(object action) { }

	// RVA: 0x74F108C
	private static object .cctor() { }

	// RVA: 0x74F1114
	private object UnityEngine.UI.ICanvasElement.get_transform() { }

}

// Namespace: 
public enum BlockingObjects
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object TwoD;
	public const object ThreeD;
	public const object All;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__27_0; // 0x8

	// Methods

	// RVA: 0x74F31FC
	private static object .cctor() { }

	// RVA: 0x74F325C
	public object .ctor() { }

	// RVA: 0x74F3264
	internal object <Raycast>b__27_0(object g1, object g2) { }

}

// Namespace: UnityEngine.UI
public class GraphicRaycaster
{

	// Fields
	protected const object kNoEventMaskSet;
	private object m_IgnoreReversedGraphics; // 0x20
	private object m_BlockingObjects; // 0x24
	protected object m_BlockingMask; // 0x28
	private object m_Canvas; // 0x30
	private object m_RaycastResults; // 0x38
	private static readonly object s_SortedGraphics; // 0x0

	// Properties
	public override object sortOrderPriority { get; }
	public override object renderOrderPriority { get; }
	public object ignoreReversedGraphics { get; set; }
	public object blockingObjects { get; set; }
	public object blockingMask { get; set; }
	private object canvas { get; }
	public override object eventCamera { get; }

	// Methods

	// RVA: 0x74F111C
	public override object get_sortOrderPriority() { }

	// RVA: 0x74F136C
	public override object get_renderOrderPriority() { }

	// RVA: 0x74F1504
	public object get_ignoreReversedGraphics() { }

	// RVA: 0x74F150C
	public object set_ignoreReversedGraphics(object value) { }

	// RVA: 0x74F1514
	public object get_blockingObjects() { }

	// RVA: 0x74F151C
	public object set_blockingObjects(object value) { }

	// RVA: 0x74F1524
	public object get_blockingMask() { }

	// RVA: 0x74F152C
	public object set_blockingMask(object value) { }

	// RVA: 0x74F1534
	protected object .ctor() { }

	// RVA: 0x74F129C
	private object get_canvas() { }

	// RVA: 0x74F15CC
	public override object Raycast(object eventData, object resultAppendList) { }

	// RVA: 0x74F2FC8
	public override object get_eventCamera() { }

	// RVA: 0x74F279C
	private static object Raycast(object canvas, object eventCamera, object pointerPosition, object foundGraphics, object results) { }

	// RVA: 0x74F316C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UI
public class GraphicRegistry
{

	// Fields
	private static object s_Instance; // 0x0
	private readonly object m_Graphics; // 0x8
	private readonly object m_RaycastableGraphics; // 0x10
	private static readonly object s_EmptyList; // 0x8

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: 0x74F32E4
	protected object .ctor() { }

	// RVA: 0x74F3490
	public static object get_instance() { }

	// RVA: 0x74ED594
	public static object RegisterGraphicForCanvas(object c, object graphic) { }

	// RVA: 0x74EC300
	public static object RegisterRaycastGraphicForCanvas(object c, object graphic) { }

	// RVA: 0x74ED064
	public static object UnregisterGraphicForCanvas(object c, object graphic) { }

	// RVA: 0x74EC0E4
	public static object UnregisterRaycastGraphicForCanvas(object c, object graphic) { }

	// RVA: 0x74EE1F4
	public static object DisableGraphicForCanvas(object c, object graphic) { }

	// RVA: 0x74F3578
	public static object DisableRaycastGraphicForCanvas(object c, object graphic) { }

	// RVA: 0x74F37A0
	public static object GetGraphicsForCanvas(object canvas) { }

	// RVA: 0x74F26A8
	public static object GetRaycastableGraphicsForCanvas(object canvas) { }

	// RVA: 0x74F3894
	private static object .cctor() { }

}

// Namespace: UnityEngine.UI
internal interface IGraphicEnabledDisabled
{

	// Methods

	// RVA: -1
	public abstract object OnSiblingGraphicEnabledDisabled() { }

}

// Namespace: 
public enum Type
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Simple;
	public const object Sliced;
	public const object Tiled;
	public const object Filled;
}

// Namespace: 
public enum FillMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Horizontal;
	public const object Vertical;
	public const object Radial90;
	public const object Radial180;
	public const object Radial360;
}

// Namespace: 
public enum OriginHorizontal
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
}

// Namespace: 
public enum OriginVertical
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Bottom;
	public const object Top;
}

// Namespace: 
public enum Origin90
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BottomLeft;
	public const object TopLeft;
	public const object TopRight;
	public const object BottomRight;
}

// Namespace: 
public enum Origin180
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Bottom;
	public const object Left;
	public const object Top;
	public const object Right;
}

// Namespace: 
public enum Origin360
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Bottom;
	public const object Right;
	public const object Top;
	public const object Left;
}

// Namespace: UnityEngine.UI
public class Image
{

	// Fields
	protected static object s_ETC1DefaultUI; // 0x0
	private object m_Sprite; // 0xD0
	private object m_OverrideSprite; // 0xD8
	private object m_Type; // 0xE0
	private object m_PreserveAspect; // 0xE4
	private object m_FillCenter; // 0xE5
	private object m_FillMethod; // 0xE8
	private object m_FillAmount; // 0xEC
	private object m_FillClockwise; // 0xF0
	private object m_FillOrigin; // 0xF4
	private object m_AlphaHitTestMinimumThreshold; // 0xF8
	private object m_Tracked; // 0xFC
	private object m_UseSpriteMesh; // 0xFD
	private object m_PixelsPerUnitMultiplier; // 0x100
	private object m_CachedReferencePixelsPerUnit; // 0x104
	private static readonly object s_VertScratch; // 0x8
	private static readonly object s_UVScratch; // 0x10
	private static readonly object s_Xy; // 0x18
	private static readonly object s_Uv; // 0x20
	private static object m_TrackedTexturelessImages; // 0x28
	private static object s_Initialized; // 0x30

	// Properties
	public object sprite { get; set; }
	public object overrideSprite { get; set; }
	private object activeSprite { get; }
	public object type { get; set; }
	public object preserveAspect { get; set; }
	public object fillCenter { get; set; }
	public object fillMethod { get; set; }
	public object fillAmount { get; set; }
	public object fillClockwise { get; set; }
	public object fillOrigin { get; set; }
	public object eventAlphaThreshold { get; set; }
	public object alphaHitTestMinimumThreshold { get; set; }
	public object useSpriteMesh { get; set; }
	public static object defaultETC1GraphicMaterial { get; }
	public override object mainTexture { get; }
	public object hasBorder { get; }
	public object pixelsPerUnitMultiplier { get; set; }
	public object pixelsPerUnit { get; }
	protected object multipliedPixelsPerUnit { get; }
	public override object material { get; set; }
	public virtual object minWidth { get; }
	public virtual object preferredWidth { get; }
	public virtual object flexibleWidth { get; }
	public virtual object minHeight { get; }
	public virtual object preferredHeight { get; }
	public virtual object flexibleHeight { get; }
	public virtual object layoutPriority { get; }

	// Methods

	// RVA: 0x74F3924
	public object get_sprite() { }

	// RVA: 0x74E1E8C
	public object set_sprite(object value) { }

	// RVA: 0x74F3BC4
	public object DisableSpriteOptimizations() { }

	// RVA: 0x74F3BCC
	public object get_overrideSprite() { }

	// RVA: 0x74F3CD4
	public object set_overrideSprite(object value) { }

	// RVA: 0x74F3C50
	private object get_activeSprite() { }

	// RVA: 0x74F3D74
	public object get_type() { }

	// RVA: 0x74E22F0
	public object set_type(object value) { }

	// RVA: 0x74F3D7C
	public object get_preserveAspect() { }

	// RVA: 0x74F3D84
	public object set_preserveAspect(object value) { }

	// RVA: 0x74F3E1C
	public object get_fillCenter() { }

	// RVA: 0x74F3E24
	public object set_fillCenter(object value) { }

	// RVA: 0x74F3EBC
	public object get_fillMethod() { }

	// RVA: 0x74F3EC4
	public object set_fillMethod(object value) { }

	// RVA: 0x74F3F74
	public object get_fillAmount() { }

	// RVA: 0x74F3F7C
	public object set_fillAmount(object value) { }

	// RVA: 0x74F4034
	public object get_fillClockwise() { }

	// RVA: 0x74F403C
	public object set_fillClockwise(object value) { }

	// RVA: 0x74F40D4
	public object get_fillOrigin() { }

	// RVA: 0x74F40DC
	public object set_fillOrigin(object value) { }

	// RVA: 0x74F4174
	public object get_eventAlphaThreshold() { }

	// RVA: 0x74F4184
	public object set_eventAlphaThreshold(object value) { }

	// RVA: 0x74F4350
	public object get_alphaHitTestMinimumThreshold() { }

	// RVA: 0x74F4190
	public object set_alphaHitTestMinimumThreshold(object value) { }

	// RVA: 0x74F4358
	public object get_useSpriteMesh() { }

	// RVA: 0x74F4360
	public object set_useSpriteMesh(object value) { }

	// RVA: 0x74F43F8
	protected object .ctor() { }

	// RVA: 0x74F4444
	public static object get_defaultETC1GraphicMaterial() { }

	// RVA: 0x74F4584
	public override object get_mainTexture() { }

	// RVA: 0x74F4874
	public object get_hasBorder() { }

	// RVA: 0x74F4A28
	public object get_pixelsPerUnitMultiplier() { }

	// RVA: 0x74F4A30
	public object set_pixelsPerUnitMultiplier(object value) { }

	// RVA: 0x74F4A8C
	public object get_pixelsPerUnit() { }

	// RVA: 0x74F4DF8
	protected object get_multipliedPixelsPerUnit() { }

	// RVA: 0x74F4E20
	public override object get_material() { }

	// RVA: 0x74F50B0
	public override object set_material(object value) { }

	// RVA: 0x74F5184
	public virtual object OnBeforeSerialize() { }

	// RVA: 0x74F5188
	public virtual object OnAfterDeserialize() { }

	// RVA: 0x74F51DC
	private object PreserveSpriteAspectRatio(object rect, object spriteSize) { }

	// RVA: 0x74F5330
	private object GetDrawingDimensions(object shouldPreserveAspect) { }

	// RVA: 0x74F5904
	public override object SetNativeSize() { }

	// RVA: 0x74F5C6C
	protected override object OnPopulateMesh(object toFill) { }

	// RVA: 0x74F39C0
	private object TrackSprite() { }

	// RVA: 0x74F91B0
	protected override object OnEnable() { }

	// RVA: 0x74F91D8
	protected override object OnDisable() { }

	// RVA: 0x74F9394
	protected override object UpdateMaterial() { }

	// RVA: 0x74F9590
	protected override object OnCanvasHierarchyChanged() { }

	// RVA: 0x74F5E34
	private object GenerateSimpleSprite(object vh, object lPreserveAspect) { }

	// RVA: 0x74F61BC
	private object GenerateSprite(object vh, object lPreserveAspect) { }

	// RVA: 0x74F67A8
	private object GenerateSlicedSprite(object toFill) { }

	// RVA: 0x74F7058
	private object GenerateTiledSprite(object toFill) { }

	// RVA: 0x74F9AE0
	private static object AddQuad(object vertexHelper, object quadPositions, object color, object quadUVs) { }

	// RVA: 0x74F997C
	private static object AddQuad(object vertexHelper, object posMin, object posMax, object color, object uvMin, object uvMax) { }

	// RVA: 0x74F9864
	private object GetAdjustedBorders(object border, object adjustedRect) { }

	// RVA: 0x74F82BC
	private object GenerateFilledSprite(object toFill, object preserveAspect) { }

	// RVA: 0x74F9C74
	private static object RadialCut(object xy, object uv, object fill, object invert, object corner) { }

	// RVA: 0x74F9DA8
	private static object RadialCut(object xy, object cos, object sin, object invert, object corner) { }

	// RVA: 0x74FA20C
	public virtual object CalculateLayoutInputHorizontal() { }

	// RVA: 0x74FA210
	public virtual object CalculateLayoutInputVertical() { }

	// RVA: 0x74FA214
	public virtual object get_minWidth() { }

	// RVA: 0x74FA21C
	public virtual object get_preferredWidth() { }

	// RVA: 0x74FA438
	public virtual object get_flexibleWidth() { }

	// RVA: 0x74FA440
	public virtual object get_minHeight() { }

	// RVA: 0x74FA448
	public virtual object get_preferredHeight() { }

	// RVA: 0x74FA664
	public virtual object get_flexibleHeight() { }

	// RVA: 0x74FA66C
	public virtual object get_layoutPriority() { }

	// RVA: 0x74FA674
	public virtual object IsRaycastLocationValid(object screenPoint, object eventCamera) { }

	// RVA: 0x74FADC0
	private object MapCoordinate(object local, object rect) { }

	// RVA: 0x74FB134
	private static object RebuildImage(object spriteAtlas) { }

	// RVA: 0x74F8F98
	private static object TrackImage(object g) { }

	// RVA: 0x74F92E8
	private static object UnTrackImage(object g) { }

	// RVA: 0x74FB418
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x74FB488
	private static object .cctor() { }

	// RVA: 0x74F392C
	private object <set_sprite>g__ResetAlphaHitThresholdIfNeeded|11_0() { }

	// RVA: 0x74FB5B4
	private object <set_sprite>g__SpriteSupportsAlphaHitTest|11_1() { }

}

// Namespace: UnityEngine.UI
public interface IMask
{

	// Properties
	public abstract object rectTransform { get; }

	// Methods

	// RVA: -1
	public abstract object Enabled() { }

	// RVA: -1
	public abstract object get_rectTransform() { }

}

// Namespace: UnityEngine.UI
public interface IMaskable
{

	// Methods

	// RVA: -1
	public abstract object RecalculateMasking() { }

}

// Namespace: 
public enum ContentType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Standard;
	public const object Autocorrected;
	public const object IntegerNumber;
	public const object DecimalNumber;
	public const object Alphanumeric;
	public const object Name;
	public const object EmailAddress;
	public const object Password;
	public const object Pin;
	public const object Custom;
}

// Namespace: 
public enum InputType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Standard;
	public const object AutoCorrect;
	public const object Password;
}

// Namespace: 
public enum CharacterValidation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Integer;
	public const object Decimal;
	public const object Alphanumeric;
	public const object Name;
	public const object EmailAddress;
}

// Namespace: 
public enum LineType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SingleLine;
	public const object MultiLineSubmit;
	public const object MultiLineNewline;
}

// Namespace: 
public sealed class OnValidateInput
{

	// Methods

	// RVA: 0x769FF68
	public object .ctor(object object, object method) { }

	// RVA: 0x76ACBC0
	public virtual object Invoke(object text, object charIndex, object addedChar) { }

	// RVA: 0x76ACBD4
	public virtual object BeginInvoke(object text, object charIndex, object addedChar, object callback, object object) { }

	// RVA: 0x76ACCC8
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public class SubmitEvent
{

	// Methods

	// RVA: 0x769F5C0
	public object .ctor() { }

}

// Namespace: 
public class EndEditEvent
{

	// Methods

	// RVA: 0x769F618
	public object .ctor() { }

}

// Namespace: 
public class OnChangeEvent
{

	// Methods

	// RVA: 0x769F670
	public object .ctor() { }

}

// Namespace: 
protected enum EditState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Continue;
	public const object Finish;
}

// Namespace: 
private sealed class <CaretBlink>d__173
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x76A216C
	public object .ctor(object <>1__state) { }

	// RVA: 0x76ACCFC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x76ACD00
	private object MoveNext() { }

	// RVA: 0x76ACEB4
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x76ACEBC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x76ACEFC
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <MouseDragOutsideRect>d__197
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object eventData; // 0x18
	public object <>4__this; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x76A5A54
	public object .ctor(object <>1__state) { }

	// RVA: 0x76ACF04
	private object System.IDisposable.Dispose() { }

	// RVA: 0x76ACF08
	private object MoveNext() { }

	// RVA: 0x76AD1F8
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x76AD200
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x76AD240
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: UnityEngine.UI
public class InputField
{

	// Fields
	protected object m_Keyboard; // 0xF8
	private static readonly object kSeparators; // 0x0
	private static object s_IsQuestDevice; // 0x8
	protected object m_TextComponent; // 0x100
	protected object m_Placeholder; // 0x108
	private object m_ContentType; // 0x110
	private object m_InputType; // 0x114
	private object m_AsteriskChar; // 0x118
	private object m_KeyboardType; // 0x11C
	private object m_LineType; // 0x120
	private object m_HideMobileInput; // 0x124
	private object m_CharacterValidation; // 0x128
	private object m_CharacterLimit; // 0x12C
	private object m_OnSubmit; // 0x130
	private object m_OnDidEndEdit; // 0x138
	private object m_OnValueChanged; // 0x140
	private object m_OnValidateInput; // 0x148
	private object m_CaretColor; // 0x150
	private object m_CustomCaretColor; // 0x160
	private object m_SelectionColor; // 0x164
	protected object m_Text; // 0x178
	private object m_CaretBlinkRate; // 0x180
	private object m_CaretWidth; // 0x184
	private object m_ReadOnly; // 0x188
	private object m_ShouldActivateOnSelect; // 0x189
	protected object m_CaretPosition; // 0x18C
	protected object m_CaretSelectPosition; // 0x190
	private object caretRectTrans; // 0x198
	protected object m_CursorVerts; // 0x1A0
	private object m_InputTextCache; // 0x1A8
	private object m_CachedInputRenderer; // 0x1B0
	private object m_PreventFontCallback; // 0x1B8
	protected object m_Mesh; // 0x1C0
	private object m_AllowInput; // 0x1C8
	private object m_ShouldActivateNextUpdate; // 0x1C9
	private object m_UpdateDrag; // 0x1CA
	private object m_DragPositionOutOfBounds; // 0x1CB
	private const object kHScrollSpeed;
	private const object kVScrollSpeed;
	protected object m_CaretVisible; // 0x1CC
	private object m_BlinkCoroutine; // 0x1D0
	private object m_BlinkStartTime; // 0x1D8
	protected object m_DrawStart; // 0x1DC
	protected object m_DrawEnd; // 0x1E0
	private object m_DragCoroutine; // 0x1E8
	private object m_OriginalText; // 0x1F0
	private object m_WasCanceled; // 0x1F8
	private object m_HasDoneFocusTransition; // 0x1F9
	private object m_WaitForSecondsRealtime; // 0x200
	private object m_TouchKeyboardAllowsInPlaceEditing; // 0x208
	private object m_IsCompositionActive; // 0x209
	private const object kEmailSpecialCharacters;
	private const object kOculusQuestDeviceModel;
	private object m_ProcessingEvent; // 0x210
	private const object k_MaxTextLength;

	// Properties
	private object input { get; }
	private object compositionString { get; }
	protected object mesh { get; }
	protected object cachedInputTextGenerator { get; }
	public object shouldHideMobileInput { get; set; }
	public virtual object shouldActivateOnSelect { get; set; }
	public virtual object text { get; set; }
	public object innerText { get; set; }
	public object isFocused { get; }
	public object caretBlinkRate { get; set; }
	public object caretWidth { get; set; }
	public object textComponent { get; set; }
	public object placeholder { get; set; }
	public object caretColor { get; set; }
	public object customCaretColor { get; set; }
	public object selectionColor { get; set; }
	public object onEndEdit { get; set; }
	public object onSubmit { get; set; }
	public object onValueChange { get; set; }
	public object onValueChanged { get; set; }
	public object onValidateInput { get; set; }
	public object characterLimit { get; set; }
	public object contentType { get; set; }
	public object lineType { get; set; }
	public object inputType { get; set; }
	public object touchScreenKeyboard { get; }
	public object keyboardType { get; set; }
	public object characterValidation { get; set; }
	public object readOnly { get; set; }
	public object multiLine { get; }
	public object asteriskChar { get; set; }
	public object wasCanceled { get; }
	protected object caretPositionInternal { get; set; }
	protected object caretSelectPositionInternal { get; set; }
	private object hasSelection { get; }
	public object caretPosition { get; set; }
	public object selectionAnchorPosition { get; set; }
	public object selectionFocusPosition { get; set; }
	private static object clipboard { get; set; }
	public virtual object minWidth { get; }
	public virtual object preferredWidth { get; }
	public virtual object flexibleWidth { get; }
	public virtual object minHeight { get; }
	public virtual object preferredHeight { get; }
	public virtual object flexibleHeight { get; }
	public virtual object layoutPriority { get; }

	// Methods

	// RVA: 0x769F0B8
	private object get_input() { }

	// RVA: 0x769F2C8
	private object get_compositionString() { }

	// RVA: 0x769F3A8
	protected object .ctor() { }

	// RVA: 0x769F7C4
	protected object get_mesh() { }

	// RVA: 0x769F8A0
	protected object get_cachedInputTextGenerator() { }

	// RVA: 0x769F91C
	public object set_shouldHideMobileInput(object value) { }

	// RVA: 0x769F978
	public object get_shouldHideMobileInput() { }

	// RVA: 0x769FA38
	public virtual object set_shouldActivateOnSelect(object value) { }

	// RVA: 0x769FA40
	public virtual object get_shouldActivateOnSelect() { }

	// RVA: 0x769FAC0
	public virtual object get_text() { }

	// RVA: 0x769FAC8
	public virtual object set_text(object value) { }

	// RVA: 0x769FAD8
	public object get_innerText() { }

	// RVA: 0x769FAD0
	public object set_innerText(object value) { }

	// RVA: 0x769FF60
	public object SetTextWithoutNotify(object input) { }

	// RVA: 0x769FAE0
	private object SetText(object value, object sendCallback) { }

	// RVA: 0x76A00A8
	public object get_isFocused() { }

	// RVA: 0x76A00B0
	public object get_caretBlinkRate() { }

	// RVA: 0x76A00B8
	public object set_caretBlinkRate(object value) { }

	// RVA: 0x76A027C
	public object get_caretWidth() { }

	// RVA: 0x76A0284
	public object set_caretWidth(object value) { }

	// RVA: 0x76A03E4
	public object get_textComponent() { }

	// RVA: 0x76A03EC
	public object set_textComponent(object value) { }

	// RVA: 0x76A06F4
	public object get_placeholder() { }

	// RVA: 0x76A06FC
	public object set_placeholder(object value) { }

	// RVA: 0x76A0758
	public object get_caretColor() { }

	// RVA: 0x76A07D0
	public object set_caretColor(object value) { }

	// RVA: 0x76A0878
	public object get_customCaretColor() { }

	// RVA: 0x76A0880
	public object set_customCaretColor(object value) { }

	// RVA: 0x76A0928
	public object get_selectionColor() { }

	// RVA: 0x76A093C
	public object set_selectionColor(object value) { }

	// RVA: 0x76A09E4
	public object get_onEndEdit() { }

	// RVA: 0x76A09EC
	public object set_onEndEdit(object value) { }

	// RVA: 0x76A0A48
	public object get_onSubmit() { }

	// RVA: 0x76A0A50
	public object set_onSubmit(object value) { }

	// RVA: 0x76A0AAC
	public object get_onValueChange() { }

	// RVA: 0x76A0AB4
	public object set_onValueChange(object value) { }

	// RVA: 0x76A0B6C
	public object get_onValueChanged() { }

	// RVA: 0x76A0B10
	public object set_onValueChanged(object value) { }

	// RVA: 0x76A0B74
	public object get_onValidateInput() { }

	// RVA: 0x76A0B7C
	public object set_onValidateInput(object value) { }

	// RVA: 0x76A0BD8
	public object get_characterLimit() { }

	// RVA: 0x76A0BE0
	public object set_characterLimit(object value) { }

	// RVA: 0x76A0CC0
	public object get_contentType() { }

	// RVA: 0x76A0CC8
	public object set_contentType(object value) { }

	// RVA: 0x76A0F58
	public object get_lineType() { }

	// RVA: 0x76A0F60
	public object set_lineType(object value) { }

	// RVA: 0x76A10B8
	public object get_inputType() { }

	// RVA: 0x76A10C0
	public object set_inputType(object value) { }

	// RVA: 0x76A1160
	public object get_touchScreenKeyboard() { }

	// RVA: 0x76A1168
	public object get_keyboardType() { }

	// RVA: 0x76A1170
	public object set_keyboardType(object value) { }

	// RVA: 0x76A11F8
	public object get_characterValidation() { }

	// RVA: 0x76A1200
	public object set_characterValidation(object value) { }

	// RVA: 0x76A1288
	public object get_readOnly() { }

	// RVA: 0x76A1290
	public object set_readOnly(object value) { }

	// RVA: 0x76A1298
	public object get_multiLine() { }

	// RVA: 0x76A12AC
	public object get_asteriskChar() { }

	// RVA: 0x76A12B4
	public object set_asteriskChar(object value) { }

	// RVA: 0x76A134C
	public object get_wasCanceled() { }

	// RVA: 0x76A1354
	protected object ClampPos(object pos) { }

	// RVA: 0x76A1394
	protected object get_caretPositionInternal() { }

	// RVA: 0x76A13CC
	protected object set_caretPositionInternal(object value) { }

	// RVA: 0x76A140C
	protected object get_caretSelectPositionInternal() { }

	// RVA: 0x76A1444
	protected object set_caretSelectPositionInternal(object value) { }

	// RVA: 0x76A1484
	private object get_hasSelection() { }

	// RVA: 0x76A14E4
	public object get_caretPosition() { }

	// RVA: 0x76A151C
	public object set_caretPosition(object value) { }

	// RVA: 0x76A16EC
	public object get_selectionAnchorPosition() { }

	// RVA: 0x76A15DC
	public object set_selectionAnchorPosition(object value) { }

	// RVA: 0x76A1724
	public object get_selectionFocusPosition() { }

	// RVA: 0x76A1664
	public object set_selectionFocusPosition(object value) { }

	// RVA: 0x76A175C
	protected override object OnEnable() { }

	// RVA: 0x76A1A8C
	protected override object OnDisable() { }

	// RVA: 0x76A2090
	protected override object OnDestroy() { }

	// RVA: 0x76A2100
	private object CaretBlink() { }

	// RVA: 0x76A2198
	private object SetCaretVisible() { }

	// RVA: 0x76A01D0
	private object SetCaretActive() { }

	// RVA: 0x76A225C
	private object UpdateCaretMaterial() { }

	// RVA: 0x76A23E4
	protected object OnFocus() { }

	// RVA: 0x76A2428
	protected object SelectAll() { }

	// RVA: 0x76A246C
	public object MoveTextEnd(object shift) { }

	// RVA: 0x76A2528
	public object MoveTextStart(object shift) { }

	// RVA: 0x76A25FC
	private static object get_clipboard() { }

	// RVA: 0x76A2604
	private static object set_clipboard(object value) { }

	// RVA: 0x76A260C
	private object TouchScreenKeyboardShouldBeUsed() { }

	// RVA: 0x76A26F8
	private object InPlaceEditing() { }

	// RVA: 0x76A273C
	private object InPlaceEditingChanged() { }

	// RVA: 0x76A27E8
	private object GetInternalSelection() { }

	// RVA: 0x76A28E8
	private object UpdateKeyboardCaret() { }

	// RVA: 0x76A29D4
	private object UpdateCaretFromKeyboard() { }

	// RVA: 0x76A2B30
	protected virtual object LateUpdate() { }

	// RVA: 0x76A4990
	public object ScreenToLocal(object screen) { }

	// RVA: 0x76A4E00
	private object GetUnclampedCharacterLineFromPosition(object pos, object generator) { }

	// RVA: 0x76A5088
	protected object GetCharacterIndexFromPosition(object pos) { }

	// RVA: 0x76A55B4
	private object MayDrag(object eventData) { }

	// RVA: 0x76A56F8
	public virtual object OnBeginDrag(object eventData) { }

	// RVA: 0x76A5724
	public virtual object OnDrag(object eventData) { }

	// RVA: 0x76A59E4
	private object MouseDragOutsideRect(object eventData) { }

	// RVA: 0x76A5A80
	public virtual object OnEndDrag(object eventData) { }

	// RVA: 0x76A5AA8
	public override object OnPointerDown(object eventData) { }

	// RVA: 0x76A5D3C
	protected object KeyPressed(object evt) { }

	// RVA: 0x76A6E20
	private object IsValidChar(object c) { }

	// RVA: 0x76A6EBC
	public object ProcessEvent(object e) { }

	// RVA: 0x76A6EC0
	public virtual object OnUpdateSelected(object eventData) { }

	// RVA: 0x76A666C
	private object GetSelectedString() { }

	// RVA: 0x76A7194
	private object FindtNextWordBegin() { }

	// RVA: 0x76A6C40
	private object MoveRight(object shift, object ctrl) { }

	// RVA: 0x76A7290
	private object FindtPrevWordBegin() { }

	// RVA: 0x76A6A70
	private object MoveLeft(object shift, object ctrl) { }

	// RVA: 0x76A7368
	private object DetermineCharacterLine(object charPos, object generator) { }

	// RVA: 0x76A74B4
	private object LineUpCharacterPosition(object originalPos, object goToFirstChar) { }

	// RVA: 0x76A7AE0
	private object LineDownCharacterPosition(object originalPos, object goToLastChar) { }

	// RVA: 0x76A6E18
	private object MoveDown(object shift) { }

	// RVA: 0x76A80BC
	private object MoveDown(object shift, object goToLastChar) { }

	// RVA: 0x76A6E10
	private object MoveUp(object shift) { }

	// RVA: 0x76A82A4
	private object MoveUp(object shift, object goToFirstChar) { }

	// RVA: 0x76A675C
	private object Delete() { }

	// RVA: 0x76A652C
	private object ForwardSpace() { }

	// RVA: 0x76A6324
	private object Backspace() { }

	// RVA: 0x76A844C
	private object Insert(object c) { }

	// RVA: 0x76A6A0C
	private object UpdateTouchKeyboardFromEditChanges() { }

	// RVA: 0x76A48E8
	private object SendOnValueChangedAndUpdateLabel() { }

	// RVA: 0x76A0018
	private object SendOnValueChanged() { }

	// RVA: 0x76A8690
	protected object SendOnEndEdit() { }

	// RVA: 0x76A40FC
	protected object SendOnSubmit() { }

	// RVA: 0x76A8720
	protected virtual object Append(object input) { }

	// RVA: 0x76A8814
	protected virtual object Append(object input) { }

	// RVA: 0x76A8B34
	protected virtual object GetVisualText() { }

	// RVA: 0x76A8B3C
	protected virtual object UpdateLabel() { }

	// RVA: 0x76AA3D0
	private object IsSelectionVisible() { }

	// RVA: 0x76AA4BC
	private static object GetLineStartPosition(object gen, object line) { }

	// RVA: 0x76A53D0
	private static object GetLineEndPosition(object gen, object line) { }

	// RVA: 0x76A9174
	private object SetDrawRangeToContainCaretPosition(object caretPos) { }

	// RVA: 0x76AA670
	public object ForceLabelUpdate() { }

	// RVA: 0x76A035C
	private object MarkGeometryAsDirty() { }

	// RVA: 0x76AA6B4
	public virtual object Rebuild(object update) { }

	// RVA: 0x76AADB8
	public virtual object LayoutComplete() { }

	// RVA: 0x76AADBC
	public virtual object GraphicUpdateComplete() { }

	// RVA: 0x76AA6C4
	private object UpdateGeometry() { }

	// RVA: 0x76A392C
	private object AssignPositioningIfNeeded() { }

	// RVA: 0x76AADC0
	private object OnFillVBO(object vbo) { }

	// RVA: 0x76AB068
	private object GenerateCaret(object vbo, object roundingOffset) { }

	// RVA: 0x76AC204
	private object CreateCursorVerts() { }

	// RVA: 0x76AB9C8
	private object GenerateHighlight(object vbo, object roundingOffset) { }

	// RVA: 0x76A418C
	protected object Validate(object text, object pos, object ch) { }

	// RVA: 0x76AC350
	public object ActivateInputField() { }

	// RVA: 0x76A3408
	private object ActivateInputFieldInternal() { }

	// RVA: 0x76AC510
	public override object OnSelect(object eventData) { }

	// RVA: 0x76AC570
	public virtual object OnPointerClick(object eventData) { }

	// RVA: 0x76A1D6C
	public object DeactivateInputField() { }

	// RVA: 0x76AC598
	public override object OnDeselect(object eventData) { }

	// RVA: 0x76AC5C8
	public virtual object OnSubmit(object eventData) { }

	// RVA: 0x76A0E4C
	private object EnforceContentType() { }

	// RVA: 0x769F6C8
	private object EnforceTextHOverflow() { }

	// RVA: 0x76A105C
	private object SetToCustomIfContentTypeIsNot(object allowedContentTypes) { }

	// RVA: 0x76A1148
	private object SetToCustom() { }

	// RVA: 0x76AC648
	protected override object DoStateTransition(object state, object instant) { }

	// RVA: 0x76AC674
	public virtual object CalculateLayoutInputHorizontal() { }

	// RVA: 0x76AC678
	public virtual object CalculateLayoutInputVertical() { }

	// RVA: 0x76AC67C
	public virtual object get_minWidth() { }

	// RVA: 0x76AC684
	public virtual object get_preferredWidth() { }

	// RVA: 0x76AC834
	public virtual object get_flexibleWidth() { }

	// RVA: 0x76AC83C
	public virtual object get_minHeight() { }

	// RVA: 0x76AC844
	public virtual object get_preferredHeight() { }

	// RVA: 0x76AC9EC
	public virtual object get_flexibleHeight() { }

	// RVA: 0x76AC9F4
	public virtual object get_layoutPriority() { }

	// RVA: 0x76AC9FC
	private static object .cctor() { }

	// RVA: 0x76ACA98
	private object UnityEngine.UI.ICanvasElement.get_transform() { }

}

// Namespace: 
public enum AspectMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object WidthControlsHeight;
	public const object HeightControlsWidth;
	public const object FitInParent;
	public const object EnvelopeParent;
}

// Namespace: UnityEngine.UI
public class AspectRatioFitter
{

	// Fields
	private object m_AspectMode; // 0x18
	private object m_AspectRatio; // 0x1C
	private object m_Rect; // 0x20
	private object m_DelayedSetDirty; // 0x28
	private object m_DoesParentExist; // 0x29
	private object m_Tracker; // 0x2A

	// Properties
	public object aspectMode { get; set; }
	public object aspectRatio { get; set; }
	private object rectTransform { get; }

	// Methods

	// RVA: 0x76AD248
	public object get_aspectMode() { }

	// RVA: 0x76AD250
	public object set_aspectMode(object value) { }

	// RVA: 0x76AD2CC
	public object get_aspectRatio() { }

	// RVA: 0x76AD2D4
	public object set_aspectRatio(object value) { }

	// RVA: 0x76AD358
	private object get_rectTransform() { }

	// RVA: 0x76AD428
	protected object .ctor() { }

	// RVA: 0x76AD438
	protected override object OnEnable() { }

	// RVA: 0x76AD5B8
	protected override object Start() { }

	// RVA: 0x76AD784
	protected override object OnDisable() { }

	// RVA: 0x76ADE08
	protected override object OnTransformParentChanged() { }

	// RVA: 0x76ADF88
	protected virtual object Update() { }

	// RVA: 0x76ADFA0
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x76ADFA4
	private object UpdateRect() { }

	// RVA: 0x76AE864
	private object GetSizeDeltaToProduceSize(object size, object axis) { }

	// RVA: 0x76AE654
	private object GetParentSize() { }

	// RVA: 0x76AEA78
	public virtual object SetLayoutHorizontal() { }

	// RVA: 0x76AEA7C
	public virtual object SetLayoutVertical() { }

	// RVA: 0x76AD2C8
	protected object SetDirty() { }

	// RVA: 0x76AD618
	public object IsComponentValidOnObject() { }

	// RVA: 0x76AD75C
	public object IsAspectModeValid() { }

	// RVA: 0x76AEA80
	private object DoesParentExists() { }

}

// Namespace: 
public enum ScaleMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ConstantPixelSize;
	public const object ScaleWithScreenSize;
	public const object ConstantPhysicalSize;
}

// Namespace: 
public enum ScreenMatchMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MatchWidthOrHeight;
	public const object Expand;
	public const object Shrink;
}

// Namespace: 
public enum Unit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Centimeters;
	public const object Millimeters;
	public const object Inches;
	public const object Points;
	public const object Picas;
}

// Namespace: UnityEngine.UI
public class CanvasScaler
{

	// Fields
	private object m_UiScaleMode; // 0x18
	protected object m_ReferencePixelsPerUnit; // 0x1C
	protected object m_ScaleFactor; // 0x20
	protected object m_ReferenceResolution; // 0x24
	protected object m_ScreenMatchMode; // 0x2C
	protected object m_MatchWidthOrHeight; // 0x30
	private const object kLogBase;
	protected object m_PhysicalUnit; // 0x34
	protected object m_FallbackScreenDPI; // 0x38
	protected object m_DefaultSpriteDPI; // 0x3C
	protected object m_DynamicPixelsPerUnit; // 0x40
	private object m_Canvas; // 0x48
	private object m_PrevScaleFactor; // 0x50
	private object m_PrevReferencePixelsPerUnit; // 0x54
	protected object m_PresetInfoIsWorld; // 0x58

	// Properties
	public object uiScaleMode { get; set; }
	public object referencePixelsPerUnit { get; set; }
	public object scaleFactor { get; set; }
	public object referenceResolution { get; set; }
	public object screenMatchMode { get; set; }
	public object matchWidthOrHeight { get; set; }
	public object physicalUnit { get; set; }
	public object fallbackScreenDPI { get; set; }
	public object defaultSpriteDPI { get; set; }
	public object dynamicPixelsPerUnit { get; set; }

	// Methods

	// RVA: 0x76AEA88
	public object get_uiScaleMode() { }

	// RVA: 0x76AEA90
	public object set_uiScaleMode(object value) { }

	// RVA: 0x76AEA98
	public object get_referencePixelsPerUnit() { }

	// RVA: 0x76AEAA0
	public object set_referencePixelsPerUnit(object value) { }

	// RVA: 0x76AEAA8
	public object get_scaleFactor() { }

	// RVA: 0x76AEAB0
	public object set_scaleFactor(object value) { }

	// RVA: 0x76AEACC
	public object get_referenceResolution() { }

	// RVA: 0x76AEAD4
	public object set_referenceResolution(object value) { }

	// RVA: 0x76AEB60
	public object get_screenMatchMode() { }

	// RVA: 0x76AEB68
	public object set_screenMatchMode(object value) { }

	// RVA: 0x76AEB70
	public object get_matchWidthOrHeight() { }

	// RVA: 0x76AEB78
	public object set_matchWidthOrHeight(object value) { }

	// RVA: 0x76AEB80
	public object get_physicalUnit() { }

	// RVA: 0x76AEB88
	public object set_physicalUnit(object value) { }

	// RVA: 0x76AEB90
	public object get_fallbackScreenDPI() { }

	// RVA: 0x76AEB98
	public object set_fallbackScreenDPI(object value) { }

	// RVA: 0x76AEBA0
	public object get_defaultSpriteDPI() { }

	// RVA: 0x76AEBA8
	public object set_defaultSpriteDPI(object value) { }

	// RVA: 0x76AEBBC
	public object get_dynamicPixelsPerUnit() { }

	// RVA: 0x76AEBC4
	public object set_dynamicPixelsPerUnit(object value) { }

	// RVA: 0x76AEBCC
	protected object .ctor() { }

	// RVA: 0x76AEC14
	protected override object OnEnable() { }

	// RVA: 0x76AECF0
	private object Canvas_preWillRenderCanvases() { }

	// RVA: 0x76AED34
	protected override object OnDisable() { }

	// RVA: 0x76AEF0C
	protected virtual object Handle() { }

	// RVA: 0x76AF0AC
	protected virtual object HandleWorldCanvas() { }

	// RVA: 0x76AF14C
	protected virtual object HandleConstantPixelSize() { }

	// RVA: 0x76AF1EC
	protected virtual object HandleScaleWithScreenSize() { }

	// RVA: 0x76AF4F8
	protected virtual object HandleConstantPhysicalSize() { }

	// RVA: 0x76AEE44
	protected object SetScaleFactor(object scaleFactor) { }

	// RVA: 0x76AEEA8
	protected object SetReferencePixelsPerUnit(object referencePixelsPerUnit) { }

}

// Namespace: 
public enum FitMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unconstrained;
	public const object MinSize;
	public const object PreferredSize;
}

// Namespace: UnityEngine.UI
public class ContentSizeFitter
{

	// Fields
	protected object m_HorizontalFit; // 0x18
	protected object m_VerticalFit; // 0x1C
	private object m_Rect; // 0x20
	private object m_Tracker; // 0x28

	// Properties
	public object horizontalFit { get; set; }
	public object verticalFit { get; set; }
	private object rectTransform { get; }

	// Methods

	// RVA: 0x76AF5C4
	public object get_horizontalFit() { }

	// RVA: 0x76AF5CC
	public object set_horizontalFit(object value) { }

	// RVA: 0x76AF77C
	public object get_verticalFit() { }

	// RVA: 0x76AF784
	public object set_verticalFit(object value) { }

	// RVA: 0x76AF7FC
	private object get_rectTransform() { }

	// RVA: 0x76AF8CC
	protected object .ctor() { }

	// RVA: 0x76AF8D4
	protected override object OnEnable() { }

	// RVA: 0x76AF8FC
	protected override object OnDisable() { }

	// RVA: 0x76AFA04
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x76AFA08
	private object HandleSelfFittingAlongAxis(object axis) { }

	// RVA: 0x76AFD4C
	public virtual object SetLayoutHorizontal() { }

	// RVA: 0x76AFD7C
	public virtual object SetLayoutVertical() { }

	// RVA: 0x76AF644
	protected object SetDirty() { }

}

// Namespace: 
public enum Corner
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UpperLeft;
	public const object UpperRight;
	public const object LowerLeft;
	public const object LowerRight;
}

// Namespace: 
public enum Axis
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Horizontal;
	public const object Vertical;
}

// Namespace: 
public enum Constraint
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Flexible;
	public const object FixedColumnCount;
	public const object FixedRowCount;
}

// Namespace: UnityEngine.UI
public class GridLayoutGroup
{

	// Fields
	protected object m_StartCorner; // 0x58
	protected object m_StartAxis; // 0x5C
	protected object m_CellSize; // 0x60
	protected object m_Spacing; // 0x68
	protected object m_Constraint; // 0x70
	protected object m_ConstraintCount; // 0x74

	// Properties
	public object startCorner { get; set; }
	public object startAxis { get; set; }
	public object cellSize { get; set; }
	public object spacing { get; set; }
	public object constraint { get; set; }
	public object constraintCount { get; set; }

	// Methods

	// RVA: 0x76AFD84
	public object get_startCorner() { }

	// RVA: 0x76AFD8C
	public object set_startCorner(object value) { }

	// RVA: 0x76AFDF0
	public object get_startAxis() { }

	// RVA: 0x76AFDF8
	public object set_startAxis(object value) { }

	// RVA: 0x76AFE5C
	public object get_cellSize() { }

	// RVA: 0x76AFE64
	public object set_cellSize(object value) { }

	// RVA: 0x76AFED8
	public object get_spacing() { }

	// RVA: 0x76AFEE0
	public object set_spacing(object value) { }

	// RVA: 0x76AFF54
	public object get_constraint() { }

	// RVA: 0x76AFF5C
	public object set_constraint(object value) { }

	// RVA: 0x76AFFC0
	public object get_constraintCount() { }

	// RVA: 0x76AFFC8
	public object set_constraintCount(object value) { }

	// RVA: 0x76B0030
	protected object .ctor() { }

	// RVA: 0x76B01DC
	public override object CalculateLayoutInputHorizontal() { }

	// RVA: 0x76B0A78
	public override object CalculateLayoutInputVertical() { }

	// RVA: 0x76B0E60
	public override object SetLayoutHorizontal() { }

	// RVA: 0x76B1924
	public override object SetLayoutVertical() { }

	// RVA: 0x76B0E68
	private object SetCellsAlongAxis(object axis) { }

}

// Namespace: UnityEngine.UI
public class HorizontalLayoutGroup
{

	// Methods

	// RVA: 0x76B1C48
	protected object .ctor() { }

	// RVA: 0x76B1C60
	public override object CalculateLayoutInputHorizontal() { }

	// RVA: 0x76B2164
	public override object CalculateLayoutInputVertical() { }

	// RVA: 0x76B2170
	public override object SetLayoutHorizontal() { }

	// RVA: 0x76B2A0C
	public override object SetLayoutVertical() { }

}

// Namespace: UnityEngine.UI
public abstract class HorizontalOrVerticalLayoutGroup
{

	// Fields
	protected object m_Spacing; // 0x58
	protected object m_ChildForceExpandWidth; // 0x5C
	protected object m_ChildForceExpandHeight; // 0x5D
	protected object m_ChildControlWidth; // 0x5E
	protected object m_ChildControlHeight; // 0x5F
	protected object m_ChildScaleWidth; // 0x60
	protected object m_ChildScaleHeight; // 0x61
	protected object m_ReverseArrangement; // 0x62

	// Properties
	public object spacing { get; set; }
	public object childForceExpandWidth { get; set; }
	public object childForceExpandHeight { get; set; }
	public object childControlWidth { get; set; }
	public object childControlHeight { get; set; }
	public object childScaleWidth { get; set; }
	public object childScaleHeight { get; set; }
	public object reverseArrangement { get; set; }

	// Methods

	// RVA: 0x76B2A18
	public object get_spacing() { }

	// RVA: 0x76B2A20
	public object set_spacing(object value) { }

	// RVA: 0x76B2A8C
	public object get_childForceExpandWidth() { }

	// RVA: 0x76B2A94
	public object set_childForceExpandWidth(object value) { }

	// RVA: 0x76B2AF8
	public object get_childForceExpandHeight() { }

	// RVA: 0x76B2B00
	public object set_childForceExpandHeight(object value) { }

	// RVA: 0x76B2B64
	public object get_childControlWidth() { }

	// RVA: 0x76B2B6C
	public object set_childControlWidth(object value) { }

	// RVA: 0x76B2BD0
	public object get_childControlHeight() { }

	// RVA: 0x76B2BD8
	public object set_childControlHeight(object value) { }

	// RVA: 0x76B2C3C
	public object get_childScaleWidth() { }

	// RVA: 0x76B2C44
	public object set_childScaleWidth(object value) { }

	// RVA: 0x76B2CA8
	public object get_childScaleHeight() { }

	// RVA: 0x76B2CB0
	public object set_childScaleHeight(object value) { }

	// RVA: 0x76B2D14
	public object get_reverseArrangement() { }

	// RVA: 0x76B2D1C
	public object set_reverseArrangement(object value) { }

	// RVA: 0x76B1C8C
	protected object CalcAlongAxis(object axis, object isVertical) { }

	// RVA: 0x76B217C
	protected object SetChildrenAlongAxis(object axis, object isVertical) { }

	// RVA: 0x76B2D80
	private object GetChildSizes(object child, object axis, object controlSize, object childForceExpand, object min, object preferred, object flexible) { }

	// RVA: 0x76B1C54
	protected object .ctor() { }

}

// Namespace: UnityEngine.UI
public interface ILayoutElement
{

	// Properties
	public abstract object minWidth { get; }
	public abstract object preferredWidth { get; }
	public abstract object flexibleWidth { get; }
	public abstract object minHeight { get; }
	public abstract object preferredHeight { get; }
	public abstract object flexibleHeight { get; }
	public abstract object layoutPriority { get; }

	// Methods

	// RVA: -1
	public abstract object CalculateLayoutInputHorizontal() { }

	// RVA: -1
	public abstract object CalculateLayoutInputVertical() { }

	// RVA: -1
	public abstract object get_minWidth() { }

	// RVA: -1
	public abstract object get_preferredWidth() { }

	// RVA: -1
	public abstract object get_flexibleWidth() { }

	// RVA: -1
	public abstract object get_minHeight() { }

	// RVA: -1
	public abstract object get_preferredHeight() { }

	// RVA: -1
	public abstract object get_flexibleHeight() { }

	// RVA: -1
	public abstract object get_layoutPriority() { }

}

// Namespace: UnityEngine.UI
public interface ILayoutController
{

	// Methods

	// RVA: -1
	public abstract object SetLayoutHorizontal() { }

	// RVA: -1
	public abstract object SetLayoutVertical() { }

}

// Namespace: UnityEngine.UI
public interface ILayoutGroup
{
}

// Namespace: UnityEngine.UI
public interface ILayoutSelfController
{
}

// Namespace: UnityEngine.UI
public interface ILayoutIgnorer
{

	// Properties
	public abstract object ignoreLayout { get; }

	// Methods

	// RVA: -1
	public abstract object get_ignoreLayout() { }

}

// Namespace: UnityEngine.UI
public class LayoutElement
{

	// Fields
	private object m_IgnoreLayout; // 0x18
	private object m_MinWidth; // 0x1C
	private object m_MinHeight; // 0x20
	private object m_PreferredWidth; // 0x24
	private object m_PreferredHeight; // 0x28
	private object m_FlexibleWidth; // 0x2C
	private object m_FlexibleHeight; // 0x30
	private object m_LayoutPriority; // 0x34

	// Properties
	public virtual object ignoreLayout { get; set; }
	public virtual object minWidth { get; set; }
	public virtual object minHeight { get; set; }
	public virtual object preferredWidth { get; set; }
	public virtual object preferredHeight { get; set; }
	public virtual object flexibleWidth { get; set; }
	public virtual object flexibleHeight { get; set; }
	public virtual object layoutPriority { get; set; }

	// Methods

	// RVA: 0x76B3520
	public virtual object get_ignoreLayout() { }

	// RVA: 0x76B3528
	public virtual object set_ignoreLayout(object value) { }

	// RVA: 0x76B3674
	public virtual object CalculateLayoutInputHorizontal() { }

	// RVA: 0x76B3678
	public virtual object CalculateLayoutInputVertical() { }

	// RVA: 0x76B367C
	public virtual object get_minWidth() { }

	// RVA: 0x76B3684
	public virtual object set_minWidth(object value) { }

	// RVA: 0x76B3708
	public virtual object get_minHeight() { }

	// RVA: 0x76B3710
	public virtual object set_minHeight(object value) { }

	// RVA: 0x76B3794
	public virtual object get_preferredWidth() { }

	// RVA: 0x76B379C
	public virtual object set_preferredWidth(object value) { }

	// RVA: 0x76B3820
	public virtual object get_preferredHeight() { }

	// RVA: 0x76B3828
	public virtual object set_preferredHeight(object value) { }

	// RVA: 0x76B38AC
	public virtual object get_flexibleWidth() { }

	// RVA: 0x76B38B4
	public virtual object set_flexibleWidth(object value) { }

	// RVA: 0x76B3938
	public virtual object get_flexibleHeight() { }

	// RVA: 0x76B3940
	public virtual object set_flexibleHeight(object value) { }

	// RVA: 0x76B39C4
	public virtual object get_layoutPriority() { }

	// RVA: 0x76B39CC
	public virtual object set_layoutPriority(object value) { }

	// RVA: 0x76B3A44
	protected object .ctor() { }

	// RVA: 0x76B3A64
	protected override object OnEnable() { }

	// RVA: 0x76B3A8C
	protected override object OnTransformParentChanged() { }

	// RVA: 0x76B3A90
	protected override object OnDisable() { }

	// RVA: 0x76B3AB8
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x76B3ABC
	protected override object OnBeforeTransformParentChanged() { }

	// RVA: 0x76B35A0
	protected object SetDirty() { }

}

// Namespace: 
private sealed class <DelayedSetDirty>d__56
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object rectTransform; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x76B42E0
	public object .ctor(object <>1__state) { }

	// RVA: 0x76B430C
	private object System.IDisposable.Dispose() { }

	// RVA: 0x76B4310
	private object MoveNext() { }

	// RVA: 0x76B43B0
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x76B43B8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x76B43F8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: UnityEngine.UI
public abstract class LayoutGroup
{

	// Fields
	protected object m_Padding; // 0x18
	protected object m_ChildAlignment; // 0x20
	private object m_Rect; // 0x28
	protected object m_Tracker; // 0x30
	private object m_TotalMinSize; // 0x34
	private object m_TotalPreferredSize; // 0x3C
	private object m_TotalFlexibleSize; // 0x44
	private object m_RectChildren; // 0x50

	// Properties
	public object padding { get; set; }
	public object childAlignment { get; set; }
	protected object rectTransform { get; }
	protected object rectChildren { get; }
	public virtual object minWidth { get; }
	public virtual object preferredWidth { get; }
	public virtual object flexibleWidth { get; }
	public virtual object minHeight { get; }
	public virtual object preferredHeight { get; }
	public virtual object flexibleHeight { get; }
	public virtual object layoutPriority { get; }
	private object isRootLayoutGroup { get; }

	// Methods

	// RVA: 0x76B3AC0
	public object get_padding() { }

	// RVA: 0x76B3AC8
	public object set_padding(object value) { }

	// RVA: 0x76B3B2C
	public object get_childAlignment() { }

	// RVA: 0x76B3B34
	public object set_childAlignment(object value) { }

	// RVA: 0x76B0D90
	protected object get_rectTransform() { }

	// RVA: 0x76B3B98
	protected object get_rectChildren() { }

	// RVA: 0x76B03D0
	public virtual object CalculateLayoutInputHorizontal() { }

	// RVA: -1
	public abstract object CalculateLayoutInputVertical() { }

	// RVA: 0x76B3BA0
	public virtual object get_minWidth() { }

	// RVA: 0x76B3BA8
	public virtual object get_preferredWidth() { }

	// RVA: 0x76B3BB0
	public virtual object get_flexibleWidth() { }

	// RVA: 0x76B3BB8
	public virtual object get_minHeight() { }

	// RVA: 0x76B3BC0
	public virtual object get_preferredHeight() { }

	// RVA: 0x76B3BC8
	public virtual object get_flexibleHeight() { }

	// RVA: 0x76B3BD0
	public virtual object get_layoutPriority() { }

	// RVA: -1
	public abstract object SetLayoutHorizontal() { }

	// RVA: -1
	public abstract object SetLayoutVertical() { }

	// RVA: 0x76B00A8
	protected object .ctor() { }

	// RVA: 0x76B3BD8
	protected override object OnEnable() { }

	// RVA: 0x76B3EC0
	protected override object OnDisable() { }

	// RVA: 0x76B3FC8
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x76B349C
	protected object GetTotalMinSize(object axis) { }

	// RVA: 0x76B33AC
	protected object GetTotalPreferredSize(object axis) { }

	// RVA: 0x76B3424
	protected object GetTotalFlexibleSize(object axis) { }

	// RVA: 0x76B192C
	protected object GetStartOffset(object axis, object requiredSpaceWithoutPadding) { }

	// RVA: 0x76B2EA8
	protected object GetAlignmentOnAxis(object axis) { }

	// RVA: 0x76B09E0
	protected object SetLayoutInputForAxis(object totalMin, object totalPreferred, object totalFlexible, object axis) { }

	// RVA: 0x76B3FCC
	protected object SetChildAlongAxis(object rect, object axis, object pos) { }

	// RVA: 0x76B3154
	protected object SetChildAlongAxisWithScale(object rect, object axis, object pos, object scaleFactor) { }

	// RVA: 0x76B1B68
	protected object SetChildAlongAxis(object rect, object axis, object pos, object size) { }

	// RVA: 0x76B2EE0
	protected object SetChildAlongAxisWithScale(object rect, object axis, object pos, object size, object scaleFactor) { }

	// RVA: 0x76B40A4
	private object get_isRootLayoutGroup() { }

	// RVA: 0x76B4230
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x76B4270
	protected virtual object OnTransformChildrenChanged() { }

	// RVA: -1
	protected object SetProperty(object currentValue, object newValue) { }

	// RVA: 0x76B3C00
	protected object SetDirty() { }

	// RVA: 0x76B4274
	private object DelayedSetDirty(object rectTransform) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__10_0; // 0x8
	public static object <>9__12_0; // 0x10
	public static object <>9__12_1; // 0x18
	public static object <>9__12_2; // 0x20
	public static object <>9__12_3; // 0x28

	// Methods

	// RVA: 0x76B5AE4
	private static object .cctor() { }

	// RVA: 0x76B5B44
	public object .ctor() { }

	// RVA: 0x76B5B4C
	internal object <.cctor>b__5_0() { }

	// RVA: 0x76B5BA4
	internal object <.cctor>b__5_1(object x) { }

	// RVA: 0x76B5BC8
	internal object <StripDisabledBehavioursFromList>b__10_0(object e) { }

	// RVA: 0x76B5C5C
	internal object <Rebuild>b__12_0(object e) { }

	// RVA: 0x76B5D54
	internal object <Rebuild>b__12_1(object e) { }

	// RVA: 0x76B5E4C
	internal object <Rebuild>b__12_2(object e) { }

	// RVA: 0x76B5F48
	internal object <Rebuild>b__12_3(object e) { }

}

// Namespace: UnityEngine.UI
public class LayoutRebuilder
{

	// Fields
	private object m_ToRebuild; // 0x8
	private object m_CachedHashFromTransform; // 0x10
	private static object s_Rebuilders; // 0x0

	// Properties
	public object transform { get; }

	// Methods

	// RVA: 0x76B4400
	private object Initialize(object controller) { }

	// RVA: 0x76B445C
	private object Clear() { }

	// RVA: 0x76B4468
	private static object .cctor() { }

	// RVA: 0x76B4648
	private static object ReapplyDrivenProperties(object driven) { }

	// RVA: 0x76B46C8
	public object get_transform() { }

	// RVA: 0x76B46D0
	public object IsDestroyed() { }

	// RVA: 0x76B473C
	private static object StripDisabledBehavioursFromList(object components) { }

	// RVA: 0x76B485C
	public static object ForceRebuildLayoutImmediate(object layoutRoot) { }

	// RVA: 0x76B499C
	public object Rebuild(object executing) { }

	// RVA: 0x76B4FD4
	private object PerformLayoutControl(object rect, object action) { }

	// RVA: 0x76B4C98
	private object PerformLayoutCalculation(object rect, object action) { }

	// RVA: 0x76AD88C
	public static object MarkLayoutForRebuild(object rect) { }

	// RVA: 0x76B54B4
	private static object ValidController(object layoutRoot, object comps) { }

	// RVA: 0x76B5720
	private static object MarkLayoutRootForRebuild(object controller) { }

	// RVA: 0x76B58FC
	public object LayoutComplete() { }

	// RVA: 0x76B59A8
	public object GraphicUpdateComplete() { }

	// RVA: 0x76B59AC
	public override object GetHashCode() { }

	// RVA: 0x76B59B4
	public override object Equals(object obj) { }

	// RVA: 0x76B5A38
	public override object ToString() { }

	// RVA: 0x76B5ADC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8
	public static object <>9__4_0; // 0x10
	public static object <>9__4_1; // 0x18
	public static object <>9__5_0; // 0x20
	public static object <>9__6_0; // 0x28
	public static object <>9__7_0; // 0x30
	public static object <>9__7_1; // 0x38
	public static object <>9__8_0; // 0x40

	// Methods

	// RVA: 0x76B6BC8
	private static object .cctor() { }

	// RVA: 0x76B6C28
	public object .ctor() { }

	// RVA: 0x76B6C30
	internal object <GetMinWidth>b__3_0(object e) { }

	// RVA: 0x76B6D10
	internal object <GetPreferredWidth>b__4_0(object e) { }

	// RVA: 0x76B6DF0
	internal object <GetPreferredWidth>b__4_1(object e) { }

	// RVA: 0x76B6ED0
	internal object <GetFlexibleWidth>b__5_0(object e) { }

	// RVA: 0x76B6FB0
	internal object <GetMinHeight>b__6_0(object e) { }

	// RVA: 0x76B7090
	internal object <GetPreferredHeight>b__7_0(object e) { }

	// RVA: 0x76B7170
	internal object <GetPreferredHeight>b__7_1(object e) { }

	// RVA: 0x76B7250
	internal object <GetFlexibleHeight>b__8_0(object e) { }

}

// Namespace: UnityEngine.UI
public static class LayoutUtility
{

	// Methods

	// RVA: 0x76AFD34
	public static object GetMinSize(object rect, object axis) { }

	// RVA: 0x76AFD40
	public static object GetPreferredSize(object rect, object axis) { }

	// RVA: 0x76B3514
	public static object GetFlexibleSize(object rect, object axis) { }

	// RVA: 0x76B6150
	public static object GetMinWidth(object rect) { }

	// RVA: 0x76B641C
	public static object GetPreferredWidth(object rect) { }

	// RVA: 0x76B66E8
	public static object GetFlexibleWidth(object rect) { }

	// RVA: 0x76B6044
	public static object GetMinHeight(object rect) { }

	// RVA: 0x76B625C
	public static object GetPreferredHeight(object rect) { }

	// RVA: 0x76B65DC
	public static object GetFlexibleHeight(object rect) { }

	// RVA: 0x76B67F4
	public static object GetLayoutProperty(object rect, object property, object defaultValue) { }

	// RVA: 0x76B6814
	public static object GetLayoutProperty(object rect, object property, object defaultValue, object source) { }

}

// Namespace: UnityEngine.UI
public class VerticalLayoutGroup
{

	// Methods

	// RVA: 0x76B7330
	protected object .ctor() { }

	// RVA: 0x76B733C
	public override object CalculateLayoutInputHorizontal() { }

	// RVA: 0x76B7368
	public override object CalculateLayoutInputVertical() { }

	// RVA: 0x76B7374
	public override object SetLayoutHorizontal() { }

	// RVA: 0x76B7380
	public override object SetLayoutVertical() { }

}

// Namespace: UnityEngine.UI
public class Mask
{

	// Fields
	private object m_RectTransform; // 0x18
	private object m_ShowMaskGraphic; // 0x20
	private object m_BlockMaskPopInstruction; // 0x21
	private object m_Graphic; // 0x28
	private object m_MaskMaterial; // 0x30
	private object m_UnmaskMaterial; // 0x38

	// Properties
	public object rectTransform { get; }
	public object showMaskGraphic { get; set; }
	public object blockMaskPopInstruction { get; set; }
	public object graphic { get; }

	// Methods

	// RVA: 0x76B738C
	public object get_rectTransform() { }

	// RVA: 0x76B73FC
	public object get_showMaskGraphic() { }

	// RVA: 0x76B7404
	public object set_showMaskGraphic(object value) { }

	// RVA: 0x76B75F0
	public object get_blockMaskPopInstruction() { }

	// RVA: 0x76B75F8
	public object set_blockMaskPopInstruction(object value) { }

	// RVA: 0x76B7580
	public object get_graphic() { }

	// RVA: 0x76B7774
	protected object .ctor() { }

	// RVA: 0x76B7784
	public virtual object MaskEnabled() { }

	// RVA: 0x76B7890
	public virtual object OnSiblingGraphicEnabledDisabled() { }

	// RVA: 0x76B7894
	protected override object OnEnable() { }

	// RVA: 0x76B7EA8
	protected override object OnDisable() { }

	// RVA: 0x76B8258
	public virtual object IsRaycastLocationValid(object sp, object eventCamera) { }

	// RVA: 0x76B836C
	public virtual object GetModifiedMaterial(object baseMaterial) { }

}

// Namespace: 
public class CullStateChangedEvent
{

	// Methods

	// RVA: 0x76BA100
	public object .ctor() { }

}

// Namespace: UnityEngine.UI
public abstract class MaskableGraphic
{

	// Fields
	protected object m_ShouldRecalculateStencil; // 0x99
	protected object m_MaskMaterial; // 0xA0
	private object m_ParentMask; // 0xA8
	private object m_Maskable; // 0xB0
	private object m_IsMaskingGraphic; // 0xB1
	protected object m_IncludeForMasking; // 0xB2
	private object m_OnCullStateChanged; // 0xB8
	protected object m_ShouldRecalculate; // 0xC0
	protected object m_StencilValue; // 0xC4
	private readonly object m_Corners; // 0xC8

	// Properties
	public object onCullStateChanged { get; set; }
	public object maskable { get; set; }
	public object isMaskingGraphic { get; set; }
	private object rootCanvasRect { get; }

	// Methods

	// RVA: 0x76B8E60
	public object get_onCullStateChanged() { }

	// RVA: 0x76B8E68
	public object set_onCullStateChanged(object value) { }

	// RVA: 0x76B8E70
	public object get_maskable() { }

	// RVA: 0x76B8E78
	public object set_maskable(object value) { }

	// RVA: 0x76B8ED8
	public object get_isMaskingGraphic() { }

	// RVA: 0x76B7BA8
	public object set_isMaskingGraphic(object value) { }

	// RVA: 0x76B8EE0
	public virtual object GetModifiedMaterial(object baseMaterial) { }

	// RVA: 0x76B9004
	public virtual object Cull(object clipRect, object validRect) { }

	// RVA: 0x76B93E4
	private object UpdateCull(object cull) { }

	// RVA: 0x76B9500
	public virtual object SetClipRect(object clipRect, object validRect) { }

	// RVA: 0x76B9594
	public virtual object SetClipSoftness(object clipSoftness) { }

	// RVA: 0x76B95D8
	protected override object OnEnable() { }

	// RVA: 0x76B9870
	protected override object OnDisable() { }

	// RVA: 0x76B9944
	protected override object OnTransformParentChanged() { }

	// RVA: 0x76B99B8
	public virtual object ParentMaskStateChanged() { }

	// RVA: 0x76B99BC
	protected override object OnCanvasHierarchyChanged() { }

	// RVA: 0x76B90EC
	private object get_rootCanvasRect() { }

	// RVA: 0x76B9650
	private object UpdateClipParent() { }

	// RVA: 0x76B9F64
	public virtual object RecalculateClipping() { }

	// RVA: 0x76B9F68
	public virtual object RecalculateMasking() { }

	// RVA: 0x76BA004
	protected object .ctor() { }

	// RVA: 0x76BA158
	private object UnityEngine.UI.IClippable.get_gameObject() { }

}

// Namespace: UnityEngine.UI
public class MaskUtilities
{

	// Methods

	// RVA: 0x76BA160
	public static object Notify2DMaskStateChanged(object mask) { }

	// RVA: 0x76B7BBC
	public static object NotifyStencilStateChanged(object mask) { }

	// RVA: 0x76B8820
	public static object FindRootSortOverrideCanvas(object start) { }

	// RVA: 0x76B8A48
	public static object GetStencilDepth(object transform, object stopAfter) { }

	// RVA: 0x76BA450
	public static object IsDescendantOrSelf(object father, object child) { }

	// RVA: 0x76B9A30
	public static object GetRectMaskForClippable(object clippable) { }

	// RVA: 0x76BA634
	public static object GetRectMasksForClip(object clipper, object masks) { }

	// RVA: 0x76BAAE8
	public object .ctor() { }

}

// Namespace: UnityEngine.UI
public interface IMaterialModifier
{

	// Methods

	// RVA: -1
	public abstract object GetModifiedMaterial(object baseMaterial) { }

}

// Namespace: UnityEngine.UI
internal static class Misc
{

	// Methods

	// RVA: 0x76BAAF0
	public static object Destroy(object obj) { }

	// RVA: 0x76BAC8C
	public static object DestroyImmediate(object obj) { }

}

// Namespace: UnityEngine.UI
internal static class MultipleDisplayUtilities
{

	// Methods

	// RVA: 0x76BADE0
	public static object GetRelativeMousePositionForDrag(object eventData, object position) { }

	// RVA: 0x76BAE58
	public static object RelativeMouseAtScaled(object position) { }

}

// Namespace: 
public enum Mode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Horizontal;
	public const object Vertical;
	public const object Automatic;
	public const object Explicit;
}

// Namespace: UnityEngine.UI
public struct Navigation
{

	// Fields
	private object m_Mode; // 0xFFFFFFFFFFFFFFF8
	private object m_WrapAround; // 0xFFFFFFFFFFFFFFFC
	private object m_SelectOnUp; // 0x0
	private object m_SelectOnDown; // 0x8
	private object m_SelectOnLeft; // 0x10
	private object m_SelectOnRight; // 0x18

	// Properties
	public object mode { get; set; }
	public object wrapAround { get; set; }
	public object selectOnUp { get; set; }
	public object selectOnDown { get; set; }
	public object selectOnLeft { get; set; }
	public object selectOnRight { get; set; }
	public static object defaultNavigation { get; }

	// Methods

	// RVA: 0x76BB41C
	public object get_mode() { }

	// RVA: 0x76BB42C
	public object set_mode(object value) { }

	// RVA: 0x76BB43C
	public object get_wrapAround() { }

	// RVA: 0x76BB44C
	public object set_wrapAround(object value) { }

	// RVA: 0x76BB45C
	public object get_selectOnUp() { }

	// RVA: 0x76BB46C
	public object set_selectOnUp(object value) { }

	// RVA: 0x76BB47C
	public object get_selectOnDown() { }

	// RVA: 0x76BB48C
	public object set_selectOnDown(object value) { }

	// RVA: 0x76BB49C
	public object get_selectOnLeft() { }

	// RVA: 0x76BB4AC
	public object set_selectOnLeft(object value) { }

	// RVA: 0x76BB4BC
	public object get_selectOnRight() { }

	// RVA: 0x76BB4CC
	public object set_selectOnRight(object value) { }

	// RVA: 0x76BB4DC
	public static object get_defaultNavigation() { }

	// RVA: 0x76BB4FC
	public object Equals(object other) { }

}

// Namespace: UnityEngine.UI
public class RawImage
{

	// Fields
	private object m_Texture; // 0xD0
	private object m_UVRect; // 0xD8

	// Properties
	public override object mainTexture { get; }
	public object texture { get; set; }
	public object uvRect { get; set; }

	// Methods

	// RVA: 0x76BB69C
	protected object .ctor() { }

	// RVA: 0x76BB6D0
	public override object get_mainTexture() { }

	// RVA: 0x76BB8F4
	public object get_texture() { }

	// RVA: 0x76BB8FC
	public object set_texture(object value) { }

	// RVA: 0x76BB9F8
	public object get_uvRect() { }

	// RVA: 0x76BBA04
	public object set_uvRect(object value) { }

	// RVA: 0x76BBA7C
	public override object SetNativeSize() { }

	// RVA: 0x76BBE20
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x76BC790
	protected override object OnDidApplyAnimationProperties() { }

}

// Namespace: UnityEngine.UI
public class RectMask2D
{

	// Fields
	private readonly object m_VertexClipper; // 0x18
	private object m_RectTransform; // 0x20
	private object m_MaskableTargets; // 0x28
	private object m_ClipTargets; // 0x30
	private object m_ShouldRecalculateClipRects; // 0x38
	private object m_Clippers; // 0x40
	private object m_LastClipRectCanvasSpace; // 0x48
	private object m_ForceClip; // 0x58
	private object m_Padding; // 0x5C
	private object m_Softness; // 0x6C
	private object m_Canvas; // 0x78
	private object m_Corners; // 0x80

	// Properties
	public object padding { get; set; }
	public object softness { get; set; }
	internal object Canvas { get; }
	public object canvasRect { get; }
	public object rectTransform { get; }
	private object rootCanvasRect { get; }

	// Methods

	// RVA: 0x76BC804
	public object get_padding() { }

	// RVA: 0x76BC810
	public object set_padding(object value) { }

	// RVA: 0x76BC820
	public object get_softness() { }

	// RVA: 0x76BC828
	public object set_softness(object value) { }

	// RVA: 0x76BC844
	internal object get_Canvas() { }

	// RVA: 0x76BCA0C
	public object get_canvasRect() { }

	// RVA: 0x76BCAB4
	public object get_rectTransform() { }

	// RVA: 0x76BCB24
	protected object .ctor() { }

	// RVA: 0x76BCC8C
	protected override object OnEnable() { }

	// RVA: 0x76BCCCC
	protected override object OnDisable() { }

	// RVA: 0x76BCDC0
	protected override object OnDestroy() { }

	// RVA: 0x76BCDEC
	public virtual object IsRaycastLocationValid(object sp, object eventCamera) { }

	// RVA: 0x76BCF38
	private object get_rootCanvasRect() { }

	// RVA: 0x76BD188
	public virtual object PerformClipping() { }

	// RVA: 0x76BDB20
	public virtual object UpdateClipSoftness() { }

	// RVA: 0x76BDE74
	public object AddClippable(object clippable) { }

	// RVA: 0x76BDFCC
	public object RemoveClippable(object clippable) { }

	// RVA: 0x76BE1C8
	protected override object OnTransformParentChanged() { }

	// RVA: 0x76BE1F8
	protected override object OnCanvasHierarchyChanged() { }

}

// Namespace: 
public enum Direction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LeftToRight;
	public const object RightToLeft;
	public const object BottomToTop;
	public const object TopToBottom;
}

// Namespace: 
public class ScrollEvent
{

	// Methods

	// RVA: 0x76BE8C4
	public object .ctor() { }

}

// Namespace: 
private enum Axis
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Horizontal;
	public const object Vertical;
}

// Namespace: 
private sealed class <ClickRepeat>d__58
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object screenPosition; // 0x20
	public object camera; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x76BFFB8
	public object .ctor(object <>1__state) { }

	// RVA: 0x76C0B44
	private object System.IDisposable.Dispose() { }

	// RVA: 0x76C0B48
	private object MoveNext() { }

	// RVA: 0x76C0F90
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x76C0F98
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x76C0FD8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: UnityEngine.UI
public class Scrollbar
{

	// Fields
	private object m_HandleRect; // 0xF8
	private object m_Direction; // 0x100
	private object m_Value; // 0x104
	private object m_Size; // 0x108
	private object m_NumberOfSteps; // 0x10C
	private object m_OnValueChanged; // 0x110
	private object m_ContainerRect; // 0x118
	private object m_Offset; // 0x120
	private object m_Tracker; // 0x128
	private object m_PointerDownRepeat; // 0x130
	private object isPointerDownAndNotDragging; // 0x138
	private object m_DelayedUpdateVisuals; // 0x139

	// Properties
	public object handleRect { get; set; }
	public object direction { get; set; }
	public object value { get; set; }
	public object size { get; set; }
	public object numberOfSteps { get; set; }
	public object onValueChanged { get; set; }
	private object stepSize { get; }
	private object axis { get; }
	private object reverseValue { get; }

	// Methods

	// RVA: 0x76BE228
	public object get_handleRect() { }

	// RVA: 0x76BE230
	public object set_handleRect(object value) { }

	// RVA: 0x76BE734
	public object get_direction() { }

	// RVA: 0x76BE73C
	public object set_direction(object value) { }

	// RVA: 0x76BE7B4
	protected object .ctor() { }

	// RVA: 0x76BEA38
	public object get_value() { }

	// RVA: 0x76BEAF4
	public object set_value(object value) { }

	// RVA: 0x76BED4C
	public virtual object SetValueWithoutNotify(object input) { }

	// RVA: 0x76BED54
	public object get_size() { }

	// RVA: 0x76BED5C
	public object set_size(object value) { }

	// RVA: 0x76BEDF4
	public object get_numberOfSteps() { }

	// RVA: 0x76BEDFC
	public object set_numberOfSteps(object value) { }

	// RVA: 0x76BEE84
	public object get_onValueChanged() { }

	// RVA: 0x76BEE8C
	public object set_onValueChanged(object value) { }

	// RVA: 0x76BEE94
	private object get_stepSize() { }

	// RVA: 0x76BEEC4
	public virtual object Rebuild(object executing) { }

	// RVA: 0x76BEEC8
	public virtual object LayoutComplete() { }

	// RVA: 0x76BEECC
	public virtual object GraphicUpdateComplete() { }

	// RVA: 0x76BEED0
	protected override object OnEnable() { }

	// RVA: 0x76BF280
	protected override object OnDisable() { }

	// RVA: 0x76BF410
	protected virtual object Update() { }

	// RVA: 0x76BE2B0
	private object UpdateCachedReferences() { }

	// RVA: 0x76BEAFC
	private object Set(object input, object sendCallback) { }

	// RVA: 0x76BF428
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x76BF484
	private object get_axis() { }

	// RVA: 0x76BF494
	private object get_reverseValue() { }

	// RVA: 0x76BE470
	private object UpdateVisuals() { }

	// RVA: 0x76BF4A8
	private object UpdateDrag(object eventData) { }

	// RVA: 0x76BF7A0
	private object DoUpdateDrag(object handleCorner, object remainingSize) { }

	// RVA: 0x76BF810
	private object MayDrag(object eventData) { }

	// RVA: 0x76BF8A0
	public virtual object OnBeginDrag(object eventData) { }

	// RVA: 0x76BFAD0
	public virtual object OnDrag(object eventData) { }

	// RVA: 0x76BFBE0
	public override object OnPointerDown(object eventData) { }

	// RVA: 0x76BFF18
	protected object ClickRepeat(object eventData) { }

	// RVA: 0x76BFE90
	protected object ClickRepeat(object screenPosition, object camera) { }

	// RVA: 0x76BFFE4
	public override object OnPointerUp(object eventData) { }

	// RVA: 0x76C0060
	public override object OnMove(object eventData) { }

	// RVA: 0x76C0494
	public override object FindSelectableOnLeft() { }

	// RVA: 0x76C05B8
	public override object FindSelectableOnRight() { }

	// RVA: 0x76C06DC
	public override object FindSelectableOnUp() { }

	// RVA: 0x76C0800
	public override object FindSelectableOnDown() { }

	// RVA: 0x76C0924
	public virtual object OnInitializePotentialDrag(object eventData) { }

	// RVA: 0x76C0944
	public object SetDirection(object direction, object includeRectLayouts) { }

	// RVA: 0x76C0B3C
	private object UnityEngine.UI.ICanvasElement.get_transform() { }

}

// Namespace: 
public enum MovementType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unrestricted;
	public const object Elastic;
	public const object Clamped;
}

// Namespace: 
public enum ScrollbarVisibility
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Permanent;
	public const object AutoHide;
	public const object AutoHideAndExpandViewport;
}

// Namespace: 
public class ScrollRectEvent
{

	// Methods

	// RVA: 0x76C1BE4
	public object .ctor() { }

}

// Namespace: UnityEngine.UI
public class ScrollRect
{

	// Fields
	private object m_Content; // 0x18
	private object m_Horizontal; // 0x20
	private object m_Vertical; // 0x21
	private object m_MovementType; // 0x24
	private object m_Elasticity; // 0x28
	private object m_Inertia; // 0x2C
	private object m_DecelerationRate; // 0x30
	private object m_ScrollSensitivity; // 0x34
	private object m_Viewport; // 0x38
	private object m_HorizontalScrollbar; // 0x40
	private object m_VerticalScrollbar; // 0x48
	private object m_HorizontalScrollbarVisibility; // 0x50
	private object m_VerticalScrollbarVisibility; // 0x54
	private object m_HorizontalScrollbarSpacing; // 0x58
	private object m_VerticalScrollbarSpacing; // 0x5C
	private object m_OnValueChanged; // 0x60
	private object m_PointerStartLocalCursor; // 0x68
	protected object m_ContentStartPosition; // 0x70
	private object m_ViewRect; // 0x78
	protected object m_ContentBounds; // 0x80
	private object m_ViewBounds; // 0x98
	private object m_Velocity; // 0xB0
	private object m_Dragging; // 0xB8
	private object m_Scrolling; // 0xB9
	private object m_PrevPosition; // 0xBC
	private object m_PrevContentBounds; // 0xC4
	private object m_PrevViewBounds; // 0xDC
	private object m_HasRebuiltLayout; // 0xF4
	private object m_HSliderExpand; // 0xF5
	private object m_VSliderExpand; // 0xF6
	private object m_HSliderHeight; // 0xF8
	private object m_VSliderWidth; // 0xFC
	private object m_Rect; // 0x100
	private object m_HorizontalScrollbarRect; // 0x108
	private object m_VerticalScrollbarRect; // 0x110
	private object m_Tracker; // 0x118
	private readonly object m_Corners; // 0x120

	// Properties
	public object content { get; set; }
	public object horizontal { get; set; }
	public object vertical { get; set; }
	public object movementType { get; set; }
	public object elasticity { get; set; }
	public object inertia { get; set; }
	public object decelerationRate { get; set; }
	public object scrollSensitivity { get; set; }
	public object viewport { get; set; }
	public object horizontalScrollbar { get; set; }
	public object verticalScrollbar { get; set; }
	public object horizontalScrollbarVisibility { get; set; }
	public object verticalScrollbarVisibility { get; set; }
	public object horizontalScrollbarSpacing { get; set; }
	public object verticalScrollbarSpacing { get; set; }
	public object onValueChanged { get; set; }
	protected object viewRect { get; }
	public object velocity { get; set; }
	private object rectTransform { get; }
	public object normalizedPosition { get; set; }
	public object horizontalNormalizedPosition { get; set; }
	public object verticalNormalizedPosition { get; set; }
	private object hScrollingNeeded { get; }
	private object vScrollingNeeded { get; }
	public virtual object minWidth { get; }
	public virtual object preferredWidth { get; }
	public virtual object flexibleWidth { get; }
	public virtual object minHeight { get; }
	public virtual object preferredHeight { get; }
	public virtual object flexibleHeight { get; }
	public virtual object layoutPriority { get; }

	// Methods

	// RVA: 0x76C0FE0
	public object get_content() { }

	// RVA: 0x76C0FE8
	public object set_content(object value) { }

	// RVA: 0x76C0FF0
	public object get_horizontal() { }

	// RVA: 0x76C0FF8
	public object set_horizontal(object value) { }

	// RVA: 0x76C1000
	public object get_vertical() { }

	// RVA: 0x76C1008
	public object set_vertical(object value) { }

	// RVA: 0x76C1010
	public object get_movementType() { }

	// RVA: 0x76C1018
	public object set_movementType(object value) { }

	// RVA: 0x76C1020
	public object get_elasticity() { }

	// RVA: 0x76C1028
	public object set_elasticity(object value) { }

	// RVA: 0x76C1030
	public object get_inertia() { }

	// RVA: 0x76C1038
	public object set_inertia(object value) { }

	// RVA: 0x76C1040
	public object get_decelerationRate() { }

	// RVA: 0x76C1048
	public object set_decelerationRate(object value) { }

	// RVA: 0x76C1050
	public object get_scrollSensitivity() { }

	// RVA: 0x76C1058
	public object set_scrollSensitivity(object value) { }

	// RVA: 0x76C1060
	public object get_viewport() { }

	// RVA: 0x76C1068
	public object set_viewport(object value) { }

	// RVA: 0x76C11C4
	public object get_horizontalScrollbar() { }

	// RVA: 0x76C11CC
	public object set_horizontalScrollbar(object value) { }

	// RVA: 0x76C1454
	public object get_verticalScrollbar() { }

	// RVA: 0x76C145C
	public object set_verticalScrollbar(object value) { }

	// RVA: 0x76C16E4
	public object get_horizontalScrollbarVisibility() { }

	// RVA: 0x76C16EC
	public object set_horizontalScrollbarVisibility(object value) { }

	// RVA: 0x76C16F4
	public object get_verticalScrollbarVisibility() { }

	// RVA: 0x76C16FC
	public object set_verticalScrollbarVisibility(object value) { }

	// RVA: 0x76C1704
	public object get_horizontalScrollbarSpacing() { }

	// RVA: 0x76C170C
	public object set_horizontalScrollbarSpacing(object value) { }

	// RVA: 0x76C1854
	public object get_verticalScrollbarSpacing() { }

	// RVA: 0x76C185C
	public object set_verticalScrollbarSpacing(object value) { }

	// RVA: 0x76C1864
	public object get_onValueChanged() { }

	// RVA: 0x76C186C
	public object set_onValueChanged(object value) { }

	// RVA: 0x76C1874
	protected object get_viewRect() { }

	// RVA: 0x76C19D0
	public object get_velocity() { }

	// RVA: 0x76C19D8
	public object set_velocity(object value) { }

	// RVA: 0x76C19E0
	private object get_rectTransform() { }

	// RVA: 0x76C1AB0
	protected object .ctor() { }

	// RVA: 0x76C1C3C
	public virtual object Rebuild(object executing) { }

	// RVA: 0x76C2D08
	public virtual object LayoutComplete() { }

	// RVA: 0x76C2D0C
	public virtual object GraphicUpdateComplete() { }

	// RVA: 0x76C1CD4
	private object UpdateCachedData() { }

	// RVA: 0x76C2D10
	protected override object OnEnable() { }

	// RVA: 0x76C2FC8
	protected override object OnDisable() { }

	// RVA: 0x76C3394
	public override object IsActive() { }

	// RVA: 0x76C342C
	private object EnsureLayoutHasRebuilt() { }

	// RVA: 0x76C34B0
	public virtual object StopMovement() { }

	// RVA: 0x76C350C
	public virtual object OnScroll(object data) { }

	// RVA: 0x76C39C4
	public virtual object OnInitializePotentialDrag(object eventData) { }

	// RVA: 0x76C3A50
	public virtual object OnBeginDrag(object eventData) { }

	// RVA: 0x76C3BB4
	public virtual object OnEndDrag(object eventData) { }

	// RVA: 0x76C3BE0
	public virtual object OnDrag(object eventData) { }

	// RVA: 0x76C3F7C
	protected virtual object SetContentAnchoredPosition(object position) { }

	// RVA: 0x76C4070
	protected virtual object LateUpdate() { }

	// RVA: 0x76C2BF8
	protected object UpdatePrevData() { }

	// RVA: 0x76C268C
	private object UpdateScrollbars(object offset) { }

	// RVA: 0x76C4948
	public object get_normalizedPosition() { }

	// RVA: 0x76C4EB0
	public object set_normalizedPosition(object value) { }

	// RVA: 0x76C4C80
	public object get_horizontalNormalizedPosition() { }

	// RVA: 0x76C4F38
	public object set_horizontalNormalizedPosition(object value) { }

	// RVA: 0x76C4D98
	public object get_verticalNormalizedPosition() { }

	// RVA: 0x76C4F90
	public object set_verticalNormalizedPosition(object value) { }

	// RVA: 0x76C4FE8
	private object SetHorizontalNormalizedPosition(object value) { }

	// RVA: 0x76C5040
	private object SetVerticalNormalizedPosition(object value) { }

	// RVA: 0x76C5098
	protected virtual object SetNormalizedPosition(object value, object axis) { }

	// RVA: 0x76C3F40
	private static object RubberDelta(object overStretching, object viewSize) { }

	// RVA: 0x76C5398
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x76C539C
	private object get_hScrollingNeeded() { }

	// RVA: 0x76C5458
	private object get_vScrollingNeeded() { }

	// RVA: 0x76C5514
	public virtual object CalculateLayoutInputHorizontal() { }

	// RVA: 0x76C5518
	public virtual object CalculateLayoutInputVertical() { }

	// RVA: 0x76C551C
	public virtual object get_minWidth() { }

	// RVA: 0x76C5524
	public virtual object get_preferredWidth() { }

	// RVA: 0x76C552C
	public virtual object get_flexibleWidth() { }

	// RVA: 0x76C5534
	public virtual object get_minHeight() { }

	// RVA: 0x76C553C
	public virtual object get_preferredHeight() { }

	// RVA: 0x76C5544
	public virtual object get_flexibleHeight() { }

	// RVA: 0x76C554C
	public virtual object get_layoutPriority() { }

	// RVA: 0x76C5554
	public virtual object SetLayoutHorizontal() { }

	// RVA: 0x76C5DF4
	public virtual object SetLayoutVertical() { }

	// RVA: 0x76C4B30
	private object UpdateScrollbarVisibility() { }

	// RVA: 0x76C637C
	private static object UpdateOneScrollbarVisibility(object xScrollingNeeded, object xAxisEnabled, object scrollbarVisibility, object scrollbar) { }

	// RVA: 0x76C5EC8
	private object UpdateScrollbarLayout() { }

	// RVA: 0x76C22C0
	protected object UpdateBounds() { }

	// RVA: 0x76C6524
	internal static object AdjustBounds(object viewBounds, object contentPivot, object contentSize, object contentPos) { }

	// RVA: 0x76C5CD0
	private object GetBounds() { }

	// RVA: 0x76C65AC
	internal static object InternalGetBounds(object corners, object viewWorldToLocalMatrix) { }

	// RVA: 0x76C388C
	private object CalculateOffset(object delta) { }

	// RVA: 0x76C67F4
	internal static object InternalCalculateOffset(object viewBounds, object contentBounds, object horizontal, object vertical, object movementType, object delta) { }

	// RVA: 0x76C1714
	protected object SetDirty() { }

	// RVA: 0x76C1070
	protected object SetDirtyCaching() { }

	// RVA: 0x76C6934
	private object UnityEngine.UI.ICanvasElement.get_transform() { }

}

// Namespace: 
public enum Transition
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ColorTint;
	public const object SpriteSwap;
	public const object Animation;
}

// Namespace: 
protected enum SelectionState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Highlighted;
	public const object Pressed;
	public const object Selected;
	public const object Disabled;
}

// Namespace: UnityEngine.UI
public class Selectable
{

	// Fields
	protected static object s_Selectables; // 0x0
	protected static object s_SelectableCount; // 0x8
	private object m_EnableCalled; // 0x18
	private object m_Navigation; // 0x20
	private object m_Transition; // 0x48
	private object m_Colors; // 0x4C
	private object m_SpriteState; // 0xA8
	private object m_AnimationTriggers; // 0xC8
	private object m_Interactable; // 0xD0
	private object m_TargetGraphic; // 0xD8
	private object m_GroupsAllowInteraction; // 0xE0
	protected object m_CurrentIndex; // 0xE4
	private object <isPointerInside>k__BackingField; // 0xE8
	private object <isPointerDown>k__BackingField; // 0xE9
	private object <hasSelection>k__BackingField; // 0xEA
	private readonly object m_CanvasGroupCache; // 0xF0

	// Properties
	public static object allSelectablesArray { get; }
	public static object allSelectableCount { get; }
	public static object allSelectables { get; }
	public object navigation { get; set; }
	public object transition { get; set; }
	public object colors { get; set; }
	public object spriteState { get; set; }
	public object animationTriggers { get; set; }
	public object targetGraphic { get; set; }
	public object interactable { get; set; }
	private object isPointerInside { get; set; }
	private object isPointerDown { get; set; }
	private object hasSelection { get; set; }
	public object image { get; set; }
	public object animator { get; }
	protected object currentSelectionState { get; }

	// Methods

	// RVA: 0x76C693C
	public static object get_allSelectablesArray() { }

	// RVA: 0x76C69D8
	public static object get_allSelectableCount() { }

	// RVA: 0x76C6A54
	public static object get_allSelectables() { }

	// RVA: 0x76C6B84
	public static object AllSelectablesNoAlloc(object selectables) { }

	// RVA: 0x76C6C7C
	public object get_navigation() { }

	// RVA: 0x76C6C90
	public object set_navigation(object value) { }

	// RVA: 0x76C6E34
	public object get_transition() { }

	// RVA: 0x76C6E3C
	public object set_transition(object value) { }

	// RVA: 0x76C6F34
	public object get_colors() { }

	// RVA: 0x76C6F60
	public object set_colors(object value) { }

	// RVA: 0x76C7074
	public object get_spriteState() { }

	// RVA: 0x76C7084
	public object set_spriteState(object value) { }

	// RVA: 0x76C7180
	public object get_animationTriggers() { }

	// RVA: 0x76C7188
	public object set_animationTriggers(object value) { }

	// RVA: 0x76C7280
	public object get_targetGraphic() { }

	// RVA: 0x76C7288
	public object set_targetGraphic(object value) { }

	// RVA: 0x76C7380
	public object get_interactable() { }

	// RVA: 0x76C7388
	public object set_interactable(object value) { }

	// RVA: 0x76C75D0
	private object get_isPointerInside() { }

	// RVA: 0x76C75D8
	private object set_isPointerInside(object value) { }

	// RVA: 0x76C75E0
	private object get_isPointerDown() { }

	// RVA: 0x76C75E8
	private object set_isPointerDown(object value) { }

	// RVA: 0x76C75F0
	private object get_hasSelection() { }

	// RVA: 0x76C75F8
	private object set_hasSelection(object value) { }

	// RVA: 0x76BE91C
	protected object .ctor() { }

	// RVA: 0x76C7600
	public object get_image() { }

	// RVA: 0x76C7688
	public object set_image(object value) { }

	// RVA: 0x76C7690
	public object get_animator() { }

	// RVA: 0x76C76E8
	protected override object Awake() { }

	// RVA: 0x76C77B4
	protected override object OnCanvasGroupChanged() { }

	// RVA: 0x76C7874
	private object ParentGroupAllowsInteraction() { }

	// RVA: 0x76C7A48
	public virtual object IsInteractable() { }

	// RVA: 0x76C7A68
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x76BEF0C
	protected override object OnEnable() { }

	// RVA: 0x76C7B94
	protected override object OnTransformParentChanged() { }

	// RVA: 0x76C6D94
	private object OnSetProperty() { }

	// RVA: 0x76BF2AC
	protected override object OnDisable() { }

	// RVA: 0x76C7BDC
	private object OnApplicationFocus(object hasFocus) { }

	// RVA: 0x76C7B08
	protected object get_currentSelectionState() { }

	// RVA: 0x76C7D18
	protected virtual object InstantClearState() { }

	// RVA: 0x76C8418
	protected virtual object DoStateTransition(object state, object instant) { }

	// RVA: 0x76C8714
	public object FindSelectable(object dir) { }

	// RVA: 0x76C8C94
	private static object GetPointOnRectEdge(object rect, object dir) { }

	// RVA: 0x76C8E4C
	private object Navigate(object eventData, object sel) { }

	// RVA: 0x76C04B8
	public virtual object FindSelectableOnLeft() { }

	// RVA: 0x76C05DC
	public virtual object FindSelectableOnRight() { }

	// RVA: 0x76C0700
	public virtual object FindSelectableOnUp() { }

	// RVA: 0x76C0824
	public virtual object FindSelectableOnDown() { }

	// RVA: 0x76C0364
	public virtual object OnMove(object eventData) { }

	// RVA: 0x76C7D84
	private object StartColorTween(object targetColor, object instant) { }

	// RVA: 0x76C7EE8
	private object DoSpriteSwap(object newSprite) { }

	// RVA: 0x76C8084
	private object TriggerAnimation(object triggername) { }

	// RVA: 0x76C8F54
	protected object IsHighlighted() { }

	// RVA: 0x76C7C8C
	protected object IsPressed() { }

	// RVA: 0x76C8FF8
	private object EvaluateAndTransitionToSelectionState() { }

	// RVA: 0x76BFD20
	public virtual object OnPointerDown(object eventData) { }

	// RVA: 0x76C0034
	public virtual object OnPointerUp(object eventData) { }

	// RVA: 0x76C90F8
	public virtual object OnPointerEnter(object eventData) { }

	// RVA: 0x76C9104
	public virtual object OnPointerExit(object eventData) { }

	// RVA: 0x76C910C
	public virtual object OnSelect(object eventData) { }

	// RVA: 0x76C9118
	public virtual object OnDeselect(object eventData) { }

	// RVA: 0x76C9120
	public virtual object Select() { }

	// RVA: 0x76C9284
	private static object .cctor() { }

}

// Namespace: UnityEngine.UI
internal static class SetPropertyUtility
{

	// Methods

	// RVA: 0x76C92FC
	public static object SetColor(object currentValue, object newValue) { }

	// RVA: -1
	public static object SetStruct(object currentValue, object newValue) { }

	// RVA: -1
	public static object SetClass(object currentValue, object newValue) { }

}

// Namespace: 
public enum Direction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LeftToRight;
	public const object RightToLeft;
	public const object BottomToTop;
	public const object TopToBottom;
}

// Namespace: 
public class SliderEvent
{

	// Methods

	// RVA: 0x76CA7A8
	public object .ctor() { }

}

// Namespace: 
private enum Axis
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Horizontal;
	public const object Vertical;
}

// Namespace: UnityEngine.UI
public class Slider
{

	// Fields
	private object m_FillRect; // 0xF8
	private object m_HandleRect; // 0x100
	private object m_Direction; // 0x108
	private object m_MinValue; // 0x10C
	private object m_MaxValue; // 0x110
	private object m_WholeNumbers; // 0x114
	protected object m_Value; // 0x118
	private object m_OnValueChanged; // 0x120
	private object m_FillImage; // 0x128
	private object m_FillTransform; // 0x130
	private object m_FillContainerRect; // 0x138
	private object m_HandleTransform; // 0x140
	private object m_HandleContainerRect; // 0x148
	private object m_Offset; // 0x150
	private object m_Tracker; // 0x158
	private object m_DelayedUpdateVisuals; // 0x159

	// Properties
	public object fillRect { get; set; }
	public object handleRect { get; set; }
	public object direction { get; set; }
	public object minValue { get; set; }
	public object maxValue { get; set; }
	public object wholeNumbers { get; set; }
	public virtual object value { get; set; }
	public object normalizedValue { get; set; }
	public object onValueChanged { get; set; }
	private object stepSize { get; }
	private object axis { get; }
	private object reverseValue { get; }

	// Methods

	// RVA: 0x76C9348
	public object get_fillRect() { }

	// RVA: 0x76C9350
	public object set_fillRect(object value) { }

	// RVA: 0x76C9FA0
	public object get_handleRect() { }

	// RVA: 0x76C9FA8
	public object set_handleRect(object value) { }

	// RVA: 0x76CA028
	public object get_direction() { }

	// RVA: 0x76CA030
	public object set_direction(object value) { }

	// RVA: 0x76CA0A8
	public object get_minValue() { }

	// RVA: 0x76CA0B0
	public object set_minValue(object value) { }

	// RVA: 0x76CA1CC
	public object get_maxValue() { }

	// RVA: 0x76CA1D4
	public object set_maxValue(object value) { }

	// RVA: 0x76CA28C
	public object get_wholeNumbers() { }

	// RVA: 0x76CA294
	public object set_wholeNumbers(object value) { }

	// RVA: 0x76CA34C
	public virtual object get_value() { }

	// RVA: 0x76CA41C
	public virtual object set_value(object value) { }

	// RVA: 0x76CA474
	public virtual object SetValueWithoutNotify(object input) { }

	// RVA: 0x76CA4CC
	public object get_normalizedValue() { }

	// RVA: 0x76CA5DC
	public object set_normalizedValue(object value) { }

	// RVA: 0x76CA660
	public object get_onValueChanged() { }

	// RVA: 0x76CA668
	public object set_onValueChanged(object value) { }

	// RVA: 0x76CA670
	private object get_stepSize() { }

	// RVA: 0x76CA69C
	protected object .ctor() { }

	// RVA: 0x76CA800
	public virtual object Rebuild(object executing) { }

	// RVA: 0x76CA804
	public virtual object LayoutComplete() { }

	// RVA: 0x76CA808
	public virtual object GraphicUpdateComplete() { }

	// RVA: 0x76CA80C
	protected override object OnEnable() { }

	// RVA: 0x76CA874
	protected override object OnDisable() { }

	// RVA: 0x76CA8A0
	protected virtual object Update() { }

	// RVA: 0x76CA910
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x76C93D0
	private object UpdateCachedReferences() { }

	// RVA: 0x76CAE80
	private object ClampValue(object input) { }

	// RVA: 0x76CAF88
	protected virtual object Set(object input, object sendCallback) { }

	// RVA: 0x76CB114
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x76CAF78
	private object get_axis() { }

	// RVA: 0x76CAF64
	private object get_reverseValue() { }

	// RVA: 0x76C9814
	private object UpdateVisuals() { }

	// RVA: 0x76CB170
	private object UpdateDrag(object eventData, object cam) { }

	// RVA: 0x76CB430
	private object MayDrag(object eventData) { }

	// RVA: 0x76CB4C0
	public override object OnPointerDown(object eventData) { }

	// RVA: 0x76CB6FC
	public virtual object OnDrag(object eventData) { }

	// RVA: 0x76CB7AC
	public override object OnMove(object eventData) { }

	// RVA: 0x76CBA98
	public override object FindSelectableOnLeft() { }

	// RVA: 0x76CBABC
	public override object FindSelectableOnRight() { }

	// RVA: 0x76CBAE0
	public override object FindSelectableOnUp() { }

	// RVA: 0x76CBB04
	public override object FindSelectableOnDown() { }

	// RVA: 0x76CBB28
	public virtual object OnInitializePotentialDrag(object eventData) { }

	// RVA: 0x76CBB48
	public object SetDirection(object direction, object includeRectLayouts) { }

	// RVA: 0x76CBD40
	private object UnityEngine.UI.ICanvasElement.get_transform() { }

}

// Namespace: UnityEngine.UI
public struct SpriteState
{

	// Fields
	private object m_HighlightedSprite; // 0xFFFFFFFFFFFFFFF8
	private object m_PressedSprite; // 0x0
	private object m_SelectedSprite; // 0x8
	private object m_DisabledSprite; // 0x10

	// Properties
	public object highlightedSprite { get; set; }
	public object pressedSprite { get; set; }
	public object selectedSprite { get; set; }
	public object disabledSprite { get; set; }

	// Methods

	// RVA: 0x76CBD84
	public object get_highlightedSprite() { }

	// RVA: 0x76CBD94
	public object set_highlightedSprite(object value) { }

	// RVA: 0x76CBDA4
	public object get_pressedSprite() { }

	// RVA: 0x76CBDB4
	public object set_pressedSprite(object value) { }

	// RVA: 0x76CBDC4
	public object get_selectedSprite() { }

	// RVA: 0x76CBDD4
	public object set_selectedSprite(object value) { }

	// RVA: 0x76CBDE4
	public object get_disabledSprite() { }

	// RVA: 0x76CBDF4
	public object set_disabledSprite(object value) { }

	// RVA: 0x76CBE04
	public object Equals(object other) { }

}

// Namespace: 
private class MatEntry
{

	// Fields
	public object baseMat; // 0x8
	public object customMat; // 0x10
	public object count; // 0x18
	public object stencilId; // 0x1C
	public object operation; // 0x20
	public object compareFunction; // 0x24
	public object readMask; // 0x28
	public object writeMask; // 0x2C
	public object useAlphaClip; // 0x30
	public object colorMask; // 0x34

	// Methods

	// RVA: 0x76CCBF0
	public object .ctor() { }

}

// Namespace: UnityEngine.UI
public static class StencilMaterial
{

	// Fields
	private static object m_List; // 0x0

	// Methods

	// RVA: 0x76CBFA0
	public static object Add(object baseMat, object stencilID) { }

	// RVA: 0x76CBFA8
	public static object Add(object baseMat, object stencilID, object operation, object compareFunction, object colorWriteMask) { }

	// RVA: 0x76CCB2C
	private static object LogWarningWhenNotInBatchmode(object warning, object context) { }

	// RVA: 0x76CC040
	public static object Add(object baseMat, object stencilID, object operation, object compareFunction, object colorWriteMask, object readMask, object writeMask) { }

	// RVA: 0x76CCC00
	public static object Remove(object customMat) { }

	// RVA: 0x76CCE14
	public static object ClearAll() { }

	// RVA: 0x76CCFA8
	private static object .cctor() { }

}

// Namespace: UnityEngine.UI
public class Text
{

	// Fields
	private object m_FontData; // 0xD0
	protected object m_Text; // 0xD8
	private object m_TextCache; // 0xE0
	private object m_TextCacheForLayout; // 0xE8
	protected static object s_DefaultText; // 0x0
	protected object m_DisableFontTextureRebuiltCallback; // 0xF0
	private readonly object m_TempVerts; // 0xF8

	// Properties
	public object cachedTextGenerator { get; }
	public object cachedTextGeneratorForLayout { get; }
	public override object mainTexture { get; }
	public object font { get; set; }
	public virtual object text { get; set; }
	public object supportRichText { get; set; }
	public object resizeTextForBestFit { get; set; }
	public object resizeTextMinSize { get; set; }
	public object resizeTextMaxSize { get; set; }
	public object alignment { get; set; }
	public object alignByGeometry { get; set; }
	public object fontSize { get; set; }
	public object horizontalOverflow { get; set; }
	public object verticalOverflow { get; set; }
	public object lineSpacing { get; set; }
	public object fontStyle { get; set; }
	public object pixelsPerUnit { get; }
	public virtual object minWidth { get; }
	public virtual object preferredWidth { get; }
	public virtual object flexibleWidth { get; }
	public virtual object minHeight { get; }
	public virtual object preferredHeight { get; }
	public virtual object flexibleHeight { get; }
	public virtual object layoutPriority { get; }

	// Methods

	// RVA: 0x76CD038
	protected object .ctor() { }

	// RVA: 0x76CD0D0
	public object get_cachedTextGenerator() { }

	// RVA: 0x76CD190
	public object get_cachedTextGeneratorForLayout() { }

	// RVA: 0x76CD20C
	public override object get_mainTexture() { }

	// RVA: 0x76CD4B0
	public object FontTextureChanged() { }

	// RVA: 0x76CD48C
	public object get_font() { }

	// RVA: 0x76CD6E4
	public object set_font(object value) { }

	// RVA: 0x76CD844
	public virtual object get_text() { }

	// RVA: 0x76CD84C
	public virtual object set_text(object value) { }

	// RVA: 0x76CD964
	public object get_supportRichText() { }

	// RVA: 0x76CD988
	public object set_supportRichText(object value) { }

	// RVA: 0x76CDA20
	public object get_resizeTextForBestFit() { }

	// RVA: 0x76CDA44
	public object set_resizeTextForBestFit(object value) { }

	// RVA: 0x76CDADC
	public object get_resizeTextMinSize() { }

	// RVA: 0x76CDB00
	public object set_resizeTextMinSize(object value) { }

	// RVA: 0x76CDB98
	public object get_resizeTextMaxSize() { }

	// RVA: 0x76CDBBC
	public object set_resizeTextMaxSize(object value) { }

	// RVA: 0x76CDC54
	public object get_alignment() { }

	// RVA: 0x76CDC78
	public object set_alignment(object value) { }

	// RVA: 0x76CDD10
	public object get_alignByGeometry() { }

	// RVA: 0x76CDD34
	public object set_alignByGeometry(object value) { }

	// RVA: 0x76CDDA8
	public object get_fontSize() { }

	// RVA: 0x76CDDCC
	public object set_fontSize(object value) { }

	// RVA: 0x76CDE64
	public object get_horizontalOverflow() { }

	// RVA: 0x76CDE88
	public object set_horizontalOverflow(object value) { }

	// RVA: 0x76CDF20
	public object get_verticalOverflow() { }

	// RVA: 0x76CDF44
	public object set_verticalOverflow(object value) { }

	// RVA: 0x76CDFDC
	public object get_lineSpacing() { }

	// RVA: 0x76CE000
	public object set_lineSpacing(object value) { }

	// RVA: 0x76CE098
	public object get_fontStyle() { }

	// RVA: 0x76CE0BC
	public object set_fontStyle(object value) { }

	// RVA: 0x76CE154
	public object get_pixelsPerUnit() { }

	// RVA: 0x76CE3A8
	protected override object OnEnable() { }

	// RVA: 0x76CE4EC
	protected override object OnDisable() { }

	// RVA: 0x76CE55C
	protected override object UpdateGeometry() { }

	// RVA: 0x76CE604
	internal object AssignDefaultFont() { }

	// RVA: 0x76CE678
	internal object AssignDefaultFontIfNecessary() { }

	// RVA: 0x76CE754
	public object GetGenerationSettings(object extents) { }

	// RVA: 0x76CE990
	public static object GetTextAnchorPivot(object anchor) { }

	// RVA: 0x76CEA1C
	public virtual object GetVisualText() { }

	// RVA: 0x76CEA60
	protected override object OnPopulateMesh(object toFill) { }

	// RVA: 0x76CF610
	public virtual object CalculateLayoutInputHorizontal() { }

	// RVA: 0x76CF614
	public virtual object CalculateLayoutInputVertical() { }

	// RVA: 0x76CF618
	public virtual object get_minWidth() { }

	// RVA: 0x76CF620
	public virtual object get_preferredWidth() { }

	// RVA: 0x76CF770
	public virtual object get_flexibleWidth() { }

	// RVA: 0x76CF778
	public virtual object get_minHeight() { }

	// RVA: 0x76CF780
	public virtual object get_preferredHeight() { }

	// RVA: 0x76CF89C
	public virtual object get_flexibleHeight() { }

	// RVA: 0x76CF8A4
	public virtual object get_layoutPriority() { }

}

// Namespace: 
public enum ToggleTransition
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Fade;
}

// Namespace: 
public class ToggleEvent
{

	// Methods

	// RVA: 0x76CFD54
	public object .ctor() { }

}

// Namespace: UnityEngine.UI
public class Toggle
{

	// Fields
	public object toggleTransition; // 0xF8
	public object graphic; // 0x100
	private object m_Group; // 0x108
	public object onValueChanged; // 0x110
	private object m_IsOn; // 0x118

	// Properties
	public object group { get; set; }
	public object isOn { get; set; }

	// Methods

	// RVA: 0x76CF8AC
	public object get_group() { }

	// RVA: 0x76CF8B4
	public object set_group(object value) { }

	// RVA: 0x76CFC78
	protected object .ctor() { }

	// RVA: 0x76CFDAC
	public virtual object Rebuild(object executing) { }

	// RVA: 0x76CFDB0
	public virtual object LayoutComplete() { }

	// RVA: 0x76CFDB4
	public virtual object GraphicUpdateComplete() { }

	// RVA: 0x76CFDB8
	protected override object OnDestroy() { }

	// RVA: 0x76D0364
	protected override object OnEnable() { }

	// RVA: 0x76D039C
	protected override object OnDisable() { }

	// RVA: 0x76D03C8
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x76CF8E0
	private object SetToggleGroup(object newGroup, object setMemberValue) { }

	// RVA: 0x76D0BA8
	public object get_isOn() { }

	// RVA: 0x76D0BB0
	public object set_isOn(object value) { }

	// RVA: 0x76D0BB8
	public object SetIsOnWithoutNotify(object value) { }

	// RVA: 0x76D05B8
	private object Set(object value, object sendCallback) { }

	// RVA: 0x76CFB54
	private object PlayEffect(object instant) { }

	// RVA: 0x76D0D3C
	protected override object Start() { }

	// RVA: 0x76D0D44
	private object InternalToggle() { }

	// RVA: 0x76D0DD4
	public virtual object OnPointerClick(object eventData) { }

	// RVA: 0x76D0E7C
	public virtual object OnSubmit(object eventData) { }

	// RVA: 0x76D0F0C
	private object UnityEngine.UI.ICanvasElement.get_transform() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__13_0; // 0x8
	public static object <>9__14_0; // 0x10

	// Methods

	// RVA: 0x76D146C
	private static object .cctor() { }

	// RVA: 0x76D14CC
	public object .ctor() { }

	// RVA: 0x76D14D4
	internal object <AnyTogglesOn>b__13_0(object x) { }

	// RVA: 0x76D14F4
	internal object <ActiveToggles>b__14_0(object x) { }

}

// Namespace: UnityEngine.UI
public class ToggleGroup
{

	// Fields
	private object m_AllowSwitchOff; // 0x18
	protected object m_Toggles; // 0x20

	// Properties
	public object allowSwitchOff { get; set; }

	// Methods

	// RVA: 0x76D0F14
	public object get_allowSwitchOff() { }

	// RVA: 0x76D0F1C
	public object set_allowSwitchOff(object value) { }

	// RVA: 0x76D0F24
	protected object .ctor() { }

	// RVA: 0x76D0FA4
	protected override object Start() { }

	// RVA: 0x76D0FCC
	protected override object OnEnable() { }

	// RVA: 0x76D0FF4
	private object ValidateToggleIsInGroup(object toggle) { }

	// RVA: 0x76D09A0
	public object NotifyToggleOn(object toggle, object sendCallback) { }

	// RVA: 0x76D0794
	public object UnregisterToggle(object toggle) { }

	// RVA: 0x76D0848
	public object RegisterToggle(object toggle) { }

	// RVA: 0x76CFE88
	public object EnsureValidState() { }

	// RVA: 0x76D0BC0
	public object AnyTogglesOn() { }

	// RVA: 0x76D1184
	public object ActiveToggles() { }

	// RVA: 0x76D12AC
	public object GetFirstActiveToggle() { }

	// RVA: 0x76D1348
	public object SetAllTogglesOff(object sendCallback) { }

}

// Namespace: 
public sealed class Raycast3DCallback
{

	// Methods

	// RVA: 0x76D2418
	public object .ctor(object object, object method) { }

	// RVA: 0x76D24B0
	public virtual object Invoke(object r, object hit, object f, object i) { }

	// RVA: 0x76D24F0
	public virtual object BeginInvoke(object r, object hit, object f, object i, object callback, object object) { }

	// RVA: 0x76D2634
	public virtual object EndInvoke(object hit, object result) { }

}

// Namespace: 
public sealed class RaycastAllCallback
{

	// Methods

	// RVA: 0x76D2854
	public object .ctor(object object, object method) { }

	// RVA: 0x76D28EC
	public virtual object Invoke(object r, object f, object i) { }

	// RVA: 0x76D292C
	public virtual object BeginInvoke(object r, object f, object i, object callback, object object) { }

	// RVA: 0x76D2A40
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class GetRaycastNonAllocCallback
{

	// Methods

	// RVA: 0x76D2B70
	public object .ctor(object object, object method) { }

	// RVA: 0x76D2C08
	public virtual object Invoke(object r, object results, object f, object i) { }

	// RVA: 0x76D2C48
	public virtual object BeginInvoke(object r, object results, object f, object i, object callback, object object) { }

	// RVA: 0x76D2D68
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class Raycast2DCallback
{

	// Methods

	// RVA: 0x76D2E60
	public object .ctor(object object, object method) { }

	// RVA: 0x76D2EF8
	public virtual object Invoke(object p1, object p2, object f, object i) { }

	// RVA: 0x76D2F0C
	public virtual object BeginInvoke(object p1, object p2, object f, object i, object callback, object object) { }

	// RVA: 0x76D3034
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class GetRayIntersectionAllCallback
{

	// Methods

	// RVA: 0x76D322C
	public object .ctor(object object, object method) { }

	// RVA: 0x76D32C4
	public virtual object Invoke(object r, object f, object i) { }

	// RVA: 0x76D3304
	public virtual object BeginInvoke(object r, object f, object i, object callback, object object) { }

	// RVA: 0x76D3418
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class GetRayIntersectionAllNonAllocCallback
{

	// Methods

	// RVA: 0x76D3548
	public object .ctor(object object, object method) { }

	// RVA: 0x76D35E0
	public virtual object Invoke(object r, object results, object f, object i) { }

	// RVA: 0x76D3620
	public virtual object BeginInvoke(object r, object results, object f, object i, object callback, object object) { }

	// RVA: 0x76D3740
	public virtual object EndInvoke(object result) { }

}

// Namespace: UnityEngine.UI
internal class ReflectionMethodsCache
{

	// Fields
	public object raycast3D; // 0x8
	public object raycast3DAll; // 0x10
	public object getRaycastNonAlloc; // 0x18
	public object raycast2D; // 0x20
	public object getRayIntersectionAll; // 0x28
	public object getRayIntersectionAllNonAlloc; // 0x30
	private static object s_ReflectionMethodsCache; // 0x0

	// Properties
	public static object Singleton { get; }

	// Methods

	// RVA: 0x76D1514
	public object .ctor() { }

	// RVA: 0x76D226C
	public static object get_Singleton() { }

}

// Namespace: UnityEngine.UI
public class VertexHelper
{

	// Fields
	private object m_Positions; // 0x8
	private object m_Colors; // 0x10
	private object m_Uv0S; // 0x18
	private object m_Uv1S; // 0x20
	private object m_Uv2S; // 0x28
	private object m_Uv3S; // 0x30
	private object m_Normals; // 0x38
	private object m_Tangents; // 0x40
	private object m_Indices; // 0x48
	private static readonly object s_DefaultTangent; // 0x0
	private static readonly object s_DefaultNormal; // 0x10
	private object m_ListsInitalized; // 0x50

	// Properties
	public object currentVertCount { get; }
	public object currentIndexCount { get; }

	// Methods

	// RVA: 0x76D3774
	public object .ctor() { }

	// RVA: 0x76D377C
	public object .ctor(object m) { }

	// RVA: 0x76D3A44
	private object InitializeListIfRequired() { }

	// RVA: 0x76D3C34
	public object Dispose() { }

	// RVA: 0x76BC180
	public object Clear() { }

	// RVA: 0x76D3E58
	public object get_currentVertCount() { }

	// RVA: 0x76D3EB0
	public object get_currentIndexCount() { }

	// RVA: 0x76D3F08
	public object PopulateUIVertex(object vertex, object i) { }

	// RVA: 0x76D40D4
	public object SetUIVertex(object vertex, object i) { }

	// RVA: 0x76D429C
	public object FillMesh(object mesh) { }

	// RVA: 0x76D441C
	public object AddVert(object position, object color, object uv0, object uv1, object uv2, object uv3, object normal, object tangent) { }

	// RVA: 0x76D4B5C
	public object AddVert(object position, object color, object uv0, object uv1, object normal, object tangent) { }

	// RVA: 0x76BC318
	public object AddVert(object position, object color, object uv0) { }

	// RVA: 0x76D4C94
	public object AddVert(object v) { }

	// RVA: 0x76BC4C4
	public object AddTriangle(object idx0, object idx1, object idx2) { }

	// RVA: 0x76CF1EC
	public object AddUIVertexQuad(object verts) { }

	// RVA: 0x76D4D14
	public object AddUIVertexStream(object verts, object indices) { }

	// RVA: 0x76D4DCC
	public object AddUIVertexTriangleStream(object verts) { }

	// RVA: 0x76D4E20
	public object GetUIVertexStream(object stream) { }

	// RVA: 0x76D4E74
	private static object .cctor() { }

}

// Namespace: UnityEngine.UI
public abstract class BaseVertexEffect
{

	// Methods

	// RVA: -1
	public abstract object ModifyVertices(object vertices) { }

	// RVA: 0x76D4F18
	protected object .ctor() { }

}

// Namespace: UnityEngine.UI
public abstract class BaseMeshEffect
{

	// Fields
	private object m_Graphic; // 0x18

	// Properties
	protected object graphic { get; }

	// Methods

	// RVA: 0x76D4F20
	protected object get_graphic() { }

	// RVA: 0x76D4FF0
	protected override object OnEnable() { }

	// RVA: 0x76D51E4
	protected override object OnDisable() { }

	// RVA: 0x76D53F0
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x76D55FC
	public virtual object ModifyMesh(object mesh) { }

	// RVA: -1
	public abstract object ModifyMesh(object vh) { }

	// RVA: 0x76D57AC
	protected object .ctor() { }

}

// Namespace: UnityEngine.UI
public interface IVertexModifier
{

	// Methods

	// RVA: -1
	public abstract object ModifyVertices(object verts) { }

}

// Namespace: UnityEngine.UI
public interface IMeshModifier
{

	// Methods

	// RVA: -1
	public abstract object ModifyMesh(object mesh) { }

	// RVA: -1
	public abstract object ModifyMesh(object verts) { }

}

// Namespace: UnityEngine.UI
public class Outline
{

	// Methods

	// RVA: 0x76D57B4
	protected object .ctor() { }

	// RVA: 0x76D57BC
	public override object ModifyMesh(object vh) { }

}

// Namespace: UnityEngine.UI
public class PositionAsUV1
{

	// Methods

	// RVA: 0x76D5A74
	protected object .ctor() { }

	// RVA: 0x76D5A7C
	public override object ModifyMesh(object vh) { }

}

// Namespace: UnityEngine.UI
public class Shadow
{

	// Fields
	private object m_EffectColor; // 0x20
	private object m_EffectDistance; // 0x30
	private object m_UseGraphicAlpha; // 0x38
	private const object kMaxEffectDistance;

	// Properties
	public object effectColor { get; set; }
	public object effectDistance { get; set; }
	public object useGraphicAlpha { get; set; }

	// Methods

	// RVA: 0x76D5B44
	protected object .ctor() { }

	// RVA: 0x76D5B6C
	public object get_effectColor() { }

	// RVA: 0x76D5B78
	public object set_effectColor(object value) { }

	// RVA: 0x76D5C94
	public object get_effectDistance() { }

	// RVA: 0x76D5C9C
	public object set_effectDistance(object value) { }

	// RVA: 0x76D5DF0
	public object get_useGraphicAlpha() { }

	// RVA: 0x76D5DF8
	public object set_useGraphicAlpha(object value) { }

	// RVA: 0x76D5EEC
	protected object ApplyShadowZeroAlloc(object verts, object color, object start, object end, object x, object y) { }

	// RVA: 0x76D6264
	protected object ApplyShadow(object verts, object color, object start, object end, object x, object y) { }

	// RVA: 0x76D626C
	public override object ModifyMesh(object vh) { }

}

// Namespace: UnityEngine.UI.Collections
internal class IndexedSet<T0>
{

	// Fields
	private readonly object m_List; // 0x0
	private object m_Dictionary; // 0x0
	private object m_EnabledObjectCount; // 0x0

	// Properties
	public object Count { get; }
	public object Capacity { get; }
	public object IsReadOnly { get; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Add(object item, object isActive) { }

	// RVA: -1
	public object AddUnique(object item, object isActive) { }

	// RVA: -1
	public object EnableItem(object item) { }

	// RVA: -1
	public object DisableItem(object item) { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Capacity() { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	public object IndexOf(object item) { }

	// RVA: -1
	public object Insert(object index, object item) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	private object Swap(object index1, object index2) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object RemoveAll(object match) { }

	// RVA: -1
	public object Sort(object sortLayoutFunction) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UI.CoroutineTween
internal interface ITweenValue
{

	// Properties
	public abstract object ignoreTimeScale { get; }
	public abstract object duration { get; }

	// Methods

	// RVA: -1
	public abstract object TweenValue(object floatPercentage) { }

	// RVA: -1
	public abstract object get_ignoreTimeScale() { }

	// RVA: -1
	public abstract object get_duration() { }

	// RVA: -1
	public abstract object ValidTarget() { }

}

// Namespace: 
public enum ColorTweenMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object All;
	public const object RGB;
	public const object Alpha;
}

// Namespace: 
public class ColorTweenCallback
{

	// Methods

	// RVA: 0x76D675C
	public object .ctor() { }

}

// Namespace: UnityEngine.UI.CoroutineTween
internal struct ColorTween
{

	// Fields
	private object m_Target; // 0xFFFFFFFFFFFFFFF8
	private object m_StartColor; // 0x0
	private object m_TargetColor; // 0x10
	private object m_TweenMode; // 0x20
	private object m_Duration; // 0x24
	private object m_IgnoreTimeScale; // 0x28

	// Properties
	public object startColor { get; set; }
	public object targetColor { get; set; }
	public object tweenMode { get; set; }
	public object duration { get; set; }
	public object ignoreTimeScale { get; set; }

	// Methods

	// RVA: 0x76D6400
	public object get_startColor() { }

	// RVA: 0x76D6418
	public object set_startColor(object value) { }

	// RVA: 0x76D6430
	public object get_targetColor() { }

	// RVA: 0x76D6448
	public object set_targetColor(object value) { }

	// RVA: 0x76D6460
	public object get_tweenMode() { }

	// RVA: 0x76D6470
	public object set_tweenMode(object value) { }

	// RVA: 0x76D6480
	public object get_duration() { }

	// RVA: 0x76D6490
	public object set_duration(object value) { }

	// RVA: 0x76D64A0
	public object get_ignoreTimeScale() { }

	// RVA: 0x76D64B0
	public object set_ignoreTimeScale(object value) { }

	// RVA: 0x76D64C0
	public object TweenValue(object floatPercentage) { }

	// RVA: 0x76D6688
	public object AddOnChangedCallback(object callback) { }

	// RVA: 0x76D67BC
	public object GetIgnoreTimescale() { }

	// RVA: 0x76D67CC
	public object GetDuration() { }

	// RVA: 0x76D659C
	public object ValidTarget() { }

}

// Namespace: 
public class FloatTweenCallback
{

	// Methods

	// RVA: 0x76D6AB4
	public object .ctor() { }

}

// Namespace: UnityEngine.UI.CoroutineTween
internal struct FloatTween
{

	// Fields
	private object m_Target; // 0xFFFFFFFFFFFFFFF8
	private object m_StartValue; // 0x0
	private object m_TargetValue; // 0x4
	private object m_Duration; // 0x8
	private object m_IgnoreTimeScale; // 0xC

	// Properties
	public object startValue { get; set; }
	public object targetValue { get; set; }
	public object duration { get; set; }
	public object ignoreTimeScale { get; set; }

	// Methods

	// RVA: 0x76D6828
	public object get_startValue() { }

	// RVA: 0x76D6838
	public object set_startValue(object value) { }

	// RVA: 0x76D6848
	public object get_targetValue() { }

	// RVA: 0x76D6858
	public object set_targetValue(object value) { }

	// RVA: 0x76D6868
	public object get_duration() { }

	// RVA: 0x76D6878
	public object set_duration(object value) { }

	// RVA: 0x76D6888
	public object get_ignoreTimeScale() { }

	// RVA: 0x76D6898
	public object set_ignoreTimeScale(object value) { }

	// RVA: 0x76D68A8
	public object TweenValue(object floatPercentage) { }

	// RVA: 0x76D69E0
	public object AddOnChangedCallback(object callback) { }

	// RVA: 0x76D6B14
	public object GetIgnoreTimescale() { }

	// RVA: 0x76D6B24
	public object GetDuration() { }

	// RVA: 0x76D693C
	public object ValidTarget() { }

}

// Namespace: 
private sealed class <Start>d__2
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	public object tweenInfo; // 0x0
	private object <elapsedTime>5__2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: UnityEngine.UI.CoroutineTween
internal class TweenRunner<T0>
{

	// Fields
	protected object m_CoroutineContainer; // 0x0
	protected object m_Tween; // 0x0

	// Methods

	// RVA: -1
	private static object Start(object tweenInfo) { }

	// RVA: -1
	public object Init(object coroutineContainer) { }

	// RVA: -1
	public object StartTween(object info) { }

	// RVA: -1
	public object StopTween() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private enum PointerEventType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Down;
	public const object Up;
}

// Namespace: 
private class PointerEvent
{

	// Fields
	private object <pointerId>k__BackingField; // 0x8
	private object <pointerType>k__BackingField; // 0x10
	private object <isPrimary>k__BackingField; // 0x18
	private object <button>k__BackingField; // 0x1C
	private object <pressedButtons>k__BackingField; // 0x20
	private object <position>k__BackingField; // 0x24
	private object <localPosition>k__BackingField; // 0x30
	private object <deltaPosition>k__BackingField; // 0x3C
	private object <deltaTime>k__BackingField; // 0x48
	private object <clickCount>k__BackingField; // 0x4C
	private object <pressure>k__BackingField; // 0x50
	private object <tangentialPressure>k__BackingField; // 0x54
	private object <altitudeAngle>k__BackingField; // 0x58
	private object <azimuthAngle>k__BackingField; // 0x5C
	private object <twist>k__BackingField; // 0x60
	private object <tilt>k__BackingField; // 0x64
	private object <penStatus>k__BackingField; // 0x6C
	private object <radius>k__BackingField; // 0x70
	private object <radiusVariance>k__BackingField; // 0x78
	private object <modifiers>k__BackingField; // 0x80

	// Properties
	public object pointerId { get; set; }
	public object pointerType { get; set; }
	public object isPrimary { get; set; }
	public object button { get; set; }
	public object pressedButtons { get; set; }
	public object position { get; set; }
	public object localPosition { get; set; }
	public object deltaPosition { get; set; }
	public object deltaTime { get; set; }
	public object clickCount { get; set; }
	public object pressure { get; set; }
	public object tangentialPressure { get; set; }
	public object altitudeAngle { get; set; }
	public object azimuthAngle { get; set; }
	public object twist { get; set; }
	public object tilt { get; set; }
	public object penStatus { get; set; }
	public object radius { get; set; }
	public object radiusVariance { get; set; }
	public object modifiers { get; set; }
	public object shiftKey { get; }
	public object ctrlKey { get; }
	public object commandKey { get; }
	public object altKey { get; }
	public object actionKey { get; }

	// Methods

	// RVA: 0x76D9C40
	public object get_pointerId() { }

	// RVA: 0x76D9C48
	private object set_pointerId(object value) { }

	// RVA: 0x76D9C50
	public object get_pointerType() { }

	// RVA: 0x76D9C58
	private object set_pointerType(object value) { }

	// RVA: 0x76D9C60
	public object get_isPrimary() { }

	// RVA: 0x76D9C68
	private object set_isPrimary(object value) { }

	// RVA: 0x76D9C70
	public object get_button() { }

	// RVA: 0x76D9C78
	private object set_button(object value) { }

	// RVA: 0x76D9C80
	public object get_pressedButtons() { }

	// RVA: 0x76D9C88
	private object set_pressedButtons(object value) { }

	// RVA: 0x76D9C90
	public object get_position() { }

	// RVA: 0x76D9C9C
	private object set_position(object value) { }

	// RVA: 0x76D9CA8
	public object get_localPosition() { }

	// RVA: 0x76D9CB4
	private object set_localPosition(object value) { }

	// RVA: 0x76D9CC0
	public object get_deltaPosition() { }

	// RVA: 0x76D9CCC
	private object set_deltaPosition(object value) { }

	// RVA: 0x76D9CD8
	public object get_deltaTime() { }

	// RVA: 0x76D9CE0
	private object set_deltaTime(object value) { }

	// RVA: 0x76D9CE8
	public object get_clickCount() { }

	// RVA: 0x76D9CF0
	private object set_clickCount(object value) { }

	// RVA: 0x76D9CF8
	public object get_pressure() { }

	// RVA: 0x76D9D00
	private object set_pressure(object value) { }

	// RVA: 0x76D9D08
	public object get_tangentialPressure() { }

	// RVA: 0x76D9D10
	private object set_tangentialPressure(object value) { }

	// RVA: 0x76D9D18
	public object get_altitudeAngle() { }

	// RVA: 0x76D9D20
	private object set_altitudeAngle(object value) { }

	// RVA: 0x76D9D28
	public object get_azimuthAngle() { }

	// RVA: 0x76D9D30
	private object set_azimuthAngle(object value) { }

	// RVA: 0x76D9D38
	public object get_twist() { }

	// RVA: 0x76D9D40
	private object set_twist(object value) { }

	// RVA: 0x76D9D48
	public object get_tilt() { }

	// RVA: 0x76D9D50
	private object set_tilt(object value) { }

	// RVA: 0x76D9D58
	public object get_penStatus() { }

	// RVA: 0x76D9D60
	private object set_penStatus(object value) { }

	// RVA: 0x76D9D68
	public object get_radius() { }

	// RVA: 0x76D9D70
	private object set_radius(object value) { }

	// RVA: 0x76D9D78
	public object get_radiusVariance() { }

	// RVA: 0x76D9D80
	private object set_radiusVariance(object value) { }

	// RVA: 0x76D9D88
	public object get_modifiers() { }

	// RVA: 0x76D9D90
	private object set_modifiers(object value) { }

	// RVA: 0x76D9D98
	public object get_shiftKey() { }

	// RVA: 0x76D9DA4
	public object get_ctrlKey() { }

	// RVA: 0x76D9DB0
	public object get_commandKey() { }

	// RVA: 0x76D9DBC
	public object get_altKey() { }

	// RVA: 0x76D9DC8
	public object get_actionKey() { }

	// RVA: 0x76D95D8
	public object Read(object self, object eventData, object eventType) { }

	// RVA: 0x76D9B80
	public object SetPosition(object positionOverride, object deltaOverride) { }

	// RVA: 0x76D9C30
	public object .ctor() { }

	// RVA: 0x76D9E94
	internal static object <Read>g__InRange|90_0(object i, object start, object count) { }

}

// Namespace: UnityEngine.UIElements
public class PanelEventHandler
{

	// Fields
	private object m_Panel; // 0x18
	private readonly object m_PointerEvent; // 0x20
	private object m_Selecting; // 0x28
	private object m_Event; // 0x30
	private static object s_Modifiers; // 0x0

	// Properties
	public object panel { get; set; }
	private object selectableGameObject { get; }
	private object eventSystem { get; }
	private object isCurrentFocusedPanel { get; }
	private object currentFocusedElement { get; }

	// Methods

	// RVA: 0x76D6B44
	public object get_panel() { }

	// RVA: 0x76D6B4C
	public object set_panel(object value) { }

	// RVA: 0x76D7048
	private object get_selectableGameObject() { }

	// RVA: 0x76D7060
	private object get_eventSystem() { }

	// RVA: 0x76D7180
	private object get_isCurrentFocusedPanel() { }

	// RVA: 0x76D727C
	private object get_currentFocusedElement() { }

	// RVA: 0x76D72E8
	protected override object OnEnable() { }

	// RVA: 0x76D72F0
	protected override object OnDisable() { }

	// RVA: 0x76D6E24
	private object RegisterCallbacks() { }

	// RVA: 0x76D6C00
	private object UnregisterCallbacks() { }

	// RVA: 0x76D72F8
	private object OnPanelDestroyed() { }

	// RVA: 0x76D7358
	private object OnElementFocus(object e) { }

	// RVA: 0x76D7540
	private object OnElementBlur(object e) { }

	// RVA: 0x76D7544
	public object OnSelect(object eventData) { }

	// RVA: 0x76D75C4
	public object OnDeselect(object eventData) { }

	// RVA: 0x76D75D8
	public object OnPointerMove(object eventData) { }

	// RVA: 0x76D79A0
	public object OnPointerUp(object eventData) { }

	// RVA: 0x76D7BA0
	public object OnPointerDown(object eventData) { }

	// RVA: 0x76D7E78
	public object OnPointerExit(object eventData) { }

	// RVA: 0x76D8154
	public object OnPointerEnter(object eventData) { }

	// RVA: 0x76D81CC
	public object OnSubmit(object eventData) { }

	// RVA: 0x76D8644
	public object OnCancel(object eventData) { }

	// RVA: 0x76D8890
	public object OnMove(object eventData) { }

	// RVA: 0x76D8B0C
	public object OnScroll(object eventData) { }

	// RVA: 0x76D7904
	private object SendEvent(object e, object sourceEventData) { }

	// RVA: 0x76D8CE0
	private object SendEvent(object e, object sourceEvent) { }

	// RVA: 0x76D8D64
	private object Update() { }

	// RVA: 0x76D8E38
	private object LateUpdate() { }

	// RVA: 0x76D8418
	private object ProcessImguiEvents(object target) { }

	// RVA: 0x76D8E40
	private object ProcessKeyboardEvent(object e, object target) { }

	// RVA: 0x76D8EDC
	private object ProcessTabEvent(object e, object target) { }

	// RVA: 0x76D93A4
	private object SendTabEvent(object e, object direction, object target) { }

	// RVA: 0x76D8F6C
	private object SendKeyUpEvent(object e, object target) { }

	// RVA: 0x76D9180
	private object SendKeyDownEvent(object e, object target) { }

	// RVA: 0x76D775C
	private object ReadPointerData(object pe, object eventData, object eventType) { }

	// RVA: 0x76D9B98
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class PanelRaycaster
{

	// Fields
	private object m_Panel; // 0x20

	// Properties
	public object panel { get; set; }
	private object selectableGameObject { get; }
	public override object sortOrderPriority { get; }
	public override object renderOrderPriority { get; }
	public override object eventCamera { get; }

	// Methods

	// RVA: 0x76D9EA8
	public object get_panel() { }

	// RVA: 0x76D9EB0
	public object set_panel(object value) { }

	// RVA: 0x76DA0D0
	private object RegisterCallbacks() { }

	// RVA: 0x76DA030
	private object UnregisterCallbacks() { }

	// RVA: 0x76DA170
	private object OnPanelDestroyed() { }

	// RVA: 0x76DA178
	private object get_selectableGameObject() { }

	// RVA: 0x76DA190
	public override object get_sortOrderPriority() { }

	// RVA: 0x76DA22C
	public override object get_renderOrderPriority() { }

	// RVA: 0x76DA2CC
	public override object Raycast(object eventData, object resultAppendList) { }

	// RVA: 0x76DA938
	public override object get_eventCamera() { }

	// RVA: 0x76DA940
	public object .ctor() { }

}

// Namespace: UnityEngine.EventSystems
public class AxisEventData
{

	// Fields
	private object <moveVector>k__BackingField; // 0x18
	private object <moveDir>k__BackingField; // 0x20

	// Properties
	public object moveVector { get; set; }
	public object moveDir { get; set; }

	// Methods

	// RVA: 0x76DA950
	public object get_moveVector() { }

	// RVA: 0x76DA958
	public object set_moveVector(object value) { }

	// RVA: 0x76DA960
	public object get_moveDir() { }

	// RVA: 0x76DA968
	public object set_moveDir(object value) { }

	// RVA: 0x76DA970
	public object .ctor(object eventSystem) { }

}

// Namespace: UnityEngine.EventSystems
public abstract class AbstractEventData
{

	// Fields
	protected object m_Used; // 0x8

	// Properties
	public virtual object used { get; }

	// Methods

	// RVA: 0x76DAA10
	public virtual object Reset() { }

	// RVA: 0x76DAA18
	public virtual object Use() { }

	// RVA: 0x76DAA24
	public virtual object get_used() { }

	// RVA: 0x76DAA2C
	protected object .ctor() { }

}

// Namespace: UnityEngine.EventSystems
public class BaseEventData
{

	// Fields
	private readonly object m_EventSystem; // 0x10

	// Properties
	public object currentInputModule { get; }
	public object selectedObject { get; set; }

	// Methods

	// RVA: 0x76DA9E4
	public object .ctor(object eventSystem) { }

	// RVA: 0x76DAA34
	public object get_currentInputModule() { }

	// RVA: 0x76DAA58
	public object get_selectedObject() { }

	// RVA: 0x76DAA7C
	public object set_selectedObject(object value) { }

}

// Namespace: 
public enum InputButton
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
	public const object Middle;
}

// Namespace: 
public enum FramePressState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Pressed;
	public const object Released;
	public const object PressedAndReleased;
	public const object NotChanged;
}

// Namespace: UnityEngine.EventSystems
public class PointerEventData
{

	// Fields
	private object <pointerEnter>k__BackingField; // 0x18
	private object m_PointerPress; // 0x20
	private object <lastPress>k__BackingField; // 0x28
	private object <rawPointerPress>k__BackingField; // 0x30
	private object <pointerDrag>k__BackingField; // 0x38
	private object <pointerClick>k__BackingField; // 0x40
	private object <pointerCurrentRaycast>k__BackingField; // 0x48
	private object <pointerPressRaycast>k__BackingField; // 0x98
	public object hovered; // 0xE8
	private object <eligibleForClick>k__BackingField; // 0xF0
	private object <displayIndex>k__BackingField; // 0xF4
	private object <pointerId>k__BackingField; // 0xF8
	private object <position>k__BackingField; // 0xFC
	private object <delta>k__BackingField; // 0x104
	private object <pressPosition>k__BackingField; // 0x10C
	private object <worldPosition>k__BackingField; // 0x114
	private object <worldNormal>k__BackingField; // 0x120
	private object <clickTime>k__BackingField; // 0x12C
	private object <clickCount>k__BackingField; // 0x130
	private object <scrollDelta>k__BackingField; // 0x134
	private object <useDragThreshold>k__BackingField; // 0x13C
	private object <dragging>k__BackingField; // 0x13D
	private object <button>k__BackingField; // 0x140
	private object <pressure>k__BackingField; // 0x144
	private object <tangentialPressure>k__BackingField; // 0x148
	private object <altitudeAngle>k__BackingField; // 0x14C
	private object <azimuthAngle>k__BackingField; // 0x150
	private object <twist>k__BackingField; // 0x154
	private object <tilt>k__BackingField; // 0x158
	private object <penStatus>k__BackingField; // 0x160
	private object <radius>k__BackingField; // 0x164
	private object <radiusVariance>k__BackingField; // 0x16C
	private object <fullyExited>k__BackingField; // 0x174
	private object <reentered>k__BackingField; // 0x175

	// Properties
	public object pointerEnter { get; set; }
	public object lastPress { get; set; }
	public object rawPointerPress { get; set; }
	public object pointerDrag { get; set; }
	public object pointerClick { get; set; }
	public object pointerCurrentRaycast { get; set; }
	public object pointerPressRaycast { get; set; }
	public object eligibleForClick { get; set; }
	public object displayIndex { get; set; }
	public object pointerId { get; set; }
	public object position { get; set; }
	public object delta { get; set; }
	public object pressPosition { get; set; }
	public object worldPosition { get; set; }
	public object worldNormal { get; set; }
	public object clickTime { get; set; }
	public object clickCount { get; set; }
	public object scrollDelta { get; set; }
	public object useDragThreshold { get; set; }
	public object dragging { get; set; }
	public object button { get; set; }
	public object pressure { get; set; }
	public object tangentialPressure { get; set; }
	public object altitudeAngle { get; set; }
	public object azimuthAngle { get; set; }
	public object twist { get; set; }
	public object tilt { get; set; }
	public object penStatus { get; set; }
	public object radius { get; set; }
	public object radiusVariance { get; set; }
	public object fullyExited { get; set; }
	public object reentered { get; set; }
	public object enterEventCamera { get; }
	public object pressEventCamera { get; }
	public object pointerPress { get; set; }

	// Methods

	// RVA: 0x76DAD40
	public object get_pointerEnter() { }

	// RVA: 0x76DAD48
	public object set_pointerEnter(object value) { }

	// RVA: 0x76DAD50
	public object get_lastPress() { }

	// RVA: 0x76DAD58
	private object set_lastPress(object value) { }

	// RVA: 0x76DAD60
	public object get_rawPointerPress() { }

	// RVA: 0x76DAD68
	public object set_rawPointerPress(object value) { }

	// RVA: 0x76DAD70
	public object get_pointerDrag() { }

	// RVA: 0x76DAD78
	public object set_pointerDrag(object value) { }

	// RVA: 0x76DAD80
	public object get_pointerClick() { }

	// RVA: 0x76DAD88
	public object set_pointerClick(object value) { }

	// RVA: 0x76DAD90
	public object get_pointerCurrentRaycast() { }

	// RVA: 0x76DADB4
	public object set_pointerCurrentRaycast(object value) { }

	// RVA: 0x76DADC0
	public object get_pointerPressRaycast() { }

	// RVA: 0x76DADE4
	public object set_pointerPressRaycast(object value) { }

	// RVA: 0x76DADF0
	public object get_eligibleForClick() { }

	// RVA: 0x76DADF8
	public object set_eligibleForClick(object value) { }

	// RVA: 0x76DAE00
	public object get_displayIndex() { }

	// RVA: 0x76DAE08
	public object set_displayIndex(object value) { }

	// RVA: 0x76DAE10
	public object get_pointerId() { }

	// RVA: 0x76DAE18
	public object set_pointerId(object value) { }

	// RVA: 0x76DAE20
	public object get_position() { }

	// RVA: 0x76DAE28
	public object set_position(object value) { }

	// RVA: 0x76DAE30
	public object get_delta() { }

	// RVA: 0x76DAE3C
	public object set_delta(object value) { }

	// RVA: 0x76DAE48
	public object get_pressPosition() { }

	// RVA: 0x76DAE54
	public object set_pressPosition(object value) { }

	// RVA: 0x76DAE60
	public object get_worldPosition() { }

	// RVA: 0x76DAE70
	public object set_worldPosition(object value) { }

	// RVA: 0x76DAE80
	public object get_worldNormal() { }

	// RVA: 0x76DAE90
	public object set_worldNormal(object value) { }

	// RVA: 0x76DAEA0
	public object get_clickTime() { }

	// RVA: 0x76DAEA8
	public object set_clickTime(object value) { }

	// RVA: 0x76DAEB0
	public object get_clickCount() { }

	// RVA: 0x76DAEB8
	public object set_clickCount(object value) { }

	// RVA: 0x76DAEC0
	public object get_scrollDelta() { }

	// RVA: 0x76DAECC
	public object set_scrollDelta(object value) { }

	// RVA: 0x76DAED8
	public object get_useDragThreshold() { }

	// RVA: 0x76DAEE0
	public object set_useDragThreshold(object value) { }

	// RVA: 0x76DAEE8
	public object get_dragging() { }

	// RVA: 0x76DAEF0
	public object set_dragging(object value) { }

	// RVA: 0x76DAEF8
	public object get_button() { }

	// RVA: 0x76DAF00
	public object set_button(object value) { }

	// RVA: 0x76DAF08
	public object get_pressure() { }

	// RVA: 0x76DAF10
	public object set_pressure(object value) { }

	// RVA: 0x76DAF18
	public object get_tangentialPressure() { }

	// RVA: 0x76DAF20
	public object set_tangentialPressure(object value) { }

	// RVA: 0x76DAF28
	public object get_altitudeAngle() { }

	// RVA: 0x76DAF30
	public object set_altitudeAngle(object value) { }

	// RVA: 0x76DAF38
	public object get_azimuthAngle() { }

	// RVA: 0x76DAF40
	public object set_azimuthAngle(object value) { }

	// RVA: 0x76DAF48
	public object get_twist() { }

	// RVA: 0x76DAF50
	public object set_twist(object value) { }

	// RVA: 0x76DAF58
	public object get_tilt() { }

	// RVA: 0x76DAF64
	public object set_tilt(object value) { }

	// RVA: 0x76DAF70
	public object get_penStatus() { }

	// RVA: 0x76DAF78
	public object set_penStatus(object value) { }

	// RVA: 0x76DAF80
	public object get_radius() { }

	// RVA: 0x76DAF8C
	public object set_radius(object value) { }

	// RVA: 0x76DAF98
	public object get_radiusVariance() { }

	// RVA: 0x76DAFA4
	public object set_radiusVariance(object value) { }

	// RVA: 0x76DAFB0
	public object get_fullyExited() { }

	// RVA: 0x76DAFB8
	public object set_fullyExited(object value) { }

	// RVA: 0x76DAFC0
	public object get_reentered() { }

	// RVA: 0x76DAFC8
	public object set_reentered(object value) { }

	// RVA: 0x76DAFD0
	public object .ctor(object eventSystem) { }

	// RVA: 0x76DB0F0
	public object IsPointerMoving() { }

	// RVA: 0x76DB110
	public object IsScrolling() { }

	// RVA: 0x76DB130
	public object get_enterEventCamera() { }

	// RVA: 0x76DB214
	public object get_pressEventCamera() { }

	// RVA: 0x76DB2F8
	public object get_pointerPress() { }

	// RVA: 0x76DB300
	public object set_pointerPress(object value) { }

	// RVA: 0x76DB3B4
	public override object ToString() { }

}

// Namespace: UnityEngine.EventSystems
public enum EventHandle
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unused;
	public const object Used;
}

// Namespace: UnityEngine.EventSystems
public interface IEventSystemHandler
{
}

// Namespace: UnityEngine.EventSystems
public interface IPointerMoveHandler
{

	// Methods

	// RVA: -1
	public abstract object OnPointerMove(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IPointerEnterHandler
{

	// Methods

	// RVA: -1
	public abstract object OnPointerEnter(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IPointerExitHandler
{

	// Methods

	// RVA: -1
	public abstract object OnPointerExit(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IPointerDownHandler
{

	// Methods

	// RVA: -1
	public abstract object OnPointerDown(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IPointerUpHandler
{

	// Methods

	// RVA: -1
	public abstract object OnPointerUp(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IPointerClickHandler
{

	// Methods

	// RVA: -1
	public abstract object OnPointerClick(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IBeginDragHandler
{

	// Methods

	// RVA: -1
	public abstract object OnBeginDrag(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IInitializePotentialDragHandler
{

	// Methods

	// RVA: -1
	public abstract object OnInitializePotentialDrag(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IDragHandler
{

	// Methods

	// RVA: -1
	public abstract object OnDrag(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IEndDragHandler
{

	// Methods

	// RVA: -1
	public abstract object OnEndDrag(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IDropHandler
{

	// Methods

	// RVA: -1
	public abstract object OnDrop(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IScrollHandler
{

	// Methods

	// RVA: -1
	public abstract object OnScroll(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IUpdateSelectedHandler
{

	// Methods

	// RVA: -1
	public abstract object OnUpdateSelected(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface ISelectHandler
{

	// Methods

	// RVA: -1
	public abstract object OnSelect(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IDeselectHandler
{

	// Methods

	// RVA: -1
	public abstract object OnDeselect(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface IMoveHandler
{

	// Methods

	// RVA: -1
	public abstract object OnMove(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface ISubmitHandler
{

	// Methods

	// RVA: -1
	public abstract object OnSubmit(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public interface ICancelHandler
{

	// Methods

	// RVA: -1
	public abstract object OnCancel(object eventData) { }

}

// Namespace: 
private struct UIToolkitOverrideConfig
{

	// Fields
	public object activeEventSystem; // 0xFFFFFFFFFFFFFFF8
	public object sendEvents; // 0x0
	public object createPanelGameObjectsOnStart; // 0x1
}

// Namespace: 
private sealed class <>c__DisplayClass56_0
{

	// Fields
	public object go; // 0x8

	// Methods

	// RVA: 0x76DDC58
	public object .ctor() { }

	// RVA: 0x76DE9E0
	internal object <CreateUIToolkitPanelGameObject>b__0() { }

}

// Namespace: UnityEngine.EventSystems
public class EventSystem
{

	// Fields
	private object m_SystemInputModules; // 0x18
	private object m_CurrentInputModule; // 0x20
	private static object m_EventSystems; // 0x0
	private object m_FirstSelected; // 0x28
	private object m_sendNavigationEvents; // 0x30
	private object m_DragThreshold; // 0x34
	private object m_CurrentSelected; // 0x38
	private object m_HasFocus; // 0x40
	private object m_SelectionGuard; // 0x41
	private object m_DummyData; // 0x48
	private static readonly object s_RaycastComparer; // 0x8
	private static object s_UIToolkitOverride; // 0x10
	private object m_Started; // 0x50
	private object m_IsTrackingUIToolkitPanels; // 0x51

	// Properties
	public static object current { get; set; }
	public object sendNavigationEvents { get; set; }
	public object pixelDragThreshold { get; set; }
	public object currentInputModule { get; }
	public object firstSelectedGameObject { get; set; }
	public object currentSelectedGameObject { get; }
	public object lastSelectedGameObject { get; }
	public object isFocused { get; }
	public object alreadySelecting { get; }
	private object baseEventDataCache { get; }
	private object isUIToolkitActiveEventSystem { get; }
	private object sendUIToolkitEvents { get; }
	private object createUIToolkitPanelGameObjectsOnStart { get; }

	// Methods

	// RVA: 0x76DC0F0
	public static object get_current() { }

	// RVA: 0x76DC1E4
	public static object set_current(object value) { }

	// RVA: 0x76DC3EC
	public object get_sendNavigationEvents() { }

	// RVA: 0x76DC3F4
	public object set_sendNavigationEvents(object value) { }

	// RVA: 0x76DC3FC
	public object get_pixelDragThreshold() { }

	// RVA: 0x76DC404
	public object set_pixelDragThreshold(object value) { }

	// RVA: 0x76DC40C
	public object get_currentInputModule() { }

	// RVA: 0x76DC414
	public object get_firstSelectedGameObject() { }

	// RVA: 0x76DC41C
	public object set_firstSelectedGameObject(object value) { }

	// RVA: 0x76DC424
	public object get_currentSelectedGameObject() { }

	// RVA: 0x76DC42C
	public object get_lastSelectedGameObject() { }

	// RVA: 0x76DC434
	public object get_isFocused() { }

	// RVA: 0x76DC43C
	protected object .ctor() { }

	// RVA: 0x76DC4D0
	public object UpdateModules() { }

	// RVA: 0x76DC6D0
	public object get_alreadySelecting() { }

	// RVA: 0x76DAAA0
	public object SetSelectedGameObject(object selected, object pointer) { }

	// RVA: 0x76DC6D8
	private object get_baseEventDataCache() { }

	// RVA: 0x76D74A0
	public object SetSelectedGameObject(object selected) { }

	// RVA: 0x76DC758
	private static object RaycastComparer(object lhs, object rhs) { }

	// RVA: 0x76DCE3C
	public object RaycastAll(object eventData, object raycastResults) { }

	// RVA: 0x76DD0B8
	public object IsPointerOverGameObject() { }

	// RVA: 0x76DD0C0
	public object IsPointerOverGameObject(object pointerId) { }

	// RVA: 0x76DD1A8
	private object get_isUIToolkitActiveEventSystem() { }

	// RVA: 0x76DD2E8
	private object get_sendUIToolkitEvents() { }

	// RVA: 0x76DD38C
	private object get_createUIToolkitPanelGameObjectsOnStart() { }

	// RVA: 0x76DD430
	public static object SetUITookitEventSystemOverride(object activeEventSystem, object sendEvents, object createPanelGameObjectsOnStart) { }

	// RVA: 0x76DD5F0
	private object StartTrackingUIToolkitPanels() { }

	// RVA: 0x76DDB80
	private object StopTrackingUIToolkitPanels() { }

	// RVA: 0x76DD8A0
	private object CreateUIToolkitPanelGameObject(object panel) { }

	// RVA: 0x76DDC60
	protected override object Start() { }

	// RVA: 0x76DDC70
	protected override object OnEnable() { }

	// RVA: 0x76DDE94
	protected override object OnDisable() { }

	// RVA: 0x76DE010
	private object TickModules() { }

	// RVA: 0x76DE17C
	protected virtual object OnApplicationFocus(object hasFocus) { }

	// RVA: 0x76DE18C
	protected virtual object Update() { }

	// RVA: 0x76DE520
	private object ChangeEventModule(object module) { }

	// RVA: 0x76DE6D8
	public override object ToString() { }

	// RVA: 0x76DE8AC
	private static object .cctor() { }

}

// Namespace: 
public class TriggerEvent
{

	// Methods

	// RVA: 0x76DEE10
	public object .ctor() { }

}

// Namespace: 
public class Entry
{

	// Fields
	public object eventID; // 0x8
	public object callback; // 0x10

	// Methods

	// RVA: 0x76DEE68
	public object .ctor() { }

}

// Namespace: UnityEngine.EventSystems
public class EventTrigger
{

	// Fields
	private object m_Delegates; // 0x18

	// Properties
	public object delegates { get; set; }
	public object triggers { get; set; }

	// Methods

	// RVA: 0x76DEA70
	public object get_delegates() { }

	// RVA: 0x76DEB90
	public object set_delegates(object value) { }

	// RVA: 0x76DEB98
	protected object .ctor() { }

	// RVA: 0x76DEB00
	public object get_triggers() { }

	// RVA: 0x76DEBA0
	public object set_triggers(object value) { }

	// RVA: 0x76DEBA8
	private object Execute(object id, object eventData) { }

	// RVA: 0x76DED44
	public virtual object OnPointerEnter(object eventData) { }

	// RVA: 0x76DED50
	public virtual object OnPointerExit(object eventData) { }

	// RVA: 0x76DED5C
	public virtual object OnDrag(object eventData) { }

	// RVA: 0x76DED68
	public virtual object OnDrop(object eventData) { }

	// RVA: 0x76DED74
	public virtual object OnPointerDown(object eventData) { }

	// RVA: 0x76DED80
	public virtual object OnPointerUp(object eventData) { }

	// RVA: 0x76DED8C
	public virtual object OnPointerClick(object eventData) { }

	// RVA: 0x76DED98
	public virtual object OnSelect(object eventData) { }

	// RVA: 0x76DEDA4
	public virtual object OnDeselect(object eventData) { }

	// RVA: 0x76DEDB0
	public virtual object OnScroll(object eventData) { }

	// RVA: 0x76DEDBC
	public virtual object OnMove(object eventData) { }

	// RVA: 0x76DEDC8
	public virtual object OnUpdateSelected(object eventData) { }

	// RVA: 0x76DEDD4
	public virtual object OnInitializePotentialDrag(object eventData) { }

	// RVA: 0x76DEDE0
	public virtual object OnBeginDrag(object eventData) { }

	// RVA: 0x76DEDEC
	public virtual object OnEndDrag(object eventData) { }

	// RVA: 0x76DEDF8
	public virtual object OnSubmit(object eventData) { }

	// RVA: 0x76DEE04
	public virtual object OnCancel(object eventData) { }

}

// Namespace: UnityEngine.EventSystems
public enum EventTriggerType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PointerEnter;
	public const object PointerExit;
	public const object PointerDown;
	public const object PointerUp;
	public const object PointerClick;
	public const object Drag;
	public const object Drop;
	public const object Scroll;
	public const object UpdateSelected;
	public const object Select;
	public const object Deselect;
	public const object Move;
	public const object InitializePotentialDrag;
	public const object BeginDrag;
	public const object EndDrag;
	public const object Submit;
	public const object Cancel;
}

// Namespace: 
public sealed class EventFunction<T0>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object handler, object eventData) { }

	// RVA: -1
	public virtual object BeginInvoke(object handler, object eventData, object callback, object object) { }

	// RVA: -1
	public virtual object EndInvoke(object result) { }

}

// Namespace: UnityEngine.EventSystems
public static class ExecuteEvents
{

	// Fields
	private static readonly object s_PointerMoveHandler; // 0x0
	private static readonly object s_PointerEnterHandler; // 0x8
	private static readonly object s_PointerExitHandler; // 0x10
	private static readonly object s_PointerDownHandler; // 0x18
	private static readonly object s_PointerUpHandler; // 0x20
	private static readonly object s_PointerClickHandler; // 0x28
	private static readonly object s_InitializePotentialDragHandler; // 0x30
	private static readonly object s_BeginDragHandler; // 0x38
	private static readonly object s_DragHandler; // 0x40
	private static readonly object s_EndDragHandler; // 0x48
	private static readonly object s_DropHandler; // 0x50
	private static readonly object s_ScrollHandler; // 0x58
	private static readonly object s_UpdateSelectedHandler; // 0x60
	private static readonly object s_SelectHandler; // 0x68
	private static readonly object s_DeselectHandler; // 0x70
	private static readonly object s_MoveHandler; // 0x78
	private static readonly object s_SubmitHandler; // 0x80
	private static readonly object s_CancelHandler; // 0x88
	private static readonly object s_InternalTransformList; // 0x90

	// Properties
	public static object pointerMoveHandler { get; }
	public static object pointerEnterHandler { get; }
	public static object pointerExitHandler { get; }
	public static object pointerDownHandler { get; }
	public static object pointerUpHandler { get; }
	public static object pointerClickHandler { get; }
	public static object initializePotentialDrag { get; }
	public static object beginDragHandler { get; }
	public static object dragHandler { get; }
	public static object endDragHandler { get; }
	public static object dropHandler { get; }
	public static object scrollHandler { get; }
	public static object updateSelectedHandler { get; }
	public static object selectHandler { get; }
	public static object deselectHandler { get; }
	public static object moveHandler { get; }
	public static object submitHandler { get; }
	public static object cancelHandler { get; }

	// Methods

	// RVA: -1
	public static object ValidateEventData(object data) { }

	// RVA: 0x76DEF08
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DF044
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DF180
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DF2BC
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DF3F8
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DF534
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DF670
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DF7AC
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DF8E8
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DFA24
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DFB60
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DFC9C
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DFDD8
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DFEA8
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76DFF78
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76E0048
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76E0184
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76E0254
	private static object Execute(object handler, object eventData) { }

	// RVA: 0x76E0324
	public static object get_pointerMoveHandler() { }

	// RVA: 0x76E03A0
	public static object get_pointerEnterHandler() { }

	// RVA: 0x76E041C
	public static object get_pointerExitHandler() { }

	// RVA: 0x76E0498
	public static object get_pointerDownHandler() { }

	// RVA: 0x76E0514
	public static object get_pointerUpHandler() { }

	// RVA: 0x76E0590
	public static object get_pointerClickHandler() { }

	// RVA: 0x76E060C
	public static object get_initializePotentialDrag() { }

	// RVA: 0x76E0688
	public static object get_beginDragHandler() { }

	// RVA: 0x76E0704
	public static object get_dragHandler() { }

	// RVA: 0x76E0780
	public static object get_endDragHandler() { }

	// RVA: 0x76E07FC
	public static object get_dropHandler() { }

	// RVA: 0x76E0878
	public static object get_scrollHandler() { }

	// RVA: 0x76E08F4
	public static object get_updateSelectedHandler() { }

	// RVA: 0x76E0970
	public static object get_selectHandler() { }

	// RVA: 0x76E09EC
	public static object get_deselectHandler() { }

	// RVA: 0x76E0A68
	public static object get_moveHandler() { }

	// RVA: 0x76E0AE4
	public static object get_submitHandler() { }

	// RVA: 0x76E0B60
	public static object get_cancelHandler() { }

	// RVA: 0x76E0BDC
	private static object GetEventChain(object root, object eventChain) { }

	// RVA: -1
	public static object Execute(object target, object eventData, object functor) { }

	// RVA: -1
	public static object ExecuteHierarchy(object root, object eventData, object callbackFunction) { }

	// RVA: -1
	private static object ShouldSendToComponent(object component) { }

	// RVA: -1
	private static object GetEventList(object go, object results) { }

	// RVA: -1
	public static object CanHandleEvent(object go) { }

	// RVA: -1
	public static object GetEventHandler(object root) { }

	// RVA: 0x76E0E1C
	private static object .cctor() { }

}

// Namespace: UnityEngine.EventSystems
public class BaseInput
{

	// Properties
	public virtual object compositionString { get; }
	public virtual object imeCompositionMode { get; set; }
	public virtual object compositionCursorPos { get; set; }
	public virtual object mousePresent { get; }
	public virtual object mousePosition { get; }
	public virtual object mouseScrollDelta { get; }
	public virtual object touchSupported { get; }
	public virtual object touchCount { get; }

	// Methods

	// RVA: 0x76E1468
	public virtual object get_compositionString() { }

	// RVA: 0x76E1470
	public virtual object get_imeCompositionMode() { }

	// RVA: 0x76E1478
	public virtual object set_imeCompositionMode(object value) { }

	// RVA: 0x76E1484
	public virtual object get_compositionCursorPos() { }

	// RVA: 0x76E148C
	public virtual object set_compositionCursorPos(object value) { }

	// RVA: 0x76E1494
	public virtual object get_mousePresent() { }

	// RVA: 0x76E149C
	public virtual object GetMouseButtonDown(object button) { }

	// RVA: 0x76E14A8
	public virtual object GetMouseButtonUp(object button) { }

	// RVA: 0x76E14B4
	public virtual object GetMouseButton(object button) { }

	// RVA: 0x76E14C0
	public virtual object get_mousePosition() { }

	// RVA: 0x76E14C8
	public virtual object get_mouseScrollDelta() { }

	// RVA: 0x76E14D0
	public virtual object get_touchSupported() { }

	// RVA: 0x76E14D8
	public virtual object get_touchCount() { }

	// RVA: 0x76E14E0
	public virtual object GetTouch(object index) { }

	// RVA: 0x76E14EC
	public virtual object GetAxisRaw(object axisName) { }

	// RVA: 0x76E14F8
	public virtual object GetButtonDown(object buttonName) { }

	// RVA: 0x76E1504
	public object .ctor() { }

}

// Namespace: UnityEngine.EventSystems
public abstract class BaseInputModule
{

	// Fields
	protected object m_RaycastResultCache; // 0x18
	private object m_SendPointerHoverToParent; // 0x20
	private object m_AxisEventData; // 0x28
	private object m_EventSystem; // 0x30
	private object m_BaseEventData; // 0x38
	protected object m_InputOverride; // 0x40
	private object m_DefaultInput; // 0x48

	// Properties
	internal object sendPointerHoverToParent { get; set; }
	public object input { get; }
	public object inputOverride { get; set; }
	protected object eventSystem { get; }

	// Methods

	// RVA: 0x76E150C
	internal object get_sendPointerHoverToParent() { }

	// RVA: 0x76E1514
	internal object set_sendPointerHoverToParent(object value) { }

	// RVA: 0x76E151C
	public object get_input() { }

	// RVA: 0x76E17C0
	public object get_inputOverride() { }

	// RVA: 0x76E17C8
	public object set_inputOverride(object value) { }

	// RVA: 0x76E17D0
	protected object get_eventSystem() { }

	// RVA: 0x76E17D8
	protected override object OnEnable() { }

	// RVA: 0x76E1844
	protected override object OnDisable() { }

	// RVA: -1
	public abstract object Process() { }

	// RVA: 0x76E1864
	protected static object FindFirstRaycast(object candidates) { }

	// RVA: 0x76E197C
	protected static object DetermineMoveDirection(object x, object y) { }

	// RVA: 0x76E19D0
	protected static object DetermineMoveDirection(object x, object y, object deadZone) { }

	// RVA: 0x76E1A1C
	protected static object FindCommonRoot(object g1, object g2) { }

	// RVA: 0x76E1C4C
	protected object HandlePointerExitAndEnter(object currentPointerData, object newEnterTarget) { }

	// RVA: 0x76E2A94
	protected virtual object GetAxisEventData(object x, object y, object moveDeadZone) { }

	// RVA: 0x76E2C08
	protected virtual object GetBaseEventData() { }

	// RVA: 0x76E2CC0
	public virtual object IsPointerOverGameObject(object pointerId) { }

	// RVA: 0x76E2CC8
	public virtual object ShouldActivateModule() { }

	// RVA: 0x76E2D1C
	public virtual object DeactivateModule() { }

	// RVA: 0x76E2D20
	public virtual object ActivateModule() { }

	// RVA: 0x76E2D24
	public virtual object UpdateModule() { }

	// RVA: 0x76E2D28
	public virtual object IsModuleSupported() { }

	// RVA: 0x76E2D30
	public virtual object ConvertUIToolkitPointerId(object sourcePointerData) { }

	// RVA: 0x76E2DE4
	protected object .ctor() { }

}

// Namespace: 
protected class ButtonState
{

	// Fields
	private object m_Button; // 0x8
	private object m_EventData; // 0x10

	// Properties
	public object eventData { get; set; }
	public object button { get; set; }

	// Methods

	// RVA: 0x76E4AD8
	public object get_eventData() { }

	// RVA: 0x76E4AE0
	public object set_eventData(object value) { }

	// RVA: 0x76E4AE8
	public object get_button() { }

	// RVA: 0x76E4AF0
	public object set_button(object value) { }

	// RVA: 0x76E4AF8
	public object .ctor() { }

}

// Namespace: 
protected class MouseState
{

	// Fields
	private object m_TrackedButtons; // 0x8

	// Methods

	// RVA: 0x76E4B00
	public object AnyPressesThisFrame() { }

	// RVA: 0x76E4C1C
	public object AnyReleasesThisFrame() { }

	// RVA: 0x76E4D40
	public object GetButtonState(object button) { }

	// RVA: 0x76E3C08
	public object SetButtonState(object button, object stateForMouseButton, object data) { }

	// RVA: 0x76E4A58
	public object .ctor() { }

}

// Namespace: 
public class MouseButtonEventData
{

	// Fields
	public object buttonState; // 0x8
	public object buttonData; // 0x10

	// Methods

	// RVA: 0x76E4C0C
	public object PressedThisFrame() { }

	// RVA: 0x76E4D2C
	public object ReleasedThisFrame() { }

	// RVA: 0x76E4F90
	public object .ctor() { }

}

// Namespace: UnityEngine.EventSystems
public abstract class PointerInputModule
{

	// Fields
	public const object kMouseLeftId;
	public const object kMouseRightId;
	public const object kMouseMiddleId;
	public const object kFakeTouchesId;
	protected object m_PointerData; // 0x50
	private readonly object m_MouseState; // 0x58

	// Methods

	// RVA: 0x76E2E6C
	protected object GetPointerData(object id, object data, object create) { }

	// RVA: 0x76E2F7C
	protected object RemovePointerData(object data) { }

	// RVA: 0x76E2FF8
	protected object GetTouchPointerEventData(object input, object pressed, object released) { }

	// RVA: 0x76E3470
	protected object CopyFromTo(object from, object to) { }

	// RVA: 0x76E3528
	protected object StateForMouseButton(object buttonId) { }

	// RVA: 0x76E3604
	protected virtual object GetMousePointerEventData() { }

	// RVA: 0x76E364C
	protected virtual object GetMousePointerEventData(object id) { }

	// RVA: 0x76E3C58
	protected object GetLastPointerEventData(object id) { }

	// RVA: 0x76E3CF4
	private static object ShouldStartDrag(object pressPos, object currentPos, object threshold, object useDragThreshold) { }

	// RVA: 0x76E3D24
	protected virtual object ProcessMove(object pointerEvent) { }

	// RVA: 0x76E3D74
	protected virtual object ProcessDrag(object pointerEvent) { }

	// RVA: 0x76E4160
	public override object IsPointerOverGameObject(object pointerId) { }

	// RVA: 0x76E427C
	protected object ClearSelection() { }

	// RVA: 0x76E44A8
	public override object ToString() { }

	// RVA: 0x76E47A4
	protected object DeselectIfSelectionChanged(object currentOverGo, object pointerEvent) { }

	// RVA: 0x76E48F0
	protected object .ctor() { }

}

// Namespace: 
public enum InputMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Mouse;
	public const object Buttons;
}

// Namespace: UnityEngine.EventSystems
public class StandaloneInputModule
{

	// Fields
	private object m_PrevActionTime; // 0x60
	private object m_LastMoveVector; // 0x64
	private object m_ConsecutiveMoveCount; // 0x6C
	private object m_LastMousePosition; // 0x70
	private object m_MousePosition; // 0x78
	private object m_CurrentFocusedGameObject; // 0x80
	private object m_InputPointerEvent; // 0x88
	private object m_HorizontalAxis; // 0x90
	private object m_VerticalAxis; // 0x98
	private object m_SubmitButton; // 0xA0
	private object m_CancelButton; // 0xA8
	private object m_InputActionsPerSecond; // 0xB0
	private object m_RepeatDelay; // 0xB4
	private object m_ForceModuleActive; // 0xB8

	// Properties
	public object inputMode { get; }
	public object allowActivationOnMobileDevice { get; set; }
	public object forceModuleActive { get; set; }
	public object inputActionsPerSecond { get; set; }
	public object repeatDelay { get; set; }
	public object horizontalAxis { get; set; }
	public object verticalAxis { get; set; }
	public object submitButton { get; set; }
	public object cancelButton { get; set; }

	// Methods

	// RVA: 0x76E4F98
	protected object .ctor() { }

	// RVA: 0x76E5054
	public object get_inputMode() { }

	// RVA: 0x76E505C
	public object get_allowActivationOnMobileDevice() { }

	// RVA: 0x76E5064
	public object set_allowActivationOnMobileDevice(object value) { }

	// RVA: 0x76E506C
	public object get_forceModuleActive() { }

	// RVA: 0x76E5074
	public object set_forceModuleActive(object value) { }

	// RVA: 0x76E507C
	public object get_inputActionsPerSecond() { }

	// RVA: 0x76E5084
	public object set_inputActionsPerSecond(object value) { }

	// RVA: 0x76E508C
	public object get_repeatDelay() { }

	// RVA: 0x76E5094
	public object set_repeatDelay(object value) { }

	// RVA: 0x76E509C
	public object get_horizontalAxis() { }

	// RVA: 0x76E50A4
	public object set_horizontalAxis(object value) { }

	// RVA: 0x76E50AC
	public object get_verticalAxis() { }

	// RVA: 0x76E50B4
	public object set_verticalAxis(object value) { }

	// RVA: 0x76E50BC
	public object get_submitButton() { }

	// RVA: 0x76E50C4
	public object set_submitButton(object value) { }

	// RVA: 0x76E50CC
	public object get_cancelButton() { }

	// RVA: 0x76E50D4
	public object set_cancelButton(object value) { }

	// RVA: 0x76E50DC
	private object ShouldIgnoreEventsOnNoFocus() { }

	// RVA: 0x76E50E4
	public override object UpdateModule() { }

	// RVA: 0x76E5228
	private object ReleaseMouse(object pointerEvent, object currentOverGo) { }

	// RVA: 0x76E56EC
	public override object ShouldActivateModule() { }

	// RVA: 0x76E5A3C
	public override object ActivateModule() { }

	// RVA: 0x76E5C14
	public override object DeactivateModule() { }

	// RVA: 0x76E5C18
	public override object Process() { }

	// RVA: 0x76E5ECC
	private object ProcessTouchEvents() { }

	// RVA: 0x76E6784
	protected object ProcessTouchPress(object pointerEvent, object pressed, object released) { }

	// RVA: 0x76E6460
	protected object SendSubmitEventToSelectedObject() { }

	// RVA: 0x76E708C
	private object GetRawMoveVector() { }

	// RVA: 0x76E6144
	protected object SendMoveEventToSelectedObject() { }

	// RVA: 0x76E613C
	protected object ProcessMouseEvent() { }

	// RVA: 0x76E7610
	protected virtual object ForceAutoSelect() { }

	// RVA: 0x76E7260
	protected object ProcessMouseEvent(object id) { }

	// RVA: 0x76E5D08
	protected object SendUpdateEventToSelectedObject() { }

	// RVA: 0x76E7618
	protected object ProcessMousePress(object data) { }

	// RVA: 0x76E7AB0
	protected object GetCurrentFocusedGameObject() { }

}

// Namespace: UnityEngine.EventSystems
public class TouchInputModule
{

	// Fields
	private object m_LastMousePosition; // 0x60
	private object m_MousePosition; // 0x68
	private object m_InputPointerEvent; // 0x70
	private object m_ForceModuleActive; // 0x78

	// Properties
	public object allowActivationOnStandalone { get; set; }
	public object forceModuleActive { get; set; }

	// Methods

	// RVA: 0x76E7AB8
	protected object .ctor() { }

	// RVA: 0x76E7ABC
	public object get_allowActivationOnStandalone() { }

	// RVA: 0x76E7AC4
	public object set_allowActivationOnStandalone(object value) { }

	// RVA: 0x76E7ACC
	public object get_forceModuleActive() { }

	// RVA: 0x76E7AD4
	public object set_forceModuleActive(object value) { }

	// RVA: 0x76E7ADC
	public override object UpdateModule() { }

	// RVA: 0x76E7CB0
	public override object IsModuleSupported() { }

	// RVA: 0x76E7D20
	public override object ShouldActivateModule() { }

	// RVA: 0x76E7E90
	private object UseFakeInput() { }

	// RVA: 0x76E7EF0
	public override object Process() { }

	// RVA: 0x76E7F68
	private object FakeTouches() { }

	// RVA: 0x76E8138
	private object ProcessTouchEvents() { }

	// RVA: 0x76E835C
	protected object ProcessTouchPress(object pointerEvent, object pressed, object released) { }

	// RVA: 0x76E8C7C
	public override object DeactivateModule() { }

	// RVA: 0x76E8C80
	public override object ToString() { }

}

// Namespace: UnityEngine.EventSystems
public enum MoveDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Up;
	public const object Right;
	public const object Down;
	public const object None;
}

// Namespace: UnityEngine.EventSystems
public static class RaycasterManager
{

	// Fields
	private static readonly object s_Raycasters; // 0x0

	// Methods

	// RVA: 0x76E8FB8
	internal static object AddRaycaster(object baseRaycaster) { }

	// RVA: 0x76E9168
	public static object GetRaycasters() { }

	// RVA: 0x76E91E4
	internal static object RemoveRaycasters(object baseRaycaster) { }

	// RVA: 0x76E92F0
	private static object .cctor() { }

}

// Namespace: UnityEngine.EventSystems
public abstract class BaseRaycaster
{

	// Fields
	private object m_RootRaycaster; // 0x18

	// Properties
	public abstract object eventCamera { get; }
	public virtual object priority { get; }
	public virtual object sortOrderPriority { get; }
	public virtual object renderOrderPriority { get; }
	public object rootRaycaster { get; }

	// Methods

	// RVA: -1
	public abstract object Raycast(object eventData, object resultAppendList) { }

	// RVA: -1
	public abstract object get_eventCamera() { }

	// RVA: 0x76E9380
	public virtual object get_priority() { }

	// RVA: 0x76E9388
	public virtual object get_sortOrderPriority() { }

	// RVA: 0x76E9390
	public virtual object get_renderOrderPriority() { }

	// RVA: 0x76DCD38
	public object get_rootRaycaster() { }

	// RVA: 0x76E9398
	public override object ToString() { }

	// RVA: 0x76E95F4
	protected override object OnEnable() { }

	// RVA: 0x76E9674
	protected override object OnDisable() { }

	// RVA: 0x76E96F4
	protected override object OnCanvasHierarchyChanged() { }

	// RVA: 0x76E9700
	protected override object OnTransformParentChanged() { }

	// RVA: 0x76DA948
	protected object .ctor() { }

}

// Namespace: UnityEngine.EventSystems
public class Physics2DRaycaster
{

	// Fields
	private object m_Hits; // 0x40

	// Methods

	// RVA: 0x76E970C
	protected object .ctor() { }

	// RVA: 0x76E9774
	public override object Raycast(object eventData, object resultAppendList) { }

}

// Namespace: 
private class RaycastHitComparer
{

	// Fields
	public static object instance; // 0x0

	// Methods

	// RVA: 0x76EACF4
	public object Compare(object x, object y) { }

	// RVA: 0x76EAD40
	public object .ctor() { }

	// RVA: 0x76EAD48
	private static object .cctor() { }

}

// Namespace: UnityEngine.EventSystems
public class PhysicsRaycaster
{

	// Fields
	protected const object kNoEventMaskSet;
	protected object m_EventCamera; // 0x20
	protected object m_EventMask; // 0x28
	protected object m_MaxRayIntersections; // 0x2C
	protected object m_LastMaxRayIntersections; // 0x30
	private object m_Hits; // 0x38

	// Properties
	public override object eventCamera { get; }
	public virtual object depth { get; }
	public object finalEventMask { get; }
	public object eventMask { get; set; }
	public object maxRayIntersections { get; set; }

	// Methods

	// RVA: 0x76E9740
	protected object .ctor() { }

	// RVA: 0x76EA51C
	public override object get_eventCamera() { }

	// RVA: 0x76EA640
	public virtual object get_depth() { }

	// RVA: 0x76EA410
	public object get_finalEventMask() { }

	// RVA: 0x76EA750
	public object get_eventMask() { }

	// RVA: 0x76EA758
	public object set_eventMask(object value) { }

	// RVA: 0x76EA760
	public object get_maxRayIntersections() { }

	// RVA: 0x76EA768
	public object set_maxRayIntersections(object value) { }

	// RVA: 0x76EA044
	protected object ComputeRayAndDistance(object eventData, object ray, object eventDisplayIndex, object distanceToClipPlane) { }

	// RVA: 0x76EA770
	public override object Raycast(object eventData, object resultAppendList) { }

}

// Namespace: UnityEngine.EventSystems
public struct RaycastResult
{

	// Fields
	private object m_GameObject; // 0xFFFFFFFFFFFFFFF8
	public object module; // 0x0
	public object distance; // 0x8
	public object index; // 0xC
	public object depth; // 0x10
	public object sortingGroupID; // 0x14
	public object sortingGroupOrder; // 0x18
	public object sortingLayer; // 0x1C
	public object sortingOrder; // 0x20
	public object worldPosition; // 0x24
	public object worldNormal; // 0x30
	public object screenPosition; // 0x3C
	public object displayIndex; // 0x44

	// Properties
	public object gameObject { get; set; }
	public object isValid { get; }

	// Methods

	// RVA: 0x76EADE4
	public object get_gameObject() { }

	// RVA: 0x76EADF4
	public object set_gameObject(object value) { }

	// RVA: 0x76EAE04
	public object get_isValid() { }

	// RVA: 0x76EAF94
	public object Clear() { }

	// RVA: 0x76DBB64
	public override object ToString() { }

}

// Namespace: UnityEngine.EventSystems
public abstract class UIBehaviour
{

	// Methods

	// RVA: 0x76EB054
	protected virtual object Awake() { }

	// RVA: 0x76D72EC
	protected virtual object OnEnable() { }

	// RVA: 0x76DDC6C
	protected virtual object Start() { }

	// RVA: 0x76D72F4
	protected virtual object OnDisable() { }

	// RVA: 0x76EB058
	protected virtual object OnDestroy() { }

	// RVA: 0x76EB05C
	public virtual object IsActive() { }

	// RVA: 0x76EB064
	protected virtual object OnRectTransformDimensionsChange() { }

	// RVA: 0x76EB068
	protected virtual object OnBeforeTransformParentChanged() { }

	// RVA: 0x76E9708
	protected virtual object OnTransformParentChanged() { }

	// RVA: 0x76EB06C
	protected virtual object OnDidApplyAnimationProperties() { }

	// RVA: 0x76EB070
	protected virtual object OnCanvasGroupChanged() { }

	// RVA: 0x76E96FC
	protected virtual object OnCanvasHierarchyChanged() { }

	// RVA: 0x76EB074
	public object IsDestroyed() { }

	// RVA: 0x76D9C38
	protected object .ctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=12
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=5527
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=6181
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 1C3635C112D556F4C11A4FE6BDE6ED3F126C4B2B546811BDB64DE7BDED3A05CB; // 0x0
	internal static readonly object 3A7FF8A09651DF5CF9F4400AF40A227B86419E57F904AEA8411CE3F1E03BE9D0; // 0xC
	internal static readonly object 7C777EEED2359F9E03B1E9BA3FE7218E75A8BA42A33894ABBE8BB2022DDED720; // 0x1831
}

