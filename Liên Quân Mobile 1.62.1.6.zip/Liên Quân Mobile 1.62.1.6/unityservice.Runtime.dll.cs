// Namespace: 
internal class <Module>
{
}

// Namespace: 
protected internal struct Entry
{

	// Fields
	public object hashCode; // 0x0
	public object next; // 0x0
	public object key; // 0x0
	public object value; // 0x0
}

// Namespace: UnityService.Collections
public abstract class AbstractBaseTinyDictionary<T0, T1>
{

	// Fields
	protected internal object Buckets; // 0x0
	protected internal object Entries_Backends; // 0x0
	protected internal object count; // 0x0
	protected internal object freeList; // 0x0
	protected internal object freeCount; // 0x0
	protected internal object comparer; // 0x0

	// Properties
	public object Count { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	protected object Initialize(object capacity) { }

	// RVA: -1
	protected object Resize() { }

	// RVA: -1
	protected object Resize(object newSize, object forceNewHashCodes) { }

	// RVA: -1
	protected object FindEntry(object key) { }

	// RVA: -1
	protected object Insert(object key, object value, object add) { }

	// RVA: -1
	protected object RemoveKey(object key) { }

}

// Namespace: UnityService.Collections
public abstract class AbstractBaseTinyList<T0>
{

	// Fields
	protected internal object Item_Backends; // 0x0
	protected object Size; // 0x0
	protected static readonly object EmptyArray; // 0x0

	// Properties
	public object Count { get; }
	public object Capacity { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Capacity() { }

	// RVA: -1
	public object set_Capacity(object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	protected object EnsureCapacity(object min) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	public object RemoveRange(object index, object count) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityService.Collections
internal static class HashHelpers
{

	// Fields
	public static readonly object primes; // 0x0

	// Methods

	// RVA: 0x76FAE24
	public static object IsPrime(object candidate) { }

	// RVA: 0x76FAEE8
	public static object GetPrime(object min) { }

	// RVA: 0x76FB11C
	public static object ExpandPrime(object oldSize) { }

	// RVA: 0x76FB1B4
	private static object .cctor() { }

}

// Namespace: UnityService.Collections
public class TinyDictionary<T0, T1>
{

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object Remove(object key) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object dictionary; // 0x0
	private object index; // 0x0
	private object current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary) { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Reset() { }

}

// Namespace: UnityService.Collections
public class MicroDictionary<T0, T1>
{

	// Methods

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityService.Collections
public class TinyList<T0>
{

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object AddRange(object from) { }

	// RVA: -1
	public object Insert(object index, object item) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object InternalList; // 0x0
	private object Index; // 0x0
	private object CurrentElement; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object list) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: UnityService.Collections
public class MicroList<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityService.Collections
public class TinyObjectKeyDictionary<T0, T1>
{

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object dictionary; // 0x0
	private object index; // 0x0
	private object current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary) { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Reset() { }

}

// Namespace: UnityService.Collections
public class MicroObjectKeyDictionary<T0, T1>
{

	// Methods

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityService.Collections
public class TinyObjectKeyValueDictionary<T0, T1>
{

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object dictionary; // 0x0
	private object index; // 0x0
	private object current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary) { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Reset() { }

}

// Namespace: UnityService.Collections
public class MicroObjectKeyValueDictionary<T0, T1>
{

	// Methods

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityService.Collections
public class TinyValueDictionary<T0, T1>
{

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object dictionary; // 0x0
	private object index; // 0x0
	private object current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary) { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object Reset() { }

}

// Namespace: UnityService.Collections
public class MicroValueDictionary<T0, T1>
{

	// Methods

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityService.Collections
public class TinyValueList<T0>
{

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Insert(object index, object item) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object InternalList; // 0x0
	private object Index; // 0x0
	private object CurrentElement; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object list) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: UnityService.Collections
public class MicroValueList<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyListOperationExtensions
{

	// Methods

	// RVA: -1
	public static object AddRange(object list, object values) { }

	// RVA: -1
	public static object Remove(object list, object value) { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyListLinqExtensions
{

	// Methods

	// RVA: -1
	public static object ToArray(object list) { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyListSearchingExtensions
{

	// Methods

	// RVA: -1
	public static object IndexOf(object list, object item) { }

	// RVA: -1
	public static object Contains(object list, object item) { }

}

// Namespace: 
public sealed class Comparison
{

	// Methods

	// RVA: 0x76FB914
	public object .ctor(object object, object method) { }

	// RVA: 0x76FBA20
	public virtual object Invoke(object x, object y) { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyListSortingExtensions
{

	// Methods

	// RVA: 0x76FB24C
	public static object InsertionSort(object array, object index, object count, object comparer) { }

	// RVA: 0x76FB478
	public static object InsertionSort(object array, object index, object count, object comparer) { }

	// RVA: -1
	public static object Sort(object list) { }

	// RVA: -1
	public static object Sort(object list, object index, object count, object comparer) { }

	// RVA: -1
	public static object Sort(object list, object comparison) { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyValueListOperationExtensions
{

	// Methods

	// RVA: -1
	public static object AddRange(object list, object values) { }

	// RVA: -1
	public static object AddRange(object list, object values) { }

	// RVA: -1
	public static object Remove(object list, object value) { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyValueListLinqExtensions
{

	// Methods

	// RVA: -1
	public static object ToArray(object list) { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyValueListSearchingExtensions
{

	// Methods

	// RVA: -1
	public static object Contains(object list, object item) { }

	// RVA: -1
	public static object IndexOf(object list, object item) { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyValueListSortingExtensions
{

	// Methods

	// RVA: -1
	public static object InsertionSort(object array, object index, object count, object comparer) { }

	// RVA: -1
	public static object InsertionSort(object array, object index, object count, object comparer) { }

	// RVA: -1
	public static object Sort(object list) { }

	// RVA: -1
	public static object Sort(object list, object comparer) { }

	// RVA: -1
	public static object Sort(object list, object index, object count, object comparer) { }

	// RVA: -1
	public static object Sort(object list, object comparison) { }

}

// Namespace: UnityService.Collections.Extensions
public static class TinyValueListInternalExtensions
{

	// Methods

	// RVA: -1
	public static object GetInternalArray(object list) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=288
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 74BCD6ED20AF2231F2BB1CDE814C5F4FF48E54BAC46029EEF90DDF4A208E2B20; // 0x0
}

