// Namespace: 
internal class <Module>
{
}

// Namespace: System.Runtime.Serialization
public sealed class DataContractAttribute
{

	// Fields
	private object isReference; // 0x8

	// Properties
	public object IsReference { get; }

	// Methods

	// RVA: 0x6ED5F74
	public object get_IsReference() { }

}

// Namespace: System.Runtime.Serialization
public sealed class DataMemberAttribute
{

	// Fields
	private object name; // 0x8
	private object order; // 0x10
	private object isRequired; // 0x14
	private object emitDefaultValue; // 0x15

	// Properties
	public object Name { get; }
	public object Order { get; }
	public object IsRequired { get; }
	public object EmitDefaultValue { get; }

	// Methods

	// RVA: 0x6ED5F7C
	public object get_Name() { }

	// RVA: 0x6ED5F84
	public object get_Order() { }

	// RVA: 0x6ED5F8C
	public object get_IsRequired() { }

	// RVA: 0x6ED5F94
	public object get_EmitDefaultValue() { }

}

// Namespace: System.Runtime.Serialization
public sealed class EnumMemberAttribute
{

	// Fields
	private object value; // 0x8

	// Properties
	public object Value { get; }

	// Methods

	// RVA: 0x6ED5F9C
	public object get_Value() { }

}

// Namespace: System.Runtime.Serialization
public sealed class IgnoreDataMemberAttribute
{
}

