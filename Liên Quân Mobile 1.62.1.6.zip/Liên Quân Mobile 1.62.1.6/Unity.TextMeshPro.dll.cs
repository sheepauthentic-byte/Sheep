// Namespace: 
internal class <Module>
{
}

// Namespace: TMPro
public class FastAction
{

	// Fields
	private object delegates; // 0x8
	private object lookup; // 0x10

	// Methods

	// RVA: 0x728B628
	public object .ctor() { }

}

// Namespace: TMPro
public class FastAction<T0>
{

	// Fields
	private object delegates; // 0x0
	private object lookup; // 0x0

	// Methods

	// RVA: -1
	public object Add(object rhs) { }

	// RVA: -1
	public object Remove(object rhs) { }

	// RVA: -1
	public object Call(object a) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: TMPro
public class FastAction<T0, T1>
{

	// Fields
	private object delegates; // 0x0
	private object lookup; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: TMPro
public class FastAction<T0, T1, T2>
{

	// Fields
	private object delegates; // 0x0
	private object lookup; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: TMPro
public interface ITextPreprocessor
{

	// Methods

	// RVA: -1
	public abstract object PreprocessText(object text) { }

}

// Namespace: TMPro
public class MaterialReferenceManager
{

	// Fields
	private static object s_Instance; // 0x0
	private object m_FontMaterialReferenceLookup; // 0x8
	private object m_FontAssetReferenceLookup; // 0x10
	private object m_SpriteAssetReferenceLookup; // 0x18
	private object m_ColorGradientReferenceLookup; // 0x20

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: 0x728B6F0
	public static object get_instance() { }

	// RVA: 0x728B8D4
	public static object AddFontAsset(object fontAsset) { }

	// RVA: 0x728B964
	private object AddFontAssetInternal(object fontAsset) { }

	// RVA: 0x728BA64
	public static object AddSpriteAsset(object hashCode, object spriteAsset) { }

	// RVA: 0x728BAFC
	private object AddSpriteAssetInternal(object hashCode, object spriteAsset) { }

	// RVA: 0x728BC10
	public static object AddFontMaterial(object hashCode, object material) { }

	// RVA: 0x728BCD4
	private object AddFontMaterialInternal(object hashCode, object material) { }

	// RVA: 0x728BD48
	public static object AddColorGradientPreset(object hashCode, object spriteAsset) { }

	// RVA: 0x728BE54
	private object AddColorGradientPreset_Internal(object hashCode, object spriteAsset) { }

	// RVA: 0x728BF10
	public static object TryGetFontAsset(object hashCode, object fontAsset) { }

	// RVA: 0x728BFE4
	private object TryGetFontAssetInternal(object hashCode, object fontAsset) { }

	// RVA: 0x728C05C
	public static object TryGetSpriteAsset(object hashCode, object spriteAsset) { }

	// RVA: 0x728C130
	private object TryGetSpriteAssetInternal(object hashCode, object spriteAsset) { }

	// RVA: 0x728C1A8
	public static object TryGetColorGradientPreset(object hashCode, object gradientPreset) { }

	// RVA: 0x728C27C
	private object TryGetColorGradientPresetInternal(object hashCode, object gradientPreset) { }

	// RVA: 0x728C2F4
	public static object TryGetMaterial(object hashCode, object material) { }

	// RVA: 0x728C3C8
	private object TryGetMaterialInternal(object hashCode, object material) { }

	// RVA: 0x728B77C
	public object .ctor() { }

}

// Namespace: TMPro
public struct MaterialReference
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object fontAsset; // 0x0
	public object spriteAsset; // 0x8
	public object material; // 0x10
	public object isDefaultMaterial; // 0x18
	public object isFallbackMaterial; // 0x19
	public object fallbackMaterial; // 0x20
	public object padding; // 0x28
	public object referenceCount; // 0x2C

	// Methods

	// RVA: 0x728C47C
	public object .ctor(object index, object fontAsset, object spriteAsset, object material, object padding) { }

	// RVA: 0x728C5CC
	public static object AddMaterialReference(object material, object fontAsset, object materialReferences, object materialReferenceIndexLookup) { }

	// RVA: 0x728C7F8
	public static object AddMaterialReference(object material, object spriteAsset, object materialReferences, object materialReferenceIndexLookup) { }

}

// Namespace: TMPro
public enum TextContainerAnchors
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TopLeft;
	public const object Top;
	public const object TopRight;
	public const object Left;
	public const object Middle;
	public const object Right;
	public const object BottomLeft;
	public const object Bottom;
	public const object BottomRight;
	public const object Custom;
}

// Namespace: TMPro
public class TextContainer
{

	// Fields
	private object m_hasChanged; // 0x18
	private object m_pivot; // 0x1C
	private object m_anchorPosition; // 0x24
	private object m_rect; // 0x28
	private object m_isDefaultWidth; // 0x38
	private object m_isDefaultHeight; // 0x39
	private object m_isAutoFitting; // 0x3A
	private object m_corners; // 0x40
	private object m_worldCorners; // 0x48
	private object m_margins; // 0x50
	private object m_rectTransform; // 0x60
	private static object k_defaultSize; // 0x0
	private object m_textMeshPro; // 0x68

	// Properties
	public object hasChanged { get; set; }
	public object pivot { get; set; }
	public object anchorPosition { get; set; }
	public object rect { get; set; }
	public object size { get; set; }
	public object width { get; set; }
	public object height { get; set; }
	public object isDefaultWidth { get; }
	public object isDefaultHeight { get; }
	public object isAutoFitting { get; set; }
	public object corners { get; }
	public object worldCorners { get; }
	public object margins { get; set; }
	public object rectTransform { get; }
	public object textMeshPro { get; }

	// Methods

	// RVA: 0x728C9B4
	public object get_hasChanged() { }

	// RVA: 0x728C9BC
	public object set_hasChanged(object value) { }

	// RVA: 0x728C9C4
	public object get_pivot() { }

	// RVA: 0x728C9CC
	public object set_pivot(object value) { }

	// RVA: 0x728CF28
	public object get_anchorPosition() { }

	// RVA: 0x728CF30
	public object set_anchorPosition(object value) { }

	// RVA: 0x728D074
	public object get_rect() { }

	// RVA: 0x728D080
	public object set_rect(object value) { }

	// RVA: 0x728D0C4
	public object get_size() { }

	// RVA: 0x728D0CC
	public object set_size(object value) { }

	// RVA: 0x728D118
	public object get_width() { }

	// RVA: 0x728D120
	public object set_width(object value) { }

	// RVA: 0x728D134
	public object get_height() { }

	// RVA: 0x728D13C
	public object set_height(object value) { }

	// RVA: 0x728D150
	public object get_isDefaultWidth() { }

	// RVA: 0x728D158
	public object get_isDefaultHeight() { }

	// RVA: 0x728D160
	public object get_isAutoFitting() { }

	// RVA: 0x728D168
	public object set_isAutoFitting(object value) { }

	// RVA: 0x728D170
	public object get_corners() { }

	// RVA: 0x728D178
	public object get_worldCorners() { }

	// RVA: 0x728D180
	public object get_margins() { }

	// RVA: 0x728D18C
	public object set_margins(object value) { }

	// RVA: 0x728D1EC
	public object get_rectTransform() { }

	// RVA: 0x728D2BC
	public object get_textMeshPro() { }

	// RVA: 0x728D38C
	protected override object Awake() { }

	// RVA: 0x728D474
	protected override object OnEnable() { }

	// RVA: 0x728D478
	protected override object OnDisable() { }

	// RVA: 0x728CCA0
	private object OnContainerChanged() { }

	// RVA: 0x728D5DC
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x728D110
	private object SetRect(object size) { }

	// RVA: 0x728D47C
	private object UpdateCorners() { }

	// RVA: 0x728CFE4
	private object GetPivot(object anchor) { }

	// RVA: 0x728CB84
	private object GetAnchorPosition(object pivot) { }

	// RVA: 0x728D9BC
	public object .ctor() { }

	// RVA: 0x728DA38
	private static object .cctor() { }

}

// Namespace: TMPro
public class TextMeshPro
{

	// Fields
	internal object _SortingLayer; // 0x6C0
	internal object _SortingLayerID; // 0x6C4
	internal object _SortingOrder; // 0x6C8
	private object OnPreRenderText; // 0x6D0
	private object m_currentAutoSizeMode; // 0x6D8
	private object m_hasFontAssetChanged; // 0x6D9
	private object m_previousLossyScaleY; // 0x6DC
	private object m_fontColorPreviews; // 0x6E0
	private object m_BL; // 0x6F0
	private object m_TL; // 0x6F4
	private object m_TR; // 0x6F8
	private object m_BR; // 0x6FC
	private object m_renderer; // 0x700
	private object m_meshFilter; // 0x708
	private object m_CanvasRenderer; // 0x710
	private object m_isFirstAllocation; // 0x718
	private object m_max_characters; // 0x71C
	private object m_max_numberOfLines; // 0x720
	private object m_subTextObjects; // 0x728
	private object m_maskType; // 0x730
	private object m_EnvMapMatrix; // 0x734
	private object m_RectTransformCorners; // 0x778
	private object m_isRegisteredForEvents; // 0x780
	private static object k_GenerateTextMarker; // 0x0
	private static object k_SetArraySizesMarker; // 0x8
	private static object k_GenerateTextPhaseIMarker; // 0x10
	private static object k_ParseMarkupTextMarker; // 0x18
	private static object k_CharacterLookupMarker; // 0x20
	private static object k_HandleGPOSFeaturesMarker; // 0x28
	private static object k_CalculateVerticesPositionMarker; // 0x30
	private static object k_ComputeTextMetricsMarker; // 0x38
	private static object k_HandleVisibleCharacterMarker; // 0x40
	private static object k_HandleWhiteSpacesMarker; // 0x48
	private static object k_HandleHorizontalLineBreakingMarker; // 0x50
	private static object k_HandleVerticalLineBreakingMarker; // 0x58
	private static object k_SaveGlyphVertexDataMarker; // 0x60
	private static object k_ComputeCharacterAdvanceMarker; // 0x68
	private static object k_HandleCarriageReturnMarker; // 0x70
	private static object k_HandleLineTerminationMarker; // 0x78
	private static object k_SavePageInfoMarker; // 0x80
	private static object k_SaveProcessingStatesMarker; // 0x88
	private static object k_GenerateTextPhaseIIMarker; // 0x90
	private static object k_GenerateTextPhaseIIIMarker; // 0x98

	// Properties
	public object sortingLayerID { get; set; }
	public object sortingOrder { get; set; }
	public override object autoSizeTextContainer { get; set; }
	public object textContainer { get; }
	public object transform { get; }
	public object renderer { get; }
	public override object mesh { get; }
	public object meshFilter { get; }
	public object maskType { get; set; }

	// Methods

	// RVA: 0x728DA8C
	public object get_sortingLayerID() { }

	// RVA: 0x728DCC8
	public object set_sortingLayerID(object value) { }

	// RVA: 0x728DFAC
	public object get_sortingOrder() { }

	// RVA: 0x728E118
	public object set_sortingOrder(object value) { }

	// RVA: 0x728E3FC
	public override object get_autoSizeTextContainer() { }

	// RVA: 0x728E404
	public override object set_autoSizeTextContainer(object value) { }

	// RVA: 0x728E4B8
	public object get_textContainer() { }

	// RVA: 0x728E4C0
	public object get_transform() { }

	// RVA: 0x728DBF8
	public object get_renderer() { }

	// RVA: 0x728E590
	public override object get_mesh() { }

	// RVA: 0x728E68C
	public object get_meshFilter() { }

	// RVA: 0x728E7F8
	public object get_maskType() { }

	// RVA: 0x728E800
	public object set_maskType(object value) { }

	// RVA: 0x728E9F4
	public object SetMask(object type, object maskCoords) { }

	// RVA: 0x728EB88
	public object SetMask(object type, object maskCoords, object softnessX, object softnessY) { }

	// RVA: 0x728ED24
	public override object SetVerticesDirty() { }

	// RVA: 0x728EE34
	public override object SetLayoutDirty() { }

	// RVA: 0x728EF60
	public override object SetMaterialDirty() { }

	// RVA: 0x728EFA4
	public override object SetAllDirty() { }

	// RVA: 0x728F034
	public override object Rebuild(object update) { }

	// RVA: 0x728F554
	protected override object UpdateMaterial() { }

	// RVA: 0x728F7BC
	public override object UpdateMeshPadding() { }

	// RVA: 0x728F8E4
	public override object ForceMeshUpdate(object ignoreActiveState, object forceTextReparsing) { }

	// RVA: 0x728F8F4
	public override object GetTextInfo(object text) { }

	// RVA: 0x728F9AC
	public override object ClearMesh(object updateMesh) { }

	// RVA: 0x728FAE4
	public override object add_OnPreRenderText(object value) { }

	// RVA: 0x728FB98
	public override object remove_OnPreRenderText(object value) { }

	// RVA: 0x728FC4C
	public override object UpdateGeometry(object mesh, object index) { }

	// RVA: 0x728FC70
	public override object UpdateVertexData(object flags) { }

	// RVA: 0x728FFB4
	public override object UpdateVertexData() { }

	// RVA: 0x72902E0
	public object UpdateFontAsset() { }

	// RVA: 0x7290324
	public object CalculateLayoutInputHorizontal() { }

	// RVA: 0x7290328
	public object CalculateLayoutInputVertical() { }

	// RVA: 0x729032C
	protected override object Awake() { }

	// RVA: 0x7290804
	protected override object OnEnable() { }

	// RVA: 0x7290960
	protected override object OnDisable() { }

	// RVA: 0x7290A30
	protected override object OnDestroy() { }

	// RVA: 0x7290B40
	protected override object LoadFontAsset() { }

	// RVA: 0x7291348
	private object UpdateEnvMapMatrix() { }

	// RVA: 0x728E808
	private object SetMask(object maskType) { }

	// RVA: 0x728EAC0
	private object SetMaskCoordinates(object coords) { }

	// RVA: 0x728EBF4
	private object SetMaskCoordinates(object coords, object softX, object softY) { }

	// RVA: 0x7291608
	private object EnableMasking() { }

	// RVA: 0x7291858
	private object DisableMasking() { }

	// RVA: 0x72917BC
	private object UpdateMask() { }

	// RVA: 0x7291AEC
	protected override object GetMaterial(object mat) { }

	// RVA: 0x7291CA0
	protected override object GetMaterials(object mats) { }

	// RVA: 0x7291E8C
	protected override object SetSharedMaterial(object mat) { }

	// RVA: 0x7291EFC
	protected override object GetSharedMaterials() { }

	// RVA: 0x72920D0
	protected override object SetSharedMaterials(object materials) { }

	// RVA: 0x7292548
	protected override object SetOutlineThickness(object thickness) { }

	// RVA: 0x72926DC
	protected override object SetFaceColor(object color) { }

	// RVA: 0x729284C
	protected override object SetOutlineColor(object color) { }

	// RVA: 0x7291A08
	private object CreateMaterialInstance() { }

	// RVA: 0x72929BC
	protected override object SetShaderDepth() { }

	// RVA: 0x7292B2C
	protected override object SetCulling() { }

	// RVA: 0x7292EE4
	private object SetPerspectiveCorrection() { }

	// RVA: 0x7292F94
	internal override object SetArraySizes(object unicodeChars) { }

	// RVA: 0x72950F8
	public override object ComputeMarginSize() { }

	// RVA: 0x7295240
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x729529C
	protected override object OnTransformParentChanged() { }

	// RVA: 0x7295310
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x7295524
	internal override object InternalUpdate() { }

	// RVA: 0x7295A44
	private object GenerateFastColor() { }

	// RVA: 0x728F174
	private object OnPreRenderObject() { }

	// RVA: 0x727ADD8
	protected virtual object GenerateTextMesh() { }

	// RVA: 0x7296650
	protected override object GetTextContainerLocalCorners() { }

	// RVA: 0x7296720
	private object SetMeshFilters(object state) { }

	// RVA: 0x7296AE0
	protected override object SetActiveSubMeshes(object state) { }

	// RVA: 0x72964D0
	protected object SetActiveSubTextObjectRenderers(object state) { }

	// RVA: 0x7296C34
	protected override object DestroySubMeshObjects() { }

	// RVA: 0x728DE48
	internal object UpdateSubMeshSortingLayerID(object id) { }

	// RVA: 0x728E298
	internal object UpdateSubMeshSortingOrder(object order) { }

	// RVA: 0x7296D40
	protected override object GetCompoundBounds() { }

	// RVA: 0x729568C
	private object UpdateSDFScale(object scaleDelta) { }

	// RVA: 0x7296F08
	public object .ctor() { }

	// RVA: 0x7297054
	private static object .cctor() { }

}

// Namespace: 
private struct RichTextFlagInfo
{

	// Fields
	public object prefix; // 0xFFFFFFFFFFFFFFF8
	public object flagName; // 0x0
}

// Namespace: 
private class ARTP
{

	// Fields
	private object o; // 0x8
	private static object s_arContentBuilder; // 0x0
	private static object s_arLineBuilder; // 0x8
	private static object remainFlags; // 0x10

	// Methods

	// RVA: 0x72A0AE8
	public object .ctor(object o) { }

	// RVA: 0x72A0B14
	public object PreprocessText(object text) { }

	// RVA: 0x72A0C84
	private static object RevertRtlBackAlgorithm_ForTMPRtl(object aovFixedStr) { }

	// RVA: 0x72A1918
	public static object Reverse(object sb) { }

	// RVA: 0x72A19D8
	private static object .cctor() { }

}

// Namespace: 
private sealed class <DelayedGraphicRebuild>d__18
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x72A1B80
	public object .ctor(object <>1__state) { }

	// RVA: 0x72A1BAC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x72A1BB0
	private object MoveNext() { }

	// RVA: 0x72A1C8C
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x72A1C94
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x72A1CD4
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <DelayedMaterialRebuild>d__19
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x72A1CDC
	public object .ctor(object <>1__state) { }

	// RVA: 0x72A1D08
	private object System.IDisposable.Dispose() { }

	// RVA: 0x72A1D0C
	private object MoveNext() { }

	// RVA: 0x72A1DF0
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x72A1DF8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x72A1E38
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: TMPro
public class TextMeshProUGUI
{

	// Fields
	private object m_isRebuildingLayout; // 0x6C0
	private object m_DelayedGraphicRebuild; // 0x6C8
	private object m_DelayedMaterialRebuild; // 0x6D0
	private object m_ClipRect; // 0x6D8
	private object m_ValidRect; // 0x6E8
	private object OnPreRenderText; // 0x6F0
	private object m_hasFontAssetChanged; // 0x6F8
	protected object m_subTextObjects; // 0x700
	private object m_previousLossyScaleY; // 0x708
	private object m_RectTransformCorners; // 0x710
	private object m_canvasRenderer; // 0x718
	private object m_canvas; // 0x720
	private object m_CanvasScaleFactor; // 0x728
	private object m_isFirstAllocation; // 0x72C
	private object m_max_characters; // 0x730
	private object m_baseMaterial; // 0x738
	private object m_isScrollRegionSet; // 0x740
	private object m_maskOffset; // 0x744
	private object m_EnvMapMatrix; // 0x754
	private object m_isRegisteredForEvents; // 0x794
	private static object k_GenerateTextMarker; // 0x0
	private static object k_SetArraySizesMarker; // 0x8
	private static object k_GenerateTextPhaseIMarker; // 0x10
	private static object k_ParseMarkupTextMarker; // 0x18
	private static object k_CharacterLookupMarker; // 0x20
	private static object k_HandleGPOSFeaturesMarker; // 0x28
	private static object k_CalculateVerticesPositionMarker; // 0x30
	private static object k_ComputeTextMetricsMarker; // 0x38
	private static object k_HandleVisibleCharacterMarker; // 0x40
	private static object k_HandleWhiteSpacesMarker; // 0x48
	private static object k_HandleHorizontalLineBreakingMarker; // 0x50
	private static object k_HandleVerticalLineBreakingMarker; // 0x58
	private static object k_SaveGlyphVertexDataMarker; // 0x60
	private static object k_ComputeCharacterAdvanceMarker; // 0x68
	private static object k_HandleCarriageReturnMarker; // 0x70
	private static object k_HandleLineTerminationMarker; // 0x78
	private static object k_SavePageInfoMarker; // 0x80
	private static object k_SaveProcessingStatesMarker; // 0x88
	private static object k_GenerateTextPhaseIIMarker; // 0x90
	private static object k_GenerateTextPhaseIIIMarker; // 0x98
	public static object IsLanguageAR; // 0xA0

	// Properties
	public override object materialForRendering { get; }
	public override object autoSizeTextContainer { get; set; }
	public override object mesh { get; }
	public object canvasRenderer { get; }
	public object maskOffset { get; set; }

	// Methods

	// RVA: 0x7297514
	public override object get_materialForRendering() { }

	// RVA: 0x7297580
	public override object get_autoSizeTextContainer() { }

	// RVA: 0x7297588
	public override object set_autoSizeTextContainer(object value) { }

	// RVA: 0x729763C
	public override object get_mesh() { }

	// RVA: 0x7297644
	public object get_canvasRenderer() { }

	// RVA: 0x7297714
	public object CalculateLayoutInputHorizontal() { }

	// RVA: 0x7297718
	public object CalculateLayoutInputVertical() { }

	// RVA: 0x729771C
	public override object SetVerticesDirty() { }

	// RVA: 0x7297858
	public override object SetLayoutDirty() { }

	// RVA: 0x72979B4
	public override object SetMaterialDirty() { }

	// RVA: 0x7297AF8
	public override object SetAllDirty() { }

	// RVA: 0x7297B88
	private object DelayedGraphicRebuild() { }

	// RVA: 0x7297C04
	private object DelayedMaterialRebuild() { }

	// RVA: 0x7297C80
	public override object Rebuild(object update) { }

	// RVA: 0x7298110
	private object UpdateSubObjectPivot() { }

	// RVA: 0x7298218
	public override object GetModifiedMaterial(object baseMaterial) { }

	// RVA: 0x729833C
	protected override object UpdateMaterial() { }

	// RVA: 0x7298534
	public object get_maskOffset() { }

	// RVA: 0x7298548
	public object set_maskOffset(object value) { }

	// RVA: 0x7298974
	public override object RecalculateClipping() { }

	// RVA: 0x729897C
	public override object Cull(object clipRect, object validRect) { }

	// RVA: 0x7298C70
	internal override object UpdateCulling() { }

	// RVA: 0x7298F08
	public override object UpdateMeshPadding() { }

	// RVA: 0x7299030
	protected override object InternalCrossFadeColor(object targetColor, object duration, object ignoreTimeScale, object useAlpha) { }

	// RVA: 0x7299140
	protected override object InternalCrossFadeAlpha(object alpha, object duration, object ignoreTimeScale) { }

	// RVA: 0x7299220
	public override object ForceMeshUpdate(object ignoreActiveState, object forceTextReparsing) { }

	// RVA: 0x72992F4
	public override object GetTextInfo(object text) { }

	// RVA: 0x7299448
	public override object ClearMesh() { }

	// RVA: 0x7299584
	public override object add_OnPreRenderText(object value) { }

	// RVA: 0x7299638
	public override object remove_OnPreRenderText(object value) { }

	// RVA: 0x72996EC
	public override object UpdateGeometry(object mesh, object index) { }

	// RVA: 0x72997A8
	public override object UpdateVertexData(object flags) { }

	// RVA: 0x7299B48
	public override object UpdateVertexData() { }

	// RVA: 0x7299EEC
	public object UpdateFontAsset() { }

	// RVA: 0x7299F30
	protected override object Awake() { }

	// RVA: 0x729A438
	protected override object OnEnable() { }

	// RVA: 0x729A7A8
	protected override object OnDisable() { }

	// RVA: 0x729A9C0
	protected override object OnDestroy() { }

	// RVA: 0x729AB94
	protected override object LoadFontAsset() { }

	// RVA: 0x729A60C
	private object GetCanvas() { }

	// RVA: 0x729B28C
	private object UpdateEnvMapMatrix() { }

	// RVA: 0x729B54C
	private object EnableMasking() { }

	// RVA: 0x729B758
	private object DisableMasking() { }

	// RVA: 0x7298580
	private object UpdateMask() { }

	// RVA: 0x729B75C
	protected override object GetMaterial(object mat) { }

	// RVA: 0x729B960
	protected override object GetMaterials(object mats) { }

	// RVA: 0x729BB6C
	protected override object SetSharedMaterial(object mat) { }

	// RVA: 0x729BBDC
	protected override object GetSharedMaterials() { }

	// RVA: 0x729BDB0
	protected override object SetSharedMaterials(object materials) { }

	// RVA: 0x729C2D8
	protected override object SetOutlineThickness(object thickness) { }

	// RVA: 0x729C564
	protected override object SetFaceColor(object color) { }

	// RVA: 0x729C6F0
	protected override object SetOutlineColor(object color) { }

	// RVA: 0x729C87C
	protected override object SetShaderDepth() { }

	// RVA: 0x729CA34
	protected override object SetCulling() { }

	// RVA: 0x729CE74
	private object SetPerspectiveCorrection() { }

	// RVA: 0x729CF24
	private object SetMeshArrays(object size) { }

	// RVA: 0x729D014
	internal override object SetArraySizes(object unicodeChars) { }

	// RVA: 0x729F3D4
	public override object ComputeMarginSize() { }

	// RVA: 0x729F51C
	protected override object OnDidApplyAnimationProperties() { }

	// RVA: 0x729F58C
	protected override object OnCanvasHierarchyChanged() { }

	// RVA: 0x729F6E8
	protected override object OnTransformParentChanged() { }

	// RVA: 0x729F74C
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x729FA0C
	internal override object InternalUpdate() { }

	// RVA: 0x7297DC0
	private object OnPreRenderCanvas() { }

	// RVA: 0x7283158
	protected virtual object GenerateTextMesh() { }

	// RVA: 0x729FDF8
	protected override object GetTextContainerLocalCorners() { }

	// RVA: 0x729FEC8
	protected override object SetActiveSubMeshes(object state) { }

	// RVA: 0x72A001C
	protected override object DestroySubMeshObjects() { }

	// RVA: 0x72A0128
	protected override object GetCompoundBounds() { }

	// RVA: 0x72A02F0
	internal override object GetCanvasSpaceClippingRect() { }

	// RVA: 0x729FAD0
	private object UpdateSDFScale(object scaleDelta) { }

	// RVA: 0x72A0564
	public object .ctor() { }

	// RVA: 0x72A0628
	private static object .cctor() { }

}

// Namespace: TMPro
public static class TMPro_EventManager
{

	// Fields
	public static readonly object COMPUTE_DT_EVENT; // 0x0
	public static readonly object MATERIAL_PROPERTY_EVENT; // 0x8
	public static readonly object FONT_PROPERTY_EVENT; // 0x10
	public static readonly object SPRITE_ASSET_PROPERTY_EVENT; // 0x18
	public static readonly object TEXTMESHPRO_PROPERTY_EVENT; // 0x20
	public static readonly object DRAG_AND_DROP_MATERIAL_EVENT; // 0x28
	public static readonly object TEXT_STYLE_PROPERTY_EVENT; // 0x30
	public static readonly object COLOR_GRADIENT_PROPERTY_EVENT; // 0x38
	public static readonly object TMP_SETTINGS_PROPERTY_EVENT; // 0x40
	public static readonly object RESOURCE_LOAD_EVENT; // 0x48
	public static readonly object TEXTMESHPRO_UGUI_PROPERTY_EVENT; // 0x50
	public static readonly object TEXT_CHANGED_EVENT; // 0x58

	// Methods

	// RVA: 0x72A1E40
	public static object ON_TEXT_CHANGED(object obj) { }

	// RVA: 0x72A1EEC
	private static object .cctor() { }

}

// Namespace: TMPro
public class Compute_DT_EventArgs
{
}

// Namespace: TMPro
public static class TMPro_ExtensionMethods
{

	// Methods

	// RVA: 0x72A21D0
	internal static object UintToString(object unicodes) { }

	// RVA: 0x72A22D8
	public static object Compare(object a, object b) { }

	// RVA: 0x72A22E8
	public static object Compare(object a, object b) { }

	// RVA: 0x72A230C
	public static object Multiply(object c1, object c2) { }

	// RVA: 0x72A23F0
	public static object MinAlpha(object c1, object c2) { }

}

// Namespace: TMPro
public static class TMP_Math
{

	// Fields
	public static object MAX_16BIT; // 0x0
	public static object MIN_16BIT; // 0x8

	// Methods

	// RVA: 0x72A23FC
	public static object Approximately(object a, object b) { }

	// RVA: 0x72A242C
	private static object .cctor() { }

}

// Namespace: TMPro
public enum TMP_VertexDataUpdateFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Vertices;
	public const object Uv0;
	public const object Uv2;
	public const object Uv4;
	public const object Colors32;
	public const object All;
}

// Namespace: TMPro
public struct VertexGradient
{

	// Fields
	public object topLeft; // 0xFFFFFFFFFFFFFFF8
	public object topRight; // 0x8
	public object bottomLeft; // 0x18
	public object bottomRight; // 0x28

	// Methods

	// RVA: 0x72A249C
	public object .ctor(object color) { }

	// RVA: 0x72A24E4
	public object .ctor(object color0, object color1, object color2, object color3) { }

}

// Namespace: TMPro
public struct TMP_PageInfo
{

	// Fields
	public object firstCharacterIndex; // 0xFFFFFFFFFFFFFFF8
	public object lastCharacterIndex; // 0xFFFFFFFFFFFFFFFC
	public object ascender; // 0x0
	public object baseLine; // 0x4
	public object descender; // 0x8
}

// Namespace: TMPro
public struct TMP_LinkInfo
{

	// Fields
	public object textComponent; // 0xFFFFFFFFFFFFFFF8
	public object hashCode; // 0x0
	public object linkIdFirstCharacterIndex; // 0x4
	public object linkIdLength; // 0x8
	public object linkTextfirstCharacterIndex; // 0xC
	public object linkTextLength; // 0x10
	internal object linkID; // 0x18

	// Methods

	// RVA: 0x72A255C
	internal object SetLinkID(object text, object startIndex, object length) { }

}

// Namespace: TMPro
public struct TMP_WordInfo
{

	// Fields
	public object textComponent; // 0xFFFFFFFFFFFFFFF8
	public object firstCharacterIndex; // 0x0
	public object lastCharacterIndex; // 0x4
	public object characterCount; // 0x8
}

// Namespace: TMPro
public struct Extents
{

	// Fields
	internal static object zero; // 0x0
	internal static object uninitialized; // 0x0
	public object min; // 0xFFFFFFFFFFFFFFF8
	public object max; // 0x0

	// Methods

	// RVA: 0x72A26A4
	public object .ctor(object min, object max) { }

	// RVA: 0x72A26BC
	public override object ToString() { }

	// RVA: 0x72A2870
	private static object .cctor() { }

}

// Namespace: TMPro
public struct WordWrapState
{

	// Fields
	public object previous_WordBreak; // 0xFFFFFFFFFFFFFFF8
	public object total_CharacterCount; // 0xFFFFFFFFFFFFFFFC
	public object visible_CharacterCount; // 0x0
	public object visible_SpriteCount; // 0x4
	public object visible_LinkCount; // 0x8
	public object firstCharacterIndex; // 0xC
	public object firstVisibleCharacterIndex; // 0x10
	public object lastCharacterIndex; // 0x14
	public object lastVisibleCharIndex; // 0x18
	public object lineNumber; // 0x1C
	public object maxCapHeight; // 0x20
	public object maxAscender; // 0x24
	public object maxDescender; // 0x28
	public object startOfLineAscender; // 0x2C
	public object maxLineAscender; // 0x30
	public object maxLineDescender; // 0x34
	public object pageAscender; // 0x38
	public object horizontalAlignment; // 0x3C
	public object marginLeft; // 0x40
	public object marginRight; // 0x44
	public object xAdvance; // 0x48
	public object preferredWidth; // 0x4C
	public object preferredHeight; // 0x50
	public object previousLineScale; // 0x54
	public object wordCount; // 0x58
	public object fontStyle; // 0x5C
	public object italicAngle; // 0x60
	public object fontScaleMultiplier; // 0x64
	public object currentFontSize; // 0x68
	public object baselineOffset; // 0x6C
	public object lineOffset; // 0x70
	public object isDrivenLineSpacing; // 0x74
	public object glyphHorizontalAdvanceAdjustment; // 0x78
	public object cSpace; // 0x7C
	public object mSpace; // 0x80
	public object textInfo; // 0x88
	public object lineInfo; // 0x90
	public object vertexColor; // 0xEC
	public object underlineColor; // 0xF0
	public object strikethroughColor; // 0xF4
	public object highlightColor; // 0xF8
	public object basicStyleStack; // 0xFC
	public object italicAngleStack; // 0x108
	public object colorStack; // 0x128
	public object underlineColorStack; // 0x148
	public object strikethroughColorStack; // 0x168
	public object highlightColorStack; // 0x188
	public object highlightStateStack; // 0x1A8
	public object colorGradientStack; // 0x1D8
	public object sizeStack; // 0x200
	public object indentStack; // 0x220
	public object fontWeightStack; // 0x240
	public object styleStack; // 0x260
	public object baselineStack; // 0x280
	public object actionStack; // 0x2A0
	public object materialReferenceStack; // 0x2C0
	public object lineJustificationStack; // 0x318
	public object spriteAnimationID; // 0x338
	public object currentFontAsset; // 0x340
	public object currentSpriteAsset; // 0x348
	public object currentMaterial; // 0x350
	public object currentMaterialIndex; // 0x358
	public object meshExtents; // 0x35C
	public object tagNoParsing; // 0x36C
	public object isNonBreakingSpace; // 0x36D
}

// Namespace: TMPro
public struct RichTextTagAttribute
{

	// Fields
	public object nameHashCode; // 0xFFFFFFFFFFFFFFF8
	public object valueHashCode; // 0xFFFFFFFFFFFFFFFC
	public object valueType; // 0x0
	public object valueStartIndex; // 0x4
	public object valueLength; // 0x8
	public object unitType; // 0xC
}

// Namespace: TMPro
public abstract class TMP_Asset
{

	// Fields
	private object m_InstanceID; // 0x10
	public object hashCode; // 0x14
	public object material; // 0x18
	public object materialHashCode; // 0x20

	// Properties
	public object instanceID { get; }

	// Methods

	// RVA: 0x72A2940
	public object get_instanceID() { }

	// RVA: 0x72A2980
	protected object .ctor() { }

}

// Namespace: TMPro
public class TMP_Character
{

	// Methods

	// RVA: 0x72A2988
	public object .ctor() { }

	// RVA: 0x72A29BC
	public object .ctor(object unicode, object fontAsset, object glyph) { }

	// RVA: 0x72A2A28
	internal object .ctor(object unicode, object glyphIndex) { }

}

// Namespace: TMPro
public struct TMP_Vertex
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object uv; // 0x4
	public object uv2; // 0xC
	public object uv4; // 0x14
	public object color; // 0x1C
	private static readonly object k_Zero; // 0x0
}

// Namespace: TMPro
public struct TMP_Offset
{

	// Fields
	private object m_Left; // 0xFFFFFFFFFFFFFFF8
	private object m_Right; // 0xFFFFFFFFFFFFFFFC
	private object m_Top; // 0x0
	private object m_Bottom; // 0x4
	private static readonly object k_ZeroOffset; // 0x0

	// Properties
	public object left { get; }
	public object right { get; }
	public object top { get; }
	public object bottom { get; }
	public static object zero { get; }

	// Methods

	// RVA: 0x72A2A74
	public object get_left() { }

	// RVA: 0x72A2A84
	public object get_right() { }

	// RVA: 0x72A2A94
	public object get_top() { }

	// RVA: 0x72A2AA4
	public object get_bottom() { }

	// RVA: 0x72A2AB4
	public static object get_zero() { }

	// RVA: 0x72A2B38
	public object .ctor(object left, object right, object top, object bottom) { }

	// RVA: 0x72A2B50
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x72A2B74
	public static object op_Multiply(object a, object b) { }

	// RVA: 0x72A2B88
	public override object GetHashCode() { }

	// RVA: 0x72A2C68
	public override object Equals(object obj) { }

	// RVA: 0x72A2D58
	private static object .cctor() { }

}

// Namespace: TMPro
public struct HighlightState
{

	// Fields
	public object color; // 0xFFFFFFFFFFFFFFF8
	public object padding; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x72A2DA4
	public object .ctor(object color, object padding) { }

	// RVA: 0x72A2DC4
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x72A2E7C
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x72A2F34
	public override object GetHashCode() { }

	// RVA: 0x72A3024
	public override object Equals(object obj) { }

}

// Namespace: TMPro
public struct TMP_CharacterInfo
{

	// Fields
	public object character; // 0xFFFFFFFFFFFFFFF8
	public object index; // 0xFFFFFFFFFFFFFFFC
	public object stringLength; // 0x0
	public object elementType; // 0x4
	public object textElement; // 0x8
	public object fontAsset; // 0x10
	public object spriteAsset; // 0x18
	public object spriteIndex; // 0x20
	public object material; // 0x28
	public object materialReferenceIndex; // 0x30
	public object isUsingAlternateTypeface; // 0x34
	public object pointSize; // 0x38
	public object lineNumber; // 0x3C
	public object pageNumber; // 0x40
	public object vertexIndex; // 0x44
	public object vertex_BL; // 0x48
	public object vertex_TL; // 0x70
	public object vertex_TR; // 0x98
	public object vertex_BR; // 0xC0
	public object topLeft; // 0xE8
	public object bottomLeft; // 0xF4
	public object topRight; // 0x100
	public object bottomRight; // 0x10C
	public object origin; // 0x118
	public object xAdvance; // 0x11C
	public object ascender; // 0x120
	public object baseLine; // 0x124
	public object descender; // 0x128
	internal object adjustedAscender; // 0x12C
	internal object adjustedDescender; // 0x130
	public object aspectRatio; // 0x134
	public object scale; // 0x138
	public object color; // 0x13C
	public object underlineColor; // 0x140
	public object underlineVertexIndex; // 0x144
	public object strikethroughColor; // 0x148
	public object strikethroughVertexIndex; // 0x14C
	public object highlightColor; // 0x150
	public object highlightState; // 0x154
	public object style; // 0x168
	public object isVisible; // 0x16C
}

// Namespace: TMPro
public enum ColorMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Single;
	public const object HorizontalGradient;
	public const object VerticalGradient;
	public const object FourCornersGradient;
}

// Namespace: TMPro
public class TMP_ColorGradient
{

	// Fields
	public object colorMode; // 0x10
	public object topLeft; // 0x14
	public object topRight; // 0x24
	public object bottomLeft; // 0x34
	public object bottomRight; // 0x44
	private const object k_DefaultColorMode;
	private static readonly object k_DefaultColor; // 0x0

	// Methods

	// RVA: 0x72A3160
	public object .ctor() { }

	// RVA: 0x72A3208
	public object .ctor(object color) { }

	// RVA: 0x72A3278
	public object .ctor(object color0, object color1, object color2, object color3) { }

	// RVA: 0x72A3320
	private static object .cctor() { }

}

// Namespace: TMPro
public static class TMP_Compatibility
{

	// Methods

	// RVA: 0x72A3370
	public static object ConvertTextAlignmentEnumValues(object oldValue) { }

}

// Namespace: TMPro
public enum AtlasPopulationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Static;
	public const object Dynamic;
	public const object DynamicOS;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__124_0; // 0x8
	public static object <>9__125_0; // 0x10

	// Methods

	// RVA: 0x72AF3B8
	private static object .cctor() { }

	// RVA: 0x72AF418
	public object .ctor() { }

	// RVA: 0x72AF420
	internal object <SortCharacterTable>b__124_0(object c) { }

	// RVA: 0x72AF440
	internal object <SortGlyphTable>b__125_0(object c) { }

}

// Namespace: TMPro
public class TMP_FontAsset
{

	// Fields
	private object m_Version; // 0x28
	internal object m_SourceFontFileGUID; // 0x30
	private object m_SourceFontFile; // 0x38
	private object m_AtlasPopulationMode; // 0x40
	internal object m_FaceInfo; // 0x48
	internal object m_GlyphTable; // 0xA8
	internal object m_GlyphLookupDictionary; // 0xB0
	internal object m_CharacterTable; // 0xB8
	internal object m_CharacterLookupDictionary; // 0xC0
	internal object m_AtlasTexture; // 0xC8
	internal object m_AtlasTextures; // 0xD0
	internal object m_AtlasTextureIndex; // 0xD8
	private object m_IsMultiAtlasTexturesEnabled; // 0xDC
	private object m_ClearDynamicDataOnBuild; // 0xDD
	private object m_UsedGlyphRects; // 0xE0
	private object m_FreeGlyphRects; // 0xE8
	private object m_fontInfo; // 0xF0
	public object atlas; // 0xF8
	internal object m_AtlasWidth; // 0x100
	internal object m_AtlasHeight; // 0x104
	internal object m_AtlasPadding; // 0x108
	internal object m_AtlasRenderMode; // 0x10C
	internal object m_glyphInfoList; // 0x110
	internal object m_KerningTable; // 0x118
	internal object m_FontFeatureTable; // 0x120
	private object fallbackFontAssets; // 0x128
	internal object m_FallbackFontAssetTable; // 0x130
	internal object m_CreationSettings; // 0x138
	private object m_FontWeightTable; // 0x190
	private object fontWeights; // 0x198
	public object normalStyle; // 0x1A0
	public object normalSpacingOffset; // 0x1A4
	public object boldStyle; // 0x1A8
	public object boldSpacing; // 0x1AC
	public object italicStyle; // 0x1B0
	public object tabSize; // 0x1B1
	internal object IsFontAssetLookupTablesDirty; // 0x1B2
	private static object k_ReadFontAssetDefinitionMarker; // 0x0
	private static object k_AddSynthesizedCharactersMarker; // 0x8
	private static object k_TryAddCharacterMarker; // 0x10
	private static object k_TryAddCharactersMarker; // 0x18
	private static object k_UpdateGlyphAdjustmentRecordsMarker; // 0x20
	private static object k_ClearFontAssetDataMarker; // 0x28
	private static object k_UpdateFontAssetDataMarker; // 0x30
	private static object s_DefaultMaterialSuffix; // 0x38
	internal object FallbackSearchQueryLookup; // 0x1B8
	private static object k_SearchedFontAssetLookup; // 0x40
	private static object k_FontAssets_FontFeaturesUpdateQueue; // 0x48
	private static object k_FontAssets_FontFeaturesUpdateQueueLookup; // 0x50
	private static object k_FontAssets_AtlasTexturesUpdateQueue; // 0x58
	private static object k_FontAssets_AtlasTexturesUpdateQueueLookup; // 0x60
	private object m_GlyphsToRender; // 0x1C0
	private object m_GlyphsRendered; // 0x1C8
	private object m_GlyphIndexList; // 0x1D0
	private object m_GlyphIndexListNewlyAdded; // 0x1D8
	internal object m_GlyphsToAdd; // 0x1E0
	internal object m_GlyphsToAddLookup; // 0x1E8
	internal object m_CharactersToAdd; // 0x1F0
	internal object m_CharactersToAddLookup; // 0x1F8
	internal object s_MissingCharacterList; // 0x200
	internal object m_MissingUnicodesFromFontFile; // 0x208
	internal static object k_GlyphIndexArray; // 0x68

	// Properties
	public object version { get; set; }
	public object sourceFontFile { get; set; }
	public object atlasPopulationMode { get; set; }
	public object faceInfo { get; set; }
	public object glyphTable { get; set; }
	public object glyphLookupTable { get; }
	public object characterTable { get; set; }
	public object characterLookupTable { get; }
	public object atlasTexture { get; }
	public object atlasTextures { get; set; }
	public object atlasTextureCount { get; }
	public object isMultiAtlasTexturesEnabled { get; set; }
	internal object clearDynamicDataOnBuild { get; set; }
	internal object usedGlyphRects { get; set; }
	internal object freeGlyphRects { get; set; }
	public object fontInfo { get; }
	public object atlasWidth { get; set; }
	public object atlasHeight { get; set; }
	public object atlasPadding { get; set; }
	public object atlasRenderMode { get; set; }
	public object fontFeatureTable { get; set; }
	public object fallbackFontAssetTable { get; set; }
	public object creationSettings { get; set; }
	public object fontWeightTable { get; set; }

	// Methods

	// RVA: 0x72A3394
	public object get_version() { }

	// RVA: 0x72A339C
	internal object set_version(object value) { }

	// RVA: 0x72A33A4
	public object get_sourceFontFile() { }

	// RVA: 0x72A33AC
	internal object set_sourceFontFile(object value) { }

	// RVA: 0x72A33B4
	public object get_atlasPopulationMode() { }

	// RVA: 0x72A33BC
	public object set_atlasPopulationMode(object value) { }

	// RVA: 0x72A33C4
	public object get_faceInfo() { }

	// RVA: 0x72A33EC
	public object set_faceInfo(object value) { }

	// RVA: 0x72A33F8
	public object get_glyphTable() { }

	// RVA: 0x72A3400
	internal object set_glyphTable(object value) { }

	// RVA: 0x72A3408
	public object get_glyphLookupTable() { }

	// RVA: 0x72A36D0
	public object get_characterTable() { }

	// RVA: 0x72A36D8
	internal object set_characterTable(object value) { }

	// RVA: 0x72A36E0
	public object get_characterLookupTable() { }

	// RVA: 0x72A371C
	public object get_atlasTexture() { }

	// RVA: 0x72A37F0
	public object get_atlasTextures() { }

	// RVA: 0x72A37F8
	public object set_atlasTextures(object value) { }

	// RVA: 0x72A3800
	public object get_atlasTextureCount() { }

	// RVA: 0x72A380C
	public object get_isMultiAtlasTexturesEnabled() { }

	// RVA: 0x72A3814
	public object set_isMultiAtlasTexturesEnabled(object value) { }

	// RVA: 0x72A381C
	internal object get_clearDynamicDataOnBuild() { }

	// RVA: 0x72A3824
	internal object set_clearDynamicDataOnBuild(object value) { }

	// RVA: 0x72A382C
	internal object get_usedGlyphRects() { }

	// RVA: 0x72A3834
	internal object set_usedGlyphRects(object value) { }

	// RVA: 0x72A383C
	internal object get_freeGlyphRects() { }

	// RVA: 0x72A3844
	internal object set_freeGlyphRects(object value) { }

	// RVA: 0x72A384C
	public object get_fontInfo() { }

	// RVA: 0x72A3854
	public object get_atlasWidth() { }

	// RVA: 0x72A385C
	internal object set_atlasWidth(object value) { }

	// RVA: 0x72A3864
	public object get_atlasHeight() { }

	// RVA: 0x72A386C
	internal object set_atlasHeight(object value) { }

	// RVA: 0x72A3874
	public object get_atlasPadding() { }

	// RVA: 0x72A387C
	internal object set_atlasPadding(object value) { }

	// RVA: 0x72A3884
	public object get_atlasRenderMode() { }

	// RVA: 0x72A388C
	internal object set_atlasRenderMode(object value) { }

	// RVA: 0x72A3894
	public object get_fontFeatureTable() { }

	// RVA: 0x72A389C
	internal object set_fontFeatureTable(object value) { }

	// RVA: 0x72A38A4
	public object get_fallbackFontAssetTable() { }

	// RVA: 0x72A38AC
	public object set_fallbackFontAssetTable(object value) { }

	// RVA: 0x72A38B4
	public object get_creationSettings() { }

	// RVA: 0x72A38DC
	public object set_creationSettings(object value) { }

	// RVA: 0x72A38E8
	public object get_fontWeightTable() { }

	// RVA: 0x72A38F0
	internal object set_fontWeightTable(object value) { }

	// RVA: 0x72A38F8
	public static object CreateFontAsset(object font) { }

	// RVA: 0x72A3980
	public static object CreateFontAsset(object font, object samplingPointSize, object atlasPadding, object renderMode, object atlasWidth, object atlasHeight, object atlasPopulationMode, object enableMultiAtlasSupport) { }

	// RVA: 0x72A3F14
	private object Awake() { }

	// RVA: 0x72A3444
	public object ReadFontAssetDefinition() { }

	// RVA: 0x72A4EB8
	internal object InitializeDictionaryLookupTables() { }

	// RVA: 0x72A526C
	internal object InitializeGlyphLookupDictionary() { }

	// RVA: 0x72A55BC
	internal object InitializeCharacterLookupDictionary() { }

	// RVA: 0x72A5820
	internal object InitializeGlyphPaidAdjustmentRecordsLookupDictionary() { }

	// RVA: 0x72A4EE4
	internal object AddSynthesizedCharactersAndFaceMetrics() { }

	// RVA: 0x72A5EA0
	private object AddSynthesizedCharacter(object unicode, object isFontFaceLoaded, object addImmediately) { }

	// RVA: 0x72A6158
	internal object AddCharacterToLookupCache(object unicode, object character) { }

	// RVA: 0x72A6240
	internal object SortCharacterTable() { }

	// RVA: 0x72A6390
	internal object SortGlyphTable() { }

	// RVA: 0x72A64E0
	internal object SortFontFeatureTable() { }

	// RVA: 0x72A6710
	internal object SortAllTables() { }

	// RVA: 0x72A674C
	public object HasCharacter(object character) { }

	// RVA: 0x72A67BC
	public object HasCharacter(object character, object searchFallbacks, object tryAddCharacter) { }

	// RVA: 0x72A7AA8
	private object HasCharacter_Internal(object character, object searchFallbacks, object tryAddCharacter) { }

	// RVA: 0x72A7CF4
	public object HasCharacters(object text, object missingCharacters) { }

	// RVA: 0x72A7F1C
	public object HasCharacters(object text, object missingCharacters, object searchFallbacks, object tryAddCharacter) { }

	// RVA: 0x72A869C
	public object HasCharacters(object text) { }

	// RVA: 0x72A8794
	public static object GetCharacters(object fontAsset) { }

	// RVA: 0x72A88D4
	public static object GetCharactersArray(object fontAsset) { }

	// RVA: 0x72A8A14
	internal object GetGlyphIndex(object unicode) { }

	// RVA: 0x72A8B84
	internal static object RegisterFontAssetForFontFeatureUpdate(object fontAsset) { }

	// RVA: 0x72A8D78
	internal static object UpdateFontFeaturesForFontAssetsInQueue() { }

	// RVA: 0x72A931C
	internal static object RegisterFontAssetForAtlasTextureUpdate(object fontAsset) { }

	// RVA: 0x72A9510
	internal static object UpdateAtlasTexturesForFontAssetsInQueue() { }

	// RVA: 0x72A96CC
	public object TryAddCharacters(object unicodes, object includeFontFeatures) { }

	// RVA: 0x72A96F0
	public object TryAddCharacters(object unicodes, object missingUnicodes, object includeFontFeatures) { }

	// RVA: 0x72AAF70
	public object TryAddCharacters(object characters, object includeFontFeatures) { }

	// RVA: 0x72AAF94
	public object TryAddCharacters(object characters, object missingCharacters, object includeFontFeatures) { }

	// RVA: 0x72A6D68
	internal object TryAddCharacterInternal(object unicode, object character) { }

	// RVA: 0x72AC404
	internal object TryAddCharacterFromOS(object unicode, object character) { }

	// RVA: 0x72AD3C0
	internal object TryGetCharacter_and_QueueRenderToTexture(object unicode, object character) { }

	// RVA: 0x72A96C8
	internal object TryAddGlyphsToAtlasTextures() { }

	// RVA: 0x72AA8A0
	private object TryAddGlyphsToNewAtlasTexture() { }

	// RVA: 0x72AC13C
	private object SetupNewAtlasTexture() { }

	// RVA: 0x72ADC60
	internal object UpdateAtlasTexture() { }

	// RVA: 0x72A8F34
	internal object UpdateGlyphAdjustmentRecords() { }

	// RVA: 0x72AE0B8
	internal object UpdateGlyphAdjustmentRecords(object glyphIndexes) { }

	// RVA: 0x72AE494
	internal object UpdateGlyphAdjustmentRecords(object glyphIndexes) { }

	// RVA: 0x72AE498
	internal object UpdateGlyphAdjustmentRecords(object newGlyphIndexes, object allGlyphIndexes) { }

	// RVA: -1
	private object CopyListDataToArray(object srcList, object dstArray) { }

	// RVA: 0x72AE49C
	public object ClearFontAssetData(object setAtlasSizeToZero) { }

	// RVA: 0x72AEAFC
	internal object ClearFontAssetDataInternal() { }

	// RVA: 0x72AEB24
	internal object UpdateFontAssetData() { }

	// RVA: 0x72AE4D0
	internal object ClearFontAssetTables() { }

	// RVA: 0x72AE754
	internal object ClearAtlasTextures(object setAtlasSizeToZero) { }

	// RVA: 0x72A3FD4
	internal object UpgradeFontAsset() { }

	// RVA: 0x72A5A40
	private object UpgradeGlyphAdjustmentTableToFontFeatureTable() { }

	// RVA: 0x72AED10
	public object .ctor() { }

	// RVA: 0x72AF0E8
	private static object .cctor() { }

}

// Namespace: TMPro
public class FaceInfo_Legacy
{

	// Fields
	public object Name; // 0x8
	public object PointSize; // 0x10
	public object Scale; // 0x14
	public object CharacterCount; // 0x18
	public object LineHeight; // 0x1C
	public object Baseline; // 0x20
	public object Ascender; // 0x24
	public object CapHeight; // 0x28
	public object Descender; // 0x2C
	public object CenterLine; // 0x30
	public object SuperscriptOffset; // 0x34
	public object SubscriptOffset; // 0x38
	public object SubSize; // 0x3C
	public object Underline; // 0x40
	public object UnderlineThickness; // 0x44
	public object strikethrough; // 0x48
	public object strikethroughThickness; // 0x4C
	public object TabWidth; // 0x50
	public object Padding; // 0x54
	public object AtlasWidth; // 0x58
	public object AtlasHeight; // 0x5C

	// Methods

	// RVA: 0x72AF464
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_Glyph
{

	// Methods

	// RVA: 0x72AF46C
	public object .ctor() { }

}

// Namespace: TMPro
public struct FontAssetCreationSettings
{

	// Fields
	public object sourceFontFileName; // 0xFFFFFFFFFFFFFFF8
	public object sourceFontFileGUID; // 0x0
	public object pointSizeSamplingMode; // 0x8
	public object pointSize; // 0xC
	public object padding; // 0x10
	public object packingMode; // 0x14
	public object atlasWidth; // 0x18
	public object atlasHeight; // 0x1C
	public object characterSetSelectionMode; // 0x20
	public object characterSequence; // 0x28
	public object referencedFontAssetGUID; // 0x30
	public object referencedTextAssetGUID; // 0x38
	public object fontStyle; // 0x40
	public object fontStyleModifier; // 0x44
	public object renderMode; // 0x48
	public object includeFontFeatures; // 0x4C
}

// Namespace: TMPro
public struct TMP_FontWeightPair
{

	// Fields
	public object regularTypeface; // 0xFFFFFFFFFFFFFFF8
	public object italicTypeface; // 0x0
}

// Namespace: TMPro
public struct GlyphValueRecord_Legacy
{

	// Fields
	public object xPlacement; // 0xFFFFFFFFFFFFFFF8
	public object yPlacement; // 0xFFFFFFFFFFFFFFFC
	public object xAdvance; // 0x0
	public object yAdvance; // 0x4
}

// Namespace: TMPro
public class KerningPair
{

	// Fields
	private object m_FirstGlyph; // 0x8
	private object m_FirstGlyphAdjustments; // 0xC
	private object m_SecondGlyph; // 0x1C
	private object m_SecondGlyphAdjustments; // 0x20
	public object xOffset; // 0x30
	internal static object empty; // 0x0
	private object m_IgnoreSpacingAdjustments; // 0x34

	// Properties
	public object firstGlyph { get; }
	public object firstGlyphAdjustments { get; }
	public object secondGlyph { get; }
	public object secondGlyphAdjustments { get; }

	// Methods

	// RVA: 0x72AF658
	public object get_firstGlyph() { }

	// RVA: 0x72AF660
	public object get_firstGlyphAdjustments() { }

	// RVA: 0x72AF66C
	public object get_secondGlyph() { }

	// RVA: 0x72AF674
	public object get_secondGlyphAdjustments() { }

	// RVA: 0x72AF680
	public object .ctor() { }

	// RVA: 0x72AF6B4
	public object .ctor(object firstGlyph, object firstGlyphAdjustments, object secondGlyph, object secondGlyphAdjustments) { }

	// RVA: 0x72AF740
	private static object .cctor() { }

}

// Namespace: TMPro
public class KerningTable
{

	// Fields
	public object kerningPairs; // 0x8

	// Methods

	// RVA: 0x72AF064
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_FontAssetUtilities
{

	// Fields
	private static readonly object s_Instance; // 0x0
	private static object k_SearchedAssets; // 0x8

	// Methods

	// RVA: 0x72AF7B0
	private static object .cctor() { }

	// RVA: 0x72AF818
	public static object GetCharacterFromFontAsset(object unicode, object sourceFontAsset, object includeFallbacks, object fontStyle, object fontWeight, object isAlternativeTypeface) { }

	// RVA: 0x72AF9A0
	private static object GetCharacterFromFontAsset_Internal(object unicode, object sourceFontAsset, object includeFallbacks, object fontStyle, object fontWeight, object isAlternativeTypeface) { }

	// RVA: 0x72AFE80
	public static object GetCharacterFromFontAssets(object unicode, object sourceFontAsset, object fontAssets, object includeFallbacks, object fontStyle, object fontWeight, object isAlternativeTypeface) { }

	// RVA: 0x72B0190
	public static object GetSpriteCharacterFromSpriteAsset(object unicode, object spriteAsset, object includeFallbacks) { }

	// RVA: 0x72B054C
	private static object GetSpriteCharacterFromSpriteAsset_Internal(object unicode, object spriteAsset, object includeFallbacks) { }

	// RVA: 0x72AF810
	public object .ctor() { }

}

// Namespace: TMPro
public enum FontFeatureLookupFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object IgnoreLigatures;
	public const object IgnoreSpacingAdjustments;
}

// Namespace: TMPro
public struct TMP_GlyphValueRecord
{

	// Fields
	internal object m_XPlacement; // 0xFFFFFFFFFFFFFFF8
	internal object m_YPlacement; // 0xFFFFFFFFFFFFFFFC
	internal object m_XAdvance; // 0x0
	internal object m_YAdvance; // 0x4

	// Properties
	public object xPlacement { get; }
	public object yPlacement { get; }
	public object xAdvance { get; }
	public object yAdvance { get; }

	// Methods

	// RVA: 0x72B0798
	public object get_xPlacement() { }

	// RVA: 0x72B07A8
	public object get_yPlacement() { }

	// RVA: 0x72B07B8
	public object get_xAdvance() { }

	// RVA: 0x72B07C8
	public object get_yAdvance() { }

	// RVA: 0x72AECA0
	public object .ctor(object xPlacement, object yPlacement, object xAdvance, object yAdvance) { }

	// RVA: 0x72B07E4
	internal object .ctor(object valueRecord) { }

	// RVA: 0x72B08BC
	public static object op_Addition(object a, object b) { }

}

// Namespace: TMPro
public struct TMP_GlyphAdjustmentRecord
{

	// Fields
	internal object m_GlyphIndex; // 0xFFFFFFFFFFFFFFF8
	internal object m_GlyphValueRecord; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object glyphIndex { get; }

	// Methods

	// RVA: 0x72B08D0
	public object get_glyphIndex() { }

	// RVA: 0x72AECAC
	public object .ctor(object glyphIndex, object glyphValueRecord) { }

	// RVA: 0x72B08F0
	internal object .ctor(object adjustmentRecord) { }

}

// Namespace: TMPro
public class TMP_GlyphPairAdjustmentRecord
{

	// Fields
	internal object m_FirstAdjustmentRecord; // 0x8
	internal object m_SecondAdjustmentRecord; // 0x1C
	internal object m_FeatureLookupFlags; // 0x30

	// Properties
	public object firstAdjustmentRecord { get; }
	public object secondAdjustmentRecord { get; }

	// Methods

	// RVA: 0x72B0A3C
	public object get_firstAdjustmentRecord() { }

	// RVA: 0x72B0A50
	public object get_secondAdjustmentRecord() { }

	// RVA: 0x72AECBC
	public object .ctor(object firstAdjustmentRecord, object secondAdjustmentRecord) { }

	// RVA: 0x72ADF54
	internal object .ctor(object glyphPairAdjustmentRecord) { }

}

// Namespace: TMPro
public struct GlyphPairKey
{

	// Fields
	public object firstGlyphIndex; // 0xFFFFFFFFFFFFFFF8
	public object secondGlyphIndex; // 0xFFFFFFFFFFFFFFFC
	public object key; // 0x0

	// Methods

	// RVA: 0x72A5E70
	internal object .ctor(object record) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__6_0; // 0x8
	public static object <>9__6_1; // 0x10

	// Methods

	// RVA: 0x72B0A9C
	private static object .cctor() { }

	// RVA: 0x72B0AFC
	public object .ctor() { }

	// RVA: 0x72B0B04
	internal object <SortGlyphPairAdjustmentRecords>b__6_0(object s) { }

	// RVA: 0x72B0B24
	internal object <SortGlyphPairAdjustmentRecords>b__6_1(object s) { }

}

// Namespace: TMPro
public class TMP_FontFeatureTable
{

	// Fields
	internal object m_GlyphPairAdjustmentRecords; // 0x8
	internal object m_GlyphPairAdjustmentRecordLookupDictionary; // 0x10

	// Properties
	public object glyphPairAdjustmentRecords { get; }

	// Methods

	// RVA: 0x72B0A94
	public object get_glyphPairAdjustmentRecords() { }

	// RVA: 0x72ADE88
	public object .ctor() { }

	// RVA: 0x72A6500
	public object SortGlyphPairAdjustmentRecords() { }

}

// Namespace: 
public enum ContentType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Standard;
	public const object Autocorrected;
	public const object IntegerNumber;
	public const object DecimalNumber;
	public const object Alphanumeric;
	public const object Name;
	public const object EmailAddress;
	public const object Password;
	public const object Pin;
	public const object Custom;
}

// Namespace: 
public enum InputType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Standard;
	public const object AutoCorrect;
	public const object Password;
}

// Namespace: 
public enum CharacterValidation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Digit;
	public const object Integer;
	public const object Decimal;
	public const object Alphanumeric;
	public const object Name;
	public const object Regex;
	public const object EmailAddress;
	public const object CustomValidator;
}

// Namespace: 
public enum LineType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SingleLine;
	public const object MultiLineSubmit;
	public const object MultiLineNewline;
}

// Namespace: 
public sealed class OnValidateInput
{

	// Methods

	// RVA: 0x72DBB24
	public object .ctor(object object, object method) { }

	// RVA: 0x72DBBD4
	public virtual object Invoke(object text, object charIndex, object addedChar) { }

}

// Namespace: 
public class SubmitEvent
{

	// Methods

	// RVA: 0x72DBBE8
	public object .ctor() { }

}

// Namespace: 
public class OnChangeEvent
{

	// Methods

	// RVA: 0x72DBC40
	public object .ctor() { }

}

// Namespace: 
public class SelectionEvent
{

	// Methods

	// RVA: 0x72DBC98
	public object .ctor() { }

}

// Namespace: 
public class TextSelectionEvent
{

	// Methods

	// RVA: 0x72DBCF0
	public object .ctor() { }

}

// Namespace: 
public class TouchScreenKeyboardEvent
{

	// Methods

	// RVA: 0x72DBD48
	public object .ctor() { }

}

// Namespace: 
protected enum EditState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Continue;
	public const object Finish;
}

// Namespace: 
private sealed class <CaretBlink>d__279
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x72DBDA0
	public object .ctor(object <>1__state) { }

	// RVA: 0x72DBDCC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x72DBDD0
	private object MoveNext() { }

	// RVA: 0x72DBF18
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x72DBF20
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x72DBF60
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <MouseDragOutsideRect>d__297
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object eventData; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x72DBF68
	public object .ctor(object <>1__state) { }

	// RVA: 0x72DBF94
	private object System.IDisposable.Dispose() { }

	// RVA: 0x72DBF98
	private object MoveNext() { }

	// RVA: 0x72DC1F0
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x72DC1F8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x72DC238
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: TMPro
public class TMP_InputField
{

	// Fields
	protected object m_SoftKeyboard; // 0xF8
	private static readonly object kSeparators; // 0x0
	protected object m_RectTransform; // 0x100
	protected object m_TextViewport; // 0x108
	protected object m_TextComponentRectMask; // 0x110
	protected object m_TextViewportRectMask; // 0x118
	private object m_CachedViewportRect; // 0x120
	protected object m_TextComponent; // 0x130
	protected object m_TextComponentRectTransform; // 0x138
	protected object m_Placeholder; // 0x140
	protected object m_VerticalScrollbar; // 0x148
	protected object m_VerticalScrollbarEventHandler; // 0x150
	private object m_IsDrivenByLayoutComponents; // 0x158
	private object m_LayoutGroup; // 0x160
	private object m_IScrollHandlerParent; // 0x168
	private object m_ScrollPosition; // 0x170
	protected object m_ScrollSensitivity; // 0x174
	private object m_ContentType; // 0x178
	private object m_InputType; // 0x17C
	private object m_AsteriskChar; // 0x180
	private object m_KeyboardType; // 0x184
	private object m_LineType; // 0x188
	private object m_HideMobileInput; // 0x18C
	private object m_HideSoftKeyboard; // 0x18D
	private object m_CharacterValidation; // 0x190
	private object m_RegexValue; // 0x198
	private object m_GlobalPointSize; // 0x1A0
	private object m_CharacterLimit; // 0x1A4
	private object m_OnEndEdit; // 0x1A8
	private object m_OnSubmit; // 0x1B0
	private object m_OnSelect; // 0x1B8
	private object m_OnDeselect; // 0x1C0
	private object m_OnTextSelection; // 0x1C8
	private object m_OnEndTextSelection; // 0x1D0
	private object m_OnValueChanged; // 0x1D8
	private object m_OnTouchScreenKeyboardStatusChanged; // 0x1E0
	private object m_OnValidateInput; // 0x1E8
	private object m_CaretColor; // 0x1F0
	private object m_CustomCaretColor; // 0x200
	private object m_SelectionColor; // 0x204
	protected object m_Text; // 0x218
	private object m_CaretBlinkRate; // 0x220
	private object m_CaretWidth; // 0x224
	private object m_ReadOnly; // 0x228
	private object m_RichText; // 0x229
	protected object m_StringPosition; // 0x22C
	protected object m_StringSelectPosition; // 0x230
	protected object m_CaretPosition; // 0x234
	protected object m_CaretSelectPosition; // 0x238
	private object caretRectTrans; // 0x240
	protected object m_CursorVerts; // 0x248
	private object m_CachedInputRenderer; // 0x250
	private object m_LastPosition; // 0x258
	protected object m_Mesh; // 0x260
	private object m_AllowInput; // 0x268
	private object m_ShouldActivateNextUpdate; // 0x269
	private object m_UpdateDrag; // 0x26A
	private object m_DragPositionOutOfBounds; // 0x26B
	private const object kHScrollSpeed;
	private const object kVScrollSpeed;
	protected object m_CaretVisible; // 0x26C
	private object m_BlinkCoroutine; // 0x270
	private object m_BlinkStartTime; // 0x278
	private object m_DragCoroutine; // 0x280
	private object m_OriginalText; // 0x288
	private object m_WasCanceled; // 0x290
	private object m_HasDoneFocusTransition; // 0x291
	private object m_WaitForSecondsRealtime; // 0x298
	private object m_PreventCallback; // 0x2A0
	private object m_TouchKeyboardAllowsInPlaceEditing; // 0x2A1
	private object m_IsTextComponentUpdateRequired; // 0x2A2
	private object m_isLastKeyBackspace; // 0x2A3
	private object m_PointerDownClickStartTime; // 0x2A4
	private object m_KeyDownStartTime; // 0x2A8
	private object m_DoubleClickDelay; // 0x2AC
	private const object kEmailSpecialCharacters;
	private object m_IsCompositionActive; // 0x2B0
	private object m_ShouldUpdateIMEWindowPosition; // 0x2B1
	private object m_PreviousIMEInsertionLine; // 0x2B4
	public object ContainsUnsupportedCharacter; // 0x2B8
	private object m_visualText; // 0x2C0
	public static object ProcessVisualText; // 0x8
	protected object m_GlobalFontAsset; // 0x2C8
	protected object m_OnFocusSelectAll; // 0x2D0
	protected object m_isSelectAll; // 0x2D1
	protected object m_ResetOnDeActivation; // 0x2D2
	private object m_SelectionStillActive; // 0x2D3
	private object m_ReleaseSelection; // 0x2D4
	private object m_PreviouslySelectedObject; // 0x2D8
	private object m_RestoreOriginalTextOnEscape; // 0x2E0
	protected object m_isRichTextEditingAllowed; // 0x2E1
	protected object m_LineLimit; // 0x2E4
	protected object m_InputValidator; // 0x2E8
	private object m_isSelected; // 0x2F0
	private object m_IsStringPositionDirty; // 0x2F1
	private object m_IsCaretPositionDirty; // 0x2F2
	private object m_forceRectTransformAdjustment; // 0x2F3
	private object m_ProcessingEvent; // 0x2F8

	// Properties
	private object inputSystem { get; }
	private object compositionString { get; }
	private object compositionLength { get; }
	protected object mesh { get; }
	public object shouldHideMobileInput { get; set; }
	public object shouldHideSoftKeyboard { get; set; }
	public object text { get; set; }
	public object isFocused { get; }
	public object caretBlinkRate { get; set; }
	public object caretWidth { get; set; }
	public object textViewport { get; set; }
	public object textComponent { get; set; }
	public object placeholder { get; set; }
	public object verticalScrollbar { get; set; }
	public object scrollSensitivity { get; set; }
	public object caretColor { get; set; }
	public object customCaretColor { get; set; }
	public object selectionColor { get; set; }
	public object onEndEdit { get; set; }
	public object onSubmit { get; set; }
	public object onSelect { get; set; }
	public object onDeselect { get; set; }
	public object onTextSelection { get; set; }
	public object onEndTextSelection { get; set; }
	public object onValueChanged { get; set; }
	public object onTouchScreenKeyboardStatusChanged { get; set; }
	public object onValidateInput { get; set; }
	public object characterLimit { get; set; }
	public object pointSize { get; set; }
	public object fontAsset { get; set; }
	public object onFocusSelectAll { get; set; }
	public object resetOnDeActivation { get; set; }
	public object restoreOriginalTextOnEscape { get; set; }
	public object isRichTextEditingAllowed { get; set; }
	public object contentType { get; set; }
	public object lineType { get; set; }
	public object lineLimit { get; set; }
	public object inputType { get; set; }
	public object keyboardType { get; set; }
	public object characterValidation { get; set; }
	public object inputValidator { get; set; }
	public object readOnly { get; set; }
	public object richText { get; set; }
	public object multiLine { get; }
	public object asteriskChar { get; set; }
	public object wasCanceled { get; }
	protected object caretPositionInternal { get; set; }
	protected object stringPositionInternal { get; set; }
	protected object caretSelectPositionInternal { get; set; }
	protected object stringSelectPositionInternal { get; set; }
	private object hasSelection { get; }
	public object caretPosition { get; set; }
	public object selectionAnchorPosition { get; set; }
	public object selectionFocusPosition { get; set; }
	public object stringPosition { get; set; }
	public object selectionStringAnchorPosition { get; set; }
	public object selectionStringFocusPosition { get; set; }
	private static object clipboard { get; set; }
	public virtual object minWidth { get; }
	public virtual object preferredWidth { get; }
	public virtual object flexibleWidth { get; }
	public virtual object minHeight { get; }
	public virtual object preferredHeight { get; }
	public virtual object flexibleHeight { get; }
	public virtual object layoutPriority { get; }

	// Methods

	// RVA: 0x72B0B44
	private object get_inputSystem() { }

	// RVA: 0x72B0D54
	private object get_compositionString() { }

	// RVA: 0x72B0E34
	private object get_compositionLength() { }

	// RVA: 0x72B0E70
	protected object .ctor() { }

	// RVA: 0x72B11DC
	protected object get_mesh() { }

	// RVA: 0x72B12B8
	public object get_shouldHideMobileInput() { }

	// RVA: 0x72B1378
	public object set_shouldHideMobileInput(object value) { }

	// RVA: 0x72B1458
	public object get_shouldHideSoftKeyboard() { }

	// RVA: 0x72B155C
	public object set_shouldHideSoftKeyboard(object value) { }

	// RVA: 0x72B16E4
	private object isKeyboardUsingEvents() { }

	// RVA: 0x72B1768
	public object get_text() { }

	// RVA: 0x72B1770
	public object set_text(object value) { }

	// RVA: 0x72B19C4
	public object SetTextWithoutNotify(object input) { }

	// RVA: 0x72B1848
	private object SetText(object value, object sendCallback) { }

	// RVA: 0x72B20B8
	public object get_isFocused() { }

	// RVA: 0x72B20C0
	public object get_caretBlinkRate() { }

	// RVA: 0x72B20C8
	public object set_caretBlinkRate(object value) { }

	// RVA: 0x72B22C4
	public object get_caretWidth() { }

	// RVA: 0x72B22CC
	public object set_caretWidth(object value) { }

	// RVA: 0x72B242C
	public object get_textViewport() { }

	// RVA: 0x72B2434
	public object set_textViewport(object value) { }

	// RVA: 0x72B2490
	public object get_textComponent() { }

	// RVA: 0x72B2498
	public object set_textComponent(object value) { }

	// RVA: 0x72B2510
	public object get_placeholder() { }

	// RVA: 0x72B2518
	public object set_placeholder(object value) { }

	// RVA: 0x72B2574
	public object get_verticalScrollbar() { }

	// RVA: 0x72B257C
	public object set_verticalScrollbar(object value) { }

	// RVA: 0x72B27DC
	public object get_scrollSensitivity() { }

	// RVA: 0x72B27E4
	public object set_scrollSensitivity(object value) { }

	// RVA: 0x72B28A4
	public object get_caretColor() { }

	// RVA: 0x72B291C
	public object set_caretColor(object value) { }

	// RVA: 0x72B29C4
	public object get_customCaretColor() { }

	// RVA: 0x72B29CC
	public object set_customCaretColor(object value) { }

	// RVA: 0x72B2A74
	public object get_selectionColor() { }

	// RVA: 0x72B2A88
	public object set_selectionColor(object value) { }

	// RVA: 0x72B2B30
	public object get_onEndEdit() { }

	// RVA: 0x72B2B38
	public object set_onEndEdit(object value) { }

	// RVA: 0x72B2B94
	public object get_onSubmit() { }

	// RVA: 0x72B2B9C
	public object set_onSubmit(object value) { }

	// RVA: 0x72B2BF8
	public object get_onSelect() { }

	// RVA: 0x72B2C00
	public object set_onSelect(object value) { }

	// RVA: 0x72B2C5C
	public object get_onDeselect() { }

	// RVA: 0x72B2C64
	public object set_onDeselect(object value) { }

	// RVA: 0x72B2CC0
	public object get_onTextSelection() { }

	// RVA: 0x72B2CC8
	public object set_onTextSelection(object value) { }

	// RVA: 0x72B2D24
	public object get_onEndTextSelection() { }

	// RVA: 0x72B2D2C
	public object set_onEndTextSelection(object value) { }

	// RVA: 0x72B2D88
	public object get_onValueChanged() { }

	// RVA: 0x72B2D90
	public object set_onValueChanged(object value) { }

	// RVA: 0x72B2DEC
	public object get_onTouchScreenKeyboardStatusChanged() { }

	// RVA: 0x72B2DF4
	public object set_onTouchScreenKeyboardStatusChanged(object value) { }

	// RVA: 0x72B2E50
	public object get_onValidateInput() { }

	// RVA: 0x72B2E58
	public object set_onValidateInput(object value) { }

	// RVA: 0x72B2EB4
	public object get_characterLimit() { }

	// RVA: 0x72B2EBC
	public object set_characterLimit(object value) { }

	// RVA: 0x72B2F7C
	public object get_pointSize() { }

	// RVA: 0x72B2F84
	public object set_pointSize(object value) { }

	// RVA: 0x72B3164
	public object get_fontAsset() { }

	// RVA: 0x72B316C
	public object set_fontAsset(object value) { }

	// RVA: 0x72B3310
	public object get_onFocusSelectAll() { }

	// RVA: 0x72B3318
	public object set_onFocusSelectAll(object value) { }

	// RVA: 0x72B3320
	public object get_resetOnDeActivation() { }

	// RVA: 0x72B3328
	public object set_resetOnDeActivation(object value) { }

	// RVA: 0x72B3330
	public object get_restoreOriginalTextOnEscape() { }

	// RVA: 0x72B3338
	public object set_restoreOriginalTextOnEscape(object value) { }

	// RVA: 0x72B3340
	public object get_isRichTextEditingAllowed() { }

	// RVA: 0x72B3348
	public object set_isRichTextEditingAllowed(object value) { }

	// RVA: 0x72B3350
	public object get_contentType() { }

	// RVA: 0x72B3358
	public object set_contentType(object value) { }

	// RVA: 0x72B35E8
	public object get_lineType() { }

	// RVA: 0x72B35F0
	public object set_lineType(object value) { }

	// RVA: 0x72B3748
	public object get_lineLimit() { }

	// RVA: 0x72B3750
	public object set_lineLimit(object value) { }

	// RVA: 0x72B37CC
	public object get_inputType() { }

	// RVA: 0x72B37D4
	public object set_inputType(object value) { }

	// RVA: 0x72B3874
	public object get_keyboardType() { }

	// RVA: 0x72B387C
	public object set_keyboardType(object value) { }

	// RVA: 0x72B3904
	public object get_characterValidation() { }

	// RVA: 0x72B390C
	public object set_characterValidation(object value) { }

	// RVA: 0x72B3994
	public object get_inputValidator() { }

	// RVA: 0x72B399C
	public object set_inputValidator(object value) { }

	// RVA: 0x72B3A3C
	public object get_readOnly() { }

	// RVA: 0x72B3A44
	public object set_readOnly(object value) { }

	// RVA: 0x72B3A4C
	public object get_richText() { }

	// RVA: 0x72B3A54
	public object set_richText(object value) { }

	// RVA: 0x72B3BE0
	public object get_multiLine() { }

	// RVA: 0x72B3BF4
	public object get_asteriskChar() { }

	// RVA: 0x72B3BFC
	public object set_asteriskChar(object value) { }

	// RVA: 0x72B3C74
	public object get_wasCanceled() { }

	// RVA: 0x72B3C7C
	protected object ClampStringPos(object pos) { }

	// RVA: 0x72B3CBC
	protected object ClampCaretPos(object pos) { }

	// RVA: 0x72B3D1C
	protected object get_caretPositionInternal() { }

	// RVA: 0x72B3D70
	protected object set_caretPositionInternal(object value) { }

	// RVA: 0x72B3DD0
	protected object get_stringPositionInternal() { }

	// RVA: 0x72B3E24
	protected object set_stringPositionInternal(object value) { }

	// RVA: 0x72B3E64
	protected object get_caretSelectPositionInternal() { }

	// RVA: 0x72B3EB8
	protected object set_caretSelectPositionInternal(object value) { }

	// RVA: 0x72B3F18
	protected object get_stringSelectPositionInternal() { }

	// RVA: 0x72B3F6C
	protected object set_stringSelectPositionInternal(object value) { }

	// RVA: 0x72B3FAC
	private object get_hasSelection() { }

	// RVA: 0x72B4034
	public object get_caretPosition() { }

	// RVA: 0x72B4088
	public object set_caretPosition(object value) { }

	// RVA: 0x72B4320
	public object get_selectionAnchorPosition() { }

	// RVA: 0x72B41B8
	public object set_selectionAnchorPosition(object value) { }

	// RVA: 0x72B4374
	public object get_selectionFocusPosition() { }

	// RVA: 0x72B426C
	public object set_selectionFocusPosition(object value) { }

	// RVA: 0x72B43C8
	public object get_stringPosition() { }

	// RVA: 0x72B441C
	public object set_stringPosition(object value) { }

	// RVA: 0x72B4660
	public object get_selectionStringAnchorPosition() { }

	// RVA: 0x72B4528
	public object set_selectionStringAnchorPosition(object value) { }

	// RVA: 0x72B46B4
	public object get_selectionStringFocusPosition() { }

	// RVA: 0x72B45C4
	public object set_selectionStringFocusPosition(object value) { }

	// RVA: 0x72B4708
	protected override object OnEnable() { }

	// RVA: 0x72B5810
	protected override object OnDisable() { }

	// RVA: 0x72B5EF8
	private object ON_TEXT_CHANGED(object obj) { }

	// RVA: 0x72B6420
	private object CaretBlink() { }

	// RVA: 0x72B649C
	private object SetCaretVisible() { }

	// RVA: 0x72B21F0
	private object SetCaretActive() { }

	// RVA: 0x72B658C
	protected object OnFocus() { }

	// RVA: 0x72B65E0
	protected object SelectAll() { }

	// RVA: 0x72B662C
	public object MoveTextEnd(object shift) { }

	// RVA: 0x72B68AC
	public object MoveTextStart(object shift) { }

	// RVA: 0x72B6AF8
	public object MoveToEndOfLine(object shift, object ctrl) { }

	// RVA: 0x72B6DCC
	public object MoveToStartOfLine(object shift, object ctrl) { }

	// RVA: 0x72B70A4
	private static object get_clipboard() { }

	// RVA: 0x72B70AC
	private static object set_clipboard(object value) { }

	// RVA: 0x72B70B4
	private object InPlaceEditing() { }

	// RVA: 0x72B7404
	private object UpdateStringPositionFromKeyboard() { }

	// RVA: 0x72B76C4
	protected virtual object LateUpdate() { }

	// RVA: 0x72B91A4
	private object MayDrag(object eventData) { }

	// RVA: 0x72B9390
	public virtual object OnBeginDrag(object eventData) { }

	// RVA: 0x72B93BC
	public virtual object OnDrag(object eventData) { }

	// RVA: 0x72B98B8
	private object MouseDragOutsideRect(object eventData) { }

	// RVA: 0x72B9938
	public virtual object OnEndDrag(object eventData) { }

	// RVA: 0x72B9960
	public override object OnPointerDown(object eventData) { }

	// RVA: 0x72BA4F4
	protected object KeyPressed(object evt) { }

	// RVA: 0x72BCBFC
	protected virtual object IsValidChar(object c) { }

	// RVA: 0x72BCC10
	public object ProcessEvent(object e) { }

	// RVA: 0x72BCC14
	public virtual object OnUpdateSelected(object eventData) { }

	// RVA: 0x72BCF28
	public virtual object OnScroll(object eventData) { }

	// RVA: 0x72BD1C4
	private object GetScrollPositionRelativeToViewport() { }

	// RVA: 0x72BB78C
	private object GetSelectedString() { }

	// RVA: 0x72BD548
	private object FindNextWordBegin() { }

	// RVA: 0x72BC3B0
	private object MoveRight(object shift, object ctrl) { }

	// RVA: 0x72BD678
	private object FindPrevWordBegin() { }

	// RVA: 0x72BBBA8
	private object MoveLeft(object shift, object ctrl) { }

	// RVA: 0x72BD78C
	private object LineUpCharacterPosition(object originalPos, object goToFirstChar) { }

	// RVA: 0x72BD90C
	private object LineDownCharacterPosition(object originalPos, object goToLastChar) { }

	// RVA: 0x72BDA8C
	private object PageUpCharacterPosition(object originalPos, object goToFirstChar) { }

	// RVA: 0x72BDD1C
	private object PageDownCharacterPosition(object originalPos, object goToLastChar) { }

	// RVA: 0x72BCBE4
	private object MoveDown(object shift) { }

	// RVA: 0x72BDFBC
	private object MoveDown(object shift, object goToLastChar) { }

	// RVA: 0x72BCBDC
	private object MoveUp(object shift) { }

	// RVA: 0x72BE3C8
	private object MoveUp(object shift, object goToFirstChar) { }

	// RVA: 0x72BCBEC
	private object MovePageUp(object shift) { }

	// RVA: 0x72BE7AC
	private object MovePageUp(object shift, object goToFirstChar) { }

	// RVA: 0x72BCBF4
	private object MovePageDown(object shift) { }

	// RVA: 0x72BECC8
	private object MovePageDown(object shift, object goToLastChar) { }

	// RVA: 0x72BB8E0
	private object Delete() { }

	// RVA: 0x72BB340
	private object DeleteKey() { }

	// RVA: 0x72BAB98
	private object Backspace() { }

	// RVA: 0x72BF1F8
	protected virtual object Append(object input) { }

	// RVA: 0x72BF2DC
	protected virtual object Append(object input) { }

	// RVA: 0x72BF668
	private object Insert(object c) { }

	// RVA: 0x72BBB54
	private object UpdateTouchKeyboardFromEditChanges() { }

	// RVA: 0x72B9140
	private object SendOnValueChangedAndUpdateLabel() { }

	// RVA: 0x72B2058
	private object SendOnValueChanged() { }

	// RVA: 0x72BF86C
	protected object SendOnEndEdit() { }

	// RVA: 0x72BCEC8
	protected object SendOnSubmit() { }

	// RVA: 0x72BF8CC
	protected object SendOnFocus() { }

	// RVA: 0x72BF92C
	protected object SendOnFocusLost() { }

	// RVA: 0x72BF98C
	protected object SendOnTextSelection() { }

	// RVA: 0x72BFA64
	protected object SendOnEndTextSelection() { }

	// RVA: 0x72B87E4
	protected object SendTouchScreenKeyboardStatusChanged() { }

	// RVA: 0x72B19CC
	protected object UpdateLabel() { }

	// RVA: 0x72B628C
	private object UpdateScrollbar() { }

	// RVA: 0x72BFB40
	private object OnScrollbarValueChange(object value) { }

	// RVA: 0x72B580C
	private object UpdateMaskRegions() { }

	// RVA: 0x72BD310
	private object AdjustTextPositionRelativeToViewport(object relativePosition) { }

	// RVA: 0x72B61F4
	private object GetCaretPositionFromStringIndex(object stringIndex) { }

	// RVA: 0x72BFB80
	private object GetMinCaretPositionFromStringIndex(object stringIndex) { }

	// RVA: 0x72BFC1C
	private object GetMaxCaretPositionFromStringIndex(object stringIndex) { }

	// RVA: 0x72B6800
	private object GetStringIndexFromCaretPosition(object caretPosition) { }

	// RVA: 0x72BFCB4
	public object ForceLabelUpdate() { }

	// RVA: 0x72B23A4
	private object MarkGeometryAsDirty() { }

	// RVA: 0x72BFCB8
	public virtual object Rebuild(object update) { }

	// RVA: 0x72BFEBC
	public virtual object LayoutComplete() { }

	// RVA: 0x72BFEC0
	public virtual object GraphicUpdateComplete() { }

	// RVA: 0x72BFCC8
	private object UpdateGeometry() { }

	// RVA: 0x72B503C
	private object AssignPositioningIfNeeded() { }

	// RVA: 0x72BFEC4
	private object OnFillVBO(object vbo) { }

	// RVA: 0x72C03EC
	private object GenerateCaret(object vbo, object roundingOffset) { }

	// RVA: 0x72C1478
	private object CreateCursorVerts() { }

	// RVA: 0x72C0C9C
	private object GenerateHightlight(object vbo, object roundingOffset) { }

	// RVA: 0x72C15C4
	private object AdjustRectTransformRelativeToViewport(object startPosition, object height, object isCharVisible) { }

	// RVA: 0x72B8864
	protected object Validate(object text, object pos, object ch) { }

	// RVA: 0x72C1C80
	public object ActivateInputField() { }

	// RVA: 0x72B7FE8
	private object ActivateInputFieldInternal() { }

	// RVA: 0x72C1E38
	public override object OnSelect(object eventData) { }

	// RVA: 0x72C1E9C
	public virtual object OnPointerClick(object eventData) { }

	// RVA: 0x72C1EC4
	public object OnControlClick() { }

	// RVA: 0x72B8700
	public object ReleaseSelection() { }

	// RVA: 0x72B5C18
	public object DeactivateInputField(object clearSelection) { }

	// RVA: 0x72C1EC8
	public override object OnDeselect(object eventData) { }

	// RVA: 0x72C1F44
	public virtual object OnSubmit(object eventData) { }

	// RVA: 0x72B34DC
	private object EnforceContentType() { }

	// RVA: 0x72B10F4
	private object SetTextComponentWrapMode() { }

	// RVA: 0x72B3B1C
	private object SetTextComponentRichTextMode() { }

	// RVA: 0x72B36EC
	private object SetToCustomIfContentTypeIsNot(object allowedContentTypes) { }

	// RVA: 0x72B385C
	private object SetToCustom() { }

	// RVA: 0x72B3A24
	private object SetToCustom(object characterValidation) { }

	// RVA: 0x72C201C
	protected override object DoStateTransition(object state, object instant) { }

	// RVA: 0x72C2048
	public virtual object CalculateLayoutInputHorizontal() { }

	// RVA: 0x72C204C
	public virtual object CalculateLayoutInputVertical() { }

	// RVA: 0x72C2050
	public virtual object get_minWidth() { }

	// RVA: 0x72C2058
	public virtual object get_preferredWidth() { }

	// RVA: 0x72C2260
	public virtual object get_flexibleWidth() { }

	// RVA: 0x72C2268
	public virtual object get_minHeight() { }

	// RVA: 0x72C2270
	public virtual object get_preferredHeight() { }

	// RVA: 0x72C2478
	public virtual object get_flexibleHeight() { }

	// RVA: 0x72C2480
	public virtual object get_layoutPriority() { }

	// RVA: 0x72B3044
	public object SetGlobalPointSize(object pointSize) { }

	// RVA: 0x72B31F0
	public object SetGlobalFontAsset(object fontAsset) { }

	// RVA: 0x72C2488
	protected override object OnDestroy() { }

	// RVA: 0x72C24E0
	private static object .cctor() { }

	// RVA: 0x72C2578
	private object UnityEngine.UI.ICanvasElement.get_transform() { }

}

// Namespace: TMPro
internal static class SetPropertyUtility
{

	// Methods

	// RVA: 0x72DC240
	public static object SetColor(object currentValue, object newValue) { }

	// RVA: -1
	public static object SetStruct(object currentValue, object newValue) { }

	// RVA: -1
	public static object SetClass(object currentValue, object newValue) { }

}

// Namespace: TMPro
public abstract class TMP_InputValidator
{

	// Methods

	// RVA: -1
	public abstract object Validate(object text, object pos, object ch) { }

	// RVA: 0x72DC28C
	protected object .ctor() { }

}

// Namespace: TMPro
public struct TMP_LineInfo
{

	// Fields
	internal object controlCharacterCount; // 0xFFFFFFFFFFFFFFF8
	public object characterCount; // 0xFFFFFFFFFFFFFFFC
	public object visibleCharacterCount; // 0x0
	public object spaceCount; // 0x4
	public object wordCount; // 0x8
	public object firstCharacterIndex; // 0xC
	public object firstVisibleCharacterIndex; // 0x10
	public object lastCharacterIndex; // 0x14
	public object lastVisibleCharacterIndex; // 0x18
	public object length; // 0x1C
	public object lineHeight; // 0x20
	public object ascender; // 0x24
	public object baseline; // 0x28
	public object descender; // 0x2C
	public object maxAdvance; // 0x30
	public object width; // 0x34
	public object marginLeft; // 0x38
	public object marginRight; // 0x3C
	public object alignment; // 0x40
	public object lineExtents; // 0x44
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__3_0(object l) { }

}

// Namespace: TMPro
internal static class TMP_ListPool<T0>
{

	// Fields
	private static readonly object s_ListPool; // 0x0

	// Methods

	// RVA: -1
	public static object Get() { }

	// RVA: -1
	public static object Release(object toRelease) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
private class FallbackMaterial
{

	// Fields
	public object fallbackID; // 0x8
	public object sourceMaterial; // 0x10
	internal object sourceMaterialCRC; // 0x18
	public object fallbackMaterial; // 0x20
	public object count; // 0x28

	// Methods

	// RVA: 0x72DD2E0
	public object .ctor() { }

}

// Namespace: 
private class MaskingMaterial
{

	// Fields
	public object stencilMaterial; // 0x8
	public object count; // 0x10
}

// Namespace: TMPro
public static class TMP_MaterialManager
{

	// Fields
	private static object m_materialList; // 0x0
	private static object m_fallbackMaterials; // 0x8
	private static object m_fallbackMaterialLookup; // 0x10
	private static object m_fallbackCleanupList; // 0x18
	private static object isFallbackListDirty; // 0x20

	// Methods

	// RVA: 0x72DC294
	private static object .cctor() { }

	// RVA: 0x72DC460
	private static object OnPreRender() { }

	// RVA: 0x72DC7BC
	public static object ReleaseStencilMaterial(object stencilMaterial) { }

	// RVA: 0x72DCA6C
	public static object GetMaterialForRendering(object graphic, object baseMaterial) { }

	// RVA: 0x72DCCE0
	internal static object GetFallbackMaterial(object fontAsset, object sourceMaterial, object atlasIndex) { }

	// RVA: 0x72DD2E8
	public static object GetFallbackMaterial(object sourceMaterial, object targetMaterial) { }

	// RVA: 0x72DD7DC
	public static object AddFallbackMaterialReference(object targetMaterial) { }

	// RVA: 0x72DC508
	public static object CleanupFallbackMaterials() { }

	// RVA: 0x72DD98C
	public static object ReleaseFallbackMaterial(object fallbackMaterial) { }

	// RVA: 0x72DD04C
	public static object CopyMaterialPresetProperties(object source, object destination) { }

}

// Namespace: TMPro
public enum VertexSortingOrder
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Reverse;
}

// Namespace: TMPro
public struct TMP_MeshInfo
{

	// Fields
	private static readonly object s_DefaultColor; // 0x0
	private static readonly object s_DefaultNormal; // 0xFFFFFFFFFFFFFFF4
	private static readonly object s_DefaultTangent; // 0x0
	private static readonly object s_DefaultBounds; // 0x10
	public object mesh; // 0xFFFFFFFFFFFFFFF8
	public object vertexCount; // 0x0
	public object vertices; // 0x8
	public object normals; // 0x10
	public object tangents; // 0x18
	public object uvs0; // 0x20
	public object uvs2; // 0x28
	public object colors32; // 0x30
	public object triangles; // 0x38
	public object material; // 0x40

	// Methods

	// RVA: 0x72DDC90
	public object .ctor(object mesh, object size) { }

	// RVA: 0x72DE238
	public object ResizeMeshInfo(object size) { }

	// RVA: 0x72DE6B4
	public object ResizeMeshInfo(object size, object isVolumetric) { }

	// RVA: 0x72DEEA4
	public object Clear(object uploadChanges) { }

	// RVA: 0x72DF040
	public object ClearUnusedVertices() { }

	// RVA: 0x72DF0C0
	public object ClearUnusedVertices(object startIndex, object updateMesh) { }

	// RVA: 0x72DF1B8
	public object SortGeometry(object order) { }

	// RVA: 0x72DF280
	public object SwapVertexData(object src, object dst) { }

	// RVA: 0x72DF760
	private static object .cctor() { }

}

// Namespace: TMPro
internal class TMP_ObjectPool<T0>
{

	// Fields
	private readonly object m_Stack; // 0x0
	private readonly object m_ActionOnGet; // 0x0
	private readonly object m_ActionOnRelease; // 0x0
	private object <countAll>k__BackingField; // 0x0

	// Properties
	public object countAll { get; set; }

	// Methods

	// RVA: -1
	public object get_countAll() { }

	// RVA: -1
	private object set_countAll(object value) { }

	// RVA: -1
	public object .ctor(object actionOnGet, object actionOnRelease) { }

	// RVA: -1
	public object Get() { }

	// RVA: -1
	public object Release(object element) { }

}

// Namespace: TMPro
internal enum MarkupTag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BOLD;
	public const object SLASH_BOLD;
	public const object ITALIC;
	public const object SLASH_ITALIC;
	public const object UNDERLINE;
	public const object SLASH_UNDERLINE;
	public const object STRIKETHROUGH;
	public const object SLASH_STRIKETHROUGH;
	public const object MARK;
	public const object SLASH_MARK;
	public const object SUBSCRIPT;
	public const object SLASH_SUBSCRIPT;
	public const object SUPERSCRIPT;
	public const object SLASH_SUPERSCRIPT;
	public const object COLOR;
	public const object SLASH_COLOR;
	public const object ALPHA;
	public const object A;
	public const object SLASH_A;
	public const object SIZE;
	public const object SLASH_SIZE;
	public const object SPRITE;
	public const object NO_BREAK;
	public const object SLASH_NO_BREAK;
	public const object STYLE;
	public const object SLASH_STYLE;
	public const object FONT;
	public const object SLASH_FONT;
	public const object SLASH_MATERIAL;
	public const object LINK;
	public const object SLASH_LINK;
	public const object FONT_WEIGHT;
	public const object SLASH_FONT_WEIGHT;
	public const object NO_PARSE;
	public const object SLASH_NO_PARSE;
	public const object POSITION;
	public const object SLASH_POSITION;
	public const object VERTICAL_OFFSET;
	public const object SLASH_VERTICAL_OFFSET;
	public const object SPACE;
	public const object SLASH_SPACE;
	public const object PAGE;
	public const object SLASH_PAGE;
	public const object ALIGN;
	public const object SLASH_ALIGN;
	public const object WIDTH;
	public const object SLASH_WIDTH;
	public const object GRADIENT;
	public const object SLASH_GRADIENT;
	public const object CHARACTER_SPACE;
	public const object SLASH_CHARACTER_SPACE;
	public const object MONOSPACE;
	public const object SLASH_MONOSPACE;
	public const object CLASS;
	public const object INDENT;
	public const object SLASH_INDENT;
	public const object LINE_INDENT;
	public const object SLASH_LINE_INDENT;
	public const object MARGIN;
	public const object SLASH_MARGIN;
	public const object MARGIN_LEFT;
	public const object MARGIN_RIGHT;
	public const object LINE_HEIGHT;
	public const object SLASH_LINE_HEIGHT;
	public const object ACTION;
	public const object SLASH_ACTION;
	public const object SCALE;
	public const object SLASH_SCALE;
	public const object ROTATE;
	public const object SLASH_ROTATE;
	public const object LOWERCASE;
	public const object SLASH_LOWERCASE;
	public const object ALLCAPS;
	public const object SLASH_ALLCAPS;
	public const object UPPERCASE;
	public const object SLASH_UPPERCASE;
	public const object SMALLCAPS;
	public const object SLASH_SMALLCAPS;
	public const object LIGA;
	public const object SLASH_LIGA;
	public const object FRAC;
	public const object SLASH_FRAC;
	public const object NAME;
	public const object INDEX;
	public const object TINT;
	public const object ANIM;
	public const object MATERIAL;
	public const object HREF;
	public const object ANGLE;
	public const object RED;
	public const object GREEN;
	public const object BLUE;
	public const object YELLOW;
	public const object ORANGE;
	public const object BLACK;
	public const object WHITE;
	public const object PURPLE;
	public const object BR;
	public const object ZWSP;
	public const object NBSP;
	public const object SHY;
	public const object LEFT;
	public const object RIGHT;
	public const object CENTER;
	public const object JUSTIFIED;
	public const object FLUSH;
	public const object NONE;
	public const object PLUS;
	public const object MINUS;
	public const object PX;
	public const object PLUS_PX;
	public const object MINUS_PX;
	public const object EM;
	public const object PLUS_EM;
	public const object MINUS_EM;
	public const object PCT;
	public const object PLUS_PCT;
	public const object MINUS_PCT;
	public const object PERCENTAGE;
	public const object PLUS_PERCENTAGE;
	public const object MINUS_PERCENTAGE;
	public const object TRUE;
	public const object FALSE;
	public const object INVALID;
	public const object NORMAL;
	public const object DEFAULT;
}

// Namespace: TMPro
public enum TagValueType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NumericalValue;
	public const object StringValue;
	public const object ColorValue;
}

// Namespace: TMPro
public enum TagUnitType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Pixels;
	public const object FontUnits;
	public const object Percentage;
}

// Namespace: TMPro
public class TMP_ScrollbarEventHandler
{

	// Fields
	public object isSelected; // 0x18

	// Methods

	// RVA: 0x72DF7D8
	public object OnPointerClick(object eventData) { }

	// RVA: 0x72DF86C
	public object OnSelect(object eventData) { }

	// RVA: 0x72DF8F0
	public object OnDeselect(object eventData) { }

	// RVA: 0x72DF970
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_SelectionCaret
{

	// Methods

	// RVA: 0x72DF978
	public override object Cull(object clipRect, object validRect) { }

	// RVA: 0x72DFA60
	protected override object UpdateGeometry() { }

	// RVA: 0x72DFA64
	public object .ctor() { }

}

// Namespace: 
public class LineBreakingTable
{

	// Fields
	public object leadingCharacters; // 0x8
	public object followingCharacters; // 0x10

	// Methods

	// RVA: 0x72E07A0
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_Settings
{

	// Fields
	private static object s_Instance; // 0x0
	private object m_enableWordWrapping; // 0x10
	private object m_enableKerning; // 0x11
	private object m_enableExtraPadding; // 0x12
	private object m_enableTintAllSprites; // 0x13
	private object m_enableParseEscapeCharacters; // 0x14
	private object m_EnableRaycastTarget; // 0x15
	private object m_GetFontFeaturesAtRuntime; // 0x16
	private object m_missingGlyphCharacter; // 0x18
	private object m_warningsDisabled; // 0x1C
	private object m_defaultFontAsset; // 0x20
	private object m_defaultFontAssetPath; // 0x28
	private object m_defaultFontSize; // 0x30
	private object m_defaultAutoSizeMinRatio; // 0x34
	private object m_defaultAutoSizeMaxRatio; // 0x38
	private object m_defaultTextMeshProTextContainerSize; // 0x3C
	private object m_defaultTextMeshProUITextContainerSize; // 0x44
	private object m_autoSizeTextContainer; // 0x4C
	private object m_IsTextObjectScaleStatic; // 0x4D
	private object m_fallbackFontAssets; // 0x50
	private object m_matchMaterialPreset; // 0x58
	private object m_defaultSpriteAsset; // 0x60
	private object m_defaultSpriteAssetPath; // 0x68
	private object m_enableEmojiSupport; // 0x70
	private object m_MissingCharacterSpriteUnicode; // 0x74
	private object m_defaultColorGradientPresetsPath; // 0x78
	private object m_defaultStyleSheet; // 0x80
	private object m_StyleSheetsResourcePath; // 0x88
	private object m_leadingCharacters; // 0x90
	private object m_followingCharacters; // 0x98
	private object m_linebreakingRules; // 0xA0
	private object m_UseModernHangulLineBreakingRules; // 0xA8

	// Properties
	public static object version { get; }
	public static object enableWordWrapping { get; }
	public static object enableKerning { get; }
	public static object enableExtraPadding { get; }
	public static object enableTintAllSprites { get; }
	public static object enableParseEscapeCharacters { get; }
	public static object enableRaycastTarget { get; }
	public static object getFontFeaturesAtRuntime { get; }
	public static object missingGlyphCharacter { get; set; }
	public static object warningsDisabled { get; }
	public static object defaultFontAsset { get; }
	public static object defaultFontAssetPath { get; }
	public static object defaultFontSize { get; }
	public static object defaultTextAutoSizingMinRatio { get; }
	public static object defaultTextAutoSizingMaxRatio { get; }
	public static object defaultTextMeshProTextContainerSize { get; }
	public static object defaultTextMeshProUITextContainerSize { get; }
	public static object autoSizeTextContainer { get; }
	public static object isTextObjectScaleStatic { get; set; }
	public static object fallbackFontAssets { get; }
	public static object matchMaterialPreset { get; }
	public static object defaultSpriteAsset { get; }
	public static object defaultSpriteAssetPath { get; }
	public static object enableEmojiSupport { get; set; }
	public static object missingCharacterSpriteUnicode { get; set; }
	public static object defaultColorGradientPresetsPath { get; }
	public static object defaultStyleSheet { get; }
	public static object styleSheetsResourcePath { get; }
	public static object leadingCharacters { get; }
	public static object followingCharacters { get; }
	public static object linebreakingRules { get; }
	public static object useModernHangulLineBreakingRules { get; set; }
	public static object instance { get; }

	// Methods

	// RVA: 0x72DFA6C
	public static object get_version() { }

	// RVA: 0x72DFAB0
	public static object get_enableWordWrapping() { }

	// RVA: 0x72DFBEC
	public static object get_enableKerning() { }

	// RVA: 0x72DFC14
	public static object get_enableExtraPadding() { }

	// RVA: 0x72DFC3C
	public static object get_enableTintAllSprites() { }

	// RVA: 0x72DFC64
	public static object get_enableParseEscapeCharacters() { }

	// RVA: 0x72DFC8C
	public static object get_enableRaycastTarget() { }

	// RVA: 0x72DFCB4
	public static object get_getFontFeaturesAtRuntime() { }

	// RVA: 0x72DFCDC
	public static object get_missingGlyphCharacter() { }

	// RVA: 0x72DFD04
	public static object set_missingGlyphCharacter(object value) { }

	// RVA: 0x72DFD38
	public static object get_warningsDisabled() { }

	// RVA: 0x72DFD60
	public static object get_defaultFontAsset() { }

	// RVA: 0x72DFD88
	public static object get_defaultFontAssetPath() { }

	// RVA: 0x72DFDB0
	public static object get_defaultFontSize() { }

	// RVA: 0x72DFDD8
	public static object get_defaultTextAutoSizingMinRatio() { }

	// RVA: 0x72DFE00
	public static object get_defaultTextAutoSizingMaxRatio() { }

	// RVA: 0x72DFE28
	public static object get_defaultTextMeshProTextContainerSize() { }

	// RVA: 0x72DFE50
	public static object get_defaultTextMeshProUITextContainerSize() { }

	// RVA: 0x72DFE78
	public static object get_autoSizeTextContainer() { }

	// RVA: 0x72DFEA0
	public static object get_isTextObjectScaleStatic() { }

	// RVA: 0x72DFEC8
	public static object set_isTextObjectScaleStatic(object value) { }

	// RVA: 0x72DFEFC
	public static object get_fallbackFontAssets() { }

	// RVA: 0x72DFF24
	public static object get_matchMaterialPreset() { }

	// RVA: 0x72DFF4C
	public static object get_defaultSpriteAsset() { }

	// RVA: 0x72DFF74
	public static object get_defaultSpriteAssetPath() { }

	// RVA: 0x72DFF9C
	public static object get_enableEmojiSupport() { }

	// RVA: 0x72DFFC4
	public static object set_enableEmojiSupport(object value) { }

	// RVA: 0x72DFFF8
	public static object get_missingCharacterSpriteUnicode() { }

	// RVA: 0x72E0020
	public static object set_missingCharacterSpriteUnicode(object value) { }

	// RVA: 0x72E0054
	public static object get_defaultColorGradientPresetsPath() { }

	// RVA: 0x72E007C
	public static object get_defaultStyleSheet() { }

	// RVA: 0x72E00A4
	public static object get_styleSheetsResourcePath() { }

	// RVA: 0x72E00CC
	public static object get_leadingCharacters() { }

	// RVA: 0x72E00F4
	public static object get_followingCharacters() { }

	// RVA: 0x72E011C
	public static object get_linebreakingRules() { }

	// RVA: 0x72E02E4
	public static object get_useModernHangulLineBreakingRules() { }

	// RVA: 0x72E030C
	public static object set_useModernHangulLineBreakingRules(object value) { }

	// RVA: 0x72DFAD8
	public static object get_instance() { }

	// RVA: 0x72E0340
	public static object LoadDefaultSettings() { }

	// RVA: 0x72E04B4
	public static object GetSettings() { }

	// RVA: 0x72E0554
	public static object GetFontAsset() { }

	// RVA: 0x72E0618
	public static object GetSpriteAsset() { }

	// RVA: 0x72E06DC
	public static object GetStyleSheet() { }

	// RVA: 0x72E0164
	public static object LoadLinebreakingRules() { }

	// RVA: 0x72E07A8
	private static object GetCharacters(object file) { }

	// RVA: 0x72E0908
	public object .ctor() { }

}

// Namespace: TMPro
public static class ShaderUtilities
{

	// Fields
	public static object ID_MainTex; // 0x0
	public static object ID_FaceTex; // 0x4
	public static object ID_FaceColor; // 0x8
	public static object ID_FaceDilate; // 0xC
	public static object ID_Shininess; // 0x10
	public static object ID_UnderlayColor; // 0x14
	public static object ID_UnderlayOffsetX; // 0x18
	public static object ID_UnderlayOffsetY; // 0x1C
	public static object ID_UnderlayDilate; // 0x20
	public static object ID_UnderlaySoftness; // 0x24
	public static object ID_WeightNormal; // 0x28
	public static object ID_WeightBold; // 0x2C
	public static object ID_OutlineTex; // 0x30
	public static object ID_OutlineWidth; // 0x34
	public static object ID_OutlineSoftness; // 0x38
	public static object ID_OutlineColor; // 0x3C
	public static object ID_Outline2Color; // 0x40
	public static object ID_Outline2Width; // 0x44
	public static object ID_Padding; // 0x48
	public static object ID_GradientScale; // 0x4C
	public static object ID_ScaleX; // 0x50
	public static object ID_ScaleY; // 0x54
	public static object ID_PerspectiveFilter; // 0x58
	public static object ID_Sharpness; // 0x5C
	public static object ID_TextureWidth; // 0x60
	public static object ID_TextureHeight; // 0x64
	public static object ID_BevelAmount; // 0x68
	public static object ID_GlowColor; // 0x6C
	public static object ID_GlowOffset; // 0x70
	public static object ID_GlowPower; // 0x74
	public static object ID_GlowOuter; // 0x78
	public static object ID_GlowInner; // 0x7C
	public static object ID_LightAngle; // 0x80
	public static object ID_EnvMap; // 0x84
	public static object ID_EnvMatrix; // 0x88
	public static object ID_EnvMatrixRotation; // 0x8C
	public static object ID_MaskCoord; // 0x90
	public static object ID_ClipRect; // 0x94
	public static object ID_MaskSoftnessX; // 0x98
	public static object ID_MaskSoftnessY; // 0x9C
	public static object ID_VertexOffsetX; // 0xA0
	public static object ID_VertexOffsetY; // 0xA4
	public static object ID_UseClipRect; // 0xA8
	public static object ID_StencilID; // 0xAC
	public static object ID_StencilOp; // 0xB0
	public static object ID_StencilComp; // 0xB4
	public static object ID_StencilReadMask; // 0xB8
	public static object ID_StencilWriteMask; // 0xBC
	public static object ID_ShaderFlags; // 0xC0
	public static object ID_ScaleRatio_A; // 0xC4
	public static object ID_ScaleRatio_B; // 0xC8
	public static object ID_ScaleRatio_C; // 0xCC
	public static object Keyword_Bevel; // 0xD0
	public static object Keyword_Glow; // 0xD8
	public static object Keyword_Underlay; // 0xE0
	public static object Keyword_Ratios; // 0xE8
	public static object Keyword_MASK_SOFT; // 0xF0
	public static object Keyword_MASK_HARD; // 0xF8
	public static object Keyword_MASK_TEX; // 0x100
	public static object Keyword_Outline; // 0x108
	public static object ShaderTag_ZTestMode; // 0x110
	public static object ShaderTag_CullMode; // 0x118
	private static object m_clamp; // 0x120
	public static object isInitialized; // 0x124
	private static object k_ShaderRef_MobileSDF; // 0x128
	private static object k_ShaderRef_MobileBitmap; // 0x130

	// Properties
	internal static object ShaderRef_MobileSDF { get; }
	internal static object ShaderRef_MobileBitmap { get; }

	// Methods

	// RVA: 0x72E0918
	internal static object get_ShaderRef_MobileSDF() { }

	// RVA: 0x72E0A70
	internal static object get_ShaderRef_MobileBitmap() { }

	// RVA: 0x72E0BC8
	private static object .cctor() { }

	// RVA: 0x72E0D50
	public static object GetShaderPropertyIDs() { }

	// RVA: 0x72E182C
	public static object UpdateShaderRatios(object mat) { }

	// RVA: 0x72E1CE8
	public static object IsMaskingEnabled(object material) { }

	// RVA: 0x72E1EE4
	public static object GetPadding(object material, object enableExtraPadding, object isBold) { }

}

// Namespace: TMPro
public class TMP_Sprite
{

	// Fields
	public object name; // 0x30
	public object hashCode; // 0x38
	public object unicode; // 0x3C
	public object pivot; // 0x40
	public object sprite; // 0x48

	// Methods

	// RVA: 0x72E2648
	public object .ctor() { }

}

// Namespace: 
private sealed class <DoSpriteAnimationInternal>d__7
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object start; // 0x20
	public object end; // 0x24
	public object spriteAsset; // 0x28
	public object currentCharacter; // 0x30
	public object framerate; // 0x34
	private object <currentFrame>5__2; // 0x38
	private object <charInfo>5__3; // 0x40
	private object <materialIndex>5__4; // 0x1B8
	private object <vertexIndex>5__5; // 0x1BC
	private object <meshInfo>5__6; // 0x1C0
	private object <baseSpriteScale>5__7; // 0x210
	private object <elapsedTime>5__8; // 0x214
	private object <targetTime>5__9; // 0x218

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x72E28FC
	public object .ctor(object <>1__state) { }

	// RVA: 0x72E29AC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x72E29B0
	private object MoveNext() { }

	// RVA: 0x72E35CC
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x72E35D4
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x72E3614
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: TMPro
public class TMP_SpriteAnimator
{

	// Fields
	private object m_animations; // 0x18
	private object m_TextComponent; // 0x20

	// Methods

	// RVA: 0x72E2658
	private object Awake() { }

	// RVA: 0x72E26B4
	private object OnEnable() { }

	// RVA: 0x72E26B8
	private object OnDisable() { }

	// RVA: 0x72E26BC
	public object StopAllAnimations() { }

	// RVA: 0x72E2724
	public object DoSpriteAnimation(object currentCharacter, object spriteAsset, object start, object end, object framerate) { }

	// RVA: 0x72E2860
	private object DoSpriteAnimationInternal(object currentCharacter, object spriteAsset, object start, object end, object framerate) { }

	// RVA: 0x72E2928
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__40_0; // 0x8
	public static object <>9__41_0; // 0x10

	// Methods

	// RVA: 0x72E5930
	private static object .cctor() { }

	// RVA: 0x72E5990
	public object .ctor() { }

	// RVA: 0x72E5998
	internal object <SortGlyphTable>b__40_0(object item) { }

	// RVA: 0x72E59BC
	internal object <SortCharacterTable>b__41_0(object c) { }

}

// Namespace: TMPro
public class TMP_SpriteAsset
{

	// Fields
	internal object m_NameLookup; // 0x28
	internal object m_GlyphIndexLookup; // 0x30
	private object m_Version; // 0x38
	internal object m_FaceInfo; // 0x40
	public object spriteSheet; // 0xA0
	private object m_SpriteCharacterTable; // 0xA8
	internal object m_SpriteCharacterLookup; // 0xB0
	private object m_SpriteGlyphTable; // 0xB8
	internal object m_SpriteGlyphLookup; // 0xC0
	public object spriteInfoList; // 0xC8
	public object fallbackSpriteAssets; // 0xD0
	internal object m_IsSpriteAssetLookupTablesDirty; // 0xD8
	private static object k_searchedSpriteAssets; // 0x0

	// Properties
	public object version { get; set; }
	public object faceInfo { get; set; }
	public object spriteCharacterTable { get; set; }
	public object spriteCharacterLookupTable { get; set; }
	public object spriteGlyphTable { get; set; }

	// Methods

	// RVA: 0x72E361C
	public object get_version() { }

	// RVA: 0x72E3624
	internal object set_version(object value) { }

	// RVA: 0x72E362C
	public object get_faceInfo() { }

	// RVA: 0x72E3648
	internal object set_faceInfo(object value) { }

	// RVA: 0x72E358C
	public object get_spriteCharacterTable() { }

	// RVA: 0x72E3C58
	internal object set_spriteCharacterTable(object value) { }

	// RVA: 0x72E3C60
	public object get_spriteCharacterLookupTable() { }

	// RVA: 0x72E3C9C
	internal object set_spriteCharacterLookupTable(object value) { }

	// RVA: 0x72E3CA4
	public object get_spriteGlyphTable() { }

	// RVA: 0x72E3CAC
	internal object set_spriteGlyphTable(object value) { }

	// RVA: 0x72E3CB4
	private object Awake() { }

	// RVA: 0x72E4330
	private object GetDefaultSpriteMaterial() { }

	// RVA: 0x72E3654
	public object UpdateLookupTables() { }

	// RVA: 0x72E4420
	public object GetSpriteIndexFromHashcode(object hashCode) { }

	// RVA: 0x72E44BC
	public object GetSpriteIndexFromUnicode(object unicode) { }

	// RVA: 0x72E4580
	public object GetSpriteIndexFromName(object name) { }

	// RVA: 0x72E4770
	public static object SearchForSpriteByUnicode(object spriteAsset, object unicode, object includeFallbacks, object spriteIndex) { }

	// RVA: 0x72E4A60
	private static object SearchForSpriteByUnicodeInternal(object spriteAssets, object unicode, object includeFallbacks, object spriteIndex) { }

	// RVA: 0x72E4C34
	private static object SearchForSpriteByUnicodeInternal(object spriteAsset, object unicode, object includeFallbacks, object spriteIndex) { }

	// RVA: 0x72E4D70
	public static object SearchForSpriteByHashCode(object spriteAsset, object hashCode, object includeFallbacks, object spriteIndex) { }

	// RVA: 0x72E51B4
	private static object SearchForSpriteByHashCodeInternal(object spriteAssets, object hashCode, object searchFallbacks, object spriteIndex) { }

	// RVA: 0x72E5388
	private static object SearchForSpriteByHashCodeInternal(object spriteAsset, object hashCode, object searchFallbacks, object spriteIndex) { }

	// RVA: 0x72E54A4
	public object SortGlyphTable() { }

	// RVA: 0x72E55F0
	internal object SortCharacterTable() { }

	// RVA: 0x72E5740
	internal object SortGlyphAndCharacterTables() { }

	// RVA: 0x72E3D74
	private object UpgradeSpriteAsset() { }

	// RVA: 0x72E5868
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_SpriteCharacter
{

	// Fields
	private object m_Name; // 0x28
	private object m_HashCode; // 0x30

	// Properties
	public object name { set; }
	public object hashCode { get; }

	// Methods

	// RVA: 0x72E5798
	public object set_name(object value) { }

	// RVA: 0x72E5A68
	public object get_hashCode() { }

	// RVA: 0x72E576C
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_SpriteGlyph
{

	// Fields
	public object sprite; // 0x40

	// Methods

	// RVA: 0x72E5764
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_Style
{

	// Fields
	internal static object k_NormalStyle; // 0x0
	private object m_Name; // 0x8
	private object m_HashCode; // 0x10
	private object m_OpeningDefinition; // 0x18
	private object m_ClosingDefinition; // 0x20
	private object m_OpeningTagArray; // 0x28
	private object m_ClosingTagArray; // 0x30
	internal object m_OpeningTagUnicodeArray; // 0x38
	internal object m_ClosingTagUnicodeArray; // 0x40

	// Properties
	public static object NormalStyle { get; }
	public object hashCode { get; }
	public object styleOpeningTagArray { get; }
	public object styleClosingTagArray { get; }

	// Methods

	// RVA: 0x72E5A78
	public static object get_NormalStyle() { }

	// RVA: 0x72E5C44
	public object get_hashCode() { }

	// RVA: 0x72E5C4C
	public object get_styleOpeningTagArray() { }

	// RVA: 0x72E5C54
	public object get_styleClosingTagArray() { }

	// RVA: 0x72E5BB0
	internal object .ctor(object styleName, object styleOpeningDefinition, object styleClosingDefinition) { }

	// RVA: 0x72E5D94
	public object RefreshStyle() { }

}

// Namespace: TMPro
public class TMP_StyleSheet
{

	// Fields
	private object m_StyleList; // 0x10
	private object m_StyleLookupDictionary; // 0x18

	// Properties
	internal object styles { get; }

	// Methods

	// RVA: 0x72E6018
	internal object get_styles() { }

	// RVA: 0x72E6020
	private object Reset() { }

	// RVA: 0x72E6464
	public object GetStyle(object hashCode) { }

	// RVA: 0x72E6500
	public object GetStyle(object name) { }

	// RVA: 0x72E65FC
	public object RefreshStyles() { }

	// RVA: 0x72E6024
	private object LoadStyleDictionaryInternal() { }

	// RVA: 0x72E6600
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_SubMesh
{

	// Fields
	private object m_fontAsset; // 0x18
	private object m_spriteAsset; // 0x20
	private object m_material; // 0x28
	private object m_sharedMaterial; // 0x30
	private object m_fallbackMaterial; // 0x38
	private object m_fallbackSourceMaterial; // 0x40
	private object m_isDefaultMaterial; // 0x48
	private object m_padding; // 0x4C
	private object m_renderer; // 0x50
	private object m_meshFilter; // 0x58
	private object m_mesh; // 0x60
	private object m_TextComponent; // 0x68
	private object m_isRegisteredForEvents; // 0x70

	// Properties
	public object fontAsset { get; set; }
	public object spriteAsset { get; set; }
	public object material { get; set; }
	public object sharedMaterial { get; set; }
	public object fallbackMaterial { get; set; }
	public object fallbackSourceMaterial { get; set; }
	public object isDefaultMaterial { get; set; }
	public object padding { get; set; }
	public object renderer { get; }
	public object meshFilter { get; }
	public object mesh { get; set; }
	public object textComponent { get; }

	// Methods

	// RVA: 0x72E6684
	public object get_fontAsset() { }

	// RVA: 0x72E668C
	public object set_fontAsset(object value) { }

	// RVA: 0x72E6694
	public object get_spriteAsset() { }

	// RVA: 0x72E669C
	public object set_spriteAsset(object value) { }

	// RVA: 0x72E66A4
	public object get_material() { }

	// RVA: 0x72E68AC
	public object set_material(object value) { }

	// RVA: 0x72E6B30
	public object get_sharedMaterial() { }

	// RVA: 0x72E6B38
	public object set_sharedMaterial(object value) { }

	// RVA: 0x72E6C70
	public object get_fallbackMaterial() { }

	// RVA: 0x72E6C78
	public object set_fallbackMaterial(object value) { }

	// RVA: 0x72E6E40
	public object get_fallbackSourceMaterial() { }

	// RVA: 0x72E6E48
	public object set_fallbackSourceMaterial(object value) { }

	// RVA: 0x72E6E50
	public object get_isDefaultMaterial() { }

	// RVA: 0x72E6E58
	public object set_isDefaultMaterial(object value) { }

	// RVA: 0x72E6E60
	public object get_padding() { }

	// RVA: 0x72E6E68
	public object set_padding(object value) { }

	// RVA: 0x72E6E70
	public object get_renderer() { }

	// RVA: 0x72E6F40
	public object get_meshFilter() { }

	// RVA: 0x72E70AC
	public object get_mesh() { }

	// RVA: 0x72E71A8
	public object set_mesh(object value) { }

	// RVA: 0x72E71B0
	public object get_textComponent() { }

	// RVA: 0x72E7280
	public static object AddSubTextObject(object textComponent, object materialReference) { }

	// RVA: 0x72E7878
	private object OnEnable() { }

	// RVA: 0x72E7A18
	private object OnDisable() { }

	// RVA: 0x72E7B04
	private object OnDestroy() { }

	// RVA: 0x72E7CF8
	public object DestroySelf() { }

	// RVA: 0x72E66AC
	private object GetMaterial(object mat) { }

	// RVA: 0x72E7DA4
	private object CreateMaterialInstance(object source) { }

	// RVA: 0x72E7E84
	private object GetSharedMaterial() { }

	// RVA: 0x72E6BD4
	private object SetSharedMaterial(object mat) { }

	// RVA: 0x72E69A4
	public object GetPaddingForMaterial() { }

	// RVA: 0x72E7F5C
	public object UpdateMeshPadding(object isExtraPadding, object isUsingBold) { }

	// RVA: 0x72E6A38
	public object SetVerticesDirty() { }

	// RVA: 0x72E6B2C
	public object SetMaterialDirty() { }

	// RVA: 0x72E7FD4
	protected object UpdateMaterial() { }

	// RVA: 0x72E8314
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_SubMeshUI
{

	// Fields
	private object m_fontAsset; // 0xD0
	private object m_spriteAsset; // 0xD8
	private object m_material; // 0xE0
	private object m_sharedMaterial; // 0xE8
	private object m_fallbackMaterial; // 0xF0
	private object m_fallbackSourceMaterial; // 0xF8
	private object m_isDefaultMaterial; // 0x100
	private object m_padding; // 0x104
	private object m_mesh; // 0x108
	private object m_TextComponent; // 0x110
	private object m_isRegisteredForEvents; // 0x118
	private object m_materialDirty; // 0x119
	private object m_materialReferenceIndex; // 0x11C
	private object m_RootCanvasTransform; // 0x120

	// Properties
	public object fontAsset { get; set; }
	public object spriteAsset { get; set; }
	public override object mainTexture { get; }
	public override object material { get; set; }
	public object sharedMaterial { get; set; }
	public object fallbackMaterial { get; set; }
	public object fallbackSourceMaterial { get; set; }
	public override object materialForRendering { get; }
	public object isDefaultMaterial { get; set; }
	public object padding { get; set; }
	public object mesh { get; set; }
	public object textComponent { get; }

	// Methods

	// RVA: 0x72E831C
	public object get_fontAsset() { }

	// RVA: 0x72E8324
	public object set_fontAsset(object value) { }

	// RVA: 0x72E832C
	public object get_spriteAsset() { }

	// RVA: 0x72E8334
	public object set_spriteAsset(object value) { }

	// RVA: 0x72E833C
	public override object get_mainTexture() { }

	// RVA: 0x72E8434
	public override object get_material() { }

	// RVA: 0x72E860C
	public override object set_material(object value) { }

	// RVA: 0x72E8850
	public object get_sharedMaterial() { }

	// RVA: 0x72E8858
	public object set_sharedMaterial(object value) { }

	// RVA: 0x72E891C
	public object get_fallbackMaterial() { }

	// RVA: 0x72E8924
	public object set_fallbackMaterial(object value) { }

	// RVA: 0x72E8A80
	public object get_fallbackSourceMaterial() { }

	// RVA: 0x72E8A88
	public object set_fallbackSourceMaterial(object value) { }

	// RVA: 0x72E8A90
	public override object get_materialForRendering() { }

	// RVA: 0x72E8B20
	public object get_isDefaultMaterial() { }

	// RVA: 0x72E8B28
	public object set_isDefaultMaterial(object value) { }

	// RVA: 0x72E8B30
	public object get_padding() { }

	// RVA: 0x72E8B38
	public object set_padding(object value) { }

	// RVA: 0x72E8B40
	public object get_mesh() { }

	// RVA: 0x72E8C3C
	public object set_mesh(object value) { }

	// RVA: 0x72E8C44
	public object get_textComponent() { }

	// RVA: 0x72E8D14
	public static object AddSubTextObject(object textComponent, object materialReference) { }

	// RVA: 0x72E91D4
	protected override object OnEnable() { }

	// RVA: 0x72E92A8
	protected override object OnDisable() { }

	// RVA: 0x72E9380
	protected override object OnDestroy() { }

	// RVA: 0x72E95F8
	protected override object OnTransformParentChanged() { }

	// RVA: 0x72E969C
	public override object GetModifiedMaterial(object baseMaterial) { }

	// RVA: 0x72E87BC
	public object GetPaddingForMaterial() { }

	// RVA: 0x72E97C0
	public object GetPaddingForMaterial(object mat) { }

	// RVA: 0x72E9844
	public object UpdateMeshPadding(object isExtraPadding, object isUsingBold) { }

	// RVA: 0x72E98BC
	public override object SetAllDirty() { }

	// RVA: 0x72E98C0
	public override object SetVerticesDirty() { }

	// RVA: 0x72E99CC
	public override object SetLayoutDirty() { }

	// RVA: 0x72E99D0
	public override object SetMaterialDirty() { }

	// RVA: 0x72E9A3C
	public object SetPivotDirty() { }

	// RVA: 0x72E9AE8
	private object GetRootCanvasTransform() { }

	// RVA: 0x72E9BE4
	public override object Cull(object clipRect, object validRect) { }

	// RVA: 0x72E9BE8
	protected override object UpdateGeometry() { }

	// RVA: 0x72E9BEC
	public override object Rebuild(object update) { }

	// RVA: 0x72E9C50
	public object RefreshMaterial() { }

	// RVA: 0x72E9C94
	protected override object UpdateMaterial() { }

	// RVA: 0x72E9F4C
	public override object RecalculateClipping() { }

	// RVA: 0x72E9F54
	private object GetMaterial() { }

	// RVA: 0x72E843C
	private object GetMaterial(object mat) { }

	// RVA: 0x72E9F5C
	private object CreateMaterialInstance(object source) { }

	// RVA: 0x72EA03C
	private object GetSharedMaterial() { }

	// RVA: 0x72E885C
	private object SetSharedMaterial(object mat) { }

	// RVA: 0x72EA068
	public object .ctor() { }

}

// Namespace: TMPro
public enum TextAlignmentOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TopLeft;
	public const object Top;
	public const object TopRight;
	public const object TopJustified;
	public const object TopFlush;
	public const object TopGeoAligned;
	public const object Left;
	public const object Center;
	public const object Right;
	public const object Justified;
	public const object Flush;
	public const object CenterGeoAligned;
	public const object BottomLeft;
	public const object Bottom;
	public const object BottomRight;
	public const object BottomJustified;
	public const object BottomFlush;
	public const object BottomGeoAligned;
	public const object BaselineLeft;
	public const object Baseline;
	public const object BaselineRight;
	public const object BaselineJustified;
	public const object BaselineFlush;
	public const object BaselineGeoAligned;
	public const object MidlineLeft;
	public const object Midline;
	public const object MidlineRight;
	public const object MidlineJustified;
	public const object MidlineFlush;
	public const object MidlineGeoAligned;
	public const object CaplineLeft;
	public const object Capline;
	public const object CaplineRight;
	public const object CaplineJustified;
	public const object CaplineFlush;
	public const object CaplineGeoAligned;
	public const object Converted;
}

// Namespace: TMPro
public enum HorizontalAlignmentOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Center;
	public const object Right;
	public const object Justified;
	public const object Flush;
	public const object Geometry;
}

// Namespace: TMPro
public enum VerticalAlignmentOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Top;
	public const object Middle;
	public const object Bottom;
	public const object Baseline;
	public const object Geometry;
	public const object Capline;
}

// Namespace: TMPro
public enum TextRenderFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DontRender;
	public const object Render;
}

// Namespace: TMPro
public enum TMP_TextElementType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Character;
	public const object Sprite;
}

// Namespace: TMPro
public enum MaskingTypes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MaskOff;
	public const object MaskHard;
	public const object MaskSoft;
}

// Namespace: TMPro
public enum TextOverflowModes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Overflow;
	public const object Ellipsis;
	public const object Masking;
	public const object Truncate;
	public const object ScrollRect;
	public const object Page;
	public const object Linked;
}

// Namespace: TMPro
public enum TextureMappingOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Character;
	public const object Line;
	public const object Paragraph;
	public const object MatchAspect;
}

// Namespace: TMPro
public enum FontStyles
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Bold;
	public const object Italic;
	public const object Underline;
	public const object LowerCase;
	public const object UpperCase;
	public const object SmallCaps;
	public const object Strikethrough;
	public const object Superscript;
	public const object Subscript;
	public const object Highlight;
}

// Namespace: TMPro
public enum FontWeight
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Thin;
	public const object ExtraLight;
	public const object Light;
	public const object Regular;
	public const object Medium;
	public const object SemiBold;
	public const object Bold;
	public const object Heavy;
	public const object Black;
}

// Namespace: 
protected struct CharacterSubstitution
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object unicode; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x72EA070
	public object .ctor(object index, object unicode) { }

}

// Namespace: 
internal enum TextInputSources
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TextInputBox;
	public const object SetText;
	public const object SetTextArray;
	public const object TextString;
}

// Namespace: 
internal struct UnicodeChar
{

	// Fields
	public object unicode; // 0xFFFFFFFFFFFFFFF8
	public object stringIndex; // 0xFFFFFFFFFFFFFFFC
	public object length; // 0x0
}

// Namespace: 
protected struct SpecialCharacter
{

	// Fields
	public object character; // 0xFFFFFFFFFFFFFFF8
	public object fontAsset; // 0x0
	public object material; // 0x8
	public object materialIndex; // 0x10

	// Methods

	// RVA: 0x72EA0BC
	public object .ctor(object character, object materialIndex) { }

}

// Namespace: 
private struct TextBackingContainer
{

	// Fields
	private object m_Array; // 0xFFFFFFFFFFFFFFF8
	private object m_Count; // 0x0

	// Properties
	public object Capacity { get; }
	public object Count { get; set; }
	public object Item { get; set; }

	// Methods

	// RVA: 0x72EA2E0
	public object get_Capacity() { }

	// RVA: 0x72EA328
	public object get_Count() { }

	// RVA: 0x72EA338
	public object set_Count(object value) { }

	// RVA: 0x72EA348
	public object get_Item(object index) { }

	// RVA: 0x72EA3C0
	public object set_Item(object index, object value) { }

	// RVA: 0x72EA4F4
	public object .ctor(object size) { }

	// RVA: 0x72EA484
	public object Resize(object size) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__624_0; // 0x8

	// Methods

	// RVA: 0x72EA624
	private static object .cctor() { }

	// RVA: 0x72EA684
	public object .ctor() { }

	// RVA: 0x72EA68C
	internal object <.ctor>b__624_0(object <p0>) { }

}

// Namespace: TMPro
public abstract class TMP_Text
{

	// Fields
	protected object m_text; // 0xD0
	private object m_IsTextBackingStringDirty; // 0xD8
	protected object m_TextPreprocessor; // 0xE0
	protected object m_isRightToLeft; // 0xE8
	protected object m_fontAsset; // 0xF0
	protected object m_currentFontAsset; // 0xF8
	protected object m_isSDFShader; // 0x100
	protected object m_sharedMaterial; // 0x108
	protected object m_currentMaterial; // 0x110
	protected static object m_materialReferences; // 0x0
	protected static object m_materialReferenceIndexLookup; // 0x8
	protected static object m_materialReferenceStack; // 0x10
	protected object m_currentMaterialIndex; // 0x118
	protected object m_fontSharedMaterials; // 0x120
	protected object m_fontMaterial; // 0x128
	protected object m_fontMaterials; // 0x130
	protected object m_isMaterialDirty; // 0x138
	protected object m_fontColor32; // 0x13C
	protected object m_fontColor; // 0x140
	protected static object s_colorWhite; // 0x68
	protected object m_underlineColor; // 0x150
	protected object m_strikethroughColor; // 0x154
	protected object m_enableVertexGradient; // 0x158
	protected object m_colorMode; // 0x15C
	protected object m_fontColorGradient; // 0x160
	protected object m_fontColorGradientPreset; // 0x1A0
	protected object m_spriteAsset; // 0x1A8
	protected object m_tintAllSprites; // 0x1B0
	protected object m_tintSprite; // 0x1B1
	protected object m_spriteColor; // 0x1B4
	protected object m_StyleSheet; // 0x1B8
	internal object m_TextStyle; // 0x1C0
	protected object m_TextStyleHashCode; // 0x1C8
	protected object m_overrideHtmlColors; // 0x1CC
	protected object m_faceColor; // 0x1D0
	protected object m_outlineColor; // 0x1D4
	protected object m_outlineWidth; // 0x1D8
	protected object m_fontSize; // 0x1DC
	protected object m_currentFontSize; // 0x1E0
	protected object m_fontSizeBase; // 0x1E4
	protected object m_sizeStack; // 0x1E8
	protected object m_fontWeight; // 0x208
	protected object m_FontWeightInternal; // 0x20C
	protected object m_FontWeightStack; // 0x210
	protected object m_enableAutoSizing; // 0x230
	protected object m_maxFontSize; // 0x234
	protected object m_minFontSize; // 0x238
	protected object m_AutoSizeIterationCount; // 0x23C
	protected object m_AutoSizeMaxIterationCount; // 0x240
	protected object m_IsAutoSizePointSizeSet; // 0x244
	protected object m_fontSizeMin; // 0x248
	protected object m_fontSizeMax; // 0x24C
	protected object m_fontStyle; // 0x250
	protected object m_FontStyleInternal; // 0x254
	protected object m_fontStyleStack; // 0x258
	protected object m_isUsingBold; // 0x262
	protected object m_HorizontalAlignment; // 0x264
	protected object m_VerticalAlignment; // 0x268
	protected object m_textAlignment; // 0x26C
	protected object m_lineJustification; // 0x270
	protected object m_lineJustificationStack; // 0x278
	protected object m_textContainerLocalCorners; // 0x298
	protected object m_characterSpacing; // 0x2A0
	protected object m_cSpacing; // 0x2A4
	protected object m_monoSpacing; // 0x2A8
	protected object m_wordSpacing; // 0x2AC
	protected object m_lineSpacing; // 0x2B0
	protected object m_lineSpacingDelta; // 0x2B4
	protected object m_lineHeight; // 0x2B8
	protected object m_IsDrivenLineSpacing; // 0x2BC
	protected object m_lineSpacingMax; // 0x2C0
	protected object m_paragraphSpacing; // 0x2C4
	protected object m_charWidthMaxAdj; // 0x2C8
	protected object m_charWidthAdjDelta; // 0x2CC
	protected object m_enableWordWrapping; // 0x2D0
	protected object m_isCharacterWrappingEnabled; // 0x2D1
	protected object m_isNonBreakingSpace; // 0x2D2
	protected object m_isIgnoringAlignment; // 0x2D3
	protected object m_wordWrappingRatios; // 0x2D4
	protected object m_overflowMode; // 0x2D8
	protected object m_firstOverflowCharacterIndex; // 0x2DC
	protected object m_linkedTextComponent; // 0x2E0
	internal object parentLinkedComponent; // 0x2E8
	protected object m_isTextTruncated; // 0x2F0
	protected object m_enableKerning; // 0x2F1
	protected object m_GlyphHorizontalAdvanceAdjustment; // 0x2F4
	protected object m_enableExtraPadding; // 0x2F8
	protected object checkPaddingRequired; // 0x2F9
	protected object m_isRichText; // 0x2FA
	protected object m_parseCtrlCharacters; // 0x2FB
	protected object m_isOverlay; // 0x2FC
	protected object m_isOrthographic; // 0x2FD
	protected object m_isCullingEnabled; // 0x2FE
	protected object m_isMaskingEnabled; // 0x2FF
	protected object isMaskUpdateRequired; // 0x300
	protected object m_ignoreCulling; // 0x301
	protected object m_horizontalMapping; // 0x304
	protected object m_verticalMapping; // 0x308
	protected object m_uvLineOffset; // 0x30C
	protected object m_renderMode; // 0x310
	protected object m_geometrySortingOrder; // 0x314
	protected object m_IsTextObjectScaleStatic; // 0x318
	protected object m_VertexBufferAutoSizeReduction; // 0x319
	protected object m_firstVisibleCharacter; // 0x31C
	protected object m_maxVisibleCharacters; // 0x320
	protected object m_maxVisibleWords; // 0x324
	protected object m_maxVisibleLines; // 0x328
	protected object m_useMaxVisibleDescender; // 0x32C
	protected object m_pageToDisplay; // 0x330
	protected object m_isNewPage; // 0x334
	protected object m_margin; // 0x338
	protected object m_marginLeft; // 0x348
	protected object m_marginRight; // 0x34C
	protected object m_marginWidth; // 0x350
	protected object m_marginHeight; // 0x354
	protected object m_width; // 0x358
	protected object m_textInfo; // 0x360
	protected object m_havePropertiesChanged; // 0x368
	protected object m_isUsingLegacyAnimationComponent; // 0x369
	protected object m_transform; // 0x370
	protected object m_rectTransform; // 0x378
	protected object m_PreviousRectTransformSize; // 0x380
	protected object m_PreviousPivotPosition; // 0x388
	private object <autoSizeTextContainer>k__BackingField; // 0x390
	protected object m_autoSizeTextContainer; // 0x391
	protected object m_mesh; // 0x398
	protected object m_isVolumetricText; // 0x3A0
	private static object OnFontAssetRequest; // 0x70
	private static object OnSpriteAssetRequest; // 0x78
	private object OnPreRenderText; // 0x3A8
	protected object m_spriteAnimator; // 0x3B0
	protected object m_flexibleHeight; // 0x3B8
	protected object m_flexibleWidth; // 0x3BC
	protected object m_minWidth; // 0x3C0
	protected object m_minHeight; // 0x3C4
	protected object m_maxWidth; // 0x3C8
	protected object m_maxHeight; // 0x3CC
	protected object m_LayoutElement; // 0x3D0
	protected object m_preferredWidth; // 0x3D8
	protected object m_renderedWidth; // 0x3DC
	protected object m_isPreferredWidthDirty; // 0x3E0
	protected object m_preferredHeight; // 0x3E4
	protected object m_renderedHeight; // 0x3E8
	protected object m_isPreferredHeightDirty; // 0x3EC
	protected object m_isCalculatingPreferredValues; // 0x3ED
	protected object m_layoutPriority; // 0x3F0
	protected object m_isLayoutDirty; // 0x3F4
	protected object isUseOptimizeMode; // 0x3F5
	protected object m_isAwake; // 0x3F6
	internal object m_isWaitingOnResourceLoad; // 0x3F7
	internal object m_inputSource; // 0x3F8
	protected object m_fontScaleMultiplier; // 0x3FC
	private static object m_htmlTag; // 0x80
	private static object m_xmlAttribute; // 0x88
	private static object m_attributeParameterValues; // 0x90
	protected object tag_LineIndent; // 0x400
	protected object tag_Indent; // 0x404
	protected object m_indentStack; // 0x408
	protected object tag_NoParsing; // 0x428
	protected object m_isParsingText; // 0x429
	protected object m_FXMatrix; // 0x42C
	protected object m_isFXMatrixSet; // 0x46C
	internal object m_TextProcessingArray; // 0x470
	internal object m_InternalTextProcessingArraySize; // 0x478
	private object m_internalCharacterInfo; // 0x480
	protected object m_totalCharacterCount; // 0x488
	protected static object m_SavedWordWrapState; // 0x98
	protected static object m_SavedLineState; // 0x410
	protected static object m_SavedEllipsisState; // 0x788
	protected static object m_SavedLastValidState; // 0xB00
	protected static object m_SavedSoftLineBreakState; // 0xE78
	internal static object m_EllipsisInsertionCandidateStack; // 0x11F0
	protected object m_characterCount; // 0x48C
	protected object m_firstCharacterOfLine; // 0x490
	protected object m_firstVisibleCharacterOfLine; // 0x494
	protected object m_lastCharacterOfLine; // 0x498
	protected object m_lastVisibleCharacterOfLine; // 0x49C
	protected object m_lineNumber; // 0x4A0
	protected object m_lineVisibleCharacterCount; // 0x4A4
	protected object m_pageNumber; // 0x4A8
	protected object m_PageAscender; // 0x4AC
	protected object m_maxTextAscender; // 0x4B0
	protected object m_maxCapHeight; // 0x4B4
	protected object m_ElementAscender; // 0x4B8
	protected object m_ElementDescender; // 0x4BC
	protected object m_maxLineAscender; // 0x4C0
	protected object m_maxLineDescender; // 0x4C4
	protected object m_startOfLineAscender; // 0x4C8
	protected object m_startOfLineDescender; // 0x4CC
	protected object m_lineOffset; // 0x4D0
	protected object m_meshExtents; // 0x4D4
	protected object m_htmlColor; // 0x4E4
	protected object m_colorStack; // 0x4E8
	protected object m_underlineColorStack; // 0x508
	protected object m_strikethroughColorStack; // 0x528
	protected object m_HighlightStateStack; // 0x548
	protected object m_colorGradientPreset; // 0x578
	protected object m_colorGradientStack; // 0x580
	protected object m_colorGradientPresetIsTinted; // 0x5A8
	protected object m_tabSpacing; // 0x5AC
	protected object m_spacing; // 0x5B0
	protected object m_TextStyleStacks; // 0x5B8
	protected object m_TextStyleStackDepth; // 0x5C0
	protected object m_ItalicAngleStack; // 0x5C8
	protected object m_ItalicAngle; // 0x5E8
	protected object m_actionStack; // 0x5F0
	protected object m_padding; // 0x610
	protected object m_baselineOffset; // 0x614
	protected object m_baselineOffsetStack; // 0x618
	protected object m_xAdvance; // 0x638
	protected object m_textElementType; // 0x63C
	protected object m_cached_TextElement; // 0x640
	protected object m_Ellipsis; // 0x648
	protected object m_Underline; // 0x668
	protected object m_defaultSpriteAsset; // 0x688
	protected object m_currentSpriteAsset; // 0x690
	protected object m_spriteCount; // 0x698
	protected object m_spriteIndex; // 0x69C
	protected object m_spriteAnimationID; // 0x6A0
	private static object k_ParseTextMarker; // 0x1588
	private static object k_InsertNewLineMarker; // 0x1590
	protected object m_ignoreActiveState; // 0x6A4
	private object m_TextBackingArray; // 0x6A8
	private readonly object k_Power; // 0x6B8
	protected static object k_LargePositiveVector2; // 0x1598
	protected static object k_LargeNegativeVector2; // 0x15A0
	protected static object k_LargePositiveFloat; // 0x15A8
	protected static object k_LargeNegativeFloat; // 0x15AC
	protected static object k_LargePositiveInt; // 0x15B0
	protected static object k_LargeNegativeInt; // 0x15B4

	// Properties
	public virtual object text { get; set; }
	public object textPreprocessor { get; set; }
	public object isRightToLeftText { get; set; }
	public object font { get; set; }
	public virtual object fontSharedMaterial { get; set; }
	public virtual object fontSharedMaterials { get; set; }
	public object fontMaterial { get; set; }
	public virtual object fontMaterials { get; set; }
	public override object color { get; set; }
	public object alpha { get; set; }
	public object enableVertexGradient { get; set; }
	public object colorGradient { get; set; }
	public object colorGradientPreset { get; set; }
	public object spriteAsset { get; set; }
	public object tintAllSprites { get; set; }
	public object styleSheet { get; set; }
	public object textStyle { get; set; }
	public object overrideColorTags { get; set; }
	public object faceColor { get; set; }
	public object outlineColor { get; set; }
	public object outlineWidth { get; set; }
	public object fontSize { get; set; }
	public object fontWeight { get; set; }
	public object pixelsPerUnit { get; }
	public object enableAutoSizing { get; set; }
	public object fontSizeMin { get; set; }
	public object fontSizeMax { get; set; }
	public object fontStyle { get; set; }
	public object isUsingBold { get; }
	public object horizontalAlignment { get; set; }
	public object verticalAlignment { get; set; }
	public object alignment { get; set; }
	public object characterSpacing { get; set; }
	public object wordSpacing { get; set; }
	public object lineSpacing { get; set; }
	public object lineSpacingAdjustment { get; set; }
	public object paragraphSpacing { get; set; }
	public object characterWidthAdjustment { get; set; }
	public object enableWordWrapping { get; set; }
	public object wordWrappingRatios { get; set; }
	public object overflowMode { get; set; }
	public object isTextOverflowing { get; }
	public object firstOverflowCharacterIndex { get; }
	public object linkedTextComponent { get; set; }
	public object isTextTruncated { get; }
	public object enableKerning { get; set; }
	public object extraPadding { get; set; }
	public object richText { get; set; }
	public object parseCtrlCharacters { get; set; }
	public object isOverlay { get; set; }
	public object isOrthographic { get; set; }
	public object enableCulling { get; set; }
	public object ignoreVisibility { get; set; }
	public object horizontalMapping { get; set; }
	public object verticalMapping { get; set; }
	public object mappingUvLineOffset { get; set; }
	public object renderMode { get; set; }
	public object geometrySortingOrder { get; set; }
	public object isTextObjectScaleStatic { get; set; }
	public object vertexBufferAutoSizeReduction { get; set; }
	public object firstVisibleCharacter { get; set; }
	public object maxVisibleCharacters { get; set; }
	public object maxVisibleWords { get; set; }
	public object maxVisibleLines { get; set; }
	public object useMaxVisibleDescender { get; set; }
	public object pageToDisplay { get; set; }
	public virtual object margin { get; set; }
	public object textInfo { get; }
	public object havePropertiesChanged { get; set; }
	public object isUsingLegacyAnimationComponent { get; set; }
	public object transform { get; }
	public object rectTransform { get; }
	public virtual object autoSizeTextContainer { get; set; }
	public virtual object mesh { get; }
	public object isVolumetricText { get; set; }
	public object bounds { get; }
	public object textBounds { get; }
	protected object spriteAnimator { get; }
	public object flexibleHeight { get; }
	public object flexibleWidth { get; }
	public object minWidth { get; }
	public object minHeight { get; }
	public object maxWidth { get; }
	public object maxHeight { get; }
	protected object layoutElement { get; }
	public virtual object preferredWidth { get; }
	public virtual object preferredHeight { get; }
	public virtual object renderedWidth { get; }
	public virtual object renderedHeight { get; }
	public object layoutPriority { get; }

	// Methods

	// RVA: 0x72C2580
	public virtual object get_text() { }

	// RVA: 0x72C2690
	public virtual object set_text(object value) { }

	// RVA: 0x72C2754
	public object get_textPreprocessor() { }

	// RVA: 0x72C275C
	public object set_textPreprocessor(object value) { }

	// RVA: 0x72C2764
	public object get_isRightToLeftText() { }

	// RVA: 0x72C276C
	public object set_isRightToLeftText(object value) { }

	// RVA: 0x72C27F0
	public object get_font() { }

	// RVA: 0x72C27F8
	public object set_font(object value) { }

	// RVA: 0x72C2924
	public virtual object get_fontSharedMaterial() { }

	// RVA: 0x72C292C
	public virtual object set_fontSharedMaterial(object value) { }

	// RVA: 0x72C2A58
	public virtual object get_fontSharedMaterials() { }

	// RVA: 0x72C2A9C
	public virtual object set_fontSharedMaterials(object value) { }

	// RVA: 0x72C2B3C
	public object get_fontMaterial() { }

	// RVA: 0x72C2B88
	public object set_fontMaterial(object value) { }

	// RVA: 0x72C2D00
	public virtual object get_fontMaterials() { }

	// RVA: 0x72C2D4C
	public virtual object set_fontMaterials(object value) { }

	// RVA: 0x72C2DEC
	public override object get_color() { }

	// RVA: 0x72C2E00
	public override object set_color(object value) { }

	// RVA: 0x72C2EB8
	public object get_alpha() { }

	// RVA: 0x72C2EC0
	public object set_alpha(object value) { }

	// RVA: 0x72C2F20
	public object get_enableVertexGradient() { }

	// RVA: 0x72C2F28
	public object set_enableVertexGradient(object value) { }

	// RVA: 0x72C2F90
	public object get_colorGradient() { }

	// RVA: 0x72C2FA4
	public object set_colorGradient(object value) { }

	// RVA: 0x72C300C
	public object get_colorGradientPreset() { }

	// RVA: 0x72C3014
	public object set_colorGradientPreset(object value) { }

	// RVA: 0x72C3064
	public object get_spriteAsset() { }

	// RVA: 0x72C306C
	public object set_spriteAsset(object value) { }

	// RVA: 0x72C30E0
	public object get_tintAllSprites() { }

	// RVA: 0x72C30E8
	public object set_tintAllSprites(object value) { }

	// RVA: 0x72C3148
	public object get_styleSheet() { }

	// RVA: 0x72C3150
	public object set_styleSheet(object value) { }

	// RVA: 0x72C31C4
	public object get_textStyle() { }

	// RVA: 0x72C3364
	public object set_textStyle(object value) { }

	// RVA: 0x72C33F0
	public object get_overrideColorTags() { }

	// RVA: 0x72C33F8
	public object set_overrideColorTags(object value) { }

	// RVA: 0x72C3458
	public object get_faceColor() { }

	// RVA: 0x72C3560
	public object set_faceColor(object value) { }

	// RVA: 0x72C363C
	public object get_outlineColor() { }

	// RVA: 0x72C3744
	public object set_outlineColor(object value) { }

	// RVA: 0x72C37F8
	public object get_outlineWidth() { }

	// RVA: 0x72C38F8
	public object set_outlineWidth(object value) { }

	// RVA: 0x72C3998
	public object get_fontSize() { }

	// RVA: 0x72C39A0
	public object set_fontSize(object value) { }

	// RVA: 0x72C3A58
	public object get_fontWeight() { }

	// RVA: 0x72C3A60
	public object set_fontWeight(object value) { }

	// RVA: 0x72C3AE4
	public object get_pixelsPerUnit() { }

	// RVA: 0x72C3D44
	public object get_enableAutoSizing() { }

	// RVA: 0x72C3D4C
	public object set_enableAutoSizing(object value) { }

	// RVA: 0x72C3DC8
	public object get_fontSizeMin() { }

	// RVA: 0x72C3DD0
	public object set_fontSizeMin(object value) { }

	// RVA: 0x72C3E4C
	public object get_fontSizeMax() { }

	// RVA: 0x72C3E54
	public object set_fontSizeMax(object value) { }

	// RVA: 0x72C3ED0
	public object get_fontStyle() { }

	// RVA: 0x72C3ED8
	public object set_fontStyle(object value) { }

	// RVA: 0x72C3F6C
	public object get_isUsingBold() { }

	// RVA: 0x72C3F74
	public object get_horizontalAlignment() { }

	// RVA: 0x72C3F7C
	public object set_horizontalAlignment(object value) { }

	// RVA: 0x72C3FDC
	public object get_verticalAlignment() { }

	// RVA: 0x72C3FE4
	public object set_verticalAlignment(object value) { }

	// RVA: 0x72C4044
	public object get_alignment() { }

	// RVA: 0x72C4054
	public object set_alignment(object value) { }

	// RVA: 0x72C40CC
	public object get_characterSpacing() { }

	// RVA: 0x72C40D4
	public object set_characterSpacing(object value) { }

	// RVA: 0x72C4158
	public object get_wordSpacing() { }

	// RVA: 0x72C4160
	public object set_wordSpacing(object value) { }

	// RVA: 0x72C41E4
	public object get_lineSpacing() { }

	// RVA: 0x72C41EC
	public object set_lineSpacing(object value) { }

	// RVA: 0x72C4270
	public object get_lineSpacingAdjustment() { }

	// RVA: 0x72C4278
	public object set_lineSpacingAdjustment(object value) { }

	// RVA: 0x72C42FC
	public object get_paragraphSpacing() { }

	// RVA: 0x72C4304
	public object set_paragraphSpacing(object value) { }

	// RVA: 0x72C4388
	public object get_characterWidthAdjustment() { }

	// RVA: 0x72C4390
	public object set_characterWidthAdjustment(object value) { }

	// RVA: 0x72C4414
	public object get_enableWordWrapping() { }

	// RVA: 0x72C441C
	public object set_enableWordWrapping(object value) { }

	// RVA: 0x72C44A0
	public object get_wordWrappingRatios() { }

	// RVA: 0x72C44A8
	public object set_wordWrappingRatios(object value) { }

	// RVA: 0x72C452C
	public object get_overflowMode() { }

	// RVA: 0x72C4534
	public object set_overflowMode(object value) { }

	// RVA: 0x72C45B8
	public object get_isTextOverflowing() { }

	// RVA: 0x72C45C8
	public object get_firstOverflowCharacterIndex() { }

	// RVA: 0x72C45D0
	public object get_linkedTextComponent() { }

	// RVA: 0x72C45D8
	public object set_linkedTextComponent(object value) { }

	// RVA: 0x72C4A18
	public object get_isTextTruncated() { }

	// RVA: 0x72C4A20
	public object get_enableKerning() { }

	// RVA: 0x72C4A28
	public object set_enableKerning(object value) { }

	// RVA: 0x72C4AAC
	public object get_extraPadding() { }

	// RVA: 0x72C4AB4
	public object set_extraPadding(object value) { }

	// RVA: 0x72C4B38
	public object get_richText() { }

	// RVA: 0x72C4B40
	public object set_richText(object value) { }

	// RVA: 0x72C4BC4
	public object get_parseCtrlCharacters() { }

	// RVA: 0x72C4BCC
	public object set_parseCtrlCharacters(object value) { }

	// RVA: 0x72C4C50
	public object get_isOverlay() { }

	// RVA: 0x72C4C58
	public object set_isOverlay(object value) { }

	// RVA: 0x72C4CDC
	public object get_isOrthographic() { }

	// RVA: 0x72C4CE4
	public object set_isOrthographic(object value) { }

	// RVA: 0x72C4D44
	public object get_enableCulling() { }

	// RVA: 0x72C4D4C
	public object set_enableCulling(object value) { }

	// RVA: 0x72C4DA8
	public object get_ignoreVisibility() { }

	// RVA: 0x72C4DB0
	public object set_ignoreVisibility(object value) { }

	// RVA: 0x72C4DCC
	public object get_horizontalMapping() { }

	// RVA: 0x72C4DD4
	public object set_horizontalMapping(object value) { }

	// RVA: 0x72C4E34
	public object get_verticalMapping() { }

	// RVA: 0x72C4E3C
	public object set_verticalMapping(object value) { }

	// RVA: 0x72C4E9C
	public object get_mappingUvLineOffset() { }

	// RVA: 0x72C4EA4
	public object set_mappingUvLineOffset(object value) { }

	// RVA: 0x72C4F04
	public object get_renderMode() { }

	// RVA: 0x72C4F0C
	public object set_renderMode(object value) { }

	// RVA: 0x72C4F28
	public object get_geometrySortingOrder() { }

	// RVA: 0x72C4F30
	public object set_geometrySortingOrder(object value) { }

	// RVA: 0x72C4F80
	public object get_isTextObjectScaleStatic() { }

	// RVA: 0x72C4F88
	public object set_isTextObjectScaleStatic(object value) { }

	// RVA: 0x72C5048
	public object get_vertexBufferAutoSizeReduction() { }

	// RVA: 0x72C5050
	public object set_vertexBufferAutoSizeReduction(object value) { }

	// RVA: 0x72C50A0
	public object get_firstVisibleCharacter() { }

	// RVA: 0x72C50A8
	public object set_firstVisibleCharacter(object value) { }

	// RVA: 0x72C5108
	public object get_maxVisibleCharacters() { }

	// RVA: 0x72C5110
	public object set_maxVisibleCharacters(object value) { }

	// RVA: 0x72C5170
	public object get_maxVisibleWords() { }

	// RVA: 0x72C5178
	public object set_maxVisibleWords(object value) { }

	// RVA: 0x72C51D8
	public object get_maxVisibleLines() { }

	// RVA: 0x72C51E0
	public object set_maxVisibleLines(object value) { }

	// RVA: 0x72C5240
	public object get_useMaxVisibleDescender() { }

	// RVA: 0x72C5248
	public object set_useMaxVisibleDescender(object value) { }

	// RVA: 0x72C52A8
	public object get_pageToDisplay() { }

	// RVA: 0x72C52B0
	public object set_pageToDisplay(object value) { }

	// RVA: 0x72C5310
	public virtual object get_margin() { }

	// RVA: 0x72C5324
	public virtual object set_margin(object value) { }

	// RVA: 0x72C53F8
	public object get_textInfo() { }

	// RVA: 0x72C5400
	public object get_havePropertiesChanged() { }

	// RVA: 0x72C5408
	public object set_havePropertiesChanged(object value) { }

	// RVA: 0x72C5460
	public object get_isUsingLegacyAnimationComponent() { }

	// RVA: 0x72C5468
	public object set_isUsingLegacyAnimationComponent(object value) { }

	// RVA: 0x72C5470
	public object get_transform() { }

	// RVA: 0x72C5540
	public object get_rectTransform() { }

	// RVA: 0x72C5610
	public virtual object get_autoSizeTextContainer() { }

	// RVA: 0x72C5618
	public virtual object set_autoSizeTextContainer(object value) { }

	// RVA: 0x72C5620
	public virtual object get_mesh() { }

	// RVA: 0x72C5628
	public object get_isVolumetricText() { }

	// RVA: 0x72C5630
	public object set_isVolumetricText(object value) { }

	// RVA: 0x72C56D0
	public object get_bounds() { }

	// RVA: 0x72C57AC
	public object get_textBounds() { }

	// RVA: 0x72C59AC
	public static object add_OnFontAssetRequest(object value) { }

	// RVA: 0x72C5AC0
	public static object remove_OnFontAssetRequest(object value) { }

	// RVA: 0x72C5BD4
	public static object add_OnSpriteAssetRequest(object value) { }

	// RVA: 0x72C5CE8
	public static object remove_OnSpriteAssetRequest(object value) { }

	// RVA: 0x72C5DFC
	public virtual object add_OnPreRenderText(object value) { }

	// RVA: 0x72C5EB0
	public virtual object remove_OnPreRenderText(object value) { }

	// RVA: 0x72C5F64
	protected object get_spriteAnimator() { }

	// RVA: 0x72C60B0
	public object get_flexibleHeight() { }

	// RVA: 0x72C60B8
	public object get_flexibleWidth() { }

	// RVA: 0x72C60C0
	public object get_minWidth() { }

	// RVA: 0x72C60C8
	public object get_minHeight() { }

	// RVA: 0x72C60D0
	public object get_maxWidth() { }

	// RVA: 0x72C60D8
	public object get_maxHeight() { }

	// RVA: 0x72C60E0
	protected object get_layoutElement() { }

	// RVA: 0x72C61B0
	public virtual object get_preferredWidth() { }

	// RVA: 0x72C6384
	public virtual object get_preferredHeight() { }

	// RVA: 0x72C6580
	public virtual object get_renderedWidth() { }

	// RVA: 0x72C65D0
	public virtual object get_renderedHeight() { }

	// RVA: 0x72C6620
	public object get_layoutPriority() { }

	// RVA: 0x72C6628
	protected virtual object LoadFontAsset() { }

	// RVA: 0x72C662C
	protected virtual object SetSharedMaterial(object mat) { }

	// RVA: 0x72C6630
	protected virtual object GetMaterial(object mat) { }

	// RVA: 0x72C6638
	protected virtual object SetFontBaseMaterial(object mat) { }

	// RVA: 0x72C663C
	protected virtual object GetSharedMaterials() { }

	// RVA: 0x72C6644
	protected virtual object SetSharedMaterials(object materials) { }

	// RVA: 0x72C6648
	protected virtual object GetMaterials(object mats) { }

	// RVA: 0x72C6650
	protected virtual object CreateMaterialInstance(object source) { }

	// RVA: 0x72C6730
	protected object SetVertexColorGradient(object gradient) { }

	// RVA: 0x72C6828
	protected object SetTextSortingOrder(object order) { }

	// RVA: 0x72C682C
	protected object SetTextSortingOrder(object order) { }

	// RVA: 0x72C6830
	protected virtual object SetFaceColor(object color) { }

	// RVA: 0x72C6834
	protected virtual object SetOutlineColor(object color) { }

	// RVA: 0x72C6838
	protected virtual object SetOutlineThickness(object thickness) { }

	// RVA: 0x72C683C
	protected virtual object SetShaderDepth() { }

	// RVA: 0x72C6840
	protected virtual object SetCulling() { }

	// RVA: 0x72C6844
	internal virtual object UpdateCulling() { }

	// RVA: 0x72C6848
	protected virtual object GetPaddingForMaterial() { }

	// RVA: 0x72C69C0
	protected virtual object GetPaddingForMaterial(object mat) { }

	// RVA: 0x72C6AFC
	protected virtual object GetTextContainerLocalCorners() { }

	// RVA: 0x72C6B04
	public virtual object ForceMeshUpdate(object ignoreActiveState, object forceTextReparsing) { }

	// RVA: 0x72C6B08
	public virtual object UpdateGeometry(object mesh, object index) { }

	// RVA: 0x72C6B0C
	public virtual object UpdateVertexData(object flags) { }

	// RVA: 0x72C6B10
	public virtual object UpdateVertexData() { }

	// RVA: 0x72C6B14
	public virtual object SetVertices(object vertices) { }

	// RVA: 0x72C6B18
	public virtual object UpdateMeshPadding() { }

	// RVA: 0x72C6B1C
	public override object CrossFadeColor(object targetColor, object duration, object ignoreTimeScale, object useAlpha) { }

	// RVA: 0x72C6BBC
	public override object CrossFadeAlpha(object alpha, object duration, object ignoreTimeScale) { }

	// RVA: 0x72C6C24
	protected virtual object InternalCrossFadeColor(object targetColor, object duration, object ignoreTimeScale, object useAlpha) { }

	// RVA: 0x72C6C28
	protected virtual object InternalCrossFadeAlpha(object alpha, object duration, object ignoreTimeScale) { }

	// RVA: 0x72C6C2C
	protected object ParseInputText() { }

	// RVA: 0x72C6D88
	private object PopulateTextBackingArray(object sourceText) { }

	// RVA: 0x72C7AA4
	private object PopulateTextBackingArray(object sourceText, object start, object length) { }

	// RVA: 0x72C7BC4
	private object PopulateTextBackingArray(object sourceText, object start, object length) { }

	// RVA: 0x72C7D10
	private object PopulateTextBackingArray(object sourceText, object start, object length) { }

	// RVA: 0x72C6DA4
	private object PopulateTextProcessingArray() { }

	// RVA: 0x72C9380
	private object SetTextInternal(object sourceText) { }

	// RVA: 0x72C93D0
	public object SetText(object sourceText, object syncTextInputBox) { }

	// RVA: 0x72C9478
	public object SetText(object sourceText, object arg0) { }

	// RVA: 0x72C9820
	public object SetText(object sourceText, object arg0, object arg1) { }

	// RVA: 0x72C983C
	public object SetText(object sourceText, object arg0, object arg1, object arg2) { }

	// RVA: 0x72C9854
	public object SetText(object sourceText, object arg0, object arg1, object arg2, object arg3) { }

	// RVA: 0x72C9868
	public object SetText(object sourceText, object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x72C9878
	public object SetText(object sourceText, object arg0, object arg1, object arg2, object arg3, object arg4, object arg5) { }

	// RVA: 0x72C9884
	public object SetText(object sourceText, object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6) { }

	// RVA: 0x72C9498
	public object SetText(object sourceText, object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7) { }

	// RVA: 0x72C9BAC
	public object SetText(object sourceText) { }

	// RVA: 0x72C9C60
	private object SetText(object sourceText, object start, object length) { }

	// RVA: 0x72C9CE8
	public object SetText(object sourceText) { }

	// RVA: 0x72C9E10
	public object SetText(object sourceText, object start, object length) { }

	// RVA: 0x72C9E98
	public object SetCharArray(object sourceText) { }

	// RVA: 0x72C9D88
	public object SetCharArray(object sourceText, object start, object length) { }

	// RVA: 0x72C321C
	private object GetStyle(object hashCode) { }

	// RVA: 0x72C85B0
	private object ReplaceOpeningStyleTag(object sourceText, object srcIndex, object srcOffset, object charBuffer, object writeIndex) { }

	// RVA: 0x72CA368
	private object ReplaceOpeningStyleTag(object sourceText, object srcIndex, object srcOffset, object charBuffer, object writeIndex) { }

	// RVA: 0x72C8A74
	private object ReplaceClosingStyleTag(object sourceText, object srcIndex, object charBuffer, object writeIndex) { }

	// RVA: 0x72CA82C
	private object ReplaceClosingStyleTag(object sourceText, object srcIndex, object charBuffer, object writeIndex) { }

	// RVA: 0x72C7E48
	private object InsertOpeningStyleTag(object style, object srcIndex, object charBuffer, object writeIndex) { }

	// RVA: 0x72C8F08
	private object InsertClosingStyleTag(object charBuffer, object writeIndex) { }

	// RVA: 0x72CA24C
	private object GetMarkupTagHashCode(object tagDefinition, object readIndex) { }

	// RVA: 0x72C84A8
	private object GetMarkupTagHashCode(object tagDefinition, object readIndex) { }

	// RVA: 0x72CACC0
	private object GetStyleHashCode(object text, object index, object closeIndex) { }

	// RVA: 0x72C9F38
	private object GetStyleHashCode(object text, object index, object closeIndex) { }

	// RVA: -1
	private object ResizeInternalArray(object array) { }

	// RVA: -1
	private object ResizeInternalArray(object array, object size) { }

	// RVA: 0x72C988C
	private object AddFloatToInternalTextBackingArray(object value, object padding, object precision, object writeIndex) { }

	// RVA: 0x72CADA4
	private object AddIntegerToInternalTextBackingArray(object number, object padding, object writeIndex) { }

	// RVA: 0x72C2598
	private object InternalTextBackingArrayToString() { }

	// RVA: 0x72CAED8
	internal virtual object SetArraySizes(object unicodeChars) { }

	// RVA: 0x72CAEE0
	public object GetPreferredValues() { }

	// RVA: 0x72CAF30
	public object GetPreferredValues(object width, object height) { }

	// RVA: 0x72CB214
	public object GetPreferredValues(object text) { }

	// RVA: 0x72CB41C
	public object GetPreferredValues(object text, object width, object height) { }

	// RVA: 0x72C61D4
	protected object GetPreferredWidth() { }

	// RVA: 0x72CB090
	private object GetPreferredWidth(object margin) { }

	// RVA: 0x72C63A8
	protected object GetPreferredHeight() { }

	// RVA: 0x72CB138
	private object GetPreferredHeight(object margin) { }

	// RVA: 0x72CB5DC
	public object GetRenderedValues() { }

	// RVA: 0x72CB608
	public object GetRenderedValues(object onlyVisibleCharacters) { }

	// RVA: 0x72C65A8
	private object GetRenderedWidth() { }

	// RVA: 0x72CB904
	protected object GetRenderedWidth(object onlyVisibleCharacters) { }

	// RVA: 0x72C65F8
	private object GetRenderedHeight() { }

	// RVA: 0x72CB92C
	protected object GetRenderedHeight(object onlyVisibleCharacters) { }

	// RVA: 0x72CB954
	protected virtual object CalculatePreferredValues(object fontSize, object marginSize, object isTextAutoSizingEnabled, object isWordWrappingEnabled) { }

	// RVA: 0x72D4544
	protected virtual object GetCompoundBounds() { }

	// RVA: 0x72D4550
	internal virtual object GetCanvasSpaceClippingRect() { }

	// RVA: 0x72C57C4
	protected object GetTextBounds() { }

	// RVA: 0x72CB634
	protected object GetTextBounds(object onlyVisibleCharacters) { }

	// RVA: 0x72D4558
	protected object AdjustLineOffset(object startIndex, object endIndex, object offset) { }

	// RVA: 0x72D4658
	protected object ResizeLineExtents(object size) { }

	// RVA: 0x72D4868
	public virtual object GetTextInfo(object text) { }

	// RVA: 0x72D4870
	public virtual object ComputeMarginSize() { }

	// RVA: 0x72D4874
	protected object InsertNewLine(object i, object baseScale, object currentElementScale, object currentEmScale, object glyphAdjustment, object boldSpacingAdjustment, object characterSpacingAdjustment, object width, object lineGap, object isMaxVisibleDescenderSet, object maxVisibleDescender) { }

	// RVA: 0x72D425C
	protected object SaveWordWrappingState(object state, object index, object count) { }

	// RVA: 0x72D3F50
	protected object RestoreWordWrappingState(object state) { }

	// RVA: 0x72D4E14
	protected virtual object SaveGlyphVertexInfo(object padding, object style_padding, object vertexColor) { }

	// RVA: 0x72D5D98
	protected virtual object SaveSpriteVertexInfo(object vertexColor) { }

	// RVA: 0x72D67A4
	protected virtual object FillCharacterVertexBuffers(object i, object index_X4) { }

	// RVA: 0x72D6C8C
	protected virtual object FillCharacterVertexBuffers(object i, object index_X4, object isVolumetric) { }

	// RVA: 0x72D73EC
	protected virtual object FillSpriteVertexBuffers(object i, object index_X4) { }

	// RVA: 0x72D78D4
	protected virtual object DrawUnderlineMesh(object start, object end, object index, object startScale, object endScale, object maxScale, object sdfScale, object underlineColor) { }

	// RVA: 0x72D86F4
	protected virtual object DrawTextHighlight(object start, object end, object index, object highlightColor) { }

	// RVA: 0x72D8C14
	protected object LoadDefaultSettings() { }

	// RVA: 0x72D8FB4
	protected object GetSpecialCharacters(object fontAsset) { }

	// RVA: 0x72D8FE0
	protected object GetEllipsisSpecialCharacter(object fontAsset) { }

	// RVA: 0x72D8530
	protected object GetUnderlineSpecialCharacter(object fontAsset) { }

	// RVA: 0x72D9230
	protected object ReplaceTagWithCharacter(object chars, object insertionIndex, object tagLength, object c) { }

	// RVA: 0x72D9340
	protected object GetFontAssetForWeight(object fontWeight) { }

	// RVA: 0x72D9414
	internal object GetTextElement(object unicode, object fontAsset, object fontStyle, object fontWeight, object isUsingAlternativeTypeface) { }

	// RVA: 0x72D9858
	protected virtual object SetActiveSubMeshes(object state) { }

	// RVA: 0x72D985C
	protected virtual object DestroySubMeshObjects() { }

	// RVA: 0x72D9860
	public virtual object ClearMesh() { }

	// RVA: 0x72D9864
	public virtual object ClearMesh(object uploadGeometry) { }

	// RVA: 0x72D9868
	public virtual object GetParsedText() { }

	// RVA: 0x72C48C8
	internal object IsSelfOrLinkedAncestor(object targetTextComponent) { }

	// RVA: 0x72C4730
	internal object ReleaseLinkedTextComponent(object targetTextComponent) { }

	// RVA: 0x72D8698
	protected object PackUV(object x, object y, object scale) { }

	// RVA: 0x72D998C
	protected object PackUV(object x, object y) { }

	// RVA: 0x72D99F0
	internal virtual object InternalUpdate() { }

	// RVA: 0x72D99F4
	protected object HexToInt(object hex) { }

	// RVA: 0x72D9A1C
	protected object GetUTF16(object text, object i) { }

	// RVA: 0x72CA044
	protected object GetUTF16(object text, object i) { }

	// RVA: 0x72D9AD8
	internal object GetUTF16(object text, object i) { }

	// RVA: 0x72D9B94
	protected object GetUTF16(object text, object i) { }

	// RVA: 0x72C82C0
	private object GetUTF16(object text, object i) { }

	// RVA: 0x72D9C50
	protected object GetUTF32(object text, object i) { }

	// RVA: 0x72CA100
	protected object GetUTF32(object text, object i) { }

	// RVA: 0x72D9D9C
	internal object GetUTF32(object text, object i) { }

	// RVA: 0x72D9EE8
	protected object GetUTF32(object text, object i) { }

	// RVA: 0x72C836C
	private object GetUTF32(object text, object i) { }

	// RVA: 0x72DA034
	protected object HexCharsToColor(object hexChars, object tagCount) { }

	// RVA: 0x72DA508
	protected object HexCharsToColor(object hexChars, object startIndex, object length) { }

	// RVA: 0x72DA758
	private object GetAttributeParameters(object chars, object startIndex, object length, object parameters) { }

	// RVA: 0x72DA9B4
	protected object ConvertToFloat(object chars, object startIndex, object length) { }

	// RVA: 0x72DA818
	protected object ConvertToFloat(object chars, object startIndex, object length, object lastIndex) { }

	// RVA: 0x72CDEB8
	internal object ValidateHtmlTag(object chars, object startIndex, object endIndex) { }

	// RVA: 0x72DA9D4
	public static object CleanupStatics() { }

	// RVA: 0x72DAD80
	protected object .ctor() { }

	// RVA: 0x72DB6EC
	private static object .cctor() { }

}

// Namespace: TMPro
public enum TextElementType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Character;
	public const object Sprite;
}

// Namespace: TMPro
public class TMP_TextElement
{

	// Fields
	protected object m_ElementType; // 0x8
	internal object m_Unicode; // 0xC
	internal object m_TextAsset; // 0x10
	internal object m_Glyph; // 0x18
	internal object m_GlyphIndex; // 0x20
	internal object m_Scale; // 0x24

	// Properties
	public object elementType { get; }
	public object unicode { get; set; }
	public object textAsset { get; set; }
	public object glyph { get; set; }
	public object glyphIndex { get; set; }
	public object scale { get; set; }

	// Methods

	// RVA: 0x72EA690
	public object get_elementType() { }

	// RVA: 0x72EA698
	public object get_unicode() { }

	// RVA: 0x72EA6A0
	public object set_unicode(object value) { }

	// RVA: 0x72EA6A8
	public object get_textAsset() { }

	// RVA: 0x72EA6B0
	public object set_textAsset(object value) { }

	// RVA: 0x72EA6B8
	public object get_glyph() { }

	// RVA: 0x72EA6C0
	public object set_glyph(object value) { }

	// RVA: 0x72EA6C8
	public object get_glyphIndex() { }

	// RVA: 0x72EA6D0
	public object set_glyphIndex(object value) { }

	// RVA: 0x72EA6D8
	public object get_scale() { }

	// RVA: 0x72EA6E0
	public object set_scale(object value) { }

	// RVA: 0x72E5A70
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_TextElement_Legacy
{

	// Fields
	public object id; // 0x8
	public object x; // 0xC
	public object y; // 0x10
	public object width; // 0x14
	public object height; // 0x18
	public object xOffset; // 0x1C
	public object yOffset; // 0x20
	public object xAdvance; // 0x24
	public object scale; // 0x28

	// Methods

	// RVA: 0x72E2650
	public object .ctor() { }

}

// Namespace: TMPro
public class TMP_TextInfo
{

	// Fields
	internal static object k_InfinityVectorPositive; // 0x0
	internal static object k_InfinityVectorNegative; // 0x8
	public object textComponent; // 0x8
	public object characterCount; // 0x10
	public object spriteCount; // 0x14
	public object spaceCount; // 0x18
	public object wordCount; // 0x1C
	public object linkCount; // 0x20
	public object lineCount; // 0x24
	public object pageCount; // 0x28
	public object materialCount; // 0x2C
	public object characterInfo; // 0x30
	public object wordInfo; // 0x38
	public object linkInfo; // 0x40
	public object lineInfo; // 0x48
	public object pageInfo; // 0x50
	public object meshInfo; // 0x58
	private object m_CachedMeshInfo; // 0x60

	// Methods

	// RVA: 0x72EA6E8
	public object .ctor() { }

	// RVA: 0x72EA814
	internal object .ctor(object characterCount) { }

	// RVA: 0x72EA94C
	public object .ctor(object textComponent) { }

	// RVA: 0x72EAAEC
	public object Clear() { }

	// RVA: 0x72EAB7C
	public object ClearMeshInfo(object updateMesh) { }

	// RVA: 0x72EAC44
	public object ResetVertexLayout(object isVolumetric) { }

	// RVA: 0x72EAD10
	public object ClearLineInfo() { }

	// RVA: 0x72EAEC4
	internal object ClearPageInfo() { }

	// RVA: -1
	public static object Resize(object array, object size) { }

	// RVA: -1
	public static object Resize(object array, object size, object isBlockAllocated) { }

	// RVA: 0x72EAFC8
	private static object .cctor() { }

}

// Namespace: TMPro
public class TMP_TextParsingUtilities
{

	// Fields
	private static readonly object s_Instance; // 0x0

	// Methods

	// RVA: 0x72EB038
	private static object .cctor() { }

	// RVA: 0x72E5C5C
	public static object GetHashCode(object s) { }

	// RVA: 0x72E59DC
	public static object GetHashCodeCaseSensitive(object s) { }

	// RVA: 0x72EB0A0
	public static object ToUpperASCIIFast(object c) { }

	// RVA: 0x72EB12C
	internal static object ConvertToUTF32(object highSurrogate, object lowSurrogate) { }

	// RVA: 0x72EB098
	public object .ctor() { }

}

// Namespace: TMPro
public struct TMP_FontStyleStack
{

	// Fields
	public object bold; // 0xFFFFFFFFFFFFFFF8
	public object italic; // 0xFFFFFFFFFFFFFFF9
	public object underline; // 0xFFFFFFFFFFFFFFFA
	public object strikethrough; // 0xFFFFFFFFFFFFFFFB
	public object highlight; // 0xFFFFFFFFFFFFFFFC
	public object superscript; // 0xFFFFFFFFFFFFFFFD
	public object subscript; // 0xFFFFFFFFFFFFFFFE
	public object uppercase; // 0xFFFFFFFFFFFFFFFF
	public object lowercase; // 0x0
	public object smallcaps; // 0x1

	// Methods

	// RVA: 0x72EB140
	public object Clear() { }

	// RVA: 0x72EB158
	public object Add(object style) { }

	// RVA: 0x72EB3C0
	public object Remove(object style) { }

}

// Namespace: TMPro
public struct TMP_TextProcessingStack<T0>
{

	// Fields
	public object itemStack; // 0x0
	public object index; // 0x0
	private object m_DefaultItem; // 0x0
	private object m_Capacity; // 0x0
	private object m_RolloverSize; // 0x0
	private object m_Count; // 0x0
	private const object k_DefaultCapacity;

	// Properties
	public object Count { get; }
	public object current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object stack) { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object .ctor(object capacity, object rolloverSize) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_current() { }

	// RVA: -1
	internal static object SetDefault(object stack, object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object SetDefault(object item) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Remove() { }

	// RVA: -1
	public object Push(object item) { }

	// RVA: -1
	public object Pop() { }

	// RVA: -1
	public object Peek() { }

	// RVA: -1
	public object CurrentItem() { }

}

// Namespace: TMPro
public enum CaretPosition
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Left;
	public const object Right;
}

// Namespace: TMPro
public static class TMP_TextUtilities
{

	// Fields
	private static object m_rectWorldCorners; // 0x0

	// Methods

	// RVA: 0x72EB564
	public static object GetCursorIndexFromPosition(object textComponent, object position, object camera, object cursor) { }

	// RVA: 0x72EB780
	public static object FindNearestLine(object text, object position, object camera) { }

	// RVA: 0x72EB954
	public static object FindNearestCharacterOnLine(object text, object position, object line, object camera, object visibleOnly) { }

	// RVA: 0x72EC524
	public static object FindIntersectingWord(object text, object position, object camera) { }

	// RVA: 0x72EC390
	private static object PointIntersectRectangle(object m, object a, object b, object c, object d) { }

	// RVA: 0x72EC064
	public static object ScreenPointToWorldPointInRectangle(object transform, object screenPoint, object cam, object worldPoint) { }

	// RVA: 0x72EC448
	public static object DistanceToLine(object a, object b, object point) { }

	// RVA: 0x72ECC68
	internal static object ToUpperASCIIFast(object c) { }

	// RVA: 0x72E46E4
	public static object GetSimpleHashCode(object s) { }

	// RVA: 0x72ECCF0
	private static object .cctor() { }

}

// Namespace: TMPro
public class TMP_UpdateManager
{

	// Fields
	private static object s_Instance; // 0x0
	private readonly object m_LayoutQueueLookup; // 0x8
	private readonly object m_LayoutRebuildQueue; // 0x10
	private readonly object m_GraphicQueueLookup; // 0x18
	private readonly object m_GraphicRebuildQueue; // 0x20
	private readonly object m_InternalUpdateLookup; // 0x28
	private readonly object m_InternalUpdateQueue; // 0x30
	private readonly object m_CullingUpdateLookup; // 0x38
	private readonly object m_CullingUpdateQueue; // 0x40
	private static object k_RegisterTextObjectForUpdateMarker; // 0x8
	private static object k_RegisterTextElementForGraphicRebuildMarker; // 0x10
	private static object k_RegisterTextElementForCullingUpdateMarker; // 0x18
	private static object k_UnregisterTextObjectForUpdateMarker; // 0x20
	private static object k_UnregisterTextElementForGraphicRebuildMarker; // 0x28

	// Properties
	private static object instance { get; }

	// Methods

	// RVA: 0x72ECD64
	private static object get_instance() { }

	// RVA: 0x72ECE4C
	private object .ctor() { }

	// RVA: 0x72ECFFC
	internal static object RegisterTextObjectForUpdate(object textObject) { }

	// RVA: 0x72ED084
	private object InternalRegisterTextObjectForUpdate(object textObject) { }

	// RVA: 0x72ED248
	public static object RegisterTextElementForLayoutRebuild(object element) { }

	// RVA: 0x72ED2D0
	private object InternalRegisterTextElementForLayoutRebuild(object element) { }

	// RVA: 0x72ED494
	public static object RegisterTextElementForGraphicRebuild(object element) { }

	// RVA: 0x72ED51C
	private object InternalRegisterTextElementForGraphicRebuild(object element) { }

	// RVA: 0x72ED6E0
	public static object RegisterTextElementForCullingUpdate(object element) { }

	// RVA: 0x72ED768
	private object InternalRegisterTextElementForCullingUpdate(object element) { }

	// RVA: 0x72ED92C
	private object DoRebuilds() { }

	// RVA: 0x72EDC94
	internal static object UnRegisterTextObjectForUpdate(object textObject) { }

	// RVA: 0x72EDDDC
	public static object UnRegisterTextElementForRebuild(object element) { }

	// RVA: 0x72EDE9C
	private object InternalUnRegisterTextElementForGraphicRebuild(object element) { }

	// RVA: 0x72EDF5C
	private object InternalUnRegisterTextElementForLayoutRebuild(object element) { }

	// RVA: 0x72EDD1C
	private object InternalUnRegisterTextObjectForUpdate(object textObject) { }

	// RVA: 0x72EE01C
	private static object .cctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=12
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 1C3635C112D556F4C11A4FE6BDE6ED3F126C4B2B546811BDB64DE7BDED3A05CB; // 0x0
}

