// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public struct PhysicsScene2D
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x745766C
	public override object ToString() { }

	// RVA: 0x745776C
	public override object GetHashCode() { }

	// RVA: 0x745777C
	public override object Equals(object other) { }

	// RVA: 0x74578C4
	public object Equals(object other) { }

	// RVA: 0x74578E4
	public object Linecast(object start, object end, object layerMask) { }

	// RVA: 0x7457C44
	public object Linecast(object start, object end, object contactFilter) { }

	// RVA: 0x7457AE4
	private static object Linecast_Internal(object physicsScene, object start, object end, object contactFilter) { }

	// RVA: 0x7457E04
	public object Linecast(object start, object end, object results, object layerMask) { }

	// RVA: 0x7457FD0
	public object Linecast(object start, object end, object contactFilter, object results) { }

	// RVA: 0x7457EB0
	private static object LinecastArray_Internal(object physicsScene, object start, object end, object contactFilter, object results) { }

	// RVA: 0x7458150
	public object Linecast(object start, object end, object contactFilter, object results) { }

	// RVA: 0x74581CC
	private static object LinecastNonAllocList_Internal(object physicsScene, object start, object end, object contactFilter, object results) { }

	// RVA: 0x7458344
	public object Raycast(object origin, object direction, object distance, object layerMask) { }

	// RVA: 0x74585B0
	public object Raycast(object origin, object direction, object distance, object contactFilter) { }

	// RVA: 0x7458430
	private static object Raycast_Internal(object physicsScene, object origin, object direction, object distance, object contactFilter) { }

	// RVA: 0x74587A4
	public object Raycast(object origin, object direction, object distance, object results, object layerMask) { }

	// RVA: 0x74589A0
	public object Raycast(object origin, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7458860
	private static object RaycastArray_Internal(object physicsScene, object origin, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7458B54
	public object Raycast(object origin, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7458BE0
	private static object RaycastList_Internal(object physicsScene, object origin, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7458D8C
	public object CircleCast(object origin, object radius, object direction, object distance, object layerMask) { }

	// RVA: 0x7459010
	public object CircleCast(object origin, object radius, object direction, object distance, object contactFilter) { }

	// RVA: 0x7458E80
	private static object CircleCast_Internal(object physicsScene, object origin, object radius, object direction, object distance, object contactFilter) { }

	// RVA: 0x745921C
	public object CircleCast(object origin, object radius, object direction, object distance, object results, object layerMask) { }

	// RVA: 0x7459430
	public object CircleCast(object origin, object radius, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x74592E0
	private static object CircleCastArray_Internal(object physicsScene, object origin, object radius, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x74595FC
	public object CircleCast(object origin, object radius, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7459690
	private static object CircleCastList_Internal(object physicsScene, object origin, object radius, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7459854
	public object BoxCast(object origin, object size, object angle, object direction, object distance, object layerMask) { }

	// RVA: 0x7459B10
	public object BoxCast(object origin, object size, object angle, object direction, object distance, object contactFilter) { }

	// RVA: 0x7459960
	private static object BoxCast_Internal(object physicsScene, object origin, object size, object angle, object direction, object distance, object contactFilter) { }

	// RVA: 0x7459D34
	public object BoxCast(object origin, object size, object angle, object direction, object distance, object results, object layerMask) { }

	// RVA: 0x7459F80
	public object BoxCast(object origin, object size, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7459E10
	private static object BoxCastArray_Internal(object physicsScene, object origin, object size, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745A154
	public object BoxCast(object origin, object size, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745A1F0
	private static object BoxCastList_Internal(object physicsScene, object origin, object size, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745A3BC
	public object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object layerMask) { }

	// RVA: 0x745A6A0
	public object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter) { }

	// RVA: 0x745A4D8
	private static object CapsuleCast_Internal(object physicsScene, object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter) { }

	// RVA: 0x745A8EC
	public object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object results, object layerMask) { }

	// RVA: 0x745AB60
	public object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745A9D8
	private static object CapsuleCastArray_Internal(object physicsScene, object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745AD5C
	public object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745AE08
	private static object CapsuleCastList_Internal(object physicsScene, object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745AFF4
	public object GetRayIntersection(object ray, object distance, object layerMask) { }

	// RVA: 0x745B0B8
	private static object GetRayIntersection_Internal(object physicsScene, object origin, object direction, object distance, object layerMask) { }

	// RVA: 0x745B2B8
	public object GetRayIntersection(object ray, object distance, object results, object layerMask) { }

	// RVA: 0x745B358
	private static object GetRayIntersectionArray_Internal(object physicsScene, object origin, object direction, object distance, object layerMask, object results) { }

	// RVA: 0x745B520
	public object OverlapPoint(object point, object layerMask) { }

	// RVA: 0x745B694
	public object OverlapPoint(object point, object contactFilter) { }

	// RVA: 0x745B5AC
	private static object OverlapPoint_Internal(object physicsScene, object point, object contactFilter) { }

	// RVA: 0x745B7D8
	public object OverlapPoint(object point, object results, object layerMask) { }

	// RVA: 0x745B96C
	public object OverlapPoint(object point, object contactFilter, object results) { }

	// RVA: 0x745B86C
	private static object OverlapPointArray_Internal(object physicsScene, object point, object contactFilter, object results) { }

	// RVA: 0x745BAD4
	public object OverlapPoint(object point, object contactFilter, object results) { }

	// RVA: 0x745BB48
	private static object OverlapPointList_Internal(object physicsScene, object point, object contactFilter, object results) { }

	// RVA: 0x745BCA8
	public object OverlapCircle(object point, object radius, object layerMask) { }

	// RVA: 0x745BE4C
	public object OverlapCircle(object point, object radius, object contactFilter) { }

	// RVA: 0x745BD44
	private static object OverlapCircle_Internal(object physicsScene, object point, object radius, object contactFilter) { }

	// RVA: 0x745BFC4
	public object OverlapCircle(object point, object radius, object results, object layerMask) { }

	// RVA: 0x745C188
	public object OverlapCircle(object point, object radius, object contactFilter, object results) { }

	// RVA: 0x745C068
	private static object OverlapCircleArray_Internal(object physicsScene, object point, object radius, object contactFilter, object results) { }

	// RVA: 0x745C324
	public object OverlapCircle(object point, object radius, object contactFilter, object results) { }

	// RVA: 0x745C3A8
	private static object OverlapCircleList_Internal(object physicsScene, object point, object radius, object contactFilter, object results) { }

	// RVA: 0x745C53C
	public object OverlapBox(object point, object size, object angle, object layerMask) { }

	// RVA: 0x745C718
	public object OverlapBox(object point, object size, object angle, object contactFilter) { }

	// RVA: 0x745C5F0
	private static object OverlapBox_Internal(object physicsScene, object point, object size, object angle, object contactFilter) { }

	// RVA: 0x745C8B4
	public object OverlapBox(object point, object size, object angle, object results, object layerMask) { }

	// RVA: 0x745CAB0
	public object OverlapBox(object point, object size, object angle, object contactFilter, object results) { }

	// RVA: 0x745C970
	private static object OverlapBoxArray_Internal(object physicsScene, object point, object size, object angle, object contactFilter, object results) { }

	// RVA: 0x745CC64
	public object OverlapBox(object point, object size, object angle, object contactFilter, object results) { }

	// RVA: 0x745CCF0
	private static object OverlapBoxList_Internal(object physicsScene, object point, object size, object angle, object contactFilter, object results) { }

	// RVA: 0x745CE9C
	public object OverlapArea(object pointA, object pointB, object layerMask) { }

	// RVA: 0x745D0C4
	public object OverlapArea(object pointA, object pointB, object contactFilter) { }

	// RVA: 0x745CFB8
	private object OverlapAreaToBoxArray_Internal(object pointA, object pointB, object contactFilter) { }

	// RVA: 0x745D3F4
	public object OverlapArea(object pointA, object pointB, object results, object layerMask) { }

	// RVA: 0x745D634
	public object OverlapArea(object pointA, object pointB, object contactFilter, object results) { }

	// RVA: 0x745D518
	private object OverlapAreaToBoxArray_Internal(object pointA, object pointB, object contactFilter, object results) { }

	// RVA: 0x745D97C
	public object OverlapArea(object pointA, object pointB, object contactFilter, object results) { }

	// RVA: 0x745DA94
	private object OverlapAreaToBoxList_Internal(object pointA, object pointB, object contactFilter, object results) { }

	// RVA: 0x745DDD8
	public object OverlapCapsule(object point, object size, object direction, object angle, object layerMask) { }

	// RVA: 0x745DFD4
	public object OverlapCapsule(object point, object size, object direction, object angle, object contactFilter) { }

	// RVA: 0x745DE94
	private static object OverlapCapsule_Internal(object physicsScene, object point, object size, object direction, object angle, object contactFilter) { }

	// RVA: 0x745E188
	public object OverlapCapsule(object point, object size, object direction, object angle, object results, object layerMask) { }

	// RVA: 0x745E3AC
	public object OverlapCapsule(object point, object size, object direction, object angle, object contactFilter, object results) { }

	// RVA: 0x745E254
	private static object OverlapCapsuleArray_Internal(object physicsScene, object point, object size, object direction, object angle, object contactFilter, object results) { }

	// RVA: 0x745E578
	public object OverlapCapsule(object point, object size, object direction, object angle, object contactFilter, object results) { }

	// RVA: 0x745E614
	private static object OverlapCapsuleList_Internal(object physicsScene, object point, object size, object direction, object angle, object contactFilter, object results) { }

	// RVA: 0x745E7D0
	public static object OverlapCollider(object collider, object contactFilter, object results) { }

	// RVA: 0x745E844
	private static object OverlapColliderArray_Internal(object collider, object contactFilter, object results) { }

	// RVA: 0x745E91C
	public static object OverlapCollider(object collider, object contactFilter, object results) { }

	// RVA: 0x745E990
	private static object OverlapColliderList_Internal(object collider, object contactFilter, object results) { }

	// RVA: 0x7457D7C
	private static object Linecast_Internal_Injected(object physicsScene, object start, object end, object contactFilter, object ret) { }

	// RVA: 0x74580C8
	private static object LinecastArray_Internal_Injected(object physicsScene, object start, object end, object contactFilter, object results) { }

	// RVA: 0x74582BC
	private static object LinecastNonAllocList_Internal_Injected(object physicsScene, object start, object end, object contactFilter, object results) { }

	// RVA: 0x7458708
	private static object Raycast_Internal_Injected(object physicsScene, object origin, object direction, object distance, object contactFilter, object ret) { }

	// RVA: 0x7458AB8
	private static object RaycastArray_Internal_Injected(object physicsScene, object origin, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7458CF0
	private static object RaycastList_Internal_Injected(object physicsScene, object origin, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7459178
	private static object CircleCast_Internal_Injected(object physicsScene, object origin, object radius, object direction, object distance, object contactFilter, object ret) { }

	// RVA: 0x7459558
	private static object CircleCastArray_Internal_Injected(object physicsScene, object origin, object radius, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x74597B0
	private static object CircleCastList_Internal_Injected(object physicsScene, object origin, object radius, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7459C98
	private static object BoxCast_Internal_Injected(object physicsScene, object origin, object size, object angle, object direction, object distance, object contactFilter, object ret) { }

	// RVA: 0x745A0B8
	private static object BoxCastArray_Internal_Injected(object physicsScene, object origin, object size, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745A320
	private static object BoxCastList_Internal_Injected(object physicsScene, object origin, object size, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745A848
	private static object CapsuleCast_Internal_Injected(object physicsScene, object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter, object ret) { }

	// RVA: 0x745ACB8
	private static object CapsuleCastArray_Internal_Injected(object physicsScene, object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745AF50
	private static object CapsuleCastList_Internal_Injected(object physicsScene, object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x745B21C
	private static object GetRayIntersection_Internal_Injected(object physicsScene, object origin, object direction, object distance, object layerMask, object ret) { }

	// RVA: 0x745B484
	private static object GetRayIntersectionArray_Internal_Injected(object physicsScene, object origin, object direction, object distance, object layerMask, object results) { }

	// RVA: 0x745B76C
	private static object OverlapPoint_Internal_Injected(object physicsScene, object point, object contactFilter) { }

	// RVA: 0x745BA54
	private static object OverlapPointArray_Internal_Injected(object physicsScene, object point, object contactFilter, object results) { }

	// RVA: 0x745BC28
	private static object OverlapPointList_Internal_Injected(object physicsScene, object point, object contactFilter, object results) { }

	// RVA: 0x745BF44
	private static object OverlapCircle_Internal_Injected(object physicsScene, object point, object radius, object contactFilter) { }

	// RVA: 0x745C290
	private static object OverlapCircleArray_Internal_Injected(object physicsScene, object point, object radius, object contactFilter, object results) { }

	// RVA: 0x745C4A8
	private static object OverlapCircleList_Internal_Injected(object physicsScene, object point, object radius, object contactFilter, object results) { }

	// RVA: 0x745C820
	private static object OverlapBox_Internal_Injected(object physicsScene, object point, object size, object angle, object contactFilter) { }

	// RVA: 0x745CBC8
	private static object OverlapBoxArray_Internal_Injected(object physicsScene, object point, object size, object angle, object contactFilter, object results) { }

	// RVA: 0x745CE00
	private static object OverlapBoxList_Internal_Injected(object physicsScene, object point, object size, object angle, object contactFilter, object results) { }

	// RVA: 0x745E0EC
	private static object OverlapCapsule_Internal_Injected(object physicsScene, object point, object size, object direction, object angle, object contactFilter) { }

	// RVA: 0x745E4E4
	private static object OverlapCapsuleArray_Internal_Injected(object physicsScene, object point, object size, object direction, object angle, object contactFilter, object results) { }

	// RVA: 0x745E73C
	private static object OverlapCapsuleList_Internal_Injected(object physicsScene, object point, object size, object direction, object angle, object contactFilter, object results) { }

	// RVA: 0x745E8B0
	private static object OverlapColliderArray_Internal_Injected(object collider, object contactFilter, object results) { }

	// RVA: 0x745E9FC
	private static object OverlapColliderList_Internal_Injected(object collider, object contactFilter, object results) { }

}

// Namespace: UnityEngine
public class Physics2D
{

	// Fields
	public const object IgnoreRaycastLayer;
	public const object DefaultRaycastLayers;
	public const object AllLayers;
	public const object MaxPolygonShapeVertices;
	private static object m_LastDisabledRigidbody2D; // 0x0
	private static object <alwaysShowColliders>k__BackingField; // 0x8
	private static object <showCollidersFilled>k__BackingField; // 0x9
	private static object <showColliderSleep>k__BackingField; // 0xA
	private static object <showColliderContacts>k__BackingField; // 0xB

	// Properties
	public static object defaultPhysicsScene { get; }
	public static object velocityIterations { get; set; }
	public static object positionIterations { get; set; }
	public static object gravity { get; set; }
	public static object queriesHitTriggers { get; set; }
	public static object queriesStartInColliders { get; set; }
	public static object callbacksOnDisable { get; set; }
	public static object reuseCollisionCallbacks { get; set; }
	public static object autoSyncTransforms { get; set; }
	public static object simulationMode { get; set; }
	public static object jobOptions { get; set; }
	public static object velocityThreshold { get; set; }
	public static object maxLinearCorrection { get; set; }
	public static object maxAngularCorrection { get; set; }
	public static object maxTranslationSpeed { get; set; }
	public static object maxRotationSpeed { get; set; }
	public static object defaultContactOffset { get; set; }
	public static object baumgarteScale { get; set; }
	public static object baumgarteTOIScale { get; set; }
	public static object timeToSleep { get; set; }
	public static object linearSleepTolerance { get; set; }
	public static object angularSleepTolerance { get; set; }
	public static object raycastsHitTriggers { get; set; }
	public static object raycastsStartInColliders { get; set; }
	public static object deleteStopsCallbacks { get; set; }
	public static object changeStopsCallbacks { get; set; }
	public static object minPenetrationForPenalty { get; set; }
	public static object autoSimulation { get; set; }
	public static object colliderAwakeColor { get; set; }
	public static object colliderAsleepColor { get; set; }
	public static object colliderContactColor { get; set; }
	public static object colliderAABBColor { get; set; }
	public static object contactArrowScale { get; set; }
	public static object alwaysShowColliders { get; set; }
	public static object showCollidersFilled { get; set; }
	public static object showColliderSleep { get; set; }
	public static object showColliderContacts { get; set; }
	public static object showColliderAABB { get; set; }

	// Methods

	// RVA: 0x745EA68
	public static object get_defaultPhysicsScene() { }

	// RVA: 0x745EA70
	public static object get_velocityIterations() { }

	// RVA: 0x745EAB0
	public static object set_velocityIterations(object value) { }

	// RVA: 0x745EB00
	public static object get_positionIterations() { }

	// RVA: 0x745EB40
	public static object set_positionIterations(object value) { }

	// RVA: 0x745EB90
	public static object get_gravity() { }

	// RVA: 0x745EC88
	public static object set_gravity(object value) { }

	// RVA: 0x745ED8C
	public static object get_queriesHitTriggers() { }

	// RVA: 0x745EDCC
	public static object set_queriesHitTriggers(object value) { }

	// RVA: 0x745EE1C
	public static object get_queriesStartInColliders() { }

	// RVA: 0x745EE5C
	public static object set_queriesStartInColliders(object value) { }

	// RVA: 0x745EEAC
	public static object get_callbacksOnDisable() { }

	// RVA: 0x745EEEC
	public static object set_callbacksOnDisable(object value) { }

	// RVA: 0x745EF3C
	public static object get_reuseCollisionCallbacks() { }

	// RVA: 0x745EF7C
	public static object set_reuseCollisionCallbacks(object value) { }

	// RVA: 0x745EFCC
	public static object get_autoSyncTransforms() { }

	// RVA: 0x745F00C
	public static object set_autoSyncTransforms(object value) { }

	// RVA: 0x745F05C
	public static object get_simulationMode() { }

	// RVA: 0x745F09C
	public static object set_simulationMode(object value) { }

	// RVA: 0x745F0EC
	public static object get_jobOptions() { }

	// RVA: 0x745F20C
	public static object set_jobOptions(object value) { }

	// RVA: 0x745F308
	public static object get_velocityThreshold() { }

	// RVA: 0x745F348
	public static object set_velocityThreshold(object value) { }

	// RVA: 0x745F39C
	public static object get_maxLinearCorrection() { }

	// RVA: 0x745F3DC
	public static object set_maxLinearCorrection(object value) { }

	// RVA: 0x745F430
	public static object get_maxAngularCorrection() { }

	// RVA: 0x745F470
	public static object set_maxAngularCorrection(object value) { }

	// RVA: 0x745F4C4
	public static object get_maxTranslationSpeed() { }

	// RVA: 0x745F504
	public static object set_maxTranslationSpeed(object value) { }

	// RVA: 0x745F558
	public static object get_maxRotationSpeed() { }

	// RVA: 0x745F598
	public static object set_maxRotationSpeed(object value) { }

	// RVA: 0x745F5EC
	public static object get_defaultContactOffset() { }

	// RVA: 0x745F62C
	public static object set_defaultContactOffset(object value) { }

	// RVA: 0x745F680
	public static object get_baumgarteScale() { }

	// RVA: 0x745F6C0
	public static object set_baumgarteScale(object value) { }

	// RVA: 0x745F714
	public static object get_baumgarteTOIScale() { }

	// RVA: 0x745F754
	public static object set_baumgarteTOIScale(object value) { }

	// RVA: 0x745F7A8
	public static object get_timeToSleep() { }

	// RVA: 0x745F7E8
	public static object set_timeToSleep(object value) { }

	// RVA: 0x745F83C
	public static object get_linearSleepTolerance() { }

	// RVA: 0x745F87C
	public static object set_linearSleepTolerance(object value) { }

	// RVA: 0x745F8D0
	public static object get_angularSleepTolerance() { }

	// RVA: 0x745F910
	public static object set_angularSleepTolerance(object value) { }

	// RVA: 0x745F964
	public static object Simulate(object step) { }

	// RVA: 0x745FA60
	internal static object Simulate_Internal(object physicsScene, object step) { }

	// RVA: 0x745FB74
	public static object SyncTransforms() { }

	// RVA: 0x745FBB4
	public static object IgnoreCollision(object collider1, object collider2) { }

	// RVA: 0x745FC5C
	public static object IgnoreCollision(object collider1, object collider2, object ignore) { }

	// RVA: 0x745FCC8
	public static object GetIgnoreCollision(object collider1, object collider2) { }

	// RVA: 0x745FD2C
	public static object IgnoreLayerCollision(object layer1, object layer2) { }

	// RVA: 0x745FD98
	public static object IgnoreLayerCollision(object layer1, object layer2, object ignore) { }

	// RVA: 0x745FEB0
	private static object IgnoreLayerCollision_Internal(object layer1, object layer2, object ignore) { }

	// RVA: 0x745FF1C
	public static object GetIgnoreLayerCollision(object layer1, object layer2) { }

	// RVA: 0x7460040
	private static object GetIgnoreLayerCollision_Internal(object layer1, object layer2) { }

	// RVA: 0x74600A4
	public static object SetLayerCollisionMask(object layer, object layerMask) { }

	// RVA: 0x74601A0
	private static object SetLayerCollisionMask_Internal(object layer, object layerMask) { }

	// RVA: 0x7460204
	public static object GetLayerCollisionMask(object layer) { }

	// RVA: 0x74602E8
	private static object GetLayerCollisionMask_Internal(object layer) { }

	// RVA: 0x7460338
	public static object IsTouching(object collider1, object collider2) { }

	// RVA: 0x746039C
	public static object IsTouching(object collider1, object collider2, object contactFilter) { }

	// RVA: 0x74604AC
	private static object IsTouching_TwoCollidersWithFilter(object collider1, object collider2, object contactFilter) { }

	// RVA: 0x74605CC
	public static object IsTouching(object collider, object contactFilter) { }

	// RVA: 0x74606CC
	private static object IsTouching_SingleColliderWithFilter(object collider, object contactFilter) { }

	// RVA: 0x74607E8
	public static object IsTouchingLayers(object collider) { }

	// RVA: 0x746089C
	public static object IsTouchingLayers(object collider, object layerMask) { }

	// RVA: 0x7460900
	public static object Distance(object colliderA, object colliderB) { }

	// RVA: 0x7460B78
	private static object Distance_Internal(object colliderA, object colliderB) { }

	// RVA: 0x7460CBC
	public static object ClosestPoint(object position, object collider) { }

	// RVA: 0x7460F2C
	public static object ClosestPoint(object position, object rigidbody) { }

	// RVA: 0x7460E6C
	private static object ClosestPoint_Collider(object position, object collider) { }

	// RVA: 0x74610DC
	private static object ClosestPoint_Rigidbody(object position, object rigidbody) { }

	// RVA: 0x7461274
	public static object Linecast(object start, object end) { }

	// RVA: 0x746137C
	public static object Linecast(object start, object end, object layerMask) { }

	// RVA: 0x74614A8
	public static object Linecast(object start, object end, object layerMask, object minDepth) { }

	// RVA: 0x74615E4
	public static object Linecast(object start, object end, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7461720
	public static object Linecast(object start, object end, object contactFilter, object results) { }

	// RVA: 0x74617FC
	public static object Linecast(object start, object end, object contactFilter, object results) { }

	// RVA: 0x74618D8
	public static object LinecastAll(object start, object end) { }

	// RVA: 0x7461AC8
	public static object LinecastAll(object start, object end, object layerMask) { }

	// RVA: 0x7461C08
	public static object LinecastAll(object start, object end, object layerMask, object minDepth) { }

	// RVA: 0x7461D50
	public static object LinecastAll(object start, object end, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7461A08
	private static object LinecastAll_Internal(object physicsScene, object start, object end, object contactFilter) { }

	// RVA: 0x7461F18
	public static object LinecastNonAlloc(object start, object end, object results) { }

	// RVA: 0x7461FFC
	public static object LinecastNonAlloc(object start, object end, object results, object layerMask) { }

	// RVA: 0x74620F4
	public static object LinecastNonAlloc(object start, object end, object results, object layerMask, object minDepth) { }

	// RVA: 0x74621F4
	public static object LinecastNonAlloc(object start, object end, object results, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x74622F4
	public static object Raycast(object origin, object direction) { }

	// RVA: 0x7462404
	public static object Raycast(object origin, object direction, object distance) { }

	// RVA: 0x746251C
	public static object Raycast(object origin, object direction, object distance, object layerMask) { }

	// RVA: 0x7462660
	public static object Raycast(object origin, object direction, object distance, object layerMask, object minDepth) { }

	// RVA: 0x74627A4
	public static object Raycast(object origin, object direction, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x74628F0
	public static object Raycast(object origin, object direction, object contactFilter, object results) { }

	// RVA: 0x74629D4
	public static object Raycast(object origin, object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7462AC0
	public static object Raycast(object origin, object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7462BAC
	public static object RaycastNonAlloc(object origin, object direction, object results) { }

	// RVA: 0x7462C98
	public static object RaycastNonAlloc(object origin, object direction, object results, object distance) { }

	// RVA: 0x7462D8C
	public static object RaycastNonAlloc(object origin, object direction, object results, object distance, object layerMask) { }

	// RVA: 0x7462E94
	public static object RaycastNonAlloc(object origin, object direction, object results, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7462F9C
	public static object RaycastNonAlloc(object origin, object direction, object results, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x74630AC
	public static object RaycastAll(object origin, object direction) { }

	// RVA: 0x74632B4
	public static object RaycastAll(object origin, object direction, object distance) { }

	// RVA: 0x74633F4
	public static object RaycastAll(object origin, object direction, object distance, object layerMask) { }

	// RVA: 0x7463544
	public static object RaycastAll(object origin, object direction, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7463694
	public static object RaycastAll(object origin, object direction, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x74631E4
	private static object RaycastAll_Internal(object physicsScene, object origin, object direction, object distance, object contactFilter) { }

	// RVA: 0x7463880
	public static object CircleCast(object origin, object radius, object direction) { }

	// RVA: 0x74639A0
	public static object CircleCast(object origin, object radius, object direction, object distance) { }

	// RVA: 0x7463AC0
	public static object CircleCast(object origin, object radius, object direction, object distance, object layerMask) { }

	// RVA: 0x7463C0C
	public static object CircleCast(object origin, object radius, object direction, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7463D60
	public static object CircleCast(object origin, object radius, object direction, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7463EB4
	public static object CircleCast(object origin, object radius, object direction, object contactFilter, object results) { }

	// RVA: 0x7463FA8
	public static object CircleCast(object origin, object radius, object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x746409C
	public static object CircleCast(object origin, object radius, object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7464190
	public static object CircleCastAll(object origin, object radius, object direction) { }

	// RVA: 0x74643B0
	public static object CircleCastAll(object origin, object radius, object direction, object distance) { }

	// RVA: 0x74644F8
	public static object CircleCastAll(object origin, object radius, object direction, object distance, object layerMask) { }

	// RVA: 0x7464650
	public static object CircleCastAll(object origin, object radius, object direction, object distance, object layerMask, object minDepth) { }

	// RVA: 0x74647B0
	public static object CircleCastAll(object origin, object radius, object direction, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x74642D8
	private static object CircleCastAll_Internal(object physicsScene, object origin, object radius, object direction, object distance, object contactFilter) { }

	// RVA: 0x74649AC
	public static object CircleCastNonAlloc(object origin, object radius, object direction, object results) { }

	// RVA: 0x7464AA8
	public static object CircleCastNonAlloc(object origin, object radius, object direction, object results, object distance) { }

	// RVA: 0x7464BA4
	public static object CircleCastNonAlloc(object origin, object radius, object direction, object results, object distance, object layerMask) { }

	// RVA: 0x7464CB4
	public static object CircleCastNonAlloc(object origin, object radius, object direction, object results, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7464DCC
	public static object CircleCastNonAlloc(object origin, object radius, object direction, object results, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7464EE4
	public static object BoxCast(object origin, object size, object angle, object direction) { }

	// RVA: 0x746501C
	public static object BoxCast(object origin, object size, object angle, object direction, object distance) { }

	// RVA: 0x7465154
	public static object BoxCast(object origin, object size, object angle, object direction, object distance, object layerMask) { }

	// RVA: 0x74652AC
	public static object BoxCast(object origin, object size, object angle, object direction, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7465404
	public static object BoxCast(object origin, object size, object angle, object direction, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7465550
	public static object BoxCast(object origin, object size, object angle, object direction, object contactFilter, object results) { }

	// RVA: 0x746565C
	public static object BoxCast(object origin, object size, object angle, object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7465768
	public static object BoxCast(object origin, object size, object angle, object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7465874
	public static object BoxCastAll(object origin, object size, object angle, object direction) { }

	// RVA: 0x7465AB4
	public static object BoxCastAll(object origin, object size, object angle, object direction, object distance) { }

	// RVA: 0x7465C14
	public static object BoxCastAll(object origin, object size, object angle, object direction, object distance, object layerMask) { }

	// RVA: 0x7465D84
	public static object BoxCastAll(object origin, object size, object angle, object direction, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7465EF4
	public static object BoxCastAll(object origin, object size, object angle, object direction, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x74659D4
	private static object BoxCastAll_Internal(object physicsScene, object origin, object size, object angle, object direction, object distance, object contactFilter) { }

	// RVA: 0x74660FC
	public static object BoxCastNonAlloc(object origin, object size, object angle, object direction, object results) { }

	// RVA: 0x7466210
	public static object BoxCastNonAlloc(object origin, object size, object angle, object direction, object results, object distance) { }

	// RVA: 0x7466324
	public static object BoxCastNonAlloc(object origin, object size, object angle, object direction, object results, object distance, object layerMask) { }

	// RVA: 0x746644C
	public static object BoxCastNonAlloc(object origin, object size, object angle, object direction, object results, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7466574
	public static object BoxCastNonAlloc(object origin, object size, object angle, object direction, object results, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7466690
	public static object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction) { }

	// RVA: 0x74667D8
	public static object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance) { }

	// RVA: 0x7466920
	public static object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object layerMask) { }

	// RVA: 0x7466A7C
	public static object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7466BD8
	public static object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7466D28
	public static object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object contactFilter, object results) { }

	// RVA: 0x7466E44
	public static object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7466F60
	public static object CapsuleCast(object origin, object size, object capsuleDirection, object angle, object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x746707C
	public static object CapsuleCastAll(object origin, object size, object capsuleDirection, object angle, object direction) { }

	// RVA: 0x74672D4
	public static object CapsuleCastAll(object origin, object size, object capsuleDirection, object angle, object direction, object distance) { }

	// RVA: 0x74671EC
	private static object CapsuleCastAll_Internal(object physicsScene, object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter) { }

	// RVA: 0x74674E0
	public static object CapsuleCastAll(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object layerMask) { }

	// RVA: 0x7467654
	public static object CapsuleCastAll(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object layerMask, object minDepth) { }

	// RVA: 0x74677C8
	public static object CapsuleCastAll(object origin, object size, object capsuleDirection, object angle, object direction, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7467930
	public static object CapsuleCastNonAlloc(object origin, object size, object capsuleDirection, object angle, object direction, object results) { }

	// RVA: 0x7467A4C
	public static object CapsuleCastNonAlloc(object origin, object size, object capsuleDirection, object angle, object direction, object results, object distance) { }

	// RVA: 0x7467B68
	public static object CapsuleCastNonAlloc(object origin, object size, object capsuleDirection, object angle, object direction, object results, object distance, object layerMask) { }

	// RVA: 0x7467CA0
	public static object CapsuleCastNonAlloc(object origin, object size, object capsuleDirection, object angle, object direction, object results, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7467DD8
	public static object CapsuleCastNonAlloc(object origin, object size, object capsuleDirection, object angle, object direction, object results, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7467F04
	public static object GetRayIntersection(object ray) { }

	// RVA: 0x7468000
	public static object GetRayIntersection(object ray, object distance) { }

	// RVA: 0x7468104
	public static object GetRayIntersection(object ray, object distance, object layerMask) { }

	// RVA: 0x7468214
	public static object GetRayIntersectionAll(object ray) { }

	// RVA: 0x74683FC
	public static object GetRayIntersectionAll(object ray, object distance) { }

	// RVA: 0x7468514
	public static object GetRayIntersectionAll(object ray, object distance, object layerMask) { }

	// RVA: 0x7468324
	private static object GetRayIntersectionAll_Internal(object physicsScene, object origin, object direction, object distance, object layerMask) { }

	// RVA: 0x74686C4
	public static object GetRayIntersectionNonAlloc(object ray, object results) { }

	// RVA: 0x7468790
	public static object GetRayIntersectionNonAlloc(object ray, object results, object distance) { }

	// RVA: 0x7468864
	public static object GetRayIntersectionNonAlloc(object ray, object results, object distance, object layerMask) { }

	// RVA: 0x7468944
	public static object OverlapPoint(object point) { }

	// RVA: 0x7468A00
	public static object OverlapPoint(object point, object layerMask) { }

	// RVA: 0x7468ADC
	public static object OverlapPoint(object point, object layerMask, object minDepth) { }

	// RVA: 0x7468BC0
	public static object OverlapPoint(object point, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7468CA4
	public static object OverlapPoint(object point, object contactFilter, object results) { }

	// RVA: 0x7468D68
	public static object OverlapPoint(object point, object contactFilter, object results) { }

	// RVA: 0x7468E2C
	public static object OverlapPointAll(object point) { }

	// RVA: 0x7468FFC
	public static object OverlapPointAll(object point, object layerMask) { }

	// RVA: 0x7469124
	public static object OverlapPointAll(object point, object layerMask, object minDepth) { }

	// RVA: 0x7469254
	public static object OverlapPointAll(object point, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7468F44
	private static object OverlapPointAll_Internal(object physicsScene, object point, object contactFilter) { }

	// RVA: 0x74693F0
	public static object OverlapPointNonAlloc(object point, object results) { }

	// RVA: 0x74694BC
	public static object OverlapPointNonAlloc(object point, object results, object layerMask) { }

	// RVA: 0x746959C
	public static object OverlapPointNonAlloc(object point, object results, object layerMask, object minDepth) { }

	// RVA: 0x7469684
	public static object OverlapPointNonAlloc(object point, object results, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746976C
	public static object OverlapCircle(object point, object radius) { }

	// RVA: 0x7469838
	public static object OverlapCircle(object point, object radius, object layerMask) { }

	// RVA: 0x7469924
	public static object OverlapCircle(object point, object radius, object layerMask, object minDepth) { }

	// RVA: 0x7469A10
	public static object OverlapCircle(object point, object radius, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7469B04
	public static object OverlapCircle(object point, object radius, object contactFilter, object results) { }

	// RVA: 0x7469BD8
	public static object OverlapCircle(object point, object radius, object contactFilter, object results) { }

	// RVA: 0x7469CAC
	public static object OverlapCircleAll(object point, object radius) { }

	// RVA: 0x7469E9C
	public static object OverlapCircleAll(object point, object radius, object layerMask) { }

	// RVA: 0x7469FD4
	public static object OverlapCircleAll(object point, object radius, object layerMask, object minDepth) { }

	// RVA: 0x746A10C
	public static object OverlapCircleAll(object point, object radius, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7469DD4
	private static object OverlapCircleAll_Internal(object physicsScene, object point, object radius, object contactFilter) { }

	// RVA: 0x746A2CC
	public static object OverlapCircleNonAlloc(object point, object radius, object results) { }

	// RVA: 0x746A3A8
	public static object OverlapCircleNonAlloc(object point, object radius, object results, object layerMask) { }

	// RVA: 0x746A498
	public static object OverlapCircleNonAlloc(object point, object radius, object results, object layerMask, object minDepth) { }

	// RVA: 0x746A588
	public static object OverlapCircleNonAlloc(object point, object radius, object results, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746A680
	public static object OverlapBox(object point, object size, object angle) { }

	// RVA: 0x746A764
	public static object OverlapBox(object point, object size, object angle, object layerMask) { }

	// RVA: 0x746A868
	public static object OverlapBox(object point, object size, object angle, object layerMask, object minDepth) { }

	// RVA: 0x746A96C
	public static object OverlapBox(object point, object size, object angle, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746AA78
	public static object OverlapBox(object point, object size, object angle, object contactFilter, object results) { }

	// RVA: 0x746AB64
	public static object OverlapBox(object point, object size, object angle, object contactFilter, object results) { }

	// RVA: 0x746AC50
	public static object OverlapBoxAll(object point, object size, object angle) { }

	// RVA: 0x746AE60
	public static object OverlapBoxAll(object point, object size, object angle, object layerMask) { }

	// RVA: 0x746AFB0
	public static object OverlapBoxAll(object point, object size, object angle, object layerMask, object minDepth) { }

	// RVA: 0x746B100
	public static object OverlapBoxAll(object point, object size, object angle, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746AD90
	private static object OverlapBoxAll_Internal(object physicsScene, object point, object size, object angle, object contactFilter) { }

	// RVA: 0x746B2EC
	public static object OverlapBoxNonAlloc(object point, object size, object angle, object results) { }

	// RVA: 0x746B3E0
	public static object OverlapBoxNonAlloc(object point, object size, object angle, object results, object layerMask) { }

	// RVA: 0x746B4E8
	public static object OverlapBoxNonAlloc(object point, object size, object angle, object results, object layerMask, object minDepth) { }

	// RVA: 0x746B5F0
	public static object OverlapBoxNonAlloc(object point, object size, object angle, object results, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746B700
	public static object OverlapArea(object pointA, object pointB) { }

	// RVA: 0x746B798
	public static object OverlapArea(object pointA, object pointB, object layerMask) { }

	// RVA: 0x746B904
	public static object OverlapArea(object pointA, object pointB, object layerMask, object minDepth) { }

	// RVA: 0x746BA70
	public static object OverlapArea(object pointA, object pointB, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746BBDC
	public static object OverlapArea(object pointA, object pointB, object contactFilter, object results) { }

	// RVA: 0x746BD28
	public static object OverlapArea(object pointA, object pointB, object contactFilter, object results) { }

	// RVA: 0x746BE74
	public static object OverlapAreaAll(object pointA, object pointB) { }

	// RVA: 0x746C008
	public static object OverlapAreaAll(object pointA, object pointB, object layerMask) { }

	// RVA: 0x746C0A8
	public static object OverlapAreaAll(object pointA, object pointB, object layerMask, object minDepth) { }

	// RVA: 0x746C150
	public static object OverlapAreaAll(object pointA, object pointB, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746BF08
	private static object OverlapAreaAllToBox_Internal(object pointA, object pointB, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746C1F8
	public static object OverlapAreaNonAlloc(object pointA, object pointB, object results) { }

	// RVA: 0x746C2A0
	public static object OverlapAreaNonAlloc(object pointA, object pointB, object results, object layerMask) { }

	// RVA: 0x746C410
	public static object OverlapAreaNonAlloc(object pointA, object pointB, object results, object layerMask, object minDepth) { }

	// RVA: 0x746C580
	public static object OverlapAreaNonAlloc(object pointA, object pointB, object results, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746C6F0
	public static object OverlapCapsule(object point, object size, object direction, object angle) { }

	// RVA: 0x746C7E4
	public static object OverlapCapsule(object point, object size, object direction, object angle, object layerMask) { }

	// RVA: 0x746C8EC
	public static object OverlapCapsule(object point, object size, object direction, object angle, object layerMask, object minDepth) { }

	// RVA: 0x746C9F4
	public static object OverlapCapsule(object point, object size, object direction, object angle, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746CB04
	public static object OverlapCapsule(object point, object size, object direction, object angle, object contactFilter, object results) { }

	// RVA: 0x746CC00
	public static object OverlapCapsule(object point, object size, object direction, object angle, object contactFilter, object results) { }

	// RVA: 0x746CCFC
	public static object OverlapCapsuleAll(object point, object size, object direction, object angle) { }

	// RVA: 0x746CF24
	public static object OverlapCapsuleAll(object point, object size, object direction, object angle, object layerMask) { }

	// RVA: 0x746D078
	public static object OverlapCapsuleAll(object point, object size, object direction, object angle, object layerMask, object minDepth) { }

	// RVA: 0x746D1CC
	public static object OverlapCapsuleAll(object point, object size, object direction, object angle, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746CE4C
	private static object OverlapCapsuleAll_Internal(object physicsScene, object point, object size, object direction, object angle, object contactFilter) { }

	// RVA: 0x746D3C4
	public static object OverlapCapsuleNonAlloc(object point, object size, object direction, object angle, object results) { }

	// RVA: 0x746D4C0
	public static object OverlapCapsuleNonAlloc(object point, object size, object direction, object angle, object results, object layerMask) { }

	// RVA: 0x746D5D8
	public static object OverlapCapsuleNonAlloc(object point, object size, object direction, object angle, object results, object layerMask, object minDepth) { }

	// RVA: 0x746D6F0
	public static object OverlapCapsuleNonAlloc(object point, object size, object direction, object angle, object results, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x746D810
	public static object OverlapCollider(object collider, object contactFilter, object results) { }

	// RVA: 0x746D884
	public static object OverlapCollider(object collider, object contactFilter, object results) { }

	// RVA: 0x746D8F8
	public static object GetContacts(object collider1, object collider2, object contactFilter, object contacts) { }

	// RVA: 0x746DACC
	public static object GetContacts(object collider, object contacts) { }

	// RVA: 0x746DCEC
	public static object GetContacts(object collider, object contactFilter, object contacts) { }

	// RVA: 0x746DDFC
	public static object GetContacts(object collider, object colliders) { }

	// RVA: 0x746DFC4
	public static object GetContacts(object collider, object contactFilter, object colliders) { }

	// RVA: 0x746E0D4
	public static object GetContacts(object rigidbody, object contacts) { }

	// RVA: 0x746E29C
	public static object GetContacts(object rigidbody, object contactFilter, object contacts) { }

	// RVA: 0x746E3AC
	public static object GetContacts(object rigidbody, object colliders) { }

	// RVA: 0x746E574
	public static object GetContacts(object rigidbody, object contactFilter, object colliders) { }

	// RVA: 0x746DC38
	private static object GetColliderContactsArray(object collider, object contactFilter, object results) { }

	// RVA: 0x746DA10
	private static object GetColliderColliderContactsArray(object collider1, object collider2, object contactFilter, object results) { }

	// RVA: 0x746E1E8
	private static object GetRigidbodyContactsArray(object rigidbody, object contactFilter, object results) { }

	// RVA: 0x746DF10
	private static object GetColliderContactsCollidersOnlyArray(object collider, object contactFilter, object results) { }

	// RVA: 0x746E4C0
	private static object GetRigidbodyContactsCollidersOnlyArray(object rigidbody, object contactFilter, object results) { }

	// RVA: 0x746E8B4
	public static object GetContacts(object collider1, object collider2, object contactFilter, object contacts) { }

	// RVA: 0x746EA88
	public static object GetContacts(object collider, object contacts) { }

	// RVA: 0x746EC50
	public static object GetContacts(object collider, object contactFilter, object contacts) { }

	// RVA: 0x746ED60
	public static object GetContacts(object collider, object colliders) { }

	// RVA: 0x746EF28
	public static object GetContacts(object collider, object contactFilter, object colliders) { }

	// RVA: 0x746F038
	public static object GetContacts(object rigidbody, object contacts) { }

	// RVA: 0x746F200
	public static object GetContacts(object rigidbody, object contactFilter, object contacts) { }

	// RVA: 0x746F310
	public static object GetContacts(object rigidbody, object colliders) { }

	// RVA: 0x746F4D8
	public static object GetContacts(object rigidbody, object contactFilter, object colliders) { }

	// RVA: 0x746EB9C
	private static object GetColliderContactsList(object collider, object contactFilter, object results) { }

	// RVA: 0x746E9CC
	private static object GetColliderColliderContactsList(object collider1, object collider2, object contactFilter, object results) { }

	// RVA: 0x746F14C
	private static object GetRigidbodyContactsList(object rigidbody, object contactFilter, object results) { }

	// RVA: 0x746EE74
	private static object GetColliderContactsCollidersOnlyList(object collider, object contactFilter, object results) { }

	// RVA: 0x746F424
	private static object GetRigidbodyContactsCollidersOnlyList(object rigidbody, object contactFilter, object results) { }

	// RVA: 0x746F818
	internal static object SetEditorDragMovement(object dragging, object objs) { }

	// RVA: 0x746FD38
	public static object get_raycastsHitTriggers() { }

	// RVA: 0x746FD40
	public static object set_raycastsHitTriggers(object value) { }

	// RVA: 0x746FD44
	public static object get_raycastsStartInColliders() { }

	// RVA: 0x746FD4C
	public static object set_raycastsStartInColliders(object value) { }

	// RVA: 0x746FD50
	public static object get_deleteStopsCallbacks() { }

	// RVA: 0x746FD58
	public static object set_deleteStopsCallbacks(object value) { }

	// RVA: 0x746FD5C
	public static object get_changeStopsCallbacks() { }

	// RVA: 0x746FD64
	public static object set_changeStopsCallbacks(object value) { }

	// RVA: 0x746FD68
	public static object get_minPenetrationForPenalty() { }

	// RVA: 0x746FDF8
	public static object set_minPenetrationForPenalty(object value) { }

	// RVA: 0x746FEA0
	public static object get_autoSimulation() { }

	// RVA: 0x746FF48
	public static object set_autoSimulation(object value) { }

	// RVA: 0x746FFEC
	public static object get_colliderAwakeColor() { }

	// RVA: 0x7470000
	public static object set_colliderAwakeColor(object value) { }

	// RVA: 0x7470004
	public static object get_colliderAsleepColor() { }

	// RVA: 0x7470018
	public static object set_colliderAsleepColor(object value) { }

	// RVA: 0x747001C
	public static object get_colliderContactColor() { }

	// RVA: 0x7470030
	public static object set_colliderContactColor(object value) { }

	// RVA: 0x7470034
	public static object get_colliderAABBColor() { }

	// RVA: 0x7470048
	public static object set_colliderAABBColor(object value) { }

	// RVA: 0x747004C
	public static object get_contactArrowScale() { }

	// RVA: 0x747005C
	public static object set_contactArrowScale(object value) { }

	// RVA: 0x7470060
	public static object get_alwaysShowColliders() { }

	// RVA: 0x74700DC
	public static object set_alwaysShowColliders(object value) { }

	// RVA: 0x7470168
	public static object get_showCollidersFilled() { }

	// RVA: 0x74701E4
	public static object set_showCollidersFilled(object value) { }

	// RVA: 0x7470270
	public static object get_showColliderSleep() { }

	// RVA: 0x74702EC
	public static object set_showColliderSleep(object value) { }

	// RVA: 0x7470378
	public static object get_showColliderContacts() { }

	// RVA: 0x74703F4
	public static object set_showColliderContacts(object value) { }

	// RVA: 0x7470480
	public static object get_showColliderAABB() { }

	// RVA: 0x7470488
	public static object set_showColliderAABB(object value) { }

	// RVA: 0x747048C
	public object .ctor() { }

	// RVA: 0x7470494
	private static object .cctor() { }

	// RVA: 0x745EC38
	private static object get_gravity_Injected(object ret) { }

	// RVA: 0x745ED3C
	private static object set_gravity_Injected(object value) { }

	// RVA: 0x745F1BC
	private static object get_jobOptions_Injected(object ret) { }

	// RVA: 0x745F2B8
	private static object set_jobOptions_Injected(object value) { }

	// RVA: 0x745FB10
	private static object Simulate_Internal_Injected(object physicsScene, object step) { }

	// RVA: 0x7460560
	private static object IsTouching_TwoCollidersWithFilter_Injected(object collider1, object collider2, object contactFilter) { }

	// RVA: 0x7460784
	private static object IsTouching_SingleColliderWithFilter_Injected(object collider, object contactFilter) { }

	// RVA: 0x7460C50
	private static object Distance_Internal_Injected(object colliderA, object colliderB, object ret) { }

	// RVA: 0x746119C
	private static object ClosestPoint_Collider_Injected(object position, object collider, object ret) { }

	// RVA: 0x7461208
	private static object ClosestPoint_Rigidbody_Injected(object position, object rigidbody, object ret) { }

	// RVA: 0x7461E98
	private static object LinecastAll_Internal_Injected(object physicsScene, object start, object end, object contactFilter) { }

	// RVA: 0x74637EC
	private static object RaycastAll_Internal_Injected(object physicsScene, object origin, object direction, object distance, object contactFilter) { }

	// RVA: 0x7464910
	private static object CircleCastAll_Internal_Injected(object physicsScene, object origin, object radius, object direction, object distance, object contactFilter) { }

	// RVA: 0x7466058
	private static object BoxCastAll_Internal_Injected(object physicsScene, object origin, object size, object angle, object direction, object distance, object contactFilter) { }

	// RVA: 0x7467444
	private static object CapsuleCastAll_Internal_Injected(object physicsScene, object origin, object size, object capsuleDirection, object angle, object direction, object distance, object contactFilter) { }

	// RVA: 0x7468630
	private static object GetRayIntersectionAll_Internal_Injected(object physicsScene, object origin, object direction, object distance, object layerMask) { }

	// RVA: 0x7469384
	private static object OverlapPointAll_Internal_Injected(object physicsScene, object point, object contactFilter) { }

	// RVA: 0x746A24C
	private static object OverlapCircleAll_Internal_Injected(object physicsScene, object point, object radius, object contactFilter) { }

	// RVA: 0x746B258
	private static object OverlapBoxAll_Internal_Injected(object physicsScene, object point, object size, object angle, object contactFilter) { }

	// RVA: 0x746D328
	private static object OverlapCapsuleAll_Internal_Injected(object physicsScene, object point, object size, object direction, object angle, object contactFilter) { }

	// RVA: 0x746E684
	private static object GetColliderContactsArray_Injected(object collider, object contactFilter, object results) { }

	// RVA: 0x746E6F0
	private static object GetColliderColliderContactsArray_Injected(object collider1, object collider2, object contactFilter, object results) { }

	// RVA: 0x746E770
	private static object GetRigidbodyContactsArray_Injected(object rigidbody, object contactFilter, object results) { }

	// RVA: 0x746E7DC
	private static object GetColliderContactsCollidersOnlyArray_Injected(object collider, object contactFilter, object results) { }

	// RVA: 0x746E848
	private static object GetRigidbodyContactsCollidersOnlyArray_Injected(object rigidbody, object contactFilter, object results) { }

	// RVA: 0x746F5E8
	private static object GetColliderContactsList_Injected(object collider, object contactFilter, object results) { }

	// RVA: 0x746F654
	private static object GetColliderColliderContactsList_Injected(object collider1, object collider2, object contactFilter, object results) { }

	// RVA: 0x746F6D4
	private static object GetRigidbodyContactsList_Injected(object rigidbody, object contactFilter, object results) { }

	// RVA: 0x746F740
	private static object GetColliderContactsCollidersOnlyList_Injected(object collider, object contactFilter, object results) { }

	// RVA: 0x746F7AC
	private static object GetRigidbodyContactsCollidersOnlyList_Injected(object rigidbody, object contactFilter, object results) { }

}

// Namespace: UnityEngine
public enum SimulationMode2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FixedUpdate;
	public const object Update;
	public const object Script;
}

// Namespace: UnityEngine
public enum CapsuleDirection2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Vertical;
	public const object Horizontal;
}

// Namespace: UnityEngine
public enum RigidbodyConstraints2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object FreezePositionX;
	public const object FreezePositionY;
	public const object FreezeRotation;
	public const object FreezePosition;
	public const object FreezeAll;
}

// Namespace: UnityEngine
public enum RigidbodyInterpolation2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Interpolate;
	public const object Extrapolate;
}

// Namespace: UnityEngine
public enum RigidbodySleepMode2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NeverSleep;
	public const object StartAwake;
	public const object StartAsleep;
}

// Namespace: UnityEngine
public enum CollisionDetectionMode2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Discrete;
	public const object Continuous;
}

// Namespace: UnityEngine
public enum RigidbodyType2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Dynamic;
	public const object Kinematic;
	public const object Static;
}

// Namespace: UnityEngine
public enum ForceMode2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Force;
	public const object Impulse;
}

// Namespace: UnityEngine
public enum ColliderErrorState2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NoShapes;
	public const object RemovedShapes;
}

// Namespace: UnityEngine
public enum PhysicsShapeType2D
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Circle;
	public const object Capsule;
	public const object Polygon;
	public const object Edges;
}

// Namespace: UnityEngine
public struct PhysicsShape2D
{

	// Fields
	private object m_ShapeType; // 0xFFFFFFFFFFFFFFF8
	private object m_Radius; // 0xFFFFFFFFFFFFFFFC
	private object m_VertexStartIndex; // 0x0
	private object m_VertexCount; // 0x4
	private object m_UseAdjacentStart; // 0x8
	private object m_UseAdjacentEnd; // 0xC
	private object m_AdjacentStart; // 0x10
	private object m_AdjacentEnd; // 0x18
}

// Namespace: 
internal struct GroupState
{

	// Fields
	public object m_Shapes; // 0xFFFFFFFFFFFFFFF8
	public object m_Vertices; // 0x0
	public object m_LocalToWorld; // 0x8
}

// Namespace: UnityEngine
public class PhysicsShapeGroup2D
{

	// Fields
	internal object m_GroupState; // 0x8
}

// Namespace: UnityEngine
public struct ColliderDistance2D
{

	// Fields
	private object m_PointA; // 0xFFFFFFFFFFFFFFF8
	private object m_PointB; // 0x0
	private object m_Normal; // 0x8
	private object m_Distance; // 0x10
	private object m_IsValid; // 0x14
}

// Namespace: UnityEngine
public struct ContactFilter2D
{

	// Fields
	public object useTriggers; // 0xFFFFFFFFFFFFFFF8
	public object useLayerMask; // 0xFFFFFFFFFFFFFFF9
	public object useDepth; // 0xFFFFFFFFFFFFFFFA
	public object useOutsideDepth; // 0xFFFFFFFFFFFFFFFB
	public object useNormalAngle; // 0xFFFFFFFFFFFFFFFC
	public object useOutsideNormalAngle; // 0xFFFFFFFFFFFFFFFD
	public object layerMask; // 0x0
	public object minDepth; // 0x4
	public object maxDepth; // 0x8
	public object minNormalAngle; // 0xC
	public object maxNormalAngle; // 0x10
	public const object NormalAngleUpperLimit;

	// Properties
	public object isFiltering { get; }

	// Methods

	// RVA: 0x746DBE0
	public object NoFilter() { }

	// RVA: 0x747063C
	private object CheckConsistency() { }

	// RVA: 0x747072C
	public object ClearLayerMask() { }

	// RVA: 0x747073C
	public object SetLayerMask(object layerMask) { }

	// RVA: 0x747075C
	public object ClearDepth() { }

	// RVA: 0x747076C
	public object SetDepth(object minDepth, object maxDepth) { }

	// RVA: 0x7470824
	public object ClearNormalAngle() { }

	// RVA: 0x7470834
	public object SetNormalAngle(object minNormalAngle, object maxNormalAngle) { }

	// RVA: 0x74708EC
	public object get_isFiltering() { }

	// RVA: 0x7470944
	public object IsFilteringTrigger(object collider) { }

	// RVA: 0x7470A8C
	public object IsFilteringLayerMask(object obj) { }

	// RVA: 0x7470B6C
	public object IsFilteringDepth(object obj) { }

	// RVA: 0x7470C94
	public object IsFilteringNormalAngle(object normal) { }

	// RVA: 0x7470DBC
	public object IsFilteringNormalAngle(object angle) { }

	// RVA: 0x7470E20
	private object IsFilteringNormalAngleUsingAngle(object angle) { }

	// RVA: 0x74579C0
	internal static object CreateLegacyFilter(object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x747068C
	private static object CheckConsistency_Injected(object _unity_self) { }

	// RVA: 0x7470D04
	private static object IsFilteringNormalAngle_Injected(object _unity_self, object normal) { }

	// RVA: 0x7470EE8
	private static object IsFilteringNormalAngleUsingAngle_Injected(object _unity_self, object angle) { }

}

// Namespace: UnityEngine
public class Collision2D
{

	// Fields
	internal object m_Collider; // 0x8
	internal object m_OtherCollider; // 0xC
	internal object m_Rigidbody; // 0x10
	internal object m_OtherRigidbody; // 0x14
	internal object m_RelativeVelocity; // 0x18
	internal object m_Enabled; // 0x20
	internal object m_ContactCount; // 0x24
	internal object m_ReusedContacts; // 0x28
	internal object m_LegacyContacts; // 0x30

	// Properties
	public object collider { get; }
	public object otherCollider { get; }
	public object rigidbody { get; }
	public object otherRigidbody { get; }
	public object transform { get; }
	public object gameObject { get; }
	public object relativeVelocity { get; }
	public object enabled { get; }
	public object contacts { get; }
	public object contactCount { get; }

	// Methods

	// RVA: 0x747127C
	private object GetContacts_Internal() { }

	// RVA: 0x7471298
	public object get_collider() { }

	// RVA: 0x747138C
	public object get_otherCollider() { }

	// RVA: 0x7471480
	public object get_rigidbody() { }

	// RVA: 0x7471538
	public object get_otherRigidbody() { }

	// RVA: 0x74715F0
	public object get_transform() { }

	// RVA: 0x7471874
	public object get_gameObject() { }

	// RVA: 0x7471AF8
	public object get_relativeVelocity() { }

	// RVA: 0x7471B00
	public object get_enabled() { }

	// RVA: 0x7471B10
	public object get_contacts() { }

	// RVA: 0x7471B98
	public object get_contactCount() { }

	// RVA: 0x7471BA0
	public object GetContact(object index) { }

	// RVA: 0x7471CCC
	public object GetContacts(object contacts) { }

	// RVA: 0x7471D68
	public object GetContacts(object contacts) { }

	// RVA: 0x7471FB4
	public object .ctor() { }

}

// Namespace: UnityEngine
public struct ContactPoint2D
{

	// Fields
	private object m_Point; // 0xFFFFFFFFFFFFFFF8
	private object m_Normal; // 0x0
	private object m_RelativeVelocity; // 0x8
	private object m_Separation; // 0x10
	private object m_NormalImpulse; // 0x14
	private object m_TangentImpulse; // 0x18
	private object m_Collider; // 0x1C
	private object m_OtherCollider; // 0x20
	private object m_Rigidbody; // 0x24
	private object m_OtherRigidbody; // 0x28
	private object m_Enabled; // 0x2C
}

// Namespace: UnityEngine
public struct RaycastHit2D
{

	// Fields
	private object m_Centroid; // 0xFFFFFFFFFFFFFFF8
	private object m_Point; // 0x0
	private object m_Normal; // 0x8
	private object m_Distance; // 0x10
	private object m_Fraction; // 0x14
	private object m_Collider; // 0x18

	// Properties
	public object point { get; }
	public object normal { get; }
	public object distance { get; }
	public object collider { get; }

	// Methods

	// RVA: 0x7471FBC
	public object get_point() { }

	// RVA: 0x7471FCC
	public object get_normal() { }

	// RVA: 0x7471FDC
	public object get_distance() { }

	// RVA: 0x7471FEC
	public object get_collider() { }

}

// Namespace: UnityEngine
public struct PhysicsJobOptions2D
{

	// Fields
	private object m_UseMultithreading; // 0xFFFFFFFFFFFFFFF8
	private object m_UseConsistencySorting; // 0xFFFFFFFFFFFFFFF9
	private object m_InterpolationPosesPerJob; // 0xFFFFFFFFFFFFFFFC
	private object m_NewContactsPerJob; // 0x0
	private object m_CollideContactsPerJob; // 0x4
	private object m_ClearFlagsPerJob; // 0x8
	private object m_ClearBodyForcesPerJob; // 0xC
	private object m_SyncDiscreteFixturesPerJob; // 0x10
	private object m_SyncContinuousFixturesPerJob; // 0x14
	private object m_FindNearestContactsPerJob; // 0x18
	private object m_UpdateTriggerContactsPerJob; // 0x1C
	private object m_IslandSolverCostThreshold; // 0x20
	private object m_IslandSolverBodyCostScale; // 0x24
	private object m_IslandSolverContactCostScale; // 0x28
	private object m_IslandSolverJointCostScale; // 0x2C
	private object m_IslandSolverBodiesPerJob; // 0x30
	private object m_IslandSolverContactsPerJob; // 0x34
}

// Namespace: UnityEngine
public sealed class Rigidbody2D
{

	// Properties
	public object position { get; set; }
	public object rotation { get; set; }
	public object velocity { get; set; }
	public object angularVelocity { get; set; }
	public object useAutoMass { get; set; }
	public object mass { get; set; }
	public object sharedMaterial { get; set; }
	public object centerOfMass { get; set; }
	public object worldCenterOfMass { get; }
	public object inertia { get; set; }
	public object drag { get; set; }
	public object angularDrag { get; set; }
	public object gravityScale { get; set; }
	public object bodyType { get; set; }
	public object useFullKinematicContacts { get; set; }
	public object isKinematic { get; set; }
	public object fixedAngle { get; set; }
	public object freezeRotation { get; set; }
	public object constraints { get; set; }
	public object simulated { get; set; }
	public object interpolation { get; set; }
	public object sleepMode { get; set; }
	public object collisionDetectionMode { get; set; }
	public object attachedColliderCount { get; }
	public object totalForce { get; set; }
	public object totalTorque { get; set; }
	public object excludeLayers { get; set; }
	public object includeLayers { get; set; }

	// Methods

	// RVA: 0x7472258
	public object get_position() { }

	// RVA: 0x7472318
	public object set_position(object value) { }

	// RVA: 0x74723EC
	public object get_rotation() { }

	// RVA: 0x747243C
	public object set_rotation(object value) { }

	// RVA: 0x74724A0
	public object SetRotation(object angle) { }

	// RVA: 0x7472504
	private object SetRotation_Angle(object angle) { }

	// RVA: 0x7472568
	public object SetRotation(object rotation) { }

	// RVA: 0x74725DC
	private object SetRotation_Quaternion(object rotation) { }

	// RVA: 0x74726B4
	public object MovePosition(object position) { }

	// RVA: 0x7472788
	public object MoveRotation(object angle) { }

	// RVA: 0x74727EC
	private object MoveRotation_Angle(object angle) { }

	// RVA: 0x7472850
	public object MoveRotation(object rotation) { }

	// RVA: 0x74728C4
	private object MoveRotation_Quaternion(object rotation) { }

	// RVA: 0x747299C
	public object get_velocity() { }

	// RVA: 0x7472A5C
	public object set_velocity(object value) { }

	// RVA: 0x7472B30
	public object get_angularVelocity() { }

	// RVA: 0x7472B80
	public object set_angularVelocity(object value) { }

	// RVA: 0x7472BE4
	public object get_useAutoMass() { }

	// RVA: 0x7472C34
	public object set_useAutoMass(object value) { }

	// RVA: 0x7472C98
	public object get_mass() { }

	// RVA: 0x7472CE8
	public object set_mass(object value) { }

	// RVA: 0x7472D4C
	public object get_sharedMaterial() { }

	// RVA: 0x7472D9C
	public object set_sharedMaterial(object value) { }

	// RVA: 0x7472E00
	public object get_centerOfMass() { }

	// RVA: 0x7472EC0
	public object set_centerOfMass(object value) { }

	// RVA: 0x7472F94
	public object get_worldCenterOfMass() { }

	// RVA: 0x7473054
	public object get_inertia() { }

	// RVA: 0x74730A4
	public object set_inertia(object value) { }

	// RVA: 0x7473108
	public object get_drag() { }

	// RVA: 0x7473158
	public object set_drag(object value) { }

	// RVA: 0x74731BC
	public object get_angularDrag() { }

	// RVA: 0x747320C
	public object set_angularDrag(object value) { }

	// RVA: 0x7473270
	public object get_gravityScale() { }

	// RVA: 0x74732C0
	public object set_gravityScale(object value) { }

	// RVA: 0x7473324
	public object get_bodyType() { }

	// RVA: 0x7473374
	public object set_bodyType(object value) { }

	// RVA: 0x746FC94
	internal object SetDragBehaviour(object dragged) { }

	// RVA: 0x74733D8
	public object get_useFullKinematicContacts() { }

	// RVA: 0x7473428
	public object set_useFullKinematicContacts(object value) { }

	// RVA: 0x747348C
	public object get_isKinematic() { }

	// RVA: 0x74734F4
	public object set_isKinematic(object value) { }

	// RVA: 0x7473568
	public object get_fixedAngle() { }

	// RVA: 0x74735B8
	public object set_fixedAngle(object value) { }

	// RVA: 0x747361C
	public object get_freezeRotation() { }

	// RVA: 0x747366C
	public object set_freezeRotation(object value) { }

	// RVA: 0x74736D0
	public object get_constraints() { }

	// RVA: 0x7473720
	public object set_constraints(object value) { }

	// RVA: 0x7473784
	public object IsSleeping() { }

	// RVA: 0x74737D4
	public object IsAwake() { }

	// RVA: 0x7473824
	public object Sleep() { }

	// RVA: 0x7473874
	public object WakeUp() { }

	// RVA: 0x74738C4
	public object get_simulated() { }

	// RVA: 0x7473914
	public object set_simulated(object value) { }

	// RVA: 0x7473978
	public object get_interpolation() { }

	// RVA: 0x74739C8
	public object set_interpolation(object value) { }

	// RVA: 0x7473A2C
	public object get_sleepMode() { }

	// RVA: 0x7473A7C
	public object set_sleepMode(object value) { }

	// RVA: 0x7473AE0
	public object get_collisionDetectionMode() { }

	// RVA: 0x7473B30
	public object set_collisionDetectionMode(object value) { }

	// RVA: 0x7473B94
	public object get_attachedColliderCount() { }

	// RVA: 0x7473BE4
	public object get_totalForce() { }

	// RVA: 0x7473CA4
	public object set_totalForce(object value) { }

	// RVA: 0x7473D78
	public object get_totalTorque() { }

	// RVA: 0x7473DC8
	public object set_totalTorque(object value) { }

	// RVA: 0x7473E2C
	public object get_excludeLayers() { }

	// RVA: 0x7473EEC
	public object set_excludeLayers(object value) { }

	// RVA: 0x7473FC0
	public object get_includeLayers() { }

	// RVA: 0x7474080
	public object set_includeLayers(object value) { }

	// RVA: 0x7474154
	public object IsTouching(object collider) { }

	// RVA: 0x74741B8
	public object IsTouching(object collider, object contactFilter) { }

	// RVA: 0x747422C
	private object IsTouching_OtherColliderWithFilter_Internal(object collider, object contactFilter) { }

	// RVA: 0x7474304
	public object IsTouching(object contactFilter) { }

	// RVA: 0x7474380
	private object IsTouching_AnyColliderWithFilter_Internal(object contactFilter) { }

	// RVA: 0x7474448
	public object IsTouchingLayers() { }

	// RVA: 0x74744A0
	public object IsTouchingLayers(object layerMask) { }

	// RVA: 0x7474504
	public object OverlapPoint(object point) { }

	// RVA: 0x74745D8
	public object Distance(object collider) { }

	// RVA: 0x747483C
	private object Distance_Internal(object collider) { }

	// RVA: 0x7474920
	public object ClosestPoint(object position) { }

	// RVA: 0x7474998
	public object AddForce(object force) { }

	// RVA: 0x74749F4
	public object AddForce(object force, object mode) { }

	// RVA: 0x7474AC8
	public object AddRelativeForce(object relativeForce) { }

	// RVA: 0x7474B24
	public object AddRelativeForce(object relativeForce, object mode) { }

	// RVA: 0x7474BF8
	public object AddForceAtPosition(object force, object position) { }

	// RVA: 0x7474C5C
	public object AddForceAtPosition(object force, object position, object mode) { }

	// RVA: 0x7474D4C
	public object AddTorque(object torque) { }

	// RVA: 0x7474DB8
	public object AddTorque(object torque, object mode) { }

	// RVA: 0x7474E30
	public object GetPoint(object point) { }

	// RVA: 0x7474F00
	public object GetRelativePoint(object relativePoint) { }

	// RVA: 0x7474FD0
	public object GetVector(object vector) { }

	// RVA: 0x74750A0
	public object GetRelativeVector(object relativeVector) { }

	// RVA: 0x7475170
	public object GetPointVelocity(object point) { }

	// RVA: 0x7475240
	public object GetRelativePointVelocity(object relativePoint) { }

	// RVA: 0x7475310
	public object OverlapCollider(object contactFilter, object results) { }

	// RVA: 0x7475384
	private object OverlapColliderArray_Internal(object contactFilter, object results) { }

	// RVA: 0x747545C
	public object OverlapCollider(object contactFilter, object results) { }

	// RVA: 0x74754D0
	private object OverlapColliderList_Internal(object contactFilter, object results) { }

	// RVA: 0x74755A8
	public object GetContacts(object contacts) { }

	// RVA: 0x747564C
	public object GetContacts(object contacts) { }

	// RVA: 0x74756F0
	public object GetContacts(object contactFilter, object contacts) { }

	// RVA: 0x7475784
	public object GetContacts(object contactFilter, object contacts) { }

	// RVA: 0x7475818
	public object GetContacts(object colliders) { }

	// RVA: 0x74758BC
	public object GetContacts(object colliders) { }

	// RVA: 0x7475960
	public object GetContacts(object contactFilter, object colliders) { }

	// RVA: 0x74759F4
	public object GetContacts(object contactFilter, object colliders) { }

	// RVA: 0x7475A88
	public object GetAttachedColliders(object results) { }

	// RVA: 0x7475AEC
	private object GetAttachedCollidersArray_Internal(object results) { }

	// RVA: 0x7475B50
	public object GetAttachedColliders(object results) { }

	// RVA: 0x7475BB4
	private object GetAttachedCollidersList_Internal(object results) { }

	// RVA: 0x7475C18
	public object Cast(object direction, object results) { }

	// RVA: 0x7475D00
	public object Cast(object direction, object results, object distance) { }

	// RVA: 0x7475C88
	private object CastArray_Internal(object direction, object distance, object results) { }

	// RVA: 0x7475DF8
	public object Cast(object direction, object results, object distance) { }

	// RVA: 0x7475E70
	private object CastList_Internal(object direction, object distance, object results) { }

	// RVA: 0x7475F68
	public object Cast(object direction, object contactFilter, object results) { }

	// RVA: 0x747606C
	public object Cast(object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7475FEC
	private object CastFilteredArray_Internal(object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x747618C
	public object Cast(object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7476218
	private object CastFilteredList_Internal(object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x747632C
	public object GetShapes(object physicsShapeGroup) { }

	// RVA: 0x74763A4
	private object GetShapes_Internal(object physicsShapeGroupState) { }

	// RVA: 0x7476408
	public object .ctor() { }

	// RVA: 0x74722B4
	private object get_position_Injected(object ret) { }

	// RVA: 0x7472388
	private object set_position_Injected(object value) { }

	// RVA: 0x7472650
	private object SetRotation_Quaternion_Injected(object rotation) { }

	// RVA: 0x7472724
	private object MovePosition_Injected(object position) { }

	// RVA: 0x7472938
	private object MoveRotation_Quaternion_Injected(object rotation) { }

	// RVA: 0x74729F8
	private object get_velocity_Injected(object ret) { }

	// RVA: 0x7472ACC
	private object set_velocity_Injected(object value) { }

	// RVA: 0x7472E5C
	private object get_centerOfMass_Injected(object ret) { }

	// RVA: 0x7472F30
	private object set_centerOfMass_Injected(object value) { }

	// RVA: 0x7472FF0
	private object get_worldCenterOfMass_Injected(object ret) { }

	// RVA: 0x7473C40
	private object get_totalForce_Injected(object ret) { }

	// RVA: 0x7473D14
	private object set_totalForce_Injected(object value) { }

	// RVA: 0x7473E88
	private object get_excludeLayers_Injected(object ret) { }

	// RVA: 0x7473F5C
	private object set_excludeLayers_Injected(object value) { }

	// RVA: 0x747401C
	private object get_includeLayers_Injected(object ret) { }

	// RVA: 0x74740F0
	private object set_includeLayers_Injected(object value) { }

	// RVA: 0x7474298
	private object IsTouching_OtherColliderWithFilter_Internal_Injected(object collider, object contactFilter) { }

	// RVA: 0x74743E4
	private object IsTouching_AnyColliderWithFilter_Internal_Injected(object contactFilter) { }

	// RVA: 0x7474574
	private object OverlapPoint_Injected(object point) { }

	// RVA: 0x74748B4
	private object Distance_Internal_Injected(object collider, object ret) { }

	// RVA: 0x7474A5C
	private object AddForce_Injected(object force, object mode) { }

	// RVA: 0x7474B8C
	private object AddRelativeForce_Injected(object relativeForce, object mode) { }

	// RVA: 0x7474CCC
	private object AddForceAtPosition_Injected(object force, object position, object mode) { }

	// RVA: 0x7474E94
	private object GetPoint_Injected(object point, object ret) { }

	// RVA: 0x7474F64
	private object GetRelativePoint_Injected(object relativePoint, object ret) { }

	// RVA: 0x7475034
	private object GetVector_Injected(object vector, object ret) { }

	// RVA: 0x7475104
	private object GetRelativeVector_Injected(object relativeVector, object ret) { }

	// RVA: 0x74751D4
	private object GetPointVelocity_Injected(object point, object ret) { }

	// RVA: 0x74752A4
	private object GetRelativePointVelocity_Injected(object relativePoint, object ret) { }

	// RVA: 0x74753F0
	private object OverlapColliderArray_Internal_Injected(object contactFilter, object results) { }

	// RVA: 0x747553C
	private object OverlapColliderList_Internal_Injected(object contactFilter, object results) { }

	// RVA: 0x7475D78
	private object CastArray_Internal_Injected(object direction, object distance, object results) { }

	// RVA: 0x7475EE8
	private object CastList_Internal_Injected(object direction, object distance, object results) { }

	// RVA: 0x74760F8
	private object CastFilteredArray_Internal_Injected(object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7476298
	private object CastFilteredList_Internal_Injected(object direction, object distance, object contactFilter, object results) { }

}

// Namespace: UnityEngine
public class Collider2D
{

	// Properties
	public object density { get; set; }
	public object isTrigger { get; set; }
	public object usedByEffector { get; set; }
	public object usedByComposite { get; set; }
	public object composite { get; }
	public object offset { get; set; }
	public object attachedRigidbody { get; }
	public object shapeCount { get; }
	public object bounds { get; }
	public object errorState { get; }
	internal object compositeCapable { get; }
	public object sharedMaterial { get; set; }
	public object layerOverridePriority { get; set; }
	public object excludeLayers { get; set; }
	public object includeLayers { get; set; }
	public object forceSendLayers { get; set; }
	public object forceReceiveLayers { get; set; }
	public object contactCaptureLayers { get; set; }
	public object callbackLayers { get; set; }
	public object friction { get; }
	public object bounciness { get; }

	// Methods

	// RVA: 0x7476410
	public object get_density() { }

	// RVA: 0x7476460
	public object set_density(object value) { }

	// RVA: 0x74709C0
	public object get_isTrigger() { }

	// RVA: 0x74764C4
	public object set_isTrigger(object value) { }

	// RVA: 0x7476528
	public object get_usedByEffector() { }

	// RVA: 0x7476578
	public object set_usedByEffector(object value) { }

	// RVA: 0x74765DC
	public object get_usedByComposite() { }

	// RVA: 0x747662C
	public object set_usedByComposite(object value) { }

	// RVA: 0x7476690
	public object get_composite() { }

	// RVA: 0x74766E0
	public object get_offset() { }

	// RVA: 0x74767A0
	public object set_offset(object value) { }

	// RVA: 0x74747EC
	public object get_attachedRigidbody() { }

	// RVA: 0x7476874
	public object get_shapeCount() { }

	// RVA: 0x74768C4
	public object CreateMesh(object useBodyPosition, object useBodyRotation) { }

	// RVA: 0x7476930
	public object GetShapeHash() { }

	// RVA: 0x7476980
	public object GetShapes(object physicsShapeGroup) { }

	// RVA: 0x7476AB0
	public object GetShapes(object physicsShapeGroup, object shapeIndex, object shapeCount) { }

	// RVA: 0x7476A30
	private object GetShapes_Internal(object physicsShapeGroupState, object shapeIndex, object shapeCount) { }

	// RVA: 0x7476C2C
	public object get_bounds() { }

	// RVA: 0x7476D08
	public object get_errorState() { }

	// RVA: 0x7476D58
	internal object get_compositeCapable() { }

	// RVA: 0x7476DA8
	public object get_sharedMaterial() { }

	// RVA: 0x7476DF8
	public object set_sharedMaterial(object value) { }

	// RVA: 0x7476E5C
	public object get_layerOverridePriority() { }

	// RVA: 0x7476EAC
	public object set_layerOverridePriority(object value) { }

	// RVA: 0x7476F10
	public object get_excludeLayers() { }

	// RVA: 0x7476FD0
	public object set_excludeLayers(object value) { }

	// RVA: 0x74770A4
	public object get_includeLayers() { }

	// RVA: 0x7477164
	public object set_includeLayers(object value) { }

	// RVA: 0x7477238
	public object get_forceSendLayers() { }

	// RVA: 0x74772F8
	public object set_forceSendLayers(object value) { }

	// RVA: 0x74773CC
	public object get_forceReceiveLayers() { }

	// RVA: 0x747748C
	public object set_forceReceiveLayers(object value) { }

	// RVA: 0x7477560
	public object get_contactCaptureLayers() { }

	// RVA: 0x7477620
	public object set_contactCaptureLayers(object value) { }

	// RVA: 0x74776F4
	public object get_callbackLayers() { }

	// RVA: 0x74777B4
	public object set_callbackLayers(object value) { }

	// RVA: 0x7477888
	public object get_friction() { }

	// RVA: 0x74778D8
	public object get_bounciness() { }

	// RVA: 0x7477928
	public object IsTouching(object collider) { }

	// RVA: 0x747798C
	public object IsTouching(object collider, object contactFilter) { }

	// RVA: 0x7477A00
	private object IsTouching_OtherColliderWithFilter(object collider, object contactFilter) { }

	// RVA: 0x7477AD8
	public object IsTouching(object contactFilter) { }

	// RVA: 0x7477B54
	private object IsTouching_AnyColliderWithFilter(object contactFilter) { }

	// RVA: 0x7477C1C
	public object IsTouchingLayers() { }

	// RVA: 0x7477C74
	public object IsTouchingLayers(object layerMask) { }

	// RVA: 0x7477CD8
	public object OverlapPoint(object point) { }

	// RVA: 0x7477DAC
	public object Distance(object collider) { }

	// RVA: 0x7477E40
	public object OverlapCollider(object contactFilter, object results) { }

	// RVA: 0x7477EB4
	public object OverlapCollider(object contactFilter, object results) { }

	// RVA: 0x7477F28
	public object GetContacts(object contacts) { }

	// RVA: 0x7477FCC
	public object GetContacts(object contacts) { }

	// RVA: 0x7478070
	public object GetContacts(object contactFilter, object contacts) { }

	// RVA: 0x7478104
	public object GetContacts(object contactFilter, object contacts) { }

	// RVA: 0x7478198
	public object GetContacts(object colliders) { }

	// RVA: 0x747823C
	public object GetContacts(object colliders) { }

	// RVA: 0x74782E0
	public object GetContacts(object contactFilter, object colliders) { }

	// RVA: 0x7478374
	public object GetContacts(object contactFilter, object colliders) { }

	// RVA: 0x7478408
	public object Cast(object direction, object results) { }

	// RVA: 0x74785F4
	public object Cast(object direction, object results, object distance) { }

	// RVA: 0x7478758
	public object Cast(object direction, object results, object distance, object ignoreSiblingColliders) { }

	// RVA: 0x74788C8
	public object Cast(object direction, object contactFilter, object results) { }

	// RVA: 0x7478950
	public object Cast(object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x74789E0
	public object Cast(object direction, object contactFilter, object results, object distance, object ignoreSiblingColliders) { }

	// RVA: 0x7478564
	private object CastArray_Internal(object direction, object distance, object contactFilter, object ignoreSiblingColliders, object results) { }

	// RVA: 0x7478B10
	public object Cast(object direction, object contactFilter, object results, object distance, object ignoreSiblingColliders) { }

	// RVA: 0x7478BA4
	private object CastList_Internal(object direction, object distance, object contactFilter, object ignoreSiblingColliders, object results) { }

	// RVA: 0x7478CD0
	public object Raycast(object direction, object results) { }

	// RVA: 0x7478DEC
	public object Raycast(object direction, object results, object distance) { }

	// RVA: 0x7478E90
	public object Raycast(object direction, object results, object distance, object layerMask) { }

	// RVA: 0x7478F34
	public object Raycast(object direction, object results, object distance, object layerMask, object minDepth) { }

	// RVA: 0x7478FD4
	public object Raycast(object direction, object results, object distance, object layerMask, object minDepth, object maxDepth) { }

	// RVA: 0x7479070
	public object Raycast(object direction, object contactFilter, object results) { }

	// RVA: 0x74790F4
	public object Raycast(object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x7478D6C
	private object RaycastArray_Internal(object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7479214
	public object Raycast(object direction, object contactFilter, object results, object distance) { }

	// RVA: 0x74792A0
	private object RaycastList_Internal(object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x74793B4
	public object ClosestPoint(object position) { }

	// RVA: 0x747942C
	public object .ctor() { }

	// RVA: 0x747673C
	private object get_offset_Injected(object ret) { }

	// RVA: 0x7476810
	private object set_offset_Injected(object value) { }

	// RVA: 0x7476CA4
	private object get_bounds_Injected(object ret) { }

	// RVA: 0x7476F6C
	private object get_excludeLayers_Injected(object ret) { }

	// RVA: 0x7477040
	private object set_excludeLayers_Injected(object value) { }

	// RVA: 0x7477100
	private object get_includeLayers_Injected(object ret) { }

	// RVA: 0x74771D4
	private object set_includeLayers_Injected(object value) { }

	// RVA: 0x7477294
	private object get_forceSendLayers_Injected(object ret) { }

	// RVA: 0x7477368
	private object set_forceSendLayers_Injected(object value) { }

	// RVA: 0x7477428
	private object get_forceReceiveLayers_Injected(object ret) { }

	// RVA: 0x74774FC
	private object set_forceReceiveLayers_Injected(object value) { }

	// RVA: 0x74775BC
	private object get_contactCaptureLayers_Injected(object ret) { }

	// RVA: 0x7477690
	private object set_contactCaptureLayers_Injected(object value) { }

	// RVA: 0x7477750
	private object get_callbackLayers_Injected(object ret) { }

	// RVA: 0x7477824
	private object set_callbackLayers_Injected(object value) { }

	// RVA: 0x7477A6C
	private object IsTouching_OtherColliderWithFilter_Injected(object collider, object contactFilter) { }

	// RVA: 0x7477BB8
	private object IsTouching_AnyColliderWithFilter_Injected(object contactFilter) { }

	// RVA: 0x7477D48
	private object OverlapPoint_Injected(object point) { }

	// RVA: 0x7478A74
	private object CastArray_Internal_Injected(object direction, object distance, object contactFilter, object ignoreSiblingColliders, object results) { }

	// RVA: 0x7478C34
	private object CastList_Internal_Injected(object direction, object distance, object contactFilter, object ignoreSiblingColliders, object results) { }

	// RVA: 0x7479180
	private object RaycastArray_Internal_Injected(object direction, object distance, object contactFilter, object results) { }

	// RVA: 0x7479320
	private object RaycastList_Internal_Injected(object direction, object distance, object contactFilter, object results) { }

}

// Namespace: UnityEngine
public sealed class CircleCollider2D
{

	// Properties
	public object radius { get; set; }
	public object center { get; set; }

	// Methods

	// RVA: 0x7479434
	public object get_radius() { }

	// RVA: 0x7479484
	public object set_radius(object value) { }

	// RVA: 0x74794E8
	public object get_center() { }

	// RVA: 0x7479534
	public object set_center(object value) { }

	// RVA: 0x7479538
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class BoxCollider2D
{

	// Properties
	public object size { get; set; }
	public object edgeRadius { get; set; }
	public object autoTiling { get; set; }
	public object center { get; set; }

	// Methods

	// RVA: 0x7479540
	public object get_size() { }

	// RVA: 0x7479600
	public object set_size(object value) { }

	// RVA: 0x74796D4
	public object get_edgeRadius() { }

	// RVA: 0x7479724
	public object set_edgeRadius(object value) { }

	// RVA: 0x7479788
	public object get_autoTiling() { }

	// RVA: 0x74797D8
	public object set_autoTiling(object value) { }

	// RVA: 0x747983C
	public object get_center() { }

	// RVA: 0x7479888
	public object set_center(object value) { }

	// RVA: 0x747988C
	public object .ctor() { }

	// RVA: 0x747959C
	private object get_size_Injected(object ret) { }

	// RVA: 0x7479670
	private object set_size_Injected(object value) { }

}

// Namespace: UnityEngine
public sealed class PolygonCollider2D
{

	// Methods

	// RVA: 0x7479894
	public object SetPath(object index, object points) { }

	// RVA: 0x7479980
	private object SetPath_Internal(object index, object points) { }

}

// Namespace: UnityEngine
public sealed class CompositeCollider2D
{

	// Methods

	// RVA: 0x74799EC
	public object .ctor() { }

}

// Namespace: UnityEngine
public class Joint2D
{

	// Properties
	public object connectedBody { get; }

	// Methods

	// RVA: 0x74799F4
	public object get_connectedBody() { }

}

// Namespace: UnityEngine
public class AnchoredJoint2D
{

	// Properties
	public object connectedAnchor { get; }

	// Methods

	// RVA: 0x7479A44
	public object get_connectedAnchor() { }

	// RVA: 0x7479AA0
	private object get_connectedAnchor_Injected(object ret) { }

}

// Namespace: UnityEngine
public sealed class HingeJoint2D
{
}

// Namespace: UnityEngine
public sealed class PhysicsMaterial2D
{

	// Properties
	public object bounciness { get; set; }
	public object friction { get; set; }

	// Methods

	// RVA: 0x7479B04
	public object .ctor() { }

	// RVA: 0x7479C34
	public object .ctor(object name) { }

	// RVA: 0x7479BD0
	private static object Create_Internal(object scriptMaterial, object name) { }

	// RVA: 0x7479D04
	public object get_bounciness() { }

	// RVA: 0x7479D54
	public object set_bounciness(object value) { }

	// RVA: 0x7479DB8
	public object get_friction() { }

	// RVA: 0x7479E08
	public object set_friction(object value) { }

}

