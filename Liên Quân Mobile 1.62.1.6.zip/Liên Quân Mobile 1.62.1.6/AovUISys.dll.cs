// Namespace: 
internal class <Module>
{
}

// Namespace: 
public class PushGoldCollision
{

	// Methods

	// RVA: 0xD26CCC
	private object OnCollisionEnter(object colObj) { }

	// RVA: 0xD26D30
	private object OnCollisionStay(object colObj) { }

	// RVA: 0xD26D94
	private object OnCollisionExit(object colObj) { }

	// RVA: 0xD26DF8
	private object OnTriggerEnter(object colObj) { }

	// RVA: 0xD26EE4
	private object OnTriggerStay(object colObj) { }

	// RVA: 0xD26F48
	private object OnTriggerExit(object colObj) { }

	// RVA: 0xD26FAC
	public object .ctor() { }

}

// Namespace: 
public class PushGoldCollisionItem
{

	// Fields
	private object hasCollided1; // 0x18
	private object hasCollided2; // 0x19

	// Methods

	// RVA: 0xD26FB4
	private object OnCollisionEnter(object colObj) { }

	// RVA: 0xD271D4
	public object .ctor() { }

}

// Namespace: 
public class ReturnDiscountShopLotteryAnimationHelper
{

	// Methods

	// RVA: 0xD271DC
	public object OnGetDiscountAnimationOver() { }

	// RVA: 0xD27290
	public object .ctor() { }

}

// Namespace: 
public class ReturnDiscountShopLotteryWidget
{

	// Fields
	public object DiscountValueOther; // 0x18
	public object DiscountValueCH; // 0x20
	public object RemainTimer; // 0x28
	public object CDNRole; // 0x30
	public object CDNTitle; // 0x38
	public object GetDiscountBtn; // 0x40
	public object GotoShopBtn; // 0x48
	public object FormAnimator; // 0x50
	public object RealDiscount; // 0x58
	public object RealDiscountCH; // 0x60
	public object RealDiscountOther; // 0x68
	public object UnknowDiscount; // 0x70
	public object DiscountAnimator; // 0x78

	// Methods

	// RVA: 0xD27298
	public object .ctor() { }

}

// Namespace: 
public class ReturnDiscountShopMallWidget
{

	// Fields
	public object GoodsContainer; // 0x18
	public object RemainTimer; // 0x20
	public object Discount; // 0x28
	public object CDNRole; // 0x30
	public object CDNTitle; // 0x38

	// Methods

	// RVA: 0xD272A0
	public object .ctor() { }

}

// Namespace: 
public class ReturnRechargeActivityCtrlWidget
{

	// Fields
	public object CDNRole; // 0x18
	public object CDNTitle; // 0x20
	public object Goods; // 0x28
	public object duration; // 0x30

	// Methods

	// RVA: 0xD272A8
	public object .ctor() { }

}

// Namespace: 
public class ReturnRechargeActivityGoodsItemWidget
{

	// Fields
	public object ExtraCoupons; // 0x18
	public object ExtraCouponsValue; // 0x20
	public object Icon; // 0x28
	public object BuyCount; // 0x30
	public object GoodsPrice; // 0x38
	public object Gifts; // 0x40
	public object BuyEventScript; // 0x48
	public object Buy; // 0x50
	public object Bought; // 0x58

	// Methods

	// RVA: 0xD272B0
	public object .ctor() { }

}

// Namespace: 
public class AccelerationValue
{

	// Fields
	public object x; // 0x18
	public object y; // 0x20

	// Methods

	// RVA: 0xD272B8
	private object Start() { }

	// RVA: 0xD27314
	private object Update() { }

	// RVA: 0xD274D0
	public object .ctor() { }

}

// Namespace: 
public class AnimationSync
{

	// Fields
	private object followAnimationComponent; // 0x18
	private object animationComponent; // 0x20

	// Methods

	// RVA: 0xD274D8
	private object Start() { }

	// RVA: 0xD276B0
	public object PlayIdleShow() { }

	// RVA: 0xD27D30
	public object PlayCome() { }

	// RVA: 0xD277B8
	private object GetCrossFadeTime(object _curAnimation) { }

	// RVA: 0xD27EF8
	public object .ctor() { }

}

// Namespace: 
public class AovUISysAdapter
{

	// Properties
	public object SpecialCaseSystem { get; }
	public object LegendMgr { get; }
	public object MoWenSystem { get; }
	public object MallSystem { get; }
	public object PlayerInfoSystems { get; }
	public object RecordUseSDK { get; }
	public object ChatSystem { get; }
	public object FriendController { get; }
	public object DLCDownloadSystems { get; }
	public object EquipSystem { get; }

	// Methods

	// RVA: 0xD27F00
	private static object InitRegisterNetworkModule() { }

	// RVA: 0xD28510
	public object get_SpecialCaseSystem() { }

	// RVA: 0xD28598
	public object get_LegendMgr() { }

	// RVA: 0xD28620
	public object get_MoWenSystem() { }

	// RVA: 0xD286A8
	public object get_MallSystem() { }

	// RVA: 0xD28730
	public object get_PlayerInfoSystems() { }

	// RVA: 0xD287B8
	public object get_RecordUseSDK() { }

	// RVA: 0xD28840
	public object get_ChatSystem() { }

	// RVA: 0xD288C8
	public object get_FriendController() { }

	// RVA: 0xD28950
	public object get_DLCDownloadSystems() { }

	// RVA: 0xD289D8
	public object get_EquipSystem() { }

	// RVA: 0xD28A60
	public static object InitSys() { }

	// RVA: 0xD28E40
	public static object GetSingleton() { }

	// RVA: 0xD28EC0
	public object DLCDownloadUISystemCreateInstance() { }

	// RVA: 0xD28F48
	public override object UnInit() { }

	// RVA: 0xD292F4
	public object Clear() { }

	// RVA: 0xD294CC
	public object .ctor() { }

	// RVA: 0xD29524
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
public class CSpecialCaseSystem
{

	// Methods

	// RVA: 0xD29528
	public object GetMonthCheckReddotCount() { }

	// RVA: 0xD295C8
	public object GetMonthCheckWealID() { }

	// RVA: 0xD29668
	public object GetReturnSplashReturnTime() { }

	// RVA: 0xD29708
	public object GetBirthdayNeedShowInLobby() { }

	// RVA: 0xD297A8
	public object IsNewbieTaskInCurrentTask() { }

	// RVA: 0xD29848
	public object GetPlentyModeTaskRedPointNum() { }

	// RVA: 0xD298F0
	public object IsDuringGrowUpTaskTime() { }

	// RVA: 0xD29990
	public object .ctor() { }

}

// Namespace: 
public class CDelayDrawGiftCtrlItemWidget
{

	// Fields
	public object itemCell; // 0x18
	public object itemName; // 0x20
	public object unSelected; // 0x28
	public object selected; // 0x30
	public object cannotSelectMask; // 0x38
	public object owned; // 0x40

	// Methods

	// RVA: 0xD299E8
	public object .ctor() { }

}

// Namespace: 
public class CDelayDrawGiftCtrlWidget
{

	// Fields
	public object rewardNumTip; // 0x18
	public object itemListScript; // 0x20
	public object exchangeButton; // 0x28

	// Methods

	// RVA: 0xD299F0
	public object .ctor() { }

}

// Namespace: 
public enum Widgets
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WIDGET_LANG_LIST;
}

// Namespace: 
public class CChatFilterLangView
{

	// Fields
	public const object ChatFilterLang;
	private object templateLangList; // 0x8
	private object _currentSupportLanguagesSort; // 0x10

	// Properties
	public object currentSupportLanguagesSort { get; }

	// Methods

	// RVA: 0xD299F8
	public object get_currentSupportLanguagesSort() { }

	// RVA: 0xD29FD8
	private object InitTemplateLangList() { }

	// RVA: 0xD2A44C
	public object .ctor() { }

	// RVA: 0xD2A718
	public object FilterFunction() { }

	// RVA: 0xD2A848
	private object IsFilterFunctionConfigOpen() { }

	// RVA: 0xD2A4EC
	private object InitEvent() { }

	// RVA: 0xD2A98C
	private object GetToggleList() { }

	// RVA: 0xD2AB04
	public object OnLobbyChatFilterLang(object evt) { }

	// RVA: 0xD2ACE4
	private object SelectCurLanguage() { }

	// RVA: 0xD2B22C
	private object OnConfirmFilterLang(object evt) { }

	// RVA: 0xD2B758
	private object OnFilterLangItemEnable(object uiEvent) { }

	// RVA: 0xD2BAE8
	private object OnSelectChange(object uiEvent) { }

}

// Namespace: 
public class LabelType
{

	// Fields
	public object info; // 0x8
	public object type; // 0x10

	// Methods

	// RVA: 0xD2C4B4
	public object .ctor(object text, object tp) { }

}

// Namespace: 
public enum InfoType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Text;
	public const object Face;
}

// Namespace: 
public class CChatParser
{

	// Fields
	public static object chat_entry_lineHeight; // 0x0
	public static object chat_list_max_width; // 0x4
	public static object chat_entry_channel_img_width; // 0x8
	public static object talk_icon_width; // 0xC
	public static object start_x; // 0x10
	public static object chatFaceWidth; // 0x14
	public static object chatFaceHeight; // 0x18
	public static object lineHeight; // 0x1C
	public object maxWidth; // 0x8
	public static object element_width; // 0x20
	public static object element_height; // 0x24
	public static object inviteElement_height; // 0x28
	public static object shareWithoutMailboxElement_height; // 0x2C
	public static object shareWithMailboxElement_height; // 0x30
	public static object MeaninglessElementHeightOffset; // 0x34
	private object mPositionX; // 0xC
	private object mPositionY; // 0x10
	private object mOriginalPositionX; // 0x14
	private object mWidth; // 0x18
	private object mList; // 0x20
	private object curEntNode; // 0x28
	public object chatCell_InitHeight; // 0x30
	public object chatCell_patchHeight; // 0x34
	public object chatCell_DeltaHeight; // 0x38
	public object bProc_ChatEntry; // 0x3C
	private const object SPEAKER_STR;
	private const object SPEAKER_REP_STR;
	private readonly object WhiteSpaceChars; // 0x40
	public static object ascii_width_for_GameFont; // 0x38

	// Methods

	// RVA: 0xD2BB4C
	public object .ctor() { }

	// RVA: 0xD2BC38
	public object Parse(object startX, object entNode) { }

	// RVA: 0xD2C370
	public object LobbyChatParse(object startX, object entNode) { }

	// RVA: 0xD2BD7C
	private object ParseText(object value) { }

	// RVA: 0xD2C208
	private object ShowText() { }

	// RVA: 0xD2C4F0
	private object CreateText(object value) { }

	// RVA: 0xD2CA04
	private object CreateTextFace(object value) { }

	// RVA: 0xD2D59C
	private object IsWhiteChar(object ch) { }

	// RVA: 0xD2D64C
	private object GetCharacterWidth(object font, object ch, object fontSize) { }

	// RVA: 0xD2CD30
	private object WrapText(object text, object curPosX, object finalText, object length) { }

	// RVA: 0xD2D3E0
	private object getLogicLineCountFromSingleLine(object text) { }

	// RVA: 0xD2D860
	private static object .cctor() { }

}

// Namespace: 
public class AllColorParser
{

	// Fields
	private object m_result; // 0x8
	private object m_viewFontSize; // 0x10
	private object m_Font; // 0x18
	private object Header_Half_Str; // 0x20
	private object tail_Str; // 0x28

	// Methods

	// RVA: 0xD2D92C
	public object Parse(object lingWidth, object content, object viewFontSize, object inFont) { }

	// RVA: 0xD2DB44
	private object _parse(object lingWidth, object content, object result, object actualWidth, object inFont) { }

	// RVA: 0xD2E3E4
	private object bHeader_Half_Match(object startIndex, object content) { }

	// RVA: 0xD2E46C
	private object bColorTail_Match(object startIndex, object content) { }

	// RVA: 0xD2E4F4
	private object bMatch(object startIndex, object content, object destStr) { }

	// RVA: 0xD2E620
	public object .ctor() { }

}

// Namespace: 
public enum TemplateFormWidget
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TextTemplate;
	public const object ImageTemplate;
}

// Namespace: 
public class CChatView
{

	// Fields
	public static object ChatFaceCount; // 0x0
	public object bShow; // 0x8
	public object bRefreshNew; // 0x9
	public object chatForm; // 0x10
	private object bFormWidgetInited; // 0x18
	public object chatFormViewLua; // 0x20
	public static object entrySizeLobby; // 0x4
	public static object entrySizeRoom; // 0xC
	public static object entrySizeTeam; // 0x14
	public object curChannels; // 0x28
	public object ChatParser; // 0x30
	public object text_template; // 0x38
	public object templateText; // 0x40
	public object image_template; // 0x48
	public object Anim; // 0x50
	public object AnimtorComp; // 0x58
	public object topDeleteCount; // 0x60
	public object startIndex; // 0x64
	public object endIndex; // 0x68
	public object openTranslate; // 0x6C
	public object _tab; // 0x70

	// Properties
	public object CurTab { get; set; }

	// Methods

	// RVA: 0xD2E6DC
	public object InitTemplateForm() { }

	// RVA: 0xD2EA88
	public object ClearEnterBattle() { }

	// RVA: 0xD2EAEC
	public object CheckInit() { }

	// RVA: 0xD2EFF8
	public object Open() { }

	// RVA: 0xD2F30C
	public object DoChatOpenningAnim() { }

	// RVA: 0xD2F40C
	public object DoChatClosingAnim() { }

	// RVA: 0xD2EEB8
	public object HideForm() { }

	// RVA: 0xD2EC88
	private object InitChatWidget() { }

	// RVA: 0xD2F5CC
	public object ClearChatForm() { }

	// RVA: 0xD2F648
	public object get_CurTab() { }

	// RVA: 0xD2F6A8
	public object set_CurTab(object value) { }

	// RVA: 0xD2F7E8
	public object Refresh_ChatInputView() { }

	// RVA: 0xD2F900
	public object IsCheckHistory() { }

	// RVA: 0xD2FA18
	public object On_RefreshListItemTextTranslate() { }

	// RVA: 0xD2FC30
	public object ShowLoudSpeaker(object bShow, object data) { }

	// RVA: 0xD2FD7C
	public object RefreshCurShowItemIndexRange() { }

	// RVA: 0xD2FEE0
	public object SubCurShowItemIndexRange(object index) { }

	// RVA: 0xD2FF54
	public object AddDeleteTopItemCount(object count) { }

	// RVA: 0xD2FFC4
	public object Create_Content(object pNode, object content, object bText, object x, object y, object width, object bSelf, object bUse_Entry, object bneedRemoveEmoji, object ent) { }

	// RVA: 0xD30718
	private object SetGameVipChatMsgColor(object label, object ent, object content, object bSelf) { }

	// RVA: 0xD30E4C
	private object IsRichText(object content) { }

	// RVA: 0xD310A4
	private object GetVipPlayerMsgColorSwitch(object ent, object bSelf) { }

	// RVA: 0xD304E4
	private object GetTextLabel(object name, object template, object pNode) { }

	// RVA: 0xD30B70
	private object GetImage(object index, object template, object pNode) { }

	// RVA: 0xD3119C
	public object ClearRegionChatData() { }

	// RVA: 0xD31388
	public object .ctor() { }

	// RVA: 0xD31400
	private static object .cctor() { }

}

// Namespace: 
public class MapDrag
{

	// Fields
	public object canvas; // 0x18
	public object imgRect; // 0x20
	private object offset; // 0x28
	private object picSize; // 0x30
	public object formCanvas; // 0x38
	private object minX; // 0x40
	private object minY; // 0x44
	private object maxX; // 0x48
	private object maxY; // 0x4C
	public object TimeSpeed; // 0x50
	private object isBeginLerp; // 0x54
	private object detVectorPosition; // 0x58

	// Methods

	// RVA: 0xD31480
	private object Start() { }

	// RVA: 0xD31530
	public object OnPointerDown(object eventData) { }

	// RVA: 0xD316A8
	public object OnDrag(object eventData) { }

	// RVA: 0xD31938
	private object JudgePosition(object last) { }

	// RVA: 0xD31A00
	public object Update() { }

	// RVA: 0xD31BB0
	public object OnEndDrag(object eventData) { }

	// RVA: 0xD31C1C
	public object .ctor() { }

}

// Namespace: 
public enum ItemType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Hero;
	public const object Skin;
	public const object Item;
	public const object SoldierSkin;
}

// Namespace: 
public enum IconType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Small;
}

// Namespace: 
public enum PayBy
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object OnlyOne;
	public const object Both;
}

// Namespace: 
public enum OldPriceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object FirstOne;
	public const object SecondOne;
	public const object Both;
}

// Namespace: 
public class CMallItem
{

	// Fields
	private object m_type; // 0x8
	private object m_iconType; // 0xC
	private object m_heroData; // 0x10
	private object m_product; // 0x18
	private object m_useable; // 0x20
	private object m_skinData; // 0x28
	private object m_firstName; // 0x30
	private object m_secondName; // 0x38
	private object m_iconPath; // 0x40
	private object m_payInfoSet; // 0x48
	private object m_soldOut; // 0x58
	private object originID; // 0x5C

	// Properties
	public object OriginID { get; }
	public object SoldOut { get; }

	// Methods

	// RVA: 0xD31C90
	public object .ctor(object id, object type, object iconType, object idIsItemId) { }

	// RVA: 0xD32B84
	public object .ctor(object usable, object type) { }

	// RVA: 0xD32C14
	public object .ctor(object heroID, object iconType) { }

	// RVA: 0xD32C24
	public object .ctor(object heroID, object skinID, object iconType) { }

	// RVA: 0xD32CB8
	public object .ctor(object product, object iconType) { }

	// RVA: 0xD33278
	public object Icon() { }

	// RVA: 0xD332D8
	public object Type() { }

	// RVA: 0xD33338
	public object GetUseable() { }

	// RVA: 0xD33398
	public object GetIconType() { }

	// RVA: 0xD333F8
	public object get_OriginID() { }

	// RVA: 0xD33458
	public object get_SoldOut() { }

	// RVA: 0xD334B8
	public object Grade() { }

	// RVA: 0xD3353C
	public object Job() { }

	// RVA: 0xD33684
	public object Owned() { }

	// RVA: 0xD33A38
	public object CanSendFriend() { }

	// RVA: 0xD33C08
	public object SetPayinfo(object payinfo) { }

	// RVA: 0xD33C84
	public object HeroID() { }

	// RVA: 0xD33DB0
	public object SkinID() { }

	// RVA: 0xD33E28
	public object SkinUniqID() { }

	// RVA: 0xD33EA0
	public object Product() { }

	// RVA: 0xD33F00
	public object FirstName() { }

	// RVA: 0xD33F60
	public object SecondName() { }

	// RVA: 0xD33FC0
	public object PayInfoSet(object isDianquanOnly) { }

	// RVA: 0xD34240
	public object IsValidExperience() { }

	// RVA: 0xD343EC
	public object IsSourceplanExp() { }

	// RVA: 0xD34598
	public object IsInInstallment() { }

	// RVA: 0xD345F4
	public object GetOldPriceType(object couponDiscount) { }

	// RVA: 0xD347E4
	public object TagType() { }

	// RVA: 0xD34A28
	public object TagInfo(object iconPath, object text, object owned) { }

	// RVA: 0xD34FB8
	public object AddTag(object gameObject, object content) { }

	// RVA: 0xD35974
	public static object OnTimerEnd(object timerScript) { }

	// RVA: 0xD35A68
	public object ObtWayAction() { }

	// RVA: 0xD35CBC
	public object ObtWay() { }

	// RVA: 0xD35F10
	public object PayWay() { }

}

// Namespace: 
public enum BuyContainer
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Coin;
	public const object Dianmond;
}

// Namespace: 
public enum ItemType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Hero;
	public const object Skin;
}

// Namespace: 
private sealed class <>c__DisplayClass34_0
{

	// Fields
	public object item; // 0x8

	// Methods

	// RVA: 0xD3A380
	public object .ctor() { }

	// RVA: 0xD3A9C0
	internal object <SetMallItem>b__0(object e) { }

}

// Namespace: 
public class CMallItemWidget
{

	// Fields
	private object m_icon; // 0x18
	private object m_smallicon; // 0x20
	private object m_smalliconFrame; // 0x28
	private object m_imgQuality; // 0x30
	private object m_name1; // 0x38
	private object m_name2; // 0x40
	private object m_priceContainer; // 0x48
	private object m_experienceMask; // 0x50
	private object m_tagContainer; // 0x58
	private object m_txtTag; // 0x60
	private object m_buyBtn; // 0x68
	private object m_cantBuyBtn; // 0x70
	private object m_specialOwnedText; // 0x78
	private object m_dcLogo; // 0x80
	private object m_numBg; // 0x88
	private object m_numText; // 0x90
	private object m_icon_filename; // 0x98
	private object m_icon_type; // 0xA0

	// Methods

	// RVA: 0xD35F80
	public object SetBuyButtonVisible(object v) { }

	// RVA: 0xD360D0
	public object SetPriceVisible(object v) { }

	// RVA: 0xD36140
	private object ResetDefaultState() { }

	// RVA: 0xD363C4
	private object SetSmallIconFrame(object item) { }

	// RVA: 0xD36670
	private object DoSetItemImage(object go, object item) { }

	// RVA: 0xD36A94
	private object SetItemImageForAliceShop(object item) { }

	// RVA: 0xD36C6C
	private object SetItemImage(object item) { }

	// RVA: 0xD36CDC
	private object SetItemByType(object item) { }

	// RVA: 0xD374F0
	private object SetItemQuality(object item, object useSmallIcon) { }

	// RVA: 0xD379DC
	public object SetItemName(object item) { }

	// RVA: 0xD37CDC
	private object SetItemTag(object item) { }

	// RVA: 0xD37F48
	public object SetItemPriceInfo(object item, object payInfoSet, object couponDiscount) { }

	// RVA: 0xD39224
	private object SetItemAlreadyHave(object item) { }

	// RVA: 0xD395F4
	private object HandleDisableHeroState(object item) { }

	// RVA: 0xD39954
	public object SetMallItem(object item) { }

	// RVA: 0xD3A388
	public object SetGiftItem(object item) { }

	// RVA: 0xD3A960
	public object .ctor() { }

}

// Namespace: 
public static class ResBoutiqueConfExt
{

	// Methods

	// RVA: 0xD3AA28
	private static object RemoveReddotRecord(object c) { }

	// RVA: 0xD3AB38
	public static object SetAsRead(object x, object refresh) { }

	// RVA: 0xD3AD00
	public static object ShouldNotify(object x) { }

	// RVA: 0xD3AE1C
	public static object GetAvaiSpecsale(object x) { }

}

// Namespace: 
public class Data
{

	// Fields
	public object NewArrival; // 0x8
	public object HotSale; // 0x10

	// Methods

	// RVA: 0xD3BD3C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__5_0; // 0x8
	public static object <>9__6_0; // 0x10

	// Methods

	// RVA: 0xD3BEDC
	private static object .cctor() { }

	// RVA: 0xD3BF3C
	public object .ctor() { }

	// RVA: 0xD3BF44
	internal object <get_IsAnyNewShouldNotify>b__5_0(object x) { }

	// RVA: 0xD3BF4C
	internal object <GetBoutiqueData>b__6_0(object l, object r) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object role; // 0x8

	// Methods

	// RVA: 0xD3BD34
	public object .ctor() { }

	// RVA: 0xD3BF88
	internal object <GetBoutiqueData>b__1(object x) { }

}

// Namespace: 
public class CMallBoutiqueModel
{

	// Fields
	private static object cachedData; // 0x0

	// Properties
	public static object IsAnyNewShouldNotify { get; }

	// Methods

	// RVA: 0xD3AFBC
	public static object InvalidateCache() { }

	// RVA: 0xD3B044
	public static object SetAsRead(object refresh) { }

	// RVA: 0xD3BBB8
	public static object get_IsAnyNewShouldNotify() { }

	// RVA: 0xD3B404
	public static object GetBoutiqueData() { }

	// RVA: 0xD3BED4
	public object .ctor() { }

}

// Namespace: 
public class CUIPrice
{

	// Fields
	private object txt_name; // 0x18
	private object txt_price; // 0x20
	private object txt_old_price; // 0x28
	private object obj_cost_type; // 0x30
	private object _form; // 0x38

	// Methods

	// RVA: 0xD3C04C
	public object SetActive(object active) { }

	// RVA: 0xD3C2A0
	public object SetPrice(object payType, object price, object oldPrice, object costName) { }

	// RVA: 0xD3C6D8
	public object SetPirceOfCostItem(object itemid, object count, object costName) { }

	// RVA: 0xD3CA88
	public object SetItemPriceOfCostCoin(object itemid, object count) { }

	// RVA: 0xD3CD80
	public object .ctor() { }

}

// Namespace: 
public class RecommendData
{

	// Properties
	public object srv_hero_favor_order_raw { get; }
	public object recommend_list_hero_global { get; }
	public object recommend_list_skin_global { get; }
	public object srv_skin_favor_order_raw { get; }
	public object recommend_list_item_global { get; }
	public object srv_MangoItem_list { get; }

	// Methods

	// RVA: 0xD3CD88
	public object get_srv_hero_favor_order_raw() { }

	// RVA: 0xD3CE3C
	public object get_recommend_list_hero_global() { }

	// RVA: 0xD3CEF0
	public object get_recommend_list_skin_global() { }

	// RVA: 0xD3CFA4
	public object get_srv_skin_favor_order_raw() { }

	// RVA: 0xD3D058
	public object get_recommend_list_item_global() { }

	// RVA: 0xD3D10C
	public object get_srv_MangoItem_list() { }

	// RVA: 0xD3D1C0
	public object .ctor() { }

}

// Namespace: 
private class PreOrderEntry
{

	// Fields
	public object ID; // 0x8
	public object priority; // 0xC

	// Methods

	// RVA: 0xD44788
	public object .ctor() { }

}

// Namespace: 
private class SkinSortInfo
{

	// Fields
	public object CanBuy; // 0x8
	public object isOwn; // 0x9
	public object BuySortIDPriority; // 0xC
	public object PromoSortID; // 0x10

	// Methods

	// RVA: 0xD44790
	public object .ctor() { }

}

// Namespace: 
public class CircledEnumerator<T0>
{

	// Fields
	private object c; // 0x0
	private object l; // 0x0
	private object onRewind; // 0x0
	private object firstMoved; // 0x0

	// Properties
	private object System.Collections.IEnumerator.Current { get; }
	public object Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object l, object onRewind) { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__0_2; // 0x18
	public static object <>9__19_0; // 0x20
	public static object <>9__19_2; // 0x28
	public static object <>9__20_0; // 0x30
	public static object <>9__22_0; // 0x38
	public static object <>9__22_1; // 0x40
	public static object <>9__23_0; // 0x48
	public static object <>9__24_0; // 0x50
	public static object <>9__24_1; // 0x58
	public static object <>9__24_2; // 0x60
	public static object <>9__24_3; // 0x68

	// Methods

	// RVA: 0xD44798
	private static object .cctor() { }

	// RVA: 0xD447F8
	public object .ctor() { }

	// RVA: 0xD44800
	internal object <Init>b__0_0(object e) { }

	// RVA: 0xD4487C
	internal object <Init>b__0_1(object id) { }

	// RVA: 0xD448F8
	internal object <Init>b__0_2(object h, object s, object r) { }

	// RVA: 0xD44974
	internal object <__init_hero_sort_config_lazy>b__19_0(object x) { }

	// RVA: 0xD449B4
	internal object <__init_hero_sort_config_lazy>b__19_2(object x, object y) { }

	// RVA: 0xD449F4
	internal object <__init_srv_recommend_hero_global_lazy>b__20_0(object x) { }

	// RVA: 0xD44A9C
	internal object <__init_srv_recommend_skin_global_lazy>b__22_0(object l) { }

	// RVA: 0xD44B48
	internal object <__init_srv_recommend_skin_global_lazy>b__22_1(object l) { }

	// RVA: 0xD44CCC
	internal object <__init_srv_recommend_skin_global_lazy_opt>b__23_0(object a, object b) { }

	// RVA: 0xD44DBC
	internal object <__init_skin_sort_config_lazy>b__24_0(object x) { }

	// RVA: 0xD44DFC
	internal object <__init_skin_sort_config_lazy>b__24_1(object x, object y) { }

	// RVA: 0xD44E3C
	internal object <__init_skin_sort_config_lazy>b__24_2(object x) { }

	// RVA: 0xD44E7C
	internal object <__init_skin_sort_config_lazy>b__24_3(object x, object y) { }

}

// Namespace: 
private sealed class <>c__DisplayClass19_0
{

	// Fields
	public object isNewBie; // 0x8

	// Methods

	// RVA: 0xD44EBC
	public object .ctor() { }

	// RVA: 0xD44EC4
	internal object <__init_hero_sort_config_lazy>b__1(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass22_0
{

	// Fields
	public object parsing_heroid; // 0x8

	// Methods

	// RVA: 0xD44EF8
	public object .ctor() { }

	// RVA: 0xD44F00
	internal object <__init_srv_recommend_skin_global_lazy>b__2() { }

}

// Namespace: 
public class CRecommendModel
{

	// Fields
	public static object srv_hero_favor_order_raw; // 0x0
	public static object recommend_list_hero_global; // 0x8
	public static object recommend_list_skin_global; // 0x10
	public static object srv_skin_favor_order_raw; // 0x18
	public static object recommend_list_item_global; // 0x20
	public static object srv_MangoItem_list; // 0x28
	private static object role; // 0x30
	private static object preOrderedHeroes; // 0x38
	private static object preOrderedSkins; // 0x40
	private static object mangoHeros; // 0x48
	private static object mangoSkins; // 0x50
	private static object skinSortCache; // 0x58

	// Methods

	// RVA: 0xD3D1C8
	public static object Init() { }

	// RVA: 0xD3D5B4
	public static object OnRcv_SCID_RECOMMEND_GLOBAL_HERO_NTF(object msg) { }

	// RVA: 0xD3D6F8
	public static object OnRcv_SCID_RECOMMEND_GLOBAL_SKIN_NTF(object msg) { }

	// RVA: 0xD3D83C
	public static object OnRcv_SCID_RECOMMEND_GLOBAL_ITEM_NTF(object msg) { }

	// RVA: 0xD3D978
	public static object OnRcv_SCID_MANGOLIST_ITEM_NTF(object msg) { }

	// RVA: 0xD3DE34
	private static object __init_hero_sort_config_lazy() { }

	// RVA: 0xD3ED04
	private static object __init_srv_recommend_hero_global_lazy() { }

	// RVA: 0xD3EF9C
	private static object __init_srv_recommend_skin_global_lazy() { }

	// RVA: 0xD3F5BC
	private static object __init_srv_recommend_skin_global_lazy_opt() { }

	// RVA: 0xD3FFA4
	private static object __init_skin_sort_config_lazy() { }

	// RVA: 0xD419B8
	public static object MallHeroSortDefault(object l, object r) { }

	// RVA: 0xD421F4
	public static object MallHeroSortDefault_RecommendDataApplied(object l, object r) { }

	// RVA: 0xD42488
	public static object PreSortOwnState(object l, object r) { }

	// RVA: 0xD41670
	private static object GetSkinSortInfoCached(object skin) { }

	// RVA: 0xD42AD0
	public static object MallSkinSortNewByDefault(object l, object r) { }

	// RVA: 0xD42EB8
	public static object MallSkinSortByDefault(object l, object r) { }

	// RVA: 0xD4333C
	private static object GetSkinShelfPriority(object skin, object roleInfo) { }

	// RVA: 0xD43528
	public static object MallSkinSortDefault_RecommendDataApplied(object l, object r) { }

	// RVA: 0xD43E04
	public static object HeroViewSortDefault(object l, object r) { }

	// RVA: 0xD44578
	public object .ctor() { }

	// RVA: 0xD44580
	private static object .cctor() { }

}

// Namespace: 
public static class COMDT_GLOBAL_RECOMMEND_SKIN_NODE_EXT
{

	// Methods

	// RVA: 0xD44BFC
	public static object GetHeroID(object thiz) { }

}

// Namespace: 
public static class COMDT_GLOBAL_RECOMMEND_ITEM_NODE_EXT
{

	// Methods

	// RVA: 0xD44F08
	public static object GetSpecSaleID(object thiz) { }

}

// Namespace: 
public static class ResHeroCfgInfoExt
{

	// Methods

	// RVA: 0xD45020
	public static object GetPriorityByBuySortID(object l) { }

	// RVA: 0xD4543C
	public static object GetHeroShopNormalSortID(object l) { }

	// RVA: 0xD451C4
	public static object GetPromoSortIDOnly(object l) { }

	// RVA: 0xD455D4
	public static object GetPromoSortID(object l, object isRegisterSale, object poromt) { }

	// RVA: 0xD45870
	public static object GetPriorityByBuySortID(object l, object PromoSID) { }

	// RVA: 0xD45A10
	public static object GetPromoSortID(object l) { }

	// RVA: 0xD45BF0
	public static object GetSkinCanBuy(object l) { }

}

// Namespace: 
public class DrawBoard
{

	// Fields
	public object lineColor; // 0x18
	public object lineWidth; // 0x1C
	public object clearTexture; // 0x20
	public object mat; // 0x28
	private object _rectTransform; // 0x30
	private object _renderTexture; // 0x38
	private object _lastPoint; // 0x40
	private object _drawing; // 0x48
	private object _pointId; // 0x4C
	private object _canDraw; // 0x50
	private static object lineMaterial; // 0x0
	public object drawCount; // 0x54
	public object maxPointNum; // 0x58
	public object onEndDraw; // 0x60
	public object onBeginDraw; // 0x68
	public object onDrawing; // 0x70
	public object DefaultTexture; // 0x78
	public object rpoints; // 0x80
	private object vertList; // 0x88
	private object _drawVerts; // 0x90

	// Properties
	public object CanDraw { get; set; }

	// Methods

	// RVA: 0xD45DC8
	public object get_CanDraw() { }

	// RVA: 0xD45DD0
	public object set_CanDraw(object value) { }

	// RVA: 0xD45DD8
	private object Awake() { }

	// RVA: 0xD45F68
	private object Start() { }

	// RVA: 0xD460D8
	public object DrawDefault() { }

	// RVA: 0xD462C4
	private object OnDestroy() { }

	// RVA: 0xD4637C
	public object OnPointerUp(object eventData) { }

	// RVA: 0xD464F4
	public object OnPointerDown(object eventData) { }

	// RVA: 0xD467A4
	public object OnDrag(object eventData) { }

	// RVA: 0xD46154
	public object Clear(object bClearPoints) { }

	// RVA: 0xD466A8
	private object _ScreenPosToDrawPos(object eventData, object drawPos) { }

	// RVA: 0xD46A88
	private object DrawLineCopy(object newPoint, object lastPoint) { }

	// RVA: 0xD46B68
	private object DrawLine2(object newPoint, object lastPoint) { }

	// RVA: 0xD46EF4
	private object DrawPointCopy(object point) { }

	// RVA: 0xD474BC
	private object DrawLine(object points, object angle) { }

	// RVA: 0xD463F0
	public object UpdateBoard() { }

	// RVA: 0xD46984
	private object CheckDistance(object startPos, object endPos) { }

	// RVA: 0xD4829C
	private object _CalculateVert(object point, object dir, object width) { }

	// RVA: 0xD48460
	private object _CalculateTexCoordUnit(object start, object end) { }

	// RVA: 0xD48244
	private object Rotation2DVector(object dir, object angle, object offset) { }

	// RVA: 0xD48558
	private object DrawQuad() { }

	// RVA: 0xD46F9C
	private object DrawPoint(object point) { }

	// RVA: 0xD486F0
	public object .ctor() { }

}

// Namespace: 
public class CHeroSkillUpgradeGiftItemWidget
{

	// Fields
	public object itemCell; // 0x18
	public object itemName; // 0x20
	public object unSelected; // 0x28
	public object selected; // 0x30
	public object cannotSelectMask; // 0x38
	public object heroExpInfo; // 0x40

	// Methods

	// RVA: 0xD48B18
	public object .ctor() { }

}

// Namespace: 
public class CHeroSkillUpgradeGiftWidget
{

	// Fields
	public object rewardNumTip; // 0x18
	public object itemListScript; // 0x20
	public object exchangeButton; // 0x28

	// Methods

	// RVA: 0xD48B20
	public object .ctor() { }

}

// Namespace: 
public class CPlentyTaskItemWidget
{

	// Fields
	public object FinishedCnt; // 0x18
	public object FinishedCnt_On; // 0x20
	public object FinishedCnt_Disable; // 0x28
	public object RewardBtn; // 0x30
	public object rewards; // 0x38
	public object boxEffect; // 0x40
	public object cntBgSelect; // 0x48
	public object cntBgUnselect; // 0x50
	public object taskBgSelect; // 0x58
	public object taskBgUnselect; // 0x60
	public object cntBgDisable; // 0x68
	public object taskBgDisable; // 0x70
	public object MaskOver; // 0x78
	public object nIndex; // 0x80

	// Methods

	// RVA: 0xD48B28
	public object InitView(object isCompleted, object idx, object item) { }

	// RVA: 0xD494D8
	public object CompleteTaskRefreshView(object taskItem) { }

	// RVA: 0xD49544
	public object BoxEffectChanged(object bEnable) { }

	// RVA: 0xD48FBC
	public object UpdateItemState(object taskItem) { }

	// RVA: 0xD496CC
	public object .ctor() { }

}

// Namespace: 
public class CPlentyTaskWidget
{

	// Fields
	public object weekKillCountText; // 0x18
	public object weekStartRewardCount; // 0x20
	public object FinishedGameCnt; // 0x28
	public object TimerCountDownText; // 0x30
	public object TaskContainer; // 0x38
	public object BoxEffect; // 0x40
	public object KillCntMaskOver; // 0x48
	public object KillCntPanel; // 0x50
	public object KillRewardBtn; // 0x58
	public object listScript; // 0x60
	public object lbCurCreditScoreDesc; // 0x68
	public object lbCurCreditBuffDesc; // 0x70

	// Methods

	// RVA: 0xD496D4
	public object RefreshKillCntTaskView(object taskItem) { }

	// RVA: 0xD49AE0
	public object UpdateWeekCnt(object weekStarCnt, object weekStarCntLimit) { }

	// RVA: 0xD49CCC
	public object InitStarAndGameCnt(object weekStarCnt, object WeekStarCntLimit, object CompleteTotalCnt) { }

	// RVA: 0xD498C0
	public object BoxEffectStateChanged(object bEnable) { }

	// RVA: 0xD49F18
	public object CompleteTaskRefreshView() { }

	// RVA: 0xD49F9C
	public object UpdateCreditScorePanel() { }

	// RVA: 0xD4A28C
	public object .ctor() { }

}

// Namespace: 
public class CPlatformDataHelper
{

	// Fields
	public object toggle; // 0x18
	public object icon; // 0x20
	public object platformName; // 0x28
	public object ExtendGo; // 0x30
	public object mCacheData; // 0x38

	// Methods

	// RVA: 0xD4A294
	public object OnValueChanged(object isToggled) { }

	// RVA: 0xD4A498
	public object .ctor() { }

}

// Namespace: 
public static class CPlatformDataHelperExtension
{

	// Methods

	// RVA: 0xD4A4A0
	public static object IsToggle(object helper) { }

	// RVA: 0xD4A600
	public static object Show(object helper, object bShow) { }

	// RVA: 0xD4A704
	public static object Init(object helper, object data, object bDefaultToggle, object bInitShow, object group) { }

}

// Namespace: 
public class CVideoSharePlatformHelper
{

	// Fields
	public object platformRootGo; // 0x18
	public object buttonGroupGo; // 0x20
	public object toggleGroup; // 0x28
	private object helperList; // 0x30

	// Methods

	// RVA: 0xD4A8EC
	public object .ctor() { }

}

// Namespace: 
public class CDailyTaskViewExchangeItemWidget
{

	// Fields
	public object imgExchangeItemBefore; // 0x18
	public object imgExchangeItemAfter; // 0x20
	public object btnExchange; // 0x28
	public object imgExchange; // 0x30
	public object txtExchangeDesc; // 0x38
	public object nIndex; // 0x40

	// Methods

	// RVA: 0xD4A96C
	public object .ctor() { }

}

// Namespace: 
public class CDailyTaskViewItemWidget
{

	// Fields
	public object imgLuckyTag; // 0x18
	public object imgLuckyMask; // 0x20
	public object imgBgYellow; // 0x28
	public object imgBgBlack; // 0x30
	public object goLucky; // 0x38
	public object goNormal; // 0x40
	public object gohaveDone; // 0x48
	public object btnCanGet; // 0x50
	public object btnGoComplete; // 0x58
	public object btnNotComplete; // 0x60
	public object imgPrizeIcon; // 0x68
	public object txtProcess; // 0x70
	public object txtPrizeNum; // 0x78
	public object txtDesc; // 0x80
	public object txtPoint; // 0x88
	public object nIndex; // 0x90

	// Methods

	// RVA: 0xD4A974
	public object .ctor() { }

}

// Namespace: 
public class CDailyTaskViewWidget
{

	// Fields
	public object txtDayActityPoint; // 0x18
	public object txtDaytimes; // 0x20
	public object txtWeekActityPoint; // 0x28
	public object txtWeektimes; // 0x30
	public object lstTask; // 0x38
	public object lstExchange; // 0x40

	// Methods

	// RVA: 0xD4A97C
	public object .ctor() { }

}

// Namespace: 
public class FiveCampSignalTipShower
{

	// Fields
	public object senderFrame; // 0x190
	public object battleSenderFrame; // 0x198
	public object targetFrame; // 0x1A0
	public object ActorAttach_Normal; // 0x1A8
	public object ActorFrame_Normal; // 0x1B0
	public object ActorIconWidth; // 0x1B8
	public object ActorIconHeight; // 0x1BC
	private object actionIcons_Normal; // 0x1C0

	// Methods

	// RVA: 0xD4A984
	protected override object UpdateState_Normal(object data) { }

	// RVA: 0xD4B83C
	protected override object UpdateState_BattleMsg(object data) { }

	// RVA: 0xD4BB20
	protected override object UpdatePosition_Normal() { }

	// RVA: 0xD4AF50
	private object SetActorIcons(object signalID, object attaches, object frames) { }

	// RVA: 0xD4C11C
	public object .ctor() { }

	// RVA: 0xD4C1D0
	public object <>iFixBaseProxy_UpdateState_Normal(object P0) { }

	// RVA: 0xD4C1D8
	public object <>iFixBaseProxy_UpdateState_BattleMsg(object P0) { }

	// RVA: 0xD4C1E0
	public object <>iFixBaseProxy_UpdatePosition_Normal() { }

}

// Namespace: 
public class NewSimpleTaskWidget
{

	// Fields
	public object treeScript; // 0x18
	public object closeBtn; // 0x20
	public object time; // 0x28
	public object heroImage; // 0x30
	public object heroName; // 0x38
	public object processText; // 0x40
	public object processBar; // 0x48
	public object getReward; // 0x50
	public object getReward_disable; // 0x58
	public object levelListScript; // 0x60
	public object UnlockLabel; // 0x68
	public object Level; // 0x70
	public object LVText; // 0x78
	public object SystemTxt1; // 0x80
	public object SystemTxt2; // 0x88
	public object LevelRewardContainer; // 0x90
	public object LevelRewardBtn; // 0x98
	public object LevelRewardBtn_disable; // 0xA0
	public object NewbieWealCDNImage; // 0xA8

	// Methods

	// RVA: 0xD4C1E8
	public object .ctor() { }

}

// Namespace: 
public class StopEfxWhenOutBound
{

	// Fields
	public object GoEfx2Stop; // 0x18
	public object TargetRect; // 0x20
	public object BoundRect; // 0x28
	public object canvas; // 0x30
	private object _camera; // 0x38

	// Methods

	// RVA: 0xD4C1F0
	private object Start() { }

	// RVA: 0xD4C2B0
	private object Update() { }

	// RVA: 0xD4C4C4
	public object .ctor() { }

}

// Namespace: 
public enum NewbieViewState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object eNewbieViewState_NULL;
	public const object eNewbieViewState_BeforeNotLastOne;
	public const object eNewbieViewState_BeforeLastOne;
	public const object eNewbieViewState_TodayDoing;
	public const object eNewbieViewState_TodayNextDoing;
	public const object eNewbieViewState_TomorrowLastOne;
	public const object eNewbieViewState_TomorrowNotLastOne;
}

// Namespace: 
private class TaskNewbieIdxInfo
{

	// Fields
	public object taskID; // 0x8
	public object preTaskID; // 0xC
	public object followTaskIDArray; // 0x10

	// Methods

	// RVA: 0xD4D1A0
	public object .ctor() { }

}

// Namespace: 
public class TaskNewbieLogic
{

	// Fields
	private object reqGetNewbiePrizeTaskID; // 0x8
	private object heroOwn; // 0xC
	public object taskNewbieList; // 0x10
	private object idxPerforming; // 0x18
	private object idxPerformingFinish; // 0x1C
	private object _DailyTaskNumber; // 0x20

	// Properties
	public object IdxPerforming { get; }
	public object DailyTaskNumber { get; }

	// Methods

	// RVA: 0xD4C4CC
	public object ReqGetNewbieTaskFinishPrize(object taskID) { }

	// RVA: 0xD4C818
	public object IsNeedChargeHeroToCoin(object heroID) { }

	// RVA: 0xD4C8E4
	public object InitNewbieTaskFinishPrize() { }

	// RVA: 0xD4C948
	public object get_IdxPerforming() { }

	// RVA: 0xD4C9A8
	public object get_DailyTaskNumber() { }

	// RVA: 0xD4CAC8
	public object InitConfigNewbieTask() { }

	// RVA: 0xD4D1A8
	public object IsNewbieTask(object taskID) { }

	// RVA: 0xD4D2DC
	public object IsNewbieTaskInCurrentTask() { }

	// RVA: 0xD4D600
	public object GetLobbyShowNewbieTaskPrizeHeroID() { }

	// RVA: 0xD4D4E8
	private object GetIdxOfList(object list, object val) { }

	// RVA: 0xD4D784
	public object GetElementStateByIdx(object idx) { }

	// RVA: 0xD4DB28
	public object TodayTaskIsFinish() { }

	// RVA: 0xD4DD8C
	public object GetElementTaskID(object idx) { }

	// RVA: 0xD4D70C
	public object GetElementPrizeHeroID(object idx) { }

	// RVA: 0xD4C5F4
	public object GetHeroIDByTaskID(object taskID) { }

	// RVA: 0xD4D9B0
	private object GetElementStateByIdxLeftCurIdx(object idx) { }

	// RVA: 0xD4DA30
	private object GetElementStateByIdxEqualCurIdx(object idx) { }

	// RVA: 0xD4DAA4
	private object GetElementStateByIdxRightCurIdx(object idx) { }

	// RVA: 0xD4DF18
	private object GetElementStateByIdxRightCurIdxInCurrentTaskFinish(object idx) { }

	// RVA: 0xD4DFF4
	private object GetElementStateByIdxRightCurIdxInCurrentTaskNotFinish(object idx) { }

	// RVA: 0xD4DBA0
	private object GetTodayFinishNumber() { }

	// RVA: 0xD4E0D8
	public object GetTaskNeedBattleNum(object taskID) { }

	// RVA: 0xD4E29C
	public object GetTaskAreadyBattleNumber(object taskID, object maxNum) { }

	// RVA: 0xD4E440
	public object GetNeedMarkInSliderDict(object maxNum, object taskID) { }

	// RVA: 0xD4E580
	public object GetDoingTaskID() { }

	// RVA: 0xD4E6B4
	public object GetTaskState(object taskID) { }

	// RVA: 0xD4E818
	public object .ctor() { }

}

// Namespace: 
public class CBagSystemEditor
{

	// Methods

	// RVA: 0xD4E8C4
	public object .ctor() { }

}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0xD4E8CC
	private static object Get() { }

	// RVA: 0xD4E99C
	public object .ctor() { }

}

// Namespace: MS.UI
public class ChangeChildrenPosByDistance
{

	// Fields
	public object CenterPositionOffset; // 0x18
	public object DefaultPosX; // 0x20
	public object MinPosX; // 0x24
	public object DistanceRate; // 0x28
	public object DistanceChangePosCurve; // 0x30
	public object AlphaChangePosCurve; // 0x38
	public object scrollRect; // 0x40
	private object _childList; // 0x48
	private object _rectTrans; // 0x50
	private object _corners; // 0x58

	// Properties
	private object RectTrans { get; }

	// Methods

	// RVA: 0xD4EAD8
	private object get_RectTrans() { }

	// RVA: 0xD4EBF0
	public object SetLayoutHorizontal() { }

	// RVA: 0xD4F3E4
	public object SetLayoutVertical() { }

	// RVA: 0xD4F44C
	private object LateUpdate() { }

	// RVA: 0xD4EC58
	private object CollectChildList() { }

	// RVA: 0xD4EF18
	private object ChangeScale() { }

	// RVA: 0xD4F4E8
	private object GetRectCenterPosition(object rect) { }

	// RVA: 0xD4F5AC
	private object Update() { }

	// RVA: 0xD4F614
	public object .ctor() { }

}

// Namespace: Assets.Scripts.UI
public class CUITweenAnimActionBindTarget
{

	// Fields
	public object targetPathUpCount; // 0x18
	public object targetPathDown; // 0x20
	private object animAction; // 0x28

	// Methods

	// RVA: 0xD4F6D4
	private object Update() { }

	// RVA: 0xD4F734
	private object FindTarget() { }

	// RVA: 0xD4FA40
	public object .ctor() { }

}

// Namespace: Assets.Scripts.UI
internal class LobbyTurnTableLotteryWidgetView
{

	// Fields
	public object root; // 0x38

	// Methods

	// RVA: 0xD4FA48
	public override object Init() { }

	// RVA: 0xD4FB68
	private object UpdateEntryRoot() { }

	// RVA: 0xD4FC0C
	public override object UnInit() { }

	// RVA: 0xD4FD24
	public object .ctor() { }

	// RVA: 0xD4FD2C
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xD4FD34
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.UI
internal class LobbyActivityPointWidgetView
{

	// Fields
	public object goOn; // 0x38
	public object goOff; // 0x40

	// Methods

	// RVA: 0xD4FD3C
	public override object Init() { }

	// RVA: 0xD4FFE8
	private object Start() { }

	// RVA: 0xD50108
	private object OnDestroy() { }

	// RVA: 0xD50228
	private object OnLobbyRedPoint(object num) { }

	// RVA: 0xD4FDEC
	private object SetRedPoint(object num) { }

	// RVA: 0xD50294
	public object .ctor() { }

	// RVA: 0xD5029C
	public object <>iFixBaseProxy_Init() { }

}

// Namespace: Assets.Scripts.UI
internal class LobbyEveryDayFightWidgetView
{

	// Fields
	private const object InvalidTaskID;
	private object m_ActPointsList; // 0x68
	private object m_lastRequestTaskID; // 0x70
	private object attachedGameObj; // 0x78
	private object titleText; // 0x80
	private object rewardCount; // 0x88
	private object rewardsidds; // 0x90

	// Methods

	// RVA: 0xD502A4
	protected override object OnViewInited() { }

	// RVA: 0xD5128C
	public override object OnFormDestroyed() { }

	// RVA: 0xD51568
	private object OnTaskSubmit(object uiEvent) { }

	// RVA: 0xD515D0
	private object CheckAndSendTask() { }

	// RVA: 0xD51AF8
	private object CheckNewbieTaskAndSendTask() { }

	// RVA: 0xD51C18
	private object OnClickLobbyActPanel(object uiEvent) { }

	// RVA: 0xD51F68
	private object CreateActPoints(object parent, object template, object count) { }

	// RVA: 0xD52294
	private object SetActPointState(object obj, object isKey, object isShow, object index) { }

	// RVA: 0xD50514
	public object ShowActivityVal() { }

	// RVA: 0xD526D8
	private object PlayGiftBoxEffectAnimation(object go, object hasTaskHaveDone) { }

	// RVA: 0xD528A0
	private object OnTaskUpdate() { }

	// RVA: 0xD523F4
	public object updateNewbieBtn() { }

	// RVA: 0xD52CE8
	public object .ctor() { }

	// RVA: 0xD52DB8
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xD52DC0
	public object <>iFixBaseProxy_OnFormDestroyed() { }

}

// Namespace: Assets.Scripts.UI
internal class LobbyNewbieTaskWidgetView
{

	// Fields
	public object awardCountDown; // 0x38

	// Methods

	// RVA: 0xD52DC8
	public override object Init() { }

	// RVA: 0xD53180
	private object OnClick(object uiEvent) { }

	// RVA: 0xD53274
	public override object Appear() { }

	// RVA: 0xD532D0
	public override object UnInit() { }

	// RVA: 0xD53430
	public object .ctor() { }

	// RVA: 0xD53438
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xD53440
	public object <>iFixBaseProxy_Appear() { }

	// RVA: 0xD53448
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CBirthdayShareUI
{

	// Fields
	private object PanelShare; // 0x18
	private object cdn1Year; // 0x20
	private object txtTitle; // 0x28
	private object txtBirthday; // 0x30
	private object txtDesc; // 0x38
	private object txtDescValue; // 0x40
	private object txtBestKills; // 0x48
	private object txtBestAssist; // 0x50
	private object txtBestTakeDamage; // 0x58
	private object txtBestEconomy; // 0x60
	private object imgPlayerHead; // 0x68
	private object _form; // 0x70
	private const object BirthdaySharePrefab;

	// Methods

	// RVA: 0xD53450
	private object Start() { }

	// RVA: 0xD53C68
	public static object Open() { }

	// RVA: 0xD53E74
	public object .ctor() { }

}

// Namespace: 
public static class Event
{

	// Fields
	internal static readonly object ReceiveRewardSuccess; // 0x0

	// Methods

	// RVA: 0xD55DB0
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__20_0; // 0x8

	// Methods

	// RVA: 0xD55E2C
	private static object .cctor() { }

	// RVA: 0xD55E8C
	public object .ctor() { }

	// RVA: 0xD55E94
	internal object <Init>b__20_0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass25_0
{

	// Fields
	public object pkg; // 0x8

	// Methods

	// RVA: 0xD55244
	public object .ctor() { }

	// RVA: 0xD55E98
	internal object <OnRewardRsp>b__0(object x) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CBirthdaySystem
{

	// Fields
	private const object eventPatchKey;
	private const object birthdayWindowPrefab;
	private object eventsPatchInQueue; // 0x8
	private object rewardsAvaliable; // 0xC
	private object allQueueHeadPtr; // 0x10
	private object unExpiredQueueHeadPtr; // 0x14
	private object showExpired; // 0x18
	private object showFromPailian; // 0x19
	private object window; // 0x20
	public object m_AllBirthdayInfoList; // 0x28
	public object m_UnExpiredBirthdayInfoList; // 0x30

	// Properties
	public object NeedShowBirthdayIconInLobby { get; }
	public object currentBirthdayInfo { get; }

	// Methods

	// RVA: 0xD53E7C
	public object get_NeedShowBirthdayIconInLobby() { }

	// RVA: 0xD53B64
	public object get_currentBirthdayInfo() { }

	// RVA: 0xD53FB0
	public object dequeueBirthdayInfo() { }

	// RVA: 0xD540A0
	public object resetQueueHead() { }

	// RVA: 0xD54100
	public object sortBirthdayList() { }

	// RVA: 0xD541F4
	private static object sort(object left, object right) { }

	// RVA: 0xD5440C
	public override object Init() { }

	// RVA: 0xD546D4
	private object OpenForm(object uiEvent) { }

	// RVA: 0xD549AC
	private object CloseForm(object uiEvent) { }

	// RVA: 0xD54C60
	public object Clear() { }

	// RVA: 0xD54D24
	public static object SendReceiveReward() { }

	// RVA: 0xD54E90
	public static object OnRewardRsp(object pkg) { }

	// RVA: 0xD5524C
	public static object OnBirthdayNtf(object pkg) { }

	// RVA: 0xD556A8
	private static object pushBirthdaySequence() { }

	// RVA: 0xD55BA8
	private static object ShowAllBirthdayInfoNormal() { }

	// RVA: 0xD55CF0
	public object .ctor() { }

	// RVA: 0xD55DAC
	public object <>iFixBaseProxy_Init() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIBirthdayRewardItem
{

	// Fields
	private object ItemGo; // 0x78
	private object HeroGo; // 0x80
	private object ExperienceTag; // 0x88
	private object UIEvent; // 0x90
	private object parentForm; // 0x98
	private object ItemImage; // 0xA0
	private object HeroImage; // 0xA8

	// Methods

	// RVA: 0xD55F10
	public object ShowReward(object useable) { }

	// RVA: 0xD56288
	protected override object OnViewInited() { }

	// RVA: 0xD56324
	private object CheckComponentNull() { }

	// RVA: 0xD567AC
	public object .ctor() { }

	// RVA: 0xD567B4
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: 
private enum SwitchStatusKey
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object HISTORY;
	public const object EVALUATE;
}

// Namespace: Assets.Scripts.GameSystem
public class CUIBirthdayWindow
{

	// Fields
	private object BgCDN; // 0x78
	private object RewardItems; // 0x80
	private object LegendStartTime; // 0x88
	private object TotalBattleNum; // 0x90
	private object TotalHeroNum; // 0x98
	private object TotalSkinNum; // 0xA0
	private object BestKilling; // 0xA8
	private object BestAssistance; // 0xB0
	private object MostDamageSoaked; // 0xB8
	private object Richest; // 0xC0
	private object TabSwitchMarkStatus; // 0xC8
	private object EvaluateTitle; // 0xD0
	private object EvaluateDescTitle; // 0xD8
	private object EvaluateDescValue; // 0xE0
	private object PlayerHeadIcon; // 0xE8
	private object HistoryStatisticsNode; // 0xF0
	private object EvaluateNode; // 0xF8
	private object ReceiveRewardBtn; // 0x100
	private object LeftArrow; // 0x108
	private object RightArrow; // 0x110
	private object ReceiveBtnText; // 0x118
	private object ReceiveRewardEventScript; // 0x120
	private object receiveRewardImg; // 0x128
	private object showEvaluate; // 0x130
	private object parentForm; // 0x138

	// Properties
	private object ShowEvaluate { get; set; }

	// Methods

	// RVA: 0xD567BC
	private object get_ShowEvaluate() { }

	// RVA: 0xD5681C
	private object set_ShowEvaluate(object value) { }

	// RVA: 0xD56988
	protected override object OnViewInited() { }

	// RVA: 0xD57858
	protected override object OnRegEvent() { }

	// RVA: 0xD57B18
	protected override object OnUnRegEvent() { }

	// RVA: 0xD57DD8
	protected override object OnShow() { }

	// RVA: 0xD57E44
	private object FillData() { }

	// RVA: 0xD57F2C
	private object FillReward(object rewardDetail) { }

	// RVA: 0xD59028
	private object refreshBtnState() { }

	// RVA: 0xD582A8
	private object FillStartTime(object startTime) { }

	// RVA: 0xD5845C
	private object FillHistoryStatistics(object birthdayInfo) { }

	// RVA: 0xD58954
	private object FillEvaluate(object birthdayInfo) { }

	// RVA: 0xD58DAC
	private object FillCDN() { }

	// RVA: 0xD594AC
	private object OnReceiveRewardSuccess() { }

	// RVA: 0xD59200
	private object ChangeReceiveRewardBtnActiveState(object active, object text) { }

	// RVA: 0xD57768
	private object InitShowEvaluate() { }

	// RVA: 0xD5950C
	private object ReceiveReward(object uiEvent) { }

	// RVA: 0xD59570
	private object Share(object uiEvent) { }

	// RVA: 0xD595D4
	private object SwitchHistory(object uiEvent) { }

	// RVA: 0xD59640
	private object SwitchCertified(object uiEvent) { }

	// RVA: 0xD56A2C
	private object CheckComponentNull() { }

	// RVA: 0xD596AC
	public object .ctor() { }

	// RVA: 0xD596B4
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xD596BC
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xD596C4
	public object <>iFixBaseProxy_OnUnRegEvent() { }

	// RVA: 0xD596CC
	public object <>iFixBaseProxy_OnShow() { }

}

// Namespace: 
public enum enInviteNewPlayerPlat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Messenger;
	public const object WhatsApp;
	public const object Line;
	public const object IMessage;
	public const object Discord;
	public const object Twitter;
	public const object Paste;
}

// Namespace: Assets.Scripts.GameSystem
public class InviteNewPlayerHelper
{

	// Fields
	private static object m_InviteNewPlayerPlatform; // 0x0
	public static readonly object s_PlatformNames; // 0x8
	public static readonly object s_ApolloPlatforms; // 0x10
	public static readonly object s_ShareChannels; // 0x18
	public static readonly object s_H5ChannelNames; // 0x20
	public static readonly object s_ImgLogoPaths; // 0x28

	// Properties
	public static object InviteNewPlayerPlatform { get; }

	// Methods

	// RVA: 0xD596D4
	public static object IsValidSharePlatform(object invitePlat) { }

	// RVA: 0xD59738
	public static object get_InviteNewPlayerPlatform() { }

	// RVA: -1
	public static object ConvertPlatformGeneric(object plat, object platMapArray, object emptyVal) { }

	// RVA: 0xD597E4
	public static object UpdateInviteNewPlayerPlatform() { }

	// RVA: 0xD59A38
	private static object TestAndAddPlatform(object conf) { }

	// RVA: 0xD59F90
	public object .ctor() { }

	// RVA: 0xD59F98
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class ShortCodeGen
{

	// Fields
	private static object logicIDBeginIdx; // 0x0
	public static object logicIDEndIdx; // 0x4
	public static object ShortCodeLength; // 0x8
	public static object SHORTCODE_LENGTH_LIMIT; // 0xC
	public static object chars; // 0x10
	public static object revChars; // 0x18

	// Methods

	// RVA: 0xD5A348
	public override object Init() { }

	// RVA: 0xD5A51C
	public object GetShortCodeByOpenIDAndLocalID(object playerOpenID, object localID, object shortCode) { }

	// RVA: 0xD5A7D8
	private object LongConvertToShortCode(object combineID, object shortCodeStr) { }

	// RVA: 0xD5AB5C
	public object GetOpenIDLocalIDByShortCode(object shortCode, object playerOpenID, object localID) { }

	// RVA: 0xD5B06C
	public object IdToCode(object id) { }

	// RVA: 0xD5B394
	public object CodeToId(object code) { }

	// RVA: 0xD5B528
	public object CreatCodeByID() { }

	// RVA: 0xD5B734
	public object .ctor() { }

	// RVA: 0xD5B78C
	private static object .cctor() { }

	// RVA: 0xD5B87C
	public object <>iFixBaseProxy_Init() { }

}

// Namespace: 
private sealed class <>c__DisplayClass92_0
{

	// Fields
	public object <>4__this; // 0x8
	public object bFind; // 0x10

	// Methods

	// RVA: 0xE4F580
	public object .ctor() { }

	// RVA: 0xE4F588
	internal object <SetCheckInState>b__0(object i, object d) { }

}

// Namespace: Assets.Scripts.GameSystem
public class MonthCheckSystem
{

	// Fields
	public static object sFormPath; // 0x0
	public static object sTipBoxName; // 0x8
	private object m_UpdateTodayTimer; // 0x8
	private object m_weekDayOfMonthFirst; // 0xC
	private object ullRewardMask; // 0x10
	private object ullAccuRewardMask; // 0x18
	public object ullFillinTimes; // 0x20
	public object dwLastCheckTime; // 0x28
	public object dwWealID; // 0x2C
	private object bInActivity; // 0x30
	public object m_CorssMonthCheckInfo; // 0x38
	private object m_bAuto; // 0x40
	private object mLastOpenDateTime; // 0x48
	private object mLastRefreshDateTime; // 0x50
	private object m_LeftMendingTime; // 0x58
	private object mLeftPrimeMendingTime; // 0x5C
	private object m_CheckFreshTimer; // 0x60

	// Properties
	private object m_Form { get; }
	private object mFormCtrl { get; }
	private object mSvrDateTime { get; }
	private object mCliDateTime { get; }
	private object mIsCheckInActActived { get; }
	private object mIsAlreadyCheckIn { get; }
	private object mIsOpenDurationOverOneDay { get; }
	private object mPrevRefreshDateTime { get; }
	private object mNormalMendingCheckConfig { get; }

	// Methods

	// RVA: 0xD5B880
	public override object Init() { }

	// RVA: 0xD5BFCC
	private object _CreateEmptyData() { }

	// RVA: 0xD5C028
	public override object UnInit() { }

	// RVA: 0xD5C750
	public object ClearData() { }

	// RVA: 0xD5C7B4
	private object get_m_Form() { }

	// RVA: 0xD5C8B4
	private object get_mFormCtrl() { }

	// RVA: 0xD5C9B8
	private object get_mSvrDateTime() { }

	// RVA: 0xD5CA60
	private object get_mCliDateTime() { }

	// RVA: 0xD5CB08
	private object get_mIsCheckInActActived() { }

	// RVA: 0xD5CE24
	private object get_mIsAlreadyCheckIn() { }

	// RVA: 0xD5D154
	private object get_mIsOpenDurationOverOneDay() { }

	// RVA: 0xD5D2B8
	private object get_mPrevRefreshDateTime() { }

	// RVA: 0xD5D3DC
	private object get_mNormalMendingCheckConfig() { }

	// RVA: 0xD5D4D4
	public object OpenCheckForm() { }

	// RVA: 0xD5DB30
	private object _GetMendingTimes() { }

	// RVA: 0xD5DA70
	private object RemoveTimer(object timerSeq) { }

	// RVA: 0xD5DC1C
	public object CloseForm(object uiEvent) { }

	// RVA: 0xD5DC84
	private object _CloseForm() { }

	// RVA: 0xD5D784
	private object _UpdateAll() { }

	// RVA: 0xD6214C
	private object CheckIn() { }

	// RVA: 0xD5D9F8
	private object AutoCheckIn() { }

	// RVA: 0xD5E1E4
	private object _SetActDate() { }

	// RVA: 0xD5F8C4
	private object _UpdateReward() { }

	// RVA: 0xD624C4
	private object _GetCheckIn() { }

	// RVA: 0xD5DF64
	private object _GetSvrCurActConfig() { }

	// RVA: 0xD5CB84
	private object GetSvrCheckInActTimeNode(object tStart, object tEnd) { }

	// RVA: 0xD616D4
	private object _UpdateHeroInfo() { }

	// RVA: 0xD5EA88
	private object _SetupDateList() { }

	// RVA: 0xD628D4
	private object _SetListToToday(object tseq) { }

	// RVA: 0xD62744
	private object _GetTotalCheckInTime() { }

	// RVA: 0xD62C38
	private object _GetFirstNotCheckInDay() { }

	// RVA: 0xD62854
	private object _GetMendingCheckInRewardState(object tDay) { }

	// RVA: 0xD62EFC
	private object _GetMendingCost(object CostPrice, object CostType, object typePath) { }

	// RVA: 0xD63170
	public object GetRedDotCount() { }

	// RVA: 0xD636E4
	public object GetReadyForGet() { }

	// RVA: 0xD5ED54
	private object _SetupCheckInState() { }

	// RVA: 0xD5F81C
	private object SetupMendingPanel() { }

	// RVA: 0xD5CF3C
	private object GetSvrActTime() { }

	// RVA: 0xD638BC
	private object GetRewardInfo(object nIndex) { }

	// RVA: 0xD63B6C
	private object OnDayItemEnable(object uiEvent) { }

	// RVA: 0xD5D0D4
	private object GetCheckInState(object day) { }

	// RVA: 0xD64758
	private object OnGetHeroConfirm(object uiEvent) { }

	// RVA: 0xD64890
	private object OnVPBuy() { }

	// RVA: 0xD648F0
	private object ReqMending() { }

	// RVA: 0xD64A34
	private object OnConfirmMendingClick(object uiEvent) { }

	// RVA: 0xD64B4C
	private object OnCancelMendingClick(object uiEvent) { }

	// RVA: 0xD64C5C
	private object OnMendingCheckInClick(object uiEvent) { }

	// RVA: 0xD658F0
	private object CheckGetDayReward(object periodDay) { }

	// RVA: 0xD65D6C
	private object DrawWealImpl(object periodID) { }

	// RVA: 0xD65F30
	private object ReqDrawWeal(object periodID) { }

	// RVA: 0xD6624C
	private object DrawCrossMonthAccuReward() { }

	// RVA: 0xD66370
	private object OnThreeDayRewardClick(object uiEvent) { }

	// RVA: 0xD663DC
	private object OnSixDayRewardClick(object uiEvent) { }

	// RVA: 0xD66448
	private object OnFifteenDayRewardClick(object uiEvent) { }

	// RVA: 0xD5DDAC
	private object SetLobbyPopup(object setPopup) { }

	// RVA: 0xD664B4
	private object CheckMeetConditionAutoPopup() { }

	// RVA: 0xD66944
	private object OnFormOpen(object uiEvent) { }

	// RVA: 0xD66DF4
	private object OnCheckInClick(object uiEvent) { }

	// RVA: 0xD66E5C
	public object UpdateState(object tRsp) { }

	// RVA: 0xD66EC4
	public object UpdateAccState() { }

	// RVA: 0xD6703C
	public static object OnFillInMessageGet(object msg) { }

	// RVA: 0xD671A8
	public static object OnCrossMonthCheckInfoNty(object msg) { }

	// RVA: 0xD672A4
	public static object OnGetFillinTimes(object msg) { }

	// RVA: 0xD67410
	private object _CheckTimer(object tSeq) { }

	// RVA: 0xD675DC
	private object CheckNeedUpdate() { }

	// RVA: 0xD5D710
	private object RecordUpdateTime() { }

	// RVA: 0xD67714
	public object SetCheckInState(object w, object bFullData) { }

	// RVA: 0xD678F4
	private object TryPopup() { }

	// RVA: 0xD66F98
	private object UpdateActivityReddot() { }

	// RVA: 0xD67984
	private object OnPrimeStatusUpdate() { }

	// RVA: 0xD679E4
	private object OnResumeMonthCheck() { }

	// RVA: 0xD67BB4
	private object OnFreeMendingCheckInClick(object uiEvent) { }

	// RVA: 0xD67C1C
	private object OnBeComePrimeOrRechargeClick(object uiEvent) { }

	// RVA: 0xD63758
	private static object IsPrimeMendingFuncOpen() { }

	// RVA: 0xD6380C
	private object GetPrimeExtarFreePendingCnt() { }

	// RVA: 0xD67D70
	public object .ctor() { }

	// RVA: 0xD67E20
	private static object .cctor() { }

	// RVA: 0xD67EA8
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xD67EAC
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class UIMonthCheckSysFormCtrl
{

	// Fields
	public object formScript; // 0x18
	public object titleDateText; // 0x20
	public object rewardProgress1; // 0x28
	public object rewardProgress2; // 0x30
	public object dateListCtrl; // 0x38
	public object listContentRect; // 0x40
	public object heroBgCdnPicCtrl; // 0x48
	public object tipBgGo; // 0x50
	public object heroNameText; // 0x58
	public object heroNameEventScript; // 0x60
	public object tipResText; // 0x68
	public object getHeroBtn; // 0x70
	public object totalCheckInDayText; // 0x78
	public object leftMendingCheckText; // 0x80
	public object freeMendingCheckInText; // 0x88
	public object primeMendingGo; // 0x90
	public object becomePrimeBtnGo; // 0x98
	public object btnGroupGo; // 0xA0
	public object checkInBtnGo; // 0xA8
	public object mendingBtnGo; // 0xB0
	public object mendingCostIconGo; // 0xB8
	public object mendingCostText; // 0xC0
	public object freeMendingBtnGo; // 0xC8
	public object pnlMendingGo; // 0xD0
	public object pnlMendingCostText; // 0xD8
	public object pnlMendingItemNameText; // 0xE0
	public object pnlMendingItemCellGo; // 0xE8
	public object pnlExchageGo; // 0xF0
	public object TitleBgCdnPicCtrl; // 0xF8
	public object GetHeroDate; // 0x100
	public object GetHeroDesc; // 0x108

	// Properties
	public object tipBgImage { get; }
	public object checkInBtn { get; }
	public object mendingBtn { get; }
	public object mendingCostImage { get; }
	public object freeMendingBtn { get; }

	// Methods

	// RVA: 0xE4F824
	public object get_tipBgImage() { }

	// RVA: 0xE4F920
	public object get_checkInBtn() { }

	// RVA: 0xE4FA1C
	public object get_mendingBtn() { }

	// RVA: 0xE4FB18
	public object get_mendingCostImage() { }

	// RVA: 0xE4FC14
	public object get_freeMendingBtn() { }

	// RVA: 0xE4FD10
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallMysteryDiscountHandler
{

	// Fields
	private object m_LimitBuyCnt; // 0x8
	private object m_BoughtCnt; // 0xC
	private object m_HasGotDiscount; // 0x10
	private object m_Discount; // 0x14
	private object m_StartTime; // 0x18
	private object m_EndTime; // 0x20
	private object m_discountContentGo; // 0x28
	private object m_bannerGo; // 0x30
	private object m_listGo; // 0x38

	// Properties
	public object HasGotDiscount { get; set; }
	public object BoughtCnt { get; }
	public object LimitBuyCnt { get; set; }
	public object Discount { get; set; }
	public object StartTime { get; set; }
	public object EndTime { get; set; }
	public object EndDateTime { get; set; }

	// Methods

	// RVA: 0xE4FD18
	public object set_HasGotDiscount(object value) { }

	// RVA: 0xE4FD80
	public object get_HasGotDiscount() { }

	// RVA: 0xE4FDE0
	public object get_BoughtCnt() { }

	// RVA: 0xE4FF40
	public object get_LimitBuyCnt() { }

	// RVA: 0xE4FFA0
	public object set_LimitBuyCnt(object value) { }

	// RVA: 0xE50008
	public object get_Discount() { }

	// RVA: 0xE50068
	public object set_Discount(object value) { }

	// RVA: 0xE500D0
	public object get_StartTime() { }

	// RVA: 0xE50130
	public object set_StartTime(object value) { }

	// RVA: 0xE50198
	public object get_EndTime() { }

	// RVA: 0xE5024C
	public object set_EndTime(object value) { }

	// RVA: 0xE50304
	public object get_EndDateTime() { }

	// RVA: 0xE50364
	public object set_EndDateTime(object value) { }

	// RVA: 0xE503CC
	public object Init() { }

	// RVA: 0xE50478
	public object Clear() { }

	// RVA: 0xE50544
	public object RefreshDiscountMsg() { }

	// RVA: 0xE50F60
	public object PlayLuckDiscount() { }

	// RVA: 0xE511C4
	private object GetDiscountGO() { }

	// RVA: 0xE50610
	private object RefreshBannerDiscount() { }

	// RVA: 0xE50A2C
	private object RefreshMainDiscount() { }

	// RVA: 0xE507A0
	private object RefreshTimer(object timePath) { }

	// RVA: 0xE51464
	public object SetDiscountList(object discountContentGo, object discountImage1, object discountImage2, object discountPercentImage, object discountRightTxt, object form) { }

	// RVA: 0xE519A0
	private object GetTimeToClose() { }

	// RVA: 0xE51B88
	private object GetDiscountNumIconPath(object discount) { }

	// RVA: 0xE51D04
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallMysteryGetNewDiscount
{

	// Fields
	private static object discountContentGo; // 0x0
	private static object discountRightTxt; // 0x8

	// Methods

	// RVA: 0xE51D0C
	public object GetRollDiscount() { }

	// RVA: 0xE52118
	private static object OnDiscountAnimationEnd(object time) { }

	// RVA: 0xE52C80
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass20_0
{

	// Fields
	public object obtAction; // 0x8

	// Methods

	// RVA: 0xE55084
	public object .ctor() { }

	// RVA: 0xE55D0C
	internal object <UpdateView>b__0(object e) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallMysteryProduct
{

	// Fields
	private object m_ItemType; // 0x8
	private object m_itemID; // 0xC
	private object m_BoughtCnt; // 0x10
	private object m_Cfg; // 0x18
	private object m_buyIdx; // 0x20
	private object m_shopType; // 0x24

	// Properties
	public object ShopType { get; }
	public object BuyIdx { get; }
	public object ItemType { get; }
	public object ItemID { get; }
	public object Cfg { get; }
	public object BoughtCnt { get; set; }

	// Methods

	// RVA: 0xE52C88
	public object .ctor(object goodsCfg, object buyIdx, object shopType) { }

	// RVA: 0xE52CE8
	public object get_ShopType() { }

	// RVA: 0xE52D48
	public object get_BuyIdx() { }

	// RVA: 0xE52DA8
	public object get_ItemType() { }

	// RVA: 0xE52E08
	public object get_ItemID() { }

	// RVA: 0xE52E68
	public object get_Cfg() { }

	// RVA: 0xE52EC8
	public object get_BoughtCnt() { }

	// RVA: 0xE52F28
	public object set_BoughtCnt(object value) { }

	// RVA: 0xE52F90
	public object UpdateView(object form, object itemGo, object widgetIndexInList) { }

	// RVA: 0xE55B40
	private object SetBuyBtnEnabled(object buyBtnImage, object enabled) { }

	// RVA: 0xE55100
	private object UpdateItemPricePnl(object form, object priceContainer, object tagTrans, object payInfoSet) { }

}

// Namespace: 
private sealed class <>c__DisplayClass14_0
{

	// Fields
	public object role; // 0x8

	// Methods

	// RVA: 0xE562F8
	public object .ctor() { }

	// RVA: 0xE56300
	internal object <RefreshProducts>b__0(object l, object r) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallMysteryItem
{

	// Fields
	private object m_Products; // 0x8
	private object m_formPath; // 0x10
	private object m_listPath; // 0x18
	private object m_shopType; // 0x20

	// Properties
	public object ProductCnt { get; }

	// Methods

	// RVA: 0xE55D58
	public object .ctor(object shopType, object formPath, object listPath) { }

	// RVA: 0xE55D98
	public object get_ProductCnt() { }

	// RVA: 0xE55E0C
	public object Draw() { }

	// RVA: 0xE55E6C
	public object Init() { }

	// RVA: 0xE55F28
	public object UnInit() { }

	// RVA: 0xE55FA4
	public object Clear() { }

	// RVA: 0xE56018
	public object AddProduct(object product) { }

	// RVA: 0xE560CC
	public object UpdateProduct(object itemType, object itemID, object boughtCnt) { }

	// RVA: 0xE56150
	public object GetProduct(object itemType, object itemID) { }

	// RVA: 0xE5289C
	public object RefreshProducts() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallMysteryTab
{

	// Fields
	private object m_NextRefreshTimerSeq; // 0x8
	private object m_Inited; // 0xC
	public object m_MysteryDisountHandler; // 0x10
	public object m_MysteryItem; // 0x18
	private object discountContentGo; // 0x20
	private object discountRightTxt; // 0x28
	private object m_showID; // 0x30

	// Methods

	// RVA: 0xE56A30
	public object Init() { }

	// RVA: 0xE56E30
	public object UnInit() { }

	// RVA: 0xE57200
	private object OnMallGoToMysteryTab(object uiEvent) { }

	// RVA: 0xE5741C
	private object RefreshProducts() { }

	// RVA: 0xE574A4
	private object OnHeroAdd(object heroId, object from) { }

	// RVA: 0xE57520
	private object OnShopBuySuccess(object shopType) { }

	// RVA: 0xE57598
	private object OnUpdateFlagSuccess(object shopType) { }

	// RVA: 0xE57800
	public object RefreshShop(object seq) { }

	// RVA: 0xE57ED4
	public object CloseShop(object seq) { }

	// RVA: 0xE57F3C
	public object Clear() { }

	// RVA: 0xE5786C
	public object InitData() { }

	// RVA: 0xE5736C
	public object IsShopAvailable() { }

	// RVA: 0xE586EC
	public object Load(object form) { }

	// RVA: 0xE58A44
	private object OnShowGO(object seq) { }

	// RVA: 0xE58EBC
	public object Loaded(object form) { }

	// RVA: 0xE58FF0
	public object Draw(object form) { }

	// RVA: 0xE58DB0
	private object InitPrefabData() { }

	// RVA: 0xE59058
	private object OnOpenShareMysteryDiscount(object uiEvent) { }

	// RVA: 0xE590C0
	public object OpenMysteryDiscountForm() { }

	// RVA: 0xE59850
	private object OnRollDiscount(object uiEvent) { }

	// RVA: 0xE57610
	public object GetRollDiscount() { }

	// RVA: 0xE59B60
	private object OnDiscountAnimationEnd(object time) { }

	// RVA: 0xE5A1DC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass26_0
{

	// Fields
	public object <>4__this; // 0x8
	public object uiEvent; // 0x10

	// Methods

	// RVA: 0xE5C390
	public object .ctor() { }

	// RVA: 0xE5D68C
	internal object <OnBuyItem>b__0() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DiscountShopSystem
{

	// Fields
	public object MysteryTab; // 0x8
	private object lastBuyGoodsShopType; // 0x10
	private object shopInfos; // 0x18

	// Methods

	// RVA: 0xE5A2B4
	public override object Init() { }

	// RVA: 0xE5A5E4
	public override object UnInit() { }

	// RVA: 0xE5A920
	public static object ReceiveMysteryShopData(object msg) { }

	// RVA: 0xE5AAB4
	public static object ReceiveShopBuy(object msg) { }

	// RVA: 0xE5ADF4
	public static object ReceiveShopBuyErr(object msg) { }

	// RVA: 0xE5AF14
	public static object ReceiveMysteryFlag(object msg) { }

	// RVA: 0xE59A20
	public object RequestShopFlag(object shopType) { }

	// RVA: 0xE5B0D4
	private object GetShopData(object shopType) { }

	// RVA: 0xE58054
	public object GetShopDetail(object shopType) { }

	// RVA: 0xE580CC
	public object GetShopInfo(object shopType) { }

	// RVA: 0xE4FE80
	public object GetBoughtCount(object shopType) { }

	// RVA: 0xE5B1AC
	public object GetDiscount(object shopType) { }

	// RVA: 0xE55C44
	public object HasGotDiscount(object shopType) { }

	// RVA: 0xE5B26C
	public object GetGoods(object shopType, object itemType, object itemID, object index) { }

	// RVA: 0xE5B3D8
	public object GetGoods(object itemType, object itemID, object index, object resultShopType) { }

	// RVA: 0xE585C8
	public object IsShopAvailable(object shopType) { }

	// RVA: 0xE5B4E4
	public object IsLimitBuyTime(object shopType) { }

	// RVA: 0xE5B62C
	public object GetRemainTime(object shopType) { }

	// RVA: 0xE51F74
	public object SetDiscountAlreadyGet(object shopType) { }

	// RVA: 0xE5ACA8
	private object AddBoughtCount(object shopType) { }

	// RVA: 0xE54C0C
	public object GetPayInfoSetOfGood(object itemType, object itemID, object shopType) { }

	// RVA: 0xE5B750
	private object OnOpenBuyForm(object uiEvent) { }

	// RVA: 0xE5B9F8
	public object OpenBuy(object form, object product) { }

	// RVA: 0xE5C234
	private object OnBuyItem(object uiEvent) { }

	// RVA: 0xE5C398
	private object _RealOnBuyItem(object uiEvent) { }

	// RVA: 0xE5C730
	private object OnConfirmuyItem(object uiEvent) { }

	// RVA: 0xE5CAD4
	private object OnBuyHeroNotOwn(object uiEvent) { }

	// RVA: 0xE58144
	public object IsProductAvailable(object product) { }

	// RVA: 0xE5CFCC
	private object OnNtyAddHero(object heroId, object from) { }

	// RVA: 0xE5D0C8
	private object OnNtyAddSkin(object heroId, object skinId, object from) { }

	// RVA: 0xE5D1D8
	public object Clear() { }

	// RVA: 0xE5CD0C
	public object GetMysteryPayInfoSetOfGood(object resHeroCfgInfo, object payType) { }

	// RVA: 0xE5D28C
	public object GetMysteryPayInfoSetOfGood(object resHeroSkin, object payType) { }

	// RVA: 0xE5D5C0
	public object .ctor() { }

	// RVA: 0xE5D684
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE5D688
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class ReturnDiscountShopLotteryCtrl
{

	// Fields
	private object FORM_PATH; // 0x8

	// Methods

	// RVA: 0xE5D6B4
	public object Init() { }

	// RVA: 0xE5D8B4
	public object Uninit() { }

	// RVA: 0xE5DAB4
	public object GetForm() { }

	// RVA: 0xE5DB58
	public object OpenForm() { }

	// RVA: 0xE5E460
	private object CloseForm() { }

	// RVA: 0xE5E530
	private object GetWidgets() { }

	// RVA: 0xE5DD04
	private object Refresh() { }

	// RVA: 0xE5E948
	private object PlayFormAnimator(object name) { }

	// RVA: 0xE5EB10
	private object OnEvtGetDiscount(object uiEvent) { }

	// RVA: 0xE5ED38
	private object OnGetDiscountAnimationOver() { }

	// RVA: 0xE5EEDC
	private object OnEvtGotoShop(object uiEvent) { }

	// RVA: 0xE5F05C
	private object OnRemainTimeUpdate(object timer) { }

	// RVA: 0xE5E818
	private object UpdateTimerFormat(object timer) { }

	// RVA: 0xE5F0C8
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class ReturnDiscountShopMallCtrl
{

	// Fields
	private static readonly object FORM_PATH; // 0x0
	private object m_MysteryItem; // 0x8

	// Methods

	// RVA: 0xE5F128
	public object Init() { }

	// RVA: 0xE5F38C
	public object Uninit() { }

	// RVA: 0xE5F630
	public object GetForm() { }

	// RVA: 0xE5F70C
	public object OpenForm() { }

	// RVA: 0xE5F900
	private object Refresh() { }

	// RVA: 0xE60228
	private object OnBuySuccess(object shopType) { }

	// RVA: 0xE601BC
	private object OnRemainTimeUpdate(object timer) { }

	// RVA: 0xE60320
	private object UpdateTimerFormat(object timer) { }

	// RVA: 0xE60450
	private object OnNtyAddHero(object heroId, object from) { }

	// RVA: 0xE604CC
	private object OnNtyAddSkin(object heroId, object skinId, object from) { }

	// RVA: 0xE60550
	public object .ctor() { }

	// RVA: 0xE60618
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class ReturnDiscountShopSystem
{

	// Fields
	private static readonly object LOBBY_TIP_RETURN_DISCOUNT_SHOP_NAME; // 0x0
	private object lotteryCtrl; // 0x8
	private object mallCtrl; // 0x10

	// Methods

	// RVA: 0xE60684
	public override object Init() { }

	// RVA: 0xE608E8
	public override object UnInit() { }

	// RVA: 0xE5E694
	public object GetDiscount() { }

	// RVA: 0xE60B4C
	private object OnRecvDiscountShopData(object shopType) { }

	// RVA: 0xE60CDC
	private object OnOpenReturnDiscountShop(object uiEvent) { }

	// RVA: 0xE60EBC
	private object OpenLotteryForm() { }

	// RVA: 0xE5EFEC
	public object OpenMallForm() { }

	// RVA: 0xE60F2C
	private object OnShopClosed(object uiEvent) { }

	// RVA: 0xE5E734
	public object IsCH() { }

	// RVA: 0xE61024
	public object .ctor() { }

	// RVA: 0xE61108
	private static object .cctor() { }

	// RVA: 0xE61174
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE61178
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class ReturnRechargeActivityCtrl
{

	// Fields
	private static readonly object FORM_PATH; // 0x0

	// Methods

	// RVA: 0xE6117C
	public object Init() { }

	// RVA: 0xE6137C
	public object Uninit() { }

	// RVA: 0xE6157C
	public object GetForm() { }

	// RVA: 0xE61658
	public object OpenForm() { }

	// RVA: 0xE6221C
	private object GetWidgets() { }

	// RVA: 0xE61984
	private object Refresh() { }

	// RVA: 0xE62544
	private object RefreshGoodsItem(object widgets, object goodsIdx, object goods) { }

	// RVA: 0xE62DB8
	private object GetCoupons(object goodsID) { }

	// RVA: 0xE62EB4
	private object GetGifts(object goods) { }

	// RVA: 0xE630E0
	private object OnPackGet() { }

	// RVA: 0xE6327C
	private object OnOpenRule(object uiEvent) { }

	// RVA: 0xE63334
	private object OnBuyGoods(object uiEvent) { }

	// RVA: 0xE63788
	public object .ctor() { }

	// RVA: 0xE63790
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class ReturnRechargeActivitySystem
{

	// Fields
	private static readonly object LOBBY_TIP_RETURN_RECHARGE_ACTIVITY_NAME; // 0x0
	private object ctrl; // 0x8
	private object activityData; // 0x10

	// Methods

	// RVA: 0xE637FC
	public override object Init() { }

	// RVA: 0xE6396C
	public override object UnInit() { }

	// RVA: 0xE63AA4
	public static object OnReturnPackGetNtf(object msg) { }

	// RVA: 0xE63D80
	private object IsActivityAvaliable() { }

	// RVA: 0xE63F3C
	private object OnOpenForm(object uiEvent) { }

	// RVA: 0xE62380
	public object GetGoods() { }

	// RVA: 0xE62C98
	public object GetActivityDuration(object beginTime, object endTime) { }

	// RVA: 0xE63FCC
	public object .ctor() { }

	// RVA: 0xE64024
	private static object .cctor() { }

	// RVA: 0xE64090
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE64094
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
private enum eSplash1Widgets
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Content;
	public const object CDN_BG;
}

// Namespace: 
private enum eSplash2Widgets
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Content;
	public const object CDN_BG;
	public const object REWARD_BG;
}

// Namespace: Assets.Scripts.GameSystem
public class ReturnSplashSystem
{

	// Fields
	private static readonly object FORM_RETURN_SPLASH_1; // 0x0
	private static readonly object FORM_RETURN_SPLASH_2; // 0x8
	private static readonly object LOBBY_TIP_RETURN_SPLASH_NAME; // 0x10
	private object returnTimeDetail; // 0x8
	private object returnIdentityLabel; // 0x10

	// Methods

	// RVA: 0xE64098
	public override object Init() { }

	// RVA: 0xE64284
	public override object UnInit() { }

	// RVA: 0xE64470
	public object Clear() { }

	// RVA: 0xE63EDC
	public object GetReturnTimeDetail() { }

	// RVA: 0xE644D0
	public static object GetApplyRsp(object msg) { }

	// RVA: 0xE646D8
	public static object OnRecvReturnIdentityLableNtf(object msg) { }

	// RVA: 0xE64670
	private object SetReturnTimeDetail(object data) { }

	// RVA: 0xE647BC
	private object SetReturnIdentityLable(object newReturnIdentityLabel) { }

	// RVA: 0xE648A4
	public object GetReturnState() { }

	// RVA: 0xE6491C
	public object GetReturnTime() { }

	// RVA: 0xE64994
	public object GetReturnEndTime() { }

	// RVA: 0xE64A0C
	public object GetReturnIdentityLable() { }

	// RVA: 0xE63BCC
	public object SetReturnPackGet(object id) { }

	// RVA: 0xE64A6C
	private object OnEvtOpenForm(object uiEvent) { }

	// RVA: 0xE65824
	private object OnEvtOpenReturnActivity(object uiEvent) { }

	// RVA: 0xE65AD4
	private object OnEvtFormClosed(object uiEvent) { }

	// RVA: 0xE64D4C
	private object OpenSplash1() { }

	// RVA: 0xE652D4
	private object OpenSplash2() { }

	// RVA: 0xE65BCC
	private object ReportSplashOpenedTLog() { }

	// RVA: 0xE65A2C
	private object ReportGotoPandoraActivityTLog() { }

	// RVA: 0xE65C74
	public object .ctor() { }

	// RVA: 0xE65CCC
	private static object .cctor() { }

	// RVA: 0xE65D74
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE65D78
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class GravityContainer
{

	// Methods

	// RVA: 0xE65D7C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class GravityEditItem
{

	// Fields
	public object xToggle; // 0x18
	public object yToggle; // 0x20
	public object slider1; // 0x28
	public object sliderValue1; // 0x30
	public object slider2; // 0x38
	public object sliderValue2; // 0x40
	public object slider3; // 0x48
	public object sliderValue3; // 0x50
	public object slider4; // 0x58
	public object sliderValue4; // 0x60
	private object component; // 0x68
	public object name; // 0x70
	private object waitTime; // 0x78
	public object curRotationText; // 0x80
	private object stringBuilder; // 0x88

	// Properties
	public object MoveDistance { set; }

	// Methods

	// RVA: 0xE65D84
	public object set_MoveDistance(object value) { }

	// RVA: 0xE65E0C
	private object Start() { }

	// RVA: 0xE65E68
	private object Init() { }

	// RVA: 0xE666EC
	public object UpdateName() { }

	// RVA: 0xE66A48
	private object Update() { }

	// RVA: 0xE66BB8
	private object GetCurRotation() { }

	// RVA: 0xE66924
	public object UpdateText(object name, object mode) { }

	// RVA: 0xE66EF4
	public object OnXToggleValueChanged(object isOn) { }

	// RVA: 0xE66FA4
	public object OnYToggleValueChanged(object isOn) { }

	// RVA: 0xE67054
	public object OnSlider1ValueChanged(object value) { }

	// RVA: 0xE67178
	public object OnSlider2ValueChanged(object value) { }

	// RVA: 0xE6729C
	public object OnSlider3ValueChanged(object value) { }

	// RVA: 0xE673C0
	public object OnSlider4ValueChanged(object value) { }

	// RVA: 0xE674E4
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class GravityEditScript
{

	// Fields
	public object slider; // 0x18
	public object arr; // 0x20
	public object value; // 0x28

	// Methods

	// RVA: 0xE67558
	private object Start() { }

	// RVA: 0xE67660
	public object OnSliderValueChanged(object value) { }

	// RVA: 0xE67778
	private object Update() { }

	// RVA: 0xE677D4
	public object .ctor() { }

}

// Namespace: 
public enum MotionAxial
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object All;
	public const object None;
	public const object x;
	public const object y;
	public const object z;
}

// Namespace: 
public enum MotionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Postion;
	public const object Rotation;
	public const object All;
}

// Namespace: Assets.Scripts.GameSystem
public class SimulationOfGravity
{

	// Fields
	public object MotionAxial1; // 0x18
	public object MotionAxial2; // 0x1C
	public object motionMode; // 0x20
	public object Sensitivity; // 0x24
	public object VerticalSensitivity; // 0x28
	public object HorizontalSensitivity; // 0x2C
	public object MoveSensitivity; // 0x30
	public object MoveTarget; // 0x38
	public object useHeroModel; // 0x40
	public object MoveDistance; // 0x44
	private object mobileOrientation; // 0x48
	private object tagerTransform; // 0x54
	private object tagerPos; // 0x60
	private object ReversePosition; // 0x6C
	public object minPos; // 0x78
	public object maxPos; // 0x80
	public object offsetLimited; // 0x88
	public object minRot; // 0x8C
	public object maxRot; // 0x94
	public object rotateLimited; // 0x9C
	private object lastFrameValue; // 0xA0

	// Methods

	// RVA: 0xE677DC
	public object SetOfffsetLimited(object offsetMin, object offsetMax, object offset) { }

	// RVA: 0xE67898
	public object SetDate(object sensitivity, object maxSlipSpeed, object maxTilt, object posMoveRate) { }

	// RVA: 0xE67934
	private object Awake() { }

	// RVA: 0xE67B6C
	private object LateUpdate() { }

	// RVA: 0xE685D4
	private object _AdjustValue(object value, object min, object max) { }

	// RVA: 0xE68670
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__10_0; // 0x8
	public static object <>9__31_0; // 0x10

	// Methods

	// RVA: 0xE6CA78
	private static object .cctor() { }

	// RVA: 0xE6CAD8
	public object .ctor() { }

	// RVA: 0xE6CAE0
	internal object <get_RecentlyRewardList>b__10_0(object a, object b) { }

	// RVA: 0xE6CB24
	internal object <GetTurnTableLotteryCntCfgList>b__31_0(object a, object b) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryData
{

	// Fields
	public object mRewardRecordList; // 0x8
	private const object mNearValidTime;
	public object mCntData; // 0x10
	public object mPhaseData; // 0x18
	public object mCacheResultData; // 0x20
	public object mCastData; // 0x28
	public object mTotalGameNum; // 0x30
	public object mNormalLotteryCnt; // 0x38

	// Properties
	public object RecentlyRewardList { get; }
	public object CurPhaseConfig { get; }
	public object CastItemCnt { get; }
	public object ReqCastSeq { get; }

	// Methods

	// RVA: 0xE68784
	public object Clear() { }

	// RVA: 0xE68BB8
	public object get_RecentlyRewardList() { }

	// RVA: 0xE68FB8
	public object get_CurPhaseConfig() { }

	// RVA: 0xE69204
	public object get_CastItemCnt() { }

	// RVA: 0xE692FC
	public object get_ReqCastSeq() { }

	// RVA: 0xE693F4
	public object CreateTestData(object lotteryId, object nCnt, object releatedCfgID) { }

	// RVA: 0xE6986C
	public object CreateTestResultData(object phaseId, object index) { }

	// RVA: 0xE69CA8
	public object InitTurnTableLotterData(object svrData) { }

	// RVA: 0xE69D44
	public object UpdateTurnTableLotterData(object svrData) { }

	// RVA: 0xE6A0DC
	public object UpdateTurnTableLotteryResultData(object svrData) { }

	// RVA: 0xE696BC
	public object UpdatePhaseData(object svrData) { }

	// RVA: 0xE69E84
	public object UpdateRewardRecordData(object svrData) { }

	// RVA: 0xE697F0
	public object UpdateCntData(object svrData) { }

	// RVA: 0xE6A774
	public object AppendCastData(object svrData) { }

	// RVA: 0xE6AAEC
	public static object GetTurnTableLotteryPhaseCfgData(object cfgId) { }

	// RVA: 0xE6AC5C
	public static object GetTurnTableLotteryPoolData(object cfgId) { }

	// RVA: 0xE6AF34
	public static object GetTurnTableLotteryPoolItemCfg(object cfgId, object index) { }

	// RVA: 0xE69014
	public static object GetCurTurnTableLotteryPhaseCfgData() { }

	// RVA: 0xE6B038
	public static object GetTurnTableLotteryCntCfg(object id) { }

	// RVA: 0xE6B1A8
	public static object GetTurnTableLotteryCntCfgList() { }

	// RVA: 0xE6B520
	public object GetValidCnt() { }

	// RVA: 0xE6B8C4
	public object GetLastResultIdx() { }

	// RVA: 0xE6B9FC
	public object GetLastResultHeroOrSkinId(object heroId, object skinId) { }

	// RVA: 0xE6BB90
	public object UpdateLastResultOfHeroOrSkin(object heroId, object skinId) { }

	// RVA: 0xE6BC08
	public static object GetConfigClientDateTime(object showTimeSecs, object durationSecs, object showDateTime, object expiredDateTime) { }

	// RVA: 0xE6BDFC
	public static object GetConfigUtcTime(object showTimeSecs, object durationSecs, object showUtcTime, object expiredUtcTime) { }

	// RVA: 0xE6BF10
	public object GetNextValidLottery(object showUtcTime, object expiredUtcTime) { }

	// RVA: 0xE6C314
	public static object GetTurnTableLotteryCntData(object cfgId) { }

	// RVA: 0xE6C484
	public static object GetAwardItemList(object poolId) { }

	// RVA: 0xE6C588
	private static object SortByIndex(object a, object b) { }

	// RVA: 0xE6C620
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryRewardItemInfo
{

	// Fields
	public object itemType; // 0x8
	public object itemTag; // 0x9
	public object itemID; // 0xC
	public object itemNum; // 0x10
	public object getUtcTime; // 0x14

	// Properties
	public object GetDataTime { get; }
	public object IsHightQualityItem { get; }
	public object IsMidQualityItem { get; }
	public object ItemName { get; }

	// Methods

	// RVA: 0xE6CB68
	public object get_GetDataTime() { }

	// RVA: 0xE6A494
	public object .ctor(object svrData) { }

	// RVA: 0xE6CC1C
	public object get_IsHightQualityItem() { }

	// RVA: 0xE6CC84
	public object get_IsMidQualityItem() { }

	// RVA: 0xE6CCEC
	public object get_ItemName() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryCntData
{

	// Fields
	public object lastUpateTime; // 0x8
	public object mValidCntList; // 0x10

	// Methods

	// RVA: 0xE68A70
	public object Clear() { }

	// RVA: 0xE6A4E0
	public object UpdateData(object svrData) { }

	// RVA: 0xE6C14C
	public object GetValidCnt(object cfgId, object targeType, object nowUtcTime) { }

	// RVA: 0xE6CE20
	public object GetUsedCnt(object cfgId, object targetType) { }

	// RVA: 0xE6CF5C
	public object GetTotalCnt(object cfgId, object targetType) { }

	// RVA: 0xE6C8D0
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryOneValidCntData
{

	// Fields
	public object releatedCfgID; // 0x8
	public object dataType; // 0xC
	public object totalCnt; // 0x10
	public object usedCnt; // 0x14
	public object getUtcTime; // 0x18
	public object validSeconds; // 0x1C

	// Properties
	public object thatDayExpiredUtcTime { get; }
	public object thatDayShowTimeUtcTime { get; }

	// Methods

	// RVA: 0xE6B858
	public object get_thatDayExpiredUtcTime() { }

	// RVA: 0xE6B6D4
	public object get_thatDayShowTimeUtcTime() { }

	// RVA: 0xE6CD98
	public object .ctor(object svrData) { }

	// RVA: 0xE6D098
	public object UpdateData(object svrData) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryCastData
{

	// Fields
	private object mMaxLen; // 0x8
	private object mCurSeq; // 0xC
	private object mFreeItemIdx; // 0x10
	private object mItemNum; // 0x14
	public object ReqTimerId; // 0x18
	private object mCastItemList; // 0x20

	// Properties
	public object CurSeq { get; }
	public object ItemNum { get; }

	// Methods

	// RVA: 0xE69394
	public object get_CurSeq() { }

	// RVA: 0xE6929C
	public object get_ItemNum() { }

	// RVA: 0xE6C9D0
	public object .ctor(object maxLen) { }

	// RVA: 0xE688E0
	public object Clear() { }

	// RVA: 0xE6A800
	public object AppendData(object svrData) { }

	// RVA: 0xE6D118
	public object GetItemDataBySeq(object seq) { }

	// RVA: 0xE6D340
	public object GetItemDataByUIIdx(object idx) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryCastItem
{

	// Fields
	public object seq; // 0x8
	public object fromPlayer; // 0x10
	public object fromName; // 0x18
	public object itemData; // 0x20

	// Methods

	// RVA: 0xE6D42C
	public object IsSelf(object uuid) { }

	// RVA: 0xE6D218
	public object UpdateData(object svrData) { }

	// RVA: 0xE6D338
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryResultData
{

	// Fields
	public object lotteryID; // 0x8
	public object rewardIndexList; // 0x10

	// Methods

	// RVA: 0xE68B24
	public object Clear() { }

	// RVA: 0xE69958
	public object UpdateLastResult(object phaseId, object rewardNum, object rewardAry) { }

	// RVA: 0xE6B934
	public object GetLastResultIdx() { }

	// RVA: 0xE6C950
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryChosenData
{

	// Fields
	public object index; // 0x8
	public object getUtcTime; // 0xC

	// Properties
	public object GetDataTime { get; }

	// Methods

	// RVA: 0xE6D4B4
	public object get_GetDataTime() { }

	// RVA: 0xE6D568
	public object .ctor(object svrData) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotteryPhaseData
{

	// Fields
	public object itemNum; // 0x8
	public object itemMissList; // 0x10
	public object lotteryID; // 0x18
	public object totalLotteryCnt; // 0x1C
	public object chosenMask; // 0x20
	public object chosenNum; // 0x24
	public object mChosenList; // 0x28

	// Methods

	// RVA: 0xE68998
	public object Clear() { }

	// RVA: 0xE6A1EC
	public object UpdateData(object svrData) { }

	// RVA: 0xE6A16C
	public object .ctor() { }

}

// Namespace: 
public enum enTurnTableLotteryCDNSubType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object enTurnTableLotteryCDNSubType_TitileImg;
	public const object enTurnTableLotteryCDNSubType_ActShareBg;
	public const object enTurnTableLotteryCDNSubType_RareAwardShareBg;
	public const object enTurnTableLotteryCDNSubType_RareAwardImg;
}

// Namespace: Assets.Scripts.GameSystem
public class CTurnTableLotterySystem
{

	// Fields
	public static object szMainFormPath; // 0x0
	public static object szMyAwardPath; // 0x8
	public static object szSharePath; // 0x10
	public static object szAwardPath; // 0x18
	public static object on_SCID_TURNTABLE_LOTTERY_RSP; // 0x20
	public static object on_SCID_TURNTABLE_LOTTERY_CNT_INFO_NTF; // 0x28
	public static object szTurnTableLotteryLobbyMsgTipName; // 0x30
	private object mLoginAlreadyPopup; // 0x8
	public object mTurnTableLotteryData; // 0x10
	public const object s_ShareTurnTableLotteryLoading;
	public const object s_ShareTurnTableLotteryPicNotFound;
	public const object s_ShareTurnTableLotteryPicOutofTime;
	public const object s_formShareTurnTableLotteryLuckyPath;

	// Methods

	// RVA: 0xE6D59C
	public object Clear() { }

	// RVA: 0xE6D610
	public object UpdateLobbyEntry(object entryRoot) { }

	// RVA: 0xE6DEE0
	public object ReqTurnTableLotteryStop(object lotteryId) { }

	// RVA: 0xE6E0A0
	public object ReqTurnTableLotteryCast(object seq) { }

	// RVA: 0xE6E260
	public static object OnTurnTableLotteryCastRsp(object msg) { }

	// RVA: 0xE6E520
	public static object OnTurnTableLotteryRsp(object msg) { }

	// RVA: 0xE6E80C
	public static object OnTurnTableLotteryInfoNtf(object msg) { }

	// RVA: 0xE6EA00
	public static object OnTurnTableLotteryCntInfoNtf(object msg) { }

	// RVA: 0xE6EC1C
	public override object Init() { }

	// RVA: 0xE6F034
	public override object UnInit() { }

	// RVA: 0xE6F4C4
	private object OnTurnTableLotteryEntryClick(object uiEvent) { }

	// RVA: 0xE6FA60
	private object OnTurnTableLotteryLoginOpen(object uiEvent) { }

	// RVA: 0xE6FDC8
	private object OnTurnTableLotteryGetNewHeroNtf(object id, object addReason) { }

	// RVA: 0xE6FF04
	private object OnTurnTableLotteryGetNewSkinNtf(object heroId, object skinId, object addReason) { }

	// RVA: 0xE70070
	private object OnTurnTableLotteryCDNDataNtf() { }

	// RVA: 0xE703A8
	private object OnTurnTableLotteryDataCfgNtf() { }

	// RVA: 0xE70684
	public object MeetAutoShowCondition() { }

	// RVA: 0xE6FB48
	public object TryToAutoPopupForm() { }

	// RVA: 0xE6F984
	public object GetMainViewForm() { }

	// RVA: 0xE70AD4
	public object GetVaildLotteryCnt() { }

	// RVA: 0xE6DE20
	public object IsOpen() { }

	// RVA: 0xE709E4
	public object IsAutoPopupLevel() { }

	// RVA: 0xE70B44
	public object IsSvrCtrlOpen() { }

	// RVA: 0xE70BF0
	public object IsInTimeOpen() { }

	// RVA: 0xE70CB0
	public static object AddPoolCfgSafe(object itemList, object newItem) { }

	// RVA: 0xE70E40
	public static object OpenTurnTableLotteryShareForm(object phaseId, object cdnType) { }

	// RVA: 0xE71678
	public static object CloseTurnTableLotteryShareForm() { }

	// RVA: 0xE7179C
	private static object GetResFromTurnTableLotteryPhase(object phaseId, object subType) { }

	// RVA: 0xE70298
	public static object PreloadOneCDNPicFromTurnTableLottery(object phaseId, object subType) { }

	// RVA: 0xE71564
	public static object SetImageWithPicFromTurnTablePhaseId(object phaseId, object cdnType, object subType, object img) { }

	// RVA: 0xE71448
	public static object CanBeShareByTurnTableLotteryPhase(object phaseId, object subType) { }

	// RVA: 0xE71978
	public object .ctor() { }

	// RVA: 0xE719F4
	private static object .cctor() { }

	// RVA: 0xE71BB8
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE71BBC
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class MonoTurnTableCastItemCtrl
{

	// Fields
	public static object szTurnTableLotteryLuckyGain; // 0x0
	public object isSelfNameTextColor; // 0x18
	public object otherPlayerNameNormalColor; // 0x28
	public object normalTextColor; // 0x38
	public object highAwardPlayerNameColor; // 0x48
	public object nameText; // 0x58
	public object awardText; // 0x60
	public object isHighQualityGo; // 0x68

	// Methods

	// RVA: 0xE71BC0
	public object SetData(object data) { }

	// RVA: 0xE720B4
	public object .ctor() { }

	// RVA: 0xE720BC
	private static object .cctor() { }

}

// Namespace: 
public enum enTurnTableStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Pause;
	public const object SpeedUp;
	public const object MaxConstantSpeed;
	public const object StopInit;
	public const object StopBeginingContantSpeed;
	public const object SlowDown;
}

// Namespace: 
public enum enTurnTableBtnStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Go;
	public const object GoHitAreaDisable;
	public const object GoDisable;
	public const object Stop;
	public const object StopHitAreaDisable;
	public const object StopDisable;
}

// Namespace: Assets.Scripts.GameSystem
public class MonoTurnTableCtrl
{

	// Fields
	private const object szPointerHighQualityItemAnim;
	private const object szPointerMidQualityItemAnim;
	private const object szPointerNormalQulityItemAnim;
	public object EditorStopTargetIndex; // 0x18
	public const object mCricleAngle;
	public const object mPerAngle;
	public object SPEED_PRECISION; // 0x1C
	public object ANGLE_PRECISION; // 0x20
	public object turnTableRoot; // 0x28
	public object pointerRoot; // 0x30
	public object pointerRotationGo; // 0x38
	public object pointerStartBg; // 0x40
	public object resCntBgImg; // 0x48
	public object startDescTextGo; // 0x50
	public object resCntDescTextGo; // 0x58
	public object resCntTextGo; // 0x60
	public object pointerStopBg; // 0x68
	public object stopDescTextGo; // 0x70
	public object enableColor; // 0x78
	public object disableColor; // 0x88
	public object pointerHighItemEffectGo; // 0x98
	public object pointerHighItemTimer; // 0xA0
	public object pointerMidItemEffectGo; // 0xA8
	public object pointerMidItemTimer; // 0xB0
	public object pointerNormalItemEffectGo; // 0xB8
	public object pointerNormatlItemTimer; // 0xC0
	public object pointerStatusRoot; // 0xC8
	public object startRootGo; // 0xD0
	public object startClickAreaGo; // 0xD8
	public object stopRootGo; // 0xE0
	public object stopClickAreaGo; // 0xE8
	public object startBtnDisableTimerGo; // 0xF0
	public object startBtnDisableTimer; // 0xF8
	public object ResCntText; // 0x100
	public object idleCircleEffectAnimator; // 0x108
	public object rollingCircleEffecAnimator; // 0x110
	public object circleEffectAnimatorRollingSpeed; // 0x118
	public object circleEffectanimatorSlowingSpeed; // 0x11C
	public object turnTableItemCtrlList; // 0x120
	public object turnTablePointerTailCtrlList; // 0x128
	public object MAX_SPEED; // 0x130
	public object MAX_STOP_TIME; // 0x134
	public object ACCELERATE_SPEED; // 0x138
	public object mTargetSpeed; // 0x13C
	public object mTargetIdx; // 0x140
	public object mAccelerateSpeed; // 0x144
	public object mStopAccelerateSpeed; // 0x148
	public object mCurSpeed; // 0x14C
	public object mTargetDiffAngle; // 0x150
	public object mBegin2StopPosAngle; // 0x154
	public object mStopTime; // 0x158
	public object mStopDeltaTime; // 0x15C
	public object mStopDetalAngle; // 0x160
	public object mEnStatus; // 0x164
	public object mEnGoBtnStatu; // 0x168
	public static object mItemAngle; // 0x0

	// Properties
	private object mCurAngle { get; }
	public object IsGoDisable { get; }
	public object IsStopDisable { get; }

	// Methods

	// RVA: 0xE72128
	private object get_mCurAngle() { }

	// RVA: 0xE72234
	public object get_IsGoDisable() { }

	// RVA: 0xE7229C
	public object get_IsStopDisable() { }

	// RVA: 0xE72304
	public object ChangeStartBtnStatus(object status) { }

	// RVA: 0xE72CAC
	public object UpdateValidCnt(object nCnt) { }

	// RVA: 0xE72BAC
	private object SetCircleAnimatioEffectSpeed(object speed) { }

	// RVA: 0xE72DF4
	public object Init() { }

	// RVA: 0xE730D0
	public object FillItem(object idx, object item) { }

	// RVA: 0xE73CE0
	public object HideAllItemEffects() { }

	// RVA: 0xE73F7C
	public object RestoreAllItemEffects() { }

	// RVA: 0xE74428
	public object StartRoll() { }

	// RVA: 0xE74508
	public object StopRoll(object index) { }

	// RVA: 0xE74A54
	public object DisableStopRoll() { }

	// RVA: 0xE73034
	public object Reset() { }

	// RVA: 0xE74AB8
	private object Update() { }

	// RVA: 0xE7466C
	private object DoStopInit() { }

	// RVA: 0xE751F4
	private object DispatchTurnTableStopEvent(object index) { }

	// RVA: 0xE75488
	public object ShowPointerChosenItemAnimEffect(object index) { }

	// RVA: 0xE75860
	public object HidePointerChosenItemAnimEffect() { }

	// RVA: 0xE758D8
	private object ShowCurAnglePointerTailImpl(object showAngle) { }

	// RVA: 0xE74E14
	private object ShowCurAnglePointerTail(object curAngle, object curSpeed, object accelerateSpeed, object stopAccelerateSpeed, object deltaTime) { }

	// RVA: 0xE72ED8
	private object LoadPointerTailRes() { }

	// RVA: 0xE75DC8
	private object GetDeltaAngle(object v0, object a, object t) { }

	// RVA: 0xE765B0
	private object GetVtSpeed(object v0, object a, object t) { }

	// RVA: 0xE76644
	private object DoRotate(object v0, object a, object deltaTime, object vt, object deltaS, object adjustAngle) { }

	// RVA: 0xE75020
	private object DoSlowDown(object v0, object a, object deltaTime, object adjustAngle) { }

	// RVA: 0xE753A8
	private object DoSpeedUp(object maxSpeed, object v0, object a, object deltaTime) { }

	// RVA: 0xE75300
	private object DoConstantRotate(object v, object deltaTime) { }

	// RVA: 0xE767C0
	private object ClockWiseRollAngle(object angle) { }

	// RVA: 0xE75A1C
	private object GetNearestAngleIndex(object ccwAngle, object percision) { }

	// RVA: 0xE75E6C
	private object WrapAngle(object srcAngle) { }

	// RVA: 0xE72810
	private object SetObjColor(object opObj, object rgba, object disableGradient, object disableOutline) { }

	// RVA: 0xE768E4
	public object .ctor() { }

	// RVA: 0xE76924
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class MonoTurnTableItemCtrl
{

	// Fields
	private static object MID_EFFECT_PATH; // 0x0
	private static object HIGH_EFFECT_PATH; // 0x8
	public object formScript; // 0x18
	public object itemImage; // 0x20
	public object itemCngText; // 0x28
	public object uiEventScript; // 0x30
	public object rareRootGo; // 0x38
	public object tagNodeGo; // 0x40
	public object effectNodeGo; // 0x48
	public object itemEffectNodeGo; // 0x50
	public object pointerTailEffectNodeGo; // 0x58
	private object mCacheItemData; // 0x60

	// Properties
	public object ItemTag { get; }
	public object IsMidQualityItem { get; }
	public object IsHighQualityItem { get; }

	// Methods

	// RVA: 0xE769BC
	public object get_ItemTag() { }

	// RVA: 0xE75798
	public object get_IsMidQualityItem() { }

	// RVA: 0xE756D0
	public object get_IsHighQualityItem() { }

	// RVA: 0xE7332C
	public object SetData(object item) { }

	// RVA: 0xE73E38
	public object NotShowItemEffect() { }

	// RVA: 0xE741D4
	public object RestoreItemEffect() { }

	// RVA: 0xE76A84
	public object .ctor() { }

	// RVA: 0xE76A8C
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class MonoTurnTablePointerTailCtrl
{

	// Fields
	private static object POINTER_TAIL_EFFECT_PATH; // 0x0
	public const object szAnimationName;
	public object runtimAnimCtrl; // 0x18
	public object runtimePointerTailEffectGo; // 0x20
	private object mIndex; // 0x28

	// Methods

	// RVA: 0xE75C6C
	public object ShowTailEffect() { }

	// RVA: 0xE76B8C
	public object OnTailAnimEffectEnd() { }

	// RVA: 0xE75EE8
	public object Init(object index) { }

	// RVA: 0xE76C0C
	public object .ctor() { }

	// RVA: 0xE76C14
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class TurnTableLotteryMainView
{

	// Fields
	private static object szTurnTableLotteryOutOfTime; // 0x0
	private static object szTurnTableLotteryStartSoundEvent; // 0x8
	private static object REQ_FREQUENCE; // 0x10
	private static object LUCKLY_LIST_REFRESH; // 0x14
	public object topGo; // 0x78
	public object titleCDNImage; // 0x80
	public object btnClose; // 0x88
	public object leftGo; // 0x90
	public object rareAwardCDNImage; // 0x98
	public object ruleTitleText; // 0xA0
	public object ruleContentText; // 0xA8
	public object detailHttpText; // 0xB0
	public object actShareBtnGo; // 0xB8
	public object centerGo; // 0xC0
	public object turnTableCtrl; // 0xC8
	public object rightGo; // 0xD0
	public object luckyList; // 0xD8
	public object luckyScrollRect; // 0xE0
	private object mLuckyListRefreshTimerID; // 0xE8
	public object myAwardBtnGo; // 0xF0
	private object mCacheData; // 0xF8
	private object mCurParse; // 0x100

	// Methods

	// RVA: 0xE76CD0
	protected override object OnViewInited() { }

	// RVA: 0xE771C0
	protected override object OnRegEvent() { }

	// RVA: 0xE77264
	public object Show(object data) { }

	// RVA: 0xE77CF8
	public object UpdateRule() { }

	// RVA: 0xE78690
	public object UpdateValidCnt(object nCnt) { }

	// RVA: 0xE78A10
	public object UpdateLuckyList(object castData) { }

	// RVA: 0xE7850C
	private object FillItemList(object lotteryId) { }

	// RVA: 0xE7878C
	private object ReqCastItemList(object seq) { }

	// RVA: 0xE77818
	private object RegisterUIEvent(object isRegister) { }

	// RVA: 0xE78B90
	public override object OnFormDestroyed() { }

	// RVA: 0xE78900
	private object StartTimer(object srcTimerId, object millonseconds, object times, object onTimeUpHandler) { }

	// RVA: 0xE78840
	private object RemoveTimer(object srcTimerId) { }

	// RVA: 0xE78FE8
	private object OnTurnTableLotteryGoDisableTimerUp(object uiEvent) { }

	// RVA: 0xE79144
	private object OnTurnTableLotteryShareActClick(object uiEvent) { }

	// RVA: 0xE792DC
	private object OnTurnTableLotteryTimeUp2PushCastItem(object timerSeq) { }

	// RVA: 0xE79368
	private object OnTurnTableLotteryRefreshLuckyListTimerUp(object timerSeq) { }

	// RVA: 0xE793E8
	private object OnTurnTableLotteryStartClick(object uiEvent) { }

	// RVA: 0xE798A8
	private object OnTurnTableLotteryStopClcik(object uiEvent) { }

	// RVA: 0xE79D24
	private object OnDetailHttpTextClick(object uiEvent) { }

	// RVA: 0xE79EE8
	private object OnLuckyListItemEnable(object uiEvent) { }

	// RVA: 0xE7A130
	private object OnTurnTableLotteryEntryClose(object uiEvent) { }

	// RVA: 0xE7A228
	private object OnTurnTableLotteryMyAwardClose(object uiEvent) { }

	// RVA: 0xE7A380
	private object OnTurnTableLotteryRareAwardShareClick(object uiEvent) { }

	// RVA: 0xE7A504
	private object OnTurnTableLotteryShareFormCloseClick(object uiEvent) { }

	// RVA: 0xE7A61C
	private object OnTurnTableLotteryTableStopEvent(object uiEvent) { }

	// RVA: 0xE7A878
	private object OnTurnTableLotteryPointerChosenBlinkAnimEndEvent(object uiEvent) { }

	// RVA: 0xE7AEB8
	private object OnTurnTableLotteryAwardViewClose(object uiEvent) { }

	// RVA: 0xE7B1C0
	private object OnLobbyEntryCountDownEnd(object uiEvent) { }

	// RVA: 0xE7B288
	private object OnTurnTableLotteryMyAwardClick(object uiEvent) { }

	// RVA: 0xE7B3E8
	public object OpenMyAwardView(object awardRewardList) { }

	// RVA: 0xE7ABC0
	public object OpenRewardView(object itemCfg) { }

	// RVA: 0xE7B8DC
	private object ShowNormalAwardView(object itemCfg) { }

	// RVA: 0xE7C3F4
	public object .ctor() { }

	// RVA: 0xE7C3FC
	private static object .cctor() { }

	// RVA: 0xE7C490
	private object <OnViewInited>b__22_0() { }

	// RVA: 0xE7C658
	private object <OnViewInited>b__22_1() { }

	// RVA: 0xE7C6D8
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xE7C6E0
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xE7C6E8
	public object <>iFixBaseProxy_OnFormDestroyed() { }

}

// Namespace: Assets.Scripts.GameSystem
public class TurnTableLotteryMyAwardView
{

	// Fields
	public object uiListScript; // 0x18
	public object emptyInfoGo; // 0x20
	private object mAwardDataList; // 0x28
	public object form; // 0x30

	// Methods

	// RVA: 0xE7B738
	public object Show(object awardList) { }

	// RVA: 0xE7C83C
	public object OnAwardItemEnable(object uiEvent) { }

	// RVA: 0xE7CA1C
	private object SetItem(object listElm, object itemData) { }

	// RVA: 0xE7CFC0
	public object OnDestroy() { }

	// RVA: 0xE7C6F0
	private object RegisterUIEvent(object isRegister) { }

	// RVA: 0xE7D25C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class TurnTableLotteryRewardView
{

	// Fields
	private static object MID_EFFECT_PATH; // 0x0
	private static object HIGH_EFFECT_PATH; // 0x8
	private static object szTurnTableLotteryMidRewardTitle; // 0x10
	private static object szTurnTableLotteryHighRewardTitle; // 0x18
	public object titleText; // 0x18
	public object btnGroupGo; // 0x20
	public object btnContinueGo; // 0x28
	public object btnShareGo; // 0x30
	public object itemRootGo; // 0x38
	public object itemIconImg; // 0x40
	public object itemDescText; // 0x48

	// Properties
	public object form { get; }

	// Methods

	// RVA: 0xE7D264
	public object get_form() { }

	// RVA: 0xE7BAE8
	public object Show(object itemCfg) { }

	// RVA: 0xE7D2F0
	public object .ctor() { }

	// RVA: 0xE7D2F8
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CBagSystem
{

	// Fields
	public static object sheetContainerTable; // 0x0

	// Methods

	// RVA: 0xE7D434
	public static object GetSheetContainer(object type) { }

	// RVA: 0xE7D5B8
	public object .ctor() { }

	// RVA: 0xE7D610
	private static object .cctor() { }

}

// Namespace: 
public class ChoseableItemInfo
{

	// Fields
	public object randomRewardType; // 0x8
	public object itemID; // 0xC
	public object count; // 0x10

	// Methods

	// RVA: 0xE810B8
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CDelayDrawGiftCtrl
{

	// Fields
	public static readonly object FORM_DELAY_DRAW_GIFT; // 0x0
	private object item; // 0x8
	private object widgets; // 0x10
	private object selectedRewardIndex; // 0x18
	private object itemList; // 0x20
	private object maxCount; // 0x28
	private object allowChooseDup; // 0x2C
	private object instanceFormPath; // 0x30
	private object showBigItem; // 0x38

	// Properties
	public object ShowBigItem { get; set; }

	// Methods

	// RVA: 0xE7D684
	public object get_ShowBigItem() { }

	// RVA: 0xE7D6E4
	public object set_ShowBigItem(object value) { }

	// RVA: 0xE7D74C
	public object Init() { }

	// RVA: 0xE7D918
	public object UnInit() { }

	// RVA: 0xE7DAE4
	private object openFormInternal(object itemList, object maxCount, object titleString, object prefabPath) { }

	// RVA: 0xE7E26C
	public object OpenForm(object data, object maxCount, object allowDup) { }

	// RVA: 0xE7E6AC
	public object OpenForm(object item, object allowDup, object prefabPath) { }

	// RVA: 0xE7EBD8
	private object GetForm() { }

	// RVA: 0xE7EC7C
	private object OnEvtFormClosed(object uiEvent) { }

	// RVA: 0xE7ED6C
	private object OnEvtSelectRewardItem(object uiEvent) { }

	// RVA: 0xE7FEF4
	private object OnEvtExchange(object uiEvent) { }

	// RVA: 0xE80370
	private object GetItem() { }

	// RVA: 0xE7EA18
	private object GetDelayDrawGiftConfig() { }

	// RVA: 0xE7DE3C
	private object Refresh() { }

	// RVA: 0xE80A68
	private object RefreshRewardItem(object listElementScript, object useableItem) { }

	// RVA: 0xE7F640
	private object RefreshRewardItemSelectState(object listElementScript) { }

	// RVA: 0xE7F3B8
	private object SkinOrHeroAlreadyHave(object index) { }

	// RVA: 0xE7F964
	private object RefreshRewardStates() { }

	// RVA: 0xE80FA0
	public object .ctor() { }

	// RVA: 0xE8104C
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CDelayDrawGiftSystem
{

	// Fields
	private object delayDrawGiftCtrl; // 0x8

	// Methods

	// RVA: 0xE810C0
	public override object Init() { }

	// RVA: 0xE8129C
	public override object UnInit() { }

	// RVA: 0xE813D4
	private object OnEvtOpenGift(object uiEvent) { }

	// RVA: 0xE815B0
	public object OpenForm(object data, object maxCount, object allowDup) { }

	// RVA: 0xE808DC
	public object GetDelayDrawConfig(object giftID) { }

	// RVA: 0xE803D0
	public object ExchangeGift(object itemData, object selectedRewardIndex) { }

	// RVA: 0xE80690
	public object SpecialGiftExchanged(object selectedRewardIndex) { }

	// RVA: 0xE7FE24
	public object SpecialGiftSelected(object count) { }

	// RVA: 0xE81650
	public object GetUseables(object giftID) { }

	// RVA: 0xE817EC
	public object .ctor() { }

	// RVA: 0xE81844
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE81848
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__9_0; // 0x8
	public static object <>9__16_0; // 0x10

	// Methods

	// RVA: 0xE825B4
	private static object .cctor() { }

	// RVA: 0xE82614
	public object .ctor() { }

	// RVA: 0xE8261C
	internal object <Set>b__9_0(object left, object right) { }

	// RVA: 0xE827BC
	internal object <OnShowRewardOver>b__16_0(object useableItem) { }

}

// Namespace: 
private sealed class <DisplayLevelRewards>d__15
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <iter>5__2; // 0x20
	private object <allList>5__3; // 0x40

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xE82858
	public object .ctor(object <>1__state) { }

	// RVA: 0xE82884
	private object System.IDisposable.Dispose() { }

	// RVA: 0xE82888
	private object MoveNext() { }

	// RVA: 0xE82FE8
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xE82FF0
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xE83030
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class RewardsController
{

	// Fields
	private object _rewardsDisplayList; // 0x18
	private object _rewardsCompletedCallback; // 0x20
	private object _currentIter; // 0x28
	private object _cdnBgPath; // 0x30
	private object _topDes; // 0x38
	private object _itemNameShow; // 0x40
	private object _limitLength; // 0x48
	private object _showName; // 0x49

	// Methods

	// RVA: 0xE8184C
	public static object ShowRewards(object list, object callback, object cdnBgPath, object topDes, object itemNameShow, object limitLength, object showName) { }

	// RVA: 0xE81A98
	internal object Set(object list, object callback, object cdnBgPath, object topDes, object itemNameShow, object limitLength, object showName) { }

	// RVA: 0xE81EB0
	private object OnEnable() { }

	// RVA: 0xE8201C
	private object OnDisable() { }

	// RVA: 0xE81E34
	private object OnRewardsCompleted() { }

	// RVA: 0xE82188
	private object OnRewardsCollected(object uiEvent) { }

	// RVA: 0xE821F0
	private object OnRewardsCollected() { }

	// RVA: 0xE81D80
	private object DisplayLevelRewards() { }

	// RVA: 0xE82350
	private object OnShowRewardOver(object uiEvent) { }

	// RVA: 0xE825A8
	public object .ctor() { }

	// RVA: 0xE825B0
	private object <DisplayLevelRewards>b__15_0() { }

}

// Namespace: 
public class Chat_Model_EventID
{

	// Fields
	public static readonly object Chat_Offline_GetMsg_NTF; // 0x0
	public static readonly object Chat_GetJudgePunish_NTF; // 0x8
	public static readonly object Chat_GetComplaintPunish_NTF; // 0x10
	public static readonly object Chat_GetComplaintPunish_ERROR; // 0x18
	public static readonly object Chat_GmeTranslateRsp; // 0x20
	public static readonly object Chat_GuildChatData_Change; // 0x28
	public static readonly object Chat_Intimacy_Friend_Online_NTF; // 0x30
	public static readonly object Chat_PlayerLevel_Set; // 0x38
	public static readonly object Chat_RoomChatData_Change; // 0x40
	public static readonly object Chat_RegionChatData_Change; // 0x48
	public static readonly object Chat_Add_Bubble_Msg; // 0x50
	public static readonly object Chat_GuildTeamChatData_Change; // 0x58
	public static readonly object Chat_HeorSelectChatData_Change; // 0x60
	public static readonly object Chat_Settle_Change; // 0x68
	public static readonly object ChatSendOneIndex; // 0x70
	public static readonly object Chat_UnreadCountChanged; // 0x78
	public static readonly object Chat_FriendChat_Update_TransLate; // 0x80
	public static readonly object Chat_RoomChat_LeaveRoom; // 0x88
	public static readonly object Chat_VoiceComplaintNtf; // 0x90
	public static readonly object Chat_RoomChat_voiceComplaintNtf; // 0x98
	public static readonly object Chat_MessEquipShowTipsNtf; // 0xA0

	// Properties
	public static object Chat_GetMsg_NTF { get; }
	public static object Chat_FriendChatData_Change { get; }
	public static object Chat_LobbyChatData_Change { get; }
	public static object Chat_Friend_Online_Change { get; }
	public static object Chat_TeamChat_Change { get; }
	public static object Chat_SelectLaneType { get; }
	public static object Force_Close_Chat_View { get; }

	// Methods

	// RVA: 0xE84280
	public static object get_Chat_GetMsg_NTF() { }

	// RVA: 0xE8C334
	public static object get_Chat_FriendChatData_Change() { }

	// RVA: 0xE8E694
	public static object get_Chat_LobbyChatData_Change() { }

	// RVA: 0xE8432C
	public static object get_Chat_Friend_Online_Change() { }

	// RVA: 0xE8E46C
	public static object get_Chat_TeamChat_Change() { }

	// RVA: 0xE91F20
	public static object get_Chat_SelectLaneType() { }

	// RVA: 0xE96C8C
	public static object get_Force_Close_Chat_View() { }

	// RVA: 0xE96D38
	public object .ctor() { }

	// RVA: 0xE96D40
	private static object .cctor() { }

}

// Namespace: 
public enum enCheckChatResult
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Success;
	public const object CdLimit;
	public const object BanLimit;
	public const object FreeCntLimit;
	public const object FunUnlockLimit;
	public const object EmptyLimit;
	public const object EUAgeBanLimit;
}

// Namespace: 
public enum eChatAuthorizationStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WarningAuthorization;
	public const object OpenUrl;
	public const object LimitChat;
	public const object PreviewTips;
	public const object NormalChat;
	public const object AgreeFriend;
}

// Namespace: 
public enum eChatAuthorizationEntryType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Lobby;
	public const object SelectHero;
	public const object Battle;
}

// Namespace: 
public class CChatBubbleMsg
{

	// Fields
	public object msg; // 0x8
	public object imagePath; // 0x10

	// Methods

	// RVA: 0xE971BC
	public object .ctor() { }

}

// Namespace: 
public enum EChatBanFrom
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FromChatForm;
	public const object FromHeroSelectChat;
	public const object FromGuildChat;
	public const object FromOther;
	public const object Bag;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__73_0; // 0x8

	// Methods

	// RVA: 0xE971C4
	private static object .cctor() { }

	// RVA: 0xE97224
	public object .ctor() { }

	// RVA: 0xE9722C
	internal object <On_Chat_GetMsg_NTF>b__73_0(object uiEvent) { }

}

// Namespace: 
private sealed class <>c__DisplayClass111_0
{

	// Fields
	public object laneType; // 0x8
	public object subTag; // 0xC

	// Methods

	// RVA: 0xE9218C
	public object .ctor() { }

	// RVA: 0xE97348
	internal object <SendChatSelectLaneType>b__0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass66_0
{

	// Fields
	public object ent; // 0x8
	public object <>9__0; // 0x10

	// Methods

	// RVA: 0xE874C8
	public object .ctor() { }

	// RVA: 0xE973A8
	internal object <NewMethod>b__0(object x) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CChatController
{

	// Fields
	public static object fmt; // 0x0
	public static object fmt_teamup; // 0x8
	public static object fmt_blue_name; // 0x10
	public static object fmt_gold_name; // 0x18
	public static object ChatFormPath; // 0x20
	public const object ChatTextImgTemplatePath;
	public const object ChatSelectHeroPath_Normal;
	public const object ChatSelectHeroPath_Normal_LanePick;
	public const object ChatSelectHeroPath_BanPick;
	public const object ChatSelectHeroPath_Plenty;
	public static object ChatPlayerInfo; // 0x28
	public static object MaxCount; // 0x30
	public static object friendMaxCount; // 0x34
	public static object init_chatTime; // 0x38
	public static object step_time; // 0x3C
	public static object max_ChatTime; // 0x40
	public object cur_chatTimer_totalTime; // 0x8
	public object CachedTemplateTextFont; // 0x10
	public object CachedTemplateTextSize; // 0x18
	public object bSendChat; // 0x1C
	private object chatTimer; // 0x20
	public object model; // 0x28
	public object view; // 0x30
	public object CurrAuthorizationEntryForm; // 0x38
	private object JumpFriendTab; // 0x3C
	private object ChatLimitMaps; // 0x40
	public object FilterLangView; // 0x48
	public object ColorParser; // 0x50
	public object isInLobby; // 0x58
	public static object isCanProcessChatMsg; // 0x44
	private object lobbyChatFilterLangList; // 0x60
	public const object HOT_REGION_RANK_INDEX;
	public static object MORE_REGION_TEXT_COLOR; // 0x48
	public object ChangeRegionSelectId; // 0x68
	private object iMaxChatLength; // 0x6C
	private object iDefaultChatLengthValue; // 0x70
	public static object PunishTime; // 0x58
	private static object isChatPunishLimit; // 0x60

	// Properties
	public object MaxChatLength { get; }
	public object SendChat { get; set; }
	public object Model { get; }
	public object IsCanProcessChatMsg { get; set; }
	public object IsInLobby { get; set; }

	// Methods

	// RVA: 0xE83038
	public object .ctor() { }

	// RVA: 0xE832D8
	public object IsPrimeChatBubbleEnabled() { }

	// RVA: 0xE83394
	public object ClearAll() { }

	// RVA: 0xE83408
	public object SetChatTimerEnable(object b) { }

	// RVA: 0xE83478
	private object On_Send_GetChat_Req(object timerSequence) { }

	// RVA: 0xE835B0
	public object ReportGvoiceReq(object reportType) { }

	// RVA: 0xE8361C
	public override object Init() { }

	// RVA: 0xE84224
	public object Update() { }

	// RVA: 0xE836B0
	private object InitEvent() { }

	// RVA: 0xE843D8
	public object SubmitRefreshEvent() { }

	// RVA: 0xE84608
	public object CancleRefreshEvent() { }

	// RVA: 0xE84838
	public object OpenFriendChatView() { }

	// RVA: 0xE8498C
	private object GetTempalteTextFont() { }

	// RVA: 0xE84BEC
	public object SetLastTimeStamp(object lastTimeStamp) { }

	// RVA: 0xE84C7C
	public object GetCachedTemplateTextFont() { }

	// RVA: 0xE84D50
	public object GetCachedTemplateTextSize() { }

	// RVA: 0xE84DC8
	private object GetTemplateTextSize() { }

	// RVA: 0xE85028
	public object ClearAllPanel() { }

	// RVA: 0xE851B0
	public object Jump2FriendChat(object info) { }

	// RVA: 0xE8529C
	private object On_Chat_EntryPanel_Click(object uievent) { }

	// RVA: 0xE85708
	private object On_Friend_Delete_NTF(object friendUid, object friendLogicWorldId, object type) { }

	// RVA: 0xE85794
	public object ClearFriendChatData(object friendUid, object friendLogicWorldId) { }

	// RVA: 0xE85954
	public object CheckInputLenth(object inputField) { }

	// RVA: 0xE85CD8
	public object IsChatBanByEUAge() { }

	// RVA: 0xE85D8C
	public object ProcessChatBanByEUAge() { }

	// RVA: 0xE85F20
	public object IsChatBanLimit() { }

	// RVA: 0xE86078
	public object GetBanLeftTimeStr() { }

	// RVA: 0xE86314
	public object ProcessChatBanTips(object eBanForm, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE8676C
	public object CheckSend(object channel, object content, object bContentCheck) { }

	// RVA: 0xE86A20
	public object RemoveRichText(object inputText) { }

	// RVA: 0xE86AE8
	public object GetSysDataId(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE86B98
	public object NewMethod(object ent, object BgNode, object textContainer) { }

	// RVA: 0xE874D0
	private object On_Chat_CloseForm(object uievent) { }

	// RVA: 0xE875C0
	public object OnClosingAnimEnd() { }

	// RVA: 0xE87634
	public object OnShowAnimEnd() { }

	// RVA: 0xE877BC
	private object On_Chat_PlayerLevel_Set() { }

	// RVA: 0xE87968
	private object On_Chat_Offline_GetMsg_NTF(object msg) { }

	// RVA: 0xE88D18
	private object On_Chat_GetMsg_NTF(object msg) { }

	// RVA: 0xE8E740
	public object On_Chat_GetMsg_NTF(object uid, object master, object content, object revert) { }

	// RVA: 0xE8EAB8
	private object On_Chat_GetComplaintPunish_NTF(object msg) { }

	// RVA: 0xE8EBB4
	private object On_Chat_GetComplaintPunish_Error(object msg) { }

	// RVA: 0xE8ECB0
	private object On_Chat_GetJudgePunish_NTF(object msg) { }

	// RVA: 0xE8EE44
	private object On_Chat_GetHangUp_NTF(object type, object playerId) { }

	// RVA: 0xE8EF68
	private object OnChatGetSystemWarningNtf(object warningType, object playerID) { }

	// RVA: 0xE8F120
	private object On_Friend_FriendList_Refresh() { }

	// RVA: 0xE8F25C
	private object On_Chat_Friend_Online_Change(object info, object bOffline, object bOnlineChange) { }

	// RVA: 0xE8F83C
	private object OnFriendOnlineChangeNTF(object info, object bOffline) { }

	// RVA: 0xE8FAF8
	private object SendIntimacyFriendLoginMsgToBattle(object info, object intimacydata) { }

	// RVA: 0xE90014
	private object SendIntimacyFriendLoginMsgToLobby(object info, object intimacydata) { }

	// RVA: 0xE90564
	private object SendReturnFriendLoginMsgToLobby(object info) { }

	// RVA: 0xE90954
	private object On_Chat_Intimacy_Friend_Online_NTF(object info) { }

	// RVA: 0xE90CE8
	private object OnErrorCodeNtf(object errorCode) { }

	// RVA: 0xE90E64
	private object On_Guild_EnterGuild(object obj) { }

	// RVA: 0xE90EF8
	private object On_Guild_LeaveGuild(object obj) { }

	// RVA: 0xE90F8C
	private object On_Rolling_SystemChatInfoReceived(object content) { }

	// RVA: 0xE91034
	public object GetChatFilterLang() { }

	// RVA: 0xE91094
	public object SetChatFilterLang(object arrayFilterLang, object cnt) { }

	// RVA: 0xE91444
	public object IsRegionChatOpen() { }

	// RVA: 0xE83544
	public object IsChatRegionSet() { }

	// RVA: 0xE915A0
	public object GetCurSetRegionName() { }

	// RVA: 0xE914F4
	public object GetChatRegionId() { }

	// RVA: 0xE91674
	public object HaveHistoryRegion() { }

	// RVA: 0xE91714
	public object GetRecentChatRegion() { }

	// RVA: 0xE91984
	public object GetHotChatRegion() { }

	// RVA: 0xE91C08
	public object HaveMoreCities() { }

	// RVA: 0xE85BDC
	public object get_MaxChatLength() { }

	// RVA: 0xE91EC0
	private object OnLanguageChanged() { }

	// RVA: 0xE8E064
	public object UpdateChatSelectLaneType(object ullUid, object index) { }

	// RVA: 0xE91FCC
	public object SendChatSelectLaneType(object laneType, object subTag) { }

	// RVA: 0xE92194
	public object HandleBack(object formScript) { }

	// RVA: 0xE922EC
	public object IsFaceRainAvailable() { }

	// RVA: 0xE92398
	public object IsChatPunishLimit() { }

	// RVA: 0xE9244C
	public object IsRealTimeVoicePunish() { }

	// RVA: 0xE925E0
	public static object NtfRealTimeVoice(object ntf) { }

	// RVA: 0xE92DC8
	public static object NtfMessEquipTip(object ntf) { }

	// RVA: 0xE92EFC
	public object AddChatLimit(object uid, object type) { }

	// RVA: 0xE930E4
	public object DelChatLimit(object uid, object type) { }

	// RVA: 0xE932CC
	public object IsChatLimit(object uid, object type) { }

	// RVA: 0xE93428
	public object IsRegionChatAuthorization() { }

	// RVA: 0xE85658
	public object DoChatAuthorization(object callBack, object bOpenUrl) { }

	// RVA: 0xE93484
	public object DoNormalChatCallBack(object callBack, object bOpenUrl) { }

	// RVA: 0xE935C8
	public object DoAuthorizationStatus(object callBack, object bOpenUrl) { }

	// RVA: 0xE93678
	private object SetChatAuthorizationResult(object voiceControlStatus, object adultStatus, object needVoiceControlIngame) { }

	// RVA: 0xE93778
	public object IsAuthorizationSwitch() { }

	// RVA: 0xE85528
	public object IsRefreshAuthorizationPanelResult() { }

	// RVA: 0xE938F8
	public object ShowChatLimitTips() { }

	// RVA: 0xE93AD4
	public object ShowChatPreviewTips() { }

	// RVA: 0xE93CB0
	public object RefreshChatAuthorizationResultTips(object resultStaus, object bOpenUrl) { }

	// RVA: 0xE94060
	private object ChatAuthorizationSdkCallbackEvent(object uiEvent) { }

	// RVA: 0xE94334
	private object OnRefreshAuthorizationStatusEvent(object uiEvent) { }

	// RVA: 0xE93FFC
	private object OnChatAuthorizationLimitEvent(object uiEvent) { }

	// RVA: 0xE855F0
	public object SetAuthorizationEntryForm(object type) { }

	// RVA: 0xE942D4
	public object GetAuthorizationEntryForm() { }

	// RVA: 0xE854C0
	public object SetJumpFriendTab(object bJump) { }

	// RVA: 0xE94440
	public object GetJumpFriendTab() { }

	// RVA: 0xE944A0
	public object SetMaxCount(object maxCount) { }

	// RVA: 0xE9456C
	public object ProcessChatBanTips(object eChatBanFrom) { }

	// RVA: 0xE945E0
	public object ViewIsShow() { }

	// RVA: 0xE9464C
	public object FakeSendChat(object content) { }

	// RVA: 0xE94944
	public object ViewInitTemplateForm() { }

	// RVA: 0xE949B8
	public object ViewHideForm() { }

	// RVA: 0xE94A2C
	public object HasView() { }

	// RVA: 0xE94A94
	public object IsLabbyFriendTab() { }

	// RVA: 0xE94B64
	public object SetViewFreshNew(object refreshNew) { }

	// RVA: 0xE94BE0
	public object ViewShowLoudSpeaker(object bShow, object data) { }

	// RVA: 0xE94C78
	public object ViewIsCheckHistory() { }

	// RVA: 0xE94CEC
	public object UpdateSystem() { }

	// RVA: 0xE94D68
	public object ColorParserParse(object lingWidth, object content, object viewFontSize, object inFont) { }

	// RVA: 0xE94E24
	public object get_SendChat() { }

	// RVA: 0xE94E84
	public object set_SendChat(object value) { }

	// RVA: 0xE94EEC
	public object get_Model() { }

	// RVA: 0xE94F4C
	public object get_IsCanProcessChatMsg() { }

	// RVA: 0xE95000
	public object set_IsCanProcessChatMsg(object value) { }

	// RVA: 0xE950CC
	public object get_IsInLobby() { }

	// RVA: 0xE9512C
	public object set_IsInLobby(object value) { }

	// RVA: 0xE95194
	public object ChatMsgReceiverParseText(object text) { }

	// RVA: 0xE95200
	public object CChatNetUT_Send_Room_Chat(object text) { }

	// RVA: 0xE9526C
	public object CChatNetUT_Send_Team_Chat(object text, object chatType) { }

	// RVA: 0xE952F0
	public object CChatNetUT_SendEmojiMsgInTeam(object emojiID) { }

	// RVA: 0xE9535C
	public object CChatNetUT_Send_Leave_Settle() { }

	// RVA: 0xE953BC
	public object CChatNetUT_Send_Lobby_Chat(object text) { }

	// RVA: 0xE95428
	public object CChatNetUT_Send_Private_Chat(object ullUid, object logicWorldId, object text) { }

	// RVA: 0xE954B8
	public object CChatNetUT_On_Chat_NTFMainThread(object msg) { }

	// RVA: 0xE95524
	public object CChatNetUT_On_Chat_Complaint_NTF(object msg) { }

	// RVA: 0xE95590
	public object CChatNetUT_On_Chat_Complaint_RSP(object msg) { }

	// RVA: 0xE955FC
	public object CChatNetUT_On_RealtimeVoice_Complaint_RSP(object msg) { }

	// RVA: 0xE95668
	public object CChatNetUT_On_RealtimeVoice_Complaint_NTF(object msg) { }

	// RVA: 0xE956D4
	public object CChatNetUT_On_TranslateChatState_RSP(object msg) { }

	// RVA: 0xE95740
	public object CChatNetUT_Send_GetChat_Req(object channel) { }

	// RVA: 0xE957AC
	public object CChatNetUT_Send_Private_Chat_To_IntimacyFriend(object ullUid, object logicWorldId) { }

	// RVA: 0xE95830
	public object Report_Private_Chat_InBattle(object type, object ullUid, object logicWorldId) { }

	// RVA: 0xE95A5C
	public object CChatNetUT_Send_Clear_Offline(object delIndexList) { }

	// RVA: 0xE95AC8
	public object CChatNetUT_Send_Guild_Chat(object text) { }

	// RVA: 0xE95B34
	public object CChatUT_EnterLobby() { }

	// RVA: 0xE95DBC
	public object CChatUT_LeaveRoom() { }

	// RVA: 0xE9602C
	public object CChatUT_Build_Friend_System(object content, object friendName) { }

	// RVA: 0xE9617C
	public object CChatUT_LeaveLobby() { }

	// RVA: 0xE96304
	public object CChatUT_EnterTeam(object isForMatchForm) { }

	// RVA: 0xE96528
	public object CChatUT_Build_4_LoudSpeaker_EntryString(object ullUid, object iLogicWorldID, object rawText) { }

	// RVA: 0xE96714
	public object CChatUT_Build_4_Speaker_EntryString(object ullUid, object iLogicWorldID, object rawText) { }

	// RVA: 0xE96900
	public object CChatUT_Send_SelectHero_Chat(object text) { }

	// RVA: 0xE9696C
	public object CChatUT_Send_Reverse_Chat(object ullUid, object iLogicWorldID) { }

	// RVA: 0xE969F0
	public object CChatNetUT_On_MESS_EQUIPWARNING_RESULT_NTF(object msg) { }

	// RVA: 0xE96A5C
	public object OnBattleStart() { }

	// RVA: 0xE96ACC
	private static object .cctor() { }

	// RVA: 0xE96BF4
	private object <OnRefreshAuthorizationStatusEvent>b__134_0(object evt) { }

	// RVA: 0xE96C88
	public object <>iFixBaseProxy_Init() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CChatUT
{

	// Methods

	// RVA: 0xE8BD3C
	public static object Convert_ChatMsgType_Channel(object v) { }

	// RVA: 0xE9769C
	public static object GetEChatChannel_Text(object channel) { }

	// RVA: 0xE97618
	public static object Convert_ChatMsgType_Channel(object type) { }

	// RVA: 0xE97A60
	public static object Convert_Channel_ChatMsgType(object type) { }

	// RVA: 0xE88600
	public static object Build_4_Offline_Friend(object data) { }

	// RVA: 0xE8F6F0
	public static object Build_4_OfflineOrOnline(object bOffline) { }

	// RVA: 0xE8C3E0
	public static object Build_4_Friend(object data) { }

	// RVA: 0xE97D60
	private static object HandleReserveData(object entity, object contentInfo) { }

	// RVA: 0xE8C6E8
	public static object Build_4_Lobby(object data) { }

	// RVA: 0xE8C930
	public static object Build_4_Lobby(object data) { }

	// RVA: 0xE98BE8
	public static object FillWorldInviteData(object targetData, object srcData) { }

	// RVA: 0xE97BB8
	public static object FillMomentsShareData(object targetData, object srcData) { }

	// RVA: 0xE98638
	private static object _fillIntimacyChatData(object ent, object data, object isSelf) { }

	// RVA: 0xE98888
	private static object _fillDeeplinkChatData(object ent, object data, object isSelf) { }

	// RVA: 0xE8CCCC
	public static object Build_4_Guild(object data) { }

	// RVA: 0xE8CF14
	public static object Build_4_GuildTeam(object data) { }

	// RVA: 0xE8CB20
	public static object Build_4_Guild(object data) { }

	// RVA: 0xE98E5C
	public static object FillGuildInviteData(object targetData, object srcData) { }

	// RVA: 0xE8D110
	public static object Build_4_Room(object data) { }

	// RVA: 0xE8D268
	public static object Build_4_Region(object data) { }

	// RVA: 0xE8D46C
	public static object Build_4_Region(object data) { }

	// RVA: 0xE98FCC
	public static object FillRegionInviteData(object targetData, object srcData) { }

	// RVA: 0xE9913C
	public static object Build_4_Self(object content) { }

	// RVA: 0xE8C07C
	public static object Build_4_Self(object data) { }

	// RVA: 0xE8D618
	public static object Build_4_SelectHero(object data, object chatSource) { }

	// RVA: 0xE866B4
	public static object Build_4_System(object content) { }

	// RVA: 0xE960AC
	public static object CChatUT_Build_Friend_System(object content, object friendName) { }

	// RVA: 0xE992B8
	public static object Build_4_FriendReserveTips(object content) { }

	// RVA: 0xE87FC0
	public static object Build_4_OfflineInfo(object content) { }

	// RVA: 0xE8E238
	public static object Build_4_Team(object data) { }

	// RVA: 0xE8E518
	public static object Build_4_Settle(object data) { }

	// RVA: 0xE99370
	public static object GetUser(object type, object ulluid, object logicworld_id, object name, object level, object head_url, object head_frame, object head_pendant, object gender, object remark, object game_viplevel, object gamevip_switch) { }

	// RVA: 0xE94868
	public static object GetUser(object type, object ulluid, object logicworld_id, object ent) { }

	// RVA: 0xE99B68
	public static object Build_4_Time() { }

	// RVA: 0xE88078
	public static object Build_4_Time(object curSec) { }

	// RVA: 0xE99D00
	public static object Build_4_ChatEntry(object bFriend, object ent) { }

	// RVA: 0xE973D8
	public static object OnRichTextClick(object text, object id, object logicWorldId) { }

	// RVA: 0xE888F0
	public static object Build_4_EntryString(object type, object ullUid, object iLogicWorldID, object rawText, object szTeamUpMsg) { }

	// RVA: 0xE967A0
	public static object Build_4_Speaker_EntryString(object ullUid, object iLogicWorldID, object rawText) { }

	// RVA: 0xE965B4
	public static object Build_4_LoudSpeaker_EntryString(object ullUid, object iLogicWorldID, object rawText) { }

	// RVA: 0xE8837C
	public static object Build_4_Friend_ActivityJump(object data) { }

	// RVA: 0xE8BDF8
	public static object Build_4_Friend_ActivityJump_Self(object data) { }

	// RVA: 0xE99FA4
	public static object ColorString(object color, object text) { }

	// RVA: 0xE97AE4
	private static object IsChatPlayerPrime(object chatPlayerInfo) { }

	// RVA: 0xE95B90
	public static object EnterLobby() { }

	// RVA: 0xE961D8
	public static object LeaveLobby() { }

	// RVA: 0xE9A048
	public static object EnterRoom() { }

	// RVA: 0xE95E18
	public static object LeaveRoom() { }

	// RVA: 0xE9636C
	public static object EnterTeam(object isForMatchForm) { }

	// RVA: 0xE9A264
	public static object LeaveTeam(object isTempLeaveTeam) { }

	// RVA: 0xE9A474
	public static object EnterSettle() { }

	// RVA: 0xE9A65C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public enum EChaterType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Self;
	public const object Friend;
	public const object Strenger;
	public const object Time;
	public const object GuildMember;
	public const object System;
	public const object Speaker;
	public const object LoudSpeaker;
	public const object OfflineInfo;
	public const object IntimacyFriendOnlineInfo;
	public const object FriendReserveTips;
	public const object None;
	public const object FriendActivityJump;
	public const object FriendActivityJumpSelf;
}

// Namespace: Assets.Scripts.GameSystem
public struct stMomentsShareDetail
{

	// Fields
	public object Uid; // 0xFFFFFFFFFFFFFFF8
	public object LogicWorldId; // 0x0
	public object ullShareKey; // 0x8
	public object PicCount; // 0x10
	public object DefaultPicUrlSmall; // 0x18
	public object DefaultPicUrlBig; // 0x20
	public object ShareText; // 0x28
	public object MomentsSysType; // 0x30
	public object MomentsSysValue; // 0x34
	public object MomentsAddType; // 0x38
	public object UserName; // 0x40
	public object HeadUrl; // 0x48
	public object HeadID; // 0x50
	public object PendantId; // 0x54
}

// Namespace: Assets.Scripts.GameSystem
public enum enSoldierSkinThanksMessageType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Team;
	public const object Room;
	public const object Enemy;
}

// Namespace: Assets.Scripts.GameSystem
public class CLegendTitleInfo
{

	// Fields
	public object dwAdCode; // 0x8
	public object dwHeroID; // 0xC
	public object dwRank; // 0x10

	// Methods

	// RVA: 0xE9A80C
	public object copyFromComdt(object LegendTitleInfo) { }

	// RVA: 0xE9A890
	public object copyToComdt(object LegendTitleInfo) { }

	// RVA: 0xE9A914
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CChatFriendMsgCache
{

	// Fields
	public object ullUid; // 0x8
	public object lastChatTime; // 0x10
	public object unread_count; // 0x14
	public object unread_count_all; // 0x18

	// Methods

	// RVA: 0xE9A91C
	public object .ctor(object pUllUid, object pLastChatTime, object pUnreadMsg, object pUnreadMsgAll) { }

}

// Namespace: Assets.Scripts.GameSystem
public struct stGameVipChatSwitch
{

	// Fields
	private object <switch_head_pendant>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <switch_playerName_color>k__BackingField; // 0xFFFFFFFFFFFFFFFC
	private object <switch_chatMsg_color>k__BackingField; // 0x0
	private object <switch_chatBubble_color>k__BackingField; // 0x4

	// Properties
	public object switch_head_pendant { get; set; }
	public object switch_playerName_color { get; set; }
	public object switch_chatMsg_color { get; set; }
	public object switch_chatBubble_color { get; set; }

	// Methods

	// RVA: 0xE9A96C
	public object get_switch_head_pendant() { }

	// RVA: 0xE9A97C
	public object set_switch_head_pendant(object value) { }

	// RVA: 0xE9A98C
	public object get_switch_playerName_color() { }

	// RVA: 0xE9A99C
	public object set_switch_playerName_color(object value) { }

	// RVA: 0xE9A9AC
	public object get_switch_chatMsg_color() { }

	// RVA: 0xE9A9BC
	public object set_switch_chatMsg_color(object value) { }

	// RVA: 0xE9A9CC
	public object get_switch_chatBubble_color() { }

	// RVA: 0xE9A9DC
	public object set_switch_chatBubble_color(object value) { }

	// RVA: 0xE9A9EC
	public object .ctor(object switch_pendant, object switch_playerName, object switch_chatMsg, object switch_chatBubble) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CChatEntity
{

	// Fields
	public object ullUid; // 0x8
	public object iLogicWorldID; // 0x10
	public object miniRaceRank; // 0x14
	public object rankGrade; // 0x16
	public object rankClass; // 0x18
	public object rankScore; // 0x1C
	public object isPrime; // 0x20
	public object LegendTitleHideLocationInfo; // 0x21
	public object szTeamUpMsg; // 0x28
	public object LegendTitleInfo; // 0x30
	public object cacheLegendTitleInfo; // 0x38
	public object TextClickable; // 0x40
	public object clickableShowText; // 0x48
	public object joinSetting; // 0x50
	public object isSoldierSkinShareThanks; // 0x58
	public object soldierSkinThanksMessageType; // 0x5C
	public object soldierSkinEnemyTargetID; // 0x60
	public object bChatType; // 0x68
	public object textTranslated; // 0x70
	public object textUnTranslated; // 0x78
	public object contentType; // 0x80
	public object reserveState; // 0x84
	public object reserveTime; // 0x88
	public object reserveText; // 0x90
	public object reserveInvalid; // 0x98
	public object state; // 0x9C
	public object originalTextLanguage; // 0xA0
	public object shouldUseOrginalTextOrTranslatedText; // 0xA4
	public object lobbyChatShouldUseTranslatedText; // 0xA5
	public object type; // 0xA8
	public object bHasReaded; // 0xAC
	public object gender; // 0xB0
	public object name; // 0xB8
	public object remark; // 0xC0
	public object head_url; // 0xC8
	public object head_frame; // 0xD0
	public object head_pendant; // 0xD4
	public object game_viplevel; // 0xD8
	public object level; // 0xE0
	public object time; // 0xE8
	public object GameVipSwitch; // 0xEC
	public object TextObjList; // 0x100
	public object cacheTextObjList; // 0x108
	public object final_width; // 0x110
	public object final_height; // 0x114
	public object numLine; // 0x118
	public object haveImg; // 0x11C
	public object bIsGameInvite; // 0x11D
	public object inviteDetail; // 0x120
	public object bIsMomentShare; // 0x1C0
	public object momentsShareDetail; // 0x1C8
	public object intimacyState; // 0x228
	public object intimacyTitleId; // 0x22C
	public object relationChgType; // 0x230
	public object otherUid; // 0x238
	public object otherLogicWorldID; // 0x240
	public object deepLinkWealType; // 0x244
	public object pushType; // 0x248
	public object deepLinkID; // 0x24C
	public object inviteCode; // 0x250
	public object pushExtendJson; // 0x258
	public object bOnlineOrOffline; // 0x260

	// Properties
	public object TextForDisplay { get; set; }
	public object TransTextForDisplay { get; set; }
	public object UllUid { get; set; }
	public object ILogicWorldID { get; set; }
	public object iName { get; set; }
	public object iRemark { get; set; }
	public object ContentType { get; set; }
	public object State { get; set; }
	public object ChatType { get; set; }

	// Methods

	// RVA: 0xE9AA04
	public object set_TextForDisplay(object value) { }

	// RVA: 0xE9AA88
	public object get_TextForDisplay() { }

	// RVA: 0xE9AB00
	public object set_TransTextForDisplay(object value) { }

	// RVA: 0xE9AB80
	public object get_TransTextForDisplay() { }

	// RVA: 0xE9ABFC
	public object Clear() { }

	// RVA: 0xE9AD40
	public object CopyTextDataTo(object entity) { }

	// RVA: 0xE9ADCC
	public object IsMeanbleChatEnt() { }

	// RVA: 0xE9AE44
	public object get_UllUid() { }

	// RVA: 0xE9AEA4
	public object set_UllUid(object value) { }

	// RVA: 0xE9AF0C
	public object get_ILogicWorldID() { }

	// RVA: 0xE9AF6C
	public object set_ILogicWorldID(object value) { }

	// RVA: 0xE9AFD4
	public object get_iName() { }

	// RVA: 0xE9B034
	public object set_iName(object value) { }

	// RVA: 0xE9B09C
	public object get_iRemark() { }

	// RVA: 0xE9B0FC
	public object set_iRemark(object value) { }

	// RVA: 0xE9B168
	public object get_ContentType() { }

	// RVA: 0xE9B1C8
	public object set_ContentType(object value) { }

	// RVA: 0xE9B230
	public object get_State() { }

	// RVA: 0xE9B290
	public object set_State(object value) { }

	// RVA: 0xE9B2F8
	public object get_ChatType() { }

	// RVA: 0xE9B358
	public object set_ChatType(object value) { }

	// RVA: 0xE9B3C0
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTextImageNode
{

	// Fields
	public object content; // 0x8
	public object bText; // 0x10
	public object width; // 0x14
	public object height; // 0x18
	public object posX; // 0x1C
	public object posY; // 0x20

	// Methods

	// RVA: 0xE9B458
	public object .ctor(object ct, object bText, object width, object height, object x, object y) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CChatModel
{

	// Fields
	public static object STORAGE_LIMIT_SIZE; // 0x0
	public static object playerUllUID; // 0x8
	private static object _friendCacheDir; // 0x10
	public object bEnableInBattleInputChat; // 0x8
	public object playerInfos; // 0x10
	public object stOfflineChatIndexList; // 0x18
	public object sysData; // 0x20
	public object channelMgr; // 0x28
	public object selectHeroTemplateList; // 0x30
	private object m_CurSelectGroupTemplateInfo; // 0x38
	private object m_CurSelectGroupChatTemplateInfo; // 0x40
	public object m_curGroupID; // 0x48
	public const object MAP_TAG;
	private object index; // 0x4C

	// Properties
	public static object friendCacheDir { get; }
	public object EnableInBattleInputChat { get; set; }
	public object SysData { get; }
	public object ChannelMgr { get; }

	// Methods

	// RVA: 0xE9B4BC
	public static object get_friendCacheDir() { }

	// RVA: 0xE9B630
	public static object GetFriendCachePath(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE9B900
	public object AddOfflineChatIndex(object ullUid, object dwLogicWorldId, object index) { }

	// RVA: 0xE9BC6C
	public object ClearCOfflineChatIndex(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE9BDCC
	public object ClearCOfflineChatIndex(object data) { }

	// RVA: 0xE9BE94
	public object GetCOfflineChatIndex(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE9BFCC
	public object GetCurGroupTemplateInfo() { }

	// RVA: 0xE9C02C
	public object GetCurGroupChatTemplateInfo() { }

	// RVA: 0xE9C08C
	public object SetCurGroupTemplateInfo(object cfgId) { }

	// RVA: 0xE9C4C4
	public object ClearAll() { }

	// RVA: 0xE9C88C
	public object .ctor() { }

	// RVA: 0xE9CCC8
	public object SetTimeStamp(object v, object time) { }

	// RVA: 0xE9CD58
	public object SetRestFreeCnt(object v, object count) { }

	// RVA: 0xE9CDE8
	public object Load_HeroSelect_ChatTemplate() { }

	// RVA: 0xE9D1F0
	public object Get_HeroSelect_ChatTemplate(object index) { }

	// RVA: 0xE9D2F0
	public object GetLastUnread_Selected() { }

	// RVA: 0xE9D4A0
	public object IsTemplate_IndexValid(object index) { }

	// RVA: 0xE9D568
	public object Clear_HeroSelected() { }

	// RVA: 0xE9D854
	public object Has_PLAYER_INFO(object info) { }

	// RVA: 0xE9D9A8
	public object Add_Palyer_Info(object info) { }

	// RVA: 0xE9DAC4
	public object Remove_Palyer_Info(object info) { }

	// RVA: 0xE9DB8C
	public object Get_Palyer_Info(object ullUid, object iLogicWorldID) { }

	// RVA: 0xE9DCD4
	public object get_EnableInBattleInputChat() { }

	// RVA: 0xE9DD34
	public object set_EnableInBattleInputChat(object value) { }

	// RVA: 0xE9DD9C
	public object get_SysData() { }

	// RVA: 0xE9DDFC
	public object get_ChannelMgr() { }

	// RVA: 0xE9DE5C
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CChatSysData
{

	// Fields
	public object ullUid; // 0x18
	public object dwLogicWorldId; // 0x20
	public object lastTimeStamp; // 0x24
	public object restChatFreeCnt; // 0x28
	private object m_chatCostNum; // 0x2C
	private object m_chatCostType; // 0x30
	public object LastChannel; // 0x34
	public object CurChannel; // 0x38
	public object entryEntity; // 0x40

	// Properties
	public object chatCostNum { get; }
	public object chatCostType { get; }

	// Methods

	// RVA: 0xE9C610
	public object Clear() { }

	// RVA: 0xE9CA30
	public object .ctor() { }

	// RVA: 0xE9DEB0
	public object get_chatCostNum() { }

	// RVA: 0xE9DFA8
	public object get_chatCostType() { }

	// RVA: 0xE9E0A0
	public override object ClearEntryText() { }

	// RVA: 0xE9E118
	public object Add_NewContent_Entry(object str, object curChannel) { }

	// RVA: 0xE9E4C4
	public override object Add_NewContent_Entry_Speaker(object a) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CChatChannel
{

	// Fields
	public static object MaxDeltaTime_Seconds; // 0x0
	public object ChannelType; // 0x8
	public object bOffline; // 0xC
	public object bCacheFriendDataLoaded; // 0xD
	public object bCacheFriendDataNeedSave; // 0xE
	public object ullUid; // 0x10
	public object dwLogicWorldId; // 0x18
	public object list; // 0x20
	private object unread_count; // 0x28
	private object unread_count_unCache; // 0x2C
	public object lastTimeStamp; // 0x30
	public object cd_time; // 0x34
	private object lastSendTime; // 0x38
	public object addTimeSplice_timer; // 0x3C
	public object sizeVec; // 0x40
	private static object clt_pendding_time; // 0x4

	// Methods

	// RVA: 0xE9D5F4
	public object Clear() { }

	// RVA: 0xE9EB4C
	public object .ctor(object channelType, object cdTime, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE9EDE4
	public object Init_Timer() { }

	// RVA: 0xE9EF88
	public object GetLast() { }

	// RVA: 0xE9F0A8
	public object GetUnreadCount(object unCahce) { }

	// RVA: 0xE9F128
	public object Add(object ent) { }

	// RVA: 0xE9FD30
	private object IsSaveFriendCacheData(object ent) { }

	// RVA: 0xE9F9FC
	private object RemoveOverFlowData(object isLowDev) { }

	// RVA: 0xE9F6C4
	public object MsgItemCntOverFlow() { }

	// RVA: 0xEA08CC
	public object GetUnreadMeanbleChatEntCount(object start_index) { }

	// RVA: 0xE9F828
	public object IsSelfShareChatMsg(object ent) { }

	// RVA: 0xE9F8C4
	public object IsSelfRelationChatMsg(object ent) { }

	// RVA: 0xE9F960
	public object IsSelfDeeplinkChatMsg(object ent) { }

	// RVA: 0xEA0A40
	public object ReadAll() { }

	// RVA: 0xEA0BA8
	public object LoadFriendCacheData() { }

	// RVA: 0xEA00EC
	public object SaveFriendCacheData(object ent) { }

	// RVA: 0xEA120C
	public object InitChat_InputTimer(object time) { }

	// RVA: 0xEA12E4
	public object Start_InputCD() { }

	// RVA: 0xEA138C
	public object IsInputValid() { }

	// RVA: 0xEA143C
	public object ClearCd() { }

	// RVA: 0xEA149C
	public object Get_Left_CDTime() { }

	// RVA: 0xEA15C0
	public object Get_ChatBanLimit_CDTime() { }

	// RVA: 0xEA17FC
	public object GetChatList() { }

	// RVA: 0xEA1A80
	public object SubRedCount(object count) { }

	// RVA: 0xEA1BE8
	private static object .cctor() { }

}

// Namespace: 
public enum EChatTab
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Room;
	public const object Team;
	public const object Settle;
	public const object Region;
	public const object GuildTeam;
	public const object Monments;
}

// Namespace: Assets.Scripts.GameSystem
public class CChatChannelMgr
{

	// Fields
	public object NormalChannelList; // 0x18
	public object FriendChannelList; // 0x20
	public object CurActiveChannels; // 0x28
	private object friendsMsgCacheDic; // 0x30
	private object hasloadFriendsCacheMsg; // 0x38
	public object hasReadFriendsCacheMsg; // 0x39
	public object ChatTab; // 0x3C

	// Methods

	// RVA: 0xE9CB24
	public object .ctor() { }

	// RVA: 0xEA301C
	private object GetFiendLastChatTimeFromPlayerPrefs(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xEA3228
	private object GetFiendUnreadFromPlayerPrefs(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xEA3434
	public object GetFiendLastChatTime(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE9ECBC
	public object GetFiendUnread(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE9FDBC
	public object SetFiendLastChatTime(object val, object unreadCount, object unreadCountAll, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xE9E7DC
	public object SetFiendUnread(object val, object valAll, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xEA355C
	public object initFriendsMsgCacheData() { }

	// RVA: 0xEA38C4
	public object GetFriendsMsgCacheList() { }

	// RVA: 0xEA397C
	public object SaveFriendsCacheData() { }

	// RVA: 0xE9C698
	public object ClearAll() { }

	// RVA: 0xEA3B10
	public object ClearIllegalPlayerChatInfo(object plkayerUid, object playerLogicWorldId) { }

	// RVA: 0xEA1C3C
	public object SetChatTab(object type) { }

	// RVA: 0xE9D408
	public object GetChannel(object type) { }

	// RVA: 0xEA4120
	public object GetFriendChannel(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xEA41E8
	public override object Clear(object type, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xEA4290
	public override object GetFriendTotal_UnreadCount() { }

	// RVA: 0xEA457C
	public object Add_CurChatFriend(object chatEnt) { }

	// RVA: 0xEA46AC
	public object Add_ChatEntity(object chatEnt, object type, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xEA3D50
	public object _getChannel(object type, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xEA3F0C
	public object CreateChannel(object type, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xEA4974
	public object ClearFriendChannelData(object friendUid, object friendLogicWorldId) { }

	// RVA: 0xEA4BD4
	public override object GetIChannel(object type) { }

	// RVA: 0xEA4C40
	public override object GetFriendIChannel(object ullUid, object dwLogicWorldId) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CChatNetUT
{

	// Methods

	// RVA: 0xEA4CC4
	public static object Send_Private_Chat(object ullUid, object logicWorldId, object text) { }

	// RVA: 0xEA5244
	public static object ResponsePrivateChat(object objId) { }

	// RVA: 0xEA5370
	public static object Send_Lobby_Chat(object text) { }

	// RVA: 0xEA5608
	public static object Send_TV_Chat(object text) { }

	// RVA: 0xEA5830
	public static object Send_Region_Chat(object text) { }

	// RVA: 0xEA5B4C
	public static object Send_Guild_Chat(object text) { }

	// RVA: 0xEA5DF8
	public static object Send_GuildTeam_Chat(object text) { }

	// RVA: 0xEA60A4
	public static object Send_Room_Chat(object text) { }

	// RVA: 0xEA62CC
	public static object Send_SelectHero_Chat(object template_id) { }

	// RVA: 0xEA6A60
	public static object Send_SelectHero_Chat(object text) { }

	// RVA: 0xEA6E38
	public static object Send_SelectHero_SoldierSkin_Chat(object text) { }

	// RVA: 0xEA7264
	public static object Send_Reverse_Chat(object ullUid, object iLogicWorldID) { }

	// RVA: 0xEA749C
	public static object Send_Team_Chat(object text, object chatType) { }

	// RVA: 0xEA77CC
	public static object SendEmojiMsgInTeam(object emojiID) { }

	// RVA: 0xEA7E3C
	public static object Send_Settle_Chat(object text) { }

	// RVA: 0xEA80E8
	public static object Send_Leave_Settle() { }

	// RVA: 0xEA8264
	public static object Send_GetChat_Req(object channel) { }

	// RVA: 0xEA84E0
	public static object Send_Private_Chat_To_IntimacyRelation(object ullUid, object logicWorldId, object intimacyState, object intimacyTitleId) { }

	// RVA: 0xEA8B8C
	public static object Send_Private_Chat_To_IntimacyFriend(object ullUid, object logicWorldId) { }

	// RVA: 0xEA8DF4
	public static object On_Chat_NTF_RelaySvr(object msg) { }

	// RVA: 0xEA8F84
	public static object On_Chat_NTF_LobbySvr(object msg) { }

	// RVA: 0xEA8EBC
	public static object On_Chat_NTFMainThread(object msg) { }

	// RVA: 0xEA8FE4
	public static object On_Offline_Chat_NTF(object msg) { }

	// RVA: 0xEA0F88
	public static object Send_Clear_Offline(object delIndexList) { }

	// RVA: 0xEA9110
	public static object On_Chat_Judge_Punish_NTF(object msg) { }

	// RVA: 0xEA923C
	public static object ReqFilterChatLang(object reqFilterLanng) { }

	// RVA: 0xEA9418
	public static object RspFilterChatLang(object msg) { }

	// RVA: 0xEA9598
	public static object ReqSetChatRegion(object regionId) { }

	// RVA: 0xEA9704
	public static object RspSetChatRegion(object msg) { }

	// RVA: 0xEA9ACC
	public static object On_Chat_Complaint_NTF(object msg) { }

	// RVA: 0xEA9BF8
	public static object On_Chat_Complaint_RSP(object msg) { }

	// RVA: 0xEA9D24
	public static object On_TranslateChatState_RSP(object msg) { }

	// RVA: 0xEA9DF0
	public static object Send_GemTranslateReq(object ent, object curtab) { }

	// RVA: 0xEAA070
	public static object On_SCPKG_CMD_MANUAL_GMETRANSLATE_RSP(object msg) { }

	// RVA: 0xEAA13C
	public static object Send_RealtimeReqComplaintReq(object VoiceComplaintType) { }

	// RVA: 0xEAA268
	public static object Send_RealtimeCandidComplaintReq(object VoiceComplaintType) { }

	// RVA: 0xEAA398
	public static object On_SCPKG_REALTIME_VOICE_COMPLAINT_RSP(object msg) { }

	// RVA: 0xEAAC28
	public static object On_SCPKG_REALTIMEVOICE_COMPLAINT_RSP(object msg) { }

	// RVA: 0xEAAC88
	public static object On_SCPKG_REALTIME_VOICE_COM_PLAINT_RSP(object msg) { }

	// RVA: 0xEAA3F8
	private static object On_SCPKG_REALTIME_VOICE_COMPLAINT(object msg) { }

	// RVA: 0xEAACE8
	public static object On_REALTIME_VOICE_COMPLAINT_RESULT_NTF(object msg) { }

	// RVA: 0xEAAF24
	public static object On_REALTIME_VOICECOMPLAINT_RESULT_NTF(object msg) { }

	// RVA: 0xEAAF84
	public static object On_REALTIME_VOICECOMPLAINT_RESULT_NTF_RelaySvr(object msg) { }

	// RVA: 0xEAAD48
	private static object On_REALTIMEVOICE_COMPLAINT_RESULT(object msg) { }

	// RVA: 0xEAB04C
	public static object On_MESS_EQUIPWARNING_RESULT_NTF(object msg) { }

	// RVA: 0xEAB308
	public static object On_MESS_EQUIP_WARNING_RESULT_NTF(object msg) { }

	// RVA: 0xEAB368
	public static object On_MESS_EQUIP_WARNING_RESULT_NTF_RelaySvr(object msg) { }

	// RVA: 0xEAB0AC
	private static object On_MESS_EQUIP_WARNING_RESULT(object msg) { }

	// RVA: 0xEAB430
	public static object onMessWarningMainThread(object bTipsType, object warnTipsText) { }

	// RVA: 0xEAB578
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class ChatItemHelper
{

	// Methods

	// RVA: 0xEAB580
	public object OnChatHideAnimationEnd() { }

	// RVA: 0xEAB620
	public object OnChatShowAnimationEnd() { }

	// RVA: 0xEAB6C0
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class ChatMsgReceiver
{

	// Fields
	public object bShowNewMsgRedPt; // 0x18
	public object redPtTargetGo; // 0x20
	public object showNewMsgRedPtChanels; // 0x28
	public object briefText; // 0x30
	public object TeamPlayerTalkText; // 0x38
	private object chatView; // 0x40
	private object chatModel; // 0x48
	public object showBriefTextChanels; // 0x50
	public object TipsGo; // 0x58
	public object reddotWithNum; // 0x60
	public object reddotNumText; // 0x68
	private object entryEntity; // 0x70

	// Methods

	// RVA: 0xEAB6C8
	private object Start() { }

	// RVA: 0xEABDA8
	public static object ParseText(object value) { }

	// RVA: 0xEAC15C
	private object On_Chat_ChatTeampTalk_Clear() { }

	// RVA: 0xEAC390
	private object On_Chat_ChatTeampTalk_Change(object type) { }

	// RVA: 0xEACC80
	private object On_Chat_ChatRoomTalk_Change() { }

	// RVA: 0xEAD080
	private object On_Chat_ChatSelectHero_Change() { }

	// RVA: 0xEACCE4
	private object SetBriefText(object chatChannel) { }

	// RVA: 0xEAD13C
	private object On_Chat_UnreadCountChanged(object channel) { }

	// RVA: 0xEABB3C
	private object ProcessNewMsgTips() { }

	// RVA: 0xEAD20C
	private object HasNewMsgUnread() { }

	// RVA: 0xEAD410
	private object ClearLastChatMsgText() { }

	// RVA: 0xEAD604
	private object OnChatFormClose(object evt) { }

	// RVA: 0xEAD66C
	private object On_Friend_Delete_NTF(object friendUid, object friendLogicWorldId, object type) { }

	// RVA: 0xEAD6F0
	private object OnDestroy() { }

	// RVA: 0xEADAF8
	public object .ctor() { }

}

// Namespace: 
public class TextWithEmotion
{

	// Fields
	public object data; // 0x8
	public object index; // 0x10

	// Methods

	// RVA: 0xEAF4AC
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class TextCutter
{

	// Fields
	public static object sEmoticonPattern; // 0x0

	// Methods

	// RVA: 0xEADB78
	public static object CutText(object srcText, object maxWidthPerLine, object textFont, object fontSize, object rawTextMaxWidth) { }

	// RVA: 0xEADF98
	public static object GetTextListAndWidth(object srcText, object maxWidthPerLine, object textFont, object fontSize, object rawTextMaxWidth) { }

	// RVA: 0xEAE3DC
	public static object ParseText(object srcText, object retList) { }

	// RVA: 0xEAEA18
	public static object ParseLines(object srcText, object textFont, object fontSize, object iSingleLineMaxWidth, object iSinglEmotionWidth) { }

	// RVA: 0xEAF534
	public static object GetCutIndexWithLineLimit(object srcText, object textFont, object fontSize, object iMaxWidth) { }

	// RVA: 0xEAF7B8
	public object .ctor() { }

	// RVA: 0xEAF7C0
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CHeroSelectSoldierSkinHelper
{

	// Fields
	public const object c_soldierSkinThanksRoom;
	public const object c_soldierSkinThanksEnemy;
	public const object c_soldierSkinThanksTeam;
	private static object m_selfShareEnemy; // 0x0

	// Methods

	// RVA: 0xEAF82C
	public static object SetSelfShareEnemy(object value) { }

	// RVA: 0xEAF8BC
	public static object IsSelfShareEnemy() { }

	// RVA: 0xEAF944
	public static object IsMyTeammate(object playerUid, object playerWorldId, object onlyRoommate) { }

	// RVA: 0xEAF9D4
	public static object GetMyTeammate(object playerUid, object playerWorldId, object onlyRoommate) { }

	// RVA: 0xEAFB7C
	public static object IsMyEnemy(object playerUid, object playerWorldId, object includeSelf) { }

	// RVA: 0xEAFD9C
	public static object GetOtherCamp(object selfCamp) { }

	// RVA: 0xEAFE10
	public static object GetThanksPrefixByMessageType(object messageType, object playerUID) { }

	// RVA: 0xEAFF68
	public static object GetTypeAndContentByMessage(object messageContent, object realContent, object playerUID) { }

	// RVA: 0xEB02B8
	public static object CanShowSoldierSkinShareThanks(object messageType, object ent, object includeSelf) { }

	// RVA: 0xEB0524
	public static object CanShowSoldierSkinShareThanksBySupporter(object messageType, object senderUid, object senderWorldId, object soldierSkinEnemyTargetID, object includeSelf) { }

	// RVA: 0xEB077C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object <>4__this; // 0x8
	public object heroId; // 0x10

	// Methods

	// RVA: 0xEB0D58
	public object .ctor() { }

	// RVA: 0xEB11F8
	internal object <ShowBubble>b__0(object e) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectBanSelectInfoBubbleView
{

	// Fields
	public object HeroHeadIcon; // 0x78
	public object TitleTextBan; // 0x80
	public object Banpick_HeroNameText; // 0x88
	public object SendHelpBan; // 0x90

	// Properties
	public override object bubbleType { get; }

	// Methods

	// RVA: 0xEB0784
	public override object get_bubbleType() { }

	// RVA: 0xEB07E4
	public override object ShowBubble(object bubble) { }

	// RVA: 0xEB0D60
	private object OnClickHelpBan(object heroId) { }

	// RVA: 0xEB1120
	public object .ctor() { }

	// RVA: 0xEB1130
	public object <>iFixBaseProxy_ShowBubble(object P0) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectBattleGuessBubbleView
{

	// Fields
	public object battleGuessTxt; // 0x78
	public object battleGuessIcon; // 0x80

	// Properties
	public override object bubbleType { get; }

	// Methods

	// RVA: 0xEB1220
	public override object get_bubbleType() { }

	// RVA: 0xEB1280
	public override object ShowBubble(object bubble) { }

	// RVA: 0xEB14D0
	public object .ctor() { }

	// RVA: 0xEB14D8
	public object <>iFixBaseProxy_ShowBubble(object P0) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectBattleInfoBubbleView
{

	// Fields
	public object heroNameText; // 0x78
	public object winRatioText; // 0x80
	public object playCountText; // 0x88
	public object winRatioDescText; // 0x90
	public object playCountDescText; // 0x98
	public object medalText; // 0xA0
	public object medalDescText; // 0xA8
	public object battleInfoBg; // 0xB0
	public object battleInfoPrimeBg; // 0xB8

	// Properties
	public override object bubbleType { get; }

	// Methods

	// RVA: 0xEB153C
	public override object get_bubbleType() { }

	// RVA: 0xEB159C
	public override object ShowBubble(object bubble) { }

	// RVA: 0xEB1B64
	public object .ctor() { }

	// RVA: 0xEB1B6C
	public object <>iFixBaseProxy_ShowBubble(object P0) { }

}

// Namespace: Assets.Scripts.GameSystem
public abstract class CUIHeroSelectBubbleBaseView
{

	// Properties
	public abstract object bubbleType { get; }

	// Methods

	// RVA: -1
	public abstract object get_bubbleType() { }

	// RVA: 0xEB1194
	public virtual object ShowBubble(object bubble) { }

	// RVA: 0xEB1BD0
	public virtual object HideBubble() { }

	// RVA: 0xEB1128
	protected object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectBubbleItemView
{

	// Fields
	public object BubbleViews; // 0x78
	public object bubbleRoot; // 0x80
	public object CdTimer; // 0x88
	private object time; // 0x90

	// Methods

	// RVA: 0xEB1C40
	protected override object OnViewInited() { }

	// RVA: 0xEB1D2C
	protected override object OnRefresh() { }

	// RVA: 0xEB1D88
	protected object ShowBubbleAndStartTime(object totalTime) { }

	// RVA: 0xEB1F18
	public object ShowBubble(object bubble) { }

	// RVA: 0xEB2290
	public object HideBubble() { }

	// RVA: 0xEB22F8
	public object HideBubble(object bubbleType) { }

	// RVA: 0xEB2490
	public object .ctor() { }

	// RVA: 0xEB24A0
	private object <ShowBubbleAndStartTime>b__6_0(object timer) { }

	// RVA: 0xEB2508
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEB2510
	public object <>iFixBaseProxy_OnRefresh() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectChatBubbleControlView
{

	// Fields
	public object BubbleInfoList; // 0x78
	public object BubbleEnemyInfoList; // 0x80

	// Methods

	// RVA: 0xEB2518
	protected override object OnViewInited() { }

	// RVA: 0xEB2574
	protected override object OnRefresh() { }

	// RVA: 0xEB25D0
	protected override object OnRegEvent() { }

	// RVA: 0xEB262C
	protected override object OnUnRegEvent() { }

	// RVA: 0xEB2688
	public object ShowBubble(object bubble) { }

	// RVA: 0xEB290C
	public object ShowEnemyBubble(object bubble) { }

	// RVA: 0xEB2B90
	public object HideBubble(object index) { }

	// RVA: 0xEB2F4C
	public object HideEnemyBubble(object index) { }

	// RVA: 0xEB3308
	public object .ctor() { }

	// RVA: 0xEB3310
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEB3318
	public object <>iFixBaseProxy_OnRefresh() { }

	// RVA: 0xEB3320
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xEB3328
	public object <>iFixBaseProxy_OnUnRegEvent() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectChatBubbleView
{

	// Fields
	public object NormalDynamicOneBubbleView; // 0x78
	private object uuid; // 0x80
	public object oneBubbleView; // 0x88

	// Methods

	// RVA: 0xEB3330
	protected override object OnViewInited() { }

	// RVA: 0xEB338C
	protected override object OnRefresh() { }

	// RVA: 0xEB33E8
	protected override object OnRegEvent() { }

	// RVA: 0xEB3444
	protected override object OnUnRegEvent() { }

	// RVA: 0xEB34A0
	public object SetCheckPlayerUid(object id) { }

	// RVA: 0xEB3508
	public object GetOneBubbleView() { }

	// RVA: 0xEB36AC
	public object .ctor() { }

	// RVA: 0xEB36B4
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEB36BC
	public object <>iFixBaseProxy_OnRefresh() { }

	// RVA: 0xEB36C4
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xEB36CC
	public object <>iFixBaseProxy_OnUnRegEvent() { }

}

// Namespace: 
public enum enChatType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Voice;
	public const object Text;
}

// Namespace: 
public enum SelectChatType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SelectChatType_Invalid;
	public const object SelectChatType_Normal;
	public const object SelectChatType_Normal_AddLaneMap;
	public const object SelectChatType_Normal_plentyMap;
	public const object SelectChatType_BanPick;
}

// Namespace: 
private sealed class <>c__DisplayClass49_0
{

	// Fields
	public object isTips; // 0x8
	public object <>4__this; // 0x10
	public object showTemplate; // 0x18

	// Methods

	// RVA: 0xEB9138
	public object .ctor() { }

	// RVA: 0xEBB384
	internal object <OnClickTabEvent>b__0(object evt) { }

}

// Namespace: 
private sealed class <>c__DisplayClass59_0
{

	// Fields
	public object <>4__this; // 0x8
	public object maxCount; // 0x10
	public object data_list; // 0x18

	// Methods

	// RVA: 0xEB97DC
	public object .ctor() { }

	// RVA: 0xEBB544
	internal object <refreshChatTemplateList>b__0(object ele) { }

}

// Namespace: 
private sealed class <>c__DisplayClass59_1
{

	// Fields
	public object templateString; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0xEBB7A0
	public object .ctor() { }

	// RVA: 0xEBB7A8
	internal object <refreshChatTemplateList>b__1(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass60_0
{

	// Fields
	public object maxCount; // 0x8
	public object data_list; // 0x10

	// Methods

	// RVA: 0xEB97E4
	public object .ctor() { }

	// RVA: 0xEBB9C8
	internal object <refreshAllChatList>b__0(object ele) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectChatControlWindow
{

	// Fields
	public object NormalNodeEnterScript; // 0x78
	public object NormalTemplateEnterScript; // 0x80
	public object NormalMapEnterScript; // 0x88
	public object HideScript; // 0x90
	public object chatDetailNode; // 0x98
	public object inputField; // 0xA0
	public object textSendBtnScript; // 0xA8
	public object backgroundObject; // 0xB0
	public object show_listScript; // 0xB8
	public object show_all_listScript; // 0xC0
	public object tab_templateEventScript; // 0xC8
	public object tab_historyEventScript; // 0xD0
	public object tabTemplateSelectObj; // 0xD8
	public object tabHistorySelectObj; // 0xE0
	public object ChatMapIcon; // 0xE8
	private object chatBriefInfo; // 0xF0
	public object NormalDynamicBubbleControlPanel; // 0xF8
	public object NormalDynamicMapControlPanel; // 0x100
	public object PlentyDynamicBubbleControlPanel; // 0x108
	public object NormalDynamicVoiceControlPanel; // 0x110
	public object btn_ReportingVoice; // 0x118
	public object SoldierSkinBtn; // 0x120
	public object SoldierSkinPanel; // 0x128
	private object CurrentBubbleControlView; // 0x130
	private object lanePickView; // 0x138
	private object curChatType; // 0x140
	private object BubbleControlPanel; // 0x148
	private object LastClickTime; // 0x150
	private object chat_cd_timer; // 0x154
	private object bIsInChatSend_CD; // 0x158

	// Methods

	// RVA: 0xEB36D4
	protected override object OnViewInited() { }

	// RVA: 0xEB4008
	protected override object OnDestroy() { }

	// RVA: 0xEB40C8
	protected override object OnRefresh() { }

	// RVA: 0xEB4124
	protected override object OnRegEvent() { }

	// RVA: 0xEB4848
	protected override object OnUnRegEvent() { }

	// RVA: 0xEB4F6C
	public override object OnFormDestroyed() { }

	// RVA: 0xEB51E0
	private object SetShowHistorOrTemplate(object showTemplate) { }

	// RVA: 0xEB58A8
	private object OnShowChatBubble(object bubble) { }

	// RVA: 0xEB5B88
	private object RefreshSoldierSkinSendBtn() { }

	// RVA: 0xEB6050
	private object OnShowSoldierSkinBubble(object data) { }

	// RVA: 0xEB689C
	private object OnShowSoldierSkinClick(object acntUniq, object soldierSkinId) { }

	// RVA: 0xEB7070
	public object OnWearShareSoldierSkin(object soldierSkinId, object acntUniq) { }

	// RVA: 0xEB6F60
	public object DoSendSoldierSkinShareThanks(object soldierSkinID, object messageType, object playerUID) { }

	// RVA: 0xEB7134
	private object On_Chat_HeorSelectChatData_Change() { }

	// RVA: 0xEB71A4
	private object Refresh_Bubble() { }

	// RVA: 0xEB7BC0
	private object OnLanePick(object uiEvent) { }

	// RVA: 0xEB8030
	private object Hide_Bubble(object index) { }

	// RVA: 0xEB7540
	private object Show_Bubble(object ent) { }

	// RVA: 0xEB8184
	private object InitChatInfo() { }

	// RVA: 0xEB901C
	public object OnClickTabEvent(object showTemplate, object isTips) { }

	// RVA: 0xEB9248
	private object IsChatAuthorization() { }

	// RVA: 0xEB9140
	public object IsChatAuthorizationInBattle(object callBack) { }

	// RVA: 0xEB92A8
	private object SelectHeroChatAuthorizationSdkCallbackEvent(object evt) { }

	// RVA: 0xEB8A64
	private object InitTemplateInfo() { }

	// RVA: 0xEB93D4
	private object HideAll() { }

	// RVA: 0xEB7E40
	private object SetHideScript(object active) { }

	// RVA: 0xEB94E0
	private object SwitchChatViewInfoShow() { }

	// RVA: 0xEB969C
	public object ForceCloseChatViewInfo() { }

	// RVA: 0xEB9774
	private object OnCloseAllPanel(object e) { }

	// RVA: 0xEB55E0
	private object refreshChatTemplateList() { }

	// RVA: 0xEB5308
	private object refreshAllChatList() { }

	// RVA: 0xEB8C20
	private object chatPanelSetToHideState() { }

	// RVA: 0xEB8CF8
	private object Show_SelectChat_MidNode(object bShow) { }

	// RVA: 0xEB8E3C
	private object OnUpdateBottomButtons() { }

	// RVA: 0xEB7274
	private object Refresh_BottomChat() { }

	// RVA: 0xEB3734
	private object SetShowType() { }

	// RVA: 0xEB9AE4
	private object NormalDynamicMapControlPanelLoadCallback() { }

	// RVA: 0xEB9C58
	private object OnChatEditEnd(object arg0) { }

	// RVA: 0xEB9DE0
	private object On_Input_Timer_End(object timer) { }

	// RVA: 0xEB9E48
	private object Start_Input_Timer() { }

	// RVA: 0xEB9F30
	private object On_Send_Text() { }

	// RVA: 0xEBA32C
	private object On_InputFiled_SendCallBack(object eventParams) { }

	// RVA: 0xEBA574
	private object On_List_Item_Click(object index) { }

	// RVA: 0xEBA8EC
	private object RefreshEntryMapIcon(object playerUUID, object type) { }

	// RVA: 0xEBAA90
	private object OnPrepareBattle() { }

	// RVA: 0xEB59FC
	private object GetCurrentBubbleControlView() { }

	// RVA: 0xEBAAF0
	public object .ctor() { }

	// RVA: 0xEBAB08
	private object <RefreshSoldierSkinSendBtn>b__38_0(object e) { }

	// RVA: 0xEBAC40
	private object <InitChatInfo>b__48_0(object e) { }

	// RVA: 0xEBAC48
	private object <InitChatInfo>b__48_1(object e) { }

	// RVA: 0xEBAC54
	private object <InitChatInfo>b__48_2(object e) { }

	// RVA: 0xEBAED0
	private object <InitChatInfo>b__48_3(object e) { }

	// RVA: 0xEBB03C
	private object <InitChatInfo>b__48_4(object e) { }

	// RVA: 0xEBB1A4
	private object <InitChatInfo>b__48_5(object e) { }

	// RVA: 0xEBB1A8
	private object <InitChatInfo>b__48_6(object e) { }

	// RVA: 0xEBB1AC
	private object <InitChatInfo>b__48_7(object e) { }

	// RVA: 0xEBB354
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEBB35C
	public object <>iFixBaseProxy_OnDestroy() { }

	// RVA: 0xEBB364
	public object <>iFixBaseProxy_OnRefresh() { }

	// RVA: 0xEBB36C
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xEBB374
	public object <>iFixBaseProxy_OnUnRegEvent() { }

	// RVA: 0xEBB37C
	public object <>iFixBaseProxy_OnFormDestroyed() { }

}

// Namespace: 
private sealed class <>c__DisplayClass10_0
{

	// Fields
	public object bubbleData; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0xEBC16C
	public object .ctor() { }

	// RVA: 0xEBC184
	internal object <ShowBubble>b__0(object e) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectSoldierShareInfoBubbleView
{

	// Fields
	public object PnlShareSoldierSkin; // 0x78
	public object AvatarIcon; // 0x80
	public object TitleText; // 0x88
	public object RemainTimeText; // 0x90
	public object UseText; // 0x98
	public object OtherContent; // 0xA0
	public object LeftBg; // 0xA8
	public object RightBg; // 0xB0

	// Properties
	public override object bubbleType { get; }

	// Methods

	// RVA: 0xEBBB44
	public override object get_bubbleType() { }

	// RVA: 0xEBBBA4
	public override object ShowBubble(object bubble) { }

	// RVA: 0xEBC174
	public object .ctor() { }

	// RVA: 0xEBC17C
	public object <>iFixBaseProxy_ShowBubble(object P0) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectSoldierShareThanksInfoBubbleView
{

	// Fields
	public object AvatarIcon; // 0x78
	public object ThanksText; // 0x80
	public object LeftBg; // 0x88
	public object RightBg; // 0x90

	// Properties
	public override object bubbleType { get; }

	// Methods

	// RVA: 0xEBC480
	public override object get_bubbleType() { }

	// RVA: 0xEBC4E0
	public override object ShowBubble(object bubble) { }

	// RVA: 0xEBC6F4
	public object .ctor() { }

	// RVA: 0xEBC6FC
	public object <>iFixBaseProxy_ShowBubble(object P0) { }

}

// Namespace: 
private sealed class <ShowBubbleInCoroutine>d__8
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object text; // 0x20
	public object isPrime; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEBCB84
	public object .ctor(object <>1__state) { }

	// RVA: 0xEBD098
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEBD09C
	private object MoveNext() { }

	// RVA: 0xEBD168
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEBD170
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEBD1B0
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectSpeakInfoBubbleView
{

	// Fields
	public object speakText; // 0x78
	public object NormalTextBgNode; // 0x80
	public object PrimeTextBgNode; // 0x88
	private object originalBubbleSpeakTextHeight; // 0x90

	// Properties
	public override object bubbleType { get; }

	// Methods

	// RVA: 0xEBC704
	public override object get_bubbleType() { }

	// RVA: 0xEBC760
	protected override object OnViewInited() { }

	// RVA: 0xEBC8B0
	public override object ShowBubble(object bubble) { }

	// RVA: 0xEBCAC0
	private object ShowBubbleInCoroutine(object text, object isPrime) { }

	// RVA: 0xEBCBB0
	private object SetBubbleText(object text, object isPrime) { }

	// RVA: 0xEBD080
	public object .ctor() { }

	// RVA: 0xEBD088
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEBD090
	public object <>iFixBaseProxy_ShowBubble(object P0) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectSystemHelpChooseInfoBubbleView
{

	// Fields
	public object HeroHeadIcon; // 0x78
	public object TitleText; // 0x80
	public object HeroNameText; // 0x88
	public object CountText; // 0x90
	public object HeroProficiencyIcon; // 0x98

	// Properties
	public override object bubbleType { get; }

	// Methods

	// RVA: 0xEBD1B8
	public override object get_bubbleType() { }

	// RVA: 0xEBD218
	public override object ShowBubble(object bubble) { }

	// RVA: 0xEBD690
	public object .ctor() { }

	// RVA: 0xEBD698
	public object <>iFixBaseProxy_ShowBubble(object P0) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUIHeroSelectWantChooseInfoBubbleView
{

	// Fields
	public object heroNameText; // 0x78
	public object titleText; // 0x80

	// Properties
	public override object bubbleType { get; }

	// Methods

	// RVA: 0xEBD6A0
	public override object get_bubbleType() { }

	// RVA: 0xEBD700
	public override object ShowBubble(object bubble) { }

	// RVA: 0xEBD930
	public object .ctor() { }

	// RVA: 0xEBD938
	public object <>iFixBaseProxy_ShowBubble(object P0) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUILanePickLaneInfo
{

	// Fields
	private object EventScript; // 0x18
	private object HeroIcon; // 0x20
	private object BorderSelf; // 0x28
	private object BorderOther; // 0x30
	private object LaneType; // 0x38
	private object OverlapNumIcon; // 0x40
	private object OverlapNum; // 0x48
	private object HeroIconImg; // 0x50
	private object LaneIconRoot; // 0x58
	private object LaneEffect; // 0x60
	private object LaneIcon; // 0x68
	private object LaneRedSelect; // 0x70

	// Methods

	// RVA: 0xEBD940
	public object Init() { }

	// RVA: 0xEBDF94
	public object SetBorderSelfActive(object active) { }

	// RVA: 0xEBE004
	public object SetBorderOtherActive(object active) { }

	// RVA: 0xEBDC80
	public object SetHeroIcon(object iconPath) { }

	// RVA: 0xEBE1F0
	public object RefreshLaneRedSelect() { }

	// RVA: 0xEBDF24
	public object SetLaneEffect(object active) { }

	// RVA: 0xEBE074
	public object SetOverlap(object num) { }

	// RVA: 0xEBE2C8
	public object GetLaneType() { }

	// RVA: 0xEBE328
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUILanePickOverlapFrame
{

	// Fields
	private object HeroIcon; // 0x78
	private object BorderSelf; // 0x80
	private object BorderOther; // 0x88
	private object HeroIconImg; // 0x90

	// Methods

	// RVA: 0xEBE330
	protected override object OnViewInited() { }

	// RVA: 0xEBE538
	public object SetBorderSelfActive(object active) { }

	// RVA: 0xEBE5B8
	public object Set(object position, object icon) { }

	// RVA: 0xEBE700
	public object .ctor() { }

	// RVA: 0xEBE708
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: 
private sealed class <>c__DisplayClass24_0
{

	// Fields
	public object <>4__this; // 0x8
	public object strTitleArray; // 0x10

	// Methods

	// RVA: 0xEC028C
	public object .ctor() { }

	// RVA: 0xEC0F68
	internal object <InitMapTab>b__0(object list) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUILanePickWindow
{

	// Fields
	private readonly object cachedLaneInfos; // 0x78
	private readonly object laneOccupyBuffer; // 0x80
	private object nodeGameObj; // 0x88
	private object MapNode; // 0x90
	private object MapTitle; // 0x98
	private object MapWeakNode; // 0xA0
	private object MapTab; // 0xA8
	public object MapSlider; // 0xB0
	public object MapBanPickMask; // 0xB8
	private object doNotWantSwitch; // 0xC0
	private object OverlapFrameTips; // 0xC8
	private object ThreeMoreOverlapXOffset; // 0xD0
	private object ThreeMoreOverlapYOffset; // 0xD4
	private object FourLessOverlapXOffset; // 0xD8
	private object FourLessOverlapYOffset; // 0xDC
	private object LaneInfos; // 0xE0
	private object TransformStatus; // 0xE8
	private object WeakLaneInfos; // 0xF0
	private object usedOverlapFrameTipsNum; // 0xF8

	// Methods

	// RVA: 0xEBE710
	protected override object OnViewInited() { }

	// RVA: 0xEB97EC
	public object InitInfo() { }

	// RVA: 0xEB50A0
	public object ClearInfo() { }

	// RVA: 0xEBADB8
	public object SwitchHideShowState() { }

	// RVA: 0xEB7F48
	public object SetToHideState() { }

	// RVA: 0xEBEB84
	private object InitMapTab() { }

	// RVA: 0xEBEFCC
	private object InitMapSlider() { }

	// RVA: 0xEC0294
	private object OnClickMapSlider() { }

	// RVA: 0xEBF2AC
	private object InitMapBanPickMask() { }

	// RVA: 0xEC03A0
	private object ResetOverlapFrameTips() { }

	// RVA: 0xEC04D8
	private object ResetLaneDisplayInfoBuff() { }

	// RVA: 0xEC06E4
	private object SetOverlapFrameTips(object laneType, object heroLaneDetails) { }

	// RVA: 0xEBF3E4
	private object ApplyHeroLanePickBySystemCache() { }

	// RVA: 0xEC0D48
	public static object Compare(object x, object y) { }

	// RVA: 0xEC0E94
	public object .ctor() { }

	// RVA: 0xEC0F5C
	private object <InitMapBanPickMask>b__27_0(object e) { }

	// RVA: 0xEC0F60
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: 
private sealed class <DelayHideBubbleMsg>d__20
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEC23E8
	public object .ctor(object <>1__state) { }

	// RVA: 0xEC24B4
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEC24B8
	private object MoveNext() { }

	// RVA: 0xEC2864
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEC286C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEC28AC
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <SetChatLayout>d__15
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object entity; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEC1624
	public object .ctor(object <>1__state) { }

	// RVA: 0xEC28B4
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEC28B8
	private object MoveNext() { }

	// RVA: 0xEC2A08
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEC2A10
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEC2A50
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class LobbyChatView
{

	// Fields
	private object playerName; // 0x78
	private object chatText; // 0x80
	private object ScrollContent; // 0x88
	private object msgBubbleObj; // 0x90
	private object msgBubbleText; // 0x98
	private object msgBubbleImage; // 0xA0
	private object bubbleMsgList; // 0xA8
	private object limitBubbleShow; // 0xB0
	private object maxBubbleShow; // 0xB4
	private object isCanChangeMsgAtOnce; // 0xB8
	private object CachChatEntity; // 0xC0

	// Methods

	// RVA: 0xEC1270
	public object OnLobbyChatMsg() { }

	// RVA: 0xEC14A4
	public object OnGuildChatMsg() { }

	// RVA: 0xEC1508
	public object OnRegionChatMsg() { }

	// RVA: 0xEC12D4
	private object ShowChannelChat(object cType) { }

	// RVA: 0xEC156C
	private object SetChatLayout(object entity) { }

	// RVA: 0xEC1650
	private object SetChatLayoutText(object uiEvent) { }

	// RVA: 0xEC1B3C
	protected override object OnViewInited() { }

	// RVA: 0xEC1DB0
	private object CreateChatText(object ent, object textContainer, object maxWidth) { }

	// RVA: 0xEC2100
	private object AddBubbleMsg(object stMsg) { }

	// RVA: 0xEC2344
	private object DelayHideBubbleMsg() { }

	// RVA: 0xEC2414
	public object .ctor() { }

	// RVA: 0xEC24AC
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: 
private sealed class <SetChatLayout>d__28
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object entity; // 0x18
	public object <>4__this; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEC4850
	public object .ctor(object <>1__state) { }

	// RVA: 0xEC4BE4
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEC4BE8
	private object MoveNext() { }

	// RVA: 0xEC4E4C
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEC4E54
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEC4E94
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class MatchingTeamChatView
{

	// Fields
	public object chatToolGo; // 0x78
	public object chatToolGo_Node; // 0x80
	public object chatToolGo_Node_List; // 0x88
	public object clickAreaEventScript; // 0x90
	public object templateListViewGo; // 0x98
	public object dynamicVoicePanelObj; // 0xA0
	public object shortCutOnGo; // 0xA8
	public object shortCutOffGo; // 0xB0
	public object playerName; // 0xB8
	public object chatText; // 0xC0
	private object m_matchingChatTemplateList; // 0xC8
	private const object TEAM_CHAT_CD_INTEVAL;
	private object iTeamQuickChatLastSendTime; // 0xD0

	// Properties
	public object DynamicVoicePanelObj { get; }

	// Methods

	// RVA: 0xEC2A58
	protected override object OnViewInited() { }

	// RVA: 0xEC2CAC
	public override object OnFormDestroyed() { }

	// RVA: 0xEC2E78
	public object SetQuickChatEnable(object enable) { }

	// RVA: 0xEC3218
	public object InitMatching_Chat_Template() { }

	// RVA: 0xEC2EF4
	public object ToggleMatching_Chat_Team_TemplateView(object isShow) { }

	// RVA: 0xEC3590
	public object get_DynamicVoicePanelObj() { }

	// RVA: 0xEC35F0
	private object OnMatchtingToggleChatView(object evt) { }

	// RVA: 0xEC366C
	private object OnMatching_Chat_Team_Template_List_ElementEnable(object uiEvent) { }

	// RVA: 0xEC3DDC
	private object CreatLineContent(object labelList, object pNode, object chatTextTemplate, object chatEmotionTemplate) { }

	// RVA: 0xEC3B20
	private object CreatGameObj(object name, object template, object pNode) { }

	// RVA: 0xEC41F0
	private object OnMatching_Chat_Team_Template_List_ElementSelect(object uiEvent) { }

	// RVA: 0xEC44BC
	private object IsTeamQuickChatInCd() { }

	// RVA: 0xEC4568
	public object OnLobbyChatMsg() { }

	// RVA: 0xEC45CC
	private object ShowChannelChat(object cType) { }

	// RVA: 0xEC4798
	private object SetChatLayout(object entity) { }

	// RVA: 0xEC487C
	private object CreateChatText(object ent, object textContainer, object maxWidth) { }

	// RVA: 0xEC4BCC
	public object .ctor() { }

	// RVA: 0xEC4BD4
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEC4BDC
	public object <>iFixBaseProxy_OnFormDestroyed() { }

}

// Namespace: 
private sealed class <>c__DisplayClass9_0
{

	// Fields
	public object confirmCb; // 0x8
	public object checkBoxCb; // 0x10
	public object <>4__this; // 0x18

	// Methods

	// RVA: 0xEC5398
	public object .ctor() { }

	// RVA: 0xEC53A8
	internal object <Show>b__0(object e) { }

	// RVA: 0xEC5424
	internal object <Show>b__1(object _) { }

	// RVA: 0xEC54A0
	internal object <Show>b__2(object e) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUITipDialogWnd
{

	// Fields
	public const object TIP_DIALOG_PATH;
	public object cancelBtn; // 0x78
	public object confirmBtn; // 0x80
	public object checkBox; // 0x88
	public object checkBoxGo; // 0x90
	public object MsgText; // 0x98
	public object CheckBoxText; // 0xA0
	public object bgGO; // 0xA8
	private object state; // 0xB0

	// Methods

	// RVA: 0xEC4E9C
	public object Show(object title, object msg, object cancelBtnMsg, object confirmBtnMsg, object checkboxMsg, object confirmCb, object checkBoxCb, object initCheckBoxState) { }

	// RVA: 0xEC53A0
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCCleanNewTableItem
{

	// Fields
	public object NameText; // 0x78
	public object TotaleSize; // 0x80
	public object Lock; // 0x88
	private object displayName; // 0x90
	private object dlcIds; // 0x98

	// Methods

	// RVA: 0xEC54F0
	public object ShowDLCDownloading(object DLCGroup, object ids) { }

	// RVA: 0xEC58C0
	protected override object OnViewInited() { }

	// RVA: 0xEC5740
	public object RefreshShow() { }

	// RVA: 0xEC5924
	private object RefreshBtn() { }

	// RVA: 0xEC5F4C
	public object .ctor() { }

	// RVA: 0xEC5FCC
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__21_1; // 0x8

	// Methods

	// RVA: 0xEC955C
	private static object .cctor() { }

	// RVA: 0xEC95BC
	public object .ctor() { }

	// RVA: 0xEC95C4
	internal object <OnDeleteClick>b__21_1(object _) { }

}

// Namespace: 
private sealed class <DoDelete>d__22
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <form>5__2; // 0x20
	private object <clearIEnum>5__3; // 0x28
	private object <size>5__4; // 0x30
	private object <lastClearTime>5__5; // 0x38
	private object <DELTA>5__6; // 0x3C

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEC821C
	public object .ctor(object <>1__state) { }

	// RVA: 0xEC95C8
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEC95CC
	private object MoveNext() { }

	// RVA: 0xEC9E9C
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEC9EA4
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEC9EE4
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCCleanView
{

	// Fields
	public object downloadedList; // 0x78
	public object listEmpty; // 0x80
	private object DeletableDLCDownLoadedGroups; // 0x88
	private object DLCDownLoadedGroups; // 0x90
	private object selectedIdxs; // 0x98
	private object selectIDs; // 0xA0
	public object SelectDlcSize; // 0xA8
	public object TotaleDlcSize; // 0xB0
	public object SelectAllGo; // 0xB8
	public object SelectAllBtn; // 0xC0
	public object UnSelectAllBtn; // 0xC8
	public object CleanBtn; // 0xD0
	private object SelectAllOneByOneAll; // 0xD8
	private object ManualCancleAll; // 0xD9
	public object currentSize; // 0xE0
	private const object DownloaderPath;
	private const object cleanPath;
	public object TemplatePopBoxBgView; // 0xE8

	// Methods

	// RVA: 0xEC5FD4
	protected override object OnViewInited() { }

	// RVA: 0xEC7B78
	private object UNSelectAllFun(object e) { }

	// RVA: 0xEC7CFC
	private object SelectAllFun(object e) { }

	// RVA: 0xEC7E08
	private object OnDeleteClick(object e) { }

	// RVA: 0xEC8178
	private object DoDelete() { }

	// RVA: 0xEC8248
	private object SelectAllDlc(object all) { }

	// RVA: 0xEC879C
	private object SelectListRefresh(object uiEvent) { }

	// RVA: 0xEC858C
	private object RefreshSelectedSize() { }

	// RVA: 0xEC8EDC
	protected override object OnDestroy() { }

	// RVA: 0xEC9054
	private object OnItemEnable(object uiEvent) { }

	// RVA: 0xEC64D8
	private object RefreshView() { }

	// RVA: 0xEC92EC
	public object .ctor() { }

	// RVA: 0xEC93E4
	private object <OnViewInited>b__18_0(object e) { }

	// RVA: 0xEC94D0
	private object <OnDeleteClick>b__21_0(object _) { }

	// RVA: 0xEC954C
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEC9554
	public object <>iFixBaseProxy_OnDestroy() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__26_1; // 0x8
	public static object <>9__29_1; // 0x10

	// Methods

	// RVA: 0xECEC98
	private static object .cctor() { }

	// RVA: 0xECECF8
	public object .ctor() { }

	// RVA: 0xECED00
	internal object <OnViewInited>b__26_1(object e) { }

	// RVA: 0xECEE14
	internal object <OnDeleteClick>b__29_1(object _) { }

}

// Namespace: 
private sealed class <>c__DisplayClass37_0
{

	// Fields
	public object sortKind; // 0x8
	public object keyCount; // 0x10

	// Methods

	// RVA: 0xECEE18
	public object .ctor() { }

	// RVA: 0xECEE20
	internal object <RefreshTableView>b__0(object firstDLCGroup, object secondDLCGroup) { }

}

// Namespace: 
private sealed class <DoDelete>d__30
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <form>5__2; // 0x20
	private object <clearIEnum>5__3; // 0x28
	private object <size>5__4; // 0x30
	private object <lastClearTime>5__5; // 0x38
	private object <DELTA>5__6; // 0x3C

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xECEFA4
	public object .ctor(object <>1__state) { }

	// RVA: 0xECEFD0
	private object System.IDisposable.Dispose() { }

	// RVA: 0xECEFD4
	private object MoveNext() { }

	// RVA: 0xECFB84
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xECFB8C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xECFBCC
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCCleanViewNew
{

	// Fields
	public object downloadedList; // 0x78
	public object listEmpty; // 0x80
	public object tableList; // 0x88
	public object tableEmpty; // 0x90
	private object DeletableDLCDownLoadedGroups; // 0x98
	private object DLCDownLoadedGroups; // 0xA0
	private object DLCDownLoadedTables; // 0xA8
	private object DLCTabGroups; // 0xB0
	private object DLCTabGroupList; // 0xB8
	private object DLCGroupIDsForTable; // 0xC0
	private object selectedIdxs; // 0xC8
	private object selectIDs; // 0xD0
	public object SelectDlcSize; // 0xD8
	public object TotaleDlcSize; // 0xE0
	public object SelectAllGo; // 0xE8
	public object SelectAllBtn; // 0xF0
	public object UnSelectAllBtn; // 0xF8
	public object CleanBtn; // 0x100
	public object DisableCleanBtn; // 0x108
	private object SelectAllOneByOneAll; // 0x110
	private object ManualCancleAll; // 0x111
	public object currentSize; // 0x118
	private const object DownloaderPath;
	private const object cleanPath;
	public object TemplatePopBoxBgView; // 0x120
	public object backBtn; // 0x128
	private object _currentTableName; // 0x130
	private object _currentTableIndex; // 0x138

	// Methods

	// RVA: 0xEC9EEC
	protected override object OnViewInited() { }

	// RVA: 0xECB068
	private object UNSelectAllFun(object e) { }

	// RVA: 0xECB1EC
	private object SelectAllFun(object e) { }

	// RVA: 0xECB358
	private object OnDeleteClick(object e) { }

	// RVA: 0xECB6C8
	private object DoDelete() { }

	// RVA: 0xECB77C
	private object SelectAllDlc(object all) { }

	// RVA: 0xECBCCC
	private object SelectListRefresh(object uiEvent) { }

	// RVA: 0xECBAC0
	private object RefreshSelectedSize() { }

	// RVA: 0xECC524
	private object ClearSelectedSize() { }

	// RVA: 0xECC588
	protected override object OnDestroy() { }

	// RVA: 0xECC7C0
	private object OnItemEnable(object uiEvent) { }

	// RVA: 0xECA630
	private object RefreshTableView() { }

	// RVA: 0xECCA58
	private object OnTableEnable(object e) { }

	// RVA: 0xECCC7C
	private object OnTableSelect(object e) { }

	// RVA: 0xECD0C4
	private object RefreshView() { }

	// RVA: 0xECC48C
	private object SetCleanBtnEnable(object isEnable) { }

	// RVA: 0xECE940
	public object .ctor() { }

	// RVA: 0xECEB20
	private object <OnViewInited>b__26_0(object e) { }

	// RVA: 0xECEC0C
	private object <OnDeleteClick>b__29_0(object _) { }

	// RVA: 0xECEC88
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xECEC90
	public object <>iFixBaseProxy_OnDestroy() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCDownloadedItem
{

	// Fields
	public object IconGO; // 0x78
	public object NameText; // 0x80
	public object TotleSize; // 0x88
	public object SelectTg; // 0x90
	public object NotDel; // 0x98
	public object form; // 0xA0
	public object DlcName; // 0xA8
	public object DownLoadedIDs; // 0xB0
	public object idx; // 0xB8
	private object canDele; // 0xBC
	private object currentSize; // 0xC0

	// Methods

	// RVA: 0xECFBD4
	protected override object OnViewInited() { }

	// RVA: 0xECFDFC
	private object SelectAllRefresh(object uiEvent) { }

	// RVA: 0xECFE8C
	protected override object OnDestroy() { }

	// RVA: 0xECFFE8
	private object OnSelectClick(object selected) { }

	// RVA: 0xED02E0
	public object ShowDLCDownloaded(object dlcName, object ids, object isOn) { }

	// RVA: 0xED0938
	public object .ctor() { }

	// RVA: 0xED0948
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xED0950
	public object <>iFixBaseProxy_OnDestroy() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCDownloaderFloatingTip
{

	// Fields
	public object progressText; // 0x68
	public object pausedGO; // 0x70
	public object downloadingGO; // 0x78
	public object lineGO; // 0x80
	private object currentId; // 0x88

	// Methods

	// RVA: 0xED0958
	public override object Initialize(object formScript) { }

	// RVA: 0xED09C8
	private object OnEnable() { }

	// RVA: 0xED0CD4
	private object OnDisable() { }

	// RVA: 0xED0D88
	public override object OnFormDestroyed() { }

	// RVA: 0xED0B6C
	private object UpdateState() { }

	// RVA: 0xED0DEC
	private object setProgress(object downloadedSize) { }

	// RVA: 0xED0FAC
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished(object id) { }

	// RVA: 0xED1014
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart(object id) { }

	// RVA: 0xED107C
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled(object id) { }

	// RVA: 0xED10E4
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadError(object id, object error) { }

	// RVA: 0xED1160
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0xED11E4
	private object ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished(object id, object filepath, object success) { }

	// RVA: 0xED1268
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0xED12D0
	public object OnDownloadPause(object pause) { }

	// RVA: 0xED1338
	public object .ctor() { }

	// RVA: 0xED1340
	public object <>iFixBaseProxy_Initialize(object P0) { }

	// RVA: 0xED1348
	public object <>iFixBaseProxy_OnFormDestroyed() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCDownloaderItem
{

	// Fields
	public object goBgLight; // 0x78
	public object iconGO; // 0x80
	public object NameText; // 0x88
	public object txtResDesc; // 0x90
	public object pauseBtn; // 0x98
	public object resumeBtn; // 0xA0
	public object deleteBtn; // 0xA8
	public object imgComplete; // 0xB0
	public object progress; // 0xB8
	public object silenceTag0; // 0xC0
	public object silenceTag1; // 0xC8
	public object Bg0GO; // 0xD0
	public object Bg1GO; // 0xD8
	public object form; // 0xE0
	private object defaultSprite; // 0xE8
	private object currentDLCGroup; // 0xF0
	private object displayName; // 0xF8
	private object resDesc; // 0x100
	private object dlcIds; // 0x108
	private object dlcUpIds; // 0x110
	private object DownloaderPath; // 0x118
	private object cdnID; // 0x120
	private object m_preState; // 0x124

	// Methods

	// RVA: 0xED1350
	public object ShowDLCDownloading(object DLCGroup, object ids, object upIDs, object formPath, object resDesc) { }

	// RVA: 0xED1D14
	protected override object OnViewInited() { }

	// RVA: 0xED1450
	public object RefreshShow() { }

	// RVA: 0xED1F48
	private object RefreshBtn() { }

	// RVA: 0xED31C8
	private object OnResumeClick(object e) { }

	// RVA: 0xED3CF4
	private object OnPauseClick(object e) { }

	// RVA: 0xED41A4
	private object OnDeleteClick(object e) { }

	// RVA: 0xED4A64
	public object .ctor() { }

	// RVA: 0xED4B1C
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__38_0; // 0x8
	public static object <>9__38_1; // 0x10
	public static object <>9__38_2; // 0x18
	public static object <>9__38_3; // 0x20

	// Methods

	// RVA: 0xEDC16C
	private static object .cctor() { }

	// RVA: 0xEDC1CC
	public object .ctor() { }

	// RVA: 0xEDC1D4
	internal object <OnViewInited>b__38_0(object e) { }

	// RVA: 0xEDC2E4
	internal object <OnViewInited>b__38_1(object e) { }

	// RVA: 0xEDC37C
	internal object <OnViewInited>b__38_2(object e) { }

	// RVA: 0xEDC538
	internal object <OnViewInited>b__38_3(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass39_0
{

	// Fields
	public object sortKind; // 0x8
	public object keyCount; // 0x10

	// Methods

	// RVA: 0xEDC63C
	public object .ctor() { }

	// RVA: 0xEDC644
	internal object <InitTable>b__0(object firstDLCGroup, object secondDLCGroup) { }

}

// Namespace: 
private sealed class <>c__DisplayClass66_0
{

	// Fields
	public object sortKind; // 0x8
	public object keyCount; // 0x10

	// Methods

	// RVA: 0xEDC7C8
	public object .ctor() { }

	// RVA: 0xEDC7D0
	internal object <RefreshCurrentTableDLCGroupList>b__0(object firstDLCGroup, object secondDLCGroup) { }

}

// Namespace: 
private sealed class <DoRefreshView>d__68
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xED9824
	public object .ctor(object <>1__state) { }

	// RVA: 0xEDC954
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEDC958
	private object MoveNext() { }

	// RVA: 0xEDCA00
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEDCA08
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEDCA48
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <InitTable>d__39
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <>8__1; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xED59F4
	public object .ctor(object <>1__state) { }

	// RVA: 0xEDCA50
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEDCA54
	private object MoveNext() { }

	// RVA: 0xEDD440
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEDD448
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEDD488
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <RefreshCurrentTableDLCGroupList>d__66
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <>8__1; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xED97F8
	public object .ctor(object <>1__state) { }

	// RVA: 0xEDD490
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEDD494
	private object MoveNext() { }

	// RVA: 0xEDE198
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEDE1A0
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEDE1E0
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCDownloaderNewView
{

	// Fields
	public object downloadingList; // 0x78
	public object btnDownloadAll; // 0x80
	public object goAllDownloaded; // 0x88
	public object tableList; // 0x90
	public object btnPause; // 0x98
	public object btnResume; // 0xA0
	public object ClearnBtn; // 0xA8
	public object txtCurTabDownloadSize; // 0xB0
	public object TemplatePopBoxBgView; // 0xB8
	public object Wifi; // 0xC0
	public object Battery; // 0xC8
	public object PandoraDlcNode; // 0xD0
	public object helpBtn; // 0xD8
	public object backBtn; // 0xE0
	public object Tips; // 0xE8
	public object txtDownloadSpeed; // 0xF0
	private object DLCGroupList; // 0xF8
	private object DLCTabGroupList; // 0x100
	private object DLCTabGroups; // 0x108
	private object DLCGroupUpIDs; // 0x110
	private object DLCGroupIDs; // 0x118
	private object DLCGroupIDsForTable; // 0x120
	private object DLCGroupResDescDic; // 0x128
	private object enableRefresh; // 0x130
	private object isRefreshing; // 0x131
	private object isDirtyRefresh; // 0x132
	private object m_isRefreshCurrentTableDLCGroupList; // 0x133
	private object isTidy; // 0x134
	private object isPufferReady; // 0x135
	public object localDownlodedList; // 0x138
	public object localDownlodedRealList; // 0x140
	private object DLCGroups; // 0x148
	private object DownloaderPath; // 0x150
	private object selectPandoraDlc; // 0x158
	private object m_currentDownloadingTable; // 0x160
	private object _currentTableName; // 0x168
	private object m_currentDownloadingDLCDisplayName; // 0x170
	private object m_firstDownloadStateReady; // 0x178
	private object m_isWifi; // 0x179

	// Methods

	// RVA: 0xED4B24
	protected override object OnViewInited() { }

	// RVA: 0xED57D0
	private object InitTable() { }

	// RVA: 0xED5A20
	private object DoTableList(object id, object majorTypeName, object data) { }

	// RVA: 0xED5EDC
	private object OnTableEnable(object e) { }

	// RVA: 0xED6170
	private object OnTableSelect(object e) { }

	// RVA: 0xED6760
	public object OnDownloadCanceled(object id) { }

	// RVA: 0xED67C4
	public object OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0xED6B4C
	public object OnDownloadError(object id, object error) { }

	// RVA: 0xED6BC4
	public object OnFileDownloadFinished(object id, object filepath, object success) { }

	// RVA: 0xED6FB0
	public object OnDLCDownloadFinished(object id) { }

	// RVA: 0xED7110
	public object OnDLCDownloadStart(object id) { }

	// RVA: 0xED7588
	public object OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0xED7640
	public object OnDownloadPause(object pause) { }

	// RVA: 0xED76E8
	private object OnDownloadStateReady() { }

	// RVA: 0xED7974
	private object OnApplicationPauseEvent(object isPaused) { }

	// RVA: 0xED7A2C
	private object OnRefreshPandoraDLCState(object state) { }

	// RVA: 0xED77C0
	private object RefreshViewOnCurrentTabIsDownloading() { }

	// RVA: 0xECF9B4
	public object CleanReturn() { }

	// RVA: 0xED7F64
	private object LoadUpdateList() { }

	// RVA: 0xED841C
	protected override object OnDestroy() { }

	// RVA: 0xED89C4
	private object Update() { }

	// RVA: 0xED7408
	public object RefreshView() { }

	// RVA: 0xED6524
	private object SetRefreshCurrentTableDLCGroupList() { }

	// RVA: 0xED7EAC
	public object RefreshTableList() { }

	// RVA: 0xED7474
	private object RefreshTableList(object tabName) { }

	// RVA: 0xED8EE4
	private object RefreshTableList(object i) { }

	// RVA: 0xED9164
	private object IsShowDLCItem(object data, object id) { }

	// RVA: 0xED54E8
	private object GetDisplayName(object id, object displayName) { }

	// RVA: 0xED8E40
	private object RefreshCurrentTableDLCGroupList() { }

	// RVA: 0xED8AA0
	private object PufferIsReady() { }

	// RVA: 0xED8D9C
	private object DoRefreshView() { }

	// RVA: 0xED9850
	public object DoDLCList(object id, object downloadState, object displayName, object displayUpdateName, object data) { }

	// RVA: 0xED7B44
	private object RefreshDownloadBtn() { }

	// RVA: 0xEDA5E8
	private object CurrentLevelResIsDownloadComplete() { }

	// RVA: 0xEDAAF0
	private object OnItemEnable(object e) { }

	// RVA: 0xECF8F8
	public object SetEnableRefresh(object _enableRefresh) { }

	// RVA: 0xEDAE80
	private object onNetworkStateChanged(object state) { }

	// RVA: 0xED5874
	private object IsShowWifi() { }

	// RVA: 0xED6930
	private object UpdateNetworkText() { }

	// RVA: 0xEDB008
	private object UpdateDownloadSpeed() { }

	// RVA: 0xEDB35C
	public object OnCreatePandoraDlc(object go) { }

	// RVA: 0xEDB7BC
	private object OpenPandoraDLC() { }

	// RVA: 0xED8888
	private object ClosePandoraDLC() { }

	// RVA: 0xED6D3C
	private object CheckAndUpdateTabDownloadProgress(object id) { }

	// RVA: 0xED6590
	private object UpdateTabDownloadProgress() { }

	// RVA: 0xEDB904
	private object UpdateTabDownloadProgress(object index) { }

	// RVA: 0xEDBF5C
	public object .ctor() { }

	// RVA: 0xEDC15C
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEDC164
	public object <>iFixBaseProxy_OnDestroy() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCDownloaderProgress
{

	// Fields
	public object DLCIDs; // 0x78
	public object beginSize; // 0x80
	public object totalSize; // 0x88
	private object currentSize; // 0x90
	public object forceUpdate; // 0x98
	private object m_isDownloading; // 0x99
	private object progressBarGO; // 0xA0
	private object progressBarGradient; // 0xA8
	private object speedText; // 0xB0
	private object progressText; // 0xB8
	private object progressNumText; // 0xC0
	private object stateText; // 0xC8
	private object progreeSli; // 0xD0
	private object curState; // 0xD8
	private object <OldCurrentSize>k__BackingField; // 0xE0
	private object <OldUnCurrentSize>k__BackingField; // 0xE8

	// Properties
	public object OldCurrentSize { get; set; }
	public object OldUnCurrentSize { get; set; }

	// Methods

	// RVA: 0xEDE1E8
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished(object id) { }

	// RVA: 0xEDE3C8
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart(object id) { }

	// RVA: 0xEDE42C
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled(object id) { }

	// RVA: 0xEDE490
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadError(object id, object error) { }

	// RVA: 0xEDE508
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0xEDE6CC
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0xEDEDF8
	private object ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished(object id, object filepath, object success) { }

	// RVA: 0xEDEE78
	private object ExchangeSize(object size) { }

	// RVA: 0xEDF04C
	private object CalcBeginSize() { }

	// RVA: 0xED1EDC
	public object SetDLCIDs(object ids) { }

	// RVA: 0xEDF118
	private object UpdateSpeed() { }

	// RVA: 0xED2A28
	public object ShowSpeed(object value, object state) { }

	// RVA: 0xEDF2D4
	private object UpdateDownloadState() { }

	// RVA: 0xEDF584
	public object get_OldCurrentSize() { }

	// RVA: 0xEDF58C
	public object set_OldCurrentSize(object value) { }

	// RVA: 0xEDF594
	public object get_OldUnCurrentSize() { }

	// RVA: 0xEDF59C
	public object set_OldUnCurrentSize(object value) { }

	// RVA: 0xED2CBC
	public object UpdateProgress(object showPercent) { }

	// RVA: 0xED3018
	public object SetStateText(object text) { }

	// RVA: 0xEDE760
	private object SetProgress(object v, object currentSize01, object showPercent) { }

	// RVA: 0xEDF5A4
	protected override object OnViewInited() { }

	// RVA: 0xEDF6EC
	protected override object OnRegEvent() { }

	// RVA: 0xEDF7AC
	protected override object OnUnRegEvent() { }

	// RVA: 0xEDF86C
	public object OnDownloadPause(object pause) { }

	// RVA: 0xEDF8D0
	private object OnEnable() { }

	// RVA: 0xEDF92C
	private object OnDisable() { }

	// RVA: 0xEDFA58
	public object .ctor() { }

	// RVA: 0xEDFA68
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEDFA70
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xEDFA78
	public object <>iFixBaseProxy_OnUnRegEvent() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCDownLoaderTableItem
{

	// Fields
	public object NameText; // 0x78
	public object TotaleSize; // 0x80
	public object stateFinish; // 0x88
	public object stateDownloading; // 0x90
	public object stateWait; // 0x98
	public object stateNoStart; // 0xA0
	private object displayName; // 0xA8
	private object dlcIds; // 0xB0
	private object updateTotalSize; // 0xB8
	private object totalSize; // 0xC0

	// Methods

	// RVA: 0xED60E8
	public object ShowDLCDownloading(object DLCGroup, object ids) { }

	// RVA: 0xEDFB8C
	protected override object OnViewInited() { }

	// RVA: 0xEDFA80
	private object InitShow() { }

	// RVA: 0xEDBA7C
	public object UpdateDownloadProgress(object returnSizeStr) { }

	// RVA: 0xED9028
	public object RefreshShow() { }

	// RVA: 0xEDFBF0
	private object RefreshBtn() { }

	// RVA: 0xEE043C
	public object .ctor() { }

	// RVA: 0xEE04BC
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__18_0; // 0x8
	public static object <>9__18_1; // 0x10

	// Methods

	// RVA: 0xEE3788
	private static object .cctor() { }

	// RVA: 0xEE37E8
	public object .ctor() { }

	// RVA: 0xEE37F0
	internal object <OnViewInited>b__18_0(object e) { }

	// RVA: 0xEE3888
	internal object <OnViewInited>b__18_1(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass26_0
{

	// Fields
	public object sortKind; // 0x8
	public object keyCount; // 0x10

	// Methods

	// RVA: 0xEE3920
	public object .ctor() { }

	// RVA: 0xEE3928
	internal object <DoRefreshView>b__0(object firstDLCGroup, object secondDLCGroup) { }

}

// Namespace: 
private sealed class <DoRefreshView>d__26
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <>8__1; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEE1888
	public object .ctor(object <>1__state) { }

	// RVA: 0xEE3AAC
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEE3AB0
	private object MoveNext() { }

	// RVA: 0xEE4D88
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEE4D90
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEE4DD0
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCDownloaderView
{

	// Fields
	public object downloadingList; // 0x78
	public object listEmpty; // 0x80
	public object btnPause; // 0x88
	public object btnResume; // 0x90
	public object ClearnBtn; // 0x98
	public object TemplatePopBoxBgView; // 0xA0
	private object DLCGroupList; // 0xA8
	private object DLCGroupUpIDs; // 0xB0
	private object DLCGroupIDs; // 0xB8
	private object enableRefresh; // 0xC0
	private object isRefreshing; // 0xC1
	private object isDirtyRefresh; // 0xC2
	private object isTidy; // 0xC3
	private object isPufferReady; // 0xC4
	public object localDownlodedList; // 0xC8
	public object localDownlodedRealList; // 0xD0
	public object lobbyHeroSkin; // 0xD8
	private object DLCGroups; // 0xE0

	// Methods

	// RVA: 0xEE04C4
	protected override object OnViewInited() { }

	// RVA: 0xEE0B2C
	public object CleanReturn() { }

	// RVA: 0xEE0D68
	private object LoadUpdateList() { }

	// RVA: 0xEE11E0
	protected override object OnDestroy() { }

	// RVA: 0xEE1528
	private object OnDownloadStateReady() { }

	// RVA: 0xEE1698
	private object Update() { }

	// RVA: 0xEE17D0
	private object OnApplicationPauseEvent(object isPaused) { }

	// RVA: 0xEE0CFC
	public object RefreshView() { }

	// RVA: 0xEE172C
	public object DoRefreshView() { }

	// RVA: 0xEE18B4
	public object DoDLCList(object id, object downloadState, object displayName, object displayUpdateName, object data) { }

	// RVA: 0xEE2600
	private object RefreshDownloadBtn() { }

	// RVA: 0xEE2D68
	private object OnItemEnable(object e) { }

	// RVA: 0xEE3068
	private object showDescription(object e) { }

	// RVA: 0xEE31B8
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished(object id) { }

	// RVA: 0xEE321C
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart(object id) { }

	// RVA: 0xEE32C4
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled(object id) { }

	// RVA: 0xEE3328
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadError(object id, object error) { }

	// RVA: 0xEE33A0
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0xEE3448
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0xEE34C8
	private object ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished(object id, object filepath, object dlcItemFinished) { }

	// RVA: 0xEE3548
	public object OnDownloadPause(object pause) { }

	// RVA: 0xED3C38
	public object SetEnableRefresh(object _enableRefresh) { }

	// RVA: 0xEE35F0
	public object .ctor() { }

	// RVA: 0xEE3778
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEE3780
	public object <>iFixBaseProxy_OnDestroy() { }

}

// Namespace: 
private sealed class <>c__DisplayClass116_0
{

	// Fields
	public object <>4__this; // 0x8
	public object ms; // 0x10

	// Methods

	// RVA: 0xEF59EC
	public object .ctor() { }

	// RVA: 0xEF59F4
	internal object <OnClearAllOld>b__0(object _) { }

	// RVA: 0xEF5AA0
	internal object <OnClearAllOld>b__1(object _) { }

}

// Namespace: 
private sealed class <>c__DisplayClass26_0
{

	// Fields
	public object <>4__this; // 0x8
	public object id; // 0x10

	// Methods

	// RVA: 0xEF5AC4
	public object .ctor() { }

	// RVA: 0xEF5ACC
	internal object <_TryDownloadDLC>b__0(object confirmed) { }

	// RVA: 0xEF5B24
	internal object <_TryDownloadDLC>b__1(object flag) { }

}

// Namespace: 
private sealed class <>c__DisplayClass27_0
{

	// Fields
	public object unstartList; // 0x8
	public object <>4__this; // 0x10
	public object showTips; // 0x18

	// Methods

	// RVA: 0xEF5B4C
	public object .ctor() { }

	// RVA: 0xEF5B54
	internal object <_TryDownloadDLC>b__0(object confirmed) { }

	// RVA: 0xEF5D10
	internal object <_TryDownloadDLC>b__1(object flag) { }

}

// Namespace: 
private sealed class <>c__DisplayClass36_0
{

	// Fields
	public object <>4__this; // 0x8
	public object downloadResLevel; // 0x10

	// Methods

	// RVA: 0xEF5D38
	public object .ctor() { }

	// RVA: 0xEF5D40
	internal object <GetResumeDownloadDLCIds>b__0(object id, object cfg) { }

	// RVA: 0xEF5E10
	internal object <GetResumeDownloadDLCIds>b__1(object id, object cfg) { }

}

// Namespace: 
private sealed class <>c__DisplayClass41_0
{

	// Fields
	public object id; // 0x8

	// Methods

	// RVA: 0xEF5EE0
	public object .ctor() { }

	// RVA: 0xEF5EE8
	internal object <heroAllSkinInQueue>b__0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass43_0
{

	// Fields
	public object <>4__this; // 0x8
	public object heroid; // 0x10
	public object ObjParam; // 0x18

	// Methods

	// RVA: 0xEF5EF8
	public object .ctor() { }

	// RVA: 0xEF5F00
	internal object <requestDownloadHuanHua>b__0() { }

	// RVA: 0xEF6070
	internal object <requestDownloadHuanHua>b__1(object confirmed) { }

	// RVA: 0xEF60A4
	internal object <requestDownloadHuanHua>b__2(object flag) { }

}

// Namespace: 
private sealed class <>c__DisplayClass62_0
{

	// Fields
	public object <>4__this; // 0x8
	public object downloadResLevel; // 0x10

	// Methods

	// RVA: 0xEF60CC
	public object .ctor() { }

	// RVA: 0xEF60D4
	internal object <AutoDownloadLobbyRes>b__0(object id, object cfg) { }

}

// Namespace: 
private sealed class <AutoDownloadLobbyRes>d__62
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <mgr>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEF61A4
	public object .ctor(object <>1__state) { }

	// RVA: 0xEF61D0
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEF61D4
	private object MoveNext() { }

	// RVA: 0xEF67F4
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEF67FC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEF683C
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <DoClearAll>d__117
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <clearIEnum>5__2; // 0x20
	private object <size>5__3; // 0x28
	private object <lastClearTime>5__4; // 0x30
	private object <DELTA>5__5; // 0x34

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEF6844
	public object .ctor(object <>1__state) { }

	// RVA: 0xEF6870
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEF6874
	private object MoveNext() { }

	// RVA: 0xEF6D84
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEF6D8C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEF6DCC
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <LoadBank>d__106
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object bankName; // 0x18
	public object bankType; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEF6DD4
	public object .ctor(object <>1__state) { }

	// RVA: 0xEF6E00
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEF6E04
	private object MoveNext() { }

	// RVA: 0xEF6EB0
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEF6EB8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEF6EF8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <RegisterOwnerBattleHeroDLC>d__56
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEF6F00
	public object .ctor(object <>1__state) { }

	// RVA: 0xEF6F2C
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEF6F30
	private object MoveNext() { }

	// RVA: 0xEF727C
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEF7284
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEF72C4
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <ShowDownloadFloatWndAndDownloadLobyRes>d__65
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <mgr>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEF72CC
	public object .ctor(object <>1__state) { }

	// RVA: 0xEF72F8
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEF72FC
	private object MoveNext() { }

	// RVA: 0xEF76E0
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEF76E8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEF7728
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCDownloadUISystem
{

	// Fields
	public const object DownloaderPath;
	public const object DownloaderPrePath;
	public const object DownloaderNewPath;
	public const object DownloadedPath;
	public const object DownloadedNewPath;
	public object CanRefreshSize; // 0x8
	public object DlcSelectIdx; // 0xC
	public object bClickConfirm; // 0x10
	private object m_ownedResHelper; // 0x18
	private object NewAddHeroSkin; // 0x20
	private object _startDLCDownloadedSize; // 0x28
	private object _startDLCDownloadTime; // 0x30
	private object hasReportDownloadSize; // 0x34
	private object _showConfirmDownloadDialog; // 0x35
	private object IsAddLobbyHeroSkinDL; // 0x36
	private object _downloadAllExcuted; // 0x37
	private object _lastReportPercent; // 0x38
	private object _autoDownloadLobbyInProceccing; // 0x39
	private object _autoDownloadLobbyResFlag; // 0x3A
	private object autoLobbyResFlag; // 0x3B
	private object m_isShowDownloadFloatWndAndDownloadLobyRes; // 0x3C
	public object CleanAll; // 0x3D
	private object downloadStartTime; // 0x40
	private object t_downloadingid; // 0x44
	private static object s_splashReg; // 0x0

	// Methods

	// RVA: 0xEE4DD8
	public override object Init() { }

	// RVA: 0xEE595C
	private object OnPufferVersionChanged(object obj) { }

	// RVA: 0xEE5D3C
	private object OnGetNewSkinNtf(object heroId, object skinId, object addReason) { }

	// RVA: 0xEE64B0
	private object OnGetNewHeroNtf(object heroId) { }

	// RVA: 0xEE608C
	private object TemporarySkin(object heroId, object skinId) { }

	// RVA: 0xEE6B04
	public object TryReportDownloadSize() { }

	// RVA: 0xEE6CF4
	private object OnDownloadStateReady() { }

	// RVA: 0xEE6E88
	public object StartListenDownloading() { }

	// RVA: 0xEE6F80
	public override object UnInit() { }

	// RVA: 0xEE7AFC
	private object OnGameLogout() { }

	// RVA: 0xEE7E1C
	public object TryDownloadHeroDLC(object heroid, object skinid, object withoutTips) { }

	// RVA: 0xEE8874
	public object TryDownloadAsianDLC() { }

	// RVA: 0xEE7F50
	private object _TryDownloadDLC(object id, object withoutTips) { }

	// RVA: 0xEE91D8
	private object _TryDownloadDLC(object ids) { }

	// RVA: 0xEE9E5C
	public object TryDownloadDLCByType(object szType, object localID, object withoutTips) { }

	// RVA: 0xEE8A4C
	public object TryDownloadDLCByType(object szTypes, object localID) { }

	// RVA: 0xEEA190
	public object TryDownloadDLCByID(object id, object withoutTips) { }

	// RVA: 0xEEA214
	public object tryPause() { }

	// RVA: 0xEEA398
	public object tryResume() { }

	// RVA: 0xEEAB20
	private object AddLobbyHeroSkinDL(object downloadResLevel, object addLoobyHeroSkin, object insertStartIndex) { }

	// RVA: 0xEEAD54
	public object GetResumeIds() { }

	// RVA: 0xEEA8C8
	private object GetResumeDownloadDLCIds(object downloadResLevel) { }

	// RVA: 0xEEAF84
	public object HeroAllSkinDownloaded(object heroid) { }

	// RVA: 0xEEB1EC
	public object IsHeroSkinDownloaded(object heroId, object skinId, object tryDownload) { }

	// RVA: 0xEEB6C0
	public object TryDownloadLobbyHeroSkinSound(object heroId, object skinId) { }

	// RVA: 0xEEB9D8
	public object IsHuanHuaReady(object heroid) { }

	// RVA: 0xEEBE0C
	private object heroAllSkinInQueue(object heroid) { }

	// RVA: 0xEEC174
	private object _DoDownloadHuanhua(object heroid) { }

	// RVA: 0xEEC8D4
	public object requestDownloadHuanHua(object heroid) { }

	// RVA: 0xEECF5C
	public object requestDownloadHeroAllSkin(object heroid) { }

	// RVA: 0xEED5D8
	public object requestDownloadAutoChessHeroAllSkin() { }

	// RVA: 0xEEA7A8
	private object doPause(object e) { }

	// RVA: 0xEED90C
	private object doPandoraDLCPause(object e) { }

	// RVA: 0xEED9C4
	private object OnDownloadAll(object e) { }

	// RVA: 0xEEE17C
	private object DoDownloadAll() { }

	// RVA: 0xEED2D0
	private object _doDowloadHeroAllSkin(object heroid) { }

	// RVA: 0xEEE2EC
	private object downloadHeroAllSkin(object e) { }

	// RVA: 0xEEE4A4
	private object ReportDownloadProgress() { }

	// RVA: 0xEEE710
	private object DownloadHeroBattleLowRes() { }

	// RVA: 0xEEE934
	private object RegisterOwnerBattleHeroDLC() { }

	// RVA: 0xEEE9E8
	public static object CheckInitialAppBattleResourceNeedUpdateAndShowTip() { }

	// RVA: 0xEEEA30
	private object IsDLCNeedDownload(object id, object cfg, object downloadResLevel) { }

	// RVA: 0xED95A0
	public object IsOwnLobbyHeroSkin(object id, object heroSkinName, object displayName) { }

	// RVA: 0xEEEEA8
	public object InitNotOwnHeroNewSkin() { }

	// RVA: 0xEEF1F8
	private object AutoDownloadLobbyRes() { }

	// RVA: 0xEEF2AC
	private object ShowDownloadFloatWndAndDownloadLobyRes() { }

	// RVA: 0xEEF360
	private object RefreshDLCDownloadListBtn() { }

	// RVA: 0xEE5B3C
	public object IsPufferVersionUnMatched() { }

	// RVA: 0xEE5BEC
	public object DoPufferVersionUnMatched() { }

	// RVA: 0xEEF858
	private object OnEnterLobby(object e) { }

	// RVA: 0xEEFD4C
	public object UpdateDLMaxConfig() { }

	// RVA: 0xEF00A4
	public object ActiveAndShowDownloading() { }

	// RVA: 0xEF0404
	private object StartShowDownloadFloatWndAndDownloadLobyRes() { }

	// RVA: 0xEEF9BC
	private object RegisterPreDLCConfig() { }

	// RVA: 0xEEFB84
	private object AddPandoraDLCConfig() { }

	// RVA: 0xEEF914
	private object RegisterTimingDLCConfig() { }

	// RVA: 0xEF04D4
	private object OnLobbyShow() { }

	// RVA: 0xEF0584
	private object OnLobbyStateLeave() { }

	// RVA: 0xEF05E4
	private object OnSettleToLobby() { }

	// RVA: 0xEE8EAC
	private object onConfirmDownload(object id, object showTips) { }

	// RVA: 0xEF0C74
	private object onCancelDownload(object id) { }

	// RVA: 0xEF0D6C
	private object onNetworkStateChanged(object state) { }

	// RVA: 0xEF106C
	private object onDownloadDeactive() { }

	// RVA: 0xEF10CC
	private object openDownloadingList() { }

	// RVA: 0xEF0644
	private object RefreshDLCTipsState() { }

	// RVA: 0xEF14CC
	private object CloseDLCDownloadListBtnTips() { }

	// RVA: 0xEF1354
	private object CloseDLCDownloadListBtnTips(object gameObject) { }

	// RVA: 0xEF166C
	private object onClickDDownloadListBtnClick(object e) { }

	// RVA: 0xEF1740
	private object onClickClearListBtnClick(object e) { }

	// RVA: 0xEF1920
	private object onClickClearNewBtnClick(object e) { }

	// RVA: 0xEEF504
	private object showDLCDownloadListBtn() { }

	// RVA: 0xEE7C2C
	private object hideDLCDownloadListBtn() { }

	// RVA: 0xEF1AAC
	private object updateDLCDownloadListBtnIcon() { }

	// RVA: 0xEF1DA4
	public object IsPausing() { }

	// RVA: 0xEDAEE8
	public object IsDownloading() { }

	// RVA: 0xEF1E84
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished(object id) { }

	// RVA: 0xEF257C
	public object RefreshDLCDownloadTab() { }

	// RVA: 0xEF26D4
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart(object id) { }

	// RVA: 0xEF29F8
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled(object id) { }

	// RVA: 0xEEDEB0
	private object TriggerStorageLimited() { }

	// RVA: 0xEF2A68
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadError(object id, object error) { }

	// RVA: 0xEF2D0C
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0xEF2D8C
	private object LoadBank(object bankName, object bankType) { }

	// RVA: 0xEF2E60
	private object ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished(object id, object filepath, object success) { }

	// RVA: 0xEF3224
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0xEF328C
	public object OnDownloadPause(object pause) { }

	// RVA: 0xEF22FC
	public object _ReportDLCDownloadTaskState(object id, object type) { }

	// RVA: 0xEF0AC4
	public object _ReportDLCDownloadPopWndEvent(object type, object opType) { }

	// RVA: 0xEF08D0
	public object SwitchDLCGroupNameToTLogReportType(object dlcGroupName) { }

	// RVA: 0xEF3368
	private object RefreshView() { }

	// RVA: 0xEF3600
	private object OnClearAll(object e) { }

	// RVA: 0xEF366C
	private object OnClearAllOld(object e) { }

	// RVA: 0xEF472C
	private object DoClearAll() { }

	// RVA: 0xEF47E0
	private object OnPauseAll(object e) { }

	// RVA: 0xEF48D8
	private object OnResumeAll(object e) { }

	// RVA: 0xEF49D0
	public object OpenTipDialogWnd(object title, object msg, object cancelMsg, object confirmMsg, object checkBoxMsg, object confirmCb, object checkBoxCb, object initCheckBoxState) { }

	// RVA: 0xEF4C54
	public object SetDownloaderProgress(object downloadingGo, object ids, object downloadItem, object name, object forceUpdateState) { }

	// RVA: 0xEDC480
	public object GetRuleID() { }

	// RVA: 0xEF4F58
	public object CreatePandoraDlc(object go) { }

	// RVA: 0xEF50D0
	private object OnRefreshPandoraDLCState(object state) { }

	// RVA: 0xEF52D4
	public object ChangeDownloadPackage(object id) { }

	// RVA: 0xEDAA08
	public object GetCurrentDownloadResLevel() { }

	// RVA: 0xEF535C
	public object GetCurrentPackageConfigID() { }

	// RVA: 0xEF53D0
	public object GetRecommendedPackageConfigID() { }

	// RVA: 0xEDAA7C
	public object GetResLevelIdsArray() { }

	// RVA: 0xEF5444
	public object GetResLevelTotalSizeArray() { }

	// RVA: 0xEF54B8
	public object GetResLevelByDlcID(object id) { }

	// RVA: 0xEF5538
	public object .ctor() { }

	// RVA: 0xEF55F0
	private static object .cctor() { }

	// RVA: 0xEF5688
	private object <OnDownloadAll>b__49_0(object _) { }

	// RVA: 0xEF56B4
	private object <OnDownloadAll>b__49_1(object _) { }

	// RVA: 0xEF56C0
	private object <ActiveAndShowDownloading>b__71_0(object succ, object code) { }

	// RVA: 0xEF56F4
	private object <onNetworkStateChanged>b__82_0(object _) { }

	// RVA: 0xEF5700
	private object <onNetworkStateChanged>b__82_1(object _) { }

	// RVA: 0xEF59E4
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xEF59E8
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__27_0; // 0x8
	public static object <>9__27_1; // 0x10
	public static object <>9__27_2; // 0x18

	// Methods

	// RVA: 0xEFBD78
	private static object .cctor() { }

	// RVA: 0xEFBDD8
	public object .ctor() { }

	// RVA: 0xEFBDE0
	internal object <OnViewInited>b__27_0(object e) { }

	// RVA: 0xEFBF64
	internal object <OnViewInited>b__27_1(object e) { }

	// RVA: 0xEFC06C
	internal object <OnViewInited>b__27_2(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass67_0
{

	// Fields
	public object sortKind; // 0x8
	public object keyCount; // 0x10

	// Methods

	// RVA: 0xEFC208
	public object .ctor() { }

	// RVA: 0xEFC210
	internal object <RefreshItemView>b__0(object firstDLCGroup, object secondDLCGroup) { }

}

// Namespace: 
private sealed class <DoRefreshView>d__66
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEFBB5C
	public object .ctor(object <>1__state) { }

	// RVA: 0xEFC394
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEFC398
	private object MoveNext() { }

	// RVA: 0xEFC440
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEFC448
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEFC488
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <RefreshItemView>d__67
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <>8__1; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xEFBC2C
	public object .ctor(object <>1__state) { }

	// RVA: 0xEFC490
	private object System.IDisposable.Dispose() { }

	// RVA: 0xEFC494
	private object MoveNext() { }

	// RVA: 0xEFCE30
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xEFCE38
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xEFCE78
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCPreView
{

	// Fields
	public object downloadingList; // 0x78
	public object helpBtn; // 0x80
	public object TemplatePopBoxBgView; // 0x88
	public object Wifi; // 0x90
	public object Battery; // 0x98
	public object Tips; // 0xA0
	public object txtDownloadSpeed; // 0xA8
	public object btnGoToDownloadList; // 0xB0
	public object imgRecommend; // 0xB8
	public object txtPackageRecommend; // 0xC0
	public object btnPackageChange; // 0xC8
	public object sliderProgress; // 0xD0
	public object goProgressEffect; // 0xD8
	public object txtDownloadProgress; // 0xE0
	public object txtDownloadSize; // 0xE8
	private object DLCGroupList; // 0xF0
	private object DLCGroups; // 0xF8
	private object DLCGroupIDs; // 0x100
	private object enableRefresh; // 0x108
	private object isRefreshing; // 0x109
	private object isDirtyRefresh; // 0x10A
	private object isReport; // 0x10B
	private object m_isRefreshItem; // 0x10C
	public static object showRefreshEffect; // 0x0
	private object m_firstDownloadStateReady; // 0x10D
	private object m_currentDownloadingTable; // 0x110
	private object m_isWifi; // 0x118
	private object m_totalSize; // 0x120
	private object m_currentSizeArr; // 0x128
	private object m_currentSize; // 0x130

	// Methods

	// RVA: 0xEF7730
	public static object GetPrefabPath() { }

	// RVA: 0xEF77B0
	protected override object OnViewInited() { }

	// RVA: 0xEF8320
	protected override object OnRegEvent() { }

	// RVA: 0xEF8438
	protected override object OnUnRegEvent() { }

	// RVA: 0xEF8564
	private object onNetworkStateChanged(object state) { }

	// RVA: 0xEF7F60
	private object IsShowWifi() { }

	// RVA: 0xEF85CC
	private object UpdateNetworkText() { }

	// RVA: 0xEF880C
	private object UpdateDownloadSpeed() { }

	// RVA: 0xEF8A50
	protected override object OnDestroy() { }

	// RVA: 0xEF8D08
	private object OnApplicationPauseEvent(object isPaused) { }

	// RVA: 0xEF9078
	private object OnDownloadStateReady() { }

	// RVA: 0xEF9260
	public object OnDownloadCanceled(object id) { }

	// RVA: 0xEF92C4
	public object OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0xEF95E8
	public object OnDownloadError(object id, object error) { }

	// RVA: 0xEF9660
	public object OnFileDownloadFinished(object id, object filepath, object dlcItemFinished) { }

	// RVA: 0xEF96E0
	public object OnDLCDownloadFinished(object id) { }

	// RVA: 0xEF9848
	public object OnDLCDownloadStart(object id) { }

	// RVA: 0xEF9CD8
	public object OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0xEF9D80
	public object OnDownloadPause(object pause) { }

	// RVA: 0xEF9E28
	private object OnRefreshPandoraDLCState(object state) { }

	// RVA: 0xEF9E8C
	private object RefreshItems() { }

	// RVA: 0xEF9A14
	private object RefreshItem(object tabName) { }

	// RVA: 0xEFA084
	private object OnItemEnable(object e) { }

	// RVA: 0xEFA538
	private object Update() { }

	// RVA: 0xEF82B4
	private object RefreshView() { }

	// RVA: 0xEF8DDC
	private object SetRefreshItems() { }

	// RVA: 0xEFA908
	private object ReportDownloadState() { }

	// RVA: 0xEFAE6C
	public object DoDLCList(object id, object downloadState, object displayName, object data) { }

	// RVA: 0xEFB330
	public object SetEnableRefresh(object _enableRefresh) { }

	// RVA: 0xEF8244
	private object DownloadPackageChangeHandle(object e) { }

	// RVA: 0xEFB3C0
	private object UpdateRecommendPackageInfo() { }

	// RVA: 0xEF8E48
	private object UpdateTotalDownloadSize() { }

	// RVA: 0xEF943C
	private object UpdateDownloadSizeDisplay(object id) { }

	// RVA: 0xEF80E0
	private object SetTotalSizeEmpty() { }

	// RVA: 0xEFB694
	private object UpdateDownloadSizeDisplay() { }

	// RVA: 0xEFA608
	private object PufferIsReady() { }

	// RVA: 0xEFA864
	private object DoRefreshView() { }

	// RVA: 0xEFBB88
	private object RefreshItemView() { }

	// RVA: 0xEFBC58
	public object .ctor() { }

	// RVA: 0xEFBD58
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEFBD60
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xEFBD68
	public object <>iFixBaseProxy_OnUnRegEvent() { }

	// RVA: 0xEFBD70
	public object <>iFixBaseProxy_OnDestroy() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCPreViewDownloaderProgress
{

	// Fields
	public object DLCIDs; // 0x78
	private object totalSize; // 0x80
	private object currentSize; // 0x88
	private object m_isDownloading; // 0x90
	private object m_progressBar; // 0x98
	private object txtProgress; // 0xA0
	private object txtSize; // 0xA8
	private object goBgProgress; // 0xB0
	private object goNoContentMask; // 0xB8

	// Methods

	// RVA: 0xEFCE80
	protected override object OnViewInited() { }

	// RVA: 0xEFCEE4
	protected override object OnRegEvent() { }

	// RVA: 0xEFCFA4
	protected override object OnUnRegEvent() { }

	// RVA: 0xEFD064
	public object SetDLCIDs(object ids) { }

	// RVA: 0xEFD0D0
	private object CalcBeginSize() { }

	// RVA: 0xEFD7D8
	private object UpdateNoIdsText() { }

	// RVA: 0xEFDBCC
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled(object id) { }

	// RVA: 0xEFDC30
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0xEFDCB0
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadError(object id, object error) { }

	// RVA: 0xEFDD28
	private object ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished(object id, object filepath, object success) { }

	// RVA: 0xEFDFBC
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished(object id) { }

	// RVA: 0xEFE020
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart(object id) { }

	// RVA: 0xEFE084
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0xEFE0E8
	public object OnDownloadPause(object pause) { }

	// RVA: 0xEFDEC8
	private object UpdateDownloadedSize(object resPath) { }

	// RVA: 0xEFE14C
	public object SetDownloaded() { }

	// RVA: 0xEFD28C
	public object UpdateProgress(object showProgress) { }

	// RVA: 0xEFE1B8
	public object SetProgressBarImage(object progressBar, object isDownloading) { }

	// RVA: 0xEFE238
	public object .ctor() { }

	// RVA: 0xEFE240
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xEFE248
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xEFE250
	public object <>iFixBaseProxy_OnUnRegEvent() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCPreViewItem
{

	// Fields
	public object iconGO; // 0x78
	public object NameText; // 0x80
	public object Detailes; // 0x88
	public object stateFinish; // 0x90
	public object goDownloadingEffect; // 0x98
	public object stateDownloading; // 0xA0
	public object imgDownloadingProgress; // 0xA8
	public object stateWait; // 0xB0
	public object imgWaitProgress; // 0xB8
	public object stateNoStart; // 0xC0
	public object imgNoStartProgress; // 0xC8
	public object progress; // 0xD0
	public object pandoraDlcNode; // 0xD8
	public object gameDlcNode; // 0xE0
	public object goRefreshLight; // 0xE8
	private object currentDLCGroup; // 0xF0
	private object displayName; // 0xF8
	private object dlcGroupDesc; // 0x100
	private object m_cfg; // 0x108
	private object dlcIds; // 0x110
	private object m_preState; // 0x118

	// Methods

	// RVA: 0xEFA470
	public object ShowDLCDownloading(object cfg, object ids, object showRefreshEffect) { }

	// RVA: 0xEFE564
	protected override object OnViewInited() { }

	// RVA: 0xEFE6E4
	private object OnWaitClick(object uievent) { }

	// RVA: 0xEFECF4
	private object OnDownloadingClick(object uievent) { }

	// RVA: 0xEFF02C
	private object OnNoStartClick(object uievent) { }

	// RVA: 0xEFE258
	private object InitShow(object showRefreshEffect) { }

	// RVA: 0xEFA024
	public object RefreshShow() { }

	// RVA: 0xEFF62C
	private object RefreshBtn() { }

	// RVA: 0xF0017C
	public object .ctor() { }

	// RVA: 0xF001FC
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCPackageView
{

	// Fields
	private static object PrefabPath; // 0x0
	public object TemplatePopBoxBgView; // 0x78
	public object btnHelp; // 0x80
	public object itemList; // 0x88
	public object btnConfirm; // 0x90
	private object m_selectedId; // 0x98

	// Methods

	// RVA: 0xEFC154
	public static object GetPrefabPath() { }

	// RVA: 0xF00204
	protected override object OnViewInited() { }

	// RVA: 0xF00678
	protected override object OnRegEvent() { }

	// RVA: 0xF00790
	protected override object OnUnRegEvent() { }

	// RVA: 0xF008A8
	private object OnBtnHelpClick(object uievent) { }

	// RVA: 0xF00998
	private object OnBtnConfirmClick(object uievent) { }

	// RVA: 0xF00CD0
	private object OnItemEnable(object e) { }

	// RVA: 0xF005B4
	private object InitPackageData() { }

	// RVA: 0xF0166C
	public object SelectDLCPackage(object packageID) { }

	// RVA: 0xF01A28
	public object .ctor() { }

	// RVA: 0xF01A30
	private static object .cctor() { }

	// RVA: 0xF01A9C
	public object <>iFixBaseProxy_OnViewInited() { }

	// RVA: 0xF01AA4
	public object <>iFixBaseProxy_OnRegEvent() { }

	// RVA: 0xF01AAC
	public object <>iFixBaseProxy_OnUnRegEvent() { }

}

// Namespace: Assets.Scripts.GameSystem
public class DLCPackageViewItem
{

	// Fields
	public object txtPackageName; // 0x78
	public object txtPackageDesc; // 0x80
	public object txtPackageSize; // 0x88
	public object imgIcon; // 0x90
	public object imgRecommend; // 0x98
	public object goSelected; // 0xA0
	public object clickItem; // 0xA8
	private object m_cfg; // 0xB0

	// Methods

	// RVA: 0xF01AB4
	protected override object OnViewInited() { }

	// RVA: 0xF00F4C
	public object ShowPackageItem(object cfg, object size) { }

	// RVA: 0xF019A8
	public object SetSelectedState(object select) { }

	// RVA: 0xF01B98
	private object OnItemClick(object uievent) { }

	// RVA: 0xF01920
	public object PackageIdIsEqual(object packageId) { }

	// RVA: 0xF01D44
	public object .ctor() { }

	// RVA: 0xF01D4C
	public object <>iFixBaseProxy_OnViewInited() { }

}

// Namespace: 
public enum SelfEquipFormOrigin
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object FromHeroPick;
	public const object FromGodInfo;
	public const object FromBattleSelf;
	public const object FromHeroPickAsian;
}

// Namespace: Assets.Scripts.GameSystem
public class CEquipSystem
{

	// Fields
	public const object lobbyEquipShoplevelId;
	private object <selfEquipOpenOrigin>k__BackingField; // 0x8
	public object curEditHeroID; // 0xC
	private object <equipShopDictionary>k__BackingField; // 0x10
	private object <disPlayEquipList>k__BackingField; // 0x18
	private object <fumoEquipDic>k__BackingField; // 0x20
	private object <equipTaskSystem>k__BackingField; // 0x28
	private object <curRecmdIndex>k__BackingField; // 0x30
	private object m_equipShopTitleKeyList; // 0x38
	private object m_cfgEquipTypeStrsDict; // 0x40
	public object IsIgnoreLightDarkCampLimit; // 0x48

	// Properties
	public object twoEquipMaxCount { get; }
	public object threeEquipMaxCountPer2ndEquip { get; }
	public object backEquipMaxCount { get; }
	public object selfEquipOpenOrigin { get; set; }
	public object equipShopDictionary { get; set; }
	public object disPlayEquipList { get; set; }
	public object fumoEquipDic { get; set; }
	public object equipTaskSystem { get; set; }
	public object curRecmdIndex { get; set; }

	// Methods

	// RVA: 0xF01D54
	public object get_twoEquipMaxCount() { }

	// RVA: 0xF01DB4
	public object get_threeEquipMaxCountPer2ndEquip() { }

	// RVA: 0xF01E14
	public object get_backEquipMaxCount() { }

	// RVA: 0xF01E74
	public object get_selfEquipOpenOrigin() { }

	// RVA: 0xF01E7C
	private object set_selfEquipOpenOrigin(object value) { }

	// RVA: 0xF01E84
	public object get_equipShopDictionary() { }

	// RVA: 0xF01E8C
	private object set_equipShopDictionary(object value) { }

	// RVA: 0xF01E94
	public object get_disPlayEquipList() { }

	// RVA: 0xF01E9C
	private object set_disPlayEquipList(object value) { }

	// RVA: 0xF01EA4
	public object get_fumoEquipDic() { }

	// RVA: 0xF01EAC
	private object set_fumoEquipDic(object value) { }

	// RVA: 0xF01EB4
	public object get_equipTaskSystem() { }

	// RVA: 0xF01EBC
	private object set_equipTaskSystem(object value) { }

	// RVA: 0xF01EC4
	public object get_curRecmdIndex() { }

	// RVA: 0xF01ECC
	public object set_curRecmdIndex(object value) { }

	// RVA: 0xF01ED4
	public override object Init() { }

	// RVA: 0xF0254C
	public override object UnInit() { }

	// RVA: 0xF02734
	public object ReloadEquipInfoDictionaryUI(object e) { }

	// RVA: 0xF02418
	public object ReloadEquipInfoDictionary() { }

	// RVA: 0xF0279C
	public object ClearEquipList() { }

	// RVA: 0xF0299C
	public object CurEditHeroID() { }

	// RVA: 0xF029FC
	private object InitEquipShopTitleVars() { }

	// RVA: 0xF03340
	public object IsEquipUsageEnable(object equipUsage, object includeRecommand) { }

	// RVA: 0xF03D34
	private object GetEquipTypeTitle(object equipTypeIndex) { }

	// RVA: 0xF03F74
	public object GetEquipTittleList(object includeRecommand) { }

	// RVA: 0xF03870
	public object IsAidEquipEnable() { }

	// RVA: 0xF039E0
	public object IsFestivalEquipEnable() { }

	// RVA: 0xF04200
	private object IsLightDarkMode() { }

	// RVA: 0xF03AD4
	public object IsLightEquipEnable() { }

	// RVA: 0xF03BFC
	public object IsDarkEquipEnable() { }

	// RVA: 0xF034A8
	private object IsCfgForbidEquipType(object equipUsage) { }

	// RVA: 0xF042B8
	public object GetCurEditHeroUserEquipId() { }

	// RVA: 0xF043A4
	public object GetCurEditHeroEquipPlanNameByIndex(object equipIndex) { }

	// RVA: 0xF044CC
	public object CheckPrivilegeIconDisableStatus(object index, object heroId) { }

	// RVA: 0xF045CC
	private object NeedCheckPrivilege(object index, object heroId) { }

	// RVA: 0xF047B4
	private object GetPrivilegeCountNum(object heroId) { }

	// RVA: 0xF04714
	public object HasEverHadPrivilege() { }

	// RVA: 0xF0488C
	public object IsEverHadPrivilegeOrNowHave() { }

	// RVA: 0xF049AC
	private object LobbyEquipShopInVisitor(object resShopInfo) { }

	// RVA: 0xF05114
	public object GetEquipShopInfo(object equipId, object type) { }

	// RVA: 0xF05068
	private object GetLobbyEquipShopID() { }

	// RVA: 0xF05270
	public object OpenSelfEquipPlanFormInBattle(object formPath, object heroId, object rcmdEquipList, object changeEventID, object bChangeName, object bSvrRsp) { }

	// RVA: 0xF05414
	public object RefreshSelfEquipPlanForm(object selfEquipPlanForm, object heroId, object rcmdEquipList, object changeEventID, object showAni) { }

	// RVA: 0xF06A9C
	public object GetRcmdShowCount(object heroId) { }

	// RVA: 0xF06BE0
	public object ShowSingleEquipItemUIWithTouchTips(object equipItem, object equipInfo, object form) { }

	// RVA: 0xF07098
	public object .ctor() { }

	// RVA: 0xF070F0
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xF070F4
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public struct CFriendNewApplayForRedPoint
{

	// Fields
	public object typeIndex; // 0xFFFFFFFFFFFFFFF8
	public object ApplayHeadIcon; // 0x0
	public object ApplayCount; // 0x8
	public object ApplayRelationCount; // 0xC

	// Methods

	// RVA: 0xF071A0
	public object ResetAllData() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__71_0; // 0x8

	// Methods

	// RVA: 0xF11AE4
	private static object .cctor() { }

	// RVA: 0xF11B44
	public object .ctor() { }

	// RVA: 0xF11B4C
	internal object <SendInviteMsg>b__71_0(object result) { }

}

// Namespace: 
private sealed class <>c__DisplayClass74_0
{

	// Fields
	public object <>4__this; // 0x8
	public object uniq; // 0x10

	// Methods

	// RVA: 0xF0F8EC
	public object .ctor() { }

	// RVA: 0xF11DD4
	internal object <SendRecallMsg>b__0(object result) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendController
{

	// Fields
	public static readonly object FriendFormPath; // 0x0
	public static readonly object SNSOnlyInviteFormPath; // 0x8
	public static readonly object SNSOnlyShareFormPath; // 0x10
	public static readonly object FORM_MY_Friend; // 0x18
	private readonly object <model>k__BackingField; // 0x8
	private readonly object <view>k__BackingField; // 0x10
	private object <IsSnsFriendCondition>k__BackingField; // 0x18
	private object applayForRedPointInfo; // 0x20
	private object relationAnniCount; // 0x38
	private object relationUpGradeCount; // 0x3C
	private object m_IntimacyTip; // 0x40
	private object m_SessionRecall; // 0x48
	private object m_RecallSession; // 0x50
	private const object DONT_INTERRUPT_DATE_KEY;
	private object m_hasSelected; // 0x54

	// Properties
	private object Assets.Scripts.GameSystem.IFriendController.model { get; }
	public object model { get; }
	private object Assets.Scripts.GameSystem.IFriendController.view { get; }
	public object view { get; }
	public object IsSnsFriendCondition { get; set; }
	public object ApplayForRedPointInfo { get; }
	public object iLng { get; }
	public object iLat { get; }

	// Methods

	// RVA: 0xF072C0
	private object Assets.Scripts.GameSystem.IFriendController.get_model() { }

	// RVA: 0xF07320
	public object get_model() { }

	// RVA: 0xF07328
	private object Assets.Scripts.GameSystem.IFriendController.get_view() { }

	// RVA: 0xF07388
	public object get_view() { }

	// RVA: 0xF07390
	public object get_IsSnsFriendCondition() { }

	// RVA: 0xF07398
	public object set_IsSnsFriendCondition(object value) { }

	// RVA: 0xF073A0
	public object get_ApplayForRedPointInfo() { }

	// RVA: 0xF07414
	public object SetNewApplayForRedPointInfo(object index, object headIcon, object applayCount) { }

	// RVA: 0xF074DC
	public object SetFriendApplayCount(object applayCount) { }

	// RVA: 0xF075A8
	public object SetApplayRelationCount(object applayCount) { }

	// RVA: 0xF07E40
	public object .ctor() { }

	// RVA: 0xF08B74
	public object ClearAll() { }

	// RVA: 0xF093BC
	public override object Init() { }

	// RVA: 0xF0A2C8
	private object OnLanChanged() { }

	// RVA: 0xF095E4
	private object InitEvent() { }

	// RVA: 0xF0A338
	private object UninitEvent() { }

	// RVA: 0xF0A394
	public object OpenSnsOnlyAwardForm() { }

	// RVA: 0xF0A70C
	public object Update_SNSOnlyList_CanBeInvite(object num, object astSnsInviteList) { }

	// RVA: 0xF0ACFC
	private object SaveInviteLog(object invitedID) { }

	// RVA: 0xF0AD60
	private object ReadinviteLog() { }

	// RVA: 0xF0ADBC
	public object Send_Req_SNSFriendList() { }

	// RVA: 0xF0AE18
	public object On_Friend_SNS_Share_Friend(object platformUid) { }

	// RVA: 0xF0B074
	public object SNSOpenIdToPlatformId(object snsOpenId) { }

	// RVA: 0xF0B0DC
	public object GetIntimacyChangeInfo(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF0B1D8
	public object GetIntimacyChangeInfoDelta(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF0B2DC
	public object ShowDelayedIntimacyChange() { }

	// RVA: 0xF0B9C0
	public object CheckFriendStatusChange(object type, object NewCount) { }

	// RVA: 0xF0BB48
	public object OpFriendListCount(object type, object add) { }

	// RVA: 0xF0BD04
	private object OnShareToggle(object uievent) { }

	// RVA: 0xF0BEBC
	public object GetFriendPointByType(object intimacyType) { }

	// RVA: 0xF0BFA8
	public object On_GPS_Response() { }

	// RVA: 0xF0C1A4
	private object OnFriend_LBS_OnClickEnableLBS(object evt) { }

	// RVA: 0xF0C4FC
	private object OnFriend_LBS_OnClickDisableLBS(object evt) { }

	// RVA: 0xF0C210
	public object SetEnableShareLocation(object enableShareLocation) { }

	// RVA: 0xF09320
	public object SetFilter(object value) { }

	// RVA: 0xF0C788
	private object OnFriend_LBS_Nan(object evt) { }

	// RVA: 0xF0CA20
	private object OnFriend_LBS_Nv(object evt) { }

	// RVA: 0xF0CC28
	private object On_OpenForm(object uiEvent) { }

	// RVA: 0xF0CF40
	public object DownloadDlc() { }

	// RVA: 0xF0D200
	private object On_CloseForm(object uiEvent) { }

	// RVA: 0xF0D2B4
	public object Open_Friend_Verify(object ullUid, object dwLogicWorldId, object channel, object prePriority, object preSubPriority) { }

	// RVA: 0xF0D6D8
	public object Send_MatchBlack(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF0DF90
	private object On_Send_MatchBlack(object uiEvent) { }

	// RVA: 0xF0E05C
	private object OnLobbyEnter(object mode) { }

	// RVA: 0xF0E11C
	private object On_Friend_SendCoin(object uievent) { }

	// RVA: 0xF0E3C0
	public object GetFirendRedDotCount() { }

	// RVA: 0xF0E61C
	public object GetRelationRedDotCount() { }

	// RVA: 0xF0E6CC
	public object SetRelationUpdateRedDotCount(object count) { }

	// RVA: 0xF0E798
	public object SetRelationAnniRedDotCount(object count) { }

	// RVA: 0xF0E864
	public object GetRelationAnniAndUpdateRedDotCount() { }

	// RVA: 0xF0E918
	public object GetFriendBtnIsHaveRed() { }

	// RVA: 0xF0E9B0
	private object On_Friend_CheckInfo(object uievent) { }

	// RVA: 0xF0EBAC
	private object On_Friend_Invite_SNS_Friend_BtnClick(object uievent) { }

	// RVA: 0xF0ED54
	private object GetGCloudChannelFormParam(object param) { }

	// RVA: 0xF0F18C
	private object SendInviteMsg(object platform) { }

	// RVA: 0xF0F504
	public object SendRecallMsg(object platformId, object uniq) { }

	// RVA: 0xF0F8F4
	private object OnApplicationPause(object isPaused) { }

	// RVA: 0xF0FA24
	private object On_Intimacy_Reward(object uiEvent) { }

	// RVA: 0xF0FAE8
	private object OnNewDayNtf() { }

	// RVA: 0xF0FB44
	public object UpdateForbidFriendReq() { }

	// RVA: 0xF0FD68
	public object CanShowFriendReqTipToday() { }

	// RVA: 0xF100D8
	private object OnFriend_SetConnect(object evt) { }

	// RVA: 0xF10198
	private object OnFriend_ConnectFacebookFinish() { }

	// RVA: 0xF101F4
	private object OnFriend_DisConnectFacebookFinish() { }

	// RVA: 0xF10250
	private object OnFriend_FacebookStateChange() { }

	// RVA: 0xF102AC
	private object OnFriendFBSNSInviteChooseToNotBindFacebook(object uiEvent) { }

	// RVA: 0xF07780
	private object OnNewApplayRedPointRefresh() { }

	// RVA: 0xF089B0
	private object AddIntimacyFriendTranslateInBattle() { }

	// RVA: 0xF10318
	public object GetRelationLvByValue(object mValue, object targetLv, object intimacyValue, object showLv) { }

	// RVA: 0xF106AC
	public object OpenMyFriendForm(object onItemClicked) { }

	// RVA: 0xF10814
	public object GetFriendRaltionItemList() { }

	// RVA: 0xF10AC8
	public object SetHttpImage(object HttpImage, object url, object loadFX) { }

	// RVA: 0xF10B58
	public object ShowRank(object HisRankGo, object RankGrade, object RankClass, object RankScore, object titleInfo) { }

	// RVA: 0xF10C0C
	public object ShowRank(object HisRankGo, object RankGrade, object RankClass, object RankScore) { }

	// RVA: 0xF10CA0
	public object ShowSNSOnlyFriendData(object info, object com) { }

	// RVA: 0xF10D24
	public object GetTimeString(object time) { }

	// RVA: 0xF10D90
	public object ResetTimer(object timer, object bPause) { }

	// RVA: 0xF10E14
	public object CalcDeltaHorus(object fromT, object toT) { }

	// RVA: 0xF10E98
	public object GetCanRemoveRelationFriendList() { }

	// RVA: 0xF10F20
	public object SetTabList(object titles, object start_index, object tablistScript) { }

	// RVA: 0xF10FB0
	public object ResetGetFrinedInfoState() { }

	// RVA: 0xF11058
	public object Send_Request_Sns_Switch(object type, object tag) { }

	// RVA: 0xF11114
	public object CheckFrinedInfoState() { }

	// RVA: 0xF111BC
	public object SendReserveAcntReq(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF11278
	public object SendReserveOperReq(object operType, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF1134C
	public object SendInviteSNSFriendReport(object type, object subType, object result) { }

	// RVA: 0xF0A204
	public object GetPosition(object callback, object needGotoSettings) { }

	// RVA: 0xF11420
	public object GetRemarkOrNicky(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF114A4
	public object ShowRank(object HisRankGo, object RankGrade, object RankClass) { }

	// RVA: 0xF11548
	public object get_iLng() { }

	// RVA: 0xF115E8
	public object get_iLat() { }

	// RVA: 0xF11688
	public object GetCurrentFriendPanelTab() { }

	// RVA: 0xF11910
	public object IsFriendLBS() { }

	// RVA: 0xF1197C
	public object StopGPS() { }

	// RVA: 0xF11A1C
	private static object .cctor() { }

	// RVA: 0xF11AE0
	public object <>iFixBaseProxy_Init() { }

}

// Namespace: 
private enum SortFriendType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object GameFriend;
	public const object SNS;
}

// Namespace: 
public class SNSOnlyFriendInfo
{

	// Fields
	private object <name>k__BackingField; // 0x8
	private object <headUrl>k__BackingField; // 0x10
	public object uid; // 0x18
	private object <platformUid>k__BackingField; // 0x20
	public object gameId; // 0x28
	public object hashedUserKey; // 0x30
	public object messageBlocked; // 0x38
	public object supportedDevice; // 0x39
	private object <canBeInvite>k__BackingField; // 0x3A
	private object <lastShareTime>k__BackingField; // 0x3C

	// Properties
	public object name { get; set; }
	public object headUrl { get; set; }
	public object platformUid { get; set; }
	public object canBeInvite { get; set; }
	public object lastShareTime { get; set; }

	// Methods

	// RVA: 0xF18678
	public object get_name() { }

	// RVA: 0xF18680
	public object set_name(object value) { }

	// RVA: 0xF18688
	public object get_headUrl() { }

	// RVA: 0xF18690
	public object set_headUrl(object value) { }

	// RVA: 0xF18698
	public object get_platformUid() { }

	// RVA: 0xF186A0
	public object set_platformUid(object value) { }

	// RVA: 0xF186A8
	public object get_canBeInvite() { }

	// RVA: 0xF186B0
	public object set_canBeInvite(object value) { }

	// RVA: 0xF186B8
	public object get_lastShareTime() { }

	// RVA: 0xF186C0
	public object set_lastShareTime(object value) { }

	// RVA: 0xF186C8
	public object .ctor() { }

}

// Namespace: 
public class FindFriendData
{

	// Fields
	public object level; // 0x8
	public object goodAt; // 0xC
	public object day; // 0x10
	public object hour; // 0x14
	public object location; // 0x18

	// Methods

	// RVA: 0xF186D8
	public object .ctor() { }

	// RVA: 0xF18744
	public object reset() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__50_0; // 0x8

	// Methods

	// RVA: 0xF187A8
	private static object .cctor() { }

	// RVA: 0xF18808
	public object .ctor() { }

	// RVA: 0xF18810
	internal object <SortSNSOnlyList>b__50_0(object x, object y) { }

}

// Namespace: 
private sealed class <>c__DisplayClass145_0
{

	// Fields
	public object friendName; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0xF18C00
	public object .ctor() { }

	// RVA: 0xF18C08
	internal object <GetTempAllFriendByName>b__0(object info) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendModel
{

	// Fields
	private object _fbOrVkSort; // 0x8
	public object ullSvrCurSec; // 0x10
	private object _map; // 0x18
	private object _allFriends; // 0x20
	private object _tempFriends; // 0x28
	private object _needSortFriendType; // 0x30
	private object delayRefreshFriendGameStateTimer; // 0x34
	public object InGameStateData; // 0x38
	public object NicknameData; // 0x40
	public object WinRateData; // 0x48
	public object IntimacyData; // 0x50
	public object HeartData; // 0x58
	public object SnsReCallData; // 0x60
	public object AddFriendTimeData; // 0x68
	public object FiveCampELOData; // 0x70
	public object RemarkData; // 0x78
	public object MoTogameData; // 0x80
	public object MusicParkourData; // 0x88
	public object SnsChannelNickNameData; // 0x90
	public object TeamStateData; // 0x98
	public object IntimacyUpInfo; // 0xA0
	public object ChannelIDData; // 0xA8
	public object ChampionData; // 0xB0
	private object m_friendVerifyList; // 0xB8
	private object m_preconfigVerifyContentList; // 0xC0
	public object friend_static_text; // 0xC8
	public object friendReserve; // 0xD0
	private object m_blackList_friend; // 0xD8
	private object m_SNSUnregistList; // 0xE0
	private object m_SNSRegistedList; // 0xE8
	private object snsTotalInviteNum; // 0xF0
	private object m_LBSList; // 0xF8
	private object m_LBSListNv; // 0x100
	private object m_LBSListNan; // 0x108
	private object m_LBSListOther; // 0x110
	public object m_shareLocation; // 0x118
	private object _fileter; // 0x11C
	public object m_findFriendData; // 0x120
	public object filterFriendList; // 0x128
	private object m_MatchBlackList; // 0x130
	public object snsTokenResultCodeList; // 0x138

	// Properties
	public object FBOrVkSort { get; }
	private object Assets.Scripts.GameSystem.IFriendModel.friendReserve { get; }
	public object SnsTotalInviteNum { get; set; }
	public object fileter { get; set; }
	public object EnableShareLocation { get; set; }

	// Methods

	// RVA: 0xF12128
	public object get_FBOrVkSort() { }

	// RVA: 0xF12240
	private object Assets.Scripts.GameSystem.IFriendModel.get_friendReserve() { }

	// RVA: 0xF122A0
	public object GetBlackList() { }

	// RVA: 0xF12300
	public object GetName(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF123FC
	public object GetUser(object ullUid, object dwLogicWorldId, object friendInfo, object chatInfo) { }

	// RVA: 0xF126F0
	public object IsBlack(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF127B0
	public object GetBlackName(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF128A4
	public object AddBlack(object info) { }

	// RVA: 0xF12958
	public object AddFriendBlack(object info) { }

	// RVA: 0xF12A4C
	public object RemoveFriendBlack(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF12B0C
	public object GetSNSOnlyAllList() { }

	// RVA: 0xF12C34
	public object GetSNSOnlyList(object registed) { }

	// RVA: 0xF12CB0
	public object ResetSNSOnlyFriend() { }

	// RVA: 0xF12DC8
	public object AddSNSOnlyFirend(object info, object registed) { }

	// RVA: 0xF12E94
	public object GetSNSOnlyIndex(object platformUid, object registed) { }

	// RVA: 0xF0AA5C
	public object SetCanNotBeInvited(object id) { }

	// RVA: 0xF0A468
	public object SortSNSOnlyList() { }

	// RVA: 0xF13068
	public object set_SnsTotalInviteNum(object value) { }

	// RVA: 0xF130D0
	public object get_SnsTotalInviteNum() { }

	// RVA: 0xF0AEC8
	public object SetSNSOnlyHaveShared(object platformUid) { }

	// RVA: 0xF09ED4
	public object LoadPreconfigVerifyContentList() { }

	// RVA: 0xF13130
	public object GetVerifyContentList(object channel) { }

	// RVA: 0xF1340C
	public object GetFriendVerifyContent(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF134D8
	public object GetFriendVerifySource(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF135B8
	public object AddFriendVerifyContent(object ullUid, object dwLogicWorldID, object content, object source) { }

	// RVA: 0xF13720
	public object RemoveFriendVerifyContent(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF0C144
	public object get_fileter() { }

	// RVA: 0xF0C720
	public object set_fileter(object value) { }

	// RVA: 0xF0C63C
	public object get_EnableShareLocation() { }

	// RVA: 0xF0C568
	public object set_EnableShareLocation(object value) { }

	// RVA: 0xF137E0
	public object GetLBSGenterFilter() { }

	// RVA: 0xF0C990
	public object NegFlag(object value, object flag) { }

	// RVA: 0xF13924
	public object GetCurrentLBSList() { }

	// RVA: 0xF13C64
	public object GetLBSListByUISys(object type) { }

	// RVA: 0xF13BA4
	public object GetLBSList(object type) { }

	// RVA: 0xF13D24
	public object GetLBSUserInfo(object ullUid, object dwLogicWorldId, object type) { }

	// RVA: 0xF13E74
	public object SortLBSFriend() { }

	// RVA: 0xF14034
	public object ClearLBSData() { }

	// RVA: 0xF1416C
	public object RemoveLBSUser(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF14230
	private object RemoveLBSUser(object ullUid, object dwLogicWorldId, object list) { }

	// RVA: 0xF1430C
	public object AddLBSUser(object info) { }

	// RVA: 0xF143F4
	private object AddLBSUser(object info, object list) { }

	// RVA: 0xF144B8
	public object GetFriendListContainText(object text, object type) { }

	// RVA: 0xF147A8
	public object GetMatchBlackList() { }

	// RVA: 0xF14808
	public object ClearMatchBlackList() { }

	// RVA: 0xF14898
	public object AddMatchBlack(object info) { }

	// RVA: 0xF149C4
	public object RemoveMatchBlack(object info) { }

	// RVA: 0xF14A88
	public object RemoveMatchBlack(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF14B48
	public object IsMatchBlack(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF0DE9C
	public object GetMatchBlackName(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF0DD50
	public object GetMatchBlackCount() { }

	// RVA: 0xF0DDEC
	public static object GetMatchBlackMaxCount() { }

	// RVA: 0xF07F60
	public object .ctor() { }

	// RVA: 0xF14C08
	public object IsAnyFriendExist(object requre_bOnline) { }

	// RVA: 0xF0BE50
	public static object IsOnSnsSwitch(object switchBits, object type) { }

	// RVA: 0xF14D00
	public object IsFriendOfflineOnline(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF14DE4
	public object IsFriendInGamingState(object ullUid, object dwLogicWorldID, object State) { }

	// RVA: 0xF14E88
	public object GetFriendInGameStateList() { }

	// RVA: 0xF14EE8
	public object GetFriendInGamingState(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF14F80
	public object GetFriendInGamingSubState(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF15018
	public object GetFriendInGamingTeamId(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF150B0
	public object GetFriendInGamingTeamSeq(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF15148
	public object GetFriendInGaming(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF15208
	public object GetFriendInGameMapType(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF152A0
	public object GetFriendInGameMapID(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF15338
	public object GetFriendInGamingTimeString(object ullUid, object dwLogicWorldID, object showInHead) { }

	// RVA: 0xF153E4
	public object GetFriendInGamingByState(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF15490
	public object SetUserPrivacyBits(object ullUid, object dwLogicWorldId, object inUserPrivacyBits) { }

	// RVA: 0xF1562C
	public static object IsAntiDisturbBits(object inFriend) { }

	// RVA: 0xF156A4
	public static object IsAntiDisturbBits(object inAntiDisturbBits) { }

	// RVA: 0xF15704
	public object SetFriendGameState(object ullUid, object dwLogicWorldID, object bState, object bSubState, object startTime, object updateAsianWhiteList, object bIsInAsianGamesWhiteList, object info, object videoState, object allowDirectJoinFriendType, object teamStateInfo, object bMaptype, object dwMapID) { }

	// RVA: 0xF15A24
	private object OnFriendReserveStateChange(object ullUid, object dwLogicWorldID, object oldState, object oldSubState, object newState, object newSubState) { }

	// RVA: 0xF15DDC
	public object ContainTokenResultCode(object apolloPlatform) { }

	// RVA: 0xF0E4B8
	public object GetDataCount(object type) { }

	// RVA: 0xF15EEC
	public object GetFindFriendInfoAtIndex(object index) { }

	// RVA: 0xF160E4
	public object GetFilterInfoAtIndex(object index) { }

	// RVA: 0xF161C8
	public object GetInfoAtIndex(object type, object index) { }

	// RVA: 0xF162D4
	public object Add(object type, object data) { }

	// RVA: 0xF16410
	public object Remove(object type, object data) { }

	// RVA: 0xF167A8
	public object Remove(object type, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF16890
	public object Remove(object type, object uniq) { }

	// RVA: 0xF16B8C
	public object Clear(object type) { }

	// RVA: 0xF08C88
	public object ClearAll() { }

	// RVA: 0xF16AE0
	public object GetInfo(object type, object uniq) { }

	// RVA: 0xF0E324
	public object GetInfo(object type, object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF16DCC
	public object GetInfo(object type, object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF12628
	public object GetGameOrSnsFriend(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF16E68
	public object IsContain(object type, object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF16F4C
	public object IsContain(object type, object data) { }

	// RVA: 0xF17014
	private object isPlayerInType(object type, object playerUUID, object dwLogicWorldID) { }

	// RVA: 0xF170A4
	public object IsFriend(object playerUUID, object dwLogicWorldID) { }

	// RVA: 0xF14698
	public object GetList(object type) { }

	// RVA: 0xF171D8
	public object GetListByUISys(object type) { }

	// RVA: 0xF15FEC
	public object GetFindFriendList() { }

	// RVA: 0xF172E8
	public object GetAllFriend() { }

	// RVA: 0xF17348
	public object GetAllFriendByUISys() { }

	// RVA: 0xF173A8
	public object GetTempAllFriendByName(object friendName) { }

	// RVA: 0xF174B4
	public object GetTempAllFriend(object filter) { }

	// RVA: 0xF176B8
	private object SortAllFriendList() { }

	// RVA: 0xF17788
	private object DelayRefreshFriendGameState(object seq) { }

	// RVA: 0xF16684
	public object SetDelayRefreshFriendGameState() { }

	// RVA: 0xF17C88
	public object SortGameFriend() { }

	// RVA: 0xF17CF4
	public object SortSNSFriend() { }

	// RVA: 0xF17D60
	public object GetAllFriendsSorted() { }

	// RVA: 0xF16CEC
	private object getFriendInfo(object ullUid, object dwLogicWorldID, object list) { }

	// RVA: 0xF17E44
	public object IsGameFriend(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF17F0C
	public object IsSnsFriend(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF17FD4
	public object getFriendByName(object friendName, object friendType) { }

	// RVA: 0xF15548
	public object getFriendByUidAndLogicWorldID(object uid, object LogicWorldId, object friendType) { }

	// RVA: 0xF18178
	public object SetGameFriendGuildState(object uid, object LogicWorldId, object guildState) { }

	// RVA: 0xF18260
	public object CheckHaveRelationFriend() { }

	// RVA: 0xF182D4
	public object IsIntimacyFriend(object ullUid, object dwLogicWorldId, object friendRelationInfo) { }

	// RVA: 0xF184B4
	public object GetChannelFriendByChannelID(object channelID) { }

	// RVA: 0xF18618
	public object EnableLbs() { }

}

// Namespace: Assets.Scripts.GameSystem
public enum FriendSortType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Online;
	public const object GameState;
	public const object Intimacy;
	public const object ShowGrade;
	public const object PvPLevel;
	public const object VipLevel;
	public const object LoginTime;
	public const object ChannelNickName;
}

// Namespace: Assets.Scripts.GameSystem
public sealed class FriendSortDelegate
{

	// Methods

	// RVA: 0xF19164
	public object .ctor(object object, object method) { }

	// RVA: 0xF19270
	public virtual object Invoke(object x, object y, object skip) { }

	// RVA: 0xF19284
	public virtual object BeginInvoke(object x, object y, object skip, object callback, object object) { }

	// RVA: 0xF19354
	public virtual object EndInvoke(object skip, object result) { }

}

// Namespace: Assets.Scripts.GameSystem
public sealed class MiniFriendSortDelegate
{

	// Methods

	// RVA: 0xF19724
	public object .ctor(object object, object method) { }

	// RVA: 0xF19830
	public virtual object Invoke(object x, object y, object skip) { }

	// RVA: 0xF19844
	public virtual object BeginInvoke(object x, object y, object skip, object callback, object object) { }

	// RVA: 0xF19914
	public virtual object EndInvoke(object skip, object result) { }

}

// Namespace: Assets.Scripts.GameSystem
public interface IFriendComparer
{

	// Properties
	public abstract object type { get; }
	public abstract object skip { get; }

	// Methods

	// RVA: -1
	public abstract object get_type() { }

	// RVA: -1
	public abstract object get_skip() { }

	// RVA: -1
	public abstract object Init() { }

	// RVA: -1
	public abstract object Reset() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendCustomComparer
{

	// Fields
	private object m_SortType; // 0x8
	private object m_Skip; // 0xC
	private object m_Func; // 0x10
	private object m_Mini_Func; // 0x18

	// Properties
	public object type { get; }
	public object skip { get; }

	// Methods

	// RVA: 0xF19980
	public object get_type() { }

	// RVA: 0xF199E0
	public object get_skip() { }

	// RVA: 0xF19A40
	public object .ctor(object type, object func) { }

	// RVA: 0xF19A7C
	public object .ctor(object type, object func) { }

	// RVA: 0xF19AB8
	public virtual object Init() { }

	// RVA: 0xF19B14
	public virtual object Reset() { }

	// RVA: 0xF19B70
	public object Compare(object x, object y) { }

	// RVA: 0xF19C20
	public object Compare(object x, object y) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendComparer
{

	// Fields
	private object m_SortTypes; // 0x8

	// Methods

	// RVA: 0xF19CD0
	public object .ctor() { }

	// RVA: 0xF19D6C
	public object .ctor(object sortTypes) { }

	// RVA: 0xF1A03C
	public object .ctor(object sortTypes) { }

	// RVA: 0xF19E78
	public object AddSortTypes(object enumerator) { }

	// RVA: 0xF1A42C
	public object IndexOf(object sortType) { }

	// RVA: 0xF1A204
	public object AddSortType(object sortType) { }

	// RVA: 0xF1A6D4
	public object AddRange(object sortTypes) { }

	// RVA: 0xF1A160
	public object AddRange(object sortTypes) { }

	// RVA: 0xF1A7C4
	public object Remove(object sortType) { }

	// RVA: 0xF1A864
	public object Clear() { }

	// RVA: 0xF1A8D8
	public override object Compare(object l, object r) { }

}

// Namespace: Assets.Scripts.GameSystem
public static class CFriendSort
{

	// Fields
	public static object DefaultFriendComparer; // 0x0
	public static object FriendComparerWithGrade; // 0x8
	public static object s_comparer; // 0x10
	public static object s_comparers; // 0x18

	// Methods

	// RVA: 0xF1ABA4
	private static object .cctor() { }

	// RVA: 0xF1B0D0
	private static object AddComparer(object comparer) { }

	// RVA: 0xF1A5EC
	public static object GetFriendComparer(object type) { }

	// RVA: 0xF1B334
	public static object FriendDataSort(object list, object sortTypes) { }

	// RVA: 0xF1B4A8
	private static object FriendDataSortByOnline(object l, object r, object skip) { }

	// RVA: 0xF1B598
	private static object FriendDataSortMiniGame(object l, object r, object skip) { }

	// RVA: 0xF1B6F0
	private static object FriendDataSortByGameState(object l, object r, object skip) { }

	// RVA: 0xF1B914
	private static object FriendDataSortByIntimacy(object l, object r, object skip) { }

	// RVA: 0xF1BB30
	private static object FriendDataSortByShowGrade(object l, object r, object skip) { }

	// RVA: 0xF1BC74
	private static object FriendDataSortByPvPLevel(object l, object r, object skip) { }

	// RVA: 0xF1BD1C
	private static object FriendDataSortByVipLevel(object l, object r, object skip) { }

	// RVA: 0xF1BDEC
	private static object FriendDataSortByLoginTime(object l, object r, object skip) { }

	// RVA: 0xF1BE94
	private static object FriendDataSortByChannelNickName(object l, object r, object skip) { }

	// RVA: 0xF1C2C4
	public static object LBSDataSort(object l, object r) { }

}

// Namespace: 
public enum Tab
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Friend_SNS;
	public const object Friend;
	public const object Find_Friends;
	public const object Friend_Request;
	public const object Friend_LBS;
	public const object Friend_Relation;
	public const object Friend_RelationAnni;
	public const object None;
}

// Namespace: 
public class SNSOnlyInviteView
{

	// Fields
	private object form; // 0x8
	private object _snsListScript; // 0x10
	private object _infoNode; // 0x18
	private object _inviteNum; // 0x20
	private object _inviteSlider; // 0x28
	private object _rewards; // 0x30
	private object _iosBg; // 0x38
	private object curTag; // 0x40

	// Methods

	// RVA: 0xF1CD44
	public object Init() { }

	// RVA: 0xF1D874
	private object Clear() { }

	// RVA: 0xF1DB14
	public object RefreshSlider(object value) { }

	// RVA: 0xF1DB78
	public object RefreshPlatform() { }

	// RVA: 0xF1DE5C
	public object RefreshTotalNum() { }

	// RVA: 0xF1E004
	public object RefreshFriend() { }

	// RVA: 0xF1D6A8
	public object Refresh() { }

	// RVA: 0xF1E408
	private object On_Friend_Close_SNSInviteForm(object uiEvent) { }

	// RVA: 0xF1E470
	private object On_SNS_Invite_ItemEnable(object uiEvent) { }

	// RVA: 0xF1EA68
	private object On_Invite_SNS_OnlyFriend(object uiEvent) { }

	// RVA: 0xF1EE14
	private object On_Invite_SNSOnly_Friend_Confirm(object uiEvent) { }

	// RVA: 0xF1F194
	private object On_Get_SNS_Invite_Rewards(object uiEvent) { }

	// RVA: 0xF1C504
	public object .ctor() { }

}

// Namespace: 
public class SNSOnlyShareView
{

	// Fields
	private object m_SNSList; // 0x8
	private object m_InfoNode; // 0x10
	private object m_SendButtonText; // 0x18
	private object m_SendedButtonText; // 0x20
	private object m_ConfirmDescText; // 0x28
	public object Share; // 0x30
	public object Close; // 0x38
	public object Context; // 0x40

	// Methods

	// RVA: 0xF1C604
	public object Init(object title, object send, object sended, object confirm) { }

	// RVA: 0xF1F3C4
	public object Clear() { }

	// RVA: 0xF1F1F8
	public object Refresh() { }

	// RVA: 0xF1F5FC
	public object SetHaveShared(object uid) { }

	// RVA: 0xF1FAFC
	private object On_Friend_Close_SNSOnlyList(object uiEvent) { }

	// RVA: 0xF1FB80
	private object OnSNSShareItemEnable(object uiEvent) { }

	// RVA: 0xF1FE38
	private object OnShareSNSOnlyFriend(object uiEvent) { }

	// RVA: 0xF2037C
	private object OnShareSNSOnlyFriendConfirm(object uiEvent) { }

	// RVA: 0xF200E0
	private object ShareSNSOnlyFriend() { }

	// RVA: 0xF1F804
	private object SetButtonInteractable(object com, object interactable) { }

	// RVA: 0xF1C4FC
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendView
{

	// Fields
	public object snsOnlyShareView; // 0x8
	public object snsOnlyInviteView; // 0x10

	// Methods

	// RVA: 0xF1C458
	public object .ctor() { }

	// RVA: 0xF1C514
	public object OpenSNSOnlyListForm(object share, object close, object context, object title, object send, object sended, object confirm) { }

	// RVA: 0xF1CCD4
	public object On_OpenSNSOnlyInviteForm() { }

}

// Namespace: 
public class Ent
{

	// Fields
	private readonly object <ullUid>k__BackingField; // 0x8
	private readonly object <dwLogicWorldId>k__BackingField; // 0x10
	private object <result>k__BackingField; // 0x14
	private readonly object <inBattleContent>k__BackingField; // 0x18
	private readonly object <name>k__BackingField; // 0x20
	private readonly object <headUrl>k__BackingField; // 0x28
	private object <isRead>k__BackingField; // 0x30

	// Properties
	public object ullUid { get; }
	public object dwLogicWorldId { get; }
	public object result { get; set; }
	public object inBattleContent { get; }
	public object name { get; }
	public object headUrl { get; }
	public object isRead { get; set; }

	// Methods

	// RVA: 0xF22134
	public object get_ullUid() { }

	// RVA: 0xF2213C
	public object get_dwLogicWorldId() { }

	// RVA: 0xF22144
	public object get_result() { }

	// RVA: 0xF2214C
	public object set_result(object value) { }

	// RVA: 0xF22154
	public object get_inBattleContent() { }

	// RVA: 0xF2215C
	public object get_name() { }

	// RVA: 0xF22164
	public object get_headUrl() { }

	// RVA: 0xF2216C
	public object get_isRead() { }

	// RVA: 0xF22174
	public object set_isRead(object value) { }

	// RVA: 0xF21E50
	public object .ctor(object ullUid, object dwLogicWorldId, object result, object inBattleContent, object name, object headUrl) { }

}

// Namespace: Assets.Scripts.GameSystem
public class FriendReserve
{

	// Fields
	public static readonly object ReservedMsg_Content; // 0x0
	public object _hasAcceptOrRejectReverseMsg; // 0x8
	public object dataList; // 0x10
	public object accept_receiveReserve; // 0x18
	public object sendReserve_accepted; // 0x20
	public object accept_ReserveTime; // 0x28
	public object accept_ReserveTeamId; // 0x30
	public object accept_ReserveTeamSeq; // 0x38
	private object <BServerEnableReverse>k__BackingField; // 0x40

	// Properties
	private object Assets.Scripts.GameSystem.IFriendReserve.dataList { get; }
	private object Assets.Scripts.GameSystem.IFriendReserve.accept_receiveReserve { get; }
	private object Assets.Scripts.GameSystem.IFriendReserve.accept_ReserveTime { get; }
	private object Assets.Scripts.GameSystem.IFriendReserve.accept_ReserveTeamId { get; }
	private object Assets.Scripts.GameSystem.IFriendReserve.accept_ReserveTeamSeq { get; }
	public object BServerEnableReverse { get; set; }

	// Methods

	// RVA: 0xF203E4
	private object Assets.Scripts.GameSystem.IFriendReserve.get_dataList() { }

	// RVA: 0xF20444
	private object Assets.Scripts.GameSystem.IFriendReserve.get_accept_receiveReserve() { }

	// RVA: 0xF204A4
	private object Assets.Scripts.GameSystem.IFriendReserve.get_accept_ReserveTime() { }

	// RVA: 0xF20504
	private object Assets.Scripts.GameSystem.IFriendReserve.get_accept_ReserveTeamId() { }

	// RVA: 0xF20564
	private object Assets.Scripts.GameSystem.IFriendReserve.get_accept_ReserveTeamSeq() { }

	// RVA: 0xF205C4
	public object get_BServerEnableReverse() { }

	// RVA: 0xF205CC
	public object set_BServerEnableReverse(object value) { }

	// RVA: 0xF205D4
	public object CheckShowAcceptReceiveReserve() { }

	// RVA: 0xF20A18
	public object CheckShowAcceptReserveInvite(object MemInfoList) { }

	// RVA: 0xF21094
	public object .ctor() { }

	// RVA: 0xF212B0
	public object Clear() { }

	// RVA: 0xF21458
	public object IsReservable(object ullUid, object dwLogicWorldId, object type) { }

	// RVA: 0xF21784
	public object RemoveReceiveReserveData(object ullUid, object dwLogicWorldId, object type) { }

	// RVA: 0xF21AF4
	public object AddReceiveReservieData(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF21EB8
	public object SetData(object ullUid, object dwLogicWorldId, object result, object type) { }

	// RVA: 0xF214F4
	public object Find(object ullUid, object dwLogicWorldId, object type) { }

	// RVA: 0xF21874
	public object GetIndex(object ullUid, object dwLogicWorldId, object type) { }

	// RVA: 0xF220C8
	private static object .cctor() { }

}

// Namespace: 
public enum ItemType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object Normal;
	public const object Request;
	public const object BlackList;
	public const object LBS;
}

// Namespace: Assets.Scripts.GameSystem
public class FriendShower
{

	// Fields
	public object ullUid; // 0x18
	public object dwLogicWorldID; // 0x20
	public object NameText; // 0x28
	public object SNSNameText; // 0x30
	public object LevelText; // 0x38
	public object headIcon; // 0x40
	public object pvpText; // 0x48
	public object pvpIcon; // 0x50
	public object intimacyNode; // 0x58
	public object intimacyBar; // 0x60
	public object intimacyStp; // 0x68
	public object HttpImage; // 0x70
	public object ShareSNSButton; // 0x78
	private readonly object <SNSInviteButton>k__BackingField; // 0x80
	private readonly object <SNSHasInvited>k__BackingField; // 0x88
	private readonly object <head>k__BackingField; // 0x90
	private object intimacyNodeInitPos; // 0x98

	// Properties
	public object SNSInviteButton { get; }
	public object SNSHasInvited { get; }
	public object head { get; }

	// Methods

	// RVA: 0xF2217C
	public object get_SNSInviteButton() { }

	// RVA: 0xF22184
	public object get_SNSHasInvited() { }

	// RVA: 0xF2218C
	public object get_head() { }

	// RVA: 0xF22194
	public object ShowName(object name) { }

	// RVA: 0xF22244
	private object ShowGameName(object name) { }

	// RVA: 0xF2244C
	private object ShowNickNameOrRemark(object name, object show) { }

	// RVA: 0xF228B8
	public object .ctor() { }

}

// Namespace: 
public sealed class OnFriendItemFuncClickedDelegate
{

	// Methods

	// RVA: 0xF24294
	public object .ctor(object object, object method) { }

	// RVA: 0xF243B0
	public virtual object Invoke(object info) { }

	// RVA: 0xF243C4
	public virtual object BeginInvoke(object info, object callback, object object) { }

	// RVA: 0xF24414
	public virtual object EndInvoke(object result) { }

}

// Namespace: Assets.Scripts.GameSystem
public class MyFriendForm
{

	// Fields
	public object ListFriend; // 0x18
	private object <dataList>k__BackingField; // 0x20
	private object <OnItemClick>k__BackingField; // 0x28

	// Properties
	public object dataList { get; set; }
	public object OnItemClick { get; set; }

	// Methods

	// RVA: 0xF22928
	public object get_dataList() { }

	// RVA: 0xF22930
	private object set_dataList(object value) { }

	// RVA: 0xF22938
	public object get_OnItemClick() { }

	// RVA: 0xF22940
	private object set_OnItemClick(object value) { }

	// RVA: 0xF22948
	private object OnGuildInviteFriendListItemEnabled(object uiEvent) { }

	// RVA: 0xF2362C
	private object On_GuildSys_Guild_Invite_Success(object obj) { }

	// RVA: 0xF2374C
	private object OnEnable() { }

	// RVA: 0xF238F4
	private object OnDisable() { }

	// RVA: 0xF23A9C
	public object Init(object fun) { }

	// RVA: 0xF23E54
	private object CanInvite(object info) { }

	// RVA: 0xF23FB4
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class MyFriendFormItem
{

	// Fields
	private object _fun; // 0x18
	private object _info; // 0x20

	// Methods

	// RVA: 0xF22B6C
	internal object InitFriendData(object fun, object info) { }

	// RVA: 0xF24530
	private object OnButtonClicked(object uiEvent) { }

	// RVA: 0xF245B8
	public object .ctor() { }

}

// Namespace: 
public class AddFriendTimeData
{

	// Fields
	public object AddFriendTime; // 0x18

	// Methods

	// RVA: 0xF2483C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendAddFriendTime
{

	// Methods

	// RVA: 0xF245C0
	public object Add(object uniq, object normalTime) { }

	// RVA: 0xF246A4
	public object Get(object uniq) { }

	// RVA: 0xF24728
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF247E4
	public object .ctor() { }

}

// Namespace: 
public class ChampionData
{

	// Fields
	public object ChampionHotData; // 0x18

	// Methods

	// RVA: 0xF24AA8
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendChampionData
{

	// Methods

	// RVA: 0xF24844
	public object Add(object uniq, object stChampionHotData) { }

	// RVA: 0xF24908
	public object GetListCount() { }

	// RVA: 0xF24994
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF24A50
	public object .ctor() { }

}

// Namespace: 
public class ChannelIDData
{

	// Fields
	public object dwChannelID; // 0x14

	// Methods

	// RVA: 0xF24D60
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendChannelIDData
{

	// Methods

	// RVA: 0xF24AB0
	public object Add(object uniq, object channelID) { }

	// RVA: 0xF24B74
	public object Get(object uniq, object channelID) { }

	// RVA: 0xF24C18
	public object Get(object ullUid, object dwLogicWorldID, object channelID) { }

	// RVA: 0xF24D08
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.ctor>b__0_0(object v) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendExtraData<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	protected object AddData(object uniq) { }

	// RVA: -1
	protected object AddData(object ullUid, object dwLogicWorldId) { }

	// RVA: -1
	protected object GetIndex(object uniq) { }

	// RVA: -1
	public object GetData(object uniq) { }

	// RVA: -1
	public object GetData(object ullUid, object dwLogicWorldId) { }

	// RVA: -1
	public object Remove(object uniq) { }

	// RVA: -1
	public object Remove(object ullUid, object dwLogicWorldId) { }

	// RVA: -1
	public object Contains(object ullUid, object dwLogicWorldId) { }

}

// Namespace: Assets.Scripts.GameSystem
public class stBlackName
{

	// Fields
	public object name; // 0x18
	public object bIsOnline; // 0x20
	public object dwLastLoginTime; // 0x24
	public object bGender; // 0x28
	public object szHeadUrl; // 0x30
	public object dwPvpLvl; // 0x38

	// Methods

	// RVA: 0xF24D68
	public object .ctor() { }

	// RVA: 0xF24D70
	public object .ctor(object info) { }

	// RVA: 0xF24E04
	public object .ctor(object info, object bGender, object dwLastLoginTime) { }

}

// Namespace: Assets.Scripts.GameSystem
public class stFriendVerifyContent
{

	// Fields
	public object content; // 0x18
	public object source; // 0x20

	// Properties
	public object dwLogicWorldID { get; }

	// Methods

	// RVA: 0xF24E84
	public object get_dwLogicWorldID() { }

	// RVA: 0xF24EE4
	public object .ctor() { }

	// RVA: 0xF24EEC
	public object .ctor(object ullUid, object dwLogicWorldID, object content, object source) { }

}

// Namespace: 
public class FiveCampELO
{

	// Fields
	public object m_FiveCampELO; // 0x14

	// Methods

	// RVA: 0xF251B8
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendFiveCampELO
{

	// Methods

	// RVA: 0xF24F40
	public object Add(object uniq, object fiveCampELO) { }

	// RVA: 0xF25020
	public object Get(object uniq) { }

	// RVA: 0xF250A4
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF25160
	public object .ctor() { }

}

// Namespace: 
public class HeartData
{

	// Fields
	public object ullLastNormalDonateTime; // 0x18
	public object ullLastSeniorDonateTime; // 0x20

	// Methods

	// RVA: 0xF25BBC
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendHeartData
{

	// Fields
	private object m_RemainSeniorTimes; // 0x20
	private object m_LastSeniorSetTime; // 0x24

	// Properties
	public object SeniorThreshold { get; }
	public object RemainSeniorTimes { get; set; }
	public object RefreshTimeOfDay { get; }

	// Methods

	// RVA: 0xF251C0
	public object get_SeniorThreshold() { }

	// RVA: 0xF25278
	public object get_RemainSeniorTimes() { }

	// RVA: 0xF25638
	public object set_RemainSeniorTimes(object value) { }

	// RVA: 0xF256F0
	public object get_RefreshTimeOfDay() { }

	// RVA: 0xF257BC
	public object Add(object uniq, object normalDonateTime, object seniorDonateTime) { }

	// RVA: 0xF25904
	public object Add(object uniq, object donateTime, object senior) { }

	// RVA: 0xF25A70
	public object IsInCd(object uniq, object normalInCd, object seniorInCd) { }

	// RVA: 0xF25324
	private object IsInCd(object lastTime) { }

	// RVA: 0xF25B64
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class FriendInGame
{

	// Fields
	public object State; // 0x14
	public object dwStartGameTime; // 0x18
	public object lastStartGameTime; // 0x1C
	public object teamId; // 0x20
	public object teamSeq; // 0x24
	public object gameSubState; // 0x28
	public object isAsianGameWhite; // 0x2C
	public object gameInfo; // 0x30
	public object bVideoState; // 0x38
	public object allowDirectJoinFriendGameType; // 0x3C
	public object bMaptype; // 0x40
	public object dwMapId; // 0x44

	// Properties
	public object dwLogicWorldID { get; }

	// Methods

	// RVA: 0xF25BC4
	public object get_dwLogicWorldID() { }

	// RVA: 0xF25C24
	public object .ctor() { }

	// RVA: 0xF25C2C
	public object Init(object state, object startTime, object subState, object bIsInAsianGamesWhiteList, object info, object videoState, object allowDirectJoinFriendType, object teamStateInfo, object maptype, object mapId) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendInGameData
{

	// Methods

	// RVA: 0xF25E50
	public object Add(object uniq) { }

	// RVA: 0xF25EF4
	public object Add(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF25FA4
	public object IsFriendInGamingState(object ullUid, object dwLogicWorldID, object State) { }

	// RVA: 0xF2603C
	public object GetFriendInGamingState(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF260F8
	public object GetFriendInGamingSubState(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF261B4
	public object GetFriendInGamingTeamId(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF26270
	public object GetFriendInGamingTeamSeq(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF2632C
	public object GetFriendInGameMapType(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF263E8
	public object GetFriendInGameMapID(object ullUid, object dwLogicWorldID) { }

	// RVA: 0xF264A4
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class IntimacyUpInfo
{

	// Fields
	public object username; // 0x18
	public object delta; // 0x20
	public object deltaLv; // 0x24

	// Properties
	public object dwLogicWorldID { get; }

	// Methods

	// RVA: 0xF264FC
	public object get_dwLogicWorldID() { }

	// RVA: 0xF2655C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendRelationInfo
{

	// Fields
	public object IntimacyData; // 0x8
	private object <FriendInfo>k__BackingField; // 0x10
	private object <IsRecommend>k__BackingField; // 0x18

	// Properties
	public object FriendInfo { get; set; }
	public object wIntimacyValue { get; }
	public object IntimacyShowPrio { get; }
	public object IsRecommend { get; set; }

	// Methods

	// RVA: 0xF26564
	public object .ctor() { }

	// RVA: 0xF2660C
	public object get_FriendInfo() { }

	// RVA: 0xF26614
	public object set_FriendInfo(object value) { }

	// RVA: 0xF2661C
	public object get_wIntimacyValue() { }

	// RVA: 0xF26710
	public object get_IntimacyShowPrio() { }

	// RVA: 0xF26784
	public object get_IsRecommend() { }

	// RVA: 0xF2678C
	public object set_IsRecommend(object value) { }

	// RVA: 0xF26794
	public object Equals(object other) { }

	// RVA: 0xF26984
	public override object Equals(object obj) { }

	// RVA: 0xF26BCC
	public object <>iFixBaseProxy_Equals(object P0) { }

}

// Namespace: 
public class IntimacyData
{

	// Fields
	public object dwLastIntimacyTime; // 0x14
	public object wDayIntimacyValue; // 0x18
	public object isTodayFull; // 0x1A
	public object isFull; // 0x1B
	public object dwBuildIntimacyRelationTime; // 0x1C
	public object bIntimacyState; // 0x20
	public object dwTerminateTime; // 0x24
	public object IntimacyShowPrio; // 0x28
	public object IntimacyLevel; // 0x2C
	private object mIntimacyValue; // 0x30
	public object iIntimacyTitleId; // 0x34
	public object iIntimacyStateUpd; // 0x38

	// Properties
	public object wIntimacyValue { get; set; }

	// Methods

	// RVA: 0xF26604
	public object .ctor() { }

	// RVA: 0xF266B0
	public object get_wIntimacyValue() { }

	// RVA: 0xF27A7C
	public object set_wIntimacyValue(object value) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendIntimacyData
{

	// Fields
	private object relationShowPriority; // 0x20
	public object RecommendFriends; // 0x28
	private object _isRecommendCount; // 0x30
	private object _flagSet; // 0x38

	// Properties
	public object IntimacyFull { get; }
	public object TodayIntimacyFull { get; }
	public object FreezeTime { get; }
	public object RefreshTimeOfDay { get; }
	public object RelationShowPriority { get; set; }

	// Methods

	// RVA: 0xF26BD4
	public object get_IntimacyFull() { }

	// RVA: 0xF26C84
	public object get_TodayIntimacyFull() { }

	// RVA: 0xF26D34
	public object get_FreezeTime() { }

	// RVA: 0xF1BA44
	public object GetValue(object uniq) { }

	// RVA: 0xF26E1C
	public object GetValue(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF26F14
	public object GetState(object uniq) { }

	// RVA: 0xF26FC4
	public object GetState(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF27080
	public object GetTodayValue(object uniq) { }

	// RVA: 0xF27178
	public object IsNeedReset(object lastTime) { }

	// RVA: 0xF27344
	public object get_RefreshTimeOfDay() { }

	// RVA: 0xF27410
	public object GetMax() { }

	// RVA: 0xF275AC
	public object IsFreeze(object uniq) { }

	// RVA: 0xF276A0
	public object IsTodayFull(object uniq) { }

	// RVA: 0xF277E0
	public object IsFull(object uniq) { }

	// RVA: 0xF278AC
	public object Add(object uniq, object IntimacyData, object isTodayFull, object isFull) { }

	// RVA: 0xF27E44
	public object get_RelationShowPriority() { }

	// RVA: 0xF27EA4
	public object set_RelationShowPriority(object value) { }

	// RVA: 0xF27F0C
	public object GetCanCreateRelationFriendList() { }

	// RVA: 0xF28294
	public object GetCanRemoveRelationFriendList() { }

	// RVA: 0xF28578
	public object GetIntimacyInfoByState(object state) { }

	// RVA: 0xF288CC
	public object GetAllRelationFriendList(object needSort) { }

	// RVA: 0xF28C0C
	public object CheckHaveRelationFriend() { }

	// RVA: 0xF28D6C
	public static object SortCFriendRelationInfo(object left, object right) { }

	// RVA: 0xF27DD4
	public object HaveRelationState(object state) { }

	// RVA: 0xF29108
	public object IsInRelationReqState(object state) { }

	// RVA: 0xF29178
	public object SetIntimacyData(object ullUid, object dwLogicWorldId, object initimacyState, object terminateTime, object buildRelationTime, object ShowPrio, object IntimacyValue, object iIntimacyTitleId, object iIntimacyStateUpd) { }

	// RVA: 0xF29294
	public object GetOriginCanCreateRelationFriendList() { }

	// RVA: 0xF295E0
	public static object SortCFriendRelationInfoWithRecommends(object left, object right) { }

	// RVA: 0xF29AC0
	public object SetRecommendFlag(object info) { }

	// RVA: 0xF29BBC
	private object ResetRecommendFlags(object infos) { }

	// RVA: 0xF2A194
	public object GetCanCreateRelationFriendListByRecommends() { }

	// RVA: 0xF2A2A4
	public object .ctor() { }

	// RVA: 0xF2A390
	private object <ResetRecommendFlags>b__39_0(object cFriendRelationInfo) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__1_0; // 0x8

	// Methods

	// RVA: 0xF2ABEC
	private static object .cctor() { }

	// RVA: 0xF2AC4C
	public object .ctor() { }

	// RVA: 0xF2AC54
	internal object <.ctor>b__1_0(object v) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendListData
{

	// Fields
	private object m_OnlineCount; // 0x20

	// Methods

	// RVA: 0xF2A484
	public object .ctor() { }

	// RVA: 0xF2A5A4
	public object IsFriendOnline(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2A668
	public object GetOnlineCount() { }

	// RVA: 0xF2A6C8
	protected override object OnBeforeUpdateIndex() { }

	// RVA: 0xF2A728
	protected override object OnUpdateIndex(object i, object key, object value) { }

	// RVA: 0xF2A7E4
	public object SortWith(object sortTypes) { }

	// RVA: 0xF2A9AC
	public object SortWith(object sortTypes) { }

	// RVA: 0xF2AB08
	public static object op_Implicit(object v) { }

	// RVA: 0xF2AB8C
	public object <>iFixBaseProxy_OnBeforeUpdateIndex() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__2_0; // 0x8

	// Methods

	// RVA: 0xF2AEDC
	private static object .cctor() { }

	// RVA: 0xF2AF3C
	public object .ctor() { }

	// RVA: 0xF2AF44
	internal object <.ctor>b__2_0(object v) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CSearchFriendListData
{

	// Fields
	public object search_info; // 0x20
	public object search_userPrivacyBits; // 0x28

	// Methods

	// RVA: 0xF2AC94
	public object .ctor() { }

	// RVA: 0xF2ADB4
	public override object Clear() { }

	// RVA: 0xF2AE48
	public object <>iFixBaseProxy_Clear() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8

	// Methods

	// RVA: 0xF2B0A4
	private static object .cctor() { }

	// RVA: 0xF2B104
	public object .ctor() { }

	// RVA: 0xF2B10C
	internal object <.ctor>b__0_0(object v) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLBSFriendListData
{

	// Methods

	// RVA: 0xF2AF84
	public object .ctor() { }

}

// Namespace: 
public class MoTogameData
{

	// Fields
	public object m_MoToGameInfo; // 0x18

	// Methods

	// RVA: 0xF2B448
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendMoTogameData
{

	// Methods

	// RVA: 0xF2B160
	public object Get(object uniq) { }

	// RVA: 0xF2B2A0
	public object GetListCount() { }

	// RVA: 0xF2B1E4
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2B32C
	public object Add(object uniq, object MoToGameInfo) { }

	// RVA: 0xF2B3F0
	public object .ctor() { }

}

// Namespace: 
public class MusicParkourData
{

	// Fields
	public object m_MusicParkourData; // 0x18

	// Methods

	// RVA: 0xF2B738
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendMusicParkourData
{

	// Methods

	// RVA: 0xF2B450
	public object Get(object uniq) { }

	// RVA: 0xF2B590
	public object GetListCount() { }

	// RVA: 0xF2B4D4
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2B61C
	public object Add(object uniq, object ParkourBatchInfo) { }

	// RVA: 0xF2B6E0
	public object .ctor() { }

}

// Namespace: 
public class NicknameData
{

	// Fields
	public object szNickname; // 0x18

	// Methods

	// RVA: 0xF2BB6C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendNicknameData
{

	// Methods

	// RVA: 0xF18D44
	public object Get(object uniq) { }

	// RVA: 0xF2B740
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2B824
	public object Append(object name, object uniq) { }

	// RVA: 0xF2B8C4
	public object Append(object name, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2B9FC
	public object Add(object uniq, object szNickname) { }

	// RVA: 0xF2BB14
	public object .ctor() { }

}

// Namespace: 
public class ReCallData
{

	// Fields
	public object szPlatformId; // 0x18
	public object bLost; // 0x20
	public object ullLastRecallTime; // 0x28

	// Methods

	// RVA: 0xF2C17C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendReCallData
{

	// Properties
	private static object RecallCD { get; }

	// Methods

	// RVA: 0xF2BB74
	private static object get_RecallCD() { }

	// RVA: 0xF2BC1C
	public object Add(object uniq, object lastRecallTime) { }

	// RVA: 0xF2BCE0
	public object Add(object uniq, object lost) { }

	// RVA: 0xF2BDA4
	public object Add(object uniq, object platformId, object lost, object lastRecallTime) { }

	// RVA: 0xF2BE90
	public object IsLost(object uniq) { }

	// RVA: 0xF2BF5C
	public object IsInCd(object uniq) { }

	// RVA: 0xF2C04C
	public object GetPlatformId(object uniq) { }

	// RVA: 0xF2C124
	public object .ctor() { }

}

// Namespace: 
public class FriendRemarkData
{

	// Fields
	public object szRemark; // 0x18

	// Methods

	// RVA: 0xF2C660
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendRemarkData
{

	// Methods

	// RVA: 0xF2C184
	public object Get(object uniq) { }

	// RVA: 0xF2C240
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2C324
	public object Append(object name, object uniq) { }

	// RVA: 0xF2C3C4
	public object Append(object name, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2C4FC
	public object Add(object uniq, object szRemark) { }

	// RVA: 0xF2C608
	public object .ctor() { }

}

// Namespace: 
public class SnsChannelNickNameData
{

	// Fields
	public object m_SnsChannelNickNameData; // 0x18

	// Methods

	// RVA: 0xF2C8CC
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendSNSChannelNickNameData
{

	// Methods

	// RVA: 0xF1C180
	public object Get(object uniq) { }

	// RVA: 0xF2C724
	public object GetListCount() { }

	// RVA: 0xF2C668
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2C7B0
	public object Add(object uniq, object ChannelNickNameData) { }

	// RVA: 0xF2C874
	public object .ctor() { }

}

// Namespace: 
public class TeamStateData
{

	// Fields
	public object stTeamStateInfo; // 0x18

	// Methods

	// RVA: 0xF2CBBC
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendTeamStateData
{

	// Methods

	// RVA: 0xF2C8D4
	public object Get(object uniq) { }

	// RVA: 0xF2CA14
	public object GetListCount() { }

	// RVA: 0xF2C958
	public object Get(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF2CAA0
	public object Add(object uniq, object TeamStateInfo) { }

	// RVA: 0xF2CB64
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class UT
{

	// Methods

	// RVA: 0xF1C204
	public static object Bytes2String(object bytes) { }

	// RVA: 0xF2CBC4
	public static object Bytes2String(object str) { }

	// RVA: 0xF2CC24
	public static object String2Bytes(object name) { }

	// RVA: 0xF2CCC8
	public static object GetTimeString(object time) { }

	// RVA: 0xF2D1E4
	public static object CalcDeltaHorus(object fromT, object toT) { }

	// RVA: 0xF2D39C
	public static object SetChatFace(object formScript, object img, object index) { }

	// RVA: 0xF2D48C
	public static object Check_AddHeartCD(object uniq, object senior) { }

	// RVA: 0xF2D5A0
	public static object Check_AddReCallCD(object uniq) { }

	// RVA: 0xF2D69C
	public static object SetImage(object img, object bGray) { }

	// RVA: 0xF2D7E0
	public static object ResetTimer(object timer, object bPause) { }

	// RVA: 0xF2D8F4
	public static object GetText(object key) { }

	// RVA: 0xF2D128
	public static object GetMeasureText(object key, object args) { }

	// RVA: 0xF2D998
	public static object SetHttpImage(object HttpImage, object szHeadUrl) { }

	// RVA: 0xF2DA6C
	public static object SetHttpImage(object HttpImage, object url, object loadFX) { }

	// RVA: 0xF2DC4C
	public static object SetHeadFrame(object frame, object headImgId, object form) { }

	// RVA: 0xF2DD78
	public static object SetHead(object head, object url, object headImgId, object headPendant) { }

	// RVA: 0xF1E79C
	public static object ShowSNSOnlyFriendData(object info, object com) { }

	// RVA: 0xF2DF04
	public static object SetTabList(object titles, object start_index, object tablistScript) { }

	// RVA: 0xF2E208
	public static object ShowRank(object HisRankGo, object RankGrade, object RankClass, object RankScore, object titleInfo) { }

	// RVA: 0xF2E5D0
	public static object ShowRank(object HisRankGo, object RankGrade, object RankClass, object RankScore) { }

	// RVA: 0xF2E650
	public static object ShowSend(object uniq, object normalGo, object normalBtn, object normalEvent, object seniorGo, object seniorBtn, object seniorEvent) { }

	// RVA: 0xF2EA48
	public static object GetFriendInGamingTimeString(object starttime, object showInHead) { }

	// RVA: 0xF2ED80
	public static object ShowGender(object genderImage, object genderType) { }

	// RVA: 0xF2F0B4
	public static object PlayerNameOrRemarkOrNicky(object uniq, object format) { }

	// RVA: 0xF2F27C
	public static object PlayerNameOrRemarkOrNicky(object ullUid, object dwLogicWorldId, object format) { }

	// RVA: 0xF2F1F0
	public static object PlayerNameOrRemarkOrNicky(object name, object uniq, object format) { }

	// RVA: 0xF2F480
	public static object PlayerNameOrRemarkOrNicky(object name, object ullUid, object dwLogicWorldId, object format) { }

	// RVA: 0xF2F350
	public static object MixtureNameFormat(object name, object remarkOrNicky, object format) { }

	// RVA: 0xF2F5B8
	public static object PlayerNickyOrRemarkName(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF24420
	public static object PlayerNickyOrRemarkName(object uniq) { }

	// RVA: 0xF2F680
	public object .ctor() { }

}

// Namespace: 
public class WinRateData
{

	// Fields
	public object dwTotalMatchCnt; // 0x14
	public object dwWinMatchCnt; // 0x18

	// Methods

	// RVA: 0xF2FA48
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CFriendWinRateData
{

	// Methods

	// RVA: 0xF2F688
	public object Add(object uniq, object totalMatchCnt, object winMatchCnt) { }

	// RVA: 0xF2F760
	public object Get(object uniq, object totalMatchCnt, object winMatchCnt, object winRate) { }

	// RVA: 0xF2F868
	public object Get(object ullUid, object dwLogicWorldID, object totalMatchCnt, object winMatchCnt, object winRate) { }

	// RVA: 0xF2F9F0
	public object .ctor() { }

}

// Namespace: 
public class FriendReservationMsg
{

	// Fields
	public object ullUid; // 0x8
	public object dwLogicWorldId; // 0x10
	public object bResult; // 0x14
	public object playerName; // 0x18
	public object headUrl; // 0x20

	// Methods

	// RVA: 0xD67EB0
	public object .ctor() { }

}

// Namespace: 
private enum EnTPNSPushFriendOnlineType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IntimacyFriend;
	public const object BackFlowFriend;
}

// Namespace: 
public enum EN_TPNSScene
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object EN_None;
	public const object EN_FiendOnline;
	public const object EN_OfflineInviteNonSnsFriend;
}

// Namespace: Assets.Scripts.GameSystem
public class FriendSysNetCore
{

	// Fields
	private static object UnNeedOpenReserveBoxForms; // 0x0
	public static object FriendReservationMsgs; // 0x8
	private static object m_bHaveGetFrinedList; // 0x10
	private static object m_bHaveGetSnSFrinedList; // 0x11
	private static object intimacyCount; // 0x14
	private static object backFlowCount; // 0x18

	// Methods

	// RVA: 0xF2FA50
	public static object Send_Upload_Sns_InGameFriend(object friendNum, object openidList) { }

	// RVA: 0xF2FBC4
	public static object Send_Upload_Sns_InGameFriend(object wealID) { }

	// RVA: 0xF2FCF0
	public static object Send_Sns_Invite_Friend(object InvitedKakaoID, object wealID) { }

	// RVA: 0xF2FEC0
	public static object On_Sns_Invite_Friend(object msg) { }

	// RVA: 0xF30348
	public static object On_Sns_Have_Invited_List(object msg) { }

	// RVA: 0xF30634
	public static object On_Sns_Invite_Num_NTF(object msg) { }

	// RVA: 0xF30844
	public static object Send_Request_Sns_Switch(object type, object tag) { }

	// RVA: 0xF309B8
	public static object On_SC_Friend_Info(object msg) { }

	// RVA: 0xF31E4C
	public static object Send_Request_RecommandFriend_List() { }

	// RVA: 0xF31F30
	public static object Send_Request_FindFriend_List(object searchType, object pageIndex, object rankGrade, object heroType, object placeID, object day, object hour) { }

	// RVA: 0xF3220C
	public static object Send_Requeset_MyPendingFriend() { }

	// RVA: 0xF322F0
	public static object On_SC_Friend_Request_Info(object msg) { }

	// RVA: 0xF32638
	public static object On_Send_FriendCoin(object msg) { }

	// RVA: 0xF32BF0
	public static object Send_FriendCoin(object uniq, object friendType) { }

	// RVA: 0xF25554
	public static object RequestRefreshFreindInfo() { }

	// RVA: 0xF32DD4
	public static object OnRefreshFreindInfoResponse(object rsp) { }

	// RVA: 0xF32F24
	public static object Send_Serch_Player(object name) { }

	// RVA: 0xF330AC
	public static object Send_Request_BeFriend(object uniq, object veriyText, object addChannel) { }

	// RVA: 0xF33184
	public static object Send_Request_BeFriend(object ullUid, object dwLogicWorldId, object veriyText, object enAddChannel) { }

	// RVA: 0xF33628
	public static object On_SC_BeFriend(object msg) { }

	// RVA: 0xF33A7C
	public static object On_SC_FakeBeFriend(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF33C4C
	public static object Send_Confrim_BeFriend(object uniq) { }

	// RVA: 0xF33E7C
	public static object On_SC_Confrim_BeFriend(object msg) { }

	// RVA: 0xF345B4
	public static object Send_DENY_BeFriend(object uniq) { }

	// RVA: 0xF34818
	public static object On_SC_DENY_BeFriend(object msg) { }

	// RVA: 0xF34A94
	public static object On_SC_Friend_RequestInfo(object msg) { }

	// RVA: 0xF34E44
	public static object On_SC_Friend_Recommand_Info(object msg) { }

	// RVA: 0xF35040
	public static object On_SC_NTF_FRIEND_ADD(object msg) { }

	// RVA: 0xF354B8
	public static object On_SCID_CMD_NTF_FRIEND_GAME_STATE(object msg) { }

	// RVA: 0xF356EC
	public static object OnSCID_CMD_NTF_FRIEND_LOGIN_STATUS(object msg) { }

	// RVA: 0xF359F0
	public static object AddPvpHistoryCachedFriendSearchResult(object table) { }

	// RVA: 0xF36368
	public static object On_SC_Serch_Player(object msg) { }

	// RVA: 0xF36818
	public static object On_SCID_NTF_SNS_FRIEND(object msg) { }

	// RVA: 0xF368C0
	public static object SetSnsFriendList(object msg) { }

	// RVA: 0xF379D0
	public static object On_SCID_UPLOAD_MULTI_SNS_PLATFORM_INFO_RSP(object msg) { }

	// RVA: 0xF37C68
	public static object On_SCID_SNS_FRIEND_CHG_PROFILE(object msg) { }

	// RVA: 0xF37E2C
	public static object Send_Del_Friend(object uniq) { }

	// RVA: 0xF37FCC
	public static object On_SC_Del_Friend(object msg) { }

	// RVA: 0xF38198
	public static object Send_Invite_Friend_Game(object bReserve) { }

	// RVA: 0xF382C4
	public static object On_SC_Invite_Friend_Game(object msg) { }

	// RVA: 0xF38364
	public static object On_SC_NTF_FRIEND_DEL(object msg) { }

	// RVA: 0xF38460
	public static object On_SC_NTF_FRIEND_REQUEST(object msg) { }

	// RVA: 0xF3875C
	public static object ReCallSnsFriend(object uniq, object friendType) { }

	// RVA: 0xF38940
	public static object On_SCID_SNS_FRIEND_RECALLPOINT(object msg) { }

	// RVA: 0xF389E0
	public static object On_SCID_SNS_FRIEND_RECALL_NTF(object msg) { }

	// RVA: 0xF38BD4
	public static object RequestRecallReward(object uniq) { }

	// RVA: 0xF38D00
	public static object OnRecallRewardResponse(object msg) { }

	// RVA: 0xF39048
	public static object On_Sns_Switch_Rep(object msg) { }

	// RVA: 0xF39138
	public static object On_Sns_Switch_Ntf(object msg) { }

	// RVA: 0xF392B0
	public static object On_SCPKG_CMD_NTF_CHG_INTIMACY(object msg) { }

	// RVA: 0xF39A94
	public static object On_SCPKG_CMD_BLACKLIST(object msg) { }

	// RVA: 0xF39BEC
	public static object Send_Block(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF39E30
	public static object On_SCPKG_CMD_DEFRIEND(object msg) { }

	// RVA: 0xF3A2D0
	public static object Send_Cancle_Block(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF3A510
	public static object On_SCPKG_CMD_CANCEL_DEFRIEND(object msg) { }

	// RVA: 0xF3A6E8
	public static object Send_Report_Clt_Location(object longitude, object latitude) { }

	// RVA: 0xF3A8F8
	public static object Send_Search_LBS_Req(object gender, object longitude, object latitude, object isShowAlert) { }

	// RVA: 0xF3AB70
	public static object On_SC_Search_LBS_Rsp(object msg) { }

	// RVA: 0xF3AF64
	public static object Send_Clear_Location() { }

	// RVA: 0xF3B0A8
	public static object SendReserveAcntReq(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF3B308
	public static object OnReserveAcntRsp(object msg) { }

	// RVA: 0xF3B780
	public static object OnReserveAcntNtf(object msg) { }

	// RVA: 0xF3B904
	public static object SendReserveOperReq(object operType, object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF3BDC4
	public static object OnReserveOperRsp(object msg) { }

	// RVA: 0xF3BF70
	public static object OnReserveOperNtf(object msg) { }

	// RVA: 0xF3C74C
	private static object NeedOpenReserveBox() { }

	// RVA: 0xF3CA2C
	public static object OnFriendMatchUpdate(object msg) { }

	// RVA: 0xF3CB38
	public static object SendInviteSNSFriendReport(object type, object subType, object result) { }

	// RVA: 0xF3CE18
	public static object ResetGetFrinedInfoState() { }

	// RVA: 0xF3CEC4
	public static object CheckFrinedInfoState() { }

	// RVA: 0xF3D0DC
	public static object Send_MatchBlack(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF3D320
	public static object On_SCPKG_ADD_MATCH_BLACKLIST_RSP(object msg) { }

	// RVA: 0xF3D7B8
	public static object Send_Cancel_MatchBlack(object ullUid, object dwLogicWorldId) { }

	// RVA: 0xF3D954
	public static object On_SCPKG_DEL_MATCH_BLACKLIST_RSP(object msg) { }

	// RVA: 0xF3D634
	public static object Send_MatchBlackList() { }

	// RVA: 0xF3DB5C
	public static object On_SCPKG_MATCH_BLACKLIST_GET_RSP(object msg) { }

	// RVA: 0xF3DCEC
	public static object ResGetIntimacyShowDetailInfo(object msg) { }

	// RVA: 0xF3DE0C
	public static object SendFriendsState() { }

	// RVA: 0xF311BC
	private static object SolveFriendFirebasePush(object friendInfo, object intimacyBuilder, object isSelfReturnPlayer, object backFlowBuilder) { }

	// RVA: 0xF3DF50
	private static object IsIntimateFriend(object friendInfo) { }

	// RVA: 0xF319D8
	private static object SendFriendOnlineData(object data) { }

	// RVA: 0xF3DFE0
	public object .ctor() { }

	// RVA: 0xF3DFE8
	private static object .cctor() { }

}

// Namespace: 
private sealed class <StartGPS>d__10
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <msgOpened>5__2; // 0x20
	private object <maxWait>5__3; // 0x24

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xD682C8
	public object .ctor(object <>1__state) { }

	// RVA: 0xD68458
	private object System.IDisposable.Dispose() { }

	// RVA: 0xD6845C
	private object MoveNext() { }

	// RVA: 0xD68C70
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xD68C78
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xD68CB8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class GPSSys
{

	// Fields
	private object bRunning; // 0x18
	private object mCoroutine; // 0x20
	private object mCallback; // 0x28

	// Properties
	public object bHide { get; }
	public object iLng { get; }
	public object iLat { get; }

	// Methods

	// RVA: 0xD67EB8
	public object get_bHide() { }

	// RVA: 0xD67F70
	public object get_iLng() { }

	// RVA: 0xD68038
	public object get_iLat() { }

	// RVA: 0xD68100
	public object GetPosition(object callback, object needGotoSettings) { }

	// RVA: 0xD68210
	public object StartGPS(object needGotoSettings) { }

	// RVA: 0xD682F4
	public object StopGPS() { }

	// RVA: 0xD68400
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CGuildSystem
{

	// Fields
	public object dropItemData; // 0x8

	// Methods

	// RVA: 0xD68CC0
	public object GetGuildWeekAwardNestGift(object randomCfg, object propCfg, object usable) { }

	// RVA: 0xD68F4C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CLanChangeSys
{

	// Fields
	public static object LANCHANGE_FORM; // 0x0

	// Methods

	// RVA: 0xD68FE8
	public override object Init() { }

	// RVA: 0xD6915C
	public override object UnInit() { }

	// RVA: 0xD692D0
	private object OnOpenFoem(object uiEvent) { }

	// RVA: 0xD69448
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished(object id) { }

	// RVA: 0xD69AF0
	private object ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart(object id) { }

	// RVA: 0xD69B54
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled(object id) { }

	// RVA: 0xD69BB8
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadError(object id, object error) { }

	// RVA: 0xD69C30
	private object ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished(object id, object filepath, object dlcItemFinished) { }

	// RVA: 0xD69CB0
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0xD69E58
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0xD69EBC
	private object ResCore.DLC.DLCDownloaderDelegate.OnDownloadPause(object pause) { }

	// RVA: 0xD69F20
	public object .ctor() { }

	// RVA: 0xD69F78
	private static object .cctor() { }

	// RVA: 0xD69FE4
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xD69FE8
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportData
{

	// Fields
	private object mIsReaded; // 0x8
	private object mReportEndTime; // 0x10
	public object mBaseData; // 0x18
	public object mThemeType; // 0x20
	private object mThemeData; // 0x28

	// Properties
	public object IsReaded { get; }
	public object ReportEndTimeString { get; }
	public object ReportStartTimeString { get; }
	public object ReportTimeString { get; }
	public object LadderGameCnt { get; }
	public object StarChangeCnt { get; }
	public object GrowHeroList { get; }
	public object AscendData { get; }
	public object AdversityData { get; }
	public object SlaughterData { get; }
	public object PracticeData { get; }
	public object StableData { get; }
	public object LeisureData { get; }
	public object ReportThemeNameString { get; }

	// Methods

	// RVA: 0xD69FEC
	public object get_IsReaded() { }

	// RVA: 0xD6A04C
	public object get_ReportEndTimeString() { }

	// RVA: 0xD6A11C
	public object get_ReportStartTimeString() { }

	// RVA: 0xD6A1F0
	public object get_ReportTimeString() { }

	// RVA: 0xD6A324
	public object get_LadderGameCnt() { }

	// RVA: 0xD6A39C
	public object get_StarChangeCnt() { }

	// RVA: 0xD6A414
	public object get_GrowHeroList() { }

	// RVA: -1
	public object GetThemeData() { }

	// RVA: 0xD6A48C
	public object get_AscendData() { }

	// RVA: 0xD6A518
	public object get_AdversityData() { }

	// RVA: 0xD6A5A4
	public object get_SlaughterData() { }

	// RVA: 0xD6A630
	public object get_PracticeData() { }

	// RVA: 0xD6A6BC
	public object get_StableData() { }

	// RVA: 0xD6A748
	public object get_LeisureData() { }

	// RVA: 0xD6A7D4
	public object get_ReportThemeNameString() { }

	// RVA: 0xD6A8E8
	public object Clear() { }

	// RVA: 0xD6AA68
	public object ConverSvrData2CliData(object svrData) { }

	// RVA: 0xD6AC54
	public static object CreateThemeDataFactory(object svrData, object themeType) { }

	// RVA: 0xD6B354
	public static object ConverSvrHeroData2CliHeroData(object heroCnt, object svrData) { }

	// RVA: 0xD6B5D0
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportSlaughterData
{

	// Fields
	public object mKillCnt; // 0x8
	public object mAssistCnt; // 0xC

	// Methods

	// RVA: 0xD6B5E4
	public object .ctor(object svrData) { }

	// RVA: 0xD6B61C
	public object Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportWonderfulGameData
{

	// Fields
	public object mKillCnt; // 0x8
	public object mDeadCnt; // 0xC
	public object mAssistCnt; // 0x10
	public object mMVPScore; // 0x14
	public object mHeroID; // 0x18

	// Properties
	public object MVPScoreString { get; }
	public object IsValid { get; }

	// Methods

	// RVA: 0xD6B67C
	public object get_MVPScoreString() { }

	// RVA: 0xD6B730
	public object get_IsValid() { }

	// RVA: 0xD6B798
	public object .ctor(object svrData) { }

	// RVA: 0xD6B7E4
	public object Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportFriendData
{

	// Fields
	public object mUid; // 0x8
	public object mLogicWorldID; // 0x10
	public object mName; // 0x18
	public object mHeadImgUrl; // 0x20
	public object mGameCnt; // 0x28
	public object mNetWinCnt; // 0x2C
	public object mMVPScoreAVG; // 0x30

	// Properties
	public object WinRate { get; }
	public object LostCnt { get; }
	public object MVPScoreAVGString { get; }
	public object IsValid { get; }

	// Methods

	// RVA: 0xD6B844
	public object get_WinRate() { }

	// RVA: 0xD6B97C
	public object get_LostCnt() { }

	// RVA: 0xD6B9E0
	public object get_MVPScoreAVGString() { }

	// RVA: 0xD6BA94
	public object get_IsValid() { }

	// RVA: 0xD6BB14
	public object .ctor(object svrData) { }

	// RVA: 0xD6BB44
	public object ConverSvrData2CliData(object svrData) { }

	// RVA: 0xD6BCD0
	public object Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportThemeBaseData
{

	// Fields
	private object mThemeType; // 0x8

	// Methods

	// RVA: 0xD6BD74
	public virtual object Clear() { }

	// RVA: 0xD6BDD8
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportLeisureThemeData
{

	// Fields
	public object mWonderfulGameData; // 0x10
	public object mBestPerfFriendData; // 0x18
	public object mSlaughterData; // 0x20

	// Methods

	// RVA: 0xD6B078
	public object .ctor(object svrData) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportStableThemeData
{

	// Methods

	// RVA: 0xD6BDE0
	public override object Clear() { }

	// RVA: 0xD6B198
	public object .ctor(object svrData) { }

	// RVA: 0xD6BFD0
	public object <>iFixBaseProxy_Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportParcticeThemeData
{

	// Fields
	public object mMostProficientHeroID; // 0xC
	public object mProficiencyLevel; // 0x10
	public object mLoseGameCnt; // 0x14
	public object mWinGameCnt; // 0x18
	public object mBestPerfFriendData; // 0x20

	// Properties
	public object WinRate { get; }
	public object GameCnt { get; }

	// Methods

	// RVA: 0xD6BFD4
	public object get_WinRate() { }

	// RVA: 0xD6C180
	public object get_GameCnt() { }

	// RVA: 0xD6B2C0
	public object .ctor(object svrData) { }

	// RVA: 0xD6C1E4
	public override object Clear() { }

	// RVA: 0xD6C30C
	public object <>iFixBaseProxy_Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportSlaughterThemeData
{

	// Fields
	public object mSlaughterData; // 0x10
	public object mKillHeroMostHeroID; // 0x18
	public object mTotalKillHeroCnt; // 0x1C
	public object mBestPerfFriendData; // 0x20

	// Methods

	// RVA: 0xD6B1C8
	public object .ctor(object svrData) { }

	// RVA: 0xD6C370
	public override object Clear() { }

	// RVA: 0xD6C4E4
	public object <>iFixBaseProxy_Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportAdversityThemeData
{

	// Fields
	public object mBusterHeroData; // 0x10
	public object mEntrapHeroData; // 0x18
	public object mWorstPerfFriendData; // 0x20

	// Methods

	// RVA: 0xD6AF4C
	public object .ctor(object svrData) { }

	// RVA: 0xD6C580
	public override object Clear() { }

	// RVA: 0xD6C718
	public object <>iFixBaseProxy_Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportAscendingThemeData
{

	// Fields
	public object mTopAscendingHeroID; // 0xC
	public object mTopAscendHeroNetWinCnt; // 0x10
	public object mWonderfulGameData; // 0x18
	public object mBestPerfFriendData; // 0x20

	// Methods

	// RVA: 0xD6BE40
	public override object Clear() { }

	// RVA: 0xD6AF1C
	public object .ctor(object svrData) { }

	// RVA: 0xD6C77C
	public object ConverSvrData2CliData(object svrData) { }

	// RVA: 0xD6C8C8
	public object <>iFixBaseProxy_Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportHeroCommonData
{

	// Fields
	public object mHeroID; // 0x8
	public object mGameCnt; // 0xC

	// Properties
	public object IsValid { get; }
	public object HeroItem { get; }
	public object CricleIconPath { get; }

	// Methods

	// RVA: 0xD6C92C
	public object get_IsValid() { }

	// RVA: 0xD6C994
	public object get_HeroItem() { }

	// RVA: 0xD6CA7C
	public object get_CricleIconPath() { }

	// RVA: 0xD6C548
	public object .ctor(object heroId, object gameCnt) { }

	// RVA: 0xD6CB3C
	public virtual object Clear() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportHeroGrowData
{

	// Fields
	public object mWinGameCnt; // 0x10
	public object mLegendBeginCnt; // 0x14
	public object mLegendEndCnt; // 0x18

	// Properties
	public object TitleCode { get; }

	// Methods

	// RVA: 0xD6CB9C
	public object get_TitleCode() { }

	// RVA: 0xD6B57C
	public object .ctor(object heroId, object gameCnt, object winGameCnt, object legendBegCnt, object legendEndCnt) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendWeeklyReportBaseData
{

	// Fields
	public object mGameCnt; // 0x8
	public object mActuallyStarChangeCnt; // 0xC
	public object mGrowHeroData; // 0x10

	// Methods

	// RVA: 0xD6A9F0
	public object Clear() { }

	// RVA: 0xD6AB58
	public object .ctor(object svrData) { }

	// RVA: 0xD6CC98
	public object ConverSvrData2CliData(object svrData) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendHeroTitleData
{

	// Fields
	private object <mHeroID>k__BackingField; // 0x8
	private object <mRanking>k__BackingField; // 0xC
	private object <mTitleCode>k__BackingField; // 0x10
	private object <mShowType>k__BackingField; // 0x14
	private object <mTitleFlag>k__BackingField; // 0x18

	// Properties
	public object mHeroID { get; set; }
	public object mRanking { get; set; }
	public virtual object mTitleCode { get; set; }
	public object mShowType { get; set; }
	public object mTitleFlag { get; set; }
	public object HeroData { get; }
	public object TitleCnt { get; }
	public object SkinID { get; }
	public object mLegendTitle { get; }
	public virtual object mMedalType { get; }
	public object Valid { get; }
	public object mReginIndex { get; }
	public object mCountryIndex { get; }
	public object mProvinceIndex { get; }
	public object mCityIndex { get; }

	// Methods

	// RVA: 0xD6CD1C
	public object get_mHeroID() { }

	// RVA: 0xD6CD24
	public object set_mHeroID(object value) { }

	// RVA: 0xD6CD2C
	public object get_mRanking() { }

	// RVA: 0xD6CD34
	public object set_mRanking(object value) { }

	// RVA: 0xD6CD3C
	public virtual object get_mTitleCode() { }

	// RVA: 0xD6CD44
	public virtual object set_mTitleCode(object value) { }

	// RVA: 0xD6CD4C
	public object get_mShowType() { }

	// RVA: 0xD6CD54
	public object set_mShowType(object value) { }

	// RVA: 0xD6CD5C
	public object get_mTitleFlag() { }

	// RVA: 0xD6CD64
	public object set_mTitleFlag(object value) { }

	// RVA: 0xD6CD6C
	public object get_HeroData() { }

	// RVA: 0xD6CDD0
	public object get_TitleCnt() { }

	// RVA: 0xD6CF8C
	public object get_SkinID() { }

	// RVA: 0xD6D048
	public object get_mLegendTitle() { }

	// RVA: 0xD6D98C
	public virtual object get_mMedalType() { }

	// RVA: 0xD6D218
	public object get_Valid() { }

	// RVA: 0xD6DB8C
	public object get_mReginIndex() { }

	// RVA: 0xD6DD08
	public object get_mCountryIndex() { }

	// RVA: 0xD6DEB4
	public object get_mProvinceIndex() { }

	// RVA: 0xD6E038
	public object get_mCityIndex() { }

	// RVA: 0xD6E1C8
	public virtual object Clear() { }

	// RVA: 0xD6E258
	public virtual object UpdateData(object adCode, object heroId, object ranking) { }

	// RVA: 0xD6E334
	public virtual object UpdateData(object adCode, object heroId, object ranking, object showType, object titleFlag) { }

	// RVA: 0xD6E430
	public virtual object IsSameLegendTitle(object other) { }

	// RVA: 0xD6E74C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendHeroTopTitleData
{

	// Properties
	public override object mTitleCode { get; }
	public override object mMedalType { get; }

	// Methods

	// RVA: 0xD6E754
	public override object get_mTitleCode() { }

	// RVA: 0xD6E93C
	public override object get_mMedalType() { }

	// RVA: 0xD6EA18
	public object .ctor() { }

	// RVA: 0xD6EA20
	public object <>iFixBaseProxy_get_mTitleCode() { }

	// RVA: 0xD6EA28
	public object <>iFixBaseProxy_get_mMedalType() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendHeroAreaTitleData
{

	// Methods

	// RVA: 0xD6EA2C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CUsedLegendTitleData
{

	// Methods

	// RVA: 0xD6EA34
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class RegionInfoBase
{

	// Fields
	public object regionIndex; // 0x8
	public object coutryIndex; // 0xC
	public object cityIndex; // 0x10
	public object provIndex; // 0x14
	public object regionType; // 0x18

	// Methods

	// RVA: 0xD6EA3C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendRegionInfo
{

	// Fields
	public object regionInfoBase; // 0x8
	public object adCode; // 0x10
	public object lastSetRegionTime; // 0x14
	public object bHasRegion; // 0x18
	public object mCurUsedLegendData; // 0x20
	public object mGetLegendAreaTitleData; // 0x28
	public object mGetLegendTopTitleData; // 0x30
	public object mHeroTopLegendTitleData; // 0x38
	public object mLegendWeeklyReportData; // 0x40
	public object rankInfo; // 0x48
	public object u_RankHeroId; // 0x50
	public object m_heroList; // 0x58
	public object u_MostPowerHeroId; // 0x60
	public object mostPowerInfo; // 0x68
	private object _topRequestHeroId; // 0x70

	// Properties
	public object TopRequestHeroId { get; set; }

	// Methods

	// RVA: 0xD6EA44
	public object Clear() { }

	// RVA: 0xD6EB54
	public object get_TopRequestHeroId() { }

	// RVA: 0xD6EBB4
	public object set_TopRequestHeroId(object value) { }

	// RVA: 0xD6EC1C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class RankingInfo
{

	// Fields
	private object <WorldId>k__BackingField; // 0x8
	private object <UId>k__BackingField; // 0x10
	private object <WinTimes>k__BackingField; // 0x18
	private object <TotalNum>k__BackingField; // 0x1C
	private object <No>k__BackingField; // 0x20
	private object <PlayerName>k__BackingField; // 0x28
	private object <Score>k__BackingField; // 0x30
	private object <WinRate>k__BackingField; // 0x34
	private object <AdCode>k__BackingField; // 0x38
	private object <PlayerHeadUrl>k__BackingField; // 0x40
	private object <PlayerHeadBox>k__BackingField; // 0x48
	private object <LegendNumber>k__BackingField; // 0x4C
	private object <HeadImg>k__BackingField; // 0x50
	private object <Pendant>k__BackingField; // 0x54
	private object <PvpLevel>k__BackingField; // 0x58
	private object <GameVipLevel>k__BackingField; // 0x5C
	private object <SwitchHeadPendant>k__BackingField; // 0x60
	private object <CampID>k__BackingField; // 0x64
	private object <ChampionCount>k__BackingField; // 0x68
	private object <ShowGradeOfRank>k__BackingField; // 0x6C
	private object <symbolInfo>k__BackingField; // 0x70
	private object <equipInfo>k__BackingField; // 0x78
	private object <moWenInfo>k__BackingField; // 0x80
	private object <armorySuitInfo>k__BackingField; // 0x88
	private object <IsHideInfo>k__BackingField; // 0x90

	// Properties
	public object WorldId { get; set; }
	public object UId { get; set; }
	public object WinTimes { get; set; }
	public object TotalNum { get; set; }
	public object No { get; set; }
	public object PlayerName { get; set; }
	public object Score { get; set; }
	public object WinRate { get; set; }
	public object AdCode { get; set; }
	public object PlayerHeadUrl { get; set; }
	public object PlayerHeadBox { get; set; }
	public object LegendNumber { get; set; }
	public object HeadImg { get; set; }
	public object Pendant { get; set; }
	public object PvpLevel { get; set; }
	public object GameVipLevel { get; set; }
	public object SwitchHeadPendant { get; set; }
	public object CampID { get; set; }
	public object ChampionCount { get; set; }
	public object ShowGradeOfRank { get; set; }
	public object symbolInfo { get; set; }
	public object equipInfo { get; set; }
	public object moWenInfo { get; set; }
	public object armorySuitInfo { get; set; }
	public object IsHideInfo { get; set; }

	// Methods

	// RVA: 0xD6EE5C
	public object get_WorldId() { }

	// RVA: 0xD6EE64
	public object set_WorldId(object value) { }

	// RVA: 0xD6EE6C
	public object get_UId() { }

	// RVA: 0xD6EE74
	public object set_UId(object value) { }

	// RVA: 0xD6EE7C
	public object get_WinTimes() { }

	// RVA: 0xD6EE84
	public object set_WinTimes(object value) { }

	// RVA: 0xD6EE8C
	public object get_TotalNum() { }

	// RVA: 0xD6EE94
	public object set_TotalNum(object value) { }

	// RVA: 0xD6EE9C
	public object get_No() { }

	// RVA: 0xD6EEA4
	public object set_No(object value) { }

	// RVA: 0xD6EEAC
	public object get_PlayerName() { }

	// RVA: 0xD6EEB4
	public object set_PlayerName(object value) { }

	// RVA: 0xD6EEBC
	public object get_Score() { }

	// RVA: 0xD6EEC4
	public object set_Score(object value) { }

	// RVA: 0xD6EECC
	public object get_WinRate() { }

	// RVA: 0xD6EED4
	public object set_WinRate(object value) { }

	// RVA: 0xD6EEDC
	public object get_AdCode() { }

	// RVA: 0xD6EEE4
	public object set_AdCode(object value) { }

	// RVA: 0xD6EEEC
	public object get_PlayerHeadUrl() { }

	// RVA: 0xD6EEF4
	public object set_PlayerHeadUrl(object value) { }

	// RVA: 0xD6EEFC
	public object get_PlayerHeadBox() { }

	// RVA: 0xD6EF04
	public object set_PlayerHeadBox(object value) { }

	// RVA: 0xD6EF0C
	public object get_LegendNumber() { }

	// RVA: 0xD6EF14
	public object set_LegendNumber(object value) { }

	// RVA: 0xD6EF1C
	public object get_HeadImg() { }

	// RVA: 0xD6EF24
	public object set_HeadImg(object value) { }

	// RVA: 0xD6EF2C
	public object get_Pendant() { }

	// RVA: 0xD6EF34
	public object set_Pendant(object value) { }

	// RVA: 0xD6EF3C
	public object get_PvpLevel() { }

	// RVA: 0xD6EF44
	public object set_PvpLevel(object value) { }

	// RVA: 0xD6EF4C
	public object get_GameVipLevel() { }

	// RVA: 0xD6EF54
	public object set_GameVipLevel(object value) { }

	// RVA: 0xD6EF5C
	public object get_SwitchHeadPendant() { }

	// RVA: 0xD6EF64
	public object set_SwitchHeadPendant(object value) { }

	// RVA: 0xD6EF6C
	public object get_CampID() { }

	// RVA: 0xD6EF74
	public object set_CampID(object value) { }

	// RVA: 0xD6EF7C
	public object get_ChampionCount() { }

	// RVA: 0xD6EF84
	public object set_ChampionCount(object value) { }

	// RVA: 0xD6EF8C
	public object get_ShowGradeOfRank() { }

	// RVA: 0xD6EF94
	public object set_ShowGradeOfRank(object value) { }

	// RVA: 0xD6EF9C
	public object get_symbolInfo() { }

	// RVA: 0xD6EFA4
	public object set_symbolInfo(object value) { }

	// RVA: 0xD6EFAC
	public object get_equipInfo() { }

	// RVA: 0xD6EFB4
	public object set_equipInfo(object value) { }

	// RVA: 0xD6EFBC
	public object get_moWenInfo() { }

	// RVA: 0xD6EFC4
	public object set_moWenInfo(object value) { }

	// RVA: 0xD6EFCC
	public object get_armorySuitInfo() { }

	// RVA: 0xD6EFD4
	public object set_armorySuitInfo(object value) { }

	// RVA: 0xD6EFDC
	public object get_IsHideInfo() { }

	// RVA: 0xD6EFE4
	public object set_IsHideInfo(object value) { }

	// RVA: 0xD6EFEC
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendNearRegionInfo
{

	// Fields
	public object cnt; // 0x8
	public object adCode; // 0x10

	// Methods

	// RVA: 0xD6EFF4
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object bIsDesc; // 0x8

	// Methods

	// RVA: 0xD6F2CC
	public object .ctor() { }

	// RVA: 0xD72860
	internal object <SortByMedalRankingCS1>b__0(object a, object b) { }

}

// Namespace: 
private sealed class <>c__DisplayClass5_0
{

	// Fields
	public object bIsDesc; // 0x8

	// Methods

	// RVA: 0xD6F418
	public object .ctor() { }

	// RVA: 0xD72998
	internal object <SortByMedalRankingCS2>b__0(object a, object b) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendMgr
{

	// Fields
	public object m_userRegionInfo; // 0x8
	public object m_NearRegionInfo; // 0x10

	// Methods

	// RVA: 0xD6F058
	public static object GetUserRegionInfo() { }

	// RVA: 0xD6F0F0
	public static object GetNearRegionInfo() { }

	// RVA: 0xD6F188
	public static object SortByMedalRankingCS1(object list, object bIsDesc) { }

	// RVA: 0xD6F2D4
	public static object SortByMedalRankingCS2(object list, object bIsDesc) { }

	// RVA: 0xD6F420
	public object GetUsedLegendTitleData() { }

	// RVA: 0xD6F4BC
	public object GetLegendHeroTitleData() { }

	// RVA: 0xD6F558
	public object GetLegendTitleMedalType(object adCode) { }

	// RVA: 0xD6F78C
	public object GetLegendTitleBannerPath(object medalType) { }

	// RVA: 0xD6F950
	public object GetLegendTitleIconPath(object medalType) { }

	// RVA: 0xD6FB14
	public object GetLegendTitleBgPath(object medalType) { }

	// RVA: 0xD6FCD8
	public object GetLegendTitleAreaComp(object adCode) { }

	// RVA: 0xD70414
	public object SetLegendTitleText(object titleText, object titleCode, object heroId, object ranking, object isHideGIS, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD70770
	public object SetLegendTitleTextNew(object titleText, object titleCode, object showType, object titleFlag, object heroId, object ranking, object isHideGIS, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD70B00
	public object GetLegendTitleTextNew(object titleCode, object showType, object titleFlag, object heroId, object ranking, object isHideGIS, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD70E08
	public object SetLegendTitleRankingText(object rankingText, object ranking, object isAlsoSetGoVisible) { }

	// RVA: 0xD71060
	public object SetLegendTitleMedalImage(object medalImage, object titleCode, object isAlsoSetGoVisible) { }

	// RVA: 0xD712B4
	public object SetLegendTitleMedalImageNew(object medalImage, object titleFlag, object isAlsoSetGoVisible) { }

	// RVA: 0xD714E8
	public object GetLegendTitleGeographicalInfoWithRank(object titleCode, object rankNo) { }

	// RVA: 0xD71CEC
	public object SetLegendTitleComplete(object medalImage, object rankingText, object titleText, object titleCntText, object titleCode, object heroId, object ranking, object titleCnt, object hideGIS, object isAlsoSetGoVisible, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD72014
	public object SetLegendTitleCompleteNew(object medalImage, object rankingText, object titleText, object titleCntText, object titleCode, object showType, object titleFlag, object heroId, object ranking, object titleCnt, object hideGIS, object isAlsoSetGoVisible, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD7235C
	public object GetLegendTitleIconMedalTypeNew(object titleFlag) { }

	// RVA: 0xD723EC
	public object GetLegendTitleBannerPathNew(object medalType) { }

	// RVA: 0xD725B0
	public object GetLegendTitleIconPathNew(object medalType) { }

	// RVA: 0xD72774
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLegendUtility
{

	// Fields
	public static readonly object TOP_LEGEND_TITLE_KEY; // 0x0
	public static readonly object SHARE_TOP_lEGEDN_TITLE_KEY; // 0x8
	public static object LEGEND_TITLE_FORMATE_KEY; // 0x10
	public static object SHARE_LEGEND_TITLE_FORMATE_KEY; // 0x18
	public static object LEGEND_TITLE_UNUSED_KEY; // 0x20
	public static object LEGEND_TITLE_GIS_HIDE_KEY; // 0x28
	public static object LEGEND_WEEKLY_REPORT_TIME_FORMAT; // 0x30
	public static readonly object Region_Country_Mask; // 0x38
	public static readonly object Region_Province_Mask; // 0x3C
	public static readonly object Region_City_Mask; // 0x40
	public static readonly object Region_Region_Mask; // 0x44

	// Properties
	public static object PLAYER_PREF_KEY_GET_LEGEND_WEEK_REPORT_KEY { get; }
	public static object PLAYER_PREF_KEY_VISIT_NEW_TITLE_KEY { get; }
	public static object PLAYER_PREF_KEY_SETTLE_LEGEND_TITLE_KEY { get; }

	// Methods

	// RVA: 0xD72AD0
	public static object get_PLAYER_PREF_KEY_GET_LEGEND_WEEK_REPORT_KEY() { }

	// RVA: 0xD72C30
	public static object get_PLAYER_PREF_KEY_VISIT_NEW_TITLE_KEY() { }

	// RVA: 0xD72D90
	public static object get_PLAYER_PREF_KEY_SETTLE_LEGEND_TITLE_KEY() { }

	// RVA: 0xD6E10C
	public static object ParseCityIndex(object adCode) { }

	// RVA: 0xD6DF88
	public static object ParseProvinceIndex(object adCode) { }

	// RVA: 0xD6DDDC
	public static object ParseCountryIndex(object adCode) { }

	// RVA: 0xD6DC60
	public static object ParseRegionIndex(object adCode) { }

	// RVA: 0xD72EF0
	public static object FindRegionConfigData(object country, object province, object city, object type) { }

	// RVA: 0xD731B4
	public static object GetCountryAndCityName(object adCode) { }

	// RVA: 0xD73544
	public static object GetAllRegionName(object adCode) { }

	// RVA: 0xD73804
	public static object GetRegionName(object adCode) { }

	// RVA: 0xD73A30
	public static object GetCountryOrProvName(object adCode) { }

	// RVA: 0xD73CCC
	public static object GetCountryName(object adCode) { }

	// RVA: 0xD73E70
	public static object GetProvName(object adCode) { }

	// RVA: 0xD74014
	public static object GetCityName(object adCode) { }

	// RVA: 0xD6E80C
	public static object CalcAreaCode(object countryIndex, object provinceIndex, object cityIndex) { }

	// RVA: 0xD741B8
	public static object FindRegionConfigDataSingleLua(object adCode) { }

	// RVA: 0xD733D0
	public static object FindRegionConfigDataSingle(object adCode, object countryIndex, object provinceIndex, object cityIndex, object type) { }

	// RVA: 0xD742BC
	private static object GetRegionDataByCheck(object data, object checkId, object areaType) { }

	// RVA: 0xD745D8
	private static object IsRegionDataMatch(object cfg, object checkId, object areaType) { }

	// RVA: 0xD746D0
	public static object GetLegendTitle(object heroId, object ranking, object titleAdCode, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD6D380
	public static object GetLegendTitleNew(object heroId, object ranking, object titleAdCode, object showType, object titleFlag, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD74DBC
	public static object SwitchLegendTitleFlagToCfg(object titleFlag) { }

	// RVA: 0xD6D2AC
	public static object GetLegendUnusedTitle() { }

	// RVA: 0xD752F8
	public static object GetLegendTitleGISHideText() { }

	// RVA: 0xD753CC
	public static object GetLegendTitleMedalImage(object medalType) { }

	// RVA: 0xD754D0
	public static object GetLegendTitleMedalImageNew(object titleFlag) { }

	// RVA: 0xD75674
	public static object GetLegendTitleMedalImageNew(object titleFlag) { }

	// RVA: 0xD6FA10
	public static object GetLegendTitleIconPath(object medalType) { }

	// RVA: 0xD6DB0C
	public static object SwitchMedalTypeToIndex(object titleFlag) { }

	// RVA: 0xD75818
	public static object SwitchMedalTypeToIndex(object titleFlag) { }

	// RVA: 0xD75898
	public static object SwitchIndexToMedalType(object index) { }

	// RVA: 0xD6F84C
	public static object GetLegendTitleBannerPath(object medalType) { }

	// RVA: 0xD6FBD4
	public static object GetLegendTitleBgPath(object medalType) { }

	// RVA: 0xD724AC
	public static object GetLegendTitleBannerPathNew(object medalType) { }

	// RVA: 0xD72670
	public static object GetLegendTitleIconPathNew(object medalType) { }

	// RVA: 0xD7591C
	private static object SetLegendTitleMedalImage(object medalImage, object medalType) { }

	// RVA: 0xD75B38
	private static object SetLegendTitleMedalImageNew(object medalImage, object titleFlag) { }

	// RVA: 0xD71130
	public static object SetLegendTitleMedalImage(object medalImage, object titleCode, object isAlsoSetGoVisible) { }

	// RVA: 0xD71384
	public static object SetLegendTitleMedalImageNew(object medalImage, object titleFlag, object isAlsoSetGoVisible) { }

	// RVA: 0xD75D54
	public static object SetLegendTitleMedalImageNewIsValid(object medalImage, object titleFlag, object isAlsoSetGoVisible) { }

	// RVA: 0xD70590
	public static object SetLegendTitleText(object titleText, object titleCode, object heroId, object ranking, object isHideGIS, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD70900
	public static object SetLegendTitleTextNew(object titleText, object titleCode, object showType, object titleFlag, object heroId, object ranking, object isHideGIS, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD70C88
	public static object GetLegendTitleTextNew(object titleCode, object showType, object titleFlag, object heroId, object ranking, object isHideGIS, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD70EF4
	public static object SetLegendTitleRankingText(object rankingText, object ranking, object isAlsoSetGoVisible) { }

	// RVA: 0xD75E9C
	public static object SetLegendTitleCntText(object cntText, object cnt) { }

	// RVA: 0xD71E8C
	public static object SetLegendTitleComplete(object medalImage, object rankingText, object titleText, object titleCntText, object titleCode, object heroId, object ranking, object titleCnt, object hideGIS, object isAlsoSetGoVisible, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD721C4
	public static object SetLegendTitleCompleteNew(object medalImage, object rankingText, object titleText, object titleCntText, object titleCode, object showType, object titleFlag, object heroId, object ranking, object titleCnt, object hideGIS, object isAlsoSetGoVisible, object normalTitleFormat, object topTitleFormat) { }

	// RVA: 0xD749B8
	public static object GetLegendTitleAreaType(object titleAdCode) { }

	// RVA: 0xD6FD98
	public static object GetLegendTitleAreaComp(object titleCode) { }

	// RVA: 0xD74E24
	public static object GetLegendTitleAreaCompNew(object titleFlag, object titleCode) { }

	// RVA: 0xD715B8
	public static object GetLegendTitleGeographicalInfoWithRank(object titleCode, object rankNo) { }

	// RVA: 0xD74B94
	public static object GetLegendTitleHeroComp(object heroId) { }

	// RVA: 0xD75FDC
	public static object isLegendTop(object medalType) { }

	// RVA: 0xD6F618
	public static object GetLegendTitleMedalType(object titleAdCode) { }

	// RVA: 0xD76040
	public object .ctor() { }

	// RVA: 0xD76048
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CLuckDrawHandler
{

	// Methods

	// RVA: 0xD76174
	public object GetProductTagIconPath(object tagType, object owned) { }

	// RVA: 0xD762A8
	public object AddTag(object gameObject, object type, object form) { }

	// RVA: 0xD76A2C
	public object AddTagNew(object gameObject, object product, object form) { }

	// RVA: 0xD77550
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public interface CMallBaseInterface
{

	// Methods

	// RVA: -1
	public abstract object Init() { }

	// RVA: -1
	public abstract object UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public interface CMallContentInterface
{

	// Methods

	// RVA: -1
	public abstract object Load(object form) { }

	// RVA: -1
	public abstract object Loaded(object form) { }

	// RVA: -1
	public abstract object Draw(object form) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallGoToTabHandler
{

	// Methods

	// RVA: 0xD77558
	public object Init() { }

	// RVA: 0xD779D8
	public object UnInit() { }

	// RVA: 0xD77E58
	private static object OnUIEvent_Mall_Goto_Component(object e) { }

	// RVA: 0xD77EB4
	private object OnUIEvent_Mall_Goto_Activity_GGL(object e) { }

	// RVA: 0xD7802C
	private object OnMallGotoBoutique(object uiEvent) { }

	// RVA: 0xD78140
	private object OnMalOpenHeroTab(object uiEvent) { }

	// RVA: 0xD78258
	private object OnMallOpenFactoryShopTab(object uiEvent) { }

	// RVA: 0xD78370
	private object OnMallOpenDiamondsShopTab(object uiEvent) { }

	// RVA: 0xD78488
	private object OnMallGotoSymbolTab(object uiEvent) { }

	// RVA: 0xD785A0
	private object OnMallGotoSkinTab(object uiEvent) { }

	// RVA: 0xD786B8
	private object OnMallGoToTreasureTab(object uiEvent) { }

	// RVA: 0xD787EC
	private object OnMallGoToComponentLotteryTab(object uiEvent) { }

	// RVA: 0xD78964
	private object OnMallGoToRecommendHeroTab(object uiEvent) { }

	// RVA: 0xD78BE8
	private object OnMallGoToRecommendSkinTab(object uiEvent) { }

	// RVA: 0xD78D78
	private object OnMallGoToRecommendRouletteTab(object uiEvent) { }

	// RVA: 0xD78F08
	private object OnMallGoToVipShopTab(object uiEvent) { }

	// RVA: 0xD78AF4
	private object ToMallDebrisExchange() { }

	// RVA: 0xD790D8
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallItemList
{

	// Methods

	// RVA: 0xD790E0
	public object ShowItemListPrice(object form, object showBigIcon, object product) { }

	// RVA: 0xD79F18
	public object ShowItemListAndPrice(object showBigIcon, object product, object itemGroup, object saleBtn, object coinIcon, object costDecsTextObj) { }

	// RVA: 0xD7A914
	public object RefreshPrice(object count, object countText, object costText, object oldPriceText, object shopProduct, object firstPanel) { }

	// RVA: 0xD79AA4
	private object UpdateElement(object elementScript, object useable, object isShowBigIcon) { }

	// RVA: 0xD7ADF0
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallLayoutElement
{

	// Fields
	private object mLayoutGroup; // 0x68

	// Methods

	// RVA: 0xD7ADF8
	public override object Initialize(object formScript) { }

	// RVA: 0xD7B01C
	private object OnEnable() { }

	// RVA: 0xD7B40C
	private object OnDisable() { }

	// RVA: 0xD7B53C
	public object .ctor() { }

	// RVA: 0xD7B544
	public object <>iFixBaseProxy_Initialize(object P0) { }

}

// Namespace: 
public enum LayoutType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Horizontal;
	public const object Vertical;
}

// Namespace: 
public enum AnchorType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Zero;
	public const object Center;
	public const object End;
}

// Namespace: Assets.Scripts.GameSystem
public class CMallLayoutGroup
{

	// Fields
	public object ELayoutType; // 0x64
	public object EAnchorType; // 0x68
	public object mChildrensRectTrans; // 0x70
	public object IsAdapter; // 0x78
	public object IconAndTextSpaceing; // 0x7C
	private object mRectTrans; // 0x80
	private object mLayoutNum; // 0x88

	// Methods

	// RVA: 0xD7B54C
	public override object Initialize(object formScript) { }

	// RVA: 0xD7B6D0
	public object ResetHaveIconAndTextLayout() { }

	// RVA: 0xD7BA4C
	public object GetElemenet(object index) { }

	// RVA: 0xD7B14C
	public object ResetElementAmount() { }

	// RVA: 0xD7C3A4
	public object SetElementAmount(object num) { }

	// RVA: 0xD7BB8C
	private object ResetLayout() { }

	// RVA: 0xD7C67C
	public object .ctor() { }

	// RVA: 0xD7C694
	public object <>iFixBaseProxy_Initialize(object P0) { }

}

// Namespace: 
public class TagInfo
{

	// Fields
	public object icon; // 0x8
	public object text; // 0x10

	// Methods

	// RVA: 0xD833CC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object oprice; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0xD833D4
	public object .ctor() { }

	// RVA: 0xD833DC
	internal object <FillUsableCouponsHeroOrSkin>b__0(object a, object b) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallPriceHandler
{

	// Methods

	// RVA: 0xD7C69C
	public object SetSkinBuyPricePanel(object formScript, object pricePanel, object payInfo) { }

	// RVA: 0xD7CC1C
	public object FilterPayInfoSetByPayType(object payInfo, object payType) { }

	// RVA: 0xD7CD20
	public object GetPayInfoSetOfGood(object resHeroCfgInfo) { }

	// RVA: 0xD7CD90
	public object GetPayInfoSetOfGood(object resHeroCfgInfo, object normalMall) { }

	// RVA: 0xD7D53C
	private object FillUsableCouponsHeroOrSkin(object info, object heroID, object skinIndex) { }

	// RVA: 0xD7DA80
	public object GetPriceAfterCoupon(object price, object coupon) { }

	// RVA: 0xD7DCC4
	public object GetPayInfoSetOfGood(object resHeroSkin) { }

	// RVA: 0xD7DD34
	public object GetPayInfoSetOfGood(object resHeroSkin, object considerRegistalSale) { }

	// RVA: 0xD7D228
	private object GetPayInfoSetOfGood(object canUseGoldCoin, object goldCoinValue, object oriGoldCoinValue, object canUseDianQuan, object dianquanValue, object oriDianquanValue, object canUseDiamond, object diamondValue, object oriDiamondValue, object discount) { }

	// RVA: 0xD7E034
	public object CalLowestPayInfoSet(object values) { }

	// RVA: 0xD7E3D4
	public object CanUseDiscountCoupon(object coupon, object payInfo, object heroID, object skinIndex) { }

	// RVA: 0xD7D79C
	private object GetCanUseDiscountCoupons(object payInfo, object heroID, object skinIndex) { }

	// RVA: 0xD7E748
	public static object GetAllDiscountCoupons() { }

	// RVA: 0xD7EA34
	public object GetPayTypeIconPath(object payType) { }

	// RVA: 0xD7EB6C
	public object GetPayTypeText(object payType) { }

	// RVA: 0xD7ED5C
	public object GetPriceTypeBuyString(object payType) { }

	// RVA: 0xD7EF0C
	public object SetPayButton(object formScript, object buttonTransform, object payType, object payValue, object eventID, object eventParams) { }

	// RVA: 0xD7F3B0
	public object SetPayButton(object formScript, object buttonTransform, object payType, object payValue, object oriValue, object eventID, object eventParams) { }

	// RVA: 0xD7F978
	public object TryToPay(object payPurpose, object goodName, object payType, object payValue, object confirmEventID, object confirmEventParams, object cancelEventID, object needConfirm, object guideToAchieveDianQuan) { }

	// RVA: 0xD80E60
	public object TryToPaydirect(object payPurpose, object goodName, object payType, object payValue, object confirmEventID, object confirmEventParams, object cancelEventID, object needConfirm, object guideToAchieveDianQuan) { }

	// RVA: 0xD80BD0
	public object GetCurrencyValueFromRoleInfo(object roleInfo, object payType) { }

	// RVA: 0xD821D0
	public object ResBuyTypeToPayType(object resShopBuyType) { }

	// RVA: 0xD8225C
	public object PayTypeToResBuyCoinType(object payType) { }

	// RVA: 0xD822E8
	public object GetShopPromotion(object type, object subType) { }

	// RVA: 0xD8258C
	public static object GetItemRealPrice(object itemID, object count) { }

	// RVA: 0xD82620
	public static object GetItemPrice(object itemID, object count, object price, object oldPrice, object priceType) { }

	// RVA: 0xD829F0
	public static object GetDiscountStr(object percent) { }

	// RVA: 0xD82E1C
	public object GetCoinTypeIconPath(object coinType) { }

	// RVA: 0xD82F48
	public static object GetTag(object tag, object discountPercent, object offSaleTime) { }

	// RVA: 0xD833C4
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallRegisterSale
{

	// Methods

	// RVA: 0xD83460
	public object IsinRegisterSales(object stRegisterSale) { }

	// RVA: 0xD836B4
	public object GetRegisterSalesHeroDay(object heroPromotion, object heroShop) { }

	// RVA: 0xD83AD0
	public object GetRegisterSalesSkinDay(object heroPromotion, object heroShop) { }

	// RVA: 0xD83E08
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class HeroSortImp
{

	// Fields
	private object m_sortType; // 0x8
	private object m_desc; // 0xC
	private object m_roleInfo; // 0x10
	private object m_culture; // 0x18

	// Methods

	// RVA: 0xD83E10
	public override object Init() { }

	// RVA: 0xD83EF8
	public override object UnInit() { }

	// RVA: 0xD83F94
	public object GetSortTypeName(object sortType) { }

	// RVA: 0xD840FC
	public object ConvertToHeroSortType(object sortType) { }

	// RVA: 0xD84188
	public object GetCurSortType() { }

	// RVA: 0xD841E8
	public object IsDesc() { }

	// RVA: 0xD84248
	public object SetSortType(object sortType) { }

	// RVA: 0xD842E8
	public object CompareDefault(object l, object r) { }

	// RVA: 0xD843A4
	public object CompareCoin(object l, object r) { }

	// RVA: 0xD8476C
	public object CompareCoupons(object l, object r) { }

	// RVA: 0xD84B98
	public object CompareReleaseTime(object l, object r) { }

	// RVA: 0xD84D34
	public object CompareName(object l, object r) { }

	// RVA: 0xD84E54
	public object GetDiscountFactor(object c) { }

	// RVA: 0xD85154
	public object CompareDiscount(object l, object r) { }

	// RVA: 0xD8532C
	public object Compare(object l, object r) { }

	// RVA: 0xD854C8
	public object .ctor() { }

	// RVA: 0xD85520
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xD85524
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class SkinSortImp
{

	// Fields
	private object m_sortType; // 0x8
	private object m_desc; // 0xC
	private object m_roleInfo; // 0x10
	private object m_culture; // 0x18

	// Methods

	// RVA: 0xD855C0
	public override object Init() { }

	// RVA: 0xD856D4
	public override object UnInit() { }

	// RVA: 0xD85768
	public object GetSortTypeName(object sortType) { }

	// RVA: 0xD858D0
	public object GetCurSortType() { }

	// RVA: 0xD85930
	public object IsDesc() { }

	// RVA: 0xD85990
	private object SetIsDesc(object isDesc) { }

	// RVA: 0xD859F8
	public object SetSortType(object sortType) { }

	// RVA: 0xD85A98
	public object CompareDefault(object l, object r) { }

	// RVA: 0xD85B54
	public object CompareCoupons(object l, object r) { }

	// RVA: 0xD85E70
	public object CompareReleaseTime(object l, object r) { }

	// RVA: 0xD85FC4
	private object CompareName(object l, object r) { }

	// RVA: 0xD86184
	public object GetDiscountFactor(object c) { }

	// RVA: 0xD86484
	public object CompareDiscount(object l, object r) { }

	// RVA: 0xD8665C
	public object Compare(object l, object r) { }

	// RVA: 0xD867A8
	public object GetHeroSkinConfigList(object jobType, object sortType, object isSortDesc) { }

	// RVA: 0xD86C64
	public object .ctor() { }

	// RVA: 0xD86CBC
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xD86CC0
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class HeroCultivateSortImp
{

	// Fields
	private object m_sortType; // 0x8
	private object m_desc; // 0xC
	private object m_culture; // 0x10

	// Methods

	// RVA: 0xD86D54
	public override object Init() { }

	// RVA: 0xD86E3C
	public override object UnInit() { }

	// RVA: 0xD86ED8
	public object GetSortTypeName(object sortType) { }

	// RVA: 0xD87040
	public object GetCurSortType() { }

	// RVA: 0xD870A0
	public object IsDesc() { }

	// RVA: 0xD87100
	public object SetSortType(object sortType) { }

	// RVA: 0xD8718C
	public object SetDesc(object bDesc) { }

	// RVA: 0xD871F4
	private object CompareDefault(object l, object r) { }

	// RVA: 0xD8791C
	private object CompareCultivateStage(object l, object r) { }

	// RVA: 0xD8826C
	private object CompareCultivateStageForHeroSelect(object l, object r) { }

	// RVA: 0xD87C38
	private object CompareProficiency(object l, object r) { }

	// RVA: 0xD88510
	public object Compare(object l, object r) { }

	// RVA: 0xD88740
	public object .ctor() { }

	// RVA: 0xD88798
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xD8879C
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class HeroViewSortImpBase
{

	// Fields
	private object m_sortType; // 0x8
	private object m_desc; // 0xC
	private object m_culture; // 0x10

	// Methods

	// RVA: 0xD88838
	public virtual object Init() { }

	// RVA: 0xD88900
	public virtual object UnInit() { }

	// RVA: 0xD88968
	public object GetSortTypeName(object sortType) { }

	// RVA: 0xD88AE4
	public object GetCurSortType() { }

	// RVA: 0xD88B44
	public object IsDesc() { }

	// RVA: 0xD88BA4
	public object SetSortType(object sortType) { }

	// RVA: 0xD88C20
	public object SetDesc(object bDesc) { }

	// RVA: 0xD88C88
	protected virtual object CompareDefault(object l, object r) { }

	// RVA: 0xD88D44
	internal virtual object CompareReleaseTime(object l, object r) { }

	// RVA: 0xD89028
	protected virtual object CompareLegendNum(object l, object r) { }

	// RVA: 0xD89360
	protected virtual object CompareAffinity(object l, object r) { }

	// RVA: 0xD895FC
	protected virtual object CompareUseNum(object l, object r) { }

	// RVA: 0xD898CC
	protected virtual object CompareHistoryUseNum(object l, object r) { }

	// RVA: 0xD89B84
	protected virtual object CompareHistoryBanNum(object l, object r) { }

	// RVA: 0xD89E3C
	protected virtual object CompareName(object l, object r) { }

	// RVA: 0xD8A0B8
	protected virtual object CompareProficiency(object l, object r) { }

	// RVA: 0xD8A6F0
	public object Compare(object l, object r) { }

	// RVA: 0xD8A984
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class HeroViewSortImp
{

	// Fields
	private static object s_HeroViewSortImp; // 0x0

	// Methods

	// RVA: 0xD8A98C
	public static object GetInstance() { }

	// RVA: 0xD8AA88
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class HeroSelectSortImp
{

	// Fields
	private static object s_HeroSelectSortImp; // 0x0

	// Methods

	// RVA: 0xD8AA90
	public static object GetInstance() { }

	// RVA: 0xD8AB94
	protected override object CompareProficiency(object l, object r) { }

	// RVA: 0xD8AB8C
	public object .ctor() { }

	// RVA: 0xD8B1A8
	public object <>iFixBaseProxy_CompareProficiency(object P0, object P1) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallSortHelper
{

	// Fields
	public static object heroSortTypeNameKeys; // 0x0
	public static object skinSortTypeNameKeys; // 0x8
	public static object heroViewSortTypeNameKeys; // 0x10

	// Methods

	// RVA: 0xD8B1AC
	public static object CreateHeroSorter() { }

	// RVA: 0xD8B22C
	public static object CreateSkinSorter() { }

	// RVA: 0xD8B2AC
	public static object CreateHeroViewSorter() { }

	// RVA: 0xD8B2F4
	public static object CreateHeroCultivateSorter() { }

	// RVA: 0xD8B374
	public static object CreateHeroSelectSorter() { }

	// RVA: 0xD8B3BC
	public object .ctor() { }

	// RVA: 0xD8B3C4
	private static object .cctor() { }

}

// Namespace: 
public class ShopProductWidget
{

	// Fields
	public object icon; // 0x18
	public object iconFrame; // 0x20
	public object iconMark; // 0x28
	public object coinType; // 0x30
	public object coinCost; // 0x38
	public object name; // 0x40
	public object desc; // 0x48
	public object limitObj; // 0x50
	public object limitCount; // 0x58
	public object limitCycle; // 0x60
	public object LimitTimeObj; // 0x68
	public object LimitTimeCount; // 0x70
	public object TagObj; // 0x78
	public object tagImage; // 0x80
	public object tagText; // 0x88
	public object OldPriceObj; // 0x90
	public object OldPriceText; // 0x98
	public object coinPLObj; // 0xA0
	public object bigIconObj; // 0xA8
	public object btnOwned; // 0xB0
	private object blueButtonSpr; // 0xB8
	private object yellowButtonSpr; // 0xC0
	protected object btnBuy; // 0xC8
	protected object touchBuy; // 0xD0
	public object data; // 0xD8
	private object m_namePos; // 0xE0
	public object isNeedShopOpen; // 0xEC
	public object boutiqueInfo; // 0xF0
	public object CanShowReddot; // 0xF8

	// Methods

	// RVA: 0xD8EBA0
	private object Awake() { }

	// RVA: 0xD8CE88
	public object Refresh() { }

	// RVA: 0xD8F1E4
	private object OnDestroy() { }

	// RVA: 0xD8F300
	private object OnProductStateChange(object sp) { }

	// RVA: 0xD8F388
	protected virtual object Validate(object isNeedShopOpen) { }

	// RVA: 0xD90FA0
	public object .ctor() { }

	// RVA: 0xD91018
	private object <Validate>b__33_0(object e) { }

	// RVA: 0xD910C0
	private object <Validate>b__33_1(object e) { }

}

// Namespace: 
public class SpecSaleProductWidget
{

	// Methods

	// RVA: 0xD91168
	protected override object Validate(object isNeedShopOpen) { }

	// RVA: 0xD912F0
	public object .ctor() { }

	// RVA: 0xD91368
	public object <>iFixBaseProxy_Validate(object P0) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__12_0; // 0x8
	public static object <>9__17_1; // 0x10
	public static object <>9__18_0; // 0x18
	public static object <>9__18_1; // 0x20

	// Methods

	// RVA: 0xD9136C
	private static object .cctor() { }

	// RVA: 0xD913CC
	public object .ctor() { }

	// RVA: 0xD913D4
	internal object <SortProducts>b__12_0(object l, object r) { }

	// RVA: 0xD91668
	internal object <ShouldNotify>b__17_1(object x) { }

	// RVA: 0xD91740
	internal object <ShouldNotify>b__18_0(object product) { }

	// RVA: 0xD918AC
	internal object <ShouldNotify>b__18_1(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass17_0
{

	// Fields
	public object tab; // 0x8

	// Methods

	// RVA: 0xD8CA60
	public object .ctor() { }

	// RVA: 0xD91984
	internal object <ShouldNotify>b__0(object product) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallSpecSaleBase
{

	// Fields
	protected object UIInited; // 0x8
	private object m_root; // 0x10
	private object m_CurrTabSpList; // 0x18

	// Properties
	public static object CMallSystem { get; }

	// Methods

	// RVA: 0xD8B68C
	public virtual object Init() { }

	// RVA: 0xD8B6E8
	public virtual object UnInit() { }

	// RVA: 0xD8B7D8
	public virtual object Load(object form) { }

	// RVA: 0xD8B83C
	public virtual object Loaded(object form) { }

	// RVA: 0xD8B8A0
	public virtual object Draw(object form) { }

	// RVA: 0xD8B908
	public object ResetData() { }

	// RVA: 0xD8B748
	protected object Clear() { }

	// RVA: 0xD8BF84
	public object SortProducts() { }

	// RVA: 0xD8BD68
	public object InitShopData() { }

	// RVA: 0xD8C1C4
	private object FilterCurrProduct(object sp) { }

	// RVA: 0xD8C0E4
	public static object get_CMallSystem() { }

	// RVA: 0xD8C7B0
	public static object ShouldNotify(object tab) { }

	// RVA: 0xD8CA68
	public static object ShouldNotify() { }

	// RVA: 0xD8CD28
	private object onMall_SpecSale_Item_Enable(object e) { }

	// RVA: 0xD8D010
	private object onMall_SpecSale_Item_Enable_EX(object e) { }

	// RVA: 0xD8D170
	public object Open(object form, object bodyBg) { }

	// RVA: 0xD8D71C
	private object MallCloseOrTabChange() { }

	// RVA: 0xD8B980
	private object Close() { }

	// RVA: 0xD8D77C
	private object OnClickBuy(object uiEvent) { }

	// RVA: 0xD8E814
	private object OnSelectedItemChanged(object list) { }

	// RVA: 0xD8EB20
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallTagHelper
{

	// Fields
	public object clickAnyWhere; // 0x18
	public object popup; // 0x20
	public object close; // 0x28

	// Methods

	// RVA: 0xD91BA8
	private object OnEnable() { }

	// RVA: 0xD91D14
	private object OpenPopup(object cuiEvent) { }

	// RVA: 0xD91FE4
	private object ClosePopup(object cuiEvent) { }

	// RVA: 0xD92064
	private object OnDisable() { }

	// RVA: 0xD921D0
	public object .ctor() { }

}

// Namespace: 
private sealed class <CoDelayDispathBuddle>d__9
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object kv; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xD928C8
	public object .ctor(object <>1__state) { }

	// RVA: 0xD92AC0
	private object System.IDisposable.Dispose() { }

	// RVA: 0xD92AC4
	private object MoveNext() { }

	// RVA: 0xD92BC0
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xD92BC8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xD92C08
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallTopCommon
{

	// Fields
	private object m_MallForm; // 0x8
	private object redDotMap; // 0x10
	public object TabsInitialized; // 0x18

	// Methods

	// RVA: 0xD921D8
	public object Init() { }

	// RVA: 0xD92234
	public object UnInit() { }

	// RVA: 0xD92290
	public object OnCloseMallForm() { }

	// RVA: 0xD922F4
	public static object ShouldShowReddotForMall() { }

	// RVA: 0xD926A4
	public static object ShouldShowRedDotForTab(object tab) { }

	// RVA: 0xD92760
	public static object HasRoulette() { }

	// RVA: 0xD92810
	private static object CoDelayDispathBuddle(object kv) { }

	// RVA: 0xD928F4
	private static object OnQureyBtnClicked(object evt) { }

	// RVA: 0xD929C0
	public static object TabToRedID(object tab) { }

	// RVA: 0xD92A40
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass0_0
{

	// Fields
	public object uiEvent; // 0x8

	// Methods

	// RVA: 0xD92DB0
	public object .ctor() { }

	// RVA: 0xD92DC0
	internal object <CheckGuest>b__0() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallComponentModel
{

	// Methods

	// RVA: 0xD92C10
	public static object CheckGuest(object nextStep) { }

	// RVA: 0xD92DB8
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallGiftSystem
{

	// Fields
	public const object FormAskOrGiveGift;
	public const object FormGiveGiftConfirm;

	// Methods

	// RVA: 0xD92E34
	public object CheckSendGiftCurrencyEnough_ShowMessageBoxIfNotEnough(object mallItem) { }

	// RVA: 0xD93008
	public object GetSendGiftPayTip(object mallItem, object nickName) { }

	// RVA: 0xD93388
	private object HostIntimacyFull(object uniq) { }

	// RVA: 0xD93468
	private object HostToDayIntimacyFull(object uniq) { }

	// RVA: 0xD93548
	private object GetGiftResultText(object heroName) { }

	// RVA: 0xD93740
	public object SendGiftSuccess(object uniq) { }

	// RVA: 0xD93F2C
	public object IsGameFriends(object acntUniq) { }

	// RVA: 0xD938F4
	public object ShowGiftSendResult(object uniq, object nickName, object heroName) { }

	// RVA: 0xD94054
	public object CanSendGift(object isSend, object friendInfo, object tips) { }

	// RVA: 0xD94864
	public object IsGiftCenterHeroTabOpened() { }

	// RVA: 0xD94910
	public object IsGiftCenterHeroSkinTabOpened() { }

	// RVA: 0xD949BC
	public object IsGiftCenterItemTabOpened() { }

	// RVA: 0xD9463C
	public object GetSendGiftMinLevel() { }

	// RVA: 0xD946F4
	public object GetAskForGiftMinLevel() { }

	// RVA: 0xD947AC
	public object GetGiftMinFriendDay() { }

	// RVA: 0xD94A68
	public object GetMaxSendGiftCountPerDay() { }

	// RVA: 0xD94B20
	public object GetMaxAskForGiftCountPerDay() { }

	// RVA: 0xD94BD8
	public object GetGiftCenterMinLevel() { }

	// RVA: 0xD94C90
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass20_0
{

	// Fields
	public object job; // 0x8

	// Methods

	// RVA: 0xD962B8
	public object .ctor() { }

	// RVA: 0xD962D8
	internal object <OnUIEvent_Mall_Component_Exchange_Job_Change>b__0(object x) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallHeroSelect
{

	// Fields
	private object lst_hero_small; // 0x18
	private object lst_hero_small_data; // 0x20
	private object lst_hero_big; // 0x28
	private object lst_hero_big_data; // 0x30
	private object lst_hero_job_tabs; // 0x38
	private object btn_show_full; // 0x40
	private object img_show_full; // 0x48
	private object btn_close_full; // 0x50
	public object onChooseHero; // 0x58
	private object hero_big_list_initialized; // 0x60

	// Properties
	public object SelectedHero { get; }

	// Methods

	// RVA: 0xD94CE8
	public object get_SelectedHero() { }

	// RVA: 0xD94DD8
	private object OnEnable() { }

	// RVA: 0xD94FF0
	private object OnDisable() { }

	// RVA: 0xD95208
	private object Start() { }

	// RVA: 0xD955D8
	public object SetToShowHeroes(object heroes) { }

	// RVA: 0xD95750
	public object Deselect() { }

	// RVA: 0xD95370
	private object SetBigHeroListVisible(object v) { }

	// RVA: 0xD95B3C
	private object OnUIEvent_Mall_Component_Exchange_Hero_List_Enable(object e) { }

	// RVA: 0xD95E6C
	private object OnUIEvent_Mall_Component_Exchange_Hero_Select_Change(object e) { }

	// RVA: 0xD960C4
	private object OnUIEvent_Mall_Component_Exchange_Job_Change(object e) { }

	// RVA: 0xD957F0
	private object InitJobTabs() { }

	// RVA: 0xD962C0
	public object .ctor() { }

	// RVA: 0xD962C8
	private object <Start>b__14_0() { }

	// RVA: 0xD962D0
	private object <Start>b__14_1() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallUtil
{

	// Methods

	// RVA: 0xD9631C
	public static object OpenHeroSkinPreview(object heroId, object skinId, object avatarWears) { }

	// RVA: 0xD9643C
	public object .ctor() { }

}

// Namespace: 
public enum enMallFormWidget
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Tab;
	public const object Action_Mask;
	public const object Top_Common;
	public const object Body_Container;
	public const object Lottery_Result_Mask;
	public const object Action_Mask_Reset_Timer;
	public const object Skip_Mask;
	public const object Skip_Mask_Reset_Timer;
	public const object Update_Sub_Module_Timer;
	public const object BG;
	public const object BGFix;
	public const object SymbolCoinPanel;
	public const object ChipShopBtn;
	public const object Button_Recharge;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__45_0; // 0x8

	// Methods

	// RVA: 0xD99C80
	private static object .cctor() { }

	// RVA: 0xD99CE0
	public object .ctor() { }

	// RVA: 0xD99CE8
	internal object <Init>b__45_0(object e) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallSystem
{

	// Fields
	public static object s_payPurposeNameKeys; // 0x0
	public static object s_payTypeNameKeys; // 0x8
	public object SpecSaleController; // 0x8
	public object TopCommonListNotSelect; // 0x10
	public object TopCommonListSelect; // 0x20
	public object DontClickColor; // 0x30
	private object m_CurTab; // 0x40
	private object m_FreeDrawSymbolTimerSeq; // 0x44
	private object m_MallGotoTab; // 0x48
	private object m_MallTopCommon; // 0x50
	public object MallPriceHandler; // 0x58
	public object LuckDrawHandler; // 0x60
	public object RegisterSale; // 0x68
	public object m_PlayerRegisterTime; // 0x70
	public object DicHeroIsinRegisterSale; // 0x78
	public object DicSkinIsinRegisterSale; // 0x80
	private object <IsShowHeroExchange>k__BackingField; // 0x88
	private object <IsShowSkinExchange>k__BackingField; // 0x89
	public object IsShowRouletteChip; // 0x8A
	public object IsRouletteViewShow; // 0x8B

	// Properties
	public object PayPurposeNameKeys { get; }
	public object PayTypeNameKeys { get; }
	public object PlayerRegisterTime { get; set; }
	public object SpecSaleSystem { get; }
	public object PriceSystem { get; }
	public object MallTopCommon { get; }
	public object CurTab { get; set; }
	public object IsShowHeroExchange { get; set; }
	public object IsShowSkinExchange { get; set; }

	// Methods

	// RVA: 0xD96444
	public object get_PayPurposeNameKeys() { }

	// RVA: 0xD964F8
	public object get_PayTypeNameKeys() { }

	// RVA: 0xD965AC
	public object get_PlayerRegisterTime() { }

	// RVA: 0xD9660C
	public object set_PlayerRegisterTime(object value) { }

	// RVA: 0xD96674
	public object get_SpecSaleSystem() { }

	// RVA: 0xD966D4
	public object get_PriceSystem() { }

	// RVA: 0xD96734
	public object get_MallTopCommon() { }

	// RVA: 0xD8C750
	public object get_CurTab() { }

	// RVA: 0xD96890
	public object set_CurTab(object value) { }

	// RVA: 0xD968F8
	public object get_IsShowHeroExchange() { }

	// RVA: 0xD96900
	public object set_IsShowHeroExchange(object value) { }

	// RVA: 0xD96908
	public object get_IsShowSkinExchange() { }

	// RVA: 0xD96910
	public object set_IsShowSkinExchange(object value) { }

	// RVA: 0xD96918
	private object AllTabInit() { }

	// RVA: 0xD9698C
	private object AllTabUnInit() { }

	// RVA: 0xD96A00
	public override object Init() { }

	// RVA: 0xD9743C
	public override object UnInit() { }

	// RVA: 0xD9779C
	private object OnExpGiftGotoExp(object uiEvent) { }

	// RVA: 0xD978DC
	public object InitExchangeData() { }

	// RVA: 0xD979A0
	private object OnMallCloseForm(object uiEvent) { }

	// RVA: 0xD97C98
	private object OnConfirmBuyProduct(object uiEvent) { }

	// RVA: 0xD980C4
	private object OnMallActionMaskReset(object uiEvent) { }

	// RVA: 0xD981E4
	private object OnMallSkipMaskReset(object uiEvent) { }

	// RVA: 0xD98304
	public object ConvertHeroIdAndSkinId(object originID, object heroID, object skinID) { }

	// RVA: 0xD98488
	public object IsShowLv3Symbol() { }

	// RVA: 0xD985B4
	public object SetFreeDrawTimer() { }

	// RVA: 0xD98794
	public object SymbolFreeDrawTimerHandler(object seq) { }

	// RVA: 0xD9894C
	public object Send_Request_SymbolBuyByCoin(object symbolId, object symbolCnt) { }

	// RVA: 0xD98AF0
	private object OnUIEvent_Mall_Confirm_Buy_Item(object uiEvent) { }

	// RVA: 0xD98CF8
	public object CheckAndTryDownloadMallSubModule() { }

	// RVA: 0xD98EB8
	public object CanSendGift(object table) { }

	// RVA: 0xD990FC
	public object GetRecommendData() { }

	// RVA: 0xD99198
	public object CreateHeroSorter(object type) { }

	// RVA: 0xD992CC
	public object CreateSkinSorter(object type) { }

	// RVA: 0xD99400
	public object CreateHeroViewSorter(object type) { }

	// RVA: 0xD994C0
	public object CreateHeroCultivateSorter(object type) { }

	// RVA: 0xD995E0
	public object ShouldShowReddotForMall() { }

	// RVA: 0xD9963C
	public object InvalidateCacheByCMallBoutiqueModel() { }

	// RVA: 0xD9969C
	public object .ctor() { }

	// RVA: 0xD99960
	private static object .cctor() { }

	// RVA: 0xD99C78
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xD99C7C
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public static class ResSaleRecommendExt
{

	// Methods

	// RVA: 0xD99D6C
	public static object IsForSale(object thiz) { }

}

// Namespace: Assets.Scripts.GameSystem
public static class ResCrystalExchangeExt
{

	// Methods

	// RVA: 0xD99E44
	public static object IsForSale(object thiz) { }

}

// Namespace: 
public class ShopProduct
{

	// Fields
	private object <OnStateChange>k__BackingField; // 0x8
	private object _config; // 0x10
	private object _configItemDiscount; // 0x18
	private object _boughtCount; // 0x20

	// Properties
	public object OnStateChange { get; set; }
	public object config { get; set; }
	public object configItemDiscount { get; set; }
	public object IsExpGift { get; }
	public object HasDiscount { get; }
	public object ProductType { get; }
	public object Key { get; }
	public object DoubleKey { get; }
	public object Type { get; }
	public object ID { get; }
	public object CoinType { get; }
	private object RealDiscount { get; }
	public object ShowInMallList { get; }
	public object DiscountForShow { get; }
	public object BoughtCount { get; set; }
	public object LimitCount { get; }
	public object CanBuyCount { get; }
	public object LimitCycle { get; }
	public object RecommendIndex { get; }
	public object IsShowLimitBuy { get; }
	public object Tag { get; }
	public object LimitBuyDays { get; }
	public object LimitBuySeconds { get; }
	public object IsOnSale { get; }
	public object IsVipCanBuy { get; }
	public object MinShowVIPLevel { get; }
	public object StartVIPLvl { get; }
	public object EndVIPLvl { get; }
	public object OnSaleTime { get; }
	public object OnSaleDate { get; }
	public object OffSaleTime { get; }
	public object OffSaleDate { get; }
	public object CycleType { get; }

	// Methods

	// RVA: 0xD9F538
	public object get_OnStateChange() { }

	// RVA: 0xD9F540
	public object set_OnStateChange(object value) { }

	// RVA: 0xD9F548
	public object get_config() { }

	// RVA: 0xD9F5A8
	private object set_config(object value) { }

	// RVA: 0xD9F610
	public object get_configItemDiscount() { }

	// RVA: 0xD9F670
	private object set_configItemDiscount(object value) { }

	// RVA: 0xD9F6D8
	public object .ctor(object config) { }

	// RVA: 0xD9F704
	public object .ctor(object config, object configItemDiscount) { }

	// RVA: 0xD9F73C
	public object get_IsExpGift() { }

	// RVA: 0xD9F9A4
	public object get_HasDiscount() { }

	// RVA: 0xD9FFE0
	public static object GetExpGiftUseableList(object itemID, object heroNum, object heroSkinNum, object expDays) { }

	// RVA: 0xDA02BC
	public object GetItemDiscounts() { }

	// RVA: 0xDA0518
	public object GetUseableList() { }

	// RVA: 0xDA09EC
	public object GetUseable() { }

	// RVA: 0xDA0AFC
	public object GetPrice(object count, object buyRouletteItem) { }

	// RVA: 0xDA1AD4
	private object RouletteHasDiscount() { }

	// RVA: 0xDA0BA4
	public object GetPriceInfo(object count, object ownedAll, object isHeroSkinPack, object hasDeductPriceItem, object buyRouletteItem) { }

	// RVA: 0xDA1D00
	public object GetPriceText(object count) { }

	// RVA: 0xDA2360
	public object GetOldPrice(object count) { }

	// RVA: 0xDA29F0
	public object GetOldPriceText(object count) { }

	// RVA: 0xDA30C4
	public object get_ProductType() { }

	// RVA: 0xDA22EC
	public object get_Key() { }

	// RVA: 0xDA3138
	public object get_DoubleKey() { }

	// RVA: 0xD9F8BC
	public object get_Type() { }

	// RVA: 0xD9F930
	public object get_ID() { }

	// RVA: 0xD9FCD4
	public object get_CoinType() { }

	// RVA: 0xD9FD48
	private object get_RealDiscount() { }

	// RVA: 0xDA3208
	public object get_ShowInMallList() { }

	// RVA: 0xDA1B8C
	public object ConvertWithRealDiscount(object cost) { }

	// RVA: 0xDA1C24
	public static object SConvertWithRealDiscount(object cost, object realDiscount) { }

	// RVA: 0xDA3284
	public object GetSpecSaleIconPath() { }

	// RVA: 0xDA33F8
	public object get_DiscountForShow() { }

	// RVA: 0xDA34D0
	public object get_BoughtCount() { }

	// RVA: 0xDA3530
	public object set_BoughtCount(object value) { }

	// RVA: 0xDA35C8
	public object get_LimitCount() { }

	// RVA: 0xDA363C
	public object get_CanBuyCount() { }

	// RVA: 0xDA37E4
	public object get_LimitCycle() { }

	// RVA: 0xDA3868
	public object get_RecommendIndex() { }

	// RVA: 0xDA38DC
	public object get_IsShowLimitBuy() { }

	// RVA: 0xDA3958
	public object get_Tag() { }

	// RVA: 0xDA39CC
	public object get_LimitBuyDays() { }

	// RVA: 0xDA3E30
	public object get_LimitBuySeconds() { }

	// RVA: 0xDA4058
	public object get_IsOnSale() { }

	// RVA: 0xDA482C
	public object get_IsVipCanBuy() { }

	// RVA: 0xDA498C
	public object get_MinShowVIPLevel() { }

	// RVA: 0xDA4A30
	public object get_StartVIPLvl() { }

	// RVA: 0xDA4AD4
	public object get_EndVIPLvl() { }

	// RVA: 0xDA4B78
	public object get_OnSaleTime() { }

	// RVA: 0xDA3CB8
	public object get_OnSaleDate() { }

	// RVA: 0xDA4EC4
	public object get_OffSaleTime() { }

	// RVA: 0xDA3D74
	public object get_OffSaleDate() { }

	// RVA: 0xDA5210
	public object get_CycleType() { }

	// RVA: 0xDA5284
	public object CanBuy() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__19_0; // 0x8

	// Methods

	// RVA: 0xDA5DA8
	private static object .cctor() { }

	// RVA: 0xDA5E08
	public object .ctor() { }

	// RVA: 0xDA5E10
	internal object <GetShopProductByMallTabType>b__19_0(object product1, object product2) { }

}

// Namespace: 
private sealed class <>c__DisplayClass13_0
{

	// Fields
	public object theSp; // 0x8
	public object from; // 0x10
	public object newUiEvent; // 0x18

	// Methods

	// RVA: 0xDA6140
	public object .ctor() { }

	// RVA: 0xDA6148
	internal object <OnProductBuy>b__0(object c) { }

}

// Namespace: 
private sealed class <>c__DisplayClass13_1
{

	// Fields
	public object c; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0xDA6350
	public object .ctor() { }

	// RVA: 0xDA6358
	internal object <OnProductBuy>b__1() { }

}

// Namespace: 
private sealed class <>c__DisplayClass22_0
{

	// Fields
	public object theSp; // 0x8
	public object from; // 0x10
	public object isDirectPay; // 0x14

	// Methods

	// RVA: 0xDA6410
	public object .ctor() { }

	// RVA: 0xDA6418
	internal object <StartShopProduct>b__0(object c) { }

}

// Namespace: 
private sealed class <>c__DisplayClass22_1
{

	// Fields
	public object c; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0xDA6620
	public object .ctor() { }

	// RVA: 0xDA6628
	internal object <StartShopProduct>b__1() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMallSpecSaleController
{

	// Fields
	private object m_TotalSpList; // 0x8
	private object m_TotalSpDict; // 0x10
	private object m_SaleOffSpList; // 0x18
	private object m_SaleOffSpDict; // 0x20
	private object refreshTotalProductDataTimer; // 0x28
	private object heroSkinProductInfo; // 0x30

	// Properties
	public object TotalSpList { get; }

	// Methods

	// RVA: 0xD8C164
	public object get_TotalSpList() { }

	// RVA: 0xD97134
	public object Init() { }

	// RVA: 0xD96EBC
	public object UnInit() { }

	// RVA: 0xD99F1C
	public object ClearData() { }

	// RVA: 0xD9A054
	private object ResetLimitBuyDaily() { }

	// RVA: 0xD9AC48
	public object OnProductBuy(object theSp, object eventID, object from) { }

	// RVA: 0xD9BB38
	private object ResetSaleOffSpListByStatus(object status, object sp) { }

	// RVA: 0xD97DB4
	public object GetProduct(object key) { }

	// RVA: 0xD9BFBC
	public object GetShopProductByType(object type) { }

	// RVA: 0xD9C300
	public object GetShopProductByTypeIncludeSaleLimit(object type) { }

	// RVA: 0xD9C778
	public object GetShopProductByIds(object ids) { }

	// RVA: 0xD9CB08
	public object GetShopProductByMallTabType(object mallTabType) { }

	// RVA: 0xD9D354
	public object GetProductByItemID(object itemId) { }

	// RVA: 0xD9D618
	public object GetProductByItemID(object id, object costType) { }

	// RVA: 0xD8DAE4
	public object StartShopProduct(object theSp, object fromType, object isDirectPay) { }

	// RVA: 0xD9D8F8
	public object OnReflowNewbieShopBuyHeroSkin(object uiEvent) { }

	// RVA: 0xD9DA44
	public object GetSaleIffSpByID(object id) { }

	// RVA: 0xD98C28
	public object GetTotalSpByID(object id) { }

	// RVA: 0xD9DB14
	private object OnSpecalSaleConfigReady() { }

	// RVA: 0xD9DB74
	private object OnValorPassStateChanged(object obj) { }

	// RVA: 0xD9A644
	public object RefreshTotalProductData() { }

	// RVA: 0xD9E18C
	private object OnTimerRefreshTotalProductData(object timerSequence) { }

	// RVA: 0xD9DBDC
	private object ResetProductByStatus(object sp) { }

	// RVA: 0xD9B208
	public object BuyShopProduct(object shopProduct, object count, object needConfirm, object uiEvent, object from, object isRouletteBuy, object isDirectPay) { }

	// RVA: 0xD9E1F4
	private object BuyLimitProduct(object theSp) { }

	// RVA: 0xD9E394
	private object OnBuyReturn(object msg, object AwardOKEvent) { }

	// RVA: 0xD9EF3C
	public object UpdateInfo(object msg) { }

	// RVA: 0xD9F1D4
	public static object OnInitialSpecSaleInfo(object msg) { }

	// RVA: 0xD97E34
	public object RequestBuy(object shopProduct, object count, object _from) { }

	// RVA: 0xD9F2B8
	public static object OnRecv_SCID_CMD_DIRECT_PAY(object msg) { }

	// RVA: 0xD9F3D4
	public static object OnBuySpecSaleRsp(object msg) { }

	// RVA: 0xD99860
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CHeroSkinProductInfo
{

	// Fields
	private object <product>k__BackingField; // 0x8
	private object <from>k__BackingField; // 0x10
	private object <IsDirectPay>k__BackingField; // 0x14

	// Properties
	public object product { get; set; }
	public object from { get; set; }
	public object IsDirectPay { get; set; }

	// Methods

	// RVA: 0xDA66E0
	public object get_product() { }

	// RVA: 0xDA66E8
	public object set_product(object value) { }

	// RVA: 0xDA66F0
	public object get_from() { }

	// RVA: 0xDA66F8
	public object set_from(object value) { }

	// RVA: 0xDA6700
	public object get_IsDirectPay() { }

	// RVA: 0xDA6708
	public object set_IsDirectPay(object value) { }

	// RVA: 0xDA6710
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMoWenSystem
{

	// Methods

	// RVA: 0xDA6718
	public override object Init() { }

	// RVA: 0xDA6BD8
	public object GetMoWenSkillSeries(object skillId) { }

	// RVA: 0xDA6DEC
	public object GetPrimeSmallBgLobbyPath_s(object series) { }

	// RVA: 0xDA6FD8
	public object GetMoWenIconBattlePath_s(object moWenId, object isSmallIcon) { }

	// RVA: 0xDA71F8
	public object GetSeriesIconBattlePath_s(object series, object isPrimary) { }

	// RVA: 0xDA741C
	public object GetViceSmallBgLobbyPath_s(object series) { }

	// RVA: 0xDA7608
	public object IsMoWenSysEnabledForCurLevel(object player) { }

	// RVA: 0xDA7940
	public object .ctor() { }

	// RVA: 0xDA7998
	public object <>iFixBaseProxy_Init() { }

}

// Namespace: 
public class PairSeriesLayer
{

	// Fields
	public object series; // 0x8
	public object layer; // 0xC
	public object forbidden; // 0x10

	// Methods

	// RVA: 0xDA799C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMoWenDataCenter
{

	// Fields
	private static object s_MoWenTable; // 0x0
	private static readonly object s_Color_MoWen_Red; // 0x8
	private static readonly object s_Color_MoWen_Yellow; // 0x18
	private static readonly object s_Color_MoWen_Blue; // 0x28
	private static readonly object s_Color_MoWen_Green; // 0x38

	// Methods

	// RVA: 0xDA6804
	public static object LoadMoWenTable(object moWenSeriesCfg) { }

	// RVA: 0xDA6C98
	public static object GetMoWenSkillSeries(object skillId) { }

	// RVA: 0xDA79A4
	public static object GetSeriesColor_s(object series) { }

	// RVA: 0xDA6EAC
	public static object GetPrimeSmallBgLobbyPath_s(object series) { }

	// RVA: 0xDA70A8
	public static object GetMoWenIconBattlePath_s(object moWenId, object isSmallIcon) { }

	// RVA: 0xDA72C8
	public static object GetSeriesIconBattlePath_s(object series, object isPrimary) { }

	// RVA: 0xDA7CC8
	public static object GetMoWenSkillCfg(object id) { }

	// RVA: 0xDA74DC
	public static object GetViceSmallBgLobbyPath_s(object series) { }

	// RVA: 0xDA7B88
	private static object FindName(object series) { }

	// RVA: 0xDA76C8
	public static object IsMoWenSysEnabledForCurLevel(object player) { }

	// RVA: 0xDA7D90
	public static object GetSeriesName_s(object series) { }

	// RVA: 0xDA7E80
	public static object IsMoWenForbidden(object id) { }

	// RVA: 0xDA7FD8
	public object .ctor() { }

	// RVA: 0xDA7FE0
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMoWenView_AssembledItem
{

	// Fields
	public object m_PrimarySkillIcon; // 0x78
	public object m_LeftIcon; // 0x80
	public object m_RightIcon; // 0x88
	public object m_PrimeBg; // 0x90
	public object m_LeftBg; // 0x98
	public object m_RightBg; // 0xA0
	public object m_PrimaryNameText; // 0xA8
	public object m_LeftNameText; // 0xB0
	public object m_RightNameText; // 0xB8
	public object m_ForbiddenGo; // 0xC0
	public object m_UseBigBg; // 0xC8

	// Methods

	// RVA: 0xDA80A0
	public override object Show(object moWenIds) { }

	// RVA: 0xDA8C9C
	private object Reset() { }

	// RVA: 0xDA8CF8
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CMoWenView_SkillDesc
{

	// Fields
	private object m_SkillIconGo; // 0x78
	private object m_SkillSeriesIconGo; // 0x80
	private object m_SkillSeriesBgList; // 0x88
	private object m_ForbiddenGo; // 0x90
	private object m_SkillName; // 0x98
	private object m_SkillSeriesName; // 0xA0
	private object m_SkillSeriesNameList; // 0xA8
	private object m_SkillDesc; // 0xB0
	private object m_IsSmall; // 0xB8

	// Methods

	// RVA: 0xDA8D00
	public override object Show(object moWenId) { }

	// RVA: 0xDA93D8
	public override object Hide() { }

	// RVA: 0xDA9454
	public object .ctor() { }

	// RVA: 0xDA945C
	public object <>iFixBaseProxy_Hide() { }

}

// Namespace: Assets.Scripts.GameSystem
public enum enOnCallType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ShowOnePvpHistory;
	public const object Null;
}

// Namespace: Assets.Scripts.GameSystem
public struct stOnCall
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object arg0; // 0x0
	public object arg1; // 0x8
	public object arg2; // 0x10
	public object arg3; // 0x18
}

// Namespace: Assets.Scripts.GameSystem
public class CPlayerRecordOperation
{

	// Fields
	public object DeskID; // 0x8
	public object DeskSeq; // 0xC
	public object PlayerUid; // 0x10
	public object PlayerLogicWorldID; // 0x18
	public object IsComplaint; // 0x1C
	public object IsAddMatchBlack; // 0x1D

	// Methods

	// RVA: 0xDA9464
	public object .ctor() { }

}

// Namespace: 
public struct GenderInfo
{

	// Fields
	public object GenderName; // 0xFFFFFFFFFFFFFFF8
	public object IconPath; // 0x0

	// Properties
	public object IconResPath { get; }

	// Methods

	// RVA: 0xDC0FE8
	public object get_IconResPath() { }

}

// Namespace: 
private class HeroLegendTitleInfo
{

	// Fields
	public object bTitleFlag; // 0x8
	public object nTitleCount; // 0xA
	public object dwFirstGetTime; // 0xC

	// Methods

	// RVA: 0xDC1108
	public object .ctor() { }

}

// Namespace: 
private class HeroLegendTitleHeroInfo
{

	// Fields
	public object dwHeroID; // 0x8
	public object lstTitleInfo; // 0x10
	public object dwMaxLegendValue; // 0x18
	public object dwTopRankNo; // 0x1C
	public object dwAdCode; // 0x20
	public object wTitleLv; // 0x24

	// Methods

	// RVA: 0xDC1110
	public object .ctor() { }

}

// Namespace: 
private struct HeroTitleInfo
{

	// Fields
	public object TitleLv; // 0xFFFFFFFFFFFFFFF8
	public object Num; // 0xFFFFFFFFFFFFFFFC
	public object FirstGotDate; // 0x0

	// Methods

	// RVA: 0xDC11A8
	public object .ctor(object titleLv, object num, object firstGotDate) { }

}

// Namespace: 
private sealed class <ReqSendNotAsianHistory>d__201
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xDC11C0
	public object .ctor(object <>1__state) { }

	// RVA: 0xDC11EC
	private object System.IDisposable.Dispose() { }

	// RVA: 0xDC11F0
	private object MoveNext() { }

	// RVA: 0xDC1300
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xDC1308
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xDC1348
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CPlayerInfoSystems
{

	// Fields
	public const object PlAYER_INFO_RULE_ID;
	private object _lastDetailSource; // 0x8
	public object isShowPlayerInfo; // 0xC
	private static object punishInfoList; // 0x0
	private object szPlayerHideCommonHerosTip; // 0x10
	private object _filteredMostUsedHeroList; // 0x18
	private object rankBrandHistoryLst; // 0x20
	public object m_bBattleState; // 0x28
	public object HasNewFightRecord; // 0x29
	private object m_OuterInviteCode; // 0x30
	public object OpenInviteCode; // 0x38
	public object CachesShareHeroID; // 0x3C
	public object CacheHeroShareType; // 0x40
	public static readonly object sPlayerInfoFormPath; // 0x8
	public static readonly object sPlayerInfoFormMorePath; // 0x10
	public static object sPunishRecordFormPath; // 0x18
	public static readonly object sPlayerInfoFormAsianPath; // 0x20
	private object m_SysEntryForm; // 0x48
	public const object CREDIT_RULE_ID;
	public static readonly object LEGEND_RULE_ID; // 0x28
	private object m_PlayerProfile; // 0x50
	public object m_lstProfession; // 0x58
	public object m_lstWeekDay; // 0x60
	public object m_lstDayTime; // 0x68
	public object m_lastShowPlayerInfoProfile; // 0x70
	public object m_lastShowPlayerProfile; // 0x78
	private object m_InfoPageMode; // 0x80
	private object m_lstGender; // 0x88
	private object _BattleModeFunc; // 0x90
	private object m_bOpenVisitingCard; // 0x94
	private object isTriggerInfoGuide; // 0x95
	private object m_lastMomentSubIndex; // 0x98
	private object m_lastMomentDetailInfo; // 0xA0
	public static object sHeadTab; // 0x30
	public static object sHeadFrameTab; // 0x38
	public static object sHeadPendaTab; // 0x40
	private static object sGenderSetRedDot; // 0x48
	private object m_RankTitleDataDic; // 0xC0
	private object m_SortLstRankInfo; // 0xC8
	private object m_PlaceID; // 0xD0
	private object m_RegionForm; // 0xD8
	public const object REGION_SELECT_FORM_PATH;
	private object _Pos0IgnID; // 0xE0
	private object _Pos1IgnID; // 0xE4
	private object _PosStr; // 0xE8
	private object _hasReportedPvpInfoSrollEvent; // 0xF0
	public object mPlayerRecordOperations; // 0xF8

	// Properties
	public object InviteCode { get; }
	public object mForm { get; }
	public object InfoPageMode { get; }
	public object OpenVistingCard { get; }
	private object mTitleList { get; }
	private object IPlayerSystem.m_lstProfession { get; }
	private object IPlayerSystem.m_lstWeekDay { get; }
	private object IPlayerSystem.m_lstDayTime { get; }

	// Methods

	// RVA: 0xDA946C
	public object GetMostUsedHeroList() { }

	// RVA: 0xDA94CC
	public object SetHasNewFightRecord(object have) { }

	// RVA: 0xDA9534
	public object ShowPlayerDetailInfo(object ullUid, object iLogicWorldId, object sourceType, object initTab, object subIndex) { }

	// RVA: 0xDA964C
	public static object IsInNewbieGuide() { }

	// RVA: 0xDA97C0
	public object IsNewbieGuideCompleteFinish() { }

	// RVA: 0xDA98A4
	public object get_InviteCode() { }

	// RVA: 0xDA9904
	public object StartBattle() { }

	// RVA: 0xDA9968
	private object _OpenInviteCode() { }

	// RVA: 0xDA9C68
	public object ProcessInviteCodeIntent(object tInviteCode) { }

	// RVA: 0xDA9D70
	public object CheckInviteCode() { }

	// RVA: 0xDA9E18
	public object ResPlyaerDetailInfo(object msg) { }

	// RVA: 0xDAA3AC
	public static object ResMostHeroShare(object msg) { }

	// RVA: 0xDAA9CC
	private static object OnShareHeroNty(object evt) { }

	// RVA: 0xDAABC4
	public object MsgUpdateFriendCard(object tInfo) { }

	// RVA: 0xDAAC74
	public object UpdatePlayerInfoPrivacy(object inAllBits) { }

	// RVA: 0xDA9FCC
	public object ImpResDetailInfo(object msg) { }

	// RVA: 0xDAAE3C
	public object get_mForm() { }

	// RVA: 0xDAAF68
	public object get_InfoPageMode() { }

	// RVA: 0xDAAFC8
	public override object Init() { }

	// RVA: 0xDACE44
	public override object UnInit() { }

	// RVA: 0xDAD900
	public object GetProfile() { }

	// RVA: 0xDAD960
	public object OpenPvpInfo() { }

	// RVA: 0xDAD9D4
	public object OpenBaseInfo() { }

	// RVA: 0xDADA48
	public object CloseForm() { }

	// RVA: 0xDADAEC
	public object SetMode(object mode) { }

	// RVA: 0xDADB54
	private object OnChangeMomentSubIndex(object uiEvent) { }

	// RVA: 0xDADBD0
	private object OnChangeMomentDetailInfo(object uiEvent) { }

	// RVA: 0xDACB84
	private object _CreateGenderInfo() { }

	// RVA: 0xDADC64
	public object GetGenderInfo() { }

	// RVA: 0xDADCC4
	private object OpenByQQVIP(object uiEvent) { }

	// RVA: 0xDAE02C
	private object UpdatePlayerData() { }

	// RVA: 0xDAE14C
	private object OnPlayerInfoOpenPvpInfo(object uiEvent) { }

	// RVA: 0xDAE1FC
	private object OnPlayerInfoOpenBaseInfo(object uiEvent) { }

	// RVA: 0xDAE2AC
	private object OnPlayerInfoQuitGame(object uiEvent) { }

	// RVA: 0xDAE3C4
	private object OnPlayerInfoQuitGameConfirm(object uiEvent) { }

	// RVA: 0xDAE430
	private object OnPlayerInfoMostUsedHeroItemEnable(object uiEvent) { }

	// RVA: 0xDAEE3C
	private object OnPlayerInfoMostUsedHeroItemClick(object uiEvent) { }

	// RVA: 0xDAEF70
	public object GetSeasonFunc() { }

	// RVA: 0xDAF028
	public object GetBattleModeFunc() { }

	// RVA: 0xDAF088
	public object SeasonToStr(object season) { }

	// RVA: 0xDAF1D4
	public object BattleModeToStr(object season) { }

	// RVA: 0xDABC30
	private object reloadTexts() { }

	// RVA: 0xDAF424
	private object OnCommonHeroShowDesc(object uiEvent) { }

	// RVA: 0xDAF4DC
	private object OnPlayerInfoShowRule(object uiEvent) { }

	// RVA: 0xDAF7AC
	private object GetLadderCreditScore() { }

	// RVA: 0xDAF854
	private object GetPVPCreditScore() { }

	// RVA: 0xDAF8FC
	private object OnRankHeroClick(object uiEvent) { }

	// RVA: 0xDAE81C
	public object SetHeroItemData(object formScript, object listItem, object heroInfo) { }

	// RVA: 0xDAFA0C
	public object IsNeedHideGameInfo() { }

	// RVA: 0xDAFB40
	public object IsNeedHideMostUsedHeros() { }

	// RVA: 0xDAFC74
	public object get_OpenVistingCard() { }

	// RVA: 0xDAFCD4
	private object get_mTitleList() { }

	// RVA: 0xDAFD90
	private object IPlayerSystem.get_m_lstProfession() { }

	// RVA: 0xDAFE14
	private object IPlayerSystem.get_m_lstWeekDay() { }

	// RVA: 0xDAFE98
	private object IPlayerSystem.get_m_lstDayTime() { }

	// RVA: 0xDAFF1C
	private object OnCommonHeroItemEnable(object uiEvent) { }

	// RVA: 0xDAFF80
	public object GetLegendValue_Lua(object commonInfo) { }

	// RVA: 0xDB0078
	private object GetLegendValue(object commonInfo, object legendCount, object legendDesc) { }

	// RVA: 0xDB0208
	public object GetWinRate_Lua(object commonInfo) { }

	// RVA: 0xDB02DC
	private object GetWinRate(object commonInfo, object winNum, object totalNum) { }

	// RVA: 0xDB0C28
	public static object COMGameType2Index(object detail, object type) { }

	// RVA: 0xDB0CF4
	public static object COMGameType2Index(object detail, object type) { }

	// RVA: 0xDAA8EC
	public object isSelf(object playerUllUID) { }

	// RVA: 0xDB0DC0
	public object GetCurrentShowIsSelf() { }

	// RVA: 0xDB0E38
	public object IsTabRedDotNeed(object tab, object bForceSelf) { }

	// RVA: 0xDB1108
	private object UpdateHead() { }

	// RVA: 0xDB124C
	public object HasHeadFlag() { }

	// RVA: 0xDB1440
	private object UpdateMostHeroList() { }

	// RVA: 0xDB16B4
	public object ChangeLegendGISStateNetReq() { }

	// RVA: 0xDB1798
	private object OnPlayerLegendShareFormClose(object uiEvent) { }

	// RVA: 0xDB184C
	private object IsNeedHideLegendTitleGIS() { }

	// RVA: 0xDB18B8
	private object OnRegionDataUpdate() { }

	// RVA: 0xDB1914
	private object OnUsedLegendTitleUpdate() { }

	// RVA: 0xDB1970
	private object OnDetailBrandClick(object uiEvent) { }

	// RVA: 0xDB1A50
	public object ToRoman(object number) { }

	// RVA: 0xDB1CC0
	private object OpenGameLegendTitle() { }

	// RVA: 0xDB1D1C
	private object _UpdateTitleInfo() { }

	// RVA: 0xDB1D78
	private object OnSelectedRegion(object iRegionID) { }

	// RVA: 0xDB1EB4
	private object OnRemarkChange(object id, object remark) { }

	// RVA: 0xDB1F9C
	private object OnPlayerInfoEditeOKVisitingCardClick(object uiEvent) { }

	// RVA: 0xDB2928
	private object OnPlayerInfoEditePlaceIDClick(object uiEvent) { }

	// RVA: 0xDB3110
	private object OnPlayerInfoHideVisitingCardClick(object uiEvent) { }

	// RVA: 0xDB326C
	private object OnPlayerInfoHideVisitingCardComformClick(object uiEvent) { }

	// RVA: 0xDB3344
	private object OnPlayerInfoEditeVisitingCardRegionClick(object uiEvent) { }

	// RVA: 0xDB36A4
	public object SetPos0IgnID(object sltID) { }

	// RVA: 0xDB370C
	public object SetPos1IgnID(object sltID) { }

	// RVA: 0xDB2818
	private object _GetPos0IDFromSelectIndex(object sltID) { }

	// RVA: 0xDB3774
	private object _GetPos0SelectIndexFromID(object hero0ID) { }

	// RVA: 0xDB28A0
	private object _GetPos1IDFromSelectIndex(object sltID) { }

	// RVA: 0xDB37EC
	private object _GetPos1SelectIndexFromID(object hero1ID) { }

	// RVA: 0xDB3864
	private object _GetPos0StrList() { }

	// RVA: 0xDB3B38
	private object _GetPos1StrList() { }

	// RVA: 0xDB3E0C
	private object OnPlayerInfoHideVisitingCardPos1Select(object uiEvent) { }

	// RVA: 0xDB4330
	private object OnPlayerInfoHideVisitingCardPos2Select(object uiEvent) { }

	// RVA: 0xDB484C
	private object OnPlayerInfoCardAddFriend(object uiEvent) { }

	// RVA: 0xDB49AC
	public object MsgUpdateGender(object tInfo) { }

	// RVA: 0xDB4AB8
	public static object SendChangeGender(object gender) { }

	// RVA: 0xDB4BE4
	public object HomePageAccuse(object _PlayerProfile) { }

	// RVA: 0xDB4F48
	public static object RspHomePageAccuse(object msg) { }

	// RVA: 0xDB51AC
	private object OnPlayerInfoPunishRecordListSelect(object uiEvent) { }

	// RVA: 0xDB54A4
	private object OnPlayerInfoShareHeroTip(object uiEvent) { }

	// RVA: 0xDB5524
	private object OnGoToPersonalProfile(object uiEvent) { }

	// RVA: 0xDB582C
	private object OnPlayerInfoHideVisitingCardPos1Press(object uiEvent) { }

	// RVA: 0xDB5BB8
	private object OnPlayerInfoHideVisitingCardPos2Press(object uiEvent) { }

	// RVA: 0xDB5F44
	private object OnPlayerInfoHideVisitingCardWeekdayPress(object uiEvent) { }

	// RVA: 0xDB62E0
	private object OnPlayerInfoHideVisitingCardDaytimePress(object uiEvent) { }

	// RVA: 0xDB666C
	private object _SetPvpRankInfo(object pvpRankGo, object winCnt, object totalCnt) { }

	// RVA: 0xDB6B04
	private object OnShowLegendTitlePanelFromBasic() { }

	// RVA: 0xDB6BC8
	private object UpdateMiniRaceFightInfo(object root) { }

	// RVA: 0xDB6CE4
	private object UpdatePvPTinyArenaFightInfo(object root) { }

	// RVA: 0xDB707C
	private object UpdatePvPBianShenFightInfo(object root) { }

	// RVA: 0xDB7198
	private object UpdatePvPBianShenPlusFightInfo(object root) { }

	// RVA: 0xDB72B4
	private object UpdatePvPRaceFightInfo(object root) { }

	// RVA: 0xDB787C
	private object UpdatePvPCloneFightInfo(object root) { }

	// RVA: 0xDB7998
	private object UpdatePvPFootballInfo(object root) { }

	// RVA: 0xDB7BCC
	private object UpdatePvp10v10Info(object root) { }

	// RVA: 0xDB7E00
	private object UpdatePvPFiveCampInfo(object root) { }

	// RVA: 0xDB819C
	private object UpdatePvPAchievement(object root) { }

	// RVA: 0xDB843C
	private object SetAchievementCount(object root, object path, object count) { }

	// RVA: 0xDB8610
	private object SetPvpInfoSrollEvent(object root) { }

	// RVA: 0xDB87B0
	private object ReportPvpInfoScrollEvent(object v) { }

	// RVA: 0xDB8890
	public object SetMasterPvPDataWhenGameSettle(object gameInfo) { }

	// RVA: 0xDB9B78
	private object CopyPlayerHistoryData(object uiEvent) { }

	// RVA: 0xDBEAD0
	public object CheckAndSendRelationDetailReq() { }

	// RVA: 0xDBF160
	public object ResGetIntimacyShowDetailInfo(object msg) { }

	// RVA: 0xDBF668
	public object IsBehaviourScoreOpen() { }

	// RVA: 0xDBF714
	public static object IsBehaviourScoreShowOpen() { }

	// RVA: 0xDBF7B8
	public object GetPlayerEquipListNormal(object kda) { }

	// RVA: 0xDBF878
	public static object GetPlayerEquipList(object kda) { }

	// RVA: 0xDBFC58
	public static object GetPlayerRandomTalentList(object kda) { }

	// RVA: 0xDBFF00
	public object OnTestGetPlayerRandomTalentList(object cUIEvent) { }

	// RVA: 0xDBFFE8
	public static object GetNationForCamp(object data, object cmp) { }

	// RVA: 0xDC00B8
	public object GetPlayerRecordOperation(object DeskID, object DeskSeq, object PlayerUid, object PlayerLogicWorldID) { }

	// RVA: 0xDC02F8
	public object RemovePlayerRecordOperation(object DeskID, object DeskSeq) { }

	// RVA: 0xDC044C
	public object GetCroleInfoByIndex(object index) { }

	// RVA: 0xDC0500
	public object SetCroleInfo(object roleInfo) { }

	// RVA: 0xDC066C
	public object ClearCroleInfoList() { }

	// RVA: 0xDC0728
	public object RemoveCroleInfoLastOne() { }

	// RVA: 0xDC07D8
	public object GetReturnPlayerProfile() { }

	// RVA: 0xDC0838
	public object SetReturnPlayerProfile(object roleInfo) { }

	// RVA: 0xDC08A0
	public object ClearReturnPlayerProfile() { }

	// RVA: 0xDC0900
	public object StarCoroutineReqSendNotAsianHistory(object isBaseInfo) { }

	// RVA: 0xDC09CC
	public object ReqSendNotAsianHistory(object isBaseInfo) { }

	// RVA: 0xDC0A80
	public object .ctor() { }

	// RVA: 0xDC0CF8
	private static object .cctor() { }

	// RVA: 0xDC0E3C
	private object <UpdateMostHeroList>b__112_0(object x1, object x2) { }

	// RVA: 0xDC0F30
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDC0F34
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CLightDarkDuel
{

	// Fields
	public const object s_MainCityPath;
	private object m_Form; // 0x8

	// Methods

	// RVA: 0xDC1350
	public object InitUI() { }

	// RVA: 0xDC1450
	public object UnInitUI() { }

	// RVA: 0xDC1550
	public object Open() { }

	// RVA: 0xDC1878
	public object OnCloseForm(object uiEvent) { }

	// RVA: 0xDC18E0
	public object Close() { }

	// RVA: 0xDC19E0
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CLightDarkDuelControl
{

	// Fields
	private object mView; // 0x8

	// Methods

	// RVA: 0xDC19E8
	public object .ctor() { }

	// RVA: 0xDC1A6C
	public override object Init() { }

	// RVA: 0xDC1B98
	public object OnLightDarkDuelOpen(object uiEvent) { }

	// RVA: 0xDC1D0C
	public override object UnInit() { }

	// RVA: 0xDC1C9C
	public object OpenView() { }

	// RVA: 0xDC1E40
	public object CloseView() { }

	// RVA: 0xDC1EAC
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDC1EB0
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CMainCityControl
{

	// Fields
	private object mView; // 0x8

	// Methods

	// RVA: 0xDC1EB4
	public object .ctor() { }

	// RVA: 0xDC1F40
	public override object Init() { }

	// RVA: 0xDC206C
	public object OnCultivateMainCityOpen(object uiEvent) { }

	// RVA: 0xDC2534
	public override object UnInit() { }

	// RVA: 0xDC24C4
	public object OpenView() { }

	// RVA: 0xDC29A8
	public object CloseView() { }

	// RVA: 0xDC2B14
	public static object SendGuideRewardReq() { }

	// RVA: 0xDC2BF8
	public static object OnGuideRewardRsp(object msg) { }

	// RVA: 0xDC2FAC
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDC2FB0
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CMainCityView
{

	// Fields
	public const object s_MainCityPath;
	private const object s_SubMainCityBg;
	private object m_Form; // 0x8

	// Methods

	// RVA: 0xDC2FB4
	public object InitUI() { }

	// RVA: 0xDC3824
	public object UnInitUI() { }

	// RVA: 0xDC3BEC
	public object InitRedDot() { }

	// RVA: 0xDC2668
	public object Open() { }

	// RVA: 0xDC3F88
	public object OnCloseForm(object uiEvent) { }

	// RVA: 0xDC2A14
	public object Close() { }

	// RVA: 0xDC3FF0
	public object OnCultivateEntryClick(object uiEvent) { }

	// RVA: 0xDC372C
	public object ShowGuide() { }

	// RVA: 0xDC419C
	public object OnHelpClick(object uiEvent) { }

	// RVA: 0xDC4204
	public object OnIntroduceFinished(object uiEvent) { }

	// RVA: 0xDC42E8
	private object OnTaskRedPoint(object num) { }

	// RVA: 0xDC4460
	public object OnBagRedDotUpdate() { }

	// RVA: 0xDC465C
	public object OnPlayClick(object uiEvent) { }

	// RVA: 0xDC34E0
	public object InitOpenBagEventParam() { }

	// RVA: 0xDC22DC
	public static object IsIMBAModeEnable() { }

	// RVA: 0xDC4888
	public static object IsPlentyModeEnable() { }

	// RVA: 0xDC3654
	private object InitWidgetStatus() { }

	// RVA: 0xDC4BE0
	private object RefreshBgStatus() { }

	// RVA: 0xDC49A8
	private object RefreshStartButton() { }

	// RVA: 0xDC4E18
	private object SetButtonTimeEnableStatus(object status, object timeTips) { }

	// RVA: 0xDC1F38
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CHeroCultivateDetailView
{

	// Fields
	public const object ShowDetailPrefabPath;
	public object mHeroId; // 0x8
	private object mculInfo; // 0x10

	// Methods

	// RVA: 0xDC5300
	public override object Init() { }

	// RVA: 0xDC546C
	public override object UnInit() { }

	// RVA: 0xDC55D8
	public object OnOpenForm(object uiEvent) { }

	// RVA: 0xDC5F3C
	public object OnCloseForm(object uiEvent) { }

	// RVA: 0xDC5850
	public object InitSkillList(object form) { }

	// RVA: 0xDC6038
	public object .ctor() { }

	// RVA: 0xDC6090
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDC6094
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
public enum CONTROL_STATUS
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object STATUS_NOTACTIVE;
	public const object STATUS_ACTIVE;
	public const object STATUS_SELECTED;
}

// Namespace: 
public enum PROGRESS_STATUS
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object STATUS_NORMAL;
	public const object STATUS_RUNNING;
}

// Namespace: Assets.Scripts.GameSystem
public class CHeroCultivatePageView
{

	// Fields
	public const object HeroCultivatePagePrefabPath;
	public object mShowHeroId; // 0x8
	public object mSelectSkillIndex; // 0xC
	public object mCurLevel; // 0x10
	public object mCurExp; // 0x14
	public object mNeedExp; // 0x18
	public object mIsUpdateToMax; // 0x1C
	public object mdwBaseExp; // 0x20
	public object mdwActualExp; // 0x24
	public object goExpText; // 0x28
	public object goProgress; // 0x30
	public object goProgress_1; // 0x38
	public object goProgress_Glow; // 0x40

	// Methods

	// RVA: 0xDC6098
	public override object Init() { }

	// RVA: 0xDC6460
	public override object UnInit() { }

	// RVA: 0xDC6828
	public object OnCloseForm(object uiEvent) { }

	// RVA: 0xDC6924
	public object OpenForm(object uiEvent) { }

	// RVA: 0xDC72D4
	public object OnShowDetail(object uiEvent) { }

	// RVA: 0xDC73DC
	public object OnTryPlay(object uiEvent) { }

	// RVA: 0xDC75B0
	public object OnTryPlayComfirm(object uiEvent) { }

	// RVA: 0xDC7F0C
	public object GetStarCoinNeed() { }

	// RVA: 0xDC7FBC
	public object GetExpNeed(object level) { }

	// RVA: 0xDC80B8
	public object ShowExpAddEffect(object goElement) { }

	// RVA: 0xDC830C
	public object InitUpgradeBtn(object form) { }

	// RVA: 0xDC884C
	public object InitTitleLvInfo(object form, object level) { }

	// RVA: 0xDC8990
	public object InitLevelNumObj(object panel, object num) { }

	// RVA: 0xDC8E34
	public object InitSelectStatus(object skillList, object index) { }

	// RVA: 0xDC6F7C
	public object UpdatePanel() { }

	// RVA: 0xDC9C9C
	public object SetIconStatus(object element, object enableIndex) { }

	// RVA: 0xDC9D60
	public object OnSkillItemEnable(object uiEvent) { }

	// RVA: 0xDCA83C
	public object SetAfterUpgradeExp(object baseExp, object actExp) { }

	// RVA: 0xDCA8B8
	public object OnUpgrade(object uiEvent) { }

	// RVA: 0xDC901C
	public object SetControlStatus(object curElement, object curIndex, object status) { }

	// RVA: 0xDCAC9C
	public object SetSelectStatus(object skillList, object uiEvent, object clickIndex) { }

	// RVA: 0xDCAEA4
	public object OnSkillItemClick(object uiEvent) { }

	// RVA: 0xDC95E4
	public object UpdateSkillDetail() { }

	// RVA: 0xDC94C4
	private object GetNeedToSelectSkillIndex() { }

	// RVA: 0xDC6BAC
	private object ShowCdnHeroPic(object form, object heroId) { }

	// RVA: 0xDCA6B4
	private static object SetTextInGo(object obj, object str) { }

	// RVA: 0xDCA548
	private static object SetProgressInGo(object progressBarGo, object percent) { }

	// RVA: 0xDCAFA4
	private object ExpAnimUpdate(object curExpValue) { }

	// RVA: 0xDCB150
	private object ExpAnimComplete() { }

	// RVA: 0xDCB2D8
	public object .ctor() { }

	// RVA: 0xDCB330
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDCB334
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CHeroCultivateSystem
{

	// Fields
	public static object s_heroCultivateFormPath; // 0x0
	public static object HERO_CULTIVATE_RULE_ID; // 0x8
	protected object m_heroList; // 0x8
	protected object m_selectHeroType; // 0x10
	private object mCurrentSelectHeroId; // 0x14
	private object mCultivatePage; // 0x18
	private static object bHaveCultivateThisTime; // 0xC

	// Properties
	public object curretSeletHeroType { get; }

	// Methods

	// RVA: 0xDCB338
	public object get_curretSeletHeroType() { }

	// RVA: 0xDCB398
	public override object Init() { }

	// RVA: 0xDCB7B0
	private object OnHeroCultivateHelp(object uiEvent) { }

	// RVA: 0xDCB898
	public override object UnInit() { }

	// RVA: 0xDCBC08
	private object RefreshHeroListOpenStatus() { }

	// RVA: 0xDCBD6C
	protected object ResetHeroListData(object needKeepSelect) { }

	// RVA: 0xDCC2B4
	protected object FilterHeroData() { }

	// RVA: 0xDCC538
	public static object SortHeroList(object heroList) { }

	// RVA: 0xDCC6D0
	public object OnHeroCultivate_ItemEnable(object uiEvent) { }

	// RVA: 0xDCC84C
	public object SetPveHeroItemData(object formScript, object listItem, object data) { }

	// RVA: 0xDCD1C4
	public object OnHeroCultivate_MenuSelect(object uiEvent) { }

	// RVA: 0xDCD2AC
	public object OnHeroCultivate_ItemClick(object uiEvent) { }

	// RVA: 0xDCD3C8
	public object OnNtyAddHero(object id) { }

	// RVA: 0xDCD434
	private object RefreshHeroListElement(object heroId) { }

	// RVA: 0xDCD898
	public object IsHeroCanCultivate(object heroId) { }

	// RVA: 0xDCD900
	public object OnOpenHeroCultivateForm(object uiEvent) { }

	// RVA: 0xDCDDCC
	public object OnHeroCultivate_CloseForm(object uiEvent) { }

	// RVA: 0xDCDF64
	public object OnCloseHeroCultivatePageForm(object uiEvent) { }

	// RVA: 0xDCAB70
	public static object SendHeroCultivateReq(object heroId) { }

	// RVA: 0xDCE048
	public static object OnHeroCultivateRep(object msg) { }

	// RVA: 0xDC77A8
	public object OnTrainingPlentyHero(object heroId, object skinId) { }

	// RVA: 0xDCE2E0
	public object .ctor() { }

	// RVA: 0xDCE37C
	private static object .cctor() { }

	// RVA: 0xDCE3F4
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDCE3F8
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
internal enum HeroSkillState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Assets.Scripts.GameSystem
public class CHeroSkillUpgradeGiftCtrl
{

	// Fields
	public static readonly object FROM_HERO_SKILL_UPGRADE_GIFT; // 0x0
	private object item; // 0x8
	private object HeroSkillRewardExpCnt; // 0x10
	private object widgets; // 0x18
	private object selectedRewardIndex; // 0x20
	private object toastTips; // 0x28
	private object bStarReward; // 0x30

	// Methods

	// RVA: 0xDCE3FC
	public object Init() { }

	// RVA: 0xDCE65C
	public object UnInit() { }

	// RVA: 0xDCE8BC
	public object OpenForm(object item) { }

	// RVA: 0xDCF0E0
	private object GetForm() { }

	// RVA: 0xDCF1BC
	private object OnEvtFormClosed(object uiEvent) { }

	// RVA: 0xDCF274
	private object OnEvtSelectRewardItem(object uiEvent) { }

	// RVA: 0xDD1348
	private object OnEvtExchange(object uiEvent) { }

	// RVA: 0xDD19E8
	public object OnHeroKillUpgradeUseRsp() { }

	// RVA: 0xDD1730
	private object GetItem() { }

	// RVA: 0xDCFA18
	private object GetDelayDrawGiftConfig() { }

	// RVA: 0xDCEBF4
	private object Refresh() { }

	// RVA: 0xDD1DA4
	private object RefreshRewardItem(object listElementScript, object delayDrawGiftItemConfig) { }

	// RVA: 0xDCFCD8
	private object RefreshRewardItemSelectState(object listElementScript, object isHeroCultivateExp, object bOpenHero) { }

	// RVA: 0xDD00DC
	private object RefreshRewardStates() { }

	// RVA: 0xDD06FC
	private object RefreshTopTips(object bPropReward) { }

	// RVA: 0xDD2564
	public object .ctor() { }

	// RVA: 0xDD2604
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CHeroSkillUpgradeGiftSystem
{

	// Fields
	private object heroSkillUpgradeGiftCtrl; // 0x8

	// Methods

	// RVA: 0xDD2670
	public override object Init() { }

	// RVA: 0xDD2840
	public override object UnInit() { }

	// RVA: 0xDD2978
	private object OnEvtOpenGift(object uiEvent) { }

	// RVA: 0xDD1C18
	public object GetDelayDrawConfig(object giftID) { }

	// RVA: 0xDD1790
	public object ExchangeGift(object itemData, object selectedRewardIndex) { }

	// RVA: 0xDD2AD4
	public object .ctor() { }

	// RVA: 0xDD2B2C
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDD2B30
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CPlentyTaskFormCtrl
{

	// Fields
	public static readonly object FORM_PLENTY_TASK_VIEW; // 0x0
	private object taskWidget; // 0x8
	private object mTasks; // 0x10
	private object mKillCntTasks; // 0x18
	private object m_lastRequestTaskID; // 0x20

	// Methods

	// RVA: 0xDD2B34
	public object Init() { }

	// RVA: 0xDD2E74
	public object UnInit() { }

	// RVA: 0xDD31B4
	public object OpenForm() { }

	// RVA: 0xDD3768
	private object GetForm() { }

	// RVA: 0xDD3844
	private object OnEvtCultivateTaskViewClose(object uiEvent) { }

	// RVA: 0xDD36BC
	private object RefreshPanel() { }

	// RVA: 0xDD3FD8
	private object UpdateCreditScore() { }

	// RVA: 0xDD3C7C
	private object UpdateTimer() { }

	// RVA: 0xDD3EBC
	private object UpdateKillCount() { }

	// RVA: 0xDD3950
	private object UpdateTaskList() { }

	// RVA: 0xDD33E4
	private object ProcessServerData() { }

	// RVA: 0xDD42F0
	public object OnWeekStarCoinCntUpdate(object curWeekStarCoin, object curWeekStarCoinLimit) { }

	// RVA: 0xDD43FC
	private object OnTaskItemClicked(object uiEvent) { }

	// RVA: 0xDD41C8
	public object SortGameCntTask() { }

	// RVA: 0xDD486C
	private object OnTaskKillCntClicked(object uiEvent) { }

	// RVA: 0xDD4C9C
	private object OnTaskUpdate() { }

	// RVA: 0xDD533C
	public object OnTaskTimeRefreshed() { }

	// RVA: 0xDD404C
	private object CalculateCompletedGameCount() { }

	// RVA: 0xDD5070
	private object GetWeekCreditBuf() { }

	// RVA: 0xDD540C
	private object SortDataState(object a, object b) { }

	// RVA: 0xDD54EC
	public object .ctor() { }

	// RVA: 0xDD558C
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CPlentyTaskSystem
{

	// Fields
	private object plentyTaskFormCtrl; // 0x8

	// Methods

	// RVA: 0xDD55F8
	public override object Init() { }

	// RVA: 0xDD5764
	public override object UnInit() { }

	// RVA: 0xDD589C
	private object OnEvtOpenTaskView(object uiEvent) { }

	// RVA: 0xDD5914
	public object .ctor() { }

	// RVA: 0xDD596C
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDD5970
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public enum RECORD_EVENT_PRIORITY
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RECORD_EVENT_TYPE_INVALID;
	public const object RECORD_EVENT_TYPE_ASSIST;
	public const object RECORD_EVENT_TYPE_ONCEKILL;
	public const object RECORD_EVENT_TYPE_DOUBLEKILL;
	public const object RECORD_EVENT_TYPE_TRIPLEKILL;
	public const object RECORD_EVENT_TYPE_QUATARYKILL;
	public const object RECORD_EVENT_TYPE_PENTAKILL;
	public const object RECORD_EVENT_TYPE_HEXAKILL;
	public const object RECORD_EVENT_TYPE_HEPTAKILL;
	public const object RECORD_EVENT_TYPE_OCTOKILL;
	public const object RECORD_EVENT_TYPE_ENNEAKILL;
	public const object RECORD_EVENT_TYPE_DECAKILL;
	public const object RECORD_EVENT_TYPE_HIGHTLIGHT;
	public const object RECORD_EVENT_TYPE_COUNT;
}

// Namespace: 
public struct RECORD_INFO
{

	// Fields
	public object eventPriority; // 0xFFFFFFFFFFFFFFF8
	public object lEndTime; // 0x0
	public object mEffectInfo; // 0x8

	// Methods

	// RVA: 0xDD8F84
	public object .ctor(object _eventPriority, object _lEndTime, object _effectInfo) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CRecordEventChooser
{

	// Fields
	private object m_enLastEventPriority; // 0x8
	private object m_lLastEventStartTime; // 0x10
	private object m_lLastEventEndTime; // 0x18
	private object m_uiEventStartTimeInterval; // 0x20
	private object m_uiEventEndTimeInterval; // 0x24
	private object m_uiEventNumMax; // 0x28
	private object m_ui543KillEventTotalTime; // 0x2C
	private object m_ui210KillEventTotalTime; // 0x30
	private object m_lGameEndTime; // 0x38
	private object m_lGameStartTime; // 0x40
	private object InTimeStamps; // 0x48
	private object m_lLastTimeEventStart; // 0x50
	private object m_lLastTimeEventEnd; // 0x58
	private object m_uiOnceDoubleEventTimeIntervalReduce; // 0x60
	private object m_stRecordInfo; // 0x68

	// Methods

	// RVA: 0xDD5974
	public object Reset() { }

	// RVA: 0xDD5A54
	public object Init() { }

	// RVA: 0xDD5B64
	public object UnInit() { }

	// RVA: 0xDD5C00
	public object OnHighLightNotify(object highlightNotifyParams) { }

	// RVA: 0xDD617C
	public object OnKillNotify(object killNotifyParams) { }

	// RVA: 0xDD6788
	public object DoFightOver() { }

	// RVA: 0xDD6854
	public object HasMultiKill(object multiKill) { }

	// RVA: 0xDD6908
	public object HaveHonourMomentData() { }

	// RVA: 0xDD69A4
	public object ChooseTopEvent() { }

	// RVA: 0xDD9694
	public object ConvertMaxMultiKillPriorityToResDef() { }

	// RVA: 0xDD9954
	public object OnBeginRecord() { }

	// RVA: 0xDD5E2C
	private object AddRecordEvent(object eventPriority, object lStartTime, object lEndTime) { }

	// RVA: 0xDD65D0
	private object UpdateRecordEvent(object eventActor, object eventPriority, object isInMultiKill) { }

	// RVA: 0xDD8FA0
	private object GetAssistCountWithTime(object fStartTime, object fEndTime) { }

	// RVA: 0xDD937C
	private object InsertAssistInfo(object assistInfo, object iAssistCount, object lStartTime, object lEndTime) { }

	// RVA: 0xDD9A0C
	public object GetLastEventTime() { }

	// RVA: 0xDD9B7C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public static class RecordEffectTime
{

	// Fields
	public static object MomentVideoEffectTime; // 0x0
	public static object HighLightVideoEffectTime; // 0x8

	// Methods

	// RVA: 0xDD8E84
	public static object GetEffectTimeByType(object type) { }

	// RVA: 0xDD9CBC
	private static object .cctor() { }

}

// Namespace: 
private enum CHECK_STATUS
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoResult;
	public const object Checking;
	public const object Completed;
}

// Namespace: 
private enum CHECK_FEATURE_EXCEPTION
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoException;
	public const object TimeUp;
}

// Namespace: 
private enum enVideoShareFormWidgetType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object enPlatformListToggleGroup;
	public const object enButtonGroupGo;
	public const object enButtonShareGo;
	public const object enButtonCopyGo;
	public const object enAlsoShare2GuildHelper;
}

// Namespace: 
public interface IGetTicketHandler
{

	// Methods

	// RVA: -1
	public abstract object GetTicket() { }

}

// Namespace: 
public class CVideoSharePlatform
{

	// Fields
	public object sharePlatform; // 0x8
	public object platformName; // 0x10
	public object platformNameKey; // 0x18
	public object platformPrefabPath; // 0x20

	// Methods

	// RVA: 0xDEABFC
	public object .ctor(object platformType, object name, object prefabPath) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CRecordUseSDK
{

	// Fields
	private const object MODENAME;
	private const object GRADENAME;
	private const object HERONAME;
	private const object KILLNUM;
	private const object DEADNUM;
	private const object ASSISTNUM;
	private const object PLAYERNAME;
	private const object WORLDID;
	private const object PLATFORM;
	private const object VIPLEVEL;
	private const object PLAYERLEVEL;
	private const object HURTVALUE;
	private const object BEHURTVALUE;
	private const object EQUIPNAME;
	private const object SKILLNAME;
	private const object ISMVP;
	private const object ISTRIPLEKILL;
	private const object ISQUATARYKILL;
	private const object ISPENTAKILL;
	private const object ISHEXAKILL;
	private const object ISHEPTAKILL;
	private const object ISOCTOKILL;
	private const object ISENNEAKILL;
	private const object ISDECAKILL;
	private const object ISLEGENDARY;
	private const object WINORLOSE;
	private const object GAMEID;
	private object m_bIsStartRecordOk; // 0x8
	private object m_lMomentVideoTimeLen; // 0x10
	private object m_hostActor; // 0x18
	private object m_strHostHeroName; // 0x28
	private object m_bIsWinMvp; // 0x30
	private object m_bIsRecordMomentsEnable; // 0x31
	private object mbIsCheatRecordMomentEnable; // 0x32
	private object m_bIsCallStopGameJoyRecord; // 0x33
	private object m_extraInfos; // 0x38
	public object RecordEventChooser; // 0x40
	private object m_strGameId; // 0x48
	private object m_HostPlayerName; // 0x50
	private object mHonourMomentState; // 0x58
	private static readonly object szGuildKey; // 0x0
	public static readonly object szPlsCheckOnePlatform; // 0x8
	private static readonly object szAppNoInstallPlatform; // 0x10
	private static readonly object szCopyUrlSuccessKey; // 0x18
	private static readonly object szInvalidUrlKey; // 0x20
	private static readonly object szUnknowPlatformKey; // 0x28
	private static readonly object szPlsJoinGuidKey; // 0x30
	private static readonly object szShare2SnsFailed; // 0x38
	private static readonly object szShare2SnsSuccess; // 0x40
	private static readonly object szShare2GuildSuccess; // 0x48
	private static readonly object szShare2GuildFailed; // 0x50
	private static readonly object szHonourMomentHead; // 0x58
	private static readonly object szHonourMomentTail; // 0x60
	private static readonly object szHonourTrippleKillDesc; // 0x68
	private static readonly object szHonourQuataryKillDesc; // 0x70
	private static readonly object szHonourPentaKillDesc; // 0x78
	private static readonly object szHonourHexaKillDesc; // 0x80
	private static readonly object szHonourSevenKillDesc; // 0x88
	private static readonly object szHonourEightKillDesc; // 0x90
	private static readonly object szHonourEnneaKillDesc; // 0x98
	private static readonly object szHonourDecaKillDesc; // 0xA0
	private static readonly object szHonourMvpDesc; // 0xA8
	private static readonly object szDirtyWordForbid; // 0xB0
	private object m_bIsGlobalServerToClientCfgReady; // 0x5C
	private object ASYNC_CHECK_FEATURE_TIME_LIMIT; // 0x60
	private object m_asyncCheckFeatureCallBacks; // 0x68
	private object m_asyncCheckPermissionCallBacks; // 0x70
	private object m_enable; // 0x78
	private object m_checkFeatureException; // 0x7C
	private object m_asyncCheckFeatureTimerID; // 0x80
	private object m_startAsyncCheckFeature; // 0x84
	private object m_startAsyncCheckPermission; // 0x85
	private object m_checkSDKFeatureStatus; // 0x88
	private object m_enmSDKFeature; // 0x8C
	private object m_checkSDKPermissionStatus; // 0x90
	private object m_hasPermission; // 0x94
	private object m_bIsFreeRecordShowing; // 0x95
	private object m_bStartFreeRecord; // 0x96
	private object m_bShowFreeRecordView; // 0x97
	private object m_Vec2FreeRecordWindowPosInLobby; // 0x98
	private object m_Vec2FreeRecordWindowPosInBattle; // 0xA0
	private object mJsonDict; // 0xA8
	private static object szSvrVideoUrlKey; // 0xB8
	private static object szVideoTitleKey; // 0xC0
	private static object szVideoDurationKey; // 0xC8
	private static object szVideoThumbnailUrlKey; // 0xD0
	private static object szLocalVideoUrlKey; // 0xD8
	private static object szExtraInfoKey; // 0xE0
	private static object szVideoTypeKey; // 0xE8
	private static object szVideoShareUrlFormatKey; // 0xF0
	private static object szVideoShareUrlForGuidlFormatKey; // 0xF8
	private static object szVideoShareSourceKey; // 0x100
	public static readonly object VideoShareGarenaPrefabPath; // 0x108
	public static readonly object VideoShareFacebookPrefabPath; // 0x110
	public static readonly object VideoShareKakaoPrefabPath; // 0x118
	public static readonly object VideoShareWhatsAppPrefabPath; // 0x120
	public static readonly object VideoShareLinePrefabPath; // 0x128
	public static readonly object VideoShareInstagramPrefabPath; // 0x130
	private object mbGuildChatDefaultToggle; // 0xB0
	private object mSupportPlatformHelperList; // 0xB8
	public static readonly object VideoPlatformShareFormPath; // 0x138
	public const object Share_Done;
	private object mbShare2Sns; // 0xC0
	private object mbShare2Guild; // 0xC1
	private object isInited; // 0xC2
	private object mDispatchReadyEventTimerId; // 0xC4
	private object mCloseVideoManagerTimerId; // 0xC8

	// Properties
	public object IsCheatRecordMomentEnable { get; }
	public object honourMomentState { get; }
	private object m_uiMinSpaceLimit { get; }
	private object m_uiFreeRecorderMinSpaceLimit { get; }
	public object ReadyVideoShareSource { get; }
	public object ReadyVideoDuration { get; }
	public object ReadyVideoType { get; }
	public object ReadySvrVideoUrl { get; }
	public object ReadyH5ShowUrl { get; }
	public object ReadyVideoForGuildUrl { get; }
	public object ReadyVideoTitle { get; }
	public object ReadyVideoThumbnaiUrl { get; }
	public object ReadyLocalVideoUrl { get; }
	public object ReadyVideoExtraInfo { get; }
	public object IsRecordingMoments { get; }
	public object FreeRecordEnable { get; }
	public object Enable { get; set; }

	// Methods

	// RVA: 0xDD9D10
	public object get_IsCheatRecordMomentEnable() { }

	// RVA: 0xDD9D70
	public object get_honourMomentState() { }

	// RVA: 0xDD9DD0
	private object get_m_uiMinSpaceLimit() { }

	// RVA: 0xDD9E80
	private object get_m_uiFreeRecorderMinSpaceLimit() { }

	// RVA: 0xDD9F30
	public object get_ReadyVideoShareSource() { }

	// RVA: 0xDDA260
	public object get_ReadyVideoDuration() { }

	// RVA: 0xDDA4CC
	public object get_ReadyVideoType() { }

	// RVA: 0xDDA738
	public object get_ReadySvrVideoUrl() { }

	// RVA: 0xDDA95C
	public object get_ReadyH5ShowUrl() { }

	// RVA: 0xDDAA68
	public object get_ReadyVideoForGuildUrl() { }

	// RVA: 0xDDAB74
	public object get_ReadyVideoTitle() { }

	// RVA: 0xDDACE0
	public object get_ReadyVideoThumbnaiUrl() { }

	// RVA: 0xDDAE4C
	public object get_ReadyLocalVideoUrl() { }

	// RVA: 0xDDAFB8
	public object get_ReadyVideoExtraInfo() { }

	// RVA: 0xDDB23C
	private object GetVideoExtraInfoData(object key) { }

	// RVA: 0xDDB154
	private object GetJsonValueDict(object key) { }

	// RVA: 0xDDA8A4
	private object GetJsonValueString(object key) { }

	// RVA: 0xDDB324
	private object GetJsonValueLong(object key) { }

	// RVA: 0xDDA19C
	private object GetJsonValueObject(object key) { }

	// RVA: 0xDDB3F0
	private object ParseVideoNameWithoutExtension(object svrVideoUrl) { }

	// RVA: 0xDDB53C
	private object CombinationH5Link(object sdkVideoName, object gameId, object platformCode, object envCode, object descript, object title) { }

	// RVA: 0xDDB778
	private object Reset() { }

	// RVA: 0xDDB8AC
	public override object Init() { }

	// RVA: 0xDDCB18
	public object InitAfterCfgReady() { }

	// RVA: 0xDDD09C
	public override object UnInit() { }

	// RVA: 0xDDDC78
	private object OnGameJoyStartRecordResult(object bRes) { }

	// RVA: 0xDDDD0C
	public object CloseGenerateMomentsVideoTips() { }

	// RVA: 0xDDDDAC
	public object OnKillNotify(object killNotifyParams) { }

	// RVA: 0xDDDE4C
	public object OnHighLightNotify(object highlightNotifyParams) { }

	// RVA: 0xDDDEEC
	private object OnFightPrepare(object prm) { }

	// RVA: 0xDDE3D4
	public object get_IsRecordingMoments() { }

	// RVA: 0xDDE474
	public object GetRecordVideoCount() { }

	// RVA: 0xDDE57C
	public object DoFightOver() { }

	// RVA: 0xDDF5FC
	private object GetRecorderPosition(object root) { }

	// RVA: 0xDDF898
	private object ChooseTopEvent() { }

	// RVA: 0xDDFD5C
	public object OnSaveHonourMoment(object sdkVideoParentGo) { }

	// RVA: 0xDDFF6C
	public object OnSaveMomentVideoCancel() { }

	// RVA: 0xDE0040
	public object CallGameJoyGenerateWithNothing() { }

	// RVA: 0xDDE620
	public object StopMomentsRecording() { }

	// RVA: 0xDDE6F4
	private object SetExtraInfos() { }

	// RVA: 0xDE0114
	private object SetMultiKill(object extraDict, object key, object multipKill) { }

	// RVA: 0xDDF984
	private object GetVideoName() { }

	// RVA: 0xDE0238
	private object GetMultipKillDesc(object killNum) { }

	// RVA: 0xDE0720
	private object OnGameJoyStopMomentRecordResult(object lDuration) { }

	// RVA: 0xDE0788
	public object OnBadGameEnd() { }

	// RVA: 0xDE0914
	private object GetToggleSharePlatform(object isSnsPlatform) { }

	// RVA: 0xDE0B9C
	public object GetSupportSharePlatformList() { }

	// RVA: 0xDE0D28
	private object ParsePlatform(object snsPlatform, object configNum) { }

	// RVA: 0xDE13C0
	private object IsContainSpecialKill(object keyValue) { }

	// RVA: 0xDE14AC
	public object GetHighestKill() { }

	// RVA: 0xDE16A0
	public object HasSpecialKillRecord() { }

	// RVA: 0xDE1814
	public object ReqCopyShareUrl() { }

	// RVA: 0xDE1CA0
	private object ShareVideo2SNS() { }

	// RVA: 0xDE2298
	public static object PlatformToReportSubType(object platform) { }

	// RVA: 0xDE25E8
	private object ShareVideo2Guild() { }

	// RVA: 0xDE299C
	private object KingHourShareUploadLog() { }

	// RVA: 0xDE2B00
	public static object OnShareToGuildRsp(object msg) { }

	// RVA: 0xDE2E08
	private object OnShare2SnsCallback(object result) { }

	// RVA: 0xDE2308
	public static object ShareVideoReport(object type, object subType, object result) { }

	// RVA: 0xDE3204
	private object ResetVideoShareUI() { }

	// RVA: 0xDE32C0
	private object LoadSharePlatformPrefab(object prefabPath, object nodeName, object parent, object form) { }

	// RVA: 0xDE3464
	private object InitShareVideoForm(object platformList, object form) { }

	// RVA: 0xDE39E8
	public object CloseVideoShareForm() { }

	// RVA: 0xDE3B40
	public object OpenShareVideoForm() { }

	// RVA: 0xDE0AC0
	public object GetVideoShareForm() { }

	// RVA: 0xDE3E28
	public object HaveHonourMomentData() { }

	// RVA: 0xDE3E98
	public object HaveMomentVideoData() { }

	// RVA: 0xDE3F00
	public object IsCompleteHonourVideoRecorder() { }

	// RVA: 0xDE406C
	public object GetAppGameId() { }

	// RVA: 0xDE4120
	public object IsHonourMomentFucOpen() { }

	// RVA: 0xDE4388
	public object IsDeviceAvailable() { }

	// RVA: 0xDE44F0
	public static object GetIOSVer(object deviceName, object isIPhone) { }

	// RVA: 0xDE4700
	public object IsHonourMomentFuncDeviceSupport() { }

	// RVA: 0xDE483C
	public object IsHonourMomentFuncSvrOpen() { }

	// RVA: 0xDE48E8
	public object OpenSdkVideoManagerForm() { }

	// RVA: 0xDE4B94
	private object OnVideoOperateExcuted() { }

	// RVA: 0xDE4BF4
	public object CloseSdkVideoManagerForm() { }

	// RVA: 0xDE3D4C
	public object GetShareVideoForm() { }

	// RVA: 0xDE4CF4
	private object OnReceiveVideoShareNofityData(object jsonString) { }

	// RVA: 0xDE4FC0
	private object OnFreeRecordStart(object status) { }

	// RVA: 0xDE5114
	private object OnVideoManagerFormOpen(object uiEvent) { }

	// RVA: 0xDE51FC
	private object OnVideoShareFormClose(object uiEvent) { }

	// RVA: 0xDE52DC
	private object OnCheckBoxStatusChanged(object uiEvent) { }

	// RVA: 0xDE536C
	private object OnVideoReadyToShare(object uiEvent) { }

	// RVA: 0xDE545C
	private object OnHonourMomentSureShareClick(object uiEvent) { }

	// RVA: 0xDE5E10
	public object CheckDirtyWordCallRsp(object isPass, object oldWordsObj, object processWords) { }

	// RVA: 0xDE6070
	private object OnHonourMomentCopyUrlClick(object uiEvent) { }

	// RVA: 0xDE6158
	private object OnLanguageChanged() { }

	// RVA: 0xDDC5CC
	private object BundleLanguage2GameJoyLocale(object lang, object region) { }

	// RVA: 0xDE6318
	public object StartFreeRecorder(object bIsLobby) { }

	// RVA: 0xDE6E38
	public object StopFreeRecorder(object bIsLobby) { }

	// RVA: 0xDE6688
	public object ShowFreeRecorderView(object bIsLobby) { }

	// RVA: 0xDE7208
	public object CloseFreeRecordView(object bIsLobby) { }

	// RVA: 0xDE7574
	public object get_FreeRecordEnable() { }

	// RVA: 0xDDCCE0
	public object get_Enable() { }

	// RVA: 0xDE75D4
	public object set_Enable(object value) { }

	// RVA: 0xDE7784
	private object AsyncCheckSDKFeature() { }

	// RVA: 0xDE78E0
	private object OnGameJoyCheckSDKFeatureResult(object enmFeature) { }

	// RVA: 0xDE7C68
	public object AsyncCheckPermission() { }

	// RVA: 0xDE7F8C
	public object CheckPermission() { }

	// RVA: 0xDE8224
	private object OnGameJoyCheckPermissionResult(object bRes) { }

	// RVA: 0xDE8318
	private object SetCheckFeatureException(object exception) { }

	// RVA: 0xDDCED8
	public object AsyncCheckFeature() { }

	// RVA: 0xDE64CC
	public object CheckFeature(object feature) { }

	// RVA: 0xDDCE24
	public object RegisterAsyncCheckFeatureCallBack(object callback) { }

	// RVA: 0xDDCD70
	public object UnRegisterAsyncCheckFeatureCallBack(object callback) { }

	// RVA: 0xDE79D0
	private object DoAsyncCheckFeatureCallBack() { }

	// RVA: 0xDE86F0
	public object RegisterAsyncCheckPermissionCallBack(object callback) { }

	// RVA: 0xDE87A4
	public object UnRegisterAsyncCheckPermissionCallBack(object callback) { }

	// RVA: 0xDE7DB8
	private object DoAsyncCheckPermissionCallBack() { }

	// RVA: 0xDE8858
	private object OnAsyncCheckFeatueTimeUp(object timerSequence) { }

	// RVA: 0xDE80D0
	public object isINTLVideoHasAlbunPermission() { }

	// RVA: 0xDE8438
	private object CheckTaleTimeRecordStorageEnough() { }

	// RVA: 0xDE8594
	private object CheckFreeRecordStorageEnough() { }

	// RVA: 0xDDE324
	private object GetRecorderGlobalCfgEnableFlag() { }

	// RVA: 0xDE898C
	public object ResetGlobalServerToClientCfgReady() { }

	// RVA: 0xDE89F0
	private object OnGlobalServerToClientCfgReady() { }

	// RVA: 0xDE8BD0
	private object TryToAutoStartFreeRecord() { }

	// RVA: 0xDE8D58
	private object OnLobbyFormOpen(object uiEvent) { }

	// RVA: 0xDE8DC8
	private object OnLobbyFormShow(object uiEvent) { }

	// RVA: 0xDE8FD4
	private object OnLoadingFormOpen(object uiEvent) { }

	// RVA: 0xDE9040
	private object OnLoadingFormClose(object uiEvent) { }

	// RVA: 0xDE9114
	private object OnSettlementFormClosed(object uiEvent) { }

	// RVA: 0xDE9228
	private object OnApplicationPause(object pauseStatus) { }

	// RVA: 0xDE9400
	public object SetVideoQuality(object quality) { }

	// RVA: 0xDE9584
	public object SetVoiceRecordEnable(object enable) { }

	// RVA: 0xDE95E8
	public object CheatStartFreeRecorder() { }

	// RVA: 0xDE96FC
	public object CheatStopFreeRecorder() { }

	// RVA: 0xDE97D4
	public object CheatSwitchHonounMomentEnable() { }

	// RVA: 0xDE98E8
	public object SimulateCloseShareFormAndOpenSdkForm() { }

	// RVA: 0xDE99C4
	public object SimulateTimeUpReady2Share(object seconds) { }

	// RVA: 0xDE9B64
	public object OnTimerUp2DispatchEvent(object seq) { }

	// RVA: 0xDE9D0C
	public object SimulateTimeUp2CloseVideoManger(object seconds) { }

	// RVA: 0xDE9EAC
	private object OnTimerUp2CloseVideoManager(object seq) { }

	// RVA: 0xDE5D28
	private static object SetDirtWordsReqInstance(object words) { }

	// RVA: 0xDE9FD4
	public object .ctor() { }

	// RVA: 0xDEA2C8
	private static object .cctor() { }

	// RVA: 0xDEA8E0
	private object <ReqCopyShareUrl>b__175_0(object result) { }

	// RVA: 0xDEAA2C
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDEAA30
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__13_0; // 0x8

	// Methods

	// RVA: 0xDED638
	private static object .cctor() { }

	// RVA: 0xDED698
	public object .ctor() { }

	// RVA: 0xDED6A0
	internal object <BindSuccess>b__13_0(object seq) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CBindAccountSys
{

	// Fields
	private static object BIND_FORM; // 0x0
	private object _form; // 0x8
	private object m_SysEntryForm; // 0x10

	// Methods

	// RVA: 0xDEAC9C
	public override object Init() { }

	// RVA: 0xDEB114
	public override object UnInit() { }

	// RVA: 0xDEACFC
	private object _Mount() { }

	// RVA: 0xDEB1A8
	private object _UnMount() { }

	// RVA: 0xDEB5C0
	public object Clear() { }

	// RVA: 0xDEB61C
	private object onOpenBind(object uiEvent) { }

	// RVA: 0xDEB7A8
	private object OnBind_Garena(object uiEvent) { }

	// RVA: 0xDEB8C0
	private object OnBind_Facebook(object uiEvent) { }

	// RVA: 0xDEB9D8
	private object OnBind_ConfirmGarena(object uiEvent) { }

	// RVA: 0xDEBB24
	private object OnBind_ConfirmFacebook(object uiEvent) { }

	// RVA: 0xDEBC70
	private object BindSuccess(object info) { }

	// RVA: 0xDEC7C8
	private object ShowBindSuccTip(object platform) { }

	// RVA: 0xDEC638
	private object BindSuccessSyncServer() { }

	// RVA: 0xDECEA0
	public static object OnBindSuccessRsp(object msg) { }

	// RVA: 0xDED098
	public static object OnBindRewardNtf(object msg) { }

	// RVA: 0xDED3EC
	private object BindFail(object tips) { }

	// RVA: 0xDECD58
	private object _CloseForm() { }

	// RVA: 0xDED4A8
	private object OnCLoseBind(object uiEvent) { }

	// RVA: 0xDED510
	public object .ctor() { }

	// RVA: 0xDED568
	private static object .cctor() { }

	// RVA: 0xDED5D4
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDED634
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
public enum enNameChangeFormWidget
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NameInputField;
	public const object DescText;
}

// Namespace: 
private sealed class <>c__DisplayClass26_0
{

	// Fields
	public object changeType; // 0x8
	public object nameChangeCount; // 0xC

	// Methods

	// RVA: 0xDF0B78
	public object .ctor() { }

	// RVA: 0xDF18C8
	internal object <GetNameChangeCostItemCount>b__0(object x) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CNameChangeSystem
{

	// Fields
	public const object NameChangeFormPrefabPath;
	private object m_playerNameChangeCount; // 0x8
	private object m_guildNameChangeCount; // 0xC
	private object prePriority; // 0x10
	private object preSubPriority; // 0x14
	private object m_curChangeType; // 0x18
	public const object PlayerUIDKey;
	public const object PlayerLogicWorldIDKey;
	private object openEnv; // 0x20

	// Methods

	// RVA: 0xDED854
	private object SetPlayerNameChangeCount(object playerNameChangeCount) { }

	// RVA: 0xDED8BC
	public object SetGuildNameChangeCount(object guildNameChangeCount) { }

	// RVA: 0xDED924
	public override object Init() { }

	// RVA: 0xDEDD9C
	public override object UnInit() { }

	// RVA: 0xDEE214
	private object OnOpenChangeRemarkWnd(object uiEvent) { }

	// RVA: 0xDEED64
	private object OnOpenPlayerNameChangeForm(object uiEvent) { }

	// RVA: 0xDEEDD0
	private object OnOpenGuildNameChangeForm(object uiEvent) { }

	// RVA: 0xDEE404
	public object SetEnv(object env) { }

	// RVA: 0xDEE46C
	public object OpenNameChangeForm(object changeType) { }

	// RVA: 0xDEEFC4
	private object OnChangeName(object uiEvent) { }

	// RVA: 0xDF0408
	private object OnGuideToMall(object uiEvent) { }

	// RVA: 0xDF072C
	private object OnBuyNameChgCardConfirm(object uiEvent) { }

	// RVA: 0xDF0868
	private object OnOpenBuyDianQuanPanel(object uiEvent) { }

	// RVA: 0xDF05C0
	private object GetNameChangeCardShopProductKey(object chgNameType) { }

	// RVA: 0xDEF95C
	public object CheckNameChangeCardCount() { }

	// RVA: 0xDF0994
	private object GetNameChangeHaveItemCount(object changeType) { }

	// RVA: 0xDEEE3C
	public object GetNameChangeCostItemCount(object changeType) { }

	// RVA: 0xDEFFEC
	private object SendChangeNameReq(object name) { }

	// RVA: 0xDF01FC
	private object SendRemarkChangeReq(object name, object playerId, object logicWorldId) { }

	// RVA: 0xDF0B80
	public static object ReceiveChangeNameRsp(object msg) { }

	// RVA: 0xDF12A8
	public static object ReceiveGuildNameChangeNtf(object msg) { }

	// RVA: 0xDF1498
	public static object ReceiveChangeRemarkRsp(object msg) { }

	// RVA: 0xDF1764
	private object ReportChangeRemarkTlog(object uid, object remark) { }

	// RVA: 0xDF1860
	public object .ctor() { }

	// RVA: 0xDF18C0
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDF18C4
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class RollingInfo
{

	// Fields
	public object priority; // 0x8
	public object resetPriorityTime; // 0xC
	public object repeatCount; // 0x10
	public object isShowing; // 0x11
	public object content; // 0x18

	// Methods

	// RVA: 0xDF1918
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CRollingSystem
{

	// Fields
	private const object PriorityMin;
	private const object PriorityMax;
	private const object PriorityIDIPRatio;
	private const object PriorityHornRatio;
	private const object PriorityEventRatio;
	private const object ResetRollingInfoPriorityPeriod;
	private const object RollingCDMilliSeconds;
	private object m_rollingInfos; // 0x8
	private object m_isInRollingCD; // 0x10
	private static object m_poolRollInfo; // 0x0
	private const object MaxRollInfo;
	private static object m_poolRollInfoSize; // 0x8

	// Methods

	// RVA: 0xDF1980
	public override object Init() { }

	// RVA: 0xDF1D24
	public override object UnInit() { }

	// RVA: 0xDF1F3C
	private object OnSET_ROLLING_STATE(object state) { }

	// RVA: 0xDF2364
	private object _OnGameLanChange() { }

	// RVA: 0xDF2658
	private object OnAutoScrollerScrollFinish(object uiEvent) { }

	// RVA: 0xDF2DB4
	private object OnRollingCDOver(object timerSequence) { }

	// RVA: 0xDF2B18
	private object ResetRollingInfoPriority() { }

	// RVA: 0xDF2F28
	private object IsNeedResetResetPriority(object rollingInfo) { }

	// RVA: 0xDF28EC
	private object HandleOnShowRollingInfo() { }

	// RVA: 0xDF1FB4
	public object StartRolling() { }

	// RVA: 0xDF215C
	public object StopRolling() { }

	// RVA: 0xDF310C
	private object StartRolling(object autoScroller) { }

	// RVA: 0xDF34D4
	private object ShowRollingBar() { }

	// RVA: 0xDF2CB0
	private object HideRollingBar() { }

	// RVA: 0xDF35D8
	private object GetRollingBar() { }

	// RVA: 0xDF376C
	private static object CalculatePriority(object type, object innerPriority) { }

	// RVA: 0xDF37F4
	private static object CalculateRepeatCount(object startTime, object endTime, object repeatPeriod) { }

	// RVA: 0xDF3014
	private object GetOnShowRollingInfoIndex() { }

	// RVA: 0xDF33C0
	private object GetNextShowRollingInfoIndex() { }

	// RVA: 0xDF3884
	private static object _GetRollInfoFromPool() { }

	// RVA: 0xDF2510
	private static object _RollInfoPushPool(object parInfo) { }

	// RVA: 0xDF3A08
	public static object ReceiveRollingMsgNtf(object msg) { }

	// RVA: 0xDF40C8
	private static object IsInBattle() { }

	// RVA: 0xDF4230
	public object .ctor() { }

	// RVA: 0xDF42D0
	private static object .cctor() { }

	// RVA: 0xDF4348
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDF434C
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
public enum enAchievementTypeFormWidget
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object My_Point_Text;
	public const object World_Rank_Text;
	public const object Type_Panel;
	public const object Not_In_Rank;
}

// Namespace: 
public enum enAchievementListFormWidget
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Achievement_List;
	public const object Title_Text;
	public const object AchieveGobalProgressText;
}

// Namespace: 
public enum enAchievementShareFormWidget
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Name_Text;
	public const object New_Achievement_Btn_Panel;
	public const object Share_Achievement_Btn_Panel;
	public const object Close_Btn;
	public const object ScreenShotFrame_Panel;
	public const object Desc_Text;
	public const object Icon_Image;
	public const object Tips_Text;
	public const object Confirm_Btn;
	public const object Icon_Bg_Image;
	public const object ShareToFriendArea_Text;
	public const object Award_List;
	public const object StarsRoot;
}

// Namespace: 
public enum enAchievementStarState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UnAchieved;
	public const object Achieveing;
	public const object Achieved;
}

// Namespace: 
private class StarEffectData
{

	// Fields
	public object StarIdx; // 0x8
	public object FillAmount; // 0xC
	public object CurState; // 0x10

	// Methods

	// RVA: 0xDFB6AC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__31_0; // 0x8

	// Methods

	// RVA: 0xDFB6B8
	private static object .cctor() { }

	// RVA: 0xDFB718
	public object .ctor() { }

	// RVA: 0xDFB720
	internal object <RefreshAchieveItemList>b__31_0(object a, object b) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CAchievementSystem
{

	// Fields
	private const object AchievementListFormPrefabPath;
	public const object AchievementShareFormPrefabPath;
	public const object ButtonGroupShareAchievementPrefabPath;
	private object m_allAchieveItems; // 0x8
	private object m_curAchievementType; // 0x10
	private object m_worldRank; // 0x14
	private const object FORM_SHOW_EFFECT_DELAY_TIME;
	private const object STAR_ACTIVE_DELAY_TIME;
	private object m_lastGetAchievedId; // 0x18
	private object OpenFormTimerId; // 0x1C
	private object achievedStarIdx; // 0x20
	private object getStarSoundEventName; // 0x28
	private object starFxData; // 0x30

	// Methods

	// RVA: 0xDF4350
	public override object Init() { }

	// RVA: 0xDF47E0
	private object OnAchievementListElementEnabled(object uiEvent) { }

	// RVA: 0xDF4A14
	private object OnAchievementGetAward(object uiEvent) { }

	// RVA: 0xDF4DA0
	private object OnOpenAwardForm(object uiEvent) { }

	// RVA: 0xDF4EBC
	public object OnShareFormClosed(object uiEvent) { }

	// RVA: 0xDF52E4
	private object OnAchievementShowShareBtn(object uiEvent) { }

	// RVA: 0xDF541C
	private object HandleAchieveGetRankingAccountInfo(object rsp) { }

	// RVA: 0xDF54FC
	public object OnOpenLobby() { }

	// RVA: 0xDF555C
	public object NotifyRedotAndBuddle() { }

	// RVA: 0xDF5B50
	private object RemoveNotifyEventList(object evtList) { }

	// RVA: 0xDF5CB4
	public object OnBuddleJumpHandler(object evt) { }

	// RVA: 0xDF5DE4
	public object GetViewAchieveItemById(object achievementId, object index) { }

	// RVA: 0xDF5F40
	private object OpenAchieveForm(object selIdx) { }

	// RVA: 0xDF6020
	public object RefreshAchieveItemList(object listParent) { }

	// RVA: 0xDF63F0
	private object SetAchievementGobalProgress(object listForm) { }

	// RVA: 0xDF4944
	private object SetAchievementListItem(object listElement, object achieveItem) { }

	// RVA: 0xDF7C58
	private object SetGetAwardEventScript(object listElement, object achieveItem) { }

	// RVA: 0xDF66F0
	private object SetAchievementListItemProgress(object listElement, object achieveItem) { }

	// RVA: 0xDF7DF8
	private object SetAchievementItemStarsProgress(object starsRoot, object achieveItem) { }

	// RVA: 0xDF86D0
	private object SetSharedAchievementStarsProgress(object starsRoot, object achieveItem) { }

	// RVA: 0xDF917C
	private object SetStarFillAmount(object starGo, object fillAmout) { }

	// RVA: 0xDF90EC
	private object SetStarFxData(object state, object startIdx, object fillAmount) { }

	// RVA: 0xDF8E8C
	private object SetShareStarState(object starRoot, object state, object showEffect) { }

	// RVA: 0xDF9300
	private object OnTimerShowStarEffect(object seq) { }

	// RVA: 0xDF991C
	private object OnTimerShowAchieved(object seq) { }

	// RVA: 0xDF9D28
	public object GetAchieveingStarImg(object node) { }

	// RVA: 0xDF83A0
	private object SetStarState(object starRoot, object state, object progress) { }

	// RVA: 0xDF6BC4
	private object SetAchievementListItemState(object listElement, object achieveItem) { }

	// RVA: 0xDF6E80
	private object SetAchievementListItemAward(object listElement, object achieveItem) { }

	// RVA: 0xDF9EC4
	private object SetAchievementAwardTipsEvent(object eventScript, object useable) { }

	// RVA: 0xDFA120
	private object OpenShareForm(object achievementId) { }

	// RVA: 0xDFA2D8
	private object RefreshShareForm(object shareForm, object achievementId) { }

	// RVA: 0xDFA904
	private object RefreshAwardPanel(object shareForm, object achievementId) { }

	// RVA: 0xDF4C24
	public static object SendGetAchieveRewardReq(object achieveId) { }

	// RVA: 0xDFAD0C
	public static object OnRecieveAchieveInfo(object msg) { }

	// RVA: 0xDFAE50
	public static object OnNotifyAchieveStateChange(object msg) { }

	// RVA: 0xDFB058
	public static object OnNotifyAchieveDoneDataChange(object msg) { }

	// RVA: 0xDFB19C
	public static object OnNotifyGetAchieveReward(object msg) { }

	// RVA: 0xDFB2FC
	public static object OnNotifyPvpBanMsg(object msg) { }

	// RVA: 0xDFB5C0
	public object .ctor() { }

	// RVA: 0xDFB6B4
	public object <>iFixBaseProxy_Init() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CNewbieAchieveSys
{

	// Fields
	private object m_parInfo; // 0x8

	// Methods

	// RVA: 0xDFB920
	public override object Init() { }

	// RVA: 0xDFBC04
	public override object UnInit() { }

	// RVA: 0xDFBEE8
	private object onActorDead(object param) { }

	// RVA: 0xDFC20C
	private object onLearnTalent(object param) { }

	// RVA: 0xDFC37C
	private object onMonsterGroupDead(object param) { }

	// RVA: 0xDFC69C
	private object onAchieveClose(object uiEvent) { }

	// RVA: 0xDFC1A8
	public object ShowAchieve(object achieveType) { }

	// RVA: 0xDFC700
	public object .ctor() { }

	// RVA: 0xDFC758
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xDFC75C
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
public enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OnGoing;
	public const object Have_Done;
	public const object Discard;
	public const object Commited;
	public const object NewRefresh;
	public const object Show_HaveDone;
	public const object Final;
	public const object None;
}

// Namespace: 
public struct PrerequisiteInfo
{

	// Fields
	public object m_isReach; // 0xFFFFFFFFFFFFFFF8
	public object m_value; // 0xFFFFFFFFFFFFFFFC
	public object m_valueTarget; // 0x0
	public object m_conditionType; // 0x4
}

// Namespace: Assets.Scripts.GameSystem
public class CTask
{

	// Fields
	public object m_baseId; // 0x8
	public object m_taskType; // 0xC
	public object m_taskSubType; // 0x10
	public object m_taskState; // 0x11
	public object m_getTime; // 0x14
	public object m_preTaskId; // 0x18
	public object m_prerequisiteInfo; // 0x20
	private object _taskDesc; // 0x28
	private object _taskTitle; // 0x30
	public object m_rewardId; // 0x38
	public object m_taskIcon; // 0x40
	private object _MishuDesc; // 0x48
	public object m_taskJump; // 0x50
	public object m_resTask; // 0x58
	public object resAward; // 0x60

	// Properties
	public object m_taskDesc { get; }
	public object m_taskTitle { get; }
	public object m_MishuDesc { get; }

	// Methods

	// RVA: 0xDFC760
	public object get_m_taskDesc() { }

	// RVA: 0xDFC7C0
	public object get_m_taskTitle() { }

	// RVA: 0xDFC820
	public object get_m_MishuDesc() { }

	// RVA: 0xDFC880
	public object .ctor(object id, object task) { }

	// RVA: 0xDFCBD8
	public object UpdateState() { }

	// RVA: 0xDFCCDC
	private object IsHaveDone() { }

	// RVA: 0xDFCFC8
	public object SetState(object state) { }

	// RVA: 0xDFD030
	public object SetState(object bTaskState) { }

	// RVA: 0xDFD098
	public object SetGetTime(object getTime) { }

	// RVA: 0xDFCD9C
	public object SetState(object state) { }

	// RVA: 0xDFD100
	public object IsTaskIDAfterThisTask(object after_taskid) { }

}

// Namespace: Assets.Scripts.GameSystem
public class TaskUT
{

	// Methods

	// RVA: 0xDFD38C
	public static object Create_Task(object taskid) { }

	// RVA: 0xDFD5F8
	public static object Add_Task(object task) { }

	// RVA: 0xDFD8D8
	public static object GetUseableFromReward(object reward_type, object equip_id, object count) { }

	// RVA: 0xDFD984
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTaskGuideWnd
{

	// Fields
	public object ContentWidgets; // 0x78
	public object TabList; // 0x80

	// Methods

	// RVA: 0xDFD98C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTaskModel
{

	// Fields
	public object share_task_id; // 0x8
	public object task_Data; // 0x10
	public object huoyue_data; // 0x18
	public object m_levelRewardDataMap; // 0x20
	private object m_levelRewardFlag; // 0x28
	public object m_curLevelRewardData; // 0x30
	public object mDayTaskActivePoint; // 0x38
	public object mAcntTaskInfo; // 0x40
	public object mCurWeekStarCnt; // 0x48
	public object mCurWeekStarCntLimit; // 0x4C
	public object m_cltCalcCompletedTasks; // 0x50

	// Methods

	// RVA: 0xDFD994
	public object GetLevelIndex(object level) { }

	// RVA: 0xDFDAA4
	public object IsInCltCalcCompletedTasks(object taskid, object task_type) { }

	// RVA: 0xDFDBBC
	public object IsInCltCalcCompletedTasks(object taskid) { }

	// RVA: 0xDFDD24
	public object ParseCltCalcCompletedTasks(object taskids) { }

	// RVA: 0xDFE354
	private object InsertCltCalcCompletedTasks(object taskid, object task_sub_type) { }

	// RVA: 0xDFE650
	public object .ctor() { }

	// RVA: 0xDFEB9C
	public object Clear() { }

	// RVA: 0xDFEDD0
	public object GetMainTask_RedDotCount() { }

	// RVA: 0xDFF1E4
	public object IsShowMainTaskTab_RedDotCount() { }

	// RVA: 0xDFF2E8
	public object IsLevelNode_RedDot(object levelRewardData) { }

	// RVA: 0xDFF454
	public object GetLevelRewardData_Index(object data) { }

	// RVA: 0xDFF554
	public object GetLevelRewardData_ByIndex(object index) { }

	// RVA: 0xDFF640
	public object GetLevelRewardData(object level) { }

	// RVA: 0xDFEFA0
	public object IsGetLevelReward(object level) { }

	// RVA: 0xDFF754
	private object IsGetLevelReward(object flagdata, object level) { }

	// RVA: 0xDFF7D8
	public object ParseLevelRewardData() { }

	// RVA: 0xDFD310
	public object GetTask(object TaskId) { }

	// RVA: 0xDFFF90
	public object AnyTaskOfState(object state, object taskType, object outTask) { }

	// RVA: 0xE001F0
	public object GetTasks(object type) { }

	// RVA: 0xE002CC
	public object GetTotalTaskOfState(object type, object state) { }

	// RVA: 0xE00480
	public object UpdateTaskState() { }

	// RVA: 0xE005B8
	public object IsTaskAllCompelete(object type) { }

	// RVA: 0xE00768
	public object IsAnyTaskInState(object type, object state) { }

	// RVA: 0xDFD6BC
	public object AddTask(object task) { }

	// RVA: 0xE00900
	public object Remove(object task) { }

	// RVA: 0xE00AD0
	public object Remove(object id) { }

	// RVA: 0xE00B80
	public object GetTasks_Count(object type, object state) { }

	// RVA: 0xE00D38
	public object GetMaxIndex_TaskID_InState(object type, object state) { }

	// RVA: 0xE00F98
	public object Load_Share_task() { }

	// RVA: 0xE011E8
	public object SyncDailyTaskActivePointNtf(object ntf) { }

	// RVA: 0xE01250
	public object SyncWeekTaskInfoNtf(object taskinfo) { }

	// RVA: 0xE012B8
	public object SyncWeekStarInfoNtf(object curWeekStarCoin, object curWeekStarCoinLimit) { }

	// RVA: 0xE01334
	public object SyncPlentyTaskRefreshedNtf(object refreshTime) { }

}

// Namespace: Assets.Scripts.GameSystem
public class CombineData
{

	// Fields
	public object task_map; // 0x8
	public object type_taskList_array; // 0x10

	// Methods

	// RVA: 0xDFE770
	public object .ctor() { }

	// RVA: 0xDFEC24
	public object Clear() { }

	// RVA: 0xDFFEC0
	public object GetTask(object uid) { }

	// RVA: 0xE009D0
	public object Add(object uid, object task) { }

	// RVA: 0xE00A54
	public object Remove(object uid) { }

	// RVA: 0xE0176C
	public object Sort(object type) { }

	// RVA: 0xE018D8
	public object GetTask_Count(object type, object state) { }

	// RVA: 0xE00DCC
	public object GetMaxIndex_TaskID_InState(object type, object state) { }

	// RVA: 0xE00148
	public object GetListView(object type) { }

	// RVA: 0xE01A7C
	public object GetListView(object type) { }

	// RVA: 0xE01B24
	private object _sort_main(object l, object r) { }

	// RVA: 0xE01414
	private object _insert(object uid, object task) { }

	// RVA: 0xE015AC
	private object _remove(object uid) { }

	// RVA: 0xE01C28
	private object _getIndex(object task) { }

}

// Namespace: Assets.Scripts.GameSystem
public class HuoyueData
{

	// Fields
	public object have_get_list_day; // 0x8
	public object have_get_list_week; // 0x10
	public object day_curNum; // 0x18
	public object week_curNum; // 0x1C
	public object useable_cfg; // 0x20
	public object day_huoyue_list; // 0x28
	public object weekActList; // 0x30
	public object max_daily_act_num; // 0x38
	public object max_weekly_act_num; // 0x3C

	// Methods

	// RVA: 0xDFEA8C
	public object .ctor() { }

	// RVA: 0xDFED10
	public object Clear() { }

	// RVA: 0xE01D54
	public object GetRewardCfg(object id) { }

	// RVA: 0xE01E50
	public object GetUsable(object id) { }

	// RVA: 0xE01F98
	public object IsInTime(object cfg) { }

	// RVA: 0xE020F8
	public object ParseHuoyuedu(object Cfg) { }

	// RVA: 0xE02538
	private object CalcMaxNum(object ls) { }

	// RVA: 0xE024D4
	private object CalcWeeklyMaxNum() { }

	// RVA: 0xE02470
	private object Calc_Day_Max_Num() { }

	// RVA: 0xE026D4
	public object Set(object type, object num, object length, object ary) { }

	// RVA: 0xE02BC8
	public object Get_Reward(object type, object id) { }

	// RVA: 0xE02900
	public object PrintInfo(object type) { }

	// RVA: 0xE02DF4
	public object BAlready_Reward(object type, object id) { }

}

// Namespace: Assets.Scripts.GameSystem
public class LevelRewardData
{

	// Fields
	public static object TASK_MAX_COUNT; // 0x0
	public static object UNLOCK_MAX_COUNT; // 0x4
	public object m_level; // 0x8
	public object m_resLevelReward; // 0x10
	public object astLockInfo; // 0x18
	public object task_ids; // 0x20

	// Methods

	// RVA: 0xE02EC0
	public object Clear() { }

	// RVA: 0xE02F80
	public object GetConfigRewardCount() { }

	// RVA: 0xDFF060
	public object GetHaveDoneTaskCount() { }

	// RVA: 0xE03048
	public object IsAllLevelTask() { }

	// RVA: 0xE03100
	public object IsHasCltCalcCompeletedTask() { }

	// RVA: 0xE03214
	public object GetValidTaskCount() { }

	// RVA: 0xDFFD60
	public object GetResTaskIDIndex(object id) { }

	// RVA: 0xDFFE24
	public object GetFristNullResTaskIndex() { }

	// RVA: 0xDFFCA4
	public object .ctor() { }

	// RVA: 0xE03384
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
internal class CLobbyActPanel
{

	// Fields
	private static readonly object TASK_NEWBIE_FINISH; // 0x0
	private object newbieTaskFinishForm; // 0x8

	// Methods

	// RVA: 0xE033D8
	public object Init() { }

	// RVA: 0xE03544
	public object UnInit() { }

	// RVA: 0xE036B0
	private object OnClickGetNewbieTaskHeroPanel(object uiEvent) { }

	// RVA: 0xE03898
	private object OnClickFinishNewbieTaskEnsure(object uiEvent) { }

	// RVA: 0xE03A48
	public object .ctor() { }

	// RVA: 0xE03A50
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CTaskSys
{

	// Fields
	private object m_taskGuide; // 0x8
	private object m_ActivityPoint; // 0x10
	public object model; // 0x18
	private object nowTask; // 0x20
	private object m_actPanel; // 0x28
	private object lobbyPkg; // 0x30
	private object bserverDispatchTaskBin; // 0x38

	// Methods

	// RVA: 0xE03ABC
	public override object Init() { }

	// RVA: 0xE03E18
	public object ActivityPoint() { }

	// RVA: 0xE03E78
	public override object UnInit() { }

	// RVA: 0xE041AC
	public object Clear() { }

	// RVA: 0xE04228
	private object UpdateTaskState() { }

	// RVA: 0xE04298
	private object OnTaskResDataNtf() { }

	// RVA: 0xE043C0
	public object OnLobbyNfy(object pkg) { }

	// RVA: 0xE04340
	private object PrepareInitTask() { }

	// RVA: 0xE04924
	private object SendShareTask() { }

	// RVA: 0xE04480
	private object OnInitTask(object gameLoginRep) { }

	// RVA: 0xE04984
	public object GetNowTask() { }

	// RVA: 0xE049E4
	public object SetNowTask(object task) { }

	// RVA: 0xE04A4C
	public object On_TASKUPD_NTF(object pkg) { }

	// RVA: 0xE04EDC
	public object OnUSUALTASK_RES(object pkg) { }

	// RVA: 0xE05290
	public object OnSCID_NEWTASKGET_NTF(object pkg) { }

	// RVA: 0xE05628
	public object OnWeekStarCountUpdate(object curWeekStarCoin, object curWeekStarCoinLimit) { }

	// RVA: 0xE056B8
	public object show_task_award(object taskid, object evtId, object title, object buf) { }

	// RVA: 0xE05A34
	public object IsIDInWeekTask(object taskid) { }

	// RVA: 0xE05F44
	public object show_task_award(object taskid, object evtId, object title) { }

	// RVA: 0xE06600
	public object OnTASKSUBMIT_RES(object pkg) { }

	// RVA: 0xE06848
	public object OnPLENTY_TASK_REFRESHED_RES(object pkg) { }

	// RVA: 0xE069BC
	public object OnSCID_COIN_WEEK_LIMIT_CLEARED_NTY_RES(object pkg) { }

	// RVA: 0xE06B4C
	public object GetTaskItems() { }

	// RVA: 0xE05BF4
	public object GetWeekTaskItems() { }

	// RVA: 0xE06EB0
	public object GetDailyAndWeekTaskItems() { }

	// RVA: 0xE070B4
	public object GetWeeklyRewardCount() { }

	// RVA: 0xE071F4
	public object GetCompletedLevelNumAndMaxLevelNum(object items, object completedLevelNum, object maxLevelNum) { }

	// RVA: 0xE073A0
	public object .ctor() { }

	// RVA: 0xE07480
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE07484
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: Assets.Scripts.GameSystem
public class CDailyTaskView
{

	// Fields
	public static object s_DailyTaskFromPath; // 0x0
	private object mForm; // 0x8
	private object mWidget; // 0x10
	private object mTasks; // 0x18
	private object mExchangeItems; // 0x20
	private object _isJumpFromMsgAssist; // 0x28
	private object byteA; // 0x29
	private object byteB; // 0x2A
	private object weekTimer; // 0x2C

	// Methods

	// RVA: 0xE37214
	public override object Init() { }

	// RVA: 0xE37ADC
	private object OnFormClosed(object uiEvent) { }

	// RVA: 0xE37BC0
	private object OnMsgAssitJumpEvent(object obj) { }

	// RVA: 0xE37CB0
	public override object UnInit() { }

	// RVA: 0xE38350
	public object Clear() { }

	// RVA: 0xE38428
	private object OnDailyTaskGetNewHeroNtf(object id, object addReason) { }

	// RVA: 0xE385A0
	private object OnDailyTaskGetNewSkinNtf(object heroId, object skinId, object addReason) { }

	// RVA: 0xE38720
	private object OnOpenForm(object uiEvent) { }

	// RVA: 0xE38A6C
	private object OnDailyTaskClose(object uiEvent) { }

	// RVA: 0xE38CFC
	private object OnDailyTaskHelp(object uiEvent) { }

	// RVA: 0xE38E24
	private object OnDailyTaskExchange(object uiEvent) { }

	// RVA: 0xE393EC
	private object OnDailyTaskDianQuanHelp(object uiEvent) { }

	// RVA: 0xE39514
	private object OnDailyTaskCanGet(object uiEvent) { }

	// RVA: 0xE39BBC
	private object OnDailyTaskGoComplete(object uiEvent) { }

	// RVA: 0xE39FDC
	private object OnDailyTaskShare(object uIEvent) { }

	// RVA: 0xE3A164
	private object CloseDailyTaskShare(object uiEnvet) { }

	// RVA: 0xE3A288
	private object OnDailyTaskCandidateItemEnable(object uiEvent) { }

	// RVA: 0xE3ACF0
	private object OnDailyTaskExchangeCandidateItemEnable(object uiEvent) { }

	// RVA: 0xE3B818
	public static object UpdateGetItemCell(object formScript, object itemCell, object itemUseable) { }

	// RVA: 0xE38804
	public object Open() { }

	// RVA: 0xE3BE5C
	private object OnTaskUpdate() { }

	// RVA: 0xE3BF38
	private object OnActivityPointUpdate() { }

	// RVA: 0xE3BBDC
	public object UpdatePanel() { }

	// RVA: 0xE3C620
	public object ProcessServerData() { }

	// RVA: 0xE3D69C
	private object SortDataExchangeItem(object a, object b) { }

	// RVA: 0xE3D8B0
	private object SortDataState(object a, object b) { }

	// RVA: 0xE3CC80
	public object UpdateActivityPoint() { }

	// RVA: 0xE3D0D8
	public object UpdateListItem() { }

	// RVA: 0xE3D378
	public object UpdateTimer() { }

	// RVA: 0xE38B50
	public object Close() { }

	// RVA: 0xE3C014
	public static object GetDailyTaskRedPointNum() { }

	// RVA: 0xE3C398
	public static object GetPlentyModeTaskRedPointNum() { }

	// RVA: 0xE3DA74
	public object .ctor() { }

	// RVA: 0xE3DB58
	private static object .cctor() { }

	// RVA: 0xE3DBC4
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE3DBC8
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
private enum MenuTabType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NewbieCheckIn;
	public const object SimpleLevel;
	public const object SimpleTask;
	public const object SimpleWelfare;
}

// Namespace: 
private struct MenuTabItem
{

	// Fields
	public object title; // 0xFFFFFFFFFFFFFFF8
	public object content; // 0x0
	public object onSelected; // 0x8
	public object menuTabType; // 0x10

	// Methods

	// RVA: 0xE48B08
	public object .ctor(object inTitle, object inContent, object inOnSelected, object inMenuTabType) { }

}

// Namespace: 
private struct ItemComparerConverter
{

	// Methods

	// RVA: 0xE4ADAC
	public object Compare(object x, object y) { }

}

// Namespace: 
private class ResNewbieWealCfgComparer
{

	// Methods

	// RVA: 0xE4AF0C
	public object Compare(object x, object y) { }

	// RVA: 0xE4B02C
	public object .ctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class NewSimpleTaskView
{

	// Fields
	private static readonly object NEW_SIMPLE_TASK_PATH; // 0x0
	private object _form; // 0x8
	private object widget; // 0x10
	private object menu; // 0x18
	private object LevelPanel; // 0x20
	private object TimeLimitPanel; // 0x28
	private object NewbieSignPanel; // 0x30
	private object NewbieWeal; // 0x38
	private object mainTask; // 0x40
	private object allTasks_TimeLimit; // 0x48
	private object allInList_TimeLimit; // 0x50
	private object allTasks_Level; // 0x58
	private readonly object newbieWealCfgs; // 0x60
	private readonly object newbieWealInteractableUrl; // 0x68
	private object newbieWealNode; // 0x70
	private const object UTC_STANDARD_ULONG;
	private object secondTimerSequence; // 0x78
	private object recentCloseNewbieWealCloseTime; // 0x80
	private object selectTimeLimitView; // 0x88
	private object lastSelectNewbieWealSheetId; // 0x8C
	private object lastSelectedSheetIndex; // 0x90
	private const object NEWBIE_WEAL_SHEET_INDEX;
	private object menuTabItems; // 0x98
	private object _isJumpFromMsgAssist; // 0xA0
	private object task_id; // 0xA4
	private object taskItem_index; // 0xA8

	// Properties
	private object NeedShowNewbieWeal { get; }

	// Methods

	// RVA: 0xE3DBCC
	private object get_NeedShowNewbieWeal() { }

	// RVA: 0xE3DCE4
	public override object Init() { }

	// RVA: 0xE3E300
	private object OnFormClosed(object uiEvent) { }

	// RVA: 0xE3E3E4
	private object OnMsgAssitJumpEvent(object obj) { }

	// RVA: 0xE3E4D4
	private object OnTaskStateChanged() { }

	// RVA: 0xE42918
	private object OnGetRewardTipBtnDown(object uiEvent) { }

	// RVA: 0xE42C40
	private object OnGetLevelReward(object uiEvent) { }

	// RVA: 0xE42FDC
	private object OnGetReward(object uiEvent) { }

	// RVA: 0xE431AC
	private object OnSelectChanged(object uiEvent) { }

	// RVA: 0xE43490
	private object RefreshNewbieWealTab() { }

	// RVA: 0xE43884
	private object UpdateTimelimitTaskStates(object allTasks) { }

	// RVA: 0xE43FA8
	private object UpdateLevelTaskStates(object allTasks) { }

	// RVA: 0xE444A8
	public object HasUnClainedTask() { }

	// RVA: 0xE450B0
	public object InitConfigTimeLimitTask() { }

	// RVA: 0xE45504
	public object InitConfigLevelTask() { }

	// RVA: 0xE459D8
	private object Relayout(object tasks) { }

	// RVA: 0xE45EBC
	private object getFirstSubTask(object tasks, object num) { }

	// RVA: 0xE40440
	public object RefresLevelView() { }

	// RVA: 0xE46298
	private object RefreshLevelDitail(object res, object task) { }

	// RVA: 0xE46F38
	private object ShowDetailRule(object uiEvent) { }

	// RVA: 0xE47074
	private object OnSelectLevel(object uiEvent) { }

	// RVA: 0xE42D98
	private object ResetRewardViewEffect() { }

	// RVA: 0xE3E694
	public object RefresRewardView(object init) { }

	// RVA: 0xE472EC
	public object OpenForm(object e) { }

	// RVA: 0xE47490
	private object InitUI() { }

	// RVA: 0xE4815C
	private object RefreshTabSelect() { }

	// RVA: 0xE49464
	private object OnSecondTimer(object timerSequence) { }

	// RVA: 0xE48B18
	private object SetNewbieWealUI() { }

	// RVA: 0xE44924
	private object RefreshNewbieWealData() { }

	// RVA: 0xE495C8
	private object IsNewbieWealAvailable(object cfg) { }

	// RVA: 0xE47E30
	private object GetRecentCloseNewbieWealCloseTime() { }

	// RVA: 0xE42330
	private object RefreshTaskReddot() { }

	// RVA: 0xE49AB8
	private object OnNewbieSignDataChanged() { }

	// RVA: 0xE49190
	private object RefreshNewbieCheckinReddot() { }

	// RVA: 0xE49914
	private object GetMenuTabByType(object menuTabType) { }

	// RVA: 0xE49B94
	private object SetNewbieWealReddotAndRefresh() { }

	// RVA: 0xE48EFC
	private object RefreshNewbieWealReddot() { }

	// RVA: 0xE43DB0
	public object isTaskViewShow() { }

	// RVA: 0xE49D6C
	public object CloseForm(object uiEvent) { }

	// RVA: 0xE49F44
	public override object UnInit() { }

	// RVA: 0xE4A528
	private object OnTaskResDataNtf() { }

	// RVA: 0xE4A60C
	private object OnJumpToTask(object uiEvent) { }

	// RVA: 0xE4A85C
	private object OnNewbieWealClick(object uiEvent) { }

	// RVA: 0xE4AB24
	public object .ctor() { }

	// RVA: 0xE4AC6C
	private static object .cctor() { }

	// RVA: 0xE4ACD8
	private object <RefreshTabSelect>b__54_0() { }

	// RVA: 0xE4ACE8
	private object <RefreshTabSelect>b__54_1() { }

	// RVA: 0xE4ACF8
	private object <RefreshTabSelect>b__54_2() { }

	// RVA: 0xE4AD34
	private object <RefreshTabSelect>b__54_3() { }

	// RVA: 0xE4AD58
	public object <>iFixBaseProxy_Init() { }

	// RVA: 0xE4AD5C
	public object <>iFixBaseProxy_UnInit() { }

}

// Namespace: 
public enum TabMainType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Achievement;
	public const object TaskList;
}

// Namespace: 
private class TabItemConfig
{

	// Fields
	public object nameKey; // 0x8
	public object type; // 0x10
	public object childrens; // 0x18

	// Methods

	// RVA: 0xE4C134
	public object .ctor(object key, object t, object ch) { }

}

// Namespace: 
private sealed class <delayShow>d__23
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object tag; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xE4D450
	public object .ctor(object <>1__state) { }

	// RVA: 0xE4D540
	private object System.IDisposable.Dispose() { }

	// RVA: 0xE4D544
	private object MoveNext() { }

	// RVA: 0xE4D5BC
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xE4D5C4
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xE4D604
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Assets.Scripts.GameSystem
public class TaskGuide
{

	// Fields
	private static readonly object TASK_FORM_GUIDE_PATH; // 0x0
	private object m_CUIForm; // 0x8
	private object m_guideWnd; // 0x10
	private object tablMenuList; // 0x18
	private object _rootConfig; // 0x20
	public static readonly object CACHIEVEMENTSYSTEM_REFRESHACHIEVEITEMLIST; // 0x8

	// Methods

	// RVA: 0xE4B084
	public object OnCloseTaskForm() { }

	// RVA: 0xE4B200
	public object Clear() { }

	// RVA: 0xE4B2E0
	public object ShowTaskGuideByType(object guideType) { }

	// RVA: 0xE4B5F8
	private object showTabContent(object type) { }

	// RVA: 0xE4B834
	public object Init() { }

	// RVA: 0xE4BA70
	private object initTabConfig() { }

	// RVA: 0xE4C178
	public object UnInit() { }

	// RVA: 0xE4C3B4
	private static object InitTabItem(object config, object listElementScript) { }

	// RVA: 0xE4C7B8
	public object OpenForm(object uiEvent) { }

	// RVA: 0xE4C958
	private object showForm(object uiEvent) { }

	// RVA: 0xE4CBC0
	private object resizeTabWidth() { }

	// RVA: 0xE4CE40
	public object OnOpenTaskForm(object uiEvent) { }

	// RVA: 0xE4CF28
	public object OnCloseTaskForm(object uiEvent) { }

	// RVA: 0xE4D00C
	private object refreshForm() { }

	// RVA: 0xE4D13C
	public object OnTaskChanged(object uiEvent) { }

	// RVA: 0xE4D324
	private object delayShow(object tag) { }

	// RVA: 0xE4D47C
	public object .ctor() { }

	// RVA: 0xE4D484
	private static object .cctor() { }

}

// Namespace: Assets.Scripts.GameSystem
public class TaskMsgHander
{

	// Fields
	private static object mExchangeLimitCouponsIndex; // 0x0

	// Methods

	// RVA: 0xE4D60C
	public static object OnTaskUpdate(object msg) { }

	// RVA: 0xE4D740
	public static object OnDailyTaskRes(object msg) { }

	// RVA: 0xE4D8A8
	public static object OnSCID_NEWTASKGET_NTF(object msg) { }

	// RVA: 0xE4D9DC
	public static object Send_Update_Task(object taskid) { }

	// RVA: 0xE3998C
	public static object Send_SubmitTask(object taskid) { }

	// RVA: 0xE4DBC4
	public static object Send_ShareTask() { }

	// RVA: 0xE4E050
	public static object OnTASKSUBMIT_RES(object msg) { }

	// RVA: 0xE4E1B8
	public static object Send_Get_Level_Reward_Request(object level) { }

	// RVA: 0xE4E3E4
	public static object OnSCID_GETPVPLEVELREWARD_RSP(object pkg) { }

	// RVA: 0xE4E6A4
	public static object OnSCID_DAYTASK_ACTIVE_POINT_NTF(object pkg) { }

	// RVA: 0xE391A0
	public static object SendExchangeLimitCouponsRequest(object dwID) { }

	// RVA: 0xE4E860
	public static object OnSCID_EXCHANGE_LIMITCOUPONS_RSP(object pkg) { }

	// RVA: 0xE4EBF4
	public static object PlentyTaskRefreshedNtf(object msg) { }

	// RVA: 0xE4ED28
	public static object PlentyStarCoinWeekLimitClearNtf(object msg) { }

	// RVA: 0xE4EE5C
	public object .ctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=12
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=16
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=24
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=28
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=40
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=108
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=112
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=380
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=15438
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=16259
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 28538A14AAA2A50CF39BFFD0BD6D109285A74EDC6F3E53F4BD3BD058997F5C6D; // 0x0
	internal static readonly object 34B5BEEF067E3B9EAB13D40F16C5C8F5E1747DC081D358961D0230F375A0198E; // 0x1C
	internal static readonly object 5CF907617822F3D58E7C7792C75CA6F07D1D9F006AC08B535A27DC5FED5FFE3A; // 0x44
	internal static readonly object 71D23363E65F4978FCDB260B34DBBA6072434B2BB10F30F322E8DFDB936274D6; // 0x54
	internal static readonly object 7274A8E530F60F331648FF72DCCDF36B540E947F9CBCC01D1FDD6946117CB0FC; // 0x64
	internal static readonly object A04E8D2FDA9C23657C0F2D26C0DF4117E04A54FAB28D6C7F1DA72228844F82B3; // 0x7C
	internal static readonly object A811B4626FDFE7DFF2A215D04D77C3E6844DC6A00D79387DE62370BD8F5DA900; // 0xE8
	internal static readonly object AE5CE1D1489A1848B421EB1C830F4E35C13E8B6E2DF89B315247222524556C0A; // 0x100
	internal static readonly object CCF7062CB8604DF4F794C354B1B04A697805D665D472EF99A94B39C9AB30550C; // 0x4083
	internal static readonly object CD9A54ED1F18BF97DB08914E280EA7349E11CA2C4885A4D8052552CEBA84208D; // 0x40F3
	internal static readonly object E2CC2AF5B435B5264D498E934D43305A7992715B1C6777AD75DB8EC1933125D3; // 0x410B
	internal static readonly object E528BF82770304C13BE803E0276464CDE3786CFEBEA8F26592CDB9DAEC958FB6; // 0x7D59
	internal static readonly object E7500CA24094492AC28FC683A3B7055D31B1C04878D4AC112554B7BE4E2C1DCC; // 0x7D65
	internal static readonly object FBF3BC86010D3EA9209008D23A7E96AB698B30827A16E5D58BB5DE8385F3BF31; // 0x7EE1

	// Methods

	// RVA: 0xE4EE64
	internal static object ComputeStringHash(object s) { }

}

// Namespace: IFix
public class ILFixDynamicMethodWrapper
{

	// Fields
	private object virtualMachine; // 0x8
	private object methodId; // 0x10
	private object anonObj; // 0x18
	public static object wrapperArray; // 0x0

	// Methods

	// RVA: 0xE07488
	public object .ctor(object virtualMachine, object methodId, object anonObj) { }

	// RVA: 0xE074CC
	public object __Gen_Wrap_0(object P0, object P1) { }

	// RVA: 0xE07584
	public object __Gen_Wrap_1(object P0) { }

	// RVA: 0xE07620
	public object __Gen_Wrap_2(object P0, object P1) { }

	// RVA: 0xE076E8
	public object __Gen_Wrap_3() { }

	// RVA: 0xE07778
	public object __Gen_Wrap_4(object P0) { }

	// RVA: 0xE07854
	public object __Gen_Wrap_5(object P0) { }

	// RVA: 0xE07930
	public object __Gen_Wrap_6(object P0) { }

	// RVA: 0xE07A0C
	public object __Gen_Wrap_7(object P0) { }

	// RVA: 0xE07AE8
	public object __Gen_Wrap_8(object P0) { }

	// RVA: 0xE07BC4
	public object __Gen_Wrap_9(object P0) { }

	// RVA: 0xE07CA0
	public object __Gen_Wrap_10(object P0) { }

	// RVA: 0xE07D7C
	public object __Gen_Wrap_11(object P0) { }

	// RVA: 0xE07E58
	public object __Gen_Wrap_12(object P0) { }

	// RVA: 0xE07F34
	public object __Gen_Wrap_13(object P0) { }

	// RVA: 0xE08010
	public object __Gen_Wrap_14() { }

	// RVA: 0xE080D8
	public object __Gen_Wrap_15(object P0) { }

	// RVA: 0xE081B4
	public object __Gen_Wrap_16(object P0) { }

	// RVA: 0xE08290
	public object __Gen_Wrap_17(object P0) { }

	// RVA: 0xE0836C
	public object __Gen_Wrap_18(object P0, object P1) { }

	// RVA: 0xE08434
	public object __Gen_Wrap_19(object P0) { }

	// RVA: 0xE084E0
	public object __Gen_Wrap_20(object P0) { }

	// RVA: 0xE0858C
	public object __Gen_Wrap_21(object P0) { }

	// RVA: 0xE08638
	public object __Gen_Wrap_22(object P0, object P1) { }

	// RVA: 0xE08728
	public object __Gen_Wrap_23(object P0, object P1, object P2) { }

	// RVA: 0xE08804
	public object __Gen_Wrap_24() { }

	// RVA: 0xE088A4
	public object __Gen_Wrap_25(object P0) { }

	// RVA: 0xE08980
	public object __Gen_Wrap_26(object P0) { }

	// RVA: 0xE08A5C
	public object __Gen_Wrap_27(object P0) { }

	// RVA: 0xE08B38
	public object __Gen_Wrap_28(object P0) { }

	// RVA: 0xE08C14
	public object __Gen_Wrap_29(object P0) { }

	// RVA: 0xE08CF0
	public object __Gen_Wrap_30(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE08DE8
	public object __Gen_Wrap_31(object P0, object P1) { }

	// RVA: 0xE08EB0
	public object __Gen_Wrap_32(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE0903C
	public object __Gen_Wrap_33(object P0, object P1) { }

	// RVA: 0xE09104
	public object __Gen_Wrap_34(object P0, object P1, object P2) { }

	// RVA: 0xE091D0
	public object __Gen_Wrap_35(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE092C8
	public object __Gen_Wrap_36(object P0, object P1, object P2) { }

	// RVA: 0xE093A4
	public object __Gen_Wrap_37(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE09520
	public object __Gen_Wrap_38(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE0965C
	public object __Gen_Wrap_39(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0977C
	public object __Gen_Wrap_40() { }

	// RVA: 0xE09844
	public object __Gen_Wrap_41(object P0, object P1) { }

	// RVA: 0xE09934
	public object __Gen_Wrap_42(object P0) { }

	// RVA: 0xE09A10
	public object __Gen_Wrap_43(object P0, object P1) { }

	// RVA: 0xE09B00
	public object __Gen_Wrap_44(object P0) { }

	// RVA: 0xE09BAC
	public object __Gen_Wrap_45(object P0, object P1) { }

	// RVA: 0xE09C64
	public object __Gen_Wrap_46(object P0, object P1, object P2) { }

	// RVA: 0xE09D30
	public object __Gen_Wrap_47(object P0, object P1) { }

	// RVA: 0xE09DE8
	public object __Gen_Wrap_48(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE09F08
	public object __Gen_Wrap_49(object P0, object P1) { }

	// RVA: 0xE0A024
	public object __Gen_Wrap_50(object P0, object P1, object P2) { }

	// RVA: 0xE0A100
	public object __Gen_Wrap_51(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE0A2C8
	public object __Gen_Wrap_52(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0A3E8
	public object __Gen_Wrap_53(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10) { }

	// RVA: 0xE0A5B4
	public object __Gen_Wrap_54(object P0, object P1) { }

	// RVA: 0xE0A6D4
	public object __Gen_Wrap_55(object P0) { }

	// RVA: 0xE0A780
	public object __Gen_Wrap_56(object P0) { }

	// RVA: 0xE0A85C
	public object __Gen_Wrap_57(object P0) { }

	// RVA: 0xE0A908
	public object __Gen_Wrap_58(object P0) { }

	// RVA: 0xE0A9B4
	public object __Gen_Wrap_59(object P0, object P1) { }

	// RVA: 0xE0AAB0
	public object __Gen_Wrap_60(object P0) { }

	// RVA: 0xE0AB8C
	public object __Gen_Wrap_61(object P0, object P1) { }

	// RVA: 0xE0AC7C
	public object __Gen_Wrap_62(object P0, object P1) { }

	// RVA: 0xE0AD44
	public object __Gen_Wrap_63(object P0) { }

	// RVA: 0xE0ADF0
	public object __Gen_Wrap_64(object P0, object P1) { }

	// RVA: 0xE0AEB8
	public object __Gen_Wrap_65(object P0, object P1, object P2) { }

	// RVA: 0xE0B004
	public object __Gen_Wrap_66(object P0, object P1, object P2) { }

	// RVA: 0xE0B150
	public object __Gen_Wrap_67(object P0) { }

	// RVA: 0xE0B22C
	public object __Gen_Wrap_68(object P0, object P1, object P2) { }

	// RVA: 0xE0B338
	public object __Gen_Wrap_69(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0B4A8
	public object __Gen_Wrap_70(object P0, object P1, object P2) { }

	// RVA: 0xE0B574
	public object __Gen_Wrap_71(object P0) { }

	// RVA: 0xE0B650
	public object __Gen_Wrap_72(object P0) { }

	// RVA: 0xE0B6FC
	public object __Gen_Wrap_73(object P0, object P1) { }

	// RVA: 0xE0B7B4
	public object __Gen_Wrap_74(object P0, object P1, object P2) { }

	// RVA: 0xE0B880
	public object __Gen_Wrap_75(object P0, object P1) { }

	// RVA: 0xE0B970
	public object __Gen_Wrap_76(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0BA9C
	public object __Gen_Wrap_77(object P0) { }

	// RVA: 0xE0BB38
	public object __Gen_Wrap_78(object P0, object P1) { }

	// RVA: 0xE0BC28
	public object __Gen_Wrap_79(object P0, object P1) { }

	// RVA: 0xE0BCF0
	public object __Gen_Wrap_80(object P0) { }

	// RVA: 0xE0BD9C
	public object __Gen_Wrap_81() { }

	// RVA: 0xE0BE64
	public object __Gen_Wrap_82(object P0) { }

	// RVA: 0xE0BF00
	public object __Gen_Wrap_83(object P0) { }

	// RVA: 0xE0BFAC
	public object __Gen_Wrap_84() { }

	// RVA: 0xE0C04C
	public object __Gen_Wrap_85(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE0C188
	public object __Gen_Wrap_86(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0C270
	public object __Gen_Wrap_87(object P0, object P1, object P2) { }

	// RVA: 0xE0C37C
	public object __Gen_Wrap_88(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE0C4EC
	public object __Gen_Wrap_89(object P0, object P1) { }

	// RVA: 0xE0C5B4
	public object __Gen_Wrap_90(object P0, object P1, object P2) { }

	// RVA: 0xE0C680
	public object __Gen_Wrap_91(object P0) { }

	// RVA: 0xE0C75C
	public object __Gen_Wrap_92(object P0) { }

	// RVA: 0xE0C838
	public object __Gen_Wrap_93(object P0) { }

	// RVA: 0xE0C914
	public object __Gen_Wrap_94(object P0) { }

	// RVA: 0xE0C9F0
	public object __Gen_Wrap_95(object P0) { }

	// RVA: 0xE0CA8C
	public object __Gen_Wrap_96(object P0, object P1, object P2) { }

	// RVA: 0xE0CB58
	public object __Gen_Wrap_97(object P0) { }

	// RVA: 0xE0CC04
	public object __Gen_Wrap_98(object P0) { }

	// RVA: 0xE0CD08
	public object __Gen_Wrap_99(object P0) { }

	// RVA: 0xE0CDB4
	public object __Gen_Wrap_100(object P0, object P1) { }

	// RVA: 0xE0CE7C
	public object __Gen_Wrap_101(object P0, object P1, object P2) { }

	// RVA: 0xE0CFD8
	public object __Gen_Wrap_102(object P0, object P1) { }

	// RVA: 0xE0D0A0
	public object __Gen_Wrap_103(object P0) { }

	// RVA: 0xE0D14C
	public object __Gen_Wrap_104(object P0) { }

	// RVA: 0xE0D1F8
	public object __Gen_Wrap_105(object P0, object P1) { }

	// RVA: 0xE0D318
	public object __Gen_Wrap_106(object P0) { }

	// RVA: 0xE0D41C
	public object __Gen_Wrap_107(object P0, object P1) { }

	// RVA: 0xE0D4E4
	public object __Gen_Wrap_108(object P0, object P1) { }

	// RVA: 0xE0D5D8
	public object __Gen_Wrap_109(object P0) { }

	// RVA: 0xE0D6B4
	public object __Gen_Wrap_110(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0D79C
	public object __Gen_Wrap_111(object P0, object P1, object P2) { }

	// RVA: 0xE0D868
	public object __Gen_Wrap_112(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0D950
	public object __Gen_Wrap_113(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE0DA4C
	public object __Gen_Wrap_114(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0DB34
	public object __Gen_Wrap_115(object P0, object P1) { }

	// RVA: 0xE0DBFC
	public object __Gen_Wrap_116(object P0, object P1) { }

	// RVA: 0xE0DCB4
	public object __Gen_Wrap_117(object P0, object P1) { }

	// RVA: 0xE0DDA8
	public object __Gen_Wrap_118(object P0) { }

	// RVA: 0xE0DE84
	public object __Gen_Wrap_119(object P0, object P1) { }

	// RVA: 0xE0DF4C
	public object __Gen_Wrap_120(object P0, object P1) { }

	// RVA: 0xE0E014
	public object __Gen_Wrap_121(object P0, object P1) { }

	// RVA: 0xE0E0DC
	public object __Gen_Wrap_122(object P0, object P1) { }

	// RVA: 0xE0E1A4
	public object __Gen_Wrap_123(object P0, object P1, object P2) { }

	// RVA: 0xE0E280
	public object __Gen_Wrap_124(object P0, object P1, object P2) { }

	// RVA: 0xE0E38C
	public object __Gen_Wrap_125(object P0) { }

	// RVA: 0xE0E468
	public object __Gen_Wrap_126(object P0, object P1) { }

	// RVA: 0xE0E558
	public object __Gen_Wrap_127() { }

	// RVA: 0xE0E620
	public object __Gen_Wrap_128(object P0) { }

	// RVA: 0xE0E6FC
	public object __Gen_Wrap_129(object P0) { }

	// RVA: 0xE0E7D8
	public object __Gen_Wrap_130(object P0, object P1) { }

	// RVA: 0xE0E8A0
	public object __Gen_Wrap_131() { }

	// RVA: 0xE0E968
	public object __Gen_Wrap_132(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0EAC8
	public object __Gen_Wrap_133(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0EC00
	public object __Gen_Wrap_134(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0ECF8
	public object __Gen_Wrap_135(object P0, object P1, object P2) { }

	// RVA: 0xE0EE24
	public object __Gen_Wrap_136(object P0, object P1, object P2) { }

	// RVA: 0xE0EEF0
	public object __Gen_Wrap_137(object P0, object P1, object P2) { }

	// RVA: 0xE0EFBC
	public object __Gen_Wrap_138(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0F0A4
	public object __Gen_Wrap_139(object P0) { }

	// RVA: 0xE0F180
	public object __Gen_Wrap_140(object P0, object P1) { }

	// RVA: 0xE0F270
	public object __Gen_Wrap_141(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0F358
	public object __Gen_Wrap_142(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0F490
	public object __Gen_Wrap_143(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE0F578
	public object __Gen_Wrap_144(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE0F674
	public object __Gen_Wrap_145(object P0, object P1) { }

	// RVA: 0xE0F7A4
	public object __Gen_Wrap_146(object P0, object P1) { }

	// RVA: 0xE0F8B0
	public object __Gen_Wrap_147(object P0, object P1) { }

	// RVA: 0xE0F9A0
	public object __Gen_Wrap_148(object P0, object P1, object P2) { }

	// RVA: 0xE0FAD8
	public object __Gen_Wrap_149(object P0, object P1) { }

	// RVA: 0xE0FBC8
	public object __Gen_Wrap_150(object P0) { }

	// RVA: 0xE0FC74
	public object __Gen_Wrap_151(object P0) { }

	// RVA: 0xE0FD50
	public object __Gen_Wrap_152(object P0) { }

	// RVA: 0xE0FDFC
	public object __Gen_Wrap_153(object P0, object P1) { }

	// RVA: 0xE0FEB4
	public object __Gen_Wrap_154(object P0) { }

	// RVA: 0xE0FF60
	public object __Gen_Wrap_155() { }

	// RVA: 0xE10028
	public object __Gen_Wrap_156(object P0) { }

	// RVA: 0xE100C4
	public object __Gen_Wrap_157(object P0, object P1, object P2) { }

	// RVA: 0xE101FC
	public object __Gen_Wrap_158(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE10348
	public object __Gen_Wrap_159(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE104B8
	public object __Gen_Wrap_160(object P0, object P1) { }

	// RVA: 0xE105A8
	public object __Gen_Wrap_161(object P0, object P1) { }

	// RVA: 0xE10670
	public object __Gen_Wrap_162(object P0, object P1) { }

	// RVA: 0xE10760
	public object __Gen_Wrap_163(object P0) { }

	// RVA: 0xE1083C
	public object __Gen_Wrap_164(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE109C0
	public object __Gen_Wrap_165(object P0, object P1, object P2) { }

	// RVA: 0xE10B1C
	public object __Gen_Wrap_166(object P0, object P1) { }

	// RVA: 0xE10C00
	public object __Gen_Wrap_167(object P0) { }

	// RVA: 0xE10CDC
	public object __Gen_Wrap_168(object P0) { }

	// RVA: 0xE10DB8
	public object __Gen_Wrap_169(object P0) { }

	// RVA: 0xE10E94
	public object __Gen_Wrap_170(object P0) { }

	// RVA: 0xE10F70
	public object __Gen_Wrap_171(object P0, object P1) { }

	// RVA: 0xE11028
	public object __Gen_Wrap_172(object P0, object P1) { }

	// RVA: 0xE11118
	public object __Gen_Wrap_173(object P0, object P1) { }

	// RVA: 0xE11208
	public object __Gen_Wrap_174(object P0, object P1) { }

	// RVA: 0xE112D0
	public object __Gen_Wrap_175(object P0, object P1) { }

	// RVA: 0xE113C0
	public object __Gen_Wrap_176(object P0) { }

	// RVA: 0xE1146C
	public object __Gen_Wrap_177(object P0, object P1) { }

	// RVA: 0xE1155C
	public object __Gen_Wrap_178(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE11688
	public object __Gen_Wrap_179(object P0, object P1) { }

	// RVA: 0xE11740
	public object __Gen_Wrap_180(object P0) { }

	// RVA: 0xE117EC
	public object __Gen_Wrap_181(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE11924
	public object __Gen_Wrap_182(object P0, object P1) { }

	// RVA: 0xE119EC
	public object __Gen_Wrap_183(object P0) { }

	// RVA: 0xE11A98
	public object __Gen_Wrap_184(object P0, object P1) { }

	// RVA: 0xE11B60
	public object __Gen_Wrap_185(object P0, object P1) { }

	// RVA: 0xE11C50
	public object __Gen_Wrap_186(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE11D70
	public object __Gen_Wrap_187(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE11EF0
	public object __Gen_Wrap_188(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10) { }

	// RVA: 0xE120B8
	public object __Gen_Wrap_189(object P0, object P1, object P2) { }

	// RVA: 0xE12194
	public object __Gen_Wrap_190() { }

	// RVA: 0xE1225C
	public object __Gen_Wrap_191(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE123B4
	public object __Gen_Wrap_192(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE12504
	public object __Gen_Wrap_193(object P0, object P1) { }

	// RVA: 0xE125CC
	public object __Gen_Wrap_194(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE12738
	public object __Gen_Wrap_195(object P0, object P1, object P2) { }

	// RVA: 0xE12844
	public object __Gen_Wrap_196(object P0, object P1, object P2) { }

	// RVA: 0xE12988
	public object __Gen_Wrap_197(object P0) { }

	// RVA: 0xE12A64
	public object __Gen_Wrap_198(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE12B4C
	public object __Gen_Wrap_199(object P0) { }

	// RVA: 0xE12BE8
	public object __Gen_Wrap_200(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE12CD0
	public object __Gen_Wrap_201(object P0, object P1, object P2) { }

	// RVA: 0xE12DDC
	public object __Gen_Wrap_202(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE12F44
	public object __Gen_Wrap_203(object P0, object P1, object P2) { }

	// RVA: 0xE13020
	public object __Gen_Wrap_204(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9) { }

	// RVA: 0xE131DC
	public object __Gen_Wrap_205(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE13368
	public object __Gen_Wrap_206(object P0, object P1) { }

	// RVA: 0xE13458
	public object __Gen_Wrap_207(object P0, object P1, object P2) { }

	// RVA: 0xE13564
	public object __Gen_Wrap_208(object P0) { }

	// RVA: 0xE13640
	public object __Gen_Wrap_209(object P0) { }

	// RVA: 0xE1371C
	public object __Gen_Wrap_210(object P0) { }

	// RVA: 0xE137F8
	public object __Gen_Wrap_211(object P0) { }

	// RVA: 0xE138D4
	public object __Gen_Wrap_212(object P0, object P1) { }

	// RVA: 0xE139C4
	public object __Gen_Wrap_213(object P0, object P1) { }

	// RVA: 0xE13AB4
	public object __Gen_Wrap_214(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE13B9C
	public object __Gen_Wrap_215(object P0, object P1, object P2) { }

	// RVA: 0xE13CC8
	public object __Gen_Wrap_216(object P0, object P1) { }

	// RVA: 0xE13D80
	public object __Gen_Wrap_217(object P0) { }

	// RVA: 0xE13E2C
	public object __Gen_Wrap_218(object P0) { }

	// RVA: 0xE13ED8
	public object __Gen_Wrap_219(object P0, object P1) { }

	// RVA: 0xE13F90
	public object __Gen_Wrap_220(object P0, object P1, object P2) { }

	// RVA: 0xE1405C
	public object __Gen_Wrap_221(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1419C
	public object __Gen_Wrap_222(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE14298
	public object __Gen_Wrap_223(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE14390
	public object __Gen_Wrap_224(object P0, object P1) { }

	// RVA: 0xE14458
	public object __Gen_Wrap_225(object P0) { }

	// RVA: 0xE14534
	public object __Gen_Wrap_226(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1461C
	public object __Gen_Wrap_227(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE14704
	public object __Gen_Wrap_228(object P0, object P1) { }

	// RVA: 0xE147F4
	public object __Gen_Wrap_229(object P0) { }

	// RVA: 0xE148D0
	public object __Gen_Wrap_230(object P0) { }

	// RVA: 0xE149AC
	public object __Gen_Wrap_231(object P0, object P1) { }

	// RVA: 0xE14A9C
	public object __Gen_Wrap_232(object P0, object P1, object P2) { }

	// RVA: 0xE14B78
	public object __Gen_Wrap_233(object P0, object P1) { }

	// RVA: 0xE14C68
	public object __Gen_Wrap_234(object P0, object P1) { }

	// RVA: 0xE14D30
	public object __Gen_Wrap_235(object P0, object P1) { }

	// RVA: 0xE14E20
	public object __Gen_Wrap_236(object P0, object P1) { }

	// RVA: 0xE14ED8
	public object __Gen_Wrap_237(object P0, object P1) { }

	// RVA: 0xE14FA0
	public object __Gen_Wrap_238(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE15088
	public object __Gen_Wrap_239(object P0) { }

	// RVA: 0xE15134
	public object __Gen_Wrap_240(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE15288
	public object __Gen_Wrap_241(object P0, object P1) { }

	// RVA: 0xE15340
	public object __Gen_Wrap_242(object P0, object P1) { }

	// RVA: 0xE15408
	public object __Gen_Wrap_243(object P0, object P1, object P2) { }

	// RVA: 0xE154E4
	public object __Gen_Wrap_244(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE155FC
	public object __Gen_Wrap_245(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE15778
	public object __Gen_Wrap_246(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE15884
	public object __Gen_Wrap_247(object P0, object P1, object P2) { }

	// RVA: 0xE15950
	public object __Gen_Wrap_248(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE15A88
	public object __Gen_Wrap_249(object P0) { }

	// RVA: 0xE15B64
	public object __Gen_Wrap_250(object P0) { }

	// RVA: 0xE15C40
	public object __Gen_Wrap_251(object P0, object P1, object P2) { }

	// RVA: 0xE15D1C
	public object __Gen_Wrap_252(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE15E58
	public object __Gen_Wrap_253(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE15F78
	public object __Gen_Wrap_254(object P0, object P1) { }

	// RVA: 0xE16068
	public object __Gen_Wrap_255(object P0) { }

	// RVA: 0xE16144
	public object __Gen_Wrap_256(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE16264
	public object __Gen_Wrap_257(object P0, object P1) { }

	// RVA: 0xE16354
	public object __Gen_Wrap_258(object P0, object P1) { }

	// RVA: 0xE1641C
	public object __Gen_Wrap_259(object P0) { }

	// RVA: 0xE164F8
	public object __Gen_Wrap_260(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7) { }

	// RVA: 0xE16640
	public object __Gen_Wrap_261(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE1676C
	public object __Gen_Wrap_262(object P0) { }

	// RVA: 0xE16818
	public object __Gen_Wrap_263(object P0, object P1, object P2) { }

	// RVA: 0xE168F4
	public object __Gen_Wrap_264(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE169F0
	public object __Gen_Wrap_265(object P0, object P1) { }

	// RVA: 0xE16AA8
	public object __Gen_Wrap_266(object P0, object P1) { }

	// RVA: 0xE16B60
	public object __Gen_Wrap_267(object P0) { }

	// RVA: 0xE16C0C
	public object __Gen_Wrap_268(object P0) { }

	// RVA: 0xE16CA8
	public object __Gen_Wrap_269(object P0) { }

	// RVA: 0xE16D44
	public object __Gen_Wrap_270(object P0, object P1) { }

	// RVA: 0xE16DFC
	public object __Gen_Wrap_271() { }

	// RVA: 0xE16EC4
	public object __Gen_Wrap_272(object P0, object P1, object P2) { }

	// RVA: 0xE16F90
	public object __Gen_Wrap_273(object P0) { }

	// RVA: 0xE1703C
	public object __Gen_Wrap_274(object P0) { }

	// RVA: 0xE170E8
	public object __Gen_Wrap_275(object P0, object P1) { }

	// RVA: 0xE171D8
	public object __Gen_Wrap_276(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE172F8
	public object __Gen_Wrap_277(object P0, object P1, object P2) { }

	// RVA: 0xE17404
	public object __Gen_Wrap_278(object P0, object P1, object P2) { }

	// RVA: 0xE17510
	public object __Gen_Wrap_279(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10, object P11) { }

	// RVA: 0xE1782C
	public object __Gen_Wrap_280(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE17968
	public object __Gen_Wrap_281(object P0, object P1) { }

	// RVA: 0xE17ACC
	public object __Gen_Wrap_282(object P0, object P1, object P2) { }

	// RVA: 0xE17BF4
	public object __Gen_Wrap_283() { }

	// RVA: 0xE17CBC
	public object __Gen_Wrap_284(object P0, object P1) { }

	// RVA: 0xE17D84
	public object __Gen_Wrap_285(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE17E9C
	public object __Gen_Wrap_286(object P0, object P1, object P2) { }

	// RVA: 0xE17FA8
	public object __Gen_Wrap_287(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE180A4
	public object __Gen_Wrap_288(object P0, object P1, object P2) { }

	// RVA: 0xE181B0
	public object __Gen_Wrap_289(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE18340
	public object __Gen_Wrap_290(object P0, object P1, object P2) { }

	// RVA: 0xE1844C
	public object __Gen_Wrap_291(object P0, object P1) { }

	// RVA: 0xE1853C
	public object __Gen_Wrap_292(object P0, object P1, object P2) { }

	// RVA: 0xE18648
	public object __Gen_Wrap_293(object P0, object P1, object P2) { }

	// RVA: 0xE18754
	public object __Gen_Wrap_294(object P0, object P1, object P2) { }

	// RVA: 0xE18820
	public object __Gen_Wrap_295() { }

	// RVA: 0xE188E8
	public object __Gen_Wrap_296(object P0, object P1, object P2) { }

	// RVA: 0xE189C4
	public object __Gen_Wrap_297(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE18B00
	public object __Gen_Wrap_298(object P0, object P1) { }

	// RVA: 0xE18C8C
	public object __Gen_Wrap_299(object P0, object P1) { }

	// RVA: 0xE18D8C
	public object __Gen_Wrap_300(object P0, object P1, object P2) { }

	// RVA: 0xE18EE8
	public object __Gen_Wrap_301(object P0) { }

	// RVA: 0xE18F94
	public object __Gen_Wrap_302(object P0, object P1) { }

	// RVA: 0xE19084
	public object __Gen_Wrap_303(object P0, object P1, object P2) { }

	// RVA: 0xE19190
	public object __Gen_Wrap_304(object P0, object P1, object P2) { }

	// RVA: 0xE1926C
	public object __Gen_Wrap_305(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE19378
	public object __Gen_Wrap_306(object P0) { }

	// RVA: 0xE19454
	public object __Gen_Wrap_307(object P0) { }

	// RVA: 0xE19530
	public object __Gen_Wrap_308() { }

	// RVA: 0xE195F8
	public object __Gen_Wrap_309(object P0, object P1, object P2) { }

	// RVA: 0xE196C4
	public object __Gen_Wrap_310() { }

	// RVA: 0xE1978C
	public object __Gen_Wrap_311(object P0) { }

	// RVA: 0xE19868
	public object __Gen_Wrap_312(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE19950
	public object __Gen_Wrap_313(object P0, object P1, object P2) { }

	// RVA: 0xE19A1C
	public object __Gen_Wrap_314(object P0, object P1, object P2) { }

	// RVA: 0xE19AE8
	public object __Gen_Wrap_315(object P0) { }

	// RVA: 0xE19BC4
	public object __Gen_Wrap_316() { }

	// RVA: 0xE19C8C
	public object __Gen_Wrap_317(object P0) { }

	// RVA: 0xE19D68
	public object __Gen_Wrap_318(object P0, object P1) { }

	// RVA: 0xE19E30
	public object __Gen_Wrap_319(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE19F18
	public object __Gen_Wrap_320(object P0, object P1) { }

	// RVA: 0xE19FD0
	public object __Gen_Wrap_321(object P0, object P1, object P2) { }

	// RVA: 0xE1A0AC
	public object __Gen_Wrap_322(object P0) { }

	// RVA: 0xE1A158
	public object __Gen_Wrap_323(object P0) { }

	// RVA: 0xE1A234
	public object __Gen_Wrap_324(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE1A330
	public object __Gen_Wrap_325(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1A418
	public object __Gen_Wrap_326(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1A500
	public object __Gen_Wrap_327(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1A5F8
	public object __Gen_Wrap_328(object P0, object P1) { }

	// RVA: 0xE1A704
	public object __Gen_Wrap_329(object P0, object P1, object P2) { }

	// RVA: 0xE1A820
	public object __Gen_Wrap_330(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1A918
	public object __Gen_Wrap_331(object P0, object P1, object P2) { }

	// RVA: 0xE1A9E4
	public object __Gen_Wrap_332(object P0) { }

	// RVA: 0xE1AA80
	public object __Gen_Wrap_333(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1AB68
	public object __Gen_Wrap_334(object P0, object P1, object P2) { }

	// RVA: 0xE1AC34
	public object __Gen_Wrap_335(object P0) { }

	// RVA: 0xE1AD2C
	public object __Gen_Wrap_336(object P0, object P1, object P2) { }

	// RVA: 0xE1ADF8
	public object __Gen_Wrap_337(object P0, object P1, object P2) { }

	// RVA: 0xE1AED4
	public object __Gen_Wrap_338(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1AFCC
	public object __Gen_Wrap_339(object P0) { }

	// RVA: 0xE1B0A8
	public object __Gen_Wrap_340(object P0, object P1) { }

	// RVA: 0xE1B160
	public object __Gen_Wrap_341(object P0, object P1, object P2) { }

	// RVA: 0xE1B22C
	public object __Gen_Wrap_342(object P0, object P1, object P2) { }

	// RVA: 0xE1B2F8
	public object __Gen_Wrap_343(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1B3E0
	public object __Gen_Wrap_344(object P0, object P1) { }

	// RVA: 0xE1B498
	public object __Gen_Wrap_345(object P0, object P1, object P2) { }

	// RVA: 0xE1B574
	public object __Gen_Wrap_346(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1B65C
	public object __Gen_Wrap_347(object P0, object P1) { }

	// RVA: 0xE1B74C
	public object __Gen_Wrap_348(object P0, object P1, object P2) { }

	// RVA: 0xE1B858
	public object __Gen_Wrap_349(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1B978
	public object __Gen_Wrap_350(object P0, object P1) { }

	// RVA: 0xE1BA30
	public object __Gen_Wrap_351(object P0) { }

	// RVA: 0xE1BB0C
	public object __Gen_Wrap_352(object P0, object P1) { }

	// RVA: 0xE1BBFC
	public object __Gen_Wrap_353(object P0, object P1) { }

	// RVA: 0xE1BCEC
	public object __Gen_Wrap_354(object P0) { }

	// RVA: 0xE1BD98
	public object __Gen_Wrap_355(object P0, object P1) { }

	// RVA: 0xE1BE50
	public object __Gen_Wrap_356(object P0) { }

	// RVA: 0xE1BEFC
	public object __Gen_Wrap_357(object P0, object P1) { }

	// RVA: 0xE1BFB4
	public object __Gen_Wrap_358(object P0) { }

	// RVA: 0xE1C090
	public object __Gen_Wrap_359(object P0, object P1) { }

	// RVA: 0xE1C158
	public object __Gen_Wrap_360(object P0) { }

	// RVA: 0xE1C234
	public object __Gen_Wrap_361(object P0) { }

	// RVA: 0xE1C310
	public object __Gen_Wrap_362(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1C3F8
	public object __Gen_Wrap_363(object P0, object P1) { }

	// RVA: 0xE1C4E8
	public object __Gen_Wrap_364(object P0, object P1, object P2) { }

	// RVA: 0xE1C5F4
	public object __Gen_Wrap_365(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1C6DC
	public object __Gen_Wrap_366(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE1C844
	public object __Gen_Wrap_367(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE1C980
	public object __Gen_Wrap_368(object P0, object P1) { }

	// RVA: 0xE1CA9C
	public object __Gen_Wrap_369(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1CB94
	public object __Gen_Wrap_370(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE1CCD0
	public object __Gen_Wrap_371(object P0, object P1) { }

	// RVA: 0xE1CDC0
	public object __Gen_Wrap_372(object P0, object P1, object P2) { }

	// RVA: 0xE1CE9C
	public object __Gen_Wrap_373(object P0) { }

	// RVA: 0xE1CF48
	public object __Gen_Wrap_374(object P0) { }

	// RVA: 0xE1CFE4
	public object __Gen_Wrap_375(object P0, object P1) { }

	// RVA: 0xE1D09C
	public object __Gen_Wrap_376(object P0) { }

	// RVA: 0xE1D178
	public object __Gen_Wrap_377(object P0, object P1, object P2) { }

	// RVA: 0xE1D298
	public object __Gen_Wrap_378(object P0, object P1, object P2) { }

	// RVA: 0xE1D364
	public object __Gen_Wrap_379(object P0) { }

	// RVA: 0xE1D400
	public object __Gen_Wrap_380(object P0, object P1, object P2) { }

	// RVA: 0xE1D4CC
	public object __Gen_Wrap_381(object P0, object P1) { }

	// RVA: 0xE1D5D0
	public object __Gen_Wrap_382(object P0, object P1, object P2) { }

	// RVA: 0xE1D69C
	public object __Gen_Wrap_383(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1D784
	public object __Gen_Wrap_384(object P0, object P1, object P2) { }

	// RVA: 0xE1D890
	public object __Gen_Wrap_385(object P0) { }

	// RVA: 0xE1D93C
	public object __Gen_Wrap_386(object P0) { }

	// RVA: 0xE1D9D8
	public object __Gen_Wrap_387(object P0, object P1) { }

	// RVA: 0xE1DAC8
	public object __Gen_Wrap_388(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1DBB0
	public object __Gen_Wrap_389(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1DCD0
	public object __Gen_Wrap_390(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE1DDCC
	public object __Gen_Wrap_391(object P0) { }

	// RVA: 0xE1DEA8
	public object __Gen_Wrap_392(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8) { }

	// RVA: 0xE1E004
	public object __Gen_Wrap_393(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1E0EC
	public object __Gen_Wrap_394(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1E1D4
	public object __Gen_Wrap_395(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1E2BC
	public object __Gen_Wrap_396(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1E3A4
	public object __Gen_Wrap_397(object P0, object P1, object P2) { }

	// RVA: 0xE1E470
	public object __Gen_Wrap_398(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE1E588
	public object __Gen_Wrap_399(object P0, object P1) { }

	// RVA: 0xE1E678
	public object __Gen_Wrap_400(object P0) { }

	// RVA: 0xE1E754
	public object __Gen_Wrap_401(object P0, object P1) { }

	// RVA: 0xE1E80C
	public object __Gen_Wrap_402(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1E958
	public object __Gen_Wrap_403(object P0, object P1, object P2) { }

	// RVA: 0xE1EA64
	public object __Gen_Wrap_404(object P0, object P1, object P2) { }

	// RVA: 0xE1EB40
	public object __Gen_Wrap_405(object P0, object P1) { }

	// RVA: 0xE1EC60
	public object __Gen_Wrap_406(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE1ED78
	public object __Gen_Wrap_407(object P0, object P1) { }

	// RVA: 0xE1EE40
	public object __Gen_Wrap_408(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1EF38
	public object __Gen_Wrap_409(object P0, object P1) { }

	// RVA: 0xE1F000
	public object __Gen_Wrap_410(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1F0E8
	public object __Gen_Wrap_411(object P0, object P1, object P2) { }

	// RVA: 0xE1F1B4
	public object __Gen_Wrap_412(object P0, object P1) { }

	// RVA: 0xE1F26C
	public object __Gen_Wrap_413(object P0, object P1) { }

	// RVA: 0xE1F35C
	public object __Gen_Wrap_414(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1F444
	public object __Gen_Wrap_415(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE1F53C
	public object __Gen_Wrap_416(object P0) { }

	// RVA: 0xE1F5E8
	public object __Gen_Wrap_417(object P0, object P1, object P2) { }

	// RVA: 0xE1F6F4
	public object __Gen_Wrap_418(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE1F80C
	public object __Gen_Wrap_419(object P0) { }

	// RVA: 0xE1F8E8
	public object __Gen_Wrap_420(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE1F9E4
	public object __Gen_Wrap_421(object P0, object P1, object P2) { }

	// RVA: 0xE1FAB0
	public object __Gen_Wrap_422(object P0, object P1) { }

	// RVA: 0xE1FB78
	public object __Gen_Wrap_423(object P0, object P1, object P2) { }

	// RVA: 0xE1FC54
	public object __Gen_Wrap_424(object P0, object P1) { }

	// RVA: 0xE1FD44
	public object __Gen_Wrap_425(object P0, object P1) { }

	// RVA: 0xE1FE34
	public object __Gen_Wrap_426(object P0, object P1, object P2) { }

	// RVA: 0xE1FF10
	public object __Gen_Wrap_427(object P0, object P1, object P2) { }

	// RVA: 0xE2001C
	public object __Gen_Wrap_428(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE201B8
	public object __Gen_Wrap_429(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE20368
	public object __Gen_Wrap_430(object P0) { }

	// RVA: 0xE204A0
	public object __Gen_Wrap_431(object P0) { }

	// RVA: 0xE2057C
	public object __Gen_Wrap_432(object P0) { }

	// RVA: 0xE20658
	public object __Gen_Wrap_433(object P0) { }

	// RVA: 0xE2073C
	public object __Gen_Wrap_434(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE20824
	public object __Gen_Wrap_435(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE20944
	public object __Gen_Wrap_436(object P0, object P1) { }

	// RVA: 0xE209FC
	public object __Gen_Wrap_437(object P0, object P1) { }

	// RVA: 0xE20AC4
	public object __Gen_Wrap_438(object P0, object P1, object P2) { }

	// RVA: 0xE20B90
	public object __Gen_Wrap_439(object P0) { }

	// RVA: 0xE20C2C
	public object __Gen_Wrap_440(object P0, object P1) { }

	// RVA: 0xE20CE4
	public object __Gen_Wrap_441(object P0, object P1) { }

	// RVA: 0xE20DAC
	public object __Gen_Wrap_442(object P0, object P1) { }

	// RVA: 0xE20E64
	public object __Gen_Wrap_443(object P0, object P1) { }

	// RVA: 0xE20F1C
	public object __Gen_Wrap_444(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE21004
	public object __Gen_Wrap_445(object P0, object P1) { }

	// RVA: 0xE210F4
	public object __Gen_Wrap_446(object P0, object P1, object P2) { }

	// RVA: 0xE211D0
	public object __Gen_Wrap_447(object P0, object P1) { }

	// RVA: 0xE21298
	public object __Gen_Wrap_448(object P0, object P1) { }

	// RVA: 0xE21388
	public object __Gen_Wrap_449(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE21470
	public object __Gen_Wrap_450(object P0, object P1, object P2) { }

	// RVA: 0xE2157C
	public object __Gen_Wrap_451(object P0, object P1, object P2) { }

	// RVA: 0xE21658
	public object __Gen_Wrap_452(object P0, object P1, object P2) { }

	// RVA: 0xE21724
	public object __Gen_Wrap_453(object P0, object P1) { }

	// RVA: 0xE217EC
	public object __Gen_Wrap_454(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE21904
	public object __Gen_Wrap_455() { }

	// RVA: 0xE219A4
	public object __Gen_Wrap_456(object P0, object P1) { }

	// RVA: 0xE21A6C
	public object __Gen_Wrap_457(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE21BDC
	public object __Gen_Wrap_458(object P0) { }

	// RVA: 0xE21CB8
	public object __Gen_Wrap_459(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE21DB4
	public object __Gen_Wrap_460(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE21ECC
	public object __Gen_Wrap_461(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE21FC8
	public object __Gen_Wrap_462(object P0) { }

	// RVA: 0xE220A4
	public object __Gen_Wrap_463(object P0, object P1) { }

	// RVA: 0xE2216C
	public object __Gen_Wrap_464(object P0, object P1, object P2) { }

	// RVA: 0xE22248
	public object __Gen_Wrap_465(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE22368
	public object __Gen_Wrap_466(object P0) { }

	// RVA: 0xE22444
	public object __Gen_Wrap_467(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2252C
	public object __Gen_Wrap_468(object P0, object P1, object P2) { }

	// RVA: 0xE225F8
	public object __Gen_Wrap_469(object P0, object P1, object P2) { }

	// RVA: 0xE226C4
	public object __Gen_Wrap_470(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE227AC
	public object __Gen_Wrap_471(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE22894
	public object __Gen_Wrap_472(object P0) { }

	// RVA: 0xE22970
	public object __Gen_Wrap_473(object P0) { }

	// RVA: 0xE22A4C
	public object __Gen_Wrap_474(object P0) { }

	// RVA: 0xE22B28
	public object __Gen_Wrap_475(object P0, object P1) { }

	// RVA: 0xE22C18
	public object __Gen_Wrap_476(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE22D14
	public object __Gen_Wrap_477(object P0, object P1) { }

	// RVA: 0xE22E04
	public object __Gen_Wrap_478(object P0) { }

	// RVA: 0xE22EE0
	public object __Gen_Wrap_479(object P0, object P1) { }

	// RVA: 0xE22FD0
	public object __Gen_Wrap_480(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE230F0
	public object __Gen_Wrap_481(object P0, object P1, object P2) { }

	// RVA: 0xE231FC
	public object __Gen_Wrap_482(object P0, object P1) { }

	// RVA: 0xE232C4
	public object __Gen_Wrap_483(object P0, object P1, object P2) { }

	// RVA: 0xE233A0
	public object __Gen_Wrap_484(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE23498
	public object __Gen_Wrap_485(object P0) { }

	// RVA: 0xE23574
	public object __Gen_Wrap_486(object P0, object P1, object P2) { }

	// RVA: 0xE23650
	public object __Gen_Wrap_487(object P0, object P1, object P2) { }

	// RVA: 0xE2375C
	public object __Gen_Wrap_488(object P0, object P1, object P2) { }

	// RVA: 0xE23838
	public object __Gen_Wrap_489(object P0, object P1) { }

	// RVA: 0xE23928
	public object __Gen_Wrap_490(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE23A48
	public object __Gen_Wrap_491(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE23B30
	public object __Gen_Wrap_492(object P0) { }

	// RVA: 0xE23C38
	public object __Gen_Wrap_493(object P0) { }

	// RVA: 0xE23CE4
	public object __Gen_Wrap_494(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE23DDC
	public object __Gen_Wrap_495(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE23EC4
	public object __Gen_Wrap_496(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE23FF0
	public object __Gen_Wrap_497(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10) { }

	// RVA: 0xE2417C
	public object __Gen_Wrap_498(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10, object P11, object P12, object P13) { }

	// RVA: 0xE24388
	public object __Gen_Wrap_499(object P0, object P1) { }

	// RVA: 0xE24450
	public object __Gen_Wrap_500(object P0) { }

	// RVA: 0xE2452C
	public object __Gen_Wrap_501(object P0, object P1) { }

	// RVA: 0xE2461C
	public object __Gen_Wrap_502(object P0, object P1) { }

	// RVA: 0xE2470C
	public object __Gen_Wrap_503(object P0, object P1, object P2) { }

	// RVA: 0xE24818
	public object __Gen_Wrap_504(object P0, object P1, object P2) { }

	// RVA: 0xE248E4
	public object __Gen_Wrap_505(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE249CC
	public object __Gen_Wrap_506(object P0, object P1, object P2) { }

	// RVA: 0xE24AD8
	public object __Gen_Wrap_507(object P0, object P1) { }

	// RVA: 0xE24B90
	public object __Gen_Wrap_508(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE24CB0
	public object __Gen_Wrap_509(object P0, object P1, object P2) { }

	// RVA: 0xE24D8C
	public object __Gen_Wrap_510(object P0, object P1) { }

	// RVA: 0xE24E7C
	public object __Gen_Wrap_511(object P0) { }

	// RVA: 0xE24F58
	public object __Gen_Wrap_512(object P0) { }

	// RVA: 0xE25004
	public object __Gen_Wrap_513(object P0, object P1) { }

	// RVA: 0xE250F4
	public object __Gen_Wrap_514(object P0, object P1, object P2) { }

	// RVA: 0xE25200
	public object __Gen_Wrap_515(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE252E8
	public object __Gen_Wrap_516(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE25434
	public object __Gen_Wrap_517(object P0, object P1) { }

	// RVA: 0xE25524
	public object __Gen_Wrap_518(object P0) { }

	// RVA: 0xE255D0
	public object __Gen_Wrap_519(object P0, object P1, object P2) { }

	// RVA: 0xE256AC
	public object __Gen_Wrap_520(object P0, object P1) { }

	// RVA: 0xE25774
	public object __Gen_Wrap_521(object P0) { }

	// RVA: 0xE25850
	public object __Gen_Wrap_522(object P0, object P1) { }

	// RVA: 0xE25908
	public object __Gen_Wrap_523(object P0, object P1, object P2) { }

	// RVA: 0xE25A10
	public object __Gen_Wrap_524(object P0, object P1, object P2) { }

	// RVA: 0xE25B1C
	public object __Gen_Wrap_525(object P0, object P1) { }

	// RVA: 0xE25C0C
	public object __Gen_Wrap_526(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7) { }

	// RVA: 0xE25D54
	public object __Gen_Wrap_527(object P0) { }

	// RVA: 0xE25E30
	public object __Gen_Wrap_528(object P0) { }

	// RVA: 0xE25F0C
	public object __Gen_Wrap_529(object P0) { }

	// RVA: 0xE25FE8
	public object __Gen_Wrap_530(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE26108
	public object __Gen_Wrap_531(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE26200
	public object __Gen_Wrap_532(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE262FC
	public object __Gen_Wrap_533(object P0, object P1, object P2) { }

	// RVA: 0xE263D8
	public object __Gen_Wrap_534(object P0, object P1) { }

	// RVA: 0xE264A0
	public object __Gen_Wrap_535(object P0, object P1, object P2) { }

	// RVA: 0xE265AC
	public object __Gen_Wrap_536(object P0, object P1, object P2) { }

	// RVA: 0xE26678
	public object __Gen_Wrap_537(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2679C
	public object __Gen_Wrap_538(object P0, object P1, object P2) { }

	// RVA: 0xE268A4
	public object __Gen_Wrap_539(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2698C
	public object __Gen_Wrap_540(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE26A74
	public object __Gen_Wrap_541(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE26BAC
	public object __Gen_Wrap_542(object P0, object P1) { }

	// RVA: 0xE26C9C
	public object __Gen_Wrap_543(object P0, object P1) { }

	// RVA: 0xE26D64
	public object __Gen_Wrap_544(object P0, object P1) { }

	// RVA: 0xE26E2C
	public object __Gen_Wrap_545(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE26F28
	public object __Gen_Wrap_546(object P0) { }

	// RVA: 0xE27004
	public object __Gen_Wrap_547(object P0, object P1) { }

	// RVA: 0xE270F4
	public object __Gen_Wrap_548(object P0, object P1) { }

	// RVA: 0xE271E4
	public object __Gen_Wrap_549(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9) { }

	// RVA: 0xE27354
	public object __Gen_Wrap_550(object P0) { }

	// RVA: 0xE27400
	public object __Gen_Wrap_551(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2752C
	public object __Gen_Wrap_552(object P0) { }

	// RVA: 0xE27608
	public object __Gen_Wrap_553(object P0, object P1, object P2) { }

	// RVA: 0xE27714
	public object __Gen_Wrap_554(object P0, object P1) { }

	// RVA: 0xE27804
	public object __Gen_Wrap_555(object P0, object P1, object P2) { }

	// RVA: 0xE27910
	public object __Gen_Wrap_556(object P0, object P1) { }

	// RVA: 0xE27A00
	public object __Gen_Wrap_557(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE27B20
	public object __Gen_Wrap_558(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE27C1C
	public object __Gen_Wrap_559(object P0, object P1, object P2) { }

	// RVA: 0xE27D28
	public object __Gen_Wrap_560(object P0, object P1) { }

	// RVA: 0xE27E18
	public object __Gen_Wrap_561(object P0, object P1, object P2) { }

	// RVA: 0xE27EE4
	public object __Gen_Wrap_562(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE27FCC
	public object __Gen_Wrap_563(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE28190
	public object __Gen_Wrap_564(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE28340
	public object __Gen_Wrap_565(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE28428
	public object __Gen_Wrap_566(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE28554
	public object __Gen_Wrap_567(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2863C
	public object __Gen_Wrap_568(object P0, object P1, object P2) { }

	// RVA: 0xE28708
	public object __Gen_Wrap_569(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2887C
	public object __Gen_Wrap_570(object P0) { }

	// RVA: 0xE28958
	public object __Gen_Wrap_571(object P0) { }

	// RVA: 0xE28A34
	public object __Gen_Wrap_572(object P0) { }

	// RVA: 0xE28B10
	public object __Gen_Wrap_573(object P0) { }

	// RVA: 0xE28BEC
	public object __Gen_Wrap_574(object P0) { }

	// RVA: 0xE28CC8
	public object __Gen_Wrap_575(object P0) { }

	// RVA: 0xE28DA4
	public object __Gen_Wrap_576(object P0) { }

	// RVA: 0xE28E80
	public object __Gen_Wrap_577(object P0, object P1) { }

	// RVA: 0xE28F70
	public object __Gen_Wrap_578(object P0, object P1) { }

	// RVA: 0xE29060
	public object __Gen_Wrap_579(object P0) { }

	// RVA: 0xE2913C
	public object __Gen_Wrap_580(object P0) { }

	// RVA: 0xE29218
	public object __Gen_Wrap_581(object P0) { }

	// RVA: 0xE292C4
	public object __Gen_Wrap_582(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE293E4
	public object __Gen_Wrap_583(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE295B8
	public object __Gen_Wrap_584(object P0) { }

	// RVA: 0xE29664
	public object __Gen_Wrap_585(object P0, object P1) { }

	// RVA: 0xE29754
	public object __Gen_Wrap_586(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE298C0
	public object __Gen_Wrap_587(object P0) { }

	// RVA: 0xE2996C
	public object __Gen_Wrap_588(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE29A84
	public object __Gen_Wrap_589(object P0, object P1, object P2) { }

	// RVA: 0xE29B60
	public object __Gen_Wrap_590() { }

	// RVA: 0xE29C28
	public object __Gen_Wrap_591() { }

	// RVA: 0xE29CF0
	public object __Gen_Wrap_592(object P0, object P1) { }

	// RVA: 0xE29DB8
	public object __Gen_Wrap_593(object P0, object P1) { }

	// RVA: 0xE29EA8
	public object __Gen_Wrap_594(object P0, object P1) { }

	// RVA: 0xE29F70
	public object __Gen_Wrap_595(object P0, object P1) { }

	// RVA: 0xE2A060
	public object __Gen_Wrap_596(object P0) { }

	// RVA: 0xE2A13C
	public object __Gen_Wrap_597(object P0) { }

	// RVA: 0xE2A218
	public object __Gen_Wrap_598(object P0) { }

	// RVA: 0xE2A2C4
	public object __Gen_Wrap_599(object P0, object P1) { }

	// RVA: 0xE2A38C
	public object __Gen_Wrap_600(object P0) { }

	// RVA: 0xE2A468
	public object __Gen_Wrap_601(object P0, object P1) { }

	// RVA: 0xE2A558
	public object __Gen_Wrap_602(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE2A694
	public object __Gen_Wrap_603(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE2A7C0
	public object __Gen_Wrap_604(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7) { }

	// RVA: 0xE2A940
	public object __Gen_Wrap_605(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8) { }

	// RVA: 0xE2AA98
	public object __Gen_Wrap_606(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9) { }

	// RVA: 0xE2AC48
	public object __Gen_Wrap_607(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7) { }

	// RVA: 0xE2ADC8
	public object __Gen_Wrap_608(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8) { }

	// RVA: 0xE2AF60
	public object __Gen_Wrap_609(object P0, object P1, object P2) { }

	// RVA: 0xE2B02C
	public object __Gen_Wrap_610(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2B14C
	public object __Gen_Wrap_611(object P0, object P1) { }

	// RVA: 0xE2B204
	public object __Gen_Wrap_612(object P0, object P1, object P2) { }

	// RVA: 0xE2B2E0
	public object __Gen_Wrap_613(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2B3D8
	public object __Gen_Wrap_614(object P0) { }

	// RVA: 0xE2B4B4
	public object __Gen_Wrap_615(object P0, object P1) { }

	// RVA: 0xE2B56C
	public object __Gen_Wrap_616(object P0, object P1, object P2) { }

	// RVA: 0xE2B648
	public object __Gen_Wrap_617(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2B740
	public object __Gen_Wrap_618(object P0, object P1, object P2) { }

	// RVA: 0xE2B84C
	public object __Gen_Wrap_619(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10, object P11) { }

	// RVA: 0xE2B9F0
	public object __Gen_Wrap_620(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10, object P11, object P12) { }

	// RVA: 0xE2BBE0
	public object __Gen_Wrap_621(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10, object P11, object P12, object P13) { }

	// RVA: 0xE2BDB0
	public object __Gen_Wrap_622(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8, object P9, object P10, object P11, object P12, object P13, object P14) { }

	// RVA: 0xE2BFD0
	public object __Gen_Wrap_623(object P0, object P1) { }

	// RVA: 0xE2C098
	public object __Gen_Wrap_624(object P0) { }

	// RVA: 0xE2C174
	public object __Gen_Wrap_625(object P0, object P1) { }

	// RVA: 0xE2C264
	public object __Gen_Wrap_626(object P0) { }

	// RVA: 0xE2C348
	public object __Gen_Wrap_627(object P0, object P1, object P2) { }

	// RVA: 0xE2C424
	public object __Gen_Wrap_628(object P0, object P1, object P2) { }

	// RVA: 0xE2C530
	public object __Gen_Wrap_629(object P0) { }

	// RVA: 0xE2C60C
	public object __Gen_Wrap_630(object P0) { }

	// RVA: 0xE2C6B8
	public object __Gen_Wrap_631(object P0) { }

	// RVA: 0xE2C764
	public object __Gen_Wrap_632(object P0) { }

	// RVA: 0xE2C810
	public object __Gen_Wrap_633(object P0, object P1, object P2) { }

	// RVA: 0xE2C91C
	public object __Gen_Wrap_634(object P0, object P1) { }

	// RVA: 0xE2C9D4
	public object __Gen_Wrap_635(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE2CB00
	public object __Gen_Wrap_636(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE2CC2C
	public object __Gen_Wrap_637(object P0, object P1) { }

	// RVA: 0xE2CD1C
	public object __Gen_Wrap_638(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2CEA0
	public object __Gen_Wrap_639(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE2D06C
	public object __Gen_Wrap_640(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7) { }

	// RVA: 0xE2D248
	public object __Gen_Wrap_641(object P0, object P1) { }

	// RVA: 0xE2D310
	public object __Gen_Wrap_642(object P0, object P1, object P2) { }

	// RVA: 0xE2D41C
	public object __Gen_Wrap_643(object P0, object P1) { }

	// RVA: 0xE2D4E4
	public object __Gen_Wrap_644(object P0, object P1) { }

	// RVA: 0xE2D5D4
	public object __Gen_Wrap_645(object P0, object P1) { }

	// RVA: 0xE2D6C4
	public object __Gen_Wrap_646(object P0, object P1) { }

	// RVA: 0xE2D78C
	public object __Gen_Wrap_647(object P0) { }

	// RVA: 0xE2D838
	public object __Gen_Wrap_648(object P0, object P1) { }

	// RVA: 0xE2D8F0
	public object __Gen_Wrap_649(object P0, object P1) { }

	// RVA: 0xE2D9E0
	public object __Gen_Wrap_650(object P0) { }

	// RVA: 0xE2DA8C
	public object __Gen_Wrap_651(object P0, object P1) { }

	// RVA: 0xE2DB44
	public object __Gen_Wrap_652(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2DC64
	public object __Gen_Wrap_653(object P0, object P1) { }

	// RVA: 0xE2DD54
	public object __Gen_Wrap_654(object P0) { }

	// RVA: 0xE2DE00
	public object __Gen_Wrap_655(object P0, object P1) { }

	// RVA: 0xE2DEB8
	public object __Gen_Wrap_656(object P0, object P1) { }

	// RVA: 0xE2DFA8
	public object __Gen_Wrap_657(object P0) { }

	// RVA: 0xE2E054
	public object __Gen_Wrap_658(object P0, object P1) { }

	// RVA: 0xE2E10C
	public object __Gen_Wrap_659() { }

	// RVA: 0xE2E1D4
	public object __Gen_Wrap_660() { }

	// RVA: 0xE2E29C
	public object __Gen_Wrap_661() { }

	// RVA: 0xE2E364
	public object __Gen_Wrap_662() { }

	// RVA: 0xE2E42C
	public object __Gen_Wrap_663() { }

	// RVA: 0xE2E4F4
	public object __Gen_Wrap_664() { }

	// RVA: 0xE2E5BC
	public object __Gen_Wrap_665(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7) { }

	// RVA: 0xE2E704
	public object __Gen_Wrap_666(object P0) { }

	// RVA: 0xE2E7E0
	public object __Gen_Wrap_667(object P0) { }

	// RVA: 0xE2E88C
	public object __Gen_Wrap_668(object P0, object P1) { }

	// RVA: 0xE2E954
	public object __Gen_Wrap_669(object P0) { }

	// RVA: 0xE2EA00
	public object __Gen_Wrap_670(object P0) { }

	// RVA: 0xE2EAAC
	public object __Gen_Wrap_671(object P0) { }

	// RVA: 0xE2EBB0
	public object __Gen_Wrap_672(object P0) { }

	// RVA: 0xE2EC5C
	public object __Gen_Wrap_673(object P0, object P1) { }

	// RVA: 0xE2ED4C
	public object __Gen_Wrap_674(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2EE98
	public object __Gen_Wrap_675(object P0) { }

	// RVA: 0xE2EF74
	public object __Gen_Wrap_676(object P0) { }

	// RVA: 0xE2F020
	public object __Gen_Wrap_677(object P0, object P1, object P2) { }

	// RVA: 0xE2F0EC
	public object __Gen_Wrap_678(object P0) { }

	// RVA: 0xE2F1C8
	public object __Gen_Wrap_679(object P0) { }

	// RVA: 0xE2F2A4
	public object __Gen_Wrap_680(object P0) { }

	// RVA: 0xE2F380
	public object __Gen_Wrap_681(object P0) { }

	// RVA: 0xE2F45C
	public object __Gen_Wrap_682(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2F544
	public object __Gen_Wrap_683(object P0, object P1) { }

	// RVA: 0xE2F634
	public object __Gen_Wrap_684(object P0) { }

	// RVA: 0xE2F710
	public object __Gen_Wrap_685(object P0, object P1) { }

	// RVA: 0xE2F800
	public object __Gen_Wrap_686(object P0, object P1) { }

	// RVA: 0xE2F8F0
	public object __Gen_Wrap_687(object P0, object P1) { }

	// RVA: 0xE2F9E0
	public object __Gen_Wrap_688(object P0, object P1) { }

	// RVA: 0xE2FAD0
	public object __Gen_Wrap_689(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE2FBB8
	public object __Gen_Wrap_690(object P0, object P1) { }

	// RVA: 0xE2FCA8
	public object __Gen_Wrap_691(object P0, object P1) { }

	// RVA: 0xE2FD98
	public object __Gen_Wrap_692(object P0, object P1) { }

	// RVA: 0xE2FE88
	public object __Gen_Wrap_693(object P0, object P1, object P2) { }

	// RVA: 0xE2FF64
	public object __Gen_Wrap_694(object P0) { }

	// RVA: 0xE30040
	public object __Gen_Wrap_695(object P0) { }

	// RVA: 0xE3011C
	public object __Gen_Wrap_696(object P0) { }

	// RVA: 0xE301C8
	public object __Gen_Wrap_697(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE3035C
	public object __Gen_Wrap_698(object P0) { }

	// RVA: 0xE30438
	public object __Gen_Wrap_699(object P0) { }

	// RVA: 0xE30514
	public object __Gen_Wrap_700(object P0, object P1) { }

	// RVA: 0xE305DC
	public object __Gen_Wrap_701(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE30778
	public object __Gen_Wrap_702(object P0, object P1, object P2) { }

	// RVA: 0xE30854
	public object __Gen_Wrap_703(object P0) { }

	// RVA: 0xE30900
	public object __Gen_Wrap_704(object P0) { }

	// RVA: 0xE309AC
	public object __Gen_Wrap_705(object P0) { }

	// RVA: 0xE30A88
	public object __Gen_Wrap_706(object P0, object P1) { }

	// RVA: 0xE30B78
	public object __Gen_Wrap_707(object P0, object P1, object P2) { }

	// RVA: 0xE30C84
	public object __Gen_Wrap_708(object P0) { }

	// RVA: 0xE30D60
	public object __Gen_Wrap_709(object P0) { }

	// RVA: 0xE30E3C
	public object __Gen_Wrap_710(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0xE30F54
	public object __Gen_Wrap_711(object P0) { }

	// RVA: 0xE31000
	public object __Gen_Wrap_712(object P0) { }

	// RVA: 0xE310DC
	public object __Gen_Wrap_713(object P0, object P1, object P2) { }

	// RVA: 0xE311A8
	public object __Gen_Wrap_714(object P0, object P1) { }

	// RVA: 0xE31260
	public object __Gen_Wrap_715(object P0) { }

	// RVA: 0xE3133C
	public object __Gen_Wrap_716(object P0) { }

	// RVA: 0xE313E8
	public object __Gen_Wrap_717(object P0) { }

	// RVA: 0xE31494
	public object __Gen_Wrap_718(object P0, object P1) { }

	// RVA: 0xE31584
	public object __Gen_Wrap_719(object P0, object P1) { }

	// RVA: 0xE31674
	public object __Gen_Wrap_720(object P0) { }

	// RVA: 0xE31750
	public object __Gen_Wrap_721(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE318B0
	public object __Gen_Wrap_722(object P0, object P1) { }

	// RVA: 0xE319A0
	public object __Gen_Wrap_723(object P0, object P1) { }

	// RVA: 0xE31A68
	public object __Gen_Wrap_724(object P0, object P1) { }

	// RVA: 0xE31B58
	public object __Gen_Wrap_725(object P0, object P1, object P2) { }

	// RVA: 0xE31C34
	public object __Gen_Wrap_726(object P0, object P1) { }

	// RVA: 0xE31CFC
	public object __Gen_Wrap_727(object P0) { }

	// RVA: 0xE31D98
	public object __Gen_Wrap_728(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE31E80
	public object __Gen_Wrap_729(object P0, object P1) { }

	// RVA: 0xE31F7C
	public object __Gen_Wrap_730(object P0, object P1) { }

	// RVA: 0xE3206C
	public object __Gen_Wrap_731(object P0, object P1) { }

	// RVA: 0xE32134
	public object __Gen_Wrap_732(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE32270
	public object __Gen_Wrap_733(object P0, object P1) { }

	// RVA: 0xE32360
	public object __Gen_Wrap_734(object P0) { }

	// RVA: 0xE324A4
	public object __Gen_Wrap_735(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE3258C
	public object __Gen_Wrap_736(object P0, object P1, object P2) { }

	// RVA: 0xE32668
	public object __Gen_Wrap_737(object P0) { }

	// RVA: 0xE32760
	public object __Gen_Wrap_738(object P0, object P1) { }

	// RVA: 0xE32850
	public object __Gen_Wrap_739(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE32954
	public object __Gen_Wrap_740(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE32A3C
	public object __Gen_Wrap_741(object P0, object P1) { }

	// RVA: 0xE32B48
	public object __Gen_Wrap_742(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE32CB4
	public object __Gen_Wrap_743(object P0, object P1) { }

	// RVA: 0xE32E18
	public object __Gen_Wrap_744(object P0, object P1) { }

	// RVA: 0xE32EE0
	public object __Gen_Wrap_745(object P0) { }

	// RVA: 0xE32F8C
	public object __Gen_Wrap_746(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE330E4
	public object __Gen_Wrap_747(object P0) { }

	// RVA: 0xE331C0
	public object __Gen_Wrap_748(object P0) { }

	// RVA: 0xE3326C
	public object __Gen_Wrap_749(object P0, object P1) { }

	// RVA: 0xE3335C
	public object __Gen_Wrap_750(object P0) { }

	// RVA: 0xE33408
	public object __Gen_Wrap_751(object P0, object P1) { }

	// RVA: 0xE334F8
	public object __Gen_Wrap_752(object P0) { }

	// RVA: 0xE335D4
	public object __Gen_Wrap_753(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0xE33740
	public object __Gen_Wrap_754(object P0, object P1, object P2) { }

	// RVA: 0xE3384C
	public object __Gen_Wrap_755(object P0, object P1) { }

	// RVA: 0xE339B0
	public object __Gen_Wrap_756(object P0, object P1) { }

	// RVA: 0xE33A68
	public object __Gen_Wrap_757(object P0, object P1, object P2) { }

	// RVA: 0xE33B90
	public object __Gen_Wrap_758(object P0) { }

	// RVA: 0xE33C6C
	public object __Gen_Wrap_759(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE33DA8
	public object __Gen_Wrap_760(object P0) { }

	// RVA: 0xE33E54
	public object __Gen_Wrap_761(object P0) { }

	// RVA: 0xE33EF0
	public object __Gen_Wrap_762(object P0, object P1) { }

	// RVA: 0xE33FE0
	public object __Gen_Wrap_763(object P0) { }

	// RVA: 0xE340BC
	public object __Gen_Wrap_764(object P0) { }

	// RVA: 0xE34168
	public object __Gen_Wrap_765(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE34250
	public object __Gen_Wrap_766(object P0, object P1) { }

	// RVA: 0xE34318
	public object __Gen_Wrap_767(object P0, object P1) { }

	// RVA: 0xE343D0
	public object __Gen_Wrap_768(object P0, object P1) { }

	// RVA: 0xE344C4
	public object __Gen_Wrap_769(object P0, object P1) { }

	// RVA: 0xE3457C
	public object __Gen_Wrap_770(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE346C8
	public object __Gen_Wrap_771(object P0, object P1) { }

	// RVA: 0xE347B8
	public object __Gen_Wrap_772(object P0, object P1) { }

	// RVA: 0xE34870
	public object __Gen_Wrap_773(object P0) { }

	// RVA: 0xE3491C
	public object __Gen_Wrap_774(object P0, object P1) { }

	// RVA: 0xE349E4
	public object __Gen_Wrap_775(object P0, object P1) { }

	// RVA: 0xE34A9C
	public object __Gen_Wrap_776(object P0, object P1) { }

	// RVA: 0xE34B64
	public object __Gen_Wrap_777(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE34C4C
	public object __Gen_Wrap_778(object P0, object P1) { }

	// RVA: 0xE34D14
	public object __Gen_Wrap_779(object P0, object P1, object P2) { }

	// RVA: 0xE34DF0
	public object __Gen_Wrap_780() { }

	// RVA: 0xE34EB8
	public object __Gen_Wrap_781(object P0, object P1) { }

	// RVA: 0xE34FA8
	public object __Gen_Wrap_782(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE35090
	public object __Gen_Wrap_783(object P0, object P1, object P2) { }

	// RVA: 0xE351C8
	public object __Gen_Wrap_784(object P0, object P1) { }

	// RVA: 0xE35290
	public object __Gen_Wrap_785(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE35378
	public object __Gen_Wrap_786(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE35460
	public object __Gen_Wrap_787(object P0, object P1, object P2) { }

	// RVA: 0xE35534
	public object __Gen_Wrap_788(object P0, object P1) { }

	// RVA: 0xE355EC
	public object __Gen_Wrap_789(object P0, object P1) { }

	// RVA: 0xE35750
	public object __Gen_Wrap_790(object P0, object P1) { }

	// RVA: 0xE35808
	public object __Gen_Wrap_791(object P0, object P1) { }

	// RVA: 0xE358C0
	public object __Gen_Wrap_792(object P0, object P1) { }

	// RVA: 0xE359B0
	public object __Gen_Wrap_793(object P0, object P1, object P2) { }

	// RVA: 0xE35ABC
	public object __Gen_Wrap_794(object P0, object P1, object P2) { }

	// RVA: 0xE35B98
	public object __Gen_Wrap_795(object P0, object P1) { }

	// RVA: 0xE35CA4
	public object __Gen_Wrap_796(object P0, object P1) { }

	// RVA: 0xE35D94
	public object __Gen_Wrap_797(object P0, object P1, object P2, object P3) { }

	// RVA: 0xE35EE0
	public object __Gen_Wrap_798(object P0, object P1, object P2) { }

	// RVA: 0xE35FBC
	public object __Gen_Wrap_799(object P0, object P1) { }

	// RVA: 0xE36084
	public object __Gen_Wrap_800(object P0, object P1, object P2) { }

	// RVA: 0xE36160
	public object __Gen_Wrap_801(object P0, object P1, object P2) { }

	// RVA: 0xE3623C
	public object __Gen_Wrap_802(object P0, object P1, object P2) { }

	// RVA: 0xE36348
	public object __Gen_Wrap_803(object P0, object P1) { }

	// RVA: 0xE36400
	public object __Gen_Wrap_804(object P0, object P1) { }

	// RVA: 0xE364F0
	public object __Gen_Wrap_805(object P0, object P1) { }

	// RVA: 0xE365E0
	public object __Gen_Wrap_806(object P0, object P1) { }

	// RVA: 0xE366D0
	public object __Gen_Wrap_807(object P0, object P1) { }

	// RVA: 0xE36788
	public object __Gen_Wrap_808(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0xE36884
	public object __Gen_Wrap_809(object P0, object P1, object P2) { }

	// RVA: 0xE36950
	public object __Gen_Wrap_810(object P0, object P1, object P2) { }

	// RVA: 0xE36A2C
	public object __Gen_Wrap_811(object P0, object P1) { }

	// RVA: 0xE36B1C
	public object __Gen_Wrap_812(object P0, object P1) { }

	// RVA: 0xE36BD4
	public object __Gen_Wrap_813(object P0, object P1) { }

	// RVA: 0xE36CC4
	public object __Gen_Wrap_814(object P0) { }

	// RVA: 0xE36DA0
	public object __Gen_Wrap_815(object P0) { }

	// RVA: 0xE36E7C
	public object __Gen_Wrap_816(object P0, object P1) { }

	// RVA: 0xE36F88
	public object __Gen_Wrap_817(object P0, object P1) { }

	// RVA: 0xE37040
	public object __Gen_Wrap_818(object P0, object P1, object P2) { }

	// RVA: 0xE371A0
	private static object .cctor() { }

}

// Namespace: IFix
public class ILFixInterfaceBridge
{

	// Fields
	private object methodId_0; // 0x38
	private object methodId_1; // 0x3C
	private object methodId_2; // 0x40
	private object methodId_3; // 0x44
	private object methodId_4; // 0x48

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xE4EEF0
	private object System.IDisposable.Dispose() { }

	// RVA: 0xE4EF70
	private object MoveNext() { }

	// RVA: 0xE4F000
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xE4F0B8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xE4F138
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0xE4F1F0
	public object .ctor(object fieldNum, object fieldTypes, object typeIndex, object vTable, object methodIdArray, object virtualMachine) { }

	// RVA: 0xE4F2A8
	public object RefAsyncBuilderStartMethod() { }

}

// Namespace: IFix
public class WrappersManagerImpl
{

	// Fields
	private object virtualMachine; // 0x8

	// Methods

	// RVA: 0xE4F2AC
	public object .ctor(object virtualMachine) { }

	// RVA: 0xE37A34
	public static object GetPatch(object id) { }

	// RVA: 0xE3793C
	public static object IsPatched(object id) { }

	// RVA: 0xE4F2D8
	public object CreateDelegate(object type, object id, object anon) { }

	// RVA: 0xE4F3AC
	public object CreateWrapper(object id) { }

	// RVA: 0xE4F424
	public object InitWrapperArray(object len) { }

	// RVA: 0xE4F4E4
	public object CreateBridge(object fieldNum, object fieldTypes, object typeIndex, object vTable, object slots, object virtualMachine) { }

}

// Namespace: IFix
public enum IDMAP0
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PushGoldCollision-OnCollisionEnter0;
	public const object PushGoldCollision-OnCollisionStay0;
	public const object PushGoldCollision-OnCollisionExit0;
	public const object PushGoldCollision-OnTriggerEnter0;
	public const object PushGoldCollision-OnTriggerStay0;
	public const object PushGoldCollision-OnTriggerExit0;
	public const object PushGoldCollisionItem-OnCollisionEnter0;
	public const object ReturnDiscountShopLotteryAnimationHelper-OnGetDiscountAnimationOver0;
	public const object AccelerationValue-Start0;
	public const object AccelerationValue-Update0;
	public const object AnimationSync-Start0;
	public const object AnimationSync-GetCrossFadeTime0;
	public const object AnimationSync-PlayIdleShow0;
	public const object AnimationSync-PlayCome0;
	public const object AovUISysAdapter-InitRegisterNetworkModule0;
	public const object AovUISysAdapter-get_SpecialCaseSystem0;
	public const object AovUISysAdapter-get_LegendMgr0;
	public const object AovUISysAdapter-get_MoWenSystem0;
	public const object AovUISysAdapter-get_MallSystem0;
	public const object AovUISysAdapter-get_PlayerInfoSystems0;
	public const object AovUISysAdapter-get_RecordUseSDK0;
	public const object AovUISysAdapter-get_ChatSystem0;
	public const object AovUISysAdapter-get_FriendController0;
	public const object AovUISysAdapter-get_DLCDownloadSystems0;
	public const object AovUISysAdapter-get_EquipSystem0;
	public const object AovUISysAdapter-InitSys0;
	public const object AovUISysAdapter-GetSingleton0;
	public const object AovUISysAdapter-DLCDownloadUISystemCreateInstance0;
	public const object AovUISysAdapter-UnInit0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCastData-Clear0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryPhaseData-Clear0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCntData-Clear0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryResultData-Clear0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-Clear0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-Clear0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-ClearData0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-Clear0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-Clear0;
	public const object Assets-Scripts-GameSystem-CombineData-Clear0;
	public const object Assets-Scripts-GameSystem-HuoyueData-Clear0;
	public const object Assets-Scripts-GameSystem-CTaskModel-Clear0;
	public const object Assets-Scripts-GameSystem-CTaskSys-Clear0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-Clear0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-Clear0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-Clear0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-Clear0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-Clear0;
	public const object AovUISysAdapter-Clear0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_mNormalMendingCheckConfig0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_mSvrDateTime0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-GetSvrActTime0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_GetSvrCurActConfig0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-GetCheckInState0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_GetTotalCheckInTime0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_GetMendingCheckInRewardState0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_GetCheckIn0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-GetRedDotCount0;
	public const object CSpecialCaseSystem-GetMonthCheckReddotCount0;
	public const object CSpecialCaseSystem-GetMonthCheckWealID0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-GetReturnTime0;
	public const object CSpecialCaseSystem-GetReturnSplashReturnTime0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-get_NeedShowBirthdayIconInLobby0;
	public const object CSpecialCaseSystem-GetBirthdayNeedShowInLobby0;
	public const object Assets-Scripts-GameSystem-CombineData-GetListView0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetTasks0;
	public const object TaskNewbieLogic-GetIdxOfList0;
	public const object TaskNewbieLogic-IsNewbieTaskInCurrentTask0;
	public const object CSpecialCaseSystem-IsNewbieTaskInCurrentTask0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-GetPlentyModeTaskRedPointNum0;
	public const object CSpecialCaseSystem-GetPlentyModeTaskRedPointNum0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-isTaskViewShow0;
	public const object CSpecialCaseSystem-IsDuringGrowUpTaskTime0;
	public const object CChatFilterLangView-InitTemplateLangList0;
	public const object CChatFilterLangView-get_currentSupportLanguagesSort0;
	public const object CChatFilterLangView-IsFilterFunctionConfigOpen0;
	public const object CChatFilterLangView-FilterFunction0;
	public const object CChatFilterLangView-GetToggleList0;
	public const object Assets-Scripts-GameSystem-CChatController-GetChatFilterLang0;
	public const object CChatFilterLangView-SelectCurLanguage0;
	public const object CChatFilterLangView-OnLobbyChatFilterLang0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-ReqFilterChatLang0;
	public const object CChatFilterLangView-OnConfirmFilterLang0;
	public const object CChatFilterLangView-OnFilterLangItemEnable0;
	public const object CChatFilterLangView-OnSelectChange0;
	public const object CChatFilterLangView-InitEvent0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_TextForDisplay0;
	public const object CChatParser-ParseText0;
	public const object Assets-Scripts-GameSystem-CChatController-GetTempalteTextFont0;
	public const object Assets-Scripts-GameSystem-CChatController-GetCachedTemplateTextFont0;
	public const object Assets-Scripts-GameSystem-CChatController-GetTemplateTextSize0;
	public const object Assets-Scripts-GameSystem-CChatController-GetCachedTemplateTextSize0;
	public const object CChatParser-GetCharacterWidth0;
	public const object CChatParser-IsWhiteChar0;
	public const object CChatParser-WrapText0;
	public const object CChatParser-getLogicLineCountFromSingleLine0;
	public const object CChatParser-CreateText0;
	public const object CChatParser-CreateTextFace0;
	public const object CChatParser-ShowText0;
	public const object CChatParser-Parse0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_TransTextForDisplay0;
	public const object CChatParser-LobbyChatParse0;
	public const object AllColorParser-bMatch0;
	public const object AllColorParser-bHeader_Half_Match0;
	public const object AllColorParser-bColorTail_Match0;
	public const object AllColorParser-_parse0;
	public const object AllColorParser-Parse0;
	public const object CChatView-InitTemplateForm0;
	public const object CChatView-ClearEnterBattle0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-_getChannel0;
	public const object Assets-Scripts-GameSystem-CChatModel-get_friendCacheDir0;
	public const object Assets-Scripts-GameSystem-CChatModel-GetFriendCachePath0;
	public const object Assets-Scripts-GameSystem-CLegendTitleInfo-copyToComdt0;
	public const object Assets-Scripts-GameSystem-CChatChannel-LoadFriendCacheData0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_System0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-CreateChannel0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetChannel0;
	public const object Assets-Scripts-GameSystem-CChatChannel-Init_Timer0;
	public const object CChatView-InitChatWidget0;
	public const object CChatView-HideForm0;
	public const object CChatView-CheckInit0;
	public const object CChatView-DoChatOpenningAnim0;
	public const object CChatView-Open0;
	public const object CChatView-DoChatClosingAnim0;
	public const object CChatView-ClearChatForm0;
	public const object CChatView-get_CurTab0;
	public const object CChatView-set_CurTab0;
	public const object CChatView-Refresh_ChatInputView0;
	public const object CChatView-IsCheckHistory0;
	public const object CChatView-On_RefreshListItemTextTranslate0;
	public const object CChatView-ShowLoudSpeaker0;
	public const object CChatView-RefreshCurShowItemIndexRange0;
	public const object CChatView-SubCurShowItemIndexRange0;
	public const object CChatView-AddDeleteTopItemCount0;
	public const object CChatView-GetTextLabel0;
	public const object CChatView-IsRichText0;
	public const object CChatView-GetVipPlayerMsgColorSwitch0;
	public const object CChatView-SetGameVipChatMsgColor0;
	public const object CChatView-GetImage0;
	public const object CChatView-Create_Content0;
	public const object CChatView-ClearRegionChatData0;
	public const object MapDrag-Start0;
	public const object MapDrag-OnPointerDown0;
	public const object MapDrag-JudgePosition0;
	public const object MapDrag-OnDrag0;
	public const object MapDrag-Update0;
	public const object MapDrag-OnEndDrag0;
	public const object CMallItem-Icon0;
	public const object CMallItem-Type0;
	public const object CMallItem-GetUseable0;
	public const object CMallItem-GetIconType0;
	public const object CMallItem-get_OriginID0;
	public const object CMallItem-get_SoldOut0;
	public const object CMallItem-Grade0;
	public const object CMallItem-Job0;
	public const object CMallItem-Owned0;
	public const object CMallItem-CanSendFriend0;
	public const object CMallItem-SetPayinfo0;
	public const object CMallItem-HeroID0;
	public const object CMallItem-SkinID0;
	public const object CMallItem-SkinUniqID0;
	public const object CMallItem-Product0;
	public const object CMallItem-FirstName0;
	public const object CMallItem-SecondName0;
	public const object CMallItem-PayInfoSet0;
	public const object CMallItem-IsValidExperience0;
	public const object CMallItem-IsSourceplanExp0;
	public const object CMallItem-IsInInstallment0;
	public const object CMallItem-GetOldPriceType0;
	public const object CMallItem-TagType0;
	public const object Assets-Scripts-GameSystem-CMallRegisterSale-IsinRegisterSales0;
	public const object Assets-Scripts-GameSystem-CMallRegisterSale-GetRegisterSalesHeroDay0;
	public const object Assets-Scripts-GameSystem-CMallRegisterSale-GetRegisterSalesSkinDay0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetDiscountStr0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetTag0;
	public const object CMallItem-TagInfo0;
	public const object CMallItem-OnTimerEnd0;
	public const object CMallItem-AddTag0;
	public const object CMallItem-ObtWayAction0;
	public const object CMallItem-ObtWay0;
	public const object CMallItem-PayWay0;
	public const object CMallItemWidget-SetBuyButtonVisible0;
	public const object CMallItemWidget-SetPriceVisible0;
	public const object CMallItemWidget-ResetDefaultState0;
	public const object CMallItemWidget-SetSmallIconFrame0;
	public const object CMallItemWidget-DoSetItemImage0;
	public const object CMallItemWidget-SetItemImageForAliceShop0;
	public const object CMallItemWidget-SetItemImage0;
	public const object CMallItemWidget-SetItemByType0;
	public const object CMallItemWidget-SetItemQuality0;
	public const object CMallItemWidget-SetItemName0;
	public const object CMallItemWidget-SetItemTag0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPayTypeIconPath0;
	public const object CMallItemWidget-SetItemPriceInfo0;
	public const object CMallItemWidget-SetItemAlreadyHave0;
	public const object CMallItemWidget-HandleDisableHeroState0;
	public const object CMallItemWidget-SetMallItem0;
	public const object CMallItemWidget-SetGiftItem0;
	public const object ResBoutiqueConfExt-RemoveReddotRecord0;
	public const object ResBoutiqueConfExt-SetAsRead0;
	public const object ResBoutiqueConfExt-ShouldNotify0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetTotalSpByID0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetProduct0;
	public const object ResBoutiqueConfExt-GetAvaiSpecsale0;
	public const object CMallBoutiqueModel-InvalidateCache0;
	public const object CMallBoutiqueModel-GetBoutiqueData0;
	public const object CMallBoutiqueModel-SetAsRead0;
	public const object CMallBoutiqueModel-get_IsAnyNewShouldNotify0;
	public const object CUIPrice-SetActive0;
	public const object CUIPrice-SetPrice0;
	public const object CUIPrice-SetPirceOfCostItem0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetProductByItemID0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetItemPrice0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-ResBuyTypeToPayType0;
	public const object CUIPrice-SetItemPriceOfCostCoin0;
	public const object RecommendData-get_srv_hero_favor_order_raw0;
	public const object RecommendData-get_recommend_list_hero_global0;
	public const object RecommendData-get_recommend_list_skin_global0;
	public const object RecommendData-get_srv_skin_favor_order_raw0;
	public const object RecommendData-get_recommend_list_item_global0;
	public const object RecommendData-get_srv_MangoItem_list0;
	public const object COMDT_GLOBAL_RECOMMEND_SKIN_NODE_EXT-GetHeroID0;
	public const object CRecommendModel-Init0;
	public const object CRecommendModel-OnRcv_SCID_RECOMMEND_GLOBAL_HERO_NTF0;
	public const object CRecommendModel-OnRcv_SCID_RECOMMEND_GLOBAL_SKIN_NTF0;
	public const object CRecommendModel-OnRcv_SCID_RECOMMEND_GLOBAL_ITEM_NTF0;
	public const object CRecommendModel-OnRcv_SCID_MANGOLIST_ITEM_NTF0;
	public const object CRecommendModel-__init_srv_recommend_hero_global_lazy0;
	public const object Assets-Scripts-GameSystem-CMallSystem-get_PlayerRegisterTime0;
	public const object ResHeroCfgInfoExt-GetPromoSortIDOnly0;
	public const object ResHeroCfgInfoExt-GetPromoSortID0;
	public const object ResHeroCfgInfoExt-GetHeroShopNormalSortID0;
	public const object CRecommendModel-MallHeroSortDefault0;
	public const object CRecommendModel-__init_hero_sort_config_lazy0;
	public const object CRecommendModel-__init_srv_recommend_skin_global_lazy0;
	public const object CRecommendModel-__init_srv_recommend_skin_global_lazy_opt0;
	public const object ResHeroCfgInfoExt-GetPromoSortID1;
	public const object ResHeroCfgInfoExt-GetSkinCanBuy0;
	public const object ResHeroCfgInfoExt-GetPriorityByBuySortID0;
	public const object CRecommendModel-GetSkinSortInfoCached0;
	public const object CRecommendModel-MallSkinSortByDefault0;
	public const object CRecommendModel-__init_skin_sort_config_lazy0;
	public const object CRecommendModel-PreSortOwnState0;
	public const object CRecommendModel-MallHeroSortDefault_RecommendDataApplied0;
	public const object CRecommendModel-MallSkinSortNewByDefault0;
	public const object CRecommendModel-GetSkinShelfPriority0;
	public const object CRecommendModel-MallSkinSortDefault_RecommendDataApplied0;
	public const object CRecommendModel-HeroViewSortDefault0;
	public const object COMDT_GLOBAL_RECOMMEND_ITEM_NODE_EXT-GetSpecSaleID0;
	public const object ResHeroCfgInfoExt-GetPriorityByBuySortID1;
	public const object CPlentyTaskItemWidget-BoxEffectChanged0;
	public const object CPlentyTaskItemWidget-UpdateItemState0;
	public const object CPlentyTaskItemWidget-InitView0;
	public const object CPlentyTaskItemWidget-CompleteTaskRefreshView0;
	public const object CPlentyTaskWidget-BoxEffectStateChanged0;
	public const object CPlentyTaskWidget-RefreshKillCntTaskView0;
	public const object CPlentyTaskWidget-UpdateWeekCnt0;
	public const object CPlentyTaskWidget-InitStarAndGameCnt0;
	public const object CPlentyTaskWidget-CompleteTaskRefreshView0;
	public const object CPlentyTaskWidget-UpdateCreditScorePanel0;
	public const object CPlatformDataHelper-OnValueChanged0;
	public const object CPlatformDataHelperExtension-IsToggle0;
	public const object CPlatformDataHelperExtension-Show0;
	public const object CPlatformDataHelperExtension-Init0;
	public const object FiveCampSignalTipShower-SetActorIcons0;
	public const object FiveCampSignalTipShower-UpdateState_Normal0;
	public const object FiveCampSignalTipShower-UpdateState_BattleMsg0;
	public const object FiveCampSignalTipShower-UpdatePosition_Normal0;
	public const object StopEfxWhenOutBound-Start0;
	public const object StopEfxWhenOutBound-Update0;
	public const object TaskNewbieLogic-GetHeroIDByTaskID0;
	public const object TaskNewbieLogic-ReqGetNewbieTaskFinishPrize0;
	public const object TaskNewbieLogic-IsNeedChargeHeroToCoin0;
	public const object TaskNewbieLogic-InitNewbieTaskFinishPrize0;
	public const object TaskNewbieLogic-get_IdxPerforming0;
	public const object TaskNewbieLogic-get_DailyTaskNumber0;
	public const object Assets-Scripts-GameSystem-TaskUT-Create_Task0;
	public const object TaskNewbieLogic-InitConfigNewbieTask0;
	public const object TaskNewbieLogic-IsNewbieTask0;
	public const object TaskNewbieLogic-GetElementTaskID0;
	public const object TaskNewbieLogic-GetElementPrizeHeroID0;
	public const object TaskNewbieLogic-GetLobbyShowNewbieTaskPrizeHeroID0;
	public const object TaskNewbieLogic-GetElementStateByIdxLeftCurIdx0;
	public const object TaskNewbieLogic-GetElementStateByIdxEqualCurIdx0;
	public const object TaskNewbieLogic-GetTodayFinishNumber0;
	public const object TaskNewbieLogic-GetElementStateByIdxRightCurIdxInCurrentTaskFinish0;
	public const object TaskNewbieLogic-GetElementStateByIdxRightCurIdxInCurrentTaskNotFinish0;
	public const object TaskNewbieLogic-GetElementStateByIdxRightCurIdx0;
	public const object TaskNewbieLogic-GetElementStateByIdx0;
	public const object TaskNewbieLogic-TodayTaskIsFinish0;
	public const object TaskNewbieLogic-GetTaskNeedBattleNum0;
	public const object TaskNewbieLogic-GetTaskAreadyBattleNumber0;
	public const object TaskNewbieLogic-GetNeedMarkInSliderDict0;
	public const object TaskNewbieLogic-GetDoingTaskID0;
	public const object TaskNewbieLogic-GetTaskState0;
	public const object MS-UI-ChangeChildrenPosByDistance-get_RectTrans0;
	public const object MS-UI-ChangeChildrenPosByDistance-CollectChildList0;
	public const object MS-UI-ChangeChildrenPosByDistance-ChangeScale0;
	public const object MS-UI-ChangeChildrenPosByDistance-SetLayoutHorizontal0;
	public const object MS-UI-ChangeChildrenPosByDistance-SetLayoutVertical0;
	public const object MS-UI-ChangeChildrenPosByDistance-LateUpdate0;
	public const object MS-UI-ChangeChildrenPosByDistance-GetRectCenterPosition0;
	public const object MS-UI-ChangeChildrenPosByDistance-Update0;
	public const object Assets-Scripts-UI-CUITweenAnimActionBindTarget-FindTarget0;
	public const object Assets-Scripts-UI-CUITweenAnimActionBindTarget-Update0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-IsSvrCtrlOpen0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetCurTurnTableLotteryPhaseCfgData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-get_CurPhaseConfig0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-IsInTimeOpen0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-IsOpen0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetTurnTableLotteryCntCfg0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryOneValidCntData-get_thatDayShowTimeUtcTime0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryOneValidCntData-get_thatDayExpiredUtcTime0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetValidCnt0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetTurnTableLotteryCntCfgList0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetConfigClientDateTime0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetConfigUtcTime0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCntData-GetValidCnt0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetNextValidLottery0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-UpdateLobbyEntry0;
	public const object Assets-Scripts-UI-LobbyTurnTableLotteryWidgetView-UpdateEntryRoot0;
	public const object Assets-Scripts-UI-LobbyTurnTableLotteryWidgetView-Init0;
	public const object Assets-Scripts-UI-LobbyTurnTableLotteryWidgetView-UnInit0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-GetDailyTaskRedPointNum0;
	public const object Assets-Scripts-UI-LobbyActivityPointWidgetView-SetRedPoint0;
	public const object Assets-Scripts-UI-LobbyActivityPointWidgetView-Init0;
	public const object Assets-Scripts-UI-LobbyActivityPointWidgetView-OnLobbyRedPoint0;
	public const object Assets-Scripts-UI-LobbyActivityPointWidgetView-Start0;
	public const object Assets-Scripts-UI-LobbyActivityPointWidgetView-OnDestroy0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-SwitchDLCGroupNameToTLogReportType0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-_ReportDLCDownloadPopWndEvent0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-onConfirmDownload0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-onCancelDownload0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-_TryDownloadDLC0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TryDownloadDLCByType0;
	public const object Assets-Scripts-GameSystem-CTaskSys-GetTaskItems0;
	public const object Assets-Scripts-GameSystem-CTaskSys-GetWeekTaskItems0;
	public const object Assets-Scripts-GameSystem-CTaskSys-GetDailyAndWeekTaskItems0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-Send_SubmitTask0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-CheckAndSendTask0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-CheckNewbieTaskAndSendTask0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-OnClickLobbyActPanel0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-OnTaskSubmit0;
	public const object Assets-Scripts-GameSystem-CombineData-GetTask0;
	public const object Assets-Scripts-GameSystem-CTaskSys-IsIDInWeekTask0;
	public const object Assets-Scripts-GameSystem-CTaskSys-show_task_award0;
	public const object Assets-Scripts-GameSystem-CTaskSys-GetCompletedLevelNumAndMaxLevelNum0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-updateNewbieBtn0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-CreateActPoints0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-SetActPointState0;
	public const object Assets-Scripts-GameSystem-CTaskSys-GetWeeklyRewardCount0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-PlayGiftBoxEffectAnimation0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-ShowActivityVal0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-OnTaskUpdate0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-OnViewInited0;
	public const object Assets-Scripts-UI-LobbyEveryDayFightWidgetView-OnFormDestroyed0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-CloseForm0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-IsNewbieWealAvailable0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefreshNewbieWealData0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-UpdateLevelTaskStates0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-ShowDetailRule0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefreshLevelDitail0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnSelectLevel0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefresLevelView0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-ResetRewardViewEffect0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-UpdateTimelimitTaskStates0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-Relayout0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-getFirstSubTask0;
	public const object Assets-Scripts-GameSystem-CTask-get_m_taskTitle0;
	public const object Assets-Scripts-GameSystem-CTask-get_m_MishuDesc0;
	public const object Assets-Scripts-GameSystem-CTask-get_m_taskDesc0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefresRewardView0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-get_NeedShowNewbieWeal0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefreshNewbieWealTab0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefreshNewbieWealReddot0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-SetNewbieWealReddotAndRefresh0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-SetNewbieWealUI0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-GetMenuTabByType0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefreshTaskReddot0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefreshNewbieCheckinReddot0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnSelectChanged0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-RefreshTabSelect0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-InitUI0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-GetRecentCloseNewbieWealCloseTime0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnSecondTimer0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OpenForm0;
	public const object Assets-Scripts-UI-LobbyNewbieTaskWidgetView-OnClick0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-HasUnClainedTask0;
	public const object Assets-Scripts-UI-LobbyNewbieTaskWidgetView-Init0;
	public const object Assets-Scripts-UI-LobbyNewbieTaskWidgetView-Appear0;
	public const object Assets-Scripts-UI-LobbyNewbieTaskWidgetView-UnInit0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-get_currentBirthdayInfo0;
	public const object Assets-Scripts-GameSystem-CBirthdayShareUI-Start0;
	public const object Assets-Scripts-GameSystem-CBirthdayShareUI-Open0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-dequeueBirthdayInfo0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-resetQueueHead0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-sort0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-sortBirthdayList0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-OpenForm0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-CloseForm0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-pushBirthdaySequence0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-ShowAllBirthdayInfoNormal0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-Init0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-SendReceiveReward0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-OnRewardRsp0;
	public const object Assets-Scripts-GameSystem-CBirthdaySystem-OnBirthdayNtf0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayRewardItem-ShowReward0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayRewardItem-CheckComponentNull0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayRewardItem-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-get_ShowEvaluate0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-set_ShowEvaluate0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-CheckComponentNull0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-InitShowEvaluate0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-ReceiveReward0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-Share0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-SwitchHistory0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-SwitchCertified0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-ChangeReceiveRewardBtnActiveState0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-refreshBtnState0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-OnReceiveRewardSuccess0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-OnUnRegEvent0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-FillReward0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-FillStartTime0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-FillHistoryStatistics0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-FillEvaluate0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-FillCDN0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-FillData0;
	public const object Assets-Scripts-GameSystem-CUIBirthdayWindow-OnShow0;
	public const object Assets-Scripts-GameSystem-InviteNewPlayerHelper-IsValidSharePlatform0;
	public const object Assets-Scripts-GameSystem-InviteNewPlayerHelper-get_InviteNewPlayerPlatform0;
	public const object Assets-Scripts-GameSystem-InviteNewPlayerHelper-TestAndAddPlatform0;
	public const object Assets-Scripts-GameSystem-InviteNewPlayerHelper-UpdateInviteNewPlayerPlatform0;
	public const object Assets-Scripts-GameSystem-ShortCodeGen-Init0;
	public const object Assets-Scripts-GameSystem-ShortCodeGen-LongConvertToShortCode0;
	public const object Assets-Scripts-GameSystem-ShortCodeGen-GetShortCodeByOpenIDAndLocalID0;
	public const object Assets-Scripts-GameSystem-ShortCodeGen-GetOpenIDLocalIDByShortCode0;
	public const object Assets-Scripts-GameSystem-ShortCodeGen-IdToCode0;
	public const object Assets-Scripts-GameSystem-ShortCodeGen-CodeToId0;
	public const object Assets-Scripts-GameSystem-ShortCodeGen-CreatCodeByID0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_mCliDateTime0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-CheckIn0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnCheckInClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-GetRewardInfo0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_GetFirstNotCheckInDay0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnDayItemEnable0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnGetHeroConfirm0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_mFormCtrl0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-ReqMending0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnConfirmMendingClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnCancelMendingClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_GetMendingCost0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnMendingCheckInClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-CheckGetDayReward0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-ReqDrawWeal0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-DrawWealImpl0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnThreeDayRewardClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnSixDayRewardClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnFifteenDayRewardClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-GetSvrCheckInActTimeNode0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_mIsCheckInActActived0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_mPrevRefreshDateTime0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_mIsOpenDurationOverOneDay0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_mIsAlreadyCheckIn0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-CheckMeetConditionAutoPopup0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-RecordUpdateTime0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-SetLobbyPopup0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-RemoveTimer0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_CloseForm0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_SetActDate0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_SetListToToday0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_SetupDateList0;
	public const object Assets-Scripts-GameSystem-UIMonthCheckSysFormCtrl-get_mendingBtn0;
	public const object Assets-Scripts-GameSystem-UIMonthCheckSysFormCtrl-get_mendingCostImage0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-IsPrimeMendingFuncOpen0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-GetPrimeExtarFreePendingCnt0;
	public const object Assets-Scripts-GameSystem-UIMonthCheckSysFormCtrl-get_checkInBtn0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_SetupCheckInState0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-SetupMendingPanel0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_UpdateReward0;
	public const object Assets-Scripts-GameSystem-UIMonthCheckSysFormCtrl-get_tipBgImage0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_UpdateHeroInfo0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_UpdateAll0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-AutoCheckIn0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-get_m_Form0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-CheckNeedUpdate0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_GetMendingTimes0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_CheckTimer0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OpenCheckForm0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnFormOpen0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-CloseForm0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnVPBuy0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnFreeMendingCheckInClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnBeComePrimeOrRechargeClick0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnResumeMonthCheck0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnPrimeStatusUpdate0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-_CreateEmptyData0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-Init0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-GetReadyForGet0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-DrawCrossMonthAccuReward0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-UpdateState0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-UpdateActivityReddot0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-UpdateAccState0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnFillInMessageGet0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnCrossMonthCheckInfoNty0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-OnGetFillinTimes0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-TryPopup0;
	public const object Assets-Scripts-GameSystem-MonthCheckSystem-SetCheckInState0;
	public const object Assets-Scripts-GameSystem-UIMonthCheckSysFormCtrl-get_freeMendingBtn0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-set_HasGotDiscount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-get_HasGotDiscount0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetShopData0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetShopInfo0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetBoughtCount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-get_BoughtCnt0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-get_LimitBuyCnt0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-set_LimitBuyCnt0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-get_Discount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-set_Discount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-get_StartTime0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-set_StartTime0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-get_EndTime0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-set_EndTime0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-get_EndDateTime0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-set_EndDateTime0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-Init0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-GetDiscountGO0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-RefreshBannerDiscount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-GetTimeToClose0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-RefreshTimer0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-GetDiscountNumIconPath0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-SetDiscountList0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-RefreshMainDiscount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-RefreshDiscountMsg0;
	public const object Assets-Scripts-GameSystem-CMallMysteryDiscountHandler-PlayLuckDiscount0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-SetDiscountAlreadyGet0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-get_ItemID0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-get_ItemType0;
	public const object Assets-Scripts-GameSystem-CMallSystem-ConvertHeroIdAndSkinId0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-get_ProductCnt0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-get_ShopType0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-IsShopAvailable0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetShopDetail0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetDiscount0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetPayInfoSetOfGood0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-HasGotDiscount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-UpdateItemPricePnl0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPayInfoSetOfGood0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPriceAfterCoupon0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetAllDiscountCoupons0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-CanUseDiscountCoupon0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetCanUseDiscountCoupons0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-FillUsableCouponsHeroOrSkin0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPayInfoSetOfGood1;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-FilterPayInfoSetByPayType0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPayInfoSetOfGood2;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-get_Cfg0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-UpdateView0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-RefreshProducts0;
	public const object Assets-Scripts-GameSystem-CMallMysteryGetNewDiscount-OnDiscountAnimationEnd0;
	public const object Assets-Scripts-GameSystem-CMallMysteryGetNewDiscount-GetRollDiscount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-get_BuyIdx0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-get_BoughtCnt0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-set_BoughtCnt0;
	public const object Assets-Scripts-GameSystem-CMallMysteryProduct-SetBuyBtnEnabled0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-Draw0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-Init0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-UnInit0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-AddProduct0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-UpdateProduct0;
	public const object Assets-Scripts-GameSystem-CMallMysteryItem-GetProduct0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-IsProductAvailable0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-RefreshShop0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-InitData0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-IsShopAvailable0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OnMallGoToMysteryTab0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OpenMysteryDiscountForm0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OnOpenShareMysteryDiscount0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-RequestShopFlag0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OnRollDiscount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-RefreshProducts0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OnShopBuySuccess0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OnHeroAdd0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OnDiscountAnimationEnd0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-GetRollDiscount0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OnUpdateFlagSuccess0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-Init0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-UnInit0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-CloseShop0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-InitPrefabData0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-OnShowGO0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-Load0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-Loaded0;
	public const object Assets-Scripts-GameSystem-CMallMysteryTab-Draw0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-IsLimitBuyTime0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-OpenBuy0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-OnOpenBuyForm0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetGoods0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetCurrencyValueFromRoleInfo0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-TryToPay0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-_RealOnBuyItem0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-OnBuyItem0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-OnConfirmuyItem0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetGoods1;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-CalLowestPayInfoSet0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetMysteryPayInfoSetOfGood0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-OnBuyHeroNotOwn0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-OnNtyAddHero0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-OnNtyAddSkin0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-Init0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-ReceiveMysteryShopData0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-AddBoughtCount0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-ReceiveShopBuy0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-ReceiveShopBuyErr0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-ReceiveMysteryFlag0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetRemainTime0;
	public const object Assets-Scripts-GameSystem-DiscountShopSystem-GetMysteryPayInfoSetOfGood1;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-GetForm0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-GetWidgets0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-PlayFormAnimator0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-OnEvtGetDiscount0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-GetForm0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-UpdateTimerFormat0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-OnRemainTimeUpdate0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-IsCH0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-GetDiscount0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-Refresh0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-OpenForm0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-OpenMallForm0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-CloseForm0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-OnEvtGotoShop0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-OnGetDiscountAnimationOver0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-Init0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-Uninit0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-UpdateTimerFormat0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-OnRemainTimeUpdate0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-Refresh0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopLotteryCtrl-OpenForm0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-OnBuySuccess0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-OnNtyAddHero0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-OnNtyAddSkin0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-Init0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopMallCtrl-Uninit0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-OnRecvDiscountShopData0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-OpenLotteryForm0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-OnOpenReturnDiscountShop0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-OnShopClosed0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-Init0;
	public const object Assets-Scripts-GameSystem-ReturnDiscountShopSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-GetForm0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-GetWidgets0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-GetReturnTimeDetail0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivitySystem-IsActivityAvaliable0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivitySystem-GetGoods0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-GetCoupons0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-GetGifts0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-RefreshGoodsItem0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivitySystem-GetActivityDuration0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-Refresh0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-OnPackGet0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-OnOpenRule0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-OnBuyGoods0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-Init0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-Uninit0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivityCtrl-OpenForm0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivitySystem-OnOpenForm0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivitySystem-Init0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivitySystem-UnInit0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-SetReturnPackGet0;
	public const object Assets-Scripts-GameSystem-ReturnRechargeActivitySystem-OnReturnPackGetNtf0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-ReportSplashOpenedTLog0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-OpenSplash10;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-OpenSplash20;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-OnEvtOpenForm0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-ReportGotoPandoraActivityTLog0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-OnEvtOpenReturnActivity0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-OnEvtFormClosed0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-Init0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-SetReturnTimeDetail0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-GetApplyRsp0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-SetReturnIdentityLable0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-OnRecvReturnIdentityLableNtf0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-GetReturnState0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-GetReturnEndTime0;
	public const object Assets-Scripts-GameSystem-ReturnSplashSystem-GetReturnIdentityLable0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-set_MoveDistance0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-Start0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-UpdateText0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-UpdateName0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-OnXToggleValueChanged0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-OnYToggleValueChanged0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-OnSlider1ValueChanged0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-OnSlider2ValueChanged0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-OnSlider3ValueChanged0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-OnSlider4ValueChanged0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-Init0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-GetCurRotation0;
	public const object Assets-Scripts-GameSystem-GravityEditItem-Update0;
	public const object Assets-Scripts-GameSystem-GravityEditScript-OnSliderValueChanged0;
	public const object Assets-Scripts-GameSystem-GravityEditScript-Start0;
	public const object Assets-Scripts-GameSystem-GravityEditScript-Update0;
	public const object Assets-Scripts-GameSystem-SimulationOfGravity-SetOfffsetLimited0;
	public const object Assets-Scripts-GameSystem-SimulationOfGravity-SetDate0;
	public const object Assets-Scripts-GameSystem-SimulationOfGravity-Awake0;
	public const object Assets-Scripts-GameSystem-SimulationOfGravity-_AdjustValue0;
	public const object Assets-Scripts-GameSystem-SimulationOfGravity-LateUpdate0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-get_RecentlyRewardList0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCastData-get_ItemNum0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-get_CastItemCnt0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCastData-get_CurSeq0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-get_ReqCastSeq0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryPhaseData-UpdateData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-UpdatePhaseData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCntData-UpdateData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-UpdateCntData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryResultData-UpdateLastResult0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-CreateTestResultData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-CreateTestData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-UpdateRewardRecordData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-UpdateTurnTableLotterData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-InitTurnTableLotterData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-UpdateTurnTableLotteryResultData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCastData-GetItemDataBySeq0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCastItem-UpdateData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCastData-AppendData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-AppendCastData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetTurnTableLotteryPhaseCfgData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetTurnTableLotteryPoolData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetTurnTableLotteryPoolItemCfg0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryResultData-GetLastResultIdx0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetLastResultIdx0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetLastResultHeroOrSkinId0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-UpdateLastResultOfHeroOrSkin0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetTurnTableLotteryCntData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-SortByIndex0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryData-GetAwardItemList0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryRewardItemInfo-get_GetDataTime0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryRewardItemInfo-get_IsHightQualityItem0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryRewardItemInfo-get_IsMidQualityItem0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryRewardItemInfo-get_ItemName0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCntData-GetUsedCnt0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCntData-GetTotalCnt0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryOneValidCntData-UpdateData0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCastData-GetItemDataByUIIdx0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryCastItem-IsSelf0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotteryChosenData-get_GetDataTime0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-ReqTurnTableLotteryStop0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-ReqTurnTableLotteryCast0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryCastRsp0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryRsp0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryInfoNtf0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryCntInfoNtf0;
	public const object Assets-Scripts-GameSystem-CMallSystem-CheckAndTryDownloadMallSubModule0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-GetMainViewForm0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryEntryClick0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-IsAutoPopupLevel0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-MeetAutoShowCondition0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-TryToAutoPopupForm0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryLoginOpen0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-GetResFromTurnTableLotteryPhase0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-PreloadOneCDNPicFromTurnTableLottery0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryCDNDataNtf0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryDataCfgNtf0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryGetNewSkinNtf0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OnTurnTableLotteryGetNewHeroNtf0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-Init0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-GetVaildLotteryCnt0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-AddPoolCfgSafe0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-CanBeShareByTurnTableLotteryPhase0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-SetImageWithPicFromTurnTablePhaseId0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-OpenTurnTableLotteryShareForm0;
	public const object Assets-Scripts-GameSystem-CTurnTableLotterySystem-CloseTurnTableLotteryShareForm0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCastItemCtrl-SetData0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-get_mCurAngle0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-get_IsGoDisable0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-get_IsStopDisable0;
	public const object Assets-Scripts-GameSystem-UT-SetImage0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-SetObjColor0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-SetCircleAnimatioEffectSpeed0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-ChangeStartBtnStatus0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-UpdateValidCnt0;
	public const object Assets-Scripts-GameSystem-MonoTurnTablePointerTailCtrl-Init0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-LoadPointerTailRes0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-Reset0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-Init0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableItemCtrl-SetData0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-FillItem0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableItemCtrl-NotShowItemEffect0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-HideAllItemEffects0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableItemCtrl-get_ItemTag0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableItemCtrl-get_IsMidQualityItem0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableItemCtrl-get_IsHighQualityItem0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableItemCtrl-RestoreItemEffect0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-RestoreAllItemEffects0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-StartRoll0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-DoStopInit0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-StopRoll0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-DisableStopRoll0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-GetDeltaAngle0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-WrapAngle0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-GetNearestAngleIndex0;
	public const object Assets-Scripts-GameSystem-MonoTurnTablePointerTailCtrl-ShowTailEffect0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-ShowCurAnglePointerTailImpl0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-ShowCurAnglePointerTail0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-ClockWiseRollAngle0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-GetVtSpeed0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-DoRotate0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-DoSlowDown0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-DispatchTurnTableStopEvent0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-DoConstantRotate0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-DoSpeedUp0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-Update0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-ShowPointerChosenItemAnimEffect0;
	public const object Assets-Scripts-GameSystem-MonoTurnTableCtrl-HidePointerChosenItemAnimEffect0;
	public const object Assets-Scripts-GameSystem-MonoTurnTablePointerTailCtrl-OnTailAnimEffectEnd0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryEntryClose0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMyAwardView-SetItem0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMyAwardView-OnAwardItemEnable0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMyAwardView-RegisterUIEvent0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMyAwardView-Show0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OpenMyAwardView0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryMyAwardClick0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryMyAwardClose0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryRareAwardShareClick0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryShareFormCloseClick0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryTableStopEvent0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-ShowNormalAwardView0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryRewardView-get_form0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryRewardView-Show0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OpenRewardView0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryPointerChosenBlinkAnimEndEvent0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryAwardViewClose0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnLobbyEntryCountDownEnd0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-UpdateValidCnt0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-UpdateRule0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-UpdateLuckyList0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnDetailHttpTextClick0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnLuckyListItemEnable0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryStartClick0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryStopClcik0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryShareActClick0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryGoDisableTimerUp0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-RegisterUIEvent0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-FillItemList0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-ReqCastItemList0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-RemoveTimer0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryTimeUp2PushCastItem0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-StartTimer0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnTurnTableLotteryRefreshLuckyListTimerUp0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-Show0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMainView-OnFormDestroyed0;
	public const object Assets-Scripts-GameSystem-TurnTableLotteryMyAwardView-OnDestroy0;
	public const object Assets-Scripts-GameSystem-CBagSystem-GetSheetContainer0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-get_ShowBigItem0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-set_ShowBigItem0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-OnEvtFormClosed0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-SkinOrHeroAlreadyHave0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-RefreshRewardItemSelectState0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-RefreshRewardStates0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-SpecialGiftSelected0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-OnEvtSelectRewardItem0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-GetItem0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-ExchangeGift0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-SpecialGiftExchanged0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-OnEvtExchange0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-Init0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-UnInit0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-GetForm0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-RefreshRewardItem0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-Refresh0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-openFormInternal0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-OpenForm0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-GetDelayDrawConfig0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-GetDelayDrawGiftConfig0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftCtrl-OpenForm1;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-OnEvtOpenGift0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-Init0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-OpenForm0;
	public const object Assets-Scripts-GameSystem-CDelayDrawGiftSystem-GetUseables0;
	public const object Assets-Scripts-GameSystem-RewardsController-OnRewardsCompleted0;
	public const object Assets-Scripts-GameSystem-RewardsController-OnRewardsCollected0;
	public const object Assets-Scripts-GameSystem-RewardsController-DisplayLevelRewards0;
	public const object Assets-Scripts-GameSystem-RewardsController-Set0;
	public const object Assets-Scripts-GameSystem-RewardsController-ShowRewards0;
	public const object Assets-Scripts-GameSystem-RewardsController-OnRewardsCollected1;
	public const object Assets-Scripts-GameSystem-RewardsController-OnShowRewardOver0;
	public const object Assets-Scripts-GameSystem-RewardsController-OnEnable0;
	public const object Assets-Scripts-GameSystem-RewardsController-OnDisable0;
	public const object Assets-Scripts-GameSystem-CChatController-IsPrimeChatBubbleEnabled0;
	public const object Assets-Scripts-GameSystem-CChatEntity-Clear0;
	public const object Assets-Scripts-GameSystem-CChatSysData-Clear0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetFiendLastChatTimeFromPlayerPrefs0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-SetFiendUnread0;
	public const object Assets-Scripts-GameSystem-CChatChannel-Clear0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-SetChatTab0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-ClearAll0;
	public const object Assets-Scripts-GameSystem-CChatModel-ClearAll0;
	public const object Assets-Scripts-GameSystem-CChatController-ClearAll0;
	public const object Assets-Scripts-GameSystem-UT-ResetTimer0;
	public const object Assets-Scripts-GameSystem-CChatController-SetChatTimerEnable0;
	public const object Assets-Scripts-GameSystem-CChatUT-Convert_Channel_ChatMsgType0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_GetChat_Req0;
	public const object Assets-Scripts-GameSystem-CChatController-GetChatRegionId0;
	public const object Assets-Scripts-GameSystem-CChatController-IsChatRegionSet0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Send_GetChat_Req0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_RealtimeReqComplaintReq0;
	public const object Assets-Scripts-GameSystem-CChatController-ReportGvoiceReq0;
	public const object Assets-Scripts-GameSystem-CChatController-Chat_Model_EventID-get_Chat_GetMsg_NTF0;
	public const object Assets-Scripts-GameSystem-CChatModel-SetTimeStamp0;
	public const object Assets-Scripts-GameSystem-CChatModel-SetRestFreeCnt0;
	public const object Assets-Scripts-GameSystem-CChatUT-Convert_ChatMsgType_Channel0;
	public const object Assets-Scripts-GameSystem-CChatUT-Convert_ChatMsgType_Channel1;
	public const object Assets-Scripts-GameSystem-UT-Bytes2String0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-getFriendInfo0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetGameOrSnsFriend0;
	public const object Assets-Scripts-GameSystem-CChatModel-Get_Palyer_Info0;
	public const object Assets-Scripts-GameSystem-CChatUT-GetUser0;
	public const object Assets-Scripts-GameSystem-CChatUT-GetUser1;
	public const object Assets-Scripts-GameSystem-CChatUT-IsChatPlayerPrime0;
	public const object Assets-Scripts-GameSystem-CChatUT-FillMomentsShareData0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Friend_ActivityJump_Self0;
	public const object Assets-Scripts-GameSystem-CChatUT-HandleReserveData0;
	public const object Assets-Scripts-GameSystem-CChatUT-_fillIntimacyChatData0;
	public const object Assets-Scripts-GameSystem-CChatUT-_fillDeeplinkChatData0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Self0;
	public const object Assets-Scripts-GameSystem-CChatChannel-GetLast0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Time0;
	public const object Assets-Scripts-GameSystem-CChatEntity-IsMeanbleChatEnt0;
	public const object Assets-Scripts-GameSystem-CChatChannel-MsgItemCntOverFlow0;
	public const object Assets-Scripts-GameSystem-CChatChannel-IsSelfShareChatMsg0;
	public const object Assets-Scripts-GameSystem-CChatChannel-IsSelfRelationChatMsg0;
	public const object Assets-Scripts-GameSystem-CChatChannel-IsSelfDeeplinkChatMsg0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetFiendUnreadFromPlayerPrefs0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetFiendUnread0;
	public const object Assets-Scripts-GameSystem-CChatChannel-GetUnreadCount0;
	public const object Assets-Scripts-GameSystem-CChatChannel-RemoveOverFlowData0;
	public const object Assets-Scripts-GameSystem-CChatChannel-IsSaveFriendCacheData0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-SetFiendLastChatTime0;
	public const object Assets-Scripts-GameSystem-CLegendTitleInfo-copyFromComdt0;
	public const object Assets-Scripts-GameSystem-CChatModel-GetCOfflineChatIndex0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Clear_Offline0;
	public const object Assets-Scripts-GameSystem-CChatModel-ClearCOfflineChatIndex0;
	public const object Assets-Scripts-GameSystem-CChatChannel-SaveFriendCacheData0;
	public const object Assets-Scripts-GameSystem-CChatChannel-Add0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-Add_ChatEntity0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetFriendChannel0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetUser0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetName0;
	public const object Assets-Scripts-GameSystem-CFriendRemarkData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendRemarkData-Get1;
	public const object Assets-Scripts-GameSystem-CFriendNicknameData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendNicknameData-Get1;
	public const object Assets-Scripts-GameSystem-UT-PlayerNickyOrRemarkName0;
	public const object Assets-Scripts-GameSystem-UT-MixtureNameFormat0;
	public const object Assets-Scripts-GameSystem-UT-PlayerNameOrRemarkOrNicky0;
	public const object Assets-Scripts-GameSystem-UT-PlayerNameOrRemarkOrNicky1;
	public const object Assets-Scripts-GameSystem-UT-PlayerNameOrRemarkOrNicky2;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_TextForDisplay0;
	public const object Assets-Scripts-GameSystem-CChatSysData-Add_NewContent_Entry0;
	public const object Assets-Scripts-GameSystem-CChatController-Chat_Model_EventID-get_Chat_FriendChatData_Change0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-ResponsePrivateChat0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsBlack0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Friend_ActivityJump0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Friend0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_EntryString0;
	public const object Assets-Scripts-GameSystem-CChatModel-Has_PLAYER_INFO0;
	public const object Assets-Scripts-GameSystem-CChatModel-Add_Palyer_Info0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Lobby0;
	public const object Assets-Scripts-GameSystem-CChatUT-FillWorldInviteData0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Lobby1;
	public const object Assets-Scripts-GameSystem-CChatUT-FillGuildInviteData0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Guild0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Guild1;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_GuildTeam0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Room0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Region0;
	public const object Assets-Scripts-GameSystem-CChatUT-FillRegionInviteData0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Region1;
	public const object Assets-Scripts-GameSystem-CChatModel-Get_HeroSelect_ChatTemplate0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-GetTypeAndContentByMessage0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-GetOtherCamp0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_SelectHero0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-GetMyTeammate0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-IsMyTeammate0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-IsSelfShareEnemy0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-IsMyEnemy0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-CanShowSoldierSkinShareThanksBySupporter0;
	public const object Assets-Scripts-GameSystem-UT-String2Bytes0;
	public const object Assets-Scripts-GameSystem-CChatModel-GetCurGroupTemplateInfo0;
	public const object Assets-Scripts-GameSystem-CChatController-Chat_Model_EventID-get_Chat_SelectLaneType0;
	public const object Assets-Scripts-GameSystem-CChatController-UpdateChatSelectLaneType0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Team0;
	public const object Assets-Scripts-GameSystem-CChatController-Chat_Model_EventID-get_Chat_TeamChat_Change0;
	public const object Assets-Scripts-GameSystem-CChatController-IsRegionChatAuthorization0;
	public const object Assets-Scripts-GameSystem-CChatController-DoNormalChatCallBack0;
	public const object Assets-Scripts-GameSystem-CChatController-DoChatAuthorization0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Settle0;
	public const object Assets-Scripts-GameSystem-CChatController-Chat_Model_EventID-get_Chat_LobbyChatData_Change0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_GetMsg_NTF0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_OfflineInfo0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Time1;
	public const object Assets-Scripts-GameSystem-CChatModel-AddOfflineChatIndex0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Offline_Friend0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_Offline_GetMsg_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_GetJudgePunish_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_GetComplaintPunish_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_GetComplaintPunish_Error0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_GetHangUp_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-OnChatGetSystemWarningNtf0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetAllFriend0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-initFriendsMsgCacheData0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Friend_FriendList_Refresh0;
	public const object Assets-Scripts-GameSystem-CChatController-Chat_Model_EventID-get_Chat_Friend_Online_Change0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_OfflineOrOnline0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-HaveRelationState0;
	public const object Assets-Scripts-GameSystem-CChatController-SendIntimacyFriendLoginMsgToBattle0;
	public const object Assets-Scripts-GameSystem-CChatController-SendIntimacyFriendLoginMsgToLobby0;
	public const object Assets-Scripts-GameSystem-CChatController-SendReturnFriendLoginMsgToLobby0;
	public const object Assets-Scripts-GameSystem-CChatController-OnFriendOnlineChangeNTF0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_Friend_Online_Change0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_Intimacy_Friend_Online_NTF0;
	public const object Assets-Scripts-GameSystem-CChatChannel-InitChat_InputTimer0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_PlayerLevel_Set0;
	public const object Assets-Scripts-GameSystem-CChatController-NtfRealTimeVoice0;
	public const object Assets-Scripts-GameSystem-CChatController-NtfMessEquipTip0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Rolling_SystemChatInfoReceived0;
	public const object Assets-Scripts-GameSystem-CChatChannel-ClearCd0;
	public const object Assets-Scripts-GameSystem-CChatChannel-Start_InputCD0;
	public const object Assets-Scripts-GameSystem-CChatController-OnErrorCodeNtf0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_CloseForm0;
	public const object Assets-Scripts-GameSystem-CChatController-SetJumpFriendTab0;
	public const object Assets-Scripts-GameSystem-CChatController-IsAuthorizationSwitch0;
	public const object Assets-Scripts-GameSystem-CChatController-IsRefreshAuthorizationPanelResult0;
	public const object Assets-Scripts-GameSystem-CChatController-SetAuthorizationEntryForm0;
	public const object Assets-Scripts-GameSystem-CChatController-ShowChatLimitTips0;
	public const object Assets-Scripts-GameSystem-CChatController-ShowChatPreviewTips0;
	public const object Assets-Scripts-GameSystem-CChatController-OnChatAuthorizationLimitEvent0;
	public const object Assets-Scripts-GameSystem-CChatController-RefreshChatAuthorizationResultTips0;
	public const object Assets-Scripts-GameSystem-CChatController-GetAuthorizationEntryForm0;
	public const object Assets-Scripts-GameSystem-CChatModel-get_ChannelMgr0;
	public const object Assets-Scripts-GameSystem-CChatController-ChatAuthorizationSdkCallbackEvent0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_EntryPanel_Click0;
	public const object Assets-Scripts-GameSystem-CChatController-OnLanguageChanged0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Chat_GetMsg_NTF1;
	public const object Assets-Scripts-GameSystem-CChatController-DoAuthorizationStatus0;
	public const object Assets-Scripts-GameSystem-CChatController-OnRefreshAuthorizationStatusEvent0;
	public const object Assets-Scripts-GameSystem-CChatController-InitEvent0;
	public const object Assets-Scripts-GameSystem-CChatController-Init0;
	public const object Assets-Scripts-GameSystem-CChatController-Update0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-ClearFriendChannelData0;
	public const object Assets-Scripts-GameSystem-CChatController-ClearFriendChatData0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Friend_Delete_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Guild_EnterGuild0;
	public const object Assets-Scripts-GameSystem-CChatController-On_Guild_LeaveGuild0;
	public const object Assets-Scripts-GameSystem-CChatController-SubmitRefreshEvent0;
	public const object Assets-Scripts-GameSystem-CChatController-CancleRefreshEvent0;
	public const object Assets-Scripts-GameSystem-CChatController-OpenFriendChatView0;
	public const object Assets-Scripts-GameSystem-CChatController-SetLastTimeStamp0;
	public const object Assets-Scripts-GameSystem-CChatController-ClearAllPanel0;
	public const object Assets-Scripts-GameSystem-CChatController-Jump2FriendChat0;
	public const object Assets-Scripts-GameSystem-CChatController-get_MaxChatLength0;
	public const object Assets-Scripts-GameSystem-CChatController-CheckInputLenth0;
	public const object Assets-Scripts-GameSystem-CChatController-IsChatBanByEUAge0;
	public const object Assets-Scripts-GameSystem-CChatController-ProcessChatBanByEUAge0;
	public const object Assets-Scripts-GameSystem-CChatController-IsChatBanLimit0;
	public const object Assets-Scripts-GameSystem-CChatController-GetBanLeftTimeStr0;
	public const object Assets-Scripts-GameSystem-CChatController-ProcessChatBanTips0;
	public const object Assets-Scripts-GameSystem-CChatChannel-IsInputValid0;
	public const object Assets-Scripts-GameSystem-CChatController-CheckSend0;
	public const object Assets-Scripts-GameSystem-CChatController-RemoveRichText0;
	public const object Assets-Scripts-GameSystem-CChatController-GetSysDataId0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsContain0;
	public const object Assets-Scripts-GameSystem-CFriendModel-isPlayerInType0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsFriend0;
	public const object Assets-Scripts-GameSystem-CChatUT-OnRichTextClick0;
	public const object Assets-Scripts-GameSystem-CChatController-NewMethod0;
	public const object Assets-Scripts-GameSystem-CChatController-OnClosingAnimEnd0;
	public const object Assets-Scripts-GameSystem-CChatController-OnShowAnimEnd0;
	public const object Assets-Scripts-GameSystem-CChatController-SetChatFilterLang0;
	public const object Assets-Scripts-GameSystem-CChatController-IsRegionChatOpen0;
	public const object Assets-Scripts-GameSystem-CChatController-GetCurSetRegionName0;
	public const object Assets-Scripts-GameSystem-CChatController-GetRecentChatRegion0;
	public const object Assets-Scripts-GameSystem-CChatController-HaveHistoryRegion0;
	public const object Assets-Scripts-GameSystem-CChatController-GetHotChatRegion0;
	public const object Assets-Scripts-GameSystem-CChatController-HaveMoreCities0;
	public const object Assets-Scripts-GameSystem-CChatController-SendChatSelectLaneType0;
	public const object Assets-Scripts-GameSystem-CChatController-HandleBack0;
	public const object Assets-Scripts-GameSystem-CChatController-IsFaceRainAvailable0;
	public const object Assets-Scripts-GameSystem-CChatController-IsChatPunishLimit0;
	public const object Assets-Scripts-GameSystem-CChatController-IsRealTimeVoicePunish0;
	public const object Assets-Scripts-GameSystem-CChatController-AddChatLimit0;
	public const object Assets-Scripts-GameSystem-CChatController-DelChatLimit0;
	public const object Assets-Scripts-GameSystem-CChatController-IsChatLimit0;
	public const object Assets-Scripts-GameSystem-CChatController-SetChatAuthorizationResult0;
	public const object Assets-Scripts-GameSystem-CChatController-GetJumpFriendTab0;
	public const object Assets-Scripts-GameSystem-CChatController-SetMaxCount0;
	public const object Assets-Scripts-GameSystem-CChatController-ProcessChatBanTips1;
	public const object Assets-Scripts-GameSystem-CChatController-ViewIsShow0;
	public const object Assets-Scripts-GameSystem-CChatController-FakeSendChat0;
	public const object Assets-Scripts-GameSystem-CChatController-ViewInitTemplateForm0;
	public const object Assets-Scripts-GameSystem-CChatController-ViewHideForm0;
	public const object Assets-Scripts-GameSystem-CChatController-HasView0;
	public const object Assets-Scripts-GameSystem-CChatController-IsLabbyFriendTab0;
	public const object Assets-Scripts-GameSystem-CChatController-SetViewFreshNew0;
	public const object Assets-Scripts-GameSystem-CChatController-ViewShowLoudSpeaker0;
	public const object Assets-Scripts-GameSystem-CChatController-ViewIsCheckHistory0;
	public const object Assets-Scripts-GameSystem-CChatController-UpdateSystem0;
	public const object Assets-Scripts-GameSystem-CChatController-ColorParserParse0;
	public const object Assets-Scripts-GameSystem-CChatController-get_SendChat0;
	public const object Assets-Scripts-GameSystem-CChatController-set_SendChat0;
	public const object Assets-Scripts-GameSystem-CChatController-get_Model0;
	public const object Assets-Scripts-GameSystem-CChatController-get_IsCanProcessChatMsg0;
	public const object Assets-Scripts-GameSystem-CChatController-set_IsCanProcessChatMsg0;
	public const object Assets-Scripts-GameSystem-CChatController-get_IsInLobby0;
	public const object Assets-Scripts-GameSystem-CChatController-set_IsInLobby0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-ParseText0;
	public const object Assets-Scripts-GameSystem-CChatController-ChatMsgReceiverParseText0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Room_Chat0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_Room_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Team_Chat0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_Team_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-SendEmojiMsgInTeam0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_SendEmojiMsgInTeam0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Leave_Settle0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_Leave_Settle0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Lobby_Chat0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_Lobby_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Private_Chat0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_Private_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_Chat_NTFMainThread0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_On_Chat_NTFMainThread0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_Chat_Complaint_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_On_Chat_Complaint_NTF0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_Chat_Complaint_RSP0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_On_Chat_Complaint_RSP0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_SCPKG_REALTIME_VOICE_COMPLAINT0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_SCPKG_REALTIME_VOICE_COMPLAINT_RSP0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_On_RealtimeVoice_Complaint_RSP0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_REALTIMEVOICE_COMPLAINT_RESULT0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_REALTIME_VOICE_COMPLAINT_RESULT_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_On_RealtimeVoice_Complaint_NTF0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_TranslateChatState_RSP0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_On_TranslateChatState_RSP0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_GetChat_Req0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Private_Chat_To_IntimacyFriend0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_Private_Chat_To_IntimacyFriend0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-IntimacyData-get_wIntimacyValue0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetValue0;
	public const object Assets-Scripts-GameSystem-CChatController-Report_Private_Chat_InBattle0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_Clear_Offline0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Guild_Chat0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_Send_Guild_Chat0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-SaveFriendsCacheData0;
	public const object Assets-Scripts-GameSystem-CChatUT-EnterLobby0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_EnterLobby0;
	public const object Assets-Scripts-GameSystem-CChatUT-LeaveRoom0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_LeaveRoom0;
	public const object Assets-Scripts-GameSystem-CChatUT-CChatUT_Build_Friend_System0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_Build_Friend_System0;
	public const object Assets-Scripts-GameSystem-CChatUT-LeaveLobby0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_LeaveLobby0;
	public const object Assets-Scripts-GameSystem-CChatUT-EnterTeam0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_EnterTeam0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_LoudSpeaker_EntryString0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_Build_4_LoudSpeaker_EntryString0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Speaker_EntryString0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_Build_4_Speaker_EntryString0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_SelectHero_Chat0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_Send_SelectHero_Chat0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_Self1;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_FriendReserveTips0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Reverse_Chat0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatUT_Send_Reverse_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-onMessWarningMainThread0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_MESS_EQUIP_WARNING_RESULT0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_MESS_EQUIPWARNING_RESULT_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-CChatNetUT_On_MESS_EQUIPWARNING_RESULT_NTF0;
	public const object Assets-Scripts-GameSystem-CChatController-OnBattleStart0;
	public const object Assets-Scripts-GameSystem-CChatController-Chat_Model_EventID-get_Force_Close_Chat_View0;
	public const object Assets-Scripts-GameSystem-CChatUT-GetEChatChannel_Text0;
	public const object Assets-Scripts-GameSystem-CChatUT-ColorString0;
	public const object Assets-Scripts-GameSystem-CChatUT-Build_4_ChatEntry0;
	public const object Assets-Scripts-GameSystem-CChatUT-EnterRoom0;
	public const object Assets-Scripts-GameSystem-CChatUT-LeaveTeam0;
	public const object Assets-Scripts-GameSystem-CChatUT-EnterSettle0;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_TransTextForDisplay0;
	public const object Assets-Scripts-GameSystem-CChatEntity-CopyTextDataTo0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_UllUid0;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_UllUid0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_ILogicWorldID0;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_ILogicWorldID0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_iName0;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_iName0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_iRemark0;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_iRemark0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_ContentType0;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_ContentType0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_State0;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_State0;
	public const object Assets-Scripts-GameSystem-CChatEntity-get_ChatType0;
	public const object Assets-Scripts-GameSystem-CChatEntity-set_ChatType0;
	public const object Assets-Scripts-GameSystem-CChatModel-ClearCOfflineChatIndex1;
	public const object Assets-Scripts-GameSystem-CChatModel-GetCurGroupChatTemplateInfo0;
	public const object Assets-Scripts-GameSystem-CChatModel-SetCurGroupTemplateInfo0;
	public const object Assets-Scripts-GameSystem-CChatModel-Load_HeroSelect_ChatTemplate0;
	public const object Assets-Scripts-GameSystem-CChatModel-GetLastUnread_Selected0;
	public const object Assets-Scripts-GameSystem-CChatModel-IsTemplate_IndexValid0;
	public const object Assets-Scripts-GameSystem-CChatModel-Clear_HeroSelected0;
	public const object Assets-Scripts-GameSystem-CChatModel-Remove_Palyer_Info0;
	public const object Assets-Scripts-GameSystem-CChatModel-get_EnableInBattleInputChat0;
	public const object Assets-Scripts-GameSystem-CChatModel-set_EnableInBattleInputChat0;
	public const object Assets-Scripts-GameSystem-CChatModel-get_SysData0;
	public const object Assets-Scripts-GameSystem-CChatSysData-get_chatCostNum0;
	public const object Assets-Scripts-GameSystem-CChatSysData-get_chatCostType0;
	public const object Assets-Scripts-GameSystem-CChatSysData-ClearEntryText0;
	public const object Assets-Scripts-GameSystem-CChatSysData-Add_NewContent_Entry_Speaker0;
	public const object Assets-Scripts-GameSystem-CChatChannel-GetUnreadMeanbleChatEntCount0;
	public const object Assets-Scripts-GameSystem-CChatChannel-ReadAll0;
	public const object Assets-Scripts-GameSystem-CChatChannel-Get_Left_CDTime0;
	public const object Assets-Scripts-GameSystem-CChatChannel-Get_ChatBanLimit_CDTime0;
	public const object Assets-Scripts-GameSystem-CChatChannel-GetChatList0;
	public const object Assets-Scripts-GameSystem-CChatChannel-SubRedCount0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetFiendLastChatTime0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetFriendsMsgCacheList0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-ClearIllegalPlayerChatInfo0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-Clear0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetFriendTotal_UnreadCount0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-Add_CurChatFriend0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetIChannel0;
	public const object Assets-Scripts-GameSystem-CChatChannelMgr-GetFriendIChannel0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_TV_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Region_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_GuildTeam_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_SelectHero_Chat1;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_SelectHero_SoldierSkin_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Settle_Chat0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_Private_Chat_To_IntimacyRelation0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_Chat_NTF_RelaySvr0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_Chat_NTF_LobbySvr0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_Offline_Chat_NTF0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_Chat_Judge_Punish_NTF0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-RspFilterChatLang0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-ReqSetChatRegion0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-RspSetChatRegion0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_GemTranslateReq0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_SCPKG_CMD_MANUAL_GMETRANSLATE_RSP0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-Send_RealtimeCandidComplaintReq0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_SCPKG_REALTIMEVOICE_COMPLAINT_RSP0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_SCPKG_REALTIME_VOICE_COM_PLAINT_RSP0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_REALTIME_VOICECOMPLAINT_RESULT_NTF0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_REALTIME_VOICECOMPLAINT_RESULT_NTF_RelaySvr0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_MESS_EQUIP_WARNING_RESULT_NTF0;
	public const object Assets-Scripts-GameSystem-CChatNetUT-On_MESS_EQUIP_WARNING_RESULT_NTF_RelaySvr0;
	public const object Assets-Scripts-GameSystem-ChatItemHelper-OnChatHideAnimationEnd0;
	public const object Assets-Scripts-GameSystem-ChatItemHelper-OnChatShowAnimationEnd0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-HasNewMsgUnread0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-ProcessNewMsgTips0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-OnChatFormClose0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-On_Chat_ChatTeampTalk_Change0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-SetBriefText0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-On_Chat_ChatRoomTalk_Change0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-On_Chat_UnreadCountChanged0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-On_Chat_ChatTeampTalk_Clear0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-On_Chat_ChatSelectHero_Change0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-On_Friend_Delete_NTF0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-Start0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-ClearLastChatMsgText0;
	public const object Assets-Scripts-GameSystem-ChatMsgReceiver-OnDestroy0;
	public const object Assets-Scripts-GameSystem-TextCutter-CutText0;
	public const object Assets-Scripts-GameSystem-TextCutter-GetTextListAndWidth0;
	public const object Assets-Scripts-GameSystem-TextCutter-ParseText0;
	public const object Assets-Scripts-GameSystem-TextCutter-GetCutIndexWithLineLimit0;
	public const object Assets-Scripts-GameSystem-TextCutter-ParseLines0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-SetSelfShareEnemy0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-GetThanksPrefixByMessageType0;
	public const object Assets-Scripts-GameSystem-CHeroSelectSoldierSkinHelper-CanShowSoldierSkinShareThanks0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBanSelectInfoBubbleView-get_bubbleType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBubbleBaseView-HideBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBanSelectInfoBubbleView-OnClickHelpBan0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBanSelectInfoBubbleView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBattleGuessBubbleView-get_bubbleType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBattleGuessBubbleView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBattleInfoBubbleView-get_bubbleType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBubbleBaseView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBattleInfoBubbleView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBubbleItemView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBubbleItemView-OnRefresh0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBubbleItemView-HideBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBubbleItemView-ShowBubbleAndStartTime0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBubbleItemView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectBubbleItemView-HideBubble1;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleControlView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleControlView-OnRefresh0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleControlView-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleControlView-OnUnRegEvent0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleView-GetOneBubbleView0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleControlView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleControlView-ShowEnemyBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleControlView-HideBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleControlView-HideEnemyBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleView-OnRefresh0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleView-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleView-OnUnRegEvent0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatBubbleView-SetCheckPlayerUid0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-ResetLaneDisplayInfoBuff0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-ResetOverlapFrameTips0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-Compare0;
	public const object Assets-Scripts-GameSystem-CUILanePickLaneInfo-SetOverlap0;
	public const object Assets-Scripts-GameSystem-CUILanePickOverlapFrame-Set0;
	public const object Assets-Scripts-GameSystem-CUILanePickOverlapFrame-SetBorderSelfActive0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-SetOverlapFrameTips0;
	public const object Assets-Scripts-GameSystem-CUILanePickLaneInfo-SetHeroIcon0;
	public const object Assets-Scripts-GameSystem-CUILanePickLaneInfo-SetLaneEffect0;
	public const object Assets-Scripts-GameSystem-CUILanePickLaneInfo-SetBorderSelfActive0;
	public const object Assets-Scripts-GameSystem-CUILanePickLaneInfo-SetBorderOtherActive0;
	public const object Assets-Scripts-GameSystem-CUILanePickLaneInfo-RefreshLaneRedSelect0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-ApplyHeroLanePickBySystemCache0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-InitInfo0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-SetToHideState0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-NormalDynamicMapControlPanelLoadCallback0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-InitTemplateInfo0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-On_Input_Timer_End0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnChatEditEnd0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-refreshAllChatList0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-chatPanelSetToHideState0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-SetHideScript0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-Start_Input_Timer0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-refreshChatTemplateList0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-SetShowHistorOrTemplate0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-IsChatAuthorizationInBattle0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnClickTabEvent0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-SwitchHideShowState0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-SwitchChatViewInfoShow0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-On_InputFiled_SendCallBack0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-On_Send_Text0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-HideAll0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-Show_SelectChat_MidNode0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnUpdateBottomButtons0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-Refresh_BottomChat0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-RefreshSoldierSkinSendBtn0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-InitChatInfo0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-SetShowType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnDestroy0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnRefresh0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnCloseAllPanel0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnLanePick0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-GetCurrentBubbleControlView0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-Show_Bubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-Refresh_Bubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-On_Chat_HeorSelectChatData_Change0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnShowChatBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-Hide_Bubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-RefreshEntryMapIcon0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnPrepareBattle0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-On_List_Item_Click0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-ForceCloseChatViewInfo0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-SelectHeroChatAuthorizationSdkCallbackEvent0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnShowSoldierSkinBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-DoSendSoldierSkinShareThanks0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnShowSoldierSkinClick0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnWearShareSoldierSkin0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnUnRegEvent0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-ClearInfo0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-OnFormDestroyed0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectChatControlWindow-IsChatAuthorization0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSoldierShareInfoBubbleView-get_bubbleType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSoldierShareInfoBubbleView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSoldierShareThanksInfoBubbleView-get_bubbleType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSoldierShareThanksInfoBubbleView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSpeakInfoBubbleView-get_bubbleType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSpeakInfoBubbleView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSpeakInfoBubbleView-SetBubbleText0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSpeakInfoBubbleView-ShowBubbleInCoroutine0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSpeakInfoBubbleView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSystemHelpChooseInfoBubbleView-get_bubbleType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectSystemHelpChooseInfoBubbleView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectWantChooseInfoBubbleView-get_bubbleType0;
	public const object Assets-Scripts-GameSystem-CUIHeroSelectWantChooseInfoBubbleView-ShowBubble0;
	public const object Assets-Scripts-GameSystem-CUILanePickLaneInfo-Init0;
	public const object Assets-Scripts-GameSystem-CUILanePickLaneInfo-GetLaneType0;
	public const object Assets-Scripts-GameSystem-CUILanePickOverlapFrame-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-InitMapTab0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-OnClickMapSlider0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-InitMapSlider0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-InitMapBanPickMask0;
	public const object Assets-Scripts-GameSystem-CUILanePickWindow-OnViewInited0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-SetChatLayoutText0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-SetChatLayout0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-ShowChannelChat0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-OnLobbyChatMsg0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-OnGuildChatMsg0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-OnRegionChatMsg0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-DelayHideBubbleMsg0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-AddBubbleMsg0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-LobbyChatView-CreateChatText0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-ToggleMatching_Chat_Team_TemplateView0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-OnMatchtingToggleChatView0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-CreatGameObj0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-CreatLineContent0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-OnMatching_Chat_Team_Template_List_ElementEnable0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-IsTeamQuickChatInCd0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-OnMatching_Chat_Team_Template_List_ElementSelect0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-SetChatLayout0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-ShowChannelChat0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-OnLobbyChatMsg0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-OnFormDestroyed0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-SetQuickChatEnable0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-InitMatching_Chat_Template0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-get_DynamicVoicePanelObj0;
	public const object Assets-Scripts-GameSystem-MatchingTeamChatView-CreateChatText0;
	public const object Assets-Scripts-GameSystem-CUITipDialogWnd-Show0;
	public const object Assets-Scripts-GameSystem-DLCCleanNewTableItem-RefreshBtn0;
	public const object Assets-Scripts-GameSystem-DLCCleanNewTableItem-RefreshShow0;
	public const object Assets-Scripts-GameSystem-DLCCleanNewTableItem-ShowDLCDownloading0;
	public const object Assets-Scripts-GameSystem-DLCCleanNewTableItem-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCDownloadedItem-ShowDLCDownloaded0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-OnItemEnable0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-RefreshSelectedSize0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-SelectListRefresh0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-RefreshView0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-SetEnableRefresh0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-LoadUpdateList0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-CleanReturn0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-SelectAllFun0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-RefreshView0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-DoDelete0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-OnDeleteClick0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-UNSelectAllFun0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-SelectAllDlc0;
	public const object Assets-Scripts-GameSystem-DLCCleanView-OnDestroy0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-OnItemEnable0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-OnTableEnable0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-RefreshSelectedSize0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-ClearSelectedSize0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-SetCleanBtnEnable0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-SelectAllFun0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-RefreshView0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-OnTableSelect0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-SelectListRefresh0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-RefreshView0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-SetEnableRefresh0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-LoadUpdateList0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-CleanReturn0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-DoDelete0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-OnDeleteClick0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-UNSelectAllFun0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-RefreshTableView0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-SelectAllDlc0;
	public const object Assets-Scripts-GameSystem-DLCCleanViewNew-OnDestroy0;
	public const object Assets-Scripts-GameSystem-DLCDownloadedItem-OnSelectClick0;
	public const object Assets-Scripts-GameSystem-DLCDownloadedItem-SelectAllRefresh0;
	public const object Assets-Scripts-GameSystem-DLCDownloadedItem-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCDownloadedItem-OnDestroy0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-Initialize0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-setProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-UpdateState0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-OnEnable0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-OnDisable0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-OnFormDestroyed0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-ResCore.DLC.DLCDownloaderDelegate.OnDownloadError0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderFloatingTip-OnDownloadPause0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-UpdateSpeed0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-SetProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-UpdateDownloadState0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-UpdateProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-CalcBeginSize0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-SetDLCIDs0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ShowSpeed0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-SetStateText0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderItem-RefreshBtn0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderItem-RefreshShow0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderItem-ShowDLCDownloading0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderItem-OnPauseClick0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderItem-OnResumeClick0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderItem-OnDeleteClick0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderItem-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnItemEnable0;
	public const object Assets-Scripts-GameSystem-DLCDownLoaderTableItem-UpdateDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownLoaderTableItem-RefreshBtn0;
	public const object Assets-Scripts-GameSystem-DLCDownLoaderTableItem-InitShow0;
	public const object Assets-Scripts-GameSystem-DLCDownLoaderTableItem-ShowDLCDownloading0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnTableEnable0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-SetRefreshCurrentTableDLCGroupList0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-UpdateTabDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnTableSelect0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetCurrentDownloadResLevel0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetResLevelIdsArray0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-CurrentLevelResIsDownloadComplete0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-RefreshDownloadBtn0;
	public const object Assets-Scripts-GameSystem-DLCDownLoaderTableItem-RefreshShow0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-RefreshTableList0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-RefreshTableList1;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-IsDownloading0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-UpdateDownloadSpeed0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-UpdateNetworkText0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-RefreshViewOnCurrentTabIsDownloading0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDownloadStateReady0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-IsShowWifi0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-onNetworkStateChanged0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnRefreshPandoraDLCState0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetRuleID0;
	public const object Assets-Scripts-GameSystem-DLCPreView-GetPrefabPath0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-IsOwnLobbyHeroSkin0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-GetDisplayName0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-IsShowDLCItem0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-DoTableList0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-InitTable0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDownloadCanceled0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDownloadError0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-UpdateTabDownloadProgress1;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-CheckAndUpdateTabDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnFileDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDLCDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-RefreshTableList2;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDLCDownloadStart0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDownlodingCountChanged0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDownloadPause0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnApplicationPauseEvent0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-ClosePandoraDLC0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnDestroy0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-PufferIsReady0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-RefreshCurrentTableDLCGroupList0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-DoRefreshView0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-Update0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-DoDLCList0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OnCreatePandoraDlc0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderNewView-OpenPandoraDLC0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDownloadError0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-ExchangeSize0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-OnUnRegEvent0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-OnDownloadPause0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-OnEnable0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderProgress-OnDisable0;
	public const object Assets-Scripts-GameSystem-DLCDownLoaderTableItem-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-OnItemEnable0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-showDescription0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-OnApplicationPauseEvent0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-OnDownloadStateReady0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-OnDestroy0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-DoRefreshView0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-Update0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-DoDLCList0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-RefreshDownloadBtn0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-ResCore.DLC.DLCDownloaderDelegate.OnDownloadError0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloaderView-OnDownloadPause0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-openDownloadingList0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-RegisterOwnerBattleHeroDLC0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-IsDLCNeedDownload0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-doPause0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-AddLobbyHeroSkinDL0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-AutoDownloadLobbyRes0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ReportDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-hideDLCDownloadListBtn0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-updateDLCDownloadListBtnIcon0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-showDLCDownloadListBtn0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-RefreshDLCDownloadListBtn0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ShowDownloadFloatWndAndDownloadLobyRes0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-StartShowDownloadFloatWndAndDownloadLobyRes0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-_ReportDLCDownloadTaskState0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ActiveAndShowDownloading0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnLobbyShow0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnLobbyStateLeave0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-CloseDLCDownloadListBtnTips0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-RefreshDLCTipsState0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnSettleToLobby0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-onDownloadDeactive0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TryDownloadDLCByID0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-_doDowloadHeroAllSkin0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-downloadHeroAllSkin0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-CloseDLCDownloadListBtnTips1;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-onClickDDownloadListBtnClick0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-onClickClearListBtnClick0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-onClickClearNewBtnClick0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-doPandoraDLCPause0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TriggerStorageLimited0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetResumeDownloadDLCIds0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-DoDownloadAll0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnDownloadAll0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnClearAll0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-RefreshView0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-DoClearAll0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnClearAllOld0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-IsPufferVersionUnMatched0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-DoPufferVersionUnMatched0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-RegisterTimingDLCConfig0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-DownloadHeroBattleLowRes0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-RegisterPreDLCConfig0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-AddPandoraDLCConfig0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-UpdateDLMaxConfig0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnEnterLobby0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-tryPause0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnPauseAll0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-tryResume0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnResumeAll0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TemporarySkin0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnGetNewSkinNtf0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnGetNewHeroNtf0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnDownloadStateReady0;
	public const object Assets-Scripts-GameSystem-DLCPreView-UpdateDownloadSpeed0;
	public const object Assets-Scripts-GameSystem-DLCPreView-UpdateNetworkText0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-SetDownloaded0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-SetProgressBarImage0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-UpdateNoIdsText0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-UpdateProgress0;
	public const object Assets-Scripts-GameSystem-DLCPreViewItem-RefreshBtn0;
	public const object Assets-Scripts-GameSystem-DLCPreViewItem-RefreshShow0;
	public const object Assets-Scripts-GameSystem-DLCPreView-RefreshItems0;
	public const object Assets-Scripts-GameSystem-DLCPreView-SetEnableRefresh0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-onNetworkStateChanged0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnGameLogout0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnRefreshPandoraDLCState0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnPufferVersionChanged0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-Init0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TryReportDownloadSize0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-StartListenDownloading0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-UnInit0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TryDownloadHeroDLC0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-_TryDownloadDLC1;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TryDownloadDLCByType1;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TryDownloadAsianDLC0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetResumeIds0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-HeroAllSkinDownloaded0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-TryDownloadLobbyHeroSkinSound0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-IsHeroSkinDownloaded0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-IsHuanHuaReady0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-heroAllSkinInQueue0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-_DoDownloadHuanhua0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-requestDownloadHuanHua0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-requestDownloadHeroAllSkin0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-requestDownloadAutoChessHeroAllSkin0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-CheckInitialAppBattleResourceNeedUpdateAndShowTip0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-InitNotOwnHeroNewSkin0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-IsPausing0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-RefreshDLCDownloadTab0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ResCore.DLC.DLCDownloaderDelegate.OnDownloadError0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-LoadBank0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OnDownloadPause0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-OpenTipDialogWnd0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-SetDownloaderProgress0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-CreatePandoraDlc0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-ChangeDownloadPackage0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetCurrentPackageConfigID0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetRecommendedPackageConfigID0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetResLevelTotalSizeArray0;
	public const object Assets-Scripts-GameSystem-DLCDownloadUISystem-GetResLevelByDlcID0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-CalcBeginSize0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-SetDLCIDs0;
	public const object Assets-Scripts-GameSystem-DLCPreViewItem-InitShow0;
	public const object Assets-Scripts-GameSystem-DLCPreViewItem-ShowDLCDownloading0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnItemEnable0;
	public const object Assets-Scripts-GameSystem-DLCPreView-UpdateRecommendPackageInfo0;
	public const object Assets-Scripts-GameSystem-DLCPreView-DownloadPackageChangeHandle0;
	public const object Assets-Scripts-GameSystem-DLCPreView-SetRefreshItems0;
	public const object Assets-Scripts-GameSystem-DLCPreView-SetTotalSizeEmpty0;
	public const object Assets-Scripts-GameSystem-DLCPreView-UpdateDownloadSizeDisplay0;
	public const object Assets-Scripts-GameSystem-DLCPreView-UpdateTotalDownloadSize0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnApplicationPauseEvent0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDownloadStateReady0;
	public const object Assets-Scripts-GameSystem-DLCPreView-IsShowWifi0;
	public const object Assets-Scripts-GameSystem-DLCPreView-RefreshView0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-GetPrefabPath0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCPreView-onNetworkStateChanged0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnUnRegEvent0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDestroy0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDownloadCanceled0;
	public const object Assets-Scripts-GameSystem-DLCPreView-UpdateDownloadSizeDisplay1;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDownloadError0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnFileDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDLCDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCPreView-RefreshItem0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDLCDownloadStart0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDownlodingCountChanged0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnDownloadPause0;
	public const object Assets-Scripts-GameSystem-DLCPreView-OnRefreshPandoraDLCState0;
	public const object Assets-Scripts-GameSystem-DLCPreView-PufferIsReady0;
	public const object Assets-Scripts-GameSystem-DLCPreView-DoDLCList0;
	public const object Assets-Scripts-GameSystem-DLCPreView-RefreshItemView0;
	public const object Assets-Scripts-GameSystem-DLCPreView-ReportDownloadState0;
	public const object Assets-Scripts-GameSystem-DLCPreView-DoRefreshView0;
	public const object Assets-Scripts-GameSystem-DLCPreView-Update0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-OnUnRegEvent0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDownloadError0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-UpdateDownloadedSize0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged0;
	public const object Assets-Scripts-GameSystem-DLCPreViewDownloaderProgress-OnDownloadPause0;
	public const object Assets-Scripts-GameSystem-DLCPreViewItem-OnDownloadingClick0;
	public const object Assets-Scripts-GameSystem-DLCPreViewItem-OnNoStartClick0;
	public const object Assets-Scripts-GameSystem-DLCPreViewItem-OnWaitClick0;
	public const object Assets-Scripts-GameSystem-DLCPreViewItem-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-InitPackageData0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-OnBtnHelpClick0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-OnBtnConfirmClick0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-OnViewInited0;
	public const object Assets-Scripts-GameSystem-DLCPackageViewItem-SetSelectedState0;
	public const object Assets-Scripts-GameSystem-DLCPackageViewItem-ShowPackageItem0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-OnItemEnable0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-OnRegEvent0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-OnUnRegEvent0;
	public const object Assets-Scripts-GameSystem-DLCPackageViewItem-PackageIdIsEqual0;
	public const object Assets-Scripts-GameSystem-DLCPackageView-SelectDLCPackage0;
	public const object Assets-Scripts-GameSystem-DLCPackageViewItem-OnItemClick0;
	public const object Assets-Scripts-GameSystem-DLCPackageViewItem-OnViewInited0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-get_twoEquipMaxCount0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-get_threeEquipMaxCountPer2ndEquip0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-get_backEquipMaxCount0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-ClearEquipList0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-GetLobbyEquipShopID0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-LobbyEquipShopInVisitor0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-ReloadEquipInfoDictionary0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-ReloadEquipInfoDictionaryUI0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-Init0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-CurEditHeroID0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-InitEquipShopTitleVars0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-IsCfgForbidEquipType0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-IsAidEquipEnable0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-IsFestivalEquipEnable0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-IsLightDarkMode0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-IsLightEquipEnable0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-IsDarkEquipEnable0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-IsEquipUsageEnable0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-GetEquipTypeTitle0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-GetEquipTittleList0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-GetCurEditHeroUserEquipId0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-GetCurEditHeroEquipPlanNameByIndex0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-NeedCheckPrivilege0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-HasEverHadPrivilege0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-CheckPrivilegeIconDisableStatus0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-GetPrivilegeCountNum0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-IsEverHadPrivilegeOrNowHave0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-GetEquipShopInfo0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-GetRcmdShowCount0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-ShowSingleEquipItemUIWithTouchTips0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-RefreshSelfEquipPlanForm0;
	public const object Assets-Scripts-GameSystem-CEquipSystem-OpenSelfEquipPlanFormInBattle0;
	public const object Assets-Scripts-GameSystem-CFriendNewApplayForRedPoint-ResetAllData0;
	public const object Assets-Scripts-GameSystem-CFriendController-Assets.Scripts.GameSystem.IFriendController.get_model0;
	public const object Assets-Scripts-GameSystem-CFriendController-Assets.Scripts.GameSystem.IFriendController.get_view0;
	public const object Assets-Scripts-GameSystem-CFriendController-get_ApplayForRedPointInfo0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetFriendApplayCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetApplayRelationCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-CanShowFriendReqTipToday0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnNewApplayRedPointRefresh0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetNewApplayForRedPointInfo0;
	public const object Assets-Scripts-GameSystem-CFriendModel-ClearLBSData0;
	public const object Assets-Scripts-GameSystem-FriendReserve-Clear0;
	public const object Assets-Scripts-GameSystem-CFriendModel-ClearAll0;
	public const object Assets-Scripts-GameSystem-CFriendModel-set_fileter0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetFilter0;
	public const object Assets-Scripts-GameSystem-CFriendController-ClearAll0;
	public const object Assets-Scripts-GameSystem-CFriendModel-LoadPreconfigVerifyContentList0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnLanChanged0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnNewDayNtf0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_MatchBlackList0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnLobbyEnter0;
	public const object Assets-Scripts-GameSystem-CFriendController-DownloadDlc0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-CheckFrinedInfoState0;
	public const object Assets-Scripts-GameSystem-CFriendModel-FindFriendData-reset0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_OpenForm0;
	public const object Assets-Scripts-GameSystem-GPSSys-StopGPS0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_CloseForm0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetInfo0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_FriendCoin0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_Friend_SendCoin0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_Friend_CheckInfo0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetGCloudChannelFormParam0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-SendInviteSNSFriendReport0;
	public const object Assets-Scripts-GameSystem-UT-GetText0;
	public const object Assets-Scripts-GameSystem-CFriendController-SendInviteMsg0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_Friend_Invite_SNS_Friend_BtnClick0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsOnSnsSwitch0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Request_Sns_Switch0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnShareToggle0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_Intimacy_Reward0;
	public const object Assets-Scripts-GameSystem-CFriendModel-set_EnableShareLocation0;
	public const object Assets-Scripts-GameSystem-CFriendModel-get_EnableShareLocation0;
	public const object Assets-Scripts-GameSystem-GPSSys-get_iLng0;
	public const object Assets-Scripts-GameSystem-GPSSys-get_iLat0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Report_Clt_Location0;
	public const object Assets-Scripts-GameSystem-CFriendModel-get_fileter0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Search_LBS_Req0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_GPS_Response0;
	public const object Assets-Scripts-GameSystem-GPSSys-StartGPS0;
	public const object Assets-Scripts-GameSystem-GPSSys-GetPosition0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Clear_Location0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetEnableShareLocation0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriend_LBS_OnClickEnableLBS0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriend_LBS_OnClickDisableLBS0;
	public const object Assets-Scripts-GameSystem-CFriendModel-NegFlag0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriend_LBS_Nan0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriend_LBS_Nv0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriend_SetConnect0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriend_ConnectFacebookFinish0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriend_DisConnectFacebookFinish0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriendFBSNSInviteChooseToNotBindFacebook0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnApplicationPause0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_MatchBlack0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_Send_MatchBlack0;
	public const object Assets-Scripts-GameSystem-CFriendController-InitEvent0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetPosition0;
	public const object Assets-Scripts-GameSystem-CFriendController-Init0;
	public const object Assets-Scripts-GameSystem-CFriendController-UninitEvent0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SortSNSOnlyList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetSNSOnlyList0;
	public const object Assets-Scripts-GameSystem-UT-SetHead0;
	public const object Assets-Scripts-GameSystem-UT-ShowSNSOnlyFriendData0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-On_SNS_Invite_ItemEnable0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-On_Invite_SNS_OnlyFriend0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-On_Invite_SNSOnly_Friend_Confirm0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-On_Get_SNS_Invite_Rewards0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-Clear0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-On_Friend_Close_SNSInviteForm0;
	public const object Assets-Scripts-GameSystem-CFriendModel-get_SnsTotalInviteNum0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-RefreshTotalNum0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-RefreshFriend0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-RefreshPlatform0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-Refresh0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-Init0;
	public const object Assets-Scripts-GameSystem-CFriendView-On_OpenSNSOnlyInviteForm0;
	public const object Assets-Scripts-GameSystem-CFriendController-OpenSnsOnlyAwardForm0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SetCanNotBeInvited0;
	public const object Assets-Scripts-GameSystem-CFriendController-Update_SNSOnlyList_CanBeInvite0;
	public const object Assets-Scripts-GameSystem-CFriendController-SaveInviteLog0;
	public const object Assets-Scripts-GameSystem-CFriendController-ReadinviteLog0;
	public const object Assets-Scripts-GameSystem-CFriendController-Send_Req_SNSFriendList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetSNSOnlyIndex0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SetSNSOnlyHaveShared0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-SetButtonInteractable0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-SetHaveShared0;
	public const object Assets-Scripts-GameSystem-CFriendController-On_Friend_SNS_Share_Friend0;
	public const object Assets-Scripts-GameSystem-CFriendController-SNSOpenIdToPlatformId0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetIntimacyChangeInfo0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetIntimacyChangeInfoDelta0;
	public const object Assets-Scripts-GameSystem-UT-GetMeasureText0;
	public const object Assets-Scripts-GameSystem-CFriendController-ShowDelayedIntimacyChange0;
	public const object Assets-Scripts-GameSystem-CFriendController-CheckFriendStatusChange0;
	public const object Assets-Scripts-GameSystem-CFriendController-OpFriendListCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetFriendPointByType0;
	public const object Assets-Scripts-GameSystem-CFriendController-Open_Friend_Verify0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetMatchBlackCount0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetMatchBlackMaxCount0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetMatchBlackName0;
	public const object Assets-Scripts-GameSystem-CFriendController-Send_MatchBlack0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetDataCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetFirendRedDotCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetRelationRedDotCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetRelationUpdateRedDotCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetRelationAnniRedDotCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetRelationAnniAndUpdateRedDotCount0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetFriendBtnIsHaveRed0;
	public const object Assets-Scripts-GameSystem-CFriendReCallData-Add0;
	public const object Assets-Scripts-GameSystem-UT-Check_AddReCallCD0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-RequestRecallReward0;
	public const object Assets-Scripts-GameSystem-CFriendController-SendRecallMsg0;
	public const object Assets-Scripts-GameSystem-CFriendController-UpdateForbidFriendReq0;
	public const object Assets-Scripts-GameSystem-CFriendController-OnFriend_FacebookStateChange0;
	public const object Assets-Scripts-GameSystem-CFriendController-AddIntimacyFriendTranslateInBattle0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetRelationLvByValue0;
	public const object Assets-Scripts-GameSystem-MyFriendForm-CanInvite0;
	public const object Assets-Scripts-GameSystem-MyFriendForm-Init0;
	public const object Assets-Scripts-GameSystem-CFriendController-OpenMyFriendForm0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetFriendRaltionItemList0;
	public const object Assets-Scripts-GameSystem-UT-SetHttpImage0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetHttpImage0;
	public const object Assets-Scripts-GameSystem-UT-ShowRank0;
	public const object Assets-Scripts-GameSystem-CFriendController-ShowRank0;
	public const object Assets-Scripts-GameSystem-CFriendController-ShowRank1;
	public const object Assets-Scripts-GameSystem-CFriendController-ShowSNSOnlyFriendData0;
	public const object Assets-Scripts-GameSystem-UT-GetTimeString0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetTimeString0;
	public const object Assets-Scripts-GameSystem-CFriendController-ResetTimer0;
	public const object Assets-Scripts-GameSystem-UT-CalcDeltaHorus0;
	public const object Assets-Scripts-GameSystem-CFriendController-CalcDeltaHorus0;
	public const object Assets-Scripts-GameSystem-CFriendModel-getFriendByUidAndLogicWorldID0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-SortCFriendRelationInfo0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetCanRemoveRelationFriendList0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetCanRemoveRelationFriendList0;
	public const object Assets-Scripts-GameSystem-UT-SetTabList0;
	public const object Assets-Scripts-GameSystem-CFriendController-SetTabList0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-ResetGetFrinedInfoState0;
	public const object Assets-Scripts-GameSystem-CFriendController-ResetGetFrinedInfoState0;
	public const object Assets-Scripts-GameSystem-CFriendController-Send_Request_Sns_Switch0;
	public const object Assets-Scripts-GameSystem-CFriendController-CheckFrinedInfoState0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-SendReserveAcntReq0;
	public const object Assets-Scripts-GameSystem-CFriendController-SendReserveAcntReq0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-SendReserveOperReq0;
	public const object Assets-Scripts-GameSystem-CFriendController-SendReserveOperReq0;
	public const object Assets-Scripts-GameSystem-CFriendController-SendInviteSNSFriendReport0;
	public const object Assets-Scripts-GameSystem-UT-PlayerNickyOrRemarkName1;
	public const object Assets-Scripts-GameSystem-CFriendController-GetRemarkOrNicky0;
	public const object Assets-Scripts-GameSystem-CFriendController-ShowRank2;
	public const object Assets-Scripts-GameSystem-CFriendController-get_iLng0;
	public const object Assets-Scripts-GameSystem-CFriendController-get_iLat0;
	public const object Assets-Scripts-GameSystem-CFriendController-GetCurrentFriendPanelTab0;
	public const object Assets-Scripts-GameSystem-CFriendController-IsFriendLBS0;
	public const object Assets-Scripts-GameSystem-CFriendController-StopGPS0;
	public const object Assets-Scripts-GameSystem-CFriendModel-get_FBOrVkSort0;
	public const object Assets-Scripts-GameSystem-CFriendModel-Assets.Scripts.GameSystem.IFriendModel.get_friendReserve0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetBlackList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetBlackName0;
	public const object Assets-Scripts-GameSystem-CFriendModel-AddBlack0;
	public const object Assets-Scripts-GameSystem-CFriendModel-AddFriendBlack0;
	public const object Assets-Scripts-GameSystem-CFriendModel-RemoveFriendBlack0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetSNSOnlyAllList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-ResetSNSOnlyFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-AddSNSOnlyFirend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-set_SnsTotalInviteNum0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetVerifyContentList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendVerifyContent0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendVerifySource0;
	public const object Assets-Scripts-GameSystem-CFriendModel-AddFriendVerifyContent0;
	public const object Assets-Scripts-GameSystem-CFriendModel-RemoveFriendVerifyContent0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetLBSGenterFilter0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetLBSList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetCurrentLBSList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetLBSListByUISys0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetLBSUserInfo0;
	public const object Assets-Scripts-GameSystem-CFriendSort-LBSDataSort0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SortLBSFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-RemoveLBSUser0;
	public const object Assets-Scripts-GameSystem-CFriendModel-RemoveLBSUser1;
	public const object Assets-Scripts-GameSystem-CFriendModel-AddLBSUser0;
	public const object Assets-Scripts-GameSystem-CFriendModel-AddLBSUser1;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendListContainText0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetMatchBlackList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-ClearMatchBlackList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-AddMatchBlack0;
	public const object Assets-Scripts-GameSystem-CFriendModel-RemoveMatchBlack0;
	public const object Assets-Scripts-GameSystem-CFriendModel-RemoveMatchBlack1;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsMatchBlack0;
	public const object Assets-Scripts-GameSystem-CFriendListData-GetOnlineCount0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsAnyFriendExist0;
	public const object Assets-Scripts-GameSystem-CFriendListData-IsFriendOnline0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsFriendOfflineOnline0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-GetFriendInGamingState0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-IsFriendInGamingState0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsFriendInGamingState0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGameStateList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGamingState0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-GetFriendInGamingSubState0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGamingSubState0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-GetFriendInGamingTeamId0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGamingTeamId0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-GetFriendInGamingTeamSeq0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGamingTeamSeq0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGaming0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-GetFriendInGameMapType0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGameMapType0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-GetFriendInGameMapID0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGameMapID0;
	public const object Assets-Scripts-GameSystem-UT-GetFriendInGamingTimeString0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGamingTimeString0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFriendInGamingByState0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SetUserPrivacyBits0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsAntiDisturbBits0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsAntiDisturbBits1;
	public const object Assets-Scripts-GameSystem-FriendReserve-GetIndex0;
	public const object Assets-Scripts-GameSystem-FriendReserve-RemoveReceiveReserveData0;
	public const object Assets-Scripts-GameSystem-CFriendModel-OnFriendReserveStateChange0;
	public const object Assets-Scripts-GameSystem-FriendInGame-Init0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SetFriendGameState0;
	public const object Assets-Scripts-GameSystem-CFriendModel-ContainTokenResultCode0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFindFriendList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFindFriendInfoAtIndex0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetFilterInfoAtIndex0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetInfoAtIndex0;
	public const object Assets-Scripts-GameSystem-CFriendModel-Add0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SortAllFriendList0;
	public const object Assets-Scripts-GameSystem-CFriendModel-DelayRefreshFriendGameState0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SetDelayRefreshFriendGameState0;
	public const object Assets-Scripts-GameSystem-CFriendModel-Remove0;
	public const object Assets-Scripts-GameSystem-CFriendModel-Remove1;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetInfo1;
	public const object Assets-Scripts-GameSystem-CFriendModel-Remove2;
	public const object Assets-Scripts-GameSystem-CFriendModel-Clear0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetInfo2;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsContain1;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetListByUISys0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetAllFriendByUISys0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetTempAllFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetTempAllFriendByName0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SortGameFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SortSNSFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetAllFriendsSorted0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsGameFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsSnsFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-getFriendByName0;
	public const object Assets-Scripts-GameSystem-CFriendModel-SetGameFriendGuildState0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-CheckHaveRelationFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-CheckHaveRelationFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-IsIntimacyFriend0;
	public const object Assets-Scripts-GameSystem-CFriendModel-GetChannelFriendByChannelID0;
	public const object Assets-Scripts-GameSystem-CFriendModel-EnableLbs0;
	public const object Assets-Scripts-GameSystem-CFriendCustomComparer-get_type0;
	public const object Assets-Scripts-GameSystem-CFriendCustomComparer-get_skip0;
	public const object Assets-Scripts-GameSystem-CFriendCustomComparer-Init0;
	public const object Assets-Scripts-GameSystem-CFriendCustomComparer-Reset0;
	public const object Assets-Scripts-GameSystem-CFriendCustomComparer-Compare0;
	public const object Assets-Scripts-GameSystem-CFriendCustomComparer-Compare1;
	public const object Assets-Scripts-GameSystem-CFriendComparer-IndexOf0;
	public const object Assets-Scripts-GameSystem-CFriendSort-GetFriendComparer0;
	public const object Assets-Scripts-GameSystem-CFriendComparer-AddSortType0;
	public const object Assets-Scripts-GameSystem-CFriendComparer-AddSortTypes0;
	public const object Assets-Scripts-GameSystem-CFriendComparer-AddRange0;
	public const object Assets-Scripts-GameSystem-CFriendComparer-AddRange1;
	public const object Assets-Scripts-GameSystem-CFriendComparer-Remove0;
	public const object Assets-Scripts-GameSystem-CFriendComparer-Clear0;
	public const object Assets-Scripts-GameSystem-CFriendComparer-Compare0;
	public const object Assets-Scripts-GameSystem-CFriendSort-AddComparer0;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSort0;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortByOnline0;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortMiniGame0;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortByGameState0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetValue1;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortByIntimacy0;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortByShowGrade0;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortByPvPLevel0;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortByVipLevel0;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortByLoginTime0;
	public const object Assets-Scripts-GameSystem-CFriendSNSChannelNickNameData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendSNSChannelNickNameData-Get1;
	public const object Assets-Scripts-GameSystem-CFriendSort-FriendDataSortByChannelNickName0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-OnSNSShareItemEnable0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-ShareSNSOnlyFriend0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-OnShareSNSOnlyFriend0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-OnShareSNSOnlyFriendConfirm0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-Clear0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-On_Friend_Close_SNSOnlyList0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-Refresh0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyShareView-Init0;
	public const object Assets-Scripts-GameSystem-CFriendView-OpenSNSOnlyListForm0;
	public const object Assets-Scripts-GameSystem-CFriendView-SNSOnlyInviteView-RefreshSlider0;
	public const object Assets-Scripts-GameSystem-FriendReserve-Assets.Scripts.GameSystem.IFriendReserve.get_dataList0;
	public const object Assets-Scripts-GameSystem-FriendReserve-Assets.Scripts.GameSystem.IFriendReserve.get_accept_receiveReserve0;
	public const object Assets-Scripts-GameSystem-FriendReserve-Assets.Scripts.GameSystem.IFriendReserve.get_accept_ReserveTime0;
	public const object Assets-Scripts-GameSystem-FriendReserve-Assets.Scripts.GameSystem.IFriendReserve.get_accept_ReserveTeamId0;
	public const object Assets-Scripts-GameSystem-FriendReserve-Assets.Scripts.GameSystem.IFriendReserve.get_accept_ReserveTeamSeq0;
	public const object Assets-Scripts-GameSystem-FriendReserve-CheckShowAcceptReceiveReserve0;
	public const object Assets-Scripts-GameSystem-FriendReserve-CheckShowAcceptReserveInvite0;
	public const object Assets-Scripts-GameSystem-FriendReserve-Find0;
	public const object Assets-Scripts-GameSystem-FriendReserve-IsReservable0;
	public const object Assets-Scripts-GameSystem-FriendReserve-AddReceiveReservieData0;
	public const object Assets-Scripts-GameSystem-FriendReserve-SetData0;
	public const object Assets-Scripts-GameSystem-FriendShower-ShowGameName0;
	public const object Assets-Scripts-GameSystem-FriendShower-ShowNickNameOrRemark0;
	public const object Assets-Scripts-GameSystem-FriendShower-ShowName0;
	public const object Assets-Scripts-GameSystem-MyFriendFormItem-OnButtonClicked0;
	public const object Assets-Scripts-GameSystem-MyFriendFormItem-InitFriendData0;
	public const object Assets-Scripts-GameSystem-MyFriendForm-OnGuildInviteFriendListItemEnabled0;
	public const object Assets-Scripts-GameSystem-MyFriendForm-On_GuildSys_Guild_Invite_Success0;
	public const object Assets-Scripts-GameSystem-MyFriendForm-OnEnable0;
	public const object Assets-Scripts-GameSystem-MyFriendForm-OnDisable0;
	public const object Assets-Scripts-GameSystem-CFriendAddFriendTime-Add0;
	public const object Assets-Scripts-GameSystem-CFriendAddFriendTime-Get0;
	public const object Assets-Scripts-GameSystem-CFriendAddFriendTime-Get1;
	public const object Assets-Scripts-GameSystem-CFriendChampionData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendChampionData-GetListCount0;
	public const object Assets-Scripts-GameSystem-CFriendChampionData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendChannelIDData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendChannelIDData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendChannelIDData-Get1;
	public const object Assets-Scripts-GameSystem-stFriendVerifyContent-get_dwLogicWorldID0;
	public const object Assets-Scripts-GameSystem-CFriendFiveCampELO-Add0;
	public const object Assets-Scripts-GameSystem-CFriendFiveCampELO-Get0;
	public const object Assets-Scripts-GameSystem-CFriendFiveCampELO-Get1;
	public const object Assets-Scripts-GameSystem-CFriendHeartData-get_SeniorThreshold0;
	public const object Assets-Scripts-GameSystem-CFriendHeartData-get_RefreshTimeOfDay0;
	public const object Assets-Scripts-GameSystem-CFriendHeartData-IsInCd0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-RequestRefreshFreindInfo0;
	public const object Assets-Scripts-GameSystem-CFriendHeartData-get_RemainSeniorTimes0;
	public const object Assets-Scripts-GameSystem-CFriendHeartData-set_RemainSeniorTimes0;
	public const object Assets-Scripts-GameSystem-CFriendHeartData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendHeartData-Add1;
	public const object Assets-Scripts-GameSystem-CFriendHeartData-IsInCd1;
	public const object Assets-Scripts-GameSystem-FriendInGame-get_dwLogicWorldID0;
	public const object Assets-Scripts-GameSystem-CFriendInGameData-Add1;
	public const object Assets-Scripts-GameSystem-IntimacyUpInfo-get_dwLogicWorldID0;
	public const object Assets-Scripts-GameSystem-CFriendRelationInfo-get_wIntimacyValue0;
	public const object Assets-Scripts-GameSystem-CFriendRelationInfo-get_IntimacyShowPrio0;
	public const object Assets-Scripts-GameSystem-CFriendRelationInfo-Equals0;
	public const object Assets-Scripts-GameSystem-CFriendRelationInfo-Equals1;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-get_IntimacyFull0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-get_TodayIntimacyFull0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-get_FreezeTime0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetState0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetState1;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-get_RefreshTimeOfDay0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-IsNeedReset0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetTodayValue0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetMax0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-IsFreeze0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-IsTodayFull0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-IsFull0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-IntimacyData-set_wIntimacyValue0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-get_RelationShowPriority0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-set_RelationShowPriority0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetCanCreateRelationFriendList0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetIntimacyInfoByState0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetAllRelationFriendList0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-IsInRelationReqState0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-SetIntimacyData0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetOriginCanCreateRelationFriendList0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-SortCFriendRelationInfoWithRecommends0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-SetRecommendFlag0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-ResetRecommendFlags0;
	public const object Assets-Scripts-GameSystem-CFriendIntimacyData-GetCanCreateRelationFriendListByRecommends0;
	public const object Assets-Scripts-GameSystem-CFriendListData-OnBeforeUpdateIndex0;
	public const object Assets-Scripts-GameSystem-CFriendListData-OnUpdateIndex0;
	public const object Assets-Scripts-GameSystem-CFriendListData-SortWith0;
	public const object Assets-Scripts-GameSystem-CFriendListData-SortWith1;
	public const object Assets-Scripts-GameSystem-CFriendListData-op_Implicit0;
	public const object Assets-Scripts-GameSystem-CSearchFriendListData-Clear0;
	public const object Assets-Scripts-GameSystem-CFriendMoTogameData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendMoTogameData-Get1;
	public const object Assets-Scripts-GameSystem-CFriendMoTogameData-GetListCount0;
	public const object Assets-Scripts-GameSystem-CFriendMoTogameData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendMusicParkourData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendMusicParkourData-Get1;
	public const object Assets-Scripts-GameSystem-CFriendMusicParkourData-GetListCount0;
	public const object Assets-Scripts-GameSystem-CFriendMusicParkourData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendNicknameData-Append0;
	public const object Assets-Scripts-GameSystem-CFriendNicknameData-Append1;
	public const object Assets-Scripts-GameSystem-CFriendNicknameData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendReCallData-get_RecallCD0;
	public const object Assets-Scripts-GameSystem-CFriendReCallData-Add1;
	public const object Assets-Scripts-GameSystem-CFriendReCallData-Add2;
	public const object Assets-Scripts-GameSystem-CFriendReCallData-IsLost0;
	public const object Assets-Scripts-GameSystem-CFriendReCallData-IsInCd0;
	public const object Assets-Scripts-GameSystem-CFriendReCallData-GetPlatformId0;
	public const object Assets-Scripts-GameSystem-CFriendRemarkData-Append0;
	public const object Assets-Scripts-GameSystem-CFriendRemarkData-Append1;
	public const object Assets-Scripts-GameSystem-CFriendRemarkData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendSNSChannelNickNameData-GetListCount0;
	public const object Assets-Scripts-GameSystem-CFriendSNSChannelNickNameData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendTeamStateData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendTeamStateData-Get1;
	public const object Assets-Scripts-GameSystem-CFriendTeamStateData-GetListCount0;
	public const object Assets-Scripts-GameSystem-CFriendTeamStateData-Add0;
	public const object Assets-Scripts-GameSystem-UT-Bytes2String1;
	public const object Assets-Scripts-GameSystem-UT-SetChatFace0;
	public const object Assets-Scripts-GameSystem-UT-Check_AddHeartCD0;
	public const object Assets-Scripts-GameSystem-UT-SetHttpImage1;
	public const object Assets-Scripts-GameSystem-UT-SetHeadFrame0;
	public const object Assets-Scripts-GameSystem-UT-ShowRank1;
	public const object Assets-Scripts-GameSystem-UT-ShowSend0;
	public const object Assets-Scripts-GameSystem-UT-ShowGender0;
	public const object Assets-Scripts-GameSystem-UT-PlayerNameOrRemarkOrNicky3;
	public const object Assets-Scripts-GameSystem-CFriendWinRateData-Add0;
	public const object Assets-Scripts-GameSystem-CFriendWinRateData-Get0;
	public const object Assets-Scripts-GameSystem-CFriendWinRateData-Get1;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Upload_Sns_InGameFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Upload_Sns_InGameFriend1;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Sns_Invite_Friend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_Sns_Invite_Friend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_Sns_Have_Invited_List0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_Sns_Invite_Num_NTF0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-IsIntimateFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-SendFriendOnlineData0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-SolveFriendFirebasePush0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Friend_Info0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Request_RecommandFriend_List0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Request_FindFriend_List0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Requeset_MyPendingFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Friend_Request_Info0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_Send_FriendCoin0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-OnRefreshFreindInfoResponse0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Serch_Player0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Request_BeFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Request_BeFriend1;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_BeFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_FakeBeFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Confrim_BeFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Confrim_BeFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_DENY_BeFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_DENY_BeFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Friend_RequestInfo0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Friend_Recommand_Info0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_NTF_FRIEND_ADD0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCID_CMD_NTF_FRIEND_GAME_STATE0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-OnSCID_CMD_NTF_FRIEND_LOGIN_STATUS0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-AddPvpHistoryCachedFriendSearchResult0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Serch_Player0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-SetSnsFriendList0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCID_NTF_SNS_FRIEND0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCID_UPLOAD_MULTI_SNS_PLATFORM_INFO_RSP0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCID_SNS_FRIEND_CHG_PROFILE0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Del_Friend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Del_Friend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Invite_Friend_Game0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Invite_Friend_Game0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_NTF_FRIEND_DEL0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_NTF_FRIEND_REQUEST0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-ReCallSnsFriend0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCID_SNS_FRIEND_RECALLPOINT0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCID_SNS_FRIEND_RECALL_NTF0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-OnRecallRewardResponse0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_Sns_Switch_Rep0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_Sns_Switch_Ntf0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCPKG_CMD_NTF_CHG_INTIMACY0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCPKG_CMD_BLACKLIST0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Block0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCPKG_CMD_DEFRIEND0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Cancle_Block0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCPKG_CMD_CANCEL_DEFRIEND0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SC_Search_LBS_Rsp0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-OnReserveAcntRsp0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-OnReserveAcntNtf0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-OnReserveOperRsp0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-NeedOpenReserveBox0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-OnReserveOperNtf0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-OnFriendMatchUpdate0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCPKG_ADD_MATCH_BLACKLIST_RSP0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-Send_Cancel_MatchBlack0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCPKG_DEL_MATCH_BLACKLIST_RSP0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-On_SCPKG_MATCH_BLACKLIST_GET_RSP0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-ResGetIntimacyShowDetailInfo0;
	public const object Assets-Scripts-GameSystem-FriendSysNetCore-SendFriendsState0;
	public const object Assets-Scripts-GameSystem-GPSSys-get_bHide0;
	public const object Assets-Scripts-GameSystem-CGuildSystem-GetGuildWeekAwardNestGift0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-OnOpenFoem0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-Init0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-UnInit0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadFinished0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-ResCore.DLC.DLCDownloaderDelegate.OnDLCDownloadStart0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-ResCore.DLC.DLCDownloaderDelegate.OnDownloadCanceled0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-ResCore.DLC.DLCDownloaderDelegate.OnDownloadError0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-ResCore.DLC.DLCDownloaderDelegate.OnFileDownloadFinished0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-ResCore.DLC.DLCDownloaderDelegate.OnDownloadProgress0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-ResCore.DLC.DLCDownloaderDelegate.OnDownlodingCountChanged0;
	public const object Assets-Scripts-GameSystem-CLanChangeSys-ResCore.DLC.DLCDownloaderDelegate.OnDownloadPause0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_IsReaded0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_ReportEndTimeString0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_ReportStartTimeString0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_ReportTimeString0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_LadderGameCnt0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_StarChangeCnt0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_GrowHeroList0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_AscendData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_AdversityData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_SlaughterData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_PracticeData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_StableData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_LeisureData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-get_ReportThemeNameString0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportBaseData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportThemeBaseData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-CreateThemeDataFactory0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-ConverSvrData2CliData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportData-ConverSvrHeroData2CliHeroData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportSlaughterData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportWonderfulGameData-get_MVPScoreString0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportWonderfulGameData-get_IsValid0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportWonderfulGameData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportFriendData-get_WinRate0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportFriendData-get_LostCnt0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportFriendData-get_MVPScoreAVGString0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportFriendData-get_IsValid0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportFriendData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportFriendData-ConverSvrData2CliData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportAscendingThemeData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportStableThemeData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportParcticeThemeData-get_GameCnt0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportParcticeThemeData-get_WinRate0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportParcticeThemeData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportSlaughterThemeData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportHeroCommonData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportAdversityThemeData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportAscendingThemeData-ConverSvrData2CliData0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportHeroCommonData-get_IsValid0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportHeroCommonData-get_HeroItem0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportHeroCommonData-get_CricleIconPath0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportHeroGrowData-get_TitleCode0;
	public const object Assets-Scripts-GameSystem-CLegendWeeklyReportBaseData-ConverSvrData2CliData0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_HeroData0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_TitleCnt0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_SkinID0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_Valid0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendUnusedTitle0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SwitchLegendTitleFlagToCfg0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleHeroComp0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-ParseCityIndex0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-ParseProvinceIndex0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-ParseCountryIndex0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-FindRegionConfigData0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-FindRegionConfigDataSingle0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleAreaType0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleAreaCompNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleNew0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_mLegendTitle0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SwitchMedalTypeToIndex0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_mMedalType0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-ParseRegionIndex0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_mReginIndex0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_mCountryIndex0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_mProvinceIndex0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-get_mCityIndex0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-UpdateData0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-UpdateData1;
	public const object Assets-Scripts-GameSystem-CLegendHeroTitleData-IsSameLegendTitle0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-CalcAreaCode0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTopTitleData-get_mTitleCode0;
	public const object Assets-Scripts-GameSystem-CLegendHeroTopTitleData-get_mMedalType0;
	public const object Assets-Scripts-GameSystem-CLegendRegionInfo-Clear0;
	public const object Assets-Scripts-GameSystem-CLegendRegionInfo-get_TopRequestHeroId0;
	public const object Assets-Scripts-GameSystem-CLegendRegionInfo-set_TopRequestHeroId0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetUserRegionInfo0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetNearRegionInfo0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SortByMedalRankingCS10;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SortByMedalRankingCS20;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetUsedLegendTitleData0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendHeroTitleData0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleMedalType0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleMedalType0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleBannerPath0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleBannerPath0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleIconPath0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleIconPath0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleBgPath0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleBgPath0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleAreaComp0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleAreaComp0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleGISHideText0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitle0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleText0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SetLegendTitleText0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleTextNew0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SetLegendTitleTextNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleTextNew0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleTextNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleRankingText0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SetLegendTitleRankingText0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleMedalImage0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleMedalImage0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleMedalImage1;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SetLegendTitleMedalImage0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleMedalImageNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleMedalImageNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleMedalImageNew1;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SetLegendTitleMedalImageNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleGeographicalInfoWithRank0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleGeographicalInfoWithRank0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleCntText0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleComplete0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SetLegendTitleComplete0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleCompleteNew0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-SetLegendTitleCompleteNew0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleIconMedalTypeNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleBannerPathNew0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleBannerPathNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleIconPathNew0;
	public const object Assets-Scripts-GameSystem-CLegendMgr-GetLegendTitleIconPathNew0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-get_PLAYER_PREF_KEY_GET_LEGEND_WEEK_REPORT_KEY0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-get_PLAYER_PREF_KEY_VISIT_NEW_TITLE_KEY0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-get_PLAYER_PREF_KEY_SETTLE_LEGEND_TITLE_KEY0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetCountryAndCityName0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetAllRegionName0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetRegionName0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetCountryOrProvName0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetCountryName0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetProvName0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetCityName0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-FindRegionConfigDataSingleLua0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-IsRegionDataMatch0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetRegionDataByCheck0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-GetLegendTitleMedalImageNew1;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SwitchMedalTypeToIndex1;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SwitchIndexToMedalType0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-SetLegendTitleMedalImageNewIsValid0;
	public const object Assets-Scripts-GameSystem-CLegendUtility-isLegendTop0;
	public const object Assets-Scripts-GameSystem-CLuckDrawHandler-GetProductTagIconPath0;
	public const object Assets-Scripts-GameSystem-CLuckDrawHandler-AddTag0;
	public const object Assets-Scripts-GameSystem-CLuckDrawHandler-AddTagNew0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGotoBoutique0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMalOpenHeroTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallOpenFactoryShopTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallOpenDiamondsShopTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGotoSymbolTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGotoSkinTab0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-HasRoulette0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGoToTreasureTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGoToComponentLotteryTab0;
	public const object Assets-Scripts-GameSystem-CMallSystem-set_CurTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-ToMallDebrisExchange0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGoToRecommendHeroTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGoToRecommendSkinTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGoToRecommendRouletteTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnUIEvent_Mall_Goto_Activity_GGL0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnUIEvent_Mall_Goto_Component0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-OnMallGoToVipShopTab0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-Init0;
	public const object Assets-Scripts-GameSystem-CMallGoToTabHandler-UnInit0;
	public const object Assets-Scripts-GameSystem-CMallItemList-UpdateElement0;
	public const object Assets-Scripts-GameSystem-CMallItemList-ShowItemListPrice0;
	public const object Assets-Scripts-GameSystem-CMallItemList-ShowItemListAndPrice0;
	public const object Assets-Scripts-GameSystem-CMallItemList-RefreshPrice0;
	public const object Assets-Scripts-GameSystem-CMallLayoutElement-Initialize0;
	public const object Assets-Scripts-GameSystem-CMallLayoutGroup-ResetLayout0;
	public const object Assets-Scripts-GameSystem-CMallLayoutGroup-ResetElementAmount0;
	public const object Assets-Scripts-GameSystem-CMallLayoutElement-OnEnable0;
	public const object Assets-Scripts-GameSystem-CMallLayoutElement-OnDisable0;
	public const object Assets-Scripts-GameSystem-CMallLayoutGroup-Initialize0;
	public const object Assets-Scripts-GameSystem-CMallLayoutGroup-ResetHaveIconAndTextLayout0;
	public const object Assets-Scripts-GameSystem-CMallLayoutGroup-GetElemenet0;
	public const object Assets-Scripts-GameSystem-CMallLayoutGroup-SetElementAmount0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-SetSkinBuyPricePanel0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPayInfoSetOfGood3;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPayInfoSetOfGood4;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPayTypeText0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetPriceTypeBuyString0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-SetPayButton0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-SetPayButton1;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-TryToPaydirect0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-PayTypeToResBuyCoinType0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetShopPromotion0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetItemRealPrice0;
	public const object Assets-Scripts-GameSystem-CMallPriceHandler-GetCoinTypeIconPath0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-Init0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-UnInit0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-GetSortTypeName0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-ConvertToHeroSortType0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-GetCurSortType0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-IsDesc0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-SetSortType0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-CompareDefault0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-CompareCoin0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-CompareCoupons0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-CompareReleaseTime0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-CompareName0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-GetDiscountFactor0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-CompareDiscount0;
	public const object Assets-Scripts-GameSystem-HeroSortImp-Compare0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-Init0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-UnInit0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-GetSortTypeName0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-GetCurSortType0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-IsDesc0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-SetIsDesc0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-SetSortType0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-CompareDefault0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-CompareCoupons0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-CompareReleaseTime0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-CompareName0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-GetDiscountFactor0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-CompareDiscount0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-Compare0;
	public const object Assets-Scripts-GameSystem-SkinSortImp-GetHeroSkinConfigList0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-Init0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-UnInit0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-GetSortTypeName0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-GetCurSortType0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-IsDesc0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-SetSortType0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-SetDesc0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-CompareDefault0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-CompareProficiency0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-CompareCultivateStage0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-CompareCultivateStageForHeroSelect0;
	public const object Assets-Scripts-GameSystem-HeroCultivateSortImp-Compare0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-Init0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-UnInit0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-GetSortTypeName0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-GetCurSortType0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-IsDesc0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-SetSortType0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-SetDesc0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareDefault0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareReleaseTime0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareProficiency0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareLegendNum0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareAffinity0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareUseNum0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareHistoryUseNum0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareHistoryBanNum0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-CompareName0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImpBase-Compare0;
	public const object Assets-Scripts-GameSystem-HeroViewSortImp-GetInstance0;
	public const object Assets-Scripts-GameSystem-HeroSelectSortImp-GetInstance0;
	public const object Assets-Scripts-GameSystem-HeroSelectSortImp-CompareProficiency0;
	public const object Assets-Scripts-GameSystem-CMallSortHelper-CreateHeroSorter0;
	public const object Assets-Scripts-GameSystem-CMallSortHelper-CreateSkinSorter0;
	public const object Assets-Scripts-GameSystem-CMallSortHelper-CreateHeroViewSorter0;
	public const object Assets-Scripts-GameSystem-CMallSortHelper-CreateHeroCultivateSorter0;
	public const object Assets-Scripts-GameSystem-CMallSortHelper-CreateHeroSelectSorter0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-Init0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-Clear0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-UnInit0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-Load0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-Loaded0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-get_CMallSystem0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-BuyShopProduct0;
	public const object Assets-Scripts-GameSystem-CMallComponentModel-CheckGuest0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnReflowNewbieShopBuyHeroSkin0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-StartShopProduct0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-ShopProductWidget-Validate0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-ShopProductWidget-OnProductStateChange0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-ShopProductWidget-Refresh0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-onMall_SpecSale_Item_Enable_EX0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-onMall_SpecSale_Item_Enable0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-OnClickBuy0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-MallCloseOrTabChange0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-Close0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-get_TotalSpList0;
	public const object Assets-Scripts-GameSystem-CMallSystem-get_CurTab0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-FilterCurrProduct0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-InitShopData0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-SortProducts0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-ResetData0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-Draw0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-ShouldNotify0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-ShouldNotify1;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-OnSelectedItemChanged0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-Open0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-ShopProductWidget-Awake0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-ShopProductWidget-OnDestroy0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleBase-SpecSaleProductWidget-Validate0;
	public const object Assets-Scripts-GameSystem-CMallTagHelper-OpenPopup0;
	public const object Assets-Scripts-GameSystem-CMallTagHelper-ClosePopup0;
	public const object Assets-Scripts-GameSystem-CMallTagHelper-OnEnable0;
	public const object Assets-Scripts-GameSystem-CMallTagHelper-OnDisable0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-Init0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-UnInit0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-OnCloseMallForm0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-ShouldShowRedDotForTab0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-ShouldShowReddotForMall0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-CoDelayDispathBuddle0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-OnQureyBtnClicked0;
	public const object Assets-Scripts-GameSystem-CMallTopCommon-TabToRedID0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-CheckSendGiftCurrencyEnough_ShowMessageBoxIfNotEnough0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-GetSendGiftPayTip0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-HostIntimacyFull0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-HostToDayIntimacyFull0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-GetGiftResultText0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-IsGameFriends0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-ShowGiftSendResult0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-SendGiftSuccess0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-GetSendGiftMinLevel0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-GetAskForGiftMinLevel0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-GetGiftMinFriendDay0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-CanSendGift0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-IsGiftCenterHeroTabOpened0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-IsGiftCenterHeroSkinTabOpened0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-IsGiftCenterItemTabOpened0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-GetMaxSendGiftCountPerDay0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-GetMaxAskForGiftCountPerDay0;
	public const object Assets-Scripts-GameSystem-CMallGiftSystem-GetGiftCenterMinLevel0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-get_SelectedHero0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-OnUIEvent_Mall_Component_Exchange_Job_Change0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-OnUIEvent_Mall_Component_Exchange_Hero_List_Enable0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-InitJobTabs0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-SetBigHeroListVisible0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-OnUIEvent_Mall_Component_Exchange_Hero_Select_Change0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-OnEnable0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-OnDisable0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-Start0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-SetToShowHeroes0;
	public const object Assets-Scripts-GameSystem-CMallHeroSelect-Deselect0;
	public const object Assets-Scripts-GameSystem-CMallUtil-OpenHeroSkinPreview0;
	public const object Assets-Scripts-GameSystem-CMallSystem-get_PayPurposeNameKeys0;
	public const object Assets-Scripts-GameSystem-CMallSystem-get_PayTypeNameKeys0;
	public const object Assets-Scripts-GameSystem-CMallSystem-set_PlayerRegisterTime0;
	public const object Assets-Scripts-GameSystem-CMallSystem-get_SpecSaleSystem0;
	public const object Assets-Scripts-GameSystem-CMallSystem-get_PriceSystem0;
	public const object Assets-Scripts-GameSystem-CMallSystem-get_MallTopCommon0;
	public const object Assets-Scripts-GameSystem-CMallSystem-AllTabInit0;
	public const object Assets-Scripts-GameSystem-CMallSystem-AllTabUnInit0;
	public const object Assets-Scripts-GameSystem-CMallSystem-OnMallCloseForm0;
	public const object Assets-Scripts-GameSystem-CMallSystem-OnMallActionMaskReset0;
	public const object Assets-Scripts-GameSystem-CMallSystem-OnMallSkipMaskReset0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-RequestBuy0;
	public const object Assets-Scripts-GameSystem-CMallSystem-OnConfirmBuyProduct0;
	public const object Assets-Scripts-GameSystem-CMallSystem-OnExpGiftGotoExp0;
	public const object Assets-Scripts-GameSystem-CMallSystem-OnUIEvent_Mall_Confirm_Buy_Item0;
	public const object Assets-Scripts-GameSystem-CMallSystem-SymbolFreeDrawTimerHandler0;
	public const object Assets-Scripts-GameSystem-CMallSystem-SetFreeDrawTimer0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ResetSaleOffSpListByStatus0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ResetProductByStatus0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnTimerRefreshTotalProductData0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-RefreshTotalProductData0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnValorPassStateChanged0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnSpecalSaleConfigReady0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ResetLimitBuyDaily0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-UnInit0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-Init0;
	public const object Assets-Scripts-GameSystem-CMallSystem-Init0;
	public const object Assets-Scripts-GameSystem-CMallSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CMallSystem-InitExchangeData0;
	public const object Assets-Scripts-GameSystem-CMallSystem-IsShowLv3Symbol0;
	public const object Assets-Scripts-GameSystem-CMallSystem-Send_Request_SymbolBuyByCoin0;
	public const object Assets-Scripts-GameSystem-CMallSystem-CanSendGift0;
	public const object Assets-Scripts-GameSystem-CMallSystem-GetRecommendData0;
	public const object Assets-Scripts-GameSystem-CMallSystem-CreateHeroSorter0;
	public const object Assets-Scripts-GameSystem-CMallSystem-CreateSkinSorter0;
	public const object Assets-Scripts-GameSystem-CMallSystem-CreateHeroViewSorter0;
	public const object Assets-Scripts-GameSystem-CMallSystem-CreateHeroCultivateSorter0;
	public const object Assets-Scripts-GameSystem-CMallSystem-ShouldShowReddotForMall0;
	public const object Assets-Scripts-GameSystem-CMallSystem-InvalidateCacheByCMallBoutiqueModel0;
	public const object Assets-Scripts-GameSystem-ResSaleRecommendExt-IsForSale0;
	public const object Assets-Scripts-GameSystem-ResCrystalExchangeExt-IsForSale0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ClearData0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnProductBuy0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetShopProductByType0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetShopProductByTypeIncludeSaleLimit0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetShopProductByIds0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetShopProductByMallTabType0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetProductByItemID1;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-GetSaleIffSpByID0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-BuyLimitProduct0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnBuyReturn0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-UpdateInfo0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnInitialSpecSaleInfo0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnRecv_SCID_CMD_DIRECT_PAY0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-OnBuySpecSaleRsp0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_config0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-set_config0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_configItemDiscount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-set_configItemDiscount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_Type0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_ID0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_IsExpGift0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_CoinType0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_RealDiscount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_HasDiscount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetExpGiftUseableList0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetItemDiscounts0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetUseableList0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetUseable0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-RouletteHasDiscount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-ConvertWithRealDiscount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-SConvertWithRealDiscount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetPriceInfo0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetPrice0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_Key0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetPriceText0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetOldPrice0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetOldPriceText0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_ProductType0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_DoubleKey0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_ShowInMallList0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-GetSpecSaleIconPath0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_DiscountForShow0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_BoughtCount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-set_BoughtCount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_LimitCount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_CanBuyCount0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_LimitCycle0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_RecommendIndex0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_IsShowLimitBuy0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_Tag0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_OnSaleTime0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_OnSaleDate0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_OffSaleTime0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_OffSaleDate0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_LimitBuyDays0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_LimitBuySeconds0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_IsOnSale0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_IsVipCanBuy0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_MinShowVIPLevel0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_StartVIPLvl0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_EndVIPLvl0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-get_CycleType0;
	public const object Assets-Scripts-GameSystem-CMallSpecSaleController-ShopProduct-CanBuy0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-LoadMoWenTable0;
	public const object Assets-Scripts-GameSystem-CMoWenSystem-Init0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-GetMoWenSkillSeries0;
	public const object Assets-Scripts-GameSystem-CMoWenSystem-GetMoWenSkillSeries0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-FindName0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-GetPrimeSmallBgLobbyPath_s0;
	public const object Assets-Scripts-GameSystem-CMoWenSystem-GetPrimeSmallBgLobbyPath_s0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-GetMoWenSkillCfg0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-GetMoWenIconBattlePath_s0;
	public const object Assets-Scripts-GameSystem-CMoWenSystem-GetMoWenIconBattlePath_s0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-GetSeriesIconBattlePath_s0;
	public const object Assets-Scripts-GameSystem-CMoWenSystem-GetSeriesIconBattlePath_s0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-GetViceSmallBgLobbyPath_s0;
	public const object Assets-Scripts-GameSystem-CMoWenSystem-GetViceSmallBgLobbyPath_s0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-IsMoWenSysEnabledForCurLevel0;
	public const object Assets-Scripts-GameSystem-CMoWenSystem-IsMoWenSysEnabledForCurLevel0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-GetSeriesColor_s0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-GetSeriesName_s0;
	public const object Assets-Scripts-GameSystem-CMoWenDataCenter-IsMoWenForbidden0;
	public const object Assets-Scripts-GameSystem-CMoWenView_AssembledItem-Reset0;
	public const object Assets-Scripts-GameSystem-CMoWenView_AssembledItem-Show0;
	public const object Assets-Scripts-GameSystem-CMoWenView_SkillDesc-Show0;
	public const object Assets-Scripts-GameSystem-CMoWenView_SkillDesc-Hide0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetMostUsedHeroList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetHasNewFightRecord0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ShowPlayerDetailInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IsInNewbieGuide0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IsNewbieGuideCompleteFinish0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-get_InviteCode0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-StartBattle0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_OpenInviteCode0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ProcessInviteCodeIntent0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-CheckInviteCode0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ImpResDetailInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ResPlyaerDetailInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnShareHeroNty0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-isSelf0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ResMostHeroShare0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-MsgUpdateFriendCard0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePlayerInfoPrivacy0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-get_InfoPageMode0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-get_mForm0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OpenPvpInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoOpenPvpInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OpenBaseInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoOpenBaseInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoQuitGame0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoQuitGameConfirm0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetHeroItemData0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoMostUsedHeroItemEnable0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoMostUsedHeroItemClick0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetLadderCreditScore0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetPVPCreditScore0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoShowRule0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnCommonHeroItemEnable0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnRankHeroClick0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoHideVisitingCardClick0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_GetPos0IDFromSelectIndex0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_GetPos1IDFromSelectIndex0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoEditeOKVisitingCardClick0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnSelectedRegion0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoEditeVisitingCardRegionClick0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoEditePlaceIDClick0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoHideVisitingCardComformClick0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoHideVisitingCardPos1Press0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoHideVisitingCardPos2Press0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoHideVisitingCardWeekdayPress0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoHideVisitingCardDaytimePress0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_GetPos1StrList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_GetPos1SelectIndexFromID0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoHideVisitingCardPos1Select0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_GetPos0StrList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_GetPos0SelectIndexFromID0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoHideVisitingCardPos2Select0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoShareHeroTip0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoCardAddFriend0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerInfoPunishRecordListSelect0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnDetailBrandClick0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetProfile0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IsNeedHideGameInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-CopyPlayerHistoryData0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnChangeMomentSubIndex0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnChangeMomentDetailInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetPlayerRandomTalentList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnTestGetPlayerRandomTalentList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OpenByQQVIP0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePlayerData0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnRemarkChange0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdateHead0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-reloadTexts0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnPlayerLegendShareFormClose0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnRegionDataUpdate0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnUsedLegendTitleUpdate0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_CreateGenderInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnShowLegendTitlePanelFromBasic0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-Init0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UnInit0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-CloseForm0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetMode0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetGenderInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetSeasonFunc0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetBattleModeFunc0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SeasonToStr0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-BattleModeToStr0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnCommonHeroShowDesc0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IsNeedHideMostUsedHeros0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-get_OpenVistingCard0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-get_mTitleList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IPlayerSystem.get_m_lstProfession0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IPlayerSystem.get_m_lstWeekDay0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IPlayerSystem.get_m_lstDayTime0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetLegendValue0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetLegendValue_Lua0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-COMGameType2Index0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-COMGameType2Index1;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetWinRate0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetWinRate_Lua0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetCurrentShowIsSelf0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IsTabRedDotNeed0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-HasHeadFlag0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdateMostHeroList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ChangeLegendGISStateNetReq0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IsNeedHideLegendTitleGIS0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ToRoman0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OpenGameLegendTitle0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_UpdateTitleInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetPos0IgnID0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetPos1IgnID0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-MsgUpdateGender0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SendChangeGender0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-HomePageAccuse0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-RspHomePageAccuse0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-OnGoToPersonalProfile0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-_SetPvpRankInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdateMiniRaceFightInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvPTinyArenaFightInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvPBianShenFightInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvPBianShenPlusFightInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvPRaceFightInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvPCloneFightInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvPFootballInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvp10v10Info0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvPFiveCampInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetAchievementCount0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-UpdatePvPAchievement0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ReportPvpInfoScrollEvent0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetPvpInfoSrollEvent0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetMasterPvPDataWhenGameSettle0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-CheckAndSendRelationDetailReq0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ResGetIntimacyShowDetailInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IsBehaviourScoreOpen0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-IsBehaviourScoreShowOpen0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetPlayerEquipList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetPlayerEquipListNormal0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetNationForCamp0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetPlayerRecordOperation0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-RemovePlayerRecordOperation0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetCroleInfoByIndex0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetCroleInfo0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ClearCroleInfoList0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-RemoveCroleInfoLastOne0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GetReturnPlayerProfile0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-SetReturnPlayerProfile0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ClearReturnPlayerProfile0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-ReqSendNotAsianHistory0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-StarCoroutineReqSendNotAsianHistory0;
	public const object Assets-Scripts-GameSystem-CPlayerInfoSystems-GenderInfo-get_IconResPath0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuel-UnInitUI0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuel-Close0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuel-OnCloseForm0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuel-InitUI0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuel-Open0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuelControl-OpenView0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuelControl-OnLightDarkDuelOpen0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuelControl-Init0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuelControl-UnInit0;
	public const object Assets-Scripts-GameSystem-CLightDarkDuelControl-CloseView0;
	public const object Assets-Scripts-GameSystem-CMainCityView-IsIMBAModeEnable0;
	public const object Assets-Scripts-GameSystem-CMainCityView-OnCultivateEntryClick0;
	public const object Assets-Scripts-GameSystem-CMainCityView-IsPlentyModeEnable0;
	public const object Assets-Scripts-GameSystem-CMainCityView-OnPlayClick0;
	public const object Assets-Scripts-GameSystem-CMainCityView-ShowGuide0;
	public const object Assets-Scripts-GameSystem-CMainCityView-OnHelpClick0;
	public const object Assets-Scripts-GameSystem-CMainCityControl-SendGuideRewardReq0;
	public const object Assets-Scripts-GameSystem-CMainCityView-OnIntroduceFinished0;
	public const object Assets-Scripts-GameSystem-CMainCityView-OnTaskRedPoint0;
	public const object Assets-Scripts-GameSystem-CMainCityView-OnBagRedDotUpdate0;
	public const object Assets-Scripts-GameSystem-CMainCityView-UnInitUI0;
	public const object Assets-Scripts-GameSystem-CMainCityView-Close0;
	public const object Assets-Scripts-GameSystem-CMainCityView-OnCloseForm0;
	public const object Assets-Scripts-GameSystem-CMainCityView-InitOpenBagEventParam0;
	public const object Assets-Scripts-GameSystem-CMainCityView-SetButtonTimeEnableStatus0;
	public const object Assets-Scripts-GameSystem-CMainCityView-RefreshStartButton0;
	public const object Assets-Scripts-GameSystem-CMainCityView-RefreshBgStatus0;
	public const object Assets-Scripts-GameSystem-CMainCityView-InitWidgetStatus0;
	public const object Assets-Scripts-GameSystem-CMainCityView-InitUI0;
	public const object Assets-Scripts-GameSystem-CMainCityView-InitRedDot0;
	public const object Assets-Scripts-GameSystem-CMainCityView-Open0;
	public const object Assets-Scripts-GameSystem-CMainCityControl-OpenView0;
	public const object Assets-Scripts-GameSystem-CMainCityControl-OnCultivateMainCityOpen0;
	public const object Assets-Scripts-GameSystem-CMainCityControl-Init0;
	public const object Assets-Scripts-GameSystem-CMainCityControl-UnInit0;
	public const object Assets-Scripts-GameSystem-CMainCityControl-CloseView0;
	public const object Assets-Scripts-GameSystem-CMainCityControl-OnGuideRewardRsp0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateDetailView-InitSkillList0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateDetailView-OnOpenForm0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateDetailView-OnCloseForm0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateDetailView-Init0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateDetailView-UnInit0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-ShowCdnHeroPic0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-GetExpNeed0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-GetNeedToSelectSkillIndex0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-InitLevelNumObj0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-SetControlStatus0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-InitSelectStatus0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-UpdateSkillDetail0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-InitTitleLvInfo0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-GetStarCoinNeed0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-InitUpgradeBtn0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-UpdatePanel0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-OpenForm0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-OnCloseForm0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-SetIconStatus0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-ShowExpAddEffect0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-SetProgressInGo0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-SetTextInGo0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-ExpAnimUpdate0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-ExpAnimComplete0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-OnSkillItemEnable0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-SendHeroCultivateReq0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-OnUpgrade0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-SetSelectStatus0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-OnSkillItemClick0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-OnShowDetail0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-OnTryPlay0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnTrainingPlentyHero0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-OnTryPlayComfirm0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-Init0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-UnInit0;
	public const object Assets-Scripts-GameSystem-CHeroCultivatePageView-SetAfterUpgradeExp0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-get_curretSeletHeroType0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-RefreshHeroListOpenStatus0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-SortHeroList0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-FilterHeroData0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-ResetHeroListData0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnOpenHeroCultivateForm0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnHeroCultivate_CloseForm0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnHeroCultivateHelp0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-SetPveHeroItemData0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnHeroCultivate_ItemEnable0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnHeroCultivate_ItemClick0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnHeroCultivate_MenuSelect0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnCloseHeroCultivatePageForm0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnNtyAddHero0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-Init0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-RefreshHeroListElement0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-IsHeroCanCultivate0;
	public const object Assets-Scripts-GameSystem-CHeroCultivateSystem-OnHeroCultivateRep0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-OnEvtFormClosed0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-GetItem0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftSystem-GetDelayDrawConfig0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-GetDelayDrawGiftConfig0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-RefreshRewardItemSelectState0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-RefreshRewardStates0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-RefreshTopTips0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-OnEvtSelectRewardItem0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftSystem-ExchangeGift0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-OnEvtExchange0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-OnHeroKillUpgradeUseRsp0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-Init0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-UnInit0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-GetForm0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-RefreshRewardItem0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-Refresh0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftCtrl-OpenForm0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftSystem-OnEvtOpenGift0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftSystem-Init0;
	public const object Assets-Scripts-GameSystem-CHeroSkillUpgradeGiftSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-OnEvtCultivateTaskViewClose0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-OnTaskItemClicked0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-OnTaskKillCntClicked0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-SortDataState0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-SortGameCntTask0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-ProcessServerData0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-GetWeekCreditBuf0;
	public const object Assets-Scripts-GameSystem-CTaskSys-show_task_award1;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-UpdateTaskList0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-UpdateTimer0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-CalculateCompletedGameCount0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-UpdateKillCount0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-UpdateCreditScore0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-RefreshPanel0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-OnTaskUpdate0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-OnWeekStarCoinCntUpdate0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-OnTaskTimeRefreshed0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-Init0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-UnInit0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-OpenForm0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskFormCtrl-GetForm0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskSystem-OnEvtOpenTaskView0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskSystem-Init0;
	public const object Assets-Scripts-GameSystem-CPlentyTaskSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-Reset0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-Init0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-UnInit0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-AddRecordEvent0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-OnHighLightNotify0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-UpdateRecordEvent0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-OnKillNotify0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-DoFightOver0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-HasMultiKill0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-HaveHonourMomentData0;
	public const object Assets-Scripts-GameSystem-RecordEffectTime-GetEffectTimeByType0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-GetAssistCountWithTime0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-InsertAssistInfo0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-ChooseTopEvent0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-ConvertMaxMultiKillPriorityToResDef0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-OnBeginRecord0;
	public const object Assets-Scripts-GameSystem-CRecordEventChooser-GetLastEventTime0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_IsCheatRecordMomentEnable0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_honourMomentState0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_m_uiMinSpaceLimit0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_m_uiFreeRecorderMinSpaceLimit0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetJsonValueObject0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyVideoShareSource0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyVideoDuration0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyVideoType0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetJsonValueString0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadySvrVideoUrl0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyH5ShowUrl0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyVideoForGuildUrl0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyVideoTitle0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyVideoThumbnaiUrl0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyLocalVideoUrl0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetJsonValueDict0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_ReadyVideoExtraInfo0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetVideoExtraInfoData0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetJsonValueLong0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ParseVideoNameWithoutExtension0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CombinationH5Link0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-Reset0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-BundleLanguage2GameJoyLocale0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_Enable0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetRecorderGlobalCfgEnableFlag0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_IsRecordingMoments0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnFightPrepare0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnGameJoyStartRecordResult0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnGameJoyStopMomentRecordResult0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ShowFreeRecorderView0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnLobbyFormShow0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnLobbyFormOpen0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CloseFreeRecordView0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnLoadingFormOpen0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnLoadingFormClose0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnLanguageChanged0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-StopMomentsRecording0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CallGameJoyGenerateWithNothing0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnBadGameEnd0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OpenSdkVideoManagerForm0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnVideoManagerFormOpen0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnVideoShareFormClose0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CloseSdkVideoManagerForm0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetShareVideoForm0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ParsePlatform0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetSupportSharePlatformList0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ResetVideoShareUI0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-LoadSharePlatformPrefab0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-InitShareVideoForm0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OpenShareVideoForm0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnVideoReadyToShare0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnReceiveVideoShareNofityData0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-isINTLVideoHasAlbunPermission0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CheckPermission0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-DoAsyncCheckPermissionCallBack0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnGameJoyCheckPermissionResult0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ReqCopyShareUrl0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnHonourMomentCopyUrlClick0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetVideoShareForm0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetToggleSharePlatform0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SetDirtWordsReqInstance0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnShare2SnsCallback0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-PlatformToReportSubType0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ShareVideoReport0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ShareVideo2SNS0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ShareVideo2Guild0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-KingHourShareUploadLog0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CheckDirtyWordCallRsp0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnHonourMomentSureShareClick0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnCheckBoxStatusChanged0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CloseVideoShareForm0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnVideoOperateExcuted0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnSettlementFormClosed0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnApplicationPause0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnFreeRecordStart0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CheckTaleTimeRecordStorageEnough0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CheckFreeRecordStorageEnough0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CheckFeature0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-DoAsyncCheckFeatureCallBack0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnGameJoyCheckSDKFeatureResult0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-IsHonourMomentFuncSvrOpen0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetIOSVer0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-IsHonourMomentFuncDeviceSupport0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-set_Enable0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnGlobalServerToClientCfgReady0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-Init0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-StartFreeRecorder0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-UnRegisterAsyncCheckFeatureCallBack0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-TryToAutoStartFreeRecord0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-RegisterAsyncCheckFeatureCallBack0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SetCheckFeatureException0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnAsyncCheckFeatueTimeUp0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-AsyncCheckSDKFeature0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-AsyncCheckFeature0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-InitAfterCfgReady0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-UnInit0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CloseGenerateMomentsVideoTips0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnKillNotify0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnHighLightNotify0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetRecordVideoCount0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SetMultiKill0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SetExtraInfos0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-DoFightOver0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetRecorderPosition0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetMultipKillDesc0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetVideoName0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ChooseTopEvent0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnSaveHonourMoment0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnSaveMomentVideoCancel0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-IsContainSpecialKill0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-HasSpecialKillRecord0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetHighestKill0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnShareToGuildRsp0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-HaveHonourMomentData0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-HaveMomentVideoData0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-IsCompleteHonourVideoRecorder0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-GetAppGameId0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-IsHonourMomentFucOpen0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-IsDeviceAvailable0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-StopFreeRecorder0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-get_FreeRecordEnable0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-AsyncCheckPermission0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-RegisterAsyncCheckPermissionCallBack0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-UnRegisterAsyncCheckPermissionCallBack0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-ResetGlobalServerToClientCfgReady0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SetVideoQuality0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SetVoiceRecordEnable0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CheatStartFreeRecorder0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CheatStopFreeRecorder0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-CheatSwitchHonounMomentEnable0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SimulateCloseShareFormAndOpenSdkForm0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnTimerUp2DispatchEvent0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SimulateTimeUpReady2Share0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-OnTimerUp2CloseVideoManager0;
	public const object Assets-Scripts-GameSystem-CRecordUseSDK-SimulateTimeUp2CloseVideoManger0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-onOpenBind0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-OnBind_Garena0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-OnBind_Facebook0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-_CloseForm0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-OnCLoseBind0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-OnBind_ConfirmFacebook0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-OnBind_ConfirmGarena0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-BindFail0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-BindSuccessSyncServer0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-ShowBindSuccTip0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-BindSuccess0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-_Mount0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-Init0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-_UnMount0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-UnInit0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-OnBindSuccessRsp0;
	public const object Assets-Scripts-GameSystem-CBindAccountSys-OnBindRewardNtf0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-SetPlayerNameChangeCount0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-SetGuildNameChangeCount0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-GetNameChangeCostItemCount0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-OpenNameChangeForm0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-OnOpenPlayerNameChangeForm0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-OnOpenGuildNameChangeForm0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-GetNameChangeHaveItemCount0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-GetNameChangeCardShopProductKey0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-CheckNameChangeCardCount0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-SendChangeNameReq0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-SendRemarkChangeReq0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-OnChangeName0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-OnGuideToMall0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-OnBuyNameChgCardConfirm0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-OnOpenBuyDianQuanPanel0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-SetEnv0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-OnOpenChangeRemarkWnd0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-ReportChangeRemarkTlog0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-Init0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-ReceiveChangeNameRsp0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-ReceiveGuildNameChangeNtf0;
	public const object Assets-Scripts-GameSystem-CNameChangeSystem-ReceiveChangeRemarkRsp0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-GetOnShowRollingInfoIndex0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-_RollInfoPushPool0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-HandleOnShowRollingInfo0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-IsNeedResetResetPriority0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-ResetRollingInfoPriority0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-GetNextShowRollingInfoIndex0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-GetRollingBar0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-ShowRollingBar0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-StartRolling0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-StartRolling1;
	public const object Assets-Scripts-GameSystem-CRollingSystem-OnRollingCDOver0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-HideRollingBar0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-OnAutoScrollerScrollFinish0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-_OnGameLanChange0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-StopRolling0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-OnSET_ROLLING_STATE0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-Init0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-UnInit0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-CalculatePriority0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-CalculateRepeatCount0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-_GetRollInfoFromPool0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-IsInBattle0;
	public const object Assets-Scripts-GameSystem-CRollingSystem-ReceiveRollingMsgNtf0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-GetAchieveingStarImg0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetStarState0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetAchievementItemStarsProgress0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetAchievementListItemProgress0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetAchievementListItemState0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetAchievementAwardTipsEvent0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetAchievementListItemAward0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetGetAwardEventScript0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetAchievementListItem0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnAchievementListElementEnabled0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SendGetAchieveRewardReq0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnAchievementGetAward0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnAchievementShowShareBtn0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnShareFormClosed0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnOpenAwardForm0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-GetViewAchieveItemById0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OpenAchieveForm0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnBuddleJumpHandler0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-RemoveNotifyEventList0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-NotifyRedotAndBuddle0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetAchievementGobalProgress0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-RefreshAchieveItemList0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-HandleAchieveGetRankingAccountInfo0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-Init0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnOpenLobby0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetShareStarState0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetStarFxData0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetStarFillAmount0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnTimerShowAchieved0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnTimerShowStarEffect0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-SetSharedAchievementStarsProgress0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-RefreshAwardPanel0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-RefreshShareForm0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OpenShareForm0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnRecieveAchieveInfo0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnNotifyAchieveStateChange0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnNotifyAchieveDoneDataChange0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnNotifyGetAchieveReward0;
	public const object Assets-Scripts-GameSystem-CAchievementSystem-OnNotifyPvpBanMsg0;
	public const object Assets-Scripts-GameSystem-CNewbieAchieveSys-onAchieveClose0;
	public const object Assets-Scripts-GameSystem-CNewbieAchieveSys-ShowAchieve0;
	public const object Assets-Scripts-GameSystem-CNewbieAchieveSys-onActorDead0;
	public const object Assets-Scripts-GameSystem-CNewbieAchieveSys-onLearnTalent0;
	public const object Assets-Scripts-GameSystem-CNewbieAchieveSys-onMonsterGroupDead0;
	public const object Assets-Scripts-GameSystem-CNewbieAchieveSys-Init0;
	public const object Assets-Scripts-GameSystem-CNewbieAchieveSys-UnInit0;
	public const object Assets-Scripts-GameSystem-CTask-IsHaveDone0;
	public const object Assets-Scripts-GameSystem-CTask-SetState0;
	public const object Assets-Scripts-GameSystem-CTask-UpdateState0;
	public const object Assets-Scripts-GameSystem-CTask-SetState1;
	public const object Assets-Scripts-GameSystem-CTask-SetState2;
	public const object Assets-Scripts-GameSystem-CTask-SetGetTime0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetTask0;
	public const object Assets-Scripts-GameSystem-CTask-IsTaskIDAfterThisTask0;
	public const object Assets-Scripts-GameSystem-CombineData-GetListView1;
	public const object Assets-Scripts-GameSystem-CombineData-_remove0;
	public const object Assets-Scripts-GameSystem-CombineData-Remove0;
	public const object Assets-Scripts-GameSystem-CTaskModel-Remove0;
	public const object Assets-Scripts-GameSystem-CombineData-_insert0;
	public const object Assets-Scripts-GameSystem-CombineData-Add0;
	public const object Assets-Scripts-GameSystem-CTaskModel-AddTask0;
	public const object Assets-Scripts-GameSystem-TaskUT-Add_Task0;
	public const object Assets-Scripts-GameSystem-TaskUT-GetUseableFromReward0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetLevelIndex0;
	public const object Assets-Scripts-GameSystem-CTaskModel-IsInCltCalcCompletedTasks0;
	public const object Assets-Scripts-GameSystem-CTaskModel-IsInCltCalcCompletedTasks1;
	public const object Assets-Scripts-GameSystem-CTaskModel-InsertCltCalcCompletedTasks0;
	public const object Assets-Scripts-GameSystem-CTaskModel-ParseCltCalcCompletedTasks0;
	public const object Assets-Scripts-GameSystem-CTaskModel-IsGetLevelReward0;
	public const object Assets-Scripts-GameSystem-CTaskModel-IsGetLevelReward1;
	public const object Assets-Scripts-GameSystem-LevelRewardData-GetHaveDoneTaskCount0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetMainTask_RedDotCount0;
	public const object Assets-Scripts-GameSystem-CTaskModel-IsLevelNode_RedDot0;
	public const object Assets-Scripts-GameSystem-CTaskModel-IsShowMainTaskTab_RedDotCount0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetLevelRewardData_Index0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetLevelRewardData_ByIndex0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetLevelRewardData0;
	public const object Assets-Scripts-GameSystem-LevelRewardData-GetResTaskIDIndex0;
	public const object Assets-Scripts-GameSystem-LevelRewardData-GetFristNullResTaskIndex0;
	public const object Assets-Scripts-GameSystem-CTaskModel-ParseLevelRewardData0;
	public const object Assets-Scripts-GameSystem-CTaskModel-AnyTaskOfState0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetTotalTaskOfState0;
	public const object Assets-Scripts-GameSystem-CTaskModel-UpdateTaskState0;
	public const object Assets-Scripts-GameSystem-CTaskModel-IsTaskAllCompelete0;
	public const object Assets-Scripts-GameSystem-CTaskModel-IsAnyTaskInState0;
	public const object Assets-Scripts-GameSystem-CTaskModel-Remove1;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetTasks_Count0;
	public const object Assets-Scripts-GameSystem-CombineData-GetMaxIndex_TaskID_InState0;
	public const object Assets-Scripts-GameSystem-CTaskModel-GetMaxIndex_TaskID_InState0;
	public const object Assets-Scripts-GameSystem-CTaskModel-Load_Share_task0;
	public const object Assets-Scripts-GameSystem-CTaskModel-SyncDailyTaskActivePointNtf0;
	public const object Assets-Scripts-GameSystem-CTaskModel-SyncWeekTaskInfoNtf0;
	public const object Assets-Scripts-GameSystem-CTaskModel-SyncWeekStarInfoNtf0;
	public const object Assets-Scripts-GameSystem-CTaskModel-SyncPlentyTaskRefreshedNtf0;
	public const object Assets-Scripts-GameSystem-CombineData-_sort_main0;
	public const object Assets-Scripts-GameSystem-CombineData-Sort0;
	public const object Assets-Scripts-GameSystem-CombineData-GetTask_Count0;
	public const object Assets-Scripts-GameSystem-CombineData-_getIndex0;
	public const object Assets-Scripts-GameSystem-HuoyueData-GetRewardCfg0;
	public const object Assets-Scripts-GameSystem-HuoyueData-IsInTime0;
	public const object Assets-Scripts-GameSystem-HuoyueData-GetUsable0;
	public const object Assets-Scripts-GameSystem-HuoyueData-CalcMaxNum0;
	public const object Assets-Scripts-GameSystem-HuoyueData-Calc_Day_Max_Num0;
	public const object Assets-Scripts-GameSystem-HuoyueData-CalcWeeklyMaxNum0;
	public const object Assets-Scripts-GameSystem-HuoyueData-ParseHuoyuedu0;
	public const object Assets-Scripts-GameSystem-HuoyueData-PrintInfo0;
	public const object Assets-Scripts-GameSystem-HuoyueData-Set0;
	public const object Assets-Scripts-GameSystem-HuoyueData-Get_Reward0;
	public const object Assets-Scripts-GameSystem-HuoyueData-BAlready_Reward0;
	public const object Assets-Scripts-GameSystem-LevelRewardData-Clear0;
	public const object Assets-Scripts-GameSystem-LevelRewardData-GetConfigRewardCount0;
	public const object Assets-Scripts-GameSystem-LevelRewardData-IsAllLevelTask0;
	public const object Assets-Scripts-GameSystem-LevelRewardData-IsHasCltCalcCompeletedTask0;
	public const object Assets-Scripts-GameSystem-LevelRewardData-GetValidTaskCount0;
	public const object Assets-Scripts-GameSystem-CLobbyActPanel-OnClickGetNewbieTaskHeroPanel0;
	public const object Assets-Scripts-GameSystem-CLobbyActPanel-OnClickFinishNewbieTaskEnsure0;
	public const object Assets-Scripts-GameSystem-CLobbyActPanel-Init0;
	public const object Assets-Scripts-GameSystem-CLobbyActPanel-UnInit0;
	public const object Assets-Scripts-GameSystem-TaskGuide-initTabConfig0;
	public const object Assets-Scripts-GameSystem-TaskGuide-resizeTabWidth0;
	public const object Assets-Scripts-GameSystem-TaskGuide-InitTabItem0;
	public const object Assets-Scripts-GameSystem-TaskGuide-showForm0;
	public const object Assets-Scripts-GameSystem-TaskGuide-OpenForm0;
	public const object Assets-Scripts-GameSystem-TaskGuide-OnOpenTaskForm0;
	public const object Assets-Scripts-GameSystem-TaskGuide-Clear0;
	public const object Assets-Scripts-GameSystem-TaskGuide-OnCloseTaskForm0;
	public const object Assets-Scripts-GameSystem-TaskGuide-OnCloseTaskForm1;
	public const object Assets-Scripts-GameSystem-TaskGuide-showTabContent0;
	public const object Assets-Scripts-GameSystem-TaskGuide-ShowTaskGuideByType0;
	public const object Assets-Scripts-GameSystem-TaskGuide-delayShow0;
	public const object Assets-Scripts-GameSystem-TaskGuide-OnTaskChanged0;
	public const object Assets-Scripts-GameSystem-TaskGuide-Init0;
	public const object Assets-Scripts-GameSystem-CTaskSys-UpdateTaskState0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnInitTask0;
	public const object Assets-Scripts-GameSystem-CTaskSys-PrepareInitTask0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnLobbyNfy0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnTaskResDataNtf0;
	public const object Assets-Scripts-GameSystem-CTaskSys-GetNowTask0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-Send_ShareTask0;
	public const object Assets-Scripts-GameSystem-CTaskSys-SendShareTask0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnWeekStarCountUpdate0;
	public const object Assets-Scripts-GameSystem-CTaskSys-Init0;
	public const object Assets-Scripts-GameSystem-CTaskSys-ActivityPoint0;
	public const object Assets-Scripts-GameSystem-TaskGuide-UnInit0;
	public const object Assets-Scripts-GameSystem-CTaskSys-UnInit0;
	public const object Assets-Scripts-GameSystem-CTaskSys-SetNowTask0;
	public const object Assets-Scripts-GameSystem-CTaskSys-On_TASKUPD_NTF0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnUSUALTASK_RES0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnSCID_NEWTASKGET_NTF0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnTASKSUBMIT_RES0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnPLENTY_TASK_REFRESHED_RES0;
	public const object Assets-Scripts-GameSystem-CTaskSys-OnSCID_COIN_WEEK_LIMIT_CLEARED_NTY_RES0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-SortDataState0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-SortDataExchangeItem0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-ProcessServerData0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-UpdateActivityPoint0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-UpdateListItem0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-UpdateTimer0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-UpdatePanel0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-Open0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnOpenForm0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-Close0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskClose0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskHelp0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-SendExchangeLimitCouponsRequest0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskExchange0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskCanGet0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskGoComplete0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskCandidateItemEnable0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-UpdateGetItemCell0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskExchangeCandidateItemEnable0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskShare0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-CloseDailyTaskShare0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnTaskUpdate0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnActivityPointUpdate0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnMsgAssitJumpEvent0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnFormClosed0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskGetNewSkinNtf0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskGetNewHeroNtf0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-Init0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-UnInit0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-Clear0;
	public const object Assets-Scripts-GameSystem-CDailyTaskView-OnDailyTaskDianQuanHelp0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnGetReward0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnJumpToTask0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnGetLevelReward0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnGetRewardTipBtnDown0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnNewbieWealClick0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnTaskStateChanged0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-InitConfigTimeLimitTask0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-InitConfigLevelTask0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnTaskResDataNtf0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnMsgAssitJumpEvent0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnFormClosed0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-OnNewbieSignDataChanged0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-Init0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-UnInit0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-ItemComparerConverter-Compare0;
	public const object Assets-Scripts-GameSystem-NewSimpleTaskView-ResNewbieWealCfgComparer-Compare0;
	public const object Assets-Scripts-GameSystem-TaskGuide-refreshForm0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-OnTaskUpdate0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-OnDailyTaskRes0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-OnSCID_NEWTASKGET_NTF0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-Send_Update_Task0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-OnTASKSUBMIT_RES0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-Send_Get_Level_Reward_Request0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-OnSCID_GETPVPLEVELREWARD_RSP0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-OnSCID_DAYTASK_ACTIVE_POINT_NTF0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-OnSCID_EXCHANGE_LIMITCOUPONS_RSP0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-PlentyTaskRefreshedNtf0;
	public const object Assets-Scripts-GameSystem-TaskMsgHander-PlentyStarCoinWeekLimitClearNtf0;
}

