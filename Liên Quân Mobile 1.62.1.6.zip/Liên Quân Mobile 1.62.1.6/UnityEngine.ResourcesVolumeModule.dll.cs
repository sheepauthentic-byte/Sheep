// Namespace: 
internal class <Module>
{
}

// Namespace: Unity.IO.ResVolume
public class ResVolumeResourceRequest
{

	// Fields
	internal object m_ResourcesVolumeID; // 0x28
	internal object m_AsyncHandle; // 0x30
	internal object m_IsAccurate; // 0x38
}

// Namespace: Unity.IO.ResVolume
public class ResourcesVolume
{

	// Fields
	private static object s_ResourcesMissingEvent; // 0x0

	// Methods

	// RVA: 0x7498038
	public static object NotifyResourcesMissing(object path) { }

}

// Namespace: Unity.IO.ResVolume
public class ResourcesVolumeContext
{
}

