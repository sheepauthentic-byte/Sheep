// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public static class ImageConversion
{

	// Methods

	// RVA: 0x73FBCC4
	public static object EncodeToPNG(object tex) { }

	// RVA: 0x73FBD14
	public static object EncodeToJPG(object tex, object quality) { }

	// RVA: 0x73FBD78
	public static object EncodeToJPG(object tex) { }

	// RVA: 0x73FBDD0
	public static object LoadImage(object tex, object data, object markNonReadable) { }

	// RVA: 0x73FBE3C
	public static object LoadImage(object tex, object data) { }

	// RVA: 0x73FBEA8
	public static object LoadImageByPath(object tex, object path, object markNonReadable) { }

}

