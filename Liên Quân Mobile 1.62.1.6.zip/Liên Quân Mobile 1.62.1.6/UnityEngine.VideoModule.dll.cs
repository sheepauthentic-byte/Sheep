// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.Experimental.Video
public struct VideoClipPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x76F4420
	public object GetHandle() { }

	// RVA: 0x76F4438
	public object Equals(object other) { }

}

// Namespace: UnityEngine.Video
public sealed class VideoClip
{

	// Methods

	// RVA: 0x76F4540
	private object .ctor() { }

}

// Namespace: UnityEngine.Video
public enum VideoRenderMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CameraFarPlane;
	public const object CameraNearPlane;
	public const object RenderTexture;
	public const object MaterialOverride;
	public const object APIOnly;
}

// Namespace: UnityEngine.Video
public enum Video3DLayout
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object No3D;
	public const object SideBySide3D;
	public const object OverUnder3D;
}

// Namespace: UnityEngine.Video
public enum VideoAspectRatio
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoScaling;
	public const object FitVertically;
	public const object FitHorizontally;
	public const object FitInside;
	public const object FitOutside;
	public const object Stretch;
}

// Namespace: UnityEngine.Video
public enum VideoTimeSource
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AudioDSPTimeSource;
	public const object GameTimeSource;
}

// Namespace: UnityEngine.Video
public enum VideoTimeReference
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Freerun;
	public const object InternalTime;
	public const object ExternalTime;
}

// Namespace: UnityEngine.Video
public enum VideoSource
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object VideoClip;
	public const object Url;
}

// Namespace: UnityEngine.Video
public enum VideoTimeUpdateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DSPTime;
	public const object GameTime;
	public const object UnscaledGameTime;
}

// Namespace: UnityEngine.Video
public enum VideoAudioOutputMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object AudioSource;
	public const object Direct;
	public const object APIOnly;
}

// Namespace: 
public sealed class EventHandler
{

	// Methods

	// RVA: 0x76F71D4
	public object .ctor(object object, object method) { }

	// RVA: 0x76F727C
	public virtual object Invoke(object source) { }

}

// Namespace: 
public sealed class ErrorEventHandler
{

	// Methods

	// RVA: 0x76F732C
	public object .ctor(object object, object method) { }

	// RVA: 0x76F73DC
	public virtual object Invoke(object source, object message) { }

}

// Namespace: 
public sealed class FrameReadyEventHandler
{

	// Methods

	// RVA: 0x76F748C
	public object .ctor(object object, object method) { }

	// RVA: 0x76F753C
	public virtual object Invoke(object source, object frameIdx) { }

}

// Namespace: 
public sealed class TimeEventHandler
{

	// Methods

	// RVA: 0x76F75EC
	public object .ctor(object object, object method) { }

	// RVA: 0x76F769C
	public virtual object Invoke(object source, object seconds) { }

}

// Namespace: UnityEngine.Video
public sealed class VideoPlayer
{

	// Fields
	private object prepareCompleted; // 0x10
	private object loopPointReached; // 0x18
	private object started; // 0x20
	private object frameDropped; // 0x28
	private object errorReceived; // 0x30
	private object seekCompleted; // 0x38
	private object clockResyncOccurred; // 0x40
	private object frameReady; // 0x48

	// Properties
	public object source { get; set; }
	public object timeUpdateMode { get; set; }
	public object url { get; set; }
	public object clip { get; set; }
	public object renderMode { get; set; }
	public object canSetTimeUpdateMode { get; }
	public object targetCamera { get; set; }
	public object targetTexture { get; set; }
	public object targetMaterialRenderer { get; set; }
	public object targetMaterialProperty { get; set; }
	public object aspectRatio { get; set; }
	public object targetCameraAlpha { get; set; }
	public object targetCamera3DLayout { get; set; }
	public object texture { get; }
	public object isPrepared { get; }
	public object waitForFirstFrame { get; set; }
	public object playOnAwake { get; set; }
	public object isPlaying { get; }
	public object isPaused { get; }
	public object canSetTime { get; }
	public object time { get; set; }
	public object frame { get; set; }
	public object clockTime { get; }
	public object canStep { get; }
	public object canSetPlaybackSpeed { get; }
	public object playbackSpeed { get; set; }
	public object isLooping { get; set; }
	public object canSetTimeSource { get; }
	public object timeSource { get; set; }
	public object timeReference { get; set; }
	public object externalReferenceTime { get; set; }
	public object canSetSkipOnDrop { get; }
	public object skipOnDrop { get; set; }
	public object frameCount { get; }
	public object frameRate { get; }
	public object length { get; }
	public object width { get; }
	public object height { get; }
	public object pixelAspectRatioNumerator { get; }
	public object pixelAspectRatioDenominator { get; }
	public object audioTrackCount { get; }
	public static object controlledAudioTrackMaxCount { get; }
	public object controlledAudioTrackCount { get; set; }
	public object audioOutputMode { get; set; }
	public object canSetDirectAudioVolume { get; }
	public object sendFrameReadyEvents { get; set; }

	// Methods

	// RVA: 0x76F45C8
	public object get_source() { }

	// RVA: 0x76F4618
	public object set_source(object value) { }

	// RVA: 0x76F467C
	public object get_timeUpdateMode() { }

	// RVA: 0x76F46CC
	public object set_timeUpdateMode(object value) { }

	// RVA: 0x76F4730
	public object get_url() { }

	// RVA: 0x76F4780
	public object set_url(object value) { }

	// RVA: 0x76F47E4
	public object get_clip() { }

	// RVA: 0x76F4834
	public object set_clip(object value) { }

	// RVA: 0x76F4898
	public object get_renderMode() { }

	// RVA: 0x76F48E8
	public object set_renderMode(object value) { }

	// RVA: 0x76F494C
	public object get_canSetTimeUpdateMode() { }

	// RVA: 0x76F499C
	public object get_targetCamera() { }

	// RVA: 0x76F49EC
	public object set_targetCamera(object value) { }

	// RVA: 0x76F4A50
	public object get_targetTexture() { }

	// RVA: 0x76F4AA0
	public object set_targetTexture(object value) { }

	// RVA: 0x76F4B04
	public object get_targetMaterialRenderer() { }

	// RVA: 0x76F4B54
	public object set_targetMaterialRenderer(object value) { }

	// RVA: 0x76F4BB8
	public object get_targetMaterialProperty() { }

	// RVA: 0x76F4C08
	public object set_targetMaterialProperty(object value) { }

	// RVA: 0x76F4C6C
	public object get_aspectRatio() { }

	// RVA: 0x76F4CBC
	public object set_aspectRatio(object value) { }

	// RVA: 0x76F4D20
	public object get_targetCameraAlpha() { }

	// RVA: 0x76F4D70
	public object set_targetCameraAlpha(object value) { }

	// RVA: 0x76F4DD4
	public object get_targetCamera3DLayout() { }

	// RVA: 0x76F4E24
	public object set_targetCamera3DLayout(object value) { }

	// RVA: 0x76F4E88
	public object get_texture() { }

	// RVA: 0x76F4ED8
	public object Prepare() { }

	// RVA: 0x76F4F28
	public object get_isPrepared() { }

	// RVA: 0x76F4F78
	public object get_waitForFirstFrame() { }

	// RVA: 0x76F4FC8
	public object set_waitForFirstFrame(object value) { }

	// RVA: 0x76F502C
	public object get_playOnAwake() { }

	// RVA: 0x76F507C
	public object set_playOnAwake(object value) { }

	// RVA: 0x76F50E0
	public object Play() { }

	// RVA: 0x76F5130
	public object Pause() { }

	// RVA: 0x76F5180
	public object Stop() { }

	// RVA: 0x76F51D0
	public object get_isPlaying() { }

	// RVA: 0x76F5220
	public object get_isPaused() { }

	// RVA: 0x76F5270
	public object get_canSetTime() { }

	// RVA: 0x76F52C0
	public object get_time() { }

	// RVA: 0x76F5310
	public object set_time(object value) { }

	// RVA: 0x76F5374
	public object get_frame() { }

	// RVA: 0x76F53C4
	public object set_frame(object value) { }

	// RVA: 0x76F5428
	public object get_clockTime() { }

	// RVA: 0x76F5478
	public object get_canStep() { }

	// RVA: 0x76F54C8
	public object StepForward() { }

	// RVA: 0x76F5518
	public object get_canSetPlaybackSpeed() { }

	// RVA: 0x76F5568
	public object get_playbackSpeed() { }

	// RVA: 0x76F55B8
	public object set_playbackSpeed(object value) { }

	// RVA: 0x76F561C
	public object get_isLooping() { }

	// RVA: 0x76F566C
	public object set_isLooping(object value) { }

	// RVA: 0x76F56D0
	public object get_canSetTimeSource() { }

	// RVA: 0x76F5720
	public object get_timeSource() { }

	// RVA: 0x76F5770
	public object set_timeSource(object value) { }

	// RVA: 0x76F57D4
	public object get_timeReference() { }

	// RVA: 0x76F5824
	public object set_timeReference(object value) { }

	// RVA: 0x76F5888
	public object get_externalReferenceTime() { }

	// RVA: 0x76F58D8
	public object set_externalReferenceTime(object value) { }

	// RVA: 0x76F593C
	public object get_canSetSkipOnDrop() { }

	// RVA: 0x76F598C
	public object get_skipOnDrop() { }

	// RVA: 0x76F59DC
	public object set_skipOnDrop(object value) { }

	// RVA: 0x76F5A40
	public object get_frameCount() { }

	// RVA: 0x76F5A90
	public object get_frameRate() { }

	// RVA: 0x76F5AE0
	public object get_length() { }

	// RVA: 0x76F5B30
	public object get_width() { }

	// RVA: 0x76F5B80
	public object get_height() { }

	// RVA: 0x76F5BD0
	public object get_pixelAspectRatioNumerator() { }

	// RVA: 0x76F5C20
	public object get_pixelAspectRatioDenominator() { }

	// RVA: 0x76F5C70
	public object get_audioTrackCount() { }

	// RVA: 0x76F5CC0
	public object GetAudioLanguageCode(object trackIndex) { }

	// RVA: 0x76F5D24
	public object GetAudioChannelCount(object trackIndex) { }

	// RVA: 0x76F5D88
	public object GetAudioSampleRate(object trackIndex) { }

	// RVA: 0x76F5DEC
	public static object get_controlledAudioTrackMaxCount() { }

	// RVA: 0x76F5E2C
	public object get_controlledAudioTrackCount() { }

	// RVA: 0x76F5ECC
	public object set_controlledAudioTrackCount(object value) { }

	// RVA: 0x76F5E7C
	private object GetControlledAudioTrackCount() { }

	// RVA: 0x76F5FD0
	private object SetControlledAudioTrackCount(object value) { }

	// RVA: 0x76F6034
	public object EnableAudioTrack(object trackIndex, object enabled) { }

	// RVA: 0x76F60A0
	public object IsAudioTrackEnabled(object trackIndex) { }

	// RVA: 0x76F6104
	public object get_audioOutputMode() { }

	// RVA: 0x76F6154
	public object set_audioOutputMode(object value) { }

	// RVA: 0x76F61B8
	public object get_canSetDirectAudioVolume() { }

	// RVA: 0x76F6208
	public object GetDirectAudioVolume(object trackIndex) { }

	// RVA: 0x76F626C
	public object SetDirectAudioVolume(object trackIndex, object volume) { }

	// RVA: 0x76F62E4
	public object GetDirectAudioMute(object trackIndex) { }

	// RVA: 0x76F6348
	public object SetDirectAudioMute(object trackIndex, object mute) { }

	// RVA: 0x76F63B4
	public object GetTargetAudioSource(object trackIndex) { }

	// RVA: 0x76F6418
	public object SetTargetAudioSource(object trackIndex, object source) { }

	// RVA: 0x76F6484
	public object add_prepareCompleted(object value) { }

	// RVA: 0x76F6528
	public object remove_prepareCompleted(object value) { }

	// RVA: 0x76F65CC
	public object add_loopPointReached(object value) { }

	// RVA: 0x76F6670
	public object remove_loopPointReached(object value) { }

	// RVA: 0x76F6714
	public object add_started(object value) { }

	// RVA: 0x76F67B8
	public object remove_started(object value) { }

	// RVA: 0x76F685C
	public object add_frameDropped(object value) { }

	// RVA: 0x76F6900
	public object remove_frameDropped(object value) { }

	// RVA: 0x76F69A4
	public object add_errorReceived(object value) { }

	// RVA: 0x76F6A48
	public object remove_errorReceived(object value) { }

	// RVA: 0x76F6AEC
	public object add_seekCompleted(object value) { }

	// RVA: 0x76F6B90
	public object remove_seekCompleted(object value) { }

	// RVA: 0x76F6C34
	public object add_clockResyncOccurred(object value) { }

	// RVA: 0x76F6CD8
	public object remove_clockResyncOccurred(object value) { }

	// RVA: 0x76F6D7C
	public object get_sendFrameReadyEvents() { }

	// RVA: 0x76F6DCC
	public object set_sendFrameReadyEvents(object value) { }

	// RVA: 0x76F6E30
	public object add_frameReady(object value) { }

	// RVA: 0x76F6ED4
	public object remove_frameReady(object value) { }

	// RVA: 0x76F6F78
	private static object InvokePrepareCompletedCallback_Internal(object source) { }

	// RVA: 0x76F6FB0
	private static object InvokeFrameReadyCallback_Internal(object source, object frameIdx) { }

	// RVA: 0x76F6FEC
	private static object InvokeLoopPointReachedCallback_Internal(object source) { }

	// RVA: 0x76F7024
	private static object InvokeStartedCallback_Internal(object source) { }

	// RVA: 0x76F705C
	private static object InvokeFrameDroppedCallback_Internal(object source) { }

	// RVA: 0x76F7094
	private static object InvokeErrorReceivedCallback_Internal(object source, object errorStr) { }

	// RVA: 0x76F70D0
	private static object InvokeSeekCompletedCallback_Internal(object source) { }

	// RVA: 0x76F7108
	private static object InvokeClockResyncOccurredCallback_Internal(object source, object seconds) { }

	// RVA: 0x76F7140
	public object .ctor() { }

}

