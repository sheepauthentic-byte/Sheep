// Namespace: 
internal class <Module>
{
}

// Namespace: System.Runtime.CompilerServices
public static class Unsafe
{

	// Methods

	// RVA: -1
	public static object Read(object source) { }

	// RVA: -1
	public static object AsPointer(object value) { }

	// RVA: -1
	public static object SizeOf() { }

	// RVA: 0x6ED5F5C
	public static object CopyBlock(object destination, object source, object byteCount) { }

	// RVA: 0x6ED5F64
	public static object InitBlockUnaligned(object startAddress, object value, object byteCount) { }

	// RVA: -1
	public static object AsRef(object source) { }

}

// Namespace: System.Runtime.Versioning
internal sealed class NonVersionableAttribute
{

	// Methods

	// RVA: 0x6ED5F6C
	public object .ctor() { }

}

