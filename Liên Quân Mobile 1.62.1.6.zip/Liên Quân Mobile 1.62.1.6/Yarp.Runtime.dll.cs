// Namespace: 
internal class <Module>
{
}

// Namespace: Microsoft.CodeAnalysis
internal sealed class EmbeddedAttribute
{

	// Methods

	// RVA: 0x7732948
	public object .ctor() { }

}

// Namespace: System.Runtime.CompilerServices
internal sealed class IsUnmanagedAttribute
{

	// Methods

	// RVA: 0x7732950
	public object .ctor() { }

}

// Namespace: 
public class PostProcessRenderer
{

	// Methods

	// RVA: 0x7732958
	public virtual object OnPostRenderInSRP(object camera, object cmd) { }

	// RVA: 0x773295C
	public virtual object OnPreRenderInSRP(object camera, object cmd) { }

	// RVA: 0x7732960
	public object .ctor() { }

}

// Namespace: 
public struct DecalCoveredClusterRange
{

	// Fields
	public object min; // 0xFFFFFFFFFFFFFFF8
	public object max; // 0x4
	public object offset; // 0x10
	public object decalIndex; // 0x14
	public object clusterCoordRange; // 0x18

	// Methods

	// RVA: 0x7732968
	public object CompareTo(object other) { }

}

// Namespace: 
private struct CollectDecalCoveredClusterRangeJob
{

	// Fields
	public object clusterDecalProperties; // 0xFFFFFFFFFFFFFFF8
	public object worldToCameraMatrix; // 0x0
	public object projectionMatrix; // 0x40
	public object cameraPixelWidth; // 0x80
	public object cameraPixelHeight; // 0x84
	public object cameraNear; // 0x88
	public object cameraFar; // 0x8C
	public object decalCoverClusterRanges; // 0x90
	public object coveredClusterCounter; // 0xA0

	// Methods

	// RVA: 0x7733A8C
	public object Execute(object index) { }

}

// Namespace: 
private struct CoverClusterJob
{

	// Fields
	public object decalCoveredClusterRanges; // 0xFFFFFFFFFFFFFFF8
	public object decalProperties; // 0x8
	public object clusterDims; // 0x10
	public object decalCount; // 0x20
	public object startCoveredClusterIndex; // 0x24
	public object lightCountersOfCluster; // 0x28
	public object alignedLightIndicesOfAllCluster; // 0x38

	// Methods

	// RVA: 0x7733FE4
	public object Execute(object index) { }

	// RVA: 0x7734218
	private object FindDecalInfo(object index) { }

}

// Namespace: 
private struct CollectClusterBufferJob
{

	// Fields
	public object lightCountersOfCluster; // 0xFFFFFFFFFFFFFFF8
	public object alignedLightIndicesOfAllCluster; // 0x8
	public object coveredClusterIndices; // 0x18
	public object lightIndicesOfAllCluster; // 0x28
	public object lightOffsetLengthOfAllCluster; // 0x38
	public object lightOffsetCounter; // 0x48

	// Methods

	// RVA: 0x77342C4
	public object Execute(object index) { }

}

// Namespace: 
public class CPUClusterDecal
{

	// Fields
	private readonly object m_ClusterDecalCommon; // 0x8
	private readonly object m_AlignedLightIndicesOfAllClusterBuffer; // 0x10
	private readonly object m_LightCountersOfAllClusterBuffer; // 0x18
	private object m_CoverClusterCount; // 0x20
	private object m_CoveredClusterCounter; // 0x28
	private object m_DecalCoveredClusterRanges; // 0x30
	private object m_LightCountsOfAllCluster; // 0x40
	private object m_LightCountersOfAllCluster; // 0x50
	private object m_Inited; // 0x60
	private object m_FrameIndex; // 0x64
	private object m_CurNear; // 0x68
	private object m_CurFar; // 0x6C
	private object m_LastViewMatrix; // 0x70
	private object m_LastProjectionMatrix; // 0xB0
	private object m_CurViewMatrix; // 0xF0
	private object m_CurProjectionMatrix; // 0x130
	private const object ACROSS_FRAME_NUM;
	private const object ALL_LIGHT_INDICES_MAX_COUNT;
	private readonly object m_AlignedLightIndicesOfAllClusterShaderID; // 0x170
	private readonly object m_LightCountersOfAllClusterShaderID; // 0x174
	private readonly object m_LastViewMatrixShaderID; // 0x178
	private readonly object m_LastProjectionMatrixShaderID; // 0x17C

	// Methods

	// RVA: 0x7732988
	public object Render(object cmd, object camera, object decalSetting) { }

	// RVA: 0x7732F94
	public object Dispose() { }

	// RVA: 0x7732A24
	private object Init() { }

	// RVA: 0x7732DCC
	private object ClusterCulling(object cmd, object camera) { }

	// RVA: -1
	private object Swap(object obj1, object obj2) { }

	// RVA: 0x7733144
	private object ParallelClusterCulling(object camera, object clusterDims) { }

	// RVA: 0x7732E20
	private object UpdateResources(object cmd) { }

	// RVA: 0x7733900
	public object .ctor() { }

}

// Namespace: 
public class RectPackTest
{

	// Methods

	// RVA: 0x77343D4
	public object TestENABLE_UNITY_COLLECTIONS_CHECKS() { }

	// RVA: 0x7734468
	public object TestRectPack() { }

	// RVA: 0x7734B04
	private object AreDisjoint(object a, object b) { }

	// RVA: 0x77349CC
	private object AllRectsDisjoint(object packed) { }

	// RVA: 0x7734B50
	public object .ctor() { }

}

// Namespace: 
public class SeamTerrainLightmap
{

	// Methods

	// RVA: 0x7734B58
	public static object Seam() { }

	// RVA: 0x7734B5C
	public object .ctor() { }

}

// Namespace: 
public class Constants
{

	// Fields
	public const object DELTA;
	public static readonly object MAX_FLOAT; // 0x0
	public static readonly object MIN_FLOAT; // 0x4
	public static readonly object MAX_VEC; // 0x8
	public static readonly object MIN_VEC; // 0x14
	public static readonly object MAX_FLOAT3; // 0x20
	public static readonly object MIN_FLOAT3; // 0x2C

	// Methods

	// RVA: 0x7734B64
	public object .ctor() { }

	// RVA: 0x7734B6C
	private static object .cctor() { }

}

// Namespace: 
public class RuntimeInspectorCanvas
{

	// Fields
	public object button; // 0x18

	// Methods

	// RVA: 0x7734D40
	public object OnCloseBtnClicked() { }

	// RVA: 0x7734D48
	public object .ctor() { }

}

// Namespace: 
internal enum StatSource
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UnityBuiltinProfiler;
	public const object CustomCounter;
}

// Namespace: 
internal class StatInfo
{

	// Fields
	public object Source; // 0x8
	public object Builtin_Category; // 0xC
	public object Builtin_IsGPU; // 0xE
	public object Builtin_Name; // 0x10
	public object Builtin_Unit; // 0x18
	public object Builtin_Recorder; // 0x20
	public object CustomCounter; // 0x28
	public object Enabled; // 0x30
	public object DisplayCategory; // 0x38
	public object DisplayName; // 0x40
	public object LastValue; // 0x48
	public object Plot; // 0x4C
	public object HistoryData; // 0x50
	public object HistoryDataOffset; // 0x58
	public object Average; // 0x5C
	public object AvgValue; // 0x60
	public object AvgValueText; // 0x68
	public object AvgValueAccumulate; // 0x70

	// Methods

	// RVA: 0x7738F10
	public object .ctor() { }

}

// Namespace: 
public class CommonlyUsedCounter
{

	// Fields
	public object Category; // 0x8
	public object Name; // 0x10
	public object AlsoPlot; // 0x18
	internal object Stat; // 0x20

	// Methods

	// RVA: 0x773B304
	public object .ctor() { }

	// RVA: 0x7735D78
	public object .ctor(object Category, object Name, object AlsoPlot) { }

}

// Namespace: 
public class CommonlyUsedCounterGroup
{

	// Fields
	public object DisplayName; // 0x8
	public object counters; // 0x10

	// Methods

	// RVA: 0x7735D70
	public object .ctor() { }

}

// Namespace: 
private struct OneTimeLayoutInitializer
{

	// Fields
	private object initialized; // 0xFFFFFFFFFFFFFFF8
	private object initializing; // 0xFFFFFFFFFFFFFFF9
	private object initializeFrame; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object IsInitializing { get; }

	// Methods

	// RVA: 0x773B358
	public object get_IsInitializing() { }

	// RVA: 0x773AB24
	public object Update() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__74_0; // 0x8

	// Methods

	// RVA: 0x773B3D4
	private static object .cctor() { }

	// RVA: 0x773B434
	public object .ctor() { }

	// RVA: 0x773B43C
	internal object <InitProfilerStats>b__74_0(object a, object b) { }

}

// Namespace: 
public class InGameStatsGUI
{

	// Fields
	private static object gCategoryFps; // 0x0
	private static object gStatsFps; // 0x8
	private static object gCategoryHyperBatch; // 0x10
	private static object gStatsSavedByBatching; // 0x18
	private static object gStatsUnbatchedDrawCallsCount; // 0x20
	private static object gStatsChangedMeshCount; // 0x28
	private static object gStatsLODGroupTransformChangedCount; // 0x30
	private static object gStatsLODGroupChangedCount; // 0x38
	private static object gStatsMaterialChangedCount; // 0x40
	private static object gStatsMeshRendererChangedCount; // 0x48
	private static object gStatsMeshRendererTransformChangedCount; // 0x50
	private static object gStatsSkinnedMeshRendererChangedCount; // 0x58
	private static object gStatsSkinnedMeshRendererBonesTransformChangedCount; // 0x60
	private static object gStatsDestroyMeshCount; // 0x68
	private static object gStatsLODGroupDestroyCount; // 0x70
	private static object gStatsMaterialDestroyCount; // 0x78
	private static object gStatsMeshRendererDestroyCount; // 0x80
	private static object gStatsSkinnedMeshRendererDestroyCount; // 0x88
	private static object gCategoryInGameStatsGUI; // 0x90
	private static object gStatsOnLayout; // 0x98
	private static object gStatsUpdate; // 0xA0
	private object builtinStatsBatchesCount; // 0x18
	private object builtinStatsDynamicBatchesCount; // 0x20
	private object builtinStatsStaticBatchesCount; // 0x28
	private object builtinStatsInstancedBatchesCount; // 0x30
	private object builtinStatsDynamicBatchedDCCount; // 0x38
	private object builtinStatsStaticBatchedDCCount; // 0x40
	private object builtinStatsInstancedBatchedDCCount; // 0x48
	public object PlotFrames; // 0x50
	private object availableStats; // 0x58
	private object enabledStats; // 0x60
	private object updateAvgTime; // 0x68
	public object updateAvgValueInterval; // 0x6C
	private object avgAccumulateFrames; // 0x70
	public object timePrecision; // 0x74
	private object inGameStatsWindowsOpen; // 0x78
	private object showAddCounters; // 0x79
	private object showDelCounters; // 0x7A
	private object showSettings; // 0x7B
	private object settingsFilterString; // 0x80
	private object filteredAvailableStats; // 0x88
	public object fps; // 0x90
	public object updateFpsInternal; // 0x94
	private object fpsAccumulateFrames; // 0x98
	private object fpsAccumulateTime; // 0x9C
	private object m_needFocus; // 0xA0
	public object commonlyUsedCounterGroups; // 0xA8
	private object showStatsTableLayoutInitializer; // 0xB0
	private object addStatsTableLayoutInitializer; // 0xB8
	private object showOnlyEnabledFilterToken; // 0xC0
	private object showFrameFilterToken; // 0xC8
	private object showDcBatchFilterToken; // 0xD0
	private object showVertTriangleFilterToken; // 0xD8
	private object showCullingFilterToken; // 0xE0
	private object showRenderLoopFilterToken; // 0xE8
	private object showHyperDispatcherFilterToken; // 0xF0

	// Properties
	private static object ProfilerCategoryOther { get; }

	// Methods

	// RVA: 0x7734D50
	private static object get_ProfilerCategoryOther() { }

	// RVA: 0x7734DB0
	public static object CreateInScene() { }

	// RVA: 0x7735258
	public static object DestroyInScene() { }

	// RVA: 0x773503C
	public static object SetDearImGuiEnabled(object enabled) { }

	// RVA: 0x7734E1C
	public static object SetInGameStatsGuiEnabled(object enabled) { }

	// RVA: 0x77352C8
	private object Awake() { }

	// RVA: 0x7735DC0
	public object SwitchEnabled() { }

	// RVA: 0x7735DF0
	private object OnEnable() { }

	// RVA: 0x77369AC
	private object OnDisable() { }

	// RVA: 0x7736C7C
	private object Update() { }

	// RVA: 0x773709C
	private object OnLayout() { }

	// RVA: 0x773859C
	private object EnableStat(object stats) { }

	// RVA: 0x7738BAC
	private object DisableStat(object stats) { }

	// RVA: 0x7738C9C
	private object EnableStatPlot(object stats) { }

	// RVA: 0x7738DE0
	private object DisableStatPlot(object stats) { }

	// RVA: 0x7738ECC
	private object EnableStatAverage(object stats) { }

	// RVA: 0x7738EF0
	private object DisableStatAverage(object stats) { }

	// RVA: 0x7738D4C
	private object EnableStatHistory(object s) { }

	// RVA: 0x7738E64
	private object DisableStatHistory(object s) { }

	// RVA: 0x7735F00
	private object InitProfilerStats() { }

	// RVA: 0x7736A84
	private object ClearProfilerStats() { }

	// RVA: 0x7738FF8
	private object UpdateFps() { }

	// RVA: 0x77390F8
	private object UpdateStatsLastValue(object stats, object frameStats) { }

	// RVA: 0x7738870
	private object InitCustomCounters() { }

	// RVA: 0x773940C
	private object UpdateCustomCounters() { }

	// RVA: 0x7736DCC
	private object UpdateStatsData() { }

	// RVA: 0x7739924
	private object FormatValue(object value, object stats) { }

	// RVA: 0x7739C94
	private object FilterAvailableStats(object newFilterString) { }

	// RVA: 0x7739278
	private object FindStatInfoByPreciseName(object category, object name) { }

	// RVA: 0x7738024
	private object ImguiDrawCommonlyUsedGroups() { }

	// RVA: 0x7737458
	private object ImguiDrawAddCounters() { }

	// RVA: 0x7738298
	private object ImguiDrawStats() { }

	// RVA: 0x7737E80
	private object ImguiDrawDelCounters() { }

	// RVA: 0x7737B88
	private object ImguiDrawSettings() { }

	// RVA: 0x773AB90
	public object .ctor() { }

	// RVA: 0x773AD38
	private static object .cctor() { }

}

// Namespace: 
public static class ShaderIDVars
{

	// Fields
	public const object NullStringPropertyId;
	public const object EmptyStringPropertyId;
	public static readonly object _AlbedoColor; // 0x0
	public static readonly object _AlbedoMap; // 0x4
	public static readonly object _AlbedoTex; // 0x8
	public static readonly object _Alpha; // 0xC
	public static readonly object _AlphaTest; // 0x10
	public static readonly object _AlphaTex; // 0x14
	public static readonly object _AlphaToMask; // 0x18
	public static readonly object _AlphaVal; // 0x1C
	public static readonly object _Amplitude; // 0x20
	public static readonly object _Aperture; // 0x24
	public static readonly object _ARShadowMatrix; // 0x28
	public static readonly object _ARShadowParams; // 0x2C
	public static readonly object _ARShadowTexture; // 0x30
	public static readonly object _AtomicCounter; // 0x34
	public static readonly object _BakedAlbedoMap; // 0x38
	public static readonly object _Baker_Lightmap; // 0x3C
	public static readonly object _BaseColor; // 0x40
	public static readonly object _BaseColorMap; // 0x44
	public static readonly object _BaseTex; // 0x48
	public static readonly object _BGColor; // 0x4C
	public static readonly object _Blend; // 0x50
	public static readonly object _BlendFactor; // 0x54
	public static readonly object _BlendDst; // 0x58
	public static readonly object _BlendMode; // 0x5C
	public static readonly object _BlendOp; // 0x60
	public static readonly object _BlendOpacity; // 0x64
	public static readonly object _BlendSrc; // 0x68
	public static readonly object _BlendTex; // 0x6C
	public static readonly object _Bloom0; // 0x70
	public static readonly object _Bloom1; // 0x74
	public static readonly object _Bloom2; // 0x78
	public static readonly object _Bloom3; // 0x7C
	public static readonly object _Bloom4; // 0x80
	public static readonly object _Bloom5; // 0x84
	public static readonly object _BloomColor; // 0x88
	public static readonly object _BloomIntensity; // 0x8C
	public static readonly object _BloomSrcTex; // 0x90
	public static readonly object _BloomSrcUvScale; // 0x94
	public static readonly object _BloomTex; // 0x98
	public static readonly object _BloomThreshold; // 0x9C
	public static readonly object _Bloom_Params; // 0xA0
	public static readonly object _BlurDir1; // 0xA4
	public static readonly object _BlurDir2; // 0xA8
	public static readonly object _BlurScale; // 0xAC
	public static readonly object _BlurSize; // 0xB0
	public static readonly object _BlurTex; // 0xB4
	public static readonly object _Bounds; // 0xB8
	public static readonly object _BumpMap; // 0xBC
	public static readonly object _BumpScale; // 0xC0
	public static readonly object _CameraJitterOffset; // 0xC4
	public static readonly object _MultiChannelIntensity; // 0xC8
	public static readonly object _CenterAndRadiusSqr; // 0xCC
	public static readonly object _CenterPos; // 0xD0
	public static readonly object _Click; // 0xD4
	public static readonly object _Color; // 0xD8
	public static readonly object _ColorBoxGamma; // 0xDC
	public static readonly object _ColorMask; // 0xE0
	public static readonly object _ColorMaskTex; // 0xE4
	public static readonly object _ColorScaleOffset; // 0xE8
	public static readonly object _ConditionalU; // 0xEC
	public static readonly object _Coverage; // 0xF0
	public static readonly object _CubefaceIdx; // 0xF4
	public static readonly object _CubefaceSize; // 0xF8
	public static readonly object _Cull; // 0xFC
	public static readonly object _CullGradient; // 0x100
	public static readonly object _CullIntercept; // 0x104
	public static readonly object _CullMode; // 0x108
	public static readonly object _Curve; // 0x10C
	public static readonly object _Cutoff; // 0x110
	public static readonly object _CutOff; // 0x114
	public static readonly object _CloudShadowParam; // 0x118
	public static readonly object _DarkCornerColor; // 0x11C
	public static readonly object _DestBlend; // 0x120
	public static readonly object _DestTex; // 0x124
	public static readonly object _DiffuseRamp; // 0x128
	public static readonly object _Diffusion; // 0x12C
	public static readonly object _Dilate_Lightmap; // 0x130
	public static readonly object _Direction; // 0x134
	public static readonly object _DirLightAttens; // 0x138
	public static readonly object _DirLightColor; // 0x13C
	public static readonly object _DirLightExposure; // 0x140
	public static readonly object _DirLightPos; // 0x144
	public static readonly object _DirLightRanges; // 0x148
	public static readonly object _DisabledAlpha; // 0x14C
	public static readonly object _DisplayTransform; // 0x150
	public static readonly object _DistortIntensity; // 0x154
	public static readonly object _DistortionIntensity; // 0x158
	public static readonly object _DissolveEdgeColor; // 0x15C
	public static readonly object _DissolveEdgeColor2; // 0x160
	public static readonly object _DissolveLV; // 0x164
	public static readonly object _DistortTex; // 0x168
	public static readonly object _DissolveTex; // 0x16C
	public static readonly object _DissolveTexUVG; // 0x170
	public static readonly object _DissolveTexUVR; // 0x174
	public static readonly object _DissolveThreshold; // 0x178
	public static readonly object _DownsamplingScale; // 0x17C
	public static readonly object _DropData; // 0x180
	public static readonly object _DstBlend; // 0x184
	public static readonly object _EdgeLightColor; // 0x188
	public static readonly object _EdgeMaskTex; // 0x18C
	public static readonly object _EdgeWidth; // 0x190
	public static readonly object _EffectTex; // 0x194
	public static readonly object _EmisColor; // 0x198
	public static readonly object _EmissionColor; // 0x19C
	public static readonly object _Emission_Color; // 0x1A0
	public static readonly object _EmissiveColor; // 0x1A4
	public static readonly object _EmissiveMap; // 0x1A8
	public static readonly object _EnableExternalAlphaCustom; // 0x1AC
	public static readonly object _EnableSkill; // 0x1B0
	public static readonly object _EnableSSAO; // 0x1B4
	public static readonly object _EnableSSR; // 0x1B8
	public static readonly object _Encoding; // 0x1BC
	public static readonly object _EncodeMethod; // 0x1C0
	public static readonly object _EnvExposure; // 0x1C4
	public static readonly object _EnvironmentTex; // 0x1C8
	public static readonly object _Envmap; // 0x1CC
	public static readonly object _envRot; // 0x1D0
	public static readonly object _envSHR; // 0x1D4
	public static readonly object _envSHG; // 0x1D8
	public static readonly object _envSHB; // 0x1DC
	public static readonly object _ExposureColor; // 0x1E0
	public static readonly object _ExposureParams; // 0x1E4
	public static readonly object _ExposureScale; // 0x1E8
	public static readonly object _ExtraAlpha; // 0x1EC
	public static readonly object _FaceColor; // 0x1F0
	public static readonly object _Factor; // 0x1F4
	public static readonly object _FadeFactor; // 0x1F8
	public static readonly object _FalloffExp; // 0x1FC
	public static readonly object _FinalOffset; // 0x200
	public static readonly object _FogOfWar; // 0x204
	public static readonly object _FontTex; // 0x208
	public static readonly object _FowLOD; // 0x20C
	public static readonly object _ForceRange; // 0x210
	public static readonly object _ForceParam; // 0x214
	public static readonly object _Forward; // 0x218
	public static readonly object _FowParams; // 0x21C
	public static readonly object _FowTex0; // 0x220
	public static readonly object _FowTex1; // 0x224
	public static readonly object _FresnelIntension; // 0x228
	public static readonly object _FresnelPow; // 0x22C
	public static readonly object g_CloseupShadowTexture; // 0x230
	public static readonly object g_CloseupShadowMatrix; // 0x234
	public static readonly object g_CloseupShadowNormalBias; // 0x238
	public static readonly object g_CloseupShadowSliceUVOffset; // 0x23C
	public static readonly object g_ditherID; // 0x240
	public static readonly object g_DepthBias; // 0x244
	public static readonly object gDebugLightmapGI; // 0x248
	public static readonly object g_dxCamera; // 0x24C
	public static readonly object g_dyCamera; // 0x250
	public static readonly object g_OrthoCamera; // 0x254
	public static readonly object g_ShadowNearClipPlane; // 0x258
	public static readonly object g_AlphaOutput; // 0x25C
	public static readonly object g_OutputStyle; // 0x260
	public static readonly object g_ColorMatrix; // 0x264
	public static readonly object g_ColorMatrixVFX; // 0x268
	public static readonly object g_ColorMatrixExtraChange; // 0x26C
	public static readonly object g_ShadowPancaking; // 0x270
	public static readonly object g_TransparentShadowMap; // 0x274
	public static readonly object g_GyroValue; // 0x278
	public static readonly object g_GyroSinCos; // 0x27C
	public static readonly object g_TextureBias; // 0x280
	public static readonly object g_NonJitteredViewProjMat; // 0x284
	public static readonly object _GammaToLinearAdjust; // 0x288
	public static readonly object _GammaToLinearIntensities; // 0x28C
	public static readonly object _GammaToLinearPowers; // 0x290
	public static readonly object _GGXFilteredEnvmap; // 0x294
	public static readonly object _GGXFilteredEnvmapCube; // 0x298
	public static readonly object _GIBakerMode; // 0x29C
	public static readonly object _GlitchEffectCameraDepthTexture; // 0x2A0
	public static readonly object _GlitchEffectAnimTex; // 0x2A4
	public static readonly object _GlitchEffectSpeed; // 0x2A8
	public static readonly object _GlitchEffectScale; // 0x2AC
	public static readonly object _GlitchEffectDispersionDir; // 0x2B0
	public static readonly object _GlitchEffectScreenHscale; // 0x2B4
	public static readonly object _GlitchMaskScale; // 0x2B8
	public static readonly object _GlitchMaskTex; // 0x2BC
	public static readonly object _GrabTexture; // 0x2C0
	public static readonly object _Global_BloomThreshold; // 0x2C4
	public static readonly object _GlobalColorCorrection; // 0x2C8
	public static readonly object _Global_DirLight; // 0x2CC
	public static readonly object _Global_Dither8x8Tex; // 0x2D0
	public static readonly object _Global_HiddenGrassMapSize; // 0x2D4
	public static readonly object _Global_HiddenGrassMaskTex; // 0x2D8
	public static readonly object _Global_SceneBrightness; // 0x2DC
	public static readonly object _Global_SceneTintColor; // 0x2E0
	public static readonly object _Global_SceneTintIntensity; // 0x2E4
	public static readonly object _GlobalWaterReflectionRT; // 0x2E8
	public static readonly object _GlobalWaterReflectionTransparency; // 0x2EC
	public static readonly object _GlobalWaterRippleRT; // 0x2F0
	public static readonly object _GlobalLightEstimation; // 0x2F4
	public static readonly object Global_LightmapEncode_Add; // 0x2F8
	public static readonly object Global_LightmapEncode_Scale; // 0x2FC
	public static readonly object _GridColor; // 0x300
	public static readonly object _GridSpacing; // 0x304
	public static readonly object _GridThickness; // 0x308
	public static readonly object _HeightON; // 0x30C
	public static readonly object _HeroDissolve; // 0x310
	public static readonly object _HeroShowOverallExposureColor; // 0x314
	public static readonly object _HeroShowBkgExposureColor; // 0x318
	public static readonly object _Hidden; // 0x31C
	public static readonly object _HiddenTex; // 0x320
	public static readonly object _Highlight; // 0x324
	public static readonly object _HistoryTex; // 0x328
	public static readonly object _HurtColor; // 0x32C
	public static readonly object _InnerRaidusRatio; // 0x330
	public static readonly object InputTex; // 0x334
	public static readonly object _InputTex; // 0x338
	public static readonly object _InputTexSize; // 0x33C
	public static readonly object _Intensity; // 0x340
	public static readonly object _InvFade; // 0x344
	public static readonly object _InvSceneSize; // 0x348
	public static readonly object _IrradianceSH9Coeffs; // 0x34C
	public static readonly object _IsCubemap; // 0x350
	public static readonly object _IsCullPart; // 0x354
	public static readonly object _Iteration; // 0x358
	public static readonly object _Level; // 0x35C
	public static readonly object _Lightmap; // 0x360
	public static readonly object _LightmapAdd; // 0x364
	public static readonly object _LightmapDirAdd; // 0x368
	public static readonly object _LightmapDirScale; // 0x36C
	public static readonly object _LightmapScale; // 0x370
	public static readonly object _LightmapST; // 0x374
	public static readonly object _LightMapStatus; // 0x378
	public static readonly object _LightTex; // 0x37C
	public static readonly object _LinearRoughness; // 0x380
	public static readonly object _livecolor; // 0x384
	public static readonly object _liveopen; // 0x388
	public static readonly object _LM_Index; // 0x38C
	public static readonly object _LM_ScaleAndOffset; // 0x390
	public static readonly object _LM_TexArray; // 0x394
	public static readonly object _LM_TexArray1; // 0x398
	public static readonly object _Lucky; // 0x39C
	public static readonly object _LutIntensity; // 0x3A0
	public static readonly object _ColorGradingUseColorSpaceConversion; // 0x3A4
	public static readonly object _LutLerp; // 0x3A8
	public static readonly object _LutTex; // 0x3AC
	public static readonly object _MainTex; // 0x3B0
	public static readonly object _MainTex1; // 0x3B4
	public static readonly object _MainTex2; // 0x3B8
	public static readonly object _MainTex_Dimensions; // 0x3BC
	public static readonly object _MatLightMap; // 0x3C0
	public static readonly object _MatLightMapEncodeOffset; // 0x3C4
	public static readonly object _MatLightMapEncodeScale; // 0x3C8
	public static readonly object _MarginalV; // 0x3CC
	public static readonly object _Mask; // 0x3D0
	public static readonly object _MaskMap; // 0x3D4
	public static readonly object _MaskTex; // 0x3D8
	public static readonly object _MaskTex_RunTime; // 0x3DC
	public static readonly object _MaterialParamsMap; // 0x3E0
	public static readonly object _MaxX; // 0x3E4
	public static readonly object _MaxY; // 0x3E8
	public static readonly object _MessyGIType; // 0x3EC
	public static readonly object _MetalSmoothTex; // 0x3F0
	public static readonly object _MetallicGlossMap; // 0x3F4
	public static readonly object _MetallicMultiplier; // 0x3F8
	public static readonly object _MetaPassNumOutputVars; // 0x3FC
	public static readonly object _MinX; // 0x400
	public static readonly object _MinY; // 0x404
	public static readonly object _MipLevel; // 0x408
	public static readonly object _Mipmap; // 0x40C
	public static readonly object MirrorRayPos; // 0x410
	public static readonly object MirrorRayDir; // 0x414
	public static readonly object _MIS; // 0x418
	public static readonly object _MixMap; // 0x41C
	public static readonly object _Mixture0; // 0x420
	public static readonly object _Mixture1; // 0x424
	public static readonly object _Mode; // 0x428
	public static readonly object _MotionVec; // 0x42C
	public static readonly object _MulColor; // 0x430
	public static readonly object _NoisePow; // 0x434
	public static readonly object _Normal; // 0x438
	public static readonly object _NormalizeBySalarIrradiance; // 0x43C
	public static readonly object _NormalMap; // 0x440
	public static readonly object _NormalTex; // 0x444
	public static readonly object _OcclusionColor; // 0x448
	public static readonly object _offset1; // 0x44C
	public static readonly object _offset2; // 0x450
	public static readonly object _OffsetUV; // 0x454
	public static readonly object _offside; // 0x458
	public static readonly object _OutlineColor; // 0x45C
	public static readonly object _OutlineSize; // 0x460
	public static readonly object _OutlineWidth; // 0x464
	public static readonly object Output; // 0x468
	public static readonly object _OutputAlphaChannel; // 0x46C
	public static readonly object OutputBuffer; // 0x470
	public static readonly object _OutputTex; // 0x474
	public static readonly object _OutputTexture; // 0x478
	public static readonly object _OutputTexSize; // 0x47C
	public static readonly object Overdraw; // 0x480
	public static readonly object _P8HeroMainLightColor; // 0x484
	public static readonly object _P8LightDir; // 0x488
	public static readonly object _P8LightDir2; // 0x48C
	public static readonly object _Parameter; // 0x490
	public static readonly object _Params; // 0x494
	public static readonly object _ScreenSpaceIrradiance; // 0x498
	public static readonly object _Penumbra; // 0x49C
	public static readonly object _Percent; // 0x4A0
	public static readonly object _PhantomColor; // 0x4A4
	public static readonly object _Phase; // 0x4A8
	public static readonly object _PlaneNormal; // 0x4AC
	public static readonly object _PlayerId; // 0x4B0
	public static readonly object _Playing; // 0x4B4
	public static readonly object _FOWColor; // 0x4B8
	public static readonly object _FOWParams; // 0x4BC
	public static readonly object _PST_Global_ShadowMatrix; // 0x4C0
	public static readonly object _PST_Global_ShadowTex; // 0x4C4
	public static readonly object _PositionColorMaskTex; // 0x4C8
	public static readonly object PositionInfos; // 0x4CC
	public static readonly object _PostExposure; // 0x4D0
	public static readonly object _Radius; // 0x4D4
	public static readonly object _RampOffset; // 0x4D8
	public static readonly object _RampTex; // 0x4DC
	public static readonly object _RangeSize; // 0x4E0
	public static readonly object _ReflectionTex; // 0x4E4
	public static readonly object _RenderQueue; // 0x4E8
	public static readonly object _RenderToCubeface; // 0x4EC
	public static readonly object _RimColor; // 0x4F0
	public static readonly object _Rotation; // 0x4F4
	public static readonly object _RoughnessMultiplier; // 0x4F8
	public static readonly object _SamplerU; // 0x4FC
	public static readonly object _SamplerV; // 0x500
	public static readonly object _SampleScale; // 0x504
	public static readonly object _Saturation; // 0x508
	public static readonly object _Scale; // 0x50C
	public static readonly object _ScaleAndOffset; // 0x510
	public static readonly object _ScaleOffset; // 0x514
	public static readonly object _SceneDepth; // 0x518
	public static readonly object _SceneNormal; // 0x51C
	public static readonly object _ScreenCenter; // 0x520
	public static readonly object _Scroll; // 0x524
	public static readonly object _SeaLevel; // 0x528
	public static readonly object _SGamelGlobalAlphaModifier; // 0x52C
	public static readonly object _SGameShadowMatrix; // 0x530
	public static readonly object _SGameMV; // 0x534
	public static readonly object _SGameShadowParams; // 0x538
	public static readonly object _SGameShadowTexture; // 0x53C
	public static readonly object _ShadowAlpha; // 0x540
	public static readonly object _ShadowDarkness; // 0x544
	public static readonly object _ShadowFadeParams; // 0x548
	public static readonly object _ShadowHeight; // 0x54C
	public static readonly object _ShadowHeightAlpha; // 0x550
	public static readonly object _ShadowIntensity; // 0x554
	public static readonly object _ShadowPlane; // 0x558
	public static readonly object _ShadowPlaneON; // 0x55C
	public static readonly object _ShadowProjDir; // 0x560
	public static readonly object _ShadowTex; // 0x564
	public static readonly object _SHExposure; // 0x568
	public static readonly object _Shininess; // 0x56C
	public static readonly object _SoftMask; // 0x570
	public static readonly object _SoftMask_Rect; // 0x574
	public static readonly object _SoftMask_UVRect; // 0x578
	public static readonly object _SoftMask_ChannelWeights; // 0x57C
	public static readonly object _SoftMask_WorldToMask; // 0x580
	public static readonly object _SoftMask_Nested; // 0x584
	public static readonly object _SoftMask_Rect_Nested; // 0x588
	public static readonly object _SoftMask_UVRect_Nested; // 0x58C
	public static readonly object _SoftMask_ChannelWeights_Nested; // 0x590
	public static readonly object _SoftMask_WorldToMask_Nested; // 0x594
	public static readonly object _SpecColor; // 0x598
	public static readonly object _SpecularColor; // 0x59C
	public static readonly object _Splat0; // 0x5A0
	public static readonly object _Splat1; // 0x5A4
	public static readonly object _SpotLightTex; // 0x5A8
	public static readonly object _Spread; // 0x5AC
	public static readonly object _SrcBlend; // 0x5B0
	public static readonly object _SrcTex; // 0x5B4
	public static readonly object _SrcTexMSAA2; // 0x5B8
	public static readonly object _SrcTexMSAA4; // 0x5BC
	public static readonly object _SrcTexMSAA8; // 0x5C0
	public static readonly object _SrcTex_TexelSize; // 0x5C4
	public static readonly object _Stencil; // 0x5C8
	public static readonly object _StencilComp; // 0x5CC
	public static readonly object _StencilReadMask; // 0x5D0
	public static readonly object _StencilWriteMask; // 0x5D4
	public static readonly object _StencilOp; // 0x5D8
	public static readonly object _Swizzle; // 0x5DC
	public static readonly object _ShadowZTest; // 0x5E0
	public static readonly object _ShadowSnapCenter; // 0x5E4
	public static readonly object _Tex1; // 0x5E8
	public static readonly object _Tex2; // 0x5EC
	public static readonly object _TexcoordZ; // 0x5F0
	public static readonly object _TexelOffset0; // 0x5F4
	public static readonly object _TexelOffset1; // 0x5F8
	public static readonly object _TexelOffset2; // 0x5FC
	public static readonly object _TexelOffset3; // 0x600
	public static readonly object _TextureFade; // 0x604
	public static readonly object _TextureSize; // 0x608
	public static readonly object _Texture_RChannel; // 0x60C
	public static readonly object _Texture_GChannel; // 0x610
	public static readonly object _Texture_BChannel; // 0x614
	public static readonly object _Texture_AChannel; // 0x618
	public static readonly object _Thickness; // 0x61C
	public static readonly object _Threshold; // 0x620
	public static readonly object _TimeFrozen; // 0x624
	public static readonly object _Tint; // 0x628
	public static readonly object _TintColor; // 0x62C
	public static readonly object _TotalAlphaRatio; // 0x630
	public static readonly object _TwoSided; // 0x634
	public static readonly object _UE43DLutTex; // 0x638
	public static readonly object _UE42DLutTex; // 0x63C
	public static readonly object unity_ObjectToWorld; // 0x640
	public static readonly object _useSceneColor; // 0x644
	public static readonly object _UvBottomLeftRight; // 0x648
	public static readonly object _uvTex; // 0x64C
	public static readonly object _UvTopLeftRight; // 0x650
	public static readonly object _UvRotation; // 0x654
	public static readonly object _UvScaleOffset; // 0x658
	public static readonly object VideoAlpha; // 0x65C
	public static readonly object _viewBBB; // 0x660
	public static readonly object _viewmask; // 0x664
	public static readonly object _Vignette_Params1; // 0x668
	public static readonly object _Vignette_Params2; // 0x66C
	public static readonly object _BWParam; // 0x670
	public static readonly object _BWLightenColor; // 0x674
	public static readonly object _BWDarkenColor; // 0x678
	public static readonly object _SBIntensity; // 0x67C
	public static readonly object _SBTex; // 0x680
	public static readonly object _Visibility; // 0x684
	public static readonly object _VisualClarity; // 0x688
	public static readonly object _WeatherAlpha; // 0x68C
	public static readonly object _WeatherForward; // 0x690
	public static readonly object _WeatherPositionOffset; // 0x694
	public static readonly object _WeatherSizeScale; // 0x698
	public static readonly object _WeatherVelocity; // 0x69C
	public static readonly object _WeatherViewPostion; // 0x6A0
	public static readonly object _WorldPos; // 0x6A4
	public static readonly object _ZTest; // 0x6A8
	public static readonly object _ZTestMode; // 0x6AC
	public static readonly object _ZWrite; // 0x6B0
	public static readonly object _AnimMap; // 0x6B4
	public static readonly object _AlphaGradient; // 0x6B8
	public static readonly object g_RayTracingPreviewShadowMask; // 0x6BC

	// Methods

	// RVA: 0x773B4A8
	private static object .cctor() { }

}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0x773FF48
	private static object Get() { }

	// RVA: 0x774001C
	public object .ctor() { }

}

// Namespace: UnityEngine
public static class CameraExtensions
{

	// Methods

	// RVA: 0x7740158
	public static object GetCameraRendererBundle(object camera) { }

	// RVA: 0x7740284
	public static object GetCameraData(object camera) { }

	// RVA: 0x7740384
	public static object GetWorldData(object camera) { }

	// RVA: 0x77403C0
	public static object GetRenderer(object camera) { }

}

// Namespace: 
public enum ShadowDebugMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Shadow_Cache;
	public const object Shadow_Frame;
	public const object Shadow_Close;
}

// Namespace: UnityEngine.Experimental.Rendering
public class YAGraphicsSetting
{

	// Fields
	public static object renderFlags; // 0x0
	public static object OnlyRenderUI; // 0x4
	public static object HideLingBao; // 0x5
	public static object EnableLightGrid; // 0x6
	public static object ForceJuWaiRenderer; // 0x7
	public static object EnableClearBuffCamera; // 0x8
	public static object ScreenPercentage; // 0xC
	public static object DisableGrabPass; // 0x10
	public static object EnableCiyuanProjectorShadow; // 0x11
	public static object EnableSRPBatching; // 0x12
	public static object EnableCustomRenderList; // 0x13
	public static object EnableImagePostprocessDebug; // 0x14
	public static object s_ShadowDebugMode; // 0x18
	public static object EnableCloseupShadow; // 0x1C
	public static object ForceTAAUScreenPercentage; // 0x1D
	public static object DisableTAAU; // 0x1E

	// Properties
	public static object SupportSimdGroupIntrinsics { get; }

	// Methods

	// RVA: 0x77403DC
	public static object get_SupportSimdGroupIntrinsics() { }

	// RVA: 0x77403E4
	public object .ctor() { }

	// RVA: 0x77403EC
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public enum ClearFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Color;
	public const object Depth;
	public const object Stencil;
	public const object DepthStencil;
	public const object ColorStencil;
	public const object All;
}

// Namespace: UnityEngine.Rendering
public static class CommandBufferExtensions
{

	// Fields
	private static object s_quadMesh; // 0x0
	private static object s_flipQuadMesh; // 0x8
	private static object s_colorBufferLoadActions; // 0x10
	private static object s_colorBufferStoreActions; // 0x18

	// Methods

	// RVA: 0x7740470
	public static object ClearRenderTarget(object cmd, object clearFlag, object clearColor) { }

	// RVA: 0x77404A0
	public static object SetViewportForRTHandle(object cmd, object target) { }

	// RVA: 0x7740538
	private static object SetViewportAndClear(object cmd, object buffer, object clearFlag, object clearColor) { }

	// RVA: 0x7740684
	private static object FixupDepthSlice(object depthSlice, object buffer) { }

	// RVA: 0x7740708
	private static object FixupDepthSlice(object depthSlice, object cubemapFace) { }

	// RVA: 0x7740718
	public static object SetRenderTarget(object cmd, object buffer, object clearFlag, object clearColor, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x7740898
	public static object SetRenderTarget(object cmd, object buffer, object clearFlag, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x7740940
	public static object SetRenderTarget(object cmd, object colorBuffer, object depthBuffer, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x7740E60
	public static object SetRenderTarget(object cmd, object colorBuffer, object depthBuffer, object clearFlag, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x7740B94
	public static object SetRenderTarget(object cmd, object colorBuffer, object depthBuffer, object clearFlag, object clearColor, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x77410C0
	public static object SetRenderTarget(object cmd, object colorBuffer, object depthBuffer, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x7741214
	public static object SetRenderTarget(object cmd, object colorBuffer, object depthBuffer, object clearFlag, object clearColor, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x774135C
	public static object SetRenderTarget(object cmd, object buffer, object loadAction, object storeAction, object clearFlag, object clearColor, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x7741600
	public static object SetRenderTarget(object cmd, object colorBuffer, object colorLoadAction, object colorStoreAction, object depthBuffer, object depthLoadAction, object depthStoreAction, object clearFlag, object clearColor, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x7741500
	public static object SetRenderTarget(object cmd, object buffer, object loadAction, object storeAction, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x77418FC
	public static object SetRenderTarget(object cmd, object colorBuffer, object colorLoadAction, object colorStoreAction, object depthBuffer, object depthLoadAction, object depthStoreAction, object miplevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x7741A54
	public static object SetFbo(object cmd, object fbo, object cbLoadAction, object cbStoreAction, object dsLoadAction, object dsStoreAction, object readOnlyDepth, object readOnlyStencil) { }

	// RVA: 0x7741BCC
	public static object SetFbo(object cmd, object fbo, object cbLoadActions, object cbStoreActions, object dsLoadAction, object dsStoreAction, object readOnlyDepth, object readOnlyStencil) { }

	// RVA: 0x77420E0
	public static object SetRayTracingVectorIntParams(object cmd, object shader, object name, object v) { }

	// RVA: 0x77421A0
	public static object ClearFbo(object cmd, object fbo, object clearDepth, object clearColor, object backgroundColor) { }

	// RVA: 0x7742428
	public static object DispatchCompute1D(object cmd, object shader, object kernel, object width) { }

	// RVA: 0x7742518
	public static object DispatchCompute2D(object cmd, object shader, object kernel, object width, object height) { }

	// RVA: 0x7742628
	public static object DispatchRays(object cmd, object shader, object rayGenName, object shaderPass, object width, object height, object depth, object camera) { }

	// RVA: 0x7742724
	public static object DispatchRays(object cmd, object shader, object rayGenName, object shaderPass, object camera) { }

	// RVA: 0x77428A0
	public static object DrawQuad(object cmd, object mat, object shaderPass, object properties, object flip) { }

	// RVA: 0x7743050
	public static object SetViewProjectionMatrices(object cmd, object cameraData) { }

	// RVA: 0x7743184
	public static object BeginRenderPass(object cmd, object renderContext, object width, object height, object attachments, object samples, object depthAttachmentIndex) { }

	// RVA: 0x77432B0
	public static object EndRenderPass(object cmd, object renderContext) { }

	// RVA: 0x7743318
	public static object BeginSubPass(object cmd, object scriptableRenderContext, object inputAttachments, object outputAttachments, object isDepthReadOnly, object isStencilReadOnly) { }

	// RVA: 0x77433FC
	public static object BeginSubPass(object cmd, object scriptableRenderContext, object outputAttachments, object isDepthReadOnly, object isStencilReadOnly) { }

	// RVA: 0x77434B8
	public static object EndSubPass(object cmd, object scriptableRenderContext) { }

	// RVA: 0x7742C00
	private static object BuildDrawQuadMesh(object flip) { }

	// RVA: 0x7743578
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public enum YABlendMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object Lerp;
	public const object AlphaAdd;
	public const object SoftAdd;
	public const object Add;
	public const object Multiply;
	public const object Premultiply;
	public const object Customization;
	public const object CustomizationAlpha;
}

// Namespace: UnityEngine.Rendering
public enum PackingRules
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Exact;
	public const object Aggressive;
}

// Namespace: UnityEngine.Rendering
public enum FieldPacking
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoPacking;
	public const object R11G11B10;
	public const object PackedFloat;
	public const object PackedUint;
}

// Namespace: UnityEngine.Rendering
public enum FieldPrecision
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Half;
	public const object Real;
	public const object Default;
}

// Namespace: UnityEngine.Rendering
public class GenerateHLSL
{

	// Fields
	public object packingRules; // 0x8
	public object containsPackedFields; // 0xC
	public object needAccessors; // 0xD
	public object needSetters; // 0xE
	public object needParamDebug; // 0xF
	public object paramDefinesStart; // 0x10
	public object omitStructDeclaration; // 0x14
	public object generateCBuffer; // 0x15
	public object constantRegister; // 0x18
	public object sourcePath; // 0x20

	// Methods

	// RVA: 0x7743618
	public object .ctor(object rules, object needAccessors, object needSetters, object needParamDebug, object paramDefinesStart, object omitStructDeclaration, object containsPackedFields, object generateCBuffer, object constantRegister, object sourcePath) { }

}

// Namespace: UnityEngine.Rendering
public class SurfaceDataAttributes
{

	// Fields
	public object displayNames; // 0x8
	public object isDirection; // 0x10
	public object sRGBDisplay; // 0x11
	public object precision; // 0x14
	public object checkIsNormalized; // 0x18
	public object preprocessor; // 0x20

	// Methods

	// RVA: 0x77436B8
	public object .ctor(object displayName, object isDirection, object sRGBDisplay, object precision, object checkIsNormalized, object preprocessor) { }

	// RVA: 0x7743784
	public object .ctor(object displayNames, object isDirection, object sRGBDisplay, object precision, object checkIsNormalized, object preprocessor) { }

}

// Namespace: UnityEngine.Rendering
public class HLSLArray
{

	// Fields
	public object arraySize; // 0x8
	public object elementType; // 0x10

	// Methods

	// RVA: 0x77437F0
	public object .ctor(object arraySize, object elementType) { }

}

// Namespace: UnityEngine.Rendering
public class PackingAttribute
{

	// Fields
	public object displayNames; // 0x8
	public object range; // 0x10
	public object packingScheme; // 0x18
	public object offsetInSource; // 0x1C
	public object sizeInBits; // 0x20
	public object isDirection; // 0x24
	public object sRGBDisplay; // 0x25
	public object checkIsNormalized; // 0x26
	public object preprocessor; // 0x28

	// Methods

	// RVA: 0x774382C
	public object .ctor(object displayNames, object packingScheme, object bitSize, object offsetInSource, object minValue, object maxValue, object isDirection, object sRGBDisplay, object checkIsNormalized, object preprocessor) { }

	// RVA: 0x7743924
	public object .ctor(object displayName, object packingScheme, object bitSize, object offsetInSource, object minValue, object maxValue, object isDirection, object sRGBDisplay, object checkIsNormalized, object preprocessor) { }

}

// Namespace: UnityEngine.Rendering
public struct ShaderGenUInt4
{
}

// Namespace: UnityDenoiserPlugin
public enum DenoiserType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OptiX;
	public const object OIDN;
}

// Namespace: UnityDenoiserPlugin
public struct DenoiserConfig
{

	// Fields
	public object imageWidth; // 0xFFFFFFFFFFFFFFF8
	public object imageHeight; // 0xFFFFFFFFFFFFFFFC
	public object guideAlbedo; // 0x0
	public object guideNormal; // 0x4
	public object temporalMode; // 0x8
	public object cleanAux; // 0xC
	public object prefilterAux; // 0x10

	// Methods

	// RVA: 0x7743A58
	public object Equals(object cfg) { }

}

// Namespace: 
private struct RenderEventData
{

	// Fields
	public object denoiser; // 0xFFFFFFFFFFFFFFF8
	public object albedo; // 0x0
	public object normal; // 0x8
	public object flow; // 0x10
	public object color; // 0x18
	public object output; // 0x20
}

// Namespace: 
private class RenderEventDataArray
{

	// Fields
	private const object ElementCount;
	private object m_index; // 0x8
	private object m_array; // 0x10

	// Methods

	// RVA: 0x7743CFC
	public object .ctor() { }

	// RVA: -1
	public object SetData(object data) { }

	// RVA: 0x77443B0
	public object Dispose() { }

}

// Namespace: UnityDenoiserPlugin
internal class DenoiserPluginWrapper
{

	// Fields
	public object Type; // 0x8
	public object Config; // 0xC
	private object m_ptr; // 0x28
	private object m_eventData; // 0x30

	// Methods

	// RVA: 0x7743B50
	public object .ctor(object type, object cfg) { }

	// RVA: 0x7743F60
	public object Render(object commands, object color, object output, object albedo, object normal, object motion) { }

	// RVA: 0x77441F0
	public object Dispose() { }

	// RVA: 0x7743C54
	private static extern object CreateDenoiser(object type, object cfg) { }

	// RVA: 0x7744308
	private static extern object DestroyDenoiser(object type, object ptr) { }

	// RVA: 0x774416C
	private static extern object GetRenderEventFunc() { }

}

// Namespace: MessyLight
public class BakeInfo
{

	// Fields
	public object removeVerticalOverlappingSM; // 0x8
	public object resultDirectory; // 0x10
	public object generateUV2; // 0x18
	public object texelsPerUnit; // 0x1C
	public object minLightmapResolution; // 0x20
	public object maxTexelsPerUnit; // 0x24
	public object maxLightmapResolution; // 0x28
	public object enableMaxNormalDeviation; // 0x2C
	public object normalDeviationWeight; // 0x30
	public object generateUV2ByUV1; // 0x34
	public object manualUV2; // 0x35
	public object manualLightmapCount; // 0x38
	public object lightmapSize; // 0x3C
	public object removeVerticalOverlapping; // 0x40

	// Methods

	// RVA: 0x77444A0
	public object Clone() { }

	// RVA: 0x7744590
	public object .ctor() { }

}

// Namespace: MessyLight
public interface IGIVolumeSettings
{

	// Methods

	// RVA: -1
	public abstract object OnInit(object hostVolume) { }

}

// Namespace: MessyLight
public class LightmapSettings
{

	// Fields
	public object enableBakeLightmap; // 0x8
	public object lightmapQuality; // 0xC
	public object lightmapTexelPerUnit; // 0x10
	public object lightmapSize; // 0x14
	public object useIrradianceCaching; // 0x18
	public object useLightBVH; // 0x19
	public object lightmapCombinedWithShadowmask; // 0x1A
	public object globalMinLightmapResolution; // 0x1C
	public object globalMaxLightmapResolution; // 0x20
	public object diffuseBoost; // 0x24
	public object forceSingleLightmap; // 0x28
	public object lightmapType; // 0x2C
	public object useNormalMap; // 0x30
	public object lightmapEnvmapMaxValue; // 0x34
	public object manualUV2; // 0x38
	public object verticalDisplacement; // 0x3C
	public object computeAO; // 0x40
	public object maxOcclusionDistance; // 0x44
	public object occlusionExponent; // 0x48
	public object fullyOccludedSamplesFraction; // 0x4C
	public object nonOpaqueWeight; // 0x50
	public object extraLightmapSettings; // 0x58
	private object m_hostVolume; // 0x60

	// Methods

	// RVA: 0x77445F0
	public object LightmapLayoutVisualization() { }

	// RVA: 0x77445F4
	private object OnAOSettingChanged() { }

	// RVA: 0x77445F8
	public object OnInit(object hostVolume) { }

	// RVA: 0x7744600
	public object Clone() { }

	// RVA: 0x7744694
	public object .ctor() { }

}

// Namespace: MessyLight
public class VLMSettings
{

	// Fields
	public object enableBakeVLM; // 0x8
	public object raySampleNumVLM; // 0xC
	public object volumeLightMapCellSize; // 0x10
	public object vlmDiffuseBoost; // 0x14
	public object vlmEnvmapMaxValue; // 0x18
	public object vlmBlurWeight; // 0x1C
	public object vlmSampleOffset; // 0x20
	public object vlmComputeAO; // 0x24
	public object vlmMaxOcclusionDistance; // 0x28
	public object vlmOcclusionExponent; // 0x2C
	public object vlmFullyOccludedSamplesFraction; // 0x30
	public object vlmNonOpaqueWeight; // 0x34
	private object m_hostVolume; // 0x38

	// Methods

	// RVA: 0x7744760
	private object OnAOSettingChanged() { }

	// RVA: 0x7744764
	private object OnVLMSampleOffsetChanged() { }

	// RVA: 0x7744948
	public object OnInit(object hostVolume) { }

	// RVA: 0x7744BB0
	public object Clone() { }

	// RVA: 0x7744C44
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__9_0; // 0x8

	// Methods

	// RVA: 0x77451FC
	private static object .cctor() { }

	// RVA: 0x774525C
	public object .ctor() { }

	// RVA: 0x7745264
	internal object <EnableShadowmask>b__9_0(object v) { }

}

// Namespace: MessyLight
public class ShadowmaskSettings
{

	// Fields
	public object enableBakeShadowmask; // 0x8
	public object raySampleNumShadowmask; // 0xC
	public object shadowmaskSize; // 0x10
	public object shadowmaskTexelPerUnit; // 0x14
	private object enableShadowmask; // 0x18
	private object m_hostVolume; // 0x20

	// Methods

	// RVA: 0x7744C84
	public object DisableShadowmask() { }

	// RVA: 0x774512C
	public object EnableShadowmask() { }

	// RVA: 0x7745134
	private object ShadowMaskLayoutVisualization() { }

	// RVA: 0x7744C8C
	private object EnableShadowmask(object value) { }

	// RVA: 0x7745138
	public object OnInit(object hostVolume) { }

	// RVA: 0x7745140
	public object Clone() { }

	// RVA: 0x77451D4
	public object .ctor() { }

}

// Namespace: MessyLight
public class StaticShadowDepthMapSettings
{

	// Fields
	public object enableBakeStaticShadowDepthMap; // 0x8
	public object staticShadowDepthMapSize; // 0xC

	// Methods

	// RVA: 0x774532C
	public object OnInit(object hostVolume) { }

	// RVA: 0x7745330
	public object .ctor() { }

}

// Namespace: MessyLight
public class MLBakingResult
{

	// Fields
	public object lightmapTexture2Ds; // 0x8
	public object vlmTextures; // 0x10
	public object shadowmaskTexture; // 0x18
	private object m_hostVolume; // 0x20

	// Methods

	// RVA: 0x7745340
	public object OnInit(object hostVolume) { }

	// RVA: 0x7745348
	private object IsShow(object listName) { }

	// RVA: 0x77454D4
	public object .ctor() { }

}

// Namespace: MessyLight
public class AdvancedSettings
{

	// Fields
	public object developMode; // 0x8

	// Methods

	// RVA: 0x7745584
	public object GenerateRendererCode() { }

	// RVA: 0x7745588
	public object OnInit(object hostVolume) { }

	// RVA: 0x774558C
	public object .ctor() { }

}

// Namespace: MessyLight
public class ExtraLightmapSettings
{

	// Methods

	// RVA: 0x7745594
	public object OnInit(object hostVolume) { }

	// RVA: 0x7745598
	public virtual object ShowOnProjectType(object projectType) { }

	// RVA: 0x77455A0
	public object .ctor() { }

}

// Namespace: MessyLight
public class JsonSerializeProperty<T0>
{

	// Fields
	private object m_jsonData; // 0x0
	private object m_version; // 0x0
	private object m_data; // 0x0

	// Properties
	public object Data { get; set; }

	// Methods

	// RVA: -1
	public object get_Data() { }

	// RVA: -1
	public object set_Data(object value) { }

	// RVA: -1
	private object SetData(object value) { }

	// RVA: -1
	private object GetData() { }

	// RVA: -1
	private object Init() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass17_0
{

	// Fields
	public object applierID; // 0x8
	public object type; // 0x10
	public object foundApplier; // 0x18

	// Methods

	// RVA: 0x7747020
	public object .ctor() { }

	// RVA: 0x77482FC
	internal object <FindApplier>b__0(object applier) { }

}

// Namespace: 
private sealed class <>c__DisplayClass18_0
{

	// Fields
	public object giVolume; // 0x8
	public object foundAppliers; // 0x10

	// Methods

	// RVA: 0x774713C
	public object .ctor() { }

	// RVA: 0x7748354
	internal object <FindAppliers>b__0(object applier) { }

}

// Namespace: 
private sealed class <>c__DisplayClass20_0
{

	// Fields
	public object type; // 0x8
	public object foundAppliers; // 0x10

	// Methods

	// RVA: 0x774725C
	public object .ctor() { }

	// RVA: 0x77485F4
	internal object <FindAppliers>b__0(object applier) { }

}

// Namespace: 
private sealed class <>c__DisplayClass21_0
{

	// Fields
	public object predicate; // 0x8
	public object foundAppliers; // 0x10

	// Methods

	// RVA: 0x7747378
	public object .ctor() { }

	// RVA: 0x7748734
	internal object <FindAppliers>b__0(object applier) { }

}

// Namespace: 
private sealed class <>c__DisplayClass22_0
{

	// Fields
	public object renderer; // 0x8

	// Methods

	// RVA: 0x7747444
	public object .ctor() { }

	// RVA: 0x7748880
	internal object <FindAppliers>b__0(object applier) { }

}

// Namespace: 
private sealed class <>c__DisplayClass23_0
{

	// Fields
	public object foundAppliers; // 0x8

	// Methods

	// RVA: 0x7747558
	public object .ctor() { }

	// RVA: 0x77488D4
	internal object <FindAppliers>b__0(object applier) { }

}

// Namespace: 
private sealed class <>c__DisplayClass24_0
{

	// Fields
	public object applier; // 0x8
	public object exist; // 0x10

	// Methods

	// RVA: 0x7747630
	public object .ctor() { }

	// RVA: 0x77489F4
	internal object <IsExistApplier>b__0(object item) { }

}

// Namespace: MessyLight
public class ApplierList
{

	// Fields
	public object m_LightmapAppliers2D; // 0x8
	public object m_VLMAppliers; // 0x10
	public object m_CPUProbeAppliers; // 0x18
	public object m_DynamicLightAppliers; // 0x20
	public object m_ShadowmaskAppliers; // 0x28
	public object m_StaticShadowDepthMapAppliers; // 0x30

	// Methods

	// RVA: 0x77455A8
	public object Init(object lightmapApplier2D, object vlmAppliers, object cpuProbeAppliers, object dynamicLightingAppliers, object shadowmaskAppliers) { }

	// RVA: 0x77456A4
	public object OnEnable() { }

	// RVA: 0x7745D84
	public object Update() { }

	// RVA: 0x7745E08
	public object LateUpdate() { }

	// RVA: 0x7745E8C
	public object OnDisable() { }

	// RVA: 0x7745F10
	public object AddApplier(object applier) { }

	// RVA: 0x7746508
	public object AddOrCreateApplier(object type, object applierID, object giVolume) { }

	// RVA: 0x7746888
	public object RemoveApplier(object applier) { }

	// RVA: 0x7746C9C
	public object RemoveApplier(object type, object applierID) { }

	// RVA: 0x7746D64
	public object RemoveApplier(object giVolume) { }

	// RVA: 0x7746DE8
	public object ClearAppliers() { }

	// RVA: 0x77467A8
	public object FindApplier(object type, object applierID) { }

	// RVA: 0x7747028
	public object FindAppliers(object giVolume) { }

	// RVA: 0x7747144
	public object FindOrCreateApplier(object type, object applierID, object giVolume, object create) { }

	// RVA: 0x7747148
	public object FindAppliers(object type) { }

	// RVA: 0x7747264
	public object FindAppliers(object predicate) { }

	// RVA: 0x7747380
	public object FindAppliers(object renderer) { }

	// RVA: 0x774744C
	public object FindAppliers() { }

	// RVA: 0x7747560
	public object IsExistApplier(object applier) { }

	// RVA: 0x7747638
	public object EnableApplier(object type, object applierID) { }

	// RVA: 0x774774C
	public object DisableApplier(object type, object applierID) { }

	// RVA: 0x77477A0
	public object AddVLMRenderer(object renderer) { }

	// RVA: 0x7747CEC
	private object ApplierFilter(object applier) { }

	// RVA: 0x7745728
	private object LoopAppliers(object action) { }

	// RVA: 0x7746428
	private object Refresh() { }

	// RVA: 0x7747EA4
	public object .ctor() { }

	// RVA: 0x774807C
	private object <OnEnable>b__7_0(object applier) { }

	// RVA: 0x774811C
	private object <Update>b__8_0(object applier) { }

	// RVA: 0x77481BC
	private object <LateUpdate>b__9_0(object applier) { }

	// RVA: 0x774825C
	private object <OnDisable>b__10_0(object applier) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	public const object Begin;
	public const object Count;
	private object m_appliers; // 0xFFFFFFFFFFFFFFF8
	private object m_applier; // 0x0
	private object m_index; // 0x8

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x774A948
	public object .ctor(object appliers) { }

	// RVA: 0x774AC54
	public object Dispose() { }

	// RVA: 0x77493CC
	public object MoveNext() { }

	// RVA: 0x774ACC4
	public object Reset() { }

	// RVA: 0x77492EC
	public object get_Current() { }

	// RVA: 0x774ACE4
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: MessyLight
public class Appliers
{

	// Fields
	private object m_lightmapApplier2D; // 0x8
	private object m_vlmApplier; // 0x10
	private object m_cpuProbeApplier; // 0x18
	private object m_dynamicLightApplier; // 0x20
	private object m_shadowmaskApplier; // 0x28
	private object m_staticShadowDepthMapApplier; // 0x30

	// Properties
	public object Item { get; set; }
	public object LightmapApplier2D { get; }
	public object VlmApplier { get; }
	public object CPUProbeApplier { get; }
	public object DynamicLightApplier { get; }
	public object ShadowmaskApplier { get; }

	// Methods

	// RVA: 0x7748A10
	public object get_Item(object type) { }

	// RVA: 0x7748AC8
	public object set_Item(object type, object value) { }

	// RVA: 0x7748E64
	public object get_LightmapApplier2D() { }

	// RVA: 0x77448F4
	public object get_VlmApplier() { }

	// RVA: 0x7748EB8
	public object get_CPUProbeApplier() { }

	// RVA: 0x7748F0C
	public object get_DynamicLightApplier() { }

	// RVA: 0x77452D8
	public object get_ShadowmaskApplier() { }

	// RVA: 0x7748F60
	public object Enable(object type) { }

	// RVA: 0x774906C
	public object Disable(object type) { }

	// RVA: 0x77490C0
	public object OnEnable() { }

	// RVA: 0x7749434
	public object Update() { }

	// RVA: 0x774964C
	public object LateUpdate() { }

	// RVA: 0x7749864
	public object OnDisable() { }

	// RVA: 0x7749A7C
	public object Refresh() { }

	// RVA: 0x7749AA0
	public object RemoveApplier(object applier) { }

	// RVA: 0x7749B44
	public object RemoveApplier(object type) { }

	// RVA: 0x7749BAC
	public object FindApplier(object type) { }

	// RVA: 0x7749BB0
	public object CreateApplier(object type, object giVolume) { }

	// RVA: 0x7749F0C
	public object FindOrCreateApplier(object type, object giVolume) { }

	// RVA: 0x7749F64
	public object ClearAllAppliers() { }

	// RVA: 0x774A344
	public object Contains(object target) { }

	// RVA: 0x7749358
	private object ApplierFilter(object applier) { }

	// RVA: 0x774A680
	public object SetApplier(object applier) { }

	// RVA: -1
	private object SetApplier(object list, object applier) { }

	// RVA: 0x77492D8
	public object GetEnumerator() { }

	// RVA: 0x774A958
	private object System.Collections.Generic.IEnumerable<MessyLight.MessyApplier>.GetEnumerator() { }

	// RVA: 0x774A9C4
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x774AA30
	public object .ctor() { }

}

// Namespace: MessyLight
public static class AppliersExtension
{

	// Methods

	// RVA: -1
	public static object FirstOrDefaultApplier(object list) { }

}

// Namespace: MessyLight
public class BakedLightModifier
{

	// Fields
	public object lightmapIntensity; // 0x18
	public object volumetricLightmapIntensity; // 0x1C

	// Methods

	// RVA: 0x774ACF0
	public object .ctor() { }

}

// Namespace: MessyLight
public class BakeProperties
{

	// Fields
	public object GIRepresentation; // 0x18
	public object GIMode; // 0x1C
	public object CPUProbeUpdateMode; // 0x20
	public object CPUProbeAnchorMode; // 0x24
	public object CPUProbeAnchorBoundSize; // 0x28
	public object CPUProbeAnchorOffset; // 0x34
	public object CPUProbeDelayTime; // 0x40
	public object seamStitching; // 0x44
	public object manualLightmapIndex; // 0x48
	public object overrideTileSize; // 0x4C
	public object tileWidth; // 0x50
	public object tileHeight; // 0x54
	public object receiveSM; // 0x58
	public object SMMode; // 0x5C
	public object SMSeamStitching; // 0x60
	public object SMOverrideTileSize; // 0x61
	public object SMTileWidth; // 0x64
	public object SMTileHeight; // 0x68
	public object SMManualLightmapIndex; // 0x6C

	// Methods

	// RVA: 0x774AD00
	public object .ctor() { }

}

// Namespace: MessyLight
public class MaterialPropertyBlockForAnimatorRepairer
{

	// Methods

	// RVA: 0x774AD18
	public object OnEnable() { }

	// RVA: 0x774AE20
	public object .ctor() { }

}

// Namespace: MessyLight
public class DistanceFieldVisualizer
{

	// Fields
	private static object sMaterial; // 0x0
	public object mesh; // 0x18
	public object distanceField; // 0x20

	// Methods

	// RVA: 0x774AE28
	public object Render(object context, object cmd, object cameraData, object rt) { }

	// RVA: 0x774BADC
	public object .ctor() { }

}

// Namespace: MessyLight
public class DynamicLighting
{

	// Fields
	public object dynamicLuminanceRatio; // 0x18
	public object conservativeRatio; // 0x1C
	public object dynamicLightIntensity; // 0x20
	public object isLightGroup; // 0x24
	public object IsBaked; // 0x25

	// Methods

	// RVA: 0x774BAE4
	private object RefreshIntensityDiff(object intensityDiff) { }

	// RVA: 0x774C0C8
	public object Update() { }

	// RVA: 0x774C0D0
	public object OnDisable() { }

	// RVA: 0x774C0D8
	public object .ctor() { }

}

// Namespace: MessyLight
public class ReceiverMeshDataAsset
{

	// Fields
	public object oneLightVertices; // 0x10
	public object twoLightVertices; // 0x18
	public object threeLightVertices; // 0x20

	// Methods

	// RVA: 0x774C0EC
	public object .ctor() { }

}

// Namespace: MessyLight
public class ReceiverMeshData
{

	// Fields
	public object oneLightVertices; // 0x8
	public object twoLightVertices; // 0x10
	public object threeLightVertices; // 0x18
	public object asset; // 0x20
	public object meshes; // 0x28
	public object computeBuffer; // 0x30

	// Properties
	public object OneLightVertices { get; }
	public object TwoLightVertices { get; }
	public object ThreeLightVertices { get; }

	// Methods

	// RVA: 0x774C0F4
	public object Release() { }

	// RVA: 0x774C124
	public object get_OneLightVertices() { }

	// RVA: 0x774C254
	public object get_TwoLightVertices() { }

	// RVA: 0x774C384
	public object get_ThreeLightVertices() { }

	// RVA: 0x774C4B4
	public object CreateOneLightMesh() { }

	// RVA: 0x774CFD8
	public object CreateTwoLightMesh() { }

	// RVA: 0x774D8BC
	public object CreateThreeLightMesh() { }

	// RVA: 0x774E3A8
	public object .ctor() { }

}

// Namespace: MessyLight
public class ReceiverMesh
{

	// Fields
	public const object DefaultFrameGroup;
	public object lightIndices; // 0x8
	public object meshData; // 0x10
	public object frameGroup; // 0x18
	public object LODLevel; // 0x1C

	// Methods

	// RVA: 0x774E3B0
	public object Release() { }

	// RVA: 0x774E3E4
	public object .ctor() { }

}

// Namespace: MessyLight
public struct OneLightVertex
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object u; // 0x0
	public object v; // 0x4
	public object dstIrradiance; // 0x8

	// Methods

	// RVA: 0x774E3F4
	public object .ctor(object px, object py, object texWidth, object texHeight) { }

	// RVA: 0x774E46C
	public object Pack() { }

}

// Namespace: MessyLight
public struct PackedOneLightVertex
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
}

// Namespace: MessyLight
public struct TwoLightVertex
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object u; // 0x0
	public object v; // 0x4
	public object dstIrradiance0; // 0x8
	public object dstIrradiance1; // 0xC

	// Methods

	// RVA: 0x774E55C
	public object .ctor(object px, object py, object texWidth, object texHeight) { }

	// RVA: 0x774E5D4
	public object Pack() { }

}

// Namespace: MessyLight
public struct PackedTwoLightVertex
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
}

// Namespace: MessyLight
public struct ThreeLightVertex
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object u; // 0x0
	public object v; // 0x4
	public object dstIrradiance0; // 0x8
	public object dstIrradiance1; // 0xC
	public object dstIrradiance2; // 0x10

	// Methods

	// RVA: 0x774E6F4
	public object .ctor(object px, object py, object texWidth, object texHeight) { }

	// RVA: 0x774E774
	public object Pack() { }

}

// Namespace: MessyLight
public struct PackedThreeLightVertex
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public object w; // 0x4
}

// Namespace: 
private struct FrameState
{

	// Fields
	private object item0; // 0xFFFFFFFFFFFFFFF8
	private object item1; // 0xFFFFFFFFFFFFFFFC
	private object item2; // 0x0
	private object item3; // 0x4

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: 0x77515DC
	public object get_Item(object index) { }

	// RVA: 0x77516CC
	public object set_Item(object index, object value) { }

	// RVA: 0x7751624
	private object GetValue(object index) { }

	// RVA: 0x775170C
	private object SetValue(object index, object value) { }

	// RVA: 0x77514D0
	public object Contain(object frame) { }

	// RVA: 0x774F3C0
	public object Empty() { }

	// RVA: 0x7751914
	public object ActiveNum() { }

}

// Namespace: 
private struct FrameGroupAllocator
{

	// Fields
	public object currentFrameState; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x774F180
	public object AllocateFrames(object delta) { }

	// RVA: 0x774F3B4
	public object AllocateAllFrames() { }

	// RVA: 0x775197C
	private object Pop(object num) { }

	// RVA: 0x774F13C
	public object AllUpdated() { }

	// RVA: 0x774F178
	public object Reset() { }

}

// Namespace: MessyLight
public class DynamicLightingLightmapImpl
{

	// Fields
	protected object mParent; // 0x8
	private object mCmdBuffer; // 0x10
	private object mUpdateLightmapMaterial; // 0x18
	private object mUpdateLightmapComputeShader; // 0x20
	private object mOneLightKernel; // 0x28
	private object mTwoLightKernel; // 0x2C
	private object mThreeLightKernel; // 0x30
	private object mFrameGroupAllocator; // 0x34
	public object DebugFrameAllocationInEditorMode; // 0x44
	private static object _UseComputeShader; // 0x0
	private static object UseComputeShaderInitialized; // 0x1

	// Properties
	public static object UseComputeShader { get; }

	// Methods

	// RVA: 0x774CD98
	public static object get_UseComputeShader() { }

	// RVA: 0x774E8AC
	public object .ctor(object parent) { }

	// RVA: 0x774EC30
	public object Begin() { }

	// RVA: 0x774F400
	private object ComputePipelineImpl(object frames) { }

	// RVA: 0x7750668
	private object GraphicsPipelineImpl(object frames) { }

	// RVA: 0x7751520
	public object End() { }

	// RVA: 0x77515D8
	public object Dispose() { }

}

// Namespace: MessyLight
public struct ProbeReceiver
{

	// Fields
	public object dstIrradiance0; // 0xFFFFFFFFFFFFFFF8
	public object dstIrradiance1; // 0xFFFFFFFFFFFFFFFC
	public object dstIrradiance2; // 0x0
	public object index0; // 0x4
	public object index1; // 0x5
	public object index2; // 0x6
	public object pad; // 0x7
}

// Namespace: MessyLight
public class ProbeReceiverAsset
{

	// Fields
	public object locations; // 0x8
	public object receivers; // 0x10

	// Methods

	// RVA: 0x7751B4C
	public object .ctor() { }

}

// Namespace: MessyLight
public class DynamicLightingProbeImpl
{

	// Fields
	private object mParent; // 0x8
	private object mProbeApplier; // 0x10
	private object mProbeReceiverAsset; // 0x18
	private object mUpdateQueue; // 0x20
	private object mProbeReceiverLookup; // 0x28
	private object mSrcProbeData; // 0x30
	private object mDstProbeData; // 0x38

	// Methods

	// RVA: 0x7751C18
	public object .ctor(object parent, object isFallbackProbe) { }

	// RVA: 0x7751F04
	public object Begin() { }

	// RVA: 0x7752B14
	public object End() { }

	// RVA: 0x7752B18
	private object UnpackR8ToUFLOAT(object r) { }

	// RVA: 0x7752A68
	private object RGBMDecode(object rgbm) { }

}

// Namespace: MessyLight
public struct OneLightReceiver
{

	// Fields
	public object xyz; // 0xFFFFFFFFFFFFFFF8
	public object dstIrradiance; // 0x4

	// Methods

	// RVA: 0x7752B30
	public object .ctor(object px, object py, object pz) { }

}

// Namespace: MessyLight
public struct PackedOneLightReceiver
{

	// Fields
	public object xyz; // 0xFFFFFFFFFFFFFFF8
	public object dstIrradiance; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x7752BC0
	public static object SizeInBytes() { }

}

// Namespace: MessyLight
public struct TwoLightReceiver
{

	// Fields
	public object xyz; // 0xFFFFFFFFFFFFFFF8
	public object dstIrradiance0; // 0x4
	public object dstIrradiance1; // 0x8

	// Methods

	// RVA: 0x7752BC8
	public object .ctor(object px, object py, object pz) { }

}

// Namespace: MessyLight
public struct PackedTwoLightReceiver
{

	// Fields
	public object xyz; // 0xFFFFFFFFFFFFFFF8
	public object dstIrradiance0; // 0xFFFFFFFFFFFFFFFC
	public object dstIrradiance1; // 0x0

	// Methods

	// RVA: 0x7752C60
	public static object SizeInBytes() { }

}

// Namespace: MessyLight
public struct ThreeLightReceiver
{

	// Fields
	public object xyz; // 0xFFFFFFFFFFFFFFF8
	public object dstIrradiance0; // 0x4
	public object dstIrradiance1; // 0x8
	public object dstIrradiance2; // 0xC

	// Methods

	// RVA: 0x7752C68
	public object .ctor(object px, object py, object pz) { }

}

// Namespace: MessyLight
public struct PackedThreeLightReceiver
{

	// Fields
	public object xyz; // 0xFFFFFFFFFFFFFFF8
	public object dstIrradiance0; // 0xFFFFFFFFFFFFFFFC
	public object dstIrradiance1; // 0x0
	public object dstIrradiance2; // 0x4

	// Methods

	// RVA: 0x7752D00
	public static object SizeInBytes() { }

}

// Namespace: MessyLight
public class OneLightVLMReceiverAsset
{

	// Fields
	public object receivers; // 0x8
	public object lightIndices; // 0x10
	public object frameGroup; // 0x18

	// Methods

	// RVA: 0x7752D08
	public object .ctor() { }

}

// Namespace: MessyLight
public class TwoLightVLMReceiverAsset
{

	// Fields
	public object receivers; // 0x8
	public object lightIndices; // 0x10
	public object frameGroup; // 0x18

	// Methods

	// RVA: 0x7752D10
	public object .ctor() { }

}

// Namespace: MessyLight
public class ThreeLightVLMReceiverAsset
{

	// Fields
	public object receivers; // 0x8
	public object lightIndices; // 0x10
	public object frameGroup; // 0x18

	// Methods

	// RVA: 0x7752D18
	public object .ctor() { }

}

// Namespace: 
private struct FrameState
{

	// Fields
	private object item0; // 0xFFFFFFFFFFFFFFF8
	private object item1; // 0xFFFFFFFFFFFFFFFC
	private object item2; // 0x0
	private object item3; // 0x4
	private object item4; // 0x8
	private object item5; // 0xC
	private object item6; // 0x10
	private object item7; // 0x14

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: 0x7755370
	public object get_Item(object index) { }

	// RVA: 0x7755560
	public object set_Item(object index, object value) { }

	// RVA: 0x7755408
	private object GetValue(object index) { }

	// RVA: 0x77555F0
	private object SetValue(object index, object value) { }

	// RVA: 0x77550B4
	public object Contain(object frame) { }

	// RVA: 0x7755034
	public object Empty() { }

	// RVA: 0x7755A28
	public object ActiveNum() { }

}

// Namespace: 
private struct FrameGroupAllocator
{

	// Fields
	public object currentFrameState; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x7754B7C
	public object AllocateFrames(object delta) { }

	// RVA: 0x7755028
	public object AllocateAllFrames() { }

	// RVA: 0x7755B00
	private object Pop(object num) { }

	// RVA: 0x7754B04
	public object AllUpdated() { }

	// RVA: 0x7754B70
	public object Reset() { }

}

// Namespace: MessyLight
public class DynamicLightingVolumetricLightmapImpl
{

	// Fields
	private object mParent; // 0x8
	private object mCmdBuffer; // 0x10
	private object mShader; // 0x18
	private object mOneLightKernel; // 0x20
	private object mTwoLightKernel; // 0x24
	private object mThreeLightKernel; // 0x28
	private object mOneLightComputeBuffers; // 0x30
	private object mTwoLightComputeBuffers; // 0x38
	private object mThreeLightComputeBuffers; // 0x40
	private object mFrameGroupAllocator; // 0x48

	// Methods

	// RVA: 0x7752D20
	public object .ctor(object parent) { }

	// RVA: 0x7753630
	public object Begin() { }

	// RVA: 0x7755154
	public object End() { }

	// RVA: 0x7753590
	private static object FindComputeShaderByPath(object resourceRelativePath) { }

	// RVA: 0x775520C
	public object Dispose() { }

}

// Namespace: MessyLight
public class EmissiveSync
{

	// Fields
	private object mEmissiveProp; // 0x18

	// Methods

	// RVA: 0x7755DF8
	private object Update() { }

	// RVA: 0x7756008
	public object .ctor() { }

}

// Namespace: MessyLight
public static class ExtensionMethod
{

	// Methods

	// RVA: -1
	public static object ResizeList(object list, object size, object element) { }

	// RVA: -1
	public static object GetOrAddComponent(object obj) { }

	// RVA: -1
	public static object DestroyComponent(object obj) { }

	// RVA: 0x775606C
	public static object GetEnumDescription(object en) { }

	// RVA: 0x7756284
	public static object GetEnumDescriptions(object en) { }

	// RVA: -1
	public static object DeepClone(object obj) { }

}

// Namespace: MessyLight
public class GenerateUV2ForBuiltinMesh
{

	// Methods

	// RVA: 0x77565A4
	private static object .cctor() { }

	// RVA: 0x77565A8
	public static object Generate() { }

	// RVA: 0x7756840
	public object .ctor() { }

}

// Namespace: MessyLight
public class GIPTexture
{

	// Fields
	public object encodeScale; // 0x10
	public object encodeAdd; // 0x1C
	public object encodeMulCoeff; // 0x28
	public object encodeAddCoeff; // 0x34
	public object encodeMinLuminance; // 0x40
	public object encodeMaxLuminance; // 0x44
	public object unityTexture; // 0x48
	public object dimension; // 0x50
	public object dynamicRangeMin; // 0x54
	public object dynamicRangeMax; // 0x60

	// Methods

	// RVA: 0x7756848
	public object .ctor() { }

}

// Namespace: MessyLight
public interface GIResultInterface
{
}

// Namespace: MessyLight
public enum BakingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Lightmap;
	public const object VLM;
	public const object CPUProbe;
	public const object Shadowmask;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__67_0; // 0x8

	// Methods

	// RVA: 0x77585CC
	private static object .cctor() { }

	// RVA: 0x775862C
	public object .ctor() { }

	// RVA: 0x7758634
	internal object <Check>b__67_0(object item) { }

}

// Namespace: MessyLight
public class GIVolume
{

	// Fields
	public object LightmapSettings; // 0x18
	public object VlmSettings; // 0x20
	public object ShadowmaskSettings; // 0x28
	public object StaticShadowDepthMapSettings; // 0x30
	public object excludedList; // 0x38
	public object Appliers; // 0x40
	public object AdvancedSettings; // 0x48
	private object m_guid; // 0x50
	private object m_giVolumeGUID; // 0x58
	private object m_version; // 0x68
	private object m_involvedInBaking; // 0x6C
	private object lightmapApplierIndex; // 0x70
	private object vlmApplierIndex; // 0x74
	private object cpuProbeApplierIndex; // 0x78
	private object shadowmaskApplierIndex; // 0x7C
	private object dynamicLightingApplierIndex; // 0x80
	public object lightmapApplierID; // 0x88
	public object vlmApplierID; // 0x90
	public object cpuProbeApplierID; // 0x98
	public object shadowmaskApplierID; // 0xA0
	public object dynamicLightingApplierID; // 0xA8
	public object staticShadowDepthMapApplierID; // 0xB0
	public object flag; // 0xB8
	private object m_BakingType; // 0xBC
	private object m_BoundForLightmap; // 0xC0
	private object m_BoundForVLM; // 0xC1
	private object m_BoundForCPUProbe; // 0xC2
	private object m_BoundForShadowmask; // 0xC3
	private object m_BoundForDynamicBaking; // 0xC4
	private object m_BoundForStaticShadowDepthMap; // 0xC5
	private object m_boxCollider; // 0xC8
	public object hasChanged; // 0xD0
	private object m_cachedBounds; // 0xD4

	// Properties
	public object GUID { get; }
	public object version { get; set; }
	public object projectType { get; set; }
	public object InvolvedInBaking { get; set; }
	public object bakingType { get; set; }
	public object boundForDynamicBaking { get; set; }
	public object boundForLightmap { get; set; }
	public object boundForVLM { get; set; }
	public object boundForCPUProbe { get; set; }
	public object boundForShadowmask { get; set; }

	// Methods

	// RVA: 0x775696C
	public object get_GUID() { }

	// RVA: 0x7756B64
	public object get_version() { }

	// RVA: 0x7756B70
	public object set_version(object value) { }

	// RVA: 0x7756B80
	public object get_projectType() { }

	// RVA: 0x7756B88
	public object set_projectType(object value) { }

	// RVA: 0x7756B90
	public object get_InvolvedInBaking() { }

	// RVA: 0x7756B98
	public object set_InvolvedInBaking(object value) { }

	// RVA: 0x7756BA0
	public object get_bakingType() { }

	// RVA: 0x7756BA8
	public object set_bakingType(object value) { }

	// RVA: 0x7756CFC
	public object get_boundForDynamicBaking() { }

	// RVA: 0x7756D04
	public object set_boundForDynamicBaking(object value) { }

	// RVA: 0x7756D58
	public object get_boundForLightmap() { }

	// RVA: 0x7756D60
	public object set_boundForLightmap(object value) { }

	// RVA: 0x7756DB4
	public object get_boundForVLM() { }

	// RVA: 0x7756DBC
	public object set_boundForVLM(object value) { }

	// RVA: 0x7756E10
	public object get_boundForCPUProbe() { }

	// RVA: 0x7756E18
	public object set_boundForCPUProbe(object value) { }

	// RVA: 0x7756E6C
	public object get_boundForShadowmask() { }

	// RVA: 0x7756E74
	public object set_boundForShadowmask(object value) { }

	// RVA: 0x7756EC8
	public object GetBoxCollider() { }

	// RVA: 0x7756FD8
	public object OnEnable() { }

	// RVA: 0x77573CC
	public object OnDisable() { }

	// RVA: 0x77574D8
	public object OnDestroy() { }

	// RVA: 0x77575B8
	private object Update() { }

	// RVA: 0x77575DC
	private object LateUpdate() { }

	// RVA: 0x7757600
	public object Check() { }

	// RVA: 0x7757728
	public object GetLocalMinPoint() { }

	// RVA: 0x7757C44
	public object GetLocalMaxPoint() { }

	// RVA: 0x7756BB0
	private object OnBakingTypeChanged() { }

	// RVA: 0x7757280
	private object EnableAppliers() { }

	// RVA: 0x77573D8
	private object DisableAppliers() { }

	// RVA: 0x7758160
	public static object UsingRuntimeLightmapGIVolume() { }

	// RVA: 0x77582DC
	public object UpdateCachedBounds() { }

	// RVA: 0x7758400
	public object GetCachedBounds() { }

	// RVA: 0x7756B2C
	private object GenerateGUID() { }

	// RVA: 0x7758414
	public object .ctor() { }

}

// Namespace: MessyLight
public static class GIVolumeExtension
{

	// Methods

	// RVA: 0x775869C
	public static object IsLocatedInGIVolume(object targetGIVolume, object targetRenderer) { }

	// RVA: 0x77586E4
	public static object IsLocatedInGIVolume(object targetGIVolume, object targetRenderer, object giType) { }

	// RVA: 0x7758A94
	private static object IsMatchGIType(object targetGIVolume, object giType, object receiveSM) { }

	// RVA: 0x7757380
	public static object UseRuntimeLightmap(object giVolume) { }

	// RVA: 0x7758B88
	public static object EnableBake(object giVolume) { }

}

// Namespace: MessyLight
public enum GIVolumeFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Terrain;
	public const object Rest;
}

// Namespace: MessyLight
public class GIVolumeManager
{

	// Fields
	private static object s_instance; // 0x0
	private readonly object m_GIVolumeSet; // 0x8

	// Properties
	public static object Instance { get; }

	// Methods

	// RVA: 0x774BDE0
	public static object get_Instance() { }

	// RVA: 0x7757110
	public object RegisterGIVolume(object giVolume) { }

	// RVA: 0x775754C
	public object UnregisterGIVolume(object giVolume) { }

	// RVA: 0x7758CA0
	public object TryGetGIVolumeByApplier(object applier, object giVolume) { }

	// RVA: 0x7758E38
	public object AllGIVolumes() { }

	// RVA: 0x7758C20
	public object .ctor() { }

}

// Namespace: MessyLight
public static class GIVolumeManagerExtensions
{

	// Methods

	// RVA: 0x7758E40
	public static object RefreshAllApplier(object manager) { }

	// RVA: 0x7758FBC
	public static object AllGIVolumes(object scene, object outputs) { }

	// RVA: 0x77592B0
	public static object AllGIVolumes(object scene) { }

	// RVA: 0x7759334
	public static object AllAppliers(object manager, object outputs) { }

	// RVA: 0x77594F0
	public static object AllAppliers(object manager) { }

	// RVA: 0x7759574
	public static object GetFirstGIVolume(object manager) { }

	// RVA: 0x7759960
	public static object EnabledGIVolumes(object manager, object giVolumes) { }

}

// Namespace: MessyLight
public class InstanceKeywordActivator
{

	// Fields
	public object giType; // 0x18
	public object yarp_LightmapEncodeScale; // 0x1C
	public object yarp_LightmapEncodeAdd_And_UseEncoding; // 0x2C
	public object yarp_Lightmap; // 0x40
	private object m_propBlock; // 0x48

	// Methods

	// RVA: 0x7759CE0
	private object OnEnable() { }

	// RVA: 0x7759F78
	public object .ctor() { }

}

// Namespace: MessyLight
public class LightmapInfo
{

	// Fields
	public object renderer; // 0x8
	public object scaleAndOffset; // 0x10
	public object index; // 0x20
	public object valid; // 0x24

	// Methods

	// RVA: 0x7759F80
	public object .ctor() { }

	// RVA: 0x7759F90
	public object .ctor(object info) { }

}

// Namespace: MessyLight
public class LightmapResultBase
{

	// Fields
	public object lightmapType; // 0x8
	public object lightmapInfoList; // 0x10

	// Methods

	// RVA: 0x7759FF0
	public object .ctor() { }

}

// Namespace: MessyLight
public class LightmapResult2D
{

	// Fields
	public object lightmap; // 0x18
	public object lightmap1; // 0x20

	// Methods

	// RVA: 0x7759FF8
	public object IsEncoded(object index) { }

	// RVA: 0x775A090
	public object GetMulCoeffAndAddCoeff(object index, object mulCoeff, object addCoeff) { }

	// RVA: 0x775A1A8
	public object Dispose() { }

	// RVA: 0x775A244
	public object .ctor() { }

}

// Namespace: MessyLight
public enum MessyApplierType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LightmapApplier;
	public const object VLMApplier;
	public const object CPUProbeApplier;
	public const object ShadowmaskApplier;
	public const object DynamicLightingApplier;
	public const object LightmapApplier2D;
	public const object Count;
}

// Namespace: MessyLight
public class MessyApplier
{

	// Fields
	private object id; // 0x8
	public object ID; // 0x10
	public object enable; // 0x18
	public object type; // 0x1C
	public object giVolume; // 0x20

	// Methods

	// RVA: 0x775A24C
	protected object .ctor(object type, object giVolume) { }

	// RVA: 0x775A298
	public virtual object OnEnable() { }

	// RVA: 0x775A29C
	public virtual object Update() { }

	// RVA: 0x775A2A0
	public virtual object LateUpdate() { }

	// RVA: 0x775A2A4
	public virtual object OnDisable() { }

	// RVA: 0x775A2A8
	public virtual object Valid() { }

	// RVA: 0x775A2B0
	public virtual object HasRenderer(object renderer) { }

	// RVA: 0x775A2B8
	public virtual object Relink(object root) { }

	// RVA: 0x775A2BC
	public virtual object OnBeforeSerialize() { }

	// RVA: 0x775A2C0
	public virtual object OnAfterDeserialize() { }

}

// Namespace: 
private sealed class <>c__DisplayClass19_0
{

	// Fields
	public object renderer; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x775B6AC
	public object .ctor() { }

	// RVA: 0x775C428
	internal object <RemoveRenderer>b__0(object sampler) { }

}

// Namespace: MessyLight
public class MessyCPUProbeApplier
{

	// Fields
	public object advanceVLMApplierID; // 0x28
	public object cpuProbeSamplers; // 0x30
	public object VLMData; // 0x38
	public object Volume; // 0x40
	public object CellSize; // 0x48
	private object InvGridSize; // 0x4C
	private object LocalMin; // 0x58
	private object mModifiedVLMData; // 0x68

	// Methods

	// RVA: 0x775A308
	public object SetModifiedVLMData(object texData) { }

	// RVA: 0x775A310
	private object GetVLMData() { }

	// RVA: 0x775A32C
	public object .ctor(object type, object giVolume) { }

	// RVA: 0x775A3D8
	private object RefreshDerivedData() { }

	// RVA: 0x775A4C0
	public override object OnEnable() { }

	// RVA: 0x775A4E4
	private object ActivatePassiveSampler() { }

	// RVA: 0x775AD80
	public override object Update() { }

	// RVA: 0x775AD84
	public override object OnDisable() { }

	// RVA: 0x775B0D0
	public override object Valid() { }

	// RVA: 0x775B164
	public object FindCPUProbeSampler(object renderer) { }

	// RVA: 0x775B348
	public object AddRenderer(object renderer) { }

	// RVA: 0x775B5BC
	public object RemoveRenderer(object renderer) { }

	// RVA: 0x775B6B4
	public object SetData(object vlmTex) { }

	// RVA: 0x775B720
	public object IsFallbackApplier() { }

	// RVA: 0x775B740
	public override object Relink(object root) { }

	// RVA: 0x775AB50
	public object BindSampler(object probeSampler, object coeffs) { }

	// RVA: 0x775AE38
	public object UnbindSampler(object probeSampler) { }

	// RVA: 0x775BC0C
	public object UpdateSampler(object probeSampler) { }

	// RVA: 0x775A9E0
	public object WarmUpAmbientCubeCoeff(object probeSampler) { }

	// RVA: 0x775BFDC
	public object UpdateAmbientCubeCoeff(object probeSampler) { }

	// RVA: 0x77529F4
	public object GetSampledPosition(object anchorPos, object anchorBoundSize, object faceIndex) { }

	// RVA: 0x775A974
	private object ReadAmibentCubeFace(object UVW, object faceIndex) { }

	// RVA: 0x775A7CC
	private object PositionToVolumeLightmapUVW(object posW, object anchorBoundSize, object faceIndex) { }

}

// Namespace: MessyLight
public class MessyCPUProbeSampler
{

	// Fields
	public object renderer; // 0x8
	public object updateMode; // 0x10
	public object anchorMode; // 0x14
	public object anchorBoundSize; // 0x18
	public object anchorOffset; // 0x24
	public object ambientCubeCoeffs; // 0x30
	public object prevAmbientCubeCoeffs; // 0x38
	public object currentAmbientCubeCoeffs; // 0x40
	public object delayTime; // 0x48
	public object t; // 0x4C
	public object firstFrame; // 0x50

	// Methods

	// RVA: 0x775B4A8
	public object .ctor(object renderer) { }

	// RVA: 0x7752860
	public object GetAnchor() { }

}

// Namespace: MessyLight
public class DynamicLightInfo
{

	// Fields
	public object name; // 0x8
	public object intensityDiff; // 0x10
	public object deltaRatio; // 0x14

	// Methods

	// RVA: 0x775C4FC
	public object .ctor() { }

}

// Namespace: MessyLight
public class MessyDynamicLightingApplier
{

	// Fields
	private object pLightmapImpl; // 0x28
	private object pVolumetricLightmapImpl; // 0x30
	private object pFallbackProbeImpl; // 0x38
	private object pProbeImpl; // 0x40
	public object lightmapRT0; // 0x48
	public object volumeLightmapRT; // 0x50
	public object LMSplitIntoGroup; // 0x58
	public object VLMSplitIntoGroup; // 0x59
	public object LODLevel; // 0x5C
	public object MaxLODLevel; // 0x60
	private object lightmapApplierIndex; // 0x64
	private object vlmApplierIndex; // 0x68
	private object fallbackProbeApplierIndex; // 0x6C
	private object probeApplierIndex; // 0x70
	public object lightmapApplierID; // 0x78
	public object vlmApplierID; // 0x80
	public object fallbackProbeApplierID; // 0x88
	public object probeApplierID; // 0x90
	public object lightmapType; // 0x98
	public object lightmapSize; // 0x9C
	public object oneLightLMReceiverMeshes; // 0xA0
	public object twoLightLMReceiverMeshes; // 0xA8
	public object threeLightLMReceiverMeshes; // 0xB0
	public object volumetricLightmapSize; // 0xB8
	public object oneLightVLMReceiverAssets; // 0xC8
	public object twoLightVLMReceiverAssets; // 0xD0
	public object threeLightVLMReceiverAssets; // 0xD8
	public object fallbackProbeSize; // 0xE0
	public object fallbackProbeReceiverAsset; // 0xF0
	public object probeSize; // 0xF8
	public object probeReceiverAsset; // 0x108
	private object mDynamicLightInfoList; // 0x110
	public object mLightmapEncoding; // 0x118
	public object mLightmapMulCoeff; // 0x11C
	public object mLightmapAddCoeff; // 0x128
	public object mLightmapScale; // 0x134
	public object mLightmapAdd; // 0x140
	public object VLMEncoding; // 0x14C
	public object VLMScale; // 0x150
	public object VLMAdd; // 0x15C
	public object VLMEncodeMulCoeff; // 0x168
	public object VLMEncodeAddCoeff; // 0x174
	public object VLMMinLuminance; // 0x180
	public object VLMMaxLuminance; // 0x184
	private object m2DBlitShader; // 0x188
	private object m2DBlitMaterial; // 0x190
	private object m2DBlitPropBlock; // 0x198
	private static readonly object PropID_input_texture; // 0x0
	private object m3DBlitShader; // 0x1A0
	private object mCmdBuffer; // 0x1A8
	private object mDynamicLightInfoMap; // 0x1B0
	private object mSrcLightmap0; // 0x1B8
	private object mSrcLightmap1; // 0x1C0
	private object mDstLightmap0; // 0x1C8
	private object mSrcVLM; // 0x1D0
	private object mDstVLM; // 0x1D8
	private object mSrcFallbackProbeData; // 0x1E0
	private object mDstFallbackProbeData; // 0x1E8
	private object mSrcProbeData; // 0x1F0
	private object mDstProbeData; // 0x1F8
	private object mIsInitialized; // 0x200

	// Methods

	// RVA: 0x775C504
	public object .ctor(object type, object giVolume) { }

	// RVA: 0x774BEE0
	public object SetDynamicLightIntensityDiff(object name, object diff) { }

	// RVA: 0x775C564
	public object Initialize() { }

	// RVA: 0x775DE10
	public override object OnDisable() { }

	// RVA: 0x775E1A8
	public override object LateUpdate() { }

	// RVA: 0x775E274
	public object GetCmd() { }

	// RVA: 0x775E27C
	public object IsFallbackDynamicLightingApplier() { }

	// RVA: 0x775D254
	public object UpdateLightmapEncodingInfo(object encoding, object mulCoeff, object addCoeff, object scale, object add) { }

	// RVA: 0x775E29C
	public object UpdateVolumetricLightmapEncodingInfo(object encoding, object scale, object add, object mulCoeff, object addCoeff, object minLuminance, object maxLuminance) { }

	// RVA: 0x775DCE4
	private object CreateDynamicLightInfoMap() { }

	// RVA: 0x774F050
	public object GetDynamicLightCount() { }

	// RVA: 0x774F0A4
	public object GetDynamicLightInfo(object lightIndex) { }

	// RVA: 0x775E2E0
	public override object OnBeforeSerialize() { }

	// RVA: 0x775E2E4
	public override object OnAfterDeserialize() { }

	// RVA: 0x775D298
	private object LightmapToRenderTexture(object lightmapResult) { }

	// RVA: 0x775EBA8
	public object SetSrcLightmap0(object tex) { }

	// RVA: 0x775EBB0
	public object SetSrcLightmap1(object tex) { }

	// RVA: 0x775EBB8
	public object SetDstLightmap0(object rt) { }

	// RVA: 0x775EBC0
	public object SetSrcVLM(object tex) { }

	// RVA: 0x775EBC8
	public object SetDstVLM(object rt) { }

	// RVA: 0x775EBD0
	public object GetSrcLightmap0() { }

	// RVA: 0x775EBD8
	public object GetSrcLightmap1() { }

	// RVA: 0x775EBE0
	public object GetDstLightmap0() { }

	// RVA: 0x775EBE8
	public object GetSrcVLM() { }

	// RVA: 0x775EBF0
	public object GetDstVLM() { }

	// RVA: 0x775EBF8
	public object GetSrcFallbackProbeData() { }

	// RVA: 0x775EC00
	public object GetDstFallbackProbeData() { }

	// RVA: 0x775EC08
	public object GetSrcProbeData() { }

	// RVA: 0x775EC10
	public object GetDstProbeData() { }

	// RVA: 0x775D9B0
	private object VolumeLightmapToRenderTexture(object vlmResult) { }

	// RVA: 0x775E3DC
	private object Texture2DToRenderTexture(object srcTex, object enableRandomWrite) { }

	// RVA: 0x775EC18
	private object Texture3DToRenderTexture(object srcTex, object enableRandomWrite) { }

	// RVA: 0x775EEDC
	private object BlitTexture3D(object srcTex, object dstTex) { }

	// RVA: 0x775F41C
	private static object FindComputeShaderByPath(object resourceRelativePath) { }

	// RVA: 0x775F4BC
	private static object .cctor() { }

}

// Namespace: MessyLight
public class MessyLightmapApplier2D
{

	// Fields
	private object m_LightmapResult; // 0x28
	private object m_currentLightmapInfo; // 0x30

	// Properties
	public object lightmapResult { get; set; }

	// Methods

	// RVA: 0x775F530
	public object get_lightmapResult() { }

	// RVA: 0x775F538
	public object set_lightmapResult(object value) { }

	// RVA: 0x775F628
	public object .ctor(object type, object giVolume) { }

	// RVA: 0x775F6C4
	public override object OnEnable() { }

	// RVA: 0x775FCA4
	public override object OnDisable() { }

	// RVA: 0x776005C
	public override object Valid() { }

	// RVA: 0x776006C
	public override object HasRenderer(object renderer) { }

	// RVA: 0x776032C
	public override object Relink(object root) { }

	// RVA: 0x775D6EC
	public object SetLightmap(object lightmap0, object lightmap1) { }

	// RVA: 0x7760C90
	public object RegisterRuntimeLightmapRenderer(object renderer) { }

	// RVA: 0x7760F98
	private object IsLightmapInfoValid(object info) { }

	// RVA: 0x775F6C8
	protected object ActiveLightmap() { }

	// RVA: 0x775FCA8
	protected object DeactiveLightmap() { }

}

// Namespace: MessyLight
public class MessyPrecomputedGISystem
{

	// Fields
	public object projectType; // 0x18
	public object version; // 0x20
	private object m_guid; // 0x28
	public readonly object m_LightmapAppliers2D; // 0x30
	public readonly object m_VLMAppliers; // 0x38
	public readonly object m_CPUProbeAppliers; // 0x40
	public readonly object m_DynamicLightAppliers; // 0x48
	public readonly object m_ShadowmaskAppliers; // 0x50
	public object m_Appliers; // 0x58
	public object m_GISystemID; // 0x60

	// Properties
	public object GUID { get; }

	// Methods

	// RVA: 0x77610E4
	public object get_GUID() { }

	// RVA: 0x77610EC
	public object .ctor() { }

}

// Namespace: MessyLight
public class MessyShadowmaskApplier
{

	// Fields
	private object m_ShadowmaskResult; // 0x28
	private object PROP_SM_SCALE_AND_OFFSET; // 0x30
	private object PROP_SM_TEX; // 0x34
	private object PROP_G_USE_SHADOWMASK; // 0x38
	private object m_MaterialPropertyBlock; // 0x40

	// Properties
	public object shadowmaskResult { get; set; }

	// Methods

	// RVA: 0x77612B8
	public object get_shadowmaskResult() { }

	// RVA: 0x77612C0
	public object set_shadowmaskResult(object value) { }

	// RVA: 0x7761328
	public object .ctor(object type, object giVolume) { }

	// RVA: 0x7761374
	public override object OnEnable() { }

	// RVA: 0x776197C
	public override object OnDisable() { }

	// RVA: 0x7761C28
	public override object Valid() { }

	// RVA: 0x7761C38
	public override object HasRenderer(object renderer) { }

	// RVA: 0x7761DEC
	public override object Relink(object root) { }

	// RVA: 0x7761428
	private object Init() { }

	// RVA: 0x77614D4
	private object ActiveShadowmask(object shadowmaskResult) { }

	// RVA: 0x7761984
	private object DeactiveShadowmask(object shadowmaskResult) { }

}

// Namespace: MessyLight
public class MessyVLMApplier
{

	// Fields
	private object mVLMResult; // 0x28
	public object mVolume; // 0x30
	private object mAssignedVLMTexture; // 0x38
	private object mFallbackTexture; // 0x40

	// Properties
	public object vlmResult { get; set; }

	// Methods

	// RVA: 0x77622AC
	public object .ctor(object type, object giVolume) { }

	// RVA: 0x77622F8
	public object GetVLMTexture() { }

	// RVA: 0x7762500
	public object GetVLMTextureFromVLMResult() { }

	// RVA: 0x7762768
	public object get_vlmResult() { }

	// RVA: 0x7762770
	public object set_vlmResult(object value) { }

	// RVA: 0x77627D8
	public override object OnEnable() { }

	// RVA: 0x7762D6C
	public override object OnDisable() { }

	// RVA: 0x7762E28
	public override object Valid() { }

	// RVA: 0x7762B40
	public object ActivateVLM() { }

	// RVA: 0x775DC44
	public object SetVolumetricLightmap(object volumetricLightmap) { }

	// RVA: 0x7762E38
	public override object Relink(object root) { }

}

// Namespace: 
public sealed class ProjectChangedCallback
{

	// Methods

	// RVA: 0x77C24E4
	public object .ctor(object object, object method) { }

	// RVA: 0x77C257C
	public virtual object Invoke(object projectType) { }

	// RVA: 0x77C2590
	public virtual object BeginInvoke(object projectType, object callback, object object) { }

	// RVA: 0x77C264C
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class SupportDynamicBakingCallback
{

	// Methods

	// RVA: 0x77C26D8
	public object .ctor(object object, object method) { }

	// RVA: 0x77C276C
	public virtual object Invoke() { }

	// RVA: 0x77C2780
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0x77C27D8
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class SupportDirectionalLightmap
{

	// Methods

	// RVA: 0x77C288C
	public object .ctor(object object, object method) { }

	// RVA: 0x77C2920
	public virtual object Invoke() { }

	// RVA: 0x77C2934
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0x77C298C
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class GetDeviceModelCallback
{

	// Methods

	// RVA: 0x77C2A58
	public object .ctor(object object, object method) { }

	// RVA: 0x77C2AEC
	public virtual object Invoke() { }

	// RVA: 0x77C2B00
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0x77C2B58
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class BeginProfilingSampleCallback
{

	// Methods

	// RVA: 0x77C2E68
	public object .ctor(object object, object method) { }

	// RVA: 0x77C2F74
	public virtual object Invoke(object cmd, object marker) { }

	// RVA: 0x77C2F88
	public virtual object BeginInvoke(object cmd, object marker, object callback, object object) { }

	// RVA: 0x77C2FE4
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class EndProfilingSampleCallback
{

	// Methods

	// RVA: 0x77C32F4
	public object .ctor(object object, object method) { }

	// RVA: 0x77C3400
	public virtual object Invoke(object cmd, object marker) { }

	// RVA: 0x77C3414
	public virtual object BeginInvoke(object cmd, object marker, object callback, object object) { }

	// RVA: 0x77C3470
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class ActiveGICallback
{

	// Methods

	// RVA: 0x77C3518
	public object .ctor(object object, object method) { }

	// RVA: 0x77C35C8
	public virtual object Invoke(object matPropertyBlock, object giType) { }

	// RVA: 0x77C35DC
	public virtual object BeginInvoke(object matPropertyBlock, object giType, object callback, object object) { }

	// RVA: 0x77C36A0
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class DeactiveGICallback
{

	// Methods

	// RVA: 0x77C3738
	public object .ctor(object object, object method) { }

	// RVA: 0x77C37E0
	public virtual object Invoke(object matPropertyBlock) { }

	// RVA: 0x77C37F4
	public virtual object BeginInvoke(object matPropertyBlock, object callback, object object) { }

	// RVA: 0x77C3844
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class SetShadowmaskCallback
{

	// Methods

	// RVA: 0x77C3B9C
	public object .ctor(object object, object method) { }

	// RVA: 0x77C3CA8
	public virtual object Invoke(object renderer, object matPropertyBlock, object val) { }

	// RVA: 0x77C3CBC
	public virtual object BeginInvoke(object renderer, object matPropertyBlock, object val, object callback, object object) { }

	// RVA: 0x77C3D8C
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class ActiveLightmappedRenderer
{

	// Methods

	// RVA: 0x77C409C
	public object .ctor(object object, object method) { }

	// RVA: 0x77C41A8
	public virtual object Invoke(object lightmapRes, object lightmapInfo) { }

	// RVA: 0x77C41BC
	public virtual object BeginInvoke(object lightmapRes, object lightmapInfo, object callback, object object) { }

	// RVA: 0x77C4218
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class DeactiveLightmappedRenderer
{

	// Methods

	// RVA: 0x77C4528
	public object .ctor(object object, object method) { }

	// RVA: 0x77C4634
	public virtual object Invoke(object lightmapRes, object lightmapInfo) { }

	// RVA: 0x77C4648
	public virtual object BeginInvoke(object lightmapRes, object lightmapInfo, object callback, object object) { }

	// RVA: 0x77C46A4
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class ActiveVLMCallback
{

	// Methods

	// RVA: 0x77C49FC
	public object .ctor(object object, object method) { }

	// RVA: 0x77C4B08
	public virtual object Invoke(object vlmTex, object vlmRes, object giVolume) { }

	// RVA: 0x77C4B1C
	public virtual object BeginInvoke(object vlmTex, object vlmRes, object giVolume, object callback, object object) { }

	// RVA: 0x77C4B78
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class DeactiveVLMCallback
{

	// Methods

	// RVA: 0x77C4E5C
	public object .ctor(object object, object method) { }

	// RVA: 0x77C4F78
	public virtual object Invoke(object vlmRes) { }

	// RVA: 0x77C4F8C
	public virtual object BeginInvoke(object vlmRes, object callback, object object) { }

	// RVA: 0x77C4FDC
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class GetSpecialASTCFormatCallback
{

	// Methods

	// RVA: 0x77C507C
	public object .ctor(object object, object method) { }

	// RVA: 0x77C5114
	public virtual object Invoke(object channelCount, object blockSize) { }

	// RVA: 0x77C5128
	public virtual object BeginInvoke(object channelCount, object blockSize, object callback, object object) { }

	// RVA: 0x77C5214
	public virtual object EndInvoke(object blockSize, object result) { }

}

// Namespace: 
public sealed class FindShaderByPathCallback
{

	// Methods

	// RVA: 0x77C5320
	public object .ctor(object object, object method) { }

	// RVA: 0x77C53C8
	public virtual object Invoke(object resourceRelativePath) { }

	// RVA: 0x77C53DC
	public virtual object BeginInvoke(object resourceRelativePath, object callback, object object) { }

	// RVA: 0x77C542C
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class FindComputeShaderByPathCallback
{

	// Methods

	// RVA: 0x77C54D8
	public object .ctor(object object, object method) { }

	// RVA: 0x77C5580
	public virtual object Invoke(object resourceRelativePath) { }

	// RVA: 0x77C5594
	public virtual object BeginInvoke(object resourceRelativePath, object callback, object object) { }

	// RVA: 0x77C55E4
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class LogErrorCallback
{

	// Methods

	// RVA: 0x77C56AC
	public object .ctor(object object, object method) { }

	// RVA: 0x77C5754
	public virtual object Invoke(object message) { }

	// RVA: 0x77C5768
	public virtual object BeginInvoke(object message, object callback, object object) { }

	// RVA: 0x77C57B8
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class LogWarningCallback
{

	// Methods

	// RVA: 0x77C5880
	public object .ctor(object object, object method) { }

	// RVA: 0x77C5928
	public virtual object Invoke(object message) { }

	// RVA: 0x77C593C
	public virtual object BeginInvoke(object message, object callback, object object) { }

	// RVA: 0x77C598C
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class LogCallback
{

	// Methods

	// RVA: 0x77C5A54
	public object .ctor(object object, object method) { }

	// RVA: 0x77C5AFC
	public virtual object Invoke(object message) { }

	// RVA: 0x77C5B10
	public virtual object BeginInvoke(object message, object callback, object object) { }

	// RVA: 0x77C5B60
	public virtual object EndInvoke(object result) { }

}

// Namespace: MessyLight
public static class MLRuntimeCallback
{

	// Fields
	private const object c_UndefinedCallback;
	public static object s_ProjectChangedCallback; // 0x0
	public static object s_SupportDynamicBakingCallback; // 0x8
	public static object s_SupportDirectionalLightmap; // 0x10
	public static object s_ActiveGICallback; // 0x18
	public static object s_SetShadowmaskCallback; // 0x20
	public static object s_DeactiveGICallback; // 0x28
	public static object s_ActiveLightmappedRenderer; // 0x30
	public static object s_DeactiveLightmappedRenderer; // 0x38
	public static object s_ActiveVLMCallback; // 0x40
	public static object s_GetSpecialASTCFormatCallback; // 0x48
	public static object s_FindShaderByPathCallback; // 0x50
	public static object s_FindComputeShaderByPathCallback; // 0x58
	public static object LogError; // 0x60
	public static object LogWarning; // 0x68
	public static object Log; // 0x70
	private static object s_MatPropertyBlock; // 0x78

	// Methods

	// RVA: 0x7763358
	public static object Reset() { }

	// RVA: 0x7763878
	private static object ProjectChangedDefault(object projectType) { }

	// RVA: 0x776387C
	private static object SupportDirectionalLightmapDefault() { }

	// RVA: 0x7763884
	private static object SupportDynamicBakingDefault() { }

	// RVA: 0x776388C
	public static object ActiveLightmappedRendererDefault(object lightmapRes, object lightmapInfo) { }

	// RVA: 0x7763FD8
	private static object DeactiveLightmappedRendererDefault(object lightmapRes, object lightmapInfo) { }

	// RVA: 0x776435C
	private static object ActiveVLMDefault(object vlmTex, object vlmRes, object giVolume) { }

	// RVA: 0x7764620
	private static object ActiveGIDefault(object matPropertyBlock, object giType) { }

	// RVA: 0x776489C
	private static object DeactiveGIDefault(object matPropertyBlock) { }

	// RVA: 0x7764974
	private static object SetShadowmaskCallbackDefault(object renderer, object matPropertyBlock, object val) { }

	// RVA: 0x7764A18
	private static object GetSpecialASTCFormatDefault(object channelCount, object blockSize) { }

	// RVA: 0x7764A80
	private static object FindShaderByPathDefault(object resourceRelativePath) { }

	// RVA: 0x7764CA4
	private static object FindComputeShaderByPathDefault(object resourceRelativePath) { }

	// RVA: 0x7764EC8
	public static object LogErrorDefault(object message) { }

	// RVA: 0x7764FB4
	public static object LogWarningDefault(object message) { }

	// RVA: 0x77621C0
	public static object LogDefault(object message) { }

	// RVA: 0x77650A0
	public static object LogErrorUnimplementedFunc(object funcName) { }

	// RVA: 0x7765150
	public static object LogWarningUnimplementedFunc(object funcName) { }

	// RVA: 0x7765200
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__22_0; // 0x8

	// Methods

	// RVA: 0x77C7444
	private static object .cctor() { }

	// RVA: 0x77C74A4
	public object .ctor() { }

	// RVA: 0x77C74AC
	internal object <GetGIEncodeStatus>b__22_0(object x) { }

}

// Namespace: 
private sealed class <FindChildGameObjects>d__15
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	private object parentObj; // 0x20
	public object <>3__parentObj; // 0x28
	private object includeInactive; // 0x30
	public object <>3__includeInactive; // 0x31
	private object childName; // 0x38
	public object <>3__childName; // 0x40
	private object <>7__wrap1; // 0x48
	private object <>7__wrap2; // 0x50

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.GameObject>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77C639C
	public object .ctor(object <>1__state) { }

	// RVA: 0x77C74C8
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77C74CC
	private object MoveNext() { }

	// RVA: 0x77C7650
	private object System.Collections.Generic.IEnumerator<UnityEngine.GameObject>.get_Current() { }

	// RVA: 0x77C7658
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77C7698
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x77C76A0
	private object System.Collections.Generic.IEnumerable<UnityEngine.GameObject>.GetEnumerator() { }

	// RVA: 0x77C7754
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: MessyLight
public static class MLRuntimeUtils
{

	// Fields
	private static object s_quadMesh; // 0x0

	// Methods

	// RVA: -1
	public static object GetAllCurSceneComponents(object outputs, object includeInactiveInHierarchy, object extraCheck) { }

	// RVA: -1
	public static object GetAllCurSceneComponents(object includeInactiveInHierarchy, object extraCheck) { }

	// RVA: -1
	public static object GetComponentsInAllScenes(object outputs, object includeInactiveInHierarchy, object extraCheck) { }

	// RVA: -1
	public static object GetComponentsInAllScenes(object includeInactiveInHierarchy, object extraCheck) { }

	// RVA: -1
	public static object GetAllComponentsInScene(object scene, object outputs, object includeInactiveInHierarchy, object extraCheck) { }

	// RVA: -1
	public static object GetAllComponentsInScene(object scene, object includeInactiveInHierarchy, object extraCheck) { }

	// RVA: -1
	public static object GetAllComponents(object outputs, object parentObj, object includeChildren, object includeInactiveInHierarchy, object extraCheck) { }

	// RVA: -1
	public static object GetAllComponents(object parentObj, object includeChildren, object includeInactiveInHierarchy, object extraCheck) { }

	// RVA: -1
	public static object GetAllComponents(object outputs, object parentObjects, object includeChildren, object includeInactiveInHierarchy) { }

	// RVA: -1
	public static object GetAllComponents(object parentObjects, object includeChildren, object includeInactiveInHierarchy) { }

	// RVA: 0x77C5B6C
	public static object FindGameObject(object name, object includeInactive) { }

	// RVA: 0x77C5D54
	public static object FindGameObjectInAllScenes(object name, object includeInactive) { }

	// RVA: 0x77C5BE0
	public static object FindGameObjectInScene(object scene, object name, object includeInactive) { }

	// RVA: 0x77C616C
	public static object FindChildGameObject(object parentObj, object childName, object includeInactive) { }

	// RVA: 0x77C6308
	public static object FindChildGameObjects(object parentObj, object childName, object includeInactive) { }

	// RVA: 0x77C63D4
	public static object IsChild(object parent, object child) { }

	// RVA: 0x77C64DC
	public static object GetParentName(object transform) { }

	// RVA: 0x77C65F4
	public static object GetGameObjectPath(object obj) { }

	// RVA: 0x77C5EF0
	public static object GetAllActiveScenes() { }

	// RVA: 0x77C6760
	public static object TextureFmtToRenderTextureFmt(object fmt) { }

	// RVA: 0x77C6828
	public static object SafeDestroyObj(object obj) { }

	// RVA: 0x77C68F8
	public static object GetGIEncodeStatus(object encodeScale) { }

	// RVA: 0x77C6A78
	public static object IsFallbackCPUProbeGIVolume(object giVolume) { }

	// RVA: -1
	public static object GITypeIsLightmap(object renderer) { }

	// RVA: -1
	public static object GITypeIsDefaultOrUnset(object renderer) { }

	// RVA: -1
	public static object GetGIType(object renderer) { }

	// RVA: 0x77C6AB0
	public static object supportASTC3DTexture() { }

	// RVA: 0x77C6C28
	private static object supportASTC3DTextureAndroid() { }

	// RVA: 0x77C6AB4
	private static object supportASTC3DTextureIOS() { }

	// RVA: 0x77C6CF0
	public static object Get3DASTCFormat() { }

	// RVA: 0x77C6DA4
	public static object GetCameraTexture(object camera) { }

	// RVA: 0x77C6EC8
	public static object DrawQuad(object cmd, object mat, object shaderPass, object properties) { }

}

// Namespace: MessyLight
public enum LightmapType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Uniform;
	public const object Directional;
}

// Namespace: MessyLight
public enum LightmapQuality
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Preview;
	public const object High;
	public const object Production;
}

// Namespace: MessyLight
public enum ShaderGIType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object UniformLightmap;
	public const object DirectionalLightmap;
	public const object ScreenSpaceIrradiance;
	public const object VolumetricLightmap;
	public const object LightProbe;
}

// Namespace: 
public enum ProjectType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Standard;
	public const object WZ_Junei;
	public const object Ciyuan;
	public const object TianGong;
}

// Namespace: MessyLight
public static class RuntimeConfig
{

	// Fields
	public static object LIGHTMAP_RESOURCE_DIR; // 0x0
	public static readonly object SHADER_PROP_GI_TYPE; // 0x8
	public const object SMALL_THRESHOLD;
	public static object ENABLE_INSTANCE_KEYWORD; // 0xC
	public static object ENABLE_LOG; // 0xD
	public const object KEYWORD_USE_UNIFORM_LIGHTMAP;
	public const object KEYWORD_USE_DIRECTIONAL_LIGHTMAP;
	public const object KEYWORD_USE_LIGHTMAP_ENCODING;
	public const object KEYWORD_YARP_EDITOR;
	public static readonly object KEYWORD_USE_UNIFORM_LIGHTMAP_GLOBAL_KEYWORD; // 0x10
	public static readonly object KEYWORD_USE_DIRECTIONAL_LIGHTMAP_GLOBAL_KEYWORD; // 0x20
	public static readonly object PROP_USE_VLM_ENCODING; // 0x30
	public static readonly object PROP_YARP_LIGHTMAP; // 0x34
	public static readonly object PROP_YARP_LIGHTMAP_DIRECTION; // 0x38
	public static readonly object PROP_YARP_LIGHTMAP_ENCODE_SCALE; // 0x3C
	public static readonly object PROP_YARP_LIGHTMAP_ENCODE_ADD_AND_USE_ENCODING; // 0x40
	public static readonly object PROP_YARP_LIGHTMAP_SCALE_AND_OFFSET; // 0x44
	public const object KEYWORD_USE_VOLUMETRIC_LIGHTMAP;
	public static readonly object PROP_VLM_TEXTURE; // 0x48
	public static readonly object PROP_VLM_BOUNDING_BOX_MIN; // 0x4C
	public static readonly object PROP_VLM_INV_GRID_SIZE; // 0x50
	public static readonly object PROP_VLM_LOCAL_TO_WORLD_MATRIX; // 0x54
	public static readonly object PROP_VLM_WORLD_TO_LOCAL_MATRIX; // 0x58
	public static readonly object PROP_VLM_SCALE; // 0x5C
	public static readonly object PROP_VLM_ADD; // 0x60
	public static readonly object PROP_VLM_MIN_LUM; // 0x64
	public static readonly object PROP_VLM_MAX_LUM; // 0x68
	public static readonly object KEYWORD_USE_VOLUMETRIC_LIGHTMAP_GLOBAL_KEYWORD; // 0x70
	public static object KEYWORD_USE_LIGHT_PROBE; // 0x80
	public static object PROP_PROBE_AMBIENT_CUBE_COEFFS; // 0x88
	public static object PROP_PROBE_LOCAL_TO_WORLD; // 0x8C
	public static readonly object KEYWORD_USE_LIGHT_PROBE_GLOBAL_KEYWORD; // 0x90
	public const object RECEIVER_OFFSETS_START;
	public static object PROP_RECEIVER_OFFSETS_START; // 0xA0
	public const object RECEIVER_OFFSETS_NUM;
	public static object PROP_RECEIVER_OFFSETS_NUM; // 0xA4
	public const object LIGHT_INTENSITY_DIFF;
	public static object PROP_LIGHT_INTENSITY_DIFF; // 0xA8
	public const object RECEIVERS;
	public static object PROP_RECEIVERS; // 0xAC
	public const object AHD_RECEIVERS;
	public static object PROP_AHD_RECEIVERS; // 0xB0
	public const object LM_SRC_IRRADIANCE;
	public static object PROP_LM_SRC_IRRADIANCE; // 0xB4
	public const object LM_DST_IRRADIANCE;
	public static object PROP_LM_DST_IRRADIANCE; // 0xB8
	public const object LM_SRC_DIRECTION_AND_WEIGHT;
	public static object PROP_LM_SRC_DIRECTION_AND_WEIGHT; // 0xBC
	public const object LM_DST_DIRECTION_AND_WEIGHT;
	public static object PROP_LM_DST_DIRECTION_AND_WEIGHT; // 0xC0
	public const object VLM_SRC_VLM;
	public static object PROP_VLM_SRC_VLM; // 0xC4
	public const object VLM_DST_VLM;
	public static object PROP_VLM_DST_VLM; // 0xC8
	public const object VLM_WIDTH;
	public static object PROP_VLM_WIDTH; // 0xCC
	public const object DYNAMIC_LIGHTING_SCALE;
	public static object PROP_DYNAMIC_LIGHTING_SCALE; // 0xD0
	public const object DYNAMIC_LIGHTING_ADD;
	public static object PROP_DYNAMIC_LIGHTING_ADD; // 0xD4
	public const object DYNAMIC_LIGHTING_LM_ENCODING;
	public static object PROP_DYNAMIC_LIGHTING_LM_ENCODING; // 0xD8
	public const object DYNAMIC_LIGHTING_LM_MUL_COEFF;
	public static object PROP_DYNAMIC_LIGHTING_LM_MUL_COEFF; // 0xDC
	public const object DYNAMIC_LIGHTING_LM_ADD_COEFF;
	public static object PROP_DYNAMIC_LIGHTING_LM_ADD_COEFF; // 0xE0
	public const object DYNAMIC_LIGHTING_LM_SCALE;
	public static object PROP_DYNAMIC_LIGHTING_LM_SCALE; // 0xE4
	public const object DYNAMIC_LIGHTING_LM_ADD;
	public static object PROP_DYNAMIC_LIGHTING_LM_ADD; // 0xE8
	public const object KEYWORD_USE_SHADOWMASK;
	public const object USE_SHADOWMASK;
	public static object PROP_USE_SHADOWMASK; // 0xEC
	public const object GI_VOLUME_VERSION_ORIGIN;
	public const object GI_VOLUME_VERSION_1;
	public const object GI_VOLUME_VERSION_2;
	public const object GI_VOLUME_VERSION_LATEST;
	public static object version; // 0xF0

	// Methods

	// RVA: 0x77C7808
	private static object .cctor() { }

}

// Namespace: MessyLight
public class RuntimeRenderAdditionalInfo
{

	// Fields
	private object m_guid; // 0x18
	private object m_data; // 0x20
	private object m_extraData; // 0x28

	// Properties
	public object GUID { get; }
	public object Data { get; }

	// Methods

	// RVA: 0x77C7FF4
	public object get_GUID() { }

	// RVA: 0x77C7FFC
	public object get_Data() { }

	// RVA: 0x77C8004
	public object TryGetData(object giVolumeGUID, object data) { }

	// RVA: 0x77C82D4
	public object .ctor() { }

}

// Namespace: MessyLight
public class RuntimeLightmapApplierData
{

	// Fields
	public object HostGIVolumeGUID; // 0x8
	public object LightmapIndex; // 0x10
	public object LightmapScaleAndOffset; // 0x14
	private object m_guidOfHostGIVolume; // 0x24

	// Properties
	public object GUIDOfHostGIVolume { get; }

	// Methods

	// RVA: 0x77C81FC
	public object get_GUIDOfHostGIVolume() { }

	// RVA: 0x77C8354
	public object Clone() { }

	// RVA: 0x77C83E8
	public object .ctor() { }

}

// Namespace: MessyLight
public static class RuntimeSetting
{

	// Fields
	private static object SupportRenderTexture3DInitialized; // 0x0
	private static object _SupportRenderTexture3D; // 0x1

	// Properties
	public static object EnableDynamicBaking { get; }
	public static object EnableVLM { get; }
	public static object EnableProbe { get; }
	public static object EnableDirectionalLightmap { get; }

	// Methods

	// RVA: 0x77C83F0
	public static object get_EnableDynamicBaking() { }

	// RVA: 0x77C84C0
	public static object get_EnableVLM() { }

	// RVA: 0x77C8590
	public static object get_EnableProbe() { }

	// RVA: 0x77C8660
	public static object get_EnableDirectionalLightmap() { }

	// RVA: 0x77C86F0
	public static object SupportRenderTexture3D() { }

}

// Namespace: MessyLight
public class ShadowmaskResult
{

	// Fields
	public object shadowmask; // 0x8
	public object lightmapInfoList; // 0x10

	// Methods

	// RVA: 0x77C8D70
	public object .ctor() { }

}

// Namespace: MessyLight
public class StaticShadowDepthMapApplier
{

	// Fields
	public object staticShadowDepthMap; // 0x28
	public object shadowMapSize; // 0x30
	public object worldToLight; // 0x40
	public object mVolume; // 0x80

	// Methods

	// RVA: 0x77C8D78
	public object .ctor(object type, object giVolume) { }

}

// Namespace: MessyLight
public class VolumetricLightmapItemInfo
{

	// Fields
	public object renderer; // 0x8
	public object otherObject; // 0x10

	// Methods

	// RVA: 0x77C8D80
	public object .ctor() { }

}

// Namespace: MessyLight
public class VolumetricLightmapResult
{

	// Fields
	public object volumetricLightmap; // 0x8
	public object itemInfos; // 0x10
	public object cellSize; // 0x18
	public object localMin; // 0x1C
	public object invGridSize; // 0x28

	// Properties
	public object sampleOffset { get; set; }
	public object blurWeight { get; set; }

	// Methods

	// RVA: 0x77C8D88
	public object get_sampleOffset() { }

	// RVA: 0x77C8DB4
	public object set_sampleOffset(object value) { }

	// RVA: 0x77C8E18
	public object get_blurWeight() { }

	// RVA: 0x77C8E40
	public object set_blurWeight(object value) { }

	// RVA: 0x77C8EBC
	public object IsEncoded() { }

	// RVA: 0x77C8EF4
	public object .ctor() { }

}

// Namespace: MessyLight
internal class VolumetricLightmapVisualization
{

	// Fields
	private object mParent; // 0x8
	private object mMaterial; // 0x10

	// Methods

	// RVA: 0x77C8F74
	public object .ctor(object parent) { }

	// RVA: 0x77C901C
	public object Render(object context, object cmd, object cameraData, object rt) { }

}

// Namespace: 
public struct Allocation
{

	// Fields
	public const object NO_SPACE;
	public object offset; // 0xFFFFFFFFFFFFFFF8
	public object metadata; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x77CA568
	public object .ctor(object _offset, object _metadata) { }

}

// Namespace: 
public struct Node
{

	// Fields
	public const object unused;
	public object dataOffset; // 0xFFFFFFFFFFFFFFF8
	public object dataSize; // 0xFFFFFFFFFFFFFFFC
	public object binListPrev; // 0x0
	public object binListNext; // 0x4
	public object neighborPrev; // 0x8
	public object neighborNext; // 0xC
	public object used; // 0x10

	// Properties
	public static object Default { get; }

	// Methods

	// RVA: 0x77C9F9C
	public static object get_Default() { }

}

// Namespace: 
public struct StorageReport
{

	// Fields
	public object totalFreeSpace; // 0xFFFFFFFFFFFFFFF8
	public object largestFreeRegion; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: 
public struct Region
{

	// Fields
	public object size; // 0xFFFFFFFFFFFFFFF8
	public object count; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: 
public class StorageReportFull
{

	// Fields
	public object freeRegions; // 0x8

	// Methods

	// RVA: 0x77CAD30
	public object .ctor() { }

}

// Namespace: 
private static class SmallFloat
{

	// Fields
	private const object MANTISSA_BITS;
	private const object MANTISSA_VALUE;
	private const object MANTISSA_MASK;

	// Methods

	// RVA: 0x77CA570
	public static object uintToFloatRoundUp(object size) { }

	// RVA: 0x77CAD94
	public static object uintToFloatRoundDown(object size) { }

	// RVA: 0x77CAB98
	public static object floatToUint(object floatValue) { }

}

// Namespace: Yarp
public class OffsetAllocator
{

	// Fields
	private const object NUM_TOP_BINS;
	private const object BINS_PER_LEAF;
	private const object TOP_BINS_INDEX_SHIFT;
	private const object LEAF_BINS_INDEX_MASK;
	private const object NUM_LEAF_BINS;
	private object m_size; // 0x8
	private object m_maxAllocs; // 0xC
	private object m_freeStorage; // 0x10
	private object m_usedBinsTop; // 0x14
	private object m_usedBins; // 0x18
	private object m_binIndices; // 0x20
	private object m_nodes; // 0x28
	private object m_freeNodes; // 0x30
	private object m_freeOffset; // 0x38

	// Methods

	// RVA: 0x77C99FC
	public object .ctor(object size, object maxAllocs) { }

	// RVA: 0x77C9AA4
	private object reset() { }

	// RVA: 0x77CA1C0
	public object allocate(object size) { }

	// RVA: 0x77CA650
	public object free(object allocation) { }

	// RVA: 0x77CAA30
	public object allocationSize(object allocation) { }

	// RVA: 0x77CAA78
	public object storageReport() { }

	// RVA: 0x77CABBC
	public object storageReportFull() { }

	// RVA: 0x77C9FB8
	private object insertNodeIntoBin(object size, object dataOffset) { }

	// RVA: 0x77CA838
	private object removeNodeFromBin(object nodeIndex) { }

	// RVA: 0x77CAB5C
	private static object lzcnt_nonzero(object v) { }

	// RVA: 0x77CA614
	private static object tzcnt_nonzero(object v) { }

	// RVA: 0x77CA5D0
	private static object findLowestSetBitAfter(object bitMask, object startBitIndex) { }

}

// Namespace: Yarp
public class ClusterDecalCommon
{

	// Fields
	private object m_ClusterDims; // 0x8
	private object m_DecalPropertiesBuffer; // 0x18
	private static readonly object m_DecalNumShaderID; // 0x0
	private static readonly object m_DecalPropertiesShaderID; // 0x4
	private static readonly object m_ClusterDimsShaderID; // 0x8
	private static readonly object m_ClusterParamsShaderID; // 0xC
	private static readonly object m_ClusterParams2ShaderID; // 0x10
	private static readonly object m_ClusterScreenParamsShaderID; // 0x14

	// Properties
	public object clusterDims { get; }

	// Methods

	// RVA: 0x77CAE30
	public object get_clusterDims() { }

	// RVA: 0x77CAE3C
	public object Render(object cmd, object camera, object decalSetting) { }

	// RVA: 0x77CB6C4
	public object Dispose() { }

	// RVA: 0x77CB11C
	private object UpdateResource(object cmd, object camera) { }

	// RVA: 0x77CB7C0
	public object .ctor() { }

	// RVA: 0x77CB7C8
	private static object .cctor() { }

}

// Namespace: Yarp
public class ClusterCulling
{

	// Fields
	private object m_ClearClusterInfoShader; // 0x8
	private object m_CollectCoveredClusterRangeShader; // 0x10
	private object m_SortClusterItemsShader; // 0x18
	private object m_ClearClusterInfoKernel; // 0x20
	private object m_CollectCoveredClusterRangeKernel; // 0x24
	private object m_SortClusterItemsKernel; // 0x28
	private object m_ClearClusterInfoGroupSizeX; // 0x2C
	private object m_ClearClusterInfoGroupSizeY; // 0x30
	private object m_ClearClusterInfoGroupSizeZ; // 0x34
	private object m_CollectCoveredClusterRangeGroupSizeX; // 0x38
	private object m_CollectCoveredClusterRangeGroupSizeY; // 0x3C
	private object m_CollectCoveredClusterRangeGroupSizeZ; // 0x40
	private object m_SortClusterItemsGroupSizeX; // 0x44
	private object m_SortClusterItemsGroupSizeY; // 0x48
	private object m_SortClusterItemsGroupSizeZ; // 0x4C
	private object m_AlignedLightIndicesOfAllClusterBuffer; // 0x50
	private object m_AlignedLightCountersOfAllClusterBuffer; // 0x58
	private readonly object m_ProjectionMatrixShaderID; // 0x60
	private readonly object m_ClusterCountShaderID; // 0x64
	private readonly object m_AlignedLightIndicesOfAllClusterShaderID; // 0x68
	private readonly object m_AlignedLightCountersOfAllClusterShaderID; // 0x6C
	private readonly object m_AlignedLightIndicesOfAllClusterRShaderID; // 0x70
	private readonly object m_AlignedLightCountersOfAllClusterRShaderID; // 0x74

	// Methods

	// RVA: 0x77CB928
	public object Render(object cmd, object itemCount, object camera) { }

	// RVA: 0x77CC1B0
	public object Dispose(object cmd) { }

	// RVA: 0x77CBAB0
	private object Init() { }

	// RVA: 0x77CBEC8
	private object SetGlobalParams(object cmd) { }

	// RVA: 0x77CBF44
	private object ClearClusterInfo(object cmd) { }

	// RVA: 0x77CC00C
	private object CollectCoveredClusterRange(object cmd, object itemCount, object camera) { }

	// RVA: 0x77CC0EC
	private object SortClusterItems(object cmd) { }

	// RVA: 0x77CC1F4
	public object .ctor() { }

}

// Namespace: Yarp
public class ClusterShading
{

	// Fields
	private object m_ClearClusterInfoShader; // 0x8
	private object m_CollectValidClusterShader; // 0x10
	private object m_ClusterLightCullingShader; // 0x18
	private object m_ClusterLightIndexOffsetLengthBuffer; // 0x20
	private object m_ValidClusterIndicesBuffer; // 0x28
	private object m_LightIndicesOfAllClusterBuffer; // 0x30
	private object m_LightIndicesCountBuffer; // 0x38
	private object m_LightCullingIndirectBuffer; // 0x40
	private object m_ClearClusterInfoKernel; // 0x48
	private object m_CollectValidClusterKernel; // 0x4C
	private object m_ClusterLightCullingKernel; // 0x50
	private object m_ClearClusterInfoGroupSizeX; // 0x54
	private object m_ClearClusterInfoGroupSizeY; // 0x58
	private object m_ClearClusterInfoGroupSizeZ; // 0x5C
	private object m_CollectValidClusterGroupSizeX; // 0x60
	private object m_CollectValidClusterGroupSizeY; // 0x64
	private object m_CollectValidClusterGroupSizeZ; // 0x68
	private object m_ClusterLightCullingGroupSizeX; // 0x6C
	private object m_ClusterLightCullingGroupSizeY; // 0x70
	private object m_ClusterLightCullingGroupSizeZ; // 0x74
	private readonly object m_DepthTextureShaderID; // 0x78
	private readonly object m_ValidClusterIndicesShaderID; // 0x7C
	private readonly object m_ClusterLightIndexOffsetLengthShaderID; // 0x80
	private readonly object m_LightIndicesOfAllClusterShaderID; // 0x84
	private readonly object m_LightIndicesCountShaderID; // 0x88
	private readonly object m_ClusterLightIndexOffsetLengthRShaderID; // 0x8C
	private readonly object m_LightIndicesOfAllClusterRShaderID; // 0x90

	// Properties
	public object validClusterIndicesBuffer { get; }
	public object clusterLightIndexOffsetLengthBuffer { get; }

	// Methods

	// RVA: 0x77CC31C
	public object get_validClusterIndicesBuffer() { }

	// RVA: 0x77CC324
	public object get_clusterLightIndexOffsetLengthBuffer() { }

	// RVA: 0x77CC32C
	public object Render(object cmd, object camera, object depthTexture) { }

	// RVA: 0x77CCC20
	public object Dispose() { }

	// RVA: 0x77CC48C
	private object Init(object camera) { }

	// RVA: 0x77CC8C0
	private object SetGlobalParams(object cmd, object camera) { }

	// RVA: 0x77CC914
	private object ClearClusterInfo(object cmd) { }

	// RVA: 0x77CCA48
	private object CollectValidCluster(object cmd, object camera, object depthTexture) { }

	// RVA: 0x77CCB54
	private object ClusterLightCulling(object cmd) { }

	// RVA: 0x77CCCA0
	public object .ctor() { }

}

// Namespace: Yarp
public static class ClusterShadingConfig
{

	// Fields
	public const object MAX_CLUSTER_NUM;
	public const object CLUSTER_SCREEN_GRID_SIZE;
	public const object MAX_VALID_CLUSTER_NUM;
	public const object MAX_LIGHT_NUM_PER_CLUSTER;
	public const object MAX_CLUSTER_SLICE_NUM;
	public const object MAX_LIGHT_NUM;
}

// Namespace: Yarp
public static class ClusterShadingHelper
{

	// Methods

	// RVA: 0x77CCDF4
	public static object ComputeClusterLogDistributionParamsBasedDoom(object camera, object logNear, object logFarByNear) { }

	// RVA: 0x77CCEF4
	public static object ComputeClusterDepthBasedDoom(object camera, object sliceIndex, object sliceNum) { }

	// RVA: 0x77CCFC4
	public static object ComputeClusterDepthBasedDoom(object near, object farByNear, object sliceIndex, object sliceNum) { }

	// RVA: 0x77CD050
	public static object ComputeDepthSliceIndexBasedDoom(object viewZ, object sliceNum, object logNear, object logFarByNear) { }

	// RVA: 0x77CB6F4
	public static object ComputeClusterDimension(object camera, object clusterScreenSize, object clusterDims) { }

	// RVA: 0x77CD100
	public static object ComputeClusterCoord(object screenPos, object viewZ, object clusterScreenGridSize, object sliceNum, object logNear, object logFarByNear) { }

	// RVA: 0x77CD208
	public static object ComputeClusterCoord(object posVS, object camera) { }

	// RVA: 0x77CD330
	public static object ComputeClusterCoord(object posVS, object cameraPixelWidth, object cameraPixelHeight, object cameraNear, object cameraFar, object projectionMatrix) { }

	// RVA: 0x77CD56C
	public static object ComputeClusterCoord(object clusterIndex, object clusterDims) { }

	// RVA: 0x77CD5B0
	public static object ComputeClusterIndex(object coord, object clusterDims) { }

	// RVA: 0x77CD5F0
	public static object ScreenToClipPos(object screenPos, object invScreenWidthHeight, object depth) { }

	// RVA: 0x77CD620
	public static object ClipToViewPos(object clipPos, object invNonJitteredProjMat) { }

	// RVA: 0x77CD65C
	public static object ComputeViewPosAtDepth(object viewPosAtNear, object viewDepth) { }

	// RVA: 0x77CD678
	public static object ComputeClusterViewSpaceAABB(object clusterIndex, object clusterDims, object clusterScreenGridSize, object near, object sliceNum, object farByNear, object invScreenWidthHeight, object invNonJitteredProjMat, object aabbMin, object aabbMax) { }

	// RVA: 0x77CD9FC
	public static object CameraRightVectorWS(object worldToCameraMatrix) { }

	// RVA: 0x77CDA20
	public static object CameraUpVectorWS(object worldToCameraMatrix) { }

	// RVA: 0x77CDA44
	public static object CameraForwardVectorWS(object worldToCameraMatrix) { }

	// RVA: 0x77CDA74
	public static object ViewSpaceAABBToWorldOBB(object aabb, object worldToCameraMatrix, object cameraToWorldMatrix) { }

	// RVA: 0x77CDCD0
	public static object ProjectOBB(object obb, object axis) { }

	// RVA: 0x77CE22C
	public static object OBBIntersection(object a, object b) { }

	// RVA: 0x77CE624
	public static object CreateWireCubeMesh(object min, object max) { }

	// RVA: 0x77CE93C
	public static object CreateCubeMesh(object min, object max) { }

}

// Namespace: 
public enum ShowType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WireFrame;
	public const object Box;
}

// Namespace: 
public enum DrawType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DBuffer;
	public const object Cluster;
	public const object StaticMesh;
}

// Namespace: 
public enum ChangeReason
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object RenderOrder;
	public const object MaterialInstance;
	public const object Transform;
}

// Namespace: 
public sealed class DecalAction
{

	// Methods

	// RVA: 0x77D0194
	public object .ctor(object object, object method) { }

	// RVA: 0x77D02B0
	public virtual object Invoke(object decal) { }

	// RVA: 0x77D02C4
	public virtual object BeginInvoke(object decal, object callback, object object) { }

	// RVA: 0x77D0314
	public virtual object EndInvoke(object result) { }

}

// Namespace: Yarp
public class Decal
{

	// Fields
	public static object sOnDecalAdd; // 0x0
	public static object sOnDecalRemove; // 0x8
	private object m_ShowType; // 0x18
	private object m_DrawType; // 0x1C
	private object m_LastDrawType; // 0x20
	private object m_StaticGI; // 0x24
	private object m_RenderOrder; // 0x28
	private object m_Material; // 0x30
	private object m_OriMaterialGuid; // 0x38
	private object m_LastRenderOrder; // 0x40
	private object m_LastMaterial; // 0x48
	private object m_LastLocalToWorldMatrix; // 0x50
	private object m_PropertyBlock; // 0x90
	private object m_MeshRenderer; // 0x98

	// Properties
	public object showType { get; }
	public object drawType { get; set; }
	public object staticGI { get; }
	public object renderOrder { get; set; }
	public object material { get; set; }
	public object oriMaterialGuid { get; set; }
	public object propertyBlock { get; }
	public object meshRenderer { get; }

	// Methods

	// RVA: 0x77CEF5C
	public object get_showType() { }

	// RVA: 0x77CEF64
	public object get_drawType() { }

	// RVA: 0x77CEF6C
	public object set_drawType(object value) { }

	// RVA: 0x77CF024
	public object get_staticGI() { }

	// RVA: 0x77CF02C
	public object get_renderOrder() { }

	// RVA: 0x77CF034
	public object set_renderOrder(object value) { }

	// RVA: 0x77CF164
	public object get_material() { }

	// RVA: 0x77CF16C
	public object set_material(object value) { }

	// RVA: 0x77CF174
	public object get_oriMaterialGuid() { }

	// RVA: 0x77CF17C
	public object set_oriMaterialGuid(object value) { }

	// RVA: 0x77CF184
	public object get_propertyBlock() { }

	// RVA: 0x77CF200
	public object get_meshRenderer() { }

	// RVA: 0x77CF310
	public object Awake() { }

	// RVA: 0x77CF31C
	public object OnEnable() { }

	// RVA: 0x77CF33C
	public object IsValid() { }

	// RVA: 0x77CF32C
	private object Init() { }

	// RVA: 0x77CF3A8
	private object SetKeywordStaticDecalMesh(object enableDecalMeshKeyword) { }

	// RVA: 0x77CF03C
	private object SetRenderOrder(object renderOrder) { }

	// RVA: 0x77CF734
	public object GetCustomHashCode() { }

	// RVA: 0x77CF93C
	public object GetSize() { }

	// RVA: 0x77CF9AC
	public object GetTangentToWorldMatrix() { }

	// RVA: 0x77CFCC8
	public object GetLocalToWorldMatrix() { }

	// RVA: 0x77CFD30
	public object GetChangeReason(object lastRenderOrder, object lastMaterial) { }

	// RVA: 0x77CEFD0
	private object OnDrawTypeChanged() { }

	// RVA: 0x77CFEB4
	public object .ctor() { }

}

// Namespace: Yarp
public class DecalAtlas
{

	// Fields
	private object m_AlbedoAtlas; // 0x8
	private object m_EmissiveAtlas; // 0x10
	private object m_NormalAtlas; // 0x18
	private object m_RMAAtlas; // 0x20
	private object m_DisplacementAtlas; // 0x28

	// Properties
	public object albedoAtlas { get; }
	public object emissiveAtlas { get; }
	public object normalAtlas { get; }
	public object RMAAtlas { get; }
	public object displacementAtlas { get; }

	// Methods

	// RVA: 0x77D0320
	public object get_albedoAtlas() { }

	// RVA: 0x77D0328
	public object get_emissiveAtlas() { }

	// RVA: 0x77D0330
	public object get_normalAtlas() { }

	// RVA: 0x77D0338
	public object get_RMAAtlas() { }

	// RVA: 0x77D0340
	public object get_displacementAtlas() { }

	// RVA: 0x77D0348
	public object AddTexture(object cmd, object texture, object type) { }

	// RVA: 0x77D0738
	public object RemoveTexture(object texture, object type) { }

	// RVA: 0x77D07A4
	public object Dispose() { }

	// RVA: 0x77D0824
	public object .ctor() { }

}

// Namespace: Yarp
public enum DecalTextureType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Albedo;
	public const object Normal;
	public const object Emissive;
	public const object RMA;
	public const object Displacement;
	public const object Count;
}

// Namespace: Yarp
public class DecalConfig
{

	// Fields
	public const object enableDecalAtlas;
	public const object projectOnBackside;
	public const object maxDecalNum;
	public const object minTileSizeInAtlas;
	public const object maxDecalTextureSize;
	public const object minDecalAtlasSize;
	public const object maxDecalAtlasSize;
	public const object minDecalMeshTextureSize;
	public const object maxDecalMeshTextureSize;
	public const object cullingType;
	public static readonly object decalAlbedoMapName; // 0x0
	public static readonly object decalNormalMapName; // 0x8
	public static readonly object decalEmissiveMapName; // 0x10
	public static readonly object decalRMAMapName; // 0x18
	public static readonly object decalDisplacementName; // 0x20
	public static readonly object decalAlbedoColorName; // 0x28
	public static readonly object decalEmissiveColorName; // 0x30
	public static readonly object decalRoughnessMultiplierName; // 0x38
	public static readonly object decalMetallicMultiplierName; // 0x40
	public static readonly object decalDisplacementScaleName; // 0x48
	public static readonly object decalScaleBiasInAlbedoAtlasName; // 0x50
	public static readonly object decalScaleBiasInNormalAtlasName; // 0x58
	public static readonly object decalScaleBiasInEmissiveAtlasName; // 0x60
	public static readonly object decalScaleBiasInRMAAtlasName; // 0x68
	public static readonly object decalScaleBiasInDisplacementAtlas; // 0x70
	public static readonly object _AlbedoMap; // 0x78
	public static readonly object _NormalMap; // 0x7C
	public static readonly object _EmissiveMap; // 0x80
	public static readonly object _MaterialParamsMap; // 0x84
	public static readonly object _AlbedoColor; // 0x88
	public static readonly object _EmissiveColor; // 0x8C
	public static readonly object _RoughnessMultiplier; // 0x90
	public static readonly object _MetallicMultiplier; // 0x94
	public static readonly object _ScaleBiasInAlbedoAtlas; // 0x98
	public static readonly object _ScaleBiasInNormalAtlas; // 0x9C
	public static readonly object _ScaleBiasInEmissiveAtlas; // 0xA0
	public static readonly object _ScaleBiasInRMAAtlas; // 0xA4
	public static readonly object _ScaleBiasInDisplacementAtlas; // 0xA8
	public static readonly object _AlbedoColorsBuffer; // 0xAC
	public static readonly object _EmissiveColorBuffer; // 0xB0
	public static readonly object _RoughnessMultiplierBuffer; // 0xB4
	public static readonly object _MetallicMultiplierBuffer; // 0xB8
	public static readonly object _ScaleBiasInAlbedoAtlasBuffer; // 0xBC
	public static readonly object _ScaleBiasInNormalAtlasBuffer; // 0xC0
	public static readonly object _ScaleBiasInEmissiveAtlasBuffer; // 0xC4
	public static readonly object _ScaleBiasInRMAAtlasBuffer; // 0xC8
	public static readonly object _DecalIndicesBuffer; // 0xCC
	public static readonly object _YarpLightmap; // 0xD0
	public static readonly object _DecalAlbedoAtlas; // 0xD4
	public static readonly object _DecalNormalAtlas; // 0xD8
	public static readonly object _DecalEmissiveAtlas; // 0xDC
	public static readonly object _DecalRMAAtlas; // 0xE0
	public static readonly object _DecalDisplacementAtlas; // 0xE4
	public const object _DECAL_ATLAS;
	public const object _STATIC_DECAL_MESH;
	public const object _DECAL_CPU_CLUSTER;
	public const object _DECAL_GPU_CLUSTER;
	public const object _DECAL_DBUFFER;
	public const object _AFFECT_ALBEDO_ON;
	public const object _AFFECT_NORMAL_ON;
	public const object _AFFECT_RMA_ON;
	public const object _AFFECT_EMISSIVE_ON;
	public const object _AFFECT_DISPLACEMENT_ON;
	public const object _CLUSTER_NORMAL_ON;
	public const object AFFECT_ALBEDO;
	public const object AFFECT_EMISSIVE;
	public const object AFFECT_NORMAL;
	public const object AFFECT_RMA;
	public const object AFFECT_DISPLACEMENT;

	// Methods

	// RVA: 0x77D082C
	public object .ctor() { }

	// RVA: 0x77D0834
	private static object .cctor() { }

}

// Namespace: Yarp
public interface DecalCulling
{

	// Methods

	// RVA: -1
	public abstract object BeginCulling(object cmd, object camera) { }

	// RVA: -1
	public abstract object Culling(object cmd, object camera) { }

	// RVA: -1
	public abstract object Dispose() { }

}

// Namespace: Yarp
public class DecalNoCulling
{

	// Fields
	private object <visibleCount>k__BackingField; // 0x8
	private object <visibleIndices>k__BackingField; // 0x10

	// Properties
	public object visibleCount { get; set; }
	public object visibleIndices { get; set; }

	// Methods

	// RVA: 0x77D0E24
	public object get_visibleCount() { }

	// RVA: 0x77D0E2C
	private object set_visibleCount(object value) { }

	// RVA: 0x77D0E34
	public object get_visibleIndices() { }

	// RVA: 0x77D0E3C
	private object set_visibleIndices(object value) { }

	// RVA: 0x77D0E44
	public object BeginCulling(object cmd, object camera) { }

	// RVA: 0x77D0E48
	public object Culling(object cmd, object camera) { }

	// RVA: 0x77D0E4C
	public object Dispose() { }

	// RVA: 0x77D0E50
	public object .ctor() { }

}

// Namespace: 
public struct ComputeBoundSphereJob
{

	// Fields
	public object boundingSphereArray; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x77D1038
	public object Execute(object index, object transform) { }

	// RVA: 0x77D1074
	private object GetBoundingSphere(object transform) { }

}

// Namespace: Yarp
public class DecalCPUCulling
{

	// Fields
	private object <visibleCount>k__BackingField; // 0x8
	private object <visibleIndices>k__BackingField; // 0x10
	private readonly object m_BoundingSpheres; // 0x18
	private readonly object m_CullingGroup; // 0x20
	private const object m_MaxDistance;
	private readonly object m_BoundingDistances; // 0x28

	// Properties
	public object visibleCount { get; set; }
	public object visibleIndices { get; set; }

	// Methods

	// RVA: 0x77D0EB4
	public object get_visibleCount() { }

	// RVA: 0x77D0EBC
	private object set_visibleCount(object value) { }

	// RVA: 0x77D0EC4
	public object get_visibleIndices() { }

	// RVA: 0x77D0ECC
	private object set_visibleIndices(object value) { }

	// RVA: 0x77D0ED4
	public object BeginCulling(object cmd, object camera) { }

	// RVA: 0x77D0ED8
	public object Culling(object cmd, object camera) { }

	// RVA: 0x77D0F20
	public object Dispose() { }

	// RVA: 0x77D0F34
	public object .ctor() { }

}

// Namespace: Yarp
public class DecalGPUCulling
{

	// Methods

	// RVA: 0x77D1268
	public object BeginCulling(object cmd, object camera) { }

	// RVA: 0x77D126C
	public object Culling(object cmd, object camera) { }

	// RVA: 0x77D1270
	public object Dispose() { }

	// RVA: 0x77D1274
	public object .ctor() { }

}

// Namespace: Yarp
public struct DecalProperty
{

	// Fields
	public object localToWorldMatrix; // 0xFFFFFFFFFFFFFFF8
	public object worldToLocalMatrix; // 0x38
	public object albedoColor; // 0x78
	public object emissiveColor; // 0x88
	public object scaleBiasInAlbedoAtlas; // 0x98
	public object scaleBiasInNormalAtlas; // 0xA8
	public object scaleBiasInEmissiveAtlas; // 0xB8
	public object scaleBiasInRMAAtlas; // 0xC8
	public object scaleBiasInDisplacementAtlas; // 0xD8
	public object metallicMultiplier; // 0xE8
	public object roughnessMultiplier; // 0xEC
	public object renderOrder; // 0xF0
	public object displacementScale; // 0xF4
	public object affectFlags; // 0xF8
}

// Namespace: Yarp
public struct DecalData
{

	// Fields
	public object decalProperty; // 0xFFFFFFFFFFFFFFF8
	public object albedoMap; // 0x100
	public object normalMap; // 0x108
	public object emissiveMap; // 0x110
	public object RMAMap; // 0x118
	public object displacementMap; // 0x120
	public object clusterNormal; // 0x128

	// Methods

	// RVA: 0x77D12B8
	public object AffectAlbedo() { }

	// RVA: 0x77D12D0
	public object AffectNormal() { }

	// RVA: 0x77D12E8
	public object AffectEmissive() { }

	// RVA: 0x77D1300
	public object AffectRMA() { }

	// RVA: 0x77D1318
	public object AffectDisplacement() { }

}

// Namespace: Yarp
public class ClusterDecalDatas
{

	// Fields
	private readonly object <decalProperties>k__BackingField; // 0x8
	private readonly object <decalDatas>k__BackingField; // 0x20
	private readonly object <clusterDecals>k__BackingField; // 0x28

	// Properties
	public object decalProperties { get; }
	public object decalDatas { get; }
	public object clusterDecals { get; }
	public object decalCount { get; }

	// Methods

	// RVA: 0x77D1330
	public object get_decalProperties() { }

	// RVA: 0x77D1344
	public object get_decalDatas() { }

	// RVA: 0x77D134C
	public object get_clusterDecals() { }

	// RVA: 0x77D1354
	public object get_decalCount() { }

	// RVA: 0x77D13B0
	public object Dispose() { }

	// RVA: 0x77D1420
	public object RefreshDatas(object changedDecals, object removedDecals) { }

	// RVA: 0x77D1728
	private object RefreshData(object decal, object decalID) { }

	// RVA: 0x77D187C
	private object RemoveData(object decalID) { }

	// RVA: 0x77D19C8
	public object .ctor() { }

}

// Namespace: 
public class DecalBatch
{

	// Fields
	private readonly object <material>k__BackingField; // 0x8
	private readonly object <renderOrder>k__BackingField; // 0x10
	private readonly object <hashCode>k__BackingField; // 0x14
	public object localToWorldMatrices; // 0x18
	private const object INITIAL_LENGTH;

	// Properties
	public object material { get; }
	public object renderOrder { get; }
	public object length { get; }
	public object hashCode { get; }

	// Methods

	// RVA: 0x77D2ABC
	public object get_material() { }

	// RVA: 0x77D2AC4
	public object get_renderOrder() { }

	// RVA: 0x77D2ACC
	public object get_length() { }

	// RVA: 0x77D2B20
	public object get_hashCode() { }

	// RVA: 0x77D25F8
	public object .ctor(object material, object renderOrder) { }

	// RVA: 0x77D2C70
	public object Equals(object other) { }

	// RVA: 0x77D2C90
	public object CompareTo(object other) { }

	// RVA: 0x77D2CCC
	public override object GetHashCode() { }

	// RVA: 0x77D28D0
	public object Refresh(object decal, object decalID) { }

	// RVA: 0x77D2988
	public object Remove(object decalID) { }

	// RVA: 0x77D1D04
	public object Dispose() { }

	// RVA: 0x77D2B28
	private object GetCustomHashCode() { }

}

// Namespace: Yarp
public class BatchedDecalDatas
{

	// Fields
	private readonly object <decalBatches>k__BackingField; // 0x8
	private readonly object <sortedDecalBatches>k__BackingField; // 0x10

	// Properties
	public object decalBatches { get; }
	public object sortedDecalBatches { get; }

	// Methods

	// RVA: 0x77D1AE4
	public object Dispose() { }

	// RVA: 0x77D1D98
	public object RefreshDatas(object changedDecals, object removedDecals) { }

	// RVA: 0x77D26AC
	private object ProcessChangeReason(object decal, object decalID) { }

	// RVA: 0x77D29E4
	public object get_decalBatches() { }

	// RVA: 0x77D29EC
	public object get_sortedDecalBatches() { }

	// RVA: 0x77D29F4
	public object .ctor() { }

}

// Namespace: Yarp
public class DecalDataCollector
{

	// Fields
	private object m_ClusterDecalDatas; // 0x8
	private object m_BatchedDecalDatas; // 0x10

	// Properties
	public object clusterDecalDatas { get; }
	public object batchedDecalDatas { get; }

	// Methods

	// RVA: 0x77CB0A4
	public object get_clusterDecalDatas() { }

	// RVA: 0x77D2CD0
	public object get_batchedDecalDatas() { }

	// RVA: 0x77D2D48
	public object Dispose() { }

	// RVA: 0x77D2DCC
	public object Update(object changedDecals, object removedDecals, object needDBuffer, object needCluster) { }

	// RVA: 0x77D2EE4
	public object .ctor() { }

}

// Namespace: Yarp
public static class DecalDataExtension
{

	// Methods

	// RVA: 0x77D195C
	public static object GetDecalData(object decal) { }

	// RVA: 0x77D2EEC
	public static object GetDecalData(object decal, object decalData) { }

	// RVA: 0x77D3D24
	private static object GetScaleBiasInAtlas(object texture, object atlas) { }

}

// Namespace: Yarp
public class DecalDBuffer
{

	// Fields
	private readonly object m_PropertyBlock; // 0x8
	private object m_DBufferFBO; // 0x10
	private object m_DBufferPassID; // 0x18
	private object m_BlendDBufferIntoGBufferMat; // 0x20
	private readonly object m_DepthTextureShaderID; // 0x28
	private readonly object m_DBufferAlbedoShaderID; // 0x2C
	private readonly object m_DBufferNormalShaderID; // 0x30
	private readonly object m_DBufferRMAShaderID; // 0x34
	private readonly object m_DBufferEmissiveShaderID; // 0x38

	// Methods

	// RVA: 0x77D3F4C
	public object RenderForward(object cmd, object depthTexture, object cameraData, object width, object height) { }

	// RVA: 0x77D512C
	public object Dispose() { }

	// RVA: 0x77D515C
	public object Resize(object width, object height) { }

	// RVA: 0x77D4B14
	private object RenderDBuffer(object cmd, object depthTexture) { }

	// RVA: 0x77D4994
	private object InitDBufferFBO(object width, object height) { }

	// RVA: 0x77D459C
	private object InitDBufferPassID() { }

	// RVA: 0x77D53D4
	public object .ctor() { }

}

// Namespace: Yarp
public struct InstancingDataIndex
{

	// Fields
	public object index0; // 0xFFFFFFFFFFFFFFF8
	public object index1; // 0xFFFFFFFFFFFFFFFC
	public object index2; // 0x0

	// Methods

	// RVA: 0x77D550C
	public object .ctor(object index0, object index1, object index2) { }

}

// Namespace: Yarp
public class InstancingBuffer
{

	// Fields
	public object albedoColorsBuffer; // 0x8
	public object emissiveColorsBuffer; // 0x10
	public object roughnessMultipliersBuffer; // 0x18
	public object metallicMultipliersBuffer; // 0x20
	public object scaleBiasInAlbedoAtlasBuffer; // 0x28
	public object scaleBiasInNormalAtlasBuffer; // 0x30
	public object scaleBiasInEmissiveAtlasBuffer; // 0x38
	public object scaleBiasInRMAAtlasBuffer; // 0x40
	public object indicesBuffer; // 0x48

	// Methods

	// RVA: 0x77D5524
	public object Release() { }

	// RVA: 0x77D55F4
	public object .ctor() { }

}

// Namespace: Yarp
public interface IDecalDrawing
{

	// Methods

	// RVA: -1
	public abstract object Draw(object cmd, object cullingImpl) { }

	// RVA: -1
	public abstract object Dispose() { }

}

// Namespace: Yarp
public enum DefaultTextureType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object UnityBuiltin;
	public const object Yarp;
}

// Namespace: Yarp
public struct AABB
{

	// Fields
	public object min; // 0xFFFFFFFFFFFFFFF8
	public object max; // 0x4

	// Methods

	// RVA: 0x77D55FC
	public object Intersect(object other) { }

	// RVA: 0x77D5714
	public object Union(object other) { }

	// RVA: 0x77D5808
	public object Offset(object p) { }

}

// Namespace: Yarp
public struct OBB
{

	// Fields
	public object right; // 0xFFFFFFFFFFFFFFF8
	public object extentX; // 0x4
	public object up; // 0x8
	public object extentY; // 0x14
	public object forward; // 0x18
	public object extentZ; // 0x24
	public object center; // 0x28
	public object radius; // 0x34
}

// Namespace: Yarp
internal struct Frustum
{

	// Fields
	public object normal0; // 0xFFFFFFFFFFFFFFF8
	public object dist0; // 0x4
	public object normal1; // 0x8
	public object dist1; // 0x14
	public object normal2; // 0x18
	public object dist2; // 0x24
	public object normal3; // 0x28
	public object dist3; // 0x34
	public object normal4; // 0x38
	public object dist4; // 0x44
	public object normal5; // 0x48
	public object dist5; // 0x54
	private object m_InnerPlanes; // 0x58

	// Methods

	// RVA: 0x77D5D04
	public object UpdateCameraFrustum(object inputCamera) { }

}

// Namespace: Yarp
public static class DecalExtensions
{

	// Methods

	// RVA: 0x77D6308
	public static object GetMaxTextureSize(object meshRenderer) { }

	// RVA: 0x77D68E0
	public static object UpdateBoundingSphere(object decal, object bs) { }

	// RVA: 0x77D6BAC
	public static object UpdateBounds(object decal, object bounds) { }

	// RVA: 0x77D720C
	public static object GetAABB(object decal) { }

	// RVA: 0x77D7500
	public static object UpdateOBB(object decal, object obb) { }

	// RVA: 0x77D7538
	public static object UpdateOBB(object transform, object obb) { }

	// RVA: 0x77D768C
	public static object UpdateViewSpaceAABB(object localToWorldMatrix, object worldToCameraMatrix, object viewAABB) { }

	// RVA: 0x77D6D6C
	public static object UpdateAABB(object matrix, object vertices, object aabb) { }

	// RVA: 0x77D73C4
	public static object GetAABB(object matrix) { }

	// RVA: 0x77D7788
	public static object UpdateViewSpaceAABB(object decal, object worldToCameraMatrix, object viewAABB) { }

}

// Namespace: Yarp
public static class MaterialExtensions
{

	// Methods

	// RVA: 0x77CF87C
	public static object GetDecalMaterialHashCode(object material, object renderOrder) { }

	// RVA: 0x77D3A78
	public static object TryGetTextureWithYarpDefaultTexture(object material, object propName, object defaultValue) { }

	// RVA: 0x77D7A28
	public static object TryGetTextureWithoutDefaultTexture(object material, object propName, object defaultValue) { }

	// RVA: 0x77D7A90
	public static object GetPBRTextures(object material, object defaultTextureType, object albedoMap, object normalMap, object emissiveMap, object RMAMap, object displacementMap) { }

	// RVA: 0x77D63E4
	public static object GetMaxTextureSize(object material) { }

}

// Namespace: Yarp
public static class ColorExtensions
{

	// Methods

	// RVA: 0x77D3D20
	public static object ToFloat4(object color) { }

}

// Namespace: Yarp
public static class MathExtensions
{

	// Methods

	// RVA: 0x77D7F28
	public static object EncodeMorton3(object x, object y, object z) { }

	// RVA: 0x77D8010
	private static object LeftShift3(object x) { }

}

// Namespace: Yarp
public static class DecalUtils
{

	// Methods

	// RVA: 0x77D8058
	public static object SafeDestroy(object obj) { }

}

// Namespace: Yarp
public static class DecalResources
{

	// Fields
	private static object m_DecalMesh; // 0x0
	private static object m_WhiteTexture; // 0x8
	private static object m_BlackTexture; // 0x10
	private static object m_BumpTexture; // 0x18

	// Properties
	public static object decalMesh { get; }
	public static object whiteTexture { get; }
	public static object blackTexture { get; }
	public static object bumpTexture { get; }

	// Methods

	// RVA: 0x77D5178
	public static object get_decalMesh() { }

	// RVA: 0x77D78E0
	public static object get_whiteTexture() { }

	// RVA: 0x77D783C
	public static object get_blackTexture() { }

	// RVA: 0x77D7984
	public static object get_bumpTexture() { }

}

// Namespace: Yarp
public enum DecalCommandType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AddDecalTextureToAtlas;
	public const object RemoveDecalTextureFromAtlas;
	public const object CustomCommandAction;
	public const object DelayedAction;
}

// Namespace: Yarp
public class DecalTextureBundle
{

	// Fields
	public object texture; // 0x8
	public object type; // 0x10

	// Methods

	// RVA: 0x77D8128
	public object .ctor(object texture, object type) { }

}

// Namespace: Yarp
public struct DecalCommand
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object decal; // 0x0
	public object customAction; // 0x8
	public object parameters; // 0x10
}

// Namespace: 
public class DispatcherData
{

	// Fields
	private object m_ObjectDispatcher; // 0x8
	public object changedDecalData; // 0x10
	public object changedDecalMaterialData; // 0x70
	public object changedDecalTransformData; // 0xD0
	private object m_HasGetTppeChanges; // 0x140

	// Methods

	// RVA: 0x77DBBD4
	public object OnEnable() { }

	// RVA: 0x77DBCD8
	public object Update() { }

	// RVA: 0x77DBEC0
	public object Reboot() { }

	// RVA: 0x77DC024
	public object OnDisable() { }

	// RVA: 0x77DBE74
	private object Clear() { }

	// RVA: 0x77DC088
	public object .ctor() { }

}

// Namespace: Yarp
public class DecalManager
{

	// Fields
	private readonly object m_ChangedDecalIDs; // 0x8
	private readonly object m_RemovedDecalIDs; // 0x10
	private readonly object m_MaterialDecalMaps; // 0x18
	private readonly object m_DecalCommandQueue; // 0x20
	private readonly object m_DelayedCommands; // 0x28
	private object m_LastDecalShadingType; // 0x30
	public object decalDataCollector; // 0x38
	public readonly object allDecals; // 0x40
	public object allDecalMatrices; // 0x48
	private object <decalAtlas>k__BackingField; // 0x60
	public readonly object dispatcherData; // 0x68

	// Properties
	public object decalAtlas { get; set; }

	// Methods

	// RVA: 0x77D81A0
	public object get_decalAtlas() { }

	// RVA: 0x77D81A8
	private object set_decalAtlas(object value) { }

	// RVA: 0x77CAFEC
	public static object Instance() { }

	// RVA: 0x77D531C
	public static object HasInstance() { }

	// RVA: 0x77D81B0
	public override object OnEnable() { }

	// RVA: 0x77D81D4
	public override object OnDisable() { }

	// RVA: 0x77D82E4
	public override object Update(object _) { }

	// RVA: 0x77D8308
	public override object GetTrackingFlags() { }

	// RVA: 0x77D8310
	public override object OnFrameBegin(object cmd, object rendererBundleDict) { }

	// RVA: 0x77D8210
	private object Dispose() { }

	// RVA: 0x77D9C18
	private object Clear() { }

	// RVA: 0x77D88A8
	private object CollectDispatcherChangedDecal(object cmd, object needDecalAtlas) { }

	// RVA: 0x77D9EA8
	private object OnDecalCreated(object cmd, object decal, object needDecalAtlas) { }

	// RVA: 0x77DA664
	private object OnDecalDestroyed(object decalID, object needDecalAtlas) { }

	// RVA: 0x77DAD6C
	private object AddDecalMaterialMap(object decal) { }

	// RVA: 0x77DAF90
	private object RemoveDecalMaterialMap(object decalID) { }

	// RVA: 0x77DA520
	private object UpdateDecalMaterialMap(object decal, object decalID) { }

	// RVA: 0x77D91B4
	private object ProcessCommand(object cmd, object needDecalAtlas) { }

	// RVA: 0x77DB41C
	private object AddAllExistedDecalToChanged() { }

	// RVA: 0x77D9694
	private object CollectDecalData(object needDBuffer, object needCluster) { }

	// RVA: 0x77DAF10
	public object EnqueueDecalCommand(object command) { }

	// RVA: 0x77DB154
	private object DequeueDecalCommand() { }

	// RVA: 0x77D96C4
	private object UpdateDecalAtlasToShader(object cmd, object needDecalAtlas) { }

	// RVA: 0x77DB1C0
	private object AddDecalTextureToAtlas(object cmd, object parameters) { }

	// RVA: 0x77DB66C
	private object RemoveTextureFromAtlas(object cmd, object parameters) { }

	// RVA: 0x77D84EC
	private object CollectRequirements(object rendererBundleDict, object needDecalAtlas, object needDBuffer, object needCluster, object needReboot) { }

	// RVA: 0x77DB8BC
	private object NeedDecalAtlas(object decalSetting) { }

	// RVA: 0x77DB8E4
	private object NeedDBuffer(object decalSetting) { }

	// RVA: 0x77DB90C
	private object NeedCluster(object decalSetting) { }

	// RVA: 0x77D8844
	private object RebootDispatcher(object needReboot) { }

	// RVA: 0x77DB974
	public object .ctor() { }

}

// Namespace: Yarp
public static class DecalMeshHelper
{
}

// Namespace: Yarp
public class TrimmedSubMesh
{

	// Fields
	public object mesh; // 0x8
	public object renderer; // 0x10
	public object subMeshIndex; // 0x18
	public object resTriangleCount; // 0x1C
	public object uTexelsCount; // 0x20
	public object vTexelsCount; // 0x24
	public object uvArea; // 0x28
	public object maxTexSize; // 0x2C
	public object decalMeshTexSize; // 0x34
	public object totalPackSize; // 0x3C
	public object sizePosition; // 0x44
	public object scaleOffset; // 0x54
	public object aabb; // 0x64
	public object dmMesh; // 0x80
	public object trimmedTriangles; // 0xC0

	// Methods

	// RVA: 0x77DC090
	public object .ctor() { }

	// RVA: 0x77DC0D0
	public object IsValid() { }

	// RVA: 0x77DC0E0
	public object Dispose() { }

}

// Namespace: 
private struct Counters
{

	// Fields
	public object uTexelsCounts; // 0xFFFFFFFFFFFFFFF8
	public object vTexelsCounts; // 0x8
	public object uvAreas; // 0x18
	public object resTriangleCounts; // 0x28
	public object uTexelsCounters; // 0x38
	public object vTexelsCounters; // 0x48
	public object uvAreaCounters; // 0x58
	public object resTriangleCounters; // 0x68

	// Methods

	// RVA: 0x77DEDA0
	public object Dispose() { }

}

// Namespace: 
private sealed class <>c__DisplayClass9_0
{

	// Fields
	public object centroid; // 0x8
	public object sameDimensions; // 0x14

	// Methods

	// RVA: 0x77E0CBC
	public object .ctor() { }

	// RVA: 0x77E0CC4
	internal object <TrimTriangle>b__0(object a, object b) { }

}

// Namespace: 
private sealed class <BoxIntersectTriangle>d__11
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x2C
	private object triangle; // 0x30
	public object <>3__triangle; // 0xA0
	private object <>7__wrap1; // 0x110
	private object <>7__wrap2; // 0x118
	private object <corner>5__4; // 0x11C

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77E06A8
	public object .ctor(object <>1__state) { }

	// RVA: 0x77E0D0C
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77E0D10
	private object MoveNext() { }

	// RVA: 0x77E182C
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.get_Current() { }

	// RVA: 0x77E183C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77E187C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x77E18E8
	private object System.Collections.Generic.IEnumerable<Yarp.DMVertex>.GetEnumerator() { }

	// RVA: 0x77E1990
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <GetVerticesFromTrimmingTriangle>d__10
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x2C
	private object triangle; // 0x30
	public object <>3__triangle; // 0xA0
	private object <isTriangleInsideDecal>5__2; // 0x110
	private object <>7__wrap2; // 0x118

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77E05E8
	public object .ctor(object <>1__state) { }

	// RVA: 0x77E1A38
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77E1C68
	private object MoveNext() { }

	// RVA: 0x77E267C
	private object <>m__Finally1() { }

	// RVA: 0x77E2768
	private object <>m__Finally2() { }

	// RVA: 0x77E2854
	private object <>m__Finally3() { }

	// RVA: 0x77E2974
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.get_Current() { }

	// RVA: 0x77E2984
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77E29C4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x77E2A30
	private object System.Collections.Generic.IEnumerable<Yarp.DMVertex>.GetEnumerator() { }

	// RVA: 0x77E2AD8
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <TriangleIntersectBox>d__12
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x2C
	private object triangle; // 0x30
	public object <>3__triangle; // 0xA0
	private object <>7__wrap1; // 0x110
	private object <edge>5__3; // 0x118
	private object <>7__wrap3; // 0x158
	private object <dimension>5__5; // 0x160
	private object <>7__wrap5; // 0x168

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77E0768
	public object .ctor(object <>1__state) { }

	// RVA: 0x77E2B80
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77E2FDC
	private object MoveNext() { }

	// RVA: 0x77E3F68
	private object <>m__Finally1() { }

	// RVA: 0x77E3E70
	private object <>m__Finally2() { }

	// RVA: 0x77E3C98
	private object <>m__Finally3() { }

	// RVA: 0x77E3D84
	private object <>m__Finally4() { }

	// RVA: 0x77E4088
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.get_Current() { }

	// RVA: 0x77E4098
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77E40D8
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x77E4144
	private object System.Collections.Generic.IEnumerable<Yarp.DMVertex>.GetEnumerator() { }

	// RVA: 0x77E41EC
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <TriangleIntersectBoxFace>d__13
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x2C
	private object edge; // 0x30
	public object <>3__edge; // 0x70
	private object positiveFace; // 0xB0
	public object <>3__positiveFace; // 0xB1
	private object dimension; // 0xB4
	public object <>3__dimension; // 0xB8

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77E0840
	public object .ctor(object <>1__state) { }

	// RVA: 0x77E4294
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77E4298
	private object MoveNext() { }

	// RVA: 0x77E4994
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.get_Current() { }

	// RVA: 0x77E49A4
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77E49E4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x77E4A50
	private object System.Collections.Generic.IEnumerable<Yarp.DMVertex>.GetEnumerator() { }

	// RVA: 0x77E4B0C
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <TrimTriangle>d__9
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x7C
	private object triangle; // 0x80
	public object <>3__triangle; // 0xF0
	private object <trimmedVertices>5__2; // 0x160
	private object <i>5__3; // 0x168

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.DMTriangle>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77E0528
	public object .ctor(object <>1__state) { }

	// RVA: 0x77E4BC8
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77E4BCC
	private object MoveNext() { }

	// RVA: 0x77E508C
	private object System.Collections.Generic.IEnumerator<Yarp.DMTriangle>.get_Current() { }

	// RVA: 0x77E50BC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77E50FC
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x77E5188
	private object System.Collections.Generic.IEnumerable<Yarp.DMTriangle>.GetEnumerator() { }

	// RVA: 0x77E5230
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private struct TrimTriangleJob
{

	// Fields
	public object mesh; // 0xFFFFFFFFFFFFFFF8
	public object maxTriangleCount; // 0x38
	public object maxTextureSize; // 0x3C
	public object triangles; // 0x48
	public object uTexelsCounter; // 0x58
	public object vTexelsCounter; // 0x60
	public object totalUVAreaCounter; // 0x68
	public object resTriangleCounter; // 0x70

	// Methods

	// RVA: 0x77DFAF0
	public object Execute(object index) { }

	// RVA: 0x77E0414
	private static object TrimTriangle(object triangle) { }

	// RVA: 0x77E0560
	private static object GetVerticesFromTrimmingTriangle(object triangle) { }

	// RVA: 0x77E0620
	private static object BoxIntersectTriangle(object triangle) { }

	// RVA: 0x77E06E0
	private static object TriangleIntersectBox(object triangle) { }

	// RVA: 0x77E07A0
	private static object TriangleIntersectBoxFace(object edge, object dimension, object positiveFace) { }

	// RVA: 0x77E0878
	private static object ComputeCentroid(object vertices, object sameDimensions) { }

	// RVA: 0x77E0B1C
	private static object CompareVertices(object a, object b, object centroid, object sameDimensions) { }

	// RVA: 0x77E0C34
	private static object AngleAroundCentroid(object centroid0, object centroid1, object vertexPos0, object vertexPos1) { }

}

// Namespace: Yarp
public class DecalMeshProjection
{

	// Fields
	private const object MAX_TRIMMED_TRIANGLE_COUNT;
	private const object ENABLE_PARALLEL;

	// Methods

	// RVA: 0x77DC1FC
	public static object GenerateDecalMesh(object trimmedRenderers, object decalTransform, object trimmedSubMeshes) { }

	// RVA: 0x77DCA8C
	private static object ScheduleTrimJobs(object decalTransform, object trimmedSubMeshes, object trimTriangleJobHandles, object counters, object persistentAllocator, object immediatelyStart) { }

	// RVA: 0x77DC9F8
	private static object CreateCounters(object trimmedSubMeshes, object counters) { }

	// RVA: 0x77DF020
	private static object CreateCounters(object size, object counts, object counters) { }

	// RVA: 0x77DC4B8
	private static object GetTrimmedSubMeshes(object trimmedRenderers) { }

	// RVA: 0x77DD20C
	private static object SyncTrimmedTriangleResult(object trimTriangleJobHandles) { }

	// RVA: 0x77DD354
	private static object ValidateTrimmedSubMeshes(object trimmedSubMeshes, object counters) { }

	// RVA: 0x77DDBE8
	private static object ComputeDecalMeshTexSize(object trimmedSubMeshes) { }

	// RVA: 0x77DF214
	private static object ComputeTextureSize(object uvArea, object uTexelsCount, object vTexelsCount, object widthHeightRatioWS, object width, object height) { }

	// RVA: 0x77DDD0C
	private static object PackDecalMeshTex(object trimmedSubMeshes) { }

	// RVA: 0x77DD4DC
	private static object ComputeBounds(object trimmedSubMeshes) { }

	// RVA: 0x77DF494
	private static object ComputePackedUV(object pos, object subMeshMinPos, object subMeshMaxPos, object scaleOffset) { }

	// RVA: 0x77DDF54
	private static object CreateUnityMesh(object trimmedSubMeshes) { }

	// RVA: 0x77DF4C8
	private static object ComputeTangents(object mesh) { }

	// RVA: 0x77DEE5C
	private static object TransformPointFromLocalAToLocalB(object posLocalA, object transformA, object transformB) { }

	// RVA: 0x77DFA7C
	private static object TransformDirectionFromLocalAToLocalB(object dirLocalA, object transformA, object transformB) { }

	// RVA: 0x77DEEC0
	private static object TransformNormalFromLocalAToLocalB(object dirLocalA, object transformA, object transformB) { }

	// RVA: 0x77DFAE0
	public object .ctor() { }

}

// Namespace: Yarp
public enum DMDimension
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object x;
	public const object y;
	public const object z;
}

// Namespace: Yarp
public struct DMEdge
{

	// Fields
	public readonly object a; // 0xFFFFFFFFFFFFFFF8
	public readonly object b; // 0x18

	// Methods

	// RVA: 0x77E52D8
	public object .ctor(object a, object b) { }

	// RVA: 0x77E4960
	public object LerpVertex(object t) { }

	// RVA: 0x77E4808
	public object GetRatioInDimension(object posInDimension, object dimension) { }

	// RVA: 0x77E48E0
	public object LerpInDimension(object t, object dimension) { }

}

// Namespace: Yarp
public struct DMMesh
{

	// Fields
	public object indices; // 0xFFFFFFFFFFFFFFF8
	public object positions; // 0x8
	public object normals; // 0x18
	public object targetUVs; // 0x28

	// Properties
	public object triangleCount { get; }

	// Methods

	// RVA: 0x77DF000
	public object get_triangleCount() { }

	// RVA: 0x77DEFE8
	public object .ctor(object indices, object positions, object normals, object uvs) { }

	// RVA: 0x77DC148
	public object Dispose() { }

}

// Namespace: Yarp
public static class Float3Extension
{

	// Methods

	// RVA: 0x77E565C
	public static object isValid(object value) { }

}

// Namespace: Yarp
public struct DMVertex
{

	// Fields
	public readonly object position; // 0xFFFFFFFFFFFFFFF8
	public readonly object normal; // 0x4
	public readonly object uv; // 0x10

	// Methods

	// RVA: 0x77E0250
	public object .ctor(object position, object normal, object uv) { }

	// RVA: 0x77E5310
	public static object LerpVertex(object a, object b, object t) { }

}

// Namespace: 
private sealed class <EnumerateEdges>d__14
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x4C
	public object <>4__this; // 0x50
	public object <>3__<>4__this; // 0xC0

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.DMEdge>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77E59FC
	public object .ctor(object <>1__state) { }

	// RVA: 0x77E5FCC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77E5FD0
	private object MoveNext() { }

	// RVA: 0x77E60BC
	private object System.Collections.Generic.IEnumerator<Yarp.DMEdge>.get_Current() { }

	// RVA: 0x77E60D8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77E6118
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x77E6190
	private object System.Collections.Generic.IEnumerable<Yarp.DMEdge>.GetEnumerator() { }

	// RVA: 0x77E6238
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__12
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	public object <>4__this; // 0x2C

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77E5868
	public object .ctor(object <>1__state) { }

	// RVA: 0x77E62E0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77E62E4
	private object MoveNext() { }

	// RVA: 0x77E6358
	private object System.Collections.Generic.IEnumerator<Yarp.DMVertex>.get_Current() { }

	// RVA: 0x77E6368
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77E63A8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Yarp
public struct DMTriangle
{

	// Fields
	public readonly object IsValid; // 0xFFFFFFFFFFFFFFF8
	public readonly object a; // 0xFFFFFFFFFFFFFFFC
	public readonly object b; // 0x1C
	public readonly object c; // 0x3C
	private object m_FlatNormal; // 0x5C

	// Properties
	public object flatNormal { get; }
	public object uvArea { get; }
	public object maxUVRange { get; }

	// Methods

	// RVA: 0x77E02A8
	public object get_flatNormal() { }

	// RVA: 0x77E04EC
	public object get_uvArea() { }

	// RVA: 0x77E049C
	public object get_maxUVRange() { }

	// RVA: 0x77E0264
	public object .ctor(object a, object b, object c) { }

	// RVA: 0x77DF3DC
	public object GetEnumerator() { }

	// RVA: 0x77E590C
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x77E3C10
	public object EnumerateEdges() { }

	// RVA: 0x77E1174
	public object XAxisRayTriangleIntersection(object y, object z) { }

	// RVA: 0x77E1670
	public object YAxisRayTriangleIntersection(object x, object z) { }

	// RVA: 0x77E1754
	public object ZAxisRayTriangleIntersection(object x, object y) { }

	// RVA: 0x77E11B8
	public object ComputeCoordXOnTriangle(object y, object z) { }

	// RVA: 0x77E16C4
	public object ComputeCoordYOnTriangle(object x, object z) { }

	// RVA: 0x77E179C
	public object ComputeCoordZOnTriangle(object x, object y) { }

	// RVA: 0x77E1248
	public object ComputeNormal(object p) { }

	// RVA: 0x77E1498
	public object ComputeUV(object p) { }

	// RVA: 0x77E5044
	public object IsConsistentNormal() { }

	// RVA: 0x77E5E80
	private static object ComputeBarycentric(object a, object b, object c, object p) { }

	// RVA: 0x77E5ABC
	private static object IsInside(object a, object b, object c, object p) { }

}

// Namespace: Yarp
public class DecalSystem
{

	// Fields
	private readonly object m_GPUClusterDecal; // 0x8
	private readonly object m_CPUClusterDecal; // 0x10
	private readonly object m_DecalDBuffer; // 0x18
	private object m_LastDecalShadingType; // 0x20
	private static readonly object _DepthTexture; // 0x0

	// Methods

	// RVA: 0x77E6414
	public object Render(object cmd, object cameraData, object depthTexture, object decalSetting, object gBufferFbo, object deferred) { }

	// RVA: 0x77E6B20
	public object Resize(object width, object height) { }

	// RVA: 0x77E6B34
	public object Dispose(object cmd) { }

	// RVA: 0x77E6878
	private object Cleanup(object cmd) { }

	// RVA: 0x77E67C8
	private object DisableKeyword(object cmd) { }

	// RVA: 0x77E6B90
	public object .ctor() { }

	// RVA: 0x77E6CF8
	private static object .cctor() { }

}

// Namespace: Yarp
public class GPUClusterDecal
{

	// Fields
	private object m_DecalOBBBuffer; // 0x8
	private readonly object m_ClusterDecalCommon; // 0x10
	private readonly object <clusterCulling>k__BackingField; // 0x18

	// Properties
	public object clusterCulling { get; }

	// Methods

	// RVA: 0x77E6D6C
	public object get_clusterCulling() { }

	// RVA: 0x77E696C
	public object Render(object cmd, object camera, object depthTexture, object decalSetting) { }

	// RVA: 0x77E6B38
	public object Dispose(object cmd) { }

	// RVA: 0x77E6D74
	private object UpdateResource(object cmd) { }

	// RVA: 0x77E6C60
	public object .ctor() { }

}

// Namespace: Yarp
public enum CullingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoCulling;
	public const object CPUCulling;
}

// Namespace: Yarp
public enum InstancingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoInstancing;
	public const object Instancing;
	public const object CustomInstancing;
}

// Namespace: Yarp
public class IndividualDecal
{

	// Fields
	private readonly object m_DecalCullingImpl; // 0x8
	private readonly object m_DecalDrawingImpl; // 0x10
	private const object _CUSTOM_INSTANCING_ON;

	// Methods

	// RVA: 0x77E6DD4
	public object .ctor() { }

	// RVA: 0x77E6E44
	public object BeginRender(object cmd, object camera) { }

	// RVA: 0x77E6F28
	public object RenderBeforeOpaque(object cmd) { }

	// RVA: 0x77E6F2C
	public object RenderAfterOpaque(object cmd, object camera) { }

	// RVA: 0x77E70B8
	public object Dispose() { }

}

// Namespace: Yarp
public interface IStorage<T0>
{

	// Properties
	public abstract object Length { get; }
	public abstract object Item { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_Length() { }

	// RVA: -1
	public abstract object get_Item(object index) { }

	// RVA: -1
	public abstract object set_Item(object index, object value) { }

	// RVA: -1
	public abstract object Initialize(object allocator, object initialCapacity) { }

	// RVA: -1
	public abstract object Add(object item) { }

	// RVA: -1
	public abstract object RemoveAtSwapBack(object index) { }

	// RVA: -1
	public abstract object Clear() { }

	// RVA: -1
	public abstract object Dispose() { }

}

// Namespace: Yarp
public struct NativeListStorage<T0>
{

	// Fields
	private object m_List; // 0x0

	// Properties
	public object Length { get; }
	public object datas { get; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_datas() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object Initialize(object allocator, object initialCapacity) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object RemoveAtSwapBack(object index) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Yarp
public struct NativeArrayStorage<T0>
{

	// Fields
	private object m_Array; // 0x0
	private object m_Length; // 0x0
	private object m_Allocator; // 0x0

	// Properties
	public object Length { get; }
	public object datas { get; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_datas() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object Initialize(object allocator, object initialCapacity) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object RemoveAtSwapBack(object index) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Yarp
public struct ManagedArrayStorage<T0>
{

	// Fields
	private object m_Array; // 0x0
	private object m_Length; // 0x0

	// Properties
	public object Length { get; }
	public object datas { get; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_datas() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object Initialize(object allocator, object initialCapacity) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object RemoveAtSwapBack(object index) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Yarp
public struct CoreWrapper<T0, T1, T2>
{

	// Fields
	public object datas; // 0x0
	private object m_InstanceIDs; // 0x0
	private readonly object m_IndexingMap; // 0x0

	// Properties
	public object Length { get; }

	// Methods

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object .ctor(object allocator, object initialCapacity) { }

	// RVA: -1
	public object Add(object instanceID, object data) { }

	// RVA: -1
	public object Update(object instanceID, object data) { }

	// RVA: -1
	public static object Update(object wrapper, object instanceID, object data) { }

	// RVA: -1
	public object Remove(object instanceID) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Yarp
public struct NativeListWrapper<T0>
{

	// Fields
	private object m_Wrapper; // 0x0

	// Properties
	public object Length { get; }
	public object datas { get; }

	// Methods

	// RVA: -1
	public object .ctor(object allocator, object initialCapacity) { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_datas() { }

	// RVA: -1
	public object Add(object id, object data) { }

	// RVA: -1
	public object Update(object id, object data) { }

	// RVA: -1
	public object Remove(object id) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Yarp
public struct NativeArrayWrapper<T0>
{

	// Fields
	private object m_Wrapper; // 0x0

	// Properties
	public object Length { get; }
	public object datas { get; }

	// Methods

	// RVA: -1
	public object .ctor(object allocator, object initialCapacity) { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_datas() { }

	// RVA: -1
	public object Add(object id, object data) { }

	// RVA: -1
	public object Update(object id, object data) { }

	// RVA: -1
	public object Remove(object id) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Yarp
public struct ManagedArrayWrapper<T0>
{

	// Fields
	private object m_Wrapper; // 0x0

	// Properties
	public object Length { get; }
	public object datas { get; }

	// Methods

	// RVA: -1
	public object .ctor(object initialCapacity) { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_datas() { }

	// RVA: -1
	public object Add(object id, object data) { }

	// RVA: -1
	public object Update(object id, object data) { }

	// RVA: -1
	public object Remove(object id) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Yarp
public class AtlasTileHandleCount
{

	// Fields
	public object handle; // 0x8
	public object count; // 0xC

	// Methods

	// RVA: 0x77E7230
	public object .ctor(object handle, object count) { }

	// RVA: 0x77E7268
	public object .ctor() { }

}

// Namespace: Yarp
public class Texture2DAtlas
{

	// Fields
	private object m_Texture2DAtlas; // 0x8
	private object m_RectAllocator; // 0x10
	private object m_TextureHandleCountCache; // 0x18
	private readonly object m_MinTileSize; // 0x20
	private readonly object m_Format; // 0x24
	private readonly object m_FilterMode; // 0x28
	private readonly object m_UseMipmap; // 0x2C
	private const object ALIGNMENT;
	private const object MIN_RESOLUTION;
	private const object MAX_RESOLUTION;

	// Properties
	public object atlas { get; }

	// Methods

	// RVA: 0x77E7294
	public object get_atlas() { }

	// RVA: 0x77E729C
	public object .ctor(object format, object name, object filterMode, object minTileSize, object useMipmap) { }

	// RVA: 0x77E7588
	public object IsCached(object texture) { }

	// RVA: 0x77E76A0
	public object GetCachedCount(object texture) { }

	// RVA: 0x77E775C
	public object AddTexture(object cmd, object texture, object addRef) { }

	// RVA: 0x77E855C
	public object RemoveTexture(object texture) { }

	// RVA: 0x77E8684
	public object GetScaleBias(object texture) { }

	// RVA: 0x77E876C
	public object Dispose() { }

	// RVA: 0x77E7CA4
	private object CopyToAtlas(object cmd, object texture, object textureSizeLocation) { }

	// RVA: 0x77E7F5C
	private object GrowAtlasSize(object cmd, object texture, object addRef) { }

	// RVA: 0x77E7E0C
	private object AddTextureRef(object texture, object handle, object addRef) { }

	// RVA: 0x77E7BF8
	private object AddTextureRef(object texture, object addRef) { }

	// RVA: 0x77E739C
	private object NewAtlasTexture(object resolution) { }

	// RVA: 0x77E8880
	private object DelayDestroyAtlas(object texture) { }

	// RVA: 0x77E8A38
	internal static object <DelayDestroyAtlas>g__CustomAction|24_0(object parameters) { }

}

// Namespace: 
public enum RendererType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object JuWai;
	public const object JuNeiHDD;
	public const object JuNei;
	public const object CiYuanGuangChang;
	public const object LiteCiYuanGuangChang;
	public const object CiYuanYiChu;
	public const object UGC;
	public const object CiYuanDaZuoZhan;
	public const object UI;
	public const object CubeMap;
	public const object AO;
	public const object PathTracer;
	public const object BuildIn;
}

// Namespace: 
public enum ELastFrameData
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WorldToCameraMatrix;
	public const object ProjectionMatrix;
}

// Namespace: Yarp
public class CameraData
{

	// Fields
	private object m_camera; // 0x18
	private object <targetWidth>k__BackingField; // 0x20
	private object <targetHeight>k__BackingField; // 0x24
	public object screenPercentage; // 0x28
	public object renderLayerMask; // 0x2C
	private object m_iid; // 0x30
	private object m_cameraType; // 0x34
	private object m_name; // 0x38
	public object forceDisablePostProcessing; // 0x40
	private object m_lateResetCameraMatrix; // 0x41
	public object SortingLayerRange; // 0x42
	public object SortingOrderRange; // 0x46
	private object m_prevFrameData; // 0x4C
	private object m_prevWorldToCameraMatrix; // 0x50
	private object m_prevProjectionMatrix; // 0x90
	private object m_jitterOffset; // 0xD0
	private object m_renderer; // 0xD8
	public object ResetRenderer; // 0xDC
	public object OutputAlpha; // 0xDD
	public object CullingParameters; // 0xE0
	private object m_renderSettingsVolume; // 0xE8
	public object usingProjectionMatrixTranslation; // 0xF0
	public object projectionMatrixTranslation; // 0xF4

	// Properties
	public object targetWidth { get; set; }
	public object targetHeight { get; set; }
	public object pixelWidth { get; }
	public object pixelHeight { get; }
	public object IsSupportLight { get; }
	public object Camera { get; set; }
	public object unityCamera { get; }
	public object instanceID { get; }
	public object cameraType { get; }
	public object name { get; }
	public object worldToCameraMatrix { get; }
	public object cameraToWorldMatrix { get; }
	public object projectionMatrix { get; set; }
	public object nearClipPlane { get; }
	public object farClipPlane { get; }
	public object nonJitteredProjectionMatrix { get; set; }
	public object cullingMask { get; set; }
	public object Depth { get; set; }
	public object Fov { get; set; }
	public object RenderTarget { get; }
	public object transform { get; }
	public object IsOrthogrpahic { get; }
	public object PrevWorldToCameraMatrix { get; set; }
	public object PrevProjectionMatrix { get; set; }
	public object PrevCameraPosition { get; }
	public object PrevNonJitteredViewProjectionMatrix { get; }
	public object NonJitteredViewProjectionMatrix { get; }
	public object JitterOffset { get; set; }
	public object clearFlags { get; set; }
	public object backgroundColor { get; set; }
	public object Renderer { get; set; }
	public object RenderSettingsVolume { get; }

	// Methods

	// RVA: 0x77E8B90
	public object get_targetWidth() { }

	// RVA: 0x77E8B98
	private object set_targetWidth(object value) { }

	// RVA: 0x77E8BA0
	public object get_targetHeight() { }

	// RVA: 0x77E8BA8
	private object set_targetHeight(object value) { }

	// RVA: 0x77E8BB0
	public object get_pixelWidth() { }

	// RVA: 0x77E8BB8
	public object get_pixelHeight() { }

	// RVA: 0x77E8BC0
	public object get_IsSupportLight() { }

	// RVA: 0x77E8BD4
	public object GetCamera() { }

	// RVA: 0x77E6968
	public object get_Camera() { }

	// RVA: 0x77E8D44
	public object set_Camera(object value) { }

	// RVA: 0x77E8D4C
	public object get_unityCamera() { }

	// RVA: 0x77E8D50
	public object SetWidthAndHeight(object w, object h) { }

	// RVA: 0x77E8D58
	public object SetResetCameraMatrixTiming(object lateTiming) { }

	// RVA: 0x77E8D60
	public object BeginCameraRender() { }

	// RVA: 0x77E8DC4
	public object EndCameraRender() { }

	// RVA: 0x77E8EE8
	public object get_instanceID() { }

	// RVA: 0x77E8F10
	public object get_cameraType() { }

	// RVA: 0x77E8F34
	public object get_name() { }

	// RVA: 0x77E68F8
	public object get_worldToCameraMatrix() { }

	// RVA: 0x77E8F3C
	public object get_cameraToWorldMatrix() { }

	// RVA: 0x77E8F74
	public object set_projectionMatrix(object value) { }

	// RVA: 0x77E6930
	public object get_projectionMatrix() { }

	// RVA: 0x77E8FC8
	public object get_nearClipPlane() { }

	// RVA: 0x77E8FF0
	public object get_farClipPlane() { }

	// RVA: 0x77E9018
	public object set_nonJitteredProjectionMatrix(object value) { }

	// RVA: 0x77E906C
	public object get_nonJitteredProjectionMatrix() { }

	// RVA: 0x77E90A4
	public object set_cullingMask(object value) { }

	// RVA: 0x77E9114
	public object get_cullingMask() { }

	// RVA: 0x77E913C
	public object get_Depth() { }

	// RVA: 0x77E9164
	public object set_Depth(object value) { }

	// RVA: 0x77E919C
	public object get_Fov() { }

	// RVA: 0x77E91C4
	public object set_Fov(object value) { }

	// RVA: 0x77E91FC
	public object get_RenderTarget() { }

	// RVA: 0x77E9224
	public object get_transform() { }

	// RVA: 0x77E924C
	public object get_IsOrthogrpahic() { }

	// RVA: 0x77E9274
	public object HasPrevFrameData(object data) { }

	// RVA: 0x77E8EA8
	public object set_PrevWorldToCameraMatrix(object value) { }

	// RVA: 0x77E9284
	public object get_PrevWorldToCameraMatrix() { }

	// RVA: 0x77E8EC8
	public object set_PrevProjectionMatrix(object value) { }

	// RVA: 0x77E92E0
	public object get_PrevProjectionMatrix() { }

	// RVA: 0x77E933C
	public object get_PrevCameraPosition() { }

	// RVA: 0x77E93D0
	public object get_PrevNonJitteredViewProjectionMatrix() { }

	// RVA: 0x77E94C4
	public object get_NonJitteredViewProjectionMatrix() { }

	// RVA: 0x77E9584
	public object set_JitterOffset(object value) { }

	// RVA: 0x77E958C
	public object get_JitterOffset() { }

	// RVA: 0x77E9594
	public object ComputeJitteredProjectionMatrix(object jitterOffset) { }

	// RVA: 0x77E96D0
	public object ResetJitterOffset() { }

	// RVA: 0x77E9794
	public object set_clearFlags(object value) { }

	// RVA: 0x77E97CC
	public object get_clearFlags() { }

	// RVA: 0x77E97F4
	public object set_backgroundColor(object value) { }

	// RVA: 0x77E984C
	public object get_backgroundColor() { }

	// RVA: 0x77E9874
	public object get_Renderer() { }

	// RVA: 0x77E987C
	public object set_Renderer(object value) { }

	// RVA: 0x77E9898
	public object get_RenderSettingsVolume() { }

	// RVA: 0x77E9980
	public object SetProjectionMatrixTranslation(object trans) { }

	// RVA: 0x77E9990
	public object ClearProjectionMatrixTranslation() { }

	// RVA: 0x77E99F0
	public object Clone() { }

	// RVA: 0x77E9A78
	public object .ctor() { }

}

// Namespace: Yarp
public class AdditionalCullingParameters
{

	// Fields
	public object ShadowDistance; // 0x8

	// Methods

	// RVA: 0x77E9BEC
	public object .ctor() { }

}

// Namespace: Yarp
public enum YADebugRenderMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object MipmapLevel;
	public const object Overdraw;
	public const object LightDensity;
	public const object RadianceProbeDensity;
	public const object CapsuleVolumeDensity;
	public const object OpaqueUVDensity;
	public const object TransparentUVDensity;
	public const object Bone;
	public const object OnlyReflectPass;
	public const object OnlyShadowCasterPass;
	public const object ShadowCaster;
}

// Namespace: Yarp
public enum ESceneViewExposureOverride
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Game;
	public const object Fixed;
}

// Namespace: Yarp
public class DeviceFeatureSupportCache
{

	// Fields
	private static object s_initialized; // 0x0
	private static object s_enableARGBHalf; // 0x1
	private static object s_enableR11G11B10; // 0x2
	private static object s_enableRGHalf; // 0x3
	private static object s_enableD16; // 0x4
	private static object s_enableD32; // 0x5
	private static object s_enableD24S8; // 0x6
	private static object s_enableGrabPass; // 0x7
	private static object s_enableBloom; // 0x8
	private static object s_ASTCTexture_Strict; // 0x9
	private static object s_ASTC3DTexture_Strict; // 0xA
	private static object s_multiSampleAutoResolve; // 0xB
	private static object s_enableR8; // 0xC
	private static object s_enableR16; // 0xD
	private static object s_enableR32; // 0xE
	private static object s_enableLightGrid; // 0xF

	// Properties
	public static object EnableR11G11B10 { get; }
	public static object EnableRGhalf { get; }
	public static object EnableARGBHalf { get; }
	public static object EnableD16 { get; }
	public static object EnableD32 { get; }
	public static object EnableD24S8 { get; }
	public static object EnableGrabPass { get; set; }
	public static object EnableBloom { get; set; }
	public static object ASTCTexture_Strict { get; }
	public static object ASTC3DTexture_Strict { get; }
	public static object MultiSampleAutoResolve { get; }
	public static object EnableR8 { get; }
	public static object EnableR16 { get; }
	public static object EnableR32 { get; }
	public static object EnableLightGrid { get; }

	// Methods

	// RVA: 0x77E9BF4
	public static object get_EnableR11G11B10() { }

	// RVA: 0x77EA6D4
	public static object get_EnableRGhalf() { }

	// RVA: 0x77EA7A0
	public static object get_EnableARGBHalf() { }

	// RVA: 0x77EA86C
	public static object get_EnableD16() { }

	// RVA: 0x77EA938
	public static object get_EnableD32() { }

	// RVA: 0x77EAA04
	public static object get_EnableD24S8() { }

	// RVA: 0x77EAAD0
	public static object get_EnableGrabPass() { }

	// RVA: 0x77EAB9C
	public static object set_EnableGrabPass(object value) { }

	// RVA: 0x77EAC28
	public static object get_EnableBloom() { }

	// RVA: 0x77EACF4
	public static object set_EnableBloom(object value) { }

	// RVA: 0x77EAD80
	public static object get_ASTCTexture_Strict() { }

	// RVA: 0x77EAE4C
	public static object get_ASTC3DTexture_Strict() { }

	// RVA: 0x77EAF18
	public static object get_MultiSampleAutoResolve() { }

	// RVA: 0x77EAFE4
	public static object get_EnableR8() { }

	// RVA: 0x77EB0B0
	public static object get_EnableR16() { }

	// RVA: 0x77EB17C
	public static object get_EnableR32() { }

	// RVA: 0x77EB248
	public static object get_EnableLightGrid() { }

	// RVA: 0x77E9CC0
	public static object Init() { }

	// RVA: 0x77EB314
	private static object PrintDevicesInfo() { }

	// RVA: 0x77EB744
	public static object ApplyToWorldData(object data) { }

	// RVA: 0x77EB88C
	public object .ctor() { }

	// RVA: 0x77EB894
	private static object .cctor() { }

}

// Namespace: 
public enum IrradianceMapMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Cubemap;
	public const object SH9;
	public const object AmbientCube;
}

// Namespace: 
public enum SkyDome
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object HDRI;
	public const object ProceduralSky;
	public const object None;
}

// Namespace: Yarp
public class EnvironmentLight
{

	// Fields
	public object Priority; // 0x18
	public object lightLayer; // 0x1C
	public static object BorderSize; // 0x0
	public object RotationAngle; // 0x20
	public object mode; // 0x24
	public object Intensity; // 0x28
	public object NormalizationMode; // 0x38
	public object MipLevelsOfGgxFilteredTex; // 0x3C
	public object EnvmapGgxFilteredRawData; // 0x40
	public object EnvmapGgxFilteredOctahedralMap; // 0x48
	private object m_EnvmapGgxFiltered; // 0x50
	public object SkyDomeType; // 0x58
	public object SkyTexture; // 0x60
	public object IrradianceSH9Coeffs; // 0x68
	public object IrradianceACCoeffs; // 0x70

	// Properties
	public object EnvmapGgxFiltered { get; }

	// Methods

	// RVA: 0x77EB8EC
	private object OnEnable() { }

	// RVA: 0x77EB964
	private object OnDisable() { }

	// RVA: 0x77EB9DC
	public object GetPriority() { }

	// RVA: 0x77EB9E8
	public object GetRotationParameter() { }

	// RVA: 0x77EBA2C
	public object get_EnvmapGgxFiltered() { }

	// RVA: 0x77EBB70
	public object IsValid() { }

	// RVA: 0x77EBBDC
	public object .ctor() { }

	// RVA: 0x77EBC08
	private static object .cctor() { }

}

// Namespace: Yarp
internal class EnvironmentLightData
{

	// Fields
	public object light; // 0x8
	public object size; // 0x10
	public object rectHandle; // 0x14
	public object scaleBias; // 0x18
	public object sizePosition; // 0x28
	private object instanceId; // 0x38

	// Properties
	public object dirty { get; }

	// Methods

	// RVA: 0x77EBC58
	public object get_dirty() { }

	// RVA: 0x77EBC60
	public object .ctor(object light) { }

}

// Namespace: 
public static class ShaderConstants
{

	// Fields
	public static object g_LightLayerEnvmapIntensityInternal; // 0x0
	public static object g_LightLayerEnvmapSpecularTintColorAndMaxMip; // 0x4
	public static object g_LightLayerEnvmapRotationParam; // 0x8
	public static object g_EnvmapFilterWithGGXAtlas; // 0xC
	public static object g_LightLayerIrradianceACCoeffs; // 0x10
	public static object g_LightLayerEnvmapAtlasScaleOffset; // 0x14
	public static object g_LightLayerEnvmapLayer; // 0x18

	// Methods

	// RVA: 0x77EEB50
	private static object .cctor() { }

}

// Namespace: Yarp
public class EnvironmentLightManager
{

	// Fields
	private object m_atlasSize; // 0x8
	private const object TileSize;
	private const object LayerCount;
	private object m_rectAllocator; // 0x10
	private object m_atlasTexture; // 0x18
	private object m_useRenderTextureForAtlas; // 0x20
	private object m_atlasTextureFormat; // 0x24
	private const object LAYER_MAX_COUNT;
	private object m_LightIntensityArray; // 0x28
	private object m_LightSpecularTintArray; // 0x30
	private object m_IrradianceCoeffsArray; // 0x38
	private object m_RotationParamsArray; // 0x40
	private object m_AtlasScaleOffsetArray; // 0x48
	private object m_EnvmapLayerArray; // 0x50
	public object EnableLightingLayer; // 0x58
	private object m_material; // 0x60
	private object m_shaderPass; // 0x68
	private object m_lightDataMap; // 0x70
	private object m_activeLightIds; // 0x78
	private object m_activeLights; // 0x80
	private object m_lightsToRemove; // 0x88
	private object m_lightsToAdd; // 0x90
	private object m_allLights; // 0x98

	// Properties
	private object blitMaterial { get; }

	// Methods

	// RVA: 0x77EBDEC
	private object get_blitMaterial() { }

	// RVA: 0x77EBF94
	public object Dispose() { }

	// RVA: 0x77EC008
	private object BuildAtlas() { }

	// RVA: 0x77EC228
	private object CheckAtlasRebuildRequired() { }

	// RVA: 0x77EC380
	private object UploadToAtlas(object environmentLight) { }

	// RVA: 0x77EC8CC
	private object FillEnvironmentLight(object envmap, object index, object scaleBias) { }

	// RVA: 0x77ECD64
	private object ResetLightLayerEnvmapData(object index) { }

	// RVA: 0x77ECF68
	private object PrepareLightLayerEnvironmentData() { }

	// RVA: 0x77ED304
	public object SetupGlobalEnvmap(object cmd) { }

	// RVA: 0x77EBCE8
	public static object GetEnvironmentLightTexture(object light) { }

	// RVA: 0x77ED46C
	public object GetAtlasTexture() { }

	// RVA: 0x77ED534
	public object ClearAllLights() { }

	// RVA: 0x77ED5B0
	public object AddEnvironmentLight(object light) { }

	// RVA: 0x77ED6D0
	private object BuildRectAllocator() { }

	// RVA: 0x77ED918
	private object UpdateAtlas() { }

	// RVA: 0x77EE860
	public object UpdateEnvironmentLight() { }

	// RVA: 0x77EC6D0
	private object Blit(object cmd, object src, object dst, object mip, object rect) { }

	// RVA: 0x77EE950
	public object .ctor() { }

}

// Namespace: 
private static class Constants
{

	// Fields
	public static object InteriorMap; // 0x0
	public static object Extent; // 0x4
	public static object Center; // 0x8
	public static object WorldToVolume; // 0xC

	// Methods

	// RVA: 0x77EF79C
	private static object .cctor() { }

}

// Namespace: Yarp
public class InteriorMappingVolume
{

	// Fields
	public object resolution; // 0x18
	public object cubemap; // 0x20
	public object clearFlags; // 0x28
	public object backgroundColor; // 0x2C
	public object nearClipPlane; // 0x3C
	public object farClipPlane; // 0x40
	public object anchor; // 0x48
	public object anchorSize; // 0x50
	public object rawData; // 0x60
	public object center; // 0x68
	public object size; // 0x74
	private object propBlock; // 0x80
	private object needRefresh; // 0x88

	// Methods

	// RVA: 0x77EECE4
	private object BegineCameraRendering(object context, object commands, object camera, object dest) { }

	// RVA: 0x77EEFFC
	private object LateUpdate() { }

	// RVA: 0x77EF03C
	public object Capture() { }

	// RVA: 0x77EECF8
	public object Refresh() { }

	// RVA: 0x77EF198
	private object OnEnable() { }

	// RVA: 0x77EF474
	private object OnDisable() { }

	// RVA: 0x77EF524
	private object OnDrawGizmos() { }

	// RVA: 0x77EF6D4
	public object .ctor() { }

}

// Namespace: Yarp
public enum IBLNormalizationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Irradiance;
	public const object ScalarIrradiance;
}

// Namespace: 
public enum EType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Invalid;
	public const object ParticleSystem;
	public const object Mesh;
	public const object Other;
}

// Namespace: Yarp
public class PerObjectDistortion
{

	// Fields
	public object m_isAwake; // 0x8
	public object m_type; // 0xC
	public object m_unityGameObject; // 0x10
	public object m_particleSystem; // 0x18
	public object m_meshFilter; // 0x20
	public object m_renderer; // 0x28
	public object intensity; // 0x30
	public object layer; // 0x34

	// Methods

	// RVA: 0x77EF89C
	public object .ctor(object go) { }

	// RVA: 0x77EFB98
	public object IsAlive(object layermask) { }

}

// Namespace: Yarp
public class PlanarReflectionProbe
{

	// Fields
	public object Priority; // 0x18
	public object clipPlaneOffset; // 0x1C
	public object nearPlaneDistance; // 0x20
	public object farPlaneDistance; // 0x24
	public object clearColor; // 0x28
	public object textureSize; // 0x38
	public object roughReflections; // 0x3C
	public object enableVerticalBlur; // 0x3D
	public object usingMeshRenderFilter; // 0x3E

	// Methods

	// RVA: 0x77EFEA0
	private object OnEnable() { }

	// RVA: 0x77EFF18
	private object OnDisable() { }

	// RVA: 0x77EFF90
	public object GetPriority() { }

	// RVA: 0x77EFF9C
	public object .ctor() { }

}

// Namespace: Yarp
public struct RenderingLayerMask
{

	// Fields
	private static object s_empty; // 0x0
	private static object s_builtInLayerCount; // 0xFFFFFFFFFFFFFFF8
	public static object DefaultLayer; // 0xFFFFFFFFFFFFFFFC
	public static object ReflectionLayer; // 0x0
	public static object DistortionLayer; // 0x4
	public static object GlitchLayer; // 0x8
	public static object DefaultLayerMask; // 0xC
	public static object ReflectionLayerMask; // 0x10
	public static object DistortionLayerMask; // 0x14
	public static object GlitchLayerMask; // 0x18
	private object m_Mask; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object value { get; set; }

	// Methods

	// RVA: 0x77EFFC4
	public static object op_Implicit(object mask) { }

	// RVA: 0x77EFFC8
	public static object op_Implicit(object intVal) { }

	// RVA: 0x77EFFCC
	public object get_value() { }

	// RVA: 0x77EFFDC
	public object set_value(object value) { }

	// RVA: 0x77EFFEC
	public static object Reset(object pipelineAsset) { }

	// RVA: 0x77F02A8
	private static object RegisterLayer(object pipelineAsset, object value, object name) { }

	// RVA: 0x77F0370
	public static object LayerToName(object layer) { }

	// RVA: 0x77F04F0
	public static object NameToLayer(object layerName) { }

	// RVA: 0x77F05E4
	public static object NameToLayerMask(object layerName) { }

	// RVA: 0x77F0658
	public static object LayerToLayerMask(object layer) { }

	// RVA: 0x77F066C
	public static object GetMask(object layerNames) { }

	// RVA: 0x77F077C
	private static object .cctor() { }

}

// Namespace: Yarp
public enum QualityLevel3
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object Medium;
	public const object High;
}

// Namespace: Yarp
public enum EHdrMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Linear_R11G11B10;
	public const object Software_R10G10B10A2;
	public const object Software_R8G8B8A8;
	public const object Software_ARGBHalf;
}

// Namespace: Yarp
public class WorldData
{

	// Fields
	public object environmentLight; // 0x8
	public object envLight; // 0x10
	public object dominantLight; // 0x18
	public object allLights; // 0x20
	public object bakeLights; // 0x28
	public object dynamicLights; // 0x30
	public object grabPasses; // 0x38
	public object planarReflectionProbe; // 0x40
	public object SceneViewPreviewMode; // 0x48
	public object m_renderSettingsVolume; // 0x50
	public object EnableShadow; // 0x58
	public object EnableCloseupShadow; // 0x59
	public object ScreenPercentage; // 0x5C
	public object EnableLightGrid; // 0x60
	public object EnableMSAA; // 0x61
	public object EnableReflectionTexMips; // 0x62
	public object EnableSubsurfaceScattering; // 0x63
	public object LightNum; // 0x64
	public object GraphicSettingLevel; // 0x68
	public object enableEnLightenLightmap; // 0x6C
	public object forceDisablePostProcess; // 0x6D
	public object EnableCustomShadowDir; // 0x6E
	public object DisableFakeShadow; // 0x6F
	public object CustomShadowDir; // 0x70
	private object m_isDirty; // 0x7C

	// Properties
	public object renderSetting { get; set; }
	public object hasHDRI { get; }
	public object hasSkyDome { get; }
	public object sunDirection { get; }
	public object renderSettingsVolume { get; set; }
	public object EnablePlanarReflection { get; }
	public object EnableTAAUCombinePass { get; }

	// Methods

	// RVA: 0x77EB864
	public object get_renderSetting() { }

	// RVA: 0x77F095C
	public object set_renderSetting(object value) { }

	// RVA: 0x77F0990
	public object get_hasHDRI() { }

	// RVA: 0x77F0AD8
	public object get_hasSkyDome() { }

	// RVA: 0x77F0AF8
	public object get_sunDirection() { }

	// RVA: 0x77F0808
	public object get_renderSettingsVolume() { }

	// RVA: 0x77F0C18
	public object set_renderSettingsVolume(object value) { }

	// RVA: 0x77F0C20
	public object RefreshAndGetActiveGrabPass() { }

	// RVA: 0x77F0DF8
	public object .ctor(object camera) { }

	// RVA: 0x77F0F88
	public object IsGraphicSettingLow() { }

	// RVA: 0x77F0F98
	public object get_EnablePlanarReflection() { }

	// RVA: 0x77F1080
	public object get_EnableTAAUCombinePass() { }

	// RVA: 0x77F11D8
	public object UseMSAASubSamples() { }

	// RVA: 0x77F11E0
	public object IsDirty() { }

	// RVA: 0x77F11E8
	public object SetDirty() { }

	// RVA: 0x77F11F4
	public object ClearDirtyFlag() { }

	// RVA: 0x77F11FC
	public object ResetData() { }

	// RVA: 0x77F1368
	public object Dispose() { }

	// RVA: 0x77F153C
	public object Clone() { }

}

// Namespace: Yarp
public interface IWorldDataComponent
{

	// Methods

	// RVA: -1
	public abstract object GetPriority() { }

}

// Namespace: Yarp
public class WorldDataUpdateSystem
{

	// Fields
	public object isDirty; // 0x8

	// Methods

	// RVA: 0x77F15C4
	public override object OnEnable() { }

	// RVA: 0x77F15D0
	public override object OnDisable() { }

	// RVA: 0x77F15D8
	public override object Update(object collection) { }

	// RVA: 0x77F1728
	public override object GetTrackingFlags() { }

	// RVA: 0x77F1730
	public object .ctor() { }

}

// Namespace: Yarp
public enum Axis
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object XPositive;
	public const object XNegative;
	public const object YPositive;
	public const object YNegative;
	public const object ZPositive;
	public const object ZNegative;
}

// Namespace: Yarp
public enum RotationAxis
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object X;
	public const object Y;
	public const object Z;
}

// Namespace: Yarp
public class YABillborad
{

	// Fields
	public object LookAtAxis; // 0x18
	public object RotAxis; // 0x1C
	public object IsWorldSpace; // 0x20

	// Methods

	// RVA: 0x77F1740
	public object OnEnable() { }

	// RVA: 0x77F1818
	public object OnDisable() { }

	// RVA: 0x77F18C8
	public object BeginCameraRendering(object context, object commands, object aCamera, object dest) { }

	// RVA: 0x77F1E74
	public object .ctor() { }

}

// Namespace: 
public enum AttenuationRange
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Short;
	public const object Mid;
	public const object Long;
}

// Namespace: Yarp
public class YACapsuleShadowVolume
{

	// Fields
	public object radius; // 0x18
	public object height; // 0x1C
	public object attenuationRange; // 0x20
	public object cullingDistance; // 0x24

	// Properties
	public object range { get; }
	public object scaledRadius { get; }
	public object scaledHeight { get; }
	public object scaledRange { get; }
	public object up { get; }
	public object capA { get; }
	public object capB { get; }
	public object expandedRadius { get; }

	// Methods

	// RVA: 0x77F1E7C
	public object get_range() { }

	// RVA: 0x77F1EA4
	public object get_scaledRadius() { }

	// RVA: 0x77F1F50
	public object get_scaledHeight() { }

	// RVA: 0x77F1FFC
	public object get_scaledRange() { }

	// RVA: 0x77F20C8
	public object get_up() { }

	// RVA: 0x77F2288
	public object get_capA() { }

	// RVA: 0x77F22F4
	public object get_capB() { }

	// RVA: 0x77F2360
	public object get_expandedRadius() { }

	// RVA: 0x77F2424
	private object OnDrawGizmos() { }

	// RVA: 0x77F26B0
	public object .ctor() { }

	// RVA: 0x77F250C
	private object <OnDrawGizmos>g__DrawCapsule|21_0(object A, object B, object r) { }

}

// Namespace: Yarp
public class YADiffusionProfilerReferencer
{

	// Fields
	public object DiffusionProfiles; // 0x18

	// Methods

	// RVA: 0x77F26D0
	public object OnEnable() { }

	// RVA: 0x77F26D4
	public object OnDisable() { }

	// RVA: 0x77F26D8
	public object .ctor() { }

}

// Namespace: Yarp
public class YAGrabPass
{

	// Fields
	public object RenderQueue; // 0x18
	public object FinalRenderQueue; // 0x1C
	public object FallbackTexture; // 0x20
	public object Priority; // 0x28
	public object ResolutionScale; // 0x2C

	// Methods

	// RVA: 0x77F26E0
	public object GetPriority() { }

	// RVA: 0x77F26EC
	public object OnEnable() { }

	// RVA: 0x77F2764
	public object OnDisable() { }

	// RVA: 0x77F0DB8
	public object FinalizeRenderQueue() { }

	// RVA: 0x77F27DC
	public object GetRenderQueueFromMaterial() { }

	// RVA: 0x77F29C4
	public object .ctor() { }

}

// Namespace: Yarp
public enum ShadowType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object RealTime;
	public const object Visibility;
}

// Namespace: Yarp
public class YALight
{

	// Fields
	public object Priority; // 0x18
	private object <ProxyObj>k__BackingField; // 0x20
	public object type; // 0x28
	public object followSystemScale; // 0x2C
	private object intensity; // 0x30
	private object sunIntensity; // 0x34
	public object color; // 0x38
	public object useColorTemperature; // 0x48
	public object colorTemperature; // 0x4C
	public object cookie; // 0x50
	public object cookieSize; // 0x58
	public object cookieOffset; // 0x60
	public object lightLayerMask; // 0x68
	public object range; // 0x6C
	public object falloffExponent; // 0x70
	public object spotPlusFalloff; // 0x74
	public object innerAngle; // 0x78
	public object spotAngle; // 0x7C
	public object innerRadius; // 0x80
	public object outerRadius; // 0x84
	public object areaSize; // 0x88
	public object shadow; // 0x90
	public object ShadowSetting; // 0x98
	public object ShadowBounds; // 0xA0
	private object m_isBaked; // 0xA8
	public object mode; // 0xAC
	public object lightUnit; // 0xB0
	public object luxAtDistance; // 0xB4
	public object shadowmaskAngle; // 0xB8
	private object m_unityLight; // 0xC0
	public object IsShadowCasterBoundsVisible; // 0xC8
	public object ShadowSplitIndex; // 0xCC
	private object m_shadowMapDirty; // 0xD0
	private object m_lightShadowComp; // 0xD8

	// Properties
	public object IsActive { get; }
	public object ProxyObj { get; set; }
	public object LightType { get; }
	public object LightIntensity { get; }
	public object UseInverseSquaredFalloff { get; }
	public object LightFalloffExponent { get; }
	public object innerSpotAngle { get; }
	public object scaleFactor { get; }
	public object isBaked { get; set; }
	public object unityLight { get; set; }

	// Methods

	// RVA: 0x77F29DC
	public object get_IsActive() { }

	// RVA: 0x77F2A1C
	public object get_ProxyObj() { }

	// RVA: 0x77F2A24
	public object set_ProxyObj(object value) { }

	// RVA: 0x77F2A2C
	public object GetPriority() { }

	// RVA: 0x77F2A38
	private object OnEnable() { }

	// RVA: 0x77F2AB8
	private object OnDisable() { }

	// RVA: 0x77F2B38
	public object get_LightType() { }

	// RVA: 0x77F2B44
	public object get_LightIntensity() { }

	// RVA: 0x77F2C48
	public object get_UseInverseSquaredFalloff() { }

	// RVA: 0x77F2C58
	public object get_LightFalloffExponent() { }

	// RVA: 0x77F2C60
	public object get_innerSpotAngle() { }

	// RVA: 0x77F2C68
	public object GetSunIntensity() { }

	// RVA: 0x77F2C70
	public object SetSunIntensity(object val) { }

	// RVA: 0x77F2C78
	public object SetIntensity(object value, object unit, object useScale) { }

	// RVA: 0x77F2D40
	public object GetIntensity(object unit, object useScale) { }

	// RVA: 0x77F2DBC
	public object GetIntensityWithScale() { }

	// RVA: 0x77F2E58
	public object IsFollowScale() { }

	// RVA: 0x77F2E8C
	public object SetCurrentLightUnitIntensity(object value) { }

	// RVA: 0x77F2EA0
	public object GetCurrentLightUnitIntensity() { }

	// RVA: 0x77F2EA8
	public object GetUnitlessIntensity() { }

	// RVA: 0x77F2F2C
	public object GetColor() { }

	// RVA: 0x77F2B48
	public object GetColoredLightBrightness() { }

	// RVA: 0x77F2F8C
	public object GetRange() { }

	// RVA: 0x77F2FB0
	public object SetRange(object value) { }

	// RVA: 0x77F2CBC
	public object get_scaleFactor() { }

	// RVA: 0x77F2FE4
	public object GetInnerRadius() { }

	// RVA: 0x77F3008
	public object SetInnerRadius(object value) { }

	// RVA: 0x77F303C
	public object GetOuterRadius() { }

	// RVA: 0x77F3060
	public object SetOuterRadius(object value) { }

	// RVA: 0x77F3094
	public object get_isBaked() { }

	// RVA: 0x77F309C
	public object set_isBaked(object value) { }

	// RVA: 0x77F30A4
	public object get_unityLight() { }

	// RVA: 0x77F3548
	public object set_unityLight(object value) { }

	// RVA: 0x77F3550
	public object SetLightShadowDirty(object bDirty) { }

	// RVA: 0x77F3558
	public object GetLightShadowDirty() { }

	// RVA: 0x77F3560
	public object GetShadowUpdateMethod() { }

	// RVA: 0x77F3680
	public object GetLightShadowComp() { }

	// RVA: 0x77F3264
	private object SyncYALightParam2UnityLight() { }

	// RVA: 0x77F385C
	public object Clone() { }

	// RVA: 0x77F38E4
	public object .ctor() { }

}

// Namespace: Yarp
public enum YALightType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Directional;
	public const object Point;
	public const object Spot;
	public const object Rim;
	public const object Rectangle;
	public const object SpotPlus;
}

// Namespace: Yarp
public enum LightUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unitless;
	public const object Lumen;
	public const object Candela;
	public const object Lux;
}

// Namespace: Yarp
public enum DirectionalLightUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unitless;
	public const object Lux;
}

// Namespace: Yarp
public enum AreaLightUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unitless;
}

// Namespace: Yarp
public enum PunctualLightUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unitless;
	public const object Lumen;
	public const object Candela;
	public const object Lux;
}

// Namespace: Yarp
public class YALightCookieMoveComponent
{

	// Fields
	public object Direction; // 0x18
	public object Speed; // 0x20
	public object Light; // 0x28

	// Methods

	// RVA: 0x77F3A08
	private object Awake() { }

	// RVA: 0x77F3AD4
	private object Update() { }

	// RVA: 0x77F3BAC
	private object OnEnable() { }

	// RVA: 0x77F3BB0
	private object OnDisable() { }

	// RVA: 0x77F3BB4
	public object .ctor() { }

}

// Namespace: Yarp
public enum EShadowRenderType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Shadow_Cascade;
	public const object Shadow_JuNei;
	public const object Shadow_AutoOpt;
	public const object Shadow_RayTracing;
}

// Namespace: Yarp
public enum EShadowObjectFilter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AllObjects;
	public const object DynamicOnly;
	public const object StaticOnly;
}

// Namespace: Yarp
public enum ContactShadowMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object StochasticJittering;
	public const object BendScreenSpaceShadow;
}

// Namespace: Yarp
public class YALightShadow
{

	// Fields
	public object ShadowMapUpdateMode; // 0x18
	public object ShadowObjectFilter; // 0x1C
	public object ShadowRenderType; // 0x20
	public object ShadowFilterSharpen; // 0x24
	public object ShadowColor; // 0x28
	public object ShadowEdgeBeginColor; // 0x38
	public object ShadowEdgeEndColor; // 0x48
	public object ShadowEdgeBegin; // 0x58
	public object ShadowEdgeEnd; // 0x5C
	public object ShadowEdgeBeginFadeWidth; // 0x60
	public object ShadowEdgeEndFadeWidth; // 0x64
	private object m_lightComp; // 0x68

	// Methods

	// RVA: 0x77F3BBC
	public object GetLightComp() { }

	// RVA: 0x77F3BC4
	private object OnEnable() { }

	// RVA: 0x77F3C30
	private object OnDisable() { }

	// RVA: 0x77F3C38
	public object .ctor() { }

}

// Namespace: Yarp
public class YALightTarget
{

	// Fields
	public object Follower; // 0x18

	// Methods

	// RVA: 0x77F3C64
	private object Update() { }

	// RVA: 0x77F3D38
	public object .ctor() { }

}

// Namespace: Yarp
public class YAPipelineResourceReference
{

	// Fields
	public object shader; // 0x10
	public object computeShader; // 0x18
	public object rayTracingShader; // 0x20
	public object texture2D; // 0x28
	public object texture2DArray; // 0x30
	public object material; // 0x38
	public object diffusionProfile; // 0x40
	public object gameObject; // 0x48

	// Methods

	// RVA: 0x77F3D40
	public object .ctor() { }

}

// Namespace: 
public enum ProbeSize
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object _64;
	public const object _128;
	public const object _256;
	public const object _512;
	public const object _1024;
}

// Namespace: Yarp
public class YARadianceProbe
{

	// Fields
	public static object ActiveList; // 0x0
	public object radius; // 0x18
	public object nearClipPlane; // 0x1C
	public object farClipPlane; // 0x20
	public object cullingMask; // 0x24
	public object probeSize; // 0x28
	public object clearFlags; // 0x2C
	public object reflectionColor; // 0x30
	public object radianceProbeAtlasFile; // 0x40
	public object scaleOffsetInAtlas; // 0x48
	public const object GizmosRadius;

	// Properties
	public object scaledRadius { get; }

	// Methods

	// RVA: 0x77F3D48
	public object get_scaledRadius() { }

	// RVA: 0x77F3DF4
	private object Update() { }

	// RVA: 0x77F3FFC
	private object OnEnable() { }

	// RVA: 0x77F4300
	private object OnDisable() { }

	// RVA: 0x77F44DC
	private object OnDrawGizmos() { }

	// RVA: 0x77F463C
	public object .ctor() { }

	// RVA: 0x77F46D8
	private static object .cctor() { }

}

// Namespace: Yarp
public class YAShadowBounds
{

	// Fields
	private object m_sphereCollider; // 0x18
	public object UseGroundProxy; // 0x20
	public object GroundOffset; // 0x24

	// Properties
	public object GroundCenter { get; }
	public object GroundNormal { get; }
	public object ShadowBounds { get; }

	// Methods

	// RVA: 0x77F4768
	public object get_GroundCenter() { }

	// RVA: 0x77F47E8
	public object get_GroundNormal() { }

	// RVA: 0x77F48F8
	public object get_ShadowBounds() { }

	// RVA: 0x77F49C8
	private object Awake() { }

	// RVA: 0x77F4A3C
	public object RayCastGroundPlane(object origin, object direction, object dist) { }

	// RVA: 0x77F4C74
	public object .ctor() { }

}

// Namespace: Yarp
public class YASkinnedMeshBounds
{

	// Fields
	public object sphere; // 0x18
	public object box; // 0x20
	private const object minMovement;
	public object scale; // 0x28
	public object _renderers; // 0x30

	// Methods

	// RVA: 0x77F4C7C
	public object OnEnable() { }

	// RVA: 0x77F4E30
	public object LateUpdate() { }

	// RVA: 0x77F5480
	public object .ctor() { }

}

// Namespace: 
private class CameraTime
{

	// Fields
	public object year; // 0x8
	public object month; // 0xC
	public object day; // 0x10
	public object hours; // 0x14

	// Methods

	// RVA: 0x77F62CC
	public object .ctor() { }

}

// Namespace: 
private class CameraLocation
{

	// Fields
	public object longitude; // 0x8
	public object latitude; // 0xC

	// Methods

	// RVA: 0x77F62EC
	public object .ctor() { }

}

// Namespace: 
private struct SunCoordinates
{

	// Fields
	public object zenith; // 0xFFFFFFFFFFFFFFF8
	public object azimuth; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x77F6300
	public object toVector() { }

}

// Namespace: Yarp
public class YASunLight
{

	// Fields
	private const object EARTH_MEAN_RADIUS;
	private const object ASTRONOMICAL_UNIT;
	private readonly object cameraTime; // 0x18
	private readonly object cameraLocation; // 0x20
	public object year; // 0x28
	public object month; // 0x2C
	public object day; // 0x30
	public object hours; // 0x34
	public object longitude; // 0x38
	public object latitude; // 0x3C

	// Methods

	// RVA: 0x77F54EC
	private object OnEnable() { }

	// RVA: 0x77F5564
	private object OnDisable() { }

	// RVA: 0x77F55DC
	private object Update() { }

	// RVA: 0x77F594C
	private object GetSunDirection(object udt_time, object udt_location) { }

	// RVA: 0x77F6204
	public object .ctor() { }

}

// Namespace: Yarp
public struct ShadowCasterPassParameters
{

	// Fields
	public object IsOrthogonalCamera; // 0xFFFFFFFFFFFFFFF8
	public object ShadowPancaking; // 0xFFFFFFFFFFFFFFF9
	public object DepthSlopeBias; // 0xFFFFFFFFFFFFFFFC
	public object DepthSlopeBiasClamp; // 0x0
	public object ConstantDepthBias; // 0x4
	public object ShadowSplitResolution; // 0x8
	public object ShadowViewMatrix; // 0xC
	public object ShadowProjectionMatrix; // 0x4C
	public object ShadowNearClipPlane; // 0x8C
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x77F9A24
	private static object .cctor() { }

	// RVA: 0x77F9A84
	public object .ctor() { }

	// RVA: 0x77F9A8C
	internal object <.cctor>b__3_0() { }

	// RVA: 0x77F9AFC
	internal object <.cctor>b__3_1() { }

	// RVA: 0x77F9B6C
	internal object <.cctor>b__3_2() { }

}

// Namespace: 
private static class BuiltinTextures
{

	// Fields
	public static readonly object PreIntegratedDFG; // 0x0
	public static readonly object SpecularOcclusion; // 0x8
	public static readonly object SpecularOcclusionBRDFCone; // 0x10

	// Methods

	// RVA: 0x77F9844
	private static object .cctor() { }

}

// Namespace: Yarp
public static class MaterialSystem
{

	// Fields
	private static object g_CSMShadowTexture; // 0x0
	private static object g_CSMNumCascades; // 0x4
	private static object g_CSMShadowMatrices; // 0x8
	private static object g_CSMUvScaleOffset; // 0xC
	private static object g_CSMNormalBias; // 0x10
	private static object g_CSMDistanceFade; // 0x14
	public static object g_ShadowFilterSharpen; // 0x18
	public static object g_ShadowColor; // 0x1C
	public static object g_ShadowEdgeBeginColor; // 0x20
	public static object g_ShadowEdgeEndColor; // 0x24
	public static object g_ShadowEdgeParameters; // 0x28
	private static object g_ShadowSplitsShadowSamplingMatrix; // 0x2C
	private static object g_ShadowSplitsUvScaleOffset; // 0x30
	private static object g_ShadowSplitsNormalBias; // 0x34
	private static object g_SunOcclusionParameter; // 0x38
	private static object g_SunOcclusion; // 0x3C
	private static object g_SunOcclusionPosScaleOffset; // 0x40
	private static object g_SkyOcclusion; // 0x44
	private static object g_SkyOcclusionPosScaleOffset; // 0x48
	private static object g_HeroCloudShadowControl; // 0x4C
	private static object g_CloudShadowParam; // 0x50
	private static object g_CameraJitterOffset; // 0x54
	private static object g_ScreenParams; // 0x58
	private static object g_FrameIndexModX; // 0x5C
	private static object g_ExposureScale; // 0x60
	private static object g_BgExposureScale; // 0x64
	private static object g_VFXBrightnessScale; // 0x68
	private static object g_PreExposure; // 0x6C
	private static object g_InvPreExposure; // 0x70
	private static object g_PrevInvPreExposure; // 0x74
	private static object s_SpecularOcclusionLut3D; // 0x78
	private static object s_SpecularOcclusionLutBRDFCone; // 0x7C
	private static object s_DFGTexture; // 0x80
	private static object g_FogParam; // 0x84
	private static object g_FogColor; // 0x88
	private static object g_ShadowmaskAngle; // 0x8C
	private static object g_FoliageZTestMode; // 0x90
	private static object g_TerrainFakeSpecular_Precomputation; // 0x94
	private static object g_LastFrameCameraPosition; // 0x98
	private static object g_PrevNonJitteredViewProjMat; // 0x9C
	private static object g_PrevInvNonJitteredViewProjMat; // 0xA0
	private static object g_ViewCameraInvViewProjMat; // 0xA4
	private static object g_NonJitteredViewProjMat; // 0xA8
	private static object g_InvNonJitteredProjMat; // 0xAC
	private static object g_ViewCameraClearParams; // 0xB0
	private static object m_defaultShadowTexture; // 0xB8
	public static object EnablePreZPass; // 0xC0
	public static object EnableGPUOpt; // 0xC1
	public static object EnableGPUOptTest; // 0xC2

	// Properties
	public static object defaultShadowTexture { get; }

	// Methods

	// RVA: 0x77F64BC
	public static object Initialize() { }

	// RVA: 0x77F67A0
	public static object Shutdown() { }

	// RVA: 0x77F67A4
	public static object ResetGlobalConstants() { }

	// RVA: 0x77F6A30
	public static object ResetGlobalConstants(object cmd) { }

	// RVA: 0x77F6F2C
	public static object SetupPerFrame(object commands, object viewCamera, object worldData, object renderSettings, object frameIndex) { }

	// RVA: 0x77F78C0
	public static object SetupExposure(object commands, object viewCamera, object renderSettings, object preExposure, object prevInvPreExposure) { }

	// RVA: 0x77F77E4
	public static object HDRLinearColorEncode(object linearSpaceColorOutput) { }

	// RVA: 0x77F7C44
	public static object SetupShadowCasterPass(object cmd, object param) { }

	// RVA: 0x77F7EC4
	public static object SetupLightingPass(object cmd, object worldData, object renderSetting, object shadowSamplingParams) { }

	// RVA: 0x77F8CE8
	private static object SetupSSS(object cmd, object worldData, object renderSetting) { }

	// RVA: 0x77F7FE0
	public static object SetupSunLight(object cmd, object worldData, object renderSetting) { }

	// RVA: 0x77F86D8
	private static object SetupShadowMapSamplingParameters(object cmd, object worldData, object renderSetting, object shadowSamplingParams) { }

	// RVA: 0x77F84FC
	private static object SetupBakeLightsForPreview(object cmd, object worldData) { }

	// RVA: 0x77F8500
	private static object SetupFog(object cmd, object worldData, object settings) { }

	// RVA: 0x77F8F7C
	public static object SetupFoliageZTestMode(object cmd, object hasPrez) { }

	// RVA: 0x77F78BC
	public static object SetupOptimizeData(object cmd, object worldData) { }

	// RVA: 0x77F8CF0
	public static object get_defaultShadowTexture() { }

	// RVA: 0x77F901C
	private static object .cctor() { }

}

// Namespace: 
public class CollectionData<T0>
{

	// Fields
	private object m_flag; // 0x0
	private object m_transformFlag; // 0x0
	public object dispatchData; // 0x0
	public object transformDispatchData; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object flag, object transFormFlag) { }

	// RVA: -1
	private object HasFlag(object flags, object testFlag) { }

	// RVA: -1
	public object Refresh(object dispatcher, object flags) { }

	// RVA: -1
	public object EnableTrakingAllChanges(object dispatcher, object flags) { }

	// RVA: -1
	public object UpdateTrakingState(object dispatcher, object preFlags, object flags) { }

	// RVA: -1
	public object Clear() { }

}

// Namespace: 
public class TypeDispatchDataCollection
{

	// Fields
	public readonly object changedMeshRenderers; // 0x8
	public readonly object changedSkinnedMeshRenderers; // 0x10
	public object meshRendererCollectionData; // 0x18
	public object skinnedMeshRendererCollectionData; // 0x20
	public object yaLightCollectionData; // 0x28
	public object environmentLightCollectionData; // 0x30

	// Properties
	public object meshRendererDispatchData { get; }
	public object meshRendererTransformDispatchData { get; }
	public object skinnedMeshRendererDispatchData { get; }
	public object skinnedMeshRendererTransformDispatchData { get; }

	// Methods

	// RVA: 0x77FB774
	public object get_meshRendererDispatchData() { }

	// RVA: 0x77FB7B4
	public object get_meshRendererTransformDispatchData() { }

	// RVA: 0x77FB808
	public object get_skinnedMeshRendererDispatchData() { }

	// RVA: 0x77FB848
	public object get_skinnedMeshRendererTransformDispatchData() { }

	// RVA: 0x77FA948
	public object EnableTrakingAllChanges(object dispatcher, object unsynchronizedTrackingFlags) { }

	// RVA: 0x77FAA64
	public object UpdateTrakingState(object dispatcher, object preFlags, object flags) { }

	// RVA: 0x77FACA8
	public object Refresh(object dispatcher, object flags) { }

	// RVA: 0x77FAE6C
	public object Clear() { }

	// RVA: 0x77FB59C
	public object .ctor() { }

}

// Namespace: 
public enum ObjectTrackingFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object MeshRenderer;
	public const object MeshRendererScriptingArray;
	public const object MeshRendererTransform;
	public const object SkinnedMeshRenderer;
	public const object SkinnedMeshRendererScriptingArray;
	public const object SkinnedMeshRendererTransform;
	public const object YALight;
	public const object EnvironmentLight;
}

// Namespace: 
public abstract class RenderSystem
{

	// Methods

	// RVA: -1
	public abstract object Update(object collection) { }

	// RVA: 0x77FB89C
	public virtual object OnFrameBegin(object commands, object rendererBundleDict) { }

	// RVA: -1
	public abstract object OnEnable() { }

	// RVA: -1
	public abstract object OnDisable() { }

	// RVA: -1
	public abstract object GetTrackingFlags() { }

	// RVA: 0x77FB8A0
	internal virtual object OnImGui() { }

	// RVA: 0x77FB8A4
	protected object .ctor() { }

}

// Namespace: 
public enum RenderSystemFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ShadowCache;
	public const object RuntimeLightmap;
	public const object VolumetricLightmap;
	public const object RadianceCache;
	public const object WorldDataUpdateSystem;
	public const object AutoGIType;
	public const object SubsurfaceScattering;
	public const object Decal;
	public const object Count;
}

// Namespace: Yarp
public class RenderSystemManager
{

	// Fields
	private object m_trackingFlags; // 0x8
	private object m_flags; // 0xC
	private object m_newlyEnabledSystemFlags; // 0x10
	private object m_subSystems; // 0x18
	private object m_dispatchDataCollection; // 0x20
	private object m_objectDispatcher; // 0x28
	public object InsideRenderFunc; // 0x30

	// Methods

	// RVA: 0x77F9BDC
	public object GetFlags() { }

	// RVA: 0x77F9BE4
	protected override object Init() { }

	// RVA: 0x77F9C40
	protected override object UnInit() { }

	// RVA: 0x77F9EDC
	private object CreateSystem(object flag) { }

	// RVA: 0x77FA578
	public object GetSystem(object flag) { }

	// RVA: 0x77FA5C4
	public object Update() { }

	// RVA: 0x77FAFD4
	public object OnFrameBegin(object commands, object rendererBundleDict) { }

	// RVA: 0x77FB0DC
	public object ToggleSystem(object flag, object toggle) { }

	// RVA: 0x77FB2E8
	public object IsSystemEnabled(object flag) { }

	// RVA: 0x77FB0E8
	private object EnableSystem(object flag) { }

	// RVA: 0x77FB21C
	private object DisableSystem(object flag) { }

	// RVA: 0x77FB2F8
	internal object OnImGui() { }

	// RVA: 0x77FB520
	public object .ctor() { }

}

// Namespace: Yarp
public struct YASubsurfaceFrameData
{

	// Fields
	public object screenSpaceBounds; // 0xFFFFFFFFFFFFFFF8
	public object targetRenderers; // 0x8
	public object usedDiffusionProfiles; // 0x10
	public object disableBasePassTargetMaterials; // 0x18

	// Methods

	// RVA: 0x77FB8E8
	public object Init() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__17_0; // 0x8

	// Methods

	// RVA: 0x77FEC18
	private static object .cctor() { }

	// RVA: 0x77FEC78
	public object .ctor() { }

	// RVA: 0x77FEC80
	internal object <PrintAllTrackingRenderers>b__17_0(object r) { }

}

// Namespace: Yarp
public class SubsurfaceScatteringManager
{

	// Fields
	private static object s_layerMask_UI; // 0x0
	private static object s_layerMask_UIRaw; // 0x4
	private static object s_layerMask_3DUI; // 0x8
	private static object s_layerMask_UI_Background; // 0xC
	private static object s_layerMask_UI_Foreground; // 0x10
	private object m_profileStateDirty; // 0x8
	private object m_trackedRenderer; // 0x10
	public static readonly object _SubsurfaceHash; // 0x14
	public static readonly object _SubsurfaceProfileRef; // 0x18
	public static readonly object _SubsurfaceProfileIndex; // 0x1C
	private object m_tempSharedMaterialList; // 0x18
	private object m_targetRenderers; // 0x20
	private object m_disableBasePassTargetMaterials; // 0x28
	private object m_matSizeCullButNeedBasePass; // 0x30
	private object m_usedDiffusionProfiles; // 0x38
	private object m_frustumPlanes; // 0x40
	private object m_corners; // 0x48
	private object m_matBlock; // 0x50
	private static object s_isSubsurfaceShaderCache; // 0x20
	private static readonly object s_RenderTypeTag; // 0x28
	private static readonly object s_SubsurfaceTagID; // 0x2C
	private static readonly object s_SurfaceRenderTypeTag; // 0x30

	// Methods

	// RVA: 0x77FB9FC
	public static object Asfloat(object val) { }

	// RVA: 0x77FBA04
	public static object Asuint(object val) { }

	// RVA: 0x77FBA0C
	public static object ConvertGUIDToVector4(object guid) { }

	// RVA: 0x77FBDA0
	public static object ConvertVector4ToGUID(object vector) { }

	// RVA: 0x77FC0E4
	public override object OnEnable() { }

	// RVA: 0x77FC0E8
	public override object OnDisable() { }

	// RVA: 0x77FC144
	public override object GetTrackingFlags() { }

	// RVA: 0x77FC14C
	private object PrintAllTrackingRenderers() { }

	// RVA: 0x77FC150
	public static object IsSubsurfaceMaterialNoGC(object mat) { }

	// RVA: 0x77FC34C
	private object IsPotentialSSSSSMaterial(object mat) { }

	// RVA: 0x77FC4A4
	private object ExtractDiffusionProfile(object mat, object diffusionProfiles) { }

	// RVA: 0x77FC690
	private object FindAnyDiffusionProfileInTrack(object mat) { }

	// RVA: 0x77FC964
	private object GetScreenSpaceBounds(object worldBounds, object camera) { }

	// RVA: 0x77FCE88
	private object MergeRects(object a, object b) { }

	// RVA: 0x77FCF7C
	private object ApplyDiffusionProfileIndexToPropertyBlock(object renderer, object matIndex, object profileIndex) { }

	// RVA: 0x77FD0C0
	public object BuildFrameData(object inCameraData) { }

	// RVA: 0x77FDCE4
	private object CheckRendererIsSSSRenderer(object inChangedRenderer) { }

	// RVA: 0x77FDF0C
	public object UpdateUpdateSubsurfaceTrackingSingleRenderer(object renderer) { }

	// RVA: 0x77FE0B0
	private object UpdateSubsurfaceTracking(object dispatchData, object inChangedObjects, object transformDispatchData) { }

	// RVA: 0x77FE28C
	private object IsUILayer(object layerID) { }

	// RVA: 0x77FE38C
	public override object Update(object collection) { }

	// RVA: 0x77FA350
	public object .ctor() { }

	// RVA: 0x77FE950
	private static object .cctor() { }

}

// Namespace: Yarp
public class VolumetricLightmapManager
{

	// Fields
	private object m_renderersWithVLM; // 0x8
	private object m_renderersNeedToSetupVLM; // 0x10
	private object m_propBlock; // 0x18
	private object m_gray3DTexture; // 0x20
	private object m_tempSharedMaterialList; // 0x28

	// Methods

	// RVA: 0x77FECA4
	public override object OnEnable() { }

	// RVA: 0x77FECA8
	public override object OnDisable() { }

	// RVA: 0x77FED34
	public override object GetTrackingFlags() { }

	// RVA: 0x77FED3C
	private object ComputeVolumeScore(object volume, object rendererBounds) { }

	// RVA: 0x77FEFE8
	private object SetupPropertyBlock(object vlmTex, object vlmResult, object activeVolume, object propertyBlock) { }

	// RVA: 0x77FF1E8
	private object ValidateRenderer(object changedObj) { }

	// RVA: 0x77FF660
	private object UpdateStates(object dispatchData, object changedObject, object transformDispatchData) { }

	// RVA: 0x77FFC3C
	private object RefreshAllRenderers() { }

	// RVA: 0x77FFDFC
	private object ActivateVLM(object activeVolume, object renderer) { }

	// RVA: 0x7800218
	public override object Update(object collection) { }

	// RVA: 0x77FA204
	public object .ctor() { }

	// RVA: 0x77FEF08
	internal static object <ComputeVolumeScore>g__ComputeSquaredDistanceBetweenAABBs|8_0(object a, object b) { }

}

// Namespace: Yarp
public class RenderNode<T0>
{

	// Fields
	public object isDirty; // 0x0
	public object datas; // 0x0

	// Methods

	// RVA: -1
	public object Register(object data) { }

	// RVA: -1
	public object Unregister(object data) { }

	// RVA: -1
	public object Validate() { }

	// RVA: -1
	public object SetDirty() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
public class WorldDataBundle
{

	// Fields
	public object camera; // 0x8
	private object m_value; // 0x10

	// Methods

	// RVA: 0x7801D58
	public object .ctor(object aCamera) { }

	// RVA: 0x78029F0
	public object GetData() { }

}

// Namespace: Yarp
public abstract class WorldDataManager
{

	// Fields
	protected static object s_instance; // 0x0
	protected object m_worldData; // 0x8
	public object lights; // 0x10
	public object envLights; // 0x18
	public object renderSettingsVolumes; // 0x20
	public object planarReflectionProbes; // 0x28
	public object grabPasses; // 0x30
	public object distortions; // 0x38
	public object sunLights; // 0x40
	public object onWorldDataChange; // 0x48
	private object m_isDirty; // 0x50
	private object m_removeList; // 0x58

	// Properties
	public object worldDatas { get; }
	public virtual object isDirty { get; }

	// Methods

	// RVA: 0x78011A4
	public static object InitializeInstance(object instance) { }

	// RVA: 0x78011FC
	public object get_worldDatas() { }

	// RVA: 0x7801204
	public virtual object get_isDirty() { }

	// RVA: 0x7801324
	public virtual object Update() { }

	// RVA: 0x780193C
	public virtual object SetPreviewEnv(object cmd) { }

	// RVA: 0x7801AC4
	public virtual object UpdateJuneiSetting(object worldData, object cameraData) { }

	// RVA: 0x7801AC8
	public virtual object UpdateJuwaiSetting(object worldData, object cameraData) { }

	// RVA: 0x7801ACC
	public virtual object UpdateCiYuanYiChuSetting(object worldData, object cameraData) { }

	// RVA: 0x7801AD0
	public virtual object UpdateCiYuanGuangchangSetting(object worldData, object cameraData) { }

	// RVA: 0x7801AD4
	public object SetRenderDataDirty() { }

	// RVA: -1
	public object Update(object node, object isDescend) { }

	// RVA: 0x7801AE0
	public object GetWorldData(object camera) { }

	// RVA: 0x7801DD4
	public static object GetInstance() { }

	// RVA: -1
	public abstract object UpdateWorldData(object cameraData) { }

	// RVA: 0x7801490
	public object CheckWorldData() { }

	// RVA: 0x7801E78
	public object GetAllYALights() { }

	// RVA: 0x7801E9C
	public static object CheckLightActiveByLayer(object lights, object target, object lightLimit, object layer) { }

	// RVA: 0x7801FF8
	public object IsLightActive(object light, object camera) { }

	// RVA: 0x780241C
	public object IsEnvironmentLightActivate(object light, object camera) { }

	// RVA: 0x7802708
	public object GetAllEnvironmentLights() { }

	// RVA: 0x780272C
	public object GetAllRenderSettingsVolumes() { }

	// RVA: 0x7802750
	protected object .ctor() { }

}

// Namespace: Yarp
public class DefaultWorldDataManager
{

	// Methods

	// RVA: 0x78029F8
	public override object UpdateWorldData(object cameraData) { }

	// RVA: 0x7801E74
	public object .ctor() { }

}

// Namespace: 
public enum LightInActiveReason
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Disabled;
	public const object CulledByCamera;
	public const object ZeroIntensity;
	public const object BlackColor;
	public const object BakedEnvLight;
	public const object LowPriority;
	public const object LightGridOnlyOneDirLight;
}

// Namespace: Yarp
public static class WorldDataUtility
{

	// Methods

	// RVA: 0x7803AF0
	public static object ApplyDebugCameraData(object cameraId) { }

	// RVA: 0x7803F04
	public static object ApplyDebugWorldData(object cameraId) { }

	// RVA: 0x7804318
	public static object AssembleSunLight(object worldData, object sunLights, object layer) { }

	// RVA: 0x7802FB8
	public static object AssembleLight(object worldData, object lights, object layer) { }

	// RVA: 0x7802D4C
	public static object AssembleEnvLight(object worldData, object envLights, object layer) { }

	// RVA: 0x780463C
	public static object AssembleGrabPasses(object worldData, object grabPasses, object layer) { }

	// RVA: 0x78038F8
	public static object WorldDataPostProcess(object worldData, object cameraData) { }

	// RVA: -1
	public static object SortByPriority(object list, object isDescend) { }

	// RVA: 0x7804588
	public static object LayerMaskTest(object component, object mask) { }

	// RVA: 0x7804884
	public static object IsYaLightActive(object worldData, object cameraData, object light, object inActiveReason) { }

	// RVA: 0x7804E3C
	public static object IsEnvLightActive(object worldData, object cameraData, object light, object inActiveReason) { }

	// RVA: -1
	public static object GetComponentWithLayer(object list, object mask) { }

	// RVA: 0x7804FE0
	public static object GetGameObjectWithLayer(object list, object mask, object allowValidate) { }

}

// Namespace: Yarp
public static class YARenderPipelineManager
{

	// Fields
	private static object onFrameBegin; // 0x0
	private static object beginCameraRenderingExt; // 0x8
	private static object endCameraRenderingExt; // 0x10
	private static object update; // 0x18
	private static object s_onRenderImageEvent; // 0x20

	// Methods

	// RVA: 0x78051D4
	public static object add_onFrameBegin(object value) { }

	// RVA: 0x78052E4
	public static object remove_onFrameBegin(object value) { }

	// RVA: 0x78053F4
	public static object add_beginCameraRenderingExt(object value) { }

	// RVA: 0x7805508
	public static object remove_beginCameraRenderingExt(object value) { }

	// RVA: 0x780561C
	public static object add_endCameraRenderingExt(object value) { }

	// RVA: 0x7805730
	public static object remove_endCameraRenderingExt(object value) { }

	// RVA: 0x7805844
	public static object add_update(object value) { }

	// RVA: 0x7805934
	public static object remove_update(object value) { }

	// RVA: 0x7805A24
	public static object AddOnRenderImageListener(object pass) { }

	// RVA: 0x7805D74
	public static object RemoveOnRenderImageListener(object pass) { }

	// RVA: 0x7805F50
	public static object GetCameraOnRenderImage(object camera) { }

	// RVA: 0x7806038
	public static object BeginCameraRendering(object context, object cmd, object camera, object dest) { }

	// RVA: 0x7806114
	public static object EndCameraRendering(object context, object cmd, object camera, object activeTexture) { }

	// RVA: 0x78061F0
	public static object Update() { }

	// RVA: 0x7806280
	public static object OnFrameBegin(object gfxContext, object cmd) { }

	// RVA: 0x7806340
	private static object .cctor() { }

}

// Namespace: 
private struct FilterCreatedRenderJob
{

	// Fields
	public object ChangeRendererIDs; // 0xFFFFFFFFFFFFFFF8
	public object ChangeRendererReasons; // 0x8
	public object FilteredCreatedRenderIDs; // 0x18

	// Methods

	// RVA: 0x78071BC
	public object .ctor(object changeRendererIDs, object changeRendererReasons, object filteredCreatedRenderIDs) { }

	// RVA: 0x78076A8
	public object Execute() { }

}

// Namespace: Yarp
public class RuntimeLightmapManager
{

	// Fields
	private object m_objectDispatcher; // 0x8
	private object m_changedMeshRenderers; // 0x10
	private object m_changedSkinnedMeshRenderers; // 0x18
	private object m_destroyedMeshRenderers; // 0x20
	private object m_destroyedSkinnedMeshRenderers; // 0x28

	// Methods

	// RVA: 0x78063D0
	public override object OnEnable() { }

	// RVA: 0x78065E8
	public override object OnDisable() { }

	// RVA: 0x7806624
	public object Reboot() { }

	// RVA: 0x7806870
	public override object GetTrackingFlags() { }

	// RVA: 0x7806878
	public override object Update(object _) { }

	// RVA: 0x78071CC
	private object RegisterRenderer(object renderer) { }

	// RVA: 0x7807624
	private object UnregisterRenderer(object renderer) { }

	// RVA: 0x77FA13C
	public object .ctor() { }

}

// Namespace: Yarp
public enum ELightSamplingStrategy
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Uniform;
	public const object LightTree;
}

// Namespace: Yarp
public enum PathTracingDebug
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object EmissivePrimitive;
	public const object EmissivePrimitivePower;
	public const object EmissivePrimitiveAverageRadiance;
	public const object EmissivePrimitiveRadiance;
	public const object EmissivePrimitiveFaceNormal;
	public const object FaceNormal;
	public const object GeometryNormal;
	public const object ShadingNormal;
	public const object PathLength;
	public const object RadianceCache;
}

// Namespace: Yarp
public sealed class AdvancedCiYuanRenderer
{

	// Fields
	private object m_stbnSampler; // 0x48
	private object m_postProcessPass; // 0x50
	private object m_motionVector; // 0x58
	private object m_planarReflectionPass; // 0x60
	private object m_mainFbo; // 0x68
	private object m_taauInputFbo; // 0x70
	private object m_motionFbo; // 0x78
	private object m_shadowPass; // 0x80
	private object m_decalSystem; // 0x88
	private object m_frameIndex; // 0x90
	private object m_mainFBOFmt; // 0x98
	private object isVivoY77; // 0x9C
	private object m_PowerVRVLM; // 0xA0
	private static readonly object VLMProp; // 0x0
	private object m_enableTaau; // 0xA8
	private object m_preEnableTaau; // 0xA9
	private static readonly object m_DepthTextureShaderID; // 0x4
	internal static object ForceEnableLocalReflectionProbe; // 0x8

	// Properties
	private object decalSystem { get; }

	// Methods

	// RVA: 0x7807744
	private object get_decalSystem() { }

	// RVA: 0x78077C0
	public override object Init(object camera) { }

	// RVA: 0x7807D68
	private object BindPowerVRVLM(object cmd) { }

	// RVA: 0x7808038
	public override object GetMainFBO() { }

	// RVA: 0x7808040
	public override object GetShadowSamplingParameters() { }

	// RVA: 0x7808064
	public override object EnablePostProcess() { }

	// RVA: 0x780806C
	protected override object OnResize() { }

	// RVA: 0x7808194
	private object UseDepth() { }

	// RVA: 0x780807C
	private object ResizeBuffer(object width, object height, object worldData) { }

	// RVA: 0x78083F8
	protected override object Dispose(object disposing) { }

	// RVA: 0x7808760
	protected override object BeginRender(object context, object commands) { }

	// RVA: 0x78091B0
	public object RenderSceneToFBO(object context, object commands, object target) { }

	// RVA: 0x78091B8
	public object RenderSceneToFBO(object context, object commands, object target, object needDepth) { }

	// RVA: 0x780ABA4
	private object CreateMotionFbo() { }

	// RVA: 0x780B2EC
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x780C444
	protected override object EndRender(object context, object commands) { }

	// RVA: 0x780C644
	protected override object AdjustWorldData() { }

	// RVA: 0x780CB20
	public override object BeginRenderShaderAOV(object commands, object target, object context, object renderSettings) { }

	// RVA: 0x7808F64
	private object UpdateMainFBO() { }

	// RVA: 0x780AD2C
	private object SetupMotionVector(object context, object commands) { }

	// RVA: 0x780AFFC
	private object RenderOpaqueMotionVector(object context, object commands) { }

	// RVA: 0x780BFBC
	private object RenderTransparentVector(object context, object commands) { }

	// RVA: 0x780CF54
	public override object OnImGui() { }

	// RVA: 0x781086C
	public override object SupportLocalReflection() { }

	// RVA: 0x7810874
	protected override object RequireFBOMultipleOfFour() { }

	// RVA: 0x781087C
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x7810884
	public override object GetHyperCompatibility() { }

	// RVA: 0x781088C
	public object .ctor() { }

	// RVA: 0x78109B4
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__15_2; // 0x8
	public static object <>9__15_3; // 0x10
	public static object <>9__15_4; // 0x18
	public static object <>9__15_5; // 0x20
	public static object <>9__15_6; // 0x28
	public static object <>9__15_7; // 0x30
	public static object <>9__15_8; // 0x38
	public static object <>9__15_9; // 0x40
	public static object <>9__15_10; // 0x48
	public static object <>9__15_11; // 0x50
	public static object <>9__15_12; // 0x58
	public static object <>9__15_13; // 0x60
	public static object <>9__15_14; // 0x68
	public static object <>9__15_19; // 0x70
	public static object <>9__15_15; // 0x78
	public static object <>9__15_16; // 0x80
	public static object <>9__15_17; // 0x88
	public static object <>9__15_18; // 0x90

	// Methods

	// RVA: 0x781193C
	private static object .cctor() { }

	// RVA: 0x781199C
	public object .ctor() { }

	// RVA: 0x78119A4
	internal object <OnImGui>b__15_2(object setting, object value) { }

	// RVA: 0x78119C4
	internal object <OnImGui>b__15_3(object setting, object value) { }

	// RVA: 0x78119E4
	internal object <OnImGui>b__15_4(object setting, object value) { }

	// RVA: 0x7811A04
	internal object <OnImGui>b__15_5(object setting, object value) { }

	// RVA: 0x7811A24
	internal object <OnImGui>b__15_6(object setting, object value) { }

	// RVA: 0x7811A44
	internal object <OnImGui>b__15_7(object setting, object value) { }

	// RVA: 0x7811A64
	internal object <OnImGui>b__15_8(object setting, object value) { }

	// RVA: 0x7811A84
	internal object <OnImGui>b__15_9(object setting, object value) { }

	// RVA: 0x7811AA4
	internal object <OnImGui>b__15_10(object setting, object value) { }

	// RVA: 0x7811AC4
	internal object <OnImGui>b__15_11(object setting, object value) { }

	// RVA: 0x7811AE4
	internal object <OnImGui>b__15_12(object setting, object value) { }

	// RVA: 0x7811B04
	internal object <OnImGui>b__15_13(object setting, object value) { }

	// RVA: 0x7811B24
	internal object <OnImGui>b__15_14(object setting, object value) { }

	// RVA: 0x7811B44
	internal object <OnImGui>b__15_19(object setting, object value) { }

	// RVA: 0x7811B64
	internal object <OnImGui>b__15_15(object setting, object value) { }

	// RVA: 0x7811B84
	internal object <OnImGui>b__15_16(object setting, object value) { }

	// RVA: 0x7811BA4
	internal object <OnImGui>b__15_17(object setting, object value) { }

	// RVA: 0x7811BC4
	internal object <OnImGui>b__15_18(object setting, object value) { }

}

// Namespace: 
private struct <>c__DisplayClass15_0
{

	// Fields
	public object renderSettingsVolumes; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Yarp
public class BaseCiYuanRenderer
{

	// Fields
	private object m_enableLocalReflectionProbe; // 0x40
	public object EnableRenderResultCaching; // 0x41
	protected object m_isAdreno; // 0x42

	// Methods

	// RVA: 0x7810A58
	private object GetAndroidApi() { }

	// RVA: 0x7807B80
	public override object Init(object camera) { }

	// RVA: 0x7810C98
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x7810CA0
	public override object SupportShadowCache() { }

	// RVA: 0x7808078
	protected override object OnResize() { }

	// RVA: 0x78086CC
	protected override object Dispose(object disposing) { }

	// RVA: 0x780C9F4
	protected override object AdjustWorldData() { }

	// RVA: 0x7810CA8
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x7810CB0
	protected override object OnUpdateRender() { }

	// RVA: 0x7808E18
	protected override object BeginRender(object context, object commands) { }

	// RVA: 0x780BFB8
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x780C63C
	protected override object EndRender(object context, object commands) { }

	// RVA: 0x780D0CC
	public override object OnImGui() { }

	// RVA: 0x781192C
	public virtual object GetShadowSamplingParameters() { }

	// RVA: 0x7811934
	public virtual object GetMainFBO() { }

	// RVA: 0x7811198
	private object OnImGUIShadowSetting() { }

	// RVA: 0x7811690
	private object OnImGUIShadowColorSetting() { }

	// RVA: 0x78109A4
	public object .ctor() { }

	// RVA: 0x7810D40
	internal static object <OnImGui>g__toggleTaauSetting|15_0(object label, object value, object setter, object ) { }

	// RVA: 0x7810F64
	internal static object <OnImGui>g__taauSettingFloatSlider|15_1(object label, object value, object min, object max, object setter, object ) { }

}

// Namespace: 
public enum HyperCompatibility
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Rejected;
	public const object Required;
	public const object Optional;
}

// Namespace: Yarp
public abstract class ICameraRenderer
{

	// Fields
	protected object m_width; // 0x8
	protected object m_height; // 0xC
	protected object m_disposed; // 0x10
	protected object m_lightLoop; // 0x18
	private object m_camera; // 0x20
	protected object m_cameraData; // 0x28
	protected object m_worldData; // 0x30
	private object m_renderPasses; // 0x38
	private const object MIN_RT_SIZE;

	// Methods

	// RVA: 0x7811BE4
	public object GetRenderPass(object renderPassName) { }

	// RVA: 0x7811C08
	public object InitRenderPass(object renderPassName) { }

	// RVA: 0x7811C2C
	public virtual object Init(object camera) { }

	// RVA: 0x7811D18
	public object Dispose() { }

	// RVA: 0x7811DB4
	public object Render(object dest, object context, object commands) { }

	// RVA: 0x7812044
	public virtual object SupportLocalReflection() { }

	// RVA: -1
	public abstract object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x781204C
	public virtual object GetHyperCompatibility() { }

	// RVA: 0x7812054
	public virtual object SupportShadowCache() { }

	// RVA: 0x781205C
	protected virtual object RequireFBOMultipleOfFour() { }

	// RVA: 0x7812064
	public virtual object OnImGui() { }

	// RVA: 0x78123FC
	public object OnUpdate() { }

	// RVA: 0x7812D74
	public virtual object EnablePostProcess() { }

	// RVA: 0x7812D7C
	public virtual object BeginRenderShaderAOV(object commands, object target, object context, object renderSettings) { }

	// RVA: 0x7812D80
	public virtual object EndRenderShaderAOV(object commands, object target, object context, object renderSettings) { }

	// RVA: 0x7812D84
	protected virtual object OnUpdateRender() { }

	// RVA: -1
	protected abstract object AdjustWorldData() { }

	// RVA: 0x7812D88
	protected virtual object ShouldUpdateWorldData() { }

	// RVA: 0x7812D90
	protected virtual object BeginRender(object context, object commands) { }

	// RVA: 0x7812F18
	protected virtual object EndRender(object context, object commands) { }

	// RVA: -1
	protected abstract object OnRender(object dest, object context, object commands) { }

	// RVA: -1
	protected abstract object OnResize() { }

	// RVA: 0x7812F1C
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x7812F84
	protected object SetupMotionVectorFlag() { }

	// RVA: 0x7812FAC
	private object GetWidthAndHeight(object camera, object ScreenPercentage, object w, object h) { }

	// RVA: 0x7811F84
	private object Resize() { }

	// RVA: 0x7813330
	protected override object Finalize() { }

	// RVA: 0x7813470
	protected object .ctor() { }

}

// Namespace: Yarp
public class CiYuanDaZuoZhanRenderer
{

	// Fields
	private object m_postProcessPass; // 0x40
	private object m_shadowPass; // 0x48
	private object m_frameIndex; // 0x50
	private object m_mainFbo; // 0x58
	private readonly object m_mainFBOFmt; // 0x60

	// Methods

	// RVA: 0x7813478
	public object GetShadowSamplingParameters() { }

	// RVA: 0x781349C
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x78134A4
	public override object GetHyperCompatibility() { }

	// RVA: 0x78134AC
	public override object Init(object camera) { }

	// RVA: 0x7813530
	protected override object OnResize() { }

	// RVA: 0x7813554
	private object DisposeMainFBO() { }

	// RVA: 0x7813584
	protected override object Dispose(object disposing) { }

	// RVA: 0x781362C
	protected override object BeginRender(object context, object commands) { }

	// RVA: 0x7813994
	protected override object EndRender(object context, object commands) { }

	// RVA: 0x7813998
	private object UseDepth() { }

	// RVA: 0x78139A0
	public override object EnablePostProcess() { }

	// RVA: 0x78139F8
	private object PrepareMainFbo() { }

	// RVA: 0x7813BE4
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x7814974
	protected override object AdjustWorldData() { }

	// RVA: 0x7814D24
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x7814D2C
	public override object SupportShadowCache() { }

	// RVA: 0x7814D34
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__31_2; // 0x8
	public static object <>9__31_3; // 0x10
	public static object <>9__31_4; // 0x18
	public static object <>9__31_5; // 0x20
	public static object <>9__31_6; // 0x28
	public static object <>9__31_7; // 0x30
	public static object <>9__31_8; // 0x38
	public static object <>9__31_9; // 0x40
	public static object <>9__31_10; // 0x48
	public static object <>9__31_11; // 0x50
	public static object <>9__31_12; // 0x58
	public static object <>9__31_13; // 0x60
	public static object <>9__31_14; // 0x68
	public static object <>9__31_19; // 0x70
	public static object <>9__31_15; // 0x78
	public static object <>9__31_16; // 0x80
	public static object <>9__31_17; // 0x88
	public static object <>9__31_18; // 0x90

	// Methods

	// RVA: 0x781B608
	private static object .cctor() { }

	// RVA: 0x781B668
	public object .ctor() { }

	// RVA: 0x781B670
	internal object <OnImGui>b__31_2(object setting, object value) { }

	// RVA: 0x781B690
	internal object <OnImGui>b__31_3(object setting, object value) { }

	// RVA: 0x781B6B0
	internal object <OnImGui>b__31_4(object setting, object value) { }

	// RVA: 0x781B6D0
	internal object <OnImGui>b__31_5(object setting, object value) { }

	// RVA: 0x781B6F0
	internal object <OnImGui>b__31_6(object setting, object value) { }

	// RVA: 0x781B710
	internal object <OnImGui>b__31_7(object setting, object value) { }

	// RVA: 0x781B730
	internal object <OnImGui>b__31_8(object setting, object value) { }

	// RVA: 0x781B750
	internal object <OnImGui>b__31_9(object setting, object value) { }

	// RVA: 0x781B770
	internal object <OnImGui>b__31_10(object setting, object value) { }

	// RVA: 0x781B790
	internal object <OnImGui>b__31_11(object setting, object value) { }

	// RVA: 0x781B7B0
	internal object <OnImGui>b__31_12(object setting, object value) { }

	// RVA: 0x781B7D0
	internal object <OnImGui>b__31_13(object setting, object value) { }

	// RVA: 0x781B7F0
	internal object <OnImGui>b__31_14(object setting, object value) { }

	// RVA: 0x781B810
	internal object <OnImGui>b__31_19(object setting, object value) { }

	// RVA: 0x781B830
	internal object <OnImGui>b__31_15(object setting, object value) { }

	// RVA: 0x781B850
	internal object <OnImGui>b__31_16(object setting, object value) { }

	// RVA: 0x781B870
	internal object <OnImGui>b__31_17(object setting, object value) { }

	// RVA: 0x781B890
	internal object <OnImGui>b__31_18(object setting, object value) { }

}

// Namespace: 
private struct <>c__DisplayClass31_0
{

	// Fields
	public object renderSettingsVolumes; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Yarp
public sealed class CiYuanYiChuRenderer
{

	// Fields
	private object m_shadowPass; // 0x40
	private object m_postProcessPass; // 0x48
	private object m_planarReflectionPass; // 0x50
	private object m_taauPass; // 0x58
	private object m_sssPass; // 0x60
	private object m_frameIndex; // 0x68
	private object m_mainFBOFmt; // 0x70
	private object m_mainFbo; // 0x78
	private object m_taauInputFbo; // 0x80
	private object m_motionFbo; // 0x88
	private object m_preEnableTaau; // 0x90

	// Methods

	// RVA: 0x7814DA0
	public object GetShadowSamplingParameters() { }

	// RVA: 0x7814DC4
	public override object Init(object camera) { }

	// RVA: 0x7815074
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x781507C
	public override object SupportShadowCache() { }

	// RVA: 0x7815084
	public object GetMainFBO() { }

	// RVA: 0x781508C
	public override object GetHyperCompatibility() { }

	// RVA: 0x7815094
	public override object EnablePostProcess() { }

	// RVA: 0x7815638
	protected override object OnResize() { }

	// RVA: 0x781571C
	protected override object Dispose(object disposing) { }

	// RVA: 0x7815858
	protected override object BeginRender(object context, object commands) { }

	// RVA: 0x7815EC0
	protected override object EndRender(object context, object commands) { }

	// RVA: 0x7815FF4
	private object UseDepth() { }

	// RVA: 0x7816198
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x781855C
	private object DrawRendererList(object context, object commands, object desc, object grabPass, object dsStoreActionAfterGrab) { }

	// RVA: 0x7815E50
	private object CheckReset(object viewCamera, object worldData) { }

	// RVA: 0x7818C68
	private object UpdateMainFBO(object viewCamera, object worldData) { }

	// RVA: 0x7815828
	private object DisposeMainFBO() { }

	// RVA: 0x7818E54
	private object ReconstructFBO(object width, object height, object sampleCnt, object mainFBOFmt, object mainFBODepthFmt, object sRGB, object enablePostProcess) { }

	// RVA: 0x7818FF4
	protected override object AdjustWorldData() { }

	// RVA: 0x78190F8
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x7819100
	public override object OnImGui() { }

	// RVA: 0x781B500
	public object .ctor() { }

	// RVA: 0x781B0A8
	internal static object <OnImGui>g__toggleTaauSetting|31_0(object label, object value, object setter, object ) { }

	// RVA: 0x781B2CC
	internal static object <OnImGui>g__taauSettingFloatSlider|31_1(object label, object value, object min, object max, object setter, object ) { }

}

// Namespace: 
private static class ShaderProps
{

	// Fields
	public static object _ColorTex; // 0x0
	public static object _DepthTex; // 0x4

	// Methods

	// RVA: 0x781C88C
	private static object .cctor() { }

}

// Namespace: Yarp
public class CubemapRenderer
{

	// Fields
	private object m_mainFbo; // 0x40
	private object m_mainFBOFmt; // 0x48
	private object m_frameIndex; // 0x50
	private object m_shadowPass; // 0x58
	private object m_blitLinearEyeDepthToAlpha; // 0x60

	// Methods

	// RVA: 0x781B8B0
	public override object Init(object camera) { }

	// RVA: 0x781BA14
	private object DisposeMainFBO() { }

	// RVA: 0x781BA44
	protected override object Dispose(object disposing) { }

	// RVA: 0x781BAD8
	public override object GetHyperCompatibility() { }

	// RVA: 0x781BAE0
	protected override object OnResize() { }

	// RVA: 0x781BB04
	public override object SupportLocalReflection() { }

	// RVA: 0x781BB0C
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x781BB14
	public override object SupportShadowCache() { }

	// RVA: 0x781BB1C
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x781C7E8
	protected override object AdjustWorldData() { }

	// RVA: 0x781C810
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x781C818
	public object .ctor() { }

	// RVA: 0x781C684
	private object <OnRender>g__GetCameraTexture|14_0() { }

}

// Namespace: Yarp
public class DefaultRenderer
{

	// Fields
	public static object SkipVertexRendererList; // 0x0

	// Methods

	// RVA: 0x781C92C
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x781C934
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x781D0E0
	protected override object OnResize() { }

	// RVA: 0x781D0E4
	protected override object AdjustWorldData() { }

	// RVA: 0x781D108
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x781D12C
	public object .ctor() { }

}

// Namespace: Yarp
public sealed class JuNeiRenderer
{

	// Fields
	private object m_postProcessPass; // 0x40
	private object m_shadowPass; // 0x48
	private object m_frameIndex; // 0x50
	private object m_HDDMode; // 0x58
	private object m_mainFbo; // 0x60
	private readonly object m_mainFBOFmt; // 0x68

	// Properties
	private object postProcessPass { get; }
	private object shadowPass { get; }

	// Methods

	// RVA: 0x781D134
	private object get_postProcessPass() { }

	// RVA: 0x781D1E4
	private object get_shadowPass() { }

	// RVA: 0x781D328
	public object GetShadowSamplingParameters() { }

	// RVA: 0x781D34C
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x781D354
	public override object GetHyperCompatibility() { }

	// RVA: 0x781D35C
	public override object Init(object camera) { }

	// RVA: 0x781D3A0
	protected override object OnResize() { }

	// RVA: 0x781D3C4
	private object DisposeMainFBO() { }

	// RVA: 0x781D3F4
	protected override object Dispose(object disposing) { }

	// RVA: 0x781D498
	protected override object BeginRender(object context, object commands) { }

	// RVA: 0x781D550
	protected override object EndRender(object context, object commands) { }

	// RVA: 0x781D554
	private object UseDepth() { }

	// RVA: 0x781D55C
	public override object EnablePostProcess() { }

	// RVA: 0x781DAFC
	private object PrepareMainFbo() { }

	// RVA: 0x781DD04
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x781F13C
	protected override object AdjustWorldData() { }

	// RVA: 0x781F4B0
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x781F4EC
	public object .ctor() { }

}

// Namespace: Yarp
public sealed class JuWaiRenderer
{

	// Fields
	private object m_shadowPass; // 0x40
	private object m_postProcessPass; // 0x48
	private object m_planarReflectionPass; // 0x50
	private object m_taauPass; // 0x58
	private object m_sssPass; // 0x60
	private object m_frameIndex; // 0x68
	private object m_mainFBOFmt; // 0x70
	private object m_mainFbo; // 0x78
	private object m_taauInputFbo; // 0x80
	private object m_motionFbo; // 0x88
	private object m_preEnableTaau; // 0x90
	private object m_enableSSSSS; // 0x91

	// Methods

	// RVA: 0x781F4F4
	public object GetShadowSamplingParameters() { }

	// RVA: 0x781F518
	public override object Init(object camera) { }

	// RVA: 0x781F7D8
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x781F7E0
	public override object GetHyperCompatibility() { }

	// RVA: 0x781F7E8
	public override object EnablePostProcess() { }

	// RVA: 0x781FDA8
	protected override object OnResize() { }

	// RVA: 0x781FEB4
	protected override object Dispose(object disposing) { }

	// RVA: 0x781FFE8
	protected override object BeginRender(object context, object commands) { }

	// RVA: 0x7820680
	protected override object EndRender(object context, object commands) { }

	// RVA: 0x78207D8
	private object UseDepth() { }

	// RVA: 0x782097C
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x7823414
	private object DrawRendererList(object context, object commands, object desc, object grabPass, object dsStoreActionAfterGrab) { }

	// RVA: 0x7820494
	private object UpdateMainFBO() { }

	// RVA: 0x781FFB8
	private object DisposeMainFBO() { }

	// RVA: 0x7823B20
	private object ReconstructFBO(object width, object height, object sampleCnt, object mainFBOFmt, object mainFBODepthFmt, object sRGB, object enablePostProcess) { }

	// RVA: 0x7823CC0
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x7823CC8
	protected override object AdjustWorldData() { }

	// RVA: 0x7823FC0
	public override object OnImGui() { }

	// RVA: 0x7824090
	public object .ctor() { }

}

// Namespace: Yarp
public sealed class LiteCiYuanRenderer
{

	// Fields
	private object m_mainFbo; // 0x48
	private object m_shadowPass; // 0x50
	private object m_frameIndex; // 0x58

	// Methods

	// RVA: 0x7824194
	public override object GetShadowSamplingParameters() { }

	// RVA: 0x78241B8
	public override object Init(object camera) { }

	// RVA: 0x78242E8
	protected override object OnResize() { }

	// RVA: 0x782436C
	public override object GetMainFBO() { }

	// RVA: 0x7824374
	protected override object Dispose(object disposing) { }

	// RVA: 0x78243BC
	protected override object BeginRender(object context, object commands) { }

	// RVA: 0x78244D8
	public object RenderSceneToFBO(object context, object commands, object target) { }

	// RVA: 0x782455C
	public object RenderSceneToFBO(object context, object commands, object target, object depth) { }

	// RVA: 0x7824CEC
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x7825098
	protected override object EndRender(object context, object commands) { }

	// RVA: 0x78250A0
	protected override object AdjustWorldData() { }

	// RVA: 0x7825110
	protected override object RequireFBOMultipleOfFour() { }

	// RVA: 0x7825118
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x7825120
	public override object GetHyperCompatibility() { }

	// RVA: 0x7825128
	public object .ctor() { }

}

// Namespace: Yarp
public sealed class LiteForwardRenderer
{

	// Fields
	public const object name;
	private object m_opaqueDrawSettings; // 0x40
	private object m_transparentDrawSettings; // 0x114
	private object m_opaqueFilterSettings; // 0x1E8
	private object m_transparentFilterSettings; // 0x204
	private object m_postProcessings; // 0x220
	public static object s_enableDynamicBatching; // 0x0

	// Methods

	// RVA: 0x7825194
	public override object Init(object camera) { }

	// RVA: 0x78257A4
	protected override object OnResize() { }

	// RVA: 0x78257A8
	protected override object Dispose(object disposing) { }

	// RVA: 0x7825810
	protected override object BeginRender(object context, object commands) { }

	// RVA: 0x7825818
	protected override object EndRender(object context, object commands) { }

	// RVA: 0x782581C
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x7825F0C
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x7825F14
	protected override object AdjustWorldData() { }

	// RVA: 0x7825E1C
	public static object DrawRendererList(object renderContext, object cmd, object cullingResults, object drawingSettings, object filteringSettings) { }

	// RVA: 0x7825F18
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x7825F3C
	public object .ctor() { }

	// RVA: 0x7825F44
	private static object .cctor() { }

}

// Namespace: Yarp
public class UGCRenderer
{

	// Methods

	// RVA: 0x7825F94
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x7825F9C
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x7826714
	private object ExecuteCameraEventCommandBuffers(object context, object commands, object camera, object cameraEvent) { }

	// RVA: 0x782683C
	protected override object AdjustWorldData() { }

	// RVA: 0x7826860
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x7826884
	protected override object OnResize() { }

	// RVA: 0x7826888
	public object .ctor() { }

}

// Namespace: Yarp
public class UIRenderer
{

	// Fields
	public static object EnableUICullingOptimize; // 0x0
	public static object SkipOpaqueRendererList; // 0x1

	// Methods

	// RVA: 0x7826890
	public override object SupportMultipleVolumetricLightmaps() { }

	// RVA: 0x7826898
	protected override object OnRender(object dest, object context, object commands) { }

	// RVA: 0x7826F30
	protected override object AdjustWorldData() { }

	// RVA: 0x7826F5C
	protected override object ShouldUpdateWorldData() { }

	// RVA: 0x7826F80
	protected override object OnResize() { }

	// RVA: 0x7826F84
	public override object OnImGui() { }

	// RVA: 0x7826F88
	public object .ctor() { }

}

// Namespace: Yarp
public sealed class AccumulatePass
{

	// Fields
	private object m_shader; // 0x10

	// Methods

	// RVA: 0x7826F90
	public object Clear(object cmd, object dst) { }

	// RVA: 0x782701C
	public object Render(object cmd, object src, object dst) { }

	// RVA: 0x7827218
	public object .ctor() { }

}

// Namespace: 
public enum ColorEncoding
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object RGBM;
	public const object DepthOnly;
	public const object LinearToGamma;
	public const object GammaToLinear;
}

// Namespace: Yarp
public class BlitPass
{

	// Fields
	public static object s_SwizzleRGBA; // 0x0
	public static object s_SwizzleBGRA; // 0x10
	public static object s_SwizzleRRRR; // 0x20
	public static object s_SwizzleAAAA; // 0x30
	private object <FlipVertical>k__BackingField; // 0x8
	private object <UVOffset>k__BackingField; // 0xC
	private object <Swizzle>k__BackingField; // 0x14
	public object ColorScale; // 0x24
	public object ColorOffset; // 0x28
	public object Encoding; // 0x2C
	public object EnableBlend; // 0x30
	public object SrcBlend; // 0x34
	public object DstBlend; // 0x38
	public object BlendOp; // 0x3C
	private object m_block; // 0x40
	private object m_material; // 0x48
	private object m_pass; // 0x50
	private object m_cubeMapToOctahedralPass; // 0x54
	private object m_keywordMSAA2; // 0x58
	private object m_keywordMSAA4; // 0x70
	private object m_keywordMSAA8; // 0x88
	private static object s_blitPass; // 0x40

	// Properties
	public object FlipVertical { get; set; }
	public object UVOffset { get; set; }
	public object Swizzle { get; set; }

	// Methods

	// RVA: 0x7827288
	public object set_FlipVertical(object value) { }

	// RVA: 0x7827290
	public object get_FlipVertical() { }

	// RVA: 0x7827298
	public object set_UVOffset(object value) { }

	// RVA: 0x78272A0
	public object get_UVOffset() { }

	// RVA: 0x78272A8
	public object set_Swizzle(object value) { }

	// RVA: 0x78272B4
	public object get_Swizzle() { }

	// RVA: 0x78272C0
	public object Dispose() { }

	// RVA: 0x7827350
	public object .ctor() { }

	// RVA: 0x7827598
	private object SetupMaterial() { }

	// RVA: 0x7827848
	private object DisableKeywords(object cmd, object material) { }

	// RVA: 0x78278B0
	private object SetupKeywordAndTexture(object cmd, object material, object block, object src) { }

	// RVA: 0x7827B54
	public object Render(object src, object dst) { }

	// RVA: 0x7827C54
	public object Render(object cmd, object src, object dst, object mipLevel, object cubemapFace, object depthSlice, object rect) { }

	// RVA: 0x7827E3C
	public object Render(object cmd, object src, object dst, object width, object height, object fmt) { }

	// RVA: 0x7827FF8
	public object CubeMapToOctahedral(object cmd, object src, object dst, object size, object borderSize) { }

	// RVA: 0x7824F0C
	public static object Blit(object commands, object src, object dst, object dstEncoding, object flipVertical, object mipLevel, object cubemapFace, object depthSlice, object rect) { }

	// RVA: 0x78282D4
	public static object Blit(object commands, object src, object dst, object width, object height, object fmt, object dstEncoding, object flipVertical) { }

	// RVA: 0x7828458
	public static object CubeMapToOctahedral(object commands, object src, object dst, object borderSize) { }

	// RVA: 0x7828714
	private static object .cctor() { }

}

// Namespace: Yarp
public class CascadeShadowMap
{

	// Fields
	private object m_viewMatrices; // 0x8
	private object m_projMatrices; // 0x10
	private object m_shadowTexture; // 0x18
	private object m_shadowMapResolution; // 0x20
	private object m_cascadeSplit; // 0x28
	private object m_shadowSamplingParameters; // 0x30
	private object m_shadowCamera; // 0x38

	// Methods

	// RVA: 0x781D494
	public object Dispose() { }

	// RVA: 0x782877C
	private object CleanUp() { }

	// RVA: 0x782886C
	private static object UpdateShadowMatrix(object viewMatrix, object projectionMatrix, object parameters) { }

	// RVA: 0x7828AB0
	private object ComputeSpotShadowMatrices(object shadowSettings, object light) { }

	// RVA: 0x7829260
	private object ComputeSpotPlusShadowMatrices(object shadowSettings, object light) { }

	// RVA: 0x78294DC
	private object ComputeViewProjMatrix(object viewCamera, object shadowSettings, object lightTransform, object debugDraw) { }

	// RVA: 0x7829734
	private object UpdateDepthBiasShaderConstants(object cmd, object settings, object viewMatrix, object projMatrix, object isDirectional) { }

	// RVA: 0x782990C
	public object GetShadowSamplingParameters() { }

	// RVA: 0x7829914
	private object UpdateShadowTexture(object settings, object mainCamera) { }

	// RVA: 0x7829BD8
	private object UpdateCascadeSplit(object settings) { }

	// RVA: 0x781EC80
	public object Render(object viewCamera, object worldData, object context, object commands) { }

	// RVA: 0x782A184
	private object CreateCamera(object viewCamera, object targetTexture, object cameraIndex) { }

	// RVA: 0x782A478
	private object UpdateCameraParameters(object viewCamera, object shadowCamera, object viewMatrix, object projectMatrix) { }

	// RVA: 0x7829CF0
	private object CameraRender(object viewCamera, object settings, object isDirectional, object context, object commands) { }

	// RVA: 0x781D25C
	public object .ctor() { }

}

// Namespace: 
public enum EShadowUpdateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object On_Frame;
	public const object On_Demand;
}

// Namespace: 
public enum ECloseupShadowAtlas
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Uniform_Split;
	public const object Apaptive_Split;
	public const object Custom_Split;
}

// Namespace: 
public enum ESunShadowBoundingBox
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Dynamic;
	public const object UserDefined;
}

// Namespace: 
public enum EShadowMapSize
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ShadowMapSize_128x128;
	public const object ShadowMapSize_256x256;
	public const object ShadowMapSize_512x512;
	public const object ShadowMapSize_1024x1024;
}

// Namespace: Yarp
public class SunShadowSetting
{

	// Fields
	public object activate; // 0x8
	public object FilteSize; // 0xC
	public object SunShadowSphereFit; // 0x10
	public object SunShadowBounds; // 0x14
	public object UserDefinedBounds; // 0x18
	public object UserDefinedSphereBounds; // 0x20
	public object LightSpaceShadowFade; // 0x28
	public object NearPlane; // 0x30
	public object FarPlane; // 0x34
	public object ZRange; // 0x38
	public object NumShadowCascades; // 0x3C
	public object CascadeDistributionExponent; // 0x40
	public object DepthSlopeBias; // 0x44
	public object DepthBiasClamp; // 0x48
	public object NormalBias; // 0x4C
	public object ConstantDepthBias; // 0x50
	public object ShadowMapResolution; // 0x54

	// Methods

	// RVA: 0x782A580
	public object GetShadowBoundingShpere() { }

	// RVA: 0x7829184
	public object UseUserDefinedShadowVolume() { }

	// RVA: 0x7814918
	public object Copy(object target) { }

	// RVA: 0x782A8C0
	public object Clone() { }

	// RVA: 0x782A948
	public object .ctor() { }

}

// Namespace: 
internal class CloudMapData
{

	// Fields
	public object CellIndex; // 0x8
	public object CellCoordxz; // 0xC
	public object CellMinMax; // 0x14
	public object SunOcclusionTex; // 0x28
	public object SkyOcclusionTex; // 0x30
	public object CellUsed; // 0x38

	// Methods

	// RVA: 0x782CA30
	public object .ctor() { }

	// RVA: 0x782CADC
	public object CopyFrom(object right) { }

}

// Namespace: 
internal class CloudMapDataPool
{

	// Fields
	private object m_maxCapacity; // 0x8
	private object m_dataItems; // 0x10

	// Methods

	// RVA: 0x782C898
	public object .ctor(object _maxCapacity) { }

	// RVA: 0x782B800
	public object Get(object index) { }

	// RVA: 0x782C63C
	public object Count() { }

}

// Namespace: Yarp
public class CloudMapSystem
{

	// Fields
	private object m_gridGrayTexture; // 0x8
	private object m_currentBlockMinMax; // 0x10
	private object m_supportLocalCloudMap; // 0x20
	private object m_needUpdateCloudMap; // 0x21
	private object m_sunOcclusionAtlas; // 0x28
	private object m_skyOcclusionAtlas; // 0x30
	private object m_cloudMap2PoolData; // 0x38
	private object m_cloudMapDataPool; // 0x40
	private object m_totalBlockXZCount; // 0x48

	// Methods

	// RVA: 0x782A994
	protected override object Init() { }

	// RVA: 0x782AA84
	protected override object UnInit() { }

	// RVA: 0x782AB3C
	private object Cleanup() { }

	// RVA: 0x782AC38
	private object GetGridGrayTexture(object width, object height, object textureFormat) { }

	// RVA: 0x782AE10
	public object GetSunOcclusionTex(object setting) { }

	// RVA: 0x782AF2C
	public object GetSunOcclusionIntensity(object setting) { }

	// RVA: 0x782B038
	public object GetSunOcclusionPositionScaleOffset(object setting) { }

	// RVA: 0x782B178
	private object GetLocalOcclusionPositionScaleOffset() { }

	// RVA: 0x782B1E8
	public object GetSkyOcclusionTex(object setting) { }

	// RVA: 0x782B2E8
	public object GetSkyOcclusionIntensity(object setting) { }

	// RVA: 0x782B414
	public object GetSkyOcclusionPositionScaleOffset(object setting) { }

	// RVA: 0x782B55C
	private object OnFrameBegin(object gfxContext, object cmd) { }

	// RVA: 0x782B5E4
	private object ComputeTerrainBlockDynamicSize() { }

	// RVA: 0x782BAE4
	private object ComputeTerrainCloudmap(object isSunOcclusion, object occlusionAtlasMap) { }

	// RVA: 0x782C29C
	private object GetOcclusionOrDefaultTex(object blockIndex, object isSunOcclusion) { }

	// RVA: 0x782B5A8
	private object OnUpdateBlockCloudMap() { }

	// RVA: 0x782C3BC
	public object RegisterSingleGridCloudMap(object gridIndex, object localCloudComp) { }

	// RVA: 0x782C654
	public object UnRegisterSingleGridCloudMap(object gridIndex) { }

	// RVA: 0x782C798
	public object .ctor() { }

}

// Namespace: Yarp
public class YALocalCloudMap
{

	// Fields
	public static object CloudRatio; // 0x0
	public object isDirty; // 0x18
	public object LocalMapIndex; // 0x1C
	public object GridMinMax; // 0x20
	public object LocalMapBlockXZ; // 0x30
	public object BlockXZCount; // 0x38
	public object LocalCloudMap; // 0x40
	public object LocalSkyOcclusion; // 0x48
	private object m_needUpdateCloudMap; // 0x50

	// Methods

	// RVA: 0x782CB20
	public object SetBlockInfo(object localMapIndex, object blockXZIndex, object blockXZCount, object gridMinMax) { }

	// RVA: 0x782CB3C
	public object RegisterCloudMap() { }

	// RVA: 0x782CBA8
	private object OnDisable() { }

	// RVA: 0x782CC18
	private object Update() { }

	// RVA: 0x782CC90
	public object .ctor() { }

	// RVA: 0x782CCA0
	private static object .cctor() { }

}

// Namespace: Yarp
public class CombineVirtualBackBufferPass
{

	// Fields
	private object m_material; // 0x8

	// Methods

	// RVA: 0x782CCF0
	public object .ctor() { }

	// RVA: 0x782CD94
	public object Render(object cmd, object src) { }

}

// Namespace: 
private class TextureObject
{

	// Fields
	public object Width; // 0x8
	public object Height; // 0xC
	public object Channels; // 0x10
	public object Buffer; // 0x18

	// Methods

	// RVA: 0x782D95C
	public object Resize(object w, object h, object c) { }

	// RVA: 0x782D16C
	public object Dispose() { }

	// RVA: 0x782DCA8
	public object .ctor() { }

}

// Namespace: Yarp
public sealed class DenoisePass
{

	// Fields
	private object m_denoiser; // 0x10
	private object m_colorTexture; // 0x18
	private object m_outputTexture; // 0x20
	private object m_albedoTexture; // 0x28
	private object m_normalTexture; // 0x30
	private object m_motionTexture; // 0x38

	// Properties
	public object ColorTexture { get; }
	public object OutputTexture { get; }
	public object AlbedoTexture { get; }
	public object NormalTexture { get; }
	public object MotionTexture { get; }

	// Methods

	// RVA: 0x782CEB8
	public object get_ColorTexture() { }

	// RVA: 0x782CEDC
	public object get_OutputTexture() { }

	// RVA: 0x782CF00
	public object get_AlbedoTexture() { }

	// RVA: 0x782CF24
	public object get_NormalTexture() { }

	// RVA: 0x782CF48
	public object get_MotionTexture() { }

	// RVA: 0x782CF6C
	protected override object Dispose(object disposing) { }

	// RVA: 0x782D204
	private object ExecuteAndSubmitCommands(object context, object commands) { }

	// RVA: 0x782D2CC
	public object Prepare(object width, object height, object type, object guideAlbedo, object guideNormal, object temporalMode, object cleanAux, object prefilterAux) { }

	// RVA: 0x782DA3C
	public object Render(object context, object commands) { }

	// RVA: 0x782DBDC
	public object .ctor() { }

}

// Namespace: 
public enum EBufferSize
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Full;
	public const object Half;
	public const object Quarter;
}

// Namespace: Yarp
public class DistortionVector
{

	// Methods

	// RVA: 0x782DCB8
	public object Dispose() { }

	// RVA: 0x782DCBC
	public object .ctor() { }

}

// Namespace: Yarp
public class ImageBlendPass
{

	// Fields
	private object m_block; // 0x8
	private object m_material; // 0x10
	public static readonly object _BeginTex; // 0x0
	public static readonly object _EndTex; // 0x4
	public static readonly object _Ratio; // 0x8
	private static object s_imageBlendPass; // 0x10

	// Methods

	// RVA: 0x782DCC4
	public object Dispose() { }

	// RVA: 0x782DD34
	public object .ctor() { }

	// RVA: 0x782DE58
	public object Render(object cmd, object src1, object src2, object ratio, object dst) { }

	// RVA: 0x782E018
	public static object ImageBlend(object commands, object begin, object end, object ratio, object dst) { }

	// RVA: 0x782E164
	private static object .cctor() { }

}

// Namespace: Yarp
public class IRenderPass
{

	// Fields
	protected object m_disposed; // 0x8

	// Methods

	// RVA: 0x782E238
	public object Dispose() { }

	// RVA: 0x782D1F0
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x782E2D0
	protected override object Finalize() { }

	// RVA: 0x782DCB0
	public object .ctor() { }

}

// Namespace: 
private static class Props
{

	// Fields
	public static readonly object LightGridOccupancyBuffer; // 0x0
	public static readonly object LightGridOccupancyTexture; // 0x4
	public static readonly object PackedLightNum; // 0x8
	public static readonly object PackedRadianceProbeNum; // 0xC
	public static readonly object LightGridWidth; // 0x10
	public static readonly object LightGridHeight; // 0x14
	public static readonly object LightGridScreenToViewSpace; // 0x18
	public static readonly object LightGridViewMatrix; // 0x1C
	public static readonly object LightGridDepthNearFar; // 0x20
	public static readonly object DirectionalLightNum; // 0x24
	public static readonly object DirectionalLightDirs; // 0x28
	public static readonly object DirectionalLightColors; // 0x2C
	public static readonly object RWLightGridOccupancyBuffer; // 0x30
	public static readonly object CameraPosition; // 0x34
	public static readonly object InvViewProjMatrix; // 0x38
	public static readonly object PackedLightData_RelativeLocationAndInvRadiusSq; // 0x3C
	public static readonly object PackedLightData_IntensityAndRange; // 0x40
	public static readonly object PackedLightData_DirectionAndLayerMask; // 0x44
	public static readonly object PackedLightData_SpotLightAngleScaleAndOffsetAndHalfAngleAndShadowIndex; // 0x48
	public static readonly object LightGridRadianceProbeAtlas; // 0x4C
	public static readonly object PackedRadianceProbeData_RelativeLocationAndRadius; // 0x50
	public static readonly object PackedRadianceProbeData_AtlasScaleOffset; // 0x54
	public static readonly object PackedRadianceProbeData_RuntimeUserData; // 0x58

	// Methods

	// RVA: 0x78320C0
	private static object .cctor() { }

}

// Namespace: 
private struct Plane
{

	// Fields
	private readonly object m_normal; // 0xFFFFFFFFFFFFFFF8
	private readonly object m_offset; // 0x4

	// Methods

	// RVA: 0x7831DFC
	public object .ctor(object normal, object offset) { }

	// RVA: 0x7831E08
	public object DistanceToPoint(object pos) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__32_0; // 0x8

	// Methods

	// RVA: 0x7832544
	private static object .cctor() { }

	// RVA: 0x78325A4
	public object .ctor() { }

	// RVA: 0x78325AC
	internal object <InplaceInsertSortRadianceProbes>b__32_0(object probeA, object probeB) { }

}

// Namespace: 
private struct <>c__DisplayClass31_0
{

	// Fields
	public object camera; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
private struct <>c__DisplayClass33_0
{

	// Fields
	public object screenToViewSpace; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Yarp
public class LightGrid
{

	// Fields
	private object m_gridOccupancyBuffer; // 0x8
	private object m_gridOccupancyTexture; // 0x10
	private object m_lightGridInjection; // 0x18
	private object m_lightGridInjectionPSMaterial; // 0x20
	private object m_lightGridInjectionKernel; // 0x28
	private const object m_maxPackedLightNum;
	private const object m_maxPackedRadianceProbeNum;
	private const object m_maxDirectionalLightNum;
	private const object m_maxPackedLightNumGLES;
	private const object m_maxPackedRadianceProbeNumGLES;
	private const object m_maxDirectionalLightNumGLES;
	private object m_lightDataRelativeLocationsAndInvRadiusSq; // 0x30
	private object m_lightDataIntensityAndRange; // 0x38
	private object m_lightDataDirectionAndLayerMask; // 0x40
	private object m_lightDataSpotLightAngleScaleAndOffsetAndHalfAngleAndShadowIndex; // 0x48
	private object m_radianceProbeDataRelativeLocationsAndRadius; // 0x50
	private object m_radianceProbeDataAtlasScaleOffset; // 0x58
	private object m_radianceProbeDataRuntimeUserData; // 0x60
	private object m_frustumPlanes; // 0x68
	private object m_sortedLocalLights; // 0x70
	private object m_sortedRadianceProbes; // 0x78
	private object m_directionalLightDirs; // 0x80
	private object m_directionalLightColors; // 0x88
	private const object m_tileSize;

	// Methods

	// RVA: 0x782E4AC
	public object .ctor() { }

	// RVA: 0x782E658
	private object IsLite() { }

	// RVA: 0x782E678
	private object ValidateOrCreateOccupancyBuffer(object w, object h) { }

	// RVA: 0x782E95C
	private object LightAttenuationPolynomialOverDeriv(object D, object R, object S) { }

	// RVA: 0x782E9B0
	private object OptimizeLightRange(object R, object luminance) { }

	// RVA: 0x782EAD4
	private object InplaceInsertSortLights(object camera) { }

	// RVA: 0x782ED94
	private object InplaceInsertSortRadianceProbes(object camera) { }

	// RVA: 0x782EEBC
	public object Render(object camera, object cmd, object supportLocalReflection) { }

	// RVA: 0x7831E2C
	public object BindDummyBuffer(object cmd) { }

	// RVA: 0x7831F40
	public object EndRender(object cmd) { }

	// RVA: 0x7831FC4
	public object Dispose() { }

	// RVA: 0x782EC28
	internal static object <InplaceInsertSortLights>g__LightComparer|31_0(object lightA, object lightB, object ) { }

	// RVA: 0x7831DE4
	internal static object <Render>g__LightGrid_ScreenToViewAtZ1|33_0(object screen, object ) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object g_DominantLightForward; // 0x0
	public static readonly object g_DominantLightUp; // 0x4
	public static readonly object g_DominantLightRight; // 0x8

	// Methods

	// RVA: 0x7832E78
	private static object .cctor() { }

}

// Namespace: Yarp
public class LightLoop
{

	// Fields
	private object m_lightGrid; // 0x8
	private object m_simpleLightLoop; // 0x10

	// Methods

	// RVA: 0x78326DC
	public object .ctor() { }

	// RVA: 0x7832774
	public object GetLightGrid() { }

	// RVA: 0x783277C
	public object ShouldUseLightGrid(object camera, object supportLightGrid) { }

	// RVA: 0x783284C
	public object Setup(object camera, object commandBuffer, object supportLightGrid, object supportLocalReflection) { }

	// RVA: 0x7832C40
	public object OnImGui(object cameraData, object worldData) { }

	// RVA: 0x7832DA0
	public object Clear(object commandBuffer) { }

	// RVA: 0x7832E38
	public object Dispose() { }

}

// Namespace: 
public enum EBufferSize
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Full;
	public const object Half;
	public const object Quarter;
	public const object Size_256;
	public const object Size_128;
}

// Namespace: Yarp
public class MaskPass
{

	// Fields
	private object m_fbo; // 0x8
	private object m_shader; // 0x10

	// Methods

	// RVA: 0x7832F4C
	public object .ctor(object shaderName) { }

	// RVA: 0x78331D4
	public object Dispose() { }

	// RVA: 0x78331E8
	public object GetMask() { }

	// RVA: 0x78330BC
	private object Init(object shader) { }

	// RVA: 0x78331F0
	public object Render(object context, object commands, object viewCamera, object bufferSize, object layerMask, object replacementTag) { }

}

// Namespace: Yarp
public sealed class MotionVector
{

	// Fields
	private object m_material; // 0x10

	// Methods

	// RVA: 0x7833644
	public object Render(object context, object commands, object viewCamera, object velocityTexture, object depthTexture, object disableAlphaToMask, object depthOffsetSlope, object depthOffsetUnits) { }

	// RVA: 0x7833F60
	public object RenderCameraMotionVectors(object commands, object viewCamera, object RTIndex) { }

	// RVA: 0x7834098
	public object RenderCameraMotionVectorsWithDepth(object commands, object viewCamera, object depth) { }

	// RVA: 0x7833BFC
	private static object SetupCameraMotionVectorsMaterial(object viewCamera, object mat) { }

	// RVA: 0x7834210
	public object .ctor() { }

}

// Namespace: Yarp
public interface OnRenderImagePass
{

	// Methods

	// RVA: -1
	public abstract object GetPriority() { }

	// RVA: -1
	public abstract object GetCamera() { }

	// RVA: -1
	public abstract object OnRenderImage(object src, object dest, object camera, object content, object cmd) { }

}

// Namespace: Yarp
public class OnRenderImageEvent
{

	// Fields
	private readonly object m_onRenderImage; // 0x8
	private object m_id; // 0x10

	// Properties
	public object Priority { get; }
	public object ID { get; }

	// Methods

	// RVA: 0x78342B0
	public override object Equals(object obj) { }

	// RVA: 0x7834354
	public override object GetHashCode() { }

	// RVA: 0x78343A0
	public object .ctor(object pass) { }

	// RVA: 0x78343CC
	public object get_Priority() { }

	// RVA: 0x78344AC
	public object get_ID() { }

	// RVA: 0x783461C
	public object OnRenderImage(object src, object dest, object camera, object content, object cmd) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _InputTex; // 0x0
	public static readonly object _ReflectionDepthTex; // 0x4
	public static readonly object _ClipPlane; // 0x8
	public static readonly object _InvReflectProjectMatrix; // 0xC
	public static readonly object _DepthToRadiusFactor; // 0x10
	public static object _ReflectionMip; // 0x18

	// Methods

	// RVA: 0x7836ED0
	private static object .cctor() { }

}

// Namespace: Yarp
public class PlanarReflection
{

	// Fields
	private object m_fbo; // 0x8
	private object m_mipfbo; // 0x10
	private object m_fboDesc; // 0x18
	private object m_FilteringMaterial; // 0x20
	private const object k_MaxPyramidSize;

	// Properties
	private object filteringMaterial { get; }

	// Methods

	// RVA: 0x7834734
	private object get_filteringMaterial() { }

	// RVA: 0x7834880
	public object Dispose() { }

	// RVA: 0x7834960
	public object .ctor() { }

	// RVA: 0x7834B80
	private static object EnsureReflectionCamera(object probe, object viewCamera, object reflectionCamera) { }

	// RVA: 0x7834CC4
	private static object UpdateReflectionCamera(object probe, object viewCamera, object reflectionCamera) { }

	// RVA: 0x7835374
	private object Resize(object w, object h) { }

	// RVA: 0x78353A0
	private object CalculateCameraPosAndDir(object probe, object viewCamera, object cameraPos, object cameraDir, object cameraUp) { }

	// RVA: 0x78358BC
	private object CalculateProjectMatrix(object probe, object viewCamera, object worldToCameraMatrix, object clipPlane) { }

	// RVA: 0x7835AEC
	private object ShuoldUseMipmap(object probe, object worldData) { }

	// RVA: 0x7835B44
	public object Render(object context, object commands, object viewCamera, object settings, object worldData, object probe) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _Intensity; // 0x0

	// Methods

	// RVA: 0x7837AB4
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class AfterStack
{

	// Fields
	private object m_materialParams; // 0x8

	// Methods

	// RVA: 0x7837004
	public object Dispose() { }

	// RVA: 0x7837008
	public object .ctor() { }

	// RVA: 0x7837078
	public object Execute(object cmd, object pixelRect, object setting, object source, object tempRTs, object finalPass) { }

}

// Namespace: 
private struct <>c__DisplayClass26_0
{

	// Fields
	public object projection; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Yarp
public class AmbientOcclusionPass
{

	// Fields
	private object m_REBLUR; // 0x18
	private object m_propBlock; // 0x20
	private static readonly object GCameraToNormalizedNDCMatrix; // 0x0
	private static readonly object GProjectionMatrix; // 0x4
	private static readonly object GWorldToCameraMatrix; // 0x8
	private static readonly object GCameraToWorldMatrix; // 0xC
	private static readonly object GCameraNearFar; // 0x10
	private static readonly object GFrameIndex; // 0x14
	private static readonly object GPixelSizeAndScreenSize; // 0x18
	private static readonly object GAmountAndPower; // 0x1C
	private static readonly object GHitDistParams; // 0x20
	private static readonly object AOTex; // 0x24
	private static readonly object AOHistoryTex; // 0x28
	private static readonly object AccumulatedSpeed; // 0x2C
	private static readonly object LinearTex; // 0x30
	private static readonly object IntermediateLinearTex; // 0x34
	private static readonly object AOBlackPoint; // 0x38
	private object m_traceRayMaterial; // 0x28
	private object m_upsampleMaterial; // 0x30
	private object APPLY_AO_TO_LINEAR_COLOR; // 0x38
	private object m_rawAOTex; // 0x50
	private object m_aoPingPongFbo; // 0x58
	private object m_aoChangedMask; // 0x60

	// Methods

	// RVA: 0x7837B28
	public override object GetRenderPassName() { }

	// RVA: 0x7837B30
	public object .ctor() { }

	// RVA: 0x7837D10
	public object ApplyAOToLinearColor(object settings, object renderContext, object commandBuffer, object linearResultTexture) { }

	// RVA: 0x783854C
	public object Render(object settings, object renderContext, object commandBuffer, object camera) { }

	// RVA: 0x7839150
	public object BuildAOChangedMask(object commandBuffer) { }

	// RVA: 0x7839448
	public object GetAOChangedMask() { }

	// RVA: 0x7839470
	protected override object Dispose(object disposing) { }

	// RVA: 0x7838F7C
	private object SetRenderTarget(object commandBuffer, object tex) { }

	// RVA: 0x7838290
	private object ValidateMaterial() { }

	// RVA: 0x7839514
	private static object .cctor() { }

	// RVA: 0x7838EB4
	internal static object <Render>g__GetCameraToNormalizedNDCMatrix|26_0(object ) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object s_HistogramBuffer; // 0x0
	public static readonly object s_HistogramDebugTex; // 0x4
	public static readonly object s_PreAutoExposureTex; // 0x8
	public static readonly object s_AutoExposureTex; // 0xC
	public static readonly object s_AutoExposureParams1; // 0x10
	public static readonly object s_AutoExposureEnable; // 0x14
	public static readonly object s_ViewportSize; // 0x18
	public static readonly object s_AEHistogramParams1; // 0x1C
	public static readonly object s_AEHistogramParams2; // 0x20
	public static readonly object s_AEHistogramParams3; // 0x24
	public static readonly object s_ExposureCompensation; // 0x28
	public static readonly object s_AETexLodLevel; // 0x2C
	public static readonly object s_ExposureTex; // 0x30
	public static readonly object s_InputTexBeforeAfterSize; // 0x34
	public static readonly object s_MulCof; // 0x38
	public static readonly object s_LogLumMainTex; // 0x3C
	public static object _LogLuminanceDown; // 0x40

	// Methods

	// RVA: 0x783C430
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass21_0
{

	// Fields
	public object <>4__this; // 0x8
	public object frameMod2; // 0x10

	// Methods

	// RVA: 0x783AA5C
	public object .ctor() { }

	// RVA: 0x783C750
	internal object <RenderAutoExposure>b__0(object request) { }

}

// Namespace: Yarp
public sealed class AutoExposure
{

	// Fields
	private static object s_EnableGPUReadBack; // 0x0
	private const object c_AutoExposureTexCount;
	private object m_firstFrame; // 0x8
	private object m_logHistogram; // 0x10
	private object m_lastExposureTex; // 0x18
	private object m_currentExposureTex; // 0x20
	private object m_autoExposurePingPong; // 0x28
	private object m_autoExposurePool; // 0x30
	private object m_csEyeAdaptionShader; // 0x38
	private object m_sceneLuminanceMaterial; // 0x40
	private object m_eyeAdaptionMaterial; // 0x48
	private object m_downSampleRTMip; // 0x50
	private object m_supportComputeShader; // 0x58
	private object m_preExposure; // 0x5C

	// Methods

	// RVA: 0x7839808
	public object .ctor() { }

	// RVA: 0x7839994
	public object Dispose() { }

	// RVA: 0x7839AF4
	public object Render(object cmd, object viewCamera, object setting, object sourceColor, object bloomOptAEInfo, object uberMaterial) { }

	// RVA: 0x783A428
	private object ExponentialAdaption(object oldExposure, object newExposure, object speedDown, object speedUp, object deltaTime) { }

	// RVA: 0x783A468
	private object InitAutoExposureResIfNeed(object exposureSetting, object viewCamera) { }

	// RVA: 0x783A9B4
	public static object CalExposureScaleAndBias(object exposureSettings) { }

	// RVA: 0x783A9E8
	public object GetPreExposureAndPrevInvPreExposure() { }

	// RVA: 0x7839E18
	private object RenderAutoExposure(object cmd, object yarpSetting, object exposureSetting, object viewCamera, object sourceColor, object uberMaterial, object bloomOptAEInfo) { }

	// RVA: 0x783AA64
	private object RenderAutoExposure_CS(object cmd, object viewCamera, object exposureSetting, object scaleAndBiasPara, object speedAndPercentPara, object timePara) { }

	// RVA: 0x783ADB0
	private object RenderAutoExposure_PS(object cmd, object viewCamera, object exposureSetting, object sourceColor, object scaleAndBiasPara, object speedAndPercentPara, object timePara, object bloomOptAEInfo) { }

	// RVA: 0x783B7AC
	private object AutoDownSample(object cmd, object exposureSetting, object sourceColor, object scaleAndBiasPara, object speedAndPercentPara, object timePara, object bloomOptAEInfo, object iterations) { }

	// RVA: 0x783BBA0
	private object ManualDownSample(object cmd, object exposureSetting, object sourceColor, object scaleAndBiasPara, object speedAndPercentPara, object timePara, object bloomOptAEInfo, object rtWidth, object rtHeight) { }

	// RVA: 0x783B6A8
	private object EnableOrDisableKeyWorld(object mat, object keyworld, object bEnable) { }

	// RVA: 0x783B5A4
	private object EnableOrDisableKeyWorld(object csShader, object keyworld, object bEnable) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _Params; // 0x0
	public static readonly object _Threshold; // 0x4
	public static readonly object _BloomTex; // 0x8
	public static readonly object _BloomSrcTex; // 0xC
	public static readonly object _BloomSrcUvScale; // 0x10
	public static readonly object _SampleScale; // 0x14
	public static readonly object _PostExposure; // 0x18
	public static readonly object s_AutoExposureParams1; // 0x1C
	public static readonly object s_DepthAETex; // 0x20
	public static object _BloomMipUp; // 0x28
	public static object _BloomMipDown; // 0x30
	public static object _AEHistogramTexId; // 0x38

	// Methods

	// RVA: 0x783E110
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class Bloom
{

	// Fields
	public const object k_InvalidBloomTexture;
	private const object k_MaxPyramidSize;
	private object m_bloomMaterial; // 0x8
	private object m_bloomPrefilterPass; // 0x10
	private object m_bloomDownsamplePass; // 0x14
	private object m_bloomUpsamplePass; // 0x18
	private object m_iterations; // 0x1C
	private object m_dataPrepared; // 0x20
	private object m_rtBuffersID; // 0x28
	private object m_bloomOptAEInfo; // 0x30

	// Methods

	// RVA: 0x783C800
	public object Dispose() { }

	// RVA: 0x783C870
	public object .ctor() { }

	// RVA: 0x783CBE4
	private object PrepareData(object cmd, object setting, object material, object tw, object th) { }

	// RVA: 0x783CEAC
	public object PrepareData(object cmd, object setting, object material, object tw, object th, object format) { }

	// RVA: 0x783CFD0
	public object GetMipDown() { }

	// RVA: 0x783D064
	public object GetAEHistogramInfo() { }

	// RVA: 0x783D070
	public object Render(object cmd, object setting, object sourceColor, object GammaSpaceAlphaBlend, object postExposure) { }

	// RVA: 0x783D2F4
	private object SetupBloom(object cmd, object setting, object exposureSetting, object source) { }

}

// Namespace: 
public static class ShaderConstants
{

	// Fields
	public static readonly object _LUT_ENABLE_HDR; // 0x0
	public static readonly object _USE_VOLUME_LUT; // 0x8
	public static readonly object _WhiteTemp; // 0xC
	public static readonly object _WhiteTint; // 0x10
	public static readonly object _ColorSaturation; // 0x14
	public static readonly object _ColorContrast; // 0x18
	public static readonly object _ColorGamma; // 0x1C
	public static readonly object _ColorGain; // 0x20
	public static readonly object _ColorOffset; // 0x24
	public static readonly object _ColorSaturationShadows; // 0x28
	public static readonly object _ColorContrastShadows; // 0x2C
	public static readonly object _ColorGammaShadows; // 0x30
	public static readonly object _ColorGainShadows; // 0x34
	public static readonly object _ColorOffsetShadows; // 0x38
	public static readonly object _ColorCorrectionShadowsMax; // 0x3C
	public static readonly object _ColorSaturationMidtones; // 0x40
	public static readonly object _ColorContrastMidtones; // 0x44
	public static readonly object _ColorGammaMidtones; // 0x48
	public static readonly object _ColorGainMidtones; // 0x4C
	public static readonly object _ColorOffsetMidtones; // 0x50
	public static readonly object _ColorSaturationHighlights; // 0x54
	public static readonly object _ColorContrastHighlights; // 0x58
	public static readonly object _ColorGammaHighlights; // 0x5C
	public static readonly object _ColorGainHighlights; // 0x60
	public static readonly object _ColorOffsetHighlights; // 0x64
	public static readonly object _ColorCorrectionHighlightsMin; // 0x68
	public static readonly object _BlueCorrection; // 0x6C
	public static readonly object _ExpandGamut; // 0x70
	public static readonly object _FilmSlope; // 0x74
	public static readonly object _FilmToe; // 0x78
	public static readonly object _FilmShoulder; // 0x7C
	public static readonly object _FilmBlackClip; // 0x80
	public static readonly object _FilmWhiteClip; // 0x84

	// Methods

	// RVA: 0x783F06C
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class ColorGrading
{

	// Fields
	private object m_tonemappingLUT; // 0x8
	private object m_tonemappingLUTMaterial; // 0x10
	private object m_lastColorGradingSettingHash; // 0x18
	private object m_useHDRDisplay; // 0x28

	// Methods

	// RVA: 0x783E2FC
	public object Dispose() { }

	// RVA: 0x783E300
	private object ReleaseLUT() { }

	// RVA: 0x783E458
	private object CreateLUTRenderTarget(object lutSize, object format) { }

	// RVA: 0x783E540
	public object GetColorGradingLUT(object cmd, object setting, object needNewRT, object format) { }

	// RVA: 0x783E7AC
	private object BakeTonemappingLUT(object cmd, object setting) { }

	// RVA: 0x783F064
	public object .ctor() { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _HalfCoCTexture; // 0x0
	public static readonly object _CoCTex; // 0x4
	public static readonly object _DownSourceTexture; // 0x8
	public static readonly object _DOFBlurTex; // 0xC
	public static readonly object _DepthTempTex; // 0x10
	public static readonly object _PreFilterTex; // 0x14
	public static readonly object _Temp; // 0x18
	public static readonly object _Temp1; // 0x1C
	public static readonly object _DOFSource; // 0x20
	public static readonly object _DepthTexture; // 0x24
	public static readonly object _DepthOfFieldFocalDistance; // 0x28
	public static readonly object _DepthOfFieldFocalRegion; // 0x2C
	public static readonly object _DepthOfFieldNearTransitionRegion; // 0x30
	public static readonly object _DepthOfFieldFarTransitionRegion; // 0x34
	public static readonly object _MaxRadius; // 0x38
	public static readonly object _DownSampleScaleFactor; // 0x3C
	public static object _MipDown; // 0x40

	// Methods

	// RVA: 0x7841120
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class DepthOfField
{

	// Fields
	private object m_depthOfFieldMaterial; // 0x8
	private object m_cocTex; // 0x10
	private object m_prepareHalfTex; // 0x18
	private object m_unityGaussianComputeCOCID; // 0x1C
	private object m_unityGaussianPrefilterID; // 0x20
	private object m_BloomAndDofPrefilterID; // 0x24
	private object m_unityGaussianDownID; // 0x28
	private object m_unityGaussianBlurHID; // 0x2C
	private object m_unityGaussianBlurVID; // 0x30
	private object m_unityGaussianDebugID; // 0x34
	private const object k_MaxPyramidSize;
	private object m_rtBuffersID; // 0x38
	private object m_supportRGBAHalf; // 0x40
	private object m_init; // 0x41
	private object m_propertyBlock; // 0x48

	// Properties
	private object supportRGBAHalf { get; }

	// Methods

	// RVA: 0x783F670
	private object get_supportRGBAHalf() { }

	// RVA: 0x783F6C0
	private object PrepareCocTex(object cmd, object sourceDepth) { }

	// RVA: 0x783F90C
	public object PrefilterDofAndBloom(object cmd, object setting, object sourceDepth, object sourceTex, object bloom) { }

	// RVA: 0x783FD78
	public object .ctor() { }

	// RVA: 0x78401A8
	public object Dispose() { }

	// RVA: 0x7840250
	private object DepthOfFieldGaussianUnity(object cmd, object sourceDepth, object sourceTex, object setting) { }

	// RVA: 0x7840DF8
	public object ResizeToZero() { }

	// RVA: 0x7840E2C
	public object Execute(object cmd, object cameraPosition, object setting, object sourceColor, object sourceDepth) { }

	// RVA: 0x7841064
	public object DebugMode(object cmd, object setting, object target, object flip) { }

}

// Namespace: Yarp
public class DoubleTemporaryRT
{

	// Fields
	private object used; // 0x8
	private object targets; // 0x10
	private object identifiers; // 0x18
	private object finalTarget; // 0x20
	private object index; // 0x48
	private object cmd; // 0x50
	private object width; // 0x58
	private object height; // 0x5C
	private object depthBuffer; // 0x60
	private object filter; // 0x64
	private object format; // 0x68

	// Methods

	// RVA: 0x7841440
	public object .ctor() { }

	// RVA: 0x78415E8
	public object Begin(object cmd, object finalTarget, object width, object height, object depthBuffer, object filter, object format) { }

	// RVA: 0x7837944
	public object Get(object finalPass) { }

	// RVA: 0x7841640
	public object End() { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _ColorTex; // 0x0
	public static readonly object _LumaThresholdMin; // 0x4
	public static readonly object _LumaThreshold; // 0x8
	public static readonly object _Scale; // 0xC
	public static readonly object _Sharpness; // 0x10
	public static readonly object _QualitySubpix; // 0x14
	public static readonly object _QualityEdgeThreshold; // 0x18
	public static readonly object _QualityEdgeThresholdMin; // 0x1C

	// Methods

	// RVA: 0x7841EB8
	private static object .cctor() { }

}

// Namespace: Yarp
public class FXAAPass
{

	// Fields
	private object m_material; // 0x8

	// Methods

	// RVA: 0x7841720
	public object Dispose() { }

	// RVA: 0x7841790
	public object .ctor() { }

	// RVA: 0x7841850
	public object Execute(object cmd, object setting, object sourceColor, object target) { }

	// RVA: 0x7841C30
	public object Execute(object cmd, object sourceColor, object target, object Subpix, object EdgeThreshold, object EdgeThresholdMin) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _ENABLE_POSTPROCESS; // 0x0
	public static readonly object _TONEMAP_ACES; // 0x8
	public static readonly object _TONEMAP_UE4_HDR10; // 0x10
	public static readonly object _TONEMAP_UE4; // 0x18
	public static readonly object _TONEMAP_UE3; // 0x20
	public static readonly object _BLOOM; // 0x28
	public static readonly object _DISTORTION; // 0x30
	public static readonly object _VIGNETTE; // 0x38
	public static readonly object _OTHERS; // 0x40
	public static readonly object _BlitTex; // 0x48
	public static readonly object _UE42DLutTex; // 0x4C
	public static readonly object _DEPTHOFFIELD_VAL; // 0x50
	public static readonly object _VIGNETTE_VAL; // 0x54
	public static readonly object _COLOR_GRADING_VAL; // 0x58
	public static readonly object _SPOTLIGHT_VAL; // 0x5C
	public static readonly object _GLITCH_EFFECT_VAL; // 0x60
	public static readonly object _BWFILTER_VAL; // 0x64
	public static readonly object _SURFACEBLUR_VAL; // 0x68
	public static readonly object _INVERSETONEMAPPING_VAL; // 0x6C
	public static readonly object _ENCODEDYCGCO_VAL; // 0x70
	public static readonly object _InputColorSpace; // 0x74
	public static readonly object g_ExposureScale; // 0x78
	public static readonly object g_ColorMatrix; // 0x7C

	// Methods

	// RVA: 0x784642C
	private static object .cctor() { }

}

// Namespace: Yarp
public class ImagePostProcessor
{

	// Fields
	private object m_debug; // 0x8
	private object m_uberMaterial; // 0x10
	private const object k_invalidTexureID;
	private object m_colorGrading; // 0x18
	private object m_bloom; // 0x20
	private object m_bloomTex; // 0x28
	private object m_depthOfField; // 0x30
	private object m_radialBlur; // 0x38
	private object m_motionBlur; // 0x40
	private object m_surfaceBlur; // 0x48
	private object m_afterStack; // 0x50
	private object m_sbTex; // 0x58
	private object m_fxaa; // 0x60
	private object m_tempRTs; // 0x68
	private object m_tempTexture; // 0x70
	private object m_sourceColor; // 0x78
	private object m_sourceDepth; // 0x80
	private object m_targetColor; // 0x88
	private object m_camera; // 0x90
	private object m_colorSpace; // 0x98
	private object m_resetTexture; // 0x9C
	private object m_isSourceTextureDirty; // 0x9D
	private object m_processedStep; // 0xA0
	private object m_setting; // 0xA8
	private object m_cmd; // 0xB0
	private object m_ue4tonemapLut; // 0xB8
	private object m_cameraFbo; // 0xC0
	private object m_width; // 0xC8
	private object m_height; // 0xCC
	private object m_sourceImageScale; // 0xD0
	public object ImageProcessCallback; // 0xD8
	private object m_excuteCallback; // 0xE0

	// Properties
	private object colorGrading { get; }
	private object bloom { get; }
	private object fxaa { get; }
	private object depthOfField { get; }
	private object radialBlur { get; }
	private object motionBlur { get; }
	private object surfaceBlur { get; }
	private object afterStack { get; }
	private object cmd { get; }
	public object ResultImage { get; }
	public object SourceTexture { get; }
	public object SourceDepthTexture { get; }

	// Methods

	// RVA: 0x7842078
	private object get_colorGrading() { }

	// RVA: 0x78420F4
	private object get_bloom() { }

	// RVA: 0x784216C
	private object get_fxaa() { }

	// RVA: 0x78421E4
	private object get_depthOfField() { }

	// RVA: 0x784225C
	private object get_radialBlur() { }

	// RVA: 0x78422D8
	private object get_motionBlur() { }

	// RVA: 0x7842354
	private object get_surfaceBlur() { }

	// RVA: 0x78423D0
	private object get_afterStack() { }

	// RVA: 0x78424A0
	private object get_cmd() { }

	// RVA: 0x7842548
	public object Dispose() { }

	// RVA: 0x7842848
	public object .ctor(object scale) { }

	// RVA: 0x7842A2C
	private object OnFrameBegin(object gfxContext, object command) { }

	// RVA: 0x7843868
	public object EndCameraRendering(object context, object cmd, object camera, object activeTexture) { }

	// RVA: 0x7843EC0
	public object SetSourceTexture(object camera, object color, object depth, object width, object height, object colorSpace) { }

	// RVA: 0x78441F4
	public object ProcessImage(object target, object setting, object lut) { }

	// RVA: 0x78444C0
	public object ProcessImage(object camera, object sourceColor, object sourceDepth, object target, object setting, object lut, object colorSpace) { }

	// RVA: 0x78447B0
	public object SetSourceTexture(object camera, object width, object height) { }

	// RVA: 0x78448B0
	public object SetSourceTexture(object camera, object width, object height) { }

	// RVA: 0x7844960
	public object ProcessImage(object setting, object lut) { }

	// RVA: 0x7844D90
	public static object GetTemporaryRT(object width, object height) { }

	// RVA: 0x78444B8
	private object ResetProcessedStep() { }

	// RVA: 0x7842E50
	public object ImageProcessed() { }

	// RVA: 0x7844DA0
	public object GetSourceColorSpace() { }

	// RVA: 0x7844DA8
	public object get_ResultImage() { }

	// RVA: 0x7844DB0
	public object get_SourceTexture() { }

	// RVA: 0x7844DB8
	public object get_SourceDepthTexture() { }

	// RVA: 0x7843A74
	private object SetSourceTexture(object color, object depth, object command) { }

	// RVA: 0x7842E60
	private object ProcessImage(object step, object command) { }

	// RVA: 0x7845B0C
	private object RenderInternal(object cmd, object setting, object sourceColor, object pixelRect, object target, object viewCamera, object sourceDepth, object pass) { }

	// RVA: 0x784625C
	private object Execute(object cmd, object pixelRect, object target, object pass) { }

	// RVA: 0x7844DC0
	private object Processed(object step, object ID) { }

	// RVA: 0x7844DC8
	private object ClearUberMaterial() { }

	// RVA: 0x7844F4C
	private object SetupBloom(object command, object setting, object bloomTex) { }

	// RVA: 0x7846334
	private object GetVignetteParams(object setting, object source, object v1, object v2) { }

	// RVA: 0x784531C
	private object SetupVignette(object setting, object source) { }

	// RVA: 0x784545C
	private object SetupBWFilter(object setting) { }

	// RVA: 0x78455F0
	private object SetupExposure(object setting, object postExposure) { }

	// RVA: 0x7845180
	private object SetupSurfaceBlur(object cmd, object setting, object sbTex) { }

	// RVA: 0x7845704
	private object SetupColorGrading(object cmd, object setting) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object s_InputTex; // 0x0
	public static readonly object s_InputTex_Size; // 0x4
	public static readonly object s_BloomHistogramTex_Size; // 0x8
	public static readonly object s_BloomHistogramTex; // 0xC
	public static readonly object s_HistogramBuffer; // 0x10
	public static readonly object s_AEHistogramParams1; // 0x14

	// Methods

	// RVA: 0x7847478
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class LuminHistogram
{

	// Fields
	public const object c_HistogramSize;
	public const object c_MinLogLuma;
	public const object c_MaxLogLuma;
	private object m_histogramData; // 0x8
	private object m_histogramDataDebugTex; // 0x10
	private object m_csHistogramShader; // 0x18

	// Properties
	public object HistogramData { get; }
	public object HistogramDebugTex { get; }

	// Methods

	// RVA: 0x78467F8
	public object get_HistogramData() { }

	// RVA: 0x7846800
	public object get_HistogramDebugTex() { }

	// RVA: 0x7846808
	public object Dispose() { }

	// RVA: 0x78468B0
	public object GenerateHistogram(object cmd, object viewCamera, object inputTex, object bloomOptAEInfo, object exposureSettings, object scaleAndBiasPara, object bUseCsPass) { }

	// RVA: 0x7846A40
	private object InitResIfNeed() { }

	// RVA: 0x7846BA4
	private object ClearHistogramPass(object histogramCS, object cmd) { }

	// RVA: 0x7846CB0
	private object BuildHistogramPass(object histogramCS, object cmd, object inputTex, object scaleAndBiasPara, object exposureSettings, object bloomOptAEInfo) { }

	// RVA: 0x784712C
	public object DebugHistogramPass(object cmd) { }

	// RVA: 0x78473B8
	private object CreateRenderTexture(object width, object height, object enableReadWrite, object rtFormat) { }

	// RVA: 0x7847470
	public object .ctor() { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _TempRT1; // 0x0
	public static readonly object _TempRT2; // 0x4
	public static readonly object _BlurParam; // 0x8
	public static readonly object _BlurOffset1; // 0xC
	public static readonly object _BlurOffset2; // 0x10

	// Methods

	// RVA: 0x7847E1C
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class MotionBlur
{

	// Fields
	private object blurMaterial; // 0x8
	private object m_materialParams; // 0x10

	// Methods

	// RVA: 0x78475D8
	public object Dispose() { }

	// RVA: 0x7847648
	public object .ctor() { }

	// RVA: 0x78477E0
	public object Execute(object cmd, object pixelRect, object setting, object source, object tempRTs, object finalPass) { }

}

// Namespace: 
public enum DistortionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MultiChannelIntensity;
	public const object SingleChannelIntensity;
}

// Namespace: 
public enum InputColorSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Linear;
	public const object LinearCompressed;
	public const object Gamma;
	public const object ACES_LQ;
}

// Namespace: 
public enum OutputColorFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RGB;
	public const object YCgCo;
}

// Namespace: 
public static class ShaderConstants
{

	// Fields
	public static readonly object _ENABLE_POSTPROCESS; // 0x0
	public static readonly object _TONEMAP_ACES; // 0x8
	public static readonly object _TONEMAP_UE4_HDR10; // 0x10
	public static readonly object _TONEMAP_UE4; // 0x18
	public static readonly object _TONEMAP_UE3; // 0x20
	public static readonly object _BLOOM; // 0x28
	public static readonly object _DISTORTION; // 0x30
	public static readonly object _VIGNETTE; // 0x38
	public static readonly object _OTHERS; // 0x40
	public static readonly object _BlitTex; // 0x48
	public static readonly object _UE42DLutTex; // 0x4C
	public static readonly object _DEPTHOFFIELD_VAL; // 0x50
	public static readonly object _VIGNETTE_VAL; // 0x54
	public static readonly object _COLOR_GRADING_VAL; // 0x58
	public static readonly object _SPOTLIGHT_VAL; // 0x5C
	public static readonly object _GLITCH_EFFECT_VAL; // 0x60
	public static readonly object _BWFILTER_VAL; // 0x64
	public static readonly object _SURFACEBLUR_VAL; // 0x68
	public static readonly object _INVERSETONEMAPPING_VAL; // 0x6C
	public static readonly object _ENCODEDYCGCO_VAL; // 0x70
	public static readonly object _InputColorSpace; // 0x74

	// Methods

	// RVA: 0x784C574
	private static object .cctor() { }

}

// Namespace: Yarp
public class PostProcessPass
{

	// Fields
	private object m_uberMaterial; // 0x8
	private const object k_invalidTexureID;
	private object m_colorGrading; // 0x10
	private object m_autoExposure; // 0x18
	private object m_bloom; // 0x20
	private object m_bloomTex; // 0x28
	private object m_depthOfField; // 0x30
	private object m_distortionMaskPass; // 0x38
	private object m_glitchEffectMaskPass; // 0x40
	private object m_radialBlur; // 0x48
	private object m_motionBlur; // 0x50
	private object m_surfaceBlur; // 0x58
	private object m_afterStack; // 0x60
	private object m_sbTex; // 0x68
	private object m_tempRTs; // 0x70
	private object m_block; // 0x78
	private object m_distortionMode; // 0x80
	private object m_inputColorSpace; // 0x84
	private object m_outputColorFormat; // 0x88
	private object m_postExposure; // 0x8C

	// Properties
	private object depthOfField { get; }
	private object distortionMaskPass { get; }
	private object glitchEffectMaskPass { get; }
	private object radialBlur { get; }
	private object motionBlur { get; }
	private object surfaceBlur { get; }
	private object afterStack { get; }

	// Methods

	// RVA: 0x7847F50
	private object get_depthOfField() { }

	// RVA: 0x7847FCC
	private object get_distortionMaskPass() { }

	// RVA: 0x784804C
	private object get_glitchEffectMaskPass() { }

	// RVA: 0x78480E0
	private object get_radialBlur() { }

	// RVA: 0x78482F0
	private object get_motionBlur() { }

	// RVA: 0x7848368
	private object get_surfaceBlur() { }

	// RVA: 0x784855C
	private object get_afterStack() { }

	// RVA: 0x78485D8
	public object .ctor(object inputColorSpace, object outputColorSpace, object distortionMode, object postExposure) { }

	// RVA: 0x7848790
	public object Dispose() { }

	// RVA: 0x7848AA4
	public object UpdateInputColorSpace(object inputColorSpace) { }

	// RVA: 0x7848AAC
	public object UpdateOutputColorSpace(object outputColorSpace) { }

	// RVA: 0x7848AB4
	public object ExecuteLocal(object cmd, object viewCamera, object setting, object worldData, object sourceColor, object sourceDepth, object target) { }

	// RVA: 0x7848D2C
	public object Execute(object context, object cmd, object viewCamera, object renderSetting, object sourceColor, object sourceDepth, object pixelRect, object target) { }

	// RVA: 0x784A1A0
	public object PrePostProcess(object cmd, object sourceColor, object target) { }

	// RVA: 0x784A398
	public object PostPostProcess(object cmd, object setting, object sourceColor, object pixelRect, object target) { }

	// RVA: 0x784A628
	public static object SetPostProcessStatus(object cmd, object colorGradingSetting) { }

	// RVA: 0x784A798
	public object GetPreExposureAndPrevInvPreExposure() { }

	// RVA: 0x7848FFC
	public object PrepareData(object context, object cmd, object viewCamera, object setting, object sourceColor, object sourceDepth) { }

	// RVA: 0x784BCE0
	private object ClearPostProcessStatus(object cmd) { }

	// RVA: 0x784A7B4
	private object ClearUberMaterial() { }

	// RVA: 0x784BDD0
	public object OnImGui() { }

	// RVA: 0x7849AF4
	private object RenderInternal(object cmd, object setting, object sourceColor, object pixelRect, object target, object pass) { }

	// RVA: 0x784BDD4
	private object Execute(object cmd, object pixelRect, object target, object pass, object finalPass) { }

	// RVA: 0x784ABA4
	private object SetupBloom(object cmd, object setting, object bloomTex) { }

	// RVA: 0x784B374
	private object SetupDistortion(object setting) { }

	// RVA: 0x784C47C
	private object GetVignetteParams(object setting, object source, object v1, object v2) { }

	// RVA: 0x784B50C
	private object SetupVignette(object setting, object source) { }

	// RVA: 0x7848BAC
	private object SetupLocalVignette(object cmd, object setting, object source) { }

	// RVA: 0x784B678
	private object SetupBWFilter(object setting) { }

	// RVA: 0x784B818
	private object SetupExposure(object setting, object postExposure) { }

	// RVA: 0x784B1D8
	private object SetupSurfaceBlur(object cmd, object setting, object source, object viewCamera, object sbTex) { }

	// RVA: 0x784A964
	private object SetupGlitchEffect(object setting, object sourceDepth) { }

	// RVA: 0x784B92C
	private object SetupColorGrading(object cmd, object setting) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _TempRT1; // 0x0
	public static readonly object _TempRT2; // 0x4
	public static readonly object _BlurParam; // 0x8
	public static readonly object _BlurOffset1; // 0xC
	public static readonly object _BlurOffset2; // 0x10

	// Methods

	// RVA: 0x784C95C
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class RadialBlur
{

	// Fields
	private object blurMaterial; // 0x8
	private object m_materialParams; // 0x10
	private static object tempRTs; // 0x0

	// Methods

	// RVA: 0x78489C4
	public object Dispose() { }

	// RVA: 0x7848158
	public object .ctor() { }

	// RVA: 0x784BEF4
	public object Execute(object cmd, object pixelRect, object setting, object source, object tempRTs, object finalPass) { }

	// RVA: 0x784C8E8
	private static object .cctor() { }

}

// Namespace: 
private struct <>c__DisplayClass37_0
{

	// Fields
	public object setting; // 0xFFFFFFFFFFFFFFF8
	public object <>4__this; // 0x0
	public object cmd; // 0x8
}

// Namespace: Yarp
public class TemporalAAUpscale
{

	// Fields
	private object m_historyFbo; // 0x18
	private object m_outputFbo; // 0x20
	private object m_lumaHistoryFbo; // 0x28
	private object m_lumaOutputFbo; // 0x30
	private object m_preDepth; // 0x38
	private object m_depthOutput; // 0x40
	private object m_alphaMask; // 0x48
	private object m_intermediateColor; // 0x50
	private object m_intermediateMotion; // 0x58
	private object m_intermediateOutput; // 0x60
	private object m_prepareKernel; // 0x68
	private object m_mainKernel; // 0x6C
	private object m_LanczosSqrLut; // 0x70
	private object m_propertyBlock; // 0x78
	private object m_material; // 0x80
	private static object s_material; // 0x0
	private object m_temporalAA_CS; // 0x88
	private object m_preparePass; // 0x90
	private object m_upscalePass; // 0x94
	private object m_resolvePass; // 0x98
	private object m_debugPass; // 0x9C
	private object m_frameCount; // 0xA0
	private object m_jitterOffset; // 0xA4
	private object m_sampleOffset; // 0xB0
	private object m_reset; // 0xB8

	// Properties
	private object material { get; }
	public static object TaauMaterial { get; }
	private object temporalAA_CS { get; }

	// Methods

	// RVA: 0x784CA90
	public object .ctor() { }

	// RVA: 0x784CFE8
	private object get_material() { }

	// RVA: 0x784D238
	public static object get_TaauMaterial() { }

	// RVA: 0x784D388
	private object get_temporalAA_CS() { }

	// RVA: 0x784D464
	public static object getJitterSample01(object frameCount, object sequence) { }

	// RVA: 0x784D584
	public object SetupCamera(object viewCamera, object setting) { }

	// RVA: 0x784D604
	public object RestoreCamera(object viewCamera) { }

	// RVA: 0x784D638
	public object DownSample(object cmd, object src, object target, object targetMaxSize) { }

	// RVA: 0x784DAE0
	public object Reset() { }

	// RVA: 0x784DAEC
	public object Execute(object cmd, object camera, object setting, object colorTexture, object depthTexture, object motionTexture, object needPrepareInput, object accumSpeed) { }

	// RVA: 0x78510D8
	private object ToggleHistoryFilterKeyword(object cmd, object setting) { }

	// RVA: 0x7851494
	private object ToggleSharpenMethodKeyword(object cmd, object setting) { }

	// RVA: 0x785191C
	private object ToggleShaderKeyword(object cmd, object setting, object keyword, object toggle) { }

	// RVA: 0x7851AAC
	private object UVToNDC() { }

	// RVA: 0x7851B8C
	private object NDCToUV() { }

	// RVA: 0x7851634
	private object GetUVZToPrevUVZMatrix(object camera) { }

	// RVA: 0x7851C78
	public object ResolveTAAUOutput(object cmd, object viewport, object target, object setting) { }

	// RVA: 0x7851EBC
	public object GetOuput() { }

	// RVA: 0x7851EE4
	public object Debug(object cmd, object camera, object worldData, object colorTexture, object accumSpeed) { }

	// RVA: 0x7851EE8
	public object MotionPassDebug(object context, object commands, object cameraData, object depthTexture) { }

	// RVA: 0x7851EEC
	public object BeginCamera(object cmd, object viewCamera, object worldData) { }

	// RVA: 0x785210C
	public object EndCamera(object viewCamera, object worldData, object cmd) { }

	// RVA: 0x78521F8
	protected override object Dispose(object disposing) { }

	// RVA: 0x7852290
	public override object GetRenderPassName() { }

	// RVA: 0x7850F4C
	private object <Execute>g__ToogleShaderKeyword|37_0(object keyword, object toogle, object ) { }

	// RVA: 0x78511A4
	private object <Execute>g__SetGlobalTexture|37_1(object name, object texture, object kernel, object subElement, object ) { }

	// RVA: 0x78513F8
	private object <Execute>g__SetGlobalInt|37_2(object name, object value, object ) { }

	// RVA: 0x785135C
	private object <Execute>g__SetGlobalFloat|37_3(object name, object value, object ) { }

	// RVA: 0x785129C
	private object <Execute>g__SetGlobalVector|37_4(object name, object value, object ) { }

	// RVA: 0x7851560
	private object <Execute>g__SetGlobalMatrix|37_5(object name, object value, object ) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object _SBTexRT; // 0x0
	public static readonly object _MainTex_TexelSize; // 0x4
	public static readonly object _SBRadius; // 0x8
	public static readonly object _SBTexelSize; // 0xC
	public static readonly object _SBRcpThreshold; // 0x10

	// Methods

	// RVA: 0x7852298
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class SurfaceBlur
{

	// Fields
	private object blurMaterial; // 0x8
	private object bufferRT; // 0x10

	// Methods

	// RVA: 0x7848A34
	public object Dispose() { }

	// RVA: 0x78483E0
	public object .ctor() { }

	// RVA: 0x784ADD8
	public object Render(object cmd, object setting, object sourceColor) { }

}

// Namespace: 
public enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RefreshRadianceMap;
	public const object Prefilter;
	public const object UploadToAtlas;
	public const object Done;
}

// Namespace: 
public class RadianceProbeTask
{

	// Fields
	public readonly object probeSize; // 0x8
	public readonly object nearClipPlane; // 0xC
	public readonly object farClipPlane; // 0x10
	public readonly object cullingMask; // 0x14
	public readonly object position; // 0x18
	public readonly object radius; // 0x24
	public readonly object cameraClearFlags; // 0x28
	public object state; // 0x2C
	public object finishedIteration; // 0x30
	public readonly object radianceProbeInstanceID; // 0x34
	public object radianceMap; // 0x38
	public object prefilteredRadianceMap; // 0x40
	public object prefilteredRadianceMapHistory; // 0x48
	public object coverageMap; // 0x50
	public object coverageHistoryMap; // 0x58
	public const object borderSize;
	public const object mipCount;

	// Properties
	public object totalIteration { get; }

	// Methods

	// RVA: 0x7856BB8
	public object .ctor(object probe) { }

	// RVA: 0x7856C58
	public object Suspend() { }

	// RVA: 0x7854F0C
	public object Release() { }

	// RVA: 0x7854708
	public object get_totalIteration() { }

	// RVA: 0x7854710
	public object samplePerFrame(object size) { }

	// RVA: 0x7854730
	public object totalSample(object size) { }

}

// Namespace: 
private static class ShaderProps
{

	// Fields
	public static readonly object _PrefilteredRadianceMap; // 0x0
	public static readonly object _MipIndex; // 0x4
	public static readonly object _ProbeSize; // 0x8
	public static readonly object _BorderSize; // 0xC
	public static readonly object _ProbeFarPlane; // 0x10
	public static readonly object _SampleOffset; // 0x14
	public static readonly object _SamplePerFrame; // 0x18
	public static readonly object _TotalSample; // 0x1C
	public static readonly object _MipLevel; // 0x20
	public static readonly object _MicrofacetAlpha; // 0x24
	public static readonly object _RadianceMap; // 0x28
	public static readonly object _PrefilteredOctahedralMapHistory; // 0x2C
	public static readonly object _CoverageHistoryMap; // 0x30
	public static readonly object _CubeMap; // 0x34
	public static readonly object _MainTexScaleOffset; // 0x38
	public static readonly object _SampleCount; // 0x3C
	public static readonly object _TotalSampleCount; // 0x40
	public static readonly object _MainTex; // 0x44
	public static readonly object _ReadyForSampling; // 0x48
	public static readonly object _BorderRatio; // 0x4C

	// Methods

	// RVA: 0x78570A8
	private static object .cctor() { }

}

// Namespace: Yarp
public class RadianceCacheSystem
{

	// Fields
	public static readonly object DISABLE_RUNTIME_GENERATION; // 0x0
	private const object m_probeTileSize;
	private const object m_probeAtlasSize;
	private object m_useRuntimeCompression; // 0x8
	private object m_rectAllocator; // 0x10
	private object m_radianceProbeInstanceIDToRectHandle; // 0x18
	private object m_radianceProbeAtlas; // 0x20
	private object m_probeCamera; // 0x28
	private object m_cubeMapCache; // 0x30
	private object m_encodedProbeCache; // 0x38
	private object m_compressedProbeCache; // 0x40
	private object m_radianceProbeFromCubeMapMaterial; // 0x48
	private object m_prefilterMaterial; // 0x50
	private object m_encodeMaterial; // 0x58
	private object m_compressMaterial; // 0x60
	private object m_radianceProbeVisualizationMaterial; // 0x68
	private object m_propBlock; // 0x70
	private object m_probeDiffuseIBLBuffer; // 0x78
	private object m_skyIBLProcess; // 0x80
	private object m_LocalKeyword_RGBM_ENCODING; // 0x88
	private object m_tasks; // 0xA0
	private object m_probesInsideTaskQueue; // 0xA8

	// Properties
	private object UseRuntimeCompression { get; }

	// Methods

	// RVA: 0x78523CC
	private object get_UseRuntimeCompression() { }

	// RVA: 0x78523D4
	public object GetProbeDiffuseIBLBuffer() { }

	// RVA: 0x7852488
	private object RenderRadianceMap(object task) { }

	// RVA: 0x785312C
	private object PrefilterRadianceMap(object task) { }

	// RVA: 0x7854750
	private object UploadToAtlas(object task) { }

	// RVA: 0x7854D7C
	private object TickTask(object task) { }

	// RVA: 0x7852BB0
	private object RenderCubeMap(object cubeMapSize, object position, object nearClipPlane, object farClipPlane, object cullingMask, object cameraClearFlags) { }

	// RVA: 0x7854FA0
	private object EncodeProbeTexture(object commandBuffer, object floatProbeTexture, object mipmapLevel) { }

	// RVA: 0x78553B8
	private object CompressProbeTexture(object commandBuffer, object encodedProbeTexture) { }

	// RVA: 0x785583C
	public override object OnEnable() { }

	// RVA: 0x78559AC
	public override object OnDisable() { }

	// RVA: 0x78547F8
	public object UploadToAtlas(object instanceID, object prefilteredRadianceMap) { }

	// RVA: 0x7856078
	public object RemoveRadianceProbeFromAtlas(object instanceID) { }

	// RVA: 0x7856150
	public object ReadyForSampling(object instanceID) { }

	// RVA: 0x7856264
	public object GetRadianceProbeAtlas() { }

	// RVA: 0x78564FC
	public object GetProbeScaleOffset(object probe, object mip) { }

	// RVA: 0x78566C4
	private object ValidateAtlasAllocationSize(object probe) { }

	// RVA: 0x78567BC
	public object AddTask(object probe) { }

	// RVA: 0x7856A3C
	public object SuspendTask(object probe) { }

	// RVA: 0x7856C5C
	public object QueuedTaskNum() { }

	// RVA: 0x7856CB0
	public object ProbeIsInsideTaskQueue(object probeID) { }

	// RVA: 0x7856D1C
	internal override object OnImGui() { }

	// RVA: 0x7856DC8
	public override object Update(object collection) { }

	// RVA: 0x7856EC8
	public override object GetTrackingFlags() { }

	// RVA: 0x7856ED0
	public object .ctor() { }

	// RVA: 0x7857058
	private static object .cctor() { }

}

// Namespace: Yarp
public abstract class RenderPass
{

	// Fields
	protected internal object renderPassList; // 0x10

	// Methods

	// RVA: -1
	public abstract object GetRenderPassName() { }

	// RVA: 0x7857478
	protected object GetRenderPass(object renderPassName) { }

	// RVA: 0x784CFE0
	protected object .ctor() { }

}

// Namespace: Yarp
public class RenderPassList
{

	// Fields
	private readonly object m_renderPasses; // 0x8

	// Methods

	// RVA: 0x7857498
	public object GetRenderPass(object renderPassName) { }

	// RVA: 0x785776C
	public object InitRenderPass(object renderPassName) { }

	// RVA: 0x7857850
	public object Dispose() { }

	// RVA: 0x7857568
	private object CreateRenderPass(object renderPassName) { }

	// RVA: 0x7857A80
	public object .ctor() { }

}

// Namespace: Yarp
public enum RenderPassName
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Skydome;
	public const object AmbientOcclusionPass;
	public const object ScreenSpaceSSSPass;
	public const object TemporalAAUpscale;
	public const object SceneBuffer;
	public const object Unknown;
}

// Namespace: 
private static class ShaderProps
{

	// Fields
	public static readonly object _depthMip0; // 0x0
	public static readonly object _depthMip1; // 0x4
	public static readonly object _depth_texture; // 0x8
	public static readonly object _depth_scale_bias; // 0xC
	public static readonly object _SceneBuffer_DepthMipChain; // 0x10
	public static readonly object _SceneBuffer_GeometryNormalMipChain; // 0x14
	public static readonly object _SceneNormalBuffer_Src; // 0x18
	public static readonly object gProjectionMatrix; // 0x1C
	public static readonly object gWorldToCameraMatrix; // 0x20
	public static readonly object gPixelSizeAndScreenSize; // 0x24

	// Methods

	// RVA: 0x7858E24
	private static object .cctor() { }

}

// Namespace: Yarp
public class SceneBuffer
{

	// Fields
	private object depthMipChain; // 0x18
	private object normalMipChain; // 0x20
	private object m_geometryNormalMipChainMaterial; // 0x28
	private object m_propBlock; // 0x30
	private object _TEXTURE_FETCH_BLIT; // 0x38
	private object m_depthDownSampleMaterial; // 0x50

	// Properties
	private object depthDownSampleMaterial { get; }

	// Methods

	// RVA: 0x7857B00
	private object get_depthDownSampleMaterial() { }

	// RVA: 0x7857C70
	public override object GetRenderPassName() { }

	// RVA: 0x7857C78
	protected override object Dispose(object disposing) { }

	// RVA: 0x7857D2C
	public object Build(object commands, object mainFbo, object motionFbo, object camera) { }

	// RVA: 0x7857A14
	public object .ctor() { }

}

// Namespace: 
public enum EBoundingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Sphere;
	public const object Box;
	public const object Custom_Sphere;
	public const object Custom_Box;
}

// Namespace: Yarp
public class YACloseupShadow
{

	// Fields
	public object ShadowCasters; // 0x18
	public object ShadowReceivers; // 0x20
	public object BoundingType; // 0x28
	public object ShadowMapSize; // 0x2C
	public object UserDefinedSphereBounds; // 0x30
	public object UserDefinedBoxBounds; // 0x38
	private object <ShadowSizeTips>k__BackingField; // 0x40

	// Properties
	public object ShadowSizeTips { get; set; }

	// Methods

	// RVA: 0x785903C
	public object get_ShadowSizeTips() { }

	// RVA: 0x7859044
	public object set_ShadowSizeTips(object value) { }

	// RVA: 0x785904C
	private object OnEnable() { }

	// RVA: 0x7859214
	private object OnDisable() { }

	// RVA: 0x78594E4
	private object OnValidate() { }

	// RVA: 0x7859578
	public object .ctor() { }

}

// Namespace: 
private class CloseupShadowSliceData
{

	// Fields
	public object m_customShadowSize; // 0x8
	public object m_shadowPercent; // 0xC
	public object m_sliceTexRect; // 0x10
	public object m_boundSphere; // 0x20
	public object m_boundsWorldSpace; // 0x30
	public object m_closeupComp; // 0x48
	public object m_nearPlaneCenterWS; // 0x50
	public object m_boundsLightSpace; // 0x5C
	public object m_shadowViewMatrix; // 0x74
	public object m_shadowProjMatrix; // 0xB4

	// Methods

	// RVA: 0x785C354
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__40_0; // 0x8

	// Methods

	// RVA: 0x785D39C
	private static object .cctor() { }

	// RVA: 0x785D3FC
	public object .ctor() { }

	// RVA: 0x785D404
	internal object <AdaptivePercentSplitShadow>b__40_0(object o) { }

}

// Namespace: 
private sealed class <>c__DisplayClass28_0
{

	// Fields
	public object comp; // 0x8

	// Methods

	// RVA: 0x7859A9C
	public object .ctor() { }

	// RVA: 0x785D424
	internal object <RemoveShadowCasters>b__0(object s) { }

}

// Namespace: Yarp
public class YACloseupShadowMgr
{

	// Fields
	private object m_dictCloseupShadowComps; // 0x8
	private object m_lstSliceData; // 0x10
	private object m_lstRect; // 0x18
	private object m_lstSize; // 0x20
	private object m_lstMaterialsProxy; // 0x28
	private object m_matBlock; // 0x30
	private const object c_stableStep;
	private object m_shadowMapSize; // 0x38
	private object m_arrayFlag; // 0x40
	private object m_needAllocateData; // 0x48
	private object m_customRepackAtlasFail; // 0x49
	private object m_enableCloseupShadow; // 0x4A
	private object m_shadowTexture; // 0x50
	private object m_shadowSplitMethod; // 0x58

	// Properties
	public object ShadowMapSize { get; }
	public object CloseUpShadowTexture { get; }
	public object CloseupShadowAtlas { get; }

	// Methods

	// RVA: 0x7859618
	public object get_ShadowMapSize() { }

	// RVA: 0x7859620
	public object IsCloseupShadowEnabled() { }

	// RVA: 0x7859628
	public object get_CloseUpShadowTexture() { }

	// RVA: 0x7859824
	public object get_CloseupShadowAtlas() { }

	// RVA: 0x785982C
	public object EnableAdaptiveScreenMethod() { }

	// RVA: 0x7859858
	protected override object Init() { }

	// RVA: 0x7859860
	protected override object UnInit() { }

	// RVA: 0x7859914
	public object Cleanup() { }

	// RVA: 0x78590B4
	public object AddShadowCasters(object closeupShadowComp) { }

	// RVA: 0x7859984
	public object ChangeShadowMapSize(object closeupShadowComp) { }

	// RVA: 0x78592A8
	public object RemoveShadowCasters(object gameobjID) { }

	// RVA: 0x7859ED0
	private object HasValidRenderList(object closeupShadowComp) { }

	// RVA: 0x785A15C
	public object HasRenderinShadowReceivers(object inRender) { }

	// RVA: 0x785A3D4
	public object OnUpdateCloseupShadow(object aCamera, object worldData) { }

	// RVA: 0x785B354
	private object UpdateSingleShadowMap(object lstShadowCasters, object lstShadowReceivers, object mainLight, object sliceData) { }

	// RVA: 0x785BAF0
	public object OnRenderCloseupShadow(object context, object cmd, object aCamera, object worldData) { }

	// RVA: 0x785BFB8
	private object RenderCloseupShadow(object commands, object lstShadowCasters, object mainLight, object sliceData) { }

	// RVA: 0x7859AA4
	public object EnableOrDisableMaterialInfo(object lstShadowReceivers, object enableKeyword, object normalBias, object shadowSliceUVOffset, object enableCloseUpPcssKeyword, object shadowMatrix) { }

	// RVA: 0x785A8FC
	private object PrepareCloseupShadowIfNeed(object mainLight, object worldData) { }

	// RVA: 0x785AE54
	private object BuildingSphereOrBoxBouds(object camera, object lstSliceData) { }

	// RVA: 0x785CD6C
	private object UniformGridSplitShadow(object lstSliceData, object shadowTexSize) { }

	// RVA: 0x785C35C
	private object RepackShadowTextures(object lstSliceData, object shadowTexSize) { }

	// RVA: 0x785C77C
	private object AdaptivePercentSplitShadow(object lstSliceData, object shadowTexSize) { }

	// RVA: 0x785CFAC
	private object SetFlagValue(object ibegin_x, object ibegin_y, object curCount, object iDimenCount, object value) { }

	// RVA: 0x785D050
	private object AdaptiveSearch(object iDimenCount, object curCount, object ibegin_x, object ibegin_y) { }

	// RVA: 0x785D1F0
	public object .ctor() { }

}

// Namespace: Yarp
public class ShadoeRenderPassJuNei
{

	// Fields
	private object m_shadowTexture; // 0x8
	private object m_hasValidBounds; // 0x10
	private object m_shadowCasterBounds; // 0x14
	private object m_shadowSamplingParameters; // 0x30
	private object m_hasInitShadowCasters; // 0x38

	// Methods

	// RVA: 0x785D4B0
	public override object Cleanup() { }

	// RVA: 0x785D558
	public override object OnBeginRenderShadow(object context, object aCamera, object worldData, object shadowSamplingParameters) { }

	// RVA: 0x785D698
	public override object RenderShadowMaps(object context, object cmd, object aCamera, object shadowSamplingParameters, object bForceUpdate) { }

	// RVA: 0x785E4D4
	public object .ctor() { }

}

// Namespace: 
public enum enShadowAtlasType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Once;
	public const object Uniform;
	public const object Power;
	public const object Pack;
}

// Namespace: Yarp
public class ShadowAtlasCache
{

	// Fields
	private const object c_TexCount;
	private object m_shadowSize; // 0x8
	private object m_lstTileCoord; // 0x10
	private object m_staticShadowTexPool; // 0x18
	private object m_staticShadowTexture; // 0x20
	private object m_mixedShadowTexture; // 0x28

	// Properties
	public object StaticShadowTex { get; }
	public object MixShadowTex { get; }

	// Methods

	// RVA: 0x785E4DC
	public object get_StaticShadowTex() { }

	// RVA: 0x785E4E4
	public object get_MixShadowTex() { }

	// RVA: 0x785E4EC
	public object .ctor(object shadowName, object width, object height, object enableDymaic, object enableStaticPingPong) { }

	// RVA: 0x785E88C
	public object UpdateShadowAtlas(object atlasType, object uniformCount, object lstTileCoord) { }

	// RVA: 0x785EDF0
	public object GetShadowSplits() { }

	// RVA: 0x785EDF8
	public object Dispose() { }

	// RVA: 0x785EFCC
	public object IsValid() { }

	// RVA: 0x785F038
	public object GetAtlasTileCoord(object tileIndex) { }

	// RVA: 0x785F108
	public object GetStaticPingPong(object index) { }

	// RVA: 0x785F158
	public object GetWidth() { }

	// RVA: 0x785F238
	public object GetHeight() { }

	// RVA: 0x785F318
	public object GetSize() { }

}

// Namespace: 
internal struct ShadowCullData
{

	// Fields
	public object render; // 0xFFFFFFFFFFFFFFF8
	public object cullType; // 0x0
}

// Namespace: Yarp
public class ShadowCacheCsmData
{

	// Fields
	private object m_lastFrameVisibleStaticObjs; // 0x8
	private object m_currFrameVisibleStaticObjs; // 0x10
	private object m_newStaticVisibleObjs; // 0x18
	private object m_frustumPlanes; // 0x20
	private object m_shadowCullingJob; // 0x28
	private object m_worldBoundsNA; // 0x38
	private object m_cullResultsNA; // 0x48
	private object m_cameraCacheData; // 0x58
	private object m_cacheDirLightRot; // 0x7C
	private object m_cacheDirShadowSetting; // 0x8C
	private object m_cacheShadowCasterCount; // 0xA4
	private object m_cacheSphereRadius; // 0xA8
	private object m_scrollingFirstFrame; // 0xAC
	private object m_shadowMapDirty; // 0xAD

	// Methods

	// RVA: 0x785F34C
	public object .ctor() { }

	// RVA: 0x785F550
	public object SetCsmShadowMapDirty(object bDirty) { }

	// RVA: 0x785F558
	private object ExecuteShadowCullingJob(object viewMatrix, object projMatrix, object staticShadowCasters) { }

	// RVA: 0x785FD38
	public object ExecuteShadowCulling(object aCamera, object viewMatrix, object projMatrix, object staticShadowCasters) { }

	// RVA: 0x7860328
	public object RenderShadowCacheSlice(object context, object cmd, object aCamera, object aLight, object samplingParameters, object cascadeIndex, object clearSubRT, object objectsFilter) { }

	// RVA: 0x7860D1C
	public object GetNewStaticObjects() { }

	// RVA: 0x7860D24
	public object ResetValue() { }

	// RVA: 0x785F4C8
	private object ClearDefaultValue() { }

	// RVA: 0x7860DB0
	private object DisposeNativeData() { }

	// RVA: 0x7860E5C
	public object CalculateCsmShadowDirty(object aCamera, object aLight, object staticShadowCasterCount, object frustumRadius) { }

	// RVA: 0x7861180
	public object MainCameraHasChanged(object aCamera) { }

	// RVA: 0x78614A0
	public object UpdateCameraData(object aCamera) { }

	// RVA: 0x7861658
	public object CalcCascadeShadowMatrixSlice(object context, object aCamera, object aLight, object lightShadowAtlas, object samplingParameters, object cascadeIndex) { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object s_ScrollingCsmTexParams; // 0x0
	public static readonly object s_ShadowUVScale; // 0x4

	// Methods

	// RVA: 0x7864BF8
	private static object .cctor() { }

}

// Namespace: Yarp
public class ShadowCacheCsmScrolling
{

	// Fields
	private object m_shadowCascadeLayerMask; // 0x8
	private object m_block; // 0x10
	private object m_cacheCsmData; // 0x18
	private object m_lastFrameCsmMatrix; // 0x20
	private object m_lastFrameShadowCamPos; // 0x28
	private object m_scrollingTexCoord; // 0x30
	private static object s_ZeroPointPos; // 0x0
	private object m_shadowCopyMat; // 0x38
	private object m_scrollingMat; // 0x40
	private object m_keywordCSM_2; // 0x48

	// Methods

	// RVA: 0x78621C8
	public object .ctor() { }

	// RVA: 0x7862534
	public object Cleanup() { }

	// RVA: 0x7862608
	public object ResetValue() { }

	// RVA: 0x786266C
	public object UpdateCsmScrolling(object context, object cmd, object aCamera, object dirLight, object lightShadowAtlas, object samplingParameters, object staticShadowCasters, object forceUpdateCascade, object staticShadowIndex) { }

	// RVA: 0x7862904
	private object OnFrameUpdateStaticObjects(object context, object cmd, object aCamera, object dirLight, object lightShadowAtlas, object samplingParameters, object staticShadowCasterCount, object staticShadowIndex, object forceUpdateCascade) { }

	// RVA: 0x7862F84
	private object OnFrameScrollShadowMap(object context, object cmd, object aCamera, object dirLight, object lightShadowAtlas, object samplingParameters, object staticShadowCasters, object frameCascadeMask, object staticShadowIndex) { }

	// RVA: 0x7863370
	private object OnFrameUpdateDynamicObjects(object context, object cmd, object aCamera, object dirLight, object lightShadowAtlas, object samplingParameters, object frameCascadeMask, object staticShadowIndex, object forceUpdateCascade) { }

	// RVA: 0x78638D4
	private object ScrollCsmShadowMap(object cmd, object dirLight, object samplingParameters, object lastShadowTex, object currShadowTex) { }

	// RVA: 0x78648B8
	public object CopyStaticTex2DynamicTex(object cmd, object currStaticShadowTex, object uvScale, object dynamicShadowTex) { }

	// RVA: 0x786377C
	private object ShadowCameraHasChanged(object dirLight, object samplingParameters) { }

	// RVA: 0x7864BA4
	private static object .cctor() { }

}

// Namespace: Yarp
public class ShadowCachePassCell
{

	// Fields
	private const object c_CellMeter_Size;
	private object m_shadowTexture; // 0x8
	private object m_cacheDirLightRot; // 0x10
	private object m_cacheShadowCasterCount; // 0x20
	private object m_cellShadowWorldtoLightMatrix; // 0x24
	private object m_cellShadowUvScaleOffset; // 0x64
	private object m_cellShadowSplitCoord; // 0x74
	private object m_lastRenderShadowPos; // 0x84
	private object m_resetLightDirty; // 0x90
	private object m_currentCellMeshRenders; // 0x98
	private object m_staticMeshRenders; // 0xA0
	private object m_shadowCullingJob; // 0xA8
	private object m_worldBoundsNA; // 0xB8
	private object m_cullResultsNA; // 0xC8
	private object m_shadowSamplingParameters; // 0xD8

	// Properties
	public object ShadowSamplingParameters { get; }

	// Methods

	// RVA: 0x7864C98
	public object get_ShadowSamplingParameters() { }

	// RVA: 0x7864CA0
	public object .ctor() { }

	// RVA: 0x7864E58
	public object Dispose() { }

	// RVA: 0x7864F78
	public object PrepareShadowMap(object context, object aCamera, object dynamicLights) { }

	// RVA: 0x78653BC
	public object RenderShadowMaps(object context, object cmd, object aCamera) { }

	// RVA: 0x7865CE0
	private object ComputeCellShadowDirty(object dirLight, object cameraPos, object meshRenderCount) { }

	// RVA: 0x7865AA8
	private object ResetShadowParameters(object shadowSamplingParameters) { }

	// RVA: 0x7865E00
	private object FilterShadowCasters(object cameraPos, object halfCellSize, object staticShadowCasters) { }

	// RVA: 0x7865A00
	private object UpdateLightDirtyNextFrame(object dirLight) { }

	// RVA: 0x7864ECC
	private object DisposeNativeData() { }

	// RVA: 0x7866338
	private object DrawCellCaster(object context, object cmd, object aCamera, object dirLight, object shadowSamplingParameters, object shadowCoords) { }

}

// Namespace: Yarp
public class ShadowCacheSystem
{

	// Fields
	private object m_staticShadowRenders; // 0x8
	private object m_dynamicShadowRenderers; // 0x10
	private object m_meshRenderBounds; // 0x18
	private object m_filterStaticShadowObjs; // 0x20
	private object m_lstMaterialsProxy; // 0x28
	private object m_staticMeshRenderDatasChanged; // 0x30

	// Methods

	// RVA: 0x7866CD4
	public override object OnEnable() { }

	// RVA: 0x7867330
	public override object OnDisable() { }

	// RVA: 0x7867440
	public override object GetTrackingFlags() { }

	// RVA: 0x7865098
	public object GetStaticShadowCasters(object aCamera) { }

	// RVA: 0x7867448
	public object GetDynamicShadowCasters() { }

	// RVA: 0x785FCC4
	public object GetBounds(object instanceID, object outBounds) { }

	// RVA: 0x7867450
	public object GetStaticRenderDatasChanged() { }

	// RVA: 0x7867458
	public object GetMeshRenderShadowCasters(object staticCaster, object clearData, object aCamera, object outlstRenders) { }

	// RVA: 0x7867880
	public object RequestShadowMapRendering(object aLight) { }

	// RVA: 0x786799C
	public override object Update(object collection) { }

	// RVA: 0x78679CC
	private object UpdateMeshRenderChanged(object collection) { }

	// RVA: 0x7867144
	private object RenderHasShadowCasterPass(object renderObj) { }

	// RVA: 0x78684F8
	private object UpdateSkinnedMeshRenderChanged(object collection) { }

	// RVA: 0x7868B28
	private object RemoveMeshRender(object id) { }

	// RVA: 0x7868CA8
	private object RemoveSkinnedMeshRender(object id) { }

	// RVA: 0x7868C9C
	private object SetStaticShadowRenderDataDirty() { }

	// RVA: 0x7868D5C
	public object .ctor() { }

}

// Namespace: Yarp
public class ShadowPassAutoOpt
{

	// Fields
	private object m_lightShadowAtlas; // 0x8
	private object m_cacheDirLightRot; // 0x10
	private object m_cacheShadowCasterCount; // 0x20
	private object m_resetLightDirty; // 0x24
	private object m_lstMeshRenders; // 0x30
	private object m_shadowSamplingParameters; // 0x38

	// Methods

	// RVA: 0x7868E9C
	public override object Cleanup() { }

	// RVA: 0x7868F48
	public override object OnBeginRenderShadow(object context, object aCamera, object worldData, object shadowSamplingParameters) { }

	// RVA: 0x78690B8
	public override object RenderShadowMaps(object context, object cmd, object aCamera, object shadowSamplingParameters, object bForceUpdate) { }

	// RVA: 0x7869DD0
	private object RenderStaticShadowMap(object context, object cmd, object aCamera, object dirLight, object shadowSamplingParameters, object lstMeshRenders) { }

	// RVA: 0x7869814
	private object UpdateShadowParameters(object dirLight, object shadowSamplingParameters, object shadowMapSize, object shadowAtlasIndex, object lstMeshRenders) { }

	// RVA: 0x78696F8
	private object ResetShadowParameters(object shadowSamplingParameters) { }

	// RVA: 0x7869650
	private object ResetLightDirtyNextFrame(object dirLight) { }

	// RVA: 0x7869F54
	public object .ctor() { }

}

// Namespace: Yarp
public abstract class IShadowRenderPass
{

	// Methods

	// RVA: -1
	public abstract object Cleanup() { }

	// RVA: -1
	public abstract object OnBeginRenderShadow(object context, object aCamera, object worldData, object shadowSamplingParameters) { }

	// RVA: -1
	public abstract object RenderShadowMaps(object context, object cmd, object aCamera, object shadowSamplingParameters, object bForceUpdate) { }

	// RVA: 0x786A01C
	public virtual object OnEndRenderShadow(object cmd, object aCamera) { }

	// RVA: 0x786A014
	protected object .ctor() { }

}

// Namespace: Yarp
public class ShadowPass
{

	// Fields
	public static object s_ShowStaticShadowTex; // 0x0
	public static object s_StaticDebugShadowTex; // 0x8
	public static object s_ShowDynamicShadowTex; // 0x10
	public static object s_DynamicDebugShadowTex; // 0x18
	private object m_shadowSamplingParameters; // 0x8
	private object m_shadowPass; // 0x10
	private object m_lastShadowCacheType; // 0x18

	// Properties
	public object ShadowSamplingParameters { get; }

	// Methods

	// RVA: 0x786A020
	public object get_ShadowSamplingParameters() { }

	// RVA: 0x786A028
	public object Dispose() { }

	// RVA: 0x786A0C0
	private object CreateShadowCacheIfNeed(object shadowCacheType) { }

	// RVA: 0x786A51C
	public object BeginRenderShadow(object gfxRenderContext, object cameraData, object worldData, object shadowRenderType) { }

	// RVA: 0x786A5B4
	public object RenderShadowMaps(object context, object cmd, object aCamera, object bForceUpdate) { }

	// RVA: 0x786A86C
	public object EndRenderShadow(object cmd, object aCamera) { }

	// RVA: 0x786A8D4
	public object .ctor() { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object g_LocalLightShadowMap; // 0x0
	public static readonly object g_LocalShadowSamplingMatrix; // 0x4
	public static readonly object g_LocalShadowUvScaleOffset; // 0x8
	public static readonly object g_LocalShadowNormalBias; // 0xC
	public static readonly object g_LocalShadowEdgeParameters; // 0x10
	public static readonly object g_LocalShadowColor; // 0x14
	public static readonly object g_LocalShadowEdgeBeginColor; // 0x18
	public static readonly object g_LocalShadowEdgeEndColor; // 0x1C

	// Methods

	// RVA: 0x786E5A8
	private static object .cctor() { }

}

// Namespace: 
internal struct LightCacheData
{

	// Fields
	public object rotation; // 0xFFFFFFFFFFFFFFF8
	public object position; // 0x8
	public object range; // 0x14
	public object spotAngle; // 0x18

	// Methods

	// RVA: 0x786E464
	public object .ctor(object rot, object pos, object aRange, object angle) { }

}

// Namespace: 
internal struct CameraCacheData
{

	// Fields
	public object forward; // 0xFFFFFFFFFFFFFFF8
	public object position; // 0x4
	public object fov; // 0x10
	public object near; // 0x14
	public object far; // 0x18

	// Methods

	// RVA: 0x78613D4
	public object .ctor(object forw, object pos, object aFov, object aNear, object aFar) { }

	// RVA: 0x78613F0
	public object Equals(object other) { }

}

// Namespace: 
internal struct ShadowSettingCache
{

	// Fields
	public object nearPlane; // 0xFFFFFFFFFFFFFFF8
	public object farPlane; // 0xFFFFFFFFFFFFFFFC
	public object zRange; // 0x0
	public object cascadeExpoent; // 0x4
	public object depthSlopeBias; // 0x8
	public object depthSlopeClamp; // 0xC

	// Methods

	// RVA: 0x78610A0
	public object .ctor(object aNear, object zFar, object aZRange, object aCascadeExponent, object aSlopeBias, object aSlopeClamp) { }

	// RVA: 0x78610B0
	public object Equals(object other) { }

}

// Namespace: Yarp
public class ShadowPassCascade
{

	// Fields
	private const object c_EpsilonValue;
	private static object k_InvalidShadowSplitUvScaleOffset; // 0x0
	private object m_dirLightShadowAtlas; // 0x8
	private object m_localLightShadowAtlas; // 0x10
	private object m_localLightCacheData; // 0x18
	private object m_cascadeSplit; // 0x20
	private object m_allLocalShadowLights; // 0x28
	private object m_resetLightDirty; // 0x30
	private object m_shadowSamplingParameters; // 0x38
	private object m_mainCameraData; // 0x40
	private object m_shadowCacheCsmScrolling; // 0x68
	private object m_staticMeshRenders; // 0x70
	private object m_lstLocalShadowRTCoord; // 0x78
	private object m_hasDirLightShadow; // 0x80
	private object m_hasLocalLightShadow; // 0x81
	private object m_staticShadowTexPingPong; // 0x84
	private object m_needRepaintShadowMap; // 0x88
	private object m_forceUpdateLocalLightShadow; // 0x89
	public static object s_EnableCustomShadowSetting; // 0x10
	public static object s_ShadowFilterSharpen; // 0x14
	public static object s_ShadowEdgeBegin; // 0x18
	public static object s_ShadowEdgeEnd; // 0x1C
	public static object s_ShadowEdgeBeginFadeWidth; // 0x20
	public static object s_ShadowEdgeEndFadeWidth; // 0x24
	public static object s_ShadowColor; // 0x28
	public static object s_ShadowEdgeBeginColor; // 0x34
	public static object s_ShadowEdgeEndColor; // 0x40

	// Methods

	// RVA: 0x786A950
	public override object Cleanup() { }

	// RVA: 0x786A814
	public object GetStaticShadowTex() { }

	// RVA: 0x786A9B8
	public override object OnBeginRenderShadow(object context, object aCamera, object worldData, object shadowSamplingParameters) { }

	// RVA: 0x786B628
	public override object RenderShadowMaps(object context, object cmd, object aCamera, object shadowSamplingParameters, object bForceUpdate) { }

	// RVA: 0x786CA28
	public override object OnEndRenderShadow(object cmd, object aCamera) { }

	// RVA: 0x786BC18
	private object ResetLightDirtyNextFrame(object worldData) { }

	// RVA: 0x786C4B0
	private object ResetCsmShadowParameters() { }

	// RVA: 0x786B074
	private object CreateShadowCacheAtlas(object shadowMapAtlas, object dirLight, object shadowMapSize, object localLightShadow) { }

	// RVA: 0x786CB90
	private object ChangedBigIfCameraCloseFrameUpdate(object aCamera) { }

	// RVA: 0x786BE10
	private object RenderDirLight_CsmShadowCache(object context, object cmd, object aCamera, object dirLight, object shadowMaptAtlas, object bForceUpdate) { }

	// RVA: 0x786D0B8
	private object SetPcssSettings(object cmd, object settings) { }

	// RVA: 0x786D20C
	private object CalculateLightAndShadowSettingDirty(object aLight) { }

	// RVA: 0x786C670
	private object RenderDynamicLights_ShadowCache(object context, object cmd, object aCamera, object shadowLights, object shadowMaptAtlas) { }

	// RVA: 0x786D8B8
	private object OptOneLocalLightShadow(object context, object cmd, object aCamera, object shadowMaptAtlas, object shadowLights) { }

	// RVA: 0x786D5A0
	private object SetLocalLightShadowSamplingData(object shadowLights) { }

	// RVA: 0x786DCA0
	private object RenderLightShadow_StaticObjects(object context, object cmd, object aCamera, object shadowLights, object shadowMaptAtlas) { }

	// RVA: 0x786DB78
	private object UpdateLightCacheAndCalculateShadowParams(object context, object aLight, object aCamera, object shadowMaptAtlas) { }

	// RVA: 0x786E1D4
	private object RenderLightShadow_DynamicObjects(object context, object cmd, object aCamera, object shadowLights, object shadowMaptAtlas) { }

	// RVA: 0x786B3CC
	private object UpdateLocalLightShadowSplits(object lights) { }

	// RVA: 0x786D37C
	private object LightHasChanged(object aLight, object lightCache) { }

	// RVA: 0x786DFC4
	private object SetLightCacheData(object aLight) { }

	// RVA: 0x786A35C
	public object .ctor() { }

	// RVA: 0x786E480
	private static object .cctor() { }

}

// Namespace: Yarp
public class ShadowCacheCompatibility
{

	// Fields
	private object m_ShadowCacheCompatibility; // 0x8
	private object m_runtimeRequireOnce; // 0x9
	private object m_shadowCacheFirstTimeOpen; // 0x10

	// Methods

	// RVA: 0x786E94C
	public object GetCompat() { }

	// RVA: 0x786E954
	public object RequireShadowCacheCompat() { }

	// RVA: 0x786F02C
	public object .ctor() { }

}

// Namespace: Yarp
public static class ShadowCacheHelper
{

	// Fields
	private static object s_lstMaterialsProxy; // 0x0
	private static object s_boundWorldConers; // 0x8

	// Methods

	// RVA: 0x7865BC4
	public static object CreateShadowTex(object width, object height, object texName) { }

	// RVA: 0x786CC9C
	public static object GetLightShadowObjectFilter(object aLight) { }

	// RVA: 0x786F0A8
	public static object GetShadowCastersBoxBounds(object lstShadowCasters) { }

	// RVA: 0x786F394
	public static object GetShadowCastersSphereBounds(object lstShadowCasters) { }

	// RVA: 0x786F71C
	public static object CalculateLightViewMatrix(object lightRotation, object boundCenter) { }

	// RVA: 0x786F7BC
	public static object CacculateLightProjMatrix(object extents, object zRangeOffset) { }

	// RVA: 0x786F7E8
	public static object GetFrustumBackPlaneCenterPos(object bounds, object mainLight) { }

	// RVA: 0x786F870
	public static object CalcualteBoundsEightConer(object bounds, object eightConers) { }

	// RVA: 0x786F8D8
	public static object CalculateScreenPercent(object bounds, object mainCamera, object eightConers) { }

	// RVA: 0x786FCB0
	public static object CalculateSphereScreenPercent(object sphereBounds, object mainCamera) { }

	// RVA: 0x786FFBC
	private static object ConvertWorldPos2ScreenPos(object vpMatrix, object posWorld, object bExecuteClip) { }

	// RVA: 0x7870090
	public static object MakeMin(object src, object vec) { }

	// RVA: 0x78700BC
	public static object MakeMax(object src, object vec) { }

	// RVA: 0x78700E8
	public static object CalculateLightViewAndProjMatrix(object mainLight, object boundSpere, object outViewMatrix, object outProjMatrix) { }

	// RVA: 0x7870468
	public static object GetShadowViewBounds(object worldBounds, object shadowViewMatrix) { }

	// RVA: 0x7870CE4
	public static object GetShadowCastersBounds(object lstMeshRenders) { }

	// RVA: 0x7861FFC
	public static object GetNumOfShadowSplits(object aLight) { }

	// RVA: 0x786214C
	public static object ComputeShadowSplitUvScaleOffset(object splitCoord, object width, object height) { }

	// RVA: 0x7871020
	public static object ComputeSpotShadowViewProjectionMatrix(object viewCamera, object aLight, object viewMatrix, object projectionMatrix) { }

	// RVA: 0x78712CC
	public static object ComputeSpotPlusShadowViewProjectionMatrix(object aLight, object viewMatrix, object projectionMatrix) { }

	// RVA: 0x78604FC
	public static object DrawShadowRendererList(object renderContext, object commands, object viewCamera, object aLight, object shadowSplitViewMatrix, object shadowSplitProjectionMatrix, object shadowSplitCoord, object clearSubRT, object objectsFilter) { }

	// RVA: 0x7866948
	public static object CalculateShadowVPMatrixCustomRenders(object dirLight, object lstMeshRenders, object shadowMapSize, object shadowViewMatrix, object shadowProjMatrix) { }

	// RVA: 0x786CDE8
	public static object RenderShadowCacheFunc(object context, object cmd, object aCamera, object aLight, object samplingParameters, object clearSubRT, object objectsFilter) { }

	// RVA: 0x7863E94
	public static object DrawShadowMapCustomRenders(object renderContext, object cmd, object aCamera, object dirLight, object lstMeshRenders, object shadowViewMatrix, object shadowProjMatrix, object sliceRect) { }

	// RVA: 0x7871574
	private static object .cctor() { }

}

// Namespace: Yarp
public class ShadowCasterCollecter
{

	// Fields
	private object m_lstMaterialsProxy; // 0x8
	private object m_allRenderShadowCasters; // 0x10
	private object m_cameraFilterShadowCasters; // 0x18
	private object m_frustumPlanes; // 0x20
	private object m_shadowCullingJob; // 0x28
	private object m_worldBoundsNA; // 0x38
	private object m_frustumPlanesNative; // 0x48
	private object m_cullResultsNA; // 0x58

	// Methods

	// RVA: 0x7871638
	public object ClearData() { }

	// RVA: 0x7871834
	public object AddShadowCaster(object renderObj) { }

	// RVA: 0x7871BAC
	public object RemoveShadowCaster(object renderObj) { }

	// RVA: 0x7871CEC
	public object GetShadowCastersRender() { }

	// RVA: 0x7871CF4
	public object GetDirectionalShadowCasterBounds(object unityCamera, object outBounds) { }

	// RVA: 0x7872838
	public object OnInitAllShadowCasterBounds() { }

	// RVA: 0x78720E0
	private object CullDirectionalShadowCasters(object unityCamera, object outBounds) { }

	// RVA: 0x78719C0
	private object RenderHasShadowCasterPass(object renderObj) { }

	// RVA: 0x7872974
	public object .ctor() { }

}

// Namespace: 
internal struct DebugCsmInfo
{

	// Fields
	public object debugSphereCenter; // 0xFFFFFFFFFFFFFFF8
	public object debugSphereRadius; // 0x4
	public object shadowCameraPos; // 0x8
	public object numberCascades; // 0x14
	public object eightCorners; // 0x18
	public object planes; // 0x20
}

// Namespace: Yarp
public class ShadowCsmDebug
{

	// Fields
	public object DrawCloseupShadow; // 0x18
	public object CloseupShadow; // 0x20
	public object DebugSceneCamera; // 0x28
	public object DebugStaticCastersBound; // 0x29
	public object DebugCSMFrustum; // 0x2A
	public object DebugDynamicOptFrustum; // 0x2B
	public object EnableCustomShadowDir; // 0x2C
	public object DirLight; // 0x30
	public object DebugCascadeIndex; // 0x38
	public object ShadowCasters; // 0x40
	private object gizColors; // 0x48
	private object m_debugCsmInfo; // 0x50
	private object m_meshRenderers; // 0x58

	// Methods

	// RVA: 0x7872A94
	private object OnEnable() { }

	// RVA: 0x7872D38
	private object OnDisable() { }

	// RVA: 0x7872DE8
	private object OnEndCameraRendering(object context, object cmd, object aCamera, object targetTexture) { }

	// RVA: 0x787418C
	private object TransformPointUnscaled(object transform, object position) { }

	// RVA: 0x78742B0
	private object InverseTransformPointUnscaled(object transform, object position) { }

	// RVA: 0x78743F4
	private object DrawCameraFrsutum(object camera) { }

	// RVA: 0x787489C
	private object DrawAABB(object points, object color) { }

	// RVA: 0x7874B90
	private object OnDrawGizmosSelected() { }

	// RVA: 0x787526C
	private object DebugCloseupShadow() { }

	// RVA: 0x7874F38
	private object DrawCsmDebugInfo() { }

	// RVA: 0x7875DD4
	private object TestFrustumAABB(object planes, object bounds) { }

	// RVA: 0x7876580
	public object .ctor() { }

}

// Namespace: Yarp
public struct ShadowCellJob
{

	// Fields
	public object worldBoundsNA; // 0xFFFFFFFFFFFFFFF8
	public object cellMin; // 0x8
	public object cellMax; // 0x10
	public object cullResultsNA; // 0x18

	// Methods

	// RVA: 0x7876C40
	public object Execute(object i) { }

}

// Namespace: Yarp
public struct ShadowCasterCullingJob
{

	// Fields
	public object worldBoundsNA; // 0xFFFFFFFFFFFFFFF8
	public object frustumPlanes; // 0x8
	public object cullResultsNA; // 0x18

	// Methods

	// RVA: 0x7876DCC
	public object Execute(object i) { }

}

// Namespace: Yarp
public struct ShadowCullingJob
{

	// Fields
	public object worldBoundsNA; // 0xFFFFFFFFFFFFFFF8
	public object plane0; // 0x8
	public object plane1; // 0x18
	public object plane2; // 0x28
	public object plane3; // 0x38
	public object plane4; // 0x48
	public object plane5; // 0x58
	public object cullResultsNA; // 0x68

	// Methods

	// RVA: 0x78771D0
	public object Execute(object i) { }

}

// Namespace: Yarp
public static class ShadowCullingUtilities
{

	// Fields
	public static readonly object CULLED; // 0x0
	public static readonly object PARTIALLY_VISIBLE; // 0x1
	public static readonly object VISIBLE; // 0x2

	// Methods

	// RVA: 0x7876D44
	public static object BoundsIntersecting(object cellMin, object cellMax, object renderBounds) { }

	// RVA: 0x7877284
	public static object TestFrustumAABB(object planes, object bounds) { }

	// RVA: 0x7875F50
	public static object TestFrustumAABB(object plane0, object plane1, object plane2, object plane3, object plane4, object plane5, object bounds) { }

	// RVA: 0x7877728
	private static object IsBehindPlaneAABB(object plane, object p0, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0x7877150
	public static object IsBehindPlaneAABB(object plane, object center, object extent) { }

	// RVA: 0x78778B0
	private static object IsPointInsideFrustum(object plane0, object plane1, object plane2, object plane3, object plane4, object plane5, object pos) { }

	// RVA: 0x7877578
	private static object IsBehindPlaneAABB(object planes, object eightCorners) { }

	// RVA: 0x7877644
	private static object IsPointInsideFrustum(object planes, object eightCorners) { }

	// RVA: 0x78779B4
	private static object .cctor() { }

}

// Namespace: Yarp
public class ShadowMapSamplingParameters
{

	// Fields
	public object ShadowTexture; // 0x8
	public object NumOfCascades; // 0x10
	public object CSMDistanceFade; // 0x14
	public object SGameShadowMatrix; // 0x1C
	public object SplitCount; // 0x60
	public object SplitOffset; // 0x68
	public object CSMAtlasCoords; // 0x70
	public object CSMShadowViewMatrix; // 0x78
	public object CSMShadowProjMatrix; // 0x80
	public object CSMShadowCameraPos; // 0x88
	public object CSMUvScaleOffset; // 0x90
	public object CSMShadowSamplingMatrix; // 0x98
	public object CSMNormalBias; // 0xA0
	public object ShadowAtlasCoords; // 0xB0
	public object ShadowSplitsViewMatrix; // 0xB8
	public object ShadowSplitsProjectionMatrix; // 0xC0
	public object ShadowSplitsShadowSamplingMatrix; // 0xC8
	public object ShadowSplitsUvScaleOffset; // 0xD0
	public object ShadowSplitsNormalBias; // 0xD8
	public object ShadowSplitsColor; // 0xE0
	public object ShadowSplitsEdgeBeginColor; // 0xE8
	public object ShadowSplitsEdgeEndColor; // 0xF0
	public object ShadowSplitsEdgeParameters; // 0xF8

	// Methods

	// RVA: 0x7877A0C
	private object InitializeArrays(object shadowSplitsCapacity, object shadowAtlasCount) { }

	// RVA: 0x7864E28
	public object .ctor() { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object g_CloseupScreenSpaceShadow; // 0x0
	public static readonly object s_MainTex; // 0x4
	public static readonly object s_BlurRadius; // 0x8
	public static readonly object s_ShadowBlueNoise; // 0xC

	// Methods

	// RVA: 0x78782B0
	private static object .cctor() { }

}

// Namespace: Yarp
public class ShadowMaskBlurPass
{

	// Fields
	private object m_shadowMaskBlurMat; // 0x8
	private object m_shadowMaskBlurRT; // 0x10

	// Methods

	// RVA: 0x7877C70
	public object Dispose() { }

	// RVA: 0x7877CF0
	public object BlurScreenSpaceShadowMask(object cmd, object aCamera, object aLight, object srcShadowMask) { }

	// RVA: 0x7877F30
	private object CreateShadowMaskTexIfNeed(object aCamera, object shadowMaskRT) { }

	// RVA: 0x78782A8
	public object .ctor() { }

}

// Namespace: Yarp
public class YAShadowCaster
{

	// Fields
	private object m_lstRenders; // 0x18

	// Methods

	// RVA: 0x78783B0
	private object OnEnable() { }

	// RVA: 0x7878500
	private object OnDisable() { }

	// RVA: 0x78783B4
	public object AddData() { }

	// RVA: 0x787862C
	public object .ctor() { }

}

// Namespace: Yarp
public class PcssSetting
{

	// Fields
	public object BlockerSamplesCount; // 0x18
	public object PCFSampleCount; // 0x1C
	public object Softness; // 0x20
	public object SoftnessFalloff; // 0x24
	public object BlockerGradientBias; // 0x28
	public object PCFGradientBias; // 0x2C

	// Methods

	// RVA: 0x7878634
	public object .ctor() { }

}

// Namespace: 
private static class ShaderConstants
{

	// Fields
	public static readonly object g_LightPositionAndFalloff; // 0x0
	public static readonly object g_LightIntensityAndAngleScale; // 0x4
	public static readonly object g_LightDirectionAndAngleOffset; // 0x8
	public static readonly object g_LightShadowSplitIndexAndLightLayers; // 0xC
	public static readonly object g_VisibilityShadowOfLights; // 0x10
	public static readonly object g_LightLayerNumOfLightsInTotal; // 0x14
	public static readonly object g_LightLayerNumOfLightsPerPixel; // 0x18
	public static readonly object g_LightCookieTex; // 0x1C
	public static readonly object g_LightRight; // 0x20
	public static readonly object g_LightUp; // 0x24
	public static readonly object g_LightForward; // 0x28
	public static readonly object g_LightCookieST; // 0x2C
	public static readonly object g_LightCookieInfo; // 0x30

	// Methods

	// RVA: 0x7879950
	private static object .cctor() { }

}

// Namespace: Yarp
public class SimpleLightLoop
{

	// Fields
	public static object s_maxPunctualLights; // 0x0
	private const object c_characterSceneLightLayerMask;
	private object m_lightPositionAndFalloff; // 0x8
	private object m_lightIntensityAndAngleScale; // 0x10
	private object m_lightDirectionAndAngleOffset; // 0x18
	private object m_lightShadowSplitIndexAndLightLayers; // 0x20
	private object m_visibilityShadowOfLights; // 0x28

	// Methods

	// RVA: 0x7878654
	private object ResetLightData(object index) { }

	// RVA: 0x787878C
	private object SetLightData(object light, object index) { }

	// RVA: 0x7878D38
	private object SetupLightCookies(object cmd, object light, object lightIndex) { }

	// RVA: 0x7879344
	public object SetupLights(object cmd, object worldData) { }

	// RVA: 0x7879824
	public object Dispose() { }

	// RVA: 0x7879828
	public object .ctor() { }

	// RVA: 0x7879900
	private static object .cctor() { }

}

// Namespace: 
private static class ShaderID
{

	// Fields
	public static object _InvViewProjMatrix; // 0x0
	public static object _CameraPositionW; // 0x4
	public static object _IsSkyTextureGammaSpace; // 0x8

	// Methods

	// RVA: 0x787A394
	private static object .cctor() { }

}

// Namespace: Yarp
public class Skydome
{

	// Fields
	private object m_material; // 0x18
	private object m_propertyBlock; // 0x20

	// Methods

	// RVA: 0x7879BEC
	public object .ctor() { }

	// RVA: 0x7879DA8
	public object Render(object cmd, object viewCamera, object skyTexture, object skyIntensity, object isSkyTextureGammaSpace, object biasAngle, object useProceduralSky) { }

	// RVA: 0x787A21C
	public object Render(object commands, object worldData, object cameraData) { }

	// RVA: 0x787A38C
	public override object GetRenderPassName() { }

}

// Namespace: Yarp
public class STBNSampler
{

	// Fields
	private static readonly object g_stbn_vec4_texture_array; // 0x0
	private object stbn_vec3_2Dx1D_128x128x64; // 0x8

	// Methods

	// RVA: 0x787A468
	public object Setup(object commands) { }

	// RVA: 0x787A7E4
	public object Dispose() { }

	// RVA: 0x787A7EC
	public object .ctor() { }

	// RVA: 0x787A7F4
	private static object .cctor() { }

}

// Namespace: 
public class CascadeData
{

	// Fields
	public object cascadeData; // 0x8

	// Methods

	// RVA: 0x787C050
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__44_0; // 0x8
	public static object <>9__44_1; // 0x10

	// Methods

	// RVA: 0x787C194
	private static object .cctor() { }

	// RVA: 0x787C1F4
	public object .ctor() { }

	// RVA: 0x787C1FC
	internal object <UpdateConfig>b__44_0(object x) { }

	// RVA: 0x787C230
	internal object <UpdateConfig>b__44_1(object a, object b) { }

}

// Namespace: Yarp
public class YADiffusionProfile
{

	// Fields
	private const object UNITY_PI;
	private const object LOG2_E;
	private object m_isDirty; // 0x10
	private object m_sampleCount; // 0x14
	private object m_d; // 0x18
	private object m_maxEstimatedMFPRadius; // 0x24
	private object m_meanFreePath; // 0x28
	private object m_unScaledMeanFreePath; // 0x34
	private object m_subsurfaceAlbedo; // 0x40
	private object m_diffusionRadius; // 0x4C
	private object m_samples; // 0x50
	private object m_hash; // 0x58
	private object m_cascadeDatas; // 0x60
	private object m_profileDataFeature; // 0x68

	// Properties
	public object BurleyD { get; }
	public object MeanFreePath { get; }
	public object SampleCount { get; }
	public object MaxEstimatedMFPRadius { get; }
	public object Samples { get; }
	public object SubsurfaceAlbedo { get; set; }
	public object UnScaledMeanFreePath { get; set; }
	public object DiffusionRadius { get; set; }
	public object hash { get; set; }
	public object CascadeDatas { get; }
	public object ProfileDataFeature { get; }
	public object ProfileDirty { get; }

	// Methods

	// RVA: 0x787A868
	public object get_BurleyD() { }

	// RVA: 0x787A874
	public object get_MeanFreePath() { }

	// RVA: 0x787A880
	public object get_SampleCount() { }

	// RVA: 0x787A888
	public object get_MaxEstimatedMFPRadius() { }

	// RVA: 0x787A890
	public object get_Samples() { }

	// RVA: 0x787A898
	public object get_SubsurfaceAlbedo() { }

	// RVA: 0x787A8A4
	public object set_SubsurfaceAlbedo(object value) { }

	// RVA: 0x787A8F4
	public object get_UnScaledMeanFreePath() { }

	// RVA: 0x787A900
	public object set_UnScaledMeanFreePath(object value) { }

	// RVA: 0x787A92C
	public object get_DiffusionRadius() { }

	// RVA: 0x787A934
	public object set_DiffusionRadius(object value) { }

	// RVA: 0x787A95C
	public object get_hash() { }

	// RVA: 0x787A964
	public object set_hash(object value) { }

	// RVA: 0x787A96C
	public object get_CascadeDatas() { }

	// RVA: 0x787A974
	public object get_ProfileDataFeature() { }

	// RVA: 0x787A97C
	public object get_ProfileDirty() { }

	// RVA: 0x787A984
	private static object RadicalInverse(object bits) { }

	// RVA: 0x787A990
	public object UpdateConfig() { }

	// RVA: 0x787AF5C
	public static object DiffusionBurley(object r, object inBurleyD) { }

	// RVA: 0x787AFB8
	public static object BurleyPDF(object r, object inBurleyD) { }

	// RVA: 0x787AE34
	public static object BurleyRCP(object u, object rcp_s, object r, object rcpPdf) { }

	// RVA: 0x787B008
	private static object GenerateLowDiscrepancySequence(object i) { }

	// RVA: 0x787B1F8
	private object GenerateBurleySamples(object sampleCount, object rcp_s) { }

	// RVA: 0x787B4F0
	private object GenerateUniformSamples(object sampleCount, object rcp_s) { }

	// RVA: 0x787B6E0
	private object GetIntervalRadius_Importance(object CurrentCascade, object TotalCascadeNum, object MaxD) { }

	// RVA: 0x787B7D4
	private object GetIntervalStart(object CurrentCascade, object TotalCascadeNum, object MaxD) { }

	// RVA: 0x787B8D0
	private object GetIntervalSize(object CurrentCascade, object TotalCascadeNum, object MaxD) { }

	// RVA: 0x787BA94
	public object BuildProfile() { }

	// RVA: 0x787A8D0
	private object OnValidate() { }

	// RVA: 0x787C0D0
	private object OnEnable() { }

	// RVA: 0x787C0D4
	public object .ctor() { }

}

// Namespace: Yarp
public class YADiffusionProfileComparer
{

	// Methods

	// RVA: 0x787C238
	public object GetHashCode(object profile) { }

	// RVA: 0x787C258
	public object Equals(object x, object y) { }

	// RVA: 0x787C298
	public object .ctor() { }

}

// Namespace: Yarp
public static class YASSSConsts
{

	// Fields
	public const object MaxDiffusionProfileCount;
	public const object MaxCascadeCount;
}

// Namespace: Yarp
public static class VectorMath
{

	// Methods

	// RVA: 0x787ACF8
	public static object ElementwiseOperation(object v, object operation) { }

	// RVA: 0x787AD88
	public static object ElementwiseOperation(object a, object b, object operation) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__23_0; // 0x8

	// Methods

	// RVA: 0x787CCFC
	private static object .cctor() { }

	// RVA: 0x787CD5C
	public object .ctor() { }

	// RVA: 0x787CD64
	internal object <UpdateDiffusionProfiles>b__23_0(object p) { }

}

// Namespace: Yarp
public class YADiffusionProfilePackage
{

	// Fields
	private object m_maxDiffusionProfileCount; // 0x8
	private object m_diffusionProfiles; // 0x10
	private object m_BurleyDArray; // 0x18
	private object m_RefSampleArrays; // 0x20
	private object m_CulledSubsurfaceRenderers; // 0x28
	private object m_MaxDiffusionRadius; // 0x30
	private object m_ProbeVPRect; // 0x34
	private object m_NeedReInit; // 0x44
	private object m_PackageHash; // 0x48
	private object m_CascadeData; // 0x50

	// Properties
	public object BurleyDArray { get; }
	public object RefSampleArrays { get; }
	public object CulledSubsurfaceRenderers { get; }
	public object MaxDiffusionRadius { get; }
	public object ProbeVPRect { get; }
	public object CascadeData { get; }
	public object HasAnySubsurfaceRenderer { get; }

	// Methods

	// RVA: 0x787C2A0
	public object get_BurleyDArray() { }

	// RVA: 0x787C2A8
	public object get_RefSampleArrays() { }

	// RVA: 0x787C2B0
	public object get_CulledSubsurfaceRenderers() { }

	// RVA: 0x787C2B8
	public object get_MaxDiffusionRadius() { }

	// RVA: 0x787C2C0
	public object get_ProbeVPRect() { }

	// RVA: 0x787C2CC
	public object get_CascadeData() { }

	// RVA: 0x787C2D4
	public object GetNeedReInitAndReset() { }

	// RVA: 0x787C2E4
	public object UpdateDiffusionProfiles(object frameData, object inDynamicRTSize, object inFBOWidth, object inFBOHeight, object inCascadeCount, object inCameraData) { }

	// RVA: 0x787CC10
	public object get_HasAnySubsurfaceRenderer() { }

	// RVA: 0x787CC6C
	public object .ctor() { }

}

// Namespace: Yarp
public enum ESubsurfaceScatteringMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UNIFORM_BF;
	public const object IMPORTANCE_BF;
	public const object RADIANCE_CASCADE;
	public const object RADIANCE_CASCADE_REWEIGHTED;
}

// Namespace: Yarp
public enum ESubsurfaceProfileMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MID_SIMULATE;
	public const object SHALLOW_SIMULATE;
	public const object DEEP_SIMULATE;
	public const object FULL;
}

// Namespace: 
private static class ShaderProps
{

	// Fields
	public static readonly object _incident_light_texture; // 0x0
	public static readonly object _surface_albedo_texture; // 0x4
	public static readonly object _depth_texture; // 0x8
	public static readonly object _sss_stencil_mask_texture; // 0xC
	public static readonly object _last_cascade_deep_texture; // 0x10
	public static readonly object _last_cascade_shallow_texture; // 0x14
	public static readonly object _last_cascade_mid_texture; // 0x18
	public static readonly object _last_cascade_norm_deep_texture; // 0x1C
	public static readonly object _last_cascade_norm_shallow_texture; // 0x20
	public static readonly object _last_cascade_norm_mid_texture; // 0x24
	public static readonly object hierarchical_incident_light_mip_1; // 0x28
	public static readonly object hierarchical_incident_light_mip_2; // 0x2C
	public static readonly object hierarchical_incident_light_mip_3; // 0x30
	public static readonly object hierarchical_incident_light_mip_4; // 0x34

	// Methods

	// RVA: 0x7883ACC
	private static object .cctor() { }

}

// Namespace: 
private class FScreenSpaceScatteringShader
{

	// Fields
	private object m_isInited; // 0x8
	public object m_screenSpaceSSSPassID; // 0xC
	public object m_screenSpaceRecombinePassID; // 0x10
	public object m_radianceCascadePassID; // 0x14
	public object m_radianceCascadeMergePassID; // 0x18
	public object m_radianceCascadeReweightedPassID; // 0x1C
	public object m_radianceCascadeReweightedMergePassID; // 0x20
	public object m_screenSpaceSSSMaterial; // 0x28

	// Methods

	// RVA: 0x7883520
	public object Init() { }

	// RVA: 0x7883AB4
	public object .ctor() { }

}

// Namespace: 
public struct CascadeRT
{

	// Fields
	public object color; // 0xFFFFFFFFFFFFFFF8
	public object norm; // 0x0
	public object attachColorDesc; // 0x8
	public object attachNormDesc; // 0x80

	// Methods

	// RVA: 0x788428C
	public object Dispose() { }

}

// Namespace: 
private class SubsurfaceScatteringCascade
{

	// Fields
	private object m_cascadeIndex; // 0x8
	private object m_shallow; // 0x10
	private object m_mid; // 0x110
	private object m_deep; // 0x210
	private object m_width; // 0x310
	private object m_height; // 0x314
	private object m_scaleFactor; // 0x318
	public object placeHolderDepth; // 0x320

	// Properties
	public object Shallow { get; }
	public object Mid { get; }
	public object Deep { get; }
	public object CascadeWidth { get; }
	public object CascadeHeight { get; }
	public object CascadeScaleFactor { get; }

	// Methods

	// RVA: 0x7883E84
	public object get_Shallow() { }

	// RVA: 0x7883EC8
	public object get_Mid() { }

	// RVA: 0x7883F0C
	public object get_Deep() { }

	// RVA: 0x7883F50
	public object get_CascadeWidth() { }

	// RVA: 0x7883F58
	public object get_CascadeHeight() { }

	// RVA: 0x7883F60
	public object get_CascadeScaleFactor() { }

	// RVA: 0x7883F68
	private object CreateRCRT(object inWidth, object inHeight, object inName, object inFormat) { }

	// RVA: 0x787E0EC
	public object Create(object inCascadeIndex, object inWidth, object inHeight, object inScaleFactor, object inProfileMode, object inNeedResources) { }

	// RVA: 0x787D3EC
	public object Dispose() { }

	// RVA: 0x787E0CC
	public object .ctor() { }

}

// Namespace: Yarp
public class YASubsurfaceScattering
{

	// Fields
	private object s_layerMask_Hide; // 0x18
	private object m_ScreenSpaceScatteringShader; // 0x20
	private object m_sssRT0; // 0x28
	private object m_sssRT1; // 0x30
	private object m_sssRT2; // 0x38
	private object m_GBufferDiffuse; // 0x40
	private object m_GBufferCustomData; // 0x48
	private object m_DeferredLighting; // 0x50
	private object m_sssLightingResult; // 0x58
	private object m_cascades; // 0x60
	private object m_propBlock; // 0x68
	private object m_propBlockCheckKeyWord; // 0x70
	private object m_isInited; // 0x78
	private object m_width; // 0x7C
	private object m_height; // 0x80
	private object m_numberOfCascade; // 0x84
	private object m_lowerCascadeResolution; // 0x88
	private object m_settingLowerCascadeResolution; // 0x89
	private object m_dynamicRTSize; // 0x8A
	private object m_incidentLightClip; // 0x8B
	private object m_shadingPathDeferred; // 0x8C
	private object m_scatteringMode; // 0x90
	private object m_profileMode; // 0x94
	private object m_diffusionProfilePackage; // 0x98
	private object m_BasePassDisableTargetMaterials; // 0xA0
	private object m_BasePassRestoreMaterials; // 0xA8
	private object m_tempSharedMaterialList; // 0xB0
	private object m_forceAttachments2; // 0xB8
	private object m_forceAttachments4; // 0xC0
	private object m_forceAttachments6; // 0xC8
	private object m_VLMKeywordCache; // 0xD0
	private object m_CloseupShadowKeywordCache; // 0xD8
	private object m_CachedKeywordGlobal; // 0xE0

	// Methods

	// RVA: 0x787CD84
	public override object GetRenderPassName() { }

	// RVA: 0x787CD8C
	public static object GetSubsurfaceScatteringFormat() { }

	// RVA: 0x787CE34
	public object RestoreMaterialsOpaquePass() { }

	// RVA: 0x787CFEC
	private object DeInitSSSContextInner() { }

	// RVA: 0x787D524
	public object InitSSSContext(object commandBuffer, object inMainFBO, object inCameraData, object inSettings) { }

	// RVA: 0x787E558
	private object SetupSceneColorBufferResources(object commandBuffer, object inDepth) { }

	// RVA: 0x787E71C
	private object EnableProfileMode(object commandBuffer) { }

	// RVA: 0x787E86C
	private object BindRCRtsCorrectLoadStore(object commandBuffer, object cascadeIndex) { }

	// RVA: 0x787F778
	private object BindRCRtsForce(object commandBuffer, object cascadeIndex) { }

	// RVA: 0x7880218
	private object BindRCRts(object commandBuffer, object cascadeIndex) { }

	// RVA: 0x788027C
	private object BuildRCAttachment(object cascadeIndex) { }

	// RVA: 0x7880810
	private object PropertyBlockSetupRCTexture(object commandBuffer, object cascadeIndex) { }

	// RVA: 0x7880CF0
	private object BurleyLighting_RC(object commandBuffer, object inMainFBO, object camera, object renderContext) { }

	// RVA: 0x7881E90
	private object BurleyLighting(object commandBuffer, object inMainFBO, object camera) { }

	// RVA: 0x7882270
	private object RecombineLighting(object commandBuffer, object inMainFBO) { }

	// RVA: 0x78824E4
	private object AttachSSSMRTContext(object commandBuffer, object inMainFBO) { }

	// RVA: 0x7882958
	private object DrawSubsurfaceTarget(object inContext, object inViewCamera, object inCommands, object inMainFBO) { }

	// RVA: 0x7883288
	public object RenderSubsurfaceScattering(object inContext, object inCommands, object inViewCamera, object inSettings, object inWorldData, object inMainFBO, object rendererEnableSSSSS) { }

	// RVA: 0x7883714
	public object DeInitSSSContext() { }

	// RVA: 0x7883718
	protected override object Dispose(object disposing) { }

	// RVA: 0x7883754
	public static object SetupSSS(object inCmd, object inWorldData, object inRenderSetting) { }

	// RVA: 0x7883758
	public object .ctor() { }

}

// Namespace: Yarp
public enum YASSSTestTargetFrameRate
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FPS_30;
	public const object FPS_60;
	public const object FPS_120;
}

// Namespace: Yarp
public class YASubsurfaceScatteringTest
{

	// Fields
	public object m_cameras; // 0x18
	public object m_renderSettings; // 0x20
	private object m_testWindowOpen; // 0x28
	private object m_SSSEnable; // 0x29
	private object m_SSSMode; // 0x2C
	private object m_SSSProfileMode; // 0x30
	private object m_SSSCascadeCount; // 0x34
	private object m_SSSLowerCascadeResolution; // 0x38
	private object m_SSSDynamicRTSize; // 0x39
	private object m_SSSIncidentLightClip; // 0x3A
	private object cpuFrameTime; // 0x40
	private object gpuFrameTime; // 0x48
	public object fpsText; // 0x50
	private object stringBuilder; // 0x58
	private object smoothFps; // 0x60
	private const object smoothingFactor;
	private object m_targetFrameRate; // 0x64

	// Methods

	// RVA: 0x78843FC
	private object Awake() { }

	// RVA: 0x7884400
	private object OnEnable() { }

	// RVA: 0x78845D4
	private object OnDisable() { }

	// RVA: 0x7884658
	private object Update() { }

	// RVA: 0x7884950
	private object DisableAllCamera() { }

	// RVA: 0x7884A74
	private object OnLayout() { }

	// RVA: 0x7885960
	public object .ctor() { }

}

// Namespace: Yarp
public enum ShaderPass
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Meta;
	public const object ShadowCaster;
	public const object MotionVectors;
	public const object ForwardGBuffer;
	public const object ForwardBase;
	public const object GlitchEffectVectors;
	public const object Outline;
	public const object OPT;
	public const object Reflection;
	public const object Impostor;
	public const object TransparentDepthPrepass;
	public const object TransparentDepthPostpass;
	public const object ProjectorShadow;
	public const object TransparentMotion;
	public const object PreZ;
	public const object Subsurface;
	public const object CloseupShadow;
	public const object RayTracingGBuffer;
	public const object PathTracingDXR;
}

// Namespace: Yarp
public enum ShadingModel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Standard;
	public const object Custom;
}

// Namespace: Yarp
public enum SurfaceRenderType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Surface;
	public const object Subsurface;
	public const object Volumetric;
}

// Namespace: Yarp
public enum ShaderProfile
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Junei;
	public const object Juwai;
	public const object Ciyuan;
}

// Namespace: Yarp
public enum CompilationTargetLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Level20;
	public const object Level25;
	public const object Level30;
	public const object Level35;
	public const object Level40;
	public const object Level45;
	public const object Level46;
	public const object Level50;
}

// Namespace: Yarp
public enum ShaderLOD
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LOD100;
	public const object LOD500;
	public const object LOD600;
}

// Namespace: Yarp
public enum YALightShape
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Directional;
	public const object Point;
	public const object Spot;
	public const object Rectangle;
	public const object Disk;
	public const object Sphere;
	public const object Mesh;
}

// Namespace: Yarp
public enum YAGIType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object UniformLightmap;
	public const object DirectionalLightmap;
	public const object ScreenSpaceIrradiance;
	public const object VolumetricLightmap;
	public const object LightProbe;
}

// Namespace: Yarp
public enum YAViewMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Lit;
	public const object DetailLighting;
	public const object LightingOnly;
}

// Namespace: Yarp
public enum YALightingComponent
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Emissive;
	public const object DirectLight;
	public const object DiffuseGlobalIllumination;
	public const object SpecularReflection;
	public const object StaticShadow;
	public const object DynamicShadow;
	public const object AmbientOcclusion;
	public const object All;
}

// Namespace: Yarp
public enum ShaderArbitraryOutputVariable
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Opacity;
	public const object Diffuse;
	public const object Specular;
	public const object Emission;
	public const object BaseColorFromDiffuseSpecular;
	public const object MetallicFromDiffuseSpecular;
	public const object Roughness;
	public const object FaceNormal;
	public const object GeometryNormal;
	public const object GeometryTangent;
	public const object GeometryBitangent;
	public const object ShadingNormal;
	public const object ShadingTangent;
	public const object ShadingBitangent;
	public const object ShadingNormalTangentSpace;
	public const object PositionWorldSpace;
	public const object UV0;
	public const object UV1;
	public const object BakedVisibilityDirection;
	public const object BakedDiffuseOcclusion;
	public const object BakedSpecularOcclusion;
	public const object VertexColor;
	public const object ShadowMask;
	public const object SunCloudMap;
	public const object SkyCloudMap;
}

// Namespace: Yarp
public enum ShadowMapFilter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object FixedSizePCF;
}

// Namespace: Yarp
public enum ShadowMapFilteSize
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FixedSize1Tap;
	public const object FixedSize4Tap;
}

// Namespace: Yarp
public enum ColorEncoding
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object HDR;
	public const object RGBM;
}

// Namespace: Yarp
public enum YACameraClearFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Skybox;
	public const object Color;
	public const object SolidColor;
	public const object Depth;
	public const object Nothing;
}

// Namespace: Yarp
public enum ShaderOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UnityProjectGammaColorSpace;
	public const object PreExposure;
	public const object AreaLights;
	public const object IblNormalization;
	public const object IblColorEncoding;
	public const object EnvmapRotation;
	public const object CsmMaxCascades;
	public const object MaxPunctualLights;
	public const object JuWaiMaxShadowSplits;
	public const object MaxShadowSplits;
	public const object SpecularOcclusionLutSize;
	public const object ColorGradingLutSize;
	public const object MaxMetaPassOutputVariables;
	public const object MaxMetaPassRenderTargets;
	public const object SUPPORT_ENVIRONMENT_LIGHT_MODE_MIXED;
}

// Namespace: Yarp
public class ShaderConfig
{

	// Fields
	public const object s_PreExposure;
	public const object s_AreaLights;
	public const object s_IblNormalization;
	public const object s_IblColorEncoding;
	public const object s_EnvmapRotation;
	public const object s_CsmMaxCascades;
	public const object s_MaxPunctualLights;
	public const object s_JuWaiMaxShadowSplits;
	public const object s_MaxShadowSplits;
	public const object s_SpecularOcclusionLutSize;
	public const object s_ColorGradingLutSize;
	public const object s_MaxMetaPassOutputVariables;
	public const object s_MaxMetaPassRenderTargets;
	public const object s_SUPPORT_ENVIRONMENT_LIGHT_MODE_MIXED;

	// Methods

	// RVA: 0x788598C
	public object .ctor() { }

}

// Namespace: Yarp
internal static class TempBackbuffer
{

	// Fields
	private static object s_index; // 0x0
	private static object s_renderTextures; // 0x8

	// Methods

	// RVA: 0x7885994
	public static object GetCurrent() { }

	// RVA: 0x7885BF8
	public static object Advance() { }

	// RVA: 0x7885C94
	public static object Reset() { }

	// RVA: 0x7885E50
	private static object .cctor() { }

}

// Namespace: Yarp
public class CameraRendererBundle
{

	// Fields
	public object Camera; // 0x8
	public object CameraData; // 0x10
	public object Renderer; // 0x18

	// Methods

	// RVA: 0x7885ED0
	public object Cleanup() { }

	// RVA: 0x7885F00
	public object IsValid() { }

	// RVA: 0x7886008
	public object IsActive() { }

	// RVA: 0x7886180
	public object .ctor() { }

}

// Namespace: 
public enum WorkStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WaitingForUpdate;
	public const object Updated;
	public const object Closing;
}

// Namespace: 
private struct ContextRenderingScope
{

	// Fields
	private readonly object m_Context; // 0xFFFFFFFFFFFFFFF8
	private readonly object m_Cameras; // 0x0

	// Methods

	// RVA: 0x788B230
	public object .ctor(object context, object cameras) { }

	// RVA: 0x788C704
	public object Dispose() { }

}

// Namespace: 
private struct CameraRenderingScope
{

	// Fields
	private readonly object m_Context; // 0xFFFFFFFFFFFFFFF8
	private readonly object m_Camera; // 0x0

	// Methods

	// RVA: 0x788AC40
	public object .ctor(object context, object camera) { }

	// RVA: 0x788C7B8
	public object Dispose() { }

}

// Namespace: Yarp
public class YARenderPipeline
{

	// Fields
	private object <State>k__BackingField; // 0xC
	private object m_frameId; // 0x10
	private object m_isMaterialSystemInitialized; // 0x14
	private object m_commands; // 0x18
	private readonly object m_rendererBundleDict; // 0x20
	private readonly object m_tempRendererBundleDict; // 0x28
	private object m_customCameraBundleDict; // 0x30
	private object m_combineVirtualBackBufferPass; // 0x38
	private object m_virtualBackBuffer; // 0x40
	private object <IsRenderingOnBackBuffer>k__BackingField; // 0x48
	private object m_removeList; // 0x50
	private static object ms_enable; // 0x0
	private static object <IsExecLowestRenderPipeline>k__BackingField; // 0x1
	private static object <IsSupportLightmap>k__BackingField; // 0x2
	private static object ms_UsingLowestPipeline; // 0x3
	private static object onPreCull; // 0x8
	private static object onPreRender; // 0x10
	private static object onPostRender; // 0x18
	private object m_onPreCullCache; // 0x58

	// Properties
	public object State { get; set; }
	private object IsRenderingOnBackBuffer { get; set; }
	public static object Enable { get; set; }
	public static object IsExecLowestRenderPipeline { get; set; }
	public static object IsSupportLightmap { get; set; }
	public static object EnableSRP { get; set; }

	// Methods

	// RVA: 0x7886188
	public object get_State() { }

	// RVA: 0x7886190
	private object set_State(object value) { }

	// RVA: 0x7886198
	private object get_IsRenderingOnBackBuffer() { }

	// RVA: 0x78861A0
	private object set_IsRenderingOnBackBuffer(object value) { }

	// RVA: 0x78861A8
	private object PrepareHDR(object cameras) { }

	// RVA: 0x78861AC
	private object UseHDR(object cameras) { }

	// RVA: 0x78861B0
	private object CommitHDR(object gfxContext, object cameras) { }

	// RVA: 0x78861B4
	private object UpdateHDR() { }

	// RVA: 0x78861B8
	public object .ctor() { }

	// RVA: 0x7886474
	protected override object Dispose(object disposing) { }

	// RVA: 0x7886318
	private object Initialize() { }

	// RVA: 0x78864B0
	private object Cleanup() { }

	// RVA: 0x78865EC
	private object InsertIntoPlayerLoop() { }

	// RVA: 0x7886EF0
	private object RemoveFromPlayerLoop() { }

	// RVA: 0x78872E4
	private static object PostPostLateUpdateStatic() { }

	// RVA: 0x7887430
	private object Update() { }

	// RVA: 0x788763C
	private object UpdateCameras() { }

	// RVA: 0x7888070
	private object CreateCameraRendererBundle(object bundleDict, object camera) { }

	// RVA: 0x7888260
	private object UpdateCameraRendererBundle(object bundle) { }

	// RVA: 0x7888180
	private object RemoveCameraRendererBundle(object cameraID) { }

	// RVA: 0x788892C
	private object UpdateRenderSystemManager() { }

	// RVA: 0x7888E40
	private object UpdateHyper() { }

	// RVA: 0x7886BAC
	private object CleanupRendererBundles() { }

	// RVA: 0x7888E44
	public object UpdateCustomCamera(object camera) { }

	// RVA: 0x7888F7C
	public object GetCameraRendererBundle(object camera) { }

	// RVA: 0x7889100
	public object GetRenderer(object camera) { }

	// RVA: 0x7888484
	private object CreateRenderer(object cameraData) { }

	// RVA: 0x78891D4
	private object OnFrameBegin(object gfxContext, object cmd) { }

	// RVA: 0x7889250
	private static object CameraRenderImageCallback(object gfxContext, object commands, object bundle, object activeTexture, object isLastCameraWithOnRenderImageCallback) { }

	// RVA: 0x788979C
	private object RenderInternal(object gfxContext, object cameras) { }

	// RVA: 0x788AC98
	private object AfterSceneViewRender(object gfxContext, object commands, object camera) { }

	// RVA: 0x7886B2C
	private object InitializeMaterialSystem() { }

	// RVA: 0x7886E54
	private object FinalizeMaterialSystem() { }

	// RVA: 0x788AE8C
	protected override object Render(object context, object cameras) { }

	// RVA: 0x788AECC
	protected override object Render(object context, object cameras) { }

	// RVA: 0x788B280
	public static object get_Enable() { }

	// RVA: 0x788B2FC
	public static object set_Enable(object value) { }

	// RVA: 0x788B388
	private object ClearBackBuffer(object context) { }

	// RVA: 0x788B460
	public static object get_IsExecLowestRenderPipeline() { }

	// RVA: 0x788B4DC
	public static object set_IsExecLowestRenderPipeline(object value) { }

	// RVA: 0x788B568
	public static object get_IsSupportLightmap() { }

	// RVA: 0x788B5E4
	public static object set_IsSupportLightmap(object value) { }

	// RVA: 0x788B224
	private object TryExecLowestRenderPipeline(object context, object cameras) { }

	// RVA: 0x788B670
	private object ExecLowestRenderPipeline(object context, object cameras) { }

	// RVA: 0x788B9E8
	public static object add_onPreCull(object value) { }

	// RVA: 0x788BAFC
	public static object remove_onPreCull(object value) { }

	// RVA: 0x788BC10
	public static object add_onPreRender(object value) { }

	// RVA: 0x788BD24
	public static object remove_onPreRender(object value) { }

	// RVA: 0x788BE38
	public static object add_onPostRender(object value) { }

	// RVA: 0x788BF4C
	public static object remove_onPostRender(object value) { }

	// RVA: 0x788C060
	private object add_m_onPreCullCache(object value) { }

	// RVA: 0x788C114
	private object remove_m_onPreCullCache(object value) { }

	// RVA: 0x788C1C8
	public object OnPreCull(object gfxContext, object camera) { }

	// RVA: 0x788AACC
	private object OnPreRender(object gfxContext, object camera) { }

	// RVA: 0x788AC9C
	private object OnPostRender(object gfxContext, object camera) { }

	// RVA: 0x788C33C
	public static object EnableOptimize() { }

	// RVA: 0x788C340
	public static object DisableOptimize() { }

	// RVA: 0x788C344
	public static object get_EnableSRP() { }

	// RVA: 0x788C34C
	private static object set_EnableSRP(object value) { }

	// RVA: 0x788C350
	public static object ForceToggleSRP(object enable) { }

	// RVA: 0x788C354
	public static object ToggleSRP(object root, object enable) { }

	// RVA: 0x788C358
	private static object GetGameObjectPath(object root) { }

	// RVA: 0x788C544
	public static object Get() { }

	// RVA: 0x788C664
	private static object .cctor() { }

}

// Namespace: Yarp
public class YARenderPipelineAsset
{

	// Fields
	public object uiMaterial; // 0x10
	public object uiETC1SupportedMaterial; // 0x18
	public object lightLayerNames; // 0x20
	public object renderingLayerMaskNames; // 0x28
	public object environmentLightAssetPath; // 0x30
	private static object m_lightLayerNames; // 0x0

	// Properties
	public override object defaultUIMaterial { get; }
	public override object defaultUIETC1SupportedMaterial { get; }
	public override object prefixedRenderingLayerMaskNames { get; }
	public static object s_lightLayerNames { get; }

	// Methods

	// RVA: 0x788C880
	protected override object CreatePipeline() { }

	// RVA: 0x788C934
	protected override object OnValidate() { }

	// RVA: 0x788C93C
	public override object get_defaultUIMaterial() { }

	// RVA: 0x788C944
	public override object get_defaultUIETC1SupportedMaterial() { }

	// RVA: 0x788C94C
	public override object get_prefixedRenderingLayerMaskNames() { }

	// RVA: 0x788C954
	public static object get_s_lightLayerNames() { }

	// RVA: 0x788CA88
	public object .ctor() { }

}

// Namespace: Yarp
public class YARenderPipelineHDRController
{

	// Fields
	private object m_isHDRContentAvailable; // 0x8
	private object m_HDRMode; // 0xC
	private object m_wantsHDR; // 0x10

	// Properties
	public object HDRMode { get; }

	// Methods

	// RVA: 0x788CAE8
	public object get_HDRMode() { }

	// RVA: 0x788CAF0
	protected override object Init() { }

	// RVA: 0x788CAF8
	protected override object UnInit() { }

	// RVA: 0x788B228
	public object ResetHDR() { }

	// RVA: 0x788CAFC
	public object CheckHDR(object worldData, object EnablePostProcess) { }

	// RVA: 0x788CB70
	public object UpdateHDR() { }

	// RVA: 0x788CBF0
	public object SetHDRMode(object mode) { }

	// RVA: 0x788CC04
	public static object GetHdrColorBufferFormat(object HdrMode) { }

	// RVA: 0x788CC2C
	public object UpdateHDRMode(object data) { }

	// RVA: 0x788CBDC
	public object RequestHDRModeChangeEx(object wantsHDR, object isHDRContentAvailable) { }

	// RVA: 0x788CC30
	public object RequestHDRModeChangeEx(object wantsHDR) { }

	// RVA: 0x788CC40
	public object IsHDREnabled() { }

	// RVA: 0x788CC5C
	public static object SwitchHDR() { }

	// RVA: 0x788CDEC
	public object .ctor() { }

}

// Namespace: Yarp
public static class YARenderPipelineResourcesLoader
{

	// Fields
	public static object LoadResource; // 0x0
	public static object LoadRawAsset; // 0x8
	public static object GetRawAssetDataLength; // 0x10
	public static object LoadRawAssetData; // 0x18
	public static object LockFileBuffer; // 0x20
	public static object UnlockFileBuffer; // 0x28

	// Properties
	public static object PostProcessShader { get; }
	public static object BlitPass { get; }
	public static object GaussianBlur { get; }
	public static object TextureBlending { get; }
	public static object PlanarReflectionFiltering { get; }
	public static object Bloom { get; }
	public static object CommonLUTCombine { get; }
	public static object DepthOfField { get; }
	public static object DepthDownSample { get; }
	public static object GeometryNormalMipChain { get; }
	public static object GenerateIncidentLightMips { get; }
	public static object ScreenSpaceSSS { get; }
	public static object AmbientOcclusionTraceRay { get; }
	public static object AmbientOcclusionUpsample { get; }
	public static object HitDistReconstruction { get; }
	public static object LinearAccumulatePass { get; }
	public static object DiffuseOcclusionBlur { get; }
	public static object SplitScreen { get; }
	public static object FXAA { get; }
	public static object Skydome { get; }
	public static object TemporalAA { get; }
	public static object TemporalAAMotionDebug { get; }
	public static object TemporalAA_CS { get; }
	public static object CameraMotionVector { get; }
	public static object MotionBlur { get; }
	public static object RadialBlur { get; }
	public static object SurfaceBlur { get; }
	public static object CombineVirtualBackBuffer { get; }
	public static object AccumulatePass { get; }
	public static object LightGridInjection { get; }
	public static object LightGridInjectionPS { get; }
	public static object CapsuleShadowInjectionPS { get; }
	public static object RadianceProbeBlitLinearEyeDepthToAlpha { get; }
	public static object RadianceProbeFromCubeMap { get; }
	public static object RadianceProbePrefilterEnvmap { get; }
	public static object RadianceProbeEncodePass { get; }
	public static object RadianceProbeCompressPass { get; }
	public static object RealtimeASTCBlitPass { get; }
	public static object RealtimeASTCEncode { get; }
	public static object ClearClusterInfo { get; }
	public static object CollectValidCluster { get; }
	public static object ClusterCulling { get; }
	public static object CollectCoveredClusterRange { get; }
	public static object CollectCoveredCluster { get; }
	public static object SortClusterItems { get; }
	public static object DefaultDecalMaterial { get; }
	public static object DefaultSSSMaterial { get; }
	public static object DefaultDiffusionProfile { get; }
	public static object PreIntegratedDFG { get; }
	public static object SpecularOcclusion { get; }
	public static object SpecularOcclusionBRDFCone { get; }
	public static object OwenScrambledNoise256 { get; }
	public static object AEHistogram_CS { get; }
	public static object AEEyeAdaptation_CS { get; }
	public static object AEHistogram_PS { get; }
	public static object AEEyeAdaptation_PS { get; }
	public static object ShadowCopy { get; }
	public static object ShadowScrolling { get; }
	public static object ContactShadow { get; }
	public static object ContactShadowPS { get; }
	public static object ContactShadowBend { get; }
	public static object ShadowMaskBlur { get; }
	public static object WhiteTexture { get; }
	public static object BlackTexture { get; }
	public static object BumpTexture { get; }
	public static object TemporalAALanczosLUT { get; }

	// Methods

	// RVA: 0x788CE44
	private static object LoadShader(object path) { }

	// RVA: 0x788CECC
	private static object LoadComputeShader(object path) { }

	// RVA: 0x788CF54
	private static object LoadRayTracingShader(object path) { }

	// RVA: 0x788CFDC
	private static object LoadTexture2D(object path) { }

	// RVA: 0x788D064
	private static object LoadTexture2DArray(object path) { }

	// RVA: 0x788D0EC
	private static object LoadMaterial(object path) { }

	// RVA: 0x788D174
	private static object LoadDiffusionProfile(object path) { }

	// RVA: 0x788D1FC
	public static object LoadGameObject(object path) { }

	// RVA: 0x787A680
	public static object LoadPipelineResource(object path) { }

	// RVA: 0x788D284
	private static object LoadResourceDefault(object path, object type) { }

	// RVA: 0x788D32C
	public static object get_PostProcessShader() { }

	// RVA: 0x788D41C
	public static object get_BlitPass() { }

	// RVA: 0x788D50C
	public static object get_GaussianBlur() { }

	// RVA: 0x788D5FC
	public static object get_TextureBlending() { }

	// RVA: 0x788D6EC
	public static object get_PlanarReflectionFiltering() { }

	// RVA: 0x788D7DC
	public static object get_Bloom() { }

	// RVA: 0x788D8CC
	public static object get_CommonLUTCombine() { }

	// RVA: 0x788D9BC
	public static object get_DepthOfField() { }

	// RVA: 0x788DAAC
	public static object get_DepthDownSample() { }

	// RVA: 0x788DB9C
	public static object get_GeometryNormalMipChain() { }

	// RVA: 0x788DC8C
	public static object get_GenerateIncidentLightMips() { }

	// RVA: 0x7883D94
	public static object get_ScreenSpaceSSS() { }

	// RVA: 0x788DD7C
	public static object get_AmbientOcclusionTraceRay() { }

	// RVA: 0x788DE6C
	public static object get_AmbientOcclusionUpsample() { }

	// RVA: 0x788DF5C
	public static object get_HitDistReconstruction() { }

	// RVA: 0x788E04C
	public static object get_LinearAccumulatePass() { }

	// RVA: 0x788E13C
	public static object get_DiffuseOcclusionBlur() { }

	// RVA: 0x788E22C
	public static object get_SplitScreen() { }

	// RVA: 0x788E31C
	public static object get_FXAA() { }

	// RVA: 0x7879CB8
	public static object get_Skydome() { }

	// RVA: 0x788E40C
	public static object get_TemporalAA() { }

	// RVA: 0x788E4FC
	public static object get_TemporalAAMotionDebug() { }

	// RVA: 0x788E5EC
	public static object get_TemporalAA_CS() { }

	// RVA: 0x788E6DC
	public static object get_CameraMotionVector() { }

	// RVA: 0x788E7CC
	public static object get_MotionBlur() { }

	// RVA: 0x788E8BC
	public static object get_RadialBlur() { }

	// RVA: 0x788E9AC
	public static object get_SurfaceBlur() { }

	// RVA: 0x788EA9C
	public static object get_CombineVirtualBackBuffer() { }

	// RVA: 0x788EB8C
	public static object get_AccumulatePass() { }

	// RVA: 0x788EC7C
	public static object get_LightGridInjection() { }

	// RVA: 0x788ED6C
	public static object get_LightGridInjectionPS() { }

	// RVA: 0x788EE5C
	public static object get_CapsuleShadowInjectionPS() { }

	// RVA: 0x788EF4C
	public static object get_RadianceProbeBlitLinearEyeDepthToAlpha() { }

	// RVA: 0x788F03C
	public static object get_RadianceProbeFromCubeMap() { }

	// RVA: 0x788F12C
	public static object get_RadianceProbePrefilterEnvmap() { }

	// RVA: 0x788F21C
	public static object get_RadianceProbeEncodePass() { }

	// RVA: 0x788F30C
	public static object get_RadianceProbeCompressPass() { }

	// RVA: 0x788F3FC
	public static object get_RealtimeASTCBlitPass() { }

	// RVA: 0x788F4EC
	public static object get_RealtimeASTCEncode() { }

	// RVA: 0x788F5DC
	public static object get_ClearClusterInfo() { }

	// RVA: 0x788F6CC
	public static object get_CollectValidCluster() { }

	// RVA: 0x788F7BC
	public static object get_ClusterCulling() { }

	// RVA: 0x788F8AC
	public static object get_CollectCoveredClusterRange() { }

	// RVA: 0x788F99C
	public static object get_CollectCoveredCluster() { }

	// RVA: 0x788FA8C
	public static object get_SortClusterItems() { }

	// RVA: 0x788FB7C
	public static object get_DefaultDecalMaterial() { }

	// RVA: 0x788FC6C
	public static object get_DefaultSSSMaterial() { }

	// RVA: 0x788FD5C
	public static object get_DefaultDiffusionProfile() { }

	// RVA: 0x788FE4C
	public static object get_PreIntegratedDFG() { }

	// RVA: 0x788FF3C
	public static object get_SpecularOcclusion() { }

	// RVA: 0x789002C
	public static object get_SpecularOcclusionBRDFCone() { }

	// RVA: 0x789011C
	public static object get_OwenScrambledNoise256() { }

	// RVA: 0x789020C
	public static object get_AEHistogram_CS() { }

	// RVA: 0x78902FC
	public static object get_AEEyeAdaptation_CS() { }

	// RVA: 0x78903EC
	public static object get_AEHistogram_PS() { }

	// RVA: 0x78904DC
	public static object get_AEEyeAdaptation_PS() { }

	// RVA: 0x78905CC
	public static object get_ShadowCopy() { }

	// RVA: 0x78906BC
	public static object get_ShadowScrolling() { }

	// RVA: 0x78907AC
	public static object get_ContactShadow() { }

	// RVA: 0x789089C
	public static object get_ContactShadowPS() { }

	// RVA: 0x789098C
	public static object get_ContactShadowBend() { }

	// RVA: 0x7890A7C
	public static object get_ShadowMaskBlur() { }

	// RVA: 0x7890B6C
	public static object get_WhiteTexture() { }

	// RVA: 0x7890C5C
	public static object get_BlackTexture() { }

	// RVA: 0x7890D4C
	public static object get_BumpTexture() { }

	// RVA: 0x7890E3C
	public static object get_TemporalAALanczosLUT() { }

	// RVA: 0x7890F2C
	private static object .cctor() { }

}

// Namespace: Yarp
public abstract class BaseRenderSettingsAnimator
{

	// Fields
	protected object m_target; // 0x18

	// Methods

	// RVA: 0x7890FD4
	private object OnEnable() { }

	// RVA: 0x78910EC
	private object OnDisable() { }

	// RVA: -1
	protected abstract object UnbindFrom(object volume) { }

	// RVA: -1
	protected abstract object BindTo(object volume) { }

	// RVA: -1
	public abstract object PasteTo(object baseSetting) { }

	// RVA: 0x78911E0
	public object IsValid() { }

	// RVA: 0x789124C
	protected object .ctor() { }

}

// Namespace: Yarp
public class FogSettingAnimator
{

	// Fields
	public object FogEnable; // 0x20
	public object FogColor; // 0x24
	public object FogColorIntensity; // 0x34
	public object FogNear; // 0x38
	public object FogFar; // 0x3C
	public object FogHeight; // 0x40
	public object FogBottom; // 0x44

	// Methods

	// RVA: 0x7891254
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x78912B4
	protected override object BindTo(object volume) { }

	// RVA: 0x7891380
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x789149C
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_Bloom
{

	// Fields
	public object EnableBloom; // 0x20
	public object BloomThreshold; // 0x24
	public object BloomSoftKnee; // 0x28
	public object BloomIntensity; // 0x2C
	public object BloomDiffusion; // 0x30
	public object BloomFireflyRemovalStrength; // 0x34
	public object BloomClamp; // 0x38
	public object BloomTint; // 0x3C

	// Methods

	// RVA: 0x78914CC
	public object CopyFrom(object src) { }

	// RVA: 0x7891508
	public object PasteTo(object dst) { }

	// RVA: 0x7891558
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x7891688
	protected override object BindTo(object volume) { }

	// RVA: 0x7891744
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7891870
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_BWFilter
{

	// Fields
	public object Enable; // 0x20
	public object Intensity; // 0x24
	public object Range; // 0x28
	public object LightenColor; // 0x30
	public object DarkenColor; // 0x40

	// Methods

	// RVA: 0x7891878
	public object CopyFrom(object src) { }

	// RVA: 0x78918BC
	public object PasteTo(object dst) { }

	// RVA: 0x7891914
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x7891A44
	protected override object BindTo(object volume) { }

	// RVA: 0x7891B08
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7891C3C
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_ColorGrading
{

	// Fields
	public object LutIntensity; // 0x20

	// Methods

	// RVA: 0x7891C44
	public object CopyFrom(object src) { }

	// RVA: 0x7891C68
	public object PasteTo(object dst) { }

	// RVA: 0x7891CA0
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x7891DD0
	protected override object BindTo(object volume) { }

	// RVA: 0x7891E74
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7891F88
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_DepthOfField
{

	// Fields
	public object Enable; // 0x20
	public object Debug; // 0x21
	public object UseCamaeraDistance; // 0x22
	public object HalfSizeDownsample; // 0x23
	public object FocalDistance; // 0x24
	public object FocalRegion; // 0x28
	public object NearRegion; // 0x2C
	public object FarRegion; // 0x30
	public object BlurRadius; // 0x34
	public object LookAt; // 0x38

	// Methods

	// RVA: 0x7891F90
	public object CopyFrom(object src) { }

	// RVA: 0x7891FCC
	public object PasteTo(object dst) { }

	// RVA: 0x789201C
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x789214C
	protected override object BindTo(object volume) { }

	// RVA: 0x7892208
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7892334
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_Glitch
{

	// Fields
	public object EnableGlitchEffect; // 0x20
	public object GlitchEffectTex; // 0x28
	public object GlitchEffectSpeed; // 0x30
	public object GlitchEffectScale; // 0x34
	public object GlitchEffectScreenHscale; // 0x38
	public object GlitchEffectDir; // 0x3C
	public object GlitchEffectMaskScale; // 0x40

	// Methods

	// RVA: 0x789233C
	public object CopyFrom(object src) { }

	// RVA: 0x7892378
	public object PasteTo(object dst) { }

	// RVA: 0x78923C8
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x78924F8
	protected override object BindTo(object volume) { }

	// RVA: 0x78925B4
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x78926E0
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_MotionBlur
{

	// Fields
	public object Enable; // 0x20
	public object Intensity; // 0x24
	public object Extend; // 0x28
	public object DirectionX; // 0x2C
	public object DirectionY; // 0x30
	public object NumIteration; // 0x34

	// Methods

	// RVA: 0x78926E8
	public object CopyFrom(object src) { }

	// RVA: 0x789271C
	public object PasteTo(object dst) { }

	// RVA: 0x7892764
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x7892894
	protected override object BindTo(object volume) { }

	// RVA: 0x7892948
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7892A9C
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_RadialBlur
{

	// Fields
	public object Enable; // 0x20
	public object Intensity; // 0x24
	public object Extend; // 0x28
	public object CenterPosX; // 0x2C
	public object CenterPosY; // 0x30
	public object NumIteration; // 0x34

	// Methods

	// RVA: 0x7892AA4
	public object CopyFrom(object src) { }

	// RVA: 0x7892AD8
	public object PasteTo(object dst) { }

	// RVA: 0x7892B20
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x7892C50
	protected override object BindTo(object volume) { }

	// RVA: 0x7892D04
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7892E28
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_ToneMapping
{

	// Fields
	public object ExposureValue; // 0x20
	public object VFXBrightnessScale; // 0x24

	// Methods

	// RVA: 0x7892E30
	public object CopyFrom(object src) { }

	// RVA: 0x7892E58
	public object PasteTo(object dst) { }

	// RVA: 0x7892E94
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x7892FC4
	protected override object BindTo(object volume) { }

	// RVA: 0x789306C
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7893184
	public object .ctor() { }

}

// Namespace: Yarp
public class PES_Vignette
{

	// Fields
	public object VignetteColor; // 0x20
	public object VignetteCenter; // 0x30
	public object VignetteIntensity; // 0x38
	public object VignetteSmoothness; // 0x3C
	public object VignetteRounded; // 0x40

	// Methods

	// RVA: 0x789318C
	public object CopyFrom(object src) { }

	// RVA: 0x78931C8
	public object PasteTo(object dst) { }

	// RVA: 0x7893218
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x7893348
	protected override object BindTo(object volume) { }

	// RVA: 0x7893404
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7893530
	public object .ctor() { }

}

// Namespace: 
public struct ToneMappingSetting
{

	// Fields
	public object ExposureValue; // 0xFFFFFFFFFFFFFFF8
	public object VFXBrightnessScale; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: 
public struct BloomSetting
{

	// Fields
	public object EnableBloom; // 0xFFFFFFFFFFFFFFF8
	public object BloomThreshold; // 0xFFFFFFFFFFFFFFFC
	public object BloomSoftKnee; // 0x0
	public object BloomIntensity; // 0x4
	public object BloomDiffusion; // 0x8
	public object BloomFireflyRemovalStrength; // 0xC
	public object BloomClamp; // 0x10
	public object BloomTint; // 0x14
}

// Namespace: 
public struct VignetteSetting
{

	// Fields
	public object VignetteColor; // 0xFFFFFFFFFFFFFFF8
	public object VignetteCenter; // 0x8
	public object VignetteIntensity; // 0x10
	public object VignetteSmoothness; // 0x14
	public object VignetteRounded; // 0x18
}

// Namespace: 
public struct ColorGradingSetting
{

	// Fields
	public object LutIntensity; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Yarp
public class PostEffectSettingsAnimator
{

	// Fields
	public object ToneMapping; // 0x20
	public object Bloom; // 0x28
	public object Vignette; // 0x54
	public object ColorGrading; // 0x78

	// Methods

	// RVA: 0x7893538
	protected override object UnbindFrom(object volume) { }

	// RVA: 0x7893880
	protected override object BindTo(object volume) { }

	// RVA: 0x7893B20
	public override object PasteTo(object baseSetting) { }

	// RVA: 0x7893E54
	public object .ctor() { }

}

// Namespace: Yarp
public class RadialBlurControllerData
{

	// Fields
	public object StartDelay; // 0x8
	public object LifeTime; // 0xC
	public object StrengthOverLife; // 0x10

	// Methods

	// RVA: 0x77657B8
	public object .ctor() { }

}

// Namespace: Yarp
public class RadialBlurController
{

	// Fields
	public object BlurData; // 0x18
	private object m_elapsedTime; // 0x20
	private object m_started; // 0x24
	private object m_setting; // 0x28

	// Methods

	// RVA: 0x7765830
	private object OnEnable() { }

	// RVA: 0x7765890
	private object Update() { }

	// RVA: 0x7765990
	private object StartRadialBlur() { }

	// RVA: 0x77659BC
	private object EndRadialBlur() { }

	// RVA: 0x77659E4
	private object OnDisable() { }

	// RVA: 0x7765A0C
	private object OnDestroy() { }

	// RVA: 0x7765A34
	public object .ctor() { }

}

// Namespace: Yarp
public abstract class BaseRenderSetting
{

	// Fields
	public object activate; // 0x18
	protected object animator; // 0x20
	public object settingSource; // 0x28

	// Properties
	public object Animator { set; }

	// Methods

	// RVA: 0x7765A3C
	public object set_Animator(object value) { }

	// RVA: 0x7765A44
	public object Interp(object setting, object factor) { }

	// RVA: 0x7765B64
	protected virtual object InterpTo(object setting, object factor) { }

	// RVA: 0x7765B68
	public virtual object OnRemove() { }

	// RVA: 0x7765B6C
	public virtual object OnReset() { }

	// RVA: 0x7765B70
	public virtual object Clone() { }

	// RVA: 0x7765BF8
	protected object .ctor() { }

}

// Namespace: Yarp
public class CiYuanRenderSettingsVolume
{

	// Methods

	// RVA: 0x7765C00
	public override object Awake() { }

	// RVA: 0x7765D48
	public object .ctor() { }

}

// Namespace: Yarp
public class ExcludeFromHashingAttribute
{

	// Methods

	// RVA: 0x7765E8C
	public object .ctor() { }

}

// Namespace: 
public enum CloudMapOcclusionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Global;
	public const object Local_Dynamic;
}

// Namespace: 
public enum SunSkyColorSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object GammaSpace;
	public const object LinearSpace;
}

// Namespace: Yarp
public class SunAndSkyOcclusionSetting
{

	// Fields
	public object Enable; // 0x30
	public object CloudMapMode; // 0x34
	public object SunOcclusion; // 0x38
	public object SunOcclusionIntensity; // 0x40
	public object SkyOcclusion; // 0x48
	public object SkyOcclusionIntensity; // 0x50
	public object SunSkyOcclusionTexelSize; // 0x54
	public object SunSkyOcclusionOffset; // 0x5C
	public object EnableLocalSkyOcclusion; // 0x64
	public object CloudMapColorSpace; // 0x68

	// Methods

	// RVA: 0x7765E94
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x77660BC
	public object GetSkyOcclusionPositionScaleOffset() { }

	// RVA: 0x77660DC
	public object GetLegacyScaleOffset() { }

	// RVA: 0x77660E8
	public object .ctor() { }

}

// Namespace: Yarp
public class GlobalFogSettingVolume
{

	// Methods

	// RVA: 0x7766184
	public object .ctor() { }

}

// Namespace: Yarp
public class ParameterInterp
{

	// Methods

	// RVA: -1
	public static object Interp(object from, object to, object factor) { }

	// RVA: 0x7766204
	public static object Interp_Int32(object from, object to, object factor) { }

	// RVA: 0x7766090
	public static object Interp_Single(object from, object to, object factor) { }

	// RVA: 0x77660A0
	public static object Interp_Vector2(object from, object to, object factor) { }

	// RVA: 0x7766234
	public static object Interp_Vector3(object from, object to, object factor) { }

	// RVA: 0x776625C
	public static object Interp_Vector4(object from, object to, object factor) { }

	// RVA: 0x7766294
	public static object Interp_Color(object from, object to, object factor) { }

	// RVA: 0x77662CC
	public static object Interp_AnimationCurve(object from, object to, object factor) { }

	// RVA: 0x77662F8
	public object .ctor() { }

}

// Namespace: Yarp
public class InterpParameterConfigAttribute
{

	// Fields
	public object enableInterp; // 0x8
	public object methodName; // 0x10

	// Methods

	// RVA: 0x7766300
	public object .ctor(object enableInterp, object customInterpMethodName) { }

}

// Namespace: Yarp
public class EditorOnlyInterpParameterAttribute
{

	// Methods

	// RVA: 0x776633C
	public object .ctor() { }

}

// Namespace: Yarp
public class RenderSettingItemAttribute
{

	// Fields
	public readonly object menuItem; // 0x8
	public readonly object name; // 0x10
	public readonly object order; // 0x18
	public readonly object generateSettingsHash; // 0x1C
	public readonly object sourcePath; // 0x20
	public readonly object hideInInspector; // 0x28

	// Methods

	// RVA: 0x7766344
	public object .ctor(object name, object generateSettingsHash, object hideInInspector, object order, object sourcePath) { }

	// RVA: 0x77663A0
	public object .ctor(object name, object menuItem, object generateSettingsHash, object hideInInspector, object order, object sourcePath) { }

}

// Namespace: Yarp
public class YARenderSettings
{

	// Fields
	private object m_commonSettting; // 0x8
	private object m_fogSetting; // 0x10
	private object m_sunSkyOcclusionSetting; // 0x18
	private object m_depthOfFieldSetting; // 0x20
	private object m_AmbientOcclusionSetting; // 0x28
	private object m_sssSetting; // 0x30
	private object m_colorGradingSetting; // 0x38
	private object m_motionBlurSetting; // 0x40
	private object m_radialBlurSetting; // 0x48
	private object m_surfaceBlurSetting; // 0x50
	private object m_afterStackSetting; // 0x58
	private object m_bloomSetting; // 0x60
	private object m_cloeupShadowSetting; // 0x68
	private object m_exposureSetting; // 0x70
	private object m_glitchSetting; // 0x78
	private object m_vignetteSetting; // 0x80
	private object m_BWFilterSetting; // 0x88
	private object m_distortionSetting; // 0x90
	private object m_temporalAAUSetting; // 0x98
	public object SunShadow; // 0xA0
	private object m_gameObject; // 0xA8
	private static object m_defaultSettingsVolume; // 0x0
	public object components; // 0xB0

	// Properties
	public object Common { get; }
	public object Fog { get; }
	public object decalSetting { get; }
	public object SunSkyOcclusion { get; }
	public object depthOfFieldSetting { get; }
	public object AmbientOcclusionSetting { get; }
	public object SSSSetting { get; }
	public object colorGradingSetting { get; }
	public object motionBlurSetting { get; }
	public object radialBlurSetting { get; }
	public object surfaceBlurSetting { get; }
	public object afterStackSetting { get; }
	public object bloomSetting { get; }
	public object closeupShadowSetting { get; }
	public object exposureSetting { get; }
	public object glitchSetting { get; }
	public object vignetteSetting { get; }
	public object BWFilterSetting { get; }
	public object distortionSetting { get; }
	public object temporalAAUSetting { get; }
	public static object DefaultSettingsVolume { get; }
	private static object s_defaultSettings { get; }
	public static object Default { get; }

	// Methods

	// RVA: 0x7766408
	public object get_Common() { }

	// RVA: 0x7766478
	public object get_Fog() { }

	// RVA: 0x77664E8
	public object get_decalSetting() { }

	// RVA: 0x7766540
	public object get_SunSkyOcclusion() { }

	// RVA: 0x77665B0
	public object get_depthOfFieldSetting() { }

	// RVA: 0x7766620
	public object get_AmbientOcclusionSetting() { }

	// RVA: 0x7766690
	public object get_SSSSetting() { }

	// RVA: 0x7766700
	public object get_colorGradingSetting() { }

	// RVA: 0x7766770
	public object get_motionBlurSetting() { }

	// RVA: 0x77667E0
	public object get_radialBlurSetting() { }

	// RVA: 0x7766850
	public object get_surfaceBlurSetting() { }

	// RVA: 0x77668C0
	public object get_afterStackSetting() { }

	// RVA: 0x7766930
	public object get_bloomSetting() { }

	// RVA: 0x77669A0
	public object get_closeupShadowSetting() { }

	// RVA: 0x7766A10
	public object get_exposureSetting() { }

	// RVA: 0x7766A80
	public object get_glitchSetting() { }

	// RVA: 0x7766AF0
	public object get_vignetteSetting() { }

	// RVA: 0x7766B60
	public object get_BWFilterSetting() { }

	// RVA: 0x7766BD0
	public object get_distortionSetting() { }

	// RVA: 0x7766C40
	public object get_temporalAAUSetting() { }

	// RVA: 0x7766CB0
	public object Init(object go) { }

	// RVA: 0x7766CB8
	private static object OnBeforeAssemblyReload() { }

	// RVA: 0x7766DEC
	public static object get_DefaultSettingsVolume() { }

	// RVA: 0x7767154
	private static object get_s_defaultSettings() { }

	// RVA: 0x776717C
	public static object get_Default() { }

	// RVA: -1
	public object GetSetting() { }

	// RVA: 0x77671A4
	public object GetSetting(object type) { }

	// RVA: 0x77674CC
	public object PureGetSetting(object type) { }

	// RVA: 0x7767550
	public object Reset() { }

	// RVA: 0x77677EC
	public static object MergeSettings(object allSettings, object cameraData, object resultSetting, object enableLocal) { }

	// RVA: 0x77690B0
	public static object MergeSettings(object allSettings, object resultSetting, object enableLocal) { }

	// RVA: 0x7768AB0
	public static object PatchSettings(object rhs, object output, object factor) { }

	// RVA: 0x77690C0
	public object ResetPostEffect() { }

	// RVA: 0x7768DC8
	public static object HasSetting(object settings, object settingType) { }

	// RVA: 0x77690C4
	public object Clone() { }

	// RVA: 0x776914C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__6_0; // 0x8
	public static object <>9__6_1; // 0x10
	public static object <>9__6_2; // 0x18

	// Methods

	// RVA: 0x776A018
	private static object .cctor() { }

	// RVA: 0x776A078
	public object .ctor() { }

	// RVA: 0x776A080
	internal object <get_objectPool>b__6_0() { }

	// RVA: 0x776A0D8
	internal object <get_objectPool>b__6_1(object go) { }

	// RVA: 0x776A210
	internal object <get_objectPool>b__6_2(object go) { }

}

// Namespace: Yarp
public class RenderSettingsVolume
{

	// Fields
	public object isGlobal; // 0x18
	public object weight; // 0x1C
	protected object m_colliders; // 0x20
	public object blendDistance; // 0x28
	private static object s_objectPool; // 0x0
	public static readonly object SupportLocalModeRendererTypes; // 0x8
	public object priority; // 0x2C
	private object m_previousPriority; // 0x30
	public object Settings; // 0x38
	private object m_version; // 0x40

	// Properties
	private static object objectPool { get; }
	public object Version { get; }

	// Methods

	// RVA: 0x7769200
	private static object get_objectPool() { }

	// RVA: 0x7766F5C
	public static object GetRenderSettingVolumeTemp() { }

	// RVA: 0x7769510
	public static object Release(object volume) { }

	// RVA: 0x7769654
	public static object SupportLocalMode(object rendererType) { }

	// RVA: 0x7769700
	public object InitVolume() { }

	// RVA: 0x776980C
	public object Copy(object target, object supportLocal) { }

	// RVA: 0x7769C4C
	public object GetColliders() { }

	// RVA: 0x7765D10
	public virtual object Awake() { }

	// RVA: 0x7769C54
	private object OnEnable() { }

	// RVA: 0x7769D24
	private object OnDisable() { }

	// RVA: 0x7769D9C
	public object GetPriority() { }

	// RVA: 0x7769DA4
	public object DataChanged() { }

	// RVA: 0x7769DC0
	public object get_Version() { }

	// RVA: 0x7769DC8
	public object AddComponent(object type, object component) { }

	// RVA: 0x7769744
	public object AssembleSettings() { }

	// RVA: 0x7765DC8
	public object .ctor() { }

	// RVA: 0x7769EC0
	private static object .cctor() { }

}

// Namespace: Yarp
public class RenderSettingsVolumeForCameraData
{

	// Methods

	// RVA: 0x776A298
	public override object Awake() { }

	// RVA: 0x776A2E0
	public object .ctor() { }

}

// Namespace: Yarp
public class RenderSettingVolumeWithoutAutoRegistry
{

	// Methods

	// RVA: 0x776A3E0
	private object OnEnable() { }

	// RVA: 0x776A468
	public object InitWithSettings(object target) { }

	// RVA: 0x776A360
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__5_0; // 0x8
	public static object <>9__5_1; // 0x10

	// Methods

	// RVA: 0x776B040
	private static object .cctor() { }

	// RVA: 0x776B0A0
	public object .ctor() { }

	// RVA: 0x776B0A8
	internal object <OnRemove>b__5_0(object t) { }

	// RVA: 0x776B12C
	internal object <OnRemove>b__5_1(object co) { }

}

// Namespace: 
private sealed class <GetModifiers>d__7
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	public object <>4__this; // 0x20
	private object updateForce; // 0x28
	public object <>3__updateForce; // 0x29
	private object includeInactive; // 0x2A
	public object <>3__includeInactive; // 0x2B
	private object <>7__wrap1; // 0x30
	private object <>7__wrap2; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.AnimateMaterial.GraphicPropertyOverride>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x776AE50
	public object .ctor(object <>1__state) { }

	// RVA: 0x776B1B0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x776B1B4
	private object MoveNext() { }

	// RVA: 0x776B72C
	private object System.Collections.Generic.IEnumerator<Yarp.AnimateMaterial.GraphicPropertyOverride>.get_Current() { }

	// RVA: 0x776B734
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x776B774
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x776B77C
	private object System.Collections.Generic.IEnumerable<Yarp.AnimateMaterial.GraphicPropertyOverride>.GetEnumerator() { }

	// RVA: 0x776B830
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: Yarp
public class AfterStackSetting
{

	// Fields
	public object Enable; // 0x30
	public object Intensity; // 0x34
	public object materials; // 0x38
	public object modifiers; // 0x40

	// Methods

	// RVA: 0x776A65C
	public object IsActivated() { }

	// RVA: 0x776A6A8
	public object OnEnable() { }

	// RVA: 0x776A7C0
	public override object OnRemove() { }

	// RVA: 0x776A72C
	public object GetModifiers(object includeInactive, object updateForce) { }

	// RVA: 0x776AE88
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776AFDC
	public object .ctor() { }

}

// Namespace: 
public enum QualityOption
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object High;
	public const object Low;
}

// Namespace: Yarp
public class AmbientOcclusionSetting
{

	// Fields
	public object Enable; // 0x30
	public object Amount; // 0x34
	public object Power; // 0x38
	public object occlusionColor; // 0x3C
	public object Quality; // 0x40
	public object MinBlurRadius; // 0x44
	public object MaxAccumulatedFrameNum; // 0x48
	public object UseReBlurLinearAccumulate; // 0x4C
	public object HitDistScale; // 0x50
	public object PostBlur; // 0x54
	public object FastHistory; // 0x55
	public object EnableSplitScreen; // 0x56
	public object SplitScreen; // 0x58
	public object leftSplit; // 0x5C
	public object rightSplit; // 0x60

	// Methods

	// RVA: 0x776B8E4
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776BB58
	public object GetSettingHash128() { }

	// RVA: 0x776BD98
	public object .ctor() { }

}

// Namespace: Yarp
public class BloomSetting
{

	// Fields
	public object Enable; // 0x30
	public object BloomThreshold; // 0x34
	public object BloomSoftKnee; // 0x38
	public object BloomIntensity; // 0x3C
	public object BloomDiffusion; // 0x40
	public object BloomFireflyRemovalStrength; // 0x44
	public object BloomClamp; // 0x48
	public object BloomTint; // 0x4C
	public object BloomHalfSizeDownsample; // 0x5C
	public object BloomQuaterSizeUpsample; // 0x5D

	// Methods

	// RVA: 0x776BE0C
	public object IsBloomActivated() { }

	// RVA: 0x776BE30
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776BF8C
	public object .ctor() { }

}

// Namespace: Yarp
public class BWFilterSetting
{

	// Fields
	public object Enable; // 0x30
	public object Intensity; // 0x34
	public object Range; // 0x38
	public object LightenColor; // 0x40
	public object DarkenColor; // 0x50

	// Methods

	// RVA: 0x776BFBC
	public object IsActivated() { }

	// RVA: 0x776BFE0
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776C120
	public object .ctor() { }

}

// Namespace: Yarp
public class CiyuanSetting
{

	// Fields
	public object LODTransitionDuration; // 0x30
	public object RenderMode; // 0x34

	// Methods

	// RVA: 0x776C144
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776C24C
	public object .ctor() { }

}

// Namespace: Yarp
public enum CiYuanMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Low;
	public const object Middle;
	public const object High;
}

// Namespace: Yarp
public enum ECloseupShadowFilter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Closeup_PCF_5x5;
}

// Namespace: Yarp
public class CloseupShadowSetting
{

	// Fields
	public object Enable; // 0x30
	public object CloseupShadowMethod; // 0x34
	public object CloseupShadowResolution; // 0x38

	// Methods

	// RVA: 0x776C260
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776C39C
	public object GetSettingHash128() { }

	// RVA: 0x776C45C
	public object .ctor() { }

}

// Namespace: 
public struct FilmStockSettings
{

	// Fields
	public object Slope; // 0xFFFFFFFFFFFFFFF8
	public object Toe; // 0xFFFFFFFFFFFFFFFC
	public object Shoulder; // 0x0
	public object BlackClip; // 0x4
	public object WhiteClip; // 0x8
}

// Namespace: 
public enum EToneCurves
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Uncharted;
	public const object HP;
	public const object Legacy;
	public const object ACES;
	public const object Custom;
}

// Namespace: Yarp
public class ColorGradingSetting
{

	// Fields
	public object TonemapMode; // 0x30
	public object LutTexture; // 0x38
	public object LutIntensity; // 0x40
	public object ColorGradingUseColorSpaceConversion; // 0x44
	public object WhiteBalanceTemperature; // 0x48
	public object WhiteBalanceTint; // 0x4C
	public object GlobalSaturation; // 0x50
	public object GlobalContrast; // 0x60
	public object GlobalGamma; // 0x70
	public object GlobalGain; // 0x80
	public object GlobalOffset; // 0x90
	public object ShadowsSaturation; // 0xA0
	public object ShadowsContrast; // 0xB0
	public object ShadowsGamma; // 0xC0
	public object ShadowsGain; // 0xD0
	public object ShadowsOffset; // 0xE0
	public object ShadowsMax; // 0xF0
	public object MidtonesSaturation; // 0xF4
	public object MidtonesContrast; // 0x104
	public object MidtonesGamma; // 0x114
	public object MidtonesGain; // 0x124
	public object MidtonesOffset; // 0x134
	public object HighlightsSaturation; // 0x144
	public object HighlightsContrast; // 0x154
	public object HighlightsGamma; // 0x164
	public object HighlightsGain; // 0x174
	public object HighlightsOffset; // 0x184
	public object HighlightsMin; // 0x194
	public object BlueCorrection; // 0x198
	public object ExpandGamut; // 0x19C
	public object ToneCurveType; // 0x1A0
	public object FilmSlope; // 0x1A4
	public object FilmToe; // 0x1A8
	public object FilmShoulder; // 0x1AC
	public object FilmBackClip; // 0x1B0
	public object FilmWhiteClip; // 0x1B4

	// Methods

	// RVA: 0x776C46C
	public object IsColorGradingActivated() { }

	// RVA: 0x776C504
	public object GetFilmStockSettings() { }

	// RVA: 0x776C57C
	private object Reset() { }

	// RVA: 0x776C584
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776C968
	public object GetSettingHash128() { }

	// RVA: 0x776D394
	public object .ctor() { }

}

// Namespace: Yarp
public enum TonemappingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ACES;
	public const object UE4;
	public const object UE3;
}

// Namespace: Yarp
public class CommonSetting
{

	// Fields
	public object ColorSpaceMode; // 0x30
	public object ScreenPercentage; // 0x34

	// Methods

	// RVA: 0x776D44C
	private object Reset() { }

	// RVA: 0x776D458
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776D560
	public object .ctor() { }

}

// Namespace: Yarp
public enum YAColorSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Gamma;
	public const object Linear;
}

// Namespace: Yarp
public enum DecalShadingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object GPUCluster;
	public const object CPUCluster;
	public const object DBuffer;
}

// Namespace: Yarp
public class DecalSetting
{

	// Fields
	public object Enable; // 0x30
	public object decalShadingType; // 0x34
	public object EnableDebugCluster; // 0x38
	public object DebugValidCluster; // 0x39
	public object DebugClusterNumber; // 0x3A
	public object DebugSurfaceDecalNumber; // 0x3B
	public object DebugClusterDepthSlice; // 0x3C

	// Methods

	// RVA: 0x776D570
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776D6F0
	public object .ctor() { }

}

// Namespace: Yarp
public class DepthOfFieldSetting
{

	// Fields
	public object Enable; // 0x30
	public object Debug; // 0x31
	public object UseCamaeraDistance; // 0x32
	public object HalfSizeDownsample; // 0x33
	public object FocalDistance; // 0x34
	public object FocalRegion; // 0x38
	public object NearRegion; // 0x3C
	public object FarRegion; // 0x40
	public object BlurRadius; // 0x44
	public object LookAt; // 0x48

	// Methods

	// RVA: 0x776D700
	public object OnValidate() { }

	// RVA: 0x776D720
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776D8A0
	public object .ctor() { }

}

// Namespace: Yarp
public class DistortionSetting
{

	// Fields
	public object Enable; // 0x30
	public object DistortionVectorBufferSize; // 0x34
	public object DistortionIntensity; // 0x38

	// Methods

	// RVA: 0x776D8BC
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776D9DC
	public object .ctor() { }

}

// Namespace: 
public enum ExposureMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Fixed;
	public const object Auto;
}

// Namespace: Yarp
public class ExposureSetting
{

	// Fields
	public object Mode; // 0x30
	public object ExposureValue; // 0x34
	public object LegacyExposureColor; // 0x38
	public object BgExposureColor; // 0x48
	public object VFXBrightnessScale; // 0x58
	public object ExposureCompensation; // 0x5C
	public object MinBrightness; // 0x60
	public object MaxBrightness; // 0x64
	public object SpeedUp; // 0x68
	public object SpeedDown; // 0x6C
	public object HistogramLogMin; // 0x70
	public object HistogramLogMax; // 0x74
	private object m_enableBloomOpt; // 0x78

	// Properties
	public object EnableBloomOpt { get; set; }

	// Methods

	// RVA: 0x776D9F8
	public object get_EnableBloomOpt() { }

	// RVA: 0x776DA00
	public object set_EnableBloomOpt(object value) { }

	// RVA: 0x776DA08
	public object IsAutoExposureEnable() { }

	// RVA: 0x776DA94
	public object GetExposureScale() { }

	// RVA: 0x776DB28
	public object GetBgExposureColor() { }

	// RVA: 0x776DBB0
	public object GetVFXBrightnessScale() { }

	// RVA: 0x776DC48
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776DDB4
	public object .ctor() { }

}

// Namespace: Yarp
public class FogSetting
{

	// Fields
	public object Enable; // 0x30
	public object FogColor; // 0x34
	public object FogColorIntensity; // 0x44
	public object FogNear; // 0x48
	public object FogFar; // 0x4C
	public object FogHeight; // 0x50
	public object FogBottom; // 0x54
	public object HorizontalOffsetFromRoot; // 0x58
	public object Root; // 0x60

	// Methods

	// RVA: 0x776DDE8
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776DF40
	public object .ctor() { }

}

// Namespace: Yarp
public class FXAASetting
{

	// Fields
	public object Enable; // 0x30
	public object Type; // 0x34
	public object LumaThresholdMin; // 0x38
	public object LumaThreshold; // 0x3C
	public object Scale; // 0x40
	public object Sharpness; // 0x50
	public object QualitySubpix; // 0x54
	public object QualityEdgeThreshold; // 0x58
	public object QualityEdgeThresholdMin; // 0x5C

	// Methods

	// RVA: 0x776DF68
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776E0BC
	public object .ctor() { }

}

// Namespace: Yarp
public enum FXAAType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Quality;
	public const object Console;
	public const object None;
}

// Namespace: Yarp
public class GlitchSetting
{

	// Fields
	public object Enable; // 0x30
	public object GlitchEffectTex; // 0x38
	public object GlitchEffectSpeed; // 0x40
	public object GlitchEffectScale; // 0x44
	public object GlitchEffectScreenHscale; // 0x48
	public object GlitchEffectDir; // 0x4C
	public object GlitchEffectMaskScale; // 0x50

	// Methods

	// RVA: 0x776E0E8
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776E224
	public object .ctor() { }

}

// Namespace: Yarp
public class JuNeiSetting
{

	// Fields
	public object mode; // 0x30

	// Methods

	// RVA: 0x776E244
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776E334
	public object .ctor() { }

}

// Namespace: Yarp
public enum JuNeiMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object HDD;
	public const object Preview;
}

// Namespace: Yarp
public class JuWaiSetting
{

	// Fields
	public object ClearDepthBg; // 0x30
	public object EnableLightingLayer; // 0x31

	// Methods

	// RVA: 0x776E33C
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776E430
	public object .ctor() { }

}

// Namespace: Yarp
public class MotionBlurSetting
{

	// Fields
	public object Enable; // 0x30
	public object Intensity; // 0x34
	public object Extend; // 0x38
	public object DirectionX; // 0x3C
	public object DirectionY; // 0x40
	public object NumIteration; // 0x44

	// Methods

	// RVA: 0x776E440
	public object IsActivated() { }

	// RVA: 0x776E464
	public object OnValidate() { }

	// RVA: 0x776E478
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776E598
	public object .ctor() { }

}

// Namespace: 
public enum EDenoiserType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Optix;
	public const object OpenImageDenoise;
}

// Namespace: Yarp
public class PathTracerSetting
{

	// Fields
	public object ResolutionScale; // 0x30
	public object Accumulation; // 0x34
	public object SamplesPerPixel; // 0x38
	public object PathLength; // 0x3C
	public object RussianRoulette; // 0x40
	public object PathRegularization; // 0x41
	public object BlueNoiseSampler; // 0x42
	public object MultipleImportanceSampling; // 0x43
	public object UseTextureLOD; // 0x44
	public object UseRadianceCache; // 0x45
	public object SharcDownscaleFactor; // 0x48
	public object SharcSceneScale; // 0x4C
	public object SharcAccumulationFrameNum; // 0x50
	public object SharcStaleFrameNum; // 0x54
	public object LightSamplingStrategy; // 0x58
	public object LightImportanceResampling; // 0x5C
	public object MISWeightedRISEstimator; // 0x5D
	public object NumEnvmapSamples; // 0x60
	public object NumAnalyticLightSamples; // 0x64
	public object NumMeshLightSamples; // 0x68
	public object DenoiserType; // 0x6C
	public object DenoiseFinalFrameOnly; // 0x70
	public object DisableDirectLight; // 0x71
	public object DebugOption; // 0x74

	// Methods

	// RVA: 0x776E5A8
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776E8F4
	public object GetSettingHash128() { }

	// RVA: 0x776EC00
	public object .ctor() { }

}

// Namespace: Yarp
public class RadialBlurSetting
{

	// Fields
	public object Enable; // 0x30
	public object Intensity; // 0x34
	public object Extend; // 0x38
	public object CenterPosX; // 0x3C
	public object CenterPosY; // 0x40
	public object NumIteration; // 0x44

	// Methods

	// RVA: 0x776EC5C
	public object IsActivated() { }

	// RVA: 0x776EC80
	public object OnValidate() { }

	// RVA: 0x776EC94
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776EDB4
	public object .ctor() { }

}

// Namespace: 
public enum RayTracingShadowType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object HardShadow;
	public const object SoftShadow;
}

// Namespace: Yarp
public class RayTracingShadowSetting
{

	// Fields
	public object Enable; // 0x30
	public object ShadowType; // 0x34
	public object Accumulation; // 0x38
	public object AngularDiameter; // 0x3C
	public object HybridShadow; // 0x40
	public object SampleCount; // 0x44

	// Methods

	// RVA: 0x776EDC4
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776EF48
	public object GetSettingHash128() { }

	// RVA: 0x776F05C
	public object .ctor() { }

}

// Namespace: Yarp
public class SurfaceBlurSetting
{

	// Fields
	public object Enable; // 0x30
	public object intensity; // 0x34
	public object radius; // 0x38
	public object range; // 0x3C
	public object threshold; // 0x40

	// Methods

	// RVA: 0x776F078
	public object IsActivated() { }

	// RVA: 0x776F09C
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776F1D4
	public object .ctor() { }

}

// Namespace: Yarp
public class TemporalAAUSetting
{

	// Fields
	public object Enable; // 0x30
	public object ScreenPercentage; // 0x34
	public object NumColorBoxSamples; // 0x38
	public object HistoryFilter; // 0x3C
	public object CheckShadingChange; // 0x40
	public object LumaConfidenceScale; // 0x44
	public object EnableDepthTest; // 0x48
	public object EnableHistoryClipConfidence; // 0x49
	public object EnableVelocityConfidence; // 0x4A
	public object MotionVelocityConfidenceScale; // 0x4C
	public object EnableHistoryContrastConfidence; // 0x50
	public object HistoryContrastConfidenceSacle; // 0x54
	public object historyClipMethod; // 0x58
	public object UpsamplingReconstructionFilterShape; // 0x5C
	public object EnableSharpen; // 0x60
	public object Sharpeness; // 0x64
	public object SharpenMethod; // 0x68
	public object SharpenWorkingColorSpace; // 0x6C
	public object Sequence; // 0x70
	public object FilterModel; // 0x74
	public object FilterSharpness; // 0x78
	public object JitterRadius; // 0x7C
	public object ColorBoxSigma; // 0x80
	public object EnableAdaptiveColorBox; // 0x84
	public object MaxColorBoxSigma; // 0x88
	public object EnableTAAU; // 0x8C
	public object Alpha; // 0x90
	public object MotionFidelityAlpha; // 0xA0
	public object EnableResponsiveAA; // 0xA4
	public object ResponsiveAAMode; // 0xA8
	public object Responsiveness; // 0xAC
	public object EnableComputeShader; // 0xBC
	public object EnableSharedMemory; // 0xBD
	public object EnableMipmapBiasing; // 0xBE
	public object TextureBias; // 0xC0
	public object BeforePostProcess; // 0xC4

	// Methods

	// RVA: 0x776F1F4
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776F6D0
	public object .ctor() { }

}

// Namespace: Yarp
public enum TAAUSampleSequence
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Halton_16x;
	public const object R2_16x;
}

// Namespace: Yarp
public enum EHistoryFilter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Bilinear;
	public const object BicubicTap5;
	public const object BicubicTap9;
}

// Namespace: Yarp
public enum EVarianceColorBoxSamples
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NumSamples5;
	public const object NumSamples9;
}

// Namespace: Yarp
public enum EResponsiveAAMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TemporalRejection;
	public const object ModulatedFeedback;
}

// Namespace: Yarp
public enum HistoryClipMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Clamp;
	public const object Clip;
}

// Namespace: Yarp
public enum SharpenMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CAS;
	public const object RCAS;
	public const object LumaSharpening;
}

// Namespace: Yarp
public enum SharpenWorkingColorSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object YCgCo;
	public const object Linear;
}

// Namespace: Yarp
public enum ReconstructionFilterShape
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Tap5;
	public const object Tap9;
}

// Namespace: Yarp
public class VignetteSetting
{

	// Fields
	public object Enable; // 0x30
	public object VignetteColor; // 0x34
	public object VignetteCenter; // 0x44
	public object VignetteIntensity; // 0x4C
	public object VignetteSmoothness; // 0x50
	public object VignetteRounded; // 0x54

	// Methods

	// RVA: 0x776F764
	public object IsVignetteActivated() { }

	// RVA: 0x776F784
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776F8C8
	public object .ctor() { }

}

// Namespace: Yarp
public enum VisibilityIntegratorType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AmbientOcclusion;
	public const object SphericalHarmonicsAO;
	public const object SpecularOcclusion;
}

// Namespace: Yarp
public class VisibilityIntegratorSetting
{

	// Fields
	public object Accumulation; // 0x30
	public object NumSamples; // 0x34
	public object MaxOcclusionRadius; // 0x38
	public object Type; // 0x3C
	public object CosineWeightAO; // 0x40
	public object UseDistanceAttenuation; // 0x41
	public object DistanceAttenuation; // 0x44
	public object SquaredDistanceAttenuation; // 0x48

	// Methods

	// RVA: 0x776F8F8
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776FA94
	public object GetSettingHash128() { }

	// RVA: 0x776FBE0
	public object .ctor() { }

}

// Namespace: Yarp
public class YASubsurfaceScatteringSetting
{

	// Fields
	public object Enable; // 0x30
	public object DevelopmentMode; // 0x31
	public object ScatteringMode; // 0x34
	public object ProfileMode; // 0x38
	public object NumofCascade; // 0x3C
	public object LowerCascadeResolution; // 0x40
	public object DynamicRTSize; // 0x41
	public object IncidentLightClip; // 0x42

	// Methods

	// RVA: 0x776FC08
	public object OnValidate() { }

	// RVA: 0x776FC88
	private object IsDeveloperModeEnabled() { }

	// RVA: 0x776FC90
	protected override object InterpTo(object setting, object factor) { }

	// RVA: 0x776FE58
	public object .ctor() { }

}

// Namespace: Yarp
public class BufferedRTHandleSystem
{

	// Fields
	private object m_RTHandles; // 0x8
	private object m_RTHandleSystem; // 0x10
	private object m_DisposedValue; // 0x18

	// Properties
	public object maxWidth { get; }
	public object maxHeight { get; }
	public object rtHandleProperties { get; }

	// Methods

	// RVA: 0x776FE7C
	public object get_maxWidth() { }

	// RVA: 0x776FEA0
	public object get_maxHeight() { }

	// RVA: 0x776FEC4
	public object get_rtHandleProperties() { }

	// RVA: 0x776FEF8
	public object GetFrameRT(object bufferId, object frameIndex) { }

	// RVA: 0x776FFE0
	public object AllocBuffer(object bufferId, object allocator, object bufferCount) { }

	// RVA: 0x77702E4
	public object ReleaseBuffer(object bufferId) { }

	// RVA: 0x7770414
	public object SwapAndSetReferenceSize(object width, object height) { }

	// RVA: 0x7770758
	public object ResetReferenceSize(object width, object height) { }

	// RVA: 0x777078C
	public object GetNumFramesAllocated(object bufferId) { }

	// RVA: 0x7770848
	public object CalculateRatioAgainstMaxSize(object width, object height) { }

	// RVA: 0x7770464
	private object Swap() { }

	// RVA: 0x7770B9C
	private object Dispose(object disposing) { }

	// RVA: 0x7770EC8
	public object Dispose() { }

	// RVA: 0x7770BF4
	public object ReleaseAll() { }

	// RVA: 0x7770F18
	public object .ctor() { }

}

// Namespace: Yarp
public enum DepthBits
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Depth8;
	public const object Depth16;
	public const object Depth24;
	public const object Depth32;
}

// Namespace: Yarp
public sealed class PerformDynamicRes
{

	// Methods

	// RVA: 0x77710D4
	public object .ctor(object object, object method) { }

	// RVA: 0x7771168
	public virtual object Invoke() { }

	// RVA: 0x777117C
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0x77711D4
	public virtual object EndInvoke(object result) { }

}

// Namespace: Yarp
public enum DynamicResolutionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Hardware;
}

// Namespace: Yarp
public enum DynamicResScalePolicyType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ReturnsPercentage;
	public const object ReturnsMinMaxLerpFactor;
}

// Namespace: Yarp
public enum DynamicResScalerSlot
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object User;
	public const object System;
	public const object Count;
}

// Namespace: Yarp
public enum DynamicResUpscaleFilter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Bilinear;
	public const object CatmullRom;
}

// Namespace: 
private struct ScalerContainer
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object method; // 0x0
}

// Namespace: 
public enum UpsamplerScheduleType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BeforePost;
	public const object AfterDepthOfField;
	public const object AfterPost;
}

// Namespace: Yarp
public class DynamicResolutionHandler
{

	// Fields
	private object m_Enabled; // 0x8
	private object m_UseMipBias; // 0x9
	private object m_MinScreenFraction; // 0xC
	private object m_MaxScreenFraction; // 0x10
	private object m_CurrentFraction; // 0x14
	private object m_ForcingRes; // 0x18
	private object m_CurrentCameraRequest; // 0x19
	private object m_PrevFraction; // 0x1C
	private object m_ForceSoftwareFallback; // 0x20
	private object m_RunUpscalerFilterOnFullResolution; // 0x21
	private object m_PrevHWScaleWidth; // 0x24
	private object m_PrevHWScaleHeight; // 0x28
	private object m_LastScaledSize; // 0x2C
	private static object s_ActiveScalerSlot; // 0x0
	private static object s_ScalerContainers; // 0x8
	private object cachedOriginalSize; // 0x34
	private object <filter>k__BackingField; // 0x3C
	private static object s_CameraUpscaleFilters; // 0x10
	private object <finalViewport>k__BackingField; // 0x40
	private object type; // 0x48
	private const object CameraDictionaryMaxcCapacity;
	private object m_OwnerCameraWeakRef; // 0x50
	private static object s_CameraInstances; // 0x18
	private static object s_DefaultInstance; // 0x20
	private static object s_ActiveCameraId; // 0x28
	private static object s_ActiveInstance; // 0x30
	private static object s_ActiveInstanceDirty; // 0x38
	private static object s_GlobalHwFraction; // 0x3C
	private static object s_GlobalHwUpresActive; // 0x40
	private object m_UpsamplerSchedule; // 0x58

	// Properties
	public object filter { get; set; }
	public object finalViewport { get; set; }
	public object runUpscalerFilterOnFullResolution { get; set; }
	public object upsamplerSchedule { get; set; }
	public static object instance { get; }

	// Methods

	// RVA: 0x7771208
	private object Reset() { }

	// RVA: 0x7771244
	public object get_filter() { }

	// RVA: 0x777124C
	private object set_filter(object value) { }

	// RVA: 0x7771254
	public object get_finalViewport() { }

	// RVA: 0x777125C
	public object set_finalViewport(object value) { }

	// RVA: 0x7771264
	public object set_runUpscalerFilterOnFullResolution(object value) { }

	// RVA: 0x777126C
	public object get_runUpscalerFilterOnFullResolution() { }

	// RVA: 0x7771274
	private object FlushScalableBufferManagerState() { }

	// RVA: 0x7771470
	private static object GetOrCreateDrsInstanceHandler(object camera) { }

	// RVA: 0x7771A14
	public object set_upsamplerSchedule(object value) { }

	// RVA: 0x7771A1C
	public object get_upsamplerSchedule() { }

	// RVA: 0x7771A24
	public static object get_instance() { }

	// RVA: 0x77719B0
	private object .ctor() { }

	// RVA: 0x7771AA0
	private static object DefaultDynamicResMethod() { }

	// RVA: 0x7771AA8
	public object GetResolvedScale() { }

	// RVA: 0x7771B28
	public object CalculateMipBias(object inputResolution, object outputResolution, object forceApply) { }

	// RVA: 0x7771BD8
	public static object SetDynamicResScaler(object scaler, object scalerType) { }

	// RVA: 0x7771C80
	public static object SetSystemDynamicResScaler(object scaler, object scalerType) { }

	// RVA: 0x7771D2C
	public static object SetActiveDynamicScalerSlot(object slot) { }

	// RVA: 0x7771DB8
	public static object ClearSelectedCamera() { }

	// RVA: 0x7771E24
	public static object SetUpscaleFilter(object camera, object filter) { }

	// RVA: 0x7771F8C
	public object SetCurrentCameraRequest(object cameraRequest) { }

	// RVA: 0x7771F94
	public object SoftwareDynamicResIsEnabled() { }

	// RVA: 0x7771438
	public object HardwareDynamicResIsEnabled() { }

	// RVA: 0x7771F9C
	public object RequestsHardwareDynamicResolution() { }

	// RVA: 0x7771FBC
	public object DynamicResolutionEnabled() { }

	// RVA: 0x7772004
	public object ForceSoftwareFallback() { }

	// RVA: 0x7772010
	public object GetScaledSize(object size) { }

	// RVA: 0x77720AC
	public object ApplyScalesOnSize(object size) { }

	// RVA: 0x7772144
	internal object ApplyScalesOnSize(object size, object scales) { }

	// RVA: 0x77722B8
	public object GetCurrentScale() { }

	// RVA: 0x77722DC
	public object GetLastScaledSize() { }

	// RVA: 0x77722E4
	public object GetLowResMultiplier(object targetLowRes) { }

	// RVA: 0x7772390
	public object GetLowResMultiplier(object targetLowRes, object minimumThreshold) { }

	// RVA: 0x7772448
	private static object .cctor() { }

}

// Namespace: Yarp
public enum DepthTextureFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object D16;
	public const object D24S8;
	public const object D32;
}

// Namespace: Yarp
public struct ColorTargetDesc
{

	// Fields
	public object format; // 0xFFFFFFFFFFFFFFF8
	public object filterMode; // 0xFFFFFFFFFFFFFFFC
	public object sRGB; // 0x0
	public object useMipmap; // 0x1
	public object allowUav; // 0x2
	public object autoGenerateMips; // 0x3

	// Methods

	// RVA: 0x7772804
	public object .ctor(object format, object filterMode, object sRGB, object useMipmap, object allowUav, object autoGenerateMips) { }

}

// Namespace: Yarp
public struct DepthTargetDesc
{

	// Fields
	public object format; // 0xFFFFFFFFFFFFFFF8
	public object allowUav; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: 
public class Desc
{

	// Fields
	public object numOfColorTargets; // 0x8
	public object hasDepthStencilTarget; // 0xC
	public object multiSamples; // 0x10
	public object colorTargets; // 0x18
	public object depthStencilTarget; // 0x20

	// Methods

	// RVA: 0x7773A38
	public object SetColorTarget(object idx, object desc) { }

	// RVA: 0x7773AF8
	public object SetColorTarget(object idx, object format, object filterMode, object sRGB, object useMipmap, object allowUav, object autoGenerateMips) { }

	// RVA: 0x7773C04
	public object SetDepthStencilTarget(object format, object allowUav) { }

	// RVA: 0x7773C18
	public object SetMultiSamples(object samples) { }

	// RVA: 0x7773C90
	public object .ctor() { }

}

// Namespace: 
private class RenderTextureWrapper
{

	// Fields
	public object tex; // 0x8
	public object owner; // 0x10

	// Methods

	// RVA: 0x77733A8
	public object .ctor() { }

}

// Namespace: Yarp
public class FBO
{

	// Fields
	public object name; // 0x8
	private object m_colorTextures; // 0x10
	private object m_depthTexture; // 0x18
	private readonly object m_fboDesc; // 0x20
	private object m_width; // 0x28
	private object m_height; // 0x2C
	private object m_useMemorylessDepth; // 0x30
	private object m_useMemorylessMSAA; // 0x31

	// Properties
	public object fboDesc { get; }

	// Methods

	// RVA: 0x7772860
	public object get_fboDesc() { }

	// RVA: 0x7772868
	public static object Create() { }

	// RVA: 0x77729C8
	public static object Create(object d, object w, object h, object name) { }

	// RVA: 0x777292C
	public object .ctor(object d, object width, object height, object name) { }

	// RVA: 0x77730F0
	public object Dispose() { }

	// RVA: 0x77730F4
	private object Cleanup() { }

	// RVA: 0x7772A9C
	public object Resize(object w, object h, object useMemorylessDepth, object useMemorylessMSAA) { }

	// RVA: 0x77733B0
	public object GetTexelSize() { }

	// RVA: 0x77733CC
	public object GetWidth() { }

	// RVA: 0x77733D4
	public object GetHeight() { }

	// RVA: 0x77733DC
	public object GetMultiSamples() { }

	// RVA: 0x7773400
	public object GetNumColorTargets() { }

	// RVA: 0x7773454
	public object GetColorTarget(object i) { }

	// RVA: 0x77734F0
	public object GetDepthStencilTarget() { }

	// RVA: 0x7773508
	public object AttachColorTarget(object idx, object rt) { }

	// RVA: 0x77738D8
	public object AttachDepthStencilTarget(object rt) { }

	// RVA: 0x7773988
	public object DetachDepthStencilTarget() { }

	// RVA: 0x7773990
	public object GetColorTargetFormat(object i) { }

	// RVA: 0x77739E4
	public object GetColorTargetIsSrgb(object i) { }

}

// Namespace: Yarp
public static class RenderTextureExtensions
{

	// Methods

	// RVA: 0x7773CFC
	public static object GetRect(object renderTexture) { }

}

// Namespace: Yarp
public struct GfxCullingResults
{

	// Fields
	public object IsValid; // 0xFFFFFFFFFFFFFFF8
	public object Result; // 0x0

	// Methods

	// RVA: 0x7773DB8
	public object .ctor(object result) { }

	// RVA: 0x7773DD8
	public object GetVisibleLightIndex(object light) { }

	// RVA: 0x7773EF0
	public object ShadowCasterBoundsVisibility(object aLight) { }

	// RVA: 0x7774040
	public object ShadowCasterBoundsVisibility(object lightIdx) { }

	// RVA: 0x77740C8
	public object GetShadowCasterBounds(object lightIdx, object outBounds) { }

	// RVA: 0x77741F0
	public static object op_Implicit(object cullingResults) { }

}

// Namespace: Yarp
public struct GfxRenderContext
{

	// Fields
	private object m_renderPipeline; // 0xFFFFFFFFFFFFFFF8
	private object m_context; // 0x0
	private static object s_cullingResults; // 0x0
	private static object s_invalidCullingResults; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object RenderContext { get; }

	// Methods

	// RVA: 0x77742D0
	public object get_RenderContext() { }

	// RVA: 0x77742E0
	public object .ctor(object renderPipeline, object context) { }

	// RVA: 0x77742F0
	public object CreateRendererList(object desc) { }

	// RVA: 0x7774440
	public object CreateRendererList(object desc, object flags) { }

	// RVA: 0x7774758
	public object CreateRendererList(object cameraData, object desc, object flags) { }

	// RVA: 0x7774948
	public object UpdateCullingResults(object camera) { }

	// RVA: 0x77749C4
	public object GetCullingResults(object camera, object isUIOpt) { }

	// RVA: 0x7774EE4
	public object HasCullingResults(object camera) { }

	// RVA: 0x7774FAC
	public static object ClearAllCullingResults() { }

	// RVA: 0x7775048
	private object SetupCameraProperties(object camera, object commands) { }

	// RVA: 0x77751D8
	public object SetupCameraProperties(object camera, object commands, object target, object ForceUseCameraViewport, object cbLoadAction, object cbStoreAction, object dsLoadAction, object dsStoreAction) { }

	// RVA: 0x77755A0
	public object SetupCameraProperties(object camera, object commands, object target, object ForceUseCameraViewport, object cbLoadAction, object cbStoreAction, object dsLoadAction, object dsStoreAction) { }

	// RVA: 0x7775A6C
	public object ExecuteCommandBuffer(object commandBuffer, object clearAfterExec) { }

	// RVA: 0x7775BF4
	public object Submit() { }

	// RVA: 0x7775D04
	private static object .cctor() { }

}

// Namespace: Yarp
public static class LightweightProfilerWrapper
{

	// Methods

	// RVA: 0x7775D98
	public static object BeginDraw(object camera) { }

	// RVA: 0x7775D9C
	public static object EndDraw(object camera) { }

	// RVA: 0x7774ED4
	public static object BeginCull(object camera) { }

	// RVA: 0x7774ED8
	public static object EndCull(object camera) { }

	// RVA: 0x7775DA0
	public static object BeginRender(object name) { }

	// RVA: 0x7775DA4
	public static object EndRender(object name) { }

}

// Namespace: Yarp
public enum MSAASamples
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object MSAA2x;
	public const object MSAA4x;
	public const object MSAA8x;
}

// Namespace: Yarp
public class PingPongFBO
{

	// Fields
	private object m_ping; // 0x8
	private object m_pong; // 0x10
	private object m_index; // 0x18

	// Properties
	public object Current { get; }
	public object Previous { get; }

	// Methods

	// RVA: 0x7775DA8
	public object .ctor(object d, object name) { }

	// RVA: 0x7775F34
	public object .ctor(object mPing, object mPong) { }

	// RVA: 0x7775F6C
	public object get_Current() { }

	// RVA: 0x7775F88
	public object get_Previous() { }

	// RVA: 0x7775FA4
	public object Swap() { }

	// RVA: 0x7775FB4
	public object Resize(object w, object h, object useMemorylessDepth, object useMemorylessMSAA) { }

	// RVA: 0x777602C
	public object Dispose() { }

}

// Namespace: Yarp
public struct ProfilingSample
{

	// Methods

	// RVA: 0x7776068
	public object .ctor(object cmd, object marker) { }

	// RVA: 0x7776070
	public object Dispose() { }

}

// Namespace: Yarp
public class RenderTargetBuffer
{

	// Fields
	private static readonly object kScreenTileDim; // 0x0
	private static readonly object kScreenTileBits; // 0x4
	private object m_stride; // 0x8
	private object m_screenTiles; // 0xC
	private object m_buffer; // 0x18

	// Properties
	public object RenderBuffer { get; }
	public object ScreenTiles { get; }

	// Methods

	// RVA: 0x7776078
	public object get_RenderBuffer() { }

	// RVA: 0x7776080
	public object get_ScreenTiles() { }

	// RVA: 0x7776088
	public object Dispose() { }

	// RVA: 0x777609C
	public object .ctor(object sizeInBytes) { }

	// RVA: 0x777610C
	public object Resize(object w, object h) { }

	// RVA: 0x77762D8
	private static object .cctor() { }

}

// Namespace: Yarp
public struct RTHandleStaticHelpers
{

	// Fields
	public static object s_RTHandleWrapper; // 0x0

	// Methods

	// RVA: 0x777632C
	public static object SetRTHandleStaticWrapper(object rtId) { }

	// RVA: 0x7776554
	public static object SetRTHandleUserManagedWrapper(object rtWrapper, object rtId) { }

}

// Namespace: Yarp
public class RTHandle
{

	// Fields
	internal object m_Owner; // 0x8
	internal object m_RT; // 0x10
	internal object m_ExternalTexture; // 0x18
	internal object m_NameID; // 0x20
	internal object m_EnableMSAA; // 0x48
	internal object m_EnableRandomWrite; // 0x49
	internal object m_EnableHWDynamicScale; // 0x4A
	internal object m_Name; // 0x50
	internal object m_UseCustomHandleScales; // 0x58
	internal object m_CustomHandleProperties; // 0x5C
	private object <scaleFactor>k__BackingField; // 0x8C
	internal object scaleFunc; // 0x98
	private object <useScaling>k__BackingField; // 0xA0
	private object <referenceSize>k__BackingField; // 0xA4

	// Properties
	public object scaleFactor { get; set; }
	public object useScaling { get; set; }
	public object referenceSize { get; set; }
	public object rtHandleProperties { get; }
	public object rt { get; }
	public object nameID { get; }
	public object name { get; }
	public object isMSAAEnabled { get; }

	// Methods

	// RVA: 0x7776724
	public object SetCustomHandleProperties(object properties) { }

	// RVA: 0x7776744
	public object ClearCustomHandleProperties() { }

	// RVA: 0x777674C
	public object get_scaleFactor() { }

	// RVA: 0x7776754
	internal object set_scaleFactor(object value) { }

	// RVA: 0x777675C
	public object get_useScaling() { }

	// RVA: 0x7776764
	internal object set_useScaling(object value) { }

	// RVA: 0x777676C
	public object get_referenceSize() { }

	// RVA: 0x7776774
	internal object set_referenceSize(object value) { }

	// RVA: 0x777677C
	public object get_rtHandleProperties() { }

	// RVA: 0x77767D0
	public object get_rt() { }

	// RVA: 0x77767D8
	public object get_nameID() { }

	// RVA: 0x77767EC
	public object get_name() { }

	// RVA: 0x77767F4
	public object get_isMSAAEnabled() { }

	// RVA: 0x77767FC
	internal object .ctor(object owner) { }

	// RVA: 0x7776828
	public static object op_Implicit(object handle) { }

	// RVA: 0x7776850
	public static object op_Implicit(object handle) { }

	// RVA: 0x77768E0
	public static object op_Implicit(object handle) { }

	// RVA: 0x77768EC
	internal object SetRenderTexture(object rt) { }

	// RVA: 0x777693C
	internal object SetTexture(object tex) { }

	// RVA: 0x777653C
	internal object SetTexture(object tex) { }

	// RVA: 0x777698C
	public object GetInstanceID() { }

	// RVA: 0x7776AA4
	public object Release() { }

	// RVA: 0x7776C00
	public object GetScaledSize(object refSize) { }

	// RVA: 0x7776E58
	public object GetScaledSize() { }

	// RVA: 0x77770B8
	public object SwitchToFastMemory(object cmd, object residencyFraction, object flags, object copyContents) { }

	// RVA: 0x777714C
	public object CopyToFastMemory(object cmd, object residencyFraction, object flags) { }

	// RVA: 0x77771D4
	public object SwitchOutFastMemory(object cmd, object copyContents) { }

}

// Namespace: Yarp
public static class RTHandles
{

	// Fields
	private static object s_DefaultInstance; // 0x0

	// Properties
	public static object maxWidth { get; }
	public static object maxHeight { get; }
	public static object rtHandleProperties { get; }

	// Methods

	// RVA: 0x7777234
	public static object get_maxWidth() { }

	// RVA: 0x77772BC
	public static object get_maxHeight() { }

	// RVA: 0x7777344
	public static object get_rtHandleProperties() { }

	// RVA: 0x77773E8
	public static object Alloc(object width, object height, object slices, object depthBufferBits, object colorFormat, object filterMode, object wrapMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x77775C8
	public static object Alloc(object width, object height, object wrapModeU, object wrapModeV, object wrapModeW, object slices, object depthBufferBits, object colorFormat, object filterMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x7777CD0
	public static object Alloc(object descriptor, object filterMode, object wrapMode, object isShadowMap, object anisoLevel, object mipMapBias, object name) { }

	// RVA: 0x7777F14
	public static object Alloc(object scaleFactor, object slices, object depthBufferBits, object colorFormat, object filterMode, object wrapMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x77783B0
	public static object Alloc(object scaleFactor, object descriptor, object filterMode, object wrapMode, object isShadowMap, object anisoLevel, object mipMapBias, object name) { }

	// RVA: 0x77785F0
	public static object Alloc(object scaleFunc, object slices, object depthBufferBits, object colorFormat, object filterMode, object wrapMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x77788EC
	public static object Alloc(object scaleFunc, object descriptor, object filterMode, object wrapMode, object isShadowMap, object anisoLevel, object mipMapBias, object name) { }

	// RVA: 0x7778B84
	public static object Alloc(object tex) { }

	// RVA: 0x7778CE8
	public static object Alloc(object tex) { }

	// RVA: 0x7776400
	public static object Alloc(object tex) { }

	// RVA: 0x7778F20
	public static object Alloc(object tex, object name) { }

	// RVA: 0x77790D8
	private static object Alloc(object tex) { }

	// RVA: 0x777914C
	public static object Initialize(object width, object height) { }

	// RVA: 0x77794D0
	public static object Initialize(object width, object height, object useLegacyDynamicResControl) { }

	// RVA: 0x77795BC
	public static object Release(object rth) { }

	// RVA: 0x7779664
	public static object SetHardwareDynamicResolutionState(object hwDynamicResRequested) { }

	// RVA: 0x7779904
	public static object SetReferenceSize(object width, object height) { }

	// RVA: 0x77799A4
	public static object ResetReferenceSize(object width, object height) { }

	// RVA: 0x7779A48
	public static object CalculateRatioAgainstMaxSize(object width, object height) { }

	// RVA: 0x7779B04
	private static object .cctor() { }

}

// Namespace: Yarp
public sealed class ScaleFunc
{

	// Methods

	// RVA: 0x7779C00
	public object .ctor(object object, object method) { }

	// RVA: 0x7779C98
	public virtual object Invoke(object size) { }

	// RVA: 0x7779CAC
	public virtual object BeginInvoke(object size, object callback, object object) { }

	// RVA: 0x7779D68
	public virtual object EndInvoke(object result) { }

}

// Namespace: Yarp
public struct RTHandleProperties
{

	// Fields
	public object previousViewportSize; // 0xFFFFFFFFFFFFFFF8
	public object previousRenderTargetSize; // 0x0
	public object currentViewportSize; // 0x8
	public object currentRenderTargetSize; // 0x10
	public object rtHandleScale; // 0x18
}

// Namespace: 
internal enum ResizeMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object OnDemand;
}

// Namespace: Yarp
public class RTHandleSystem
{

	// Fields
	private object m_HardwareDynamicResRequested; // 0x8
	private object m_AutoSizedRTs; // 0x10
	private object m_AutoSizedRTsArray; // 0x18
	private object m_ResizeOnDemandRTs; // 0x20
	private object m_RTHandleProperties; // 0x28
	private object m_MaxWidths; // 0x58
	private object m_MaxHeights; // 0x5C

	// Properties
	public object rtHandleProperties { get; }

	// Methods

	// RVA: 0x7779D9C
	public object get_rtHandleProperties() { }

	// RVA: 0x7770FC8
	public object .ctor() { }

	// RVA: 0x7770EC0
	public object Dispose() { }

	// RVA: 0x77791E8
	public object Initialize(object width, object height) { }

	// RVA: 0x777958C
	public object Initialize(object width, object height, object useLegacyDynamicResControl) { }

	// RVA: 0x7770404
	public object Release(object rth) { }

	// RVA: 0x7776B94
	internal object Remove(object rth) { }

	// RVA: 0x7770780
	public object ResetReferenceSize(object width, object height) { }

	// RVA: 0x7770750
	public object SetReferenceSize(object width, object height) { }

	// RVA: 0x777A024
	public object SetReferenceSize(object width, object height, object reset) { }

	// RVA: 0x7770888
	internal object CalculateRatioAgainstMaxSize(object viewportSize) { }

	// RVA: 0x77796F8
	public object SetHardwareDynamicResolutionState(object enableHWDynamicRes) { }

	// RVA: 0x7770188
	internal object SwitchResizeMode(object rth, object mode) { }

	// RVA: 0x777A59C
	private object DemandResize(object rth) { }

	// RVA: 0x777A88C
	public object GetMaxWidth() { }

	// RVA: 0x777A894
	public object GetMaxHeight() { }

	// RVA: 0x7779DB4
	private object Dispose(object disposing) { }

	// RVA: 0x777A208
	private object Resize(object width, object height, object sizeChanged) { }

	// RVA: 0x7777534
	public object Alloc(object width, object height, object slices, object depthBufferBits, object colorFormat, object filterMode, object wrapMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x7777718
	public object Alloc(object width, object height, object wrapModeU, object wrapModeV, object wrapModeW, object slices, object depthBufferBits, object colorFormat, object filterMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x77780E4
	public object Alloc(object scaleFactor, object slices, object depthBufferBits, object colorFormat, object filterMode, object wrapMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x77787A8
	public object Alloc(object scaleFunc, object slices, object depthBufferBits, object colorFormat, object filterMode, object wrapMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x777A89C
	private object AllocAutoSizedRenderTexture(object width, object height, object slices, object depthBufferBits, object colorFormat, object filterMode, object wrapMode, object dimension, object enableRandomWrite, object useMipMap, object autoGenerateMips, object isShadowMap, object anisoLevel, object mipMapBias, object msaaSamples, object bindTextureMS, object useDynamicScale, object memoryless, object vrUsage, object name) { }

	// RVA: 0x7778D7C
	public object Alloc(object texture) { }

	// RVA: 0x7778C18
	public object Alloc(object texture) { }

	// RVA: 0x7778E4C
	public object Alloc(object texture) { }

	// RVA: 0x7779034
	public object Alloc(object texture, object name) { }

	// RVA: 0x777AE50
	private static object Alloc(object tex) { }

	// RVA: 0x777AEC4
	internal object DumpRTInfo() { }

}

// Namespace: Yarp
public struct ScopedCommandBuffer
{

	// Fields
	private static object s_commands; // 0x0

	// Methods

	// RVA: 0x777B228
	public object .ctor(object name) { }

	// RVA: 0x777B22C
	public object Get() { }

	// RVA: 0x777B2A8
	public static object op_Implicit(object c) { }

	// RVA: 0x777B324
	public object Dispose() { }

	// RVA: 0x777B404
	private static object .cctor() { }

}

// Namespace: Yarp
public class TypedConstantBuffer<T0>
{

	// Fields
	public object Value; // 0x0
	private object m_disposed; // 0x0
	private object m_name; // 0x0
	private object m_buffer; // 0x0
	private object m_valueCopy; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object SendToGPU(object cmd, object shader, object updateBufferContents) { }

	// RVA: -1
	public object SendToGPU(object cmd, object updateBufferContents) { }

	// RVA: -1
	protected override object Finalize() { }

	// RVA: -1
	private object Dispose(object disposing) { }

}

// Namespace: Yarp
public static class AdrenoLRZWorkaround
{

	// Fields
	private static object s_initialized; // 0x0
	private static object s_needsWorkaround; // 0x1
	private static object s_dummyMaterial; // 0x8

	// Properties
	public static object NeedsWorkaround { get; }

	// Methods

	// RVA: 0x777B4AC
	public static object Initialize() { }

	// RVA: 0x777B608
	private static object CreateDummyResources() { }

	// RVA: 0x777B60C
	public static object get_NeedsWorkaround() { }

	// RVA: 0x777B68C
	public static object ExecuteAfterDepthClear(object cmd) { }

	// RVA: 0x777B83C
	public static object Cleanup() { }

}

// Namespace: Yarp
public struct BakeLightInfo
{

	// Fields
	public object LightPosition; // 0xFFFFFFFFFFFFFFF8
	public object InverseSquaredDistanceAttenuation; // 0x4
	public object LightIntensity; // 0x8
	public object SpotLightAngularFalloffScale; // 0x14
	public object LightDirection; // 0x18
	public object SpotLightAngularFalloffOffset; // 0x24
}

// Namespace: Yarp
public static class BakeLightInfoDefines
{

	// Fields
	public const object kMaxNumOfBakingLightsForPreview;
}

// Namespace: Yarp
public static class ColorMatrix
{

	// Methods

	// RVA: 0x777B900
	public static object Brightness(object brightness) { }

	// RVA: 0x777B98C
	public static object Brightness(object brightness) { }

	// RVA: 0x777BA28
	public static object Contrast(object contrast) { }

	// RVA: 0x777BAC4
	public static object Saturation(object saturation, object luminanceContribution) { }

	// RVA: 0x777BBD4
	public static object Saturation(object saturation) { }

	// RVA: 0x777BD08
	public static object HueRotate(object angle) { }

}

// Namespace: Yarp
public static class CommonUtils
{

	// Fields
	private static object s_lstMaterialsProxy; // 0x0
	private static object m_allCameras; // 0x8
	private static object m_allCamerasCount; // 0x10
	public static readonly object CubemapForwardVectors; // 0x18
	public static readonly object CubemapUpVectors; // 0x20
	private static object s_ShaderTagId_Meta; // 0x28
	private static object s_ShaderTagId_ShadowCaster; // 0x2C
	private static object s_ShaderTagId_MotionVectors; // 0x30
	private static object s_ShaderTagId_ForwardGBuffer; // 0x34
	private static object s_ShaderTagId_ForwardBase; // 0x38
	private static object s_ShaderTagId_Outline; // 0x3C
	private static object s_ShaderTagId_Reflection; // 0x40
	private static object s_ShaderTagId_TransparentDepthPostpass; // 0x44
	private static object s_ShaderTagId_TransparentDepthPrepass; // 0x48
	private static object s_ShaderTagId_RayTracingGBuffer; // 0x4C
	private static object s_ShaderTagId_PathTracingDXR; // 0x50
	private static object s_ShaderTagId_Vertex; // 0x54
	private static object s_ShaderTagId_TransparentMotion; // 0x58
	private static object s_ShaderTagId_PreZ; // 0x5C
	private static object s_ShaderTagId_Subsurface; // 0x60
	private static object s_ShaderTagId_SRPDefaultUnlit; // 0x64
	public static object s_ShaderTagId_ForwardBase_SRPDefaultUnlit; // 0x68
	private static object s_renderTargetBindings; // 0x70
	private static object s_placeholderGraphicsBuffer; // 0x78
	private static object s_placeholderComputeBuffer; // 0x80
	private static object s_unitSphereMesh; // 0x88

	// Properties
	public static object PlaceholderGraphicsBuffer { get; }
	public static object PlaceholderComputeBuffer { get; }

	// Methods

	// RVA: 0x777BE70
	public static object GetRenderTargetAutoName(object width, object height, object depth, object format, object name, object mips, object enableMSAA, object msaaSamples) { }

	// RVA: 0x777C204
	public static object GetRenderTargetAutoName(object width, object height, object depth, object format, object name, object mips, object enableMSAA, object msaaSamples) { }

	// RVA: 0x777C304
	public static object GetRenderTargetAutoName(object width, object height, object depth, object format, object dim, object name, object mips, object enableMSAA, object msaaSamples, object dynamicRes, object dynamicResExplicit) { }

	// RVA: 0x777BF70
	private static object GetRenderTargetAutoName(object width, object height, object depth, object format, object dim, object name, object mips, object enableMSAA, object msaaSamples, object dynamicRes, object dynamicResExplicit) { }

	// RVA: -1
	public static object Swap(object lhs, object rhs) { }

	// RVA: -1
	public static object Insert(object array, object data, object idx) { }

	// RVA: -1
	public static object Find(object array, object data) { }

	// RVA: 0x777C41C
	public static object Luminance_sRGB(object color) { }

	// RVA: 0x777C458
	public static object Luminance_sRGB(object color) { }

	// RVA: 0x777C494
	public static object CalcNumOfMipmaps(object size) { }

	// RVA: 0x777C520
	public static object BitfieldSetUInt(object data, object offset, object numBits, object value) { }

	// RVA: 0x777C540
	public static object BitfieldGetUInt(object data, object offset, object numBits) { }

	// RVA: 0x777C554
	public static object DivideRoundUp(object numerator, object denominator) { }

	// RVA: 0x777C5C8
	public static object DivideRoundUp(object numerator, object denominator) { }

	// RVA: 0x777C63C
	public static object Scanline2D(object linearizeIndex, object width) { }

	// RVA: 0x777C64C
	public static object UnityNearClipValue() { }

	// RVA: 0x777C674
	public static object NextPowerOfTwo(object value) { }

	// RVA: 0x777C6A8
	public static object DivIntCeil(object x, object y) { }

	// RVA: 0x777C6B8
	public static object Vector4(object b, object w) { }

	// RVA: 0x777C6BC
	public static object Vector4(object a, object b) { }

	// RVA: 0x777C6C0
	public static object get_PlaceholderGraphicsBuffer() { }

	// RVA: 0x777C800
	public static object get_PlaceholderComputeBuffer() { }

	// RVA: 0x777C93C
	public static object GetTemporaryTexture(object src) { }

	// RVA: 0x777CA64
	public static object HaltonSequence(object index, object radix) { }

	// RVA: 0x777CAA8
	public static object R2Sequence(object index) { }

	// RVA: 0x777CB30
	public static object Destroy(object obj) { }

	// RVA: 0x777CC00
	public static object DestroyRenderTexture(object obj) { }

	// RVA: 0x777CCEC
	public static object IsSceneFilteringEnabled(object camera) { }

	// RVA: 0x777CCF4
	public static object IsSceneFilteringEnabled() { }

	// RVA: 0x777CCFC
	public static object DestroyRenderTexture(object obj) { }

	// RVA: -1
	public static object CreateStructuredBuffer(object count, object additionalTargets) { }

	// RVA: 0x777CDE4
	public static object CreateComputeBuffer(object count, object stride, object initializeToZero, object type, object usage) { }

	// RVA: 0x777CECC
	public static object GetRenderTargetBinding(object numCb) { }

	// RVA: 0x777D154
	public static object GetProjMatrix(object camera, object renderIntoTexture) { }

	// RVA: 0x777D1BC
	public static object GetProjMatrix(object camera, object renderIntoTexture) { }

	// RVA: 0x777D224
	public static object GetNonJitteredProjMatrix(object camera, object renderIntoTexture) { }

	// RVA: 0x777D28C
	public static object GetNonJitteredProjMatrix(object camera, object renderIntoTexture) { }

	// RVA: 0x777D2F4
	public static object GetViewProjMatrix(object camera, object renderIntoTexture) { }

	// RVA: 0x777D3AC
	public static object GetViewProjMatrix(object camera, object renderIntoTexture) { }

	// RVA: 0x777D464
	public static object GetNonJitteredViewProjMatrix(object camera, object renderIntoTexture) { }

	// RVA: 0x777D51C
	public static object GetNonJitteredViewProjMatrix(object camera, object renderIntoTexture) { }

	// RVA: 0x777D5D4
	public static object GetCameraToScreenMatrix(object camera, object screenWidth, object screenHeight) { }

	// RVA: 0x777D79C
	public static object NumChannelsOfAOV(object aov) { }

	// RVA: 0x777D7C0
	public static object GetCameraTexture(object camera) { }

	// RVA: 0x777D8E4
	public static object ShaderPassName(object pass) { }

	// RVA: 0x777DC58
	public static object ClearFrameBuffer(object cmd, object camera, object clearDepth) { }

	// RVA: 0x777DDCC
	public static object ClearFrameBufferWithLRZWorkaround(object cmd, object camera, object clearDepth) { }

	// RVA: 0x777DD2C
	public static object ClearFrameBuffer(object cmd, object clearFlags, object backgroundColor, object clearDepth) { }

	// RVA: 0x777DEDC
	public static object ShaderPassTagId(object pass) { }

	// RVA: 0x777E3A0
	public static object GetRendererListDesc(object context, object cameraData, object shaderPass) { }

	// RVA: 0x777E558
	public static object GetRendererListDesc(object context, object cameraData, object passNames, object isUIOpt) { }

	// RVA: 0x777E6E4
	public static object SaveScreenshotOrCharacterCloudMapToFile(object context, object commands, object cameraData) { }

	// RVA: 0x777E6E8
	public static object Unity5LegacySortingFlags() { }

	// RVA: 0x777E6F0
	public static object GetOpaqueRendererListDesc(object context, object cameraData, object useUnity5LegacySorting) { }

	// RVA: 0x777E8B0
	public static object GetOpaqueRendererListDesc(object context, object cameraData, object shaderPass, object useUnity5LegacySorting) { }

	// RVA: 0x777EA68
	public static object GetTransparentRendererListDesc(object context, object camera, object useUnity5LegacySorting) { }

	// RVA: 0x777EC28
	public static object GetTransparentRendererListDesc(object context, object camera, object shaderPass, object useUnity5LegacySorting) { }

	// RVA: 0x777EDE0
	public static object GetVertexRendererListDesc(object context, object cameraData, object useUnity5LegacySorting) { }

	// RVA: 0x777EFFC
	public static object DrawRendererList(object renderContext, object cmd, object rendererList) { }

	// RVA: 0x777F108
	public static object DrawQuad(object cmd, object mat, object shaderPass, object properties) { }

	// RVA: 0x777F190
	public static object GetLinearBufferFormat(object includeAlphaChannel) { }

	// RVA: 0x777F234
	public static object GetMotionBufferFormat() { }

	// RVA: 0x777F2DC
	public static object GetShaderLodMaxNum(object LOD) { }

	// RVA: 0x777F2FC
	private static object UpdateCameras(object includeSceneCameras) { }

	// RVA: 0x777F43C
	public static object GetAllCameras(object includeSceneCameras) { }

	// RVA: 0x777F4A0
	public static object GetActivateCamera() { }

	// RVA: 0x777FB70
	public static object BuildSphereMesh(object radius, object segmentsU, object segmentsV) { }

	// RVA: 0x77806A4
	public static object GetUnitSphereMesh() { }

	// RVA: 0x77807D8
	public static object CreateCubeMesh(object min, object max) { }

	// RVA: 0x7780BA8
	public static object GetAABBVertices(object min, object max, object vertices) { }

	// RVA: 0x7780C50
	public static object GetAABBVertices(object min, object max, object vertices) { }

	// RVA: 0x7780C88
	public static object ComputeScreenPos(object viewPos, object projectionMatrix, object screenWidthHeight) { }

	// RVA: 0x7780D28
	public static object CreateDepthRenderTexture(object aCamera, object depthBit, object downScale) { }

	// RVA: 0x7780F74
	public static object DrawDepthCustomRenders(object cmd, object aCamera, object lstRenders, object depthTex) { }

	// RVA: 0x77814B8
	private static object .cctor() { }

}

// Namespace: Yarp
public static class ConstVars
{

	// Fields
	public const object PlatformTextureSettings_Standalone;
	public const object PlatformTextureSettings_iPhone;
	public const object PlatformTextureSettings_Android;
	public const object PackagePath;
	public const object ShaderLibrary;
	public const object ShaderTemplate;
	public const object ShaderProjectRootPath;
	public const object CiYuanShaderDirPath;
}

// Namespace: Yarp
public class DearImGuiDriver
{

	// Fields
	public object dearImGui; // 0x18

	// Methods

	// RVA: 0x7781A20
	private static object Initialize() { }

	// RVA: 0x7781B44
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__1_0; // 0x8

	// Methods

	// RVA: 0x7781D04
	private static object .cctor() { }

	// RVA: 0x7781D64
	public object .ctor() { }

	// RVA: 0x7781D6C
	internal object <Calculate>b__1_0(object current, object obj) { }

}

// Namespace: Yarp
public static class HashingMethods
{

	// Methods

	// RVA: 0x7781B4C
	public static object Calculate(object obj) { }

	// RVA: 0x7781BE0
	public static object Calculate(object objects) { }

}

// Namespace: Yarp
public class KeyframeUtility
{

	// Methods

	// RVA: 0x7781DD4
	public static object ResetAnimationCurve(object curve) { }

	// RVA: 0x7781DF4
	private static object LerpSingleKeyframe(object lhs, object rhs, object t) { }

	// RVA: 0x7781FC0
	private static object GetKeyframeAndClampEdge(object keys, object index) { }

	// RVA: 0x77820F4
	private static object FetchKeyFromIndexClampEdge(object keys, object index, object segmentStartTime, object segmentEndTime) { }

	// RVA: 0x7782270
	private static object EvalCurveSegmentAndDeriv(object dstValue, object dstDeriv, object lhsKey, object rhsKey, object desiredTime) { }

	// RVA: 0x7782404
	private static object EvalKeyAtTime(object keys, object lhsIndex, object rhsIndex, object startTime, object endTime, object currTime) { }

	// RVA: 0x77824CC
	public static object InterpAnimationCurve(object lhsAndResultCurve, object rhsCurve, object t) { }

	// RVA: 0x7782D48
	public object .ctor() { }

}

// Namespace: Yarp
public class LightUtils
{

	// Methods

	// RVA: 0x7782D50
	public static object ConvertPointLightLumenToCandela(object intensity) { }

	// RVA: 0x7782D64
	public static object ConvertPointLightCandelaToLumen(object intensity) { }

	// RVA: 0x7782D78
	public static object ConvertSpotLightLumenToCandela(object intensity, object angle) { }

	// RVA: 0x7782DC8
	public static object ConvertSpotLightCandelaToLumen(object intensity, object angle) { }

	// RVA: 0x7782E18
	public static object ConvertLuxToCandela(object lux, object distance) { }

	// RVA: 0x7782E24
	public static object ConvertCandelaToLux(object candela, object distance) { }

	// RVA: 0x7782E30
	public static object ConvertPunctualLightLumenToCandela(object light, object lumen) { }

	// RVA: 0x7782EBC
	public static object ConvertPunctualLightLumenToLux(object light, object lumen) { }

	// RVA: 0x7782F54
	public static object ConvertPunctualLightCandelaToLumen(object light, object candela) { }

	// RVA: 0x7782FE0
	public static object ConvertPunctualLightLuxToLumen(object light, object lux) { }

	// RVA: 0x7783074
	public static object ConvertLightIntensity(object light, object newLightUnit, object intensity) { }

	// RVA: 0x7783324
	public static object GetLightUnitlessIntensity(object light) { }

	// RVA: 0x778342C
	public static object CorrelatedColorTemperatureToRGB(object temp) { }

	// RVA: 0x778359C
	private static object CorrelatedXYZToSRGB(object x, object y, object z) { }

	// RVA: 0x7783614
	public static object GetYALightType(object lightType) { }

	// RVA: 0x7783634
	public static object GetUnityLightType(object lightType) { }

	// RVA: 0x7783658
	public static object GetHeroLightLayerMask() { }

	// RVA: 0x7783660
	public static object GetLightingLayerMaskF(object lightingLayer) { }

	// RVA: 0x7783668
	public object .ctor() { }

}

// Namespace: Yarp
public enum VertexInputAttribute
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Position;
	public const object Normal;
	public const object Tangent;
	public const object Color;
	public const object TexCoord0;
	public const object TexCoord1;
	public const object TexCoord2;
	public const object TexCoord3;
	public const object TexCoord4;
	public const object TexCoord5;
	public const object TexCoord6;
	public const object TexCoord7;
}

// Namespace: 
public enum SurfaceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Opaque;
	public const object Transparent;
	public const object TransparentCutout;
	public const object Subsurface;
}

// Namespace: Yarp
public static class MaterialUtils
{

	// Fields
	public const object k_PropertySrcBlend;
	public const object k_PropertyDstBlend;
	public const object k_PropertySrcBlendAlpha;
	public const object k_PropertyDstBlendAlpha;
	public const object k_PropertyZWrite;
	public const object k_PropertyZTestMode;
	public const object k_PropertyBlendMode;
	public const object k_PropertyStencilRef;
	public const object k_PropertyStencilComp;
	public const object k_PropertyStencilReadMask;
	public const object k_PropertyStencilWriteMask;
	public const object k_PropertyStencilPass;
	public const object k_PropertyStencilFail;
	public const object k_PropertyStencilZFail;
	public const object k_PropertyVisibility;
	public const object k_PropertyThickness;
	public const object k_PropertyAlphaTest;
	public const object k_PropertyAlphaToMask;
	public const object k_PropertyTwoSided;
	public const object k_PropertyCull;
	public const object k_PropertyEnableSSAO;
	public const object k_PropertyEnableSSR;
	public const object k_PropertyEmissiveColor;
	public const object k_PropertyEmissiveMap;
	public const object k_PropertySubsurfaceHash;
	public const object k_PropertySubsurfaceProfileRef;
	public const object k_PropertySubsurfaceProfileIndex;
	public const object k_PropertyColorMask;
	public const object k_PropertyGIBakerMode;
	public const object k_PropertySpOpacity;
	public const object k_PropertyVolumetricMediumID;
	public const object k_PropertyMeshLightBaseIndex;
	public const object k_PropertyAlbedoMap;
	public const object k_PropertyNormalMap;
	public const object k_PropertyBentNormalMap;
	public const object k_PropertyParametersMap;
	public const object k_PropertyDepthSlope;
	public const object k_PropertyDepthBias;
	public const object k_PropertyDepthOffset;
	public const object k_KeywordUseCloseupShadow;
	public const object k_KeywordUseCloseupPcss;
	public const object k_ReplacementTagOff;
	public const object k_ReplacementTagShadowPass;
	public const object k_ReplacementTagShadowPassOn;
	public const object k_ReplacementTagGlitchEffectPass;
	public const object k_ReplacementTagGlitchEffectPassOn;
	public const object k_ReplacementTagGlitchEffectPassOff;
	public const object k_ReplacementTagMirrorReplacePass;
	public const object k_ReplacementTagMirrorReplaceOnPass;
	public static readonly object k_ReplacementTagMirrorReplaceValues; // 0x0
	public const object k_UVChannelToStoreVisibilityData;
	public const object k_CharacterLightLayerMask;
	public const object k_SceneLightLayerMask;
	public const object k_CloudLightLayerMask;
	public const object k_EffectLightLayerMask;
	public const object k_CharacterLightLayerMask2;
	public const object k_CharacterLightLayerMask3;
	public const object k_CharacterLightLayerMask4;
	public const object k_CharacterLightLayerMask5;

	// Methods

	// RVA: 0x7783670
	public static object PropertyNameToKeyword(object name) { }

	// RVA: 0x77836DC
	public static object GetFullShaderName(object shaderProfile, object featureName, object shaderName, object newModel) { }

	// RVA: 0x77837F8
	public static object GetShaderProfile(object shader, object shaderProfile) { }

	// RVA: 0x7783960
	public static object IsYarpShader(object shader) { }

	// RVA: 0x7783AA8
	public static object MinimalVertexInputAttrib() { }

	// RVA: 0x7783AB0
	public static object DefaultEnablePass() { }

	// RVA: 0x7783AB8
	public static object IsAlphaTestedMaterial(object mat) { }

	// RVA: 0x7783BBC
	public static object IsTransparentMaterial(object mat) { }

	// RVA: 0x7783CC0
	public static object IsSubsurfaceMaterial(object mat) { }

	// RVA: 0x7783ED4
	public static object IsVolumetricMaterial(object mat) { }

	// RVA: 0x7784118
	public static object IsValidRayTracingMaterial(object mat) { }

	// RVA: 0x77842FC
	private static object .cctor() { }

}

// Namespace: Yarp
public class MetaPassOutputBinding
{

	// Fields
	private object m_numVars; // 0x8
	private object m_vars; // 0x10
	private object m_rtIndices; // 0x18
	private object m_varSwizzles; // 0x20

	// Methods

	// RVA: 0x77843C4
	public object SetVar(object var, object renderTargetIdx, object swizzle) { }

	// RVA: 0x7784468
	public object Apply(object commands, object textureSpaceOutput) { }

	// RVA: 0x77845C0
	public object Apply(object textureSpaceOutput) { }

	// RVA: 0x7784684
	public static object Reset(object commands) { }

	// RVA: 0x778474C
	public static object Reset() { }

	// RVA: 0x77847F8
	public object .ctor() { }

}

// Namespace: 
public struct <vertexSize>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
private struct MeshInfo
{

	// Fields
	public object vertexSize; // 0xFFFFFFFFFFFFFFF8
	public object baseVertex; // 0x8
	public object vertexStart; // 0xC
	public object indexSize; // 0x10
	public object indexStart; // 0x14
}

// Namespace: 
private struct VertexAttributeInfo
{

	// Fields
	public object Stream; // 0xFFFFFFFFFFFFFFF8
	public object Format; // 0xFFFFFFFFFFFFFFFC
	public object ByteOffset; // 0x0
	public object Dimension; // 0x4
}

// Namespace: Yarp
public static class MeshUtils
{

	// Fields
	private const object kMaxVertexStreams;
	private const object kVertexAttributeCount;
	private const object kMaxSubmeshCount;
	private static object s_vertexDeclBuffer; // 0x0
	private static object s_meshInfoBuffer; // 0x8
	private static object s_vertexBuffers; // 0x10
	private static object s_vertexDeclaration; // 0x18
	private static object s_meshInfo; // 0x20
	private static object s_vertexDescriptors; // 0x28
	private static object s_kernelArray; // 0x30

	// Methods

	// RVA: 0x7784890
	public static object SetComputeMeshParam(object commands, object mesh, object computeShader, object kernel) { }

	// RVA: 0x7784984
	public static object SetComputeMeshParam(object commands, object mesh, object computeShader, object kernels) { }

	// RVA: 0x77859F0
	public static object SetComputeMeshParam(object commands, object SMR, object computeShader, object kernel) { }

	// RVA: 0x7785AE4
	public static object SetComputeMeshParam(object commands, object SMR, object computeShader, object kernels) { }

	// RVA: 0x7784A08
	private static object SetComputeMeshParamImpl(object commands, object mesh, object SMR, object computeShader, object kernels) { }

	// RVA: 0x7785B68
	private static object .cctor() { }

}

// Namespace: Yarp
public class MultiplePropertyBlocksMarker
{

	// Methods

	// RVA: 0x7785D74
	public object .ctor() { }

}

// Namespace: 
public enum EShadowCacheDirtyReason
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Dirty_None;
	public const object Dirty_LightObjectActive;
	public const object Dirty_ShadowResolution;
	public const object Dirty_ShadowSetting;
	public const object Dirty_LightTransform;
	public const object Dirty_StaticCastersCount;
	public const object Dirty_ShadowFrustum;
	public const object Dirty_ScriptsForceUpdate;
}

// Namespace: 
public enum EShadowCascadeMask
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Shadow_Cascade_1;
	public const object Shadow_Cascade_2;
	public const object Shadow_Cascade_3;
	public const object Shadow_Cascade_4;
}

// Namespace: 
public enum FrustumPlaneOrder
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
	public const object Down;
	public const object Up;
	public const object Near;
	public const object Far;
}

// Namespace: 
private sealed class <>c__DisplayClass29_0
{

	// Fields
	public object lights; // 0x8

	// Methods

	// RVA: 0x778A734
	public object .ctor() { }

	// RVA: 0x778BF40
	internal object <ComputeMultipleLightShadowSplits>b__0(object a, object b) { }

}

// Namespace: Yarp
public static class ShadowUtilities
{

	// Fields
	public static readonly object s_CascadeUpdateMasks; // 0x0
	public const object k_spotLightShadowNearPlane;
	private const object k_MaxShadowAtlasSize;
	private static object shadowVolume; // 0x8
	private static object s_frustrumNearPlaneCorners; // 0x10
	private static object s_frustrumFarPlaneCorners; // 0x18
	private static object s_frustrumCornerPoints; // 0x20
	private static object planes; // 0x28
	private static object s_SpotLightPosVS; // 0x30
	private static object rowColX; // 0x38
	private static object rowColWidth; // 0x40
	private static object rowColOccupiedHeight; // 0x48

	// Methods

	// RVA: 0x7785D7C
	public static object CalculateFrustumCorners(object projectionMatrix, object viewport, object z, object outRays) { }

	// RVA: 0x7785FC8
	public static object BoundingSphereFromCameraFrustum(object camera, object near, object far) { }

	// RVA: 0x7786250
	public static object GetShadowMatrixForShadowMapSampling(object viewMatrix, object projectionMatrix) { }

	// RVA: 0x77863D4
	public static object ComputeDirectionalLightViewProjectionMatrices(object viewCamera, object shadowSettings, object lightTransform, object numOfCascades, object cascadeSplit, object shadowMapSize, object viewMatrices, object projMatrices, object CameraZRange, object splitStart, object debugDraw) { }

	// RVA: 0x77872D4
	public static object GetCascadeShadowNearAndFarPlane(object context, object camera, object aLight, object shadowNear, object shadowFar) { }

	// RVA: 0x7787824
	private static object UpdateShadowNearAndFar(object camera, object sphere, object shadowNear, object shadowFar) { }

	// RVA: 0x77878F4
	public static object ComputeCascadeShadowMatrices(object context, object camera, object aLight, object viewMatrices, object projMatrices, object shadowCamPos, object splitStart) { }

	// RVA: 0x778816C
	public static object ComputeCascadeShadowCullingDistance(object context, object camera, object aLight) { }

	// RVA: 0x7788C58
	public static object ComputeShadowCullingDistance(object context, object aCamera, object shadowLights) { }

	// RVA: 0x77894D8
	public static object ComputeDirectionalShadowNormalBias(object shadowMapProjectionMatrix, object shadowSplitResolution, object normalBias) { }

	// RVA: 0x77894F4
	private static object ComputeAccumulatedScale(object exponent, object cascadeIndex, object cascadeCount) { }

	// RVA: 0x7787FB0
	public static object ComputeShadowSplitDistances(object shadowNear, object shadowDistance, object cascadeCount, object cascadeDistributionExponent, object splitDistances) { }

	// RVA: 0x7789550
	public static object ComputeCullingPlanes(object projMat, object viewMat) { }

	// RVA: 0x7789614
	public static object ComputeCameraDifferentials(object invProjMat, object z, object width, object height, object dxCamera, object dyCamera) { }

	// RVA: 0x7789704
	public static object ComputeMultipleLightShadowSplits(object shadowSamplingParameters, object lights, object maxLength, object shadowRTSize) { }

	// RVA: 0x778A73C
	public static object ComputeMultipleLightShadowParameters(object shadowSamplingParameters, object context, object aCamera, object aLight, object cascadeSplit, object lstShadowSplitCoord, object shadowMapSize) { }

	// RVA: 0x778BCA4
	private static object .cctor() { }

}

// Namespace: Yarp
public class ShadowVolumePool
{

	// Fields
	private static object pool; // 0x0

	// Methods

	// RVA: 0x778C034
	public static object Get() { }

	// RVA: 0x7788BAC
	public static object Release(object shadowVolume) { }

	// RVA: 0x778C194
	public object .ctor() { }

	// RVA: 0x778C19C
	private static object .cctor() { }

}

// Namespace: Yarp
public class ShadowVolume
{

	// Fields
	public object cornerPoints; // 0x8
	private static object volumeCorners; // 0x0
	private static object nearPlaneCorners; // 0x8
	private static object farPlaneCorners; // 0x10

	// Methods

	// RVA: 0x7788724
	public static object Create(object center, object size) { }

	// RVA: 0x7786B50
	public static object Create(object center, object size, object volume) { }

	// RVA: 0x778C22C
	public static object Create(object camera, object near, object far) { }

	// RVA: 0x7786EAC
	public static object Create(object camera, object near, object far, object volume) { }

	// RVA: 0x7786C94
	public object ApplyTransform(object transfo) { }

	// RVA: 0x778C58C
	public object Transform(object transfo) { }

	// RVA: 0x77888A4
	public object GetMinMax(object boundsMin, object boundsMax) { }

	// RVA: 0x7787204
	public object GetAABB(object sphereFit, object roundUpBySize) { }

	// RVA: 0x778BEDC
	public object .ctor() { }

	// RVA: 0x778C890
	private static object .cctor() { }

}

// Namespace: Yarp
public class SRPGLHelper
{

	// Fields
	private object m_meshes; // 0x8
	private object m_vertices; // 0x10
	private object m_colors; // 0x18
	private object m_uvs; // 0x20
	private static object s_indices; // 0x0
	private static object s_indiceCount; // 0x8
	private object m_meshCount; // 0x28
	private object m_color; // 0x2C
	private object m_verticeCount; // 0x3C
	private const object m_verticesLimits;
	private object m_faceVerticesLimits; // 0x40
	private object m_meshTopology; // 0x44
	private object m_camera; // 0x48
	private object m_commandBuffer; // 0x50
	private object m_modelMatrix; // 0x58
	private object m_ProjMatrix; // 0x98
	private object m_viewMatrix; // 0xD8
	private object m_rect; // 0x118
	private static object m_material; // 0x10

	// Properties
	public static object LinesMaterial { get; }

	// Methods

	// RVA: 0x778C9EC
	public static object get_LinesMaterial() { }

	// RVA: 0x778CB84
	public object SetMeshTopology(object meshTopology) { }

	// RVA: 0x778CB8C
	public object .ctor() { }

	// RVA: 0x778CDA4
	private object Init() { }

	// RVA: 0x778CE5C
	public object Dispose() { }

	// RVA: 0x778CEF0
	public object Begin(object meshTopology) { }

	// RVA: 0x778CF50
	private object GetPointsOfFace(object mesh) { }

	// RVA: 0x778CF70
	public object End() { }

	// RVA: 0x778D414
	public object Clear() { }

	// RVA: 0x778D438
	public object Color(object color) { }

	// RVA: 0x778D444
	public object Vertex3(object x, object y, object z) { }

	// RVA: 0x778D450
	public object Vertex(object pos) { }

	// RVA: 0x778D45C
	public object Vertex(object pos, object color) { }

	// RVA: 0x778D854
	public object Vertex(object pos, object color, object uv) { }

	// RVA: 0x778D9C8
	public object SetCamera(object camera) { }

	// RVA: 0x778DA74
	public object SetCamera(object camera) { }

	// RVA: 0x778DB44
	public object Viewport(object pixelRect) { }

	// RVA: 0x778DB58
	public object LoadOrtho() { }

	// RVA: 0x778DCBC
	public object LoadIdentity() { }

	// RVA: 0x778DD60
	public object LoadPixelMatrix() { }

	// RVA: 0x778DEFC
	public object MultMatrix(object model) { }

	// RVA: 0x778DC10
	private object CalcPixelMatrix(object rect) { }

	// RVA: 0x778DC34
	public object LoadProjMatrix(object pro) { }

	// RVA: 0x778DF18
	public object Draw(object context, object cmd, object mat, object pass) { }

	// RVA: 0x778E224
	public object Draw(object context, object cmd, object mat, object pass, object cameraTargetTexture) { }

	// RVA: 0x778E55C
	public object Draw(object context, object mat, object pass, object submeshIndex) { }

	// RVA: 0x778E914
	private static object .cctor() { }

}

// Namespace: 
public class SRPGLPool
{

	// Fields
	private object sRPGLHelpers; // 0x8

	// Methods

	// RVA: 0x778F294
	public object Get() { }

	// RVA: 0x778F0AC
	public object Add(object srpgl) { }

	// RVA: 0x778ECB8
	public object .ctor() { }

}

// Namespace: Yarp
public class SRPGL
{

	// Fields
	private object m_material; // 0x8
	private object m_srpGL; // 0x10
	private object srpGlpool; // 0x18
	private object list_srpGL; // 0x20
	public object vecColor; // 0x28
	protected const object kArcPoints;
	protected static object s_Points; // 0x0

	// Methods

	// RVA: 0x778E98C
	protected override object Init() { }

	// RVA: 0x778ED38
	public object EndCameraRendering(object context, object cmd, object camera, object mat) { }

	// RVA: 0x778F158
	public object GLBegin(object mode, object realBegin) { }

	// RVA: 0x778F33C
	public object GLEnd(object realEnd) { }

	// RVA: 0x778F490
	public object GLColor(object c) { }

	// RVA: 0x778F4AC
	public object GLVertex(object x) { }

	// RVA: 0x778F4D4
	public object DrawGLLine(object l, object r) { }

	// RVA: 0x778F548
	protected static object SetDiscSectionPoints(object dest, object count, object center, object normal, object from, object angle, object radius) { }

	// RVA: 0x778FA08
	protected static object RotateVectorByQuat(object lhs, object rhs) { }

	// RVA: 0x778F874
	protected static object Deg2Rad(object deg) { }

	// RVA: 0x778F898
	protected static object AxisAngleToQuaternionSafe(object axis, object angle) { }

	// RVA: 0x778FAAC
	protected object DrawWireArc(object center, object normal, object from, object angle, object radius) { }

	// RVA: 0x778FCC4
	public object DrawWireSphere(object center, object radius) { }

	// RVA: 0x778FD70
	public object .ctor() { }

	// RVA: 0x778FDD0
	private static object .cctor() { }

}

// Namespace: Yarp
public static class TextureFormatUtils
{

	// Fields
	private static object s_SupportedRenderTextureFormats; // 0x0

	// Methods

	// RVA: 0x778FE44
	private static object .cctor() { }

	// RVA: 0x7790340
	private static object IsObsolete(object value) { }

	// RVA: 0x77904B0
	internal static object IsSupported(object format) { }

}

// Namespace: Yarp.RuntimeTool
public abstract class RenderingDebugModelBase
{

	// Methods

	// RVA: -1
	public abstract object Init() { }

	// RVA: -1
	public abstract object PreRenderUpdate() { }

	// RVA: 0x7790578
	protected object .ctor() { }

}

// Namespace: Yarp.RuntimeTool
public class RenderResultDebugModel
{

	// Fields
	public object renderResults; // 0x8

	// Methods

	// RVA: 0x7790580
	public override object Init() { }

	// RVA: 0x77905F8
	public override object PreRenderUpdate() { }

	// RVA: 0x77905FC
	public object Clear() { }

	// RVA: 0x77908F4
	public object TryAddResult(object cameraId) { }

	// RVA: 0x7790BE4
	public object SyncCameraData(object cameraId, object cameraData) { }

	// RVA: 0x7790DEC
	public object SyncWorldData(object cameraId, object worldData) { }

	// RVA: 0x7791054
	public object GetResult(object cameraId) { }

	// RVA: 0x77910D8
	public object Validate() { }

	// RVA: 0x7791468
	public object MakeCopy() { }

	// RVA: 0x7791C88
	public object .ctor() { }

}

// Namespace: Yarp.RuntimeTool
public class RenderResult
{

	// Fields
	public object editCameraData; // 0x8
	public object editWorldData; // 0x10
	public object applyCameraData; // 0x18
	public object applyWorldData; // 0x20
	public object realCameraData; // 0x28
	public object realWorldData; // 0x30
	private object m_editGo; // 0x38
	private object m_editVolume; // 0x40
	private object m_editTargetVolume; // 0x48
	private object m_applyGo; // 0x50
	private object m_applyVolume; // 0x58
	private object m_applyTargetVolume; // 0x60

	// Methods

	// RVA: 0x77909D4
	public object .ctor() { }

	// RVA: 0x7790D74
	public object SyncCameraData(object cameraData) { }

	// RVA: 0x7790FAC
	public object SyncWorldData(object worldData) { }

	// RVA: 0x77913B4
	public object IsValid() { }

	// RVA: 0x77915C4
	public object MakeCopy() { }

	// RVA: 0x7791CD0
	public object MakeCopyForApply() { }

	// RVA: 0x7791D10
	public object MakeCopyForApply_CameraData() { }

	// RVA: 0x7791D4C
	public object MakeCopyForApply_WorldData() { }

	// RVA: 0x7790790
	public object Dispose() { }

}

// Namespace: Yarp.RuntimeTool
public class RenderResultEditMemento
{

	// Fields
	private object m_memento; // 0x8

	// Properties
	public object Data { get; }

	// Methods

	// RVA: 0x77923F0
	public object get_Data() { }

	// RVA: 0x77923F8
	public object Init() { }

	// RVA: 0x7792454
	public object AddData(object data) { }

	// RVA: 0x7792624
	public object Reset() { }

	// RVA: 0x7792840
	public object ApplyOnReal() { }

	// RVA: 0x7792A1C
	public object HasData(object id) { }

	// RVA: 0x7792A88
	public object Revert(object id) { }

	// RVA: 0x7792B84
	public object .ctor() { }

}

// Namespace: Yarp.RuntimeTool
public class RenderResultEditData
{

	// Fields
	private object m_memberInfo; // 0x8
	private object m_editObj; // 0x10
	private object m_realObj; // 0x18
	private object m_originalValue; // 0x20
	private object m_newValue; // 0x28

	// Properties
	public object MemberInfo { get; }
	public object RealObj { get; }
	public object NewValue { get; set; }

	// Methods

	// RVA: 0x7792C04
	public object get_MemberInfo() { }

	// RVA: 0x7792C0C
	public object get_RealObj() { }

	// RVA: 0x7792C14
	public object get_NewValue() { }

	// RVA: 0x7792C1C
	public object set_NewValue(object value) { }

	// RVA: 0x7792540
	public object GetKey() { }

	// RVA: 0x7792C24
	public static object GetKey(object obj, object memberInfoName) { }

	// RVA: 0x7792CE8
	public object .ctor(object memberInfo, object editObj, object originalValue, object realObj, object newValue) { }

	// RVA: 0x7792D3C
	public object .ctor(object memberInfo, object editObj, object originalValue, object newValue) { }

	// RVA: 0x77927B0
	public object Undo() { }

	// RVA: 0x7792D88
	public object Apply() { }

	// RVA: 0x77929CC
	public object ApplyOnReal() { }

	// RVA: 0x7792DD8
	public object UndoOnReal() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__7_0; // 0x8

	// Methods

	// RVA: 0x7793D48
	private static object .cctor() { }

	// RVA: 0x7793DA8
	public object .ctor() { }

	// RVA: 0x7793DB0
	internal object <Init>b__7_0(object t) { }

}

// Namespace: Yarp.RuntimeTool
public class RenderSettingsControlViewModel
{

	// Fields
	public object enable; // 0x8
	public object settingDictionary; // 0x10
	private object settingTypes; // 0x18
	public object currentCamera; // 0x20
	public object cameras; // 0x28

	// Properties
	public object ShowData { get; }

	// Methods

	// RVA: 0x7792E28
	public object get_ShowData() { }

	// RVA: 0x7792E88
	public override object Init() { }

	// RVA: 0x7792FF8
	public override object PreRenderUpdate() { }

	// RVA: 0x779389C
	public object AddData(object camera) { }

	// RVA: 0x7793CC8
	public object .ctor() { }

}

// Namespace: 
public class FakeDataRecord
{

	// Fields
	public object renderer; // 0x8
	public object fakeCameraData; // 0x10
	public object fakeWorldData; // 0x18
	public object realCameraData; // 0x20
	public object realWorldData; // 0x28

	// Methods

	// RVA: 0x7794E20
	public object .ctor(object renderer, object fakeCameraData, object fakeWorldData, object realCameraData, object realWorldData) { }

	// RVA: 0x7794E74
	public object SetFakeData() { }

	// RVA: 0x7794E78
	public object SetRealData() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__8_0; // 0x8
	public static object <>9__8_1; // 0x10

	// Methods

	// RVA: 0x7794E7C
	private static object .cctor() { }

	// RVA: 0x7794EDC
	public object .ctor() { }

	// RVA: 0x7794EE4
	internal object <InitPool>b__8_0() { }

	// RVA: 0x7794FB0
	internal object <InitPool>b__8_1(object o) { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugDataManager
{

	// Fields
	public object volumeDebugModel; // 0x8
	public object renderResultDebugModel; // 0x10
	public object debugModels; // 0x18
	public object renderSettingsControlViewModel; // 0x20
	public object goPool; // 0x28
	public object onEditModeChanged; // 0x30
	public object renderResultEditMemento; // 0x38
	private object m_fakeDatas; // 0x40
	public object ptrsRenderResultView; // 0x48

	// Methods

	// RVA: 0x7793E1C
	protected override object Init() { }

	// RVA: 0x7794170
	private object InitPool() { }

	// RVA: 0x779445C
	public object Update(object gfxContext, object cmd) { }

	// RVA: 0x7794384
	public object Update() { }

	// RVA: 0x7794460
	public object RegisterUpdate() { }

	// RVA: 0x7794538
	public object UnRegisterUpdate() { }

	// RVA: 0x77945E8
	public object Dispose() { }

	// RVA: 0x7794698
	public object AddOrUpdateFakeDataRecord(object instanceId, object record) { }

	// RVA: 0x779470C
	public object GetFakeDataRecord(object instanceId) { }

	// RVA: 0x7794790
	public object GetFakeWorldData(object instanceId) { }

	// RVA: 0x7794834
	public object GetFakeCameraData(object instanceId) { }

	// RVA: 0x77948D8
	private object OnEndCameraRendering(object gfxRenderContext, object commandBuffer, object cameraData, object arg4) { }

	// RVA: 0x77948DC
	public object GetPtrKey(object obj, object memberInfoName) { }

	// RVA: 0x77949A0
	public object .ctor() { }

}

// Namespace: Yarp.RuntimeTool
public class VolumeDebugModel
{

	// Fields
	private object m_cameraNames; // 0x8
	public object cameraDisplayNames; // 0x10
	private object m_cameraIds; // 0x18
	private object m_cameraDic; // 0x20
	public object selectedCameraIndex; // 0x28
	private object m_allCameras; // 0x30
	public object onCameraChanged; // 0x38
	public object settingNames; // 0x40
	public object displaySettingNames; // 0x48
	private object m_settingDic; // 0x50
	public object selectedSettingIndex; // 0x58
	public object showAllInterpolations; // 0x5C
	public object interpolations; // 0x60

	// Properties
	public object SelectedCameraIndex { get; set; }
	public object SelectedCamera { get; }
	public object SelectedSettingIndex { get; set; }
	public object SelectedSetting { get; }

	// Methods

	// RVA: 0x7795038
	public object get_SelectedCameraIndex() { }

	// RVA: 0x7795040
	public object set_SelectedCameraIndex(object value) { }

	// RVA: 0x7795048
	public object get_SelectedCamera() { }

	// RVA: 0x77950E0
	public object get_SelectedSettingIndex() { }

	// RVA: 0x77950E8
	public object set_SelectedSettingIndex(object value) { }

	// RVA: 0x77950F0
	public object get_SelectedSetting() { }

	// RVA: 0x77951B0
	public object ClearRecords(object cameraData) { }

	// RVA: 0x77953A4
	public object ClearAllRecords() { }

	// RVA: 0x77956FC
	public object AddInterpolationResult(object cameraData, object interpolation) { }

	// RVA: 0x7795998
	public object ReverseRecords(object cameraData) { }

	// RVA: 0x7795A68
	public object GetInterpolationResult(object cameraId) { }

	// RVA: 0x7795AEC
	public object GetInterpolationResult(object cameraId, object setting) { }

	// RVA: 0x7795EE8
	public override object Init() { }

	// RVA: 0x779650C
	public override object PreRenderUpdate() { }

	// RVA: 0x7794C28
	public object .ctor() { }

}

// Namespace: Yarp.RuntimeTool
public class VolumeInterpolation
{

	// Fields
	public object volume; // 0x8
	public object resultVolume; // 0x10
	public object result; // 0x18
	public object interpolationFactor; // 0x20

	// Methods

	// RVA: 0x7796CA4
	public object .ctor(object volume, object resultSettings, object interpolationFactor) { }

	// RVA: 0x7796EB8
	public object Clear() { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugStatus
{

	// Fields
	private object m_isEditorVolumeMenuOn; // 0x8
	private object m_isRuntimeDebugOn; // 0x9
	public object isEditMode; // 0xA
	private object m_dearImGui; // 0x10
	public object scrollBarSize; // 0x18

	// Properties
	public object NeedVolumeInfo { get; }
	public object DearImGuiInstance { get; }
	public object FontSize { get; set; }
	public object IsEditorVolumeMenuOn { get; set; }
	public object IsRuntimeDebugOn { get; set; }

	// Methods

	// RVA: 0x779701C
	public object get_NeedVolumeInfo() { }

	// RVA: 0x779703C
	public object get_DearImGuiInstance() { }

	// RVA: 0x7797118
	public object get_FontSize() { }

	// RVA: 0x779714C
	public object set_FontSize(object value) { }

	// RVA: 0x779718C
	public object get_IsEditorVolumeMenuOn() { }

	// RVA: 0x7797194
	public object set_IsEditorVolumeMenuOn(object value) { }

	// RVA: 0x7797284
	public object get_IsRuntimeDebugOn() { }

	// RVA: 0x779728C
	public object set_IsRuntimeDebugOn(object value) { }

	// RVA: 0x7797354
	public object IsRunningEditMode(object camera) { }

	// RVA: 0x7797450
	public object .ctor() { }

}

// Namespace: 
internal enum DockingSide
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
	public const object Top;
	public const object Down;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__27_0; // 0x8

	// Methods

	// RVA: 0x779946C
	private static object .cctor() { }

	// RVA: 0x77994CC
	public object .ctor() { }

	// RVA: 0x77994D4
	internal object <OnEnable>b__27_0(object a, object b) { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugDrawer
{

	// Fields
	private object m_inGameStatsGUI; // 0x8
	private object m_windowOpen; // 0x10
	private object <WindowPos>k__BackingField; // 0x14
	private object <WindowSize>k__BackingField; // 0x1C
	private object <WindowCollapsed>k__BackingField; // 0x24
	private object m_volumeDetailView; // 0x28
	private object m_renderResultView; // 0x30
	private object m_cameraRendererView; // 0x38
	private object m_views; // 0x40
	private const object m_yarpName;
	private const object m_sGameViewName;
	private object m_runtimeRootGo; // 0x48
	private object m_isInit; // 0x50
	private object m_isEditor; // 0x51
	internal static object dockingSide; // 0x0
	private object m_docking; // 0x52
	private object m_firstFrame; // 0x53
	private const object enableMultiTouchDragging;

	// Properties
	public object WindowPos { get; set; }
	public object WindowSize { get; set; }
	public object WindowOpen { get; set; }
	public object WindowCollapsed { get; set; }

	// Methods

	// RVA: 0x77974B0
	public object get_WindowPos() { }

	// RVA: 0x77974B8
	private object set_WindowPos(object value) { }

	// RVA: 0x77974C0
	public object get_WindowSize() { }

	// RVA: 0x77974C8
	private object set_WindowSize(object value) { }

	// RVA: 0x77974D0
	public object get_WindowOpen() { }

	// RVA: 0x77974D8
	public object set_WindowOpen(object value) { }

	// RVA: 0x77974E0
	public object get_WindowCollapsed() { }

	// RVA: 0x77974E8
	private object set_WindowCollapsed(object value) { }

	// RVA: 0x77974F0
	public object .ctor(object isEditor, object runtimeRootGo) { }

	// RVA: 0x77975DC
	public object OnEnable() { }

	// RVA: 0x779839C
	public object OnDisable() { }

	// RVA: 0x7798788
	public object OnLayout() { }

	// RVA: 0x7798E4C
	private object DrawMenu() { }

	// RVA: 0x7799048
	private object DrawTabs() { }

}

// Namespace: Yarp.RuntimeTool
public static class RuntimeDebugManager
{

	// Fields
	private static object <IsOn>k__BackingField; // 0x0
	public static object HideRuntimeDebugButton; // 0x1
	private static object m_go; // 0x8

	// Properties
	public static object IsOn { get; set; }

	// Methods

	// RVA: 0x7799728
	public static object get_IsOn() { }

	// RVA: 0x77997A4
	private static object set_IsOn(object value) { }

	// RVA: 0x7799830
	private static object .cctor() { }

	// RVA: 0x7799944
	public static object ToggleToolStatus() { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugMain
{

	// Fields
	private object m_dearimgui; // 0x18
	private object m_width; // 0x20
	private object m_height; // 0x24
	private object m_runtimeDebugWindowUIComponent; // 0x28
	private object m_runtimeDebugDrawer; // 0x30

	// Properties
	public object WindowOpen { get; }
	public object WindowCollapsed { get; }
	public object WindowPos { get; }
	public object WindowSize { get; }

	// Methods

	// RVA: 0x7799D24
	public object get_WindowOpen() { }

	// RVA: 0x7799D48
	public object get_WindowCollapsed() { }

	// RVA: 0x7799D6C
	public object get_WindowPos() { }

	// RVA: 0x7799D90
	public object get_WindowSize() { }

	// RVA: 0x7799DB4
	private object Awake() { }

	// RVA: 0x7799E20
	private object OnEnable() { }

	// RVA: 0x779A050
	private object Update() { }

	// RVA: 0x779A180
	private object OnDisable() { }

	// RVA: 0x779A204
	private object OnLayout() { }

	// RVA: 0x779A0E8
	private object UpdateRenderCamera() { }

	// RVA: 0x779A224
	private object OnGUI() { }

	// RVA: 0x779A534
	private object OnDestroy() { }

	// RVA: 0x779A554
	public object .ctor() { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugViewConfigAttribute
{

	// Fields
	private readonly object <GroupName>k__BackingField; // 0x8
	private readonly object <ViewName>k__BackingField; // 0x10
	private readonly object <Priority>k__BackingField; // 0x18
	private readonly object <NeedTab>k__BackingField; // 0x1C

	// Properties
	public object GroupName { get; }
	public object ViewName { get; }
	public object Priority { get; }
	public object NeedTab { get; }

	// Methods

	// RVA: 0x779A5D0
	public object get_GroupName() { }

	// RVA: 0x779A5D8
	public object get_ViewName() { }

	// RVA: 0x779A5E0
	public object get_Priority() { }

	// RVA: 0x779A5E8
	public object get_NeedTab() { }

	// RVA: 0x779A5F0
	public object .ctor(object groupName, object viewName, object priority, object needTab) { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugWindowUI
{

	// Fields
	public object blockImg; // 0x18
	public object canvas; // 0x20
	public object root; // 0x28
	public object imgGo; // 0x30
	private object m_vec; // 0x38
	private object m_runtimeDebugMain; // 0x40

	// Methods

	// RVA: 0x779A640
	public object Awake() { }

	// RVA: 0x779A978
	private object Update() { }

	// RVA: 0x779AB70
	private object OnDestroy() { }

	// RVA: 0x779ABE4
	public object .ctor() { }

}

// Namespace: Yarp.RuntimeTool
public class CameraControlView
{

	// Methods

	// RVA: 0x779ABF8
	public object .ctor(object name) { }

	// RVA: 0x779AC60
	public override object Init() { }

	// RVA: 0x779AC64
	public override object DrawLayout() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__1_0; // 0x8

	// Methods

	// RVA: 0x779B2A8
	private static object .cctor() { }

	// RVA: 0x779B308
	public object .ctor() { }

	// RVA: 0x779B310
	internal object <DrawLayout>b__1_0(object camera) { }

}

// Namespace: Yarp.RuntimeTool
public class CameraRendererView
{

	// Methods

	// RVA: 0x779ADA0
	public override object Init() { }

	// RVA: 0x779ADA4
	public override object DrawLayout() { }

	// RVA: 0x779B274
	public object .ctor(object name) { }

}

// Namespace: Yarp.RuntimeTool
public class SubViewKey
{

	// Fields
	private readonly object <Camera>k__BackingField; // 0x8
	private readonly object <SubViewType>k__BackingField; // 0x10

	// Properties
	public object Camera { get; }
	public object SubViewType { get; }

	// Methods

	// RVA: 0x779B344
	public object get_Camera() { }

	// RVA: 0x779B34C
	public object get_SubViewType() { }

	// RVA: 0x779B354
	public object .ctor(object camera, object subViewType) { }

	// RVA: 0x779B390
	public override object Equals(object obj) { }

	// RVA: 0x779B4A0
	public override object GetHashCode() { }

}

// Namespace: Yarp.RuntimeTool
public class SubViewData
{

	// Fields
	public object table; // 0x8
	public object searchBar; // 0x10
	public object reflectionSearchBar; // 0x18
	public object reflectionSearchFlag; // 0x20
	public object memberInfos; // 0x28
	public object simpleMemberInfos; // 0x30
	public object usingMemberInfos; // 0x38
	private object <ShowType>k__BackingField; // 0x40
	private readonly object <SubViewKey>k__BackingField; // 0x48
	private object m_isDetailMode; // 0x50
	private object <RowDatas>k__BackingField; // 0x58
	private object <ColDatas>k__BackingField; // 0x60
	public object allRealDynamicLights; // 0x68
	public object allEditDynamicLights; // 0x70
	public object allRealBakedLights; // 0x78
	public object allEditBakedLights; // 0x80

	// Properties
	public object ShowType { get; set; }
	public object SubViewKey { get; }
	public object isDetailMode { get; set; }
	public object RowDatas { get; set; }
	public object ColDatas { get; set; }

	// Methods

	// RVA: 0x779B4FC
	public object get_ShowType() { }

	// RVA: 0x779B504
	private object set_ShowType(object value) { }

	// RVA: 0x779B50C
	public object get_SubViewKey() { }

	// RVA: 0x779B514
	public object get_isDetailMode() { }

	// RVA: 0x779B51C
	public object set_isDetailMode(object value) { }

	// RVA: 0x779B524
	public object get_RowDatas() { }

	// RVA: 0x779B52C
	public object set_RowDatas(object value) { }

	// RVA: 0x779B534
	public object get_ColDatas() { }

	// RVA: 0x779B53C
	public object set_ColDatas(object value) { }

	// RVA: 0x779B544
	public object .ctor(object subViewKey, object showType, object colDatas, object simpleMemberInfoList) { }

	// RVA: 0x779C1FC
	public object ChangeType(object type, object colDatas) { }

	// RVA: 0x779BB10
	public object UpdateRowData() { }

}

// Namespace: Yarp.RuntimeTool
public enum SubViewType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CameraData;
	public const object RenderSetting;
	public const object RuntimeSetting;
	public const object YaLightDynamic;
	public const object YaLightBaked;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__16_0; // 0x8
	public static object <>9__16_1; // 0x10
	public static object <>9__21_0; // 0x18
	public static object <>9__25_0; // 0x20
	public static object <>9__25_1; // 0x28

	// Methods

	// RVA: 0x77A1388
	private static object .cctor() { }

	// RVA: 0x77A13E8
	public object .ctor() { }

	// RVA: 0x77A13F0
	internal object <Init>b__16_0(object a, object b) { }

	// RVA: 0x77A1498
	internal object <Init>b__16_1(object t) { }

	// RVA: 0x77A14E4
	internal object <InitViewDataCore>b__21_0(object regex, object item) { }

	// RVA: 0x77A1558
	internal object <DrawSubViewCore>b__25_0(object col) { }

	// RVA: 0x77A15F4
	internal object <DrawSubViewCore>b__25_1(object col) { }

}

// Namespace: 
private sealed class <>c__DisplayClass21_0
{

	// Fields
	public object subViewData; // 0x8

	// Methods

	// RVA: 0x779F72C
	public object .ctor() { }

	// RVA: 0x77A1644
	internal object <InitViewDataCore>b__1(object results) { }

	// RVA: 0x77A199C
	internal object <InitViewDataCore>b__2(object list) { }

}

// Namespace: Yarp.RuntimeTool
public class RenderResultView
{

	// Fields
	private object m_cameras; // 0x18
	private object m_tempCameraList; // 0x20
	private object m_cameraLastDynamicLightCount; // 0x28
	private object m_cameraLastBakedLightCount; // 0x30
	private object m_subViewDic; // 0x38
	private object m_settingTypes; // 0x40
	private object m_settingTypeNames; // 0x48
	public object currentSettingIndex; // 0x50
	private object m_isDirty; // 0x58
	private object m_needInitRenderSetting; // 0x59
	private object m_needInitKey; // 0x60
	private object m_needInitType; // 0x68
	private object m_cameraDataSimpleMemberInfos; // 0x70
	private object m_yaLightSimpleMemberInfos; // 0x78
	private object m_selectedDynamicYaLightIndices; // 0x80
	private object m_selectedBakedYaLightIndices; // 0x88

	// Methods

	// RVA: 0x779C6CC
	public override object Init() { }

	// RVA: 0x779D8D4
	public override object DrawLayout() { }

	// RVA: 0x779E13C
	private object CheckIsDirty(object allCameras) { }

	// RVA: 0x779E56C
	private object InitData() { }

	// RVA: 0x779E920
	private object InitSubViewData(object camera, object subViewType, object showType, object simpleMemberInfoList) { }

	// RVA: 0x779F3EC
	private object InitViewDataCore(object subViewData) { }

	// RVA: 0x779EE14
	public static object GetColDatas(object result, object key, object showType) { }

	// RVA: 0x779EB70
	private object DrawCameraGroupData(object camera) { }

	// RVA: 0x779F7FC
	public object DrawSubView(object subViewData) { }

	// RVA: 0x779FB98
	private object DrawSubViewCore(object subViewData) { }

	// RVA: 0x77A10C0
	public object .ctor(object name) { }

	// RVA: 0x77A12A8
	private object <Init>b__16_2(object isEditMode) { }

}

// Namespace: Yarp.RuntimeTool
public class RenderSettingsControlView
{

	// Methods

	// RVA: 0x77A1CF4
	public object .ctor(object name) { }

	// RVA: 0x77A1D28
	public override object Init() { }

	// RVA: 0x77A1D2C
	public override object DrawLayout() { }

}

// Namespace: Yarp.RuntimeTool
public class RenderSystemManagerView
{

	// Methods

	// RVA: 0x77A2418
	public object .ctor(object name) { }

	// RVA: 0x77A244C
	public override object Init() { }

	// RVA: 0x77A2450
	public override object DrawLayout() { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugToolSettingsView
{

	// Fields
	private object enableVisibShadow; // 0x11
	private const object SHADOW_KEYWORD;

	// Methods

	// RVA: 0x77A24AC
	public override object Init() { }

	// RVA: 0x77A24B0
	public override object DrawLayout() { }

	// RVA: 0x77A27D8
	private object SetAllSceneMaterialsKeyword(object active) { }

	// RVA: 0x77A2C5C
	public object .ctor(object name) { }

}

// Namespace: Yarp.RuntimeTool
public abstract class RuntimeDebugViewBase
{

	// Fields
	public object name; // 0x8
	public object needTab; // 0x10

	// Methods

	// RVA: 0x779AC2C
	public object .ctor(object name) { }

	// RVA: -1
	public abstract object Init() { }

	// RVA: -1
	public abstract object DrawLayout() { }

}

// Namespace: 
private sealed class <>c__DisplayClass15_0
{

	// Fields
	public object values; // 0x8

	// Methods

	// RVA: 0x77A8D64
	public object .ctor() { }

	// RVA: 0x77A8DCC
	internal object <MultiSelect>b__0(object i) { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugViewBuilder
{

	// Fields
	private static object m_keyboard; // 0x0
	private static object m_keyboardId; // 0x8
	private static object m_keyboardCounter; // 0xC
	private static object m_dragSpeed; // 0x10

	// Methods

	// RVA: 0x77A2C90
	public static object InputTextWithKeyboard(object label, object value, object realValue, object maxLength) { }

	// RVA: 0x77A2E1C
	private static object DragScalar(object label, object curValue, object ptr, object dragSpeed) { }

	// RVA: 0x77A460C
	private static object TryCallKeyBoard(object id, object showText) { }

	// RVA: 0x77A4850
	private static object DragScalarN(object label, object curValue, object ptr, object dragSpeed) { }

	// RVA: 0x77985D0
	public static object Clear(object dataDic) { }

	// RVA: 0x77A58F8
	public static object ClearPtr(object ID, object dataDic) { }

	// RVA: 0x77A59F8
	private static object GetPtr(object dataDic, object id, object value) { }

	// RVA: 0x77A7298
	public static object AutoDraw(object dataDic, object id, object label, object value) { }

	// RVA: 0x77A474C
	private static object ReadBytes(object size, object ptr) { }

	// RVA: 0x77A54EC
	private static object ReadFloatValues(object ptr, object type, object num) { }

	// RVA: 0x77A8178
	public static object AutoDrawWithMemento(object memberInfo, object editObj, object realObj, object dataDic) { }

	// RVA: 0x77A8A20
	public static object MultiSelect(object label, object values, object selectedIndices) { }

	// RVA: 0x77A8D6C
	public object .ctor() { }

	// RVA: 0x77A8D74
	private static object .cctor() { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugValue
{

	// Fields
	private readonly object <RawValue>k__BackingField; // 0x8

	// Properties
	public object RawValue { get; }

	// Methods

	// RVA: 0x77A8E08
	public object get_RawValue() { }

	// RVA: 0x77A8928
	public object .ctor(object value) { }

	// RVA: 0x77A8E10
	public override object Equals(object obj) { }

	// RVA: 0x77A92C8
	protected object Equals(object other) { }

	// RVA: 0x77A92F0
	public override object GetHashCode() { }

	// RVA: 0x77A9340
	public override object ToString() { }

}

// Namespace: Yarp.RuntimeTool
public class ImGuiTable
{

	// Fields
	private object m_hasHeader; // 0x8
	private object m_tableId; // 0x10
	private object m_rowCount; // 0x18
	private object m_colCount; // 0x1C
	private object m_properHeight; // 0x20
	private object m_properWidth; // 0x24
	private object m_waitTwoFrames; // 0x28
	private object m_headerDrawer; // 0x30
	private object m_cellDrawer; // 0x38

	// Properties
	public object RowCount { get; }
	public object ColCount { get; }

	// Methods

	// RVA: 0x77A938C
	public object get_RowCount() { }

	// RVA: 0x77A9394
	public object get_ColCount() { }

	// RVA: 0x77A939C
	public object .ctor(object tableId, object rowCount, object colCount, object hasHeader, object headerDrawer, object cellDrawer) { }

	// RVA: 0x77A9408
	public object ChangeRowAndCol(object rowCount, object colCount) { }

	// RVA: 0x77A9410
	public object UpdateRowCount(object rowCount) { }

	// RVA: 0x77A9418
	public object Draw() { }

}

// Namespace: Yarp.RuntimeTool
public class ImGuiTreeNodeTable
{

	// Fields
	public object m_rows; // 0x8
	public object m_cols; // 0x10
	private object m_tableId; // 0x18
	private object m_properHeight; // 0x20
	private object m_properWidth; // 0x24
	private object m_waitTwoFrames; // 0x28

	// Properties
	public object RowCount { get; }
	public object ColCount { get; }
	public object TableColCount { get; }

	// Methods

	// RVA: 0x77A95E8
	public object get_RowCount() { }

	// RVA: 0x77A963C
	public object get_ColCount() { }

	// RVA: 0x77A9690
	public object get_TableColCount() { }

	// RVA: 0x779F770
	public object .ctor(object tableId, object rows, object cols) { }

	// RVA: 0x77A0D94
	public object Draw() { }

}

// Namespace: Yarp.RuntimeTool
public class SearchBar<T0>
{

	// Fields
	private object m_searchText; // 0x0
	private object m_searchTextTemp; // 0x0
	private object content; // 0x0
	private object matchMethod; // 0x0
	private object m_searchCallback; // 0x0
	private object m_results; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object content, object matchMethod, object searchCallback) { }

	// RVA: -1
	public object ClearSearchText() { }

	// RVA: -1
	public object UpdateContent(object newContent, object search) { }

	// RVA: -1
	public object Draw() { }

	// RVA: -1
	public object Search() { }

	// RVA: -1
	private object SearchResults() { }

	// RVA: -1
	private object DefaultMatchMethod(object regex, object item) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__6_0; // 0x8

	// Methods

	// RVA: 0x77A9BDC
	private static object .cctor() { }

	// RVA: 0x77A9C3C
	public object .ctor() { }

	// RVA: 0x77A9C44
	internal object <Init>b__6_0(object regex, object info) { }

}

// Namespace: Yarp.RuntimeTool
public class ReflectionSearchBar
{

	// Fields
	private object m_searchBar; // 0x8
	public object bindingFlags; // 0x10
	private object m_type; // 0x18
	private object m_searchCallBack; // 0x20
	private object m_contents; // 0x28

	// Methods

	// RVA: 0x779F734
	public object .ctor(object searchType, object searchCallback) { }

	// RVA: 0x77A99A4
	private object Init() { }

	// RVA: 0x779C368
	public object UpdateContent(object newType, object search) { }

	// RVA: 0x77A9BC0
	private object SearchCallBack(object results) { }

	// RVA: 0x77A0B5C
	public object Draw() { }

	// RVA: 0x77A0D38
	public object Search() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__14_0; // 0x8
	public static object <>9__18_0; // 0x10
	public static object <>9__19_0; // 0x18
	public static object <>9__20_0; // 0x20

	// Methods

	// RVA: 0x77AA6DC
	private static object .cctor() { }

	// RVA: 0x77AA73C
	public object .ctor() { }

	// RVA: 0x77AA744
	internal object <IsValid>b__14_0(object _) { }

	// RVA: 0x77AA7F8
	internal object <ToList>b__18_0(object a, object b) { }

	// RVA: 0x77AA8AC
	internal object <ToList>b__19_0(object a, object b) { }

	// RVA: 0x77AA960
	internal object <ToList>b__20_0(object a, object b) { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugMemberInfo
{

	// Fields
	private object m_fieldInfo; // 0x8
	private object m_propertyInfo; // 0x10
	private object m_info; // 0x18
	public object infoType; // 0x20

	// Properties
	public object DataType { get; }
	public object Name { get; }

	// Methods

	// RVA: 0x77A9CB8
	public object get_DataType() { }

	// RVA: 0x779D8A0
	public object .ctor(object fieldInfo) { }

	// RVA: 0x779D86C
	public object .ctor(object propertyInfo) { }

	// RVA: 0x77A9D54
	public object .ctor(object memberInfo) { }

	// RVA: 0x779C49C
	public object get_Name() { }

	// RVA: 0x77A8838
	public object GetValue(object data) { }

	// RVA: 0x77A8954
	public object SetValue(object data, object value) { }

	// RVA: 0x77A87D0
	public object IsEditable() { }

	// RVA: 0x77A9ED0
	public object IsValid() { }

	// RVA: 0x77A8784
	public object GetHashCode() { }

	// RVA: 0x77A9FFC
	public static object op_Implicit(object fieldInfo) { }

	// RVA: 0x77AA06C
	public static object op_Implicit(object propertyInfo) { }

	// RVA: 0x77AA0DC
	public static object ToList(object memberInfos) { }

	// RVA: 0x77AA3DC
	public static object ToList(object memberInfos) { }

	// RVA: 0x779B688
	public static object ToList(object fieldInfos, object propertyInfos) { }

}

// Namespace: Yarp.RuntimeTool
public enum MemberInfoType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FieldInfo;
	public const object PropertyInfo;
}

// Namespace: Yarp.RuntimeTool
public enum RuntimeDebugShowType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RealTime;
	public const object Edit;
}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugTableCol
{

	// Fields
	public object obj; // 0x8
	public object refRealObj; // 0x10
	public object showType; // 0x18

	// Methods

	// RVA: 0x779F7B8
	public object .ctor(object obj, object refRealObj) { }

	// RVA: 0x77A15A8
	public object GetShowName() { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeDebugTableRow
{

	// Fields
	public object showName; // 0x8
	public object memberInfo; // 0x10
	public object dataType; // 0x18
	public object children; // 0x20
	public object colDatas; // 0x28
	public object drawer; // 0x30
	public object isOpen; // 0x38

	// Properties
	public object IsLeaf { get; }
	public object CanShowMore { get; }

	// Methods

	// RVA: 0x77AAA14
	public object get_IsLeaf() { }

	// RVA: 0x77AAA70
	public object get_CanShowMore() { }

	// RVA: 0x779C4E8
	public object .ctor(object showName, object memberInfo, object colDatas, object children, object drawer) { }

	// RVA: 0x77AAB24
	public object DefaultDrawer(object col) { }

	// RVA: 0x77A96E8
	public object Draw() { }

	// RVA: 0x77AAE70
	public object InitChildren() { }

}

// Namespace: Yarp.RuntimeTool
public class SystemInfoView
{

	// Methods

	// RVA: 0x77AB364
	public object .ctor(object name) { }

	// RVA: 0x77AB398
	public override object Init() { }

	// RVA: 0x77AB39C
	public override object DrawLayout() { }

}

// Namespace: Yarp.RuntimeTool
public class VolumeDetailView
{

	// Fields
	private object m_model; // 0x18
	private object m_interpolations; // 0x20
	private object m_fieldInfos; // 0x28
	private object m_defaultRowNames; // 0x30

	// Methods

	// RVA: 0x77AB884
	public override object Init() { }

	// RVA: 0x77AB8F0
	public override object DrawLayout() { }

	// RVA: 0x77ABD30
	private object DrawHeader(object row, object col) { }

	// RVA: 0x77ABDC8
	private object DrawCell(object row, object col) { }

	// RVA: 0x77AC4DC
	public object .ctor(object name) { }

}

// Namespace: Yarp.RuntimeTool
public class RuntimeInspectorManager
{

	// Fields
	private static object m_go; // 0x0

	// Methods

	// RVA: 0x77AC5F8
	public static object Toggle() { }

	// RVA: 0x77AC780
	public object .ctor() { }

}

// Namespace: Yarp.RuntimeTool
public class TemporaryDebugView
{

	// Fields
	private object localReflectionProbes; // 0x18
	private object m_DecalObj; // 0x20
	private object m_SSSObj; // 0x28
	private object m_sunLight; // 0x30

	// Methods

	// RVA: 0x77AC788
	public object .ctor(object name) { }

	// RVA: 0x77AC824
	public override object Init() { }

	// RVA: 0x77AC828
	public override object DrawLayout() { }

	// RVA: 0x77ACD44
	private object ShootingDecal() { }

	// RVA: 0x77ADE84
	private object GenerateLocalReflectionProbes() { }

	// RVA: 0x77AD584
	private object ScreenSpaceSSS() { }

}

// Namespace: 
public enum quant_method
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object QUANT_2;
	public const object QUANT_3;
	public const object QUANT_4;
	public const object QUANT_5;
	public const object QUANT_6;
	public const object QUANT_8;
	public const object QUANT_10;
	public const object QUANT_12;
	public const object QUANT_16;
	public const object QUANT_20;
	public const object QUANT_24;
	public const object QUANT_32;
	public const object QUANT_40;
	public const object QUANT_48;
	public const object QUANT_64;
	public const object QUANT_80;
	public const object QUANT_96;
	public const object QUANT_128;
	public const object QUANT_160;
	public const object QUANT_192;
	public const object QUANT_256;
	public const object Count;
	public const object WEIGHT_QUANT_MAX;
}

// Namespace: 
public struct btq_count
{

	// Fields
	public object bits; // 0xFFFFFFFFFFFFFFF8
	public object trits; // 0xFFFFFFFFFFFFFFF9
	public object quints; // 0xFFFFFFFFFFFFFFFA
}

// Namespace: 
public struct ise_size
{

	// Fields
	public object scale; // 0xFFFFFFFFFFFFFFF8
	public object divisor; // 0xFFFFFFFFFFFFFFF9
}

// Namespace: Yarp.realtime_astc
public static class bise
{

	// Fields
	public static readonly object quant_method_to_level; // 0x0
	public static readonly object quints_of_integer; // 0x8
	public static readonly object integer_of_quints; // 0x10
	public static readonly object trits_of_integer; // 0x18
	public static readonly object integer_of_trits; // 0x20
	public static readonly object btq_counts; // 0x28
	public static readonly object scramble_map; // 0x30
	public static readonly object unscramble_and_unquant_map; // 0x38
	private static readonly object quant_mode_table; // 0x40
	public static readonly object color_uquant_to_scrambled_pquant_tables; // 0x48
	public static readonly object color_scrambled_pquant_to_uquant_tables; // 0x50
	public const object ise_sizes_length;
	public static readonly object ise_sizes; // 0x58

	// Methods

	// RVA: 0x77AE4B4
	public static object get_ise_sequence_bitcount(object character_count, object quant_level) { }

	// RVA: 0x77AE5C0
	public static object write_bits(object value, object bit_count, object bit_offset, object data) { }

	// RVA: 0x77AE60C
	public static object read_bits(object bitCount, object bitOffset, object data) { }

	// RVA: 0x77AE630
	public static object encode(object quant_level, object character_count, object input_data, object output_data, object bit_offset) { }

	// RVA: 0x77AF198
	public static object decode(object quant_level, object character_count, object input_data, object output_data, object bit_offset) { }

	// RVA: 0x77AF8C8
	public static object get_end_point_quant_method(object weight_quant_method, object end_point_value_count) { }

	// RVA: 0x77AF978
	public static object get_end_point_quant_method(object bits_for_weights, object end_point_value_count) { }

	// RVA: 0x77AFA34
	private static object .cctor() { }

}

// Namespace: Yarp.realtime_astc
public struct byte4
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFF9
	public object z; // 0xFFFFFFFFFFFFFFFA
	public object w; // 0xFFFFFFFFFFFFFFFB

	// Methods

	// RVA: 0x77B00B0
	public object .ctor(object x, object y, object z, object w) { }

	// RVA: 0x77B00D8
	public object .ctor(object val) { }

	// RVA: 0x77B01A8
	public object .ctor(object color) { }

	// RVA: 0x77B0278
	public object to_unorm() { }

	// RVA: 0x77B02D0
	public object to_uint() { }

	// RVA: 0x77B02E0
	public object Equals(object other) { }

	// RVA: 0x77B0370
	public override object ToString() { }

}

// Namespace: 
private struct line4
{

	// Fields
	public object a; // 0xFFFFFFFFFFFFFFF8
	public object b; // 0x8
}

// Namespace: Yarp.realtime_astc
public struct compute_end_point_and_weight_job
{

	// Fields
	public object input_texture; // 0xFFFFFFFFFFFFFFF8
	public object block_native_array; // 0x8
	public object with_alpha_channel; // 0x18
	public object block_num_x; // 0x1C
	public object block_offset; // 0x20
	public object input_texture_width; // 0x24
	public object input_texture_height; // 0x28
	public object end_point_format; // 0x2C
	private object end_point_quant_method; // 0x30
	private object block_mode; // 0x34

	// Methods

	// RVA: 0x77B05A4
	public object initialize(object weight_quant_method) { }

	// RVA: 0x77B0658
	private object normalize_safe(object a, object safe) { }

	// RVA: 0x77B071C
	private object get_texel_color_from_block(object block_texels, object texel_index) { }

	// RVA: 0x77B0754
	public object Execute(object block_1d_index) { }

}

// Namespace: 
private static class shader_props
{

	// Fields
	public static readonly object input_texture; // 0x0
	public static readonly object input_texture_mip_level; // 0x4
	public static readonly object input_texture_width; // 0x8
	public static readonly object input_texture_height; // 0xC

	// Methods

	// RVA: 0x77B3EC0
	private static object .cctor() { }

}

// Namespace: Yarp.realtime_astc
public class encoder
{

	// Fields
	private static object gpu_compatibility_info_initialized; // 0x0
	private static object support_gpu_compression; // 0x1
	private static object quad_mesh; // 0x8
	private object command_buffer_with_ownership; // 0x8
	private object blit_pass_shader; // 0x10
	private object blit_pass_material; // 0x18
	private object realtime_astc_encode_shader; // 0x20
	private object realtime_astc_encode_material; // 0x28
	private object internal_render_texture; // 0x30

	// Methods

	// RVA: 0x77B1E70
	public object initialize_gpu_compatibility_info() { }

	// RVA: 0x77B1F50
	public object encode(object command_buffer, object input_texture, object output_texture, object with_alpha_channel) { }

	// RVA: 0x77B3A7C
	public object create_compressed_texture(object input_texture) { }

	// RVA: 0x77B3E14
	public object encode(object command_buffer, object input_texture, object with_alpha_channel) { }

	// RVA: 0x77B2B20
	private object pixel_pipeline_encode(object command_buffer, object input_texture, object output_texture, object with_alpha_channel) { }

	// RVA: 0x77B3E74
	public object Dispose() { }

	// RVA: 0x77B3EB8
	public object .ctor() { }

}

// Namespace: Yarp.realtime_astc
public enum end_point_formats
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FMT_LUMINANCE;
	public const object FMT_LUMINANCE_DELTA;
	public const object FMT_HDR_LUMINANCE_LARGE_RANGE;
	public const object FMT_HDR_LUMINANCE_SMALL_RANGE;
	public const object FMT_LUMINANCE_ALPHA;
	public const object FMT_LUMINANCE_ALPHA_DELTA;
	public const object FMT_RGB_SCALE;
	public const object FMT_HDR_RGB_SCALE;
	public const object FMT_RGB;
	public const object FMT_RGB_DELTA;
	public const object FMT_RGB_SCALE_ALPHA;
	public const object FMT_HDR_RGB;
	public const object FMT_RGBA;
	public const object FMT_RGBA_DELTA;
	public const object FMT_HDR_RGB_LDR_ALPHA;
	public const object FMT_HDR_RGBA;
}

// Namespace: Yarp.realtime_astc
public struct symbolic_block
{

	// Fields
	public object block_mode; // 0xFFFFFFFFFFFFFFF8
	public object end_point_format; // 0x0
	public object end_point_quant_method; // 0x4
	public object weights; // 0x8
	public object color_values; // 0x10

	// Methods

	// RVA: 0x77B1A54
	public object write_to_physical_block(object pcb, object weight_unorm_range) { }

	// RVA: 0x77B4180
	public object from_physical_block(object pcb) { }

	// RVA: 0x77B46B0
	public object fill_pixel_block(object pixel_data) { }

	// RVA: 0x77B4A48
	public override object ToString() { }

}

// Namespace: Yarp.realtime_astc
public class test
{

	// Fields
	public object rgba_texture; // 0x18
	public object compressed_rgba_texture; // 0x20
	private object _encoder_instance; // 0x28

	// Methods

	// RVA: 0x77B4D14
	private object OnDisable() { }

	// RVA: 0x77B4D70
	private object OnEnable() { }

	// RVA: 0x77B4E9C
	public object run_test() { }

	// RVA: 0x77B7614
	public object compress() { }

	// RVA: 0x77B4F34
	private object reverse_byte_test() { }

	// RVA: 0x77B4FD4
	private object get_ise_sequence_bitcount_test() { }

	// RVA: 0x77B5494
	private object block_mode_test() { }

	// RVA: 0x77B5844
	private object bise_quant_40_test() { }

	// RVA: 0x77B5BE0
	private object bise_quant_96_test() { }

	// RVA: 0x77B5F7C
	private object bise_quant_128_test() { }

	// RVA: 0x77B6318
	private object get_end_point_quant_method_test() { }

	// RVA: 0x77B6530
	private object weight_quant_test() { }

	// RVA: 0x77B7084
	private object log_valid_block_mode() { }

	// RVA: 0x77B787C
	public object .ctor() { }

}

// Namespace: Yarp.realtime_astc
public struct texture_block_mode
{

	// Fields
	private const object BLOCK_MAX_WEIGHTS;
	private const object BLOCK_MIN_WEIGHT_BITS;
	private const object BLOCK_MAX_WEIGHT_BITS;
	public static readonly object valid_block_modes; // 0x0
	public static readonly object valid_quant_mode; // 0xFFFFFFFFFFFFFFF8
	public static readonly object valid_weight_bits; // 0x0
	private const object invalid_rho_index;
	private static readonly object rho_possible_result; // 0x8
	private static readonly object weight_range_to_rho_index; // 0x10
	private const object x_weights;
	private const object y_weights;
	private const object is_dual_plane;
	public object quant_mode; // 0xFFFFFFFFFFFFFFF8
	public object weight_bits; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x77B45D4
	public object .ctor(object block_mode) { }

	// RVA: 0x77B7938
	public object .ctor(object quant_mode, object weight_bits) { }

	// RVA: 0x77B7948
	private object weight_range_to_rho_and_p(object weight_range, object rho_and_p) { }

	// RVA: 0x77B3FF4
	public object pack_to_binary() { }

	// RVA: 0x77B7A60
	private object invalidate() { }

	// RVA: 0x77B4688
	public object is_valid() { }

	// RVA: 0x77B7A90
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass0_0<T0>
{

	// Fields
	public object task_completion_source; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <request_into_native_array_async>g__Callback|0(object request) { }

}

// Namespace: Yarp.realtime_astc
public static class utils
{

	// Methods

	// RVA: -1
	public static object request_into_native_array_async(object output, object src) { }

	// RVA: 0x77B7A34
	public static object set_bit(object value, object position, object bitValue) { }

	// RVA: 0x77B0640
	public static object get_end_point_value_count(object format) { }

	// RVA: 0x77B3FC0
	public static object weight_unorm_to_weight_quantized(object weight_unorm, object weight_quant_range, object unorm_range) { }

	// RVA: 0x77B7CAC
	public static object weight_quantized_to_weight_unorm(object weight_unorm, object weight_quant_range, object unorm_range) { }

	// RVA: 0x77B412C
	public static object write_bits(object value, object bit_count, object bit_offset, object ptr) { }

	// RVA: 0x77B45B4
	public static object read_bits(object bitcount, object bitoffset, object ptr) { }

	// RVA: 0x77B3FE8
	public static object reverse_byte(object p) { }

	// RVA: 0x77B34B0
	public static object round_to_blocks(object w) { }

	// RVA: 0x77B3DE0
	public static object calculate_mipmap_count(object width, object height, object min_mip_size) { }

	// RVA: 0x77B34C8
	public static object calculate_mipmap_offset(object width, object height, object mip_level) { }

	// RVA: 0x77B362C
	public static object build_draw_quad_mesh(object flip) { }

	// RVA: 0x77B7D7C
	internal static object <calculate_mipmap_offset>g___round_to_blocks|10_0(object w, object h, object bw, object bh, object bs) { }

}

// Namespace: Yarp.TinyReBLUR
public class AccumulatePass
{

	// Fields
	private object m_fastDiffMip; // 0x8
	private object m_lastFrameCameraPos; // 0x10
	public object reset; // 0x1C
	private object m_accumulateAOMaterial; // 0x20
	private static readonly object GInFastDiff; // 0x0
	private static readonly object GCameraDeltaViewSpace; // 0x4
	private static readonly object Reset; // 0x8
	private static readonly object GInDiff; // 0xC
	private static readonly object GHistoryDepth; // 0x10
	private static readonly object GHistoryDiffAccumSpeed; // 0x14
	private static readonly object GHistoryDiff; // 0x18
	private static readonly object GBlurPixelSizeAndScreenSize; // 0x1C
	private static readonly object GInBlurData; // 0x20
	private static readonly object GInAccumSpeedTexture; // 0x24
	private static readonly object UVToPrevUVMatrix; // 0x28

	// Properties
	private object accumulateAOMaterial { get; }

	// Methods

	// RVA: 0x77B7DA0
	public object .ctor(object format) { }

	// RVA: 0x77B7F24
	private object get_accumulateAOMaterial() { }

	// RVA: 0x77B8120
	private object NDCToUV() { }

	// RVA: 0x77B820C
	private object UVToNDC() { }

	// RVA: 0x77B82EC
	private object GetUVZToPrevUVZMatrix(object camera) { }

	// RVA: 0x77B85D4
	public object LinearAccumulateAO(object cmd, object cameraData, object ao, object aoLinearAccumulated, object block) { }

	// RVA: 0x77B8CC0
	public object Dispose() { }

	// RVA: 0x77B8D50
	private static object .cctor() { }

}

// Namespace: 
public enum SignalType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object REBLUR_OCCLUSION;
	public const object REBLUR_DIFFUSE;
	public const object REBLUR_SPECULAR;
}

// Namespace: 
public enum OutputChannel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RawInput;
	public const object DenoisedOutput;
	public const object FastHistory;
}

// Namespace: 
public struct HitDistanceParameters
{

	// Fields
	public object A; // 0xFFFFFFFFFFFFFFF8
	public object B; // 0xFFFFFFFFFFFFFFFC
	public object C; // 0x0
	public object D; // 0x4

	// Methods

	// RVA: 0x77BAC50
	public object ToVector4() { }

	// RVA: 0x77B9A98
	public static object Default() { }

}

// Namespace: 
private struct <>c__DisplayClass54_0
{

	// Fields
	public object samplePos; // 0xFFFFFFFFFFFFFFF8
	public object frameIndex; // 0x0
}

// Namespace: Yarp.TinyReBLUR
public class REBLUR
{

	// Fields
	private object m_linearAccumulatePass; // 0x8
	private object m_hitDistReconstructionMaterial; // 0x10
	private object m_diffuseOcclusionBlurMaterial; // 0x18
	private object m_splitScreenMaterial; // 0x20
	private object HIT_DIST_RECONSTRUCTION_KERNEL_TAP_5; // 0x28
	private object HIT_DIST_RECONSTRUCTION_KERNEL_BLURRY; // 0x40
	public object minBlurRadius; // 0x58
	public object maxBlurRadius; // 0x5C
	public object planeDistanceSensitivity; // 0x60
	public object lobeAngleFraction; // 0x64
	public object minHitDistanceWeight; // 0x68
	public object historyFixFrameNum; // 0x6C
	public object maxAccumulatedFrameNum; // 0x70
	public object maxFastAccumulatedFrameNum; // 0x74
	public object hitDistScale; // 0x78
	public object meterToUnitsMultiplier; // 0x7C
	public object historyFixBasePixelStride; // 0x80
	public object signalType; // 0x84
	public object hitDistReconstruction5x5; // 0x88
	public object hitDistReconstructionBlurry; // 0x89
	public object fastHistory; // 0x8A
	public object performanceMode; // 0x8B
	public object enableSplitScreen; // 0x8C
	public object splitScreen; // 0x90
	public object UseReBlurLinearAccumulate; // 0x94
	public object leftSplit; // 0x98
	public object rightSplit; // 0x9C
	private object rotatorPre; // 0xA0
	private object rotator; // 0xB0
	private object rotatorPost; // 0xC0
	private const object REBLUR_MAX_HISTORY_FRAME_NUM;
	private static readonly object GMinBlurRadius; // 0x0
	private static readonly object GMaxBlurRadius; // 0x4
	private static readonly object GPlaneDistSensitivity; // 0x8
	private static readonly object GLobeAngleFraction; // 0xC
	private static readonly object GMinHitDistanceWeight; // 0x10
	private static readonly object GHistoryFixFrameNum; // 0x14
	private static readonly object GMaxAccumulatedFrameNum; // 0x18
	private static readonly object GMinRectDimMulUnproject; // 0x1C
	private static readonly object GResolutionScale; // 0x20
	private static readonly object GRectSize; // 0x24
	private static readonly object GRectSizeInv; // 0x28
	private static readonly object GProjectionMatrix; // 0x2C
	private static readonly object GRotator; // 0x30
	private static readonly object GInDiff; // 0x34
	private static readonly object GInFastDiff; // 0x38
	private static readonly object GHitDistParams; // 0x3C
	private static readonly object GViewZScale; // 0x40
	private object internalRT; // 0xD0
	private object diffRawCopyRT; // 0xD8
	private static readonly object GInDiffAccumSpeed; // 0x44
	private static readonly object GSplitScreen; // 0x48
	private static readonly object GRectSizeMinusOne; // 0x4C
	private static readonly object SplitScreenTempRT; // 0x50
	private static readonly object GHistoryFixBasePixelStride; // 0x54
	private static readonly object GInLeft; // 0x58
	private static readonly object GInRight; // 0x5C
	private static readonly object GMaxFastAccumulatedFrameNum; // 0x60
	private static readonly object GDiffPrepassBlurRadius; // 0x64
	private static readonly object GInvMaxAccumFrameCount; // 0x68

	// Methods

	// RVA: 0x77B8F94
	private object Weyl1D(object p, object n) { }

	// RVA: 0x77B9070
	private object GetRotator(object angle) { }

	// RVA: 0x77B913C
	private object CombineRotators(object r1, object r2) { }

	// RVA: 0x77B9170
	private object Bayer4x4(object samplePos, object frameIndex) { }

	// RVA: 0x77B9308
	private object UpdateRotator() { }

	// RVA: 0x77B9A78
	public object GetHitDistanceParameters() { }

	// RVA: 0x77B9AB4
	private object GetFormatBySignalType() { }

	// RVA: 0x77B9ACC
	public object Render(object commands, object camera, object propBlock, object srcTex, object pingPongAO) { }

	// RVA: 0x77BAC5C
	public object Dispose() { }

	// RVA: 0x77BAD5C
	public object .ctor() { }

	// RVA: 0x77BADB8
	private static object .cctor() { }

	// RVA: 0x77BB2BC
	internal static object <Bayer4x4>g__ReverseBits4|54_0(object x) { }

	// RVA: 0x77B9268
	internal static object <Bayer4x4>g__Bayer4x4ui|54_1(object ) { }

}

// Namespace: 
public enum FreeRectChoiceHeuristic
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RectBestShortSideFit;
	public const object RectBestLongSideFit;
	public const object RectBestAreaFit;
	public const object RectBottomLeftRule;
	public const object RectContactPointRule;
}

// Namespace: Yarp.RectPacking
public struct MaxRectsBinPack
{

	// Fields
	public object curRectWidth; // 0xFFFFFFFFFFFFFFF8
	public object curRectHeight; // 0xFFFFFFFFFFFFFFFC
	public object curPadding; // 0x0
	public object curMethod; // 0x4
	public object curResRect; // 0x8
	private object binWidth; // 0x18
	private object binHeight; // 0x1C
	private object binAllowFlip; // 0x20
	private object newFreeRectanglesLastSize; // 0x24
	private object newFreeRectangles; // 0x28
	private object usedRectangles; // 0x30
	private object freeRectangles; // 0x38

	// Methods

	// RVA: 0x77BB360
	public object Init(object width, object height, object allowFlip) { }

	// RVA: 0x77BB50C
	public object Execute(object index) { }

	// RVA: 0x77BB6A0
	public object Dispose() { }

	// RVA: 0x77BB73C
	public object Insert(object rects, object dst, object method, object padding) { }

	// RVA: 0x77BB53C
	public object Insert(object width, object height, object method, object padding) { }

	// RVA: 0x77BDBE8
	public object Occupancy() { }

	// RVA: 0x77BBA70
	private object ScoreRect(object width, object height, object method, object score1, object score2) { }

	// RVA: 0x77BBB84
	private object PlaceRect(object node) { }

	// RVA: 0x77BE2C4
	private object ContactPointScoreNode(object x, object y, object width, object height) { }

	// RVA: 0x77BC3AC
	private object FindPositionForNewNodeBottomLeft(object width, object height, object bestY, object bestX) { }

	// RVA: 0x77BBDB4
	private object FindPositionForNewNodeBestShortSideFit(object width, object height, object bestShortSideFit, object bestLongSideFit) { }

	// RVA: 0x77BCF6C
	private object FindPositionForNewNodeBestLongSideFit(object width, object height, object bestShortSideFit, object bestLongSideFit) { }

	// RVA: 0x77BD564
	private object FindPositionForNewNodeBestAreaFit(object width, object height, object bestAreaFit, object bestShortSideFit) { }

	// RVA: 0x77BC9E8
	private object FindPositionForNewNodeContactPoint(object width, object height, object bestContactScore) { }

	// RVA: 0x77BE840
	private object InsertNewFreeRectangle(object newFreeRect) { }

	// RVA: 0x77BDD88
	private object SplitFreeNode(object freeNode, object usedNode) { }

	// RVA: 0x77BDF58
	private object PruneFreeList() { }

	// RVA: 0x77BE7E8
	internal static object <ContactPointScoreNode>g__CommonIntervalLength|21_0(object i1start, object i1end, object i2start, object i2end) { }

}

// Namespace: Yarp.RectPacking
public static class NativeListExtensions
{

	// Methods

	// RVA: -1
	public static object PopBack(object list) { }

	// RVA: -1
	public static object Back(object list) { }

}

// Namespace: Yarp.RectPacking
public struct RectSize
{

	// Fields
	public object width; // 0xFFFFFFFFFFFFFFF8
	public object height; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: Yarp.RectPacking
public struct Rect
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object width; // 0x0
	public object height; // 0x4

	// Methods

	// RVA: 0x77BEB80
	public static object IsContainedIn(object a, object b) { }

	// RVA: 0x77BEBDC
	public object GetScaleOffset(object binSize, object padding) { }

	// RVA: 0x77BEC74
	public object GetSizePosition(object padding) { }

}

// Namespace: Yarp.RectPacking
public class DisjointRectCollection
{

	// Fields
	public object rects; // 0x8

	// Methods

	// RVA: 0x77BECC4
	public object Add(object r) { }

	// RVA: 0x77BEF00
	public object Clear() { }

	// RVA: 0x77BEE04
	public object Disjoint(object r) { }

	// RVA: 0x77BEF5C
	public static object Disjoint(object a, object b) { }

	// RVA: 0x77BEFA8
	public object .ctor() { }

}

// Namespace: 
public struct Visitor
{

	// Fields
	private object bitArray; // 0xFFFFFFFFFFFFFFF8
	private object position; // 0x0
	private object targetBitValue; // 0x4
	private object initialized; // 0x5

	// Properties
	private object SkipValue { get; }
	public object Current { get; }

	// Methods

	// RVA: 0x77BF4A8
	private object get_SkipValue() { }

	// RVA: 0x77BEFC0
	public object .ctor(object bitArray, object targetBitValue) { }

	// RVA: 0x77BF4D4
	public object get_Current() { }

	// RVA: 0x77BF4E4
	public object MoveNext() { }

}

// Namespace: Yarp.Collections
public class BitArray
{

	// Fields
	private object data; // 0x8
	private object count; // 0x10

	// Properties
	public object Item { get; set; }
	public object Count { get; }

	// Methods

	// RVA: 0x77BEFB0
	public object MakeVisitor(object targetBitValue) { }

	// RVA: 0x77BEFD4
	public object Add(object bitValue) { }

	// RVA: 0x77BF1D8
	public object Add(object bitValue, object numBits) { }

	// RVA: 0x77BF33C
	private static object Get32(object index, object data) { }

	// RVA: 0x77BF348
	private static object Set32(object index, object data, object value) { }

	// RVA: 0x77BF36C
	public object get_Item(object index) { }

	// RVA: 0x77BF114
	public object set_Item(object index, object value) { }

	// RVA: 0x77BF3E4
	public object get_Count() { }

	// RVA: 0x77BF3EC
	public object .ctor() { }

}

// Namespace: 
private struct SubAllocInfo
{

	// Fields
	public object Level; // 0xFFFFFFFFFFFFFFF8
	public object QuadIdx; // 0xFFFFFFFFFFFFFFFC
	public object UVScaleBias; // 0x0
}

// Namespace: Yarp.Collections
public class RectAllocator
{

	// Fields
	public const object INDEX_NONE;
	private object TileSize; // 0x8
	private object BorderSize; // 0xC
	private object TileSizeWithBorder; // 0x10
	private object DimInTiles; // 0x14
	private object DimInTexels; // 0x18
	private object TexelSize; // 0x1C
	private object MarkerQuadTree; // 0x20
	private object LevelOffsets; // 0x28
	private object SubAllocInfos; // 0x30

	// Methods

	// RVA: 0x77BF714
	public object .ctor(object tileSize, object borderSize, object dimInTiles) { }

	// RVA: 0x77BF9B0
	private static object DivideRoundUp(object numerator, object denominator) { }

	// RVA: 0x77BFA24
	private static object ReverseMortonCode2(object x) { }

	// RVA: 0x77BFA4C
	public object CanAlloc(object SizeX, object SizeY) { }

	// RVA: 0x77BFC04
	public object Alloc(object SizeX, object SizeY) { }

	// RVA: 0x77C00C0
	public object Free(object handle) { }

	// RVA: 0x77C0528
	public object GetScaleBias(object Handle) { }

	// RVA: 0x77C05AC
	public object GetSizePosition(object Handle) { }

}

// Namespace: Yarp.Collections
public class SparseArray<T0>
{

	// Fields
	private object freeSlots; // 0x0
	public object data; // 0x0
	public object allocationFlags; // 0x0

	// Methods

	// RVA: -1
	public object Add(object value) { }

	// RVA: -1
	public object Free(object handle) { }

	// RVA: -1
	public object GetData(object handle) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <GetModifiers>d__3
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	public object <>4__this; // 0x20
	private object updateForce; // 0x28
	public object <>3__updateForce; // 0x29
	private object includeInactive; // 0x2A
	public object <>3__includeInactive; // 0x2B
	private object <>7__wrap1; // 0x30
	private object <>7__wrap2; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<Yarp.AnimateMaterial.GraphicPropertyOverride>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x77C0768
	public object .ctor(object <>1__state) { }

	// RVA: 0x77C0D70
	private object System.IDisposable.Dispose() { }

	// RVA: 0x77C0D74
	private object MoveNext() { }

	// RVA: 0x77C1370
	private object System.Collections.Generic.IEnumerator<Yarp.AnimateMaterial.GraphicPropertyOverride>.get_Current() { }

	// RVA: 0x77C1378
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x77C13B8
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x77C13C0
	private object System.Collections.Generic.IEnumerable<Yarp.AnimateMaterial.GraphicPropertyOverride>.GetEnumerator() { }

	// RVA: 0x77C1474
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: Yarp.AnimateMaterial
public class GraphicMaterialOverride
{

	// Fields
	private object graphic; // 0x18
	private object modifiers; // 0x20

	// Methods

	// RVA: 0x77C0684
	public object SetMaterialDirty() { }

	// RVA: 0x77C06D4
	public object GetModifiers(object includeInactive, object updateForce) { }

	// RVA: 0x77C07A0
	private object OnEnable() { }

	// RVA: 0x77C083C
	private object OnDisable() { }

	// RVA: 0x77C088C
	public object GetModifiedMaterial(object baseMaterial) { }

	// RVA: 0x77C0D68
	public object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public abstract class GraphicPropertyOverride
{

	// Fields
	protected object propertyName; // 0x18
	protected object PropertyId; // 0x20

	// Properties
	public object PropertyName { get; set; }
	protected object ParentGraphic { get; }
	protected object ParentOverride { get; }

	// Methods

	// RVA: 0x77C1528
	private object OnEnable() { }

	// RVA: 0x77C1618
	private object OnDisable() { }

	// RVA: 0x77C1530
	public object SetMaterialDirty(object renewId) { }

	// RVA: 0x77C16A0
	public object get_PropertyName() { }

	// RVA: 0x77C16A8
	public object set_PropertyName(object value) { }

	// RVA: 0x77C131C
	public object IsEnabled() { }

	// RVA: -1
	public abstract object ApplyModifiedProperty(object material) { }

	// RVA: -1
	public abstract object ApplyModifiedProperty(object material) { }

	// RVA: -1
	public abstract object ResetPropertyToDefault() { }

	// RVA: -1
	public abstract object GetMaterialValue(object material) { }

	// RVA: 0x77C16B4
	protected object get_ParentGraphic() { }

	// RVA: 0x77C1620
	protected object get_ParentOverride() { }

	// RVA: 0x77C1734
	protected object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public abstract class GraphicPropertyOverride<T0>
{

	// Fields
	protected object propertyValue; // 0x0
	private object _previousValue; // 0x0
	private object _previousValueIsInit; // 0x0

	// Properties
	public object PropertyValue { get; set; }

	// Methods

	// RVA: -1
	private object LateUpdate() { }

	// RVA: -1
	public object OnDidApplyAnimationProperties() { }

	// RVA: -1
	public object get_PropertyValue() { }

	// RVA: -1
	public object set_PropertyValue(object value) { }

	// RVA: -1
	public override object ResetPropertyToDefault() { }

	// RVA: -1
	public abstract object GetDefaultValue(object material, object defaultValue) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public class GraphicPropertyOverrideAxisAngle
{

	// Methods

	// RVA: 0x77C173C
	public static object GetRotation(object angle) { }

	// RVA: 0x77C1794
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1810
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C188C
	public override object GetDefaultValue(object material, object defaultValue) { }

	// RVA: 0x77C18FC
	public override object GetMaterialValue(object material) { }

	// RVA: 0x77C1940
	public object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public class GraphicPropertyOverrideColor
{

	// Methods

	// RVA: 0x77C1998
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C19CC
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1A00
	public override object GetDefaultValue(object material, object defaultValue) { }

	// RVA: 0x77C1A80
	public override object GetMaterialValue(object material) { }

	// RVA: 0x77C1AC8
	public object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public class GraphicPropertyOverrideFloat
{

	// Methods

	// RVA: 0x77C1B20
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1B50
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1B80
	public override object GetDefaultValue(object material, object defaultValue) { }

	// RVA: 0x77C1BF0
	public override object GetMaterialValue(object material) { }

	// RVA: 0x77C1C34
	public object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public class GraphicPropertyOverrideInt
{

	// Methods

	// RVA: 0x77C1C8C
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1CB8
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1CE4
	public override object GetDefaultValue(object material, object defaultValue) { }

	// RVA: 0x77C1D6C
	public override object GetMaterialValue(object material) { }

	// RVA: 0x77C1DB0
	public object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public class GraphicPropertyOverrideRange
{

	// Methods

	// RVA: 0x77C1E08
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1E38
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1E68
	public override object GetDefaultValue(object material, object defaultValue) { }

	// RVA: 0x77C1ED8
	public override object GetMaterialValue(object material) { }

	// RVA: 0x77C1F1C
	public object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public class GraphicPropertyOverrideTexture
{

	// Methods

	// RVA: 0x77C1F74
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1FA4
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C1FD4
	public override object GetDefaultValue(object material, object defaultValue) { }

	// RVA: 0x77C2048
	public override object GetMaterialValue(object material) { }

	// RVA: 0x77C208C
	public object .ctor() { }

}

// Namespace: Yarp.AnimateMaterial
public class GraphicPropertyOverrideVector
{

	// Methods

	// RVA: 0x77C20E4
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C2118
	public override object ApplyModifiedProperty(object material) { }

	// RVA: 0x77C214C
	public override object GetDefaultValue(object material, object defaultValue) { }

	// RVA: 0x77C21D0
	public override object GetMaterialValue(object material) { }

	// RVA: 0x77C2218
	public object .ctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=3
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=5
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=12
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=16
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=32
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=44
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=84
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=125
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=144
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=243
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=384
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=1280
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=1536
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=4352
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=18102
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=66928
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 0305D78E594696D32FB035CC12A0639B4EB61A874E2DA4E94B0AE66ED7D02FCB; // 0x0
	internal static readonly object 0A1684A9CBE144F6E8F6FAD236F4A1F1538F31C85BDC2858EB638722A4F25443; // 0x5
	internal static readonly object 11047585FE102FBB5CADB42446612A578D88C6EF5ED076BB7AC360C4F9E4373D; // 0x46BB
	internal static readonly object 14996D112027C1C99C18817AE2CF050802A52C616FB11DFDD160384C19C71A47; // 0x46C7
	internal static readonly object 15F2F1A4339F5F2A313B95015CAD8124D054A171AC2F31CF529DDA7CFB6A38B4; // 0x46D7
	internal static readonly object 1885E3E9AD5E459592CEF9FA60B1E2CD7E878340D9E697D001A742035CA6283E; // 0x46DC
	internal static readonly object 2A4467B3EAE8735D06271501A55728840FED4073E7056D6A2263F9F2CC61C819; // 0x4708
	internal static readonly object 2C211989459DD8D2F4448940D62DDA1A7B116684308211FDE6C6B5EEB2BED2FD; // 0x4718
	internal static readonly object 34F7CA19221AA4F91E855E4B922163CFC1DFEC245E064C44C19DDBF038E9A35E; // 0x4728
	internal static readonly object 36BC5CD4AF3917246FA191D0633A587F1BDC9EC17F1DF5E9E2CC87DFAF13D6DD; // 0x5828
	internal static readonly object 3916C9D32FECC4B0B2D149524D1A9947E70B9FF6429877151A318008B1065DB7; // 0x582D
	internal static readonly object 3F4492328273C3B4AAE7FD41CFFF859F24F277328FF135AEFA606B81A02D4D0F; // 0x5881
	internal static readonly object 5594173D7DEEF99CFF49A05FC4AC2DF0C444C17E23FDC630571A1465C51B2265; // 0x58FE
	internal static readonly object 58DBD95E143B4C08EB7ED18C1ABEBA62DBFD68FD86E9ACCADA20CF25F55F34FC; // 0x5EFE
	internal static readonly object 59AE018FE9BC7649C593160FA309BEAAB537A1CB4E41BF4B9D23B82736D60863; // 0x64FE
	internal static readonly object 5B82E13281882EA22806294BA57D265B4C06AC5A692B341222EA83C7C8BA8BC9; // 0x16A6E
	internal static readonly object 5E26DDCFEE87DD197678748F00634D1C4F6C5CC82AAFF00BF4B9D72B9FA4FFA3; // 0x16A7E
	internal static readonly object 62CB1E4990546B2D9A29FD77D7162C74F30CE709F9FFF5F341935C72E4AD2DCA; // 0x16A8E
	internal static readonly object 682917D38012DA9CCC1571B940738347AA4C593543D1D96480BA2A50D52564C8; // 0x16A91
	internal static readonly object 6CAE5A832697595AAD60E53998FBCB8D3934D1BE4AA535914737C921AEA90788; // 0x16F91
	internal static readonly object 71518AA897EFF6FA1D053F2F9C4B4A0D67208F7FC5060AFD5E376AE3FB437EEC; // 0x16FA1
	internal static readonly object 73F184ED9FA32FBABF1EBCA4A2679AF581720CBE50171A9C8A5641A45BF85715; // 0x16FF5
	internal static readonly object 77482B7184F5115A55F83D85484A55EB0639645348BF21AC119F9E7AD66CB7A7; // 0x16FFA
	internal static readonly object 7A2B89F3C9E4B83A303C3981D84614F6A5C85C68C2C46081824EAD9590D6CA6A; // 0x1701A
	internal static readonly object 879D9327252D2DA25DFADB989DD5EE390F5E6B1AB4123D9741282DA9FB7298A6; // 0x1751A
	internal static readonly object 9E83F79A15EB537595DEDA03D05D5282562C5239B5B79F4FA288FB79AA7A3C63; // 0x175AA
	internal static readonly object B91CB43D075B6C0E16A5F379A893AC00584809C88305EEAD38B8F4EAA2538941; // 0x175BA
	internal static readonly object C99DDA0611559A358C963292F9882036F85D047432A36FCAC5296FE59C69C827; // 0x175E6
	internal static readonly object CF7605ED1BC735F6C825554154627467E1CAC9DF54CEE8699218ED434603C568; // 0x175E9
	internal static readonly object D2DFE01F82F424A1A98855888426B7259B9131CE204C1C6D8724F098E090A1CC; // 0x175EC
	internal static readonly object D7B3D4012540102C40A23ACDEEE417E06A42A74A5D66C7EFE59F4E4AA0537C5C; // 0x17618
	internal static readonly object DB262BD9043CB0102E9996EFDD7A55DF7F1A8E78B5D06E06C526C8379675D31B; // 0x1761B
	internal static readonly object DC67B548C5ED0034CE6500A6BFF7C72905B814F16CDE61F19D5023D341484BE2; // 0x1779B
	internal static readonly object E423B8ED50CAD6065A058AAF396655498DD510C336B4D7F49C33C8AAC766E8E3; // 0x1788E
	internal static readonly object E7410C5E50C4DE67CCB204710C558FF7033D8544DB093A2491FD536A89FFE28C; // 0x1898E
	internal static readonly object F4D310EDE224A522B0CEF9421011648DE9E73CA17809518176B9B6C7F3BC6156; // 0x1899E
}

// Namespace: 
internal class __JobReflectionRegistrationOutput__71870078
{

	// Methods

	// RVA: 0x77C2270
	public static object CreateJobReflectionData() { }

	// RVA: 0x77C2470
	public static object EarlyInit() { }

}

