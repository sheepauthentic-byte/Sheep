// Namespace: 
internal class <Module>
{
}

// Namespace: Pathfinding.Poly2Tri
public static class P2T
{

	// Fields
	private static object _defaultAlgorithm; // 0x0

	// Methods

	// RVA: 0x3CEF408
	public static object Triangulate(object p) { }

	// RVA: 0x3CEF4E0
	public static object CreateContext(object algorithm) { }

	// RVA: 0x3CEF448
	public static object Triangulate(object algorithm, object t) { }

	// RVA: 0x3CEF62C
	public static object Triangulate(object tcx) { }

}

// Namespace: Pathfinding.Poly2Tri
public class Polygon
{

	// Fields
	protected object _points; // 0x8
	protected object _steinerPoints; // 0x10
	protected object _holes; // 0x18
	protected object _triangles; // 0x20
	protected object _last; // 0x28

	// Properties
	public object TriangulationMode { get; }
	public object Points { get; }
	public object Triangles { get; }
	public object Holes { get; }

	// Methods

	// RVA: 0x3CEF798
	public object .ctor(object points) { }

	// RVA: 0x3CEFE68
	public object get_TriangulationMode() { }

	// RVA: 0x3CEFE70
	public object AddHole(object poly) { }

	// RVA: 0x3CEFFD4
	public object AddPoints(object list) { }

	// RVA: 0x3CF04D8
	public object get_Points() { }

	// RVA: 0x3CF04E0
	public object get_Triangles() { }

	// RVA: 0x3CF04E8
	public object get_Holes() { }

	// RVA: 0x3CF04F0
	public object AddTriangle(object t) { }

	// RVA: 0x3CF0610
	public object AddTriangles(object list) { }

	// RVA: 0x3CF067C
	public object ClearTriangles() { }

	// RVA: 0x3CF06EC
	public object Prepare(object tcx) { }

}

// Namespace: Pathfinding.Poly2Tri
public class PolygonPoint
{

	// Fields
	private object <Next>k__BackingField; // 0x20
	private object <Previous>k__BackingField; // 0x28

	// Properties
	public object Next { get; set; }
	public object Previous { set; }

	// Methods

	// RVA: 0x3CF0C38
	public object .ctor(object x, object y) { }

	// RVA: 0x3CF0CA8
	public object get_Next() { }

	// RVA: 0x3CF0CB0
	public object set_Next(object value) { }

	// RVA: 0x3CF0CB8
	public object set_Previous(object value) { }

}

// Namespace: Pathfinding.Poly2Tri
public class DelaunayTriangle
{

	// Fields
	public object Points; // 0x8
	public object Neighbors; // 0x20
	public object EdgeIsConstrained; // 0x38
	public object EdgeIsDelaunay; // 0x3B
	private object <IsInterior>k__BackingField; // 0x3E

	// Properties
	public object IsInterior { get; set; }

	// Methods

	// RVA: 0x3CF0CC0
	public object .ctor(object p1, object p2, object p3) { }

	// RVA: 0x3CF0D64
	public object get_IsInterior() { }

	// RVA: 0x3CF0D6C
	public object set_IsInterior(object value) { }

	// RVA: 0x3CF0D74
	public object IndexOf(object p) { }

	// RVA: 0x3CF0E24
	public object IndexCCWFrom(object p) { }

	// RVA: 0x3CF0E5C
	public object Contains(object p) { }

	// RVA: 0x3CF0EB8
	private object MarkNeighbor(object p1, object p2, object t) { }

	// RVA: 0x3CF1100
	public object MarkNeighbor(object t) { }

	// RVA: 0x3CF1338
	public object OppositePoint(object t, object p) { }

	// RVA: 0x3CF14B8
	public object NeighborCWFrom(object point) { }

	// RVA: 0x3CF1560
	public object NeighborCCWFrom(object point) { }

	// RVA: 0x3CF1608
	public object NeighborAcrossFrom(object point) { }

	// RVA: 0x3CF1690
	public object PointCCWFrom(object point) { }

	// RVA: 0x3CF1430
	public object PointCWFrom(object point) { }

	// RVA: 0x3CF1718
	private object RotateCW() { }

	// RVA: 0x3CF17E4
	public object Legalize(object oPoint, object nPoint) { }

	// RVA: 0x3CF1884
	public override object ToString() { }

	// RVA: 0x3CF1A40
	public object MarkConstrainedEdge(object index) { }

	// RVA: 0x3CF1B2C
	public object MarkConstrainedEdge(object p, object q) { }

	// RVA: 0x3CF100C
	public object EdgeIndex(object p1, object p2) { }

	// RVA: 0x3CF1C04
	public object GetConstrainedEdgeCCW(object p) { }

	// RVA: 0x3CF1D2C
	public object GetConstrainedEdgeCW(object p) { }

	// RVA: 0x3CF1DE8
	public object SetConstrainedEdgeCCW(object p, object ce) { }

	// RVA: 0x3CF1EA8
	public object SetConstrainedEdgeCW(object p, object ce) { }

	// RVA: 0x3CF1F68
	public object GetDelaunayEdgeCCW(object p) { }

	// RVA: 0x3CF2024
	public object GetDelaunayEdgeCW(object p) { }

	// RVA: 0x3CF20E0
	public object SetDelaunayEdgeCCW(object p, object ce) { }

	// RVA: 0x3CF21A0
	public object SetDelaunayEdgeCW(object p, object ce) { }

}

// Namespace: Pathfinding.Poly2Tri
public class AdvancingFront
{

	// Fields
	public object Head; // 0x8
	public object Tail; // 0x10
	protected object Search; // 0x18

	// Methods

	// RVA: 0x3CF2260
	public object .ctor(object head, object tail) { }

	// RVA: 0x3CF229C
	public object AddNode(object node) { }

	// RVA: 0x3CF22A0
	public object RemoveNode(object node) { }

	// RVA: 0x3CF22A4
	public override object ToString() { }

	// RVA: 0x3CF2404
	private object FindSearchNode(object x) { }

	// RVA: 0x3CF240C
	public object LocateNode(object point) { }

	// RVA: 0x3CF2490
	private object LocateNode(object x) { }

	// RVA: 0x3CF2500
	public object LocatePoint(object point) { }

}

// Namespace: Pathfinding.Poly2Tri
public class AdvancingFrontNode
{

	// Fields
	public object Next; // 0x8
	public object Prev; // 0x10
	public object Value; // 0x18
	public object Point; // 0x20
	public object Triangle; // 0x28

	// Properties
	public object HasNext { get; }
	public object HasPrev { get; }

	// Methods

	// RVA: 0x3CF2648
	public object .ctor(object point) { }

	// RVA: 0x3CF268C
	public object get_HasNext() { }

	// RVA: 0x3CF269C
	public object get_HasPrev() { }

}

// Namespace: Pathfinding.Poly2Tri
public static class DTSweep
{

	// Methods

	// RVA: 0x3CEF724
	public static object Triangulate(object tcx) { }

	// RVA: 0x3CF29C0
	private static object Sweep(object tcx) { }

	// RVA: 0x3CF2E64
	private static object FinalizationConvexHull(object tcx) { }

	// RVA: 0x3CF3CE4
	private static object TurnAdvancingFrontConvex(object tcx, object b, object c) { }

	// RVA: 0x3CF2C98
	private static object FinalizationPolygon(object tcx) { }

	// RVA: 0x3CF368C
	private static object PointEvent(object tcx, object point) { }

	// RVA: 0x3CF51F8
	private static object NewFrontTriangle(object tcx, object point, object node) { }

	// RVA: 0x3CF39C8
	private static object EdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF5CE4
	private static object FillEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF65A8
	private static object FillRightConcaveEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF6754
	private static object FillRightConvexEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF6984
	private static object FillRightBelowEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF6104
	private static object FillRightAboveEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF6BD4
	private static object FillLeftConvexEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF6DF8
	private static object FillLeftConcaveEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF6F9C
	private static object FillLeftBelowEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF6358
	private static object FillLeftAboveEdgeEvent(object tcx, object edge, object node) { }

	// RVA: 0x3CF5B00
	private static object IsEdgeSideOfTriangle(object triangle, object ep, object eq) { }

	// RVA: 0x3CF5D2C
	private static object EdgeEvent(object tcx, object ep, object eq, object triangle, object point) { }

	// RVA: 0x3CF73B8
	private static object FlipEdgeEvent(object tcx, object ep, object eq, object t, object p) { }

	// RVA: 0x3CF7DE0
	private static object NextFlipPoint(object ep, object eq, object ot, object op) { }

	// RVA: 0x3CF7BD8
	private static object NextFlipTriangle(object tcx, object o, object t, object ot, object p, object op) { }

	// RVA: 0x3CF7FCC
	private static object FlipScanEdgeEvent(object tcx, object ep, object eq, object flipTriangle, object t, object p) { }

	// RVA: 0x3CF5558
	private static object FillAdvancingFront(object tcx, object n) { }

	// RVA: 0x3CF8654
	private static object FillBasin(object tcx, object node) { }

	// RVA: 0x3CF88B8
	private static object FillBasinReq(object tcx, object node) { }

	// RVA: 0x3CF8B14
	private static object IsShallow(object tcx, object node) { }

	// RVA: 0x3CF8478
	private static object HoleAngle(object node) { }

	// RVA: 0x3CF8580
	private static object BasinAngle(object node) { }

	// RVA: 0x3CF4ECC
	private static object Fill(object tcx, object node) { }

	// RVA: 0x3CF566C
	private static object Legalize(object tcx, object t) { }

	// RVA: 0x3CF3F6C
	private static object RotateTrianglePair(object t, object p, object ot, object op) { }

}

// Namespace: Pathfinding.Poly2Tri
public class DTSweepBasin
{

	// Fields
	public object leftNode; // 0x8
	public object bottomNode; // 0x10
	public object rightNode; // 0x18
	public object width; // 0x20
	public object leftHighest; // 0x28

	// Methods

	// RVA: 0x3CF8D1C
	public object .ctor() { }

}

// Namespace: Pathfinding.Poly2Tri
public class DTSweepConstraint
{

	// Methods

	// RVA: 0x3CF8D24
	public object .ctor(object p1, object p2) { }

}

// Namespace: Pathfinding.Poly2Tri
public class DTSweepContext
{

	// Fields
	private readonly object ALPHA; // 0x38
	public object Front; // 0x40
	public object Basin; // 0x48
	public object EdgeEvent; // 0x50
	private object _comparator; // 0x58
	private object <Head>k__BackingField; // 0x60
	private object <Tail>k__BackingField; // 0x68

	// Properties
	public object Head { get; set; }
	public object Tail { get; set; }
	public override object IsDebugEnabled { get; }
	public override object Algorithm { get; }

	// Methods

	// RVA: 0x3CEF534
	public object .ctor() { }

	// RVA: 0x3CF9010
	public object get_Head() { }

	// RVA: 0x3CF9018
	public object set_Head(object value) { }

	// RVA: 0x3CF9020
	public object get_Tail() { }

	// RVA: 0x3CF9028
	public object set_Tail(object value) { }

	// RVA: 0x3CF9030
	public override object get_IsDebugEnabled() { }

	// RVA: 0x3CF4B78
	public object RemoveFromList(object triangle) { }

	// RVA: 0x3CF516C
	public object MeshClean(object triangle) { }

	// RVA: 0x3CF9038
	private object MeshCleanReq(object triangle) { }

	// RVA: 0x3CF91DC
	public override object Clear() { }

	// RVA: 0x3CF5538
	public object AddNode(object node) { }

	// RVA: 0x3CF8C04
	public object RemoveNode(object node) { }

	// RVA: 0x3CF5170
	public object LocateNode(object point) { }

	// RVA: 0x3CF26AC
	public object CreateAdvancingFront() { }

	// RVA: 0x3CF48E0
	public object MapTriangleToNodes(object t) { }

	// RVA: 0x3CF9304
	public override object PrepareTriangulation(object t) { }

	// RVA: 0x3CF4BE4
	public object FinalizeTriangulation() { }

	// RVA: 0x3CF9760
	public override object NewConstraint(object a, object b) { }

	// RVA: 0x3CF9828
	public override object get_Algorithm() { }

}

// Namespace: Pathfinding.Poly2Tri
public class DTSweepDebugContext
{

	// Fields
	private object _primaryTriangle; // 0x10
	private object _secondaryTriangle; // 0x18
	private object _activePoint; // 0x20
	private object _activeNode; // 0x28
	private object _activeConstraint; // 0x30

	// Properties
	public object PrimaryTriangle { set; }
	public object SecondaryTriangle { set; }
	public object ActivePoint { set; }
	public object ActiveNode { set; }
	public object ActiveConstraint { set; }

	// Methods

	// RVA: 0x3CF5AA0
	public object set_PrimaryTriangle(object value) { }

	// RVA: 0x3CF7ACC
	public object set_SecondaryTriangle(object value) { }

	// RVA: 0x3CF9830
	public object set_ActivePoint(object value) { }

	// RVA: 0x3CF4D30
	public object set_ActiveNode(object value) { }

	// RVA: 0x3CF3968
	public object set_ActiveConstraint(object value) { }

	// RVA: 0x3CF9890
	public override object Clear() { }

}

// Namespace: Pathfinding.Poly2Tri
public class DTSweepEdgeEvent
{

	// Fields
	public object ConstrainedEdge; // 0x8
	public object Right; // 0x10

	// Methods

	// RVA: 0x3CF8F34
	public object .ctor() { }

}

// Namespace: Pathfinding.Poly2Tri
public class DTSweepPointComparator
{

	// Methods

	// RVA: 0x3CF8F3C
	public object .ctor() { }

	// RVA: 0x3CF99CC
	public object Compare(object p1, object p2) { }

}

// Namespace: Pathfinding.Poly2Tri
public class PointOnEdgeException
{

	// Fields
	public readonly object A; // 0x88
	public readonly object B; // 0x90
	public readonly object C; // 0x98

	// Methods

	// RVA: 0x3CF71E8
	public object .ctor(object message, object a, object b, object c) { }

}

// Namespace: Pathfinding.Poly2Tri
public enum Orientation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CW;
	public const object CCW;
	public const object Collinear;
}

// Namespace: Pathfinding.Poly2Tri
public interface Triangulatable
{

	// Properties
	public abstract object TriangulationMode { get; }

	// Methods

	// RVA: -1
	public abstract object Prepare(object tcx) { }

	// RVA: -1
	public abstract object AddTriangle(object t) { }

	// RVA: -1
	public abstract object AddTriangles(object list) { }

	// RVA: -1
	public abstract object get_TriangulationMode() { }

}

// Namespace: Pathfinding.Poly2Tri
public enum TriangulationAlgorithm
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DTSweep;
}

// Namespace: Pathfinding.Poly2Tri
public class TriangulationConstraint
{

	// Fields
	public object P; // 0x8
	public object Q; // 0x10

	// Methods

	// RVA: 0x3CF8DC8
	public object .ctor() { }

}

// Namespace: Pathfinding.Poly2Tri
public abstract class TriangulationContext
{

	// Fields
	public readonly object Triangles; // 0x8
	public readonly object Points; // 0x10
	private object <DebugContext>k__BackingField; // 0x18
	private object <TriangulationMode>k__BackingField; // 0x20
	private object <Triangulatable>k__BackingField; // 0x28
	private object <StepCount>k__BackingField; // 0x30
	private object <IsDebugEnabled>k__BackingField; // 0x34

	// Properties
	public object DebugContext { get; }
	public object TriangulationMode { get; set; }
	public object Triangulatable { get; set; }
	public object StepCount { get; set; }
	public abstract object Algorithm { get; }
	public virtual object IsDebugEnabled { get; }
	public object DTDebugContext { get; }

	// Methods

	// RVA: 0x3CF8F44
	protected object .ctor() { }

	// RVA: 0x3CF9A4C
	public object get_DebugContext() { }

	// RVA: 0x3CF9A54
	public object get_TriangulationMode() { }

	// RVA: 0x3CF9A5C
	protected object set_TriangulationMode(object value) { }

	// RVA: 0x3CF9A64
	public object get_Triangulatable() { }

	// RVA: 0x3CF9A6C
	private object set_Triangulatable(object value) { }

	// RVA: 0x3CF9A74
	public object get_StepCount() { }

	// RVA: 0x3CF9A7C
	private object set_StepCount(object value) { }

	// RVA: 0x3CF367C
	public object Done() { }

	// RVA: -1
	public abstract object get_Algorithm() { }

	// RVA: 0x3CF95CC
	public virtual object PrepareTriangulation(object t) { }

	// RVA: -1
	public abstract object NewConstraint(object a, object b) { }

	// RVA: 0x3CF3CE0
	public object Update(object message) { }

	// RVA: 0x3CF9260
	public virtual object Clear() { }

	// RVA: 0x3CF9A84
	public virtual object get_IsDebugEnabled() { }

	// RVA: 0x3CF38E0
	public object get_DTDebugContext() { }

}

// Namespace: Pathfinding.Poly2Tri
public abstract class TriangulationDebugContext
{

	// Fields
	protected object _tcx; // 0x8

	// Methods

	// RVA: -1
	public abstract object Clear() { }

}

// Namespace: Pathfinding.Poly2Tri
public enum TriangulationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unconstrained;
	public const object Constrained;
	public const object Polygon;
}

// Namespace: Pathfinding.Poly2Tri
public class TriangulationPoint
{

	// Fields
	public object X; // 0x8
	public object Y; // 0x10
	private object <Edges>k__BackingField; // 0x18

	// Properties
	public object Edges { get; set; }
	public object HasEdges { get; }

	// Methods

	// RVA: 0x3CF0C70
	public object .ctor(object x, object y) { }

	// RVA: 0x3CF9A8C
	public object get_Edges() { }

	// RVA: 0x3CF9A94
	private object set_Edges(object value) { }

	// RVA: 0x3CF9A9C
	public override object ToString() { }

	// RVA: 0x3CF8DD0
	public object AddEdge(object e) { }

	// RVA: 0x3CF38D0
	public object get_HasEdges() { }

}

// Namespace: Pathfinding.Poly2Tri
public class TriangulationUtil
{

	// Fields
	public static object EPSILON; // 0x0

	// Methods

	// RVA: 0x3CF9C84
	private static object .cctor() { }

	// RVA: 0x3CF8C24
	public static object SmartIncircle(object pa, object pb, object pc, object pd) { }

	// RVA: 0x3CF7B2C
	public static object InScanArea(object pa, object pb, object pc, object pd) { }

	// RVA: 0x3CF4D90
	public static object Orient2d(object pa, object pb, object pc) { }

}

// Namespace: 
private sealed class <Enumerate>c__Iterator0
{

	// Fields
	internal object <i>__0; // 0x0
	internal object $PC; // 0x0
	internal object $current; // 0x0
	internal object <>f__this; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<T>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<T>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object Reset() { }

}

// Namespace: Pathfinding.Poly2Tri
public struct FixedArray3<T0>
{

	// Fields
	public object _0; // 0x0
	public object _1; // 0x0
	public object _2; // 0x0

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object Contains(object value) { }

	// RVA: -1
	public object IndexOf(object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	private object Enumerate() { }

	// RVA: -1
	public object GetEnumerator() { }

}

// Namespace: 
private sealed class <Enumerate>c__Iterator1
{

	// Fields
	internal object <i>__0; // 0x8
	internal object $PC; // 0xC
	internal object $current; // 0x10
	internal object <>f__this; // 0x11

	// Properties
	private object System.Collections.Generic.IEnumerator<bool>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x3CFA01C
	public object .ctor() { }

	// RVA: 0x3CFA0B8
	private object System.Collections.Generic.IEnumerator<bool>.get_Current() { }

	// RVA: 0x3CFA0C0
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x3CFA128
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x3CFA1C4
	private object System.Collections.Generic.IEnumerable<bool>.GetEnumerator() { }

	// RVA: 0x3CFA260
	public object MoveNext() { }

	// RVA: 0x3CFA35C
	public object Dispose() { }

	// RVA: 0x3CFA368
	public object Reset() { }

}

// Namespace: Pathfinding.Poly2Tri
public struct FixedBitArray3
{

	// Fields
	public object _0; // 0xFFFFFFFFFFFFFFF8
	public object _1; // 0xFFFFFFFFFFFFFFF9
	public object _2; // 0xFFFFFFFFFFFFFFFA

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: 0x3CF9D2C
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x3CF1CC0
	public object get_Item(object index) { }

	// RVA: 0x3CF1AC4
	public object set_Item(object index, object value) { }

	// RVA: 0x3CF846C
	public object Clear() { }

	// RVA: 0x3CF9F90
	private object Enumerate() { }

	// RVA: 0x3CF9D30
	public object GetEnumerator() { }

}

