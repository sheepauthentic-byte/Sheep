// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public sealed class AndroidJavaRunnable
{

	// Methods

	// RVA: 0x7321380
	public object .ctor(object object, object method) { }

	// RVA: 0x7321414
	public virtual object Invoke() { }

}

// Namespace: UnityEngine
public sealed class AndroidJavaException
{

	// Fields
	private object mJavaStackTrace; // 0x88

	// Properties
	public override object StackTrace { get; }

	// Methods

	// RVA: 0x7321428
	internal object .ctor(object message, object javaStackTrace) { }

	// RVA: 0x73214A8
	public override object get_StackTrace() { }

}

// Namespace: UnityEngine
internal class GlobalJavaObjectRef
{

	// Fields
	private object m_disposed; // 0x8
	protected object m_jobject; // 0x10

	// Methods

	// RVA: 0x73214D8
	public object .ctor(object jobject) { }

	// RVA: 0x73215A4
	protected override object Finalize() { }

	// RVA: 0x7321730
	public static object op_Implicit(object obj) { }

	// RVA: 0x7321698
	public object Dispose() { }

}

// Namespace: UnityEngine
internal class AndroidJavaRunnableProxy
{

	// Fields
	private object mRunnable; // 0x18

	// Methods

	// RVA: 0x73217BC
	public object .ctor(object runnable) { }

	// RVA: 0x7321950
	public object run() { }

	// RVA: 0x732197C
	public override object Invoke(object methodName, object javaArgs) { }

}

// Namespace: UnityEngine
public class AndroidJavaProxy
{

	// Fields
	public readonly object javaInterface; // 0x8
	internal object proxyObject; // 0x10
	private static readonly object s_JavaLangSystemClass; // 0x0
	private static readonly object s_HashCodeMethodID; // 0x8

	// Methods

	// RVA: 0x73218CC
	public object .ctor(object javaInterface) { }

	// RVA: 0x7322020
	public object .ctor(object javaInterface) { }

	// RVA: 0x7322050
	protected override object Finalize() { }

	// RVA: 0x7322188
	public virtual object Invoke(object methodName, object args) { }

	// RVA: 0x7323924
	public virtual object Invoke(object methodName, object javaArgs) { }

	// RVA: 0x7321B28
	public virtual object Invoke(object methodName, object javaArgs) { }

	// RVA: 0x7324C84
	public virtual object equals(object obj) { }

	// RVA: 0x7324D70
	public virtual object hashCode() { }

	// RVA: 0x7324F9C
	public virtual object toString() { }

	// RVA: 0x7325028
	internal object GetProxyObject() { }

	// RVA: 0x73236D4
	internal object GetRawProxy() { }

	// RVA: 0x7325254
	private static object .cctor() { }

}

// Namespace: UnityEngine
public class AndroidJavaObject
{

	// Fields
	private static object enableDebugPrints; // 0x0
	internal object m_jobject; // 0x8
	internal object m_jclass; // 0x10

	// Methods

	// RVA: 0x732546C
	public object .ctor(object className, object args) { }

	// RVA: 0x7324828
	public object .ctor(object jobject) { }

	// RVA: 0x73246A0
	public object Dispose() { }

	// RVA: 0x73257F0
	public object Call(object methodName, object args) { }

	// RVA: -1
	public object Get(object fieldName) { }

	// RVA: -1
	public object GetStatic(object fieldName) { }

	// RVA: 0x7324C1C
	public object GetRawObject() { }

	// RVA: 0x73258E0
	public object GetRawClass() { }

	// RVA: -1
	public object Call(object methodName, object args) { }

	// RVA: -1
	public object CallStatic(object methodName, object args) { }

	// RVA: 0x7325928
	protected object DebugPrint(object msg) { }

	// RVA: 0x73254B4
	private object _AndroidJavaObject(object className, object args) { }

	// RVA: 0x7325A04
	private object _AndroidJavaObject(object constructorID, object args) { }

	// RVA: 0x73254AC
	internal object .ctor() { }

	// RVA: 0x7325F3C
	protected override object Finalize() { }

	// RVA: 0x7325FF4
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x732585C
	protected object _Call(object methodName, object args) { }

	// RVA: 0x732613C
	protected object _Call(object methodID, object args) { }

	// RVA: -1
	protected object _Call(object methodName, object args) { }

	// RVA: -1
	protected object _Call(object methodID, object args) { }

	// RVA: -1
	protected object _Get(object fieldName) { }

	// RVA: -1
	protected object _Get(object fieldID) { }

	// RVA: -1
	protected object _CallStatic(object methodName, object args) { }

	// RVA: -1
	protected object _CallStatic(object methodID, object args) { }

	// RVA: -1
	protected object _GetStatic(object fieldName) { }

	// RVA: -1
	protected object _GetStatic(object fieldID) { }

	// RVA: 0x7324AF4
	internal static object AndroidJavaObjectDeleteLocalRef(object jobject) { }

	// RVA: 0x73264B4
	internal static object AndroidJavaClassDeleteLocalRef(object jclass) { }

	// RVA: -1
	internal static object FromJavaArrayDeleteLocalRef(object jobject) { }

	// RVA: 0x73258C8
	protected object _GetRawObject() { }

	// RVA: 0x7325904
	protected object _GetRawClass() { }

}

// Namespace: UnityEngine
public class AndroidJavaClass
{

	// Methods

	// RVA: 0x7321FF0
	public object .ctor(object className) { }

	// RVA: 0x73266F8
	private object _AndroidJavaClass(object className) { }

	// RVA: 0x73265DC
	internal object .ctor(object jclass) { }

}

// Namespace: UnityEngine
internal class AndroidReflection
{

	// Fields
	private static readonly object s_ReflectionHelperClass; // 0x0
	private static readonly object s_ReflectionHelperGetConstructorID; // 0x8
	private static readonly object s_ReflectionHelperGetMethodID; // 0x10
	private static readonly object s_ReflectionHelperGetFieldID; // 0x18
	private static readonly object s_ReflectionHelperGetFieldSignature; // 0x20
	private static readonly object s_ReflectionHelperNewProxyInstance; // 0x28
	private static readonly object s_ReflectionHelperSetNativeExceptionOnProxy; // 0x30
	private static readonly object s_FieldGetDeclaringClass; // 0x38

	// Methods

	// RVA: 0x73268D4
	public static object IsPrimitive(object t) { }

	// RVA: 0x73268F4
	public static object IsAssignableFrom(object t, object from) { }

	// RVA: 0x7326950
	private static object GetStaticMethodID(object clazz, object methodName, object signature) { }

	// RVA: 0x7326B48
	private static object GetMethodID(object clazz, object methodName, object signature) { }

	// RVA: 0x7326D40
	public static object GetConstructorMember(object jclass, object signature) { }

	// RVA: 0x7327160
	public static object GetMethodMember(object jclass, object methodName, object signature, object isStatic) { }

	// RVA: 0x7327498
	public static object GetFieldMember(object jclass, object fieldName, object signature, object isStatic) { }

	// RVA: 0x73276D0
	public static object GetFieldClass(object field) { }

	// RVA: 0x7327808
	public static object GetFieldSignature(object field) { }

	// RVA: 0x7327984
	public static object NewProxyInstance(object player, object delegateHandle, object interfaze) { }

	// RVA: 0x73237D0
	public static object SetNativeExceptionOnProxy(object proxy, object e, object methodNotFound) { }

	// RVA: 0x7327B3C
	private static object .cctor() { }

}

// Namespace: UnityEngine
internal sealed class _AndroidJNIHelper
{

	// Methods

	// RVA: 0x7327E5C
	public static object CreateJavaProxy(object player, object delegateHandle, object proxy) { }

	// RVA: 0x7327F24
	public static object CreateJavaRunnable(object jrunnable) { }

	// RVA: 0x7327F88
	public static object InvokeJavaProxyMethod(object proxy, object jmethodName, object jargs) { }

	// RVA: 0x7328144
	public static object CreateJNIArgArray(object args, object ret) { }

	// RVA: 0x73294F0
	public static object UnboxArray(object obj) { }

	// RVA: 0x7323B38
	public static object Unbox(object obj) { }

	// RVA: 0x7322C90
	public static object Box(object obj) { }

	// RVA: 0x7329F28
	public static object DeleteJNIArgArray(object args, object jniArgs) { }

	// RVA: 0x7328760
	public static object ConvertToJNIArray(object array) { }

	// RVA: -1
	public static object ConvertFromJNIArray(object array) { }

	// RVA: 0x732AB80
	public static object GetConstructorID(object jclass, object args) { }

	// RVA: 0x732ACE4
	public static object GetMethodID(object jclass, object methodName, object args, object isStatic) { }

	// RVA: -1
	public static object GetMethodID(object jclass, object methodName, object args, object isStatic) { }

	// RVA: -1
	public static object GetFieldID(object jclass, object fieldName, object isStatic) { }

	// RVA: 0x732AD28
	public static object GetConstructorID(object jclass, object signature) { }

	// RVA: 0x732B01C
	public static object GetMethodID(object jclass, object methodName, object signature, object isStatic) { }

	// RVA: 0x732B248
	private static object GetMethodIDFallback(object jclass, object methodName, object signature, object isStatic) { }

	// RVA: 0x732B2F4
	public static object GetFieldID(object jclass, object fieldName, object signature, object isStatic) { }

	// RVA: 0x732B950
	public static object GetSignature(object obj) { }

	// RVA: 0x732ABAC
	public static object GetSignature(object args) { }

	// RVA: -1
	public static object GetSignature(object args) { }

}

// Namespace: UnityEngine
public struct jvalue
{

	// Fields
	public object z; // 0xFFFFFFFFFFFFFFF8
	public object b; // 0xFFFFFFFFFFFFFFF8
	public object c; // 0xFFFFFFFFFFFFFFF8
	public object s; // 0xFFFFFFFFFFFFFFF8
	public object i; // 0xFFFFFFFFFFFFFFF8
	public object j; // 0xFFFFFFFFFFFFFFF8
	public object f; // 0xFFFFFFFFFFFFFFF8
	public object d; // 0xFFFFFFFFFFFFFFF8
	public object l; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine
public static class AndroidJNIHelper
{

	// Methods

	// RVA: 0x732ACE0
	public static object GetConstructorID(object javaClass, object signature) { }

	// RVA: 0x732C824
	public static object GetMethodID(object javaClass, object methodName, object signature) { }

	// RVA: 0x7325468
	public static object GetMethodID(object javaClass, object methodName, object signature, object isStatic) { }

	// RVA: 0x732C82C
	public static object GetFieldID(object javaClass, object fieldName, object signature, object isStatic) { }

	// RVA: 0x732948C
	public static object CreateJavaRunnable(object jrunnable) { }

	// RVA: 0x732508C
	public static object CreateJavaProxy(object proxy) { }

	// RVA: 0x732CA58
	public static object CreateJNIArgArray(object args) { }

	// RVA: 0x7325C94
	public static object CreateJNIArgArray(object args, object jniArgs) { }

	// RVA: 0x732CAFC
	public static object DeleteJNIArgArray(object args, object jniArgs) { }

	// RVA: 0x73259D8
	public static object GetConstructorID(object jclass, object args) { }

	// RVA: 0x73260F8
	public static object GetMethodID(object jclass, object methodName, object args, object isStatic) { }

	// RVA: -1
	public static object ConvertFromJNIArray(object array) { }

	// RVA: -1
	public static object GetMethodID(object jclass, object methodName, object args, object isStatic) { }

	// RVA: -1
	public static object GetFieldID(object jclass, object fieldName, object isStatic) { }

	// RVA: 0x732CB00
	private static object Box(object val, object boxedClass, object signature) { }

	// RVA: 0x7324A88
	public static object Box(object value) { }

	// RVA: 0x7324A1C
	public static object Box(object value) { }

}

// Namespace: UnityEngine
public static class AndroidJNI
{

	// Methods

	// RVA: 0x732CD90
	public static object FindClass(object name) { }

	// RVA: 0x732CDE0
	public static object FromReflectedMethod(object refMethod) { }

	// RVA: 0x732CE30
	public static object ExceptionOccurred() { }

	// RVA: 0x732CE70
	public static object ExceptionClear() { }

	// RVA: 0x732B6BC
	public static object PushLocalFrame(object capacity) { }

	// RVA: 0x732CEB0
	public static object PopLocalFrame(object ptr) { }

	// RVA: 0x7321554
	public static object NewGlobalRef(object obj) { }

	// RVA: 0x732CF00
	internal static object QueueDeleteGlobalRef(object obj) { }

	// RVA: 0x7325204
	public static object NewWeakGlobalRef(object obj) { }

	// RVA: 0x732503C
	public static object DeleteWeakGlobalRef(object obj) { }

	// RVA: 0x7324C34
	public static object NewLocalRef(object obj) { }

	// RVA: 0x732CF50
	public static object DeleteLocalRef(object obj) { }

	// RVA: 0x7324D0C
	public static object IsSameObject(object obj1, object obj2) { }

	// RVA: 0x732CFA0
	public static object NewObject(object clazz, object methodID, object args) { }

	// RVA: 0x732D03C
	public static object NewObjectA(object clazz, object methodID, object args) { }

	// RVA: 0x732D0A8
	public static object GetObjectClass(object obj) { }

	// RVA: 0x732D0F8
	public static object GetMethodID(object clazz, object name, object sig) { }

	// RVA: 0x732D164
	public static object GetFieldID(object clazz, object name, object sig) { }

	// RVA: 0x732D1D0
	public static object GetStaticMethodID(object clazz, object name, object sig) { }

	// RVA: 0x732D23C
	public static object GetStaticFieldID(object clazz, object name, object sig) { }

	// RVA: 0x732D2A8
	public static object NewString(object chars) { }

	// RVA: 0x732D2F8
	private static object NewStringFromStr(object chars) { }

	// RVA: 0x73280F4
	public static object GetStringChars(object str) { }

	// RVA: 0x732D348
	public static object CallStringMethod(object obj, object methodID, object args) { }

	// RVA: 0x732D438
	public static object CallStringMethod(object obj, object methodID, object args) { }

	// RVA: 0x732D4D4
	public static object CallStringMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732D540
	public static object CallObjectMethod(object obj, object methodID, object args) { }

	// RVA: 0x732D630
	public static object CallObjectMethod(object obj, object methodID, object args) { }

	// RVA: 0x732D6CC
	public static object CallObjectMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732D738
	public static object CallIntMethod(object obj, object methodID, object args) { }

	// RVA: 0x732D7D4
	public static object CallIntMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732D840
	public static object CallBooleanMethod(object obj, object methodID, object args) { }

	// RVA: 0x732D8DC
	public static object CallBooleanMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732D948
	public static object CallShortMethod(object obj, object methodID, object args) { }

	// RVA: 0x732D9E4
	public static object CallShortMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732DA50
	public static object CallSByteMethod(object obj, object methodID, object args) { }

	// RVA: 0x732DAEC
	public static object CallSByteMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732DB58
	public static object CallCharMethod(object obj, object methodID, object args) { }

	// RVA: 0x732DBF4
	public static object CallCharMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732DC60
	public static object CallFloatMethod(object obj, object methodID, object args) { }

	// RVA: 0x732DCFC
	public static object CallFloatMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732DD68
	public static object CallDoubleMethod(object obj, object methodID, object args) { }

	// RVA: 0x732DE04
	public static object CallDoubleMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732DE70
	public static object CallLongMethod(object obj, object methodID, object args) { }

	// RVA: 0x732DF0C
	public static object CallLongMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732DF78
	public static object CallVoidMethod(object obj, object methodID, object args) { }

	// RVA: 0x732E014
	public static object CallVoidMethodUnsafe(object obj, object methodID, object args) { }

	// RVA: 0x732E080
	public static object GetStringField(object obj, object fieldID) { }

	// RVA: 0x732E0E4
	public static object GetObjectField(object obj, object fieldID) { }

	// RVA: 0x732E148
	public static object GetBooleanField(object obj, object fieldID) { }

	// RVA: 0x732E1AC
	public static object GetSByteField(object obj, object fieldID) { }

	// RVA: 0x732E210
	public static object GetCharField(object obj, object fieldID) { }

	// RVA: 0x732E274
	public static object GetShortField(object obj, object fieldID) { }

	// RVA: 0x732E2D8
	public static object GetIntField(object obj, object fieldID) { }

	// RVA: 0x732E33C
	public static object GetLongField(object obj, object fieldID) { }

	// RVA: 0x732E3A0
	public static object GetFloatField(object obj, object fieldID) { }

	// RVA: 0x732E404
	public static object GetDoubleField(object obj, object fieldID) { }

	// RVA: 0x732E468
	public static object CallStaticStringMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732E558
	public static object CallStaticStringMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732E5F4
	public static object CallStaticStringMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732E660
	public static object CallStaticObjectMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732E6FC
	public static object CallStaticObjectMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732E768
	public static object CallStaticIntMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732E804
	public static object CallStaticIntMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732E870
	public static object CallStaticBooleanMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732E90C
	public static object CallStaticBooleanMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732E978
	public static object CallStaticShortMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732EA14
	public static object CallStaticShortMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732EA80
	public static object CallStaticSByteMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732EB1C
	public static object CallStaticSByteMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732EB88
	public static object CallStaticCharMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732EC24
	public static object CallStaticCharMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732EC90
	public static object CallStaticFloatMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732ED2C
	public static object CallStaticFloatMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732ED98
	public static object CallStaticDoubleMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732EE34
	public static object CallStaticDoubleMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732EEA0
	public static object CallStaticLongMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732EF3C
	public static object CallStaticLongMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732EFA8
	public static object CallStaticVoidMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732F044
	public static object CallStaticVoidMethodUnsafe(object clazz, object methodID, object args) { }

	// RVA: 0x732F0B0
	public static object GetStaticStringField(object clazz, object fieldID) { }

	// RVA: 0x732F114
	public static object GetStaticObjectField(object clazz, object fieldID) { }

	// RVA: 0x732F178
	public static object GetStaticBooleanField(object clazz, object fieldID) { }

	// RVA: 0x732F1DC
	public static object GetStaticSByteField(object clazz, object fieldID) { }

	// RVA: 0x732F240
	public static object GetStaticCharField(object clazz, object fieldID) { }

	// RVA: 0x732F2A4
	public static object GetStaticShortField(object clazz, object fieldID) { }

	// RVA: 0x732F308
	public static object GetStaticIntField(object clazz, object fieldID) { }

	// RVA: 0x732F36C
	public static object GetStaticLongField(object clazz, object fieldID) { }

	// RVA: 0x732F3D0
	public static object GetStaticFloatField(object clazz, object fieldID) { }

	// RVA: 0x732F434
	public static object GetStaticDoubleField(object clazz, object fieldID) { }

	// RVA: 0x732F498
	public static object ToBooleanArray(object array) { }

	// RVA: 0x732F4E8
	public static object ToByteArray(object array) { }

	// RVA: 0x732F538
	public static object ToSByteArray(object array) { }

	// RVA: 0x732F5B0
	public static object ToSByteArray(object array, object length) { }

	// RVA: 0x732F614
	public static object ToCharArray(object array) { }

	// RVA: 0x732F68C
	public static object ToCharArray(object array, object length) { }

	// RVA: 0x732F6F0
	public static object ToShortArray(object array) { }

	// RVA: 0x732F768
	public static object ToShortArray(object array, object length) { }

	// RVA: 0x732F7CC
	public static object ToIntArray(object array) { }

	// RVA: 0x732F844
	public static object ToIntArray(object array, object length) { }

	// RVA: 0x732F8A8
	public static object ToLongArray(object array) { }

	// RVA: 0x732F920
	public static object ToLongArray(object array, object length) { }

	// RVA: 0x732F984
	public static object ToFloatArray(object array) { }

	// RVA: 0x732F9FC
	public static object ToFloatArray(object array, object length) { }

	// RVA: 0x732FA60
	public static object ToDoubleArray(object array) { }

	// RVA: 0x732FAD8
	public static object ToDoubleArray(object array, object length) { }

	// RVA: 0x732FB3C
	public static object ToObjectArray(object array, object length, object arrayClass) { }

	// RVA: 0x732FBA8
	public static object ToObjectArray(object array, object arrayClass) { }

	// RVA: 0x732FC10
	public static object FromBooleanArray(object array) { }

	// RVA: 0x732FC60
	public static object FromByteArray(object array) { }

	// RVA: 0x732FCB0
	public static object FromSByteArray(object array) { }

	// RVA: 0x732FD00
	public static object FromCharArray(object array) { }

	// RVA: 0x732FD50
	public static object FromShortArray(object array) { }

	// RVA: 0x732FDA0
	public static object FromIntArray(object array) { }

	// RVA: 0x732FDF0
	public static object FromLongArray(object array) { }

	// RVA: 0x732FE40
	public static object FromFloatArray(object array) { }

	// RVA: 0x732FE90
	public static object FromDoubleArray(object array) { }

	// RVA: 0x732FEE0
	public static object GetArrayLength(object array) { }

	// RVA: 0x732A99C
	public static object NewObjectArray(object size, object clazz, object obj) { }

	// RVA: 0x732FF30
	public static object GetObjectArrayElement(object array, object index) { }

	// RVA: 0x732AA08
	public static object SetObjectArrayElement(object array, object index, object obj) { }

}

// Namespace: UnityEngine
internal class AndroidJNISafe
{

	// Methods

	// RVA: 0x732FF94
	public static object CheckException() { }

	// RVA: 0x7321750
	public static object QueueDeleteGlobalRef(object globalref) { }

	// RVA: 0x732211C
	public static object DeleteWeakGlobalRef(object globalref) { }

	// RVA: 0x7325784
	public static object DeleteLocalRef(object localref) { }

	// RVA: 0x7326F68
	public static object NewString(object chars) { }

	// RVA: 0x73303AC
	public static object GetStringChars(object str) { }

	// RVA: 0x73256A4
	public static object GetObjectClass(object ptr) { }

	// RVA: 0x7326A50
	public static object GetStaticMethodID(object clazz, object name, object sig) { }

	// RVA: 0x7326C48
	public static object GetMethodID(object obj, object name, object sig) { }

	// RVA: 0x732B70C
	public static object GetFieldID(object clazz, object name, object sig) { }

	// RVA: 0x732B804
	public static object GetStaticFieldID(object clazz, object name, object sig) { }

	// RVA: 0x732AF3C
	public static object FromReflectedMethod(object refMethod) { }

	// RVA: 0x7325388
	public static object FindClass(object name) { }

	// RVA: 0x7325DC8
	public static object NewObject(object clazz, object methodID, object args) { }

	// RVA: 0x733048C
	public static object GetStaticObjectField(object clazz, object fieldID) { }

	// RVA: 0x733057C
	public static object GetStaticStringField(object clazz, object fieldID) { }

	// RVA: 0x733066C
	public static object GetStaticCharField(object clazz, object fieldID) { }

	// RVA: 0x733075C
	public static object GetStaticDoubleField(object clazz, object fieldID) { }

	// RVA: 0x7330858
	public static object GetStaticFloatField(object clazz, object fieldID) { }

	// RVA: 0x7330954
	public static object GetStaticLongField(object clazz, object fieldID) { }

	// RVA: 0x7330A44
	public static object GetStaticShortField(object clazz, object fieldID) { }

	// RVA: 0x7330B34
	public static object GetStaticSByteField(object clazz, object fieldID) { }

	// RVA: 0x7330C24
	public static object GetStaticBooleanField(object clazz, object fieldID) { }

	// RVA: 0x7330D14
	public static object GetStaticIntField(object clazz, object fieldID) { }

	// RVA: 0x7327AC0
	public static object CallStaticVoidMethod(object clazz, object methodID, object args) { }

	// RVA: 0x7330E04
	public static object CallStaticVoidMethod(object clazz, object methodID, object args) { }

	// RVA: 0x7327048
	public static object CallStaticObjectMethod(object clazz, object methodID, object args) { }

	// RVA: 0x732CC58
	public static object CallStaticObjectMethod(object clazz, object methodID, object args) { }

	// RVA: 0x7327908
	public static object CallStaticStringMethod(object clazz, object methodID, object args) { }

	// RVA: 0x7330F34
	public static object CallStaticStringMethod(object clazz, object methodID, object args) { }

	// RVA: 0x733106C
	public static object CallStaticCharMethod(object clazz, object methodID, object args) { }

	// RVA: 0x73311A4
	public static object CallStaticDoubleMethod(object clazz, object methodID, object args) { }

	// RVA: 0x73312E8
	public static object CallStaticFloatMethod(object clazz, object methodID, object args) { }

	// RVA: 0x733142C
	public static object CallStaticLongMethod(object clazz, object methodID, object args) { }

	// RVA: 0x7331564
	public static object CallStaticShortMethod(object clazz, object methodID, object args) { }

	// RVA: 0x733169C
	public static object CallStaticSByteMethod(object clazz, object methodID, object args) { }

	// RVA: 0x73317D4
	public static object CallStaticBooleanMethod(object clazz, object methodID, object args) { }

	// RVA: 0x7324E64
	public static object CallStaticIntMethod(object clazz, object methodID, object args) { }

	// RVA: 0x733190C
	public static object GetObjectField(object obj, object fieldID) { }

	// RVA: 0x73319FC
	public static object GetStringField(object obj, object fieldID) { }

	// RVA: 0x7331AEC
	public static object GetCharField(object obj, object fieldID) { }

	// RVA: 0x7331BDC
	public static object GetDoubleField(object obj, object fieldID) { }

	// RVA: 0x7331CD8
	public static object GetFloatField(object obj, object fieldID) { }

	// RVA: 0x7331DD4
	public static object GetLongField(object obj, object fieldID) { }

	// RVA: 0x7331EC4
	public static object GetShortField(object obj, object fieldID) { }

	// RVA: 0x7331FB4
	public static object GetSByteField(object obj, object fieldID) { }

	// RVA: 0x73320A4
	public static object GetBooleanField(object obj, object fieldID) { }

	// RVA: 0x7332194
	public static object GetIntField(object obj, object fieldID) { }

	// RVA: 0x732630C
	public static object CallVoidMethod(object obj, object methodID, object args) { }

	// RVA: 0x732778C
	public static object CallObjectMethod(object obj, object methodID, object args) { }

	// RVA: 0x7332284
	public static object CallObjectMethod(object obj, object methodID, object args) { }

	// RVA: 0x73323BC
	public static object CallStringMethod(object obj, object methodID, object args) { }

	// RVA: 0x73324F4
	public static object CallCharMethod(object obj, object methodID, object args) { }

	// RVA: 0x733262C
	public static object CallDoubleMethod(object obj, object methodID, object args) { }

	// RVA: 0x7332770
	public static object CallFloatMethod(object obj, object methodID, object args) { }

	// RVA: 0x73328B4
	public static object CallLongMethod(object obj, object methodID, object args) { }

	// RVA: 0x73329EC
	public static object CallShortMethod(object obj, object methodID, object args) { }

	// RVA: 0x7332B24
	public static object CallSByteMethod(object obj, object methodID, object args) { }

	// RVA: 0x7332C5C
	public static object CallBooleanMethod(object obj, object methodID, object args) { }

	// RVA: 0x7332D94
	public static object CallIntMethod(object obj, object methodID, object args) { }

	// RVA: 0x7332ECC
	public static object FromCharArray(object array) { }

	// RVA: 0x7332FAC
	public static object FromDoubleArray(object array) { }

	// RVA: 0x733308C
	public static object FromFloatArray(object array) { }

	// RVA: 0x733316C
	public static object FromLongArray(object array) { }

	// RVA: 0x733324C
	public static object FromShortArray(object array) { }

	// RVA: 0x733332C
	public static object FromByteArray(object array) { }

	// RVA: 0x733340C
	public static object FromSByteArray(object array) { }

	// RVA: 0x73334EC
	public static object FromBooleanArray(object array) { }

	// RVA: 0x73335CC
	public static object FromIntArray(object array) { }

	// RVA: 0x732AA74
	public static object ToObjectArray(object array, object type) { }

	// RVA: 0x732A898
	public static object ToCharArray(object array) { }

	// RVA: 0x732A794
	public static object ToDoubleArray(object array) { }

	// RVA: 0x732A690
	public static object ToFloatArray(object array) { }

	// RVA: 0x732A58C
	public static object ToLongArray(object array) { }

	// RVA: 0x732A488
	public static object ToShortArray(object array) { }

	// RVA: 0x732A2A4
	public static object ToByteArray(object array) { }

	// RVA: 0x732A384
	public static object ToSByteArray(object array) { }

	// RVA: 0x732A1C4
	public static object ToBooleanArray(object array) { }

	// RVA: 0x732A0C0
	public static object ToIntArray(object array) { }

	// RVA: 0x7324738
	public static object GetObjectArrayElement(object array, object index) { }

	// RVA: 0x7321A48
	public static object GetArrayLength(object array) { }

}

// Namespace: UnityEngine.Android
public struct Permission
{

	// Fields
	private static object m_Activity; // 0x0

	// Methods

	// RVA: 0x732C830
	internal static object GetActivity() { }

}

