// Namespace: 
internal class <Module>
{
}

// Namespace: 
internal static class SR
{

	// Methods

	// RVA: 0x6ED5FA4
	internal static object GetString(object name, object args) { }

	// RVA: 0x6ED6018
	internal static object GetString(object culture, object name, object args) { }

	// RVA: 0x6ED6020
	internal static object Format(object resourceFormat, object p1) { }

}

// Namespace: Microsoft.CSharp
internal class CodeDomProvider
{

	// Methods

	// RVA: 0x6ED6094
	public object .ctor() { }

}

// Namespace: Microsoft.CSharp
internal class CSharpCodeProvider
{

	// Methods

	// RVA: 0x6ED609C
	public object .ctor() { }

}

// Namespace: System
internal class MonoTODOAttribute
{

	// Methods

	// RVA: 0x6ED60A4
	public object .ctor() { }

}

// Namespace: System
internal static class LocalAppContextSwitches
{

	// Fields
	public static readonly object IgnoreEmptyKeySequences; // 0x0
	public static readonly object DontThrowOnInvalidSurrogatePairs; // 0x1
}

// Namespace: System.Xml
internal static class AsyncHelper
{

	// Fields
	public static readonly object DoneTask; // 0x0
	public static readonly object DoneTaskTrue; // 0x8
	public static readonly object DoneTaskFalse; // 0x10
	public static readonly object DoneTaskZero; // 0x18

	// Methods

	// RVA: 0x6ED60AC
	private static object .cctor() { }

}

// Namespace: System.Xml
internal abstract class Base64Encoder
{

	// Fields
	private object leftOverBytes; // 0x8
	private object leftOverBytesCount; // 0x10
	private object charsLine; // 0x18

	// Methods

	// RVA: 0x6ED61A0
	internal object .ctor() { }

	// RVA: -1
	internal abstract object WriteChars(object chars, object index, object count) { }

	// RVA: 0x6ED6208
	internal object Encode(object buffer, object index, object count) { }

	// RVA: 0x6ED65CC
	internal object Flush() { }

}

// Namespace: System.Xml
internal class XmlRawWriterBase64Encoder
{

	// Fields
	private object rawWriter; // 0x20

	// Methods

	// RVA: 0x6ED6694
	internal object .ctor(object rawWriter) { }

	// RVA: 0x6ED6700
	internal override object WriteChars(object chars, object index, object count) { }

}

// Namespace: System.Xml
internal class XmlTextWriterBase64Encoder
{

	// Fields
	private object xmlTextEncoder; // 0x20

	// Methods

	// RVA: 0x6ED6770
	internal object .ctor(object xmlTextEncoder) { }

	// RVA: 0x6ED67DC
	internal override object WriteChars(object chars, object index, object count) { }

}

// Namespace: System.Xml
internal class BinHexDecoder
{

	// Fields
	private object buffer; // 0x8
	private object curIndex; // 0x10
	private object endIndex; // 0x14
	private object hasHalfByteCached; // 0x18
	private object cachedHalfByte; // 0x19

	// Properties
	internal override object IsFull { get; }

	// Methods

	// RVA: 0x6ED6800
	internal override object get_IsFull() { }

	// RVA: 0x6ED6810
	internal override object Decode(object chars, object startPos, object len) { }

	// RVA: 0x6ED6C2C
	public static object Decode(object chars, object allowOddChars) { }

	// RVA: 0x6ED6998
	private static object Decode(object pChars, object pCharsEndPos, object pBytes, object pBytesEndPos, object hasHalfByteCached, object cachedHalfByte, object charsDecoded, object bytesDecoded) { }

}

// Namespace: System.Xml
internal static class BinHexEncoder
{

	// Methods

	// RVA: 0x6ED6E1C
	internal static object Encode(object buffer, object index, object count, object writer) { }

	// RVA: 0x6ED7190
	internal static object Encode(object inArray, object offsetIn, object count) { }

	// RVA: 0x6ED701C
	private static object Encode(object inArray, object offsetIn, object count, object outArray) { }

}

// Namespace: System.Xml
internal enum BinXmlToken
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Error;
	public const object NotImpl;
	public const object EOF;
	public const object XmlDecl;
	public const object Encoding;
	public const object DocType;
	public const object System;
	public const object Public;
	public const object Subset;
	public const object Element;
	public const object EndElem;
	public const object Attr;
	public const object EndAttrs;
	public const object PI;
	public const object Comment;
	public const object CData;
	public const object EndCData;
	public const object Name;
	public const object QName;
	public const object XmlText;
	public const object Nest;
	public const object EndNest;
	public const object Extn;
	public const object NmFlush;
	public const object SQL_BIT;
	public const object SQL_TINYINT;
	public const object SQL_SMALLINT;
	public const object SQL_INT;
	public const object SQL_BIGINT;
	public const object SQL_REAL;
	public const object SQL_FLOAT;
	public const object SQL_MONEY;
	public const object SQL_SMALLMONEY;
	public const object SQL_DATETIME;
	public const object SQL_SMALLDATETIME;
	public const object SQL_DECIMAL;
	public const object SQL_NUMERIC;
	public const object SQL_UUID;
	public const object SQL_VARBINARY;
	public const object SQL_BINARY;
	public const object SQL_IMAGE;
	public const object SQL_CHAR;
	public const object SQL_VARCHAR;
	public const object SQL_TEXT;
	public const object SQL_NVARCHAR;
	public const object SQL_NCHAR;
	public const object SQL_NTEXT;
	public const object SQL_UDT;
	public const object XSD_KATMAI_DATE;
	public const object XSD_KATMAI_DATETIME;
	public const object XSD_KATMAI_TIME;
	public const object XSD_KATMAI_DATEOFFSET;
	public const object XSD_KATMAI_DATETIMEOFFSET;
	public const object XSD_KATMAI_TIMEOFFSET;
	public const object XSD_BOOLEAN;
	public const object XSD_TIME;
	public const object XSD_DATETIME;
	public const object XSD_DATE;
	public const object XSD_BINHEX;
	public const object XSD_BASE64;
	public const object XSD_DECIMAL;
	public const object XSD_BYTE;
	public const object XSD_UNSIGNEDSHORT;
	public const object XSD_UNSIGNEDINT;
	public const object XSD_UNSIGNEDLONG;
	public const object XSD_QNAME;
}

// Namespace: System.Xml
internal struct BinXmlSqlDecimal
{

	// Fields
	internal object m_bLen; // 0xFFFFFFFFFFFFFFF8
	internal object m_bPrec; // 0xFFFFFFFFFFFFFFF9
	internal object m_bScale; // 0xFFFFFFFFFFFFFFFA
	internal object m_bSign; // 0xFFFFFFFFFFFFFFFB
	internal object m_data1; // 0xFFFFFFFFFFFFFFFC
	internal object m_data2; // 0x0
	internal object m_data3; // 0x4
	internal object m_data4; // 0x8
	private static readonly object NUMERIC_MAX_PRECISION; // 0x0
	private static readonly object MaxPrecision; // 0xFFFFFFFFFFFFFFF1
	private static readonly object MaxScale; // 0xFFFFFFFFFFFFFFF2
	private static readonly object x_cNumeMax; // 0xFFFFFFFFFFFFFFF4
	private static readonly object x_lInt32Base; // 0xFFFFFFFFFFFFFFF8
	private static readonly object x_ulInt32Base; // 0x0
	private static readonly object x_ulInt32BaseForMod; // 0x8
	internal static readonly object x_llMax; // 0x10
	private static readonly object DUINT_BASE; // 0x18
	private static readonly object DUINT_BASE2; // 0x20
	private static readonly object DUINT_BASE3; // 0x28
	private static readonly object x_rgulShiftBase; // 0x30
	private static readonly object rgCLenFromPrec; // 0x38

	// Properties
	public object IsPositive { get; }

	// Methods

	// RVA: 0x6ED72E8
	public object get_IsPositive() { }

	// RVA: 0x6ED7308
	public object .ctor(object data, object offset, object trim) { }

	// RVA: 0x6ED75B4
	private static object UIntFromByteArray(object data, object offset) { }

	// RVA: 0x6ED7820
	private static object MpDiv1(object rgulU, object ciulU, object iulD, object iulR) { }

	// RVA: 0x6ED7968
	private static object MpNormalize(object rgulU, object ciulU) { }

	// RVA: 0x6ED79CC
	private static object ChFromDigit(object uiDigit) { }

	// RVA: 0x6ED79D8
	public object ToDecimal() { }

	// RVA: 0x6ED7628
	private object TrimTrailingZeros() { }

	// RVA: 0x6ED7B10
	public override object ToString() { }

	// RVA: 0x6ED8058
	private static object .cctor() { }

}

// Namespace: System.Xml
internal struct BinXmlSqlMoney
{

	// Fields
	private object data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x6ED8194
	public object .ctor(object v) { }

	// RVA: 0x6ED81AC
	public object .ctor(object v) { }

	// RVA: 0x6ED81BC
	public object ToDecimal() { }

	// RVA: 0x6ED82A4
	public override object ToString() { }

}

// Namespace: System.Xml
internal abstract class BinXmlDateTime
{

	// Fields
	internal static object KatmaiTimeScaleMultiplicator; // 0x0
	private static readonly object SQLTicksPerMillisecond; // 0x8
	public static readonly object SQLTicksPerSecond; // 0x10
	public static readonly object SQLTicksPerMinute; // 0x14
	public static readonly object SQLTicksPerHour; // 0x18
	private static readonly object SQLTicksPerDay; // 0x1C

	// Methods

	// RVA: 0x6ED83C8
	private static object Write2Dig(object sb, object val) { }

	// RVA: 0x6ED8440
	private static object Write4DigNeg(object sb, object val) { }

	// RVA: 0x6ED85AC
	private static object Write3Dec(object sb, object val) { }

	// RVA: 0x6ED8670
	private static object WriteDate(object sb, object yr, object mnth, object day) { }

	// RVA: 0x6ED87B8
	private static object WriteTime(object sb, object hr, object min, object sec, object ms) { }

	// RVA: 0x6ED8A00
	private static object WriteTimeFullPrecision(object sb, object hr, object min, object sec, object fraction) { }

	// RVA: 0x6ED8CC0
	private static object WriteTimeZone(object sb, object zone) { }

	// RVA: 0x6ED8DE8
	private static object WriteTimeZone(object sb, object negTimeZone, object hr, object min) { }

	// RVA: 0x6ED8F34
	private static object BreakDownXsdDateTime(object val, object yr, object mnth, object day, object hr, object min, object sec, object ms) { }

	// RVA: 0x6ED9104
	private static object BreakDownXsdDate(object val, object yr, object mnth, object day, object negTimeZone, object hr, object min) { }

	// RVA: 0x6ED926C
	private static object BreakDownXsdTime(object val, object hr, object min, object sec, object ms) { }

	// RVA: 0x6ED9374
	public static object XsdDateTimeToString(object val) { }

	// RVA: 0x6ED94A8
	public static object XsdDateToString(object val) { }

	// RVA: 0x6ED95B4
	public static object XsdTimeToString(object val) { }

	// RVA: 0x6ED9798
	public static object SqlDateTimeToString(object dateticks, object timeticks) { }

	// RVA: 0x6ED98F0
	public static object SqlDateTimeToDateTime(object dateticks, object timeticks) { }

	// RVA: 0x6ED99F0
	public static object SqlSmallDateTimeToString(object dateticks, object timeticks) { }

	// RVA: 0x6ED9B50
	public static object SqlSmallDateTimeToDateTime(object dateticks, object timeticks) { }

	// RVA: 0x6ED9BC4
	public static object XsdKatmaiDateToDateTime(object data, object offset) { }

	// RVA: 0x6ED9D2C
	public static object XsdKatmaiDateTimeToDateTime(object data, object offset) { }

	// RVA: 0x6EDA058
	public static object XsdKatmaiTimeToDateTime(object data, object offset) { }

	// RVA: 0x6EDA0E4
	public static object XsdKatmaiDateOffsetToDateTimeOffset(object data, object offset) { }

	// RVA: 0x6EDA170
	public static object XsdKatmaiDateTimeOffsetToDateTimeOffset(object data, object offset) { }

	// RVA: 0x6EDA314
	public static object XsdKatmaiTimeOffsetToDateTimeOffset(object data, object offset) { }

	// RVA: 0x6EDA3A0
	public static object XsdKatmaiDateToString(object data, object offset) { }

	// RVA: 0x6EDA4E4
	public static object XsdKatmaiDateTimeToString(object data, object offset) { }

	// RVA: 0x6EDA7A0
	public static object XsdKatmaiTimeToString(object data, object offset) { }

	// RVA: 0x6EDA940
	public static object XsdKatmaiDateOffsetToString(object data, object offset) { }

	// RVA: 0x6EDAAE8
	public static object XsdKatmaiDateTimeOffsetToString(object data, object offset) { }

	// RVA: 0x6EDADE8
	public static object XsdKatmaiTimeOffsetToString(object data, object offset) { }

	// RVA: 0x6ED9CB0
	private static object GetKatmaiDateTicks(object data, object pos) { }

	// RVA: 0x6ED9E34
	private static object GetKatmaiTimeTicks(object data, object pos) { }

	// RVA: 0x6EDA2B4
	private static object GetKatmaiTimeZoneTicks(object data, object pos) { }

	// RVA: 0x6EDA688
	private static object GetFractions(object dt) { }

	// RVA: 0x6EDACA4
	private static object GetFractions(object dt) { }

	// RVA: 0x6EDAFA0
	private static object .cctor() { }

}

// Namespace: 
private enum ScanState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Doc;
	public const object XmlText;
	public const object Attr;
	public const object AttrVal;
	public const object AttrValPseudoValue;
	public const object Init;
	public const object Error;
	public const object EOF;
	public const object Closed;
}

// Namespace: 
internal struct QName
{

	// Fields
	public object prefix; // 0xFFFFFFFFFFFFFFF8
	public object localname; // 0x0
	public object namespaceUri; // 0x8

	// Methods

	// RVA: 0x6EE1E84
	public object .ctor(object prefix, object lname, object nsUri) { }

	// RVA: 0x6EE0678
	public object Set(object prefix, object lname, object nsUri) { }

	// RVA: 0x6EDB6A4
	public object Clear() { }

	// RVA: 0x6EE1638
	public object MatchNs(object lname, object nsUri) { }

	// RVA: 0x6EE1688
	public object MatchPrefix(object prefix, object lname) { }

	// RVA: 0x6EE1AA4
	public object CheckPrefixNS(object prefix, object namespaceUri) { }

	// RVA: 0x6EE62C0
	public override object GetHashCode() { }

	// RVA: 0x6EE63E8
	public object GetNSHashCode(object hasher) { }

	// RVA: 0x6EE64A8
	public override object Equals(object other) { }

	// RVA: 0x6EE2F40
	public override object ToString() { }

	// RVA: 0x6EE6578
	public static object op_Equality(object a, object b) { }

}

// Namespace: 
private struct ElemInfo
{

	// Fields
	public object name; // 0xFFFFFFFFFFFFFFF8
	public object xmlLang; // 0x10
	public object xmlSpace; // 0x18
	public object xmlspacePreserve; // 0x1C
	public object nsdecls; // 0x20

	// Methods

	// RVA: 0x6EE4390
	public object Set(object name, object xmlspacePreserve) { }

	// RVA: 0x6EE31E0
	public object Clear() { }

}

// Namespace: 
private struct AttrInfo
{

	// Fields
	public object name; // 0xFFFFFFFFFFFFFFF8
	public object val; // 0x10
	public object contentPos; // 0x18
	public object hashCode; // 0x1C
	public object prevHash; // 0x20

	// Methods

	// RVA: 0x6EE1E90
	public object Set(object n, object v) { }

	// RVA: 0x6EE2524
	public object Set(object n, object pos) { }

	// RVA: 0x6EE2EE0
	public object GetLocalnameAndNamespaceUri(object localname, object namespaceUri) { }

	// RVA: 0x6EE2FBC
	public object GetLocalnameAndNamespaceUriAndHash(object hasher, object localname, object namespaceUri) { }

	// RVA: 0x6EE2EF0
	public object MatchNS(object localname, object namespaceUri) { }

	// RVA: 0x6EE3028
	public object MatchHashNS(object hash, object localname, object namespaceUri) { }

	// RVA: 0x6EE0C00
	public object AdjustPosition(object adj) { }

}

// Namespace: 
private class NamespaceDecl
{

	// Fields
	public object prefix; // 0x8
	public object uri; // 0x10
	public object scopeLink; // 0x18
	public object prevLink; // 0x20
	public object scope; // 0x28
	public object implied; // 0x2C

	// Methods

	// RVA: 0x6EE007C
	public object .ctor(object prefix, object nsuri, object nextInScope, object prevDecl, object scope, object implied) { }

}

// Namespace: 
private struct SymbolTables
{

	// Fields
	public object symtable; // 0xFFFFFFFFFFFFFFF8
	public object symCount; // 0x0
	public object qnametable; // 0x8
	public object qnameCount; // 0x10

	// Methods

	// RVA: 0x6EDB5D4
	public object Init() { }

}

// Namespace: 
private class NestedBinXml
{

	// Fields
	public object symbolTables; // 0x8
	public object docState; // 0x28
	public object next; // 0x30

	// Methods

	// RVA: 0x6EE43AC
	public object .ctor(object symbolTables, object docState, object next) { }

}

// Namespace: System.Xml
internal sealed class XmlSqlBinaryReader
{

	// Fields
	internal static readonly object TypeOfObject; // 0x0
	internal static readonly object TypeOfString; // 0x8
	private static object TokenTypeMap; // 0x10
	private static object XsdKatmaiTimeScaleToValueLengthMap; // 0x18
	private static object ScanState2ReadState; // 0x20
	private object inStrm; // 0x8
	private object data; // 0x10
	private object pos; // 0x18
	private object mark; // 0x1C
	private object end; // 0x20
	private object offset; // 0x28
	private object eof; // 0x30
	private object sniffed; // 0x31
	private object isEmpty; // 0x32
	private object docState; // 0x34
	private object symbolTables; // 0x38
	private object xnt; // 0x58
	private object xntFromSettings; // 0x60
	private object xml; // 0x68
	private object xmlns; // 0x70
	private object nsxmlns; // 0x78
	private object baseUri; // 0x80
	private object state; // 0x88
	private object nodetype; // 0x8C
	private object token; // 0x90
	private object attrIndex; // 0x94
	private object qnameOther; // 0x98
	private object qnameElement; // 0xB0
	private object parentNodeType; // 0xC8
	private object elementStack; // 0xD0
	private object elemDepth; // 0xD8
	private object attributes; // 0xE0
	private object attrHashTbl; // 0xE8
	private object attrCount; // 0xF0
	private object posAfterAttrs; // 0xF4
	private object xmlspacePreserve; // 0xF8
	private object tokLen; // 0xFC
	private object tokDataPos; // 0x100
	private object hasTypedValue; // 0x104
	private object valueType; // 0x108
	private object stringValue; // 0x110
	private object namespaces; // 0x118
	private object prevNameInfo; // 0x120
	private object textXmlReader; // 0x128
	private object closeInput; // 0x130
	private object checkCharacters; // 0x131
	private object ignoreWhitespace; // 0x132
	private object ignorePIs; // 0x133
	private object ignoreComments; // 0x134
	private object dtdProcessing; // 0x138
	private object hasher; // 0x140
	private object xmlCharType; // 0x148
	private object unicode; // 0x150
	private object version; // 0x158

	// Properties
	public override object Settings { get; }
	public override object NodeType { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object ValueType { get; }
	public override object AttributeCount { get; }
	public override object EOF { get; }
	public override object NameTable { get; }
	public override object ReadState { get; }

	// Methods

	// RVA: 0x6EDB04C
	public object .ctor(object stream, object data, object len, object baseUri, object closeInput, object settings) { }

	// RVA: 0x6EDC2DC
	public override object get_Settings() { }

	// RVA: 0x6EDC434
	public override object get_NodeType() { }

	// RVA: 0x6EDC43C
	public override object get_LocalName() { }

	// RVA: 0x6EDC444
	public override object get_NamespaceURI() { }

	// RVA: 0x6EDC44C
	public override object get_Prefix() { }

	// RVA: 0x6EDC454
	public override object get_Value() { }

	// RVA: 0x6EDD454
	public override object get_Depth() { }

	// RVA: 0x6EDD528
	public override object get_BaseURI() { }

	// RVA: 0x6EDD530
	public override object get_IsEmptyElement() { }

	// RVA: 0x6EDD550
	public override object get_XmlSpace() { }

	// RVA: 0x6EDD610
	public override object get_XmlLang() { }

	// RVA: 0x6EDD704
	public override object get_ValueType() { }

	// RVA: 0x6EDD70C
	public override object get_AttributeCount() { }

	// RVA: 0x6EDD798
	public override object GetAttribute(object name, object ns) { }

	// RVA: 0x6EDDA4C
	public override object GetAttribute(object name) { }

	// RVA: 0x6EDDC1C
	public override object GetAttribute(object i) { }

	// RVA: 0x6EDDCE4
	public override object MoveToAttribute(object name) { }

	// RVA: 0x6EDDF44
	public override object MoveToAttribute(object i) { }

	// RVA: 0x6EDE0CC
	public override object MoveToFirstAttribute() { }

	// RVA: 0x6EDE1F0
	public override object MoveToNextAttribute() { }

	// RVA: 0x6EDE378
	public override object MoveToElement() { }

	// RVA: 0x6EDE470
	public override object get_EOF() { }

	// RVA: 0x6EDE480
	public override object ReadAttributeValue() { }

	// RVA: 0x6EDE970
	public override object Close() { }

	// RVA: 0x6EDEA1C
	public override object get_NameTable() { }

	// RVA: 0x6EDEA24
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x6EDEB38
	public override object ResolveEntity() { }

	// RVA: 0x6EDEB78
	public override object get_ReadState() { }

	// RVA: 0x6EDEC24
	public override object Read() { }

	// RVA: 0x6EDF8A8
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x6EDFD7C
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

	// RVA: 0x6EDFFA0
	private object VerifyVersion(object requiredVersion, object token) { }

	// RVA: 0x6EDB704
	private object AddInitNamespace(object prefix, object uri) { }

	// RVA: 0x6EE00E0
	private object AddName() { }

	// RVA: 0x6EE02FC
	private object AddQName() { }

	// RVA: 0x6EE0684
	private object NameFlush() { }

	// RVA: 0x6EE06F4
	private object SkipExtn() { }

	// RVA: 0x6EE08D0
	private object ReadQNameRef() { }

	// RVA: 0x6EE05D0
	private object ReadNameRef() { }

	// RVA: 0x6EE0978
	private object FillAllowEOF() { }

	// RVA: 0x6EE0C14
	private object Fill_(object require) { }

	// RVA: 0x6EE0840
	private object Fill(object require) { }

	// RVA: 0x6EE0D08
	private object ReadByte() { }

	// RVA: 0x6EE0DC0
	private object ReadUShort() { }

	// RVA: 0x6EE0804
	private object ParseMB32() { }

	// RVA: 0x6EE0E98
	private object ParseMB32_(object b) { }

	// RVA: 0x6EE0F40
	private object ParseMB32(object pos) { }

	// RVA: 0x6EE1040
	private object ParseMB64() { }

	// RVA: 0x6EE107C
	private object PeekToken() { }

	// RVA: 0x6EE1100
	private object ReadToken() { }

	// RVA: 0x6EE118C
	private object NextToken2(object token) { }

	// RVA: 0x6EE12B8
	private object NextToken1() { }

	// RVA: 0x6EE13C4
	private object NextToken() { }

	// RVA: 0x6EE1430
	private object PeekNextToken() { }

	// RVA: 0x6EDE68C
	private object RescanNextToken() { }

	// RVA: 0x6EE0230
	private object ParseText() { }

	// RVA: 0x6EE14B4
	private object ScanText(object start) { }

	// RVA: 0x6EDC5F0
	private object GetString(object pos, object cch) { }

	// RVA: 0x6EE15F8
	private object GetStringAligned(object data, object offset, object cch) { }

	// RVA: 0x6EDD2F8
	private object GetAttributeText(object i) { }

	// RVA: 0x6EDD97C
	private object LocateAttribute(object name, object ns) { }

	// RVA: 0x6EDDB0C
	private object LocateAttribute(object name) { }

	// RVA: 0x6EDDE70
	private object PositionOnAttribute(object i) { }

	// RVA: 0x6EE16D4
	private object GrowElements() { }

	// RVA: 0x6EE1770
	private object GrowAttributes() { }

	// RVA: 0x6EE17FC
	private object ClearAttributes() { }

	// RVA: 0x6EE180C
	private object PushNamespace(object prefix, object ns, object implied) { }

	// RVA: 0x6EE1BC0
	private object PopNamespaces(object firstInScopeChain) { }

	// RVA: 0x6EE1C88
	private object GenerateImpliedXmlnsAttrs() { }

	// RVA: 0x6EDEE44
	private object ReadInit(object skipXmlDecl) { }

	// RVA: 0x6EE1EAC
	private object ScanAttributes() { }

	// RVA: 0x6EE28F4
	private object SimpleCheckForDuplicateAttributes() { }

	// RVA: 0x6EE2A84
	private object HashCheckForDuplicateAttributes() { }

	// RVA: 0x6EDC964
	private object XmlDeclValue() { }

	// RVA: 0x6EDC788
	private object CDATAValue() { }

	// RVA: 0x6EE3084
	private object FinishCDATA() { }

	// RVA: 0x6EE3178
	private object FinishEndElement() { }

	// RVA: 0x6EDF348
	private object ReadDoc() { }

	// RVA: 0x6EE4160
	private object ImplReadData(object tokenType) { }

	// RVA: 0x6EE31F0
	private object ImplReadElement() { }

	// RVA: 0x6EE35C4
	private object ImplReadEndElement() { }

	// RVA: 0x6EE3698
	private object ImplReadDoctype() { }

	// RVA: 0x6EE3A30
	private object ImplReadPI() { }

	// RVA: 0x6EE3AA0
	private object ImplReadComment() { }

	// RVA: 0x6EE3AD8
	private object ImplReadCDATA() { }

	// RVA: 0x6EE3B64
	private object ImplReadNest() { }

	// RVA: 0x6EE3C50
	private object ImplReadEndNest() { }

	// RVA: 0x6EE3C90
	private object ImplReadXmlText() { }

	// RVA: 0x6EE43F8
	private object UpdateFromTextReader() { }

	// RVA: 0x6EDDE48
	private object UpdateFromTextReader(object needUpdate) { }

	// RVA: 0x6EE4324
	private object CheckAllowContent() { }

	// RVA: 0x6EDB804
	private object GenerateTokenTypeMap() { }

	// RVA: 0x6EDE85C
	private object GetValueType(object token) { }

	// RVA: 0x6EDE850
	private object ReScanOverValue(object token) { }

	// RVA: 0x6EE2618
	private object ScanOverValue(object token, object attr, object checkChars) { }

	// RVA: 0x6EE47D8
	private object ScanOverAnyValue(object token, object attr, object checkChars) { }

	// RVA: 0x6EE4520
	private object CheckText(object attr) { }

	// RVA: 0x6EE4730
	private object CheckTextIsWS() { }

	// RVA: 0x6EE4D34
	private object CheckValueTokenBounds() { }

	// RVA: 0x6EE4BC8
	private object GetXsdKatmaiTokenLength(object token) { }

	// RVA: 0x6EE4D94
	private object XsdKatmaiTimeScaleToValueLength(object scale) { }

	// RVA: 0x6EE4E70
	private object ValueAsLong() { }

	// RVA: 0x6EE5870
	private object ValueAsULong() { }

	// RVA: 0x6EE55E4
	private object ValueAsDecimal() { }

	// RVA: 0x6EE5438
	private object ValueAsDouble() { }

	// RVA: 0x6EE5A4C
	private object ValueAsDateTimeString() { }

	// RVA: 0x6EDCB5C
	private object ValueAsString(object token) { }

	// RVA: 0x6EE5110
	private object GetInt16(object pos) { }

	// RVA: 0x6EE52A4
	private object GetUInt16(object pos) { }

	// RVA: 0x6EE5164
	private object GetInt32(object pos) { }

	// RVA: 0x6EE52F8
	private object GetUInt32(object pos) { }

	// RVA: 0x6EE51DC
	private object GetInt64(object pos) { }

	// RVA: 0x6EE5370
	private object GetUInt64(object pos) { }

	// RVA: 0x6EE5904
	private object GetSingle(object offset) { }

	// RVA: 0x6EE5980
	private object GetDouble(object offset) { }

	// RVA: 0x6EDFFDC
	private object ThrowUnexpectedToken(object token) { }

	// RVA: 0x6EE0C90
	private object ThrowXmlException(object res) { }

	// RVA: 0x6EE2540
	private object ThrowXmlException(object res, object arg1, object arg2) { }

	// RVA: 0x6EE2870
	private object ThrowNotSupported(object res) { }

	// RVA: 0x6EE5F40
	private static object .cctor() { }

}

// Namespace: System.Xml
internal class BitStack
{

	// Fields
	private object bitStack; // 0x8
	private object stackPos; // 0x10
	private object curr; // 0x14

	// Methods

	// RVA: 0x6EE69C4
	public object .ctor() { }

	// RVA: 0x6EE69F0
	public object PushBit(object bit) { }

	// RVA: 0x6EE6B30
	public object PopBit() { }

	// RVA: 0x6EE6BE8
	public object PeekBit() { }

	// RVA: 0x6EE6A40
	private object PushCurr() { }

	// RVA: 0x6EE6B98
	private object PopCurr() { }

}

// Namespace: System.Xml
internal static class Bits
{

	// Fields
	private static readonly object MASK_0101010101010101; // 0x0
	private static readonly object MASK_0011001100110011; // 0x4
	private static readonly object MASK_0000111100001111; // 0x8
	private static readonly object MASK_0000000011111111; // 0xC
	private static readonly object MASK_1111111111111111; // 0x10

	// Methods

	// RVA: 0x6EE6BF4
	public static object Count(object num) { }

	// RVA: 0x6EE6C9C
	public static object LeastPosition(object num) { }

	// RVA: 0x6EE6DB8
	private static object .cctor() { }

}

// Namespace: System.Xml
internal class ByteStack
{

	// Fields
	private object stack; // 0x8
	private object growthRate; // 0x10
	private object top; // 0x14
	private object size; // 0x18

	// Methods

	// RVA: 0x6EE6E14
	public object .ctor(object growthRate) { }

	// RVA: 0x6EE6E88
	public object Push(object data) { }

	// RVA: 0x6EE6F6C
	public object Pop() { }

}

// Namespace: System.Xml
internal class CharEntityEncoderFallback
{

	// Fields
	private object fallbackBuffer; // 0x8
	private object textContentMarks; // 0x10
	private object endMarkPos; // 0x18
	private object curMarkPos; // 0x1C
	private object startOffset; // 0x20

	// Properties
	public override object MaxCharCount { get; }
	internal object StartOffset { set; }

	// Methods

	// RVA: 0x6EE6FC4
	internal object .ctor() { }

	// RVA: 0x6EE6FCC
	public override object CreateFallbackBuffer() { }

	// RVA: 0x6EE7118
	public override object get_MaxCharCount() { }

	// RVA: 0x6EE7120
	internal object set_StartOffset(object value) { }

	// RVA: 0x6EE7128
	internal object Reset(object textContentMarks, object endMarkPos) { }

	// RVA: 0x6EE7134
	internal object CanReplaceAt(object index) { }

}

// Namespace: System.Xml
internal class CharEntityEncoderFallbackBuffer
{

	// Fields
	private object parent; // 0x28
	private object charEntity; // 0x30
	private object charEntityIndex; // 0x38

	// Properties
	public override object Remaining { get; }

	// Methods

	// RVA: 0x6EE70A0
	internal object .ctor(object parent) { }

	// RVA: 0x6EE71D0
	public override object Fallback(object charUnknown, object index) { }

	// RVA: 0x6EE74E0
	public override object Fallback(object charUnknownHigh, object charUnknownLow, object index) { }

	// RVA: 0x6EE78A8
	public override object GetNextChar() { }

	// RVA: 0x6EE7908
	public override object MovePrevious() { }

	// RVA: 0x6EE7924
	public override object get_Remaining() { }

	// RVA: 0x6EE7960
	public override object Reset() { }

	// RVA: 0x6EE789C
	private object SurrogateCharToUtf32(object highSurrogate, object lowSurrogate) { }

}

// Namespace: System.Xml
public enum ConformanceLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object Fragment;
	public const object Document;
}

// Namespace: System.Xml
public enum DtdProcessing
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Prohibit;
	public const object Ignore;
	public const object Parse;
}

// Namespace: System.Xml
public enum EntityHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ExpandEntities;
	public const object ExpandCharEntities;
}

// Namespace: System.Xml
internal class HtmlEncodedRawTextWriter
{

	// Fields
	protected object elementScope; // 0xB8
	protected object currentElementProperties; // 0xC0
	private object currentAttributeProperties; // 0xC4
	private object endsWithAmpersand; // 0xC8
	private object uriEscapingBuffer; // 0xD0
	private object mediaType; // 0xD8
	private object doNotEscapeUriAttributes; // 0xE0
	protected static object elementPropertySearch; // 0x0
	protected static object attributePropertySearch; // 0x8

	// Methods

	// RVA: 0x6EE796C
	public object .ctor(object writer, object settings) { }

	// RVA: 0x6EE7B60
	public object .ctor(object stream, object settings) { }

	// RVA: 0x6EE7B90
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x6EE7B94
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x6EE7B98
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x6EE7E54
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x6EE7FC0
	internal override object StartElementContent() { }

	// RVA: 0x6EE8160
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x6EE82DC
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x6EE8458
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x6EE8614
	public override object WriteEndAttribute() { }

	// RVA: 0x6EE87E0
	public override object WriteProcessingInstruction(object target, object text) { }

	// RVA: 0x6EE895C
	public override object WriteString(object text) { }

	// RVA: 0x6EE8ABC
	public override object WriteEntityRef(object name) { }

	// RVA: 0x6EE8B18
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x6EE8B74
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x6EE8BD0
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x6EE799C
	private object Init(object settings) { }

	// RVA: 0x6EE8020
	protected object WriteMetaElement() { }

	// RVA: 0x6EE8AA4
	protected object WriteHtmlElementTextBlock(object pSrc, object pSrcEnd) { }

	// RVA: 0x6EE8A60
	protected object WriteHtmlAttributeTextBlock(object pSrc, object pSrcEnd) { }

	// RVA: 0x6EE9078
	private object WriteHtmlAttributeText(object pSrc, object pSrcEnd) { }

	// RVA: 0x6EE8C80
	private object WriteUriAttributeText(object pSrc, object pSrcEnd) { }

	// RVA: 0x6EE874C
	private object OutputRestAmps() { }

}

// Namespace: System.Xml
internal class HtmlEncodedRawTextWriterIndent
{

	// Fields
	private object indentLevel; // 0xE4
	private object endBlockPos; // 0xE8
	private object indentChars; // 0xF0
	private object newLineOnAttributes; // 0xF8

	// Methods

	// RVA: 0x6EE935C
	public object .ctor(object writer, object settings) { }

	// RVA: 0x6EE93E4
	public object .ctor(object stream, object settings) { }

	// RVA: 0x6EE943C
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x6EE9464
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x6EE9744
	internal override object StartElementContent() { }

	// RVA: 0x6EE9804
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x6EE9900
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x6EE99B8
	protected override object FlushBuffer() { }

	// RVA: 0x6EE93B4
	private object Init(object settings) { }

	// RVA: 0x6EE96F0
	private object WriteIndent() { }

}

// Namespace: System.Xml
internal abstract class HtmlTernaryTree
{

	// Fields
	internal static object htmlElements; // 0x0
	internal static object htmlAttributes; // 0x8

	// Methods

	// RVA: 0x6EE99EC
	private static object .cctor() { }

}

// Namespace: System.Xml
internal class HtmlUtf8RawTextWriter
{

	// Fields
	protected object elementScope; // 0x88
	protected object currentElementProperties; // 0x90
	private object currentAttributeProperties; // 0x94
	private object endsWithAmpersand; // 0x98
	private object uriEscapingBuffer; // 0xA0
	private object mediaType; // 0xA8
	private object doNotEscapeUriAttributes; // 0xB0
	protected static object elementPropertySearch; // 0x0
	protected static object attributePropertySearch; // 0x8

	// Methods

	// RVA: 0x6EE9AC8
	public object .ctor(object stream, object settings) { }

	// RVA: 0x6EE9CBC
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x6EE9CC0
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x6EE9CC4
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x6EE9F98
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x6EEA0DC
	internal override object StartElementContent() { }

	// RVA: 0x6EEA280
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x6EEA3EC
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x6EEA558
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x6EEA70C
	public override object WriteEndAttribute() { }

	// RVA: 0x6EEA884
	public override object WriteProcessingInstruction(object target, object text) { }

	// RVA: 0x6EEA9E8
	public override object WriteString(object text) { }

	// RVA: 0x6EEAB24
	public override object WriteEntityRef(object name) { }

	// RVA: 0x6EEAB80
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x6EEABDC
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x6EEAC38
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x6EE9AF8
	private object Init(object settings) { }

	// RVA: 0x6EEA140
	protected object WriteMetaElement() { }

	// RVA: 0x6EEAB0C
	protected object WriteHtmlElementTextBlock(object pSrc, object pSrcEnd) { }

	// RVA: 0x6EEAAC8
	protected object WriteHtmlAttributeTextBlock(object pSrc, object pSrcEnd) { }

	// RVA: 0x6EEB018
	private object WriteHtmlAttributeText(object pSrc, object pSrcEnd) { }

	// RVA: 0x6EEAC90
	private object WriteUriAttributeText(object pSrc, object pSrcEnd) { }

	// RVA: 0x6EEA790
	private object OutputRestAmps() { }

}

// Namespace: System.Xml
internal class HtmlUtf8RawTextWriterIndent
{

	// Fields
	private object indentLevel; // 0xB4
	private object endBlockPos; // 0xB8
	private object indentChars; // 0xC0
	private object newLineOnAttributes; // 0xC8

	// Methods

	// RVA: 0x700C710
	public object .ctor(object stream, object settings) { }

	// RVA: 0x700C78C
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x700C7B8
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x700CBDC
	internal override object StartElementContent() { }

	// RVA: 0x700CCA4
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x700CDA8
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x700CE64
	protected override object FlushBuffer() { }

	// RVA: 0x700C75C
	private object Init(object settings) { }

	// RVA: 0x700CB88
	private object WriteIndent() { }

}

// Namespace: System.Xml
internal interface IDtdInfo
{

	// Properties
	public abstract object Name { get; }
	public abstract object InternalDtdSubset { get; }
	public abstract object HasDefaultAttributes { get; }
	public abstract object HasNonCDataAttributes { get; }

	// Methods

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: -1
	public abstract object get_InternalDtdSubset() { }

	// RVA: -1
	public abstract object get_HasDefaultAttributes() { }

	// RVA: -1
	public abstract object get_HasNonCDataAttributes() { }

	// RVA: -1
	public abstract object LookupAttributeList(object prefix, object localName) { }

	// RVA: -1
	public abstract object LookupEntity(object name) { }

}

// Namespace: System.Xml
internal interface IDtdAttributeListInfo
{

	// Properties
	public abstract object HasNonCDataAttributes { get; }

	// Methods

	// RVA: -1
	public abstract object get_HasNonCDataAttributes() { }

	// RVA: -1
	public abstract object LookupAttribute(object prefix, object localName) { }

	// RVA: -1
	public abstract object LookupDefaultAttributes() { }

}

// Namespace: System.Xml
internal interface IDtdAttributeInfo
{

	// Properties
	public abstract object Prefix { get; }
	public abstract object LocalName { get; }
	public abstract object LineNumber { get; }
	public abstract object LinePosition { get; }
	public abstract object IsNonCDataType { get; }
	public abstract object IsDeclaredInExternal { get; }
	public abstract object IsXmlAttribute { get; }

	// Methods

	// RVA: -1
	public abstract object get_Prefix() { }

	// RVA: -1
	public abstract object get_LocalName() { }

	// RVA: -1
	public abstract object get_LineNumber() { }

	// RVA: -1
	public abstract object get_LinePosition() { }

	// RVA: -1
	public abstract object get_IsNonCDataType() { }

	// RVA: -1
	public abstract object get_IsDeclaredInExternal() { }

	// RVA: -1
	public abstract object get_IsXmlAttribute() { }

}

// Namespace: System.Xml
internal interface IDtdDefaultAttributeInfo
{

	// Properties
	public abstract object DefaultValueExpanded { get; }
	public abstract object DefaultValueTyped { get; }
	public abstract object ValueLineNumber { get; }
	public abstract object ValueLinePosition { get; }

	// Methods

	// RVA: -1
	public abstract object get_DefaultValueExpanded() { }

	// RVA: -1
	public abstract object get_DefaultValueTyped() { }

	// RVA: -1
	public abstract object get_ValueLineNumber() { }

	// RVA: -1
	public abstract object get_ValueLinePosition() { }

}

// Namespace: System.Xml
internal interface IDtdEntityInfo
{

	// Properties
	public abstract object Name { get; }
	public abstract object IsExternal { get; }
	public abstract object IsDeclaredInExternal { get; }
	public abstract object IsUnparsedEntity { get; }
	public abstract object IsParameterEntity { get; }
	public abstract object BaseUriString { get; }
	public abstract object DeclaredUriString { get; }
	public abstract object SystemId { get; }
	public abstract object PublicId { get; }
	public abstract object Text { get; }
	public abstract object LineNumber { get; }
	public abstract object LinePosition { get; }

	// Methods

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: -1
	public abstract object get_IsExternal() { }

	// RVA: -1
	public abstract object get_IsDeclaredInExternal() { }

	// RVA: -1
	public abstract object get_IsUnparsedEntity() { }

	// RVA: -1
	public abstract object get_IsParameterEntity() { }

	// RVA: -1
	public abstract object get_BaseUriString() { }

	// RVA: -1
	public abstract object get_DeclaredUriString() { }

	// RVA: -1
	public abstract object get_SystemId() { }

	// RVA: -1
	public abstract object get_PublicId() { }

	// RVA: -1
	public abstract object get_Text() { }

	// RVA: -1
	public abstract object get_LineNumber() { }

	// RVA: -1
	public abstract object get_LinePosition() { }

}

// Namespace: System.Xml
internal interface IDtdParser
{

	// Methods

	// RVA: -1
	public abstract object ParseInternalDtd(object adapter, object saveInternalSubset) { }

	// RVA: -1
	public abstract object ParseFreeFloatingDtd(object baseUri, object docTypeName, object publicId, object systemId, object internalSubset, object adapter) { }

}

// Namespace: System.Xml
internal interface IDtdParserAdapter
{

	// Properties
	public abstract object NameTable { get; }
	public abstract object NamespaceResolver { get; }
	public abstract object BaseUri { get; }
	public abstract object ParsingBuffer { get; }
	public abstract object ParsingBufferLength { get; }
	public abstract object CurrentPosition { get; set; }
	public abstract object LineNo { get; }
	public abstract object LineStartPosition { get; }
	public abstract object IsEof { get; }
	public abstract object EntityStackLength { get; }
	public abstract object IsEntityEolNormalized { get; }

	// Methods

	// RVA: -1
	public abstract object get_NameTable() { }

	// RVA: -1
	public abstract object get_NamespaceResolver() { }

	// RVA: -1
	public abstract object get_BaseUri() { }

	// RVA: -1
	public abstract object get_ParsingBuffer() { }

	// RVA: -1
	public abstract object get_ParsingBufferLength() { }

	// RVA: -1
	public abstract object get_CurrentPosition() { }

	// RVA: -1
	public abstract object set_CurrentPosition(object value) { }

	// RVA: -1
	public abstract object get_LineNo() { }

	// RVA: -1
	public abstract object get_LineStartPosition() { }

	// RVA: -1
	public abstract object get_IsEof() { }

	// RVA: -1
	public abstract object get_EntityStackLength() { }

	// RVA: -1
	public abstract object get_IsEntityEolNormalized() { }

	// RVA: -1
	public abstract object ReadData() { }

	// RVA: -1
	public abstract object OnNewLine(object pos) { }

	// RVA: -1
	public abstract object ParseNumericCharRef(object internalSubsetBuilder) { }

	// RVA: -1
	public abstract object ParseNamedCharRef(object expand, object internalSubsetBuilder) { }

	// RVA: -1
	public abstract object ParsePI(object sb) { }

	// RVA: -1
	public abstract object ParseComment(object sb) { }

	// RVA: -1
	public abstract object PushEntity(object entity, object entityId) { }

	// RVA: -1
	public abstract object PopEntity(object oldEntity, object newEntityId) { }

	// RVA: -1
	public abstract object PushExternalSubset(object systemId, object publicId) { }

	// RVA: -1
	public abstract object PushInternalDtd(object baseUri, object internalDtd) { }

	// RVA: -1
	public abstract object OnSystemId(object systemId, object keywordLineInfo, object systemLiteralLineInfo) { }

	// RVA: -1
	public abstract object OnPublicId(object publicId, object keywordLineInfo, object publicLiteralLineInfo) { }

	// RVA: -1
	public abstract object Throw(object e) { }

}

// Namespace: System.Xml
internal interface IDtdParserAdapterWithValidation
{

	// Properties
	public abstract object DtdValidation { get; }
	public abstract object ValidationEventHandling { get; }

	// Methods

	// RVA: -1
	public abstract object get_DtdValidation() { }

	// RVA: -1
	public abstract object get_ValidationEventHandling() { }

}

// Namespace: System.Xml
internal interface IDtdParserAdapterV1
{

	// Properties
	public abstract object V1CompatibilityMode { get; }
	public abstract object Normalization { get; }
	public abstract object Namespaces { get; }

	// Methods

	// RVA: -1
	public abstract object get_V1CompatibilityMode() { }

	// RVA: -1
	public abstract object get_Normalization() { }

	// RVA: -1
	public abstract object get_Namespaces() { }

}

// Namespace: System.Xml
internal sealed class OnRemoveWriter
{

	// Methods

	// RVA: 0x700D170
	public object .ctor(object object, object method) { }

	// RVA: 0x700D28C
	public virtual object Invoke(object writer) { }

}

// Namespace: System.Xml
internal interface IValidationEventHandling
{

	// Properties
	public abstract object EventHandler { get; }

	// Methods

	// RVA: -1
	public abstract object get_EventHandler() { }

	// RVA: -1
	public abstract object SendEvent(object exception, object severity) { }

}

// Namespace: System.Xml
internal abstract class IncrementalReadDecoder
{

	// Properties
	internal abstract object IsFull { get; }

	// Methods

	// RVA: -1
	internal abstract object get_IsFull() { }

	// RVA: -1
	internal abstract object Decode(object chars, object startPos, object len) { }

	// RVA: 0x700D2A0
	protected object .ctor() { }

}

// Namespace: System.Xml
internal class IncrementalReadDummyDecoder
{

	// Properties
	internal override object IsFull { get; }

	// Methods

	// RVA: 0x700D2A8
	internal override object get_IsFull() { }

	// RVA: 0x700D2B0
	internal override object Decode(object chars, object startPos, object len) { }

	// RVA: 0x700D2B8
	public object .ctor() { }

}

// Namespace: System.Xml
public enum NamespaceHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object OmitDuplicates;
}

// Namespace: System.Xml
public enum NewLineHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Replace;
	public const object Entitize;
	public const object None;
}

// Namespace: System.Xml
internal class QueryOutputWriter
{

	// Fields
	private object wrapped; // 0x20
	private object inCDataSection; // 0x28
	private object lookupCDataElems; // 0x30
	private object bitsCData; // 0x38
	private object qnameCData; // 0x40
	private object outputDocType; // 0x48
	private object checkWellFormedDoc; // 0x49
	private object hasDocElem; // 0x4A
	private object inAttr; // 0x4B
	private object systemId; // 0x50
	private object publicId; // 0x58
	private object depth; // 0x60

	// Properties
	internal override object NamespaceResolver { set; }
	internal override object SupportsNamespaceDeclarationInChunks { get; }

	// Methods

	// RVA: 0x700D2C0
	public object .ctor(object writer, object settings) { }

	// RVA: 0x700D5EC
	internal override object set_NamespaceResolver(object value) { }

	// RVA: 0x700D648
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x700D6A0
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x700D6F8
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x700D798
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x700DA04
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x700DAD4
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x700DBA4
	internal override object StartElementContent() { }

	// RVA: 0x700DBF4
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x700DC68
	public override object WriteEndAttribute() { }

	// RVA: 0x700DCBC
	internal override object WriteNamespaceDeclaration(object prefix, object ns) { }

	// RVA: 0x700DD24
	internal override object get_SupportsNamespaceDeclarationInChunks() { }

	// RVA: 0x700DD74
	internal override object WriteStartNamespaceDeclaration(object prefix) { }

	// RVA: 0x700DDCC
	internal override object WriteEndNamespaceDeclaration() { }

	// RVA: 0x700DE1C
	public override object WriteCData(object text) { }

	// RVA: 0x700DE74
	public override object WriteComment(object text) { }

	// RVA: 0x700DED0
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x700DF3C
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x700E084
	public override object WriteString(object text) { }

	// RVA: 0x700E170
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x700E2A0
	public override object WriteEntityRef(object name) { }

	// RVA: 0x700E2FC
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x700E358
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x700E3C4
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x700E4F4
	public override object WriteRaw(object data) { }

	// RVA: 0x700E5E0
	public override object Close() { }

	// RVA: 0x700E6AC
	public override object Flush() { }

	// RVA: 0x700E028
	private object StartCDataSection() { }

	// RVA: 0x700D9FC
	private object EndCDataSection() { }

}

// Namespace: 
private enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object InReadContent;
	public const object InReadElementContent;
}

// Namespace: System.Xml
internal class ReadContentAsBinaryHelper
{

	// Fields
	private object reader; // 0x8
	private object state; // 0x10
	private object valueOffset; // 0x14
	private object isEnd; // 0x18

	// Methods

	// RVA: 0x700E6FC
	internal object Finish() { }

	// RVA: 0x700EB4C
	internal object Reset() { }

	// RVA: 0x700E894
	private object MoveToNextContentNode(object moveIfOnContentNode) { }

}

// Namespace: System.Xml
internal enum ElementProperties
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DEFAULT;
	public const object URI_PARENT;
	public const object BOOL_PARENT;
	public const object NAME_PARENT;
	public const object EMPTY;
	public const object NO_ENTITIES;
	public const object HEAD;
	public const object BLOCK_WS;
	public const object HAS_NS;
}

// Namespace: System.Xml
internal enum AttributeProperties
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DEFAULT;
	public const object URI;
	public const object BOOLEAN;
	public const object NAME;
}

// Namespace: System.Xml
internal class TernaryTreeReadOnly
{

	// Fields
	private object nodeBuffer; // 0x8

	// Methods

	// RVA: 0x700EB58
	public object .ctor(object nodeBuffer) { }

	// RVA: 0x700CA1C
	public object FindCaseInsensitiveString(object stringToFind) { }

}

// Namespace: System.Xml
public enum ReadState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Initial;
	public const object Interactive;
	public const object Error;
	public const object EndOfFile;
	public const object Closed;
}

// Namespace: 
private sealed class HashCodeOfStringDelegate
{

	// Methods

	// RVA: 0x700EF18
	public object .ctor(object object, object method) { }

	// RVA: 0x700F0E8
	public virtual object Invoke(object s, object sLen, object additionalEntropy) { }

}

// Namespace: System.Xml
internal class SecureStringHasher
{

	// Fields
	private static object hashCodeDelegate; // 0x0
	private object hashCodeRandomizer; // 0x8

	// Methods

	// RVA: 0x700EB84
	public object .ctor() { }

	// RVA: 0x700EBB4
	public object Equals(object x, object y) { }

	// RVA: 0x700EBC8
	public object GetHashCode(object key) { }

	// RVA: 0x700EE9C
	private static object GetHashCodeOfString(object key, object sLen, object additionalEntropy) { }

	// RVA: 0x700EC88
	private static object GetHashCodeDelegate() { }

}

// Namespace: System.Xml
internal class TextEncodedRawTextWriter
{

	// Properties
	internal override object SupportsNamespaceDeclarationInChunks { get; }

	// Methods

	// RVA: 0x700F0FC
	public object .ctor(object writer, object settings) { }

	// RVA: 0x700F248
	public object .ctor(object stream, object settings) { }

	// RVA: 0x700F604
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x700F608
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x700F60C
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x700F610
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x700F614
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x700F618
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x700F61C
	internal override object StartElementContent() { }

	// RVA: 0x700F620
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x700F62C
	public override object WriteEndAttribute() { }

	// RVA: 0x700F634
	internal override object WriteNamespaceDeclaration(object prefix, object ns) { }

	// RVA: 0x700F638
	internal override object get_SupportsNamespaceDeclarationInChunks() { }

	// RVA: 0x700F640
	public override object WriteCData(object text) { }

	// RVA: 0x700F730
	public override object WriteComment(object text) { }

	// RVA: 0x700F734
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x700F738
	public override object WriteEntityRef(object name) { }

	// RVA: 0x700F73C
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x700F740
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x700F744
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x700F7C4
	public override object WriteString(object textBlock) { }

	// RVA: 0x700F844
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x700F984
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x700FA28
	public override object WriteRaw(object data) { }

}

// Namespace: System.Xml
internal class TextUtf8RawTextWriter
{

	// Properties
	internal override object SupportsNamespaceDeclarationInChunks { get; }

	// Methods

	// RVA: 0x700FAA8
	public object .ctor(object stream, object settings) { }

	// RVA: 0x700FAB0
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x700FAB4
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x700FAB8
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x700FABC
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x700FAC0
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x700FAC4
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x700FAC8
	internal override object StartElementContent() { }

	// RVA: 0x700FACC
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x700FAD8
	public override object WriteEndAttribute() { }

	// RVA: 0x700FAE0
	internal override object WriteNamespaceDeclaration(object prefix, object ns) { }

	// RVA: 0x700FAE4
	internal override object get_SupportsNamespaceDeclarationInChunks() { }

	// RVA: 0x700FAEC
	public override object WriteCData(object text) { }

	// RVA: 0x700FAF4
	public override object WriteComment(object text) { }

	// RVA: 0x700FAF8
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x700FAFC
	public override object WriteEntityRef(object name) { }

	// RVA: 0x700FB00
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x700FB04
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x700FB08
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x700FB1C
	public override object WriteString(object textBlock) { }

	// RVA: 0x700FB30
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x700FB44
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x700FB58
	public override object WriteRaw(object data) { }

}

// Namespace: System.Xml
internal class ValidatingReaderNodeData
{

	// Fields
	private object localName; // 0x8
	private object namespaceUri; // 0x10
	private object prefix; // 0x18
	private object nameWPrefix; // 0x20
	private object rawValue; // 0x28
	private object originalStringValue; // 0x30
	private object depth; // 0x38
	private object attributePSVIInfo; // 0x40
	private object nodeType; // 0x48
	private object lineNo; // 0x4C
	private object linePos; // 0x50

	// Properties
	public object LocalName { get; set; }
	public object Namespace { get; set; }
	public object Prefix { get; set; }
	public object Depth { get; set; }
	public object RawValue { get; set; }
	public object OriginalStringValue { get; }
	public object NodeType { get; set; }
	public object AttInfo { get; set; }
	public object LineNumber { get; }
	public object LinePosition { get; }

	// Methods

	// RVA: 0x700FB6C
	public object .ctor() { }

	// RVA: 0x700FC78
	public object .ctor(object nodeType) { }

	// RVA: 0x700FD04
	public object get_LocalName() { }

	// RVA: 0x700FD0C
	public object set_LocalName(object value) { }

	// RVA: 0x700FD14
	public object get_Namespace() { }

	// RVA: 0x700FD1C
	public object set_Namespace(object value) { }

	// RVA: 0x700FD24
	public object get_Prefix() { }

	// RVA: 0x700FD2C
	public object set_Prefix(object value) { }

	// RVA: 0x700FD34
	public object GetAtomizedNameWPrefix(object nameTable) { }

	// RVA: 0x700FE14
	public object get_Depth() { }

	// RVA: 0x700FE1C
	public object set_Depth(object value) { }

	// RVA: 0x700FE24
	public object get_RawValue() { }

	// RVA: 0x700FE2C
	public object set_RawValue(object value) { }

	// RVA: 0x700FE34
	public object get_OriginalStringValue() { }

	// RVA: 0x700FE3C
	public object get_NodeType() { }

	// RVA: 0x700FE44
	public object set_NodeType(object value) { }

	// RVA: 0x700FE4C
	public object get_AttInfo() { }

	// RVA: 0x700FE54
	public object set_AttInfo(object value) { }

	// RVA: 0x700FE5C
	public object get_LineNumber() { }

	// RVA: 0x700FE64
	public object get_LinePosition() { }

	// RVA: 0x700FBF4
	internal object Clear(object nodeType) { }

	// RVA: 0x700FE6C
	internal object SetLineInfo(object lineNo, object linePos) { }

	// RVA: 0x700FE74
	internal object SetLineInfo(object lineInfo) { }

	// RVA: 0x700FFC0
	internal object SetItemData(object localName, object prefix, object ns, object depth) { }

	// RVA: 0x7010048
	internal object SetItemData(object value) { }

	// RVA: 0x7010050
	internal object SetItemData(object value, object originalStringValue) { }

}

// Namespace: System.Xml
public enum ValidationType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Auto;
	public const object DTD;
	public const object XDR;
	public const object Schema;
}

// Namespace: System.Xml
public enum WhitespaceHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object All;
	public const object Significant;
	public const object None;
}

// Namespace: System.Xml
internal class XmlAsyncCheckReader
{

	// Fields
	private readonly object coreReader; // 0x8
	private object lastTask; // 0x10

	// Properties
	internal object CoreReader { get; }
	public override object Settings { get; }
	public override object NodeType { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object IsDefault { get; }
	public override object QuoteChar { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object SchemaInfo { get; }
	public override object ValueType { get; }
	public override object AttributeCount { get; }
	public override object EOF { get; }
	public override object ReadState { get; }
	public override object NameTable { get; }
	public override object CanResolveEntity { get; }
	public override object CanReadValueChunk { get; }
	public override object HasAttributes { get; }
	internal override object NamespaceManager { get; }
	internal override object DtdInfo { get; }

	// Methods

	// RVA: 0x7010058
	internal object get_CoreReader() { }

	// RVA: 0x7010060
	public static object CreateAsyncCheckWrapper(object reader) { }

	// RVA: 0x7010734
	public object .ctor(object reader) { }

	// RVA: 0x7010810
	private object CheckAsync() { }

	// RVA: 0x7010898
	public override object get_Settings() { }

	// RVA: 0x7010BF0
	public override object get_NodeType() { }

	// RVA: 0x7010C44
	public override object get_Name() { }

	// RVA: 0x7010C98
	public override object get_LocalName() { }

	// RVA: 0x7010CEC
	public override object get_NamespaceURI() { }

	// RVA: 0x7010D40
	public override object get_Prefix() { }

	// RVA: 0x7010D94
	public override object get_Value() { }

	// RVA: 0x7010DE8
	public override object get_Depth() { }

	// RVA: 0x7010E3C
	public override object get_BaseURI() { }

	// RVA: 0x7010E94
	public override object get_IsEmptyElement() { }

	// RVA: 0x7010EEC
	public override object get_IsDefault() { }

	// RVA: 0x7010F44
	public override object get_QuoteChar() { }

	// RVA: 0x7010F9C
	public override object get_XmlSpace() { }

	// RVA: 0x7010FF4
	public override object get_XmlLang() { }

	// RVA: 0x701104C
	public override object get_SchemaInfo() { }

	// RVA: 0x70110A4
	public override object get_ValueType() { }

	// RVA: 0x70110FC
	public override object get_AttributeCount() { }

	// RVA: 0x7011154
	public override object GetAttribute(object name) { }

	// RVA: 0x70111B4
	public override object GetAttribute(object name, object namespaceURI) { }

	// RVA: 0x7011224
	public override object GetAttribute(object i) { }

	// RVA: 0x7011284
	public override object MoveToAttribute(object name) { }

	// RVA: 0x70112E4
	public override object MoveToAttribute(object i) { }

	// RVA: 0x7011344
	public override object MoveToFirstAttribute() { }

	// RVA: 0x701139C
	public override object MoveToNextAttribute() { }

	// RVA: 0x70113F4
	public override object MoveToElement() { }

	// RVA: 0x701144C
	public override object ReadAttributeValue() { }

	// RVA: 0x70114A4
	public override object Read() { }

	// RVA: 0x70114FC
	public override object get_EOF() { }

	// RVA: 0x7011554
	public override object Close() { }

	// RVA: 0x70115AC
	public override object get_ReadState() { }

	// RVA: 0x7011604
	public override object Skip() { }

	// RVA: 0x701165C
	public override object get_NameTable() { }

	// RVA: 0x70116B4
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x7011714
	public override object get_CanResolveEntity() { }

	// RVA: 0x701176C
	public override object ResolveEntity() { }

	// RVA: 0x70117C4
	public override object get_CanReadValueChunk() { }

	// RVA: 0x701181C
	public override object ReadValueChunk(object buffer, object index, object count) { }

	// RVA: 0x7011894
	public override object ReadString() { }

	// RVA: 0x70118EC
	public override object MoveToContent() { }

	// RVA: 0x7011944
	public override object ReadStartElement() { }

	// RVA: 0x701199C
	public override object ReadElementString() { }

	// RVA: 0x70119F4
	public override object ReadEndElement() { }

	// RVA: 0x7011A4C
	public override object IsStartElement(object localname, object ns) { }

	// RVA: 0x7011ABC
	public override object ReadInnerXml() { }

	// RVA: 0x7011B14
	public override object get_HasAttributes() { }

	// RVA: 0x7011B6C
	protected override object Dispose(object disposing) { }

	// RVA: 0x7011C10
	internal override object get_NamespaceManager() { }

	// RVA: 0x7011C68
	internal override object get_DtdInfo() { }

}

// Namespace: System.Xml
internal class XmlAsyncCheckReaderWithNS
{

	// Fields
	private readonly object readerAsIXmlNamespaceResolver; // 0x18

	// Methods

	// RVA: 0x70105B8
	public object .ctor(object reader) { }

	// RVA: 0x7011CC0
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x7011D94
	private object System.Xml.IXmlNamespaceResolver.LookupNamespace(object prefix) { }

	// RVA: 0x7011E6C
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

}

// Namespace: System.Xml
internal class XmlAsyncCheckReaderWithLineInfo
{

	// Fields
	private readonly object readerAsIXmlLineInfo; // 0x18

	// Properties
	public virtual object LineNumber { get; }
	public virtual object LinePosition { get; }

	// Methods

	// RVA: 0x701043C
	public object .ctor(object reader) { }

	// RVA: 0x7011F44
	public virtual object HasLineInfo() { }

	// RVA: 0x7012024
	public virtual object get_LineNumber() { }

	// RVA: 0x7012108
	public virtual object get_LinePosition() { }

}

// Namespace: System.Xml
internal class XmlAsyncCheckReaderWithLineInfoNS
{

	// Fields
	private readonly object readerAsIXmlNamespaceResolver; // 0x20

	// Methods

	// RVA: 0x7010384
	public object .ctor(object reader) { }

	// RVA: 0x70121EC
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x70122C0
	private object System.Xml.IXmlNamespaceResolver.LookupNamespace(object prefix) { }

	// RVA: 0x7012398
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

}

// Namespace: System.Xml
internal class XmlAsyncCheckReaderWithLineInfoNSSchema
{

	// Fields
	private readonly object readerAsIXmlSchemaInfo; // 0x28

	// Properties
	private object System.Xml.Schema.IXmlSchemaInfo.Validity { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.IsDefault { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.IsNil { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.MemberType { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.SchemaType { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.SchemaElement { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.SchemaAttribute { get; }

	// Methods

	// RVA: 0x70102CC
	public object .ctor(object reader) { }

	// RVA: 0x7012470
	private object System.Xml.Schema.IXmlSchemaInfo.get_Validity() { }

	// RVA: 0x7012550
	private object System.Xml.Schema.IXmlSchemaInfo.get_IsDefault() { }

	// RVA: 0x7012634
	private object System.Xml.Schema.IXmlSchemaInfo.get_IsNil() { }

	// RVA: 0x7012718
	private object System.Xml.Schema.IXmlSchemaInfo.get_MemberType() { }

	// RVA: 0x70127FC
	private object System.Xml.Schema.IXmlSchemaInfo.get_SchemaType() { }

	// RVA: 0x70128E0
	private object System.Xml.Schema.IXmlSchemaInfo.get_SchemaElement() { }

	// RVA: 0x70129C4
	private object System.Xml.Schema.IXmlSchemaInfo.get_SchemaAttribute() { }

}

// Namespace: System.Xml
internal class XmlAsyncCheckWriter
{

	// Fields
	private readonly object coreWriter; // 0x10
	private object lastTask; // 0x18

	// Properties
	public override object WriteState { get; }

	// Methods

	// RVA: 0x7012AA8
	public object .ctor(object writer) { }

	// RVA: 0x7012B28
	private object CheckAsync() { }

	// RVA: 0x7012BB0
	public override object WriteStartDocument() { }

	// RVA: 0x7012C04
	public override object WriteStartDocument(object standalone) { }

	// RVA: 0x7012C60
	public override object WriteEndDocument() { }

	// RVA: 0x7012CB4
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x7012D38
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x7012DAC
	public override object WriteEndElement() { }

	// RVA: 0x7012E00
	public override object WriteFullEndElement() { }

	// RVA: 0x7012E54
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x7012EC8
	public override object WriteEndAttribute() { }

	// RVA: 0x7012F20
	public override object WriteCData(object text) { }

	// RVA: 0x7012F80
	public override object WriteComment(object text) { }

	// RVA: 0x7012FE0
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x7013050
	public override object WriteEntityRef(object name) { }

	// RVA: 0x70130B0
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x7013110
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x7013170
	public override object WriteString(object text) { }

	// RVA: 0x70131D0
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x7013240
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x70132B8
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x7013330
	public override object WriteRaw(object data) { }

	// RVA: 0x7013390
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x7013408
	public override object WriteBinHex(object buffer, object index, object count) { }

	// RVA: 0x7013480
	public override object get_WriteState() { }

	// RVA: 0x70134D8
	public override object Close() { }

	// RVA: 0x7013530
	public override object Flush() { }

	// RVA: 0x7013588
	public override object LookupPrefix(object ns) { }

	// RVA: 0x70135E8
	public override object WriteValue(object value) { }

	// RVA: 0x7013648
	public override object WriteAttributes(object reader, object defattr) { }

	// RVA: 0x70136B8
	public override object WriteNode(object reader, object defattr) { }

	// RVA: 0x7013728
	protected override object Dispose(object disposing) { }

}

// Namespace: System.Xml
internal class XmlAutoDetectWriter
{

	// Fields
	private object wrapped; // 0x20
	private object onRemove; // 0x28
	private object writerSettings; // 0x30
	private object eventCache; // 0x38
	private object textWriter; // 0x40
	private object strm; // 0x48

	// Properties
	internal override object NamespaceResolver { set; }
	internal override object SupportsNamespaceDeclarationInChunks { get; }

	// Methods

	// RVA: 0x7013760
	private object .ctor(object writerSettings) { }

	// RVA: 0x7013870
	public object .ctor(object textWriter, object writerSettings) { }

	// RVA: 0x701389C
	public object .ctor(object strm, object writerSettings) { }

	// RVA: 0x70138C8
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x7013968
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x7013CE4
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x7013D64
	public override object WriteEndAttribute() { }

	// RVA: 0x7013DB4
	public override object WriteCData(object text) { }

	// RVA: 0x7013EE8
	public override object WriteComment(object text) { }

	// RVA: 0x7013F48
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x7013FB8
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x7014018
	public override object WriteString(object text) { }

	// RVA: 0x70140D0
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x7014124
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x7014178
	public override object WriteRaw(object data) { }

	// RVA: 0x7014230
	public override object WriteEntityRef(object name) { }

	// RVA: 0x701429C
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x7014308
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x7014384
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x7014408
	public override object WriteBinHex(object buffer, object index, object count) { }

	// RVA: 0x701448C
	public override object Close() { }

	// RVA: 0x70144F0
	public override object Flush() { }

	// RVA: 0x7014554
	public override object WriteValue(object value) { }

	// RVA: 0x70145C0
	internal override object set_NamespaceResolver(object value) { }

	// RVA: 0x7014624
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x7014690
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x70146FC
	internal override object StartElementContent() { }

	// RVA: 0x701474C
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x70147BC
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x701482C
	internal override object WriteNamespaceDeclaration(object prefix, object ns) { }

	// RVA: 0x70148A8
	internal override object get_SupportsNamespaceDeclarationInChunks() { }

	// RVA: 0x70148F8
	internal override object WriteStartNamespaceDeclaration(object prefix) { }

	// RVA: 0x7014964
	internal override object WriteEndNamespaceDeclaration() { }

	// RVA: 0x7013A20
	private static object IsHtmlTag(object tagName) { }

	// RVA: 0x7013958
	private object EnsureWrappedWriter(object outMethod) { }

	// RVA: 0x7013E6C
	private object TextBlockCreatesWriter(object textBlock) { }

	// RVA: 0x7013B2C
	private object CreateWrappedWriter(object outMethod) { }

}

// Namespace: System.Xml
internal class XmlEncodedRawTextWriter
{

	// Fields
	private readonly object useAsync; // 0x20
	protected object bufBytes; // 0x28
	protected object stream; // 0x30
	protected object encoding; // 0x38
	protected object xmlCharType; // 0x40
	protected object bufPos; // 0x48
	protected object textPos; // 0x4C
	protected object contentPos; // 0x50
	protected object cdataPos; // 0x54
	protected object attrEndPos; // 0x58
	protected object bufLen; // 0x5C
	protected object writeToNull; // 0x60
	protected object hadDoubleBracket; // 0x61
	protected object inAttributeValue; // 0x62
	protected object bufBytesUsed; // 0x64
	protected object bufChars; // 0x68
	protected object encoder; // 0x70
	protected object writer; // 0x78
	protected object trackTextContent; // 0x80
	protected object inTextContent; // 0x81
	private object lastMarkPos; // 0x84
	private object textContentMarks; // 0x88
	private object charEntityFallback; // 0x90
	protected object newLineHandling; // 0x98
	protected object closeOutput; // 0x9C
	protected object omitXmlDeclaration; // 0x9D
	protected object newLineChars; // 0xA0
	protected object checkCharacters; // 0xA8
	protected object standalone; // 0xAC
	protected object outputMethod; // 0xB0
	protected object autoXmlDeclaration; // 0xB4
	protected object mergeCDataSections; // 0xB5

	// Properties
	internal override object SupportsNamespaceDeclarationInChunks { get; }

	// Methods

	// RVA: 0x7015478
	protected object .ctor(object settings) { }

	// RVA: 0x700F100
	public object .ctor(object writer, object settings) { }

	// RVA: 0x700F24C
	public object .ctor(object stream, object settings) { }

	// RVA: 0x70158B8
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x7015C60
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x7015D00
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x7016010
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x7016130
	internal override object StartElementContent() { }

	// RVA: 0x7016180
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x7016368
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x70164D0
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x7016650
	public override object WriteEndAttribute() { }

	// RVA: 0x70166D4
	internal override object WriteNamespaceDeclaration(object prefix, object namespaceName) { }

	// RVA: 0x701677C
	internal override object get_SupportsNamespaceDeclarationInChunks() { }

	// RVA: 0x7016784
	internal override object WriteStartNamespaceDeclaration(object prefix) { }

	// RVA: 0x7016934
	internal override object WriteEndNamespaceDeclaration() { }

	// RVA: 0x70169B8
	public override object WriteCData(object text) { }

	// RVA: 0x7016F9C
	public override object WriteComment(object text) { }

	// RVA: 0x70174F8
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x701767C
	public override object WriteEntityRef(object name) { }

	// RVA: 0x7017790
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x70179A8
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x7018080
	public override object WriteString(object text) { }

	// RVA: 0x7018100
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x7018288
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x700F8E8
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x700F6B8
	public override object WriteRaw(object data) { }

	// RVA: 0x701860C
	public override object Close() { }

	// RVA: 0x7018904
	public override object Flush() { }

	// RVA: 0x70189BC
	protected virtual object FlushBuffer() { }

	// RVA: 0x7018D28
	private object EncodeChars(object startOffset, object endOffset, object writeAllToStream) { }

	// RVA: 0x70186B0
	private object FlushEncoder() { }

	// RVA: 0x7017A2C
	protected object WriteAttributeTextBlock(object pSrc, object pSrcEnd) { }

	// RVA: 0x7017D34
	protected object WriteElementTextBlock(object pSrc, object pSrcEnd) { }

	// RVA: 0x7015C18
	protected object RawText(object s) { }

	// RVA: 0x7019400
	protected object RawText(object pSrcBegin, object pSrcEnd) { }

	// RVA: 0x701832C
	protected object WriteRawWithCharChecking(object pSrcBegin, object pSrcEnd) { }

	// RVA: 0x70170D4
	protected object WriteCommentOrPi(object text, object stopChar) { }

	// RVA: 0x7016B94
	protected object WriteCDataSection(object text) { }

	// RVA: 0x70190D8
	private static object EncodeSurrogate(object pSrc, object pSrcEnd, object pDst) { }

	// RVA: 0x7019234
	private object InvalidXmlChar(object ch, object pDst, object entitize) { }

	// RVA: 0x70196AC
	internal object EncodeChar(object pSrc, object pSrcEnd, object pDst) { }

	// RVA: 0x7015B14
	protected object ChangeTextContentMark(object value) { }

	// RVA: 0x7019788
	private object GrowTextContentMarks() { }

	// RVA: 0x7019364
	protected object WriteNewLine(object pDst) { }

	// RVA: 0x7019014
	protected static object LtEntity(object pDst) { }

	// RVA: 0x701902C
	protected static object GtEntity(object pDst) { }

	// RVA: 0x7018FF0
	protected static object AmpEntity(object pDst) { }

	// RVA: 0x7019044
	protected static object QuoteEntity(object pDst) { }

	// RVA: 0x701906C
	protected static object TabEntity(object pDst) { }

	// RVA: 0x70190B4
	protected static object LineFeedEntity(object pDst) { }

	// RVA: 0x7019090
	protected static object CarriageReturnEntity(object pDst) { }

	// RVA: 0x70195F0
	private static object CharEntity(object pDst, object ch) { }

	// RVA: 0x70195BC
	protected static object RawStartCData(object pDst) { }

	// RVA: 0x70195A0
	protected static object RawEndCData(object pDst) { }

	// RVA: 0x701556C
	protected object ValidateContentChars(object chars, object propertyName, object allowOnlyWhitespace) { }

}

// Namespace: System.Xml
internal class XmlEncodedRawTextWriterIndent
{

	// Fields
	protected object indentLevel; // 0xB8
	protected object newLineOnAttributes; // 0xBC
	protected object indentChars; // 0xC0
	protected object mixedContent; // 0xC8
	private object mixedContentStack; // 0xD0
	protected object conformanceLevel; // 0xD8

	// Methods

	// RVA: 0x701981C
	public object .ctor(object writer, object settings) { }

	// RVA: 0x701995C
	public object .ctor(object stream, object settings) { }

	// RVA: 0x7019988
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x7019A84
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x7019B08
	internal override object StartElementContent() { }

	// RVA: 0x7019BA4
	internal override object OnRootElement(object currentConformanceLevel) { }

	// RVA: 0x7019BAC
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x7019C3C
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x7019CCC
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x7019D14
	public override object WriteCData(object text) { }

	// RVA: 0x7019D20
	public override object WriteComment(object text) { }

	// RVA: 0x7019D60
	public override object WriteProcessingInstruction(object target, object text) { }

	// RVA: 0x7019DB0
	public override object WriteEntityRef(object name) { }

	// RVA: 0x7019DBC
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x7019DC8
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x7019DD4
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x7019E60
	public override object WriteString(object text) { }

	// RVA: 0x7019EE8
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x7019F94
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x701A038
	public override object WriteRaw(object data) { }

	// RVA: 0x701A0B8
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x7019848
	private object Init(object settings) { }

	// RVA: 0x70199F0
	private object WriteIndent() { }

}

// Namespace: 
private enum XmlEventType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object DocType;
	public const object StartElem;
	public const object StartAttr;
	public const object EndAttr;
	public const object CData;
	public const object Comment;
	public const object PI;
	public const object Whitespace;
	public const object String;
	public const object Raw;
	public const object EntRef;
	public const object CharEnt;
	public const object SurrCharEnt;
	public const object Base64;
	public const object BinHex;
	public const object XmlDecl1;
	public const object XmlDecl2;
	public const object StartContent;
	public const object EndElem;
	public const object FullEndElem;
	public const object Nmsp;
	public const object EndBase64;
	public const object Close;
	public const object Flush;
	public const object Dispose;
}

// Namespace: 
private struct XmlEvent
{

	// Fields
	private object eventType; // 0xFFFFFFFFFFFFFFF8
	private object s1; // 0x0
	private object s2; // 0x8
	private object s3; // 0x10
	private object o; // 0x18

	// Properties
	public object EventType { get; }
	public object String1 { get; }
	public object String2 { get; }
	public object String3 { get; }
	public object Object { get; }

	// Methods

	// RVA: 0x701B83C
	public object InitEvent(object eventType) { }

	// RVA: 0x701B610
	public object InitEvent(object eventType, object s1) { }

	// RVA: 0x701B61C
	public object InitEvent(object eventType, object s1, object s2) { }

	// RVA: 0x701B628
	public object InitEvent(object eventType, object s1, object s2, object s3) { }

	// RVA: 0x701B638
	public object InitEvent(object eventType, object s1, object s2, object s3, object o) { }

	// RVA: 0x701B648
	public object InitEvent(object eventType, object o) { }

	// RVA: 0x701B890
	public object get_EventType() { }

	// RVA: 0x701B8A0
	public object get_String1() { }

	// RVA: 0x701B8B0
	public object get_String2() { }

	// RVA: 0x701B8C0
	public object get_String3() { }

	// RVA: 0x701B8D0
	public object get_Object() { }

}

// Namespace: System.Xml
internal sealed class XmlEventCache
{

	// Fields
	private object pages; // 0x20
	private object pageCurr; // 0x28
	private object pageSize; // 0x30
	private object hasRootNode; // 0x34
	private object singleText; // 0x38
	private object baseUri; // 0x70

	// Methods

	// RVA: 0x7013834
	public object .ctor(object baseUri, object hasRootNode) { }

	// RVA: 0x70149B4
	public object EndEvents() { }

	// RVA: 0x7014A18
	public object EventsToWriter(object writer) { }

	// RVA: 0x701A260
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x701A358
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x701A440
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x701A4B0
	public override object WriteEndAttribute() { }

	// RVA: 0x701A504
	public override object WriteCData(object text) { }

	// RVA: 0x701A5C4
	public override object WriteComment(object text) { }

	// RVA: 0x701A620
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x701A6F0
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x701A74C
	public override object WriteString(object text) { }

	// RVA: 0x701A7C8
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x701A81C
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x701A870
	public override object WriteRaw(object data) { }

	// RVA: 0x701A8CC
	public override object WriteEntityRef(object name) { }

	// RVA: 0x701A928
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x701AA38
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x701AB00
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x701ACE0
	public override object WriteBinHex(object buffer, object index, object count) { }

	// RVA: 0x701ADF4
	public override object Close() { }

	// RVA: 0x701AE48
	public override object Flush() { }

	// RVA: 0x701AE9C
	public override object WriteValue(object value) { }

	// RVA: 0x701AEE8
	protected override object Dispose(object disposing) { }

	// RVA: 0x701B03C
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x701B0E8
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x701B144
	internal override object StartElementContent() { }

	// RVA: 0x701B198
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x701B208
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x701B278
	internal override object WriteNamespaceDeclaration(object prefix, object ns) { }

	// RVA: 0x701B2E0
	internal override object WriteEndBase64() { }

	// RVA: 0x701A20C
	private object AddEvent(object eventType) { }

	// RVA: 0x701A560
	private object AddEvent(object eventType, object s1) { }

	// RVA: 0x701A688
	private object AddEvent(object eventType, object s1, object s2) { }

	// RVA: 0x701A3C8
	private object AddEvent(object eventType, object s1, object s2, object s3) { }

	// RVA: 0x701A2DC
	private object AddEvent(object eventType, object s1, object s2, object s3, object o) { }

	// RVA: 0x701A9D4
	private object AddEvent(object eventType, object o) { }

	// RVA: 0x701B334
	private object NewEvent() { }

	// RVA: 0x701AC14
	private static object ToBytes(object buffer, object index, object count) { }

}

// Namespace: System.Xml
public class XmlParserContext
{

	// Fields
	private object _nt; // 0x8
	private object _nsMgr; // 0x10
	private object _docTypeName; // 0x18
	private object _pubId; // 0x20
	private object _sysId; // 0x28
	private object _internalSubset; // 0x30
	private object _xmlLang; // 0x38
	private object _xmlSpace; // 0x40
	private object _baseURI; // 0x48
	private object _encoding; // 0x50

	// Properties
	public object NameTable { get; }
	public object NamespaceManager { get; }
	public object DocTypeName { get; }
	public object PublicId { get; }
	public object SystemId { get; }
	public object BaseURI { get; }
	public object InternalSubset { get; }
	public object XmlLang { get; }
	public object XmlSpace { get; }
	public object Encoding { get; }
	internal object HasDtdInfo { get; }

	// Methods

	// RVA: 0x701B8E0
	public object .ctor(object nt, object nsMgr, object xmlLang, object xmlSpace) { }

	// RVA: 0x701B990
	public object .ctor(object nt, object nsMgr, object docTypeName, object pubId, object sysId, object internalSubset, object baseURI, object xmlLang, object xmlSpace) { }

	// RVA: 0x701B9C0
	public object .ctor(object nt, object nsMgr, object docTypeName, object pubId, object sysId, object internalSubset, object baseURI, object xmlLang, object xmlSpace, object enc) { }

	// RVA: 0x701BBE4
	public object get_NameTable() { }

	// RVA: 0x701BBEC
	public object get_NamespaceManager() { }

	// RVA: 0x701BBF4
	public object get_DocTypeName() { }

	// RVA: 0x701BBFC
	public object get_PublicId() { }

	// RVA: 0x701BC04
	public object get_SystemId() { }

	// RVA: 0x701BC0C
	public object get_BaseURI() { }

	// RVA: 0x701BC14
	public object get_InternalSubset() { }

	// RVA: 0x701BC1C
	public object get_XmlLang() { }

	// RVA: 0x701BC24
	public object get_XmlSpace() { }

	// RVA: 0x701BC2C
	public object get_Encoding() { }

	// RVA: 0x701BC34
	internal object get_HasDtdInfo() { }

}

// Namespace: System.Xml
internal abstract class XmlRawWriter
{

	// Fields
	protected object base64Encoder; // 0x10
	protected object resolver; // 0x18

	// Properties
	public override object WriteState { get; }
	internal virtual object NamespaceResolver { set; }
	internal virtual object SupportsNamespaceDeclarationInChunks { get; }

	// Methods

	// RVA: 0x701BCE0
	public override object WriteStartDocument() { }

	// RVA: 0x701BD3C
	public override object WriteStartDocument(object standalone) { }

	// RVA: 0x701BD98
	public override object WriteEndDocument() { }

	// RVA: 0x701BDF4
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x701BDF8
	public override object WriteEndElement() { }

	// RVA: 0x701BE54
	public override object WriteFullEndElement() { }

	// RVA: 0x701A164
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x701BEB0
	public override object LookupPrefix(object ns) { }

	// RVA: 0x701BF0C
	public override object get_WriteState() { }

	// RVA: 0x701BF68
	public override object WriteCData(object text) { }

	// RVA: 0x701BFB4
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x701C06C
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x701C13C
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x701C188
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x701C1DC
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x701C230
	public override object WriteRaw(object data) { }

	// RVA: 0x701C27C
	public override object WriteValue(object value) { }

	// RVA: 0x701C2C8
	public override object WriteAttributes(object reader, object defattr) { }

	// RVA: 0x701C324
	public override object WriteNode(object reader, object defattr) { }

	// RVA: 0x701C380
	internal virtual object set_NamespaceResolver(object value) { }

	// RVA: 0x701C388
	internal virtual object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x701C38C
	internal virtual object WriteXmlDeclaration(object xmldecl) { }

	// RVA: -1
	internal abstract object StartElementContent() { }

	// RVA: 0x701C390
	internal virtual object OnRootElement(object conformanceLevel) { }

	// RVA: -1
	internal abstract object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x701C394
	internal virtual object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: -1
	internal abstract object WriteNamespaceDeclaration(object prefix, object ns) { }

	// RVA: 0x701C3F8
	internal virtual object get_SupportsNamespaceDeclarationInChunks() { }

	// RVA: 0x701C400
	internal virtual object WriteStartNamespaceDeclaration(object prefix) { }

	// RVA: 0x701C440
	internal virtual object WriteEndNamespaceDeclaration() { }

	// RVA: 0x701C480
	internal virtual object WriteEndBase64() { }

	// RVA: 0x701C4A4
	internal virtual object Close(object currentState) { }

	// RVA: 0x700D5A4
	protected object .ctor() { }

}

// Namespace: System.Xml
public abstract class XmlReader
{

	// Fields
	private static object IsTextualNodeBitmap; // 0x0
	private static object CanReadContentAsBitmap; // 0x4
	private static object HasValueBitmap; // 0x8

	// Properties
	public virtual object Settings { get; }
	public abstract object NodeType { get; }
	public virtual object Name { get; }
	public abstract object LocalName { get; }
	public abstract object NamespaceURI { get; }
	public abstract object Prefix { get; }
	public abstract object Value { get; }
	public abstract object Depth { get; }
	public abstract object BaseURI { get; }
	public abstract object IsEmptyElement { get; }
	public virtual object IsDefault { get; }
	public virtual object QuoteChar { get; }
	public virtual object XmlSpace { get; }
	public virtual object XmlLang { get; }
	public virtual object SchemaInfo { get; }
	public virtual object ValueType { get; }
	public abstract object AttributeCount { get; }
	public abstract object EOF { get; }
	public abstract object ReadState { get; }
	public abstract object NameTable { get; }
	public virtual object CanResolveEntity { get; }
	public virtual object CanReadValueChunk { get; }
	public virtual object HasAttributes { get; }
	internal virtual object NamespaceManager { get; }
	internal object IsDefaultInternal { get; }
	internal virtual object DtdInfo { get; }

	// Methods

	// RVA: 0x701C4E8
	public virtual object get_Settings() { }

	// RVA: -1
	public abstract object get_NodeType() { }

	// RVA: 0x701C4F0
	public virtual object get_Name() { }

	// RVA: -1
	public abstract object get_LocalName() { }

	// RVA: -1
	public abstract object get_NamespaceURI() { }

	// RVA: -1
	public abstract object get_Prefix() { }

	// RVA: -1
	public abstract object get_Value() { }

	// RVA: -1
	public abstract object get_Depth() { }

	// RVA: -1
	public abstract object get_BaseURI() { }

	// RVA: -1
	public abstract object get_IsEmptyElement() { }

	// RVA: 0x701C660
	public virtual object get_IsDefault() { }

	// RVA: 0x701C668
	public virtual object get_QuoteChar() { }

	// RVA: 0x701C670
	public virtual object get_XmlSpace() { }

	// RVA: 0x701C678
	public virtual object get_XmlLang() { }

	// RVA: 0x701C6C4
	public virtual object get_SchemaInfo() { }

	// RVA: 0x701C71C
	public virtual object get_ValueType() { }

	// RVA: -1
	public abstract object get_AttributeCount() { }

	// RVA: -1
	public abstract object GetAttribute(object name) { }

	// RVA: -1
	public abstract object GetAttribute(object name, object namespaceURI) { }

	// RVA: -1
	public abstract object GetAttribute(object i) { }

	// RVA: -1
	public abstract object MoveToAttribute(object name) { }

	// RVA: 0x701C7BC
	public virtual object MoveToAttribute(object i) { }

	// RVA: -1
	public abstract object MoveToFirstAttribute() { }

	// RVA: -1
	public abstract object MoveToNextAttribute() { }

	// RVA: -1
	public abstract object MoveToElement() { }

	// RVA: -1
	public abstract object ReadAttributeValue() { }

	// RVA: -1
	public abstract object Read() { }

	// RVA: -1
	public abstract object get_EOF() { }

	// RVA: 0x701C8E0
	public virtual object Close() { }

	// RVA: -1
	public abstract object get_ReadState() { }

	// RVA: 0x701C8E4
	public virtual object Skip() { }

	// RVA: -1
	public abstract object get_NameTable() { }

	// RVA: -1
	public abstract object LookupNamespace(object prefix) { }

	// RVA: 0x701CAC4
	public virtual object get_CanResolveEntity() { }

	// RVA: -1
	public abstract object ResolveEntity() { }

	// RVA: 0x701CACC
	public virtual object get_CanReadValueChunk() { }

	// RVA: 0x701CAD4
	public virtual object ReadValueChunk(object buffer, object index, object count) { }

	// RVA: 0x701CB30
	public virtual object ReadString() { }

	// RVA: 0x701CE88
	public virtual object MoveToContent() { }

	// RVA: 0x701CF68
	public virtual object ReadStartElement() { }

	// RVA: 0x701D094
	public virtual object ReadElementString() { }

	// RVA: 0x701D3C4
	public virtual object ReadEndElement() { }

	// RVA: 0x701D4F0
	public virtual object IsStartElement(object localname, object ns) { }

	// RVA: 0x701D5C0
	public virtual object ReadInnerXml() { }

	// RVA: 0x701DB94
	private object WriteNode(object xtw, object defattr) { }

	// RVA: 0x701DA0C
	private object WriteAttributeValue(object xtw) { }

	// RVA: 0x701D994
	private object CreateWriterForInnerOuterXml(object sw) { }

	// RVA: 0x701E3B8
	private object SetNamespacesFlag(object xtw) { }

	// RVA: 0x701E4F8
	public virtual object get_HasAttributes() { }

	// RVA: 0x7011BC8
	public object Dispose() { }

	// RVA: 0x701E548
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x701E5C8
	internal virtual object get_NamespaceManager() { }

	// RVA: 0x701CE18
	internal static object IsTextualNode(object nodeType) { }

	// RVA: 0x701E5D0
	internal static object HasValueInternal(object nodeType) { }

	// RVA: 0x701C940
	private object SkipSubtree() { }

	// RVA: 0x701E640
	internal object get_IsDefaultInternal() { }

	// RVA: 0x701E798
	internal virtual object get_DtdInfo() { }

	// RVA: 0x701E7A0
	public static object Create(object input, object settings, object baseUri) { }

	// RVA: 0x701EA90
	public static object Create(object input, object settings, object baseUri) { }

	// RVA: 0x701ECC4
	internal static object CreateSqlReader(object input, object settings, object inputContext) { }

	// RVA: 0x701F0C8
	internal static object CalcBufferSize(object input) { }

	// RVA: 0x7010808
	protected object .ctor() { }

	// RVA: 0x701F2E8
	private static object .cctor() { }

}

// Namespace: System.Xml
public sealed class XmlReaderSettings
{

	// Fields
	private object useAsync; // 0x8
	private object nameTable; // 0x10
	private object xmlResolver; // 0x18
	private object lineNumberOffset; // 0x20
	private object linePositionOffset; // 0x24
	private object conformanceLevel; // 0x28
	private object checkCharacters; // 0x2C
	private object maxCharactersInDocument; // 0x30
	private object maxCharactersFromEntities; // 0x38
	private object ignoreWhitespace; // 0x40
	private object ignorePIs; // 0x41
	private object ignoreComments; // 0x42
	private object dtdProcessing; // 0x44
	private object validationType; // 0x48
	private object validationFlags; // 0x4C
	private object schemas; // 0x50
	private object valEventHandler; // 0x58
	private object closeInput; // 0x60
	private object isReadOnly; // 0x61
	private object <IsXmlResolverSet>k__BackingField; // 0x62
	private static object s_enableLegacyXmlSettings; // 0x0

	// Properties
	public object Async { get; set; }
	public object NameTable { get; set; }
	internal object IsXmlResolverSet { get; set; }
	public object XmlResolver { set; }
	public object LineNumberOffset { get; set; }
	public object LinePositionOffset { get; set; }
	public object ConformanceLevel { get; set; }
	public object CheckCharacters { get; set; }
	public object MaxCharactersInDocument { get; set; }
	public object MaxCharactersFromEntities { get; set; }
	public object IgnoreWhitespace { get; set; }
	public object IgnoreProcessingInstructions { get; set; }
	public object IgnoreComments { get; set; }
	public object DtdProcessing { get; set; }
	public object CloseInput { get; set; }
	public object ValidationType { get; set; }
	public object ValidationFlags { get; set; }
	public object Schemas { get; set; }
	internal object ReadOnly { set; }

	// Methods

	// RVA: 0x7010AE4
	public object .ctor() { }

	// RVA: 0x701F3EC
	public object get_Async() { }

	// RVA: 0x7010B90
	public object set_Async(object value) { }

	// RVA: 0x701F4AC
	public object get_NameTable() { }

	// RVA: 0x701F4B4
	public object set_NameTable(object value) { }

	// RVA: 0x701F514
	internal object get_IsXmlResolverSet() { }

	// RVA: 0x701F51C
	internal object set_IsXmlResolverSet(object value) { }

	// RVA: 0x701F524
	public object set_XmlResolver(object value) { }

	// RVA: 0x701F58C
	internal object GetXmlResolver() { }

	// RVA: 0x701F594
	internal object GetXmlResolver_CheckConfig() { }

	// RVA: 0x701F5DC
	public object get_LineNumberOffset() { }

	// RVA: 0x701F5E4
	public object set_LineNumberOffset(object value) { }

	// RVA: 0x701F644
	public object get_LinePositionOffset() { }

	// RVA: 0x701F64C
	public object set_LinePositionOffset(object value) { }

	// RVA: 0x701F6AC
	public object get_ConformanceLevel() { }

	// RVA: 0x701F6B4
	public object set_ConformanceLevel(object value) { }

	// RVA: 0x701F764
	public object get_CheckCharacters() { }

	// RVA: 0x701F76C
	public object set_CheckCharacters(object value) { }

	// RVA: 0x701F7CC
	public object get_MaxCharactersInDocument() { }

	// RVA: 0x701F7D4
	public object set_MaxCharactersInDocument(object value) { }

	// RVA: 0x701F880
	public object get_MaxCharactersFromEntities() { }

	// RVA: 0x701F888
	public object set_MaxCharactersFromEntities(object value) { }

	// RVA: 0x701F934
	public object get_IgnoreWhitespace() { }

	// RVA: 0x701F93C
	public object set_IgnoreWhitespace(object value) { }

	// RVA: 0x701F99C
	public object get_IgnoreProcessingInstructions() { }

	// RVA: 0x701F9A4
	public object set_IgnoreProcessingInstructions(object value) { }

	// RVA: 0x701FA04
	public object get_IgnoreComments() { }

	// RVA: 0x701FA0C
	public object set_IgnoreComments(object value) { }

	// RVA: 0x701FA6C
	public object get_DtdProcessing() { }

	// RVA: 0x701FA74
	public object set_DtdProcessing(object value) { }

	// RVA: 0x701FB24
	public object get_CloseInput() { }

	// RVA: 0x701FB2C
	public object set_CloseInput(object value) { }

	// RVA: 0x701FB8C
	public object get_ValidationType() { }

	// RVA: 0x701FB94
	public object set_ValidationType(object value) { }

	// RVA: 0x701FC44
	public object get_ValidationFlags() { }

	// RVA: 0x701FC4C
	public object set_ValidationFlags(object value) { }

	// RVA: 0x701FCFC
	public object get_Schemas() { }

	// RVA: 0x701FD78
	public object set_Schemas(object value) { }

	// RVA: 0x7010A6C
	public object Clone() { }

	// RVA: 0x701FDD8
	internal object GetEventHandler() { }

	// RVA: 0x701E8A8
	internal object CreateReader(object input, object baseUri, object baseUriString, object inputContext) { }

	// RVA: 0x701EB94
	internal object CreateReader(object input, object baseUriString, object inputContext) { }

	// RVA: 0x701FDE0
	internal object set_ReadOnly(object value) { }

	// RVA: 0x701F3F4
	private object CheckReadOnly(object propertyName) { }

	// RVA: 0x701F348
	private object Initialize() { }

	// RVA: 0x701FDE8
	private object Initialize(object resolver) { }

	// RVA: 0x701FE94
	private static object CreateDefaultResolver() { }

	// RVA: 0x701F188
	internal object AddValidation(object reader) { }

	// RVA: 0x701FFFC
	private object CreateDtdValidatingReader(object baseReader) { }

	// RVA: 0x701FEEC
	internal static object EnableLegacyXmlSettings() { }

}

// Namespace: System.Xml
public enum XmlSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Default;
	public const object Preserve;
}

// Namespace: System.Xml
internal class XmlTextEncoder
{

	// Fields
	private object textWriter; // 0x8
	private object inAttribute; // 0x10
	private object quoteChar; // 0x12
	private object attrValue; // 0x18
	private object cacheAttrValue; // 0x20
	private object xmlCharType; // 0x28

	// Properties
	internal object QuoteChar { set; }
	internal object AttributeValue { get; }

	// Methods

	// RVA: 0x7020080
	internal object .ctor(object textWriter) { }

	// RVA: 0x70200C0
	internal object set_QuoteChar(object value) { }

	// RVA: 0x70200C8
	internal object StartAttribute(object cacheAttrValue) { }

	// RVA: 0x7020160
	internal object EndAttribute() { }

	// RVA: 0x70201B0
	internal object get_AttributeValue() { }

	// RVA: 0x702024C
	internal object WriteSurrogateChar(object lowChar, object highChar) { }

	// RVA: 0x7020350
	internal object Write(object array, object offset, object count) { }

	// RVA: 0x7020AA0
	internal object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x7020CB0
	internal object Write(object text) { }

	// RVA: 0x702136C
	internal object WriteRawWithSurrogateChecking(object text) { }

	// RVA: 0x7021590
	internal object WriteRaw(object array, object offset, object count) { }

	// RVA: 0x7021704
	internal object WriteCharEntity(object ch) { }

	// RVA: 0x702197C
	internal object WriteEntityRef(object name) { }

	// RVA: 0x7021278
	private object WriteStringFragment(object str, object offset, object count, object helperBuffer) { }

	// RVA: 0x7020938
	private object WriteCharEntityImpl(object ch) { }

	// RVA: 0x702186C
	private object WriteCharEntityImpl(object strVal) { }

	// RVA: 0x70209BC
	private object WriteEntityRefImpl(object name) { }

}

// Namespace: System.Xml
public class XmlTextReader
{

	// Fields
	private object impl; // 0x8

	// Properties
	public override object NodeType { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object IsDefault { get; }
	public override object QuoteChar { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object AttributeCount { get; }
	public override object EOF { get; }
	public override object ReadState { get; }
	public override object NameTable { get; }
	public override object CanResolveEntity { get; }
	public override object CanReadValueChunk { get; }
	public object LineNumber { get; }
	public object LinePosition { get; }
	public object Namespaces { get; }
	public object Normalization { get; set; }
	public object WhitespaceHandling { set; }
	public object EntityHandling { set; }
	public object XmlResolver { set; }
	internal object Impl { get; }
	internal override object NamespaceManager { get; }
	internal object XmlValidatingReaderCompatibilityMode { set; }
	internal override object DtdInfo { get; }

	// Methods

	// RVA: 0x7021A10
	public object .ctor(object input) { }

	// RVA: 0x7021AC0
	public object .ctor(object input, object nt) { }

	// RVA: 0x7021B80
	public object .ctor(object url, object input, object nt) { }

	// RVA: 0x7021C48
	public object .ctor(object input) { }

	// RVA: 0x7021CF8
	public object .ctor(object input, object nt) { }

	// RVA: 0x7021DB8
	public override object get_NodeType() { }

	// RVA: 0x7021E04
	public override object get_Name() { }

	// RVA: 0x7021E50
	public override object get_LocalName() { }

	// RVA: 0x7021E9C
	public override object get_NamespaceURI() { }

	// RVA: 0x7021EE8
	public override object get_Prefix() { }

	// RVA: 0x7021F34
	public override object get_Value() { }

	// RVA: 0x7021F80
	public override object get_Depth() { }

	// RVA: 0x7021FCC
	public override object get_BaseURI() { }

	// RVA: 0x702201C
	public override object get_IsEmptyElement() { }

	// RVA: 0x702206C
	public override object get_IsDefault() { }

	// RVA: 0x70220BC
	public override object get_QuoteChar() { }

	// RVA: 0x702210C
	public override object get_XmlSpace() { }

	// RVA: 0x702215C
	public override object get_XmlLang() { }

	// RVA: 0x70221AC
	public override object get_AttributeCount() { }

	// RVA: 0x70221FC
	public override object GetAttribute(object name) { }

	// RVA: 0x7022254
	public override object GetAttribute(object localName, object namespaceURI) { }

	// RVA: 0x70222BC
	public override object GetAttribute(object i) { }

	// RVA: 0x7022314
	public override object MoveToAttribute(object name) { }

	// RVA: 0x702236C
	public override object MoveToAttribute(object i) { }

	// RVA: 0x70223C4
	public override object MoveToFirstAttribute() { }

	// RVA: 0x7022414
	public override object MoveToNextAttribute() { }

	// RVA: 0x7022464
	public override object MoveToElement() { }

	// RVA: 0x70224B4
	public override object ReadAttributeValue() { }

	// RVA: 0x7022504
	public override object Read() { }

	// RVA: 0x7022554
	public override object get_EOF() { }

	// RVA: 0x70225A4
	public override object Close() { }

	// RVA: 0x70225F4
	public override object get_ReadState() { }

	// RVA: 0x7022644
	public override object Skip() { }

	// RVA: 0x7022694
	public override object get_NameTable() { }

	// RVA: 0x70226E4
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x7022750
	public override object get_CanResolveEntity() { }

	// RVA: 0x7022758
	public override object ResolveEntity() { }

	// RVA: 0x70227A8
	public override object get_CanReadValueChunk() { }

	// RVA: 0x70227B0
	public override object ReadString() { }

	// RVA: 0x70227EC
	public object HasLineInfo() { }

	// RVA: 0x70227F4
	public object get_LineNumber() { }

	// RVA: 0x7022818
	public object get_LinePosition() { }

	// RVA: 0x702283C
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x7022860
	private object System.Xml.IXmlNamespaceResolver.LookupNamespace(object prefix) { }

	// RVA: 0x70228B8
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

	// RVA: 0x701E4D4
	public object get_Namespaces() { }

	// RVA: 0x70228DC
	public object get_Normalization() { }

	// RVA: 0x7022900
	public object set_Normalization(object value) { }

	// RVA: 0x7022924
	public object set_WhitespaceHandling(object value) { }

	// RVA: 0x7022948
	public object set_EntityHandling(object value) { }

	// RVA: 0x702296C
	public object set_XmlResolver(object value) { }

	// RVA: 0x7022990
	internal object get_Impl() { }

	// RVA: 0x7022998
	internal override object get_NamespaceManager() { }

	// RVA: 0x70229E8
	internal object set_XmlValidatingReaderCompatibilityMode(object value) { }

	// RVA: 0x7022A0C
	internal override object get_DtdInfo() { }

}

// Namespace: 
private enum ParsingFunction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ElementContent;
	public const object NoData;
	public const object OpenUrl;
	public const object SwitchToInteractive;
	public const object SwitchToInteractiveXmlDecl;
	public const object DocumentContent;
	public const object MoveToElementContent;
	public const object PopElementContext;
	public const object PopEmptyElementContext;
	public const object ResetAttributesRootLevel;
	public const object Error;
	public const object Eof;
	public const object ReaderClosed;
	public const object EntityReference;
	public const object InIncrementalRead;
	public const object FragmentAttribute;
	public const object ReportEndEntity;
	public const object AfterResolveEntityInContent;
	public const object AfterResolveEmptyEntityInContent;
	public const object XmlDeclarationFragment;
	public const object GoToEof;
	public const object PartialTextValue;
	public const object InReadAttributeValue;
	public const object InReadValueChunk;
	public const object InReadContentAsBinary;
	public const object InReadElementContentAsBinary;
}

// Namespace: 
private enum ParsingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Full;
	public const object SkipNode;
	public const object SkipContent;
}

// Namespace: 
private enum EntityType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CharacterDec;
	public const object CharacterHex;
	public const object CharacterNamed;
	public const object Expanded;
	public const object Skipped;
	public const object FakeExpanded;
	public const object Unexpanded;
	public const object ExpandedInAttribute;
}

// Namespace: 
private enum EntityExpandType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object All;
	public const object OnlyGeneral;
	public const object OnlyCharacter;
}

// Namespace: 
private enum IncrementalReadState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Text;
	public const object StartTag;
	public const object PI;
	public const object CDATA;
	public const object Comment;
	public const object Attributes;
	public const object AttributeValue;
	public const object ReadData;
	public const object EndElement;
	public const object End;
	public const object ReadValueChunk_OnCachedValue;
	public const object ReadValueChunk_OnPartialValue;
	public const object ReadContentAsBinary_OnCachedValue;
	public const object ReadContentAsBinary_OnPartialValue;
	public const object ReadContentAsBinary_End;
}

// Namespace: 
private class LaterInitParam
{

	// Fields
	public object useAsync; // 0x8
	public object inputStream; // 0x10
	public object inputBytes; // 0x18
	public object inputByteCount; // 0x20
	public object inputbaseUri; // 0x28
	public object inputUriStr; // 0x30
	public object inputUriResolver; // 0x38
	public object inputContext; // 0x40
	public object inputTextReader; // 0x48
	public object initType; // 0x50

	// Methods

	// RVA: 0x7022A5C
	public object .ctor() { }

}

// Namespace: 
private enum InitInputType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UriString;
	public const object Stream;
	public const object TextReader;
	public const object Invalid;
}

// Namespace: 
private struct ParsingState
{

	// Fields
	internal object chars; // 0xFFFFFFFFFFFFFFF8
	internal object charPos; // 0x0
	internal object charsUsed; // 0x4
	internal object encoding; // 0x8
	internal object appendMode; // 0x10
	internal object stream; // 0x18
	internal object decoder; // 0x20
	internal object bytes; // 0x28
	internal object bytePos; // 0x30
	internal object bytesUsed; // 0x34
	internal object textReader; // 0x38
	internal object lineNo; // 0x40
	internal object lineStartPos; // 0x44
	internal object baseUriStr; // 0x48
	internal object baseUri; // 0x50
	internal object isEof; // 0x58
	internal object isStreamEof; // 0x59
	internal object entity; // 0x60
	internal object entityId; // 0x68
	internal object eolNormalized; // 0x6C
	internal object entityResolvedManually; // 0x6D

	// Properties
	internal object LineNo { get; }
	internal object LinePos { get; }

	// Methods

	// RVA: 0x7022AA8
	internal object Clear() { }

	// RVA: 0x7022BBC
	internal object Close(object closeInput) { }

	// RVA: 0x7022CCC
	internal object get_LineNo() { }

	// RVA: 0x7022CDC
	internal object get_LinePos() { }

}

// Namespace: 
private class XmlContext
{

	// Fields
	internal object xmlSpace; // 0x8
	internal object xmlLang; // 0x10
	internal object defaultNamespace; // 0x18
	internal object previousContext; // 0x20

	// Methods

	// RVA: 0x7022CFC
	internal object .ctor() { }

	// RVA: 0x7022D6C
	internal object .ctor(object previousContext) { }

}

// Namespace: 
private class NoNamespaceManager
{

	// Properties
	public override object DefaultNamespace { get; }

	// Methods

	// RVA: 0x7022DB8
	public object .ctor() { }

	// RVA: 0x7022DC0
	public override object get_DefaultNamespace() { }

	// RVA: 0x7022E0C
	public override object PushScope() { }

	// RVA: 0x7022E10
	public override object PopScope() { }

	// RVA: 0x7022E18
	public override object AddNamespace(object prefix, object uri) { }

	// RVA: 0x7022E1C
	public override object RemoveNamespace(object prefix, object uri) { }

	// RVA: 0x7022E20
	public override object GetEnumerator() { }

	// RVA: 0x7022E28
	public override object GetNamespacesInScope(object scope) { }

	// RVA: 0x7022E30
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x7022E7C
	public override object LookupPrefix(object uri) { }

}

// Namespace: 
internal class DtdParserProxy
{

	// Fields
	private object reader; // 0x8

	// Properties
	private object System.Xml.IDtdParserAdapter.NameTable { get; }
	private object System.Xml.IDtdParserAdapter.NamespaceResolver { get; }
	private object System.Xml.IDtdParserAdapter.BaseUri { get; }
	private object System.Xml.IDtdParserAdapter.IsEof { get; }
	private object System.Xml.IDtdParserAdapter.ParsingBuffer { get; }
	private object System.Xml.IDtdParserAdapter.ParsingBufferLength { get; }
	private object System.Xml.IDtdParserAdapter.CurrentPosition { get; set; }
	private object System.Xml.IDtdParserAdapter.EntityStackLength { get; }
	private object System.Xml.IDtdParserAdapter.IsEntityEolNormalized { get; }
	private object System.Xml.IDtdParserAdapter.LineNo { get; }
	private object System.Xml.IDtdParserAdapter.LineStartPosition { get; }
	private object System.Xml.IDtdParserAdapterWithValidation.DtdValidation { get; }
	private object System.Xml.IDtdParserAdapterWithValidation.ValidationEventHandling { get; }
	private object System.Xml.IDtdParserAdapterV1.Normalization { get; }
	private object System.Xml.IDtdParserAdapterV1.Namespaces { get; }
	private object System.Xml.IDtdParserAdapterV1.V1CompatibilityMode { get; }

	// Methods

	// RVA: 0x7022E84
	internal object .ctor(object reader) { }

	// RVA: 0x7022EB0
	private object System.Xml.IDtdParserAdapter.get_NameTable() { }

	// RVA: 0x7022ED4
	private object System.Xml.IDtdParserAdapter.get_NamespaceResolver() { }

	// RVA: 0x7022EF8
	private object System.Xml.IDtdParserAdapter.get_BaseUri() { }

	// RVA: 0x7022F1C
	private object System.Xml.IDtdParserAdapter.get_IsEof() { }

	// RVA: 0x7022F40
	private object System.Xml.IDtdParserAdapter.get_ParsingBuffer() { }

	// RVA: 0x7022F64
	private object System.Xml.IDtdParserAdapter.get_ParsingBufferLength() { }

	// RVA: 0x7022F88
	private object System.Xml.IDtdParserAdapter.get_CurrentPosition() { }

	// RVA: 0x7022FAC
	private object System.Xml.IDtdParserAdapter.set_CurrentPosition(object value) { }

	// RVA: 0x7022FD0
	private object System.Xml.IDtdParserAdapter.get_EntityStackLength() { }

	// RVA: 0x7022FF4
	private object System.Xml.IDtdParserAdapter.get_IsEntityEolNormalized() { }

	// RVA: 0x7023018
	private object System.Xml.IDtdParserAdapter.OnNewLine(object pos) { }

	// RVA: 0x702303C
	private object System.Xml.IDtdParserAdapter.get_LineNo() { }

	// RVA: 0x7023060
	private object System.Xml.IDtdParserAdapter.get_LineStartPosition() { }

	// RVA: 0x7023084
	private object System.Xml.IDtdParserAdapter.ReadData() { }

	// RVA: 0x70230A8
	private object System.Xml.IDtdParserAdapter.ParseNumericCharRef(object internalSubsetBuilder) { }

	// RVA: 0x70230CC
	private object System.Xml.IDtdParserAdapter.ParseNamedCharRef(object expand, object internalSubsetBuilder) { }

	// RVA: 0x70230F0
	private object System.Xml.IDtdParserAdapter.ParsePI(object sb) { }

	// RVA: 0x7023114
	private object System.Xml.IDtdParserAdapter.ParseComment(object sb) { }

	// RVA: 0x7023138
	private object System.Xml.IDtdParserAdapter.PushEntity(object entity, object entityId) { }

	// RVA: 0x702315C
	private object System.Xml.IDtdParserAdapter.PopEntity(object oldEntity, object newEntityId) { }

	// RVA: 0x7023180
	private object System.Xml.IDtdParserAdapter.PushExternalSubset(object systemId, object publicId) { }

	// RVA: 0x70231A4
	private object System.Xml.IDtdParserAdapter.PushInternalDtd(object baseUri, object internalDtd) { }

	// RVA: 0x70231C8
	private object System.Xml.IDtdParserAdapter.Throw(object e) { }

	// RVA: 0x70231EC
	private object System.Xml.IDtdParserAdapter.OnSystemId(object systemId, object keywordLineInfo, object systemLiteralLineInfo) { }

	// RVA: 0x7023210
	private object System.Xml.IDtdParserAdapter.OnPublicId(object publicId, object keywordLineInfo, object publicLiteralLineInfo) { }

	// RVA: 0x7023234
	private object System.Xml.IDtdParserAdapterWithValidation.get_DtdValidation() { }

	// RVA: 0x7023258
	private object System.Xml.IDtdParserAdapterWithValidation.get_ValidationEventHandling() { }

	// RVA: 0x702327C
	private object System.Xml.IDtdParserAdapterV1.get_Normalization() { }

	// RVA: 0x70232A0
	private object System.Xml.IDtdParserAdapterV1.get_Namespaces() { }

	// RVA: 0x70232C4
	private object System.Xml.IDtdParserAdapterV1.get_V1CompatibilityMode() { }

}

// Namespace: 
private class NodeData
{

	// Fields
	private static object s_None; // 0x0
	internal object type; // 0x8
	internal object localName; // 0x10
	internal object prefix; // 0x18
	internal object ns; // 0x20
	internal object nameWPrefix; // 0x28
	private object value; // 0x30
	private object chars; // 0x38
	private object valueStartPos; // 0x40
	private object valueLength; // 0x44
	internal object lineInfo; // 0x48
	internal object lineInfo2; // 0x50
	internal object quoteChar; // 0x58
	internal object depth; // 0x5C
	private object isEmptyOrDefault; // 0x60
	internal object entityId; // 0x64
	internal object xmlContextPushed; // 0x68
	internal object nextAttrValueChunk; // 0x70
	internal object schemaType; // 0x78
	internal object typedValue; // 0x80

	// Properties
	internal static object None { get; }
	internal object LineNo { get; }
	internal object LinePos { get; }
	internal object IsEmptyElement { get; set; }
	internal object IsDefaultAttribute { get; set; }
	internal object ValueBuffered { get; }
	internal object StringValue { get; }

	// Methods

	// RVA: 0x70232E8
	internal static object get_None() { }

	// RVA: 0x7023404
	internal object .ctor() { }

	// RVA: 0x702353C
	internal object get_LineNo() { }

	// RVA: 0x7023544
	internal object get_LinePos() { }

	// RVA: 0x702354C
	internal object get_IsEmptyElement() { }

	// RVA: 0x702356C
	internal object set_IsEmptyElement(object value) { }

	// RVA: 0x7023574
	internal object get_IsDefaultAttribute() { }

	// RVA: 0x7023594
	internal object set_IsDefaultAttribute(object value) { }

	// RVA: 0x702359C
	internal object get_ValueBuffered() { }

	// RVA: 0x70235AC
	internal object get_StringValue() { }

	// RVA: 0x70235F0
	internal object TrimSpacesInValue() { }

	// RVA: 0x70234A4
	internal object Clear(object type) { }

	// RVA: 0x702363C
	internal object ClearName() { }

	// RVA: 0x702369C
	internal object SetLineInfo(object lineNo, object linePos) { }

	// RVA: 0x70236A8
	internal object SetLineInfo2(object lineNo, object linePos) { }

	// RVA: 0x70236B4
	internal object SetValueNode(object type, object value) { }

	// RVA: 0x7023728
	internal object SetValueNode(object type, object chars, object startPos, object len) { }

	// RVA: 0x70237A8
	internal object SetNamedNode(object type, object localName) { }

	// RVA: 0x7023854
	internal object SetNamedNode(object type, object localName, object prefix, object nameWPrefix) { }

	// RVA: 0x70238E4
	internal object SetValue(object value) { }

	// RVA: 0x70238F4
	internal object SetValue(object chars, object startPos, object len) { }

	// RVA: 0x7023900
	internal object OnBufferInvalidated() { }

	// RVA: 0x7023958
	internal object CopyTo(object valueOffset, object sb) { }

	// RVA: 0x70239FC
	internal object CopyTo(object valueOffset, object buffer, object offset, object length) { }

	// RVA: 0x7023A74
	internal object GetNameWPrefix(object nt) { }

	// RVA: 0x7023A88
	internal object CreateNameWPrefix(object nt) { }

	// RVA: 0x7023B4C
	private object System.IComparable.CompareTo(object obj) { }

}

// Namespace: 
private class DtdDefaultAttributeInfoToNodeDataComparer
{

	// Fields
	private static object s_instance; // 0x0

	// Properties
	internal static object Instance { get; }

	// Methods

	// RVA: 0x7023DFC
	internal static object get_Instance() { }

	// RVA: 0x7023E78
	public object Compare(object x, object y) { }

	// RVA: 0x7024258
	public object .ctor() { }

	// RVA: 0x7024260
	private static object .cctor() { }

}

// Namespace: 
internal sealed class OnDefaultAttributeUseDelegate
{

	// Methods

	// RVA: 0x70245C4
	public object .ctor(object object, object method) { }

	// RVA: 0x70246D0
	public virtual object Invoke(object defaultAttribute, object coreReader) { }

}

// Namespace: System.Xml
internal class XmlTextReaderImpl
{

	// Fields
	private readonly object useAsync; // 0x8
	private object laterInitParam; // 0x10
	private object xmlCharType; // 0x18
	private object ps; // 0x20
	private object parsingFunction; // 0x98
	private object nextParsingFunction; // 0x9C
	private object nextNextParsingFunction; // 0xA0
	private object nodes; // 0xA8
	private object curNode; // 0xB0
	private object index; // 0xB8
	private object curAttrIndex; // 0xBC
	private object attrCount; // 0xC0
	private object attrHashtable; // 0xC4
	private object attrDuplWalkCount; // 0xC8
	private object attrNeedNamespaceLookup; // 0xCC
	private object fullAttrCleanup; // 0xCD
	private object attrDuplSortingArray; // 0xD0
	private object nameTable; // 0xD8
	private object nameTableFromSettings; // 0xE0
	private object xmlResolver; // 0xE8
	private object url; // 0xF0
	private object normalize; // 0xF8
	private object supportNamespaces; // 0xF9
	private object whitespaceHandling; // 0xFC
	private object dtdProcessing; // 0x100
	private object entityHandling; // 0x104
	private object ignorePIs; // 0x108
	private object ignoreComments; // 0x109
	private object checkCharacters; // 0x10A
	private object lineNumberOffset; // 0x10C
	private object linePositionOffset; // 0x110
	private object closeInput; // 0x114
	private object maxCharactersInDocument; // 0x118
	private object maxCharactersFromEntities; // 0x120
	private object v1Compat; // 0x128
	private object namespaceManager; // 0x130
	private object lastPrefix; // 0x138
	private object xmlContext; // 0x140
	private object parsingStatesStack; // 0x148
	private object parsingStatesStackTop; // 0x150
	private object reportedBaseUri; // 0x158
	private object reportedEncoding; // 0x160
	private object dtdInfo; // 0x168
	private object fragmentType; // 0x170
	private object fragmentParserContext; // 0x178
	private object fragment; // 0x180
	private object incReadDecoder; // 0x188
	private object incReadState; // 0x190
	private object incReadLineInfo; // 0x194
	private object incReadDepth; // 0x19C
	private object incReadLeftStartPos; // 0x1A0
	private object incReadLeftEndPos; // 0x1A4
	private object attributeValueBaseEntityId; // 0x1A8
	private object emptyEntityInAttributeResolved; // 0x1AC
	private object validationEventHandling; // 0x1B0
	private object onDefaultAttributeUse; // 0x1B8
	private object validatingReaderCompatFlag; // 0x1C0
	private object addDefaultAttributesAndNormalize; // 0x1C1
	private object stringBuilder; // 0x1C8
	private object rootElementParsed; // 0x1D0
	private object standalone; // 0x1D1
	private object nextEntityId; // 0x1D4
	private object parsingMode; // 0x1D8
	private object readState; // 0x1DC
	private object lastEntity; // 0x1E0
	private object afterResetState; // 0x1E8
	private object documentStartBytePos; // 0x1EC
	private object readValueOffset; // 0x1F0
	private object charactersInDocument; // 0x1F8
	private object charactersFromEntities; // 0x200
	private object currentEntities; // 0x208
	private object disableUndeclaredEntityCheck; // 0x210
	private object outerReader; // 0x218
	private object xmlResolverIsSet; // 0x220
	private object Xml; // 0x228
	private object XmlNs; // 0x230
	private object parseText_dummyTask; // 0x238

	// Properties
	public override object Settings { get; }
	public override object NodeType { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object IsDefault { get; }
	public override object QuoteChar { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object ReadState { get; }
	public override object EOF { get; }
	public override object NameTable { get; }
	public override object CanResolveEntity { get; }
	public override object AttributeCount { get; }
	internal object OuterReader { set; }
	public override object CanReadValueChunk { get; }
	public object LineNumber { get; }
	public object LinePosition { get; }
	internal object Namespaces { get; set; }
	internal object Normalization { get; set; }
	internal object WhitespaceHandling { set; }
	internal object EntityHandling { set; }
	internal object IsResolverSet { get; }
	internal object XmlResolver { set; }
	internal object DtdParserProxy_NameTable { get; }
	internal object DtdParserProxy_NamespaceResolver { get; }
	internal object DtdParserProxy_DtdValidation { get; }
	internal object DtdParserProxy_Normalization { get; }
	internal object DtdParserProxy_Namespaces { get; }
	internal object DtdParserProxy_V1CompatibilityMode { get; }
	internal object DtdParserProxy_BaseUri { get; }
	internal object DtdParserProxy_IsEof { get; }
	internal object DtdParserProxy_ParsingBuffer { get; }
	internal object DtdParserProxy_ParsingBufferLength { get; }
	internal object DtdParserProxy_CurrentPosition { get; set; }
	internal object DtdParserProxy_EntityStackLength { get; }
	internal object DtdParserProxy_IsEntityEolNormalized { get; }
	internal object DtdParserProxy_ValidationEventHandling { get; }
	internal object DtdParserProxy_LineNo { get; }
	internal object DtdParserProxy_LineStartPosition { get; }
	private object IsResolverNull { get; }
	private object InAttributeValueIterator { get; }
	private object DtdValidation { get; }
	private object InEntity { get; }
	internal override object DtdInfo { get; }
	internal object ValidationEventHandling { set; }
	internal object OnDefaultAttributeUse { set; }
	internal object XmlValidatingReaderCompatibilityMode { set; }
	internal object FragmentType { get; }
	internal object InternalSchemaType { set; }
	internal object InternalTypedValue { get; set; }
	internal object StandAlone { get; }
	internal override object NamespaceManager { get; }
	internal object V1Compat { get; }
	internal object DisableUndeclaredEntityCheck { set; }

	// Methods

	// RVA: 0x6EF7504
	internal object .ctor(object nt) { }

	// RVA: 0x6EF78D4
	private object .ctor(object resolver, object settings, object context) { }

	// RVA: 0x6EF8078
	internal object .ctor(object input) { }

	// RVA: 0x6EF8214
	internal object .ctor(object input, object nt) { }

	// RVA: 0x6EF8114
	internal object .ctor(object url, object input, object nt) { }

	// RVA: 0x6EF832C
	internal object .ctor(object input) { }

	// RVA: 0x6EF852C
	internal object .ctor(object input, object nt) { }

	// RVA: 0x6EF83C8
	internal object .ctor(object url, object input, object nt) { }

	// RVA: 0x6EF8654
	internal object .ctor(object xmlFragment, object fragType, object context) { }

	// RVA: 0x6EF8AAC
	internal object .ctor(object xmlFragment, object context) { }

	// RVA: 0x6EF8C10
	private object FinishInitUriString() { }

	// RVA: 0x6EF9390
	internal object .ctor(object stream, object bytes, object byteCount, object settings, object baseUri, object baseUriStr, object context, object closeInput) { }

	// RVA: 0x6EF9710
	private object FinishInitStream() { }

	// RVA: 0x6EF9810
	internal object .ctor(object input, object settings, object baseUriStr, object context) { }

	// RVA: 0x6EF9910
	private object FinishInitTextReader() { }

	// RVA: 0x6EF9A80
	internal object .ctor(object xmlFragment, object context, object settings) { }

	// RVA: 0x6EF9B28
	public override object get_Settings() { }

	// RVA: 0x6EF9CD8
	public override object get_NodeType() { }

	// RVA: 0x6EF9CFC
	public override object get_Name() { }

	// RVA: 0x6EF9D28
	public override object get_LocalName() { }

	// RVA: 0x6EF9D4C
	public override object get_NamespaceURI() { }

	// RVA: 0x6EF9D70
	public override object get_Prefix() { }

	// RVA: 0x6EF9D94
	public override object get_Value() { }

	// RVA: 0x6EFA0C4
	public override object get_Depth() { }

	// RVA: 0x6EFA0E8
	public override object get_BaseURI() { }

	// RVA: 0x6EFA0F0
	public override object get_IsEmptyElement() { }

	// RVA: 0x6EFA114
	public override object get_IsDefault() { }

	// RVA: 0x6EFA138
	public override object get_QuoteChar() { }

	// RVA: 0x6EFA170
	public override object get_XmlSpace() { }

	// RVA: 0x6EFA194
	public override object get_XmlLang() { }

	// RVA: 0x6EFA1B8
	public override object get_ReadState() { }

	// RVA: 0x6EFA1C0
	public override object get_EOF() { }

	// RVA: 0x6EFA1D0
	public override object get_NameTable() { }

	// RVA: 0x6EFA1D8
	public override object get_CanResolveEntity() { }

	// RVA: 0x6EFA1E0
	public override object get_AttributeCount() { }

	// RVA: 0x6EFA1E8
	public override object GetAttribute(object name) { }

	// RVA: 0x6EFA508
	public override object GetAttribute(object localName, object namespaceURI) { }

	// RVA: 0x6EFA724
	public override object GetAttribute(object i) { }

	// RVA: 0x6EFA7E0
	public override object MoveToAttribute(object name) { }

	// RVA: 0x6EFA9E8
	public override object MoveToAttribute(object i) { }

	// RVA: 0x6EFAAB4
	public override object MoveToFirstAttribute() { }

	// RVA: 0x6EFAB38
	public override object MoveToNextAttribute() { }

	// RVA: 0x6EFABE4
	public override object MoveToElement() { }

	// RVA: 0x6EFAC94
	private object FinishInit() { }

	// RVA: 0x6EFACD8
	public override object Read() { }

	// RVA: 0x6EFD970
	public override object Close() { }

	// RVA: 0x6EFDA88
	public override object Skip() { }

	// RVA: 0x6EFDD18
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x6EFDD8C
	public override object ReadAttributeValue() { }

	// RVA: 0x6EFE6DC
	public override object ResolveEntity() { }

	// RVA: 0x6EFEFA0
	internal object set_OuterReader(object value) { }

	// RVA: 0x6EFEFA8
	internal object MoveOffEntityReference() { }

	// RVA: 0x6EFF0A0
	public override object ReadString() { }

	// RVA: 0x6EFF0C8
	public override object get_CanReadValueChunk() { }

	// RVA: 0x6EFF0D0
	public override object ReadValueChunk(object buffer, object index, object count) { }

	// RVA: 0x6EFFDA0
	public object HasLineInfo() { }

	// RVA: 0x6EFFDA8
	public object get_LineNumber() { }

	// RVA: 0x6EFFDCC
	public object get_LinePosition() { }

	// RVA: 0x6EFFDF0
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x6EFFEA0
	private object System.Xml.IXmlNamespaceResolver.LookupNamespace(object prefix) { }

	// RVA: 0x6EFFEEC
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

	// RVA: 0x6EFFE48
	internal object GetNamespacesInScope(object scope) { }

	// RVA: 0x6EFFF44
	internal object LookupPrefix(object namespaceName) { }

	// RVA: 0x6EFFF9C
	internal object get_Namespaces() { }

	// RVA: 0x6EFFFA4
	internal object set_Namespaces(object value) { }

	// RVA: 0x6F001D0
	internal object get_Normalization() { }

	// RVA: 0x6F001D8
	internal object set_Normalization(object value) { }

	// RVA: 0x6F00328
	internal object set_WhitespaceHandling(object value) { }

	// RVA: 0x6F00408
	internal object set_EntityHandling(object value) { }

	// RVA: 0x6F00488
	internal object get_IsResolverSet() { }

	// RVA: 0x6F00490
	internal object set_XmlResolver(object value) { }

	// RVA: 0x6F00548
	internal object get_DtdParserProxy_NameTable() { }

	// RVA: 0x6F00550
	internal object get_DtdParserProxy_NamespaceResolver() { }

	// RVA: 0x6F00558
	internal object get_DtdParserProxy_DtdValidation() { }

	// RVA: 0x6F00578
	internal object get_DtdParserProxy_Normalization() { }

	// RVA: 0x6F00580
	internal object get_DtdParserProxy_Namespaces() { }

	// RVA: 0x6F00588
	internal object get_DtdParserProxy_V1CompatibilityMode() { }

	// RVA: 0x6F00590
	internal object get_DtdParserProxy_BaseUri() { }

	// RVA: 0x6F00688
	internal object get_DtdParserProxy_IsEof() { }

	// RVA: 0x6F00690
	internal object get_DtdParserProxy_ParsingBuffer() { }

	// RVA: 0x6F00698
	internal object get_DtdParserProxy_ParsingBufferLength() { }

	// RVA: 0x6F006A0
	internal object get_DtdParserProxy_CurrentPosition() { }

	// RVA: 0x6F006A8
	internal object set_DtdParserProxy_CurrentPosition(object value) { }

	// RVA: 0x6F006B0
	internal object get_DtdParserProxy_EntityStackLength() { }

	// RVA: 0x6F006BC
	internal object get_DtdParserProxy_IsEntityEolNormalized() { }

	// RVA: 0x6F006C4
	internal object get_DtdParserProxy_ValidationEventHandling() { }

	// RVA: 0x6F006CC
	internal object DtdParserProxy_OnNewLine(object pos) { }

	// RVA: 0x6F006F4
	internal object get_DtdParserProxy_LineNo() { }

	// RVA: 0x6F006FC
	internal object get_DtdParserProxy_LineStartPosition() { }

	// RVA: 0x6F00704
	internal object DtdParserProxy_ReadData() { }

	// RVA: 0x6F00C34
	internal object DtdParserProxy_ParseNumericCharRef(object internalSubsetBuilder) { }

	// RVA: 0x6F00D4C
	internal object DtdParserProxy_ParseNamedCharRef(object expand, object internalSubsetBuilder) { }

	// RVA: 0x6F00E44
	internal object DtdParserProxy_ParsePI(object sb) { }

	// RVA: 0x6F012A4
	internal object DtdParserProxy_ParseComment(object sb) { }

	// RVA: 0x6F017D0
	private object get_IsResolverNull() { }

	// RVA: 0x6F01814
	private object GetTempResolver() { }

	// RVA: 0x6F0188C
	internal object DtdParserProxy_PushEntity(object entity, object entityId) { }

	// RVA: 0x6F02284
	internal object DtdParserProxy_PopEntity(object oldEntity, object newEntityId) { }

	// RVA: 0x6F023EC
	internal object DtdParserProxy_PushExternalSubset(object systemId, object publicId) { }

	// RVA: 0x6F02C04
	internal object DtdParserProxy_PushInternalDtd(object baseUri, object internalDtd) { }

	// RVA: 0x6F02EF4
	internal object DtdParserProxy_Throw(object e) { }

	// RVA: 0x6F0301C
	internal object DtdParserProxy_OnSystemId(object systemId, object keywordLineInfo, object systemLiteralLineInfo) { }

	// RVA: 0x6F031A8
	internal object DtdParserProxy_OnPublicId(object publicId, object keywordLineInfo, object publicLiteralLineInfo) { }

	// RVA: 0x6F03244
	private object Throw(object pos, object res, object arg) { }

	// RVA: 0x6F03364
	private object Throw(object pos, object res, object args) { }

	// RVA: 0x6F03484
	private object Throw(object pos, object res) { }

	// RVA: 0x6EF96B4
	private object Throw(object res) { }

	// RVA: 0x6F034EC
	private object Throw(object res, object lineNo, object linePos) { }

	// RVA: 0x6F0325C
	private object Throw(object res, object arg) { }

	// RVA: 0x6F03604
	private object Throw(object res, object arg, object lineNo, object linePos) { }

	// RVA: 0x6F0337C
	private object Throw(object res, object args) { }

	// RVA: 0x6F03700
	private object Throw(object res, object arg, object innerException) { }

	// RVA: 0x6F0378C
	private object Throw(object res, object args, object innerException) { }

	// RVA: 0x6F02F88
	private object Throw(object e) { }

	// RVA: 0x6F038B4
	private object ReThrow(object e, object lineNo, object linePos) { }

	// RVA: 0x6EFD668
	private object ThrowWithoutLineInfo(object res) { }

	// RVA: 0x6F039E4
	private object ThrowWithoutLineInfo(object res, object arg) { }

	// RVA: 0x6F03ACC
	private object ThrowWithoutLineInfo(object res, object args, object innerException) { }

	// RVA: 0x6F03BC8
	private object ThrowInvalidChar(object data, object length, object invCharPos) { }

	// RVA: 0x6F038A0
	private object SetErrorState() { }

	// RVA: 0x6F01674
	private object SendValidationEvent(object severity, object code, object arg, object lineNo, object linePos) { }

	// RVA: 0x6F03C3C
	private object SendValidationEvent(object severity, object exception) { }

	// RVA: 0x6EFA8CC
	private object get_InAttributeValueIterator() { }

	// RVA: 0x6EFA8F0
	private object FinishAttributeValueIterator() { }

	// RVA: 0x6F00568
	private object get_DtdValidation() { }

	// RVA: 0x6EF828C
	private object InitStreamInput(object stream, object encoding) { }

	// RVA: 0x6EF8310
	private object InitStreamInput(object baseUriStr, object stream, object encoding) { }

	// RVA: 0x6F03F34
	private object InitStreamInput(object baseUri, object stream, object encoding) { }

	// RVA: 0x6F03FB4
	private object InitStreamInput(object baseUri, object baseUriStr, object stream, object encoding) { }

	// RVA: 0x6EF8FFC
	private object InitStreamInput(object baseUri, object baseUriStr, object stream, object bytes, object byteCount, object encoding) { }

	// RVA: 0x6EF85A4
	private object InitTextReaderInput(object baseUriStr, object input) { }

	// RVA: 0x6F04384
	private object InitTextReaderInput(object baseUriStr, object baseUri, object input) { }

	// RVA: 0x6EF8774
	private object InitStringInput(object baseUriStr, object originalEncoding, object str) { }

	// RVA: 0x6EF8860
	private object InitFragmentReader(object fragmentType, object parserContext, object allowXmlDeclFragment) { }

	// RVA: 0x6EF9320
	private object ProcessDtdFromParserContext(object context) { }

	// RVA: 0x6EFBDF0
	private object OpenUrl() { }

	// RVA: 0x6F04700
	private object OpenUrlDelegate(object xmlResolver) { }

	// RVA: 0x6F03FC4
	private object DetectEncoding() { }

	// RVA: 0x6F041FC
	private object SetupEncoding(object encoding) { }

	// RVA: 0x6F048E4
	private object SwitchEncoding(object newEncoding) { }

	// RVA: 0x6F04B08
	private object CheckEncoding(object newEncodingName) { }

	// RVA: 0x6F04A20
	private object UnDecodeChars() { }

	// RVA: 0x6F04F40
	private object SwitchEncodingToUTF8() { }

	// RVA: 0x6F00708
	private object ReadData() { }

	// RVA: 0x6F04FB8
	private object GetChars(object maxCharsCount) { }

	// RVA: 0x6F05128
	private object InvalidCharRecovery(object bytesCount, object charsCount) { }

	// RVA: 0x6EFD978
	internal object Close(object closeInput) { }

	// RVA: 0x6F05390
	private object ShiftBuffer(object sourcePos, object destPos, object count) { }

	// RVA: 0x6EFC050
	private object ParseXmlDeclaration(object isTextDecl) { }

	// RVA: 0x6EFB7C0
	private object ParseDocumentContent() { }

	// RVA: 0x6EFB3E8
	private object ParseElementContent() { }

	// RVA: 0x6F07054
	private object ThrowUnclosedElements() { }

	// RVA: 0x6F05920
	private object ParseElement() { }

	// RVA: 0x6F07990
	private object AddDefaultAttributesAndNormalize() { }

	// RVA: 0x6F06C5C
	private object ParseEndElement() { }

	// RVA: 0x6F08F60
	private object ThrowTagMismatch(object startTag) { }

	// RVA: 0x6F072A0
	private object ParseAttributes() { }

	// RVA: 0x6F085E4
	private object ElementNamespaceLookup() { }

	// RVA: 0x6F08E80
	private object AttributeNamespaceLookup() { }

	// RVA: 0x6F0A624
	private object AttributeDuplCheck() { }

	// RVA: 0x6F0A064
	private object OnDefaultNamespaceDecl(object attr) { }

	// RVA: 0x6F0A240
	private object OnNamespaceDecl(object attr) { }

	// RVA: 0x6F0A344
	private object OnXmlReservedAttribute(object attr) { }

	// RVA: 0x6F09464
	private object ParseAttributeValueSlow(object curPos, object quoteChar, object attr) { }

	// RVA: 0x6F0AF08
	private object AddAttributeChunkToList(object attr, object chunk, object lastChunk) { }

	// RVA: 0x6F06390
	private object ParseText() { }

	// RVA: 0x6EFF5BC
	private object ParseText(object startPos, object endPos, object outOrChars) { }

	// RVA: 0x6EF9DF0
	private object FinishPartialValue() { }

	// RVA: 0x6EF9F40
	private object FinishOtherValueIterator() { }

	// RVA: 0x6EFD76C
	private object SkipPartialTextValue() { }

	// RVA: 0x6EFD7B4
	private object FinishReadValueChunk() { }

	// RVA: 0x6EFD7D4
	private object FinishReadContentAsBinary() { }

	// RVA: 0x6EFD838
	private object FinishReadElementContentAsBinary() { }

	// RVA: 0x6F068BC
	private object ParseRootLevelWhitespace() { }

	// RVA: 0x6EFD188
	private object ParseEntityReference() { }

	// RVA: 0x6F06010
	private object HandleEntityReference(object isInAttributeValue, object expandType, object charRefEndPos) { }

	// RVA: 0x6EFE978
	private object HandleGeneralEntityReference(object name, object isInAttributeValue, object pushFakeEntityIfNullResolver, object entityStartLinePos) { }

	// RVA: 0x6F04F30
	private object get_InEntity() { }

	// RVA: 0x6F03D2C
	private object HandleEntityEnd(object checkEntityNesting) { }

	// RVA: 0x6EFD21C
	private object SetupEndEntityNodeInContent() { }

	// RVA: 0x6F0B4CC
	private object SetupEndEntityNodeInAttribute() { }

	// RVA: 0x6F05554
	private object ParsePI() { }

	// RVA: 0x6F00E7C
	private object ParsePI(object piInDtdStringBuilder) { }

	// RVA: 0x6F0B558
	private object ParsePIValue(object outStartPos, object outEndPos) { }

	// RVA: 0x6F0555C
	private object ParseComment() { }

	// RVA: 0x6F055DC
	private object ParseCData() { }

	// RVA: 0x6F0149C
	private object ParseCDataOrComment(object type) { }

	// RVA: 0x6F0B92C
	private object ParseCDataOrComment(object type, object outStartPos, object outEndPos) { }

	// RVA: 0x6F055E4
	private object ParseDoctypeDecl() { }

	// RVA: 0x6F0BDCC
	private object ParseDtd() { }

	// RVA: 0x6F0C214
	private object SkipDtd() { }

	// RVA: 0x6F0C5C8
	private object SkipPublicOrSystemIdLiteral() { }

	// RVA: 0x6F0C680
	private object SkipUntil(object stopChar, object recognizeLiterals) { }

	// RVA: 0x6F02960
	private object EatWhitespaces(object sb) { }

	// RVA: 0x6F0B168
	private object ParseCharRefInline(object startPos, object charCount, object entityType) { }

	// RVA: 0x6F00C5C
	private object ParseNumericCharRef(object expand, object internalSubsetBuilder, object entityType) { }

	// RVA: 0x6F0CBCC
	private object ParseNumericCharRefInline(object startPos, object expand, object internalSubsetBuilder, object charCount, object entityType) { }

	// RVA: 0x6F00DC8
	private object ParseNamedCharRef(object expand, object internalSubsetBuilder) { }

	// RVA: 0x6F0D25C
	private object ParseNamedCharRefInline(object startPos, object expand, object internalSubsetBuilder) { }

	// RVA: 0x6F053C0
	private object ParseName() { }

	// RVA: 0x6F07290
	private object ParseQName(object colonPos) { }

	// RVA: 0x6F0D56C
	private object ParseQName(object isQName, object startOffset, object colonPos) { }

	// RVA: 0x6F0D820
	private object ReadDataInName(object pos) { }

	// RVA: 0x6F0AF44
	private object ParseEntityName() { }

	// RVA: 0x6EFD0B0
	private object AddNode(object nodeIndex, object nodeDepth) { }

	// RVA: 0x6F0D86C
	private object AllocNode(object nodeIndex, object nodeDepth) { }

	// RVA: 0x6F030B8
	private object AddAttributeNoChecks(object name, object attrDepth) { }

	// RVA: 0x6F091F4
	private object AddAttribute(object endNamePos, object colonPos) { }

	// RVA: 0x6F0D9F8
	private object AddAttribute(object localName, object prefix, object nameWPrefix) { }

	// RVA: 0x6EFD100
	private object PopElementContext() { }

	// RVA: 0x6F006E0
	private object OnNewLine(object pos) { }

	// RVA: 0x6EFD5B4
	private object OnEof() { }

	// RVA: 0x6F0AB18
	private object LookupNamespace(object node) { }

	// RVA: 0x6F0AC80
	private object AddNamespace(object prefix, object uri, object attr) { }

	// RVA: 0x6EFD004
	private object ResetAttributes() { }

	// RVA: 0x6F0DBD0
	private object FullAttributeCleanup() { }

	// RVA: 0x6F0ABF8
	private object PushXmlContext() { }

	// RVA: 0x6F0DB8C
	private object PopXmlContext() { }

	// RVA: 0x6F0B47C
	private object GetWhitespaceType() { }

	// RVA: 0x6F0B108
	private object GetTextNodeType(object orChars) { }

	// RVA: 0x6F025A4
	private object PushExternalEntityOrSubset(object publicId, object systemId, object baseUri, object entityName) { }

	// RVA: 0x6F0DC54
	private object OpenAndPush(object uri) { }

	// RVA: 0x6F019E0
	private object PushExternalEntity(object entity) { }

	// RVA: 0x6F01E58
	private object PushInternalEntity(object entity) { }

	// RVA: 0x6F022E0
	private object PopEntity() { }

	// RVA: 0x6F0DFEC
	private object RegisterEntity(object entity) { }

	// RVA: 0x6F0E2AC
	private object UnregisterEntity() { }

	// RVA: 0x6F02C7C
	private object PushParsingState() { }

	// RVA: 0x6F05320
	private object PopParsingState() { }

	// RVA: 0x6F0E31C
	private object IncrementalRead() { }

	// RVA: 0x6EFD3C8
	private object FinishIncrementalRead() { }

	// RVA: 0x6EFD438
	private object ParseFragmentAttribute() { }

	// RVA: 0x6EFE0E8
	private object ParseAttributeValueChunk() { }

	// RVA: 0x6EFD4F8
	private object ParseXmlDeclarationFragment() { }

	// RVA: 0x6F055C4
	private object ThrowUnexpectedToken(object pos, object expectedToken) { }

	// RVA: 0x6F053B0
	private object ThrowUnexpectedToken(object expectedToken1) { }

	// RVA: 0x6F05908
	private object ThrowUnexpectedToken(object pos, object expectedToken1, object expectedToken2) { }

	// RVA: 0x6F053E8
	private object ThrowUnexpectedToken(object expectedToken1, object expectedToken2) { }

	// RVA: 0x6F05900
	private object ParseUnexpectedToken(object pos) { }

	// RVA: 0x6F0EDC8
	private object ParseUnexpectedToken() { }

	// RVA: 0x6F09130
	private object ThrowExpectingWhitespace(object pos) { }

	// RVA: 0x6EFA2A0
	private object GetIndexOfAttributeWithoutPrefix(object name) { }

	// RVA: 0x6EFA408
	private object GetIndexOfAttributeWithPrefix(object name) { }

	// RVA: 0x6F0B1E0
	private object ZeroEndingStream(object pos) { }

	// RVA: 0x6F04440
	private object ParseDtdFromParserContext() { }

	// RVA: 0x6F0B27C
	private object MoveToNextContentNode(object moveIfOnContentNode) { }

	// RVA: 0x6EF7DB0
	private object SetupFromParserContext(object context, object settings) { }

	// RVA: 0x6F0EEB4
	internal override object get_DtdInfo() { }

	// RVA: 0x6F0EEBC
	internal object SetDtdInfo(object newDtdInfo) { }

	// RVA: 0x6F0F058
	internal object set_ValidationEventHandling(object value) { }

	// RVA: 0x6F0F060
	internal object set_OnDefaultAttributeUse(object value) { }

	// RVA: 0x6F0F068
	internal object set_XmlValidatingReaderCompatibilityMode(object value) { }

	// RVA: 0x6F0F1B4
	internal object get_FragmentType() { }

	// RVA: 0x6F0F1BC
	internal object ChangeCurrentNodeType(object newNodeType) { }

	// RVA: 0x6F0F1E0
	internal object GetResolver() { }

	// RVA: 0x6F0F234
	internal object set_InternalSchemaType(object value) { }

	// RVA: 0x6F0F258
	internal object get_InternalTypedValue() { }

	// RVA: 0x6F0F27C
	internal object set_InternalTypedValue(object value) { }

	// RVA: 0x6F0F2A0
	internal object get_StandAlone() { }

	// RVA: 0x6F0F2A8
	internal override object get_NamespaceManager() { }

	// RVA: 0x6F0F2B0
	internal object get_V1Compat() { }

	// RVA: 0x6F08660
	private object AddDefaultAttributeDtd(object defAttrInfo, object definedInDtd, object nameSortedNodeData) { }

	// RVA: 0x6F0F5D4
	internal object AddDefaultAttributeNonDtd(object attrDef) { }

	// RVA: 0x6F0F2B8
	private object AddDefaultAttributeInternal(object localName, object ns, object prefix, object value, object lineNo, object linePos, object valueLineNo, object valueLinePos, object isXmlAttribute) { }

	// RVA: 0x6F0F930
	internal object set_DisableUndeclaredEntityCheck(object value) { }

	// RVA: 0x6EF9550
	private object UriEqual(object uri1, object uri1Str, object uri2Str, object resolver) { }

	// RVA: 0x6F02DFC
	private object RegisterConsumedCharacters(object characters, object inEntityReference) { }

	// RVA: 0x6F0F938
	internal static object StripSpaces(object value) { }

	// RVA: 0x6F0FB80
	internal static object StripSpaces(object value, object index, object len) { }

	// RVA: 0x6EFFD8C
	internal static object BlockCopyChars(object src, object srcOffset, object dst, object dstOffset, object count) { }

	// RVA: 0x6F04FB0
	internal static object BlockCopy(object src, object srcOffset, object dst, object dstOffset, object count) { }

}

// Namespace: System.Xml
public enum Formatting
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Indented;
}

// Namespace: 
private enum NamespaceState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Uninitialized;
	public const object NotDeclaredButInScope;
	public const object DeclaredButNotWrittenOut;
	public const object DeclaredAndWrittenOut;
}

// Namespace: 
private struct TagInfo
{

	// Fields
	internal object name; // 0xFFFFFFFFFFFFFFF8
	internal object prefix; // 0x0
	internal object defaultNs; // 0x8
	internal object defaultNsState; // 0x10
	internal object xmlSpace; // 0x14
	internal object xmlLang; // 0x18
	internal object prevNsTop; // 0x20
	internal object prefixCount; // 0x24
	internal object mixed; // 0x28

	// Methods

	// RVA: 0x7024860
	internal object Init(object nsTop) { }

}

// Namespace: 
private struct Namespace
{

	// Fields
	internal object prefix; // 0xFFFFFFFFFFFFFFF8
	internal object ns; // 0x0
	internal object declared; // 0x8
	internal object prevNsIndex; // 0xC

	// Methods

	// RVA: 0x702A07C
	internal object Set(object prefix, object ns, object declared) { }

}

// Namespace: 
private enum SpecialAttr
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object XmlSpace;
	public const object XmlLang;
	public const object XmlNs;
}

// Namespace: 
private enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object Prolog;
	public const object PostDTD;
	public const object Element;
	public const object Attribute;
	public const object Content;
	public const object AttrOnly;
	public const object Epilog;
	public const object Error;
	public const object Closed;
}

// Namespace: 
private enum Token
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PI;
	public const object Doctype;
	public const object Comment;
	public const object CData;
	public const object StartElement;
	public const object EndElement;
	public const object LongEndElement;
	public const object StartAttribute;
	public const object EndAttribute;
	public const object Content;
	public const object Base64;
	public const object RawData;
	public const object Whitespace;
	public const object Empty;
}

// Namespace: System.Xml
public class XmlTextWriter
{

	// Fields
	private object textWriter; // 0x10
	private object xmlEncoder; // 0x18
	private object encoding; // 0x20
	private object formatting; // 0x28
	private object indented; // 0x2C
	private object indentation; // 0x30
	private object indentChar; // 0x34
	private object stack; // 0x38
	private object top; // 0x40
	private object stateTable; // 0x48
	private object currentState; // 0x50
	private object lastToken; // 0x54
	private object base64Encoder; // 0x58
	private object quoteChar; // 0x60
	private object curQuoteChar; // 0x62
	private object namespaces; // 0x64
	private object specialAttr; // 0x68
	private object prefixForXmlNs; // 0x70
	private object flush; // 0x78
	private object nsStack; // 0x80
	private object nsTop; // 0x88
	private object nsHashtable; // 0x90
	private object useNsHashtable; // 0x98
	private object xmlCharType; // 0xA0
	private static object stateName; // 0x0
	private static object tokenName; // 0x8
	private static readonly object stateTableDefault; // 0x10
	private static readonly object stateTableDocument; // 0x18

	// Properties
	public object BaseStream { get; }
	public object Namespaces { set; }
	public object Formatting { set; }
	public object QuoteChar { set; }
	public override object WriteState { get; }

	// Methods

	// RVA: 0x70246E4
	internal object .ctor() { }

	// RVA: 0x70248D0
	public object .ctor(object w, object encoding) { }

	// RVA: 0x70249B0
	public object .ctor(object filename, object encoding) { }

	// RVA: 0x7024A3C
	public object .ctor(object w) { }

	// RVA: 0x7024B08
	public object get_BaseStream() { }

	// RVA: 0x7024BB0
	public object set_Namespaces(object value) { }

	// RVA: 0x7024C1C
	public object set_Formatting(object value) { }

	// RVA: 0x7024C30
	public object set_QuoteChar(object value) { }

	// RVA: 0x7024CC4
	public override object WriteStartDocument() { }

	// RVA: 0x70250A8
	public override object WriteStartDocument(object standalone) { }

	// RVA: 0x70250C4
	public override object WriteEndDocument() { }

	// RVA: 0x7025368
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x7026254
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x7026E00
	public override object WriteEndElement() { }

	// RVA: 0x7027208
	public override object WriteFullEndElement() { }

	// RVA: 0x7027210
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x7027C14
	public override object WriteEndAttribute() { }

	// RVA: 0x7027CBC
	public override object WriteCData(object text) { }

	// RVA: 0x7027EF8
	public override object WriteComment(object text) { }

	// RVA: 0x7028164
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x7028554
	public override object WriteEntityRef(object name) { }

	// RVA: 0x7028634
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x7028708
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x7028894
	public override object WriteString(object text) { }

	// RVA: 0x7028974
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x7028A58
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x7028B44
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x7028C30
	public override object WriteRaw(object data) { }

	// RVA: 0x7028D04
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x7028E60
	public override object WriteBinHex(object buffer, object index, object count) { }

	// RVA: 0x7028F38
	public override object get_WriteState() { }

	// RVA: 0x7028F5C
	public override object Close() { }

	// RVA: 0x7029188
	public override object Flush() { }

	// RVA: 0x70291D4
	public override object LookupPrefix(object ns) { }

	// RVA: 0x7024CCC
	private object StartDocument(object standalone) { }

	// RVA: 0x7025BAC
	private object AutoComplete(object token) { }

	// RVA: 0x70252EC
	private object AutoCompleteAll() { }

	// RVA: 0x7026E08
	private object InternalWriteEndElement(object longFormat) { }

	// RVA: 0x70294DC
	private object WriteEndStartTag(object empty) { }

	// RVA: 0x7029454
	private object WriteEndAttributeQuote() { }

	// RVA: 0x70292F8
	private object Indent(object beforeEndElement) { }

	// RVA: 0x7026A30
	private object PushNamespace(object prefix, object ns, object declared) { }

	// RVA: 0x7029E20
	private object AddNamespace(object prefix, object ns, object declared) { }

	// RVA: 0x702A090
	private object AddToNamespaceHashtable(object namespaceIndex) { }

	// RVA: 0x7029AB8
	private object PopNamespaces(object indexFrom, object indexTo) { }

	// RVA: 0x7027AF4
	private object GeneratePrefix() { }

	// RVA: 0x70283AC
	private object InternalWriteProcessingInstruction(object name, object text) { }

	// RVA: 0x7026818
	private object LookupNamespace(object prefix) { }

	// RVA: 0x7027984
	private object LookupNamespaceInCurrentScope(object prefix) { }

	// RVA: 0x7026930
	private object FindPrefix(object ns) { }

	// RVA: 0x70259AC
	private object ValidateName(object name, object isNCName) { }

	// RVA: 0x7029BBC
	private object HandleSpecialAttribute() { }

	// RVA: 0x7026CAC
	private object VerifyPrefixXml(object prefix, object ns) { }

	// RVA: 0x70266E0
	private object PushStack() { }

	// RVA: 0x7029A88
	private object FlushEncoders() { }

	// RVA: 0x702A1B0
	private static object .cctor() { }

}

// Namespace: System.Xml
internal class XmlUtf8RawTextWriter
{

	// Fields
	private readonly object useAsync; // 0x20
	protected object bufBytes; // 0x28
	protected object stream; // 0x30
	protected object encoding; // 0x38
	protected object xmlCharType; // 0x40
	protected object bufPos; // 0x48
	protected object textPos; // 0x4C
	protected object contentPos; // 0x50
	protected object cdataPos; // 0x54
	protected object attrEndPos; // 0x58
	protected object bufLen; // 0x5C
	protected object writeToNull; // 0x60
	protected object hadDoubleBracket; // 0x61
	protected object inAttributeValue; // 0x62
	protected object newLineHandling; // 0x64
	protected object closeOutput; // 0x68
	protected object omitXmlDeclaration; // 0x69
	protected object newLineChars; // 0x70
	protected object checkCharacters; // 0x78
	protected object standalone; // 0x7C
	protected object outputMethod; // 0x80
	protected object autoXmlDeclaration; // 0x84
	protected object mergeCDataSections; // 0x85

	// Properties
	internal override object SupportsNamespaceDeclarationInChunks { get; }

	// Methods

	// RVA: 0x702A8DC
	protected object .ctor(object settings) { }

	// RVA: 0x702AD1C
	public object .ctor(object stream, object settings) { }

	// RVA: 0x702AEEC
	internal override object WriteXmlDeclaration(object standalone) { }

	// RVA: 0x702B16C
	internal override object WriteXmlDeclaration(object xmldecl) { }

	// RVA: 0x702B20C
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x702B544
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x702B640
	internal override object StartElementContent() { }

	// RVA: 0x702B694
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x702B88C
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x702B9F0
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x702BB6C
	public override object WriteEndAttribute() { }

	// RVA: 0x702BBC4
	internal override object WriteNamespaceDeclaration(object prefix, object namespaceName) { }

	// RVA: 0x702BC6C
	internal override object get_SupportsNamespaceDeclarationInChunks() { }

	// RVA: 0x702BC74
	internal override object WriteStartNamespaceDeclaration(object prefix) { }

	// RVA: 0x702BDE8
	internal override object WriteEndNamespaceDeclaration() { }

	// RVA: 0x702BE40
	public override object WriteCData(object text) { }

	// RVA: 0x702C528
	public override object WriteComment(object text) { }

	// RVA: 0x702CAF4
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x702CC94
	public override object WriteEntityRef(object name) { }

	// RVA: 0x702CD94
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x702CFCC
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x702D6C0
	public override object WriteString(object text) { }

	// RVA: 0x702D720
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x702D8BC
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x702D90C
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x702DC48
	public override object WriteRaw(object data) { }

	// RVA: 0x702DC9C
	public override object Close() { }

	// RVA: 0x702DDF8
	public override object Flush() { }

	// RVA: 0x702DE74
	protected virtual object FlushBuffer() { }

	// RVA: 0x702DD38
	private object FlushEncoder() { }

	// RVA: 0x702D02C
	protected object WriteAttributeTextBlock(object pSrc, object pSrcEnd) { }

	// RVA: 0x702D340
	protected object WriteElementTextBlock(object pSrc, object pSrcEnd) { }

	// RVA: 0x702B124
	protected object RawText(object s) { }

	// RVA: 0x702E6AC
	protected object RawText(object pSrcBegin, object pSrcEnd) { }

	// RVA: 0x702D960
	protected object WriteRawWithCharChecking(object pSrcBegin, object pSrcEnd) { }

	// RVA: 0x702C6DC
	protected object WriteCommentOrPi(object text, object stopChar) { }

	// RVA: 0x702C138
	protected object WriteCDataSection(object text) { }

	// RVA: 0x702E884
	private static object IsSurrogateByte(object b) { }

	// RVA: 0x702E2AC
	private static object EncodeSurrogate(object pSrc, object pSrcEnd, object pDst) { }

	// RVA: 0x702E43C
	private object InvalidXmlChar(object ch, object pDst, object entitize) { }

	// RVA: 0x702E94C
	internal object EncodeChar(object pSrc, object pSrcEnd, object pDst) { }

	// RVA: 0x702E5C8
	internal static object EncodeMultibyteUTF8(object ch, object pDst) { }

	// RVA: 0x702EA30
	internal static object CharToUTF8(object pSrc, object pSrcEnd, object pDst) { }

	// RVA: 0x702E61C
	protected object WriteNewLine(object pDst) { }

	// RVA: 0x702E21C
	protected static object LtEntity(object pDst) { }

	// RVA: 0x702E22C
	protected static object GtEntity(object pDst) { }

	// RVA: 0x702E200
	protected static object AmpEntity(object pDst) { }

	// RVA: 0x702E23C
	protected static object QuoteEntity(object pDst) { }

	// RVA: 0x702E258
	protected static object TabEntity(object pDst) { }

	// RVA: 0x702E290
	protected static object LineFeedEntity(object pDst) { }

	// RVA: 0x702E274
	protected static object CarriageReturnEntity(object pDst) { }

	// RVA: 0x702E894
	private static object CharEntity(object pDst, object ch) { }

	// RVA: 0x702E860
	protected static object RawStartCData(object pDst) { }

	// RVA: 0x702E848
	protected static object RawEndCData(object pDst) { }

	// RVA: 0x702A9D0
	protected object ValidateContentChars(object chars, object propertyName, object allowOnlyWhitespace) { }

}

// Namespace: System.Xml
internal class XmlUtf8RawTextWriterIndent
{

	// Fields
	protected object indentLevel; // 0x88
	protected object newLineOnAttributes; // 0x8C
	protected object indentChars; // 0x90
	protected object mixedContent; // 0x98
	private object mixedContentStack; // 0xA0
	protected object conformanceLevel; // 0xA8

	// Methods

	// RVA: 0x702EB00
	public object .ctor(object stream, object settings) { }

	// RVA: 0x702EC40
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x702ED3C
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x702EDC0
	internal override object StartElementContent() { }

	// RVA: 0x702EE60
	internal override object OnRootElement(object currentConformanceLevel) { }

	// RVA: 0x702EE68
	internal override object WriteEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x702EEF8
	internal override object WriteFullEndElement(object prefix, object localName, object ns) { }

	// RVA: 0x702EF88
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x702EFD0
	public override object WriteCData(object text) { }

	// RVA: 0x702EFDC
	public override object WriteComment(object text) { }

	// RVA: 0x702F01C
	public override object WriteProcessingInstruction(object target, object text) { }

	// RVA: 0x702F06C
	public override object WriteEntityRef(object name) { }

	// RVA: 0x702F078
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x702F084
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x702F090
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x702F0F8
	public override object WriteString(object text) { }

	// RVA: 0x702F160
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x702F1B8
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x702F214
	public override object WriteRaw(object data) { }

	// RVA: 0x702F270
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x702EB2C
	private object Init(object settings) { }

	// RVA: 0x702ECA8
	private object WriteIndent() { }

}

// Namespace: System.Xml
public class XmlValidatingReader
{

	// Fields
	private object impl; // 0x8

	// Properties
	public override object NodeType { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object AttributeCount { get; }
	public override object EOF { get; }
	public override object ReadState { get; }
	public override object NameTable { get; }
	public object Namespaces { get; }

	// Methods

	// RVA: 0x702F280
	public override object get_NodeType() { }

	// RVA: 0x702F2CC
	public override object get_LocalName() { }

	// RVA: 0x702F318
	public override object get_NamespaceURI() { }

	// RVA: 0x702F364
	public override object get_Prefix() { }

	// RVA: 0x702F3B0
	public override object get_Value() { }

	// RVA: 0x702F3FC
	public override object get_Depth() { }

	// RVA: 0x702F448
	public override object get_BaseURI() { }

	// RVA: 0x702F498
	public override object get_IsEmptyElement() { }

	// RVA: 0x702F4E8
	public override object get_AttributeCount() { }

	// RVA: 0x702F538
	public override object GetAttribute(object name) { }

	// RVA: 0x702F590
	public override object GetAttribute(object localName, object namespaceURI) { }

	// RVA: 0x702F5F8
	public override object GetAttribute(object i) { }

	// RVA: 0x702F650
	public override object MoveToAttribute(object name) { }

	// RVA: 0x702F6A8
	public override object MoveToFirstAttribute() { }

	// RVA: 0x702F6F8
	public override object MoveToNextAttribute() { }

	// RVA: 0x702F748
	public override object MoveToElement() { }

	// RVA: 0x702F798
	public override object ReadAttributeValue() { }

	// RVA: 0x702F7E8
	public override object Read() { }

	// RVA: 0x702F838
	public override object get_EOF() { }

	// RVA: 0x702F888
	public override object get_ReadState() { }

	// RVA: 0x702F8D8
	public override object get_NameTable() { }

	// RVA: 0x702F928
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x702F994
	public override object ResolveEntity() { }

	// RVA: 0x702F9E4
	public object get_Namespaces() { }

}

// Namespace: 
private enum ParsingFunction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Read;
	public const object Init;
	public const object ParseDtdFromContext;
	public const object ResolveEntityInternally;
	public const object InReadBinaryContent;
	public const object ReaderClosed;
	public const object Error;
	public const object None;
}

// Namespace: 
internal class ValidationEventHandling
{

	// Fields
	private object reader; // 0x8
	private object eventHandler; // 0x10

	// Properties
	private object System.Xml.IValidationEventHandling.EventHandler { get; }

	// Methods

	// RVA: 0x702FF48
	internal object .ctor(object reader) { }

	// RVA: 0x7031C2C
	private object System.Xml.IValidationEventHandling.get_EventHandler() { }

	// RVA: 0x7031C34
	private object System.Xml.IValidationEventHandling.SendEvent(object exception, object severity) { }

	// RVA: 0x702FF74
	internal object AddHandler(object handler) { }

}

// Namespace: System.Xml
internal sealed class XmlValidatingReaderImpl
{

	// Fields
	private object coreReader; // 0x8
	private object coreReaderImpl; // 0x10
	private object coreReaderNSResolver; // 0x18
	private object validationType; // 0x20
	private object validator; // 0x28
	private object schemaCollection; // 0x30
	private object processIdentityConstraints; // 0x38
	private object parsingFunction; // 0x3C
	private object eventHandling; // 0x40
	private object parserContext; // 0x48
	private object readBinaryHelper; // 0x50
	private object outerReader; // 0x58
	private static object s_tempResolver; // 0x0

	// Properties
	public override object Settings { get; }
	public override object NodeType { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object IsDefault { get; }
	public override object QuoteChar { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object ReadState { get; }
	public override object EOF { get; }
	public override object NameTable { get; }
	public override object AttributeCount { get; }
	public override object CanResolveEntity { get; }
	public object LineNumber { get; }
	public object LinePosition { get; }
	internal object ValidationType { get; }
	internal object Schemas { get; }
	internal object Namespaces { get; }
	internal object Validator { get; set; }
	internal override object NamespaceManager { get; }
	internal object StandAlone { get; }
	internal object SchemaTypeObject { set; }
	internal object TypedValueObject { get; set; }
	internal override object DtdInfo { get; }

	// Methods

	// RVA: 0x702FA38
	internal object .ctor(object reader, object settingsEventHandler, object processIdentityConstraints) { }

	// RVA: 0x7030210
	public override object get_Settings() { }

	// RVA: 0x7030318
	public override object get_NodeType() { }

	// RVA: 0x7030364
	public override object get_Name() { }

	// RVA: 0x70303B0
	public override object get_LocalName() { }

	// RVA: 0x70303FC
	public override object get_NamespaceURI() { }

	// RVA: 0x7030448
	public override object get_Prefix() { }

	// RVA: 0x7030494
	public override object get_Value() { }

	// RVA: 0x70304E0
	public override object get_Depth() { }

	// RVA: 0x703052C
	public override object get_BaseURI() { }

	// RVA: 0x703057C
	public override object get_IsEmptyElement() { }

	// RVA: 0x70305CC
	public override object get_IsDefault() { }

	// RVA: 0x703061C
	public override object get_QuoteChar() { }

	// RVA: 0x703066C
	public override object get_XmlSpace() { }

	// RVA: 0x70306BC
	public override object get_XmlLang() { }

	// RVA: 0x703070C
	public override object get_ReadState() { }

	// RVA: 0x7030778
	public override object get_EOF() { }

	// RVA: 0x70307C8
	public override object get_NameTable() { }

	// RVA: 0x7030818
	public override object get_AttributeCount() { }

	// RVA: 0x7030868
	public override object GetAttribute(object name) { }

	// RVA: 0x70308C0
	public override object GetAttribute(object localName, object namespaceURI) { }

	// RVA: 0x7030928
	public override object GetAttribute(object i) { }

	// RVA: 0x7030980
	public override object MoveToAttribute(object name) { }

	// RVA: 0x70309F0
	public override object MoveToAttribute(object i) { }

	// RVA: 0x7030A5C
	public override object MoveToFirstAttribute() { }

	// RVA: 0x7030ABC
	public override object MoveToNextAttribute() { }

	// RVA: 0x7030B1C
	public override object MoveToElement() { }

	// RVA: 0x7030B7C
	public override object Read() { }

	// RVA: 0x7031188
	public override object Close() { }

	// RVA: 0x70311E8
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x7031240
	public override object ReadAttributeValue() { }

	// RVA: 0x70312CC
	public override object get_CanResolveEntity() { }

	// RVA: 0x70312D4
	public override object ResolveEntity() { }

	// RVA: 0x7031334
	internal object MoveOffEntityReference() { }

	// RVA: 0x703142C
	public override object ReadString() { }

	// RVA: 0x7031454
	public object HasLineInfo() { }

	// RVA: 0x703145C
	public object get_LineNumber() { }

	// RVA: 0x7031580
	public object get_LinePosition() { }

	// RVA: 0x70316A4
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x703177C
	private object System.Xml.IXmlNamespaceResolver.LookupNamespace(object prefix) { }

	// RVA: 0x70317C8
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

	// RVA: 0x70316A8
	internal object GetNamespacesInScope(object scope) { }

	// RVA: 0x70317CC
	internal object LookupPrefix(object namespaceName) { }

	// RVA: 0x70318A4
	internal object get_ValidationType() { }

	// RVA: 0x70318AC
	internal object get_Schemas() { }

	// RVA: 0x702FA14
	internal object get_Namespaces() { }

	// RVA: 0x7030EA4
	private object ParseDtdFromParserContext() { }

	// RVA: 0x70318B4
	private object ValidateDtd() { }

	// RVA: 0x7031064
	private object ResolveEntityInternally() { }

	// RVA: 0x7030010
	private object SetupValidation(object valType) { }

	// RVA: 0x702FE48
	private object GetResolver() { }

	// RVA: 0x7030CEC
	private object ProcessCoreReaderEvent() { }

	// RVA: 0x7031960
	internal object get_Validator() { }

	// RVA: 0x7031968
	internal object set_Validator(object value) { }

	// RVA: 0x7031970
	internal override object get_NamespaceManager() { }

	// RVA: 0x70319C0
	internal object get_StandAlone() { }

	// RVA: 0x70319E4
	internal object set_SchemaTypeObject(object value) { }

	// RVA: 0x7031A08
	internal object get_TypedValueObject() { }

	// RVA: 0x7031A2C
	internal object set_TypedValueObject(object value) { }

	// RVA: 0x7031A50
	internal object AddDefaultAttribute(object attdef) { }

	// RVA: 0x7031A74
	internal override object get_DtdInfo() { }

	// RVA: 0x7031AC4
	internal object ValidateDefaultAttributeOnUse(object defaultAttribute, object coreReader) { }

}

// Namespace: 
private enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object TopLevel;
	public const object Document;
	public const object Element;
	public const object Content;
	public const object B64Content;
	public const object B64Attribute;
	public const object AfterRootEle;
	public const object Attribute;
	public const object SpecialAttr;
	public const object EndDocument;
	public const object RootLevelAttr;
	public const object RootLevelSpecAttr;
	public const object RootLevelB64Attr;
	public const object AfterRootLevelAttr;
	public const object Closed;
	public const object Error;
	public const object StartContent;
	public const object StartContentEle;
	public const object StartContentB64;
	public const object StartDoc;
	public const object StartDocEle;
	public const object EndAttrSEle;
	public const object EndAttrEEle;
	public const object EndAttrSCont;
	public const object EndAttrSAttr;
	public const object PostB64Cont;
	public const object PostB64Attr;
	public const object PostB64RootAttr;
	public const object StartFragEle;
	public const object StartFragCont;
	public const object StartFragB64;
	public const object StartRootLevelAttr;
}

// Namespace: 
private enum Token
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object StartDocument;
	public const object EndDocument;
	public const object PI;
	public const object Comment;
	public const object Dtd;
	public const object StartElement;
	public const object EndElement;
	public const object StartAttribute;
	public const object EndAttribute;
	public const object Text;
	public const object CData;
	public const object AtomicValue;
	public const object Base64;
	public const object RawData;
	public const object Whitespace;
}

// Namespace: 
private class NamespaceResolverProxy
{

	// Fields
	private object wfWriter; // 0x8

	// Methods

	// RVA: 0x70321A0
	internal object .ctor(object wfWriter) { }

	// RVA: 0x703958C
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x70395CC
	private object System.Xml.IXmlNamespaceResolver.LookupNamespace(object prefix) { }

	// RVA: 0x70395EC
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

}

// Namespace: 
private struct ElementScope
{

	// Fields
	internal object prevNSTop; // 0xFFFFFFFFFFFFFFF8
	internal object prefix; // 0x0
	internal object localName; // 0x8
	internal object namespaceUri; // 0x10
	internal object xmlSpace; // 0x18
	internal object xmlLang; // 0x20

	// Methods

	// RVA: 0x70321DC
	internal object Set(object prefix, object localName, object namespaceUri, object prevNSTop) { }

	// RVA: 0x7033DDC
	internal object WriteEndElement(object rawWriter) { }

	// RVA: 0x70341D8
	internal object WriteFullEndElement(object rawWriter) { }

}

// Namespace: 
private enum NamespaceKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Written;
	public const object NeedToWrite;
	public const object Implied;
	public const object Special;
}

// Namespace: 
private struct Namespace
{

	// Fields
	internal object prefix; // 0xFFFFFFFFFFFFFFF8
	internal object namespaceUri; // 0x0
	internal object kind; // 0x8
	internal object prevNsIndex; // 0xC

	// Methods

	// RVA: 0x70321CC
	internal object Set(object prefix, object namespaceUri, object kind) { }

	// RVA: 0x7038AF4
	internal object WriteDecl(object writer, object rawWriter) { }

}

// Namespace: 
private struct AttrName
{

	// Fields
	internal object prefix; // 0xFFFFFFFFFFFFFFF8
	internal object namespaceUri; // 0x0
	internal object localName; // 0x8
	internal object prev; // 0x10

	// Methods

	// RVA: 0x7039B10
	internal object Set(object prefix, object localName, object namespaceUri) { }

	// RVA: 0x7039B30
	internal object IsDuplicate(object prefix, object localName, object namespaceUri) { }

}

// Namespace: 
private enum SpecialAttribute
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object No;
	public const object DefaultXmlns;
	public const object PrefixedXmlns;
	public const object XmlSpace;
	public const object XmlLang;
}

// Namespace: 
private enum ItemType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object EntityRef;
	public const object CharEntity;
	public const object SurrogateCharEntity;
	public const object Whitespace;
	public const object String;
	public const object StringChars;
	public const object Raw;
	public const object RawChars;
	public const object ValueString;
}

// Namespace: 
private class Item
{

	// Fields
	internal object type; // 0x8
	internal object data; // 0x10

	// Methods

	// RVA: 0x703B110
	internal object .ctor() { }

	// RVA: 0x703B118
	internal object Set(object type, object data) { }

}

// Namespace: 
private class BufferChunk
{

	// Fields
	internal object buffer; // 0x8
	internal object index; // 0x10
	internal object count; // 0x14

	// Methods

	// RVA: 0x703A484
	internal object .ctor(object buffer, object index, object count) { }

}

// Namespace: 
private class AttributeValueCache
{

	// Fields
	private object stringValue; // 0x8
	private object singleStringValue; // 0x10
	private object items; // 0x18
	private object firstItem; // 0x20
	private object lastItem; // 0x24

	// Properties
	internal object StringValue { get; }

	// Methods

	// RVA: 0x7039C18
	internal object get_StringValue() { }

	// RVA: 0x7039C7C
	internal object WriteEntityRef(object name) { }

	// RVA: 0x703A094
	internal object WriteCharEntity(object ch) { }

	// RVA: 0x703A164
	internal object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x703A274
	internal object WriteWhitespace(object ws) { }

	// RVA: 0x703A2F8
	internal object WriteString(object text) { }

	// RVA: 0x703A39C
	internal object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x703A4C4
	internal object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x703A5AC
	internal object WriteRaw(object data) { }

	// RVA: 0x703A630
	internal object WriteValue(object value) { }

	// RVA: 0x703A6B4
	internal object Replay(object writer) { }

	// RVA: 0x703ABEC
	internal object Trim() { }

	// RVA: 0x703B0DC
	internal object Clear() { }

	// RVA: 0x7039EB0
	private object StartComplexValue() { }

	// RVA: 0x7039F00
	private object AddItem(object type, object data) { }

	// RVA: 0x703B124
	public object .ctor() { }

}

// Namespace: System.Xml
internal class XmlWellFormedWriter
{

	// Fields
	private object writer; // 0x10
	private object rawWriter; // 0x18
	private object predefinedNamespaces; // 0x20
	private object nsStack; // 0x28
	private object nsTop; // 0x30
	private object nsHashtable; // 0x38
	private object useNsHashtable; // 0x40
	private object elemScopeStack; // 0x48
	private object elemTop; // 0x50
	private object attrStack; // 0x58
	private object attrCount; // 0x60
	private object attrHashTable; // 0x68
	private object specAttr; // 0x70
	private object attrValueCache; // 0x78
	private object curDeclPrefix; // 0x80
	private object stateTable; // 0x88
	private object currentState; // 0x90
	private object checkCharacters; // 0x94
	private object omitDuplNamespaces; // 0x95
	private object writeEndDocumentOnClose; // 0x96
	private object conformanceLevel; // 0x98
	private object dtdWritten; // 0x9C
	private object xmlDeclFollows; // 0x9D
	private object xmlCharType; // 0xA0
	private object hasher; // 0xA8
	internal static readonly object stateName; // 0x0
	internal static readonly object tokenName; // 0x8
	private static object state2WriteState; // 0x10
	private static readonly object StateTableDocument; // 0x18
	private static readonly object StateTableAuto; // 0x20

	// Properties
	public override object WriteState { get; }
	internal object RawWriter { get; }
	private object SaveAttrValue { get; }
	private object InBase64 { get; }
	private object IsClosedOrErrorState { get; }

	// Methods

	// RVA: 0x7031D60
	internal object .ctor(object writer, object settings) { }

	// RVA: 0x70321F8
	public override object get_WriteState() { }

	// RVA: 0x70322A0
	public override object WriteStartDocument() { }

	// RVA: 0x70324C0
	public override object WriteStartDocument(object standalone) { }

	// RVA: 0x70324E8
	public override object WriteEndDocument() { }

	// RVA: 0x7032ADC
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x7032FE4
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x7033B50
	public override object WriteEndElement() { }

	// RVA: 0x7033F4C
	public override object WriteFullEndElement() { }

	// RVA: 0x7034244
	public override object WriteStartAttribute(object prefix, object localName, object namespaceName) { }

	// RVA: 0x7035080
	public override object WriteEndAttribute() { }

	// RVA: 0x7036094
	public override object WriteCData(object text) { }

	// RVA: 0x70361CC
	public override object WriteComment(object text) { }

	// RVA: 0x7036304
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x7036620
	public override object WriteEntityRef(object name) { }

	// RVA: 0x70367D8
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x70369B8
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x7036BA4
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x7036DA0
	public override object WriteString(object text) { }

	// RVA: 0x7036ED4
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x7037184
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x7037434
	public override object WriteRaw(object data) { }

	// RVA: 0x7037568
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x70377DC
	public override object Close() { }

	// RVA: 0x7037B88
	public override object Flush() { }

	// RVA: 0x7037C68
	public override object LookupPrefix(object ns) { }

	// RVA: 0x7037F4C
	public override object WriteValue(object value) { }

	// RVA: 0x7038090
	public override object WriteBinHex(object buffer, object index, object count) { }

	// RVA: 0x70381D4
	internal object get_RawWriter() { }

	// RVA: 0x70367C8
	private object get_SaveAttrValue() { }

	// RVA: 0x7037A1C
	private object get_InBase64() { }

	// RVA: 0x7034AE4
	private object SetSpecialAttribute(object special) { }

	// RVA: 0x70322A8
	private object WriteStartDocumentImpl(object standalone) { }

	// RVA: 0x70381DC
	private object StartFragment() { }

	// RVA: 0x70336C8
	private object PushNamespaceImplicit(object prefix, object ns) { }

	// RVA: 0x7035B08
	private object PushNamespaceExplicit(object prefix, object ns) { }

	// RVA: 0x7038300
	private object AddNamespace(object prefix, object ns, object kind) { }

	// RVA: 0x70385D4
	private object AddToNamespaceHashtable(object namespaceIndex) { }

	// RVA: 0x70381E8
	private object LookupNamespaceIndex(object prefix) { }

	// RVA: 0x7033E48
	private object PopNamespaces(object indexFrom, object indexTo) { }

	// RVA: 0x7038490
	private static object DupAttrException(object prefix, object localName) { }

	// RVA: 0x7032688
	private object AdvanceState(object token) { }

	// RVA: 0x70389F8
	private object StartElementContent() { }

	// RVA: 0x70386F4
	private static object GetStateName(object state) { }

	// RVA: 0x7033550
	internal object LookupNamespace(object prefix) { }

	// RVA: 0x7034CD0
	private object LookupLocalNamespace(object prefix) { }

	// RVA: 0x7034B8C
	private object GeneratePrefix() { }

	// RVA: 0x7033424
	private object CheckNCName(object ncname) { }

	// RVA: 0x7038CD8
	private static object InvalidCharsException(object name, object badCharIndex) { }

	// RVA: 0x70387A8
	private object ThrowInvalidStateTransition(object token, object currentState) { }

	// RVA: 0x70381C4
	private object get_IsClosedOrErrorState() { }

	// RVA: 0x7034DD0
	private object AddAttribute(object prefix, object localName, object namespaceName) { }

	// RVA: 0x7038E00
	private object AddToAttrHashTable(object attributeIndex) { }

	// RVA: 0x7038FA4
	private static object .cctor() { }

}

// Namespace: System.Xml
public enum WriteState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object Prolog;
	public const object Element;
	public const object Attribute;
	public const object Content;
	public const object Closed;
	public const object Error;
}

// Namespace: System.Xml
public abstract class XmlWriter
{

	// Fields
	private object writeNodeBuffer; // 0x8

	// Properties
	public abstract object WriteState { get; }

	// Methods

	// RVA: -1
	public abstract object WriteStartDocument() { }

	// RVA: -1
	public abstract object WriteStartDocument(object standalone) { }

	// RVA: -1
	public abstract object WriteEndDocument() { }

	// RVA: -1
	public abstract object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x703B198
	public object WriteStartElement(object localName, object ns) { }

	// RVA: -1
	public abstract object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: -1
	public abstract object WriteEndElement() { }

	// RVA: -1
	public abstract object WriteFullEndElement() { }

	// RVA: 0x703B1F4
	public object WriteAttributeString(object localName, object ns, object value) { }

	// RVA: 0x703B2A4
	public object WriteAttributeString(object localName, object value) { }

	// RVA: 0x703B350
	public object WriteAttributeString(object prefix, object localName, object ns, object value) { }

	// RVA: -1
	public abstract object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: -1
	public abstract object WriteEndAttribute() { }

	// RVA: -1
	public abstract object WriteCData(object text) { }

	// RVA: -1
	public abstract object WriteComment(object text) { }

	// RVA: -1
	public abstract object WriteProcessingInstruction(object name, object text) { }

	// RVA: -1
	public abstract object WriteEntityRef(object name) { }

	// RVA: -1
	public abstract object WriteCharEntity(object ch) { }

	// RVA: -1
	public abstract object WriteWhitespace(object ws) { }

	// RVA: -1
	public abstract object WriteString(object text) { }

	// RVA: -1
	public abstract object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: -1
	public abstract object WriteChars(object buffer, object index, object count) { }

	// RVA: -1
	public abstract object WriteRaw(object buffer, object index, object count) { }

	// RVA: -1
	public abstract object WriteRaw(object data) { }

	// RVA: -1
	public abstract object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x703B40C
	public virtual object WriteBinHex(object buffer, object index, object count) { }

	// RVA: -1
	public abstract object get_WriteState() { }

	// RVA: 0x703B428
	public virtual object Close() { }

	// RVA: -1
	public abstract object Flush() { }

	// RVA: -1
	public abstract object LookupPrefix(object ns) { }

	// RVA: 0x703B42C
	public virtual object WriteValue(object value) { }

	// RVA: 0x703B480
	public virtual object WriteAttributes(object reader, object defattr) { }

	// RVA: 0x703B884
	public virtual object WriteNode(object reader, object defattr) { }

	// RVA: 0x703C014
	public object WriteElementString(object localName, object ns, object value) { }

	// RVA: 0x703C0CC
	public object Dispose() { }

	// RVA: 0x703C114
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x703C194
	public static object Create(object output, object settings) { }

	// RVA: 0x703C854
	public static object Create(object output, object settings) { }

	// RVA: 0x703CCC0
	protected object .ctor() { }

}

// Namespace: System.Xml
public enum XmlOutputMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Xml;
	public const object Html;
	public const object Text;
	public const object AutoDetect;
}

// Namespace: System.Xml
internal enum TriState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object False;
	public const object True;
}

// Namespace: System.Xml
internal enum XmlStandalone
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Omit;
	public const object Yes;
	public const object No;
}

// Namespace: System.Xml
public sealed class XmlWriterSettings
{

	// Fields
	private object useAsync; // 0x8
	private object encoding; // 0x10
	private object omitXmlDecl; // 0x18
	private object newLineHandling; // 0x1C
	private object newLineChars; // 0x20
	private object indent; // 0x28
	private object indentChars; // 0x30
	private object newLineOnAttributes; // 0x38
	private object closeOutput; // 0x39
	private object namespaceHandling; // 0x3C
	private object conformanceLevel; // 0x40
	private object checkCharacters; // 0x44
	private object writeEndDocumentOnClose; // 0x45
	private object outputMethod; // 0x48
	private object cdataSections; // 0x50
	private object doNotEscapeUriAttributes; // 0x58
	private object mergeCDataSections; // 0x59
	private object mediaType; // 0x60
	private object docTypeSystem; // 0x68
	private object docTypePublic; // 0x70
	private object standalone; // 0x78
	private object autoXmlDecl; // 0x7C
	private object isReadOnly; // 0x7D

	// Properties
	public object Async { get; }
	public object Encoding { get; set; }
	public object OmitXmlDeclaration { get; set; }
	public object NewLineHandling { get; set; }
	public object NewLineChars { get; set; }
	public object Indent { get; set; }
	public object IndentChars { get; set; }
	public object NewLineOnAttributes { get; }
	public object CloseOutput { get; }
	public object ConformanceLevel { get; set; }
	public object CheckCharacters { get; }
	public object NamespaceHandling { get; set; }
	public object WriteEndDocumentOnClose { get; }
	public object OutputMethod { get; set; }
	internal object CDataSectionElements { get; }
	public object DoNotEscapeUriAttributes { get; }
	internal object MergeCDataSections { get; }
	internal object MediaType { get; }
	internal object DocTypeSystem { get; }
	internal object DocTypePublic { get; }
	internal object Standalone { get; }
	internal object AutoXmlDeclaration { get; }
	internal object IndentInternal { get; }
	internal object IsQuerySpecific { get; }
	internal object ReadOnly { set; }

	// Methods

	// RVA: 0x703C26C
	public object .ctor() { }

	// RVA: 0x703CDBC
	public object get_Async() { }

	// RVA: 0x703CDC4
	public object get_Encoding() { }

	// RVA: 0x703CDCC
	public object set_Encoding(object value) { }

	// RVA: 0x703CEE4
	public object get_OmitXmlDeclaration() { }

	// RVA: 0x703CEEC
	public object set_OmitXmlDeclaration(object value) { }

	// RVA: 0x703CF4C
	public object get_NewLineHandling() { }

	// RVA: 0x703CF54
	public object set_NewLineHandling(object value) { }

	// RVA: 0x703D004
	public object get_NewLineChars() { }

	// RVA: 0x703D00C
	public object set_NewLineChars(object value) { }

	// RVA: 0x703D0B8
	public object get_Indent() { }

	// RVA: 0x703D0C8
	public object set_Indent(object value) { }

	// RVA: 0x703D138
	public object get_IndentChars() { }

	// RVA: 0x703D140
	public object set_IndentChars(object value) { }

	// RVA: 0x703D1EC
	public object get_NewLineOnAttributes() { }

	// RVA: 0x703D1F4
	public object get_CloseOutput() { }

	// RVA: 0x703D1FC
	public object get_ConformanceLevel() { }

	// RVA: 0x703D204
	public object set_ConformanceLevel(object value) { }

	// RVA: 0x703D2B4
	public object get_CheckCharacters() { }

	// RVA: 0x703D2BC
	public object get_NamespaceHandling() { }

	// RVA: 0x703D2C4
	public object set_NamespaceHandling(object value) { }

	// RVA: 0x703D374
	public object get_WriteEndDocumentOnClose() { }

	// RVA: 0x703D37C
	public object get_OutputMethod() { }

	// RVA: 0x703D384
	internal object set_OutputMethod(object value) { }

	// RVA: 0x703D38C
	public object Clone() { }

	// RVA: 0x703D468
	internal object get_CDataSectionElements() { }

	// RVA: 0x703D470
	public object get_DoNotEscapeUriAttributes() { }

	// RVA: 0x703D478
	internal object get_MergeCDataSections() { }

	// RVA: 0x703D480
	internal object get_MediaType() { }

	// RVA: 0x703D488
	internal object get_DocTypeSystem() { }

	// RVA: 0x703D490
	internal object get_DocTypePublic() { }

	// RVA: 0x703D498
	internal object get_Standalone() { }

	// RVA: 0x703D4A0
	internal object get_AutoXmlDeclaration() { }

	// RVA: 0x703D4A8
	internal object get_IndentInternal() { }

	// RVA: 0x703D4B0
	internal object get_IsQuerySpecific() { }

	// RVA: 0x703C2F4
	internal object CreateWriter(object output) { }

	// RVA: 0x703C92C
	internal object CreateWriter(object output) { }

	// RVA: 0x703D554
	internal object set_ReadOnly(object value) { }

	// RVA: 0x703CE2C
	private object CheckReadOnly(object propertyName) { }

	// RVA: 0x703CCC8
	private object Initialize() { }

}

// Namespace: 
private enum CachingReaderState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Init;
	public const object Record;
	public const object Replay;
	public const object ReaderClosed;
	public const object Error;
}

// Namespace: System.Xml
internal class XsdCachingReader
{

	// Fields
	private object coreReader; // 0x8
	private object coreReaderNameTable; // 0x10
	private object contentEvents; // 0x18
	private object attributeEvents; // 0x20
	private object cachedNode; // 0x28
	private object cacheState; // 0x30
	private object contentIndex; // 0x34
	private object attributeCount; // 0x38
	private object returnOriginalStringValues; // 0x3C
	private object cacheHandler; // 0x40
	private object currentAttrIndex; // 0x48
	private object currentContentIndex; // 0x4C
	private object readAhead; // 0x50
	private object lineInfo; // 0x58
	private object textNode; // 0x60

	// Properties
	public override object Settings { get; }
	public override object NodeType { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object IsDefault { get; }
	public override object QuoteChar { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object AttributeCount { get; }
	public override object EOF { get; }
	public override object ReadState { get; }
	public override object NameTable { get; }
	private object System.Xml.IXmlLineInfo.LineNumber { get; }
	private object System.Xml.IXmlLineInfo.LinePosition { get; }

	// Methods

	// RVA: 0x703D55C
	internal object .ctor(object reader, object lineInfo, object handlerMethod) { }

	// RVA: 0x703D61C
	private object Init() { }

	// RVA: 0x703DCD4
	internal object Reset(object reader) { }

	// RVA: 0x703DCDC
	public override object get_Settings() { }

	// RVA: 0x703DD28
	public override object get_NodeType() { }

	// RVA: 0x703DD4C
	public override object get_Name() { }

	// RVA: 0x703DD78
	public override object get_LocalName() { }

	// RVA: 0x703DD9C
	public override object get_NamespaceURI() { }

	// RVA: 0x703DDC0
	public override object get_Prefix() { }

	// RVA: 0x703DDE4
	public override object get_Value() { }

	// RVA: 0x703DE38
	public override object get_Depth() { }

	// RVA: 0x703DE5C
	public override object get_BaseURI() { }

	// RVA: 0x703DEAC
	public override object get_IsEmptyElement() { }

	// RVA: 0x703DEB4
	public override object get_IsDefault() { }

	// RVA: 0x703DEBC
	public override object get_QuoteChar() { }

	// RVA: 0x703DF0C
	public override object get_XmlSpace() { }

	// RVA: 0x703DF5C
	public override object get_XmlLang() { }

	// RVA: 0x703DFAC
	public override object get_AttributeCount() { }

	// RVA: 0x703DFB4
	public override object GetAttribute(object name) { }

	// RVA: 0x703E270
	public override object GetAttribute(object name, object namespaceURI) { }

	// RVA: 0x703E408
	public override object GetAttribute(object i) { }

	// RVA: 0x703E4B8
	public override object MoveToAttribute(object name) { }

	// RVA: 0x703E570
	public override object MoveToAttribute(object i) { }

	// RVA: 0x703E614
	public override object MoveToFirstAttribute() { }

	// RVA: 0x703E660
	public override object MoveToNextAttribute() { }

	// RVA: 0x703E6C0
	public override object MoveToElement() { }

	// RVA: 0x703E750
	public override object Read() { }

	// RVA: 0x703EC34
	internal object RecordTextNode(object textValue, object originalStringValue, object depth, object lineNo, object linePos) { }

	// RVA: 0x703ECB8
	internal object SwitchTextNodeAndEndElement(object textValue, object originalStringValue) { }

	// RVA: 0x703EE20
	internal object RecordEndElementNode() { }

	// RVA: 0x703F000
	public override object get_EOF() { }

	// RVA: 0x703F06C
	public override object Close() { }

	// RVA: 0x703F0CC
	public override object get_ReadState() { }

	// RVA: 0x703F11C
	public override object Skip() { }

	// RVA: 0x703F338
	public override object get_NameTable() { }

	// RVA: 0x703F340
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x703F398
	public override object ResolveEntity() { }

	// RVA: 0x703F3D8
	public override object ReadAttributeValue() { }

	// RVA: 0x703F534
	private object System.Xml.IXmlLineInfo.HasLineInfo() { }

	// RVA: 0x703F53C
	private object System.Xml.IXmlLineInfo.get_LineNumber() { }

	// RVA: 0x703F560
	private object System.Xml.IXmlLineInfo.get_LinePosition() { }

	// RVA: 0x703F584
	internal object SetToReplayMode() { }

	// RVA: 0x703F5D8
	internal object GetCoreReader() { }

	// RVA: 0x703F5E0
	internal object GetLineInfo() { }

	// RVA: 0x703EC24
	private object ClearAttributesInfo() { }

	// RVA: 0x703F5E8
	private object AddAttribute(object attIndex) { }

	// RVA: 0x703D870
	private object AddContent(object nodeType) { }

	// RVA: 0x703DA0C
	private object RecordAttributes() { }

	// RVA: 0x703E06C
	private object GetAttributeIndexWithoutPrefix(object name) { }

	// RVA: 0x703E184
	private object GetAttributeIndexWithPrefix(object name) { }

	// RVA: 0x703F4A0
	private object CreateDummyTextNode(object attributeValue, object depth) { }

}

// Namespace: System.Xml
internal sealed class CachingEventHandler
{

	// Methods

	// RVA: 0x703FA64
	public object .ctor(object object, object method) { }

	// RVA: 0x703FB80
	public virtual object Invoke(object cachingReader) { }

}

// Namespace: System.Xml
internal class AttributePSVIInfo
{

	// Fields
	internal object localName; // 0x8
	internal object namespaceUri; // 0x10
	internal object typedAttributeValue; // 0x18
	internal object attributeSchemaInfo; // 0x20

	// Methods

	// RVA: 0x703FB94
	internal object .ctor() { }

	// RVA: 0x703FC04
	internal object Reset() { }

}

// Namespace: 
private enum ValidatingReaderState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Init;
	public const object Read;
	public const object OnDefaultAttribute;
	public const object OnReadAttributeValue;
	public const object OnAttribute;
	public const object ClearAttributes;
	public const object ParseInlineSchema;
	public const object ReadAhead;
	public const object OnReadBinaryContent;
	public const object ReaderClosed;
	public const object EOF;
	public const object Error;
}

// Namespace: System.Xml
internal class XsdValidatingReader
{

	// Fields
	private object coreReader; // 0x8
	private object coreReaderNSResolver; // 0x10
	private object thisNSResolver; // 0x18
	private object validator; // 0x20
	private object xmlResolver; // 0x28
	private object validationEvent; // 0x30
	private object validationState; // 0x38
	private object valueGetter; // 0x40
	private object nsManager; // 0x48
	private object manageNamespaces; // 0x50
	private object processInlineSchema; // 0x51
	private object replayCache; // 0x52
	private object cachedNode; // 0x58
	private object attributePSVI; // 0x60
	private object attributeCount; // 0x68
	private object coreReaderAttributeCount; // 0x6C
	private object currentAttrIndex; // 0x70
	private object attributePSVINodes; // 0x78
	private object defaultAttributes; // 0x80
	private object inlineSchemaParser; // 0x88
	private object atomicValue; // 0x90
	private object xmlSchemaInfo; // 0x98
	private object originalAtomicValueString; // 0xA0
	private object coreReaderNameTable; // 0xA8
	private object cachingReader; // 0xB0
	private object textNode; // 0xB8
	private object NsXmlNs; // 0xC0
	private object NsXs; // 0xC8
	private object NsXsi; // 0xD0
	private object XsiType; // 0xD8
	private object XsiNil; // 0xE0
	private object XsdSchema; // 0xE8
	private object XsiSchemaLocation; // 0xF0
	private object XsiNoNamespaceSchemaLocation; // 0xF8
	private object xmlCharType; // 0x100
	private object lineInfo; // 0x108
	private object readBinaryHelper; // 0x110
	private object savedState; // 0x118
	private static object TypeOfString; // 0x0

	// Properties
	public override object Settings { get; }
	public override object NodeType { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object IsDefault { get; }
	public override object QuoteChar { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object SchemaInfo { get; }
	public override object ValueType { get; }
	public override object AttributeCount { get; }
	public override object EOF { get; }
	public override object ReadState { get; }
	public override object NameTable { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.IsDefault { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.IsNil { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.Validity { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.MemberType { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.SchemaType { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.SchemaElement { get; }
	private object System.Xml.Schema.IXmlSchemaInfo.SchemaAttribute { get; }
	public object LineNumber { get; }
	public object LinePosition { get; }
	private object AttributeSchemaInfo { get; }

	// Methods

	// RVA: 0x703FC7C
	internal object .ctor(object reader, object xmlResolver, object readerSettings, object partialValidationType) { }

	// RVA: 0x7040538
	internal object .ctor(object reader, object xmlResolver, object readerSettings) { }

	// RVA: 0x703FE40
	private object Init() { }

	// RVA: 0x7040294
	private object SetupValidator(object readerSettings, object reader, object partialValidationType) { }

	// RVA: 0x7040540
	public override object get_Settings() { }

	// RVA: 0x7040658
	public override object get_NodeType() { }

	// RVA: 0x7040730
	public override object get_Name() { }

	// RVA: 0x70408AC
	public override object get_LocalName() { }

	// RVA: 0x7040924
	public override object get_NamespaceURI() { }

	// RVA: 0x704099C
	public override object get_Prefix() { }

	// RVA: 0x7040A14
	public override object get_Value() { }

	// RVA: 0x7040A8C
	public override object get_Depth() { }

	// RVA: 0x7040B04
	public override object get_BaseURI() { }

	// RVA: 0x7040B54
	public override object get_IsEmptyElement() { }

	// RVA: 0x7040BA4
	public override object get_IsDefault() { }

	// RVA: 0x7040C10
	public override object get_QuoteChar() { }

	// RVA: 0x7040C60
	public override object get_XmlSpace() { }

	// RVA: 0x7040CB0
	public override object get_XmlLang() { }

	// RVA: 0x7040D00
	public override object get_SchemaInfo() { }

	// RVA: 0x7040D04
	public override object get_ValueType() { }

	// RVA: 0x7040E78
	public override object get_AttributeCount() { }

	// RVA: 0x7040E80
	public override object GetAttribute(object name) { }

	// RVA: 0x7041140
	public override object GetAttribute(object name, object namespaceURI) { }

	// RVA: 0x704148C
	public override object GetAttribute(object i) { }

	// RVA: 0x70415D4
	public override object MoveToAttribute(object name) { }

	// RVA: 0x7041970
	public override object MoveToAttribute(object i) { }

	// RVA: 0x7041B84
	public override object MoveToFirstAttribute() { }

	// RVA: 0x7041D74
	public override object MoveToNextAttribute() { }

	// RVA: 0x7041F48
	public override object MoveToElement() { }

	// RVA: 0x7041FD0
	public override object Read() { }

	// RVA: 0x70426CC
	public override object get_EOF() { }

	// RVA: 0x704271C
	public override object Close() { }

	// RVA: 0x704277C
	public override object get_ReadState() { }

	// RVA: 0x70427E8
	public override object Skip() { }

	// RVA: 0x7042A40
	public override object get_NameTable() { }

	// RVA: 0x7042A48
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x7042B20
	public override object ResolveEntity() { }

	// RVA: 0x7042B60
	public override object ReadAttributeValue() { }

	// RVA: 0x7042D70
	private object System.Xml.Schema.IXmlSchemaInfo.get_IsDefault() { }

	// RVA: 0x70431C4
	private object System.Xml.Schema.IXmlSchemaInfo.get_IsNil() { }

	// RVA: 0x7043240
	private object System.Xml.Schema.IXmlSchemaInfo.get_Validity() { }

	// RVA: 0x7043358
	private object System.Xml.Schema.IXmlSchemaInfo.get_MemberType() { }

	// RVA: 0x704358C
	private object System.Xml.Schema.IXmlSchemaInfo.get_SchemaType() { }

	// RVA: 0x7043628
	private object System.Xml.Schema.IXmlSchemaInfo.get_SchemaElement() { }

	// RVA: 0x70436C4
	private object System.Xml.Schema.IXmlSchemaInfo.get_SchemaAttribute() { }

	// RVA: 0x704373C
	public object HasLineInfo() { }

	// RVA: 0x7043744
	public object get_LineNumber() { }

	// RVA: 0x7043830
	public object get_LinePosition() { }

	// RVA: 0x704391C
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x7043A30
	private object System.Xml.IXmlNamespaceResolver.LookupNamespace(object prefix) { }

	// RVA: 0x7043B48
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

	// RVA: 0x7043C60
	private object GetStringValue() { }

	// RVA: 0x7040E54
	private object get_AttributeSchemaInfo() { }

	// RVA: 0x7042294
	private object ProcessReaderEvent() { }

	// RVA: 0x7043CAC
	private object ProcessElementEvent() { }

	// RVA: 0x704450C
	private object ProcessEndElementEvent() { }

	// RVA: 0x7044844
	private object ValidateAttributes() { }

	// RVA: 0x7042664
	private object ClearAttributesInfo() { }

	// RVA: 0x70416D4
	private object GetAttributePSVI(object name) { }

	// RVA: 0x7044F1C
	private object GetAttributePSVI(object localName, object ns) { }

	// RVA: 0x7040F34
	private object GetDefaultAttribute(object name, object updatePosition) { }

	// RVA: 0x70412C8
	private object GetDefaultAttribute(object attrLocalName, object ns, object updatePosition) { }

	// RVA: 0x7044CF4
	private object AddAttributePSVI(object attIndex) { }

	// RVA: 0x70447F8
	private object IsXSDRoot(object localName, object ns) { }

	// RVA: 0x70424E4
	private object ProcessInlineSchema() { }

	// RVA: 0x7044FF0
	private object ReadAheadForMemberType() { }

	// RVA: 0x7042E70
	private object GetIsDefault() { }

	// RVA: 0x7043450
	private object GetMemberType() { }

	// RVA: 0x7044C04
	private object GetCachingReader() { }

	// RVA: 0x7042CDC
	internal object CreateDummyTextNode(object attributeValue, object depth) { }

	// RVA: 0x7045308
	internal object CachingCallBack(object cachingReader) { }

	// RVA: 0x7044B44
	private object GetOriginalAtomicValueStringOfElement() { }

}

// Namespace: System.Xml
internal sealed class DocumentXPathNavigator
{

	// Fields
	private object document; // 0x8
	private object source; // 0x10
	private object attributeIndex; // 0x18
	private object namespaceParent; // 0x20

	// Properties
	public override object NameTable { get; }
	public override object NodeType { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Name { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	private object ValueDocument { get; }
	private object ValueText { get; }
	public override object BaseURI { get; }
	public override object XmlLang { get; }
	public override object UnderlyingObject { get; }
	public override object SchemaInfo { get; }

	// Methods

	// RVA: 0x7045338
	public object .ctor(object document, object node) { }

	// RVA: 0x7045560
	public object .ctor(object other) { }

	// RVA: 0x7045610
	public override object Clone() { }

	// RVA: 0x70456F4
	public override object get_NameTable() { }

	// RVA: 0x7045748
	public override object get_NodeType() { }

	// RVA: 0x70458A0
	public override object get_LocalName() { }

	// RVA: 0x70458F0
	public override object get_NamespaceURI() { }

	// RVA: 0x7045A4C
	public override object get_Name() { }

	// RVA: 0x7045C5C
	public override object get_Prefix() { }

	// RVA: 0x7045D74
	public override object get_Value() { }

	// RVA: 0x7045E90
	private object get_ValueDocument() { }

	// RVA: 0x7045FB0
	private object get_ValueText() { }

	// RVA: 0x7046338
	public override object get_BaseURI() { }

	// RVA: 0x7046388
	public override object get_XmlLang() { }

	// RVA: 0x70463D8
	public override object get_UnderlyingObject() { }

	// RVA: 0x70463FC
	public override object MoveToAttribute(object localName, object namespaceURI) { }

	// RVA: 0x7046774
	public override object MoveToFirstAttribute() { }

	// RVA: 0x704691C
	public override object MoveToNextAttribute() { }

	// RVA: 0x7046D24
	public override object MoveToNamespace(object name) { }

	// RVA: 0x70470C4
	public override object MoveToFirstNamespace(object scope) { }

	// RVA: 0x70473A8
	private static object MoveToFirstNamespaceLocal(object attributes, object index) { }

	// RVA: 0x7047468
	private static object MoveToFirstNamespaceGlobal(object attributes, object index) { }

	// RVA: 0x7047820
	public override object MoveToNextNamespace(object scope) { }

	// RVA: 0x7047C3C
	private static object MoveToNextNamespaceLocal(object attributes, object index) { }

	// RVA: 0x7047644
	private static object MoveToNextNamespaceGlobal(object attributes, object index) { }

	// RVA: 0x7047CFC
	private object PathHasDuplicateNamespace(object top, object bottom, object localName) { }

	// RVA: 0x7047E28
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x7047EC4
	public override object MoveToNext() { }

	// RVA: 0x70483CC
	public override object MoveToFirstChild() { }

	// RVA: 0x70485CC
	public override object MoveToParent() { }

	// RVA: 0x70486E8
	public override object MoveToRoot() { }

	// RVA: 0x7048824
	public override object MoveTo(object other) { }

	// RVA: 0x70488C8
	public override object MoveToId(object id) { }

	// RVA: 0x7048944
	public override object MoveToChild(object localName, object namespaceUri) { }

	// RVA: 0x7048AE0
	public override object MoveToChild(object type) { }

	// RVA: 0x7048C58
	public override object MoveToFollowing(object localName, object namespaceUri, object end) { }

	// RVA: 0x7048FA8
	public override object MoveToFollowing(object type, object end) { }

	// RVA: 0x7049334
	public override object MoveToNext(object localName, object namespaceUri) { }

	// RVA: 0x70494F4
	public override object MoveToNext(object type) { }

	// RVA: 0x7049778
	public override object IsSamePosition(object other) { }

	// RVA: 0x7049820
	public override object IsDescendant(object other) { }

	// RVA: 0x70499A8
	public override object get_SchemaInfo() { }

	// RVA: 0x70499F8
	private static object OwnerNode(object node) { }

	// RVA: 0x7049ADC
	private static object GetDepth(object node) { }

	// RVA: 0x7049B10
	private object Compare(object node1, object node2) { }

	// RVA: 0x7049E14
	public override object ComparePosition(object other) { }

	// RVA: 0x704A1C4
	private object System.Xml.IHasXmlNode.GetNode() { }

	// RVA: 0x704A1CC
	public override object SelectDescendants(object localName, object namespaceURI, object matchSelf) { }

	// RVA: 0x704A554
	public override object SelectDescendants(object nt, object includeSelf) { }

	// RVA: 0x70453BC
	internal object ResetPosition(object node) { }

	// RVA: 0x7046C58
	private static object ResetAttributePosition(object attribute, object attributes, object index) { }

	// RVA: 0x7046B34
	private static object CheckAttributePosition(object attribute, object attributes, object index) { }

	// RVA: 0x70457A0
	private object CalibrateText() { }

	// RVA: 0x70481AC
	private object ParentNode(object node) { }

	// RVA: 0x704A744
	private object ParentNodeTail(object parent) { }

	// RVA: 0x70484E8
	private object FirstChild(object node) { }

	// RVA: 0x704A7C4
	private object FirstChildTail(object child) { }

	// RVA: 0x70462AC
	private object NextSibling(object node) { }

	// RVA: 0x704A848
	private object NextSiblingTail(object node, object sibling) { }

	// RVA: 0x704A6B8
	private object PreviousText(object node) { }

	// RVA: 0x704A98C
	private object PreviousTextTail(object node, object text) { }

	// RVA: 0x70498A0
	private static object IsDescendant(object top, object bottom) { }

	// RVA: 0x7048288
	private static object IsValidChild(object parent, object child) { }

	// RVA: 0x70480D8
	private object TextEnd(object node) { }

}

// Namespace: System.Xml
internal sealed class DocumentXPathNodeIterator_Empty
{

	// Fields
	private object nav; // 0x10

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }
	public override object Count { get; }

	// Methods

	// RVA: 0x704A438
	internal object .ctor(object nav) { }

	// RVA: 0x704AB1C
	internal object .ctor(object other) { }

	// RVA: 0x704AB94
	public override object Clone() { }

	// RVA: 0x704AC48
	public override object MoveNext() { }

	// RVA: 0x704AC50
	public override object get_Current() { }

	// RVA: 0x704AC58
	public override object get_CurrentPosition() { }

	// RVA: 0x704AC60
	public override object get_Count() { }

}

// Namespace: System.Xml
internal abstract class DocumentXPathNodeIterator_ElemDescendants
{

	// Fields
	private object nav; // 0x10
	private object level; // 0x18
	private object position; // 0x1C

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }

	// Methods

	// RVA: 0x704AC68
	internal object .ctor(object nav) { }

	// RVA: 0x704AD3C
	internal object .ctor(object other) { }

	// RVA: -1
	protected abstract object Match(object node) { }

	// RVA: 0x704AE30
	public override object get_Current() { }

	// RVA: 0x704AE38
	public override object get_CurrentPosition() { }

	// RVA: 0x704AE40
	protected object SetPosition(object pos) { }

	// RVA: 0x704AE48
	public override object MoveNext() { }

}

// Namespace: System.Xml
internal class DocumentXPathNodeIterator_AllElemChildren
{

	// Methods

	// RVA: 0x704A6B4
	internal object .ctor(object nav) { }

	// RVA: 0x704B09C
	internal object .ctor(object other) { }

	// RVA: 0x704B0A0
	public override object Clone() { }

	// RVA: 0x704B104
	protected override object Match(object node) { }

}

// Namespace: System.Xml
internal sealed class DocumentXPathNodeIterator_AllElemChildren_AndSelf
{

	// Methods

	// RVA: 0x704A6B0
	internal object .ctor(object nav) { }

	// RVA: 0x704B15C
	internal object .ctor(object other) { }

	// RVA: 0x704B160
	public override object Clone() { }

	// RVA: 0x704B1C4
	public override object MoveNext() { }

}

// Namespace: System.Xml
internal class DocumentXPathNodeIterator_ElemChildren_NoLocalName
{

	// Fields
	private object nsAtom; // 0x20

	// Methods

	// RVA: 0x704A4C4
	internal object .ctor(object nav, object nsAtom) { }

	// RVA: 0x704B370
	internal object .ctor(object other) { }

	// RVA: 0x704B3AC
	public override object Clone() { }

	// RVA: 0x704B428
	protected override object Match(object node) { }

}

// Namespace: System.Xml
internal sealed class DocumentXPathNodeIterator_ElemChildren_AndSelf_NoLocalName
{

	// Methods

	// RVA: 0x704A49C
	internal object .ctor(object nav, object nsAtom) { }

	// RVA: 0x704B488
	internal object .ctor(object other) { }

	// RVA: 0x704B4C4
	public override object Clone() { }

	// RVA: 0x704B540
	public override object MoveNext() { }

}

// Namespace: System.Xml
internal class DocumentXPathNodeIterator_ElemChildren
{

	// Fields
	protected object localNameAtom; // 0x20
	protected object nsAtom; // 0x28

	// Methods

	// RVA: 0x704A520
	internal object .ctor(object nav, object localNameAtom, object nsAtom) { }

	// RVA: 0x704B6EC
	internal object .ctor(object other) { }

	// RVA: 0x704B728
	public override object Clone() { }

	// RVA: 0x704B7A4
	protected override object Match(object node) { }

}

// Namespace: System.Xml
internal sealed class DocumentXPathNodeIterator_ElemChildren_AndSelf
{

	// Methods

	// RVA: 0x704A4EC
	internal object .ctor(object nav, object localNameAtom, object nsAtom) { }

	// RVA: 0x704B848
	internal object .ctor(object other) { }

	// RVA: 0x704B884
	public override object Clone() { }

	// RVA: 0x704B900
	public override object MoveNext() { }

}

// Namespace: System.Xml
internal class DomNameTable
{

	// Fields
	private object entries; // 0x8
	private object count; // 0x10
	private object mask; // 0x14
	private object ownerDocument; // 0x18
	private object nameTable; // 0x20

	// Methods

	// RVA: 0x704BAAC
	public object .ctor(object document) { }

	// RVA: 0x704BB50
	public object GetName(object prefix, object localName, object ns, object schemaInfo) { }

	// RVA: 0x704BD10
	public object AddName(object prefix, object localName, object ns, object schemaInfo) { }

	// RVA: 0x704C054
	private object Grow() { }

}

// Namespace: System.Xml
internal class XPathNodeList
{

	// Fields
	private object list; // 0x8
	private object nodeIterator; // 0x10
	private object done; // 0x18
	private static readonly object nullparams; // 0x0

	// Properties
	public override object Count { get; }

	// Methods

	// RVA: 0x704C1B0
	public object .ctor(object nodeIterator) { }

	// RVA: 0x704C248
	public override object get_Count() { }

	// RVA: 0x704C4B4
	private object GetNode(object n) { }

	// RVA: 0x704C2C0
	internal object ReadUntil(object index) { }

	// RVA: 0x704C5D0
	public override object Item(object index) { }

	// RVA: 0x704C698
	public override object GetEnumerator() { }

	// RVA: 0x704C744
	private static object .cctor() { }

}

// Namespace: System.Xml
internal class XmlNodeListEnumerator
{

	// Fields
	private object list; // 0x8
	private object index; // 0x10
	private object valid; // 0x14

	// Properties
	public object Current { get; }

	// Methods

	// RVA: 0x704C70C
	public object .ctor(object list) { }

	// RVA: 0x704C7B8
	public object Reset() { }

	// RVA: 0x704C7C4
	public object MoveNext() { }

	// RVA: 0x704C87C
	public object get_Current() { }

}

// Namespace: System.Xml
public class XmlAttribute
{

	// Fields
	private object name; // 0x10
	private object lastChild; // 0x18

	// Properties
	internal object LocalNameHash { get; }
	internal object XmlName { get; set; }
	public override object ParentNode { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; set; }
	public override object NodeType { get; }
	public override object OwnerDocument { get; }
	public override object Value { get; set; }
	public override object SchemaInfo { get; }
	public override object InnerText { set; }
	internal override object IsContainer { get; }
	internal override object LastNode { get; set; }
	public virtual object Specified { get; }
	public virtual object OwnerElement { get; }
	public override object InnerXml { set; }
	public override object BaseURI { get; }
	internal override object XmlSpace { get; }
	internal override object XmlLang { get; }
	internal override object XPNodeType { get; }
	internal override object XPLocalName { get; }
	internal object IsNamespace { get; }

	// Methods

	// RVA: 0x704C8EC
	internal object .ctor(object name, object doc) { }

	// RVA: 0x704CB28
	internal object get_LocalNameHash() { }

	// RVA: 0x704CB4C
	protected internal object .ctor(object prefix, object localName, object namespaceURI, object doc) { }

	// RVA: 0x704CCD0
	internal object get_XmlName() { }

	// RVA: 0x704CCD8
	internal object set_XmlName(object value) { }

	// RVA: 0x704CCE0
	public override object CloneNode(object deep) { }

	// RVA: 0x704CE4C
	public override object get_ParentNode() { }

	// RVA: 0x704CE54
	public override object get_Name() { }

	// RVA: 0x704CE78
	public override object get_LocalName() { }

	// RVA: 0x704CE9C
	public override object get_NamespaceURI() { }

	// RVA: 0x704CEC0
	public override object get_Prefix() { }

	// RVA: 0x704CEE4
	public override object set_Prefix(object value) { }

	// RVA: 0x704CFD8
	public override object get_NodeType() { }

	// RVA: 0x704CFE0
	public override object get_OwnerDocument() { }

	// RVA: 0x704D004
	public override object get_Value() { }

	// RVA: 0x704D048
	public override object set_Value(object value) { }

	// RVA: 0x704D094
	public override object get_SchemaInfo() { }

	// RVA: 0x704D09C
	public override object set_InnerText(object value) { }

	// RVA: 0x704D110
	internal object PrepareOwnerElementInElementIdAttrMap() { }

	// RVA: 0x704D258
	internal object ResetOwnerElementInElementIdAttrMap(object oldInnerText) { }

	// RVA: 0x704D570
	internal override object get_IsContainer() { }

	// RVA: 0x704D578
	internal override object AppendChildForLoad(object newChild, object doc) { }

	// RVA: 0x704D868
	internal override object get_LastNode() { }

	// RVA: 0x704D870
	internal override object set_LastNode(object value) { }

	// RVA: 0x704D878
	internal override object IsValidChildType(object type) { }

	// RVA: 0x704D888
	public virtual object get_Specified() { }

	// RVA: 0x704D890
	public override object InsertBefore(object newChild, object refChild) { }

	// RVA: 0x704D938
	public override object InsertAfter(object newChild, object refChild) { }

	// RVA: 0x704D9E0
	public override object RemoveChild(object oldChild) { }

	// RVA: 0x704DA7C
	public override object PrependChild(object newChild) { }

	// RVA: 0x704DB18
	public override object AppendChild(object newChild) { }

	// RVA: 0x704DBB4
	public virtual object get_OwnerElement() { }

	// RVA: 0x704DC3C
	public override object set_InnerXml(object value) { }

	// RVA: 0x704DCE8
	public override object WriteTo(object w) { }

	// RVA: 0x704DE2C
	public override object WriteContentTo(object w) { }

	// RVA: 0x704DEE4
	public override object get_BaseURI() { }

	// RVA: 0x704DFD0
	internal override object SetParent(object node) { }

	// RVA: 0x704DFD8
	internal override object get_XmlSpace() { }

	// RVA: 0x704E090
	internal override object get_XmlLang() { }

	// RVA: 0x704E17C
	internal override object get_XPNodeType() { }

	// RVA: 0x704E1D0
	internal override object get_XPLocalName() { }

	// RVA: 0x7045A08
	internal object get_IsNamespace() { }

}

// Namespace: System.Xml
public sealed class XmlAttributeCollection
{

	// Properties
	public object ItemOf { get; }
	public object ItemOf { get; }
	public object ItemOf { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	private object System.Collections.ICollection.Count { get; }

	// Methods

	// RVA: 0x704E29C
	internal object .ctor(object parent) { }

	// RVA: 0x704661C
	public object get_ItemOf(object i) { }

	// RVA: 0x704E2A4
	public object get_ItemOf(object name) { }

	// RVA: 0x704E3F8
	public object get_ItemOf(object localName, object namespaceURI) { }

	// RVA: 0x704E598
	internal object FindNodeOffsetNS(object node) { }

	// RVA: 0x704E7DC
	public override object SetNamedItem(object node) { }

	// RVA: 0x704EAE4
	public object Append(object node) { }

	// RVA: 0x704EF68
	public object Remove(object node) { }

	// RVA: 0x704F014
	public object RemoveAt(object i) { }

	// RVA: 0x704F104
	public object RemoveAll() { }

	// RVA: 0x704F168
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x704F224
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x704F22C
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x704F230
	private object System.Collections.ICollection.get_Count() { }

	// RVA: 0x704F238
	internal override object AddNode(object node) { }

	// RVA: 0x704F460
	internal override object InsertNodeAt(object i, object node) { }

	// RVA: 0x704F514
	internal override object RemoveNodeAt(object i) { }

	// RVA: 0x704EC7C
	internal object Detach(object attr) { }

	// RVA: 0x704EDA0
	internal object InsertParentIntoElementIdAttrMap(object attr) { }

	// RVA: 0x704F74C
	internal object RemoveParentFromElementIdAttrMap(object attr) { }

	// RVA: 0x704F320
	internal object RemoveDuplicateAttribute(object attr) { }

	// RVA: 0x704D334
	internal object PrepareParentInElementIdAttrMap(object attrPrefix, object attrLocalName) { }

	// RVA: 0x704D478
	internal object ResetParentInElementIdAttrMap(object oldVal, object newVal) { }

	// RVA: 0x704EA38
	internal object InternalAppendAttribute(object node) { }

}

// Namespace: System.Xml
public class XmlCDataSection
{

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }
	public override object ParentNode { get; }
	internal override object XPNodeType { get; }
	internal override object IsText { get; }
	public override object PreviousText { get; }

	// Methods

	// RVA: 0x7050094
	protected internal object .ctor(object data, object doc) { }

	// RVA: 0x70500F4
	public override object get_Name() { }

	// RVA: 0x7050150
	public override object get_LocalName() { }

	// RVA: 0x70501AC
	public override object get_NodeType() { }

	// RVA: 0x70501B4
	public override object get_ParentNode() { }

	// RVA: 0x705029C
	public override object CloneNode(object deep) { }

	// RVA: 0x7050348
	public override object WriteTo(object w) { }

	// RVA: 0x70503D0
	public override object WriteContentTo(object w) { }

	// RVA: 0x70503D4
	internal override object get_XPNodeType() { }

	// RVA: 0x70503DC
	internal override object get_IsText() { }

	// RVA: 0x70503E4
	public override object get_PreviousText() { }

}

// Namespace: System.Xml
public abstract class XmlCharacterData
{

	// Fields
	private object data; // 0x18

	// Properties
	public override object Value { get; set; }
	public override object InnerText { get; set; }
	public virtual object Data { get; set; }

	// Methods

	// RVA: 0x70500C4
	protected internal object .ctor(object data, object doc) { }

	// RVA: 0x7050454
	public override object get_Value() { }

	// RVA: 0x7050498
	public override object set_Value(object value) { }

	// RVA: 0x70504E4
	public override object get_InnerText() { }

	// RVA: 0x7050524
	public override object set_InnerText(object value) { }

	// RVA: 0x705056C
	public virtual object get_Data() { }

	// RVA: 0x70505D8
	public virtual object set_Data(object value) { }

	// RVA: 0x70506E0
	internal object CheckOnData(object data) { }

	// RVA: 0x7050720
	internal object DecideXPNodeTypeForTextNodes(object node, object xnt) { }

}

// Namespace: System.Xml
internal sealed class XmlChildEnumerator
{

	// Fields
	internal object container; // 0x8
	internal object child; // 0x10
	internal object isFirst; // 0x18

	// Properties
	private object System.Collections.IEnumerator.Current { get; }
	internal object Current { get; }

	// Methods

	// RVA: 0x7050858
	internal object .ctor(object container) { }

	// RVA: 0x70508C8
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x705099C
	internal object MoveNext() { }

	// RVA: 0x7050A70
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x7050AD4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x7050AD8
	internal object get_Current() { }

}

// Namespace: System.Xml
internal class XmlChildNodes
{

	// Fields
	private object container; // 0x8

	// Properties
	public override object Count { get; }

	// Methods

	// RVA: 0x7050B48
	public object .ctor(object container) { }

	// RVA: 0x7050B74
	public override object Item(object i) { }

	// RVA: 0x7050C20
	public override object get_Count() { }

	// RVA: 0x7050CBC
	public override object GetEnumerator() { }

}

// Namespace: System.Xml
public class XmlComment
{

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }
	internal override object XPNodeType { get; }

	// Methods

	// RVA: 0x7050DFC
	protected internal object .ctor(object comment, object doc) { }

	// RVA: 0x7050E2C
	public override object get_Name() { }

	// RVA: 0x7050E88
	public override object get_LocalName() { }

	// RVA: 0x7050EE4
	public override object get_NodeType() { }

	// RVA: 0x7050EEC
	public override object CloneNode(object deep) { }

	// RVA: 0x7050F98
	public override object WriteTo(object w) { }

	// RVA: 0x7051020
	public override object WriteContentTo(object w) { }

	// RVA: 0x7051024
	internal override object get_XPNodeType() { }

}

// Namespace: System.Xml
public class XmlDeclaration
{

	// Fields
	private object version; // 0x18
	private object encoding; // 0x20
	private object standalone; // 0x28

	// Properties
	public object Version { get; set; }
	public object Encoding { get; set; }
	public object Standalone { get; set; }
	public override object Value { get; set; }
	public override object InnerText { get; set; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }

	// Methods

	// RVA: 0x705102C
	protected internal object .ctor(object version, object encoding, object standalone, object doc) { }

	// RVA: 0x70514D0
	public object get_Version() { }

	// RVA: 0x70514D8
	internal object set_Version(object value) { }

	// RVA: 0x70514E0
	public object get_Encoding() { }

	// RVA: 0x70512F0
	public object set_Encoding(object value) { }

	// RVA: 0x70514E8
	public object get_Standalone() { }

	// RVA: 0x705136C
	public object set_Standalone(object value) { }

	// RVA: 0x70514F0
	public override object get_Value() { }

	// RVA: 0x7051534
	public override object set_Value(object value) { }

	// RVA: 0x7051580
	public override object get_InnerText() { }

	// RVA: 0x7051748
	public override object set_InnerText(object value) { }

	// RVA: 0x7051960
	public override object get_Name() { }

	// RVA: 0x70519A4
	public override object get_LocalName() { }

	// RVA: 0x70519E4
	public override object get_NodeType() { }

	// RVA: 0x70519EC
	public override object CloneNode(object deep) { }

	// RVA: 0x7051A88
	public override object WriteTo(object w) { }

	// RVA: 0x7051B40
	public override object WriteContentTo(object w) { }

	// RVA: 0x7051264
	private object IsValidXmlVersion(object ver) { }

}

// Namespace: System.Xml
public class XmlDocument
{

	// Fields
	private object implementation; // 0x10
	private object domNameTable; // 0x18
	private object lastChild; // 0x20
	private object entities; // 0x28
	private object htElementIdMap; // 0x30
	private object htElementIDAttrDecl; // 0x38
	private object schemaInfo; // 0x40
	private object schemas; // 0x48
	private object reportValidity; // 0x50
	private object actualLoadingStatus; // 0x51
	private object onNodeInsertingDelegate; // 0x58
	private object onNodeInsertedDelegate; // 0x60
	private object onNodeRemovingDelegate; // 0x68
	private object onNodeRemovedDelegate; // 0x70
	private object onNodeChangingDelegate; // 0x78
	private object onNodeChangedDelegate; // 0x80
	internal object fEntRefNodesPresent; // 0x88
	internal object fCDataNodesPresent; // 0x89
	private object preserveWhitespace; // 0x8A
	private object isLoading; // 0x8B
	internal object strDocumentName; // 0x90
	internal object strDocumentFragmentName; // 0x98
	internal object strCommentName; // 0xA0
	internal object strTextName; // 0xA8
	internal object strCDataSectionName; // 0xB0
	internal object strEntityName; // 0xB8
	internal object strID; // 0xC0
	internal object strXmlns; // 0xC8
	internal object strXml; // 0xD0
	internal object strSpace; // 0xD8
	internal object strLang; // 0xE0
	internal object strEmpty; // 0xE8
	internal object strNonSignificantWhitespaceName; // 0xF0
	internal object strSignificantWhitespaceName; // 0xF8
	internal object strReservedXmlns; // 0x100
	internal object strReservedXml; // 0x108
	internal object baseURI; // 0x110
	private object resolver; // 0x118
	internal object bSetResolver; // 0x120
	internal object objLock; // 0x128
	private object namespaceXml; // 0x130
	internal static object EmptyEnumerator; // 0x0
	internal static object NotKnownSchemaInfo; // 0x8
	internal static object ValidSchemaInfo; // 0x10
	internal static object InvalidSchemaInfo; // 0x18

	// Properties
	internal object DtdSchemaInfo { get; set; }
	public override object NodeType { get; }
	public override object ParentNode { get; }
	public virtual object DocumentType { get; }
	internal virtual object Declaration { get; }
	public object Implementation { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public object DocumentElement { get; }
	internal override object IsContainer { get; }
	internal override object LastNode { get; set; }
	public override object OwnerDocument { get; }
	public object Schemas { set; }
	internal object CanReportValidity { get; }
	internal object HasSetResolver { get; }
	public virtual object XmlResolver { set; }
	public object NameTable { get; }
	public override object IsReadOnly { get; }
	internal object Entities { get; set; }
	internal object IsLoading { get; set; }
	internal object ActualLoadingStatus { get; }
	public override object InnerText { set; }
	public override object InnerXml { set; }
	internal object Version { get; }
	internal object Encoding { get; }
	internal object Standalone { get; }
	public override object SchemaInfo { get; }
	public override object BaseURI { get; }
	internal override object XPNodeType { get; }
	internal object HasEntityReferences { get; }
	internal object NamespaceXml { get; }

	// Methods

	// RVA: 0x7051B44
	public object .ctor() { }

	// RVA: 0x7052164
	public object .ctor(object nt) { }

	// RVA: 0x7051BAC
	protected internal object .ctor(object imp) { }

	// RVA: 0x70521D4
	internal object get_DtdSchemaInfo() { }

	// RVA: 0x70521DC
	internal object set_DtdSchemaInfo(object value) { }

	// RVA: 0x704CA20
	internal static object CheckName(object name) { }

	// RVA: 0x70521E4
	internal object AddXmlName(object prefix, object localName, object namespaceURI, object schemaInfo) { }

	// RVA: 0x7052204
	internal object GetXmlName(object prefix, object localName, object namespaceURI, object schemaInfo) { }

	// RVA: 0x704CB94
	internal object AddAttrXmlName(object prefix, object localName, object namespaceURI, object schemaInfo) { }

	// RVA: 0x7052224
	internal object AddIdInfo(object eleName, object attrName) { }

	// RVA: 0x7052328
	private object GetIDInfoByElement_(object eleName) { }

	// RVA: 0x704FC40
	internal object GetIDInfoByElement(object eleName) { }

	// RVA: 0x7052438
	private object GetElement(object elementList, object elem) { }

	// RVA: 0x704FC54
	internal object AddElementWithId(object id, object elem) { }

	// RVA: 0x704FED8
	internal object RemoveElementWithId(object id, object elem) { }

	// RVA: 0x7052BA8
	public override object CloneNode(object deep) { }

	// RVA: 0x7052D48
	public override object get_NodeType() { }

	// RVA: 0x7052D50
	public override object get_ParentNode() { }

	// RVA: 0x7052D58
	public virtual object get_DocumentType() { }

	// RVA: 0x7052DFC
	internal virtual object get_Declaration() { }

	// RVA: 0x7052EE4
	public object get_Implementation() { }

	// RVA: 0x7052EEC
	public override object get_Name() { }

	// RVA: 0x7052EF4
	public override object get_LocalName() { }

	// RVA: 0x7046208
	public object get_DocumentElement() { }

	// RVA: 0x7052EFC
	internal override object get_IsContainer() { }

	// RVA: 0x7052F04
	internal override object get_LastNode() { }

	// RVA: 0x7052F0C
	internal override object set_LastNode(object value) { }

	// RVA: 0x7052F14
	public override object get_OwnerDocument() { }

	// RVA: 0x7052F1C
	public object set_Schemas(object value) { }

	// RVA: 0x7052F24
	internal object get_CanReportValidity() { }

	// RVA: 0x7052F2C
	internal object get_HasSetResolver() { }

	// RVA: 0x7052F34
	internal object GetResolver() { }

	// RVA: 0x7052F3C
	public virtual object set_XmlResolver(object value) { }

	// RVA: 0x70530E8
	internal override object IsValidChildType(object type) { }

	// RVA: 0x70532C0
	private object HasNodeTypeInPrevSiblings(object nt, object refNode) { }

	// RVA: 0x70533F0
	private object HasNodeTypeInNextSiblings(object nt, object refNode) { }

	// RVA: 0x7053484
	internal override object CanInsertBefore(object newChild, object refChild) { }

	// RVA: 0x70536F4
	internal override object CanInsertAfter(object newChild, object refChild) { }

	// RVA: 0x7053870
	public object CreateAttribute(object name) { }

	// RVA: 0x705398C
	internal object SetDefaultNamespace(object prefix, object localName, object namespaceURI) { }

	// RVA: 0x7053A24
	public virtual object CreateCDataSection(object data) { }

	// RVA: 0x7053A9C
	public virtual object CreateComment(object data) { }

	// RVA: 0x7053B0C
	public virtual object CreateDocumentType(object name, object publicId, object systemId, object internalSubset) { }

	// RVA: 0x7053BA4
	public virtual object CreateDocumentFragment() { }

	// RVA: 0x7053C0C
	public object CreateElement(object name) { }

	// RVA: 0x7053CCC
	internal object AddDefaultAttributes(object elem) { }

	// RVA: 0x7054008
	private object GetSchemaElementDecl(object elem) { }

	// RVA: 0x7054184
	private object PrepareDefaultAttribute(object attdef, object attrPrefix, object attrLocalname, object attrNamespaceURI) { }

	// RVA: 0x705432C
	public virtual object CreateEntityReference(object name) { }

	// RVA: 0x705439C
	public virtual object CreateProcessingInstruction(object target, object data) { }

	// RVA: 0x705441C
	public virtual object CreateXmlDeclaration(object version, object encoding, object standalone) { }

	// RVA: 0x70544A0
	public virtual object CreateTextNode(object text) { }

	// RVA: 0x7054510
	public virtual object CreateSignificantWhitespace(object text) { }

	// RVA: 0x7054580
	public override object CreateNavigator() { }

	// RVA: 0x70545C4
	protected internal virtual object CreateNavigator(object node) { }

	// RVA: 0x7054B5C
	internal static object IsTextNode(object nt) { }

	// RVA: 0x7054840
	private object NormalizeText(object n) { }

	// RVA: 0x7054B74
	public virtual object CreateWhitespace(object text) { }

	// RVA: 0x7054BE4
	public object CreateAttribute(object qualifiedName, object namespaceURI) { }

	// RVA: 0x7054CA4
	public object CreateElement(object qualifiedName, object namespaceURI) { }

	// RVA: 0x7054D64
	public virtual object GetElementById(object elementId) { }

	// RVA: 0x70551BC
	private object ImportNodeInternal(object node, object deep) { }

	// RVA: 0x7055938
	private object ImportAttributes(object fromElem, object toElem) { }

	// RVA: 0x7052C3C
	private object ImportChildren(object fromNode, object toNode, object deep) { }

	// RVA: 0x7045724
	public object get_NameTable() { }

	// RVA: 0x7055BD0
	public virtual object CreateAttribute(object prefix, object localName, object namespaceURI) { }

	// RVA: 0x7055C68
	protected internal virtual object CreateDefaultAttribute(object prefix, object localName, object namespaceURI) { }

	// RVA: 0x7055CF0
	public virtual object CreateElement(object prefix, object localName, object namespaceURI) { }

	// RVA: 0x7055DB4
	public override object get_IsReadOnly() { }

	// RVA: 0x7055DBC
	internal object get_Entities() { }

	// RVA: 0x7055E3C
	internal object set_Entities(object value) { }

	// RVA: 0x7055E44
	internal object get_IsLoading() { }

	// RVA: 0x7055E4C
	internal object set_IsLoading(object value) { }

	// RVA: 0x7055E54
	internal object get_ActualLoadingStatus() { }

	// RVA: 0x7055E5C
	public virtual object ReadNode(object reader) { }

	// RVA: 0x7055F58
	private object SetupReader(object tr) { }

	// RVA: 0x7055FC8
	public virtual object Load(object inStream) { }

	// RVA: 0x70561BC
	public virtual object Load(object reader) { }

	// RVA: 0x7056300
	public virtual object LoadXml(object xml) { }

	// RVA: 0x7056530
	public override object set_InnerText(object value) { }

	// RVA: 0x705658C
	public override object set_InnerXml(object value) { }

	// RVA: 0x70565D8
	public virtual object Save(object w) { }

	// RVA: 0x7056924
	public override object WriteTo(object w) { }

	// RVA: 0x7056970
	public override object WriteContentTo(object xw) { }

	// RVA: 0x7056CC0
	internal override object GetEventArgs(object node, object oldParent, object newParent, object oldValue, object newValue, object action) { }

	// RVA: 0x704D784
	internal object GetInsertEventArgsForLoad(object node, object newParent) { }

	// RVA: 0x7056DBC
	internal override object BeforeEvent(object args) { }

	// RVA: 0x7056E10
	internal override object AfterEvent(object args) { }

	// RVA: 0x704F914
	internal object GetDefaultAttribute(object elem, object attrPrefix, object attrLocalname, object attrNamespaceURI) { }

	// RVA: 0x7056E64
	internal object get_Version() { }

	// RVA: 0x7056EB4
	internal object get_Encoding() { }

	// RVA: 0x70568D4
	internal object get_Standalone() { }

	// RVA: 0x7056F04
	internal object GetEntityNode(object name) { }

	// RVA: 0x7057028
	public override object get_SchemaInfo() { }

	// RVA: 0x7057248
	public override object get_BaseURI() { }

	// RVA: 0x7057250
	internal object SetBaseURI(object inBaseURI) { }

	// RVA: 0x7057258
	internal override object AppendChildForLoad(object newChild, object doc) { }

	// RVA: 0x70574DC
	internal override object get_XPNodeType() { }

	// RVA: 0x70574E4
	internal object get_HasEntityReferences() { }

	// RVA: 0x7046FEC
	internal object get_NamespaceXml() { }

	// RVA: 0x70574EC
	private static object .cctor() { }

}

// Namespace: System.Xml
public class XmlDocumentFragment
{

	// Fields
	private object lastChild; // 0x10

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }
	public override object ParentNode { get; }
	public override object OwnerDocument { get; }
	public override object InnerXml { set; }
	internal override object IsContainer { get; }
	internal override object LastNode { get; set; }
	internal override object XPNodeType { get; }

	// Methods

	// RVA: 0x70575E8
	protected internal object .ctor(object ownerDocument) { }

	// RVA: 0x7057670
	public override object get_Name() { }

	// RVA: 0x70576CC
	public override object get_LocalName() { }

	// RVA: 0x7057728
	public override object get_NodeType() { }

	// RVA: 0x7057730
	public override object get_ParentNode() { }

	// RVA: 0x7057738
	public override object get_OwnerDocument() { }

	// RVA: 0x70577B4
	public override object set_InnerXml(object value) { }

	// RVA: 0x7057B64
	public override object CloneNode(object deep) { }

	// RVA: 0x7057C40
	internal override object get_IsContainer() { }

	// RVA: 0x7057C48
	internal override object get_LastNode() { }

	// RVA: 0x7057C50
	internal override object set_LastNode(object value) { }

	// RVA: 0x7057C58
	internal override object IsValidChildType(object type) { }

	// RVA: 0x7057D24
	internal override object CanInsertAfter(object newChild, object refChild) { }

	// RVA: 0x7057DE8
	internal override object CanInsertBefore(object newChild, object refChild) { }

	// RVA: 0x7057E8C
	public override object WriteTo(object w) { }

	// RVA: 0x7057ED8
	public override object WriteContentTo(object w) { }

	// RVA: 0x70582C0
	internal override object get_XPNodeType() { }

}

// Namespace: System.Xml
public class XmlDocumentType
{

	// Fields
	private object name; // 0x18
	private object publicId; // 0x20
	private object systemId; // 0x28
	private object internalSubset; // 0x30
	private object namespaces; // 0x38
	private object entities; // 0x40
	private object notations; // 0x48
	private object schemaInfo; // 0x50

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }
	public override object IsReadOnly { get; }
	public object Entities { get; }
	public object Notations { get; }
	public object PublicId { get; }
	public object SystemId { get; }
	public object InternalSubset { get; }
	internal object ParseWithNamespaces { get; }
	internal object DtdSchemaInfo { get; set; }

	// Methods

	// RVA: 0x70582C8
	protected internal object .ctor(object name, object publicId, object systemId, object internalSubset, object doc) { }

	// RVA: 0x7058470
	public override object get_Name() { }

	// RVA: 0x7058478
	public override object get_LocalName() { }

	// RVA: 0x7058480
	public override object get_NodeType() { }

	// RVA: 0x7058488
	public override object CloneNode(object deep) { }

	// RVA: 0x7058530
	public override object get_IsReadOnly() { }

	// RVA: 0x7058538
	public object get_Entities() { }

	// RVA: 0x70585E4
	public object get_Notations() { }

	// RVA: 0x7058664
	public object get_PublicId() { }

	// RVA: 0x705866C
	public object get_SystemId() { }

	// RVA: 0x7058674
	public object get_InternalSubset() { }

	// RVA: 0x705867C
	internal object get_ParseWithNamespaces() { }

	// RVA: 0x7058684
	public override object WriteTo(object w) { }

	// RVA: 0x70586F8
	public override object WriteContentTo(object w) { }

	// RVA: 0x70586FC
	internal object get_DtdSchemaInfo() { }

	// RVA: 0x7058704
	internal object set_DtdSchemaInfo(object value) { }

}

// Namespace: System.Xml
public class XmlElement
{

	// Fields
	private object name; // 0x18
	private object attributes; // 0x20
	private object lastChild; // 0x28

	// Properties
	internal object XmlName { get; set; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; set; }
	public override object NodeType { get; }
	public override object ParentNode { get; }
	public override object OwnerDocument { get; }
	internal override object IsContainer { get; }
	public object IsEmpty { get; set; }
	internal override object LastNode { get; set; }
	public override object Attributes { get; }
	public virtual object HasAttributes { get; }
	public override object SchemaInfo { get; }
	public override object InnerXml { set; }
	public override object InnerText { get; set; }
	public override object NextSibling { get; }
	internal override object XPNodeType { get; }
	internal override object XPLocalName { get; }

	// Methods

	// RVA: 0x705870C
	internal object .ctor(object name, object empty, object doc) { }

	// RVA: 0x7058858
	protected internal object .ctor(object prefix, object localName, object namespaceURI, object doc) { }

	// RVA: 0x70588A8
	internal object get_XmlName() { }

	// RVA: 0x70588B0
	internal object set_XmlName(object value) { }

	// RVA: 0x70588B8
	public override object CloneNode(object deep) { }

	// RVA: 0x7059080
	public override object get_Name() { }

	// RVA: 0x7059304
	public override object get_LocalName() { }

	// RVA: 0x7059328
	public override object get_NamespaceURI() { }

	// RVA: 0x705934C
	public override object get_Prefix() { }

	// RVA: 0x7059370
	public override object set_Prefix(object value) { }

	// RVA: 0x7059468
	public override object get_NodeType() { }

	// RVA: 0x7059470
	public override object get_ParentNode() { }

	// RVA: 0x7059478
	public override object get_OwnerDocument() { }

	// RVA: 0x705949C
	internal override object get_IsContainer() { }

	// RVA: 0x70594A4
	internal override object AppendChildForLoad(object newChild, object doc) { }

	// RVA: 0x7058F6C
	public object get_IsEmpty() { }

	// RVA: 0x7058F7C
	public object set_IsEmpty(object value) { }

	// RVA: 0x7059794
	internal override object get_LastNode() { }

	// RVA: 0x70597A4
	internal override object set_LastNode(object value) { }

	// RVA: 0x70597AC
	internal override object IsValidChildType(object type) { }

	// RVA: 0x70597C4
	public override object get_Attributes() { }

	// RVA: 0x7059954
	public virtual object get_HasAttributes() { }

	// RVA: 0x70599B0
	public virtual object GetAttribute(object name) { }

	// RVA: 0x7059A74
	public virtual object SetAttribute(object name, object value) { }

	// RVA: 0x7059BCC
	public virtual object GetAttributeNode(object name) { }

	// RVA: 0x7059C68
	public virtual object SetAttributeNode(object newAttr) { }

	// RVA: 0x7059DE0
	public virtual object GetAttribute(object localName, object namespaceURI) { }

	// RVA: 0x7059EAC
	public virtual object SetAttribute(object localName, object namespaceURI, object value) { }

	// RVA: 0x705A08C
	public virtual object GetAttributeNode(object localName, object namespaceURI) { }

	// RVA: 0x705A13C
	public virtual object SetAttributeNode(object localName, object namespaceURI) { }

	// RVA: 0x705A2AC
	public virtual object HasAttribute(object name) { }

	// RVA: 0x705A304
	public override object WriteTo(object w) { }

	// RVA: 0x705A488
	private static object WriteElementTo(object writer, object e) { }

	// RVA: 0x705A848
	private object WriteStartElement(object w) { }

	// RVA: 0x705AA34
	public override object WriteContentTo(object w) { }

	// RVA: 0x705AAEC
	public virtual object RemoveAllAttributes() { }

	// RVA: 0x705AB58
	public override object RemoveAll() { }

	// RVA: 0x70596D8
	internal object RemoveAllChildren() { }

	// RVA: 0x705ACF4
	public override object get_SchemaInfo() { }

	// RVA: 0x705ACFC
	public override object set_InnerXml(object value) { }

	// RVA: 0x705AEEC
	public override object get_InnerText() { }

	// RVA: 0x705B078
	public override object set_InnerText(object value) { }

	// RVA: 0x705B26C
	public override object get_NextSibling() { }

	// RVA: 0x705B2D4
	internal override object SetParent(object node) { }

	// RVA: 0x705B2DC
	internal override object get_XPNodeType() { }

	// RVA: 0x705B2E4
	internal override object get_XPLocalName() { }

}

// Namespace: System.Xml
public class XmlEntity
{

	// Fields
	private object publicId; // 0x10
	private object systemId; // 0x18
	private object notationName; // 0x20
	private object name; // 0x28
	private object unparsedReplacementStr; // 0x30
	private object baseURI; // 0x38
	private object lastChild; // 0x40
	private object childrenFoliating; // 0x48

	// Properties
	public override object IsReadOnly { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object InnerText { get; set; }
	internal override object IsContainer { get; }
	internal override object LastNode { get; set; }
	public override object NodeType { get; }
	public object SystemId { get; }
	public override object InnerXml { set; }
	public override object BaseURI { get; }

	// Methods

	// RVA: 0x705B328
	internal object .ctor(object name, object strdata, object publicId, object systemId, object notationName, object doc) { }

	// RVA: 0x705B468
	public override object CloneNode(object deep) { }

	// RVA: 0x705B4C4
	public override object get_IsReadOnly() { }

	// RVA: 0x705B4CC
	public override object get_Name() { }

	// RVA: 0x705B4D4
	public override object get_LocalName() { }

	// RVA: 0x705B4DC
	public override object get_InnerText() { }

	// RVA: 0x705B4E0
	public override object set_InnerText(object value) { }

	// RVA: 0x705B53C
	internal override object get_IsContainer() { }

	// RVA: 0x705B544
	internal override object get_LastNode() { }

	// RVA: 0x705B6B8
	internal override object set_LastNode(object value) { }

	// RVA: 0x705B6C0
	internal override object IsValidChildType(object type) { }

	// RVA: 0x705B6D8
	public override object get_NodeType() { }

	// RVA: 0x705B6E0
	public object get_SystemId() { }

	// RVA: 0x705B6E8
	public override object set_InnerXml(object value) { }

	// RVA: 0x705B744
	public override object WriteTo(object w) { }

	// RVA: 0x705B748
	public override object WriteContentTo(object w) { }

	// RVA: 0x705B74C
	public override object get_BaseURI() { }

	// RVA: 0x705B754
	internal object SetBaseURI(object inBaseURI) { }

}

// Namespace: System.Xml
public class XmlEntityReference
{

	// Fields
	private object name; // 0x18
	private object lastChild; // 0x20

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object Value { get; set; }
	public override object NodeType { get; }
	public override object IsReadOnly { get; }
	internal override object IsContainer { get; }
	internal override object LastNode { get; set; }
	public override object BaseURI { get; }
	internal object ChildBaseURI { get; }

	// Methods

	// RVA: 0x705B75C
	protected internal object .ctor(object name, object doc) { }

	// RVA: 0x705B888
	public override object get_Name() { }

	// RVA: 0x705B890
	public override object get_LocalName() { }

	// RVA: 0x705B898
	public override object get_Value() { }

	// RVA: 0x705B8A0
	public override object set_Value(object value) { }

	// RVA: 0x705B8FC
	public override object get_NodeType() { }

	// RVA: 0x705B904
	public override object CloneNode(object deep) { }

	// RVA: 0x705B98C
	public override object get_IsReadOnly() { }

	// RVA: 0x705B994
	internal override object get_IsContainer() { }

	// RVA: 0x705B99C
	internal override object SetParent(object node) { }

	// RVA: 0x705C4EC
	internal override object SetParentForLoad(object node) { }

	// RVA: 0x705C538
	internal override object get_LastNode() { }

	// RVA: 0x705C540
	internal override object set_LastNode(object value) { }

	// RVA: 0x705C548
	internal override object IsValidChildType(object type) { }

	// RVA: 0x705C560
	public override object WriteTo(object w) { }

	// RVA: 0x705C5B8
	public override object WriteContentTo(object w) { }

	// RVA: 0x705C938
	public override object get_BaseURI() { }

	// RVA: 0x705C9BC
	private object ConstructBaseURI(object baseURI, object systemId) { }

	// RVA: 0x705CAAC
	internal object get_ChildBaseURI() { }

}

// Namespace: System.Xml
public enum XmlNodeChangedAction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Insert;
	public const object Remove;
	public const object Change;
}

// Namespace: System.Xml
public class XmlImplementation
{

	// Fields
	private object nameTable; // 0x8

	// Properties
	internal object NameTable { get; }

	// Methods

	// RVA: 0x705CBD8
	public object .ctor() { }

	// RVA: 0x705CD14
	public object .ctor(object nt) { }

	// RVA: 0x705CD40
	public virtual object CreateDocument() { }

	// RVA: 0x705CDA8
	internal object get_NameTable() { }

}

// Namespace: System.Xml
public abstract class XmlLinkedNode
{

	// Fields
	internal object next; // 0x10

	// Properties
	public override object PreviousSibling { get; }
	public override object NextSibling { get; }

	// Methods

	// RVA: 0x70583AC
	internal object .ctor(object doc) { }

	// RVA: 0x705CDB0
	public override object get_PreviousSibling() { }

	// RVA: 0x705CE6C
	public override object get_NextSibling() { }

}

// Namespace: System.Xml
internal class XmlLoader
{

	// Fields
	private object doc; // 0x8
	private object reader; // 0x10
	private object preserveWhitespace; // 0x18

	// Methods

	// RVA: 0x7057860
	public object .ctor() { }

	// RVA: 0x705CF0C
	internal object Load(object doc, object reader, object preserveWhitespace) { }

	// RVA: 0x705D204
	private object LoadDocSequence(object parentDoc) { }

	// RVA: 0x705DC10
	internal object ReadCurrentNode(object doc, object reader) { }

	// RVA: 0x705D2D8
	private object LoadNode(object skipOverWhitespace) { }

	// RVA: 0x705DDB0
	private object LoadAttributeNode() { }

	// RVA: 0x705ED3C
	private object LoadDefaultAttribute() { }

	// RVA: 0x705EFD0
	private object LoadAttributeValue(object parent, object direct) { }

	// RVA: 0x705E30C
	private object LoadEntityReferenceNode(object direct) { }

	// RVA: 0x705E6A4
	private object LoadDeclarationNode() { }

	// RVA: 0x705E95C
	private object LoadDocumentTypeNode() { }

	// RVA: 0x705F494
	private object LoadNodeDirect() { }

	// RVA: 0x7060EBC
	private object LoadAttributeNodeDirect() { }

	// RVA: 0x70583D0
	internal object ParseDocumentType(object dtNode) { }

	// RVA: 0x7061290
	private object ParseDocumentType(object dtNode, object bUseResolver, object resolver) { }

	// RVA: 0x705FF34
	private object LoadDocumentType(object dtdInfo, object dtNode) { }

	// RVA: 0x70617B8
	private object GetContext(object node) { }

	// RVA: 0x7057868
	internal object ParsePartialContent(object parentNode, object innerxmltext, object nt) { }

	// RVA: 0x705AE1C
	internal object LoadInnerXmlElement(object node, object innerxmltext) { }

	// RVA: 0x7062C94
	internal object LoadInnerXmlAttribute(object node, object innerxmltext) { }

	// RVA: 0x7062788
	private object RemoveDuplicateNamespace(object elem, object mgr, object fCheckElemAttrs) { }

	// RVA: 0x7062C9C
	private object EntitizeName(object name) { }

	// RVA: 0x705B5F0
	internal object ExpandEntity(object ent) { }

	// RVA: 0x705BB38
	internal object ExpandEntityReference(object eref) { }

	// RVA: 0x70623F8
	private object CreateInnerXmlReader(object xmlFragment, object nt, object context, object doc) { }

	// RVA: 0x705FBA0
	internal static object ParseXmlDeclarationValue(object strValue, object version, object encoding, object standalone) { }

	// RVA: 0x705EC20
	internal static object UnexpectedNodeType(object nodetype) { }

}

// Namespace: System.Xml
internal class XmlName
{

	// Fields
	private object prefix; // 0x8
	private object localName; // 0x10
	private object ns; // 0x18
	private object name; // 0x20
	private object hashCode; // 0x28
	internal object ownerDoc; // 0x30
	internal object next; // 0x38

	// Properties
	public object LocalName { get; }
	public object NamespaceURI { get; }
	public object Prefix { get; }
	public object HashCode { get; }
	public object OwnerDocument { get; }
	public object Name { get; }
	public virtual object Validity { get; }
	public virtual object IsDefault { get; }
	public virtual object IsNil { get; }
	public virtual object MemberType { get; }
	public virtual object SchemaType { get; }
	public virtual object SchemaElement { get; }
	public virtual object SchemaAttribute { get; }

	// Methods

	// RVA: 0x7062D18
	public static object Create(object prefix, object localName, object ns, object hashCode, object ownerDoc, object next, object schemaInfo) { }

	// RVA: 0x7062E04
	internal object .ctor(object prefix, object localName, object ns, object hashCode, object ownerDoc, object next) { }

	// RVA: 0x7063340
	public object get_LocalName() { }

	// RVA: 0x7063348
	public object get_NamespaceURI() { }

	// RVA: 0x7063350
	public object get_Prefix() { }

	// RVA: 0x7063358
	public object get_HashCode() { }

	// RVA: 0x7063360
	public object get_OwnerDocument() { }

	// RVA: 0x70590A0
	public object get_Name() { }

	// RVA: 0x7063368
	public virtual object get_Validity() { }

	// RVA: 0x7063370
	public virtual object get_IsDefault() { }

	// RVA: 0x7063378
	public virtual object get_IsNil() { }

	// RVA: 0x7063380
	public virtual object get_MemberType() { }

	// RVA: 0x7063388
	public virtual object get_SchemaType() { }

	// RVA: 0x7063390
	public virtual object get_SchemaElement() { }

	// RVA: 0x7063398
	public virtual object get_SchemaAttribute() { }

	// RVA: 0x70633A0
	public virtual object Equals(object schemaInfo) { }

	// RVA: 0x70633AC
	public static object GetHashCode(object name) { }

}

// Namespace: System.Xml
internal sealed class XmlNameEx
{

	// Fields
	private object flags; // 0x40
	private object memberType; // 0x48
	private object schemaType; // 0x50
	private object decl; // 0x58

	// Properties
	public override object Validity { get; }
	public override object IsDefault { get; }
	public override object IsNil { get; }
	public override object MemberType { get; }
	public override object SchemaType { get; }
	public override object SchemaElement { get; }
	public override object SchemaAttribute { get; }

	// Methods

	// RVA: 0x7062E68
	internal object .ctor(object prefix, object localName, object ns, object hashCode, object ownerDoc, object next, object schemaInfo) { }

	// RVA: 0x7063478
	public override object get_Validity() { }

	// RVA: 0x70634B4
	public override object get_IsDefault() { }

	// RVA: 0x70634C0
	public override object get_IsNil() { }

	// RVA: 0x70634CC
	public override object get_MemberType() { }

	// RVA: 0x70634D4
	public override object get_SchemaType() { }

	// RVA: 0x70634DC
	public override object get_SchemaElement() { }

	// RVA: 0x7063564
	public override object get_SchemaAttribute() { }

	// RVA: 0x7063424
	public object SetValidity(object value) { }

	// RVA: 0x7063438
	public object SetIsDefault(object value) { }

	// RVA: 0x7063458
	public object SetIsNil(object value) { }

	// RVA: 0x70635EC
	public override object Equals(object schemaInfo) { }

}

// Namespace: 
private class SingleObjectEnumerator
{

	// Fields
	private object loneValue; // 0x8
	private object position; // 0x10

	// Properties
	public object Current { get; }

	// Methods

	// RVA: 0x7065184
	public object .ctor(object value) { }

	// RVA: 0x70651C0
	public object get_Current() { }

	// RVA: 0x7065210
	public object MoveNext() { }

	// RVA: 0x7065228
	public object Reset() { }

}

// Namespace: 
internal struct SmallXmlNodeList
{

	// Fields
	private object field; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object Count { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x70640B8
	public object get_Count() { }

	// RVA: 0x7063BB8
	public object get_Item(object index) { }

	// RVA: 0x7064518
	public object Add(object value) { }

	// RVA: 0x70649BC
	public object RemoveAt(object index) { }

	// RVA: 0x7064D30
	public object Insert(object index, object value) { }

	// RVA: 0x7064188
	public object GetEnumerator() { }

}

// Namespace: System.Xml
public class XmlNamedNodeMap
{

	// Fields
	internal object parent; // 0x8
	internal object nodes; // 0x10

	// Properties
	public virtual object Count { get; }

	// Methods

	// RVA: 0x70585B8
	internal object .ctor(object parent) { }

	// RVA: 0x70639DC
	public virtual object GetNamedItem(object name) { }

	// RVA: 0x7063CC4
	public virtual object SetNamedItem(object node) { }

	// RVA: 0x7063FF0
	public virtual object get_Count() { }

	// RVA: 0x7064180
	public virtual object GetEnumerator() { }

	// RVA: 0x7063A90
	internal object FindNodeOffset(object name) { }

	// RVA: 0x7063DF4
	internal object FindNodeOffset(object localName, object namespaceURI) { }

	// RVA: 0x70642B4
	internal virtual object AddNode(object node) { }

	// RVA: 0x70646D0
	internal virtual object AddNodeForLoad(object node, object doc) { }

	// RVA: 0x70647D0
	internal virtual object RemoveNodeAt(object i) { }

	// RVA: 0x7063F68
	internal object ReplaceNodeAt(object i, object node) { }

	// RVA: 0x7064AC4
	internal virtual object InsertNodeAt(object i, object node) { }

}

// Namespace: System.Xml
public abstract class XmlNode
{

	// Fields
	internal object parentNode; // 0x8

	// Properties
	public abstract object Name { get; }
	public virtual object Value { get; set; }
	public abstract object NodeType { get; }
	public virtual object ParentNode { get; }
	public virtual object ChildNodes { get; }
	public virtual object PreviousSibling { get; }
	public virtual object NextSibling { get; }
	public virtual object Attributes { get; }
	public virtual object OwnerDocument { get; }
	public virtual object FirstChild { get; }
	public virtual object LastChild { get; }
	internal virtual object IsContainer { get; }
	internal virtual object LastNode { get; set; }
	public virtual object HasChildNodes { get; }
	public virtual object NamespaceURI { get; }
	public virtual object Prefix { get; set; }
	public abstract object LocalName { get; }
	public virtual object IsReadOnly { get; }
	public virtual object InnerText { get; set; }
	public virtual object InnerXml { set; }
	public virtual object SchemaInfo { get; }
	public virtual object BaseURI { get; }
	internal object Document { get; }
	internal virtual object XmlSpace { get; }
	internal virtual object XmlLang { get; }
	internal virtual object XPNodeType { get; }
	internal virtual object XPLocalName { get; }
	internal virtual object IsText { get; }
	public virtual object PreviousText { get; }

	// Methods

	// RVA: 0x7057668
	internal object .ctor() { }

	// RVA: 0x705B3E8
	internal object .ctor(object doc) { }

	// RVA: 0x7065234
	public virtual object CreateNavigator() { }

	// RVA: 0x7065320
	public object SelectSingleNode(object xpath) { }

	// RVA: 0x7065378
	public object SelectNodes(object xpath) { }

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: 0x706545C
	public virtual object get_Value() { }

	// RVA: 0x7065464
	public virtual object set_Value(object value) { }

	// RVA: -1
	public abstract object get_NodeType() { }

	// RVA: 0x706553C
	public virtual object get_ParentNode() { }

	// RVA: 0x7065690
	public virtual object get_ChildNodes() { }

	// RVA: 0x70656F8
	public virtual object get_PreviousSibling() { }

	// RVA: 0x7065700
	public virtual object get_NextSibling() { }

	// RVA: 0x7065708
	public virtual object get_Attributes() { }

	// RVA: 0x7065710
	public virtual object get_OwnerDocument() { }

	// RVA: 0x7065818
	public virtual object get_FirstChild() { }

	// RVA: 0x7065868
	public virtual object get_LastChild() { }

	// RVA: 0x70658AC
	internal virtual object get_IsContainer() { }

	// RVA: 0x70658B4
	internal virtual object get_LastNode() { }

	// RVA: 0x70658BC
	internal virtual object set_LastNode(object value) { }

	// RVA: 0x70658C0
	internal object AncestorNode(object node) { }

	// RVA: 0x706596C
	internal object IsConnected() { }

	// RVA: 0x7065A1C
	public virtual object InsertBefore(object newChild, object refChild) { }

	// RVA: 0x7066330
	public virtual object InsertAfter(object newChild, object refChild) { }

	// RVA: 0x7066BFC
	public virtual object RemoveChild(object oldChild) { }

	// RVA: 0x70671DC
	public virtual object PrependChild(object newChild) { }

	// RVA: 0x706725C
	public virtual object AppendChild(object newChild) { }

	// RVA: 0x7067A14
	internal virtual object AppendChildForLoad(object newChild, object doc) { }

	// RVA: 0x7067C8C
	internal virtual object IsValidChildType(object type) { }

	// RVA: 0x7067C94
	internal virtual object CanInsertBefore(object newChild, object refChild) { }

	// RVA: 0x7067C9C
	internal virtual object CanInsertAfter(object newChild, object refChild) { }

	// RVA: 0x7067CA4
	public virtual object get_HasChildNodes() { }

	// RVA: -1
	public abstract object CloneNode(object deep) { }

	// RVA: 0x7067CF4
	internal virtual object CopyChildren(object doc, object container, object deep) { }

	// RVA: 0x7067E04
	public virtual object get_NamespaceURI() { }

	// RVA: 0x7067E50
	public virtual object get_Prefix() { }

	// RVA: 0x7067E9C
	public virtual object set_Prefix(object value) { }

	// RVA: -1
	public abstract object get_LocalName() { }

	// RVA: 0x7067EA0
	public virtual object get_IsReadOnly() { }

	// RVA: 0x7067EE8
	internal static object HasReadOnlyParent(object n) { }

	// RVA: 0x7068030
	private object System.ICloneable.Clone() { }

	// RVA: 0x7068078
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x7058258
	public object GetEnumerator() { }

	// RVA: 0x70680E0
	private object AppendChildText(object builder) { }

	// RVA: 0x705AEF0
	public virtual object get_InnerText() { }

	// RVA: 0x70682A0
	public virtual object set_InnerText(object value) { }

	// RVA: 0x7068444
	public virtual object set_InnerXml(object value) { }

	// RVA: 0x70684A0
	public virtual object get_SchemaInfo() { }

	// RVA: 0x706851C
	public virtual object get_BaseURI() { }

	// RVA: -1
	public abstract object WriteTo(object w) { }

	// RVA: -1
	public abstract object WriteContentTo(object w) { }

	// RVA: 0x705AC38
	public virtual object RemoveAll() { }

	// RVA: 0x70686A0
	internal object get_Document() { }

	// RVA: 0x7068778
	public virtual object GetPrefixOfNamespace(object namespaceURI) { }

	// RVA: 0x7068800
	internal object GetPrefixOfNamespaceStrict(object namespaceURI) { }

	// RVA: 0x705BADC
	internal virtual object SetParent(object node) { }

	// RVA: 0x7068D5C
	internal virtual object SetParentForLoad(object node) { }

	// RVA: 0x7068D64
	internal static object SplitName(object name, object prefix, object localName) { }

	// RVA: 0x7068E48
	internal virtual object FindChild(object type) { }

	// RVA: 0x7068EFC
	internal virtual object GetEventArgs(object node, object oldParent, object newParent, object oldValue, object newValue, object action) { }

	// RVA: 0x7069088
	internal virtual object BeforeEvent(object args) { }

	// RVA: 0x7069124
	internal virtual object AfterEvent(object args) { }

	// RVA: 0x70691C0
	internal virtual object get_XmlSpace() { }

	// RVA: 0x70693AC
	internal virtual object get_XmlLang() { }

	// RVA: 0x7069514
	internal virtual object get_XPNodeType() { }

	// RVA: 0x706951C
	internal virtual object get_XPLocalName() { }

	// RVA: 0x7069568
	internal virtual object get_IsText() { }

	// RVA: 0x7069570
	public virtual object get_PreviousText() { }

	// RVA: 0x70596B8
	internal static object NestTextNodes(object prevNode, object nextNode) { }

	// RVA: 0x70662C4
	internal static object UnnestTextNodes(object prevNode, object nextNode) { }

}

// Namespace: System.Xml
public class XmlNodeChangedEventArgs
{

	// Fields
	private object action; // 0x8
	private object node; // 0x10
	private object oldParent; // 0x18
	private object newParent; // 0x20
	private object oldValue; // 0x28
	private object newValue; // 0x30

	// Properties
	public object Action { get; }

	// Methods

	// RVA: 0x7069578
	public object .ctor(object node, object oldParent, object newParent, object oldValue, object newValue, object action) { }

	// RVA: 0x7069620
	public object get_Action() { }

}

// Namespace: System.Xml
public sealed class XmlNodeChangedEventHandler
{

	// Methods

	// RVA: 0x706992C
	public object .ctor(object object, object method) { }

	// RVA: 0x7069A38
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Xml
public abstract class XmlNodeList
{

	// Properties
	public abstract object Count { get; }
	public virtual object ItemOf { get; }

	// Methods

	// RVA: -1
	public abstract object Item(object index) { }

	// RVA: -1
	public abstract object get_Count() { }

	// RVA: -1
	public abstract object GetEnumerator() { }

	// RVA: 0x7069A4C
	public virtual object get_ItemOf(object i) { }

	// RVA: 0x7069A94
	private object System.IDisposable.Dispose() { }

	// RVA: 0x7069AD4
	protected virtual object PrivateDisposeNodeList() { }

	// RVA: 0x7069AD8
	protected object .ctor() { }

}

// Namespace: 
internal struct VirtualAttribute
{

	// Fields
	internal object name; // 0xFFFFFFFFFFFFFFF8
	internal object value; // 0x0

	// Methods

	// RVA: 0x7069D08
	internal object .ctor(object name, object value) { }

}

// Namespace: System.Xml
internal class XmlNodeReaderNavigator
{

	// Fields
	private object curNode; // 0x8
	private object elemNode; // 0x10
	private object logNode; // 0x18
	private object attrIndex; // 0x20
	private object logAttrIndex; // 0x24
	private object nameTable; // 0x28
	private object doc; // 0x30
	private object nAttrInd; // 0x38
	private object nDeclarationAttrCount; // 0x3C
	private object nDocTypeAttrCount; // 0x40
	private object nLogLevel; // 0x44
	private object nLogAttrInd; // 0x48
	private object bLogOnAttrVal; // 0x4C
	private object bCreatedOnAttribute; // 0x4D
	internal object decNodeAttributes; // 0x50
	internal object docTypeNodeAttributes; // 0x58
	private object bOnAttrVal; // 0x60

	// Properties
	public object NodeType { get; }
	public object NamespaceURI { get; }
	public object Name { get; }
	public object LocalName { get; }
	internal object CreatedOnAttribute { get; }
	public object Prefix { get; }
	public object Value { get; }
	public object BaseURI { get; }
	public object XmlSpace { get; }
	public object XmlLang { get; }
	public object IsEmptyElement { get; }
	public object IsDefault { get; }
	public object SchemaInfo { get; }
	public object NameTable { get; }
	public object AttributeCount { get; }
	private object IsOnDeclOrDocType { get; }
	public object Document { get; }

	// Methods

	// RVA: 0x7069AE0
	public object .ctor(object node) { }

	// RVA: 0x7069D10
	public object get_NodeType() { }

	// RVA: 0x7069D80
	public object get_NamespaceURI() { }

	// RVA: 0x7069DD0
	public object get_Name() { }

	// RVA: 0x7069F80
	public object get_LocalName() { }

	// RVA: 0x706A088
	internal object get_CreatedOnAttribute() { }

	// RVA: 0x7069F60
	private object IsLocalNameEmpty(object nt) { }

	// RVA: 0x706A090
	public object get_Prefix() { }

	// RVA: 0x706A0E0
	public object get_Value() { }

	// RVA: 0x706A600
	public object get_BaseURI() { }

	// RVA: 0x706A650
	public object get_XmlSpace() { }

	// RVA: 0x706A6A0
	public object get_XmlLang() { }

	// RVA: 0x706A6F0
	public object get_IsEmptyElement() { }

	// RVA: 0x706A7D4
	public object get_IsDefault() { }

	// RVA: 0x706A8D8
	public object get_SchemaInfo() { }

	// RVA: 0x706A928
	public object get_NameTable() { }

	// RVA: 0x706A930
	public object get_AttributeCount() { }

	// RVA: 0x706AC64
	private object CheckIndexCondition(object attributeIndex) { }

	// RVA: 0x706A480
	private object InitDecAttr() { }

	// RVA: 0x706ACD8
	public object GetDeclarationAttr(object decl, object name) { }

	// RVA: 0x706ADDC
	public object GetDeclarationAttr(object i) { }

	// RVA: 0x706AE3C
	public object GetDecAttrInd(object name) { }

	// RVA: 0x706AB48
	private object InitDocTypeAttr() { }

	// RVA: 0x706AEEC
	public object GetDocumentTypeAttr(object docType, object name) { }

	// RVA: 0x706AFB0
	public object GetDocumentTypeAttr(object i) { }

	// RVA: 0x706B010
	public object GetDocTypeAttrInd(object name) { }

	// RVA: 0x706B0C0
	private object GetAttributeFromElement(object elem, object name) { }

	// RVA: 0x706B154
	public object GetAttribute(object name) { }

	// RVA: 0x706B43C
	private object GetAttributeFromElement(object elem, object name, object ns) { }

	// RVA: 0x706B4E4
	public object GetAttribute(object name, object ns) { }

	// RVA: 0x706B80C
	public object GetAttribute(object attributeIndex) { }

	// RVA: 0x706BB70
	public object LogMove(object level) { }

	// RVA: 0x706BB94
	public object RollBackMove(object level) { }

	// RVA: 0x706BBC0
	private object get_IsOnDeclOrDocType() { }

	// RVA: 0x706BC1C
	public object ResetToAttribute(object level) { }

	// RVA: 0x706BD54
	public object ResetMove(object level, object nt) { }

	// RVA: 0x706BFB4
	public object MoveToAttribute(object name) { }

	// RVA: 0x706C2AC
	private object MoveToAttributeFromElement(object elem, object name, object ns) { }

	// RVA: 0x706C01C
	public object MoveToAttribute(object name, object namespaceURI) { }

	// RVA: 0x706C3F4
	public object MoveToAttribute(object attributeIndex) { }

	// RVA: 0x706C680
	public object MoveToNextAttribute(object level) { }

	// RVA: 0x706C9F8
	public object MoveToParent() { }

	// RVA: 0x706CA68
	public object MoveToFirstChild() { }

	// RVA: 0x706CAE0
	private object MoveToNextSibling(object node) { }

	// RVA: 0x706CB58
	public object MoveToNext() { }

	// RVA: 0x706CC08
	public object MoveToElement() { }

	// RVA: 0x706CCC4
	public object LookupNamespace(object prefix) { }

	// RVA: 0x706D0BC
	internal object DefaultLookupNamespace(object prefix) { }

	// RVA: 0x706D258
	internal object LookupPrefix(object namespaceName) { }

	// RVA: 0x706D79C
	internal object GetNamespacesInScope(object scope) { }

	// RVA: 0x706DEBC
	public object ReadAttributeValue(object level, object bResolveEntity, object nt) { }

	// RVA: 0x706E200
	public object get_Document() { }

}

// Namespace: System.Xml
public class XmlNodeReader
{

	// Fields
	private object readerNav; // 0x8
	private object nodeType; // 0x10
	private object curDepth; // 0x14
	private object readState; // 0x18
	private object fEOF; // 0x1C
	private object bResolveEntity; // 0x1D
	private object bStartFromDocument; // 0x1E
	private object bInReadBinary; // 0x1F
	private object readBinaryHelper; // 0x20

	// Properties
	public override object NodeType { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object CanResolveEntity { get; }
	public override object IsEmptyElement { get; }
	public override object IsDefault { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object SchemaInfo { get; }
	public override object AttributeCount { get; }
	public override object EOF { get; }
	public override object ReadState { get; }
	public override object HasAttributes { get; }
	public override object NameTable { get; }
	internal override object DtdInfo { get; }

	// Methods

	// RVA: 0x706E2C0
	public object .ctor(object node) { }

	// RVA: 0x706E3C4
	internal object IsInReadingStates() { }

	// RVA: 0x706E3D4
	public override object get_NodeType() { }

	// RVA: 0x706E3F0
	public override object get_Name() { }

	// RVA: 0x706E46C
	public override object get_LocalName() { }

	// RVA: 0x706E4E8
	public override object get_NamespaceURI() { }

	// RVA: 0x706E59C
	public override object get_Prefix() { }

	// RVA: 0x706E650
	public override object get_Value() { }

	// RVA: 0x706E6CC
	public override object get_Depth() { }

	// RVA: 0x706E6D4
	public override object get_BaseURI() { }

	// RVA: 0x706E72C
	public override object get_CanResolveEntity() { }

	// RVA: 0x706E734
	public override object get_IsEmptyElement() { }

	// RVA: 0x706E768
	public override object get_IsDefault() { }

	// RVA: 0x706E79C
	public override object get_XmlSpace() { }

	// RVA: 0x706E81C
	public override object get_XmlLang() { }

	// RVA: 0x706E8D0
	public override object get_SchemaInfo() { }

	// RVA: 0x706E950
	public override object get_AttributeCount() { }

	// RVA: 0x706E990
	public override object GetAttribute(object name) { }

	// RVA: 0x706E9C4
	public override object GetAttribute(object name, object namespaceURI) { }

	// RVA: 0x706EA64
	public override object GetAttribute(object attributeIndex) { }

	// RVA: 0x706EAE4
	public override object MoveToAttribute(object name) { }

	// RVA: 0x706ECE0
	public override object MoveToAttribute(object attributeIndex) { }

	// RVA: 0x706EF64
	public override object MoveToFirstAttribute() { }

	// RVA: 0x706F114
	public override object MoveToNextAttribute() { }

	// RVA: 0x706F2B4
	public override object MoveToElement() { }

	// RVA: 0x706F4A8
	public override object Read() { }

	// RVA: 0x706F4B0
	private object Read(object fSkipChildren) { }

	// RVA: 0x706F704
	private object ReadNextNode(object fSkipChildren) { }

	// RVA: 0x706FE88
	private object SetEndOfFile() { }

	// RVA: 0x706FEA0
	private object ReadAtZeroLevel(object fSkipChildren) { }

	// RVA: 0x706FC2C
	private object ReadForward(object fSkipChildren) { }

	// RVA: 0x706FC00
	private object ReSetReadingMarks() { }

	// RVA: 0x706FF94
	public override object get_EOF() { }

	// RVA: 0x706FFB4
	public override object Close() { }

	// RVA: 0x706FFC0
	public override object get_ReadState() { }

	// RVA: 0x706FFC8
	public override object Skip() { }

	// RVA: 0x706FFD0
	public override object ReadString() { }

	// RVA: 0x70700A8
	public override object get_HasAttributes() { }

	// RVA: 0x70700F8
	public override object get_NameTable() { }

	// RVA: 0x707011C
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x7070168
	public override object ResolveEntity() { }

	// RVA: 0x70701E8
	public override object ReadAttributeValue() { }

	// RVA: 0x706ECB8
	private object FinishReadBinary() { }

	// RVA: 0x7070254
	private object System.Xml.IXmlNamespaceResolver.GetNamespacesInScope(object scope) { }

	// RVA: 0x7070274
	private object System.Xml.IXmlNamespaceResolver.LookupPrefix(object namespaceName) { }

	// RVA: 0x7070294
	private object System.Xml.IXmlNamespaceResolver.LookupNamespace(object prefix) { }

	// RVA: 0x7070350
	internal override object get_DtdInfo() { }

}

// Namespace: System.Xml
public class XmlNotation
{

	// Fields
	private object publicId; // 0x10
	private object systemId; // 0x18
	private object name; // 0x20

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }
	public override object IsReadOnly { get; }
	public override object InnerXml { set; }

	// Methods

	// RVA: 0x70616D0
	internal object .ctor(object name, object publicId, object systemId, object doc) { }

	// RVA: 0x707038C
	public override object get_Name() { }

	// RVA: 0x7070394
	public override object get_LocalName() { }

	// RVA: 0x707039C
	public override object get_NodeType() { }

	// RVA: 0x70703A4
	public override object CloneNode(object deep) { }

	// RVA: 0x7070400
	public override object get_IsReadOnly() { }

	// RVA: 0x7070408
	public override object set_InnerXml(object value) { }

	// RVA: 0x7070464
	public override object WriteTo(object w) { }

	// RVA: 0x7070468
	public override object WriteContentTo(object w) { }

}

// Namespace: System.Xml
public class XmlProcessingInstruction
{

	// Fields
	private object target; // 0x18
	private object data; // 0x20

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object Value { get; set; }
	public object Data { set; }
	public override object InnerText { get; set; }
	public override object NodeType { get; }
	internal override object XPLocalName { get; }
	internal override object XPNodeType { get; }

	// Methods

	// RVA: 0x706124C
	protected internal object .ctor(object target, object data, object doc) { }

	// RVA: 0x707046C
	public override object get_Name() { }

	// RVA: 0x70704D8
	public override object get_LocalName() { }

	// RVA: 0x7070518
	public override object get_Value() { }

	// RVA: 0x7070520
	public override object set_Value(object value) { }

	// RVA: 0x7070524
	public object set_Data(object value) { }

	// RVA: 0x707062C
	public override object get_InnerText() { }

	// RVA: 0x7070634
	public override object set_InnerText(object value) { }

	// RVA: 0x7070638
	public override object get_NodeType() { }

	// RVA: 0x7070640
	public override object CloneNode(object deep) { }

	// RVA: 0x70706D4
	public override object WriteTo(object w) { }

	// RVA: 0x7070738
	public override object WriteContentTo(object w) { }

	// RVA: 0x707073C
	internal override object get_XPLocalName() { }

	// RVA: 0x707077C
	internal override object get_XPNodeType() { }

}

// Namespace: System.Xml
public class XmlSignificantWhitespace
{

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }
	public override object ParentNode { get; }
	public override object Value { get; set; }
	internal override object XPNodeType { get; }
	internal override object IsText { get; }
	public override object PreviousText { get; }

	// Methods

	// RVA: 0x70610EC
	protected internal object .ctor(object strData, object doc) { }

	// RVA: 0x7070784
	public override object get_Name() { }

	// RVA: 0x70707E0
	public override object get_LocalName() { }

	// RVA: 0x707083C
	public override object get_NodeType() { }

	// RVA: 0x7070844
	public override object get_ParentNode() { }

	// RVA: 0x7070928
	public override object CloneNode(object deep) { }

	// RVA: 0x70709D4
	public override object get_Value() { }

	// RVA: 0x7070A18
	public override object set_Value(object value) { }

	// RVA: 0x7070ABC
	public override object WriteTo(object w) { }

	// RVA: 0x7070B44
	public override object WriteContentTo(object w) { }

	// RVA: 0x7070B48
	internal override object get_XPNodeType() { }

	// RVA: 0x7070B7C
	internal override object get_IsText() { }

	// RVA: 0x7070B84
	public override object get_PreviousText() { }

}

// Namespace: System.Xml
public class XmlText
{

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }
	public override object ParentNode { get; }
	public override object Value { get; set; }
	internal override object XPNodeType { get; }
	internal override object IsText { get; }
	public override object PreviousText { get; }

	// Methods

	// RVA: 0x705F488
	internal object .ctor(object strData) { }

	// RVA: 0x705F480
	protected internal object .ctor(object strData, object doc) { }

	// RVA: 0x7070BF4
	public override object get_Name() { }

	// RVA: 0x7070C50
	public override object get_LocalName() { }

	// RVA: 0x7070CAC
	public override object get_NodeType() { }

	// RVA: 0x7070CB4
	public override object get_ParentNode() { }

	// RVA: 0x7070D9C
	public override object CloneNode(object deep) { }

	// RVA: 0x7070E48
	public override object get_Value() { }

	// RVA: 0x7070E8C
	public override object set_Value(object value) { }

	// RVA: 0x7070FA8
	public override object WriteTo(object w) { }

	// RVA: 0x7071030
	public override object WriteContentTo(object w) { }

	// RVA: 0x7071034
	internal override object get_XPNodeType() { }

	// RVA: 0x707103C
	internal override object get_IsText() { }

	// RVA: 0x7071044
	public override object get_PreviousText() { }

}

// Namespace: System.Xml
internal class XmlUnspecifiedAttribute
{

	// Fields
	private object fSpecified; // 0x20

	// Properties
	public override object Specified { get; }
	public override object InnerText { set; }

	// Methods

	// RVA: 0x7061288
	protected internal object .ctor(object prefix, object localName, object namespaceURI, object doc) { }

	// RVA: 0x70710B4
	public override object get_Specified() { }

	// RVA: 0x70710BC
	public override object CloneNode(object deep) { }

	// RVA: 0x7071288
	public override object set_InnerText(object value) { }

	// RVA: 0x70712B4
	public override object InsertBefore(object newChild, object refChild) { }

	// RVA: 0x70712E0
	public override object InsertAfter(object newChild, object refChild) { }

	// RVA: 0x707130C
	public override object RemoveChild(object oldChild) { }

	// RVA: 0x7071338
	public override object AppendChild(object newChild) { }

	// RVA: 0x7071364
	public override object WriteTo(object w) { }

	// RVA: 0x707137C
	internal object SetSpecified(object f) { }

}

// Namespace: System.Xml
public class XmlWhitespace
{

	// Properties
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NodeType { get; }
	public override object ParentNode { get; }
	public override object Value { get; set; }
	internal override object XPNodeType { get; }
	internal override object IsText { get; }
	public override object PreviousText { get; }

	// Methods

	// RVA: 0x706119C
	protected internal object .ctor(object strData, object doc) { }

	// RVA: 0x7071384
	public override object get_Name() { }

	// RVA: 0x70713E0
	public override object get_LocalName() { }

	// RVA: 0x707143C
	public override object get_NodeType() { }

	// RVA: 0x7071444
	public override object get_ParentNode() { }

	// RVA: 0x7071528
	public override object get_Value() { }

	// RVA: 0x707156C
	public override object set_Value(object value) { }

	// RVA: 0x7071610
	public override object CloneNode(object deep) { }

	// RVA: 0x70716BC
	public override object WriteTo(object w) { }

	// RVA: 0x7071744
	public override object WriteContentTo(object w) { }

	// RVA: 0x7071748
	internal override object get_XPNodeType() { }

	// RVA: 0x707177C
	internal override object get_IsText() { }

	// RVA: 0x7071784
	public override object get_PreviousText() { }

}

// Namespace: System.Xml
internal sealed class EmptyEnumerator
{

	// Properties
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x70717F4
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x70717FC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x7071800
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x707185C
	public object .ctor() { }

}

// Namespace: System.Xml
internal class HWStack
{

	// Fields
	private object stack; // 0x8
	private object growthRate; // 0x10
	private object used; // 0x14
	private object size; // 0x18
	private object limit; // 0x1C

	// Properties
	internal object Item { get; set; }
	internal object Length { get; }

	// Methods

	// RVA: 0x7071864
	internal object .ctor(object GrowthRate) { }

	// RVA: 0x70718DC
	internal object .ctor(object GrowthRate, object limit) { }

	// RVA: 0x707195C
	internal object Push() { }

	// RVA: 0x7071AA0
	internal object Pop() { }

	// RVA: 0x7071AF8
	internal object Peek() { }

	// RVA: 0x7071B4C
	internal object AddToTop(object o) { }

	// RVA: 0x7071BCC
	internal object get_Item(object index) { }

	// RVA: 0x7071C54
	internal object set_Item(object index, object value) { }

	// RVA: 0x7071D10
	internal object get_Length() { }

	// RVA: 0x7071D18
	private object .ctor(object stack, object growthRate, object used, object size) { }

	// RVA: 0x7071D68
	public object Clone() { }

}

// Namespace: System.Xml
public interface IHasXmlNode
{

	// Methods

	// RVA: -1
	public abstract object GetNode() { }

}

// Namespace: System.Xml
public interface IXmlLineInfo
{

	// Properties
	public abstract object LineNumber { get; }
	public abstract object LinePosition { get; }

	// Methods

	// RVA: -1
	public abstract object HasLineInfo() { }

	// RVA: -1
	public abstract object get_LineNumber() { }

	// RVA: -1
	public abstract object get_LinePosition() { }

}

// Namespace: System.Xml
internal class PositionInfo
{

	// Properties
	public virtual object LineNumber { get; }
	public virtual object LinePosition { get; }

	// Methods

	// RVA: 0x7071E54
	public virtual object HasLineInfo() { }

	// RVA: 0x7071E5C
	public virtual object get_LineNumber() { }

	// RVA: 0x7071E64
	public virtual object get_LinePosition() { }

	// RVA: 0x7071E6C
	public static object GetPositionInfo(object o) { }

	// RVA: 0x7071F68
	public object .ctor() { }

}

// Namespace: System.Xml
internal class ReaderPositionInfo
{

	// Fields
	private object lineInfo; // 0x8

	// Properties
	public override object LineNumber { get; }
	public override object LinePosition { get; }

	// Methods

	// RVA: 0x7071F3C
	public object .ctor(object lineInfo) { }

	// RVA: 0x7071F70
	public override object HasLineInfo() { }

	// RVA: 0x7072050
	public override object get_LineNumber() { }

	// RVA: 0x7072134
	public override object get_LinePosition() { }

}

// Namespace: System.Xml
public interface IXmlNamespaceResolver
{

	// Methods

	// RVA: -1
	public abstract object GetNamespacesInScope(object scope) { }

	// RVA: -1
	public abstract object LookupNamespace(object prefix) { }

	// RVA: -1
	public abstract object LookupPrefix(object namespaceName) { }

}

// Namespace: System.Xml
internal struct LineInfo
{

	// Fields
	internal object lineNo; // 0xFFFFFFFFFFFFFFF8
	internal object linePos; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x7072218
	public object .ctor(object lineNo, object linePos) { }

	// RVA: 0x7072228
	public object Set(object lineNo, object linePos) { }

}

// Namespace: 
private class Entry
{

	// Fields
	internal object str; // 0x8
	internal object hashCode; // 0x10
	internal object next; // 0x18

	// Methods

	// RVA: 0x707292C
	internal object .ctor(object str, object hashCode, object next) { }

}

// Namespace: System.Xml
public class NameTable
{

	// Fields
	private object entries; // 0x8
	private object count; // 0x10
	private object mask; // 0x14
	private object hashCodeRandomizer; // 0x18

	// Methods

	// RVA: 0x705CC98
	public object .ctor() { }

	// RVA: 0x7072238
	public override object Add(object key) { }

	// RVA: 0x70724F4
	public override object Add(object key, object start, object len) { }

	// RVA: 0x7072798
	public override object Get(object value) { }

	// RVA: 0x70723D0
	private object AddEntry(object str, object hashCode) { }

	// RVA: 0x7072970
	private object Grow() { }

	// RVA: 0x707269C
	private static object TextEquals(object str1, object str2, object str2Start, object str2Length) { }

}

// Namespace: System.Xml
internal static class Ref
{

	// Methods

	// RVA: 0x7062D0C
	public static object Equal(object strA, object strB) { }

}

// Namespace: 
private enum Token
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CDATA;
	public const object ID;
	public const object IDREF;
	public const object IDREFS;
	public const object ENTITY;
	public const object ENTITIES;
	public const object NMTOKEN;
	public const object NMTOKENS;
	public const object NOTATION;
	public const object None;
	public const object PERef;
	public const object AttlistDecl;
	public const object ElementDecl;
	public const object EntityDecl;
	public const object NotationDecl;
	public const object Comment;
	public const object PI;
	public const object CondSectionStart;
	public const object CondSectionEnd;
	public const object Eof;
	public const object REQUIRED;
	public const object IMPLIED;
	public const object FIXED;
	public const object QName;
	public const object Name;
	public const object Nmtoken;
	public const object Quote;
	public const object LeftParen;
	public const object RightParen;
	public const object GreaterThan;
	public const object Or;
	public const object LeftBracket;
	public const object RightBracket;
	public const object PUBLIC;
	public const object SYSTEM;
	public const object Literal;
	public const object DOCTYPE;
	public const object NData;
	public const object Percent;
	public const object Star;
	public const object QMark;
	public const object Plus;
	public const object PCDATA;
	public const object Comma;
	public const object ANY;
	public const object EMPTY;
	public const object IGNORE;
	public const object INCLUDE;
}

// Namespace: 
private enum ScanningFunction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SubsetContent;
	public const object Name;
	public const object QName;
	public const object Nmtoken;
	public const object Doctype1;
	public const object Doctype2;
	public const object Element1;
	public const object Element2;
	public const object Element3;
	public const object Element4;
	public const object Element5;
	public const object Element6;
	public const object Element7;
	public const object Attlist1;
	public const object Attlist2;
	public const object Attlist3;
	public const object Attlist4;
	public const object Attlist5;
	public const object Attlist6;
	public const object Attlist7;
	public const object Entity1;
	public const object Entity2;
	public const object Entity3;
	public const object Notation1;
	public const object CondSection1;
	public const object CondSection2;
	public const object CondSection3;
	public const object Literal;
	public const object SystemId;
	public const object PublicId1;
	public const object PublicId2;
	public const object ClosingTag;
	public const object ParamEntitySpace;
	public const object None;
}

// Namespace: 
private enum LiteralType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AttributeValue;
	public const object EntityReplText;
	public const object SystemOrPublicID;
}

// Namespace: 
private class UndeclaredNotation
{

	// Fields
	internal object name; // 0x8
	internal object lineNo; // 0x10
	internal object linePos; // 0x14
	internal object next; // 0x18

	// Methods

	// RVA: 0x707FE84
	internal object .ctor(object name, object lineNo, object linePos) { }

}

// Namespace: 
private class ParseElementOnlyContent_LocalFrame
{

	// Fields
	public object startParenEntityId; // 0x8
	public object parsingSchema; // 0xC

	// Methods

	// RVA: 0x707FEC8
	public object .ctor(object startParentEntityIdParam) { }

}

// Namespace: System.Xml
internal class DtdParser
{

	// Fields
	private object readerAdapter; // 0x8
	private object readerAdapterWithValidation; // 0x10
	private object nameTable; // 0x18
	private object schemaInfo; // 0x20
	private object xmlCharType; // 0x28
	private object systemId; // 0x30
	private object publicId; // 0x38
	private object normalize; // 0x40
	private object validate; // 0x41
	private object supportNamespaces; // 0x42
	private object v1Compat; // 0x43
	private object chars; // 0x48
	private object charsUsed; // 0x50
	private object curPos; // 0x54
	private object scanningFunction; // 0x58
	private object nextScaningFunction; // 0x5C
	private object savedScanningFunction; // 0x60
	private object whitespaceSeen; // 0x64
	private object tokenStartPos; // 0x68
	private object colonPos; // 0x6C
	private object internalSubsetValueSb; // 0x70
	private object externalEntitiesDepth; // 0x78
	private object currentEntityId; // 0x7C
	private object freeFloatingDtd; // 0x80
	private object hasFreeFloatingInternalSubset; // 0x81
	private object stringBuilder; // 0x88
	private object condSectionDepth; // 0x90
	private object literalLineInfo; // 0x94
	private object literalQuoteChar; // 0x9C
	private object documentBaseUri; // 0xA0
	private object externalDtdBaseUri; // 0xA8
	private object undeclaredNotations; // 0xB0
	private object condSectionEntityIds; // 0xB8

	// Properties
	private object ParsingInternalSubset { get; }
	private object IgnoreEntityReferences { get; }
	private object SaveInternalSubsetValue { get; }
	private object ParsingTopLevelMarkup { get; }
	private object SupportNamespaces { get; }
	private object Normalize { get; }
	private object LineNo { get; }
	private object LinePos { get; }
	private object BaseUriStr { get; }

	// Methods

	// RVA: 0x7072ACC
	private object .ctor() { }

	// RVA: 0x7061604
	internal static object Create() { }

	// RVA: 0x7072B60
	private object Initialize(object readerAdapter) { }

	// RVA: 0x7073000
	private object InitializeFreeFloatingDtd(object baseUri, object docTypeName, object publicId, object systemId, object internalSubset, object adapter) { }

	// RVA: 0x70735CC
	private object System.Xml.IDtdParser.ParseInternalDtd(object adapter, object saveInternalSubset) { }

	// RVA: 0x70739C4
	private object System.Xml.IDtdParser.ParseFreeFloatingDtd(object baseUri, object docTypeName, object publicId, object systemId, object internalSubset, object adapter) { }

	// RVA: 0x70739F4
	private object get_ParsingInternalSubset() { }

	// RVA: 0x7073A04
	private object get_IgnoreEntityReferences() { }

	// RVA: 0x7073A14
	private object get_SaveInternalSubsetValue() { }

	// RVA: 0x7073B18
	private object get_ParsingTopLevelMarkup() { }

	// RVA: 0x7073B48
	private object get_SupportNamespaces() { }

	// RVA: 0x7073B50
	private object get_Normalize() { }

	// RVA: 0x7073600
	private object Parse(object saveInternalSubset) { }

	// RVA: 0x7073BC0
	private object ParseInDocumentDtd(object saveInternalSubset) { }

	// RVA: 0x7073B58
	private object ParseFreeFloatingDtd() { }

	// RVA: 0x70758C4
	private object ParseInternalSubset() { }

	// RVA: 0x70758C8
	private object ParseExternalSubset() { }

	// RVA: 0x7075B14
	private object ParseSubset() { }

	// RVA: 0x7076010
	private object ParseAttlistDecl() { }

	// RVA: 0x70783CC
	private object ParseAttlistType(object attrDef, object elementDecl, object ignoreErrors) { }

	// RVA: 0x7078B78
	private object ParseAttlistDefault(object attrDef, object ignoreErrors) { }

	// RVA: 0x7076758
	private object ParseElementDecl() { }

	// RVA: 0x70795A8
	private object ParseElementOnlyContent(object pcv, object startParenEntityId) { }

	// RVA: 0x7079A48
	private object ParseHowMany(object pcv) { }

	// RVA: 0x7079220
	private object ParseElementMixedContent(object pcv, object startParenEntityId) { }

	// RVA: 0x7076C70
	private object ParseEntityDecl() { }

	// RVA: 0x7077108
	private object ParseNotationDecl() { }

	// RVA: 0x7078EF4
	private object AddUndeclaredNotation(object notationName) { }

	// RVA: 0x7077510
	private object ParseComment() { }

	// RVA: 0x70777E4
	private object ParsePI() { }

	// RVA: 0x7077A4C
	private object ParseCondSection() { }

	// RVA: 0x70752B8
	private object ParseExternalId(object idTokenType, object declType, object publicId, object systemId) { }

	// RVA: 0x7074398
	private object GetToken(object needWhiteSpace) { }

	// RVA: 0x707A33C
	private object ScanSubsetContent() { }

	// RVA: 0x707A2B0
	private object ScanNameExpected() { }

	// RVA: 0x707A2E0
	private object ScanQNameExpected() { }

	// RVA: 0x707A310
	private object ScanNmtokenExpected() { }

	// RVA: 0x707ABAC
	private object ScanDoctype1() { }

	// RVA: 0x707ADEC
	private object ScanDoctype2() { }

	// RVA: 0x707DB6C
	private object ScanClosingTag() { }

	// RVA: 0x707AF0C
	private object ScanElement1() { }

	// RVA: 0x707B200
	private object ScanElement2() { }

	// RVA: 0x707B430
	private object ScanElement3() { }

	// RVA: 0x707B4D0
	private object ScanElement4() { }

	// RVA: 0x707B624
	private object ScanElement5() { }

	// RVA: 0x707B7A8
	private object ScanElement6() { }

	// RVA: 0x707B894
	private object ScanElement7() { }

	// RVA: 0x707B904
	private object ScanAttlist1() { }

	// RVA: 0x707B9DC
	private object ScanAttlist2() { }

	// RVA: 0x707C234
	private object ScanAttlist3() { }

	// RVA: 0x707C2EC
	private object ScanAttlist4() { }

	// RVA: 0x707C3D8
	private object ScanAttlist5() { }

	// RVA: 0x707C4C4
	private object ScanAttlist6() { }

	// RVA: 0x707C90C
	private object ScanAttlist7() { }

	// RVA: 0x707E2E0
	private object ScanLiteral(object literalType) { }

	// RVA: 0x707F0F0
	private object ScanEntityName() { }

	// RVA: 0x707C9DC
	private object ScanNotation1() { }

	// RVA: 0x707CBD0
	private object ScanSystemId() { }

	// RVA: 0x707CDDC
	private object ScanEntity1() { }

	// RVA: 0x707CE6C
	private object ScanEntity2() { }

	// RVA: 0x707D0A4
	private object ScanEntity3() { }

	// RVA: 0x707CC90
	private object ScanPublicId1() { }

	// RVA: 0x707CD50
	private object ScanPublicId2() { }

	// RVA: 0x707D1C4
	private object ScanCondSection1() { }

	// RVA: 0x707D52C
	private object ScanCondSection2() { }

	// RVA: 0x707D5D0
	private object ScanCondSection3() { }

	// RVA: 0x707DF50
	private object ScanName() { }

	// RVA: 0x707DF58
	private object ScanQName() { }

	// RVA: 0x707F58C
	private object ScanQName(object isQName) { }

	// RVA: 0x707F848
	private object ReadDataInName() { }

	// RVA: 0x707DF60
	private object ScanNmtoken() { }

	// RVA: 0x707E0F0
	private object EatPublicKeyword() { }

	// RVA: 0x707E1E8
	private object EatSystemKeyword() { }

	// RVA: 0x7075094
	private object GetNameQualified(object canHavePrefix) { }

	// RVA: 0x7078ED8
	private object GetNameString() { }

	// RVA: 0x70790CC
	private object GetNmtokenString() { }

	// RVA: 0x7079188
	private object GetValue() { }

	// RVA: 0x70790E8
	private object GetValueWithStrippedSpaces() { }

	// RVA: 0x707DC0C
	private object ReadData() { }

	// RVA: 0x7074178
	private object LoadParsingBuffer() { }

	// RVA: 0x70758BC
	private object SaveParsingBuffer() { }

	// RVA: 0x7077DF0
	private object SaveParsingBuffer(object internalSubsetValueEndPos) { }

	// RVA: 0x707A178
	private object HandleEntityReference(object paramEntity, object inLiteral, object inAttribute) { }

	// RVA: 0x707FAD8
	private object HandleEntityReference(object entityName, object paramEntity, object inLiteral, object inAttribute) { }

	// RVA: 0x707DCFC
	private object HandleEntityEnd(object inLiteral) { }

	// RVA: 0x707F270
	private object VerifyEntityReference(object entityName, object paramEntity, object mustBeDeclared, object inAttribute) { }

	// RVA: 0x7077D1C
	private object SendValidationEvent(object pos, object severity, object code, object arg) { }

	// RVA: 0x7078E18
	private object SendValidationEvent(object severity, object code, object arg) { }

	// RVA: 0x7073FA0
	private object SendValidationEvent(object severity, object e) { }

	// RVA: 0x7078E0C
	private object IsAttributeValueType(object token) { }

	// RVA: 0x7077FB8
	private object get_LineNo() { }

	// RVA: 0x707809C
	private object get_LinePos() { }

	// RVA: 0x7073E1C
	private object get_BaseUriStr() { }

	// RVA: 0x7074FF8
	private object OnUnexpectedError() { }

	// RVA: 0x70779D4
	private object Throw(object curPos, object res) { }

	// RVA: 0x7079AF0
	private object Throw(object curPos, object res, object arg) { }

	// RVA: 0x7079E88
	private object Throw(object curPos, object res, object args) { }

	// RVA: 0x7078178
	private object Throw(object res, object arg, object lineNo, object linePos) { }

	// RVA: 0x707354C
	private object ThrowInvalidChar(object pos, object data, object invCharPos) { }

	// RVA: 0x707A0F4
	private object ThrowInvalidChar(object data, object length, object invCharPos) { }

	// RVA: 0x7077FB0
	private object ThrowUnexpectedToken(object pos, object expectedToken) { }

	// RVA: 0x7079D5C
	private object ThrowUnexpectedToken(object pos, object expectedToken1, object expectedToken2) { }

	// RVA: 0x707A1CC
	private object ParseUnexpectedToken(object startPos) { }

	// RVA: 0x707F890
	internal static object StripSpaces(object value) { }

}

// Namespace: System.Xml
public enum XmlTokenizedType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CDATA;
	public const object ID;
	public const object IDREF;
	public const object IDREFS;
	public const object ENTITY;
	public const object ENTITIES;
	public const object NMTOKEN;
	public const object NMTOKENS;
	public const object NOTATION;
	public const object ENUMERATION;
	public const object QName;
	public const object NCName;
	public const object None;
}

// Namespace: System.Xml
internal static class ValidateNames
{

	// Fields
	private static object xmlCharType; // 0x0

	// Methods

	// RVA: 0x707FEF8
	internal static object ParseNmtoken(object s, object offset) { }

	// RVA: 0x707FFE0
	internal static object ParseNmtokenNoNamespaces(object s, object offset) { }

	// RVA: 0x70800E4
	internal static object ParseNameNoNamespaces(object s, object offset) { }

	// RVA: 0x708026C
	internal static object IsNameNoNamespaces(object s) { }

	// RVA: 0x708032C
	internal static object ParseNCName(object s, object offset) { }

	// RVA: 0x7080484
	internal static object ParseNCName(object s) { }

	// RVA: 0x708050C
	internal static object ParseQName(object s, object offset, object colonOffset) { }

	// RVA: 0x7080648
	internal static object ParseQNameThrow(object s, object prefix, object localName) { }

	// RVA: 0x7080794
	internal static object ThrowInvalidName(object s, object offsetStartChar, object offsetBadChar) { }

	// RVA: 0x7080C20
	internal static object GetInvalidNameException(object s, object offsetStartChar, object offsetBadChar) { }

	// RVA: 0x7080ECC
	internal static object SplitQName(object name, object prefix, object lname) { }

	// RVA: 0x70812DC
	private static object .cctor() { }

}

// Namespace: System.Xml
internal struct XmlCharType
{

	// Fields
	private static object s_Lock; // 0x0
	private static object s_CharProperties; // 0xFFFFFFFFFFFFFFF8
	internal object charProperties; // 0xFFFFFFFFFFFFFFF8

	// Properties
	private static object StaticLock { get; }
	public static object Instance { get; }

	// Methods

	// RVA: 0x7081444
	private static object get_StaticLock() { }

	// RVA: 0x70814F8
	private static object InitInstance() { }

	// RVA: 0x7081828
	private static object SetProperties(object chProps, object ranges, object value) { }

	// RVA: 0x70819D0
	private object .ctor(object charProperties) { }

	// RVA: 0x7080A9C
	public static object get_Instance() { }

	// RVA: 0x70819E0
	public object IsWhiteSpace(object ch) { }

	// RVA: 0x7080A5C
	public object IsNCNameSingleChar(object ch) { }

	// RVA: 0x7080B08
	public object IsStartNCNameSingleChar(object ch) { }

	// RVA: 0x7081AE0
	public object IsNameSingleChar(object ch) { }

	// RVA: 0x7081B70
	public object IsCharData(object ch) { }

	// RVA: 0x7081BF0
	public object IsPubidChar(object ch) { }

	// RVA: 0x7081D00
	internal object IsTextChar(object ch) { }

	// RVA: 0x7081D80
	public object IsLetter(object ch) { }

	// RVA: 0x7081E00
	public object IsNCNameCharXml4e(object ch) { }

	// RVA: 0x7081E80
	public object IsStartNCNameCharXml4e(object ch) { }

	// RVA: 0x7081F10
	public object IsNameCharXml4e(object ch) { }

	// RVA: 0x7081FA0
	public static object IsDigit(object ch) { }

	// RVA: 0x7081FC4
	internal static object IsHighSurrogate(object ch) { }

	// RVA: 0x7081FD4
	internal static object IsLowSurrogate(object ch) { }

	// RVA: 0x7081FE4
	internal static object IsSurrogate(object ch) { }

	// RVA: 0x7081FF4
	internal static object CombineSurrogateChar(object lowChar, object highChar) { }

	// RVA: 0x708200C
	internal static object SplitSurrogateChar(object combinedChar, object lowChar, object highChar) { }

	// RVA: 0x7082044
	internal object IsOnlyWhitespace(object str) { }

	// RVA: 0x70820E8
	internal object IsOnlyWhitespaceWithPos(object str) { }

	// RVA: 0x70822B4
	internal object IsOnlyCharData(object str) { }

	// RVA: 0x70823C8
	internal static object IsOnlyDigits(object str, object startPos, object len) { }

	// RVA: 0x708249C
	internal object IsPublicId(object str) { }

	// RVA: 0x7081FB0
	private static object InRange(object value, object start, object end) { }

}

// Namespace: System.Xml
internal static class XmlComplianceUtil
{

	// Methods

	// RVA: 0x7082624
	public static object NonCDataNormalize(object value) { }

	// RVA: 0x70829A0
	public static object CDataNormalize(object value) { }

}

// Namespace: System.Xml
internal enum ExceptionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ArgumentException;
	public const object XmlException;
}

// Namespace: System.Xml
public enum XmlDateTimeSerializationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Local;
	public const object Utc;
	public const object Unspecified;
	public const object RoundtripKind;
}

// Namespace: System.Xml
public class XmlConvert
{

	// Fields
	private static object xmlCharType; // 0x0
	internal static object crt; // 0x8
	private static readonly object c_EncodedCharLength; // 0x10
	private static object c_EncodeCharPattern; // 0x18
	private static object c_DecodeCharPattern; // 0x20
	private static object s_allDateTimeFormats; // 0x28
	internal static readonly object WhitespaceChars; // 0x30

	// Properties
	private static object AllDateTimeFormats { get; }

	// Methods

	// RVA: 0x7082BC4
	public static object EncodeName(object name) { }

	// RVA: 0x70837D4
	public static object EncodeLocalName(object name) { }

	// RVA: 0x708383C
	public static object DecodeName(object name) { }

	// RVA: 0x7082C2C
	private static object EncodeName(object name, object first, object local) { }

	// RVA: 0x7084334
	private static object FromHex(object digit) { }

	// RVA: 0x708435C
	internal static object FromBinHexString(object s) { }

	// RVA: 0x70843E4
	internal static object FromBinHexString(object s, object allowOddCount) { }

	// RVA: 0x708445C
	internal static object ToBinHexString(object inArray) { }

	// RVA: 0x70844C4
	public static object VerifyName(object name) { }

	// RVA: 0x7084758
	internal static object TryVerifyName(object name) { }

	// RVA: 0x7084948
	internal static object VerifyQName(object name, object exceptionType) { }

	// RVA: 0x7084B98
	public static object VerifyNCName(object name) { }

	// RVA: 0x7084C20
	internal static object VerifyNCName(object name, object exceptionType) { }

	// RVA: 0x7084D90
	internal static object TryVerifyNCName(object name) { }

	// RVA: 0x7084EB8
	public static object VerifyTOKEN(object token) { }

	// RVA: 0x7084FE8
	internal static object TryVerifyTOKEN(object token) { }

	// RVA: 0x7085120
	internal static object TryVerifyNMTOKEN(object name) { }

	// RVA: 0x70852F4
	internal static object TryVerifyNormalizedString(object str) { }

	// RVA: 0x70853F0
	public static object ToString(object value) { }

	// RVA: 0x708545C
	public static object ToString(object value) { }

	// RVA: 0x70854C8
	public static object ToString(object value) { }

	// RVA: 0x7085570
	public static object ToString(object value) { }

	// RVA: 0x70855A8
	public static object ToString(object value) { }

	// RVA: 0x70855E0
	public static object ToString(object value) { }

	// RVA: 0x7085618
	public static object ToString(object value) { }

	// RVA: 0x7085650
	public static object ToString(object value) { }

	// RVA: 0x7085688
	public static object ToString(object value) { }

	// RVA: 0x70856C0
	public static object ToString(object value) { }

	// RVA: 0x70856F8
	public static object ToString(object value) { }

	// RVA: 0x7085730
	public static object ToString(object value) { }

	// RVA: 0x708597C
	public static object ToString(object value) { }

	// RVA: 0x7085B28
	public static object ToString(object value) { }

	// RVA: 0x7085B78
	public static object ToString(object value, object format) { }

	// RVA: 0x7085C54
	public static object ToString(object value, object dateTimeOption) { }

	// RVA: 0x70860CC
	public static object ToString(object value) { }

	// RVA: 0x7086158
	public static object ToString(object value) { }

	// RVA: 0x7086180
	public static object ToBoolean(object s) { }

	// RVA: 0x708648C
	internal static object TryToBoolean(object s, object result) { }

	// RVA: 0x7086744
	public static object ToChar(object s) { }

	// RVA: 0x7086804
	internal static object TryToChar(object s, object result) { }

	// RVA: 0x7086980
	public static object ToDecimal(object s) { }

	// RVA: 0x70869F8
	internal static object TryToDecimal(object s, object result) { }

	// RVA: 0x7086B88
	internal static object ToInteger(object s) { }

	// RVA: 0x7086C00
	internal static object TryToInteger(object s, object result) { }

	// RVA: 0x7086D90
	public static object ToSByte(object s) { }

	// RVA: 0x7086DC4
	internal static object TryToSByte(object s, object result) { }

	// RVA: 0x7086F2C
	public static object ToInt16(object s) { }

	// RVA: 0x7086F60
	internal static object TryToInt16(object s, object result) { }

	// RVA: 0x70870C8
	public static object ToInt32(object s) { }

	// RVA: 0x70870FC
	internal static object TryToInt32(object s, object result) { }

	// RVA: 0x7087264
	public static object ToInt64(object s) { }

	// RVA: 0x7087298
	internal static object TryToInt64(object s, object result) { }

	// RVA: 0x7087400
	public static object ToByte(object s) { }

	// RVA: 0x7087434
	internal static object TryToByte(object s, object result) { }

	// RVA: 0x708759C
	public static object ToUInt16(object s) { }

	// RVA: 0x70875D0
	internal static object TryToUInt16(object s, object result) { }

	// RVA: 0x7087738
	public static object ToUInt32(object s) { }

	// RVA: 0x708776C
	internal static object TryToUInt32(object s, object result) { }

	// RVA: 0x70878D4
	public static object ToUInt64(object s) { }

	// RVA: 0x7087908
	internal static object TryToUInt64(object s, object result) { }

	// RVA: 0x7087A70
	public static object ToSingle(object s) { }

	// RVA: 0x7087C3C
	internal static object TryToSingle(object s, object result) { }

	// RVA: 0x7087F2C
	public static object ToDouble(object s) { }

	// RVA: 0x70880CC
	internal static object TryToDouble(object s, object result) { }

	// RVA: 0x70883BC
	internal static object ToXPathDouble(object o) { }

	// RVA: 0x7088700
	internal static object XPathRound(object value) { }

	// RVA: 0x7088808
	public static object ToTimeSpan(object s) { }

	// RVA: 0x70889B4
	internal static object TryToTimeSpan(object s, object result) { }

	// RVA: 0x7088A80
	private static object get_AllDateTimeFormats() { }

	// RVA: 0x7088B5C
	private static object CreateAllDateTimeFormats() { }

	// RVA: 0x7088FA0
	public static object ToDateTime(object s) { }

	// RVA: 0x70890B0
	public static object ToDateTime(object s, object formats) { }

	// RVA: 0x7089184
	public static object ToDateTime(object s, object dateTimeOption) { }

	// RVA: 0x7089428
	public static object ToDateTimeOffset(object s) { }

	// RVA: 0x70894F4
	public static object ToGuid(object s) { }

	// RVA: 0x7089524
	internal static object TryToGuid(object s, object result) { }

	// RVA: 0x7085EB4
	private static object SwitchToLocalTime(object value) { }

	// RVA: 0x7085FC0
	private static object SwitchToUtcTime(object value) { }

	// RVA: 0x7089728
	internal static object ToUri(object s) { }

	// RVA: 0x70899C4
	internal static object TryToUri(object s, object result) { }

	// RVA: 0x7089C70
	internal static object StrEqual(object chars, object strPos1, object strLen1, object str2) { }

	// RVA: 0x70863FC
	internal static object TrimString(object value) { }

	// RVA: 0x7089D64
	internal static object TrimStringStart(object value) { }

	// RVA: 0x7089DF4
	internal static object TrimStringEnd(object value) { }

	// RVA: 0x7089E84
	internal static object SplitString(object value) { }

	// RVA: 0x70858E0
	internal static object IsNegativeZero(object value) { }

	// RVA: 0x7089F18
	private static object DoubleToInt64Bits(object value) { }

	// RVA: 0x7089F20
	internal static object VerifyCharData(object data, object invCharExceptionType, object invSurrogateExceptionType) { }

	// RVA: 0x708A144
	internal static object CreateException(object res, object exceptionType, object lineNo, object linePos) { }

	// RVA: 0x708A578
	internal static object CreateException(object res, object arg, object exceptionType, object lineNo, object linePos) { }

	// RVA: 0x708A6C4
	internal static object CreateException(object res, object args, object exceptionType) { }

	// RVA: 0x7084A84
	internal static object CreateException(object res, object args, object exceptionType, object lineNo, object linePos) { }

	// RVA: 0x708A7C0
	internal static object CreateInvalidSurrogatePairException(object low, object hi) { }

	// RVA: 0x708A88C
	internal static object CreateInvalidSurrogatePairException(object low, object hi, object exceptionType) { }

	// RVA: 0x708A230
	internal static object CreateInvalidSurrogatePairException(object low, object hi, object exceptionType, object lineNo, object linePos) { }

	// RVA: 0x708A90C
	internal static object CreateInvalidHighSurrogateCharException(object hi) { }

	// RVA: 0x708A9D0
	internal static object CreateInvalidHighSurrogateCharException(object hi, object exceptionType) { }

	// RVA: 0x708AA40
	internal static object CreateInvalidHighSurrogateCharException(object hi, object exceptionType, object lineNo, object linePos) { }

	// RVA: 0x708A3AC
	internal static object CreateInvalidCharException(object data, object invCharPos, object exceptionType) { }

	// RVA: 0x708AB48
	internal static object CreateInvalidCharException(object invChar, object nextChar) { }

	// RVA: 0x708ABB4
	internal static object CreateInvalidCharException(object invChar, object nextChar, object exceptionType) { }

	// RVA: 0x708462C
	internal static object CreateInvalidNameCharException(object name, object index, object exceptionType) { }

	// RVA: 0x708ACB0
	internal static object CreateInvalidNameArgumentException(object name, object argumentName) { }

	// RVA: 0x708AD7C
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object uri; // 0x8

	// Methods

	// RVA: 0x708BBF8
	public object .ctor() { }

	// RVA: 0x708BD30
	internal object <GetStreamAsync>b__0() { }

}

// Namespace: 
private struct <GetNonFileStreamAsync>d__5
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object uri; // 0x18
	public object credentials; // 0x20
	public object proxy; // 0x28
	public object cachePolicy; // 0x30
	public object <>4__this; // 0x38
	private object <req>5__2; // 0x40
	private object <>u__1; // 0x48

	// Methods

	// RVA: 0x708BDC4
	private object MoveNext() { }

	// RVA: 0x708C79C
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Xml
internal class XmlDownloadManager
{

	// Fields
	private object connections; // 0x8

	// Methods

	// RVA: 0x708AEBC
	internal object GetStream(object uri, object credentials, object proxy, object cachePolicy) { }

	// RVA: 0x708AFC4
	private object GetNonFileStream(object uri, object credentials, object proxy, object cachePolicy) { }

	// RVA: 0x708B89C
	internal object Remove(object host) { }

	// RVA: 0x708BA74
	internal object GetStreamAsync(object uri, object credentials, object proxy, object cachePolicy) { }

	// RVA: 0x708BC00
	private object GetNonFileStreamAsync(object uri, object credentials, object proxy, object cachePolicy) { }

	// RVA: 0x708BD28
	public object .ctor() { }

}

// Namespace: System.Xml
internal class OpenedHost
{

	// Fields
	internal object nonCachedConnectionsCount; // 0x8

	// Methods

	// RVA: 0x708B64C
	public object .ctor() { }

}

// Namespace: System.Xml
internal class XmlRegisteredNonCachedStream
{

	// Fields
	protected object stream; // 0x20
	private object downloadManager; // 0x28
	private object host; // 0x30

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x708B654
	internal object .ctor(object stream, object downloadManager, object host) { }

	// RVA: 0x708C89C
	protected override object Finalize() { }

	// RVA: 0x708C940
	protected override object Dispose(object disposing) { }

	// RVA: 0x708CAAC
	public override object BeginRead(object buffer, object offset, object count, object callback, object state) { }

	// RVA: 0x708CB34
	public override object BeginWrite(object buffer, object offset, object count, object callback, object state) { }

	// RVA: 0x708CBBC
	public override object EndRead(object asyncResult) { }

	// RVA: 0x708CC14
	public override object EndWrite(object asyncResult) { }

	// RVA: 0x708CC6C
	public override object Flush() { }

	// RVA: 0x708CCBC
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x708CD2C
	public override object ReadByte() { }

	// RVA: 0x708CD7C
	public override object Seek(object offset, object origin) { }

	// RVA: 0x708CDE4
	public override object SetLength(object value) { }

	// RVA: 0x708CE3C
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x708CEAC
	public override object WriteByte(object value) { }

	// RVA: 0x708CF04
	public override object get_CanRead() { }

	// RVA: 0x708CF50
	public override object get_CanSeek() { }

	// RVA: 0x708CF9C
	public override object get_CanWrite() { }

	// RVA: 0x708CFE8
	public override object get_Length() { }

	// RVA: 0x708D034
	public override object get_Position() { }

	// RVA: 0x708D084
	public override object set_Position(object value) { }

}

// Namespace: System.Xml
internal class XmlCachedStream
{

	// Fields
	private object uri; // 0x48

	// Methods

	// RVA: 0x708B6D8
	internal object .ctor(object uri, object stream) { }

}

// Namespace: System.Xml
internal class UTF16Decoder
{

	// Fields
	private object bigEndian; // 0x18
	private object lastByte; // 0x1C

	// Methods

	// RVA: 0x708D148
	public object .ctor(object bigEndian) { }

	// RVA: 0x708D17C
	public override object GetCharCount(object bytes, object index, object count) { }

	// RVA: 0x708D1E0
	public override object GetCharCount(object bytes, object index, object count, object flush) { }

	// RVA: 0x708D2C8
	public override object GetChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708D4B8
	public override object Convert(object bytes, object byteIndex, object byteCount, object chars, object charIndex, object charCount, object flush, object bytesUsed, object charsUsed, object completed) { }

}

// Namespace: System.Xml
internal class SafeAsciiDecoder
{

	// Methods

	// RVA: 0x708D6E4
	public object .ctor() { }

	// RVA: 0x708D6EC
	public override object GetCharCount(object bytes, object index, object count) { }

	// RVA: 0x708D6F4
	public override object GetChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708D788
	public override object Convert(object bytes, object byteIndex, object byteCount, object chars, object charIndex, object charCount, object flush, object bytesUsed, object charsUsed, object completed) { }

}

// Namespace: System.Xml
internal class Ucs4Encoding
{

	// Fields
	internal object ucs4Decoder; // 0x30

	// Properties
	public override object WebName { get; }
	public override object CodePage { get; }
	internal static object UCS4_Littleendian { get; }
	internal static object UCS4_Bigendian { get; }
	internal static object UCS4_2143 { get; }
	internal static object UCS4_3412 { get; }

	// Methods

	// RVA: 0x708D838
	public override object get_WebName() { }

	// RVA: 0x708D878
	public override object GetDecoder() { }

	// RVA: 0x708D880
	public override object GetByteCount(object chars, object index, object count) { }

	// RVA: 0x708D8E8
	public override object GetBytes(object s) { }

	// RVA: 0x708D8F0
	public override object GetBytes(object chars, object charIndex, object charCount, object bytes, object byteIndex) { }

	// RVA: 0x708D8F8
	public override object GetMaxByteCount(object charCount) { }

	// RVA: 0x708D900
	public override object GetCharCount(object bytes, object index, object count) { }

	// RVA: 0x708D96C
	public override object GetChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708D9F0
	public override object GetMaxCharCount(object byteCount) { }

	// RVA: 0x708DA08
	public override object get_CodePage() { }

	// RVA: 0x708DA10
	public override object GetEncoder() { }

	// RVA: 0x708DA18
	internal static object get_UCS4_Littleendian() { }

	// RVA: 0x708DBA4
	internal static object get_UCS4_Bigendian() { }

	// RVA: 0x708DD30
	internal static object get_UCS4_2143() { }

	// RVA: 0x708DEBC
	internal static object get_UCS4_3412() { }

	// RVA: 0x708E048
	public object .ctor() { }

}

// Namespace: System.Xml
internal class Ucs4Encoding1234
{

	// Properties
	public override object EncodingName { get; }

	// Methods

	// RVA: 0x708DC84
	public object .ctor() { }

	// RVA: 0x708E0B4
	public override object get_EncodingName() { }

	// RVA: 0x708E0F8
	public override object GetPreamble() { }

}

// Namespace: System.Xml
internal class Ucs4Encoding4321
{

	// Properties
	public override object EncodingName { get; }

	// Methods

	// RVA: 0x708DAF8
	public object .ctor() { }

	// RVA: 0x708E1E0
	public override object get_EncodingName() { }

	// RVA: 0x708E224
	public override object GetPreamble() { }

}

// Namespace: System.Xml
internal class Ucs4Encoding2143
{

	// Properties
	public override object EncodingName { get; }

	// Methods

	// RVA: 0x708DE10
	public object .ctor() { }

	// RVA: 0x708E308
	public override object get_EncodingName() { }

	// RVA: 0x708E34C
	public override object GetPreamble() { }

}

// Namespace: System.Xml
internal class Ucs4Encoding3412
{

	// Properties
	public override object EncodingName { get; }

	// Methods

	// RVA: 0x708DF9C
	public object .ctor() { }

	// RVA: 0x708E434
	public override object get_EncodingName() { }

	// RVA: 0x708E478
	public override object GetPreamble() { }

}

// Namespace: System.Xml
internal abstract class Ucs4Decoder
{

	// Fields
	internal object lastBytes; // 0x18
	internal object lastBytesCount; // 0x20

	// Methods

	// RVA: 0x708E4F8
	public override object GetCharCount(object bytes, object index, object count) { }

	// RVA: -1
	internal abstract object GetFullChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708E514
	public override object GetChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708E774
	public override object Convert(object bytes, object byteIndex, object byteCount, object chars, object charIndex, object charCount, object flush, object bytesUsed, object charsUsed, object completed) { }

	// RVA: 0x708EA38
	internal object Ucs4ToUTF16(object code, object chars, object charIndex) { }

	// RVA: 0x708EA98
	protected object .ctor() { }

}

// Namespace: System.Xml
internal class Ucs4Decoder4321
{

	// Methods

	// RVA: 0x708EAFC
	internal override object GetFullChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708E17C
	public object .ctor() { }

}

// Namespace: System.Xml
internal class Ucs4Decoder1234
{

	// Methods

	// RVA: 0x708EDC0
	internal override object GetFullChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708E050
	public object .ctor() { }

}

// Namespace: System.Xml
internal class Ucs4Decoder2143
{

	// Methods

	// RVA: 0x708F084
	internal override object GetFullChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708E2A4
	public object .ctor() { }

}

// Namespace: System.Xml
internal class Ucs4Decoder3412
{

	// Methods

	// RVA: 0x708F348
	internal override object GetFullChars(object bytes, object byteIndex, object byteCount, object chars, object charIndex) { }

	// RVA: 0x708E3D0
	public object .ctor() { }

}

// Namespace: System.Xml
public class XmlException
{

	// Fields
	private object res; // 0x88
	private object args; // 0x90
	private object lineNumber; // 0x98
	private object linePosition; // 0x9C
	private object sourceUri; // 0xA0
	private object message; // 0xA8

	// Properties
	public object LineNumber { get; }
	public object LinePosition { get; }
	public override object Message { get; }
	internal object ResString { get; }

	// Methods

	// RVA: 0x708F60C
	protected object .ctor(object info, object context) { }

	// RVA: 0x708FC5C
	public override object GetObjectData(object info, object context) { }

	// RVA: 0x708FDD8
	public object .ctor() { }

	// RVA: 0x708FDF0
	public object .ctor(object message) { }

	// RVA: 0x708FE0C
	public object .ctor(object message, object innerException) { }

	// RVA: 0x708FE04
	public object .ctor(object message, object innerException, object lineNumber, object linePosition) { }

	// RVA: 0x708FE1C
	internal object .ctor(object message, object innerException, object lineNumber, object linePosition, object sourceUri) { }

	// RVA: 0x7080BB8
	internal object .ctor(object res, object args) { }

	// RVA: 0x7080994
	internal object .ctor(object res, object arg) { }

	// RVA: 0x70900B8
	internal object .ctor(object res, object arg, object sourceUri) { }

	// RVA: 0x7090184
	internal object .ctor(object res, object arg, object lineInfo) { }

	// RVA: 0x70903F0
	internal object .ctor(object res, object args, object lineInfo) { }

	// RVA: 0x7090224
	internal object .ctor(object res, object args, object lineInfo, object sourceUri) { }

	// RVA: 0x708A49C
	internal object .ctor(object res, object arg, object lineNumber, object linePosition) { }

	// RVA: 0x70903F8
	internal object .ctor(object res, object arg, object lineNumber, object linePosition, object sourceUri) { }

	// RVA: 0x708A744
	internal object .ctor(object res, object args, object lineNumber, object linePosition) { }

	// RVA: 0x70904D8
	internal object .ctor(object res, object args, object lineNumber, object linePosition, object sourceUri) { }

	// RVA: 0x7090558
	internal object .ctor(object res, object args, object innerException, object lineNumber, object linePosition) { }

	// RVA: 0x709002C
	internal object .ctor(object res, object args, object innerException, object lineNumber, object linePosition, object sourceUri) { }

	// RVA: 0x708FF34
	private static object FormatUserMessage(object message, object lineNumber, object linePosition) { }

	// RVA: 0x708FA08
	private static object CreateMessage(object res, object args, object lineNumber, object linePosition) { }

	// RVA: 0x7080B48
	internal static object BuildCharExceptionArgs(object data, object invCharIndex) { }

	// RVA: 0x70905D8
	internal static object BuildCharExceptionArgs(object data, object length, object invCharIndex) { }

	// RVA: 0x708102C
	internal static object BuildCharExceptionArgs(object invChar, object nextChar) { }

	// RVA: 0x7090634
	public object get_LineNumber() { }

	// RVA: 0x709063C
	public object get_LinePosition() { }

	// RVA: 0x7090644
	public override object get_Message() { }

	// RVA: 0x709065C
	internal object get_ResString() { }

}

// Namespace: System.Xml
public abstract class XmlNameTable
{

	// Methods

	// RVA: -1
	public abstract object Get(object array) { }

	// RVA: -1
	public abstract object Add(object array, object offset, object length) { }

	// RVA: -1
	public abstract object Add(object array) { }

	// RVA: 0x7090664
	protected object .ctor() { }

}

// Namespace: System.Xml
public enum XmlNamespaceScope
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object All;
	public const object ExcludeXml;
	public const object Local;
}

// Namespace: 
private struct NamespaceDeclaration
{

	// Fields
	public object prefix; // 0xFFFFFFFFFFFFFFF8
	public object uri; // 0x0
	public object scopeId; // 0x8
	public object previousNsIndex; // 0xC

	// Methods

	// RVA: 0x70908D4
	public object Set(object prefix, object uri, object scopeId, object previousNsIndex) { }

}

// Namespace: System.Xml
public class XmlNamespaceManager
{

	// Fields
	private object nsdecls; // 0x8
	private object lastDecl; // 0x10
	private object nameTable; // 0x18
	private object scopeId; // 0x20
	private object hashTable; // 0x28
	private object useHashtable; // 0x30
	private object xml; // 0x38
	private object xmlNs; // 0x40

	// Properties
	public virtual object NameTable { get; }
	public virtual object DefaultNamespace { get; }

	// Methods

	// RVA: 0x709066C
	internal object .ctor() { }

	// RVA: 0x7090674
	public object .ctor(object nameTable) { }

	// RVA: 0x70908E0
	public virtual object get_NameTable() { }

	// RVA: 0x70908E8
	public virtual object get_DefaultNamespace() { }

	// RVA: 0x709098C
	public virtual object PushScope() { }

	// RVA: 0x709099C
	public virtual object PopScope() { }

	// RVA: 0x7090A94
	public virtual object AddNamespace(object prefix, object uri) { }

	// RVA: 0x70910E4
	public virtual object RemoveNamespace(object prefix, object uri) { }

	// RVA: 0x7091240
	public virtual object GetEnumerator() { }

	// RVA: 0x7091424
	public virtual object GetNamespacesInScope(object scope) { }

	// RVA: 0x7091738
	public virtual object LookupNamespace(object prefix) { }

	// RVA: 0x7090ED0
	private object LookupNamespaceDecl(object prefix) { }

	// RVA: 0x70917A0
	public virtual object LookupPrefix(object uri) { }

}

// Namespace: System.Xml
public enum XmlNodeOrder
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Before;
	public const object After;
	public const object Same;
	public const object Unknown;
}

// Namespace: System.Xml
public enum XmlNodeType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Element;
	public const object Attribute;
	public const object Text;
	public const object CDATA;
	public const object EntityReference;
	public const object Entity;
	public const object ProcessingInstruction;
	public const object Comment;
	public const object Document;
	public const object DocumentType;
	public const object DocumentFragment;
	public const object Notation;
	public const object Whitespace;
	public const object SignificantWhitespace;
	public const object EndElement;
	public const object EndEntity;
	public const object XmlDeclaration;
}

// Namespace: 
private sealed class HashCodeOfStringDelegate
{

	// Methods

	// RVA: 0x7092358
	public object .ctor(object object, object method) { }

	// RVA: 0x7092BC4
	public virtual object Invoke(object s, object sLen, object additionalEntropy) { }

}

// Namespace: System.Xml
public class XmlQualifiedName
{

	// Fields
	private static object hashCodeDelegate; // 0x0
	private object name; // 0x8
	private object ns; // 0x10
	private object hash; // 0x18
	public static readonly object Empty; // 0x8

	// Properties
	public object Namespace { get; }
	public object Name { get; }
	public object IsEmpty { get; }

	// Methods

	// RVA: 0x7091974
	public object .ctor() { }

	// RVA: 0x7091B24
	public object .ctor(object name) { }

	// RVA: 0x7091A5C
	public object .ctor(object name, object ns) { }

	// RVA: 0x7091C30
	public object get_Namespace() { }

	// RVA: 0x7091C38
	public object get_Name() { }

	// RVA: 0x7091C40
	public override object GetHashCode() { }

	// RVA: 0x7091F84
	public object get_IsEmpty() { }

	// RVA: 0x7091FDC
	public override object ToString() { }

	// RVA: 0x7092058
	public override object Equals(object other) { }

	// RVA: 0x7092268
	public static object op_Equality(object a, object b) { }

	// RVA: 0x7092190
	public static object op_Inequality(object a, object b) { }

	// RVA: 0x70922D0
	public static object ToString(object name, object ns) { }

	// RVA: 0x7091D4C
	private static object GetHashCodeDelegate() { }

	// RVA: 0x7092350
	private static object IsRandomizedHashingDisabled() { }

	// RVA: 0x7092408
	private static object GetHashCodeOfString(object s, object length, object additionalEntropy) { }

	// RVA: 0x7092458
	internal object Init(object name, object ns) { }

	// RVA: 0x7092464
	internal object SetNamespace(object ns) { }

	// RVA: 0x709246C
	internal object Verify() { }

	// RVA: 0x7092598
	internal object Atomize(object nameTable) { }

	// RVA: 0x7092630
	internal static object Parse(object s, object nsmgr, object prefix) { }

	// RVA: 0x70928D0
	internal object Clone() { }

	// RVA: 0x7092958
	private static object .cctor() { }

}

// Namespace: System.Xml
public abstract class XmlResolver
{

	// Methods

	// RVA: -1
	public abstract object GetEntity(object absoluteUri, object role, object ofObjectToReturn) { }

	// RVA: 0x7092BD8
	public virtual object ResolveUri(object baseUri, object relativeUri) { }

	// RVA: 0x7092E00
	public virtual object SupportsType(object absoluteUri, object type) { }

	// RVA: 0x7092F7C
	public virtual object GetEntityAsync(object absoluteUri, object role, object ofObjectToReturn) { }

	// RVA: 0x7092FBC
	protected object .ctor() { }

}

// Namespace: 
private struct <GetEntityAsync>d__15
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object ofObjectToReturn; // 0x18
	public object absoluteUri; // 0x20
	public object <>4__this; // 0x28
	private object <>u__1; // 0x30

	// Methods

	// RVA: 0x709336C
	private object MoveNext() { }

	// RVA: 0x7093794
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Xml
public class XmlUrlResolver
{

	// Fields
	private static object s_DownloadManager; // 0x0
	private object _credentials; // 0x8
	private object _proxy; // 0x10
	private object _cachePolicy; // 0x18

	// Properties
	private static object DownloadManager { get; }

	// Methods

	// RVA: 0x7092FC4
	private static object get_DownloadManager() { }

	// RVA: 0x709309C
	public object .ctor() { }

	// RVA: 0x70930A4
	public override object GetEntity(object absoluteUri, object role, object ofObjectToReturn) { }

	// RVA: 0x7093254
	public override object ResolveUri(object baseUri, object relativeUri) { }

	// RVA: 0x7093258
	public override object GetEntityAsync(object absoluteUri, object role, object ofObjectToReturn) { }

}

// Namespace: System.Xml
internal static class BinaryCompatibility
{

	// Properties
	public static object TargetsAtLeast_Desktop_V4_5_2 { get; }

	// Methods

	// RVA: 0x7093894
	public static object get_TargetsAtLeast_Desktop_V4_5_2() { }

}

// Namespace: System.Xml
internal static class Res
{

	// Methods

	// RVA: 0x7084628
	public static object GetString(object name) { }

	// RVA: 0x70812CC
	public static object GetString(object name, object args) { }

}

// Namespace: System.Xml.XPath
public interface IXPathNavigable
{

	// Methods

	// RVA: -1
	public abstract object CreateNavigator() { }

}

// Namespace: System.Xml.XPath
public class XPathDocument
{

	// Fields
	private object pageText; // 0x8
	private object pageRoot; // 0x10
	private object pageXmlNmsp; // 0x18
	private object idxText; // 0x20
	private object idxRoot; // 0x24
	private object idxXmlNmsp; // 0x28
	private object nameTable; // 0x30
	private object hasLineInfo; // 0x38
	private object mapNmsp; // 0x40
	private object idValueMap; // 0x48

	// Properties
	internal object NameTable { get; }
	internal object HasLineInfo { get; }

	// Methods

	// RVA: 0x709389C
	internal object get_NameTable() { }

	// RVA: 0x70938A4
	internal object get_HasLineInfo() { }

	// RVA: 0x70938AC
	internal object GetCollapsedTextNode(object pageText) { }

	// RVA: 0x70938BC
	internal object GetRootNode(object pageRoot) { }

	// RVA: 0x70938CC
	internal object GetXmlNamespaceNode(object pageXmlNmsp) { }

	// RVA: 0x70938DC
	internal object LookupNamespaces(object pageElem, object idxElem, object pageNmsp) { }

	// RVA: 0x70939D4
	internal object LookupIdElement(object id, object pageElem) { }

}

// Namespace: System.Xml.XPath
public class XPathException
{

	// Fields
	private object res; // 0x88
	private object args; // 0x90
	private object message; // 0x98

	// Properties
	public override object Message { get; }

	// Methods

	// RVA: 0x7093A98
	protected object .ctor(object info, object context) { }

	// RVA: 0x7093E78
	public override object GetObjectData(object info, object context) { }

	// RVA: 0x7093F74
	public object .ctor() { }

	// RVA: 0x7093FD8
	public object .ctor(object message, object innerException) { }

	// RVA: 0x709410C
	internal static object Create(object res) { }

	// RVA: 0x70941F4
	internal static object Create(object res, object arg) { }

	// RVA: 0x70942C8
	internal static object Create(object res, object arg, object arg2) { }

	// RVA: 0x70943B4
	internal static object Create(object res, object arg, object innerException) { }

	// RVA: 0x7094198
	private object .ctor(object res, object args) { }

	// RVA: 0x70940AC
	private object .ctor(object res, object args, object inner) { }

	// RVA: 0x7093D34
	private static object CreateMessage(object res, object args) { }

	// RVA: 0x7094494
	public override object get_Message() { }

}

// Namespace: System.Xml.XPath
public enum XPathResultType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Number;
	public const object String;
	public const object Boolean;
	public const object NodeSet;
	public const object Navigator;
	public const object Any;
	public const object Error;
}

// Namespace: System.Xml.XPath
public abstract class XPathExpression
{

	// Methods

	// RVA: 0x70944AC
	internal object .ctor() { }

	// RVA: -1
	public abstract object SetContext(object nsResolver) { }

	// RVA: 0x70944B4
	public static object Compile(object xpath) { }

	// RVA: 0x70944BC
	public static object Compile(object xpath, object nsResolver) { }

}

// Namespace: System.Xml.XPath
public abstract class XPathItem
{

	// Properties
	public abstract object XmlType { get; }
	public abstract object Value { get; }
	public abstract object TypedValue { get; }
	public abstract object ValueType { get; }
	public abstract object ValueAsBoolean { get; }
	public abstract object ValueAsDateTime { get; }
	public abstract object ValueAsDouble { get; }
	public abstract object ValueAsInt { get; }
	public abstract object ValueAsLong { get; }

	// Methods

	// RVA: -1
	public abstract object get_XmlType() { }

	// RVA: -1
	public abstract object get_Value() { }

	// RVA: -1
	public abstract object get_TypedValue() { }

	// RVA: -1
	public abstract object get_ValueType() { }

	// RVA: -1
	public abstract object get_ValueAsBoolean() { }

	// RVA: -1
	public abstract object get_ValueAsDateTime() { }

	// RVA: -1
	public abstract object get_ValueAsDouble() { }

	// RVA: -1
	public abstract object get_ValueAsInt() { }

	// RVA: -1
	public abstract object get_ValueAsLong() { }

	// RVA: 0x70945D4
	public virtual object ValueAs(object returnType) { }

	// RVA: -1
	public abstract object ValueAs(object returnType, object nsResolver) { }

	// RVA: 0x7094624
	protected object .ctor() { }

}

// Namespace: System.Xml.XPath
public enum XPathNamespaceScope
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object All;
	public const object ExcludeXml;
	public const object Local;
}

// Namespace: System.Xml.XPath
public abstract class XPathNavigator
{

	// Fields
	internal static readonly object comparer; // 0x0
	internal static readonly object NodeTypeLetter; // 0x8
	internal static readonly object UniqueIdTbl; // 0x10
	internal static readonly object ContentKindMasks; // 0x18

	// Properties
	public override object XmlType { get; }
	public override object TypedValue { get; }
	public override object ValueType { get; }
	public override object ValueAsBoolean { get; }
	public override object ValueAsDateTime { get; }
	public override object ValueAsDouble { get; }
	public override object ValueAsInt { get; }
	public override object ValueAsLong { get; }
	public abstract object NameTable { get; }
	public abstract object NodeType { get; }
	public abstract object LocalName { get; }
	public abstract object Name { get; }
	public abstract object NamespaceURI { get; }
	public abstract object Prefix { get; }
	public abstract object BaseURI { get; }
	public virtual object XmlLang { get; }
	public virtual object UnderlyingObject { get; }
	public virtual object SchemaInfo { get; }

	// Methods

	// RVA: 0x709462C
	public override object ToString() { }

	// RVA: 0x709466C
	public override object get_XmlType() { }

	// RVA: 0x709489C
	public override object get_TypedValue() { }

	// RVA: 0x7094CF0
	public override object get_ValueType() { }

	// RVA: 0x7094FC4
	public override object get_ValueAsBoolean() { }

	// RVA: 0x70953E0
	public override object get_ValueAsDateTime() { }

	// RVA: 0x7095804
	public override object get_ValueAsDouble() { }

	// RVA: 0x7095C28
	public override object get_ValueAsInt() { }

	// RVA: 0x709604C
	public override object get_ValueAsLong() { }

	// RVA: 0x7096470
	public override object ValueAs(object returnType, object nsResolver) { }

	// RVA: 0x70968B4
	private object System.ICloneable.Clone() { }

	// RVA: 0x70968F8
	public virtual object CreateNavigator() { }

	// RVA: -1
	public abstract object get_NameTable() { }

	// RVA: 0x709693C
	public virtual object LookupNamespace(object prefix) { }

	// RVA: 0x7096BB8
	public virtual object LookupPrefix(object namespaceURI) { }

	// RVA: 0x7096EC8
	public virtual object GetNamespacesInScope(object scope) { }

	// RVA: -1
	public abstract object Clone() { }

	// RVA: -1
	public abstract object get_NodeType() { }

	// RVA: -1
	public abstract object get_LocalName() { }

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: -1
	public abstract object get_NamespaceURI() { }

	// RVA: -1
	public abstract object get_Prefix() { }

	// RVA: -1
	public abstract object get_BaseURI() { }

	// RVA: 0x70971E0
	public virtual object get_XmlLang() { }

	// RVA: 0x7097340
	public virtual object get_UnderlyingObject() { }

	// RVA: 0x7097348
	public virtual object MoveToAttribute(object localName, object namespaceURI) { }

	// RVA: -1
	public abstract object MoveToFirstAttribute() { }

	// RVA: -1
	public abstract object MoveToNextAttribute() { }

	// RVA: 0x7097498
	public virtual object MoveToNamespace(object name) { }

	// RVA: -1
	public abstract object MoveToFirstNamespace(object namespaceScope) { }

	// RVA: -1
	public abstract object MoveToNextNamespace(object namespaceScope) { }

	// RVA: 0x70975A8
	public object MoveToFirstNamespace() { }

	// RVA: 0x70975F0
	public object MoveToNextNamespace() { }

	// RVA: -1
	public abstract object MoveToNext() { }

	// RVA: -1
	public abstract object MoveToFirstChild() { }

	// RVA: -1
	public abstract object MoveToParent() { }

	// RVA: 0x7097638
	public virtual object MoveToRoot() { }

	// RVA: -1
	public abstract object MoveTo(object other) { }

	// RVA: -1
	public abstract object MoveToId(object id) { }

	// RVA: 0x7097688
	public virtual object MoveToChild(object localName, object namespaceURI) { }

	// RVA: 0x7097808
	public virtual object MoveToChild(object type) { }

	// RVA: 0x7097A68
	public virtual object MoveToFollowing(object localName, object namespaceURI, object end) { }

	// RVA: 0x7097F30
	public virtual object MoveToFollowing(object type, object end) { }

	// RVA: 0x7098274
	public virtual object MoveToNext(object localName, object namespaceURI) { }

	// RVA: 0x70983D8
	public virtual object MoveToNext(object type) { }

	// RVA: -1
	public abstract object IsSamePosition(object other) { }

	// RVA: 0x7098580
	public virtual object IsDescendant(object nav) { }

	// RVA: 0x7098658
	public virtual object ComparePosition(object nav) { }

	// RVA: 0x7098E34
	public virtual object get_SchemaInfo() { }

	// RVA: 0x7098E8C
	public virtual object Select(object xpath) { }

	// RVA: 0x7098EE0
	public virtual object Select(object expr) { }

	// RVA: 0x7098FB8
	public virtual object Evaluate(object expr) { }

	// RVA: 0x7099008
	public virtual object Evaluate(object expr, object context) { }

	// RVA: 0x7099250
	public virtual object SelectChildren(object type) { }

	// RVA: 0x70992EC
	public virtual object SelectChildren(object name, object namespaceURI) { }

	// RVA: 0x7099390
	public virtual object SelectDescendants(object type, object matchSelf) { }

	// RVA: 0x7099434
	public virtual object SelectDescendants(object name, object namespaceURI, object matchSelf) { }

	// RVA: 0x7097D54
	internal object MoveToNonDescendant() { }

	// RVA: 0x7098B8C
	private static object GetDepth(object nav) { }

	// RVA: 0x7098BF8
	private object CompareSiblings(object n1, object n2) { }

	// RVA: 0x70979C0
	internal static object GetContentKindMask(object type) { }

	// RVA: 0x70994E8
	internal static object GetKindMask(object type) { }

	// RVA: 0x709950C
	internal static object IsText(object type) { }

	// RVA: 0x709951C
	protected object .ctor() { }

	// RVA: 0x7099524
	private static object .cctor() { }

}

// Namespace: System.Xml.XPath
internal class XPathNavigatorKeyComparer
{

	// Methods

	// RVA: 0x7099694
	private object System.Collections.IEqualityComparer.Equals(object obj1, object obj2) { }

	// RVA: 0x709979C
	private object System.Collections.IEqualityComparer.GetHashCode(object obj) { }

	// RVA: 0x709968C
	public object .ctor() { }

}

// Namespace: 
private class Enumerator
{

	// Fields
	private object original; // 0x8
	private object current; // 0x10
	private object iterationStarted; // 0x18

	// Properties
	public virtual object Current { get; }

	// Methods

	// RVA: 0x7099C30
	public object .ctor(object original) { }

	// RVA: 0x7099CA0
	public virtual object get_Current() { }

	// RVA: 0x7099E38
	public virtual object MoveNext() { }

	// RVA: 0x7099EFC
	public virtual object Reset() { }

}

// Namespace: System.Xml.XPath
public abstract class XPathNodeIterator
{

	// Fields
	internal object count; // 0x8

	// Properties
	public abstract object Current { get; }
	public abstract object CurrentPosition { get; }
	public virtual object Count { get; }

	// Methods

	// RVA: 0x7099A90
	private object System.ICloneable.Clone() { }

	// RVA: -1
	public abstract object Clone() { }

	// RVA: -1
	public abstract object MoveNext() { }

	// RVA: -1
	public abstract object get_Current() { }

	// RVA: -1
	public abstract object get_CurrentPosition() { }

	// RVA: 0x7099AD0
	public virtual object get_Count() { }

	// RVA: 0x7099B94
	public virtual object GetEnumerator() { }

	// RVA: 0x7099C90
	protected object .ctor() { }

}

// Namespace: System.Xml.XPath
public enum XPathNodeType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Root;
	public const object Element;
	public const object Attribute;
	public const object Namespace;
	public const object Text;
	public const object SignificantWhitespace;
	public const object Whitespace;
	public const object ProcessingInstruction;
	public const object Comment;
	public const object All;
}

// Namespace: System.Xml.Serialization
public class CodeIdentifier
{

	// Fields
	internal static object csharp; // 0x0

	// Methods

	// RVA: 0x7099F04
	public static object MakePascal(object identifier) { }

	// RVA: 0x709A120
	public static object MakeValid(object identifier) { }

	// RVA: 0x709A3F4
	private static object IsValidStart(object c) { }

	// RVA: 0x709A374
	private static object IsValid(object c) { }

	// RVA: 0x709A464
	private static object .cctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlSerializerNamespaces
{

	// Fields
	private object namespaces; // 0x8

	// Properties
	public object Count { get; }
	internal object NamespaceList { get; }
	internal object Namespaces { get; set; }

	// Methods

	// RVA: 0x709A4E0
	public object .ctor() { }

	// RVA: 0x709A4E8
	public object Add(object prefix, object ns) { }

	// RVA: 0x709A670
	internal object AddInternal(object prefix, object ns) { }

	// RVA: 0x709A79C
	public object ToArray() { }

	// RVA: 0x709AEA4
	public object get_Count() { }

	// RVA: 0x709A8C4
	internal object get_NamespaceList() { }

	// RVA: 0x709A720
	internal object get_Namespaces() { }

	// RVA: 0x709AF3C
	internal object set_Namespaces(object value) { }

}

// Namespace: System.Xml.Serialization
public sealed class XmlAttributeEventHandler
{

	// Methods

	// RVA: 0x709B248
	public object .ctor(object object, object method) { }

	// RVA: 0x709B354
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Xml.Serialization
public class XmlAttributeEventArgs
{

	// Fields
	private object o; // 0x8
	private object attr; // 0x10
	private object qnames; // 0x18
	private object lineNumber; // 0x20
	private object linePosition; // 0x24

	// Methods

	// RVA: 0x709B368
	internal object .ctor(object attr, object lineNumber, object linePosition, object o, object qnames) { }

}

// Namespace: System.Xml.Serialization
public sealed class XmlElementEventHandler
{

	// Methods

	// RVA: 0x709B704
	public object .ctor(object object, object method) { }

	// RVA: 0x709B810
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Xml.Serialization
public class XmlElementEventArgs
{

	// Fields
	private object o; // 0x8
	private object elem; // 0x10
	private object qnames; // 0x18
	private object lineNumber; // 0x20
	private object linePosition; // 0x24

	// Methods

	// RVA: 0x709B824
	internal object .ctor(object elem, object lineNumber, object linePosition, object o, object qnames) { }

}

// Namespace: System.Xml.Serialization
public sealed class XmlNodeEventHandler
{

	// Methods

	// RVA: 0x709BBC0
	public object .ctor(object object, object method) { }

	// RVA: 0x709BCCC
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Xml.Serialization
public class XmlNodeEventArgs
{

	// Fields
	private object o; // 0x8
	private object xmlNode; // 0x10
	private object lineNumber; // 0x18
	private object linePosition; // 0x1C

	// Methods

	// RVA: 0x709BCE0
	internal object .ctor(object xmlNode, object lineNumber, object linePosition, object o) { }

}

// Namespace: System.Xml.Serialization
public sealed class UnreferencedObjectEventHandler
{

	// Methods

	// RVA: 0x709C074
	public object .ctor(object object, object method) { }

	// RVA: 0x709C180
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Xml.Serialization
public class UnreferencedObjectEventArgs
{

	// Fields
	private object o; // 0x8
	private object id; // 0x10

	// Methods

	// RVA: 0x709C194
	public object .ctor(object o, object id) { }

}

// Namespace: System.Xml.Serialization
public interface IXmlSerializable
{

	// Methods

	// RVA: -1
	public abstract object GetSchema() { }

	// RVA: -1
	public abstract object ReadXml(object reader) { }

	// RVA: -1
	public abstract object WriteXml(object writer) { }

}

// Namespace: System.Xml.Serialization
public interface IXmlTextParser
{

	// Properties
	public abstract object Normalized { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_Normalized() { }

	// RVA: -1
	public abstract object set_Normalized(object value) { }

}

// Namespace: System.Xml.Serialization
internal class KeyHelper
{

	// Methods

	// RVA: 0x709C210
	public static object AddField(object sb, object n, object val) { }

	// RVA: 0x709C218
	public static object AddField(object sb, object n, object val, object def) { }

	// RVA: 0x709C318
	public static object AddField(object sb, object n, object val) { }

	// RVA: 0x709C370
	public static object AddField(object sb, object n, object val, object def) { }

	// RVA: 0x709C3CC
	public static object AddField(object sb, object n, object val, object def) { }

	// RVA: 0x709C498
	public static object AddField(object sb, object n, object val) { }

}

// Namespace: System.Xml.Serialization
internal class ReflectionHelper
{

	// Fields
	private object _clrTypes; // 0x8
	private object _schemaTypes; // 0x10
	private static readonly object empty_modifiers; // 0x0

	// Methods

	// RVA: 0x709C5EC
	public object RegisterSchemaType(object map, object xmlType, object ns) { }

	// RVA: 0x709C6FC
	public object GetRegisteredSchemaType(object xmlType, object ns) { }

	// RVA: 0x709C80C
	public object RegisterClrType(object map, object type, object ns) { }

	// RVA: 0x709C9D4
	public object GetRegisteredClrType(object type, object ns) { }

	// RVA: 0x709CB90
	public static object CheckSerializableType(object type, object allowPrivateConstructors) { }

	// RVA: 0x709CF94
	public object .ctor() { }

	// RVA: 0x709D018
	private static object .cctor() { }

}

// Namespace: System.Xml.Serialization
internal enum SchemaTypes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NotSet;
	public const object Primitive;
	public const object Enum;
	public const object Array;
	public const object Class;
	public const object XmlSerializable;
	public const object XmlNode;
	public const object Void;
}

// Namespace: System.Xml.Serialization
internal abstract class SerializationSource
{

	// Fields
	private object includedTypes; // 0x8
	private object namspace; // 0x10
	private object canBeGenerated; // 0x18

	// Methods

	// RVA: 0x709D08C
	public object .ctor(object namspace, object includedTypes) { }

	// RVA: 0x709D0CC
	protected object BaseEquals(object other) { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeSerializationSource
{

	// Fields
	private object attributeOverridesHash; // 0x20
	private object type; // 0x28
	private object rootHash; // 0x30

	// Methods

	// RVA: 0x709D21C
	public object .ctor(object type, object root, object attributeOverrides, object namspace, object includedTypes) { }

	// RVA: 0x709D368
	public override object Equals(object o) { }

	// RVA: 0x709D474
	public override object GetHashCode() { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeConvertorAttribute
{

	// Fields
	private object <Method>k__BackingField; // 0x8

	// Properties
	public object Method { get; set; }

	// Methods

	// RVA: 0x709D4C0
	public object get_Method() { }

	// RVA: 0x709D4C8
	private object set_Method(object value) { }

	// RVA: 0x709D4D0
	public object .ctor(object method) { }

}

// Namespace: System.Xml.Serialization
internal class TypeData
{

	// Fields
	private object type; // 0x8
	private object elementName; // 0x10
	private object sType; // 0x18
	private object listItemType; // 0x20
	private object typeName; // 0x28
	private object fullTypeName; // 0x30
	private object listItemTypeData; // 0x38
	private object mappedType; // 0x40
	private object facet; // 0x48
	private object typeConvertor; // 0x50
	private object hasPublicConstructor; // 0x58
	private object nullableOverride; // 0x59
	private static object keywords; // 0x0

	// Properties
	public object TypeName { get; }
	public object XmlType { get; }
	public object Type { get; }
	public object FullTypeName { get; }
	public object SchemaType { get; }
	public object IsListType { get; }
	public object IsComplexType { get; }
	public object IsValueType { get; }
	public object IsNullable { get; set; }
	public object ListItemTypeData { get; }
	public object ListItemType { get; }
	public object IsXsdType { get; }
	public object HasPublicConstructor { get; }

	// Methods

	// RVA: 0x709D4FC
	public object .ctor(object type, object elementName, object isPrimitive) { }

	// RVA: 0x709D508
	public object .ctor(object type, object elementName, object isPrimitive, object mappedType, object facet) { }

	// RVA: 0x709DC38
	private object LookupTypeConvertor() { }

	// RVA: 0x709DD0C
	internal object ConvertForAssignment(object value) { }

	// RVA: 0x709DDF4
	public object get_TypeName() { }

	// RVA: 0x709DDFC
	public object get_XmlType() { }

	// RVA: 0x709DE04
	public object get_Type() { }

	// RVA: 0x709DE0C
	public object get_FullTypeName() { }

	// RVA: 0x709DE14
	public object get_SchemaType() { }

	// RVA: 0x709CF84
	public object get_IsListType() { }

	// RVA: 0x709DE1C
	public object get_IsComplexType() { }

	// RVA: 0x709DE54
	public object get_IsValueType() { }

	// RVA: 0x709DF24
	public object get_IsNullable() { }

	// RVA: 0x709E114
	public object set_IsNullable(object value) { }

	// RVA: 0x709D9D0
	public object get_ListItemTypeData() { }

	// RVA: 0x709E11C
	public object get_ListItemType() { }

	// RVA: 0x709DE44
	public object get_IsXsdType() { }

	// RVA: 0x709EFFC
	public object get_HasPublicConstructor() { }

	// RVA: 0x709ECE4
	public static object GetIndexerProperty(object collectionType) { }

	// RVA: 0x709EE94
	private static object CreateMissingAddMethodException(object type, object inheritFrom, object argumentType) { }

	// RVA: 0x709EA24
	internal static object GetGenericListItemType(object type) { }

	// RVA: 0x709F004
	private static object .cctor() { }

}

// Namespace: System.Xml.Serialization
internal sealed class TypeMember
{

	// Fields
	private object type; // 0x8
	private object member; // 0x10

	// Methods

	// RVA: 0x709FBC4
	internal object .ctor(object type, object member) { }

	// RVA: 0x709FBFC
	public override object GetHashCode() { }

	// RVA: 0x709FC90
	public override object Equals(object obj) { }

	// RVA: 0x709FD80
	public static object Equals(object tm1, object tm2) { }

	// RVA: 0x709FE68
	public override object ToString() { }

}

// Namespace: System.Xml.Serialization
internal class TypeTranslator
{

	// Fields
	private static object nameCache; // 0x0
	private static object primitiveTypes; // 0x8
	private static object primitiveArrayTypes; // 0x10
	private static object nullableTypes; // 0x18

	// Methods

	// RVA: 0x709FEF8
	private static object .cctor() { }

	// RVA: 0x709CF1C
	public static object GetTypeData(object type) { }

	// RVA: 0x70A2B24
	public static object GetTypeData(object runtimeType, object xmlDataType, object underlyingEnumType) { }

	// RVA: 0x70A39DC
	public static object GetPrimitiveTypeData(object typeName) { }

	// RVA: 0x70A3A64
	public static object GetPrimitiveTypeData(object typeName, object nullable) { }

	// RVA: 0x70A3CE0
	public static object FindPrimitiveTypeData(object typeName) { }

	// RVA: 0x709DB1C
	public static object GetArrayName(object elemName) { }

	// RVA: 0x70A3DE4
	public static object ParseArrayType(object arrayType, object type, object ns, object dimensions) { }

}

// Namespace: System.Xml.Serialization
public class XmlAnyAttributeAttribute
{

	// Methods

	// RVA: 0x70A3F5C
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlAnyElementAttribute
{

	// Fields
	private object elementName; // 0x8
	private object ns; // 0x10
	private object order; // 0x18

	// Properties
	public object Name { get; }
	public object Namespace { get; }
	public object Order { get; }

	// Methods

	// RVA: 0x70A3F64
	public object .ctor() { }

	// RVA: 0x70A3F74
	public object get_Name() { }

	// RVA: 0x70A3FE0
	public object get_Namespace() { }

	// RVA: 0x70A3FE8
	public object get_Order() { }

	// RVA: 0x70A3FF0
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public class XmlAnyElementAttributes
{

	// Properties
	public object Item { get; }
	internal object Order { get; }

	// Methods

	// RVA: 0x70A4094
	public object get_Item(object index) { }

	// RVA: 0x70A41D8
	public object Add(object attribute) { }

	// RVA: 0x70A42C0
	internal object AddKeyHash(object sb) { }

	// RVA: 0x70A43B0
	internal object get_Order() { }

	// RVA: 0x70A46D8
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlArrayAttribute
{

	// Fields
	private object elementName; // 0x8
	private object form; // 0x10
	private object isNullable; // 0x14
	private object ns; // 0x18
	private object order; // 0x20

	// Properties
	public object ElementName { get; }
	public object Form { get; }
	public object IsNullable { get; }
	public object Namespace { get; }
	public object Order { get; }

	// Methods

	// RVA: 0x70A46E0
	public object get_ElementName() { }

	// RVA: 0x70A474C
	public object get_Form() { }

	// RVA: 0x70A4754
	public object get_IsNullable() { }

	// RVA: 0x70A475C
	public object get_Namespace() { }

	// RVA: 0x70A4764
	public object get_Order() { }

	// RVA: 0x70A476C
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public class XmlArrayItemAttribute
{

	// Fields
	private object dataType; // 0x8
	private object elementName; // 0x10
	private object form; // 0x18
	private object ns; // 0x20
	private object isNullable; // 0x28
	private object isNullableSpecified; // 0x29
	private object nestingLevel; // 0x2C
	private object type; // 0x30

	// Properties
	public object DataType { get; }
	public object ElementName { get; }
	public object Form { get; }
	public object Namespace { get; }
	public object IsNullable { get; }
	internal object IsNullableSpecified { get; }
	public object Type { get; }
	public object NestingLevel { get; }

	// Methods

	// RVA: 0x70A48AC
	public object get_DataType() { }

	// RVA: 0x70A4918
	public object get_ElementName() { }

	// RVA: 0x70A4984
	public object get_Form() { }

	// RVA: 0x70A498C
	public object get_Namespace() { }

	// RVA: 0x70A4994
	public object get_IsNullable() { }

	// RVA: 0x70A499C
	internal object get_IsNullableSpecified() { }

	// RVA: 0x70A49A4
	public object get_Type() { }

	// RVA: 0x70A49AC
	public object get_NestingLevel() { }

	// RVA: 0x70A49B4
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public class XmlArrayItemAttributes
{

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x70A4B38
	public object get_Item(object index) { }

	// RVA: 0x70A4C7C
	public object Add(object attribute) { }

	// RVA: 0x70A4D64
	internal object AddKeyHash(object sb) { }

	// RVA: 0x70A4E54
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlAttributeAttribute
{

	// Fields
	private object attributeName; // 0x8
	private object dataType; // 0x10
	private object type; // 0x18
	private object form; // 0x20
	private object ns; // 0x28

	// Properties
	public object AttributeName { get; }
	public object DataType { get; set; }
	public object Form { get; }
	public object Namespace { get; }

	// Methods

	// RVA: 0x70A4E5C
	public object .ctor(object attributeName) { }

	// RVA: 0x70A4E88
	public object get_AttributeName() { }

	// RVA: 0x70A4EF4
	public object get_DataType() { }

	// RVA: 0x70A4F60
	public object set_DataType(object value) { }

	// RVA: 0x70A4F68
	public object get_Form() { }

	// RVA: 0x70A4F70
	public object get_Namespace() { }

	// RVA: 0x70A4F78
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public class XmlAttributeOverrides
{

	// Fields
	private object overrides; // 0x8

	// Properties
	public object Item { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x70A50CC
	public object .ctor() { }

	// RVA: 0x70A513C
	public object get_Item(object type) { }

	// RVA: 0x70A51A4
	public object get_Item(object type, object member) { }

	// RVA: 0x70A52B8
	private object GetKey(object type, object member) { }

	// RVA: 0x70A5328
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public class XmlAttributes
{

	// Fields
	private object xmlAnyAttribute; // 0x8
	private object xmlAnyElements; // 0x10
	private object xmlArray; // 0x18
	private object xmlArrayItems; // 0x20
	private object xmlAttribute; // 0x28
	private object xmlChoiceIdentifier; // 0x30
	private object xmlDefaultValue; // 0x38
	private object xmlElements; // 0x40
	private object xmlEnum; // 0x48
	private object xmlIgnore; // 0x50
	private object xmlns; // 0x51
	private object xmlRoot; // 0x58
	private object xmlText; // 0x60
	private object xmlType; // 0x68

	// Properties
	public object XmlAnyAttribute { get; }
	public object XmlAnyElements { get; }
	public object XmlArray { get; }
	public object XmlArrayItems { get; }
	public object XmlAttribute { get; }
	public object XmlChoiceIdentifier { get; }
	public object XmlDefaultValue { get; }
	public object XmlElements { get; }
	public object XmlIgnore { get; }
	public object Xmlns { get; }
	public object XmlRoot { get; }
	public object XmlText { get; }
	public object XmlType { get; }
	internal object Order { get; }
	internal object SortableOrder { get; }

	// Methods

	// RVA: 0x70A5C34
	public object .ctor() { }

	// RVA: 0x70A5D3C
	public object .ctor(object provider) { }

	// RVA: 0x70A6594
	public object get_XmlAnyAttribute() { }

	// RVA: 0x70A659C
	public object get_XmlAnyElements() { }

	// RVA: 0x70A65A4
	public object get_XmlArray() { }

	// RVA: 0x70A65AC
	public object get_XmlArrayItems() { }

	// RVA: 0x70A65B4
	public object get_XmlAttribute() { }

	// RVA: 0x70A65BC
	public object get_XmlChoiceIdentifier() { }

	// RVA: 0x70A65C4
	public object get_XmlDefaultValue() { }

	// RVA: 0x70A65CC
	public object get_XmlElements() { }

	// RVA: 0x70A65D4
	public object get_XmlIgnore() { }

	// RVA: 0x70A65DC
	public object get_Xmlns() { }

	// RVA: 0x70A65E4
	public object get_XmlRoot() { }

	// RVA: 0x70A65EC
	public object get_XmlText() { }

	// RVA: 0x70A65F4
	public object get_XmlType() { }

	// RVA: 0x70A58E8
	internal object AddKeyHash(object sb) { }

	// RVA: 0x70A7638
	internal object get_Order() { }

	// RVA: 0x70A7A50
	internal object get_SortableOrder() { }

}

// Namespace: System.Xml.Serialization
public class XmlChoiceIdentifierAttribute
{

	// Fields
	private object memberName; // 0x8

	// Properties
	public object MemberName { get; }

	// Methods

	// RVA: 0x70A7AE0
	public object get_MemberName() { }

	// RVA: 0x70A75A8
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
internal class XmlCustomFormatter
{

	// Fields
	private static object allTimeFormats; // 0x0

	// Methods

	// RVA: 0x70A7B4C
	internal static object FromEnum(object value, object values, object ids, object typeName) { }

	// RVA: 0x70A7F14
	internal static object FromXmlName(object name) { }

	// RVA: 0x70A7F9C
	internal static object FromXmlNCName(object ncName) { }

	// RVA: 0x70A66EC
	internal static object ToXmlString(object type, object value) { }

	// RVA: 0x70A8024
	internal static object FromXmlString(object type, object value) { }

	// RVA: 0x70A8BD0
	private static object .cctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlElementAttribute
{

	// Fields
	private object dataType; // 0x8
	private object elementName; // 0x10
	private object form; // 0x18
	private object ns; // 0x20
	private object isNullable; // 0x28
	private object type; // 0x30
	private object order; // 0x38

	// Properties
	public object DataType { get; }
	public object ElementName { get; }
	public object Form { get; }
	public object Namespace { get; }
	public object IsNullable { get; }
	public object Order { get; }
	public object Type { get; }

	// Methods

	// RVA: 0x70A8FB0
	public object .ctor(object elementName) { }

	// RVA: 0x70A8FE4
	public object .ctor(object elementName, object type) { }

	// RVA: 0x70A9028
	public object get_DataType() { }

	// RVA: 0x70A9094
	public object get_ElementName() { }

	// RVA: 0x70A9100
	public object get_Form() { }

	// RVA: 0x70A9108
	public object get_Namespace() { }

	// RVA: 0x70A9110
	public object get_IsNullable() { }

	// RVA: 0x70A9118
	public object get_Order() { }

	// RVA: 0x70A9120
	public object get_Type() { }

	// RVA: 0x70A9128
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public class XmlElementAttributes
{

	// Properties
	public object Item { get; }
	internal object Order { get; }

	// Methods

	// RVA: 0x70A9290
	public object get_Item(object index) { }

	// RVA: 0x70A64AC
	public object Add(object attribute) { }

	// RVA: 0x70A65FC
	internal object AddKeyHash(object sb) { }

	// RVA: 0x70A7728
	internal object get_Order() { }

	// RVA: 0x70A5D34
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlEnumAttribute
{

	// Fields
	private object name; // 0x8

	// Properties
	public object Name { get; }

	// Methods

	// RVA: 0x70A93D4
	public object .ctor(object name) { }

	// RVA: 0x70A9400
	public object get_Name() { }

	// RVA: 0x70A744C
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public class XmlIgnoreAttribute
{

	// Methods

	// RVA: 0x70A9408
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlIncludeAttribute
{

	// Fields
	private object type; // 0x8

	// Properties
	public object Type { get; }

	// Methods

	// RVA: 0x70A9410
	public object get_Type() { }

}

// Namespace: System.Xml.Serialization
public abstract class XmlMapping
{

	// Fields
	private object map; // 0x8
	private object relatedMaps; // 0x10
	private object format; // 0x18
	private object source; // 0x20
	internal object _elementName; // 0x28
	internal object _namespace; // 0x30
	private object key; // 0x38

	// Properties
	public object ElementName { get; }
	public object Namespace { get; }
	internal object ObjectMap { get; set; }
	internal object RelatedMaps { get; set; }
	internal object Format { get; set; }
	internal object Source { get; }

	// Methods

	// RVA: 0x70A9418
	internal object .ctor(object elementName, object ns) { }

	// RVA: 0x70A9450
	public object get_ElementName() { }

	// RVA: 0x70A9458
	public object get_Namespace() { }

	// RVA: 0x70A9460
	public object SetKey(object key) { }

	// RVA: 0x70A9468
	internal object get_ObjectMap() { }

	// RVA: 0x70A9470
	internal object set_ObjectMap(object value) { }

	// RVA: 0x70A9478
	internal object get_RelatedMaps() { }

	// RVA: 0x70A9480
	internal object set_RelatedMaps(object value) { }

	// RVA: 0x70A9488
	internal object get_Format() { }

	// RVA: 0x70A9490
	internal object set_Format(object value) { }

	// RVA: 0x70A9498
	internal object get_Source() { }

}

// Namespace: System.Xml.Serialization
internal class ObjectMap
{

	// Methods

	// RVA: 0x70A94A0
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
internal enum SerializationFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Encoded;
	public const object Literal;
}

// Namespace: System.Xml.Serialization
public class XmlMemberMapping
{
}

// Namespace: System.Xml.Serialization
public class XmlMembersMapping
{

	// Fields
	private object _hasWrapperElement; // 0x40
	private object _mapping; // 0x48

	// Properties
	public object Count { get; }
	internal object HasWrapperElement { get; }

	// Methods

	// RVA: 0x70A94A8
	public object get_Count() { }

	// RVA: 0x70A94CC
	internal object get_HasWrapperElement() { }

}

// Namespace: System.Xml.Serialization
public class XmlNamespaceDeclarationsAttribute
{

	// Methods

	// RVA: 0x70A94D4
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__28_0; // 0x8

	// Methods

	// RVA: 0x70B22F4
	private static object .cctor() { }

	// RVA: 0x70B2354
	public object .ctor() { }

	// RVA: 0x70B235C
	internal object <ImportClassMapping>b__28_0(object m1, object m2) { }

}

// Namespace: System.Xml.Serialization
public class XmlReflectionImporter
{

	// Fields
	private object initialDefaultNamespace; // 0x8
	private object attributeOverrides; // 0x10
	private object includedTypes; // 0x18
	private object helper; // 0x20
	private object arrayChoiceCount; // 0x28
	private object relatedMaps; // 0x30
	private object allowPrivateTypes; // 0x38
	private static readonly object errSimple; // 0x0
	private static readonly object errSimple2; // 0x8

	// Methods

	// RVA: 0x70A94DC
	public object .ctor(object attributeOverrides, object defaultNamespace) { }

	// RVA: 0x70A964C
	public object ImportTypeMapping(object type) { }

	// RVA: 0x70A9858
	public object ImportTypeMapping(object type, object defaultNamespace) { }

	// RVA: 0x70A9658
	public object ImportTypeMapping(object type, object root, object defaultNamespace) { }

	// RVA: 0x70A9864
	private object ImportTypeMapping(object typeData, object root, object defaultNamespace) { }

	// RVA: 0x70ACE48
	private object CreateTypeMapping(object typeData, object root, object defaultXmlType, object defaultNamespace) { }

	// RVA: 0x70AD480
	private object ImportClassMapping(object type, object root, object defaultNamespace, object isBaseType) { }

	// RVA: 0x70A9D50
	private object ImportClassMapping(object typeData, object root, object defaultNamespace, object isBaseType) { }

	// RVA: 0x70AF87C
	private object RegisterDerivedMap(object map, object derivedMap) { }

	// RVA: 0x70AD51C
	private object GetTypeNamespace(object typeData, object root, object defaultNamespace) { }

	// RVA: 0x70AFC48
	private object ImportListMapping(object type, object root, object defaultNamespace, object atts, object nestingLevel) { }

	// RVA: 0x70AB134
	private object ImportListMapping(object typeData, object root, object defaultNamespace, object atts, object nestingLevel) { }

	// RVA: 0x70AC218
	private object ImportXmlNodeMapping(object typeData, object root, object defaultNamespace) { }

	// RVA: 0x70AC484
	private object ImportPrimitiveMapping(object typeData, object root, object defaultNamespace) { }

	// RVA: 0x70AC578
	private object ImportEnumMapping(object typeData, object root, object defaultNamespace) { }

	// RVA: 0x70ACCF4
	private object ImportXmlSerializableMapping(object typeData, object root, object defaultNamespace) { }

	// RVA: 0x70AFABC
	private object ImportIncludedTypes(object type, object defaultNamespace) { }

	// RVA: 0x70AD694
	private object GetReflectionMembers(object type) { }

	// RVA: 0x70AEC40
	private object CreateMapMember(object declaringType, object rmember, object defaultNamespace) { }

	// RVA: 0x70B0420
	private object ImportElementInfo(object cls, object defaultName, object defaultNamespace, object defaultType, object member, object atts) { }

	// RVA: 0x70AFD2C
	private object ImportAnyElementInfo(object defaultNamespace, object rmember, object member, object atts) { }

	// RVA: 0x70B1848
	private object ImportTextElementInfo(object list, object defaultType, object member, object atts, object defaultNamespace) { }

	// RVA: 0x70AD3B0
	private object CanBeNull(object type) { }

	// RVA: 0x70B1C38
	public object IncludeType(object type) { }

	// RVA: 0x70B164C
	private object GetDefaultValue(object typeData, object defaultValue) { }

	// RVA: 0x70B226C
	private static object .cctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlReflectionMember
{

	// Fields
	private object isReturnValue; // 0x8
	private object memberName; // 0x10
	private object memberType; // 0x18
	private object xmlAttributes; // 0x20
	private object declaringType; // 0x28

	// Properties
	public object IsReturnValue { get; }
	public object MemberName { get; }
	public object MemberType { get; }
	public object XmlAttributes { get; }
	internal object DeclaringType { get; set; }

	// Methods

	// RVA: 0x70AFCEC
	internal object .ctor(object name, object type, object attributes) { }

	// RVA: 0x70B2514
	public object get_IsReturnValue() { }

	// RVA: 0x70B251C
	public object get_MemberName() { }

	// RVA: 0x70B2524
	public object get_MemberType() { }

	// RVA: 0x70AEB88
	public object get_XmlAttributes() { }

	// RVA: 0x70B252C
	internal object get_DeclaringType() { }

	// RVA: 0x70B2534
	internal object set_DeclaringType(object value) { }

}

// Namespace: System.Xml.Serialization
public class XmlRootAttribute
{

	// Fields
	private object dataType; // 0x8
	private object elementName; // 0x10
	private object isNullable; // 0x18
	private object ns; // 0x20

	// Properties
	public object DataType { get; set; }
	public object ElementName { get; set; }
	public object IsNullable { get; set; }
	public object Namespace { get; set; }

	// Methods

	// RVA: 0x70B253C
	public object .ctor() { }

	// RVA: 0x70B254C
	public object .ctor(object elementName) { }

	// RVA: 0x70B2580
	public object get_DataType() { }

	// RVA: 0x70B25EC
	public object set_DataType(object value) { }

	// RVA: 0x70AD414
	public object get_ElementName() { }

	// RVA: 0x70B25F4
	public object set_ElementName(object value) { }

	// RVA: 0x70B25FC
	public object get_IsNullable() { }

	// RVA: 0x70B2604
	public object set_IsNullable(object value) { }

	// RVA: 0x70B260C
	public object get_Namespace() { }

	// RVA: 0x70B2614
	public object set_Namespace(object value) { }

	// RVA: 0x70A74DC
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public sealed class XmlSchemaProviderAttribute
{

	// Fields
	private object _methodName; // 0x8
	private object _isAny; // 0x10

	// Properties
	public object MethodName { get; }
	public object IsAny { get; set; }

	// Methods

	// RVA: 0x70B261C
	public object .ctor(object methodName) { }

	// RVA: 0x70B2648
	public object get_MethodName() { }

	// RVA: 0x70B2650
	public object get_IsAny() { }

	// RVA: 0x70B2658
	public object set_IsAny(object value) { }

}

// Namespace: System.Xml.Serialization
public sealed class XmlSerializationCollectionFixupCallback
{

	// Methods

	// RVA: 0x70B2964
	public object .ctor(object object, object method) { }

	// RVA: 0x70B2A70
	public virtual object Invoke(object collection, object collectionItems) { }

}

// Namespace: System.Xml.Serialization
public sealed class XmlSerializationFixupCallback
{

	// Methods

	// RVA: 0x70B2D5C
	public object .ctor(object object, object method) { }

	// RVA: 0x70B2E78
	public virtual object Invoke(object fixup) { }

}

// Namespace: System.Xml.Serialization
public abstract class XmlSerializationGeneratedCode
{

	// Methods

	// RVA: 0x70B2E8C
	protected object .ctor() { }

}

// Namespace: System.Xml.Serialization
public sealed class XmlSerializationReadCallback
{

	// Methods

	// RVA: 0x70B2EF4
	public object .ctor(object object, object method) { }

	// RVA: 0x70B2F88
	public virtual object Invoke() { }

}

// Namespace: 
private class WriteCallbackInfo
{

	// Fields
	public object Type; // 0x8
	public object TypeName; // 0x10
	public object TypeNs; // 0x18
	public object Callback; // 0x20

	// Methods

	// RVA: 0x70B3BA4
	public object .ctor() { }

}

// Namespace: 
protected class CollectionFixup
{

	// Fields
	private object callback; // 0x8
	private object collection; // 0x10
	private object collectionItems; // 0x18
	private object id; // 0x20

	// Properties
	public object Callback { get; }
	public object Collection { get; }
	internal object Id { get; }
	public object CollectionItems { get; set; }

	// Methods

	// RVA: 0x70B92D8
	internal object .ctor(object collection, object callback, object id) { }

	// RVA: 0x70B9318
	public object get_Callback() { }

	// RVA: 0x70B9320
	public object get_Collection() { }

	// RVA: 0x70B9328
	internal object get_Id() { }

	// RVA: 0x70B9330
	public object get_CollectionItems() { }

	// RVA: 0x70B9338
	internal object set_CollectionItems(object value) { }

}

// Namespace: 
protected class Fixup
{

	// Fields
	private object source; // 0x8
	private object ids; // 0x10
	private object callback; // 0x18

	// Properties
	public object Callback { get; }
	public object Ids { get; }
	public object Source { get; }

	// Methods

	// RVA: 0x70B9340
	public object .ctor(object o, object callback, object count) { }

	// RVA: 0x70B93C4
	public object get_Callback() { }

	// RVA: 0x70B93CC
	public object get_Ids() { }

	// RVA: 0x70B93D4
	public object get_Source() { }

}

// Namespace: 
private class CollectionItemFixup
{

	// Fields
	private object list; // 0x8
	private object index; // 0x10
	private object id; // 0x18

	// Properties
	public object Collection { get; }
	public object Index { get; }
	public object Id { get; }

	// Methods

	// RVA: 0x70B6E64
	public object .ctor(object list, object index, object id) { }

	// RVA: 0x70B93DC
	public object get_Collection() { }

	// RVA: 0x70B93E4
	public object get_Index() { }

	// RVA: 0x70B93EC
	public object get_Id() { }

}

// Namespace: System.Xml.Serialization
public abstract class XmlSerializationReader
{

	// Fields
	private object document; // 0x8
	private object reader; // 0x10
	private object fixups; // 0x18
	private object collFixups; // 0x20
	private object collItemFixups; // 0x28
	private object typesCallbacks; // 0x30
	private object noIDTargets; // 0x38
	private object targets; // 0x40
	private object delayedListFixups; // 0x48
	private object eventSource; // 0x50
	private object delayedFixupId; // 0x58
	private object referencedObjects; // 0x60
	private object readCount; // 0x68
	private object whileIterationCount; // 0x6C
	private object w3SchemaNS; // 0x70
	private object w3InstanceNS; // 0x78
	private object w3InstanceNS2000; // 0x80
	private object w3InstanceNS1999; // 0x88
	private object soapNS; // 0x90
	private object wsdlNS; // 0x98
	private object nullX; // 0xA0
	private object nil; // 0xA8
	private object typeX; // 0xB0
	private object arrayType; // 0xB8
	private object arrayQName; // 0xC0

	// Properties
	protected object Document { get; }
	protected object Reader { get; }

	// Methods

	// RVA: 0x70B2F9C
	internal object Initialize(object reader, object eventSource) { }

	// RVA: 0x70B3598
	private object EnsureArrayList(object list) { }

	// RVA: 0x70B360C
	private object EnsureHashtable(object hash) { }

	// RVA: 0x70B3680
	protected object .ctor() { }

	// RVA: 0x70B3688
	protected object get_Document() { }

	// RVA: 0x70B374C
	protected object get_Reader() { }

	// RVA: 0x70B3754
	protected object AddFixup(object fixup) { }

	// RVA: 0x70B38F8
	protected object AddFixup(object fixup) { }

	// RVA: 0x70B39A8
	private object AddFixup(object fixup) { }

	// RVA: 0x70B3A58
	protected object AddReadCallback(object name, object ns, object type, object read) { }

	// RVA: 0x70B3BAC
	protected object AddTarget(object id, object o) { }

	// RVA: 0x70B3D68
	private object CurrentTag() { }

	// RVA: 0x70B3F94
	protected object CreateReadOnlyCollectionException(object name) { }

	// RVA: 0x70B4024
	protected object CreateUnknownConstantException(object value, object enumType) { }

	// RVA: 0x70B40C4
	protected object CreateUnknownNodeException() { }

	// RVA: 0x70B415C
	protected object CreateUnknownTypeException(object type) { }

	// RVA: 0x70B42C4
	protected object EnsureArrayIndex(object a, object index, object elementType) { }

	// RVA: 0x70B4360
	protected object GetNullAttr() { }

	// RVA: 0x70B4504
	protected object GetTarget(object id) { }

	// RVA: 0x70B460C
	private object TargetReady(object id) { }

	// RVA: 0x70B4668
	protected object GetXsiType() { }

	// RVA: -1
	protected abstract object InitCallbacks() { }

	// RVA: -1
	protected abstract object InitIDs() { }

	// RVA: 0x70B4930
	protected object IsXmlnsAttribute(object name) { }

	// RVA: 0x70B49DC
	protected object ParseWsdlArrayType(object attr) { }

	// RVA: 0x70B4BE4
	protected object ReadElementQualifiedName() { }

	// RVA: 0x70B50B8
	protected object ReadEndElement() { }

	// RVA: 0x70B522C
	protected object ReadNull() { }

	// RVA: 0x70B5474
	protected object ReadNullableQualifiedName() { }

	// RVA: 0x70B54AC
	protected object ReadNullableString() { }

	// RVA: 0x70B5524
	protected object ReadReferencedElement() { }

	// RVA: 0x70B5968
	private object GetCallbackInfo(object qname) { }

	// RVA: 0x70B55C8
	protected object ReadReferencedElement(object name, object ns) { }

	// RVA: 0x70B5A84
	private object ReadList(object resultList) { }

	// RVA: 0x70B6EA8
	protected object ReadReferencedElements() { }

	// RVA: 0x70B80F8
	protected object ReadReferencingElement(object fixupReference) { }

	// RVA: 0x70B6E58
	protected object ReadReferencingElement(object name, object ns, object fixupReference) { }

	// RVA: 0x70B81A8
	protected object ReadReferencingElement(object name, object ns, object elementCanBeType, object fixupReference) { }

	// RVA: 0x70B8608
	protected object ReadSerializable(object serializable) { }

	// RVA: 0x70B88EC
	protected object ReadTypedPrimitive(object type) { }

	// RVA: 0x70B61F0
	private object ReadTypedPrimitive(object qname, object reportUnknown) { }

	// RVA: 0x70B8BB8
	protected object ReadXmlNode(object wrapped) { }

	// RVA: 0x70B8C88
	protected object ReadXmlDocument(object wrapped) { }

	// RVA: 0x70B8E74
	protected object ShrinkArray(object a, object length, object elementType, object isNullable) { }

	// RVA: 0x70B4D90
	protected object ToXmlQualifiedName(object value) { }

	// RVA: 0x70B8F34
	protected object UnknownAttribute(object o, object attr, object qnames) { }

	// RVA: 0x70B90B8
	protected object UnknownElement(object o, object elem, object qnames) { }

	// RVA: 0x70B53E4
	protected object UnknownNode(object o) { }

	// RVA: 0x70B923C
	protected object UnknownNode(object o, object qnames) { }

	// RVA: 0x70B88F4
	private object OnUnknownNode(object node, object o, object qnames) { }

	// RVA: 0x70B804C
	protected object UnreferencedObject(object id, object o) { }

}

// Namespace: 
private class FixupCallbackInfo
{

	// Fields
	private object _sri; // 0x8
	private object _map; // 0x10
	private object _isValueList; // 0x18

	// Methods

	// RVA: 0x70BF678
	public object .ctor(object sri, object map, object isValueList) { }

	// RVA: 0x70C0BFC
	public object FixupMembers(object fixup) { }

}

// Namespace: 
private class ReaderCallbackInfo
{

	// Fields
	private object _sri; // 0x8
	private object _typeMap; // 0x10

	// Methods

	// RVA: 0x70B98AC
	public object .ctor(object sri, object typeMap) { }

	// RVA: 0x70C0C2C
	internal object ReadObject() { }

}

// Namespace: System.Xml.Serialization
internal class XmlSerializationReaderInterpreter
{

	// Fields
	private object _typeMap; // 0xC8
	private object _format; // 0xD0
	private static readonly object AnyType; // 0x0
	private static readonly object empty_array; // 0x8

	// Methods

	// RVA: 0x70B93F4
	public object .ctor(object typeMap) { }

	// RVA: 0x70B9438
	protected override object InitCallbacks() { }

	// RVA: 0x70B98E4
	protected override object InitIDs() { }

	// RVA: 0x70B98E8
	public object ReadRoot() { }

	// RVA: 0x70B9B88
	private object ReadEncodedObject(object typeMap) { }

	// RVA: 0x70B9D80
	protected virtual object ReadMessage(object typeMap) { }

	// RVA: 0x70B9A2C
	private object ReadRoot(object rootMap) { }

	// RVA: 0x70BDA80
	protected virtual object ReadObject(object typeMap, object isNullable, object checkType) { }

	// RVA: 0x70BE694
	protected virtual object ReadClassInstance(object typeMap, object isNullable, object checkType) { }

	// RVA: 0x70BEAC4
	protected virtual object ReadClassInstanceMembers(object typeMap, object ob) { }

	// RVA: 0x70BA644
	private object ReadAttributeMembers(object map, object ob, object isValueList) { }

	// RVA: 0x70BACE4
	private object ReadMembers(object map, object ob, object isValueList, object readBySoapOrder) { }

	// RVA: 0x70BF34C
	private object SetListMembersDefaults(object map, object ob, object isValueList) { }

	// RVA: 0x70BFA78
	internal object FixupMembers(object map, object obfixup, object isValueList) { }

	// RVA: 0x70BFF04
	protected virtual object ProcessUnknownAttribute(object target) { }

	// RVA: 0x70BFF94
	protected virtual object ProcessUnknownElement(object target) { }

	// RVA: 0x70BF514
	private object IsReadOnly(object member, object memType, object ob, object isValueList) { }

	// RVA: 0x70BECD8
	private object SetMemberValue(object member, object ob, object value, object isValueList) { }

	// RVA: 0x70BA52C
	private object SetMemberValueFromAttr(object member, object ob, object value, object isValueList) { }

	// RVA: 0x70BEEC0
	private object GetMemberValue(object member, object ob, object isValueList) { }

	// RVA: 0x70BF78C
	private object ReadObjectElement(object elem) { }

	// RVA: 0x70C0024
	private object ReadPrimitiveValue(object elem) { }

	// RVA: 0x70BEB7C
	private object GetValueFromXmlString(object value, object typeData, object typeMap) { }

	// RVA: 0x70BDBF8
	private object ReadListElement(object typeMap, object isNullable, object list, object canCreateInstance) { }

	// RVA: 0x70C01B4
	private object ReadListString(object typeMap, object values) { }

	// RVA: 0x70BEFB4
	private object AddListValue(object listType, object list, object index, object value, object canCreateInstance) { }

	// RVA: 0x70BEABC
	private static object CreateInstance(object type, object nonPublic) { }

	// RVA: 0x70BA4BC
	private object CreateInstance(object type) { }

	// RVA: 0x70BF6B8
	private object CreateList(object listType) { }

	// RVA: 0x70BF5BC
	private object InitializeList(object listType) { }

	// RVA: 0x70C0640
	private object FillList(object list, object items) { }

	// RVA: 0x70C0650
	private object CopyEnumerableList(object source, object dest) { }

	// RVA: 0x70BDA5C
	private object ReadXmlNodeElement(object typeMap, object isNullable) { }

	// RVA: 0x70BF9A8
	private object ReadXmlNode(object type, object wrapped) { }

	// RVA: 0x70BE21C
	private object ReadPrimitiveElement(object typeMap, object isNullable) { }

	// RVA: 0x70BE314
	private object ReadEnumElement(object typeMap, object isNullable) { }

	// RVA: 0x70C04B4
	private object GetEnumValue(object typeMap, object val) { }

	// RVA: 0x70BE3D0
	private object ReadXmlSerializableElement(object typeMap, object isNullable) { }

	// RVA: 0x70C0B1C
	private static object .cctor() { }

}

// Namespace: System.Xml.Serialization
public sealed class XmlSerializationWriteCallback
{

	// Methods

	// RVA: 0x70C0F60
	public object .ctor(object object, object method) { }

	// RVA: 0x70C107C
	public virtual object Invoke(object o) { }

}

// Namespace: 
private class WriteCallbackInfo
{

	// Fields
	public object Type; // 0x8
	public object TypeName; // 0x10
	public object TypeNs; // 0x18
	public object Callback; // 0x20

	// Methods

	// RVA: 0x70C572C
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
public abstract class XmlSerializationWriter
{

	// Fields
	private object idGenerator; // 0x8
	private object qnameCount; // 0x10
	private object topLevelElement; // 0x14
	private object namespaces; // 0x18
	private object writer; // 0x20
	private object referencedElements; // 0x28
	private object callbacks; // 0x30
	private object serializedObjects; // 0x38

	// Properties
	protected object Writer { get; }

	// Methods

	// RVA: 0x70C1090
	protected object .ctor() { }

	// RVA: 0x70C1104
	internal object Initialize(object writer, object nss) { }

	// RVA: 0x70C1264
	protected object get_Writer() { }

	// RVA: 0x70C126C
	protected object AddWriteCallback(object type, object typeName, object typeNs, object callback) { }

	// RVA: 0x70C1374
	protected object CreateUnknownAnyElementException(object name, object ns) { }

	// RVA: 0x70C1414
	protected object CreateUnknownTypeException(object o) { }

	// RVA: 0x70C14C0
	protected object CreateUnknownTypeException(object type) { }

	// RVA: 0x70C1550
	protected object FromXmlQualifiedName(object xmlQualifiedName) { }

	// RVA: 0x70C1734
	private object GetId(object o, object addToReferencesList) { }

	// RVA: 0x70C1874
	private object AlreadyQueued(object ob) { }

	// RVA: 0x70C18F0
	private object GetNamespacePrefix(object ns) { }

	// RVA: 0x70C1658
	private object GetQualifiedName(object name, object ns) { }

	// RVA: -1
	protected abstract object InitCallbacks() { }

	// RVA: 0x70C1A90
	protected object TopLevelElement() { }

	// RVA: 0x70C1A9C
	protected object WriteAttribute(object localName, object ns, object value) { }

	// RVA: 0x70C1A64
	protected object WriteAttribute(object prefix, object localName, object ns, object value) { }

	// RVA: 0x70C1AD8
	private object WriteXmlNode(object node) { }

	// RVA: 0x70C1BA4
	protected object WriteElementEncoded(object node, object name, object ns, object isNullable, object any) { }

	// RVA: 0x70C1F44
	protected object WriteElementLiteral(object node, object name, object ns, object isNullable, object any) { }

	// RVA: 0x70C22DC
	protected object WriteElementQualifiedName(object localName, object ns, object value) { }

	// RVA: 0x70C22E4
	protected object WriteElementQualifiedName(object localName, object ns, object value, object xsiType) { }

	// RVA: 0x70C266C
	protected object WriteElementString(object localName, object ns, object value) { }

	// RVA: 0x70C2674
	protected object WriteElementString(object localName, object ns, object value, object xsiType) { }

	// RVA: 0x70C2620
	protected object WriteEndElement() { }

	// RVA: 0x70C28A8
	protected object WriteEndElement(object o) { }

	// RVA: 0x70C2948
	protected object WriteNamespaceDeclarations(object xmlns) { }

	// RVA: 0x70C2E2C
	protected object WriteNullableQualifiedNameEncoded(object name, object ns, object value, object xsiType) { }

	// RVA: 0x70C2F14
	protected object WriteNullableQualifiedNameLiteral(object name, object ns, object value) { }

	// RVA: 0x70C2FEC
	protected object WriteNullableStringEncoded(object name, object ns, object value, object xsiType) { }

	// RVA: 0x70C2FF8
	protected object WriteNullableStringLiteral(object name, object ns, object value) { }

	// RVA: 0x70C1E48
	protected object WriteNullTagEncoded(object name, object ns) { }

	// RVA: 0x70C21E8
	protected object WriteNullTagLiteral(object name, object ns) { }

	// RVA: 0x70C3008
	protected object WritePotentiallyReferencingElement(object n, object ns, object o, object ambientType, object suppressReference, object isNullable) { }

	// RVA: 0x70C38E8
	protected object WriteReferencedElements() { }

	// RVA: 0x70C37D4
	private object IsPrimitiveArray(object td) { }

	// RVA: 0x70C3BC8
	private object WriteArray(object o, object td) { }

	// RVA: 0x70C3F24
	protected object WriteReferencingElement(object n, object ns, object o, object isNullable) { }

	// RVA: 0x70C3744
	private object CheckReferenceQueue() { }

	// RVA: 0x70C4178
	protected object WriteSerializable(object serializable, object name, object ns, object isNullable) { }

	// RVA: 0x70C4180
	protected object WriteSerializable(object serializable, object name, object ns, object isNullable, object wrapped) { }

	// RVA: 0x70C43BC
	protected object WriteStartDocument() { }

	// RVA: 0x70C24E8
	protected object WriteStartElement(object name, object ns) { }

	// RVA: 0x70C3734
	protected object WriteStartElement(object name, object ns, object writePrefixed) { }

	// RVA: 0x70C4460
	protected object WriteStartElement(object name, object ns, object o) { }

	// RVA: 0x70C4458
	protected object WriteStartElement(object name, object ns, object o, object writePrefixed) { }

	// RVA: 0x70C446C
	private object WriteStartElement(object name, object ns, object o, object writePrefixed, object namespaces) { }

	// RVA: 0x70C4F70
	protected object WriteTypedPrimitive(object name, object ns, object o, object xsiType) { }

	// RVA: 0x70C5334
	protected object WriteValue(object value) { }

	// RVA: 0x70C539C
	protected object WriteXmlAttribute(object node, object container) { }

	// RVA: 0x70C24F8
	protected object WriteXsiType(object name, object ns) { }

}

// Namespace: 
private class CallbackInfo
{

	// Fields
	private object _swi; // 0x8
	private object _typeMap; // 0x10

	// Methods

	// RVA: 0x70C5BE8
	public object .ctor(object swi, object typeMap) { }

	// RVA: 0x70CD45C
	internal object WriteObject(object ob) { }

	// RVA: 0x70CD500
	internal object WriteEnum(object ob) { }

}

// Namespace: System.Xml.Serialization
internal class XmlSerializationWriterInterpreter
{

	// Fields
	private object _typeMap; // 0x40
	private object _format; // 0x48

	// Methods

	// RVA: 0x70C5734
	public object .ctor(object typeMap) { }

	// RVA: 0x70C5778
	protected override object InitCallbacks() { }

	// RVA: 0x70C5C20
	public object WriteRoot(object ob) { }

	// RVA: 0x70C5E94
	protected virtual object WriteObject(object typeMap, object ob, object element, object namesp, object isNullable, object needType, object writeWrappingElem) { }

	// RVA: 0x70C6CD8
	protected virtual object WriteMessage(object membersMap, object parameters) { }

	// RVA: 0x70C6F88
	protected virtual object WriteObjectElement(object typeMap, object ob, object element, object namesp) { }

	// RVA: 0x70C725C
	protected virtual object WriteObjectElementAttributes(object typeMap, object ob) { }

	// RVA: 0x70C7B44
	protected virtual object WriteObjectElementElements(object typeMap, object ob) { }

	// RVA: 0x70C6F44
	private object WriteMembers(object map, object ob, object isValueList) { }

	// RVA: 0x70C7310
	private object WriteAttributeMembers(object map, object ob, object isValueList) { }

	// RVA: 0x70C7BF8
	private object WriteElementMembers(object map, object ob, object isValueList) { }

	// RVA: 0x70C870C
	private object GetMemberValue(object member, object ob, object isValueList) { }

	// RVA: 0x70C8418
	private object MemberHasValue(object member, object ob, object isValueList) { }

	// RVA: 0x70C9004
	private object WriteMemberElement(object elem, object memberValue) { }

	// RVA: 0x70C66D4
	internal static object ImplicitConvert(object obj, object type) { }

	// RVA: 0x70CB34C
	private object WritePrimitiveValueLiteral(object memberValue, object name, object ns, object mappedType, object typeData, object wrapped, object isNullable) { }

	// RVA: 0x70CB6F4
	private object WritePrimitiveValueEncoded(object memberValue, object name, object ns, object xsiType, object mappedType, object typeData, object wrapped, object isNullable) { }

	// RVA: 0x70CB9D0
	protected virtual object WriteListElement(object typeMap, object ob, object element, object namesp) { }

	// RVA: 0x70C96DC
	private object WriteListContent(object container, object listType, object map, object ob, object targetString) { }

	// RVA: 0x70CBBE4
	private object GetListCount(object listType, object ob) { }

	// RVA: 0x70CA100
	private object WriteAnyElementContent(object member, object memberValue) { }

	// RVA: 0x70CCEB0
	protected virtual object WritePrimitiveElement(object typeMap, object ob, object element, object namesp) { }

	// RVA: 0x70CCF24
	protected virtual object WriteEnumElement(object typeMap, object ob, object element, object namesp) { }

	// RVA: 0x70C8CDC
	private object GetStringValue(object typeMap, object type, object value) { }

	// RVA: 0x70CCF80
	private object GetEnumXmlValue(object typeMap, object ob) { }

}

// Namespace: 
internal class SerializerData
{

	// Fields
	public object ReaderMethod; // 0x8
	public object WriterType; // 0x10
	public object WriterMethod; // 0x18
	public object Implementation; // 0x20

	// Methods

	// RVA: 0x70CE7C0
	public object CreateWriter() { }

}

// Namespace: System.Xml.Serialization
public class XmlSerializer
{

	// Fields
	private static object generationThreshold; // 0x0
	private static object backgroundGeneration; // 0x4
	private static object deleteTempFiles; // 0x5
	private static object generatorFallback; // 0x6
	private object customSerializer; // 0x8
	private object typeMapping; // 0x10
	private object serializerData; // 0x18
	private static object serializerTypes; // 0x8
	private object onUnreferencedObject; // 0x20
	private object onUnknownAttribute; // 0x28
	private object onUnknownElement; // 0x30
	private object onUnknownNode; // 0x38

	// Properties
	internal object Mapping { get; }

	// Methods

	// RVA: 0x70CD5A4
	private static object .cctor() { }

	// RVA: 0x70CD654
	public object .ctor(object type) { }

	// RVA: 0x70CD668
	public object .ctor(object type, object overrides, object extraTypes, object root, object defaultNamespace) { }

	// RVA: 0x70CD820
	internal object get_Mapping() { }

	// RVA: 0x70CD828
	internal virtual object OnUnknownAttribute(object e) { }

	// RVA: 0x70CD84C
	internal virtual object OnUnknownElement(object e) { }

	// RVA: 0x70CD870
	internal virtual object OnUnknownNode(object e) { }

	// RVA: 0x70CD894
	internal virtual object OnUnreferencedObject(object e) { }

	// RVA: 0x70CD8B8
	protected virtual object CreateReader() { }

	// RVA: 0x70CD8F8
	protected virtual object CreateWriter() { }

	// RVA: 0x70CD938
	public object Deserialize(object stream) { }

	// RVA: 0x70CDACC
	public object Deserialize(object textReader) { }

	// RVA: 0x70CD9D8
	public object Deserialize(object xmlReader) { }

	// RVA: 0x70CDBD4
	protected virtual object Deserialize(object reader) { }

	// RVA: 0x70CDEE8
	protected virtual object Serialize(object o, object writer) { }

	// RVA: 0x70CE124
	public object Serialize(object textWriter, object o) { }

	// RVA: 0x70CE558
	public object Serialize(object xmlWriter, object o) { }

	// RVA: 0x70CE1C8
	public object Serialize(object xmlWriter, object o, object namespaces) { }

	// RVA: 0x70CE560
	private object CreateWriter(object typeMapping) { }

	// RVA: 0x70CDB6C
	private object CreateReader(object typeMapping) { }

}

// Namespace: System.Xml.Serialization
public class XmlSerializerFactory
{

	// Fields
	private static object serializersBySource; // 0x0

	// Methods

	// RVA: 0x70CE8F8
	public object .ctor() { }

	// RVA: 0x70CE900
	public object CreateSerializer(object type) { }

	// RVA: 0x70CEC08
	public object CreateSerializer(object type, object root) { }

	// RVA: 0x70CE914
	public object CreateSerializer(object type, object overrides, object extraTypes, object root, object defaultNamespace) { }

	// RVA: 0x70CEC1C
	private static object .cctor() { }

}

// Namespace: System.Xml.Serialization
public abstract class XmlSerializerImplementation
{

	// Properties
	public virtual object Writer { get; }

	// Methods

	// RVA: 0x70CEC98
	public virtual object get_Writer() { }

}

// Namespace: System.Xml.Serialization
public class XmlTextAttribute
{

	// Fields
	private object dataType; // 0x8
	private object type; // 0x10

	// Properties
	public object DataType { get; }
	public object Type { get; }

	// Methods

	// RVA: 0x70CECD8
	public object .ctor() { }

	// RVA: 0x70CECE0
	public object get_DataType() { }

	// RVA: 0x70CED4C
	public object get_Type() { }

	// RVA: 0x70CED54
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
public class XmlTypeAttribute
{

	// Fields
	private object includeInSchema; // 0x8
	private object ns; // 0x10
	private object typeName; // 0x18

	// Properties
	public object IncludeInSchema { get; }
	public object Namespace { get; }
	public object TypeName { get; }

	// Methods

	// RVA: 0x70CEDF8
	public object get_IncludeInSchema() { }

	// RVA: 0x70CEE00
	public object get_Namespace() { }

	// RVA: 0x70CEE08
	public object get_TypeName() { }

	// RVA: 0x70CEE74
	internal object AddKeyHash(object sb) { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapElementInfo
{

	// Fields
	private object _elementName; // 0x8
	private object _namespace; // 0x10
	private object _form; // 0x18
	private object _member; // 0x20
	private object _choiceValue; // 0x28
	private object _isNullable; // 0x30
	private object _nestingLevel; // 0x34
	private object _mappedType; // 0x38
	private object _type; // 0x40
	private object _wrappedElement; // 0x48
	private object _explicitOrder; // 0x4C

	// Properties
	public object TypeData { get; }
	public object ChoiceValue { get; set; }
	public object ElementName { get; set; }
	public object Namespace { get; set; }
	public object DataTypeNamespace { get; }
	public object DataTypeName { get; }
	public object Form { get; set; }
	public object MappedType { get; set; }
	public object IsNullable { get; set; }
	public object Member { get; }
	public object NestingLevel { set; }
	public object MultiReferenceType { get; }
	public object WrappedElement { get; set; }
	public object IsTextElement { get; set; }
	public object IsUnnamedAnyElement { get; set; }
	public object ExplicitOrder { get; set; }

	// Methods

	// RVA: 0x70CEF2C
	public object .ctor(object member, object type) { }

	// RVA: 0x70CEFEC
	public object get_TypeData() { }

	// RVA: 0x70CEFF4
	public object get_ChoiceValue() { }

	// RVA: 0x70CEFFC
	public object set_ChoiceValue(object value) { }

	// RVA: 0x70CF004
	public object get_ElementName() { }

	// RVA: 0x70CF00C
	public object set_ElementName(object value) { }

	// RVA: 0x70CF014
	public object get_Namespace() { }

	// RVA: 0x70CF01C
	public object set_Namespace(object value) { }

	// RVA: 0x70CB648
	public object get_DataTypeNamespace() { }

	// RVA: 0x70CB614
	public object get_DataTypeName() { }

	// RVA: 0x70CF024
	public object get_Form() { }

	// RVA: 0x70CF02C
	public object set_Form(object value) { }

	// RVA: 0x70CF034
	public object get_MappedType() { }

	// RVA: 0x70CF03C
	public object set_MappedType(object value) { }

	// RVA: 0x70CF044
	public object get_IsNullable() { }

	// RVA: 0x70CF04C
	public object set_IsNullable(object value) { }

	// RVA: 0x70CF054
	public object get_Member() { }

	// RVA: 0x70CF05C
	public object set_NestingLevel(object value) { }

	// RVA: 0x70CF064
	public object get_MultiReferenceType() { }

	// RVA: 0x70CF078
	public object get_WrappedElement() { }

	// RVA: 0x70CF080
	public object set_WrappedElement(object value) { }

	// RVA: 0x70CF088
	public object get_IsTextElement() { }

	// RVA: 0x70CF0E0
	public object set_IsTextElement(object value) { }

	// RVA: 0x70CF1A4
	public object get_IsUnnamedAnyElement() { }

	// RVA: 0x70CF204
	public object set_IsUnnamedAnyElement(object value) { }

	// RVA: 0x70CF2B0
	public object get_ExplicitOrder() { }

	// RVA: 0x70CF2B8
	public object set_ExplicitOrder(object value) { }

	// RVA: 0x70CF2C0
	public override object Equals(object other) { }

	// RVA: 0x70CF434
	public override object GetHashCode() { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapElementInfoList
{

	// Methods

	// RVA: 0x70CF43C
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMember
{

	// Fields
	private object _name; // 0x8
	private object _index; // 0x10
	private object _globalIndex; // 0x14
	private object _specifiedGlobalIndex; // 0x18
	private object _typeData; // 0x20
	private object _member; // 0x28
	private object _specifiedMember; // 0x30
	private object _shouldSerialize; // 0x38
	private object _defaultValue; // 0x40
	private object _flags; // 0x48

	// Properties
	public object Name { get; set; }
	public object DefaultValue { get; set; }
	public object TypeData { get; set; }
	public object Index { get; set; }
	public object GlobalIndex { get; set; }
	public object IsOptionalValueType { get; set; }
	public object IsReturnValue { get; set; }

	// Methods

	// RVA: 0x70CF444
	public object .ctor() { }

	// RVA: 0x70CF4C0
	public object get_Name() { }

	// RVA: 0x70CF4C8
	public object set_Name(object value) { }

	// RVA: 0x70CF4D0
	public object get_DefaultValue() { }

	// RVA: 0x70CF4D8
	public object set_DefaultValue(object value) { }

	// RVA: 0x70CF4E0
	public object IsReadOnly(object type) { }

	// RVA: 0x70CF8FC
	public static object GetValue(object ob, object name) { }

	// RVA: 0x70C70F4
	public object GetValue(object ob) { }

	// RVA: 0x70CFAA8
	public object SetValue(object ob, object value) { }

	// RVA: 0x70CFC3C
	public static object SetValue(object ob, object name, object value) { }

	// RVA: 0x70CF604
	private object InitMember(object type) { }

	// RVA: 0x70CFDDC
	public object get_TypeData() { }

	// RVA: 0x70CFDE4
	public object set_TypeData(object value) { }

	// RVA: 0x70CFDEC
	public object get_Index() { }

	// RVA: 0x70CFDF4
	public object set_Index(object value) { }

	// RVA: 0x70CFDFC
	public object get_GlobalIndex() { }

	// RVA: 0x70CFE04
	public object set_GlobalIndex(object value) { }

	// RVA: 0x70CB09C
	public object get_IsOptionalValueType() { }

	// RVA: 0x70CFE0C
	public object set_IsOptionalValueType(object value) { }

	// RVA: 0x70CFE20
	public object get_IsReturnValue() { }

	// RVA: 0x70CFE2C
	public object set_IsReturnValue(object value) { }

	// RVA: 0x70CFE4C
	public object CheckOptionalValueType(object type) { }

	// RVA: 0x70CB0A8
	public object GetValueSpecified(object ob) { }

	// RVA: 0x70CFEC8
	public object SetValueSpecified(object ob, object value) { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMemberAttribute
{

	// Fields
	private object _attributeName; // 0x50
	private object _namespace; // 0x58
	private object _form; // 0x60
	private object _mappedType; // 0x68

	// Properties
	public object AttributeName { get; set; }
	public object Namespace { get; set; }
	public object Form { set; }
	public object MappedType { get; set; }

	// Methods

	// RVA: 0x70D01A8
	public object .ctor() { }

	// RVA: 0x70D0254
	public object get_AttributeName() { }

	// RVA: 0x70D025C
	public object set_AttributeName(object value) { }

	// RVA: 0x70D0264
	public object get_Namespace() { }

	// RVA: 0x70D026C
	public object set_Namespace(object value) { }

	// RVA: 0x70D0274
	public object set_Form(object value) { }

	// RVA: 0x70D027C
	public object get_MappedType() { }

	// RVA: 0x70D0284
	public object set_MappedType(object value) { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMemberElement
{

	// Fields
	private object _elementInfo; // 0x50
	private object _choiceMember; // 0x58
	private object _isTextCollector; // 0x60
	private object _choiceTypeData; // 0x68

	// Properties
	public object ElementInfo { get; set; }
	public object ChoiceMember { get; set; }
	public object ChoiceTypeData { get; set; }
	public object IsXmlTextCollector { get; set; }

	// Methods

	// RVA: 0x70D028C
	public object .ctor() { }

	// RVA: 0x70C8F88
	public object get_ElementInfo() { }

	// RVA: 0x70D0308
	public object set_ElementInfo(object value) { }

	// RVA: 0x70D0310
	public object get_ChoiceMember() { }

	// RVA: 0x70D0318
	public object set_ChoiceMember(object value) { }

	// RVA: 0x70D0320
	public object get_ChoiceTypeData() { }

	// RVA: 0x70D0328
	public object set_ChoiceTypeData(object value) { }

	// RVA: 0x70CA7D8
	public object FindElement(object ob, object memberValue) { }

	// RVA: 0x70D0330
	public object SetChoice(object ob, object choice) { }

	// RVA: 0x70D0340
	public object get_IsXmlTextCollector() { }

	// RVA: 0x70D0348
	public object set_IsXmlTextCollector(object value) { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMemberList
{

	// Methods

	// RVA: 0x70D0350
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMemberExpandable
{

	// Fields
	private object _flatArrayIndex; // 0x70

	// Properties
	public object FlatArrayIndex { get; set; }

	// Methods

	// RVA: 0x70D03CC
	public object get_FlatArrayIndex() { }

	// RVA: 0x70D03D4
	public object set_FlatArrayIndex(object value) { }

	// RVA: 0x70D03DC
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMemberFlatList
{

	// Fields
	private object _listMap; // 0x78

	// Properties
	public object ListMap { get; set; }

	// Methods

	// RVA: 0x70D0458
	public object get_ListMap() { }

	// RVA: 0x70D0460
	public object set_ListMap(object value) { }

	// RVA: 0x70D0468
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMemberAnyElement
{

	// Properties
	public object IsDefaultAny { get; }

	// Methods

	// RVA: 0x70CCA74
	public object IsElementDefined(object name, object ns) { }

	// RVA: 0x70D04E4
	public object get_IsDefaultAny() { }

	// RVA: 0x70D08EC
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMemberAnyAttribute
{

	// Methods

	// RVA: 0x70D0968
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
internal class XmlTypeMapMemberNamespaces
{

	// Methods

	// RVA: 0x70D09E4
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
public class XmlTypeMapping
{

	// Fields
	private object xmlType; // 0x40
	private object xmlTypeNamespace; // 0x48
	private object type; // 0x50
	private object baseMap; // 0x58
	private object multiReferenceType; // 0x60
	private object includeInSchema; // 0x61
	private object isNullable; // 0x62
	private object isAny; // 0x63
	private object _derivedTypes; // 0x68

	// Properties
	public object TypeFullName { get; }
	internal object TypeData { get; }
	internal object XmlType { get; set; }
	internal object XmlTypeNamespace { get; set; }
	internal object HasXmlTypeNamespace { get; }
	internal object DerivedTypes { get; }
	internal object MultiReferenceType { get; }
	internal object BaseMap { get; set; }
	internal object IncludeInSchema { set; }
	internal object IsNullable { get; set; }
	internal object IsAny { get; set; }

	// Methods

	// RVA: 0x70D0A60
	internal object .ctor(object elementName, object ns, object typeData, object xmlType, object xmlTypeNamespace) { }

	// RVA: 0x70CD058
	public object get_TypeFullName() { }

	// RVA: 0x70D0B0C
	internal object get_TypeData() { }

	// RVA: 0x70D0B14
	internal object get_XmlType() { }

	// RVA: 0x70D0B1C
	internal object set_XmlType(object value) { }

	// RVA: 0x70C6C6C
	internal object get_XmlTypeNamespace() { }

	// RVA: 0x70D0B24
	internal object set_XmlTypeNamespace(object value) { }

	// RVA: 0x70D0B2C
	internal object get_HasXmlTypeNamespace() { }

	// RVA: 0x70D0B3C
	internal object get_DerivedTypes() { }

	// RVA: 0x70D0B44
	internal object get_MultiReferenceType() { }

	// RVA: 0x70D0B4C
	internal object get_BaseMap() { }

	// RVA: 0x70D0B54
	internal object set_BaseMap(object value) { }

	// RVA: 0x70D0B5C
	internal object set_IncludeInSchema(object value) { }

	// RVA: 0x70D0B64
	internal object get_IsNullable() { }

	// RVA: 0x70D0B6C
	internal object set_IsNullable(object value) { }

	// RVA: 0x70D0B74
	internal object get_IsAny() { }

	// RVA: 0x70D0B7C
	internal object set_IsAny(object value) { }

	// RVA: 0x70C6A6C
	internal object GetRealTypeMap(object objectType) { }

	// RVA: 0x70D0B84
	internal object GetRealElementMap(object name, object ens) { }

	// RVA: 0x70D0FCC
	internal object UpdateRoot(object qname) { }

}

// Namespace: System.Xml.Serialization
internal class XmlSerializableMapping
{

	// Fields
	private object _schema; // 0x70
	private object _schemaType; // 0x78
	private object _schemaTypeName; // 0x80

	// Methods

	// RVA: 0x70D1088
	internal object .ctor(object root, object elementName, object ns, object typeData, object xmlType, object xmlTypeNamespace) { }

}

// Namespace: System.Xml.Serialization
internal class ClassMap
{

	// Fields
	private object _elements; // 0x8
	private object _elementMembers; // 0x10
	private object _attributeMembers; // 0x18
	private object _attributeMembersArray; // 0x20
	private object _flatLists; // 0x28
	private object _allMembers; // 0x30
	private object _membersWithDefault; // 0x38
	private object _listMembers; // 0x40
	private object _defaultAnyElement; // 0x48
	private object _defaultAnyAttribute; // 0x50
	private object _namespaceDeclarations; // 0x58
	private object _xmlTextCollector; // 0x60
	private object _returnMember; // 0x68
	private object _ignoreMemberNamespace; // 0x70
	private object _canBeSimpleType; // 0x71
	private object _isOrderDependentMap; // 0x72

	// Properties
	public object IsOrderDependentMap { get; }
	public object DefaultAnyElementMember { get; }
	public object DefaultAnyAttributeMember { get; }
	public object NamespaceDeclarations { get; }
	public object AttributeMembers { get; }
	public object ElementMembers { get; }
	public object AllMembers { get; }
	public object FlatLists { get; }
	public object ListMembers { get; }
	public object XmlTextCollector { get; }
	public object ReturnMember { get; }
	public object SimpleContentBaseType { get; }
	public object HasSimpleContent { get; }

	// Methods

	// RVA: 0x70D1A0C
	public object AddMember(object member) { }

	// RVA: 0x70D296C
	private object RegisterFlatList(object member) { }

	// RVA: 0x70D2A64
	public object GetAttribute(object name, object ns) { }

	// RVA: 0x70D2BC8
	public object GetElement(object name, object ns, object minimalOrder) { }

	// RVA: 0x70D3010
	public object GetElement(object name, object ns) { }

	// RVA: 0x70D2884
	private object BuildKey(object name, object ns, object explicitOrder) { }

	// RVA: 0x70D3428
	public object get_IsOrderDependentMap() { }

	// RVA: 0x70D3888
	public object get_DefaultAnyElementMember() { }

	// RVA: 0x70D3890
	public object get_DefaultAnyAttributeMember() { }

	// RVA: 0x70D3898
	public object get_NamespaceDeclarations() { }

	// RVA: 0x70C87FC
	public object get_AttributeMembers() { }

	// RVA: 0x70D38A0
	public object get_ElementMembers() { }

	// RVA: 0x70D38A8
	public object get_AllMembers() { }

	// RVA: 0x70D38B0
	public object get_FlatLists() { }

	// RVA: 0x70D38B8
	public object get_ListMembers() { }

	// RVA: 0x70D38C0
	public object get_XmlTextCollector() { }

	// RVA: 0x70D38C8
	public object get_ReturnMember() { }

	// RVA: 0x70D38D0
	public object get_SimpleContentBaseType() { }

	// RVA: 0x70D3C18
	public object SetCanBeSimpleType(object can) { }

	// RVA: 0x70D3C20
	public object get_HasSimpleContent() { }

	// RVA: 0x70D3CC4
	public object .ctor() { }

}

// Namespace: System.Xml.Serialization
internal class ListMap
{

	// Fields
	private object _itemInfo; // 0x8
	private object _choiceMember; // 0x10

	// Properties
	public object ChoiceMember { set; }
	public object ItemInfo { get; set; }

	// Methods

	// RVA: 0x70D3D64
	public object set_ChoiceMember(object value) { }

	// RVA: 0x70D3D6C
	public object get_ItemInfo() { }

	// RVA: 0x70D3D74
	public object set_ItemInfo(object value) { }

	// RVA: 0x70CC074
	public object FindElement(object ob, object index, object memberValue) { }

	// RVA: 0x70D3D7C
	public object FindElement(object elementName, object ns) { }

	// RVA: 0x70D4108
	public object FindTextElement() { }

	// RVA: 0x70CBD84
	public object GetArrayType(object itemCount, object localName, object ns) { }

	// RVA: 0x70D44A8
	public override object Equals(object other) { }

	// RVA: 0x70D46EC
	public override object GetHashCode() { }

	// RVA: 0x70D46F4
	public object .ctor() { }

}

// Namespace: 
public class EnumMapMember
{

	// Fields
	private readonly object _xmlName; // 0x8
	private readonly object _enumName; // 0x10
	private readonly object _value; // 0x18

	// Properties
	public object XmlName { get; }
	public object EnumName { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x70D4D10
	public object .ctor(object xmlName, object enumName, object value) { }

	// RVA: 0x70D4D50
	public object get_XmlName() { }

	// RVA: 0x70D4D58
	public object get_EnumName() { }

	// RVA: 0x70D4D60
	public object get_Value() { }

}

// Namespace: System.Xml.Serialization
internal class EnumMap
{

	// Fields
	private readonly object _members; // 0x8
	private readonly object _isFlags; // 0x10
	private readonly object _enumNames; // 0x18
	private readonly object _xmlNames; // 0x20
	private readonly object _values; // 0x28

	// Properties
	public object IsFlags { get; }
	public object EnumNames { get; }
	public object XmlNames { get; }
	public object Values { get; }

	// Methods

	// RVA: 0x70D46FC
	public object .ctor(object members, object isFlags) { }

	// RVA: 0x70D48FC
	public object get_IsFlags() { }

	// RVA: 0x70D4904
	public object get_EnumNames() { }

	// RVA: 0x70D490C
	public object get_XmlNames() { }

	// RVA: 0x70D4914
	public object get_Values() { }

	// RVA: 0x70CD07C
	public object GetXmlName(object typeName, object enumValue) { }

	// RVA: 0x70D491C
	public object GetEnumName(object typeName, object xmlName) { }

}

// Namespace: System.Xml.XmlConfiguration
public sealed class XmlReaderSection
{

	// Properties
	internal static object ProhibitDefaultUrlResolver { get; }
	internal static object CollapseWhiteSpaceIntoEmptyString { get; }

	// Methods

	// RVA: 0x70D4D68
	internal static object get_ProhibitDefaultUrlResolver() { }

	// RVA: 0x70D4D70
	internal static object CreateDefaultResolver() { }

	// RVA: 0x70D4DC8
	internal static object get_CollapseWhiteSpaceIntoEmptyString() { }

}

// Namespace: System.Xml.Xsl
public interface IXsltContextFunction
{

	// Properties
	public abstract object ReturnType { get; }

	// Methods

	// RVA: -1
	public abstract object get_ReturnType() { }

	// RVA: -1
	public abstract object Invoke(object xsltContext, object args, object docContext) { }

}

// Namespace: System.Xml.Xsl
public interface IXsltContextVariable
{

	// Properties
	public abstract object VariableType { get; }

	// Methods

	// RVA: -1
	public abstract object get_VariableType() { }

	// RVA: -1
	public abstract object Evaluate(object xsltContext) { }

}

// Namespace: System.Xml.Xsl
public abstract class XsltContext
{

	// Properties
	public abstract object Whitespace { get; }

	// Methods

	// RVA: 0x70D4DD0
	internal object .ctor(object dummy) { }

	// RVA: -1
	public abstract object ResolveVariable(object prefix, object name) { }

	// RVA: -1
	public abstract object ResolveFunction(object prefix, object name, object ArgTypes) { }

	// RVA: -1
	public abstract object get_Whitespace() { }

	// RVA: -1
	public abstract object PreserveWhitespace(object node) { }

}

// Namespace: System.Xml.Xsl.Runtime
public struct StringConcat
{

	// Fields
	private object s1; // 0xFFFFFFFFFFFFFFF8
	private object s2; // 0x0
	private object s3; // 0x8
	private object s4; // 0x10
	private object delimiter; // 0x18
	private object strList; // 0x20
	private object idxStr; // 0x28

	// Properties
	internal object Count { get; }

	// Methods

	// RVA: 0x70D4E14
	public object Clear() { }

	// RVA: 0x70D4E2C
	internal object get_Count() { }

	// RVA: 0x70D4E3C
	public object GetResult() { }

	// RVA: 0x70D4F58
	internal object ConcatNoDelimiter(object s) { }

}

// Namespace: System.Xml.Schema
internal class AxisElement
{

	// Fields
	internal object curNode; // 0x8
	internal object rootDepth; // 0x10
	internal object curDepth; // 0x14
	internal object isMatch; // 0x18

	// Properties
	internal object CurNode { get; }

	// Methods

	// RVA: 0x70D53CC
	internal object get_CurNode() { }

	// RVA: 0x70D53D4
	internal object .ctor(object node, object depth) { }

	// RVA: 0x70D5414
	internal object SetDepth(object depth) { }

	// RVA: 0x70D541C
	internal object MoveToParent(object depth, object parent) { }

	// RVA: 0x70D5564
	internal object MoveToChild(object name, object URN, object depth, object parent) { }

}

// Namespace: System.Xml.Schema
internal class AxisStack
{

	// Fields
	private object _stack; // 0x8
	private object _subtree; // 0x10
	private object _parent; // 0x18

	// Properties
	internal object Subtree { get; }
	internal object Length { get; }

	// Methods

	// RVA: 0x70D58AC
	internal object get_Subtree() { }

	// RVA: 0x70D58B4
	internal object get_Length() { }

	// RVA: 0x70D5904
	public object .ctor(object faxis, object parent) { }

	// RVA: 0x70D59C0
	internal object Push(object depth) { }

	// RVA: 0x70D5A84
	internal object Pop() { }

	// RVA: 0x70D57FC
	internal static object Equal(object thisname, object thisURN, object name, object URN) { }

	// RVA: 0x70D5B04
	internal object MoveToParent(object name, object URN, object depth) { }

	// RVA: 0x70D5D64
	internal object MoveToChild(object name, object URN, object depth) { }

	// RVA: 0x70D5F60
	internal object MoveToAttribute(object name, object URN, object depth) { }

}

// Namespace: System.Xml.Schema
internal class ActiveAxis
{

	// Fields
	private object _currentDepth; // 0x8
	private object _isActive; // 0xC
	private object _axisTree; // 0x10
	private object _axisStack; // 0x18

	// Properties
	public object CurrentDepth { get; }

	// Methods

	// RVA: 0x70D61F0
	public object get_CurrentDepth() { }

	// RVA: 0x70D61F8
	internal object Reactivate() { }

	// RVA: 0x70D620C
	internal object .ctor(object axisTree) { }

	// RVA: 0x70D64B8
	public object MoveToStartElement(object localname, object URN) { }

	// RVA: 0x70D666C
	public virtual object EndElement(object localname, object URN) { }

	// RVA: 0x70D67D8
	public object MoveToAttribute(object localname, object URN) { }

}

// Namespace: System.Xml.Schema
internal class DoubleLinkAxis
{

	// Fields
	internal object next; // 0x38

	// Properties
	internal object Next { get; set; }

	// Methods

	// RVA: 0x70D6940
	internal object get_Next() { }

	// RVA: 0x70D6948
	internal object set_Next(object value) { }

	// RVA: 0x70D6950
	internal object .ctor(object axis, object inputaxis) { }

	// RVA: 0x70D69B8
	internal static object ConvertTree(object axis) { }

}

// Namespace: System.Xml.Schema
internal class ForwardAxis
{

	// Fields
	private object _topNode; // 0x8
	private object _rootNode; // 0x10
	private object _isAttribute; // 0x18
	private object _isDss; // 0x19
	private object _isSelfAxis; // 0x1A

	// Properties
	internal object RootNode { get; }
	internal object TopNode { get; }
	internal object IsAttribute { get; }
	internal object IsDss { get; }
	internal object IsSelfAxis { get; }

	// Methods

	// RVA: 0x70D6AB0
	internal object get_RootNode() { }

	// RVA: 0x70D6AB8
	internal object get_TopNode() { }

	// RVA: 0x70D6AC0
	internal object get_IsAttribute() { }

	// RVA: 0x70D6AC8
	internal object get_IsDss() { }

	// RVA: 0x70D6AD0
	internal object get_IsSelfAxis() { }

	// RVA: 0x70D6AD8
	public object .ctor(object axis, object isdesorself) { }

}

// Namespace: System.Xml.Schema
internal class Asttree
{

	// Fields
	private object _fAxisArray; // 0x8
	private object _xpathexpr; // 0x10
	private object _isField; // 0x18
	private object _nsmgr; // 0x20

	// Properties
	internal object SubtreeArray { get; }

	// Methods

	// RVA: 0x70D6C58
	internal object get_SubtreeArray() { }

	// RVA: 0x70D6C60
	public object .ctor(object xPath, object isField, object nsmgr) { }

	// RVA: 0x70D7580
	private static object IsNameTest(object ast) { }

	// RVA: 0x70D57C0
	internal static object IsAttribute(object ast) { }

	// RVA: 0x70D75BC
	private static object IsDescendantOrSelf(object ast) { }

	// RVA: 0x70D6C14
	internal static object IsSelf(object ast) { }

	// RVA: 0x70D6CB4
	public object CompileXPath(object xPath, object isField, object nsmgr) { }

	// RVA: 0x70D7600
	private object SetURN(object axis, object nsmgr) { }

}

// Namespace: System.Xml.Schema
internal class AutoValidator
{

	// Properties
	public override object PreserveWhitespace { get; }

	// Methods

	// RVA: 0x70D7758
	public object .ctor(object reader, object schemaCollection, object eventHandling) { }

	// RVA: 0x70D78BC
	public override object get_PreserveWhitespace() { }

	// RVA: 0x70D78C4
	public override object Validate() { }

	// RVA: 0x70D8130
	public override object CompleteValidation() { }

	// RVA: 0x70D8134
	public override object FindId(object name) { }

	// RVA: 0x70D7A1C
	private object DetectValidationType() { }

}

// Namespace: System.Xml.Schema
internal class BaseProcessor
{

	// Fields
	private object nameTable; // 0x8
	private object schemaNames; // 0x10
	private object eventHandler; // 0x18
	private object compilationSettings; // 0x20
	private object errorCount; // 0x28
	private object NsXml; // 0x30

	// Properties
	protected object NameTable { get; }
	protected object SchemaNames { get; }
	protected object EventHandler { get; }
	protected object CompilationSettings { get; }
	protected object HasErrors { get; }

	// Methods

	// RVA: 0x70D81F4
	public object .ctor(object nameTable, object schemaNames, object eventHandler) { }

	// RVA: 0x70D82E4
	public object .ctor(object nameTable, object schemaNames, object eventHandler, object compilationSettings) { }

	// RVA: 0x70D839C
	protected object get_NameTable() { }

	// RVA: 0x70D83A4
	protected object get_SchemaNames() { }

	// RVA: 0x70D8434
	protected object get_EventHandler() { }

	// RVA: 0x70D843C
	protected object get_CompilationSettings() { }

	// RVA: 0x70D8444
	protected object get_HasErrors() { }

	// RVA: 0x70D8454
	protected object AddToTable(object table, object qname, object item) { }

	// RVA: 0x70D8984
	private object IsValidAttributeGroupRedefine(object existingObject, object item, object table) { }

	// RVA: 0x70D8C98
	private object IsValidGroupRedefine(object existingObject, object item, object table) { }

	// RVA: 0x70D8B14
	private object IsValidTypeRedefine(object existingObject, object item, object table) { }

	// RVA: 0x70D8F0C
	protected object SendValidationEvent(object code, object source) { }

	// RVA: 0x70D8E08
	protected object SendValidationEvent(object code, object msg, object source) { }

	// RVA: 0x70D90D4
	protected object SendValidationEvent(object code, object msg1, object msg2, object source) { }

	// RVA: 0x70D9234
	protected object SendValidationEvent(object code, object args, object innerException, object source) { }

	// RVA: 0x70D937C
	protected object SendValidationEvent(object code, object msg1, object msg2, object sourceUri, object lineNumber, object linePosition) { }

	// RVA: 0x70D94F4
	protected object SendValidationEvent(object code, object source, object severity) { }

	// RVA: 0x70D957C
	protected object SendValidationEvent(object e) { }

	// RVA: 0x70D9628
	protected object SendValidationEvent(object code, object msg, object source, object severity) { }

	// RVA: 0x70D9008
	protected object SendValidationEvent(object e, object severity) { }

	// RVA: 0x70D96C0
	protected object SendValidationEventNoThrow(object e, object severity) { }

}

// Namespace: System.Xml.Schema
internal class BaseValidator
{

	// Fields
	private object schemaCollection; // 0x8
	private object eventHandling; // 0x10
	private object nameTable; // 0x18
	private object schemaNames; // 0x20
	private object positionInfo; // 0x28
	private object xmlResolver; // 0x30
	private object baseUri; // 0x38
	protected object schemaInfo; // 0x40
	protected object reader; // 0x48
	protected object elementName; // 0x50
	protected object context; // 0x58
	protected object textValue; // 0x60
	protected object textString; // 0x68
	protected object hasSibling; // 0x70
	protected object checkDatatype; // 0x71

	// Properties
	public object Reader { get; }
	public object SchemaCollection { get; }
	public object NameTable { get; }
	public object SchemaNames { get; }
	public object PositionInfo { get; }
	public object XmlResolver { get; set; }
	public object BaseUri { get; set; }
	public object EventHandler { get; }
	public object SchemaInfo { get; }
	public object DtdInfo { set; }
	public virtual object PreserveWhitespace { get; }

	// Methods

	// RVA: 0x70D9778
	public object .ctor(object other) { }

	// RVA: 0x70D77E4
	public object .ctor(object reader, object schemaCollection, object eventHandling) { }

	// RVA: 0x70D97E0
	public object get_Reader() { }

	// RVA: 0x70D97E8
	public object get_SchemaCollection() { }

	// RVA: 0x70D97F0
	public object get_NameTable() { }

	// RVA: 0x70D813C
	public object get_SchemaNames() { }

	// RVA: 0x70D97F8
	public object get_PositionInfo() { }

	// RVA: 0x70D9800
	public object get_XmlResolver() { }

	// RVA: 0x70D9808
	public object set_XmlResolver(object value) { }

	// RVA: 0x70D9810
	public object get_BaseUri() { }

	// RVA: 0x70D9818
	public object set_BaseUri(object value) { }

	// RVA: 0x70D9820
	public object get_EventHandler() { }

	// RVA: 0x70D992C
	public object get_SchemaInfo() { }

	// RVA: 0x70D9934
	public object set_DtdInfo(object value) { }

	// RVA: 0x70D9A18
	public virtual object get_PreserveWhitespace() { }

	// RVA: 0x70D9A20
	public virtual object Validate() { }

	// RVA: 0x70D9A24
	public virtual object CompleteValidation() { }

	// RVA: 0x70D9A28
	public virtual object FindId(object name) { }

	// RVA: 0x70D9A30
	public object ValidateText() { }

	// RVA: 0x70DA0F0
	public object ValidateWhitespace() { }

	// RVA: 0x70DA054
	private object SaveTextValue(object value) { }

	// RVA: 0x70DA2FC
	protected object SendValidationEvent(object code) { }

	// RVA: 0x70D9F04
	protected object SendValidationEvent(object code, object args) { }

	// RVA: 0x70D9DB4
	protected object SendValidationEvent(object code, object arg) { }

	// RVA: 0x70DA364
	protected object SendValidationEvent(object e) { }

	// RVA: 0x70DA478
	protected object SendValidationEvent(object code, object msg, object severity) { }

	// RVA: 0x70DA5CC
	protected object SendValidationEvent(object code, object args, object severity) { }

	// RVA: 0x70DA36C
	protected object SendValidationEvent(object e, object severity) { }

	// RVA: 0x70DA720
	protected static object ProcessEntity(object sinfo, object name, object sender, object eventhandler, object baseUri, object lineNumber, object linePosition) { }

	// RVA: 0x70DA918
	protected static object ProcessEntity(object sinfo, object name, object eventHandling, object baseUriStr, object lineNumber, object linePosition) { }

	// RVA: 0x70DAB64
	public static object CreateInstance(object valType, object reader, object schemaCollection, object eventHandling, object processIdentityConstraints) { }

}

// Namespace: System.Xml.Schema
internal sealed class BitSet
{

	// Fields
	private object count; // 0x8
	private object bits; // 0x10

	// Properties
	public object Count { get; }
	public object Item { get; }
	public object IsEmpty { get; }

	// Methods

	// RVA: 0x70DAD88
	private object .ctor() { }

	// RVA: 0x70DAD90
	public object .ctor(object count) { }

	// RVA: 0x70DAE0C
	public object get_Count() { }

	// RVA: 0x70DAE14
	public object get_Item(object index) { }

	// RVA: 0x70DAED4
	public object Clear() { }

	// RVA: 0x70DAF34
	public object Set(object index) { }

	// RVA: 0x70DAE74
	public object Get(object index) { }

	// RVA: 0x70DB0D4
	public object NextSet(object startFrom) { }

	// RVA: 0x70DB178
	public object And(object other) { }

	// RVA: 0x70DB2BC
	public object Or(object other) { }

	// RVA: 0x70DB3F8
	public override object GetHashCode() { }

	// RVA: 0x70DB43C
	public override object Equals(object obj) { }

	// RVA: 0x70DB5BC
	public object Clone() { }

	// RVA: 0x70DB6BC
	public object get_IsEmpty() { }

	// RVA: 0x70DB780
	public object Intersects(object other) { }

	// RVA: 0x70DAE04
	private object Subscript(object bitIndex) { }

	// RVA: 0x70DB024
	private object EnsureLength(object nRequiredLength) { }

}

// Namespace: System.Xml.Schema
internal class ChameleonKey
{

	// Fields
	internal object targetNS; // 0x8
	internal object chameleonLocation; // 0x10
	internal object originalSchema; // 0x18
	private object hashCode; // 0x20

	// Methods

	// RVA: 0x70DB8A4
	public object .ctor(object ns, object originalSchema) { }

	// RVA: 0x70DB938
	public override object GetHashCode() { }

	// RVA: 0x70DBA2C
	public override object Equals(object obj) { }

}

// Namespace: 
public enum ConstraintRole
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unique;
	public const object Key;
	public const object Keyref;
}

// Namespace: System.Xml.Schema
internal class CompiledIdentityConstraint
{

	// Fields
	internal object name; // 0x8
	private object role; // 0x10
	private object selector; // 0x18
	private object fields; // 0x20
	internal object refer; // 0x28
	public static readonly object Empty; // 0x0

	// Properties
	public object Role { get; }
	public object Selector { get; }
	public object Fields { get; }

	// Methods

	// RVA: 0x70DBB68
	public object get_Role() { }

	// RVA: 0x70DBB70
	public object get_Selector() { }

	// RVA: 0x70DBB78
	public object get_Fields() { }

	// RVA: 0x70DBB80
	private object .ctor() { }

	// RVA: 0x70DBBF8
	public object .ctor(object constraint, object nsmgr) { }

	// RVA: 0x70DC108
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class ConstraintStruct
{

	// Fields
	internal object constraint; // 0x8
	internal object axisSelector; // 0x10
	internal object axisFields; // 0x18
	internal object qualifiedTable; // 0x20
	internal object keyrefTable; // 0x28
	private object tableDim; // 0x30

	// Properties
	internal object TableDim { get; }

	// Methods

	// RVA: 0x70DC1C0
	internal object get_TableDim() { }

	// RVA: 0x70DC1C8
	internal object .ctor(object constraint) { }

}

// Namespace: System.Xml.Schema
internal class LocatedActiveAxis
{

	// Fields
	private object column; // 0x20
	internal object isMatched; // 0x24
	internal object Ks; // 0x28

	// Properties
	internal object Column { get; }

	// Methods

	// RVA: 0x70DC3AC
	internal object get_Column() { }

	// RVA: 0x70DC3B4
	internal object .ctor(object astfield, object ks, object column) { }

	// RVA: 0x70DC3F0
	internal object Reactivate(object ks) { }

}

// Namespace: System.Xml.Schema
internal class SelectorActiveAxis
{

	// Fields
	private object cs; // 0x20
	private object KSs; // 0x28
	private object KSpointer; // 0x30

	// Properties
	public object lastDepth { get; }

	// Methods

	// RVA: 0x70DC408
	public object get_lastDepth() { }

	// RVA: 0x70DC32C
	public object .ctor(object axisTree, object cs) { }

	// RVA: 0x70DC4EC
	public override object EndElement(object localname, object URN) { }

	// RVA: 0x70DC540
	public object PushKS(object errline, object errcol) { }

	// RVA: 0x70DCACC
	public object PopKS() { }

}

// Namespace: System.Xml.Schema
internal class KSStruct
{

	// Fields
	public object depth; // 0x8
	public object ks; // 0x10
	public object fields; // 0x18

	// Methods

	// RVA: 0x70DCA50
	public object .ctor(object ks, object dim) { }

}

// Namespace: 
private class DecimalStruct
{

	// Fields
	private object isDecimal; // 0x8
	private object dvalue; // 0x10

	// Properties
	public object IsDecimal { get; set; }
	public object Dvalue { get; }

	// Methods

	// RVA: 0x70DD7DC
	public object get_IsDecimal() { }

	// RVA: 0x70DD7E4
	public object set_IsDecimal(object value) { }

	// RVA: 0x70DD7EC
	public object get_Dvalue() { }

	// RVA: 0x70DD21C
	public object .ctor() { }

	// RVA: 0x70DD1B0
	public object .ctor(object dim) { }

}

// Namespace: System.Xml.Schema
internal class TypedObject
{

	// Fields
	private object dstruct; // 0x8
	private object ovalue; // 0x10
	private object svalue; // 0x18
	private object xsdtype; // 0x20
	private object dim; // 0x28
	private object isList; // 0x2C

	// Properties
	public object Dim { get; }
	public object IsList { get; }
	public object IsDecimal { get; }
	public object Dvalue { get; }
	public object Value { get; }
	public object Type { get; }

	// Methods

	// RVA: 0x70DCBA8
	public object get_Dim() { }

	// RVA: 0x70DCBB0
	public object get_IsList() { }

	// RVA: 0x70DCBB8
	public object get_IsDecimal() { }

	// RVA: 0x70DCBDC
	public object get_Dvalue() { }

	// RVA: 0x70DCC00
	public object get_Value() { }

	// RVA: 0x70DCC08
	public object get_Type() { }

	// RVA: 0x70DCC10
	public object .ctor(object obj, object svalue, object xsdtype) { }

	// RVA: 0x70DCDB0
	public override object ToString() { }

	// RVA: 0x70DCDB8
	public object SetDecimal() { }

	// RVA: 0x70DD284
	private object ListDValueEquals(object other) { }

	// RVA: 0x70DD3EC
	public object Equals(object other) { }

}

// Namespace: System.Xml.Schema
internal class KeySequence
{

	// Fields
	private object ks; // 0x8
	private object dim; // 0x10
	private object hashcode; // 0x14
	private object posline; // 0x18
	private object poscol; // 0x1C

	// Properties
	public object PosLine { get; }
	public object PosCol { get; }
	public object Item { get; set; }

	// Methods

	// RVA: 0x70DC9C4
	internal object .ctor(object dim, object line, object col) { }

	// RVA: 0x70DD7F4
	public object get_PosLine() { }

	// RVA: 0x70DD7FC
	public object get_PosCol() { }

	// RVA: 0x70DD804
	public object get_Item(object index) { }

	// RVA: 0x70DD840
	public object set_Item(object index, object value) { }

	// RVA: 0x70DD944
	internal object IsQualified() { }

	// RVA: 0x70DD9D0
	public override object GetHashCode() { }

	// RVA: 0x70DDE9C
	public override object Equals(object other) { }

	// RVA: 0x70DDFC4
	public override object ToString() { }

}

// Namespace: System.Xml.Schema
internal class UpaException
{

	// Fields
	private object particle1; // 0x88
	private object particle2; // 0x90

	// Properties
	public object Particle1 { get; }
	public object Particle2 { get; }

	// Methods

	// RVA: 0x70DE18C
	public object .ctor(object particle1, object particle2) { }

	// RVA: 0x70DE208
	public object get_Particle1() { }

	// RVA: 0x70DE210
	public object get_Particle2() { }

}

// Namespace: System.Xml.Schema
internal class SymbolsDictionary
{

	// Fields
	private object last; // 0x8
	private object names; // 0x10
	private object wildcards; // 0x18
	private object particles; // 0x20
	private object particleLast; // 0x28
	private object isUpaEnforced; // 0x30

	// Properties
	public object Count { get; }
	public object IsUpaEnforced { get; set; }
	public object Item { get; }

	// Methods

	// RVA: 0x70DE218
	public object .ctor() { }

	// RVA: 0x70DE2BC
	public object get_Count() { }

	// RVA: 0x70DE2C8
	public object get_IsUpaEnforced() { }

	// RVA: 0x70DE2D0
	public object set_IsUpaEnforced(object value) { }

	// RVA: 0x70DE2D8
	public object AddName(object name, object particle) { }

	// RVA: 0x70DE4A0
	public object AddNamespaceList(object list, object particle, object allowLocal) { }

	// RVA: 0x70DE8B4
	private object AddWildcard(object wildcard, object particle) { }

	// RVA: 0x70DEABC
	public object GetNamespaceListSymbols(object list) { }

	// RVA: 0x70DF44C
	public object get_Item(object name) { }

	// RVA: 0x70DF598
	public object Exists(object name) { }

	// RVA: 0x70DF5FC
	public object GetParticle(object symbol) { }

	// RVA: 0x70DF670
	public object NameOf(object symbol) { }

}

// Namespace: System.Xml.Schema
internal struct Position
{

	// Fields
	public object symbol; // 0xFFFFFFFFFFFFFFF8
	public object particle; // 0x0

	// Methods

	// RVA: 0x70E0004
	public object .ctor(object symbol, object particle) { }

}

// Namespace: System.Xml.Schema
internal class Positions
{

	// Fields
	private object positions; // 0x8

	// Properties
	public object Item { get; }
	public object Count { get; }

	// Methods

	// RVA: 0x70E001C
	public object Add(object symbol, object particle) { }

	// RVA: 0x70E00D8
	public object get_Item(object pos) { }

	// RVA: 0x70E01A0
	public object get_Count() { }

	// RVA: 0x70E01F0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal abstract class SyntaxTreeNode
{

	// Properties
	public abstract object IsNullable { get; }
	public virtual object IsRangeNode { get; }

	// Methods

	// RVA: -1
	public abstract object ExpandTree(object parent, object symbols, object positions) { }

	// RVA: -1
	public abstract object ConstructPos(object firstpos, object lastpos, object followpos) { }

	// RVA: -1
	public abstract object get_IsNullable() { }

	// RVA: 0x70E025C
	public virtual object get_IsRangeNode() { }

	// RVA: 0x70E0264
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class LeafNode
{

	// Fields
	private object pos; // 0x8

	// Properties
	public object Pos { get; set; }
	public override object IsNullable { get; }

	// Methods

	// RVA: 0x70E026C
	public object .ctor(object pos) { }

	// RVA: 0x70E0298
	public object get_Pos() { }

	// RVA: 0x70E02A0
	public object set_Pos(object value) { }

	// RVA: 0x70E02A8
	public override object ExpandTree(object parent, object symbols, object positions) { }

	// RVA: 0x70E02AC
	public override object ConstructPos(object firstpos, object lastpos, object followpos) { }

	// RVA: 0x70E0304
	public override object get_IsNullable() { }

}

// Namespace: System.Xml.Schema
internal class NamespaceListNode
{

	// Fields
	protected object namespaceList; // 0x8
	protected object particle; // 0x10

	// Properties
	public override object IsNullable { get; }

	// Methods

	// RVA: 0x70E030C
	public object .ctor(object namespaceList, object particle) { }

	// RVA: 0x70E0344
	public virtual object GetResolvedSymbols(object symbols) { }

	// RVA: 0x70E036C
	public override object ExpandTree(object parent, object symbols, object positions) { }

	// RVA: 0x70E0948
	public override object ConstructPos(object firstpos, object lastpos, object followpos) { }

	// RVA: 0x70E0988
	public override object get_IsNullable() { }

}

// Namespace: System.Xml.Schema
internal abstract class InteriorNode
{

	// Fields
	private object leftChild; // 0x8
	private object rightChild; // 0x10

	// Properties
	public object LeftChild { get; set; }
	public object RightChild { get; set; }

	// Methods

	// RVA: 0x70E09C8
	public object get_LeftChild() { }

	// RVA: 0x70E09D0
	public object set_LeftChild(object value) { }

	// RVA: 0x70E09D8
	public object get_RightChild() { }

	// RVA: 0x70E09E0
	public object set_RightChild(object value) { }

	// RVA: 0x70E09E8
	protected object ExpandTreeNoRecursive(object parent, object symbols, object positions) { }

	// RVA: 0x70E0C88
	public override object ExpandTree(object parent, object symbols, object positions) { }

	// RVA: 0x70E0D3C
	protected object .ctor() { }

}

// Namespace: 
private struct SequenceConstructPosContext
{

	// Fields
	public object this_; // 0xFFFFFFFFFFFFFFF8
	public object firstpos; // 0x0
	public object lastpos; // 0x8
	public object lastposLeft; // 0x10
	public object firstposRight; // 0x18

	// Methods

	// RVA: 0x70E13E4
	public object .ctor(object node, object firstpos, object lastpos) { }

}

// Namespace: System.Xml.Schema
internal sealed class SequenceNode
{

	// Properties
	public override object IsNullable { get; }

	// Methods

	// RVA: 0x70E0D44
	public override object ConstructPos(object firstpos, object lastpos, object followpos) { }

	// RVA: 0x70E13F4
	public override object get_IsNullable() { }

	// RVA: 0x70E15F8
	public override object ExpandTree(object parent, object symbols, object positions) { }

	// RVA: 0x70E15FC
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class ChoiceNode
{

	// Properties
	public override object IsNullable { get; }

	// Methods

	// RVA: 0x70E1650
	private static object ConstructChildPos(object child, object firstpos, object lastpos, object followpos) { }

	// RVA: 0x70E17E0
	public override object ConstructPos(object firstpos, object lastpos, object followpos) { }

	// RVA: 0x70E19B8
	public override object get_IsNullable() { }

	// RVA: 0x70E1AA4
	public override object ExpandTree(object parent, object symbols, object positions) { }

	// RVA: 0x70E0940
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class PlusNode
{

	// Properties
	public override object IsNullable { get; }

	// Methods

	// RVA: 0x70E1AA8
	public override object ConstructPos(object firstpos, object lastpos, object followpos) { }

	// RVA: 0x70E1C64
	public override object get_IsNullable() { }

	// RVA: 0x70E1CB0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class QmarkNode
{

	// Properties
	public override object IsNullable { get; }

	// Methods

	// RVA: 0x70E1CB8
	public override object ConstructPos(object firstpos, object lastpos, object followpos) { }

	// RVA: 0x70E1D24
	public override object get_IsNullable() { }

	// RVA: 0x70E1D2C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class StarNode
{

	// Properties
	public override object IsNullable { get; }

	// Methods

	// RVA: 0x70E1D34
	public override object ConstructPos(object firstpos, object lastpos, object followpos) { }

	// RVA: 0x70E1EF0
	public override object get_IsNullable() { }

	// RVA: 0x70E1EF8
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class LeafRangeNode
{

	// Fields
	private object min; // 0x10
	private object max; // 0x20
	private object nextIteration; // 0x30

	// Properties
	public object Max { get; }
	public object Min { get; }
	public object NextIteration { get; set; }
	public override object IsRangeNode { get; }

	// Methods

	// RVA: 0x70E1F00
	public object .ctor(object min, object max) { }

	// RVA: 0x70E1F54
	public object .ctor(object pos, object min, object max) { }

	// RVA: 0x70E1FA8
	public object get_Max() { }

	// RVA: 0x70E1FB4
	public object get_Min() { }

	// RVA: 0x70E1FC0
	public object get_NextIteration() { }

	// RVA: 0x70E1FC8
	public object set_NextIteration(object value) { }

	// RVA: 0x70E1FD0
	public override object get_IsRangeNode() { }

	// RVA: 0x70E1FD8
	public override object ExpandTree(object parent, object symbols, object positions) { }

}

// Namespace: System.Xml.Schema
internal class ContentValidator
{

	// Fields
	private object contentType; // 0x8
	private object isOpen; // 0xC
	private object isEmptiable; // 0xD
	public static readonly object Empty; // 0x0
	public static readonly object TextOnly; // 0x8
	public static readonly object Mixed; // 0x10
	public static readonly object Any; // 0x18

	// Properties
	public object ContentType { get; }
	public object PreserveWhitespace { get; }
	public virtual object IsEmptiable { get; }
	public object IsOpen { get; set; }

	// Methods

	// RVA: 0x70E2044
	public object .ctor(object contentType) { }

	// RVA: 0x70E2078
	protected object .ctor(object contentType, object isOpen, object isEmptiable) { }

	// RVA: 0x70E20BC
	public object get_ContentType() { }

	// RVA: 0x70E20C4
	public object get_PreserveWhitespace() { }

	// RVA: 0x70E20D8
	public virtual object get_IsEmptiable() { }

	// RVA: 0x70E20E0
	public object get_IsOpen() { }

	// RVA: 0x70E2100
	public object set_IsOpen(object value) { }

	// RVA: 0x70E2108
	public virtual object InitValidation(object context) { }

	// RVA: 0x70E210C
	public virtual object ValidateElement(object name, object context, object errorCode) { }

	// RVA: 0x70E2144
	public virtual object CompleteValidation(object context) { }

	// RVA: 0x70E214C
	public virtual object ExpectedElements(object context, object isRequiredOnly) { }

	// RVA: 0x70E2154
	public virtual object ExpectedParticles(object context, object isRequiredOnly, object schemaSet) { }

	// RVA: 0x70E215C
	public static object AddParticleToExpected(object p, object schemaSet, object particles) { }

	// RVA: 0x70E21D8
	public static object AddParticleToExpected(object p, object schemaSet, object particles, object global) { }

	// RVA: 0x70E250C
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class ParticleContentValidator
{

	// Fields
	private object symbols; // 0x10
	private object positions; // 0x18
	private object stack; // 0x20
	private object contentNode; // 0x28
	private object isPartial; // 0x30
	private object minMaxNodesCount; // 0x34
	private object enableUpaCheck; // 0x38

	// Methods

	// RVA: 0x70E25F4
	public object .ctor(object contentType) { }

	// RVA: 0x70E2670
	public object .ctor(object contentType, object enableUpaCheck) { }

	// RVA: 0x70E26F8
	public override object InitValidation(object context) { }

	// RVA: 0x70E2738
	public override object ValidateElement(object name, object context, object errorCode) { }

	// RVA: 0x70E2778
	public override object CompleteValidation(object context) { }

	// RVA: 0x70E27B8
	public object Start() { }

	// RVA: 0x70E28BC
	public object OpenGroup() { }

	// RVA: 0x70E2910
	public object CloseGroup() { }

	// RVA: 0x70E2B08
	public object Exists(object name) { }

	// RVA: 0x70E2B74
	public object AddName(object name, object particle) { }

	// RVA: 0x70E2E0C
	public object AddNamespaceList(object namespaceList, object particle) { }

	// RVA: 0x70E2CAC
	private object AddLeafNode(object node) { }

	// RVA: 0x70E2EA4
	public object AddChoice() { }

	// RVA: 0x70E2FE0
	public object AddSequence() { }

	// RVA: 0x70E311C
	public object AddStar() { }

	// RVA: 0x70E3370
	public object AddPlus() { }

	// RVA: 0x70E33D8
	public object AddQMark() { }

	// RVA: 0x70E3440
	public object AddLeafRange(object min, object max) { }

	// RVA: 0x70E3184
	private object Closure(object node) { }

	// RVA: 0x70E35CC
	public object Finish(object useDFA) { }

	// RVA: 0x70E3E24
	private object CalculateTotalFollowposForRangeNodes(object firstpos, object followpos, object posWithRangeTerminals) { }

	// RVA: 0x70E4744
	private object CheckCMUPAWithLeafRangeNodes(object curpos) { }

	// RVA: 0x70E43F8
	private object GetApplicableMinMaxFollowPos(object curpos, object posWithRangeTerminals, object minmaxFollowPos) { }

	// RVA: 0x70E49D4
	private object CheckUniqueParticleAttribution(object firstpos, object followpos) { }

	// RVA: 0x70E552C
	private object CheckUniqueParticleAttribution(object curpos) { }

	// RVA: 0x70E4AD8
	private object BuildTransitionTable(object firstpos, object followpos, object endMarkerPos) { }

}

// Namespace: System.Xml.Schema
internal sealed class DfaContentValidator
{

	// Fields
	private object transitionTable; // 0x10
	private object symbols; // 0x18

	// Methods

	// RVA: 0x70E5490
	internal object .ctor(object transitionTable, object symbols, object contentType, object isOpen, object isEmptiable) { }

	// RVA: 0x70E582C
	public override object InitValidation(object context) { }

	// RVA: 0x70E58C0
	public override object ValidateElement(object name, object context, object errorCode) { }

	// RVA: 0x70E5AA0
	public override object CompleteValidation(object context) { }

	// RVA: 0x70E5AC0
	public override object ExpectedElements(object context, object isRequiredOnly) { }

	// RVA: 0x70E5D70
	public override object ExpectedParticles(object context, object isRequiredOnly, object schemaSet) { }

}

// Namespace: System.Xml.Schema
internal sealed class NfaContentValidator
{

	// Fields
	private object firstpos; // 0x10
	private object followpos; // 0x18
	private object symbols; // 0x20
	private object positions; // 0x28
	private object endMarkerPos; // 0x30

	// Methods

	// RVA: 0x70E5FAC
	internal object .ctor(object firstpos, object followpos, object symbols, object positions, object endMarkerPos, object contentType, object isOpen, object isEmptiable) { }

	// RVA: 0x70E606C
	public override object InitValidation(object context) { }

	// RVA: 0x70E6164
	public override object ValidateElement(object name, object context, object errorCode) { }

	// RVA: 0x70E6374
	public override object CompleteValidation(object context) { }

	// RVA: 0x70E63E0
	public override object ExpectedElements(object context, object isRequiredOnly) { }

	// RVA: 0x70E666C
	public override object ExpectedParticles(object context, object isRequiredOnly, object schemaSet) { }

}

// Namespace: System.Xml.Schema
internal struct RangePositionInfo
{

	// Fields
	public object curpos; // 0xFFFFFFFFFFFFFFF8
	public object rangeCounters; // 0x0
}

// Namespace: System.Xml.Schema
internal sealed class RangeContentValidator
{

	// Fields
	private object firstpos; // 0x10
	private object followpos; // 0x18
	private object positionsWithRangeTerminals; // 0x20
	private object symbols; // 0x28
	private object positions; // 0x30
	private object minMaxNodesCount; // 0x38
	private object endMarkerPos; // 0x3C

	// Methods

	// RVA: 0x70E6864
	internal object .ctor(object firstpos, object followpos, object symbols, object positions, object endMarkerPos, object contentType, object isEmptiable, object positionsWithRangeTerminals, object minmaxNodesCount) { }

	// RVA: 0x70E692C
	public override object InitValidation(object context) { }

	// RVA: 0x70E6B58
	public override object ValidateElement(object name, object context, object errorCode) { }

	// RVA: 0x70E75B4
	public override object CompleteValidation(object context) { }

	// RVA: 0x70E75D4
	public override object ExpectedElements(object context, object isRequiredOnly) { }

	// RVA: 0x70E791C
	public override object ExpectedParticles(object context, object isRequiredOnly, object schemaSet) { }

}

// Namespace: System.Xml.Schema
internal sealed class AllElementsContentValidator
{

	// Fields
	private object elements; // 0x10
	private object particles; // 0x18
	private object isRequired; // 0x20
	private object countRequired; // 0x28

	// Properties
	public override object IsEmptiable { get; }

	// Methods

	// RVA: 0x70E7B88
	public object .ctor(object contentType, object size, object isEmptiable) { }

	// RVA: 0x70E7C9C
	public object AddElement(object name, object particle, object isEmptiable) { }

	// RVA: 0x70E7E74
	public override object get_IsEmptiable() { }

	// RVA: 0x70E7E94
	public override object InitValidation(object context) { }

	// RVA: 0x70E7F58
	public override object ValidateElement(object name, object context, object errorCode) { }

	// RVA: 0x70E8134
	public override object CompleteValidation(object context) { }

	// RVA: 0x70E81C0
	public override object ExpectedElements(object context, object isRequiredOnly) { }

	// RVA: 0x70E868C
	public override object ExpectedParticles(object context, object isRequiredOnly, object schemaSet) { }

}

// Namespace: System.Xml.Schema
public enum XmlSchemaDatatypeVariety
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Atomic;
	public const object List;
	public const object Union;
}

// Namespace: System.Xml.Schema
internal class XsdSimpleValue
{

	// Fields
	private object xmlType; // 0x8
	private object typedValue; // 0x10

	// Properties
	public object XmlType { get; }
	public object TypedValue { get; }

	// Methods

	// RVA: 0x70E8BF8
	public object .ctor(object st, object value) { }

	// RVA: 0x70E8C30
	public object get_XmlType() { }

	// RVA: 0x70E8C38
	public object get_TypedValue() { }

}

// Namespace: System.Xml.Schema
internal enum RestrictionFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Length;
	public const object MinLength;
	public const object MaxLength;
	public const object Pattern;
	public const object Enumeration;
	public const object WhiteSpace;
	public const object MaxInclusive;
	public const object MaxExclusive;
	public const object MinInclusive;
	public const object MinExclusive;
	public const object TotalDigits;
	public const object FractionDigits;
}

// Namespace: System.Xml.Schema
internal enum XmlSchemaWhiteSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Preserve;
	public const object Replace;
	public const object Collapse;
}

// Namespace: System.Xml.Schema
internal class RestrictionFacets
{

	// Fields
	internal object Length; // 0x8
	internal object MinLength; // 0xC
	internal object MaxLength; // 0x10
	internal object Patterns; // 0x18
	internal object Enumeration; // 0x20
	internal object WhiteSpace; // 0x28
	internal object MaxInclusive; // 0x30
	internal object MaxExclusive; // 0x38
	internal object MinInclusive; // 0x40
	internal object MinExclusive; // 0x48
	internal object TotalDigits; // 0x50
	internal object FractionDigits; // 0x54
	internal object Flags; // 0x58
	internal object FixedFlags; // 0x5C

	// Methods

	// RVA: 0x70E8C40
	public object .ctor() { }

}

// Namespace: 
private class SchemaDatatypeMap
{

	// Fields
	private object name; // 0x8
	private object type; // 0x10
	private object parentIndex; // 0x18

	// Properties
	public object Name { get; }
	public object ParentIndex { get; }

	// Methods

	// RVA: 0x70F0AF8
	internal object .ctor(object name, object type) { }

	// RVA: 0x70F0B30
	internal object .ctor(object name, object type, object parentIndex) { }

	// RVA: 0x70F3D0C
	public static object op_Explicit(object sdm) { }

	// RVA: 0x70F3D2C
	public object get_Name() { }

	// RVA: 0x70F3D34
	public object get_ParentIndex() { }

	// RVA: 0x70F3D3C
	public object CompareTo(object obj) { }

}

// Namespace: System.Xml.Schema
internal abstract class DatatypeImplementation
{

	// Fields
	private object variety; // 0x8
	private object restriction; // 0x10
	private object baseType; // 0x18
	private object valueConverter; // 0x20
	private object parentSchemaType; // 0x28
	private static object builtinTypes; // 0x0
	private static object enumToTypeCode; // 0x8
	private static object anySimpleType; // 0x10
	private static object anyAtomicType; // 0x18
	private static object untypedAtomicType; // 0x20
	private static object yearMonthDurationType; // 0x28
	private static object dayTimeDurationType; // 0x30
	private static object normalizedStringTypeV1Compat; // 0x38
	private static object tokenTypeV1Compat; // 0x40
	internal static object QnAnySimpleType; // 0x48
	internal static object QnAnyType; // 0x50
	internal static object stringFacetsChecker; // 0x58
	internal static object miscFacetsChecker; // 0x60
	internal static object numeric2FacetsChecker; // 0x68
	internal static object binaryFacetsChecker; // 0x70
	internal static object dateTimeFacetsChecker; // 0x78
	internal static object durationFacetsChecker; // 0x80
	internal static object listFacetsChecker; // 0x88
	internal static object qnameFacetsChecker; // 0x90
	internal static object unionFacetsChecker; // 0x98
	private static readonly object c_anySimpleType; // 0xA0
	private static readonly object c_anyURI; // 0xA8
	private static readonly object c_base64Binary; // 0xB0
	private static readonly object c_boolean; // 0xB8
	private static readonly object c_byte; // 0xC0
	private static readonly object c_char; // 0xC8
	private static readonly object c_date; // 0xD0
	private static readonly object c_dateTime; // 0xD8
	private static readonly object c_dateTimeNoTz; // 0xE0
	private static readonly object c_dateTimeTz; // 0xE8
	private static readonly object c_day; // 0xF0
	private static readonly object c_decimal; // 0xF8
	private static readonly object c_double; // 0x100
	private static readonly object c_doubleXdr; // 0x108
	private static readonly object c_duration; // 0x110
	private static readonly object c_ENTITY; // 0x118
	private static readonly object c_ENTITIES; // 0x120
	private static readonly object c_ENUMERATION; // 0x128
	private static readonly object c_fixed; // 0x130
	private static readonly object c_float; // 0x138
	private static readonly object c_floatXdr; // 0x140
	private static readonly object c_hexBinary; // 0x148
	private static readonly object c_ID; // 0x150
	private static readonly object c_IDREF; // 0x158
	private static readonly object c_IDREFS; // 0x160
	private static readonly object c_int; // 0x168
	private static readonly object c_integer; // 0x170
	private static readonly object c_language; // 0x178
	private static readonly object c_long; // 0x180
	private static readonly object c_month; // 0x188
	private static readonly object c_monthDay; // 0x190
	private static readonly object c_Name; // 0x198
	private static readonly object c_NCName; // 0x1A0
	private static readonly object c_negativeInteger; // 0x1A8
	private static readonly object c_NMTOKEN; // 0x1B0
	private static readonly object c_NMTOKENS; // 0x1B8
	private static readonly object c_nonNegativeInteger; // 0x1C0
	private static readonly object c_nonPositiveInteger; // 0x1C8
	private static readonly object c_normalizedString; // 0x1D0
	private static readonly object c_NOTATION; // 0x1D8
	private static readonly object c_positiveInteger; // 0x1E0
	private static readonly object c_QName; // 0x1E8
	private static readonly object c_QNameXdr; // 0x1F0
	private static readonly object c_short; // 0x1F8
	private static readonly object c_string; // 0x200
	private static readonly object c_time; // 0x208
	private static readonly object c_timeNoTz; // 0x210
	private static readonly object c_timeTz; // 0x218
	private static readonly object c_token; // 0x220
	private static readonly object c_unsignedByte; // 0x228
	private static readonly object c_unsignedInt; // 0x230
	private static readonly object c_unsignedLong; // 0x238
	private static readonly object c_unsignedShort; // 0x240
	private static readonly object c_uuid; // 0x248
	private static readonly object c_year; // 0x250
	private static readonly object c_yearMonth; // 0x258
	internal static readonly object c_normalizedStringV1Compat; // 0x260
	internal static readonly object c_tokenV1Compat; // 0x268
	private static readonly object c_anyAtomicType; // 0x270
	private static readonly object c_dayTimeDuration; // 0x278
	private static readonly object c_untypedAtomicType; // 0x280
	private static readonly object c_yearMonthDuration; // 0x288
	private static readonly object c_tokenizedTypes; // 0x290
	private static readonly object c_tokenizedTypesXsd; // 0x298
	private static readonly object c_XdrTypes; // 0x2A0
	private static readonly object c_XsdTypes; // 0x2A8

	// Properties
	internal static object AnySimpleType { get; }
	internal static object UntypedAtomicType { get; }
	internal override object FacetsChecker { get; }
	internal override object ValueConverter { get; }
	public override object TokenizedType { get; }
	public override object ValueType { get; }
	public override object Variety { get; }
	public override object TypeCode { get; }
	internal override object Restriction { get; }
	internal override object HasLexicalFacets { get; }
	internal override object HasValueFacets { get; }
	protected object Base { get; }
	internal abstract object ListValueType { get; }
	internal abstract object ValidRestrictionFlags { get; }
	internal override object BuiltInWhitespaceFacet { get; }

	// Methods

	// RVA: 0x70E8C48
	private static object .cctor() { }

	// RVA: 0x70F15F8
	internal static object get_AnySimpleType() { }

	// RVA: 0x70F1674
	internal static object get_UntypedAtomicType() { }

	// RVA: 0x70F16F0
	internal static object FromXmlTokenizedType(object token) { }

	// RVA: 0x70F1798
	internal static object FromXmlTokenizedTypeXsd(object token) { }

	// RVA: 0x70F1840
	internal static object FromXdrName(object name) { }

	// RVA: 0x70F1934
	private static object FromTypeName(object name) { }

	// RVA: 0x70F1A28
	internal static object StartBuiltinType(object qname, object dataType) { }

	// RVA: 0x70F1B10
	internal static object FinishBuiltinType(object derivedType, object baseType) { }

	// RVA: 0x70F0B70
	internal static object CreateBuiltinTypes() { }

	// RVA: 0x70F1DEC
	internal static object GetSimpleTypeFromTypeCode(object typeCode) { }

	// RVA: 0x70F1E94
	internal static object GetSimpleTypeFromXsdType(object qname) { }

	// RVA: 0x70F1F98
	internal static object GetNormalizedStringTypeV1Compat() { }

	// RVA: 0x70F21EC
	internal static object GetTokenTypeV1Compat() { }

	// RVA: 0x70F2440
	internal static object GetBuiltInTypes() { }

	// RVA: 0x70F24BC
	internal static object GetPrimitiveTypeCode(object typeCode) { }

	// RVA: 0x70F2644
	internal override object DeriveByRestriction(object facets, object nameTable, object schemaType) { }

	// RVA: 0x70F277C
	internal override object DeriveByList(object schemaType) { }

	// RVA: 0x70EE304
	internal object DeriveByList(object minSize, object schemaType) { }

	// RVA: 0x70F2924
	internal static object DeriveByUnion(object types, object schemaType) { }

	// RVA: 0x70F2B4C
	internal override object VerifySchemaValid(object notations, object caller) { }

	// RVA: 0x70F2B50
	public override object IsDerivedFrom(object datatype) { }

	// RVA: 0x70F2ED8
	internal override object IsEqual(object o1, object o2) { }

	// RVA: 0x70F2F40
	internal override object IsComparable(object dtype) { }

	// RVA: 0x70F3088
	internal virtual object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F3090
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F310C
	internal override object get_ValueConverter() { }

	// RVA: 0x70F3170
	public override object get_TokenizedType() { }

	// RVA: 0x70F3178
	public override object get_ValueType() { }

	// RVA: 0x70F3218
	public override object get_Variety() { }

	// RVA: 0x70F3220
	public override object get_TypeCode() { }

	// RVA: 0x70F3228
	internal override object get_Restriction() { }

	// RVA: 0x70F3230
	internal override object get_HasLexicalFacets() { }

	// RVA: 0x70F3258
	internal override object get_HasValueFacets() { }

	// RVA: 0x70F3280
	protected object get_Base() { }

	// RVA: -1
	internal abstract object get_ListValueType() { }

	// RVA: -1
	internal abstract object get_ValidRestrictionFlags() { }

	// RVA: 0x70F3288
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F3290
	public override object ParseValue(object s, object nameTable, object nsmgr) { }

	// RVA: 0x70F3568
	internal override object ParseValue(object s, object nameTable, object nsmgr, object createAtomicValue) { }

	// RVA: 0x70F3734
	internal override object TryParseValue(object value, object nameTable, object namespaceResolver, object typedValue) { }

	// RVA: 0x70F34C0
	internal object GetTypeName() { }

	// RVA: 0x70F3C8C
	protected object Compare(object value1, object value2) { }

	// RVA: 0x70F3D04
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_List
{

	// Fields
	private object itemType; // 0x30
	private object minListSize; // 0x38

	// Properties
	public override object ValueType { get; }
	public override object TokenizedType { get; }
	internal override object ListValueType { get; }
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F3DBC
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F283C
	internal object .ctor(object type, object minListSize) { }

	// RVA: 0x70F4160
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F4568
	public override object get_ValueType() { }

	// RVA: 0x70F45AC
	public override object get_TokenizedType() { }

	// RVA: 0x70F45F8
	internal override object get_ListValueType() { }

	// RVA: 0x70F4648
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F46C4
	public override object get_TypeCode() { }

	// RVA: 0x70F4710
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F4718
	internal override object TryParseValue(object value, object nameTable, object namespaceResolver, object typedValue) { }

	// RVA: 0x70F5150
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

}

// Namespace: System.Xml.Schema
internal class Datatype_union
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private object types; // 0x30

	// Properties
	public override object ValueType { get; }
	public override object TypeCode { get; }
	internal override object FacetsChecker { get; }
	internal override object ListValueType { get; }
	internal override object ValidRestrictionFlags { get; }
	internal object BaseMemberTypes { get; }

	// Methods

	// RVA: 0x70F5784
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F2A74
	internal object .ctor(object types) { }

	// RVA: 0x70F5790
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F58CC
	public override object get_ValueType() { }

	// RVA: 0x70F5948
	public override object get_TypeCode() { }

	// RVA: 0x70F5950
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F59CC
	internal override object get_ListValueType() { }

	// RVA: 0x70F5A48
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F5A50
	internal object get_BaseMemberTypes() { }

	// RVA: 0x70F2788
	internal object HasAtomicMembers() { }

	// RVA: 0x70F2DF8
	internal object IsUnionBaseOf(object derivedType) { }

	// RVA: 0x70F5A58
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70F5CF4
	internal override object TryParseValue(object value, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70F62B4
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_anySimpleType
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object ValueType { get; }
	public override object TypeCode { get; }
	internal override object ListValueType { get; }
	public override object TokenizedType { get; }
	internal override object ValidRestrictionFlags { get; }
	internal override object BuiltInWhitespaceFacet { get; }

	// Methods

	// RVA: 0x70F637C
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F63F8
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F6474
	public override object get_ValueType() { }

	// RVA: 0x70F64F0
	public override object get_TypeCode() { }

	// RVA: 0x70F64F8
	internal override object get_ListValueType() { }

	// RVA: 0x70F6574
	public override object get_TokenizedType() { }

	// RVA: 0x70F657C
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F6584
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F658C
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F6628
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70ED324
	public object .ctor() { }

	// RVA: 0x70F6658
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_anyAtomicType
{

	// Properties
	internal override object BuiltInWhitespaceFacet { get; }
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F6720
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F679C
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F67A4
	public override object get_TypeCode() { }

	// RVA: 0x70F06C8
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_untypedAtomicType
{

	// Properties
	internal override object BuiltInWhitespaceFacet { get; }
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F67AC
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F6828
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F6830
	public override object get_TypeCode() { }

	// RVA: 0x70F08E0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_string
{

	// Properties
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object TokenizedType { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F6838
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F6844
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F684C
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F68C8
	public override object get_TypeCode() { }

	// RVA: 0x70F68D0
	public override object get_TokenizedType() { }

	// RVA: 0x70F68D8
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F68E0
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EF970
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_boolean
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F6A38
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F6A44
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F6AC0
	public override object get_TypeCode() { }

	// RVA: 0x70F6AC8
	public override object get_ValueType() { }

	// RVA: 0x70F6B44
	internal override object get_ListValueType() { }

	// RVA: 0x70F6BC0
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F6BC8
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F6BD0
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F6C84
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70ED56C
	public object .ctor() { }

	// RVA: 0x70F6E00
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_float
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F6EC8
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F6ED4
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F6F50
	public override object get_TypeCode() { }

	// RVA: 0x70F6F58
	public override object get_ValueType() { }

	// RVA: 0x70F6FD4
	internal override object get_ListValueType() { }

	// RVA: 0x70F7050
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F7058
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F7060
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F7104
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EE7BC
	public object .ctor() { }

	// RVA: 0x70F72EC
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_double
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F73B4
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F73C0
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F743C
	public override object get_TypeCode() { }

	// RVA: 0x70F7444
	public override object get_ValueType() { }

	// RVA: 0x70F74C0
	internal override object get_ListValueType() { }

	// RVA: 0x70F753C
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F7544
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F754C
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F75F0
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EDF2C
	public object .ctor() { }

	// RVA: 0x70F77D8
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_decimal
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F78A0
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F78AC
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F7928
	public override object get_TypeCode() { }

	// RVA: 0x70F7930
	public override object get_ValueType() { }

	// RVA: 0x70F79AC
	internal override object get_ListValueType() { }

	// RVA: 0x70F7A28
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F7A30
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F7A38
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F7B18
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EDE4C
	public object .ctor() { }

	// RVA: 0x70F7D18
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_duration
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F7EF8
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F7F04
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F7F80
	public override object get_TypeCode() { }

	// RVA: 0x70F7F88
	public override object get_ValueType() { }

	// RVA: 0x70F8004
	internal override object get_ListValueType() { }

	// RVA: 0x70F8080
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F8088
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F8090
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F8144
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EE144
	public object .ctor() { }

	// RVA: 0x70F8378
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_yearMonthDuration
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F8440
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70F8674
	public override object get_TypeCode() { }

	// RVA: 0x70F09C0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_dayTimeDuration
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F867C
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70F88B0
	public override object get_TypeCode() { }

	// RVA: 0x70F07A8
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_dateTimeBase
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private object dateTimeFlags; // 0x30

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F88B8
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F88C4
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F8940
	public override object get_TypeCode() { }

	// RVA: 0x70F8948
	internal object .ctor(object dateTimeFlags) { }

	// RVA: 0x70F8A20
	public override object get_ValueType() { }

	// RVA: 0x70F8A9C
	internal override object get_ListValueType() { }

	// RVA: 0x70F8B18
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F8B20
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F8B28
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F8CB0
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70F9084
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_dateTimeNoTimeZone
{

	// Methods

	// RVA: 0x70EDABC
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_dateTimeTimeZone
{

	// Methods

	// RVA: 0x70EDBEC
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_dateTime
{

	// Methods

	// RVA: 0x70ED98C
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_timeNoTimeZone
{

	// Methods

	// RVA: 0x70EFB80
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_timeTimeZone
{

	// Methods

	// RVA: 0x70EFCB0
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_time
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F914C
	public override object get_TypeCode() { }

	// RVA: 0x70EFA50
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_date
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F9154
	public override object get_TypeCode() { }

	// RVA: 0x70ED85C
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_yearMonth
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F915C
	public override object get_TypeCode() { }

	// RVA: 0x70F03D8
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_year
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F9164
	public override object get_TypeCode() { }

	// RVA: 0x70F02A8
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_monthDay
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F916C
	public override object get_TypeCode() { }

	// RVA: 0x70EF040
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_day
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F9174
	public override object get_TypeCode() { }

	// RVA: 0x70EDD1C
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_month
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70F917C
	public override object get_TypeCode() { }

	// RVA: 0x70EEF10
	internal object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_hexBinary
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F9184
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F9190
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F920C
	public override object get_TypeCode() { }

	// RVA: 0x70F9214
	public override object get_ValueType() { }

	// RVA: 0x70F9290
	internal override object get_ListValueType() { }

	// RVA: 0x70F930C
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F9314
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F931C
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F9444
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EE9D4
	public object .ctor() { }

	// RVA: 0x70F967C
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_base64Binary
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F9744
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F9750
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F97CC
	public override object get_TypeCode() { }

	// RVA: 0x70F97D4
	public override object get_ValueType() { }

	// RVA: 0x70F9850
	internal override object get_ListValueType() { }

	// RVA: 0x70F98CC
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F98D4
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F98DC
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F9A04
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70ED48C
	public object .ctor() { }

	// RVA: 0x70F9C38
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_anyURI
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object HasValueFacets { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70F9D00
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70F9D0C
	internal override object get_FacetsChecker() { }

	// RVA: 0x70F9D88
	public override object get_TypeCode() { }

	// RVA: 0x70F9D90
	public override object get_ValueType() { }

	// RVA: 0x70F9E0C
	internal override object get_HasValueFacets() { }

	// RVA: 0x70F9E14
	internal override object get_ListValueType() { }

	// RVA: 0x70F9E90
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70F9E98
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70F9EA0
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70F9F8C
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70ED3AC
	public object .ctor() { }

	// RVA: 0x70FA3E0
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_QName
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object TokenizedType { get; }
	internal override object ValidRestrictionFlags { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }

	// Methods

	// RVA: 0x70FA4A8
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70FA4B4
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FA530
	public override object get_TypeCode() { }

	// RVA: 0x70FA538
	public override object get_TokenizedType() { }

	// RVA: 0x70FA540
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70FA548
	public override object get_ValueType() { }

	// RVA: 0x70FA5C4
	internal override object get_ListValueType() { }

	// RVA: 0x70FA640
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70FA648
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EF6D8
	public object .ctor() { }

	// RVA: 0x70FA910
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_normalizedString
{

	// Properties
	public override object TypeCode { get; }
	internal override object BuiltInWhitespaceFacet { get; }
	internal override object HasValueFacets { get; }

	// Methods

	// RVA: 0x70FA9D8
	public override object get_TypeCode() { }

	// RVA: 0x70FA9E0
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70FA9E8
	internal override object get_HasValueFacets() { }

	// RVA: 0x70EF498
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_normalizedStringV1Compat
{

	// Properties
	public override object TypeCode { get; }
	internal override object HasValueFacets { get; }

	// Methods

	// RVA: 0x70FA9F0
	public override object get_TypeCode() { }

	// RVA: 0x70FA9F8
	internal override object get_HasValueFacets() { }

	// RVA: 0x70F0508
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_token
{

	// Properties
	public override object TypeCode { get; }
	internal override object BuiltInWhitespaceFacet { get; }

	// Methods

	// RVA: 0x70FAA00
	public override object get_TypeCode() { }

	// RVA: 0x70FAA08
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70EFDE0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_tokenV1Compat
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70FAA10
	public override object get_TypeCode() { }

	// RVA: 0x70F05E8
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_language
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70FAA18
	public override object get_TypeCode() { }

	// RVA: 0x70EEE2C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_NMTOKEN
{

	// Properties
	public override object TypeCode { get; }
	public override object TokenizedType { get; }

	// Methods

	// RVA: 0x70FAA20
	public override object get_TypeCode() { }

	// RVA: 0x70FAA28
	public override object get_TokenizedType() { }

	// RVA: 0x70EF3B0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_Name
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70FAA30
	public override object get_TypeCode() { }

	// RVA: 0x70EF170
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_NCName
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70FAA38
	public override object get_TypeCode() { }

	// RVA: 0x70FAA40
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EF250
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_ID
{

	// Properties
	public override object TypeCode { get; }
	public override object TokenizedType { get; }

	// Methods

	// RVA: 0x70FABE8
	public override object get_TypeCode() { }

	// RVA: 0x70FABF0
	public override object get_TokenizedType() { }

	// RVA: 0x70EEAB4
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_IDREF
{

	// Properties
	public override object TypeCode { get; }
	public override object TokenizedType { get; }

	// Methods

	// RVA: 0x70FABF8
	public override object get_TypeCode() { }

	// RVA: 0x70FAC00
	public override object get_TokenizedType() { }

	// RVA: 0x70EEB94
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_ENTITY
{

	// Properties
	public override object TypeCode { get; }
	public override object TokenizedType { get; }

	// Methods

	// RVA: 0x70FAC08
	public override object get_TypeCode() { }

	// RVA: 0x70FAC10
	public override object get_TokenizedType() { }

	// RVA: 0x70EE224
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_NOTATION
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object TokenizedType { get; }
	internal override object ValidRestrictionFlags { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object BuiltInWhitespaceFacet { get; }

	// Methods

	// RVA: 0x70FAC18
	internal override object CreateValueConverter(object schemaType) { }

	// RVA: 0x70FAC24
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FACA0
	public override object get_TypeCode() { }

	// RVA: 0x70FACA8
	public override object get_TokenizedType() { }

	// RVA: 0x70FACB0
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70FACB8
	public override object get_ValueType() { }

	// RVA: 0x70FAD34
	internal override object get_ListValueType() { }

	// RVA: 0x70FADB0
	internal override object get_BuiltInWhitespaceFacet() { }

	// RVA: 0x70FADB8
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70FB080
	internal override object VerifySchemaValid(object notations, object caller) { }

	// RVA: 0x70EF578
	public object .ctor() { }

	// RVA: 0x70FB344
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_integer
{

	// Properties
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70FB40C
	public override object get_TypeCode() { }

	// RVA: 0x70FB414
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EECF4
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_nonPositiveInteger
{

	// Fields
	private static readonly object numeric10FacetsChecker; // 0x0

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	internal override object HasValueFacets { get; }

	// Methods

	// RVA: 0x70FB608
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FB684
	public override object get_TypeCode() { }

	// RVA: 0x70FB68C
	internal override object get_HasValueFacets() { }

	// RVA: 0x70EF494
	public object .ctor() { }

	// RVA: 0x70FB694
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_negativeInteger
{

	// Fields
	private static readonly object numeric10FacetsChecker; // 0x0

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70FB7B0
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FB82C
	public override object get_TypeCode() { }

	// RVA: 0x70EF330
	public object .ctor() { }

	// RVA: 0x70FB834
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_long
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	internal override object HasValueFacets { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FB950
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FB9CC
	internal override object get_HasValueFacets() { }

	// RVA: 0x70FB9D4
	public override object get_TypeCode() { }

	// RVA: 0x70FB9DC
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FBA80
	public override object get_ValueType() { }

	// RVA: 0x70FBAFC
	internal override object get_ListValueType() { }

	// RVA: 0x70FBB78
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EEF0C
	public object .ctor() { }

	// RVA: 0x70FBD54
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_int
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FBEC8
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FBF44
	public override object get_TypeCode() { }

	// RVA: 0x70FBF4C
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FBFF0
	public override object get_ValueType() { }

	// RVA: 0x70FC06C
	internal override object get_ListValueType() { }

	// RVA: 0x70FC0E8
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EEC74
	public object .ctor() { }

	// RVA: 0x70FC2C4
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_short
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FC438
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FC4B4
	public override object get_TypeCode() { }

	// RVA: 0x70FC4BC
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FC560
	public override object get_ValueType() { }

	// RVA: 0x70FC5DC
	internal override object get_ListValueType() { }

	// RVA: 0x70FC658
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EF898
	public object .ctor() { }

	// RVA: 0x70FC834
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_byte
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FC9A8
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FCA24
	public override object get_TypeCode() { }

	// RVA: 0x70FCA2C
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FCAD0
	public override object get_ValueType() { }

	// RVA: 0x70FCB4C
	internal override object get_ListValueType() { }

	// RVA: 0x70FCBC8
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70ED64C
	public object .ctor() { }

	// RVA: 0x70FCDA4
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_nonNegativeInteger
{

	// Fields
	private static readonly object numeric10FacetsChecker; // 0x0

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	internal override object HasValueFacets { get; }

	// Methods

	// RVA: 0x70FCF18
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FCF94
	public override object get_TypeCode() { }

	// RVA: 0x70FCF9C
	internal override object get_HasValueFacets() { }

	// RVA: 0x70EF490
	public object .ctor() { }

	// RVA: 0x70FCFA4
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_unsignedLong
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FD0C8
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FD144
	public override object get_TypeCode() { }

	// RVA: 0x70FD14C
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FD1F0
	public override object get_ValueType() { }

	// RVA: 0x70FD26C
	internal override object get_ListValueType() { }

	// RVA: 0x70FD2E8
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70F0018
	public object .ctor() { }

	// RVA: 0x70FD50C
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_unsignedInt
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FD6A8
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FD724
	public override object get_TypeCode() { }

	// RVA: 0x70FD72C
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FD7D0
	public override object get_ValueType() { }

	// RVA: 0x70FD84C
	internal override object get_ListValueType() { }

	// RVA: 0x70FD8C8
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EFF40
	public object .ctor() { }

	// RVA: 0x70FDAA4
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_unsignedShort
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FDC40
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FDCBC
	public override object get_TypeCode() { }

	// RVA: 0x70FDCC4
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FDD68
	public override object get_ValueType() { }

	// RVA: 0x70FDDE4
	internal override object get_ListValueType() { }

	// RVA: 0x70FDE60
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70F0098
	public object .ctor() { }

	// RVA: 0x70FE03C
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_unsignedByte
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8
	private static readonly object numeric10FacetsChecker; // 0x10

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FE1D8
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FE254
	public override object get_TypeCode() { }

	// RVA: 0x70FE25C
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FE300
	public override object get_ValueType() { }

	// RVA: 0x70FE37C
	internal override object get_ListValueType() { }

	// RVA: 0x70FE3F8
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EFEC0
	public object .ctor() { }

	// RVA: 0x70FE5D4
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_positiveInteger
{

	// Fields
	private static readonly object numeric10FacetsChecker; // 0x0

	// Properties
	internal override object FacetsChecker { get; }
	public override object TypeCode { get; }

	// Methods

	// RVA: 0x70FE770
	internal override object get_FacetsChecker() { }

	// RVA: 0x70FE7EC
	public override object get_TypeCode() { }

	// RVA: 0x70EF658
	public object .ctor() { }

	// RVA: 0x70FE7F4
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_doubleXdr
{

	// Methods

	// RVA: 0x70FE918
	public override object ParseValue(object s, object nameTable, object nsmgr) { }

	// RVA: 0x70EE00C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_floatXdr
{

	// Methods

	// RVA: 0x70FEB2C
	public override object ParseValue(object s, object nameTable, object nsmgr) { }

	// RVA: 0x70EE89C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_QNameXdr
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	public override object TokenizedType { get; }
	public override object ValueType { get; }
	internal override object ListValueType { get; }

	// Methods

	// RVA: 0x70FED40
	public override object get_TokenizedType() { }

	// RVA: 0x70FED48
	public override object ParseValue(object s, object nameTable, object nsmgr) { }

	// RVA: 0x70FEFE0
	public override object get_ValueType() { }

	// RVA: 0x70FF05C
	internal override object get_ListValueType() { }

	// RVA: 0x70EF7B8
	public object .ctor() { }

	// RVA: 0x70FF0D8
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_ENUMERATION
{

	// Properties
	public override object TokenizedType { get; }

	// Methods

	// RVA: 0x70FF1A0
	public override object get_TokenizedType() { }

	// RVA: 0x70EE5A4
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_char
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70FF1A8
	public override object get_ValueType() { }

	// RVA: 0x70FF224
	internal override object get_ListValueType() { }

	// RVA: 0x70FF2A0
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70FF2A8
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FF35C
	public override object ParseValue(object s, object nameTable, object nsmgr) { }

	// RVA: 0x70FF540
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70ED77C
	public object .ctor() { }

	// RVA: 0x70FF63C
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_fixed
{

	// Methods

	// RVA: 0x70FF704
	public override object ParseValue(object s, object nameTable, object nsmgr) { }

	// RVA: 0x70FFC90
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70EE684
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Datatype_uuid
{

	// Fields
	private static readonly object atomicValueType; // 0x0
	private static readonly object listValueType; // 0x8

	// Properties
	public override object ValueType { get; }
	internal override object ListValueType { get; }
	internal override object ValidRestrictionFlags { get; }

	// Methods

	// RVA: 0x70FFE40
	public override object get_ValueType() { }

	// RVA: 0x70FFEBC
	internal override object get_ListValueType() { }

	// RVA: 0x70FFF38
	internal override object get_ValidRestrictionFlags() { }

	// RVA: 0x70FFF40
	internal override object Compare(object value1, object value2) { }

	// RVA: 0x70FFFE8
	public override object ParseValue(object s, object nameTable, object nsmgr) { }

	// RVA: 0x71001CC
	internal override object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: 0x70F01C8
	public object .ctor() { }

	// RVA: 0x71002C8
	private static object .cctor() { }

}

// Namespace: 
private class NamespaceManager
{

	// Methods

	// RVA: 0x710354C
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x7103544
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class DtdValidator
{

	// Fields
	private static object namespaceManager; // 0x0
	private object validationStack; // 0x78
	private object attPresence; // 0x80
	private object name; // 0x88
	private object IDs; // 0x90
	private object idRefListHead; // 0x98
	private object processIdentityConstraints; // 0xA0

	// Properties
	public override object PreserveWhitespace { get; }

	// Methods

	// RVA: 0x7100390
	internal object .ctor(object reader, object eventHandling, object processIdentityConstraints) { }

	// RVA: 0x7100430
	private object Init() { }

	// RVA: 0x7100670
	public override object Validate() { }

	// RVA: 0x7100B70
	private object MeetsStandAloneConstraint() { }

	// RVA: 0x7100C40
	private object ValidatePIComment() { }

	// RVA: 0x7100990
	private object ValidateElement() { }

	// RVA: 0x71011B4
	private object ValidateChildElement() { }

	// RVA: 0x7101524
	private object ValidateStartElement() { }

	// RVA: 0x71022CC
	private object ValidateEndStartElement() { }

	// RVA: 0x71013A4
	private object ProcessElement() { }

	// RVA: 0x710250C
	public override object CompleteValidation() { }

	// RVA: 0x7100F3C
	private object ValidateEndElement() { }

	// RVA: 0x7102788
	public override object get_PreserveWhitespace() { }

	// RVA: 0x71027D8
	private object ProcessTokenizedType(object ttype, object name) { }

	// RVA: 0x7101BBC
	private object CheckValue(object value, object attdef) { }

	// RVA: 0x7102B70
	internal object AddID(object name, object node) { }

	// RVA: 0x7102C20
	public override object FindId(object name) { }

	// RVA: 0x7100D28
	private object GenEntity(object qname) { }

	// RVA: 0x7102C7C
	private object GetEntity(object qname, object fParameterEntity) { }

	// RVA: 0x710263C
	private object CheckForwardRefs() { }

	// RVA: 0x7100564
	private object Push(object elementName) { }

	// RVA: 0x710256C
	private object Pop() { }

	// RVA: 0x7102D50
	public static object SetDefaultTypedValue(object attdef, object readerAdapter) { }

	// RVA: 0x71030F0
	public static object CheckDefaultValue(object attdef, object sinfo, object eventHandling, object baseUriStr) { }

	// RVA: 0x71034C8
	private static object .cctor() { }

}

// Namespace: 
private struct Map
{

	// Fields
	internal object match; // 0xFFFFFFFFFFFFFFF8
	internal object replacement; // 0x0

	// Methods

	// RVA: 0x7108FB8
	internal object .ctor(object m, object r) { }

}

// Namespace: 
private struct FacetsCompiler
{

	// Fields
	private object datatype; // 0xFFFFFFFFFFFFFFF8
	private object derivedRestriction; // 0x0
	private object baseFlags; // 0x8
	private object baseFixedFlags; // 0xC
	private object validRestrictionFlags; // 0x10
	private object nonNegativeInt; // 0x18
	private object builtInType; // 0x20
	private object builtInEnum; // 0x28
	private object firstPattern; // 0x2C
	private object regStr; // 0x30
	private object pattern_facet; // 0x38
	private static readonly object c_map; // 0x0

	// Methods

	// RVA: 0x7103DFC
	public object .ctor(object baseDatatype, object restriction) { }

	// RVA: 0x710420C
	internal object CompileLengthFacet(object facet) { }

	// RVA: 0x7104728
	internal object CompileMinLengthFacet(object facet) { }

	// RVA: 0x7104BCC
	internal object CompileMaxLengthFacet(object facet) { }

	// RVA: 0x7105070
	internal object CompilePatternFacet(object facet) { }

	// RVA: 0x710528C
	internal object CompileEnumerationFacet(object facet, object nsmgr, object nameTable) { }

	// RVA: 0x710547C
	internal object CompileWhitespaceFacet(object facet) { }

	// RVA: 0x7105F58
	internal object CompileMaxInclusiveFacet(object facet) { }

	// RVA: 0x7106230
	internal object CompileMaxExclusiveFacet(object facet) { }

	// RVA: 0x71059A8
	internal object CompileMinInclusiveFacet(object facet) { }

	// RVA: 0x7105C80
	internal object CompileMinExclusiveFacet(object facet) { }

	// RVA: 0x7106508
	internal object CompileTotalDigitsFacet(object facet) { }

	// RVA: 0x7106A08
	internal object CompileFractionDigitsFacet(object facet) { }

	// RVA: 0x7106DD8
	internal object FinishFacetCompile() { }

	// RVA: 0x7107C58
	private object CheckValue(object value, object facet) { }

	// RVA: 0x7107220
	internal object CompileFacetCombinations() { }

	// RVA: 0x7108654
	private object CopyFacetsFromBaseType() { }

	// RVA: 0x71079E0
	private object ParseFacetValue(object datatype, object facet, object code, object nsmgr, object nameTable) { }

	// RVA: 0x7108360
	private static object Preprocess(object pattern) { }

	// RVA: 0x71078CC
	private object CheckProhibitedFlag(object facet, object flag, object errorCode) { }

	// RVA: 0x710795C
	private object CheckDupFlag(object facet, object flag, object errorCode) { }

	// RVA: 0x7107B80
	private object SetFlag(object facet, object flag) { }

	// RVA: 0x7108C30
	private object SetFlag(object flag) { }

	// RVA: 0x7108DF8
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal abstract class FacetsChecker
{

	// Methods

	// RVA: 0x7103554
	internal virtual object CheckLexicalFacets(object parseString, object datatype) { }

	// RVA: 0x71038D8
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x71038E0
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x71038E8
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x71038F0
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x71038F8
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7103900
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7103908
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7103910
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7103918
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7103920
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7103928
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7103930
	internal virtual object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x71035B8
	internal object CheckWhitespaceFacets(object s, object datatype) { }

	// RVA: 0x7103710
	internal object CheckPatternFacets(object restriction, object value) { }

	// RVA: 0x7103938
	internal virtual object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x7103940
	internal virtual object ConstructRestriction(object datatype, object facets, object nameTable) { }

	// RVA: 0x7107720
	internal static object Power(object x, object y) { }

	// RVA: 0x7107880
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class Numeric10FacetsChecker
{

	// Fields
	private static readonly object signs; // 0x0
	private object maxValue; // 0x8
	private object minValue; // 0x18

	// Methods

	// RVA: 0x70F7EAC
	internal object .ctor(object minVal, object maxVal) { }

	// RVA: 0x7109060
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7109138
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7109A20
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7109ACC
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7109B78
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7109C24
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x7109848
	internal object MatchEnumeration(object value, object enumeration, object valueConverter) { }

	// RVA: 0x70FFA08
	internal object CheckTotalAndFractionDigits(object value, object totalDigits, object fractionDigits, object checkTotal, object checkFraction) { }

	// RVA: 0x7109D04
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class Numeric2FacetsChecker
{

	// Methods

	// RVA: 0x7109DA4
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x7109E7C
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x710A33C
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x710A394
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x710A1C8
	private object MatchEnumeration(object value, object enumeration, object valueConverter) { }

	// RVA: 0x70ED30C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class DurationFacetsChecker
{

	// Methods

	// RVA: 0x710A474
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x710A5F4
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x710AA5C
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x710A920
	private object MatchEnumeration(object value, object enumeration) { }

	// RVA: 0x70ED31C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class DateTimeFacetsChecker
{

	// Methods

	// RVA: 0x710AAE8
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x710ABB8
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x710B15C
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x710AFC4
	private object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x70ED314
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class StringFacetsChecker
{

	// Fields
	private static object languagePattern; // 0x0

	// Properties
	private static object LanguagePattern { get; }

	// Methods

	// RVA: 0x710B20C
	private static object get_LanguagePattern() { }

	// RVA: 0x710B2DC
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x710B390
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x70FA180
	internal object CheckValueFacets(object value, object datatype, object verifyUri) { }

	// RVA: 0x710B95C
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x710B68C
	private object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x710B398
	private object CheckBuiltInFacets(object s, object typeCode, object verifyUri) { }

	// RVA: 0x70ED304
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class QNameFacetsChecker
{

	// Methods

	// RVA: 0x6F0FCB0
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x6F0FE38
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x6F101FC
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x6F10034
	private object MatchEnumeration(object value, object enumeration) { }

	// RVA: 0x6F10358
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class MiscFacetsChecker
{

	// Methods

	// RVA: 0x6F10360
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class BinaryFacetsChecker
{

	// Methods

	// RVA: 0x6F10368
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x6F10430
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x6F107DC
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x6F105F8
	private object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x6F1087C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class ListFacetsChecker
{

	// Methods

	// RVA: 0x6F10884
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x6F10AD0
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x6F10C44
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class UnionFacetsChecker
{

	// Methods

	// RVA: 0x6F10C4C
	internal override object CheckValueFacets(object value, object datatype) { }

	// RVA: 0x6F10D9C
	internal override object MatchEnumeration(object value, object enumeration, object datatype) { }

	// RVA: 0x6F10F10
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public interface IXmlSchemaInfo
{

	// Properties
	public abstract object Validity { get; }
	public abstract object IsDefault { get; }
	public abstract object IsNil { get; }
	public abstract object MemberType { get; }
	public abstract object SchemaType { get; }
	public abstract object SchemaElement { get; }
	public abstract object SchemaAttribute { get; }

	// Methods

	// RVA: -1
	public abstract object get_Validity() { }

	// RVA: -1
	public abstract object get_IsDefault() { }

	// RVA: -1
	public abstract object get_IsNil() { }

	// RVA: -1
	public abstract object get_MemberType() { }

	// RVA: -1
	public abstract object get_SchemaType() { }

	// RVA: -1
	public abstract object get_SchemaElement() { }

	// RVA: -1
	public abstract object get_SchemaAttribute() { }

}

// Namespace: 
public enum InferenceOption
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Restricted;
	public const object Relaxed;
}

// Namespace: System.Xml.Schema
public sealed class XmlSchemaInference
{

	// Fields
	internal static object ST_boolean; // 0x0
	internal static object ST_byte; // 0x8
	internal static object ST_unsignedByte; // 0x10
	internal static object ST_short; // 0x18
	internal static object ST_unsignedShort; // 0x20
	internal static object ST_int; // 0x28
	internal static object ST_unsignedInt; // 0x30
	internal static object ST_long; // 0x38
	internal static object ST_unsignedLong; // 0x40
	internal static object ST_integer; // 0x48
	internal static object ST_decimal; // 0x50
	internal static object ST_float; // 0x58
	internal static object ST_double; // 0x60
	internal static object ST_duration; // 0x68
	internal static object ST_dateTime; // 0x70
	internal static object ST_time; // 0x78
	internal static object ST_date; // 0x80
	internal static object ST_gYearMonth; // 0x88
	internal static object ST_string; // 0x90
	internal static object ST_anySimpleType; // 0x98
	internal static object SimpleTypes; // 0xA0
	private object rootSchema; // 0x8
	private object schemaSet; // 0x10
	private object xtr; // 0x18
	private object nametable; // 0x20
	private object TargetNamespace; // 0x28
	private object NamespaceManager; // 0x30
	private object schemaList; // 0x38
	private object occurrence; // 0x40
	private object typeInference; // 0x44

	// Properties
	public object Occurrence { get; set; }
	public object TypeInference { set; }

	// Methods

	// RVA: 0x6F10F18
	public object set_Occurrence(object value) { }

	// RVA: 0x6F10F20
	public object get_Occurrence() { }

	// RVA: 0x6F10F28
	public object set_TypeInference(object value) { }

	// RVA: 0x6F10F30
	public object .ctor() { }

	// RVA: 0x6F11070
	public object InferSchema(object instanceDocument) { }

	// RVA: 0x6F110E8
	internal object InferSchema1(object instanceDocument, object schemas) { }

	// RVA: 0x6F14468
	private object AddAttribute(object localName, object prefix, object childURI, object attrValue, object bCreatingNewType, object parentSchema, object addLocation, object compiledAttributes) { }

	// RVA: 0x6F1722C
	private object CreateXmlSchema(object targetNS) { }

	// RVA: 0x6F11DF0
	private object AddElement(object localName, object prefix, object childURI, object parentSchema, object addLocation, object positionWithinCollection) { }

	// RVA: 0x6F12558
	internal object InferElement(object xse, object bCreatingNewType, object parentSchema) { }

	// RVA: 0x6F18324
	private object CheckSimpleContentExtension(object ct) { }

	// RVA: 0x6F176D8
	private object GetEffectiveSchemaType(object elem, object bCreatingNewType) { }

	// RVA: 0x6F18A34
	internal object FindMatchingElement(object bCreatingNewType, object xtr, object ct, object lastUsedSeqItem, object bParticleChanged, object parentSchema, object setMaxoccurs) { }

	// RVA: 0x6F1783C
	internal object ProcessAttributes(object xse, object effectiveSchemaType, object bCreatingNewType, object parentSchema) { }

	// RVA: 0x6F1892C
	private object MoveAttributes(object scExtension, object ct) { }

	// RVA: 0x6F18480
	private object MoveAttributes(object ct, object simpleContentExtension, object bCreatingNewType) { }

	// RVA: 0x6F15258
	internal object FindAttribute(object attributes, object attrName) { }

	// RVA: 0x6F172D4
	internal object FindGlobalElement(object namespaceURI, object localName, object parentSchema) { }

	// RVA: 0x6F1A278
	internal object FindElement(object elements, object elementName) { }

	// RVA: 0x6F14E20
	internal object FindAttributeRef(object attributes, object attributeName, object nsURI) { }

	// RVA: 0x6F1A408
	internal object FindElementRef(object elements, object elementName, object nsURI) { }

	// RVA: 0x6F18274
	internal object MakeExistingAttributesOptional(object ct, object attributesInInstance) { }

	// RVA: 0x6F1A854
	private object SwitchUseToOptional(object attributes, object attributesInInstance) { }

	// RVA: 0x6F1563C
	internal object RefineSimpleType(object s, object iTypeFlags) { }

	// RVA: 0x6F1AA54
	internal static object InferSimpleType(object s, object bNeedsRangeCheck) { }

	// RVA: 0x6F1C084
	internal static object DateTime(object s, object bDate, object bTime) { }

	// RVA: 0x6F1A5C4
	private object CreateNewElementforChoice(object copyElement) { }

	// RVA: 0x6F167AC
	private static object GetSchemaType(object qname) { }

	// RVA: 0x6F1A088
	internal object SetMinMaxOccurs(object el, object setMaxOccurs) { }

	// RVA: 0x6F1C1CC
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaInferenceException
{

	// Methods

	// RVA: 0x6F1CB2C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6F1CB34
	public override object GetObjectData(object info, object context) { }

	// RVA: 0x6F1CB3C
	public object .ctor() { }

	// RVA: 0x6F1A79C
	internal object .ctor(object res, object arg) { }

	// RVA: 0x6F11DB8
	internal object .ctor(object res, object lineNumber, object linePosition) { }

}

// Namespace: 
public enum ListType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Any;
	public const object Other;
	public const object Set;
}

// Namespace: System.Xml.Schema
internal class NamespaceList
{

	// Fields
	private object type; // 0x8
	private object set; // 0x10
	private object targetNamespace; // 0x18

	// Properties
	public object Type { get; }
	public object Excluded { get; }
	public object Enumerate { get; }

	// Methods

	// RVA: 0x6F1CB48
	public object .ctor() { }

	// RVA: 0x6F1CB50
	public object .ctor(object namespaces, object targetNamespace) { }

	// RVA: 0x6F1CE78
	public object Clone() { }

	// RVA: 0x6F1CFE4
	public object get_Type() { }

	// RVA: 0x6F1CFEC
	public object get_Excluded() { }

	// RVA: 0x6F1CFF4
	public object get_Enumerate() { }

	// RVA: 0x6F1D084
	public virtual object Allows(object ns) { }

	// RVA: 0x6F1D158
	public object Allows(object qname) { }

	// RVA: 0x6F1D1B0
	public override object ToString() { }

	// RVA: 0x6F1D774
	public static object IsSubset(object sub, object super) { }

	// RVA: 0x6F1DC48
	public static object Union(object o1, object o2, object v1Compat) { }

	// RVA: 0x6F1E2C4
	private object CompareSetToOther(object other) { }

	// RVA: 0x6F1E4BC
	public static object Intersection(object o1, object o2, object v1Compat) { }

	// RVA: 0x6F1EC5C
	private object RemoveNamespace(object tns) { }

}

// Namespace: System.Xml.Schema
internal class NamespaceListV1Compat
{

	// Methods

	// RVA: 0x6F1ED14
	public object .ctor(object namespaces, object targetNamespace) { }

	// RVA: 0x6F1ED18
	public override object Allows(object ns) { }

}

// Namespace: System.Xml.Schema
internal sealed class Parser
{

	// Fields
	private object schemaType; // 0x8
	private object nameTable; // 0x10
	private object schemaNames; // 0x18
	private object eventHandler; // 0x20
	private object namespaceManager; // 0x28
	private object reader; // 0x30
	private object positionInfo; // 0x38
	private object isProcessNamespaces; // 0x40
	private object schemaXmlDepth; // 0x44
	private object markupDepth; // 0x48
	private object builder; // 0x50
	private object schema; // 0x58
	private object xdrSchema; // 0x60
	private object xmlResolver; // 0x68
	private object dummyDocument; // 0x70
	private object processMarkup; // 0x78
	private object parentNode; // 0x80
	private object annotationNSManager; // 0x88
	private object xmlns; // 0x90
	private object xmlCharType; // 0x98

	// Properties
	public object XmlSchema { get; }
	internal object XmlResolver { set; }
	public object XdrSchema { get; }

	// Methods

	// RVA: 0x6F1ED3C
	public object .ctor(object schemaType, object nameTable, object schemaNames, object eventHandler) { }

	// RVA: 0x6F1EDF8
	public object Parse(object reader, object targetNamespace) { }

	// RVA: 0x6F1EE78
	public object StartParsing(object reader, object targetNamespace) { }

	// RVA: 0x6F200E4
	private object CheckSchemaRoot(object rootType, object code) { }

	// RVA: 0x6F2021C
	public object FinishParsing() { }

	// RVA: 0x6F20224
	public object get_XmlSchema() { }

	// RVA: 0x6F2022C
	internal object set_XmlResolver(object value) { }

	// RVA: 0x6F20234
	public object get_XdrSchema() { }

	// RVA: 0x6F1F3B8
	public object ParseReaderNode() { }

	// RVA: 0x6F2023C
	private object ProcessAppInfoDocMarkup(object root) { }

	// RVA: 0x6F2073C
	private object LoadElementNode(object root) { }

	// RVA: 0x6F2118C
	private object CreateXmlNsAttribute(object prefix, object value) { }

	// RVA: 0x6F20F18
	private object LoadAttributeNode() { }

	// RVA: 0x6F21398
	private object LoadEntityReferenceInAttribute() { }

}

// Namespace: System.Xml.Schema
internal enum Compositor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Root;
	public const object Include;
	public const object Import;
	public const object Redefine;
}

// Namespace: System.Xml.Schema
internal class RedefineEntry
{

	// Fields
	internal object redefine; // 0x8
	internal object schemaToUpdate; // 0x10

	// Methods

	// RVA: 0x6F217A0
	public object .ctor(object external, object schema) { }

}

// Namespace: System.Xml.Schema
internal sealed class Preprocessor
{

	// Fields
	private object Xmlns; // 0x38
	private object NsXsi; // 0x40
	private object targetNamespace; // 0x48
	private object rootSchema; // 0x50
	private object currentSchema; // 0x58
	private object elementFormDefault; // 0x60
	private object attributeFormDefault; // 0x64
	private object blockDefault; // 0x68
	private object finalDefault; // 0x6C
	private object schemaLocations; // 0x70
	private object chameleonSchemas; // 0x78
	private object referenceNamespaces; // 0x80
	private object processedExternals; // 0x88
	private object lockList; // 0x90
	private object readerSettings; // 0x98
	private object rootSchemaForRedefine; // 0xA0
	private object redefinedList; // 0xA8
	private static object builtInSchemaForXmlNS; // 0x0
	private object xmlResolver; // 0xB0

	// Properties
	internal object XmlResolver { set; }
	internal object ReaderSettings { set; }
	internal object SchemaLocations { set; }
	internal object ChameleonSchemas { set; }
	internal object RootSchema { get; }

	// Methods

	// RVA: 0x6F217D8
	public object .ctor(object nameTable, object schemaNames, object eventHandler, object compilationSettings) { }

	// RVA: 0x6F218BC
	public object Execute(object schema, object targetNamespace, object loadExternals) { }

	// RVA: 0x6F25CE8
	private object Cleanup(object schema) { }

	// RVA: 0x6F26500
	private object CleanupRedefine(object include) { }

	// RVA: 0x6F265D0
	internal object set_XmlResolver(object value) { }

	// RVA: 0x6F265D8
	internal object set_ReaderSettings(object value) { }

	// RVA: 0x6F265E0
	internal object set_SchemaLocations(object value) { }

	// RVA: 0x6F265E8
	internal object set_ChameleonSchemas(object value) { }

	// RVA: 0x6F265F0
	internal object get_RootSchema() { }

	// RVA: 0x6F23200
	private object BuildSchemaList(object schema) { }

	// RVA: 0x6F22134
	private object LoadExternals(object schema) { }

	// RVA: 0x6F25E48
	internal static object GetBuildInSchema() { }

	// RVA: 0x6F26760
	private object BuildRefNamespaces(object schema) { }

	// RVA: 0x6F26AAC
	private object ParseUri(object uri, object code, object sourceSchemaObject) { }

	// RVA: 0x6F23418
	private object Preprocess(object schema, object targetNamespace, object imports) { }

	// RVA: 0x6F271C4
	private object CopyIncludedComponents(object includedSchema, object schema) { }

	// RVA: 0x6F24A9C
	private object PreprocessRedefine(object redefineEntry) { }

	// RVA: 0x6F2A704
	private object GetIncludedSet(object schema, object includesList) { }

	// RVA: 0x6F2A668
	internal static object GetParentSchema(object currentSchemaObject) { }

	// RVA: 0x6F27094
	private object SetSchemaDefaults(object schema) { }

	// RVA: 0x6F2B04C
	private object CountGroupSelfReference(object items, object name, object redefined) { }

	// RVA: 0x6F2A8BC
	private object CheckRefinedGroup(object group) { }

	// RVA: 0x6F2A980
	private object CheckRefinedAttributeGroup(object attributeGroup) { }

	// RVA: 0x6F2AF28
	private object CheckRefinedSimpleType(object stype) { }

	// RVA: 0x6F2AB14
	private object CheckRefinedComplexType(object ctype) { }

	// RVA: 0x6F28810
	private object PreprocessAttribute(object attribute) { }

	// RVA: 0x6F2BA3C
	private object PreprocessLocalAttribute(object attribute) { }

	// RVA: 0x6F2B754
	private object PreprocessAttributeContent(object attribute) { }

	// RVA: 0x6F28998
	private object PreprocessAttributeGroup(object attributeGroup) { }

	// RVA: 0x6F29DE4
	private object PreprocessElement(object element) { }

	// RVA: 0x6F2C85C
	private object PreprocessLocalElement(object element) { }

	// RVA: 0x6F2C43C
	private object PreprocessElementContent(object element) { }

	// RVA: 0x6F2CCB0
	private object PreprocessIdentityConstraint(object constraint) { }

	// RVA: 0x6F296BC
	private object PreprocessSimpleType(object simpleType, object local) { }

	// RVA: 0x6F28B04
	private object PreprocessComplexType(object complexType, object local) { }

	// RVA: 0x6F2A078
	private object PreprocessGroup(object group) { }

	// RVA: 0x6F2A2C4
	private object PreprocessNotation(object notation) { }

	// RVA: 0x6F2D168
	private object PreprocessParticle(object particle) { }

	// RVA: 0x6F2BF3C
	private object PreprocessAttributes(object attributes, object anyAttribute, object parent) { }

	// RVA: 0x6F26CC8
	private object ValidateIdAttribute(object xso) { }

	// RVA: 0x6F2B3F8
	private object ValidateNameAttribute(object xso) { }

	// RVA: 0x6F2BC70
	private object ValidateQNameAttribute(object xso, object attributeName, object value) { }

	// RVA: 0x6F265F8
	private object ResolveSchemaLocationUri(object enclosingSchema, object location) { }

	// RVA: 0x6F26698
	private object GetSchemaEntity(object ruri) { }

	// RVA: 0x6F21F90
	private object GetChameleonSchema(object targetNamespace, object schema) { }

	// RVA: 0x6F26C00
	private object SetParent(object child, object parent) { }

	// RVA: 0x6F26C20
	private object PreprocessAnnotation(object schemaObject) { }

	// RVA: 0x6F2A5A8
	private object PreprocessAnnotation(object annotation) { }

}

// Namespace: 
internal enum Reserve
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object XmlSpace;
	public const object XmlLang;
}

// Namespace: System.Xml.Schema
internal sealed class SchemaAttDef
{

	// Fields
	private object defExpanded; // 0x58
	private object lineNum; // 0x60
	private object linePos; // 0x64
	private object valueLineNum; // 0x68
	private object valueLinePos; // 0x6C
	private object reserved; // 0x70
	private object defaultValueChecked; // 0x74
	private object schemaAttribute; // 0x78
	public static readonly object Empty; // 0x0

	// Properties
	private object System.Xml.IDtdAttributeInfo.Prefix { get; }
	private object System.Xml.IDtdAttributeInfo.LocalName { get; }
	private object System.Xml.IDtdAttributeInfo.LineNumber { get; }
	private object System.Xml.IDtdAttributeInfo.LinePosition { get; }
	private object System.Xml.IDtdAttributeInfo.IsNonCDataType { get; }
	private object System.Xml.IDtdAttributeInfo.IsDeclaredInExternal { get; }
	private object System.Xml.IDtdAttributeInfo.IsXmlAttribute { get; }
	private object System.Xml.IDtdDefaultAttributeInfo.DefaultValueExpanded { get; }
	private object System.Xml.IDtdDefaultAttributeInfo.DefaultValueTyped { get; }
	private object System.Xml.IDtdDefaultAttributeInfo.ValueLineNumber { get; }
	private object System.Xml.IDtdDefaultAttributeInfo.ValueLinePosition { get; }
	internal object LinePosition { get; set; }
	internal object LineNumber { get; set; }
	internal object ValueLinePosition { get; set; }
	internal object ValueLineNumber { get; set; }
	internal object DefaultValueExpanded { get; set; }
	internal object TokenizedType { get; set; }
	internal object Reserved { get; set; }
	internal object DefaultValueChecked { get; }
	internal object SchemaAttribute { get; set; }

	// Methods

	// RVA: 0x6F2DCA0
	public object .ctor(object name, object prefix) { }

	// RVA: 0x6F2DCA8
	public object .ctor(object name) { }

	// RVA: 0x6F2DCB4
	private object .ctor() { }

	// RVA: 0x6F2DCBC
	private object System.Xml.IDtdAttributeInfo.get_Prefix() { }

	// RVA: 0x6F2DCC4
	private object System.Xml.IDtdAttributeInfo.get_LocalName() { }

	// RVA: 0x6F2DCE8
	private object System.Xml.IDtdAttributeInfo.get_LineNumber() { }

	// RVA: 0x6F2DCF0
	private object System.Xml.IDtdAttributeInfo.get_LinePosition() { }

	// RVA: 0x6F2DCF8
	private object System.Xml.IDtdAttributeInfo.get_IsNonCDataType() { }

	// RVA: 0x6F2DD9C
	private object System.Xml.IDtdAttributeInfo.get_IsDeclaredInExternal() { }

	// RVA: 0x6F2DDA4
	private object System.Xml.IDtdAttributeInfo.get_IsXmlAttribute() { }

	// RVA: 0x6F2DDB4
	private object System.Xml.IDtdDefaultAttributeInfo.get_DefaultValueExpanded() { }

	// RVA: 0x6F2DE8C
	private object System.Xml.IDtdDefaultAttributeInfo.get_DefaultValueTyped() { }

	// RVA: 0x6F2DE94
	private object System.Xml.IDtdDefaultAttributeInfo.get_ValueLineNumber() { }

	// RVA: 0x6F2DE9C
	private object System.Xml.IDtdDefaultAttributeInfo.get_ValueLinePosition() { }

	// RVA: 0x6F2DEA4
	internal object get_LinePosition() { }

	// RVA: 0x6F2DEAC
	internal object set_LinePosition(object value) { }

	// RVA: 0x6F2DEB4
	internal object get_LineNumber() { }

	// RVA: 0x6F2DEBC
	internal object set_LineNumber(object value) { }

	// RVA: 0x6F2DEC4
	internal object get_ValueLinePosition() { }

	// RVA: 0x6F2DECC
	internal object set_ValueLinePosition(object value) { }

	// RVA: 0x6F2DED4
	internal object get_ValueLineNumber() { }

	// RVA: 0x6F2DEDC
	internal object set_ValueLineNumber(object value) { }

	// RVA: 0x6F2DE20
	internal object get_DefaultValueExpanded() { }

	// RVA: 0x6F2DEE4
	internal object set_DefaultValueExpanded(object value) { }

	// RVA: 0x6F2DD50
	internal object get_TokenizedType() { }

	// RVA: 0x6F2DEEC
	internal object set_TokenizedType(object value) { }

	// RVA: 0x6F2DF18
	internal object get_Reserved() { }

	// RVA: 0x6F2DF20
	internal object set_Reserved(object value) { }

	// RVA: 0x6F2DF28
	internal object get_DefaultValueChecked() { }

	// RVA: 0x6F2DF30
	internal object get_SchemaAttribute() { }

	// RVA: 0x6F2DF38
	internal object set_SchemaAttribute(object value) { }

	// RVA: 0x6F2DF40
	internal object CheckXmlSpace(object validationEventHandling) { }

	// RVA: 0x6F2E260
	internal object Clone() { }

	// RVA: 0x6F2E2CC
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal abstract class SchemaBuilder
{

	// Methods

	// RVA: -1
	internal abstract object ProcessElement(object prefix, object name, object ns) { }

	// RVA: -1
	internal abstract object ProcessAttribute(object prefix, object name, object ns, object value) { }

	// RVA: -1
	internal abstract object IsContentParsed() { }

	// RVA: -1
	internal abstract object ProcessMarkup(object markup) { }

	// RVA: -1
	internal abstract object ProcessCData(object value) { }

	// RVA: -1
	internal abstract object StartChildren() { }

	// RVA: -1
	internal abstract object EndChildren() { }

	// RVA: 0x6F2E32C
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class SchemaCollectionCompiler
{

	// Fields
	private object compileContentModel; // 0x38
	private object examplars; // 0x40
	private object complexTypeStack; // 0x48
	private object schema; // 0x50

	// Methods

	// RVA: 0x6F2E334
	public object .ctor(object nameTable, object eventHandler) { }

	// RVA: 0x6F2E3E8
	public object Execute(object schema, object schemaInfo, object compileContentModel) { }

	// RVA: 0x6F2E450
	private object Prepare() { }

	// RVA: 0x6F2E99C
	private object Cleanup() { }

	// RVA: 0x6F33B48
	internal static object Cleanup(object schema) { }

	// RVA: 0x6F2FB98
	private object Compile() { }

	// RVA: 0x6F32164
	private object Output(object schemaInfo) { }

	// RVA: 0x6F33B04
	private static object CleanupAttribute(object attribute) { }

	// RVA: 0x6F3345C
	private static object CleanupAttributeGroup(object attributeGroup) { }

	// RVA: 0x6F334B8
	private static object CleanupComplexType(object complexType) { }

	// RVA: 0x6F33904
	private static object CleanupSimpleType(object simpleType) { }

	// RVA: 0x6F33928
	private static object CleanupElement(object element) { }

	// RVA: 0x6F39A04
	private static object CleanupAttributes(object attributes) { }

	// RVA: 0x6F33424
	private static object CleanupGroup(object group) { }

	// RVA: 0x6F39B18
	private static object CleanupParticle(object particle) { }

	// RVA: 0x6F345A8
	private object CompileSubstitutionGroup(object substitutionGroup) { }

	// RVA: 0x6F39770
	private object CheckSubstitutionGroup(object substitutionGroup) { }

	// RVA: 0x6F34CA8
	private object CompileGroup(object group) { }

	// RVA: 0x6F366AC
	private object CompileSimpleType(object simpleType) { }

	// RVA: 0x6F3A18C
	private object CompileBaseMemberTypes(object simpleType) { }

	// RVA: 0x6F3A738
	private object CheckUnionType(object unionMember, object memberTypeDefinitions, object parentType) { }

	// RVA: 0x6F35738
	private object CompileComplexType(object complexType) { }

	// RVA: 0x6F3A8CC
	private object CompileSimpleContentExtension(object complexType, object simpleExtension) { }

	// RVA: 0x6F3AB78
	private object CompileSimpleContentRestriction(object complexType, object simpleRestriction) { }

	// RVA: 0x6F3B098
	private object CompileComplexContentExtension(object complexType, object complexContent, object complexExtension) { }

	// RVA: 0x6F3B600
	private object CompileComplexContentRestriction(object complexType, object complexContent, object complexRestriction) { }

	// RVA: 0x6F39600
	private object CheckParticleDerivation(object complexType) { }

	// RVA: 0x6F3D3C0
	private object CompileContentTypeParticle(object particle, object substitution) { }

	// RVA: 0x6F39CC0
	private object CannonicalizeParticle(object particle, object root, object substitution) { }

	// RVA: 0x6F3EB2C
	private object CannonicalizeElement(object element, object substitution) { }

	// RVA: 0x6F3ECD4
	private object CannonicalizeGroupRef(object groupRef, object root, object substitution) { }

	// RVA: 0x6F3F350
	private object CannonicalizeAll(object all, object root, object substitution) { }

	// RVA: 0x6F3F9D8
	private object CannonicalizeChoice(object choice, object root, object substitution) { }

	// RVA: 0x6F4007C
	private object CannonicalizeSequence(object sequence, object root, object substitution) { }

	// RVA: 0x6F3E378
	private object IsValidRestriction(object derivedParticle, object baseParticle) { }

	// RVA: 0x6F40790
	private object IsElementFromElement(object derivedElement, object baseElement) { }

	// RVA: 0x6F408BC
	private object IsElementFromAny(object derivedElement, object baseAny) { }

	// RVA: 0x6F40924
	private object IsAnyFromAny(object derivedAny, object baseAny) { }

	// RVA: 0x6F40984
	private object IsGroupBaseFromAny(object derivedGroupBase, object baseAny) { }

	// RVA: 0x6F40C80
	private object IsElementFromGroupBase(object derivedElement, object baseGroupBase, object skipEmptableOnly) { }

	// RVA: 0x6F41110
	private object IsGroupBaseFromGroupBase(object derivedGroupBase, object baseGroupBase, object skipEmptableOnly) { }

	// RVA: 0x6F41550
	private object IsSequenceFromAll(object derivedSequence, object baseAll) { }

	// RVA: 0x6F41AB0
	private object IsSequenceFromChoice(object derivedSequence, object baseChoice) { }

	// RVA: 0x6F429D0
	private object CalculateSequenceRange(object sequence, object minOccurs, object maxOccurs) { }

	// RVA: 0x6F41E08
	private object IsValidOccurrenceRangeRestriction(object derivedParticle, object baseParticle) { }

	// RVA: 0x6F427CC
	private object IsValidOccurrenceRangeRestriction(object minOccurs, object maxOccurs, object baseMinOccurs, object baseMaxOccurs) { }

	// RVA: 0x6F428B4
	private object GetMappingParticle(object particle, object collection) { }

	// RVA: 0x6F406C0
	private object IsParticleEmptiable(object particle) { }

	// RVA: 0x6F41F04
	private object CalculateEffectiveTotalRange(object particle, object minOccurs, object maxOccurs) { }

	// RVA: 0x6F42ED8
	private object PushComplexType(object complexType) { }

	// RVA: 0x6F3D578
	private object GetSchemaContentType(object complexType, object complexContent, object particle) { }

	// RVA: 0x6F34DAC
	private object CompileAttributeGroup(object attributeGroup) { }

	// RVA: 0x6F3BA1C
	private object CompileLocalAttributes(object baseType, object derivedType, object attributes, object anyAttribute, object derivedBy) { }

	// RVA: 0x6F42FEC
	private object CompileAnyAttributeUnion(object a, object b) { }

	// RVA: 0x6F42F30
	private object CompileAnyAttributeIntersection(object a, object b) { }

	// RVA: 0x6F380E0
	private object CompileAttribute(object xa) { }

	// RVA: 0x6F38DA4
	private object CompileIdentityConstraint(object xi) { }

	// RVA: 0x6F370B8
	private object CompileElement(object xe) { }

	// RVA: 0x6F3D64C
	private object CompileComplexContent(object complexType) { }

	// RVA: 0x6F43120
	private object BuildParticleContentModel(object contentValidator, object particle) { }

	// RVA: 0x6F438DC
	private object CompileParticleElements(object complexType, object particle) { }

	// RVA: 0x6F3951C
	private object CompileCompexTypeElements(object complexType) { }

	// RVA: 0x6F39FCC
	private object GetSimpleType(object name) { }

	// RVA: 0x6F3E284
	private object GetComplexType(object name) { }

	// RVA: 0x6F3E0D4
	private object GetAnySchemaType(object name) { }

}

// Namespace: 
private enum Compositor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Root;
	public const object Include;
	public const object Import;
}

// Namespace: System.Xml.Schema
internal sealed class SchemaCollectionPreprocessor
{

	// Fields
	private object schema; // 0x38
	private object targetNamespace; // 0x40
	private object buildinIncluded; // 0x48
	private object elementFormDefault; // 0x4C
	private object attributeFormDefault; // 0x50
	private object blockDefault; // 0x54
	private object finalDefault; // 0x58
	private object schemaLocations; // 0x60
	private object referenceNamespaces; // 0x68
	private object Xmlns; // 0x70
	private object xmlResolver; // 0x78

	// Properties
	internal object XmlResolver { set; }

	// Methods

	// RVA: 0x6F43BBC
	public object .ctor(object nameTable, object schemaNames, object eventHandler) { }

	// RVA: 0x6F43BC4
	public object Execute(object schema, object targetNamespace, object loadExternals, object xsc) { }

	// RVA: 0x6F43EB0
	private object Cleanup(object schema) { }

	// RVA: 0x6F47B74
	internal object set_XmlResolver(object value) { }

	// RVA: 0x6F441B0
	private object LoadExternals(object schema, object xsc) { }

	// RVA: 0x6F47E4C
	private object BuildRefNamespaces(object schema) { }

	// RVA: 0x6F451BC
	private object Preprocess(object schema, object targetNamespace, object compositor) { }

	// RVA: 0x6F482CC
	private object PreprocessRedefine(object redefine) { }

	// RVA: 0x6F4B9E4
	private object CountGroupSelfReference(object items, object name) { }

	// RVA: 0x6F4B240
	private object CheckRefinedGroup(object group) { }

	// RVA: 0x6F4B308
	private object CheckRefinedAttributeGroup(object attributeGroup) { }

	// RVA: 0x6F4B8C0
	private object CheckRefinedSimpleType(object stype) { }

	// RVA: 0x6F4B4AC
	private object CheckRefinedComplexType(object ctype) { }

	// RVA: 0x6F49724
	private object PreprocessAttribute(object attribute) { }

	// RVA: 0x6F4C348
	private object PreprocessLocalAttribute(object attribute) { }

	// RVA: 0x6F4C0C8
	private object PreprocessAttributeContent(object attribute) { }

	// RVA: 0x6F498AC
	private object PreprocessAttributeGroup(object attributeGroup) { }

	// RVA: 0x6F4AAE4
	private object PreprocessElement(object element) { }

	// RVA: 0x6F4CEBC
	private object PreprocessLocalElement(object element) { }

	// RVA: 0x6F4CAB8
	private object PreprocessElementContent(object element) { }

	// RVA: 0x6F4D2AC
	private object PreprocessIdentityConstraint(object constraint) { }

	// RVA: 0x6F4A444
	private object PreprocessSimpleType(object simpleType, object local) { }

	// RVA: 0x6F499B4
	private object PreprocessComplexType(object complexType, object local) { }

	// RVA: 0x6F4AD78
	private object PreprocessGroup(object group) { }

	// RVA: 0x6F4AF60
	private object PreprocessNotation(object notation) { }

	// RVA: 0x6F4D6F0
	private object PreprocessParticle(object particle) { }

	// RVA: 0x6F4C6EC
	private object PreprocessAttributes(object attributes, object anyAttribute, object parent) { }

	// RVA: 0x6F44E5C
	private object ValidateIdAttribute(object xso) { }

	// RVA: 0x6F4BD6C
	private object ValidateNameAttribute(object xso) { }

	// RVA: 0x6F4C518
	private object ValidateQNameAttribute(object xso, object attributeName, object value) { }

	// RVA: 0x6F4817C
	private object SetParent(object child, object parent) { }

	// RVA: 0x6F4819C
	private object PreprocessAnnotation(object schemaObject) { }

	// RVA: 0x6F47B7C
	private object ResolveSchemaLocationUri(object enclosingSchema, object location) { }

	// RVA: 0x6F47C88
	private object GetSchemaEntity(object ruri) { }

}

// Namespace: 
internal enum Use
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Required;
	public const object Implied;
	public const object Fixed;
	public const object RequiredFixed;
}

// Namespace: System.Xml.Schema
internal abstract class SchemaDeclBase
{

	// Fields
	protected object name; // 0x8
	protected object prefix; // 0x10
	protected object isDeclaredInExternal; // 0x18
	protected object presence; // 0x1C
	protected object schemaType; // 0x20
	protected object datatype; // 0x28
	protected object defaultValueRaw; // 0x30
	protected object defaultValueTyped; // 0x38
	protected object maxLength; // 0x40
	protected object minLength; // 0x48
	protected object values; // 0x50

	// Properties
	internal object Name { get; set; }
	internal object Prefix { get; set; }
	internal object IsDeclaredInExternal { get; set; }
	internal object Presence { get; set; }
	internal object MaxLength { get; set; }
	internal object MinLength { get; set; }
	internal object SchemaType { get; set; }
	internal object Datatype { get; set; }
	internal object Values { get; set; }
	internal object DefaultValueRaw { get; set; }
	internal object DefaultValueTyped { get; set; }

	// Methods

	// RVA: 0x6F4E0EC
	protected object .ctor(object name, object prefix) { }

	// RVA: 0x6F4E180
	protected object .ctor() { }

	// RVA: 0x6F4E1F4
	internal object get_Name() { }

	// RVA: 0x6F4E1FC
	internal object set_Name(object value) { }

	// RVA: 0x6F4E204
	internal object get_Prefix() { }

	// RVA: 0x6F4E270
	internal object set_Prefix(object value) { }

	// RVA: 0x6F4E278
	internal object get_IsDeclaredInExternal() { }

	// RVA: 0x6F4E280
	internal object set_IsDeclaredInExternal(object value) { }

	// RVA: 0x6F4E288
	internal object get_Presence() { }

	// RVA: 0x6F4E290
	internal object set_Presence(object value) { }

	// RVA: 0x6F4E298
	internal object get_MaxLength() { }

	// RVA: 0x6F4E2A0
	internal object set_MaxLength(object value) { }

	// RVA: 0x6F4E2A8
	internal object get_MinLength() { }

	// RVA: 0x6F4E2B0
	internal object set_MinLength(object value) { }

	// RVA: 0x6F4E2B8
	internal object get_SchemaType() { }

	// RVA: 0x6F4E2C0
	internal object set_SchemaType(object value) { }

	// RVA: 0x6F4E2C8
	internal object get_Datatype() { }

	// RVA: 0x6F4E2D0
	internal object set_Datatype(object value) { }

	// RVA: 0x6F4E2D8
	internal object AddValue(object value) { }

	// RVA: 0x6F4E43C
	internal object get_Values() { }

	// RVA: 0x6F4E444
	internal object set_Values(object value) { }

	// RVA: 0x6F4E44C
	internal object get_DefaultValueRaw() { }

	// RVA: 0x6F4E4B8
	internal object set_DefaultValueRaw(object value) { }

	// RVA: 0x6F4E4C0
	internal object get_DefaultValueTyped() { }

	// RVA: 0x6F4E4C8
	internal object set_DefaultValueTyped(object value) { }

	// RVA: 0x6F4E4D0
	internal object CheckEnumeration(object pVal) { }

	// RVA: 0x6F4E608
	internal object CheckValue(object pVal) { }

}

// Namespace: System.Xml.Schema
internal sealed class SchemaElementDecl
{

	// Fields
	private object attdefs; // 0x58
	private object defaultAttdefs; // 0x60
	private object isIdDeclared; // 0x68
	private object hasNonCDataAttribute; // 0x69
	private object isAbstract; // 0x6A
	private object isNillable; // 0x6B
	private object hasRequiredAttribute; // 0x6C
	private object isNotationDeclared; // 0x6D
	private object prohibitedAttributes; // 0x70
	private object contentValidator; // 0x78
	private object anyAttribute; // 0x80
	private object block; // 0x88
	private object constraints; // 0x90
	private object schemaElement; // 0x98
	internal static readonly object Empty; // 0x0

	// Properties
	private object System.Xml.IDtdAttributeListInfo.HasNonCDataAttributes { get; }
	internal object IsIdDeclared { get; set; }
	internal object HasNonCDataAttribute { get; set; }
	internal object IsAbstract { get; set; }
	internal object IsNillable { get; set; }
	internal object Block { get; set; }
	internal object IsNotationDeclared { get; set; }
	internal object HasDefaultAttribute { get; }
	internal object HasRequiredAttribute { get; }
	internal object ContentValidator { get; set; }
	internal object AnyAttribute { get; set; }
	internal object Constraints { get; set; }
	internal object SchemaElement { get; set; }
	internal object DefaultAttDefs { get; }
	internal object AttDefs { get; }
	internal object ProhibitedAttributes { get; }

	// Methods

	// RVA: 0x6F4E6AC
	internal object .ctor() { }

	// RVA: 0x6F4E7BC
	internal object .ctor(object dtype) { }

	// RVA: 0x6F4E914
	internal object .ctor(object name, object prefix) { }

	// RVA: 0x6F4EA44
	internal static object CreateAnyTypeElementDecl() { }

	// RVA: 0x6F4EB4C
	private object System.Xml.IDtdAttributeListInfo.get_HasNonCDataAttributes() { }

	// RVA: 0x6F4EB54
	private object System.Xml.IDtdAttributeListInfo.LookupAttribute(object prefix, object localName) { }

	// RVA: 0x6F4EC1C
	private object System.Xml.IDtdAttributeListInfo.LookupDefaultAttributes() { }

	// RVA: 0x6F4EC24
	internal object get_IsIdDeclared() { }

	// RVA: 0x6F4EC2C
	internal object set_IsIdDeclared(object value) { }

	// RVA: 0x6F4EC34
	internal object get_HasNonCDataAttribute() { }

	// RVA: 0x6F4EC3C
	internal object set_HasNonCDataAttribute(object value) { }

	// RVA: 0x6F4EC44
	internal object Clone() { }

	// RVA: 0x6F4ECB0
	internal object get_IsAbstract() { }

	// RVA: 0x6F4ECB8
	internal object set_IsAbstract(object value) { }

	// RVA: 0x6F4ECC0
	internal object get_IsNillable() { }

	// RVA: 0x6F4ECC8
	internal object set_IsNillable(object value) { }

	// RVA: 0x6F4ECD0
	internal object get_Block() { }

	// RVA: 0x6F4ECD8
	internal object set_Block(object value) { }

	// RVA: 0x6F4ECE0
	internal object get_IsNotationDeclared() { }

	// RVA: 0x6F4ECE8
	internal object set_IsNotationDeclared(object value) { }

	// RVA: 0x6F4ECF0
	internal object get_HasDefaultAttribute() { }

	// RVA: 0x6F4ED00
	internal object get_HasRequiredAttribute() { }

	// RVA: 0x6F4ED08
	internal object get_ContentValidator() { }

	// RVA: 0x6F4ED10
	internal object set_ContentValidator(object value) { }

	// RVA: 0x6F4ED18
	internal object get_AnyAttribute() { }

	// RVA: 0x6F4ED20
	internal object set_AnyAttribute(object value) { }

	// RVA: 0x6F4ED28
	internal object get_Constraints() { }

	// RVA: 0x6F4ED30
	internal object set_Constraints(object value) { }

	// RVA: 0x6F4ED38
	internal object get_SchemaElement() { }

	// RVA: 0x6F4ED40
	internal object set_SchemaElement(object value) { }

	// RVA: 0x6F4ED48
	internal object AddAttDef(object attdef) { }

	// RVA: 0x6F4EF40
	internal object GetAttDef(object qname) { }

	// RVA: 0x6F4EFCC
	internal object get_DefaultAttDefs() { }

	// RVA: 0x6F4EFD4
	internal object get_AttDefs() { }

	// RVA: 0x6F4EFDC
	internal object get_ProhibitedAttributes() { }

	// RVA: 0x6F4EFE4
	internal object CheckAttributes(object presence, object standalone) { }

	// RVA: 0x6F4F398
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class SchemaEntity
{

	// Fields
	private object qname; // 0x8
	private object url; // 0x10
	private object pubid; // 0x18
	private object text; // 0x20
	private object ndata; // 0x28
	private object lineNumber; // 0x30
	private object linePosition; // 0x34
	private object isParameter; // 0x38
	private object isExternal; // 0x39
	private object parsingInProgress; // 0x3A
	private object isDeclaredInExternal; // 0x3B
	private object baseURI; // 0x40
	private object declaredURI; // 0x48

	// Properties
	private object System.Xml.IDtdEntityInfo.Name { get; }
	private object System.Xml.IDtdEntityInfo.IsExternal { get; }
	private object System.Xml.IDtdEntityInfo.IsDeclaredInExternal { get; }
	private object System.Xml.IDtdEntityInfo.IsUnparsedEntity { get; }
	private object System.Xml.IDtdEntityInfo.IsParameterEntity { get; }
	private object System.Xml.IDtdEntityInfo.BaseUriString { get; }
	private object System.Xml.IDtdEntityInfo.DeclaredUriString { get; }
	private object System.Xml.IDtdEntityInfo.SystemId { get; }
	private object System.Xml.IDtdEntityInfo.PublicId { get; }
	private object System.Xml.IDtdEntityInfo.Text { get; }
	private object System.Xml.IDtdEntityInfo.LineNumber { get; }
	private object System.Xml.IDtdEntityInfo.LinePosition { get; }
	internal object Name { get; }
	internal object Url { get; set; }
	internal object Pubid { get; set; }
	internal object IsExternal { get; set; }
	internal object DeclaredInExternal { get; set; }
	internal object NData { get; set; }
	internal object Text { get; set; }
	internal object Line { get; set; }
	internal object Pos { get; set; }
	internal object BaseURI { get; set; }
	internal object ParsingInProgress { get; set; }
	internal object DeclaredURI { get; set; }

	// Methods

	// RVA: 0x6F4F3F4
	internal object .ctor(object qname, object isParameter) { }

	// RVA: 0x6F4F484
	private object System.Xml.IDtdEntityInfo.get_Name() { }

	// RVA: 0x6F4F4A8
	private object System.Xml.IDtdEntityInfo.get_IsExternal() { }

	// RVA: 0x6F4F4B0
	private object System.Xml.IDtdEntityInfo.get_IsDeclaredInExternal() { }

	// RVA: 0x6F4F4B8
	private object System.Xml.IDtdEntityInfo.get_IsUnparsedEntity() { }

	// RVA: 0x6F4F4E8
	private object System.Xml.IDtdEntityInfo.get_IsParameterEntity() { }

	// RVA: 0x6F4F4F0
	private object System.Xml.IDtdEntityInfo.get_BaseUriString() { }

	// RVA: 0x6F4F5C8
	private object System.Xml.IDtdEntityInfo.get_DeclaredUriString() { }

	// RVA: 0x6F4F6A0
	private object System.Xml.IDtdEntityInfo.get_SystemId() { }

	// RVA: 0x6F4F6A8
	private object System.Xml.IDtdEntityInfo.get_PublicId() { }

	// RVA: 0x6F4F6B0
	private object System.Xml.IDtdEntityInfo.get_Text() { }

	// RVA: 0x6F4F6B8
	private object System.Xml.IDtdEntityInfo.get_LineNumber() { }

	// RVA: 0x6F4F6C0
	private object System.Xml.IDtdEntityInfo.get_LinePosition() { }

	// RVA: 0x6F4F6C8
	internal static object IsPredefinedEntity(object n) { }

	// RVA: 0x6F4F7D4
	internal object get_Name() { }

	// RVA: 0x6F4F7DC
	internal object get_Url() { }

	// RVA: 0x6F4F7E4
	internal object set_Url(object value) { }

	// RVA: 0x6F4F7F4
	internal object get_Pubid() { }

	// RVA: 0x6F4F7FC
	internal object set_Pubid(object value) { }

	// RVA: 0x6F4F804
	internal object get_IsExternal() { }

	// RVA: 0x6F4F80C
	internal object set_IsExternal(object value) { }

	// RVA: 0x6F4F814
	internal object get_DeclaredInExternal() { }

	// RVA: 0x6F4F81C
	internal object set_DeclaredInExternal(object value) { }

	// RVA: 0x6F4F824
	internal object get_NData() { }

	// RVA: 0x6F4F82C
	internal object set_NData(object value) { }

	// RVA: 0x6F4F834
	internal object get_Text() { }

	// RVA: 0x6F4F83C
	internal object set_Text(object value) { }

	// RVA: 0x6F4F848
	internal object get_Line() { }

	// RVA: 0x6F4F850
	internal object set_Line(object value) { }

	// RVA: 0x6F4F858
	internal object get_Pos() { }

	// RVA: 0x6F4F860
	internal object set_Pos(object value) { }

	// RVA: 0x6F4F55C
	internal object get_BaseURI() { }

	// RVA: 0x6F4F868
	internal object set_BaseURI(object value) { }

	// RVA: 0x6F4F870
	internal object get_ParsingInProgress() { }

	// RVA: 0x6F4F878
	internal object set_ParsingInProgress(object value) { }

	// RVA: 0x6F4F634
	internal object get_DeclaredURI() { }

	// RVA: 0x6F4F880
	internal object set_DeclaredURI(object value) { }

}

// Namespace: System.Xml.Schema
internal enum AttributeMatchState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AttributeFound;
	public const object AnyIdAttributeFound;
	public const object UndeclaredElementAndAttribute;
	public const object UndeclaredAttribute;
	public const object AnyAttributeLax;
	public const object AnyAttributeSkip;
	public const object ProhibitedAnyAttribute;
	public const object ProhibitedAttribute;
	public const object AttributeNameMismatch;
	public const object ValidateAttributeInvalidCall;
}

// Namespace: System.Xml.Schema
internal class SchemaInfo
{

	// Fields
	private object elementDecls; // 0x8
	private object undeclaredElementDecls; // 0x10
	private object generalEntities; // 0x18
	private object parameterEntities; // 0x20
	private object docTypeName; // 0x28
	private object internalDtdSubset; // 0x30
	private object hasNonCDataAttributes; // 0x38
	private object hasDefaultAttributes; // 0x39
	private object targetNamespaces; // 0x40
	private object attributeDecls; // 0x48
	private object errorCount; // 0x50
	private object schemaType; // 0x54
	private object elementDeclsByType; // 0x58
	private object notations; // 0x60

	// Properties
	public object DocTypeName { get; set; }
	internal object InternalDtdSubset { set; }
	internal object ElementDecls { get; }
	internal object UndeclaredElementDecls { get; }
	internal object GeneralEntities { get; }
	internal object ParameterEntities { get; }
	internal object SchemaType { get; set; }
	internal object TargetNamespaces { get; }
	internal object ElementDeclsByType { get; }
	internal object AttributeDecls { get; }
	internal object Notations { get; }
	internal object ErrorCount { get; set; }
	private object System.Xml.IDtdInfo.HasDefaultAttributes { get; }
	private object System.Xml.IDtdInfo.HasNonCDataAttributes { get; }
	private object System.Xml.IDtdInfo.Name { get; }
	private object System.Xml.IDtdInfo.InternalDtdSubset { get; }

	// Methods

	// RVA: 0x6F4F888
	internal object .ctor() { }

	// RVA: 0x6F4FA2C
	public object get_DocTypeName() { }

	// RVA: 0x6F4FA34
	public object set_DocTypeName(object value) { }

	// RVA: 0x6F4FA3C
	internal object set_InternalDtdSubset(object value) { }

	// RVA: 0x6F4FA44
	internal object get_ElementDecls() { }

	// RVA: 0x6F4FA4C
	internal object get_UndeclaredElementDecls() { }

	// RVA: 0x6F4FA54
	internal object get_GeneralEntities() { }

	// RVA: 0x6F4FAE4
	internal object get_ParameterEntities() { }

	// RVA: 0x6F4FB74
	internal object get_SchemaType() { }

	// RVA: 0x6F4FB7C
	internal object set_SchemaType(object value) { }

	// RVA: 0x6F4FB84
	internal object get_TargetNamespaces() { }

	// RVA: 0x6F4FB8C
	internal object get_ElementDeclsByType() { }

	// RVA: 0x6F4FB94
	internal object get_AttributeDecls() { }

	// RVA: 0x6F4FB9C
	internal object get_Notations() { }

	// RVA: 0x6F4FC2C
	internal object get_ErrorCount() { }

	// RVA: 0x6F4FC34
	internal object set_ErrorCount(object value) { }

	// RVA: 0x6F4FC3C
	internal object GetElementDecl(object qname) { }

	// RVA: 0x6F4FCC8
	internal object GetTypeDecl(object qname) { }

	// RVA: 0x6F4FD54
	internal object GetElement(object qname) { }

	// RVA: 0x6F4FE00
	internal object HasSchema(object ns) { }

	// RVA: 0x6F4FE6C
	internal object Contains(object ns) { }

	// RVA: 0x6F4FED8
	internal object GetAttributeXdr(object ed, object qname) { }

	// RVA: 0x6F500C0
	internal object GetAttributeXsd(object ed, object qname, object partialValidationType, object attributeMatchState) { }

	// RVA: 0x6F503A4
	internal object GetAttributeXsd(object ed, object qname, object skip) { }

	// RVA: 0x6F504C0
	internal object Add(object sinfo, object eventhandler) { }

	// RVA: 0x6F50FC0
	internal object Finish() { }

	// RVA: 0x6F51274
	private object System.Xml.IDtdInfo.get_HasDefaultAttributes() { }

	// RVA: 0x6F5127C
	private object System.Xml.IDtdInfo.get_HasNonCDataAttributes() { }

	// RVA: 0x6F51284
	private object System.Xml.IDtdInfo.LookupAttributeList(object prefix, object localName) { }

	// RVA: 0x6F5136C
	private object System.Xml.IDtdInfo.LookupEntity(object name) { }

	// RVA: 0x6F51444
	private object System.Xml.IDtdInfo.get_Name() { }

	// RVA: 0x6F5144C
	private object System.Xml.IDtdInfo.get_InternalDtdSubset() { }

}

// Namespace: 
public enum Token
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Empty;
	public const object SchemaName;
	public const object SchemaType;
	public const object SchemaMaxOccurs;
	public const object SchemaMinOccurs;
	public const object SchemaInfinite;
	public const object SchemaModel;
	public const object SchemaOpen;
	public const object SchemaClosed;
	public const object SchemaContent;
	public const object SchemaMixed;
	public const object SchemaEmpty;
	public const object SchemaElementOnly;
	public const object SchemaTextOnly;
	public const object SchemaOrder;
	public const object SchemaSeq;
	public const object SchemaOne;
	public const object SchemaMany;
	public const object SchemaRequired;
	public const object SchemaYes;
	public const object SchemaNo;
	public const object SchemaString;
	public const object SchemaId;
	public const object SchemaIdref;
	public const object SchemaIdrefs;
	public const object SchemaEntity;
	public const object SchemaEntities;
	public const object SchemaNmtoken;
	public const object SchemaNmtokens;
	public const object SchemaEnumeration;
	public const object SchemaDefault;
	public const object XdrRoot;
	public const object XdrElementType;
	public const object XdrElement;
	public const object XdrGroup;
	public const object XdrAttributeType;
	public const object XdrAttribute;
	public const object XdrDatatype;
	public const object XdrDescription;
	public const object XdrExtends;
	public const object SchemaXdrRootAlias;
	public const object SchemaDtType;
	public const object SchemaDtValues;
	public const object SchemaDtMaxLength;
	public const object SchemaDtMinLength;
	public const object SchemaDtMax;
	public const object SchemaDtMin;
	public const object SchemaDtMinExclusive;
	public const object SchemaDtMaxExclusive;
	public const object SchemaTargetNamespace;
	public const object SchemaVersion;
	public const object SchemaFinalDefault;
	public const object SchemaBlockDefault;
	public const object SchemaFixed;
	public const object SchemaAbstract;
	public const object SchemaBlock;
	public const object SchemaSubstitutionGroup;
	public const object SchemaFinal;
	public const object SchemaNillable;
	public const object SchemaRef;
	public const object SchemaBase;
	public const object SchemaDerivedBy;
	public const object SchemaNamespace;
	public const object SchemaProcessContents;
	public const object SchemaRefer;
	public const object SchemaPublic;
	public const object SchemaSystem;
	public const object SchemaSchemaLocation;
	public const object SchemaValue;
	public const object SchemaSource;
	public const object SchemaAttributeFormDefault;
	public const object SchemaElementFormDefault;
	public const object SchemaUse;
	public const object SchemaForm;
	public const object XsdSchema;
	public const object XsdAnnotation;
	public const object XsdInclude;
	public const object XsdImport;
	public const object XsdElement;
	public const object XsdAttribute;
	public const object xsdAttributeGroup;
	public const object XsdAnyAttribute;
	public const object XsdGroup;
	public const object XsdAll;
	public const object XsdChoice;
	public const object XsdSequence;
	public const object XsdAny;
	public const object XsdNotation;
	public const object XsdSimpleType;
	public const object XsdComplexType;
	public const object XsdUnique;
	public const object XsdKey;
	public const object XsdKeyref;
	public const object XsdSelector;
	public const object XsdField;
	public const object XsdMinExclusive;
	public const object XsdMinInclusive;
	public const object XsdMaxExclusive;
	public const object XsdMaxInclusive;
	public const object XsdTotalDigits;
	public const object XsdFractionDigits;
	public const object XsdLength;
	public const object XsdMinLength;
	public const object XsdMaxLength;
	public const object XsdEnumeration;
	public const object XsdPattern;
	public const object XsdDocumentation;
	public const object XsdAppInfo;
	public const object XsdComplexContent;
	public const object XsdComplexContentExtension;
	public const object XsdComplexContentRestriction;
	public const object XsdSimpleContent;
	public const object XsdSimpleContentExtension;
	public const object XsdSimpleContentRestriction;
	public const object XsdSimpleTypeList;
	public const object XsdSimpleTypeRestriction;
	public const object XsdSimpleTypeUnion;
	public const object XsdWhitespace;
	public const object XsdRedefine;
	public const object SchemaItemType;
	public const object SchemaMemberTypes;
	public const object SchemaXPath;
	public const object XmlLang;
}

// Namespace: System.Xml.Schema
internal sealed class SchemaNames
{

	// Fields
	private object nameTable; // 0x8
	public object NsDataType; // 0x10
	public object NsDataTypeAlias; // 0x18
	public object NsDataTypeOld; // 0x20
	public object NsXml; // 0x28
	public object NsXmlNs; // 0x30
	public object NsXdr; // 0x38
	public object NsXdrAlias; // 0x40
	public object NsXs; // 0x48
	public object NsXsi; // 0x50
	public object XsiType; // 0x58
	public object XsiNil; // 0x60
	public object XsiSchemaLocation; // 0x68
	public object XsiNoNamespaceSchemaLocation; // 0x70
	public object XsdSchema; // 0x78
	public object XdrSchema; // 0x80
	public object QnPCData; // 0x88
	public object QnXml; // 0x90
	public object QnXmlNs; // 0x98
	public object QnDtDt; // 0xA0
	public object QnXmlLang; // 0xA8
	public object QnName; // 0xB0
	public object QnType; // 0xB8
	public object QnMaxOccurs; // 0xC0
	public object QnMinOccurs; // 0xC8
	public object QnInfinite; // 0xD0
	public object QnModel; // 0xD8
	public object QnOpen; // 0xE0
	public object QnClosed; // 0xE8
	public object QnContent; // 0xF0
	public object QnMixed; // 0xF8
	public object QnEmpty; // 0x100
	public object QnEltOnly; // 0x108
	public object QnTextOnly; // 0x110
	public object QnOrder; // 0x118
	public object QnSeq; // 0x120
	public object QnOne; // 0x128
	public object QnMany; // 0x130
	public object QnRequired; // 0x138
	public object QnYes; // 0x140
	public object QnNo; // 0x148
	public object QnString; // 0x150
	public object QnID; // 0x158
	public object QnIDRef; // 0x160
	public object QnIDRefs; // 0x168
	public object QnEntity; // 0x170
	public object QnEntities; // 0x178
	public object QnNmToken; // 0x180
	public object QnNmTokens; // 0x188
	public object QnEnumeration; // 0x190
	public object QnDefault; // 0x198
	public object QnXdrSchema; // 0x1A0
	public object QnXdrElementType; // 0x1A8
	public object QnXdrElement; // 0x1B0
	public object QnXdrGroup; // 0x1B8
	public object QnXdrAttributeType; // 0x1C0
	public object QnXdrAttribute; // 0x1C8
	public object QnXdrDataType; // 0x1D0
	public object QnXdrDescription; // 0x1D8
	public object QnXdrExtends; // 0x1E0
	public object QnXdrAliasSchema; // 0x1E8
	public object QnDtType; // 0x1F0
	public object QnDtValues; // 0x1F8
	public object QnDtMaxLength; // 0x200
	public object QnDtMinLength; // 0x208
	public object QnDtMax; // 0x210
	public object QnDtMin; // 0x218
	public object QnDtMinExclusive; // 0x220
	public object QnDtMaxExclusive; // 0x228
	public object QnTargetNamespace; // 0x230
	public object QnVersion; // 0x238
	public object QnFinalDefault; // 0x240
	public object QnBlockDefault; // 0x248
	public object QnFixed; // 0x250
	public object QnAbstract; // 0x258
	public object QnBlock; // 0x260
	public object QnSubstitutionGroup; // 0x268
	public object QnFinal; // 0x270
	public object QnNillable; // 0x278
	public object QnRef; // 0x280
	public object QnBase; // 0x288
	public object QnDerivedBy; // 0x290
	public object QnNamespace; // 0x298
	public object QnProcessContents; // 0x2A0
	public object QnRefer; // 0x2A8
	public object QnPublic; // 0x2B0
	public object QnSystem; // 0x2B8
	public object QnSchemaLocation; // 0x2C0
	public object QnValue; // 0x2C8
	public object QnUse; // 0x2D0
	public object QnForm; // 0x2D8
	public object QnElementFormDefault; // 0x2E0
	public object QnAttributeFormDefault; // 0x2E8
	public object QnItemType; // 0x2F0
	public object QnMemberTypes; // 0x2F8
	public object QnXPath; // 0x300
	public object QnXsdSchema; // 0x308
	public object QnXsdAnnotation; // 0x310
	public object QnXsdInclude; // 0x318
	public object QnXsdImport; // 0x320
	public object QnXsdElement; // 0x328
	public object QnXsdAttribute; // 0x330
	public object QnXsdAttributeGroup; // 0x338
	public object QnXsdAnyAttribute; // 0x340
	public object QnXsdGroup; // 0x348
	public object QnXsdAll; // 0x350
	public object QnXsdChoice; // 0x358
	public object QnXsdSequence; // 0x360
	public object QnXsdAny; // 0x368
	public object QnXsdNotation; // 0x370
	public object QnXsdSimpleType; // 0x378
	public object QnXsdComplexType; // 0x380
	public object QnXsdUnique; // 0x388
	public object QnXsdKey; // 0x390
	public object QnXsdKeyRef; // 0x398
	public object QnXsdSelector; // 0x3A0
	public object QnXsdField; // 0x3A8
	public object QnXsdMinExclusive; // 0x3B0
	public object QnXsdMinInclusive; // 0x3B8
	public object QnXsdMaxInclusive; // 0x3C0
	public object QnXsdMaxExclusive; // 0x3C8
	public object QnXsdTotalDigits; // 0x3D0
	public object QnXsdFractionDigits; // 0x3D8
	public object QnXsdLength; // 0x3E0
	public object QnXsdMinLength; // 0x3E8
	public object QnXsdMaxLength; // 0x3F0
	public object QnXsdEnumeration; // 0x3F8
	public object QnXsdPattern; // 0x400
	public object QnXsdDocumentation; // 0x408
	public object QnXsdAppinfo; // 0x410
	public object QnSource; // 0x418
	public object QnXsdComplexContent; // 0x420
	public object QnXsdSimpleContent; // 0x428
	public object QnXsdRestriction; // 0x430
	public object QnXsdExtension; // 0x438
	public object QnXsdUnion; // 0x440
	public object QnXsdList; // 0x448
	public object QnXsdWhiteSpace; // 0x450
	public object QnXsdRedefine; // 0x458
	public object QnXsdAnyType; // 0x460
	internal object TokenToQName; // 0x468

	// Methods

	// RVA: 0x6F51454
	public object .ctor(object nameTable) { }

	// RVA: 0x6F54848
	public object CreateTokenToQNameTable() { }

	// RVA: 0x6F56778
	public object SchemaTypeFromRoot(object localName, object ns) { }

	// RVA: 0x6F56828
	public object IsXSDRoot(object localName, object ns) { }

	// RVA: 0x6F56878
	public object IsXDRRoot(object localName, object ns) { }

}

// Namespace: System.Xml.Schema
internal class SchemaNamespaceManager
{

	// Fields
	private object node; // 0x48

	// Methods

	// RVA: 0x6F568C8
	public object .ctor(object node) { }

	// RVA: 0x6F568F4
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x6F56A88
	public override object LookupPrefix(object ns) { }

}

// Namespace: System.Xml.Schema
internal sealed class SchemaNotation
{

	// Fields
	private object name; // 0x8
	private object systemLiteral; // 0x10
	private object pubid; // 0x18

	// Properties
	internal object Name { get; }
	internal object SystemLiteral { get; set; }
	internal object Pubid { get; set; }

	// Methods

	// RVA: 0x6F56F2C
	internal object .ctor(object name) { }

	// RVA: 0x6F56F58
	internal object get_Name() { }

	// RVA: 0x6F56F60
	internal object get_SystemLiteral() { }

	// RVA: 0x6F56F68
	internal object set_SystemLiteral(object value) { }

	// RVA: 0x6F56F70
	internal object get_Pubid() { }

	// RVA: 0x6F56F78
	internal object set_Pubid(object value) { }

}

// Namespace: System.Xml.Schema
internal sealed class Compiler
{

	// Fields
	private object restrictionErrorMsg; // 0x38
	private object attributes; // 0x40
	private object attributeGroups; // 0x48
	private object elements; // 0x50
	private object schemaTypes; // 0x58
	private object groups; // 0x60
	private object notations; // 0x68
	private object examplars; // 0x70
	private object identityConstraints; // 0x78
	private object complexTypeStack; // 0x80
	private object schemasToCompile; // 0x88
	private object importedSchemas; // 0x90
	private object schemaForSchema; // 0x98

	// Methods

	// RVA: 0x6F56F80
	public object .ctor(object nameTable, object eventHandler, object schemaForSchema, object compilationSettings) { }

	// RVA: 0x6F57144
	public object Execute(object schemaSet, object schemaCompiledInfo) { }

	// RVA: 0x6F5AC3C
	internal object Prepare(object schema, object cleanup) { }

	// RVA: 0x6F5D1C8
	private object UpdateSForSSimpleTypes() { }

	// RVA: 0x6F59768
	private object Output(object schemaInfo) { }

	// RVA: 0x6F5D384
	internal object ImportAllCompiledSchemas(object schemaSet) { }

	// RVA: 0x6F571C4
	internal object Compile() { }

	// RVA: 0x6F5CAA4
	private object CleanupAttribute(object attribute) { }

	// RVA: 0x6F5CB28
	private object CleanupAttributeGroup(object attributeGroup) { }

	// RVA: 0x6F5CB8C
	private object CleanupComplexType(object complexType) { }

	// RVA: 0x6F5D108
	private object CleanupSimpleType(object simpleType) { }

	// RVA: 0x6F5C8B8
	private object CleanupElement(object element) { }

	// RVA: 0x6F630F0
	private object CleanupAttributes(object attributes) { }

	// RVA: 0x6F5CAE0
	private object CleanupGroup(object group) { }

	// RVA: 0x6F631F8
	private object CleanupParticle(object particle) { }

	// RVA: 0x6F61EC4
	private object ProcessSubstitutionGroups() { }

	// RVA: 0x6F633F4
	private object CompileSubstitutionGroup(object substitutionGroup) { }

	// RVA: 0x6F62F74
	private object RecursivelyCheckRedefinedGroups(object redefinedGroup, object baseGroup) { }

	// RVA: 0x6F63054
	private object RecursivelyCheckRedefinedAttributeGroups(object attributeGroup, object baseAttributeGroup) { }

	// RVA: 0x6F5D4C8
	private object CompileGroup(object group) { }

	// RVA: 0x6F5EEA4
	private object CompileSimpleType(object simpleType) { }

	// RVA: 0x6F64CBC
	private object CompileBaseMemberTypes(object simpleType) { }

	// RVA: 0x6F65264
	private object CheckUnionType(object unionMember, object memberTypeDefinitions, object parentType) { }

	// RVA: 0x6F5E174
	private object CompileComplexType(object complexType) { }

	// RVA: 0x6F653F8
	private object CompileSimpleContentExtension(object complexType, object simpleExtension) { }

	// RVA: 0x6F656A4
	private object CompileSimpleContentRestriction(object complexType, object simpleRestriction) { }

	// RVA: 0x6F65BF4
	private object CompileComplexContentExtension(object complexType, object complexContent, object complexExtension) { }

	// RVA: 0x6F66150
	private object CompileComplexContentRestriction(object complexType, object complexContent, object complexRestriction) { }

	// RVA: 0x6F628B0
	private object CheckParticleDerivation(object complexType) { }

	// RVA: 0x6F63FF8
	private object CheckParticleDerivation(object derivedParticle, object baseParticle) { }

	// RVA: 0x6F67F44
	private object CompileContentTypeParticle(object particle) { }

	// RVA: 0x6F63BF4
	private object CannonicalizeParticle(object particle, object root) { }

	// RVA: 0x6F6B518
	private object CannonicalizeElement(object element) { }

	// RVA: 0x6F69DBC
	private object CannonicalizeGroupRef(object groupRef, object root) { }

	// RVA: 0x6F6A454
	private object CannonicalizeAll(object all, object root) { }

	// RVA: 0x6F6A7E4
	private object CannonicalizeChoice(object choice, object root) { }

	// RVA: 0x6F6AEB0
	private object CannonicalizeSequence(object sequence, object root) { }

	// RVA: 0x6F68ED4
	private object CannonicalizePointlessRoot(object particle) { }

	// RVA: 0x6F691FC
	private object IsValidRestriction(object derivedParticle, object baseParticle) { }

	// RVA: 0x6F6B994
	private object IsElementFromElement(object derivedElement, object baseElement) { }

	// RVA: 0x6F6BBF0
	private object IsElementFromAny(object derivedElement, object baseAny) { }

	// RVA: 0x6F6BDF8
	private object IsAnyFromAny(object derivedAny, object baseAny) { }

	// RVA: 0x6F6BF10
	private object IsGroupBaseFromAny(object derivedGroupBase, object baseAny) { }

	// RVA: 0x6F6C3F8
	private object IsElementFromGroupBase(object derivedElement, object baseGroupBase) { }

	// RVA: 0x6F6D7A8
	private object IsChoiceFromChoiceSubstGroup(object derivedChoice, object baseChoice) { }

	// RVA: 0x6F6CDA0
	private object IsGroupBaseFromGroupBase(object derivedGroupBase, object baseGroupBase, object skipEmptableOnly) { }

	// RVA: 0x6F6D248
	private object IsSequenceFromAll(object derivedSequence, object baseAll) { }

	// RVA: 0x6F6D9B4
	private object IsSequenceFromChoice(object derivedSequence, object baseChoice) { }

	// RVA: 0x6F6DE80
	private object IsValidOccurrenceRangeRestriction(object derivedParticle, object baseParticle) { }

	// RVA: 0x6F6EB74
	private object IsValidOccurrenceRangeRestriction(object minOccurs, object maxOccurs, object baseMinOccurs, object baseMaxOccurs) { }

	// RVA: 0x6F6EC5C
	private object GetMappingParticle(object particle, object collection) { }

	// RVA: 0x6F6B8C4
	private object IsParticleEmptiable(object particle) { }

	// RVA: 0x6F6E21C
	private object CalculateEffectiveTotalRange(object particle, object minOccurs, object maxOccurs) { }

	// RVA: 0x6F6ED78
	private object PushComplexType(object complexType) { }

	// RVA: 0x6F680F4
	private object GetSchemaContentType(object complexType, object complexContent, object particle) { }

	// RVA: 0x6F5D5C8
	private object CompileAttributeGroup(object attributeGroup) { }

	// RVA: 0x6F66564
	private object CompileLocalAttributes(object baseType, object derivedType, object attributes, object anyAttribute, object derivedBy) { }

	// RVA: 0x6F640D4
	private object CheckAtrributeGroupRestriction(object baseAttributeGroup, object derivedAttributeGroup) { }

	// RVA: 0x6F6EF84
	private object IsProcessContentsRestricted(object baseType, object derivedAttributeWildcard, object baseAttributeWildcard) { }

	// RVA: 0x6F6EEC8
	private object CompileAnyAttributeUnion(object a, object b) { }

	// RVA: 0x6F6EDD0
	private object CompileAnyAttributeIntersection(object a, object b) { }

	// RVA: 0x6F60AE4
	private object CompileAttribute(object xa) { }

	// RVA: 0x6F6F0C4
	private object SetDefaultFixed(object xa, object decl) { }

	// RVA: 0x6F615D0
	private object CompileIdentityConstraint(object xi) { }

	// RVA: 0x6F5F8FC
	private object CompileElement(object xe) { }

	// RVA: 0x6F681C8
	private object CompileComplexContent(object complexType) { }

	// RVA: 0x6F6F318
	private object BuildParticleContentModel(object contentValidator, object particle) { }

	// RVA: 0x6F6FAB8
	private object CompileParticleElements(object complexType, object particle) { }

	// RVA: 0x6F63E38
	private object CompileParticleElements(object particle) { }

	// RVA: 0x6F61D2C
	private object CompileComplexTypeElements(object complexType) { }

	// RVA: 0x6F64BB4
	private object GetSimpleType(object name) { }

	// RVA: 0x6F68DF8
	private object GetComplexType(object name) { }

	// RVA: 0x6F68C60
	private object GetAnySchemaType(object name) { }

	// RVA: 0x6F6B830
	private object CopyPosition(object to, object from, object copyParent) { }

	// RVA: 0x6F6DF7C
	private object IsFixedEqual(object baseDecl, object derivedDecl) { }

}

// Namespace: System.Xml.Schema
internal enum SchemaType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object DTD;
	public const object XDR;
	public const object XSD;
}

// Namespace: System.Xml.Schema
public class ValidationEventArgs
{

	// Fields
	private object ex; // 0x8
	private object severity; // 0x10

	// Properties
	public object Severity { get; }
	public object Exception { get; }

	// Methods

	// RVA: 0x6F6FDD4
	internal object .ctor(object ex) { }

	// RVA: 0x6F6FE48
	internal object .ctor(object ex, object severity) { }

	// RVA: 0x6F6FEC8
	public object get_Severity() { }

	// RVA: 0x6F6FED0
	public object get_Exception() { }

}

// Namespace: System.Xml.Schema
public sealed class ValidationEventHandler
{

	// Methods

	// RVA: 0x6F701DC
	public object .ctor(object object, object method) { }

	// RVA: 0x6F702E8
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Xml.Schema
internal struct StateUnion
{

	// Fields
	public object State; // 0xFFFFFFFFFFFFFFF8
	public object AllElementsRequired; // 0xFFFFFFFFFFFFFFF8
	public object CurPosIndex; // 0xFFFFFFFFFFFFFFF8
	public object NumberOfRunningPos; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Xml.Schema
internal sealed class ValidationState
{

	// Fields
	public object IsNill; // 0x8
	public object IsDefault; // 0x9
	public object NeedValidateChildren; // 0xA
	public object CheckRequiredAttribute; // 0xB
	public object ValidationSkipped; // 0xC
	public object ProcessContents; // 0x10
	public object Validity; // 0x14
	public object ElementDecl; // 0x18
	public object ElementDeclBeforeXsi; // 0x20
	public object LocalName; // 0x28
	public object Namespace; // 0x30
	public object Constr; // 0x38
	public object CurrentState; // 0x40
	public object HasMatched; // 0x44
	public object CurPos; // 0x48
	public object AllElementsSet; // 0x50
	public object RunningPositions; // 0x58
	public object TooComplex; // 0x60

	// Methods

	// RVA: 0x6F702FC
	public object .ctor() { }

}

// Namespace: 
private sealed class DeclBaseInfo
{

	// Fields
	internal object _Name; // 0x8
	internal object _Prefix; // 0x10
	internal object _TypeName; // 0x18
	internal object _TypePrefix; // 0x20
	internal object _Default; // 0x28
	internal object _Revises; // 0x30
	internal object _MaxOccurs; // 0x38
	internal object _MinOccurs; // 0x3C
	internal object _Checking; // 0x40
	internal object _ElementDecl; // 0x48
	internal object _Attdef; // 0x50
	internal object _Next; // 0x58

	// Methods

	// RVA: 0x6F767B4
	internal object .ctor() { }

	// RVA: 0x6F76F14
	internal object Reset() { }

}

// Namespace: 
private sealed class GroupContent
{

	// Fields
	internal object _MinVal; // 0x8
	internal object _MaxVal; // 0xC
	internal object _HasMaxAttr; // 0x10
	internal object _HasMinAttr; // 0x11
	internal object _Order; // 0x14

	// Methods

	// RVA: 0x6F7B9B4
	internal static object Copy(object from, object to) { }

	// RVA: 0x6F721A4
	internal static object Copy(object other) { }

	// RVA: 0x6F70568
	public object .ctor() { }

}

// Namespace: 
private sealed class ElementContent
{

	// Fields
	internal object _ElementDecl; // 0x8
	internal object _ContentAttr; // 0x10
	internal object _OrderAttr; // 0x14
	internal object _MasterGroupRequired; // 0x18
	internal object _ExistTerminal; // 0x19
	internal object _AllowDataType; // 0x1A
	internal object _HasDataType; // 0x1B
	internal object _HasType; // 0x1C
	internal object _EnumerationRequired; // 0x1D
	internal object _MinVal; // 0x20
	internal object _MaxVal; // 0x24
	internal object _MaxLength; // 0x28
	internal object _MinLength; // 0x2C
	internal object _AttDefList; // 0x30

	// Methods

	// RVA: 0x6F70558
	public object .ctor() { }

}

// Namespace: 
private sealed class AttributeContent
{

	// Fields
	internal object _AttDef; // 0x8
	internal object _Name; // 0x10
	internal object _Prefix; // 0x18
	internal object _Required; // 0x20
	internal object _MinVal; // 0x24
	internal object _MaxVal; // 0x28
	internal object _MaxLength; // 0x2C
	internal object _MinLength; // 0x30
	internal object _EnumerationRequired; // 0x34
	internal object _HasDataType; // 0x35
	internal object _Global; // 0x36
	internal object _Default; // 0x38

	// Methods

	// RVA: 0x6F70560
	public object .ctor() { }

}

// Namespace: 
private sealed class XdrBuildFunction
{

	// Methods

	// RVA: 0x6F7B574
	public object .ctor(object object, object method) { }

	// RVA: 0x6F7BAA8
	public virtual object Invoke(object builder, object obj, object prefix) { }

}

// Namespace: 
private sealed class XdrInitFunction
{

	// Methods

	// RVA: 0x6F7B7B4
	public object .ctor(object object, object method) { }

	// RVA: 0x6F7BB58
	public virtual object Invoke(object builder, object obj) { }

}

// Namespace: 
private sealed class XdrBeginChildFunction
{

	// Methods

	// RVA: 0x6F7B864
	public object .ctor(object object, object method) { }

	// RVA: 0x6F7BBF8
	public virtual object Invoke(object builder) { }

}

// Namespace: 
private sealed class XdrEndChildFunction
{

	// Methods

	// RVA: 0x6F7B90C
	public object .ctor(object object, object method) { }

	// RVA: 0x6F7BC98
	public virtual object Invoke(object builder) { }

}

// Namespace: 
private sealed class XdrAttributeEntry
{

	// Fields
	internal object _Attribute; // 0x8
	internal object _SchemaFlags; // 0xC
	internal object _Datatype; // 0x10
	internal object _BuildFunc; // 0x18

	// Methods

	// RVA: 0x6F7B624
	internal object .ctor(object a, object ttype, object build) { }

	// RVA: 0x6F7B6B4
	internal object .ctor(object a, object ttype, object schemaFlags, object build) { }

}

// Namespace: 
private sealed class XdrEntry
{

	// Fields
	internal object _Name; // 0x8
	internal object _NextStates; // 0x10
	internal object _Attributes; // 0x18
	internal object _InitFunc; // 0x20
	internal object _BeginChildFunc; // 0x28
	internal object _EndChildFunc; // 0x30
	internal object _AllowText; // 0x38

	// Methods

	// RVA: 0x6F7B748
	internal object .ctor(object n, object states, object attributes, object init, object begin, object end, object fText) { }

}

// Namespace: System.Xml.Schema
internal sealed class XdrBuilder
{

	// Fields
	private static readonly object S_XDR_Root_Element; // 0x0
	private static readonly object S_XDR_Root_SubElements; // 0x8
	private static readonly object S_XDR_ElementType_SubElements; // 0x10
	private static readonly object S_XDR_AttributeType_SubElements; // 0x18
	private static readonly object S_XDR_Group_SubElements; // 0x20
	private static readonly object S_XDR_Root_Attributes; // 0x28
	private static readonly object S_XDR_ElementType_Attributes; // 0x30
	private static readonly object S_XDR_AttributeType_Attributes; // 0x38
	private static readonly object S_XDR_Element_Attributes; // 0x40
	private static readonly object S_XDR_Attribute_Attributes; // 0x48
	private static readonly object S_XDR_Group_Attributes; // 0x50
	private static readonly object S_XDR_ElementDataType_Attributes; // 0x58
	private static readonly object S_XDR_AttributeDataType_Attributes; // 0x60
	private static readonly object S_SchemaEntries; // 0x68
	private object _SchemaInfo; // 0x8
	private object _TargetNamespace; // 0x10
	private object _reader; // 0x18
	private object positionInfo; // 0x20
	private object _contentValidator; // 0x28
	private object _CurState; // 0x30
	private object _NextState; // 0x38
	private object _StateHistory; // 0x40
	private object _GroupStack; // 0x48
	private object _XdrName; // 0x50
	private object _XdrPrefix; // 0x58
	private object _ElementDef; // 0x60
	private object _GroupDef; // 0x68
	private object _AttributeDef; // 0x70
	private object _UndefinedAttributeTypes; // 0x78
	private object _BaseDecl; // 0x80
	private object _NameTable; // 0x88
	private object _SchemaNames; // 0x90
	private object _CurNsMgr; // 0x98
	private object _Text; // 0xA0
	private object validationEventHandler; // 0xA8
	private object _UndeclaredElements; // 0xB0
	private object xmlResolver; // 0xB8

	// Properties
	internal object XmlResolver { set; }

	// Methods

	// RVA: 0x6F70360
	internal object .ctor(object reader, object curmgr, object sinfo, object targetNamspace, object nameTable, object schemaNames, object eventhandler) { }

	// RVA: 0x6F70570
	internal override object ProcessElement(object prefix, object name, object ns) { }

	// RVA: 0x6F70E70
	internal override object ProcessAttribute(object prefix, object name, object ns, object value) { }

	// RVA: 0x6F71C68
	internal object set_XmlResolver(object value) { }

	// RVA: 0x6F71424
	private object LoadSchema(object uri) { }

	// RVA: 0x6F71344
	internal static object IsXdrSchema(object uri) { }

	// RVA: 0x6F71E48
	internal override object IsContentParsed() { }

	// RVA: 0x6F71E50
	internal override object ProcessMarkup(object markup) { }

	// RVA: 0x6F71EAC
	internal override object ProcessCData(object value) { }

	// RVA: 0x6F71F40
	internal override object StartChildren() { }

	// RVA: 0x6F71F7C
	internal override object EndChildren() { }

	// RVA: 0x6F70B60
	private object Push() { }

	// RVA: 0x6F72038
	private object Pop() { }

	// RVA: 0x6F720D0
	private object PushGroupInfo() { }

	// RVA: 0x6F72238
	private object PopGroupInfo() { }

	// RVA: 0x6F722D0
	private static object XDR_InitRoot(object builder, object obj) { }

	// RVA: 0x6F72340
	private static object XDR_BuildRoot_Name(object builder, object obj, object prefix) { }

	// RVA: 0x6F723E8
	private static object XDR_BuildRoot_ID(object builder, object obj, object prefix) { }

	// RVA: 0x6F723EC
	private static object XDR_BeginRoot(object builder) { }

	// RVA: 0x6F72514
	private static object XDR_EndRoot(object builder) { }

	// RVA: 0x6F72BE0
	private static object XDR_InitElementType(object builder, object obj) { }

	// RVA: 0x6F72D1C
	private static object XDR_BuildElementType_Name(object builder, object obj, object prefix) { }

	// RVA: 0x6F72F68
	private static object XDR_BuildElementType_Content(object builder, object obj, object prefix) { }

	// RVA: 0x6F7330C
	private static object XDR_BuildElementType_Model(object builder, object obj, object prefix) { }

	// RVA: 0x6F7353C
	private static object XDR_BuildElementType_Order(object builder, object obj, object prefix) { }

	// RVA: 0x6F73824
	private static object XDR_BuildElementType_DtType(object builder, object obj, object prefix) { }

	// RVA: 0x6F73AFC
	private static object XDR_BuildElementType_DtValues(object builder, object obj, object prefix) { }

	// RVA: 0x6F73C14
	private static object XDR_BuildElementType_DtMaxLength(object builder, object obj, object prefix) { }

	// RVA: 0x6F73E50
	private static object XDR_BuildElementType_DtMinLength(object builder, object obj, object prefix) { }

	// RVA: 0x6F7408C
	private static object XDR_BeginElementType(object builder) { }

	// RVA: 0x6F74450
	private static object XDR_EndElementType(object builder) { }

	// RVA: 0x6F74AAC
	private static object XDR_InitAttributeType(object builder, object obj) { }

	// RVA: 0x6F74BB4
	private static object XDR_BuildAttributeType_Name(object builder, object obj, object prefix) { }

	// RVA: 0x6F74EF0
	private static object XDR_BuildAttributeType_Required(object builder, object obj, object prefix) { }

	// RVA: 0x6F750EC
	private static object XDR_BuildAttributeType_Default(object builder, object obj, object prefix) { }

	// RVA: 0x6F75124
	private static object XDR_BuildAttributeType_DtType(object builder, object obj, object prefix) { }

	// RVA: 0x6F75430
	private static object XDR_BuildAttributeType_DtValues(object builder, object obj, object prefix) { }

	// RVA: 0x6F75548
	private static object XDR_BuildAttributeType_DtMaxLength(object builder, object obj, object prefix) { }

	// RVA: 0x6F755D8
	private static object XDR_BuildAttributeType_DtMinLength(object builder, object obj, object prefix) { }

	// RVA: 0x6F75668
	private static object XDR_BeginAttributeType(object builder) { }

	// RVA: 0x6F75748
	private static object XDR_EndAttributeType(object builder) { }

	// RVA: 0x6F75D3C
	private static object XDR_InitElement(object builder, object obj) { }

	// RVA: 0x6F75E2C
	private static object XDR_BuildElement_Type(object builder, object obj, object prefix) { }

	// RVA: 0x6F7611C
	private static object XDR_BuildElement_MinOccurs(object builder, object obj, object prefix) { }

	// RVA: 0x6F7631C
	private static object XDR_BuildElement_MaxOccurs(object builder, object obj, object prefix) { }

	// RVA: 0x6F76538
	private static object XDR_EndElement(object builder) { }

	// RVA: 0x6F766BC
	private static object XDR_InitAttribute(object builder, object obj) { }

	// RVA: 0x6F76844
	private static object XDR_BuildAttribute_Type(object builder, object obj, object prefix) { }

	// RVA: 0x6F76934
	private static object XDR_BuildAttribute_Required(object builder, object obj, object prefix) { }

	// RVA: 0x6F769FC
	private static object XDR_BuildAttribute_Default(object builder, object obj, object prefix) { }

	// RVA: 0x6F76A34
	private static object XDR_BeginAttribute(object builder) { }

	// RVA: 0x6F76E6C
	private static object XDR_EndAttribute(object builder) { }

	// RVA: 0x6F76F9C
	private static object XDR_InitGroup(object builder, object obj) { }

	// RVA: 0x6F770E0
	private static object XDR_BuildGroup_Order(object builder, object obj, object prefix) { }

	// RVA: 0x6F77244
	private static object XDR_BuildGroup_MinOccurs(object builder, object obj, object prefix) { }

	// RVA: 0x6F772F4
	private static object XDR_BuildGroup_MaxOccurs(object builder, object obj, object prefix) { }

	// RVA: 0x6F773A4
	private static object XDR_EndGroup(object builder) { }

	// RVA: 0x6F7764C
	private static object XDR_InitElementDtType(object builder, object obj) { }

	// RVA: 0x6F7778C
	private static object XDR_EndElementDtType(object builder) { }

	// RVA: 0x6F778C8
	private static object XDR_InitAttributeDtType(object builder, object obj) { }

	// RVA: 0x6F77994
	private static object XDR_EndAttributeDtType(object builder) { }

	// RVA: 0x6F70904
	private object GetNextState(object qname) { }

	// RVA: 0x6F70BC8
	private object IsSkipableElement(object qname) { }

	// RVA: 0x6F71A30
	private object IsSkipableAttribute(object qname) { }

	// RVA: 0x6F73614
	private object GetOrder(object qname) { }

	// RVA: 0x6F76040
	private object AddOrder() { }

	// RVA: 0x6F74F84
	private static object IsYes(object obj, object builder) { }

	// RVA: 0x6F761B0
	private static object ParseMinOccurs(object obj, object builder) { }

	// RVA: 0x6F763B0
	private static object ParseMaxOccurs(object obj, object builder) { }

	// RVA: 0x6F7668C
	private static object HandleMinMax(object pContent, object cMin, object cMax) { }

	// RVA: 0x6F73CA4
	private static object ParseDtMaxLength(object cVal, object obj, object builder) { }

	// RVA: 0x6F73EE0
	private static object ParseDtMinLength(object cVal, object obj, object builder) { }

	// RVA: 0x6F749E8
	private static object CompareMinMaxLength(object cMin, object cMax, object builder) { }

	// RVA: 0x6F77B20
	private static object ParseInteger(object str, object n) { }

	// RVA: 0x6F72AE8
	private object XDR_CheckAttributeDefault(object decl, object pAttdef) { }

	// RVA: 0x6F75CE8
	private object SetAttributePresence(object pAttdef, object fRequired) { }

	// RVA: 0x6F7302C
	private object GetContent(object qname) { }

	// RVA: 0x6F733D0
	private object GetModel(object qname) { }

	// RVA: 0x6F75210
	private object CheckDatatype(object str) { }

	// RVA: 0x6F75B7C
	private object CheckDefaultAttValue(object attDef) { }

	// RVA: 0x6F71338
	private object IsGlobal(object flags) { }

	// RVA: 0x6F71C70
	private object SendValidationEvent(object code, object args, object severity) { }

	// RVA: 0x6F73A0C
	private object SendValidationEvent(object code) { }

	// RVA: 0x6F70D24
	private object SendValidationEvent(object code, object msg) { }

	// RVA: 0x6F78130
	private object SendValidationEvent(object e, object severity) { }

	// RVA: 0x6F78338
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal sealed class XdrValidator
{

	// Fields
	private object validationStack; // 0x78
	private object attPresence; // 0x80
	private object name; // 0x88
	private object nsManager; // 0x90
	private object isProcessContents; // 0x98
	private object IDs; // 0xA0
	private object idRefListHead; // 0xA8
	private object inlineSchemaParser; // 0xB0

	// Properties
	private object IsInlineSchemaStarted { get; }
	private object HasSchema { get; }
	public override object PreserveWhitespace { get; }

	// Methods

	// RVA: 0x6F7BCAC
	internal object .ctor(object validator) { }

	// RVA: 0x6F7BEF8
	internal object .ctor(object reader, object schemaCollection, object eventHandling) { }

	// RVA: 0x6F7BD30
	private object Init() { }

	// RVA: 0x6F7C0E4
	public override object Validate() { }

	// RVA: 0x6F7C45C
	private object ValidateElement() { }

	// RVA: 0x6F7C954
	private object ValidateChildElement() { }

	// RVA: 0x6F7C1FC
	private object get_IsInlineSchemaStarted() { }

	// RVA: 0x6F7C20C
	private object ProcessInlineSchema() { }

	// RVA: 0x6F7CB44
	private object ProcessElement() { }

	// RVA: 0x6F7C698
	private object ValidateEndElement() { }

	// RVA: 0x6F7CC74
	private object ThoroughGetElementDecl() { }

	// RVA: 0x6F7D234
	private object ValidateStartElement() { }

	// RVA: 0x6F7D8BC
	private object ValidateEndStartElement() { }

	// RVA: 0x6F7E804
	private object LoadSchemaFromLocation(object uri) { }

	// RVA: 0x6F7E598
	private object LoadSchema(object uri) { }

	// RVA: 0x6F7EFB4
	private object get_HasSchema() { }

	// RVA: 0x6F7EFE0
	public override object get_PreserveWhitespace() { }

	// RVA: 0x6F7F030
	private object ProcessTokenizedType(object ttype, object name) { }

	// RVA: 0x6F7F460
	public override object CompleteValidation() { }

	// RVA: 0x6F7DD64
	private object CheckValue(object value, object attdef) { }

	// RVA: 0x6F77B5C
	public static object CheckDefaultValue(object value, object attdef, object sinfo, object nsManager, object NameTable, object sender, object eventhandler, object baseUri, object lineNo, object linePos) { }

	// RVA: 0x6F7F3B0
	internal object AddID(object name, object node) { }

	// RVA: 0x6F7F744
	public override object FindId(object name) { }

	// RVA: 0x6F7BF94
	private object Push(object elementName) { }

	// RVA: 0x6F7E4D8
	private object Pop() { }

	// RVA: 0x6F7F538
	private object CheckForwardRefs() { }

	// RVA: 0x6F7E754
	private object QualifiedName(object name, object ns) { }

}

// Namespace: 
private struct Union
{

	// Fields
	public object boolVal; // 0xFFFFFFFFFFFFFFF8
	public object dblVal; // 0xFFFFFFFFFFFFFFF8
	public object i64Val; // 0xFFFFFFFFFFFFFFF8
	public object i32Val; // 0xFFFFFFFFFFFFFFF8
	public object dtVal; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
private class NamespacePrefixForQName
{

	// Fields
	public object prefix; // 0x8
	public object ns; // 0x10

	// Methods

	// RVA: 0x6F7FE18
	public object .ctor(object prefix, object ns) { }

	// RVA: 0x6F81518
	public object LookupNamespace(object prefix) { }

	// RVA: 0x6F81558
	public object LookupPrefix(object namespaceName) { }

	// RVA: 0x6F81590
	public object GetNamespacesInScope(object scope) { }

}

// Namespace: System.Xml.Schema
public sealed class XmlAtomicValue
{

	// Fields
	private object xmlType; // 0x8
	private object objVal; // 0x10
	private object clrType; // 0x18
	private object unionVal; // 0x20
	private object nsPrefix; // 0x28

	// Properties
	public override object XmlType { get; }
	public override object ValueType { get; }
	public override object TypedValue { get; }
	public override object ValueAsBoolean { get; }
	public override object ValueAsDateTime { get; }
	public override object ValueAsDouble { get; }
	public override object ValueAsInt { get; }
	public override object ValueAsLong { get; }
	public override object Value { get; }

	// Methods

	// RVA: 0x6F7F7A0
	internal object .ctor(object xmlType, object value) { }

	// RVA: 0x6F7F830
	internal object .ctor(object xmlType, object value) { }

	// RVA: 0x6F7F8C0
	internal object .ctor(object xmlType, object value) { }

	// RVA: 0x6F7F950
	internal object .ctor(object xmlType, object value) { }

	// RVA: 0x6F7F9E0
	internal object .ctor(object xmlType, object value) { }

	// RVA: 0x6F7FA70
	internal object .ctor(object xmlType, object value) { }

	// RVA: 0x6F7FB18
	internal object .ctor(object xmlType, object value, object nsResolver) { }

	// RVA: 0x6F7FE50
	internal object .ctor(object xmlType, object value) { }

	// RVA: 0x6F7FEF8
	internal object .ctor(object xmlType, object value, object nsResolver) { }

	// RVA: 0x6F80118
	private object System.ICloneable.Clone() { }

	// RVA: 0x6F8011C
	public override object get_XmlType() { }

	// RVA: 0x6F80124
	public override object get_ValueType() { }

	// RVA: 0x6F80184
	public override object get_TypedValue() { }

	// RVA: 0x6F80510
	public override object get_ValueAsBoolean() { }

	// RVA: 0x6F8071C
	public override object get_ValueAsDateTime() { }

	// RVA: 0x6F8093C
	public override object get_ValueAsDouble() { }

	// RVA: 0x6F80B40
	public override object get_ValueAsInt() { }

	// RVA: 0x6F80D54
	public override object get_ValueAsLong() { }

	// RVA: 0x6F80F74
	public override object ValueAs(object type, object nsResolver) { }

	// RVA: 0x6F81218
	public override object get_Value() { }

	// RVA: 0x6F8149C
	public override object ToString() { }

	// RVA: 0x6F7FCEC
	private object GetPrefixFromQName(object value) { }

}

// Namespace: System.Xml.Schema
public class XmlSchema
{

	// Fields
	private object attributeFormDefault; // 0x2C
	private object elementFormDefault; // 0x30
	private object blockDefault; // 0x34
	private object finalDefault; // 0x38
	private object targetNs; // 0x40
	private object version; // 0x48
	private object includes; // 0x50
	private object items; // 0x58
	private object id; // 0x60
	private object moreAttributes; // 0x68
	private object isCompiled; // 0x70
	private object isCompiledBySet; // 0x71
	private object isPreprocessed; // 0x72
	private object isRedefined; // 0x73
	private object errorCount; // 0x74
	private object attributes; // 0x78
	private object attributeGroups; // 0x80
	private object elements; // 0x88
	private object types; // 0x90
	private object groups; // 0x98
	private object notations; // 0xA0
	private object identityConstraints; // 0xA8
	private static object globalIdCounter; // 0x0
	private object importedSchemas; // 0xB0
	private object importedNamespaces; // 0xB8
	private object schemaId; // 0xC0
	private object baseUri; // 0xC8
	private object isChameleon; // 0xD0
	private object ids; // 0xD8
	private object document; // 0xE0

	// Properties
	public object AttributeFormDefault { get; set; }
	public object BlockDefault { get; set; }
	public object FinalDefault { get; set; }
	public object ElementFormDefault { get; set; }
	public object TargetNamespace { get; set; }
	public object Version { get; set; }
	public object Includes { get; }
	public object Items { get; }
	internal object IsCompiledBySet { get; set; }
	internal object IsPreprocessed { get; set; }
	internal object IsRedefined { get; set; }
	public object Attributes { get; }
	public object AttributeGroups { get; }
	public object SchemaTypes { get; }
	public object Elements { get; }
	public object Id { get; set; }
	public object Groups { get; }
	public object Notations { get; }
	internal object IdentityConstraints { get; }
	internal object BaseUri { get; set; }
	internal object SchemaId { get; }
	internal object IsChameleon { get; set; }
	internal object Ids { get; }
	internal object Document { get; }
	internal object ErrorCount { get; set; }
	internal override object IdAttribute { get; set; }
	internal object ImportedSchemas { get; }
	internal object ImportedNamespaces { get; }

	// Methods

	// RVA: 0x6F81640
	public object .ctor() { }

	// RVA: 0x6F817BC
	public static object Read(object reader, object validationEventHandler) { }

	// RVA: 0x6F819AC
	internal object CompileSchema(object xsc, object resolver, object schemaInfo, object ns, object validationEventHandler, object nameTable, object CompileContentModel) { }

	// RVA: 0x6F81BD4
	internal object CompileSchemaInSet(object nameTable, object eventHandler, object compilationSettings) { }

	// RVA: 0x6F81C8C
	public object get_AttributeFormDefault() { }

	// RVA: 0x6F81C94
	public object set_AttributeFormDefault(object value) { }

	// RVA: 0x6F81C9C
	public object get_BlockDefault() { }

	// RVA: 0x6F81CA4
	public object set_BlockDefault(object value) { }

	// RVA: 0x6F81CAC
	public object get_FinalDefault() { }

	// RVA: 0x6F81CB4
	public object set_FinalDefault(object value) { }

	// RVA: 0x6F81CBC
	public object get_ElementFormDefault() { }

	// RVA: 0x6F81CC4
	public object set_ElementFormDefault(object value) { }

	// RVA: 0x6F81CCC
	public object get_TargetNamespace() { }

	// RVA: 0x6F81CD4
	public object set_TargetNamespace(object value) { }

	// RVA: 0x6F81CDC
	public object get_Version() { }

	// RVA: 0x6F81CE4
	public object set_Version(object value) { }

	// RVA: 0x6F81CEC
	public object get_Includes() { }

	// RVA: 0x6F81CF4
	public object get_Items() { }

	// RVA: 0x6F81CFC
	internal object get_IsCompiledBySet() { }

	// RVA: 0x6F81D04
	internal object set_IsCompiledBySet(object value) { }

	// RVA: 0x6F81D0C
	internal object get_IsPreprocessed() { }

	// RVA: 0x6F81D14
	internal object set_IsPreprocessed(object value) { }

	// RVA: 0x6F81D1C
	internal object get_IsRedefined() { }

	// RVA: 0x6F81D24
	internal object set_IsRedefined(object value) { }

	// RVA: 0x6F81D2C
	public object get_Attributes() { }

	// RVA: 0x6F81DA8
	public object get_AttributeGroups() { }

	// RVA: 0x6F81E24
	public object get_SchemaTypes() { }

	// RVA: 0x6F81EA0
	public object get_Elements() { }

	// RVA: 0x6F81F1C
	public object get_Id() { }

	// RVA: 0x6F81F24
	public object set_Id(object value) { }

	// RVA: 0x6F81F2C
	public object get_Groups() { }

	// RVA: 0x6F81F34
	public object get_Notations() { }

	// RVA: 0x6F81F3C
	internal object get_IdentityConstraints() { }

	// RVA: 0x6F81F44
	internal object get_BaseUri() { }

	// RVA: 0x6F81F4C
	internal object set_BaseUri(object value) { }

	// RVA: 0x6F81F54
	internal object get_SchemaId() { }

	// RVA: 0x6F81FE0
	internal object get_IsChameleon() { }

	// RVA: 0x6F81FE8
	internal object set_IsChameleon(object value) { }

	// RVA: 0x6F81FF0
	internal object get_Ids() { }

	// RVA: 0x6F81FF8
	internal object get_Document() { }

	// RVA: 0x6F82074
	internal object get_ErrorCount() { }

	// RVA: 0x6F8207C
	internal object set_ErrorCount(object value) { }

	// RVA: 0x6F82084
	internal object Clone() { }

	// RVA: 0x6F821F0
	internal object DeepClone() { }

	// RVA: 0x6F8362C
	internal override object get_IdAttribute() { }

	// RVA: 0x6F83634
	internal override object set_IdAttribute(object value) { }

	// RVA: 0x6F8363C
	internal object SetIsCompiled(object isCompiled) { }

	// RVA: 0x6F83644
	internal override object SetUnhandledAttributes(object moreAttributes) { }

	// RVA: 0x6F8364C
	internal override object AddAnnotation(object annotation) { }

	// RVA: 0x6F8366C
	internal object get_ImportedSchemas() { }

	// RVA: 0x6F836E8
	internal object get_ImportedNamespaces() { }

	// RVA: 0x6F83764
	internal object GetExternalSchemasList(object extList, object schema) { }

	// RVA: 0x6F839DC
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAll
{

	// Fields
	private object items; // 0x70

	// Properties
	public override object Items { get; }
	internal override object IsEmpty { get; }

	// Methods

	// RVA: 0x6F83A2C
	public override object get_Items() { }

	// RVA: 0x6F83A34
	internal override object get_IsEmpty() { }

	// RVA: 0x6F83A90
	internal override object SetItems(object newItems) { }

	// RVA: 0x6F83A98
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAnnotated
{

	// Fields
	private object id; // 0x30
	private object annotation; // 0x38
	private object moreAttributes; // 0x40

	// Properties
	public object Id { get; set; }
	public object Annotation { get; set; }
	public object UnhandledAttributes { get; set; }
	internal override object IdAttribute { get; set; }

	// Methods

	// RVA: 0x6F83BE8
	public object get_Id() { }

	// RVA: 0x6F83BF0
	public object set_Id(object value) { }

	// RVA: 0x6F83BF8
	public object get_Annotation() { }

	// RVA: 0x6F83C00
	public object set_Annotation(object value) { }

	// RVA: 0x6F83C08
	public object get_UnhandledAttributes() { }

	// RVA: 0x6F83C10
	public object set_UnhandledAttributes(object value) { }

	// RVA: 0x6F83C18
	internal override object get_IdAttribute() { }

	// RVA: 0x6F83C20
	internal override object set_IdAttribute(object value) { }

	// RVA: 0x6F83C28
	internal override object SetUnhandledAttributes(object moreAttributes) { }

	// RVA: 0x6F83C30
	internal override object AddAnnotation(object annotation) { }

	// RVA: 0x6F83C38
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAnnotation
{

	// Fields
	private object id; // 0x30
	private object items; // 0x38
	private object moreAttributes; // 0x40

	// Properties
	public object Id { get; set; }
	public object Items { get; }
	internal override object IdAttribute { get; set; }

	// Methods

	// RVA: 0x6F83C40
	public object get_Id() { }

	// RVA: 0x6F83C48
	public object set_Id(object value) { }

	// RVA: 0x6F83C50
	public object get_Items() { }

	// RVA: 0x6F83C58
	internal override object get_IdAttribute() { }

	// RVA: 0x6F83C60
	internal override object set_IdAttribute(object value) { }

	// RVA: 0x6F83C68
	internal override object SetUnhandledAttributes(object moreAttributes) { }

	// RVA: 0x6F83C70
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAny
{

	// Fields
	private object ns; // 0x70
	private object processContents; // 0x78
	private object namespaceList; // 0x80

	// Properties
	public object Namespace { get; set; }
	public object ProcessContents { set; }
	internal object NamespaceList { get; }
	internal object ResolvedNamespace { get; }
	internal object ProcessContentsCorrect { get; }
	internal override object NameString { get; }

	// Methods

	// RVA: 0x6F83CDC
	public object get_Namespace() { }

	// RVA: 0x6F83CE4
	public object set_Namespace(object value) { }

	// RVA: 0x6F83CEC
	public object set_ProcessContents(object value) { }

	// RVA: 0x6F83CF4
	internal object get_NamespaceList() { }

	// RVA: 0x6F83CFC
	internal object get_ResolvedNamespace() { }

	// RVA: 0x6F83D58
	internal object get_ProcessContentsCorrect() { }

	// RVA: 0x6F83D6C
	internal override object get_NameString() { }

	// RVA: 0x6F8433C
	internal object BuildNamespaceList(object targetNamespace) { }

	// RVA: 0x6F843D0
	internal object BuildNamespaceListV1Compat(object targetNamespace) { }

	// RVA: 0x6F84484
	internal object Allows(object qname) { }

	// RVA: 0x6F844E8
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAnyAttribute
{

	// Fields
	private object ns; // 0x48
	private object processContents; // 0x50
	private object namespaceList; // 0x58

	// Properties
	public object Namespace { set; }
	public object ProcessContents { get; set; }
	internal object NamespaceList { get; }
	internal object ProcessContentsCorrect { get; }

	// Methods

	// RVA: 0x6F84570
	public object set_Namespace(object value) { }

	// RVA: 0x6F84578
	public object get_ProcessContents() { }

	// RVA: 0x6F84580
	public object set_ProcessContents(object value) { }

	// RVA: 0x6F84588
	internal object get_NamespaceList() { }

	// RVA: 0x6F84590
	internal object get_ProcessContentsCorrect() { }

	// RVA: 0x6F845A4
	internal object BuildNamespaceList(object targetNamespace) { }

	// RVA: 0x6F84638
	internal object BuildNamespaceListV1Compat(object targetNamespace) { }

	// RVA: 0x6F846EC
	internal object Allows(object qname) { }

	// RVA: 0x6F84750
	internal static object IsSubset(object sub, object super) { }

	// RVA: 0x6F8478C
	internal static object Intersection(object o1, object o2, object v1Compat) { }

	// RVA: 0x6F84860
	internal static object Union(object o1, object o2, object v1Compat) { }

	// RVA: 0x6F84858
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAppInfo
{

	// Fields
	private object source; // 0x30
	private object markup; // 0x38

	// Properties
	public object Source { set; }
	public object Markup { get; set; }

	// Methods

	// RVA: 0x6F8492C
	public object set_Source(object value) { }

	// RVA: 0x6F84934
	public object get_Markup() { }

	// RVA: 0x6F8493C
	public object set_Markup(object value) { }

	// RVA: 0x6F84944
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAttribute
{

	// Fields
	private object defaultValue; // 0x48
	private object fixedValue; // 0x50
	private object name; // 0x58
	private object form; // 0x60
	private object use; // 0x64
	private object refName; // 0x68
	private object typeName; // 0x70
	private object qualifiedName; // 0x78
	private object type; // 0x80
	private object attributeType; // 0x88
	private object attDef; // 0x90

	// Properties
	public object DefaultValue { get; set; }
	public object FixedValue { get; set; }
	public object Form { get; set; }
	public object Name { get; set; }
	public object RefName { get; set; }
	public object SchemaTypeName { get; set; }
	public object SchemaType { get; set; }
	public object Use { get; set; }
	public object QualifiedName { get; }
	public object AttributeSchemaType { get; }
	internal object Datatype { get; }
	internal object AttDef { get; set; }
	internal override object NameAttribute { get; set; }

	// Methods

	// RVA: 0x6F8494C
	public object get_DefaultValue() { }

	// RVA: 0x6F84954
	public object set_DefaultValue(object value) { }

	// RVA: 0x6F8495C
	public object get_FixedValue() { }

	// RVA: 0x6F84964
	public object set_FixedValue(object value) { }

	// RVA: 0x6F8496C
	public object get_Form() { }

	// RVA: 0x6F84974
	public object set_Form(object value) { }

	// RVA: 0x6F8497C
	public object get_Name() { }

	// RVA: 0x6F84984
	public object set_Name(object value) { }

	// RVA: 0x6F8498C
	public object get_RefName() { }

	// RVA: 0x6F84994
	public object set_RefName(object value) { }

	// RVA: 0x6F84A6C
	public object get_SchemaTypeName() { }

	// RVA: 0x6F84A74
	public object set_SchemaTypeName(object value) { }

	// RVA: 0x6F84B4C
	public object get_SchemaType() { }

	// RVA: 0x6F84B54
	public object set_SchemaType(object value) { }

	// RVA: 0x6F84B5C
	public object get_Use() { }

	// RVA: 0x6F84B64
	public object set_Use(object value) { }

	// RVA: 0x6F84B6C
	public object get_QualifiedName() { }

	// RVA: 0x6F84B74
	public object get_AttributeSchemaType() { }

	// RVA: 0x6F84B7C
	internal object get_Datatype() { }

	// RVA: 0x6F84B94
	internal object SetQualifiedName(object value) { }

	// RVA: 0x6F84B9C
	internal object SetAttributeType(object value) { }

	// RVA: 0x6F84BA4
	internal object get_AttDef() { }

	// RVA: 0x6F84BAC
	internal object set_AttDef(object value) { }

	// RVA: 0x6F84BB4
	internal override object get_NameAttribute() { }

	// RVA: 0x6F84BBC
	internal override object set_NameAttribute(object value) { }

	// RVA: 0x6F84BC4
	internal override object Clone() { }

	// RVA: 0x6F84CD0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAttributeGroup
{

	// Fields
	private object name; // 0x48
	private object attributes; // 0x50
	private object anyAttribute; // 0x58
	private object qname; // 0x60
	private object redefined; // 0x68
	private object attributeUses; // 0x70
	private object attributeWildcard; // 0x78
	private object selfReferenceCount; // 0x80

	// Properties
	public object Name { get; set; }
	public object Attributes { get; }
	public object AnyAttribute { get; set; }
	public object QualifiedName { get; }
	internal object AttributeUses { get; }
	internal object AttributeWildcard { get; set; }
	public object RedefinedAttributeGroup { get; }
	internal object Redefined { get; set; }
	internal object SelfReferenceCount { get; set; }
	internal override object NameAttribute { get; set; }

	// Methods

	// RVA: 0x6F84D48
	public object get_Name() { }

	// RVA: 0x6F84D50
	public object set_Name(object value) { }

	// RVA: 0x6F84D58
	public object get_Attributes() { }

	// RVA: 0x6F84D60
	public object get_AnyAttribute() { }

	// RVA: 0x6F84D68
	public object set_AnyAttribute(object value) { }

	// RVA: 0x6F84D70
	public object get_QualifiedName() { }

	// RVA: 0x6F84D78
	internal object get_AttributeUses() { }

	// RVA: 0x6F84DF4
	internal object get_AttributeWildcard() { }

	// RVA: 0x6F84DFC
	internal object set_AttributeWildcard(object value) { }

	// RVA: 0x6F84E04
	public object get_RedefinedAttributeGroup() { }

	// RVA: 0x6F84E0C
	internal object get_Redefined() { }

	// RVA: 0x6F84E14
	internal object set_Redefined(object value) { }

	// RVA: 0x6F84E1C
	internal object get_SelfReferenceCount() { }

	// RVA: 0x6F84E24
	internal object set_SelfReferenceCount(object value) { }

	// RVA: 0x6F84E2C
	internal override object get_NameAttribute() { }

	// RVA: 0x6F84E34
	internal override object set_NameAttribute(object value) { }

	// RVA: 0x6F84E3C
	internal object SetQualifiedName(object value) { }

	// RVA: 0x6F84E44
	internal override object Clone() { }

	// RVA: 0x6F854F0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaAttributeGroupRef
{

	// Fields
	private object refName; // 0x48

	// Properties
	public object RefName { get; set; }

	// Methods

	// RVA: 0x6F85590
	public object get_RefName() { }

	// RVA: 0x6F85598
	public object set_RefName(object value) { }

	// RVA: 0x6F85670
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaChoice
{

	// Fields
	private object items; // 0x70

	// Properties
	public override object Items { get; }
	internal override object IsEmpty { get; }

	// Methods

	// RVA: 0x6F856E4
	public override object get_Items() { }

	// RVA: 0x6F856EC
	internal override object get_IsEmpty() { }

	// RVA: 0x6F856F4
	internal override object SetItems(object newItems) { }

	// RVA: 0x6F856FC
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public sealed class XmlSchemaCollection
{

	// Fields
	private object collection; // 0x8
	private object nameTable; // 0x10
	private object schemaNames; // 0x18
	private object wLock; // 0x20
	private object timeout; // 0x28
	private object isThreadSafe; // 0x2C
	private object validationEventHandler; // 0x30
	private object xmlResolver; // 0x38

	// Properties
	public object Count { get; }
	public object NameTable { get; }
	internal object XmlResolver { set; }
	public object Item { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	private object System.Collections.ICollection.Count { get; }
	internal object EventHandler { get; set; }

	// Methods

	// RVA: 0x6F857C4
	public object .ctor(object nametable) { }

	// RVA: 0x6F858E0
	public object get_Count() { }

	// RVA: 0x6F85930
	public object get_NameTable() { }

	// RVA: 0x6F85938
	internal object set_XmlResolver(object value) { }

	// RVA: 0x6F85940
	public object get_Item(object ns) { }

	// RVA: 0x6F85A1C
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x6F85B24
	public object GetEnumerator() { }

	// RVA: 0x6F85BC8
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x6F85F70
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x6F85F78
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x6F85F7C
	private object System.Collections.ICollection.get_Count() { }

	// RVA: 0x6F7EED8
	internal object GetSchemaInfo(object ns) { }

	// RVA: 0x6F85FCC
	internal object GetSchemaNames(object nt) { }

	// RVA: 0x6F7CC6C
	internal object Add(object ns, object schemaInfo, object schema, object compile) { }

	// RVA: 0x6F8607C
	private object Add(object ns, object schemaInfo, object schema, object compile, object resolver) { }

	// RVA: 0x6F86214
	private object Add(object ns, object node) { }

	// RVA: 0x6F86458
	internal object get_EventHandler() { }

	// RVA: 0x6F86460
	internal object set_EventHandler(object value) { }

}

// Namespace: System.Xml.Schema
internal sealed class XmlSchemaCollectionNode
{

	// Fields
	private object namespaceUri; // 0x8
	private object schemaInfo; // 0x10
	private object schema; // 0x18

	// Properties
	internal object NamespaceURI { set; }
	internal object SchemaInfo { get; set; }
	internal object Schema { get; set; }

	// Methods

	// RVA: 0x6F86468
	internal object set_NamespaceURI(object value) { }

	// RVA: 0x6F86470
	internal object get_SchemaInfo() { }

	// RVA: 0x6F86478
	internal object set_SchemaInfo(object value) { }

	// RVA: 0x6F86480
	internal object get_Schema() { }

	// RVA: 0x6F86488
	internal object set_Schema(object value) { }

	// RVA: 0x6F8620C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public sealed class XmlSchemaCollectionEnumerator
{

	// Fields
	private object enumerator; // 0x8

	// Properties
	private object System.Collections.IEnumerator.Current { get; }
	public object Current { get; }
	internal object CurrentNode { get; }

	// Methods

	// RVA: 0x6F85AC0
	internal object .ctor(object collection) { }

	// RVA: 0x6F86490
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6F86574
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x6F85E90
	public object MoveNext() { }

	// RVA: 0x6F86654
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x6F85D70
	public object get_Current() { }

	// RVA: 0x6F86658
	internal object get_CurrentNode() { }

}

// Namespace: System.Xml.Schema
public sealed class XmlSchemaCompilationSettings
{

	// Fields
	private object enableUpaCheck; // 0x8

	// Properties
	public object EnableUpaCheck { get; }

	// Methods

	// RVA: 0x6F86768
	public object .ctor() { }

	// RVA: 0x6F86794
	public object get_EnableUpaCheck() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaComplexContent
{

	// Fields
	private object content; // 0x48
	private object isMixed; // 0x50
	private object hasMixedAttribute; // 0x51

	// Properties
	public object IsMixed { get; set; }
	public override object Content { get; set; }
	internal object HasMixedAttribute { get; }

	// Methods

	// RVA: 0x6F8679C
	public object get_IsMixed() { }

	// RVA: 0x6F867A4
	public object set_IsMixed(object value) { }

	// RVA: 0x6F867B4
	public override object get_Content() { }

	// RVA: 0x6F867BC
	public override object set_Content(object value) { }

	// RVA: 0x6F867C4
	internal object get_HasMixedAttribute() { }

	// RVA: 0x6F867CC
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaComplexContentExtension
{

	// Fields
	private object particle; // 0x48
	private object attributes; // 0x50
	private object anyAttribute; // 0x58
	private object baseTypeName; // 0x60

	// Properties
	public object BaseTypeName { get; set; }
	public object Particle { get; set; }
	public object Attributes { get; }
	public object AnyAttribute { get; set; }

	// Methods

	// RVA: 0x6F867DC
	public object get_BaseTypeName() { }

	// RVA: 0x6F867E4
	public object set_BaseTypeName(object value) { }

	// RVA: 0x6F868BC
	public object get_Particle() { }

	// RVA: 0x6F868C4
	public object set_Particle(object value) { }

	// RVA: 0x6F868CC
	public object get_Attributes() { }

	// RVA: 0x6F868D4
	public object get_AnyAttribute() { }

	// RVA: 0x6F868DC
	public object set_AnyAttribute(object value) { }

	// RVA: 0x6F868E4
	internal object SetAttributes(object newAttributes) { }

	// RVA: 0x6F868EC
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaComplexContentRestriction
{

	// Fields
	private object particle; // 0x48
	private object attributes; // 0x50
	private object anyAttribute; // 0x58
	private object baseTypeName; // 0x60

	// Properties
	public object BaseTypeName { get; set; }
	public object Particle { get; set; }
	public object Attributes { get; }
	public object AnyAttribute { get; set; }

	// Methods

	// RVA: 0x6F86994
	public object get_BaseTypeName() { }

	// RVA: 0x6F8699C
	public object set_BaseTypeName(object value) { }

	// RVA: 0x6F86A74
	public object get_Particle() { }

	// RVA: 0x6F86A7C
	public object set_Particle(object value) { }

	// RVA: 0x6F86A84
	public object get_Attributes() { }

	// RVA: 0x6F86A8C
	public object get_AnyAttribute() { }

	// RVA: 0x6F86A94
	public object set_AnyAttribute(object value) { }

	// RVA: 0x6F86A9C
	internal object SetAttributes(object newAttributes) { }

	// RVA: 0x6F86AA4
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaComplexType
{

	// Fields
	private object block; // 0x8C
	private object contentModel; // 0x90
	private object particle; // 0x98
	private object attributes; // 0xA0
	private object anyAttribute; // 0xA8
	private object contentTypeParticle; // 0xB0
	private object blockResolved; // 0xB8
	private object localElements; // 0xC0
	private object attributeUses; // 0xC8
	private object attributeWildcard; // 0xD0
	private static object anyTypeLax; // 0x0
	private static object anyTypeSkip; // 0x8
	private static object untypedAnyType; // 0x10
	private object pvFlags; // 0xD8

	// Properties
	internal static object AnyType { get; }
	internal static object UntypedAnyType { get; }
	internal static object AnyTypeContentValidator { get; }
	public object IsAbstract { get; set; }
	public object Block { get; set; }
	public override object IsMixed { get; set; }
	public object ContentModel { get; set; }
	public object Particle { get; set; }
	public object Attributes { get; }
	public object AnyAttribute { get; set; }
	public object ContentType { get; }
	public object ContentTypeParticle { get; }
	public object BlockResolved { get; }
	public object AttributeUses { get; }
	public object AttributeWildcard { get; }
	internal object LocalElements { get; }
	internal object HasWildCard { set; }

	// Methods

	// RVA: 0x6F86B44
	private static object .cctor() { }

	// RVA: 0x6F86E54
	private static object CreateAnyType(object processContents) { }

	// RVA: 0x6F87354
	public object .ctor() { }

	// RVA: 0x6F87470
	internal static object get_AnyType() { }

	// RVA: 0x6F874EC
	internal static object get_UntypedAnyType() { }

	// RVA: 0x6F873D0
	internal static object get_AnyTypeContentValidator() { }

	// RVA: 0x6F87568
	public object get_IsAbstract() { }

	// RVA: 0x6F87574
	public object set_IsAbstract(object value) { }

	// RVA: 0x6F87594
	public object get_Block() { }

	// RVA: 0x6F8759C
	public object set_Block(object value) { }

	// RVA: 0x6F875A4
	public override object get_IsMixed() { }

	// RVA: 0x6F875B0
	public override object set_IsMixed(object value) { }

	// RVA: 0x6F875D0
	public object get_ContentModel() { }

	// RVA: 0x6F875D8
	public object set_ContentModel(object value) { }

	// RVA: 0x6F875E0
	public object get_Particle() { }

	// RVA: 0x6F875E8
	public object set_Particle(object value) { }

	// RVA: 0x6F875F0
	public object get_Attributes() { }

	// RVA: 0x6F8766C
	public object get_AnyAttribute() { }

	// RVA: 0x6F87674
	public object set_AnyAttribute(object value) { }

	// RVA: 0x6F8767C
	public object get_ContentType() { }

	// RVA: 0x6F87684
	public object get_ContentTypeParticle() { }

	// RVA: 0x6F8768C
	public object get_BlockResolved() { }

	// RVA: 0x6F87694
	public object get_AttributeUses() { }

	// RVA: 0x6F87710
	public object get_AttributeWildcard() { }

	// RVA: 0x6F87718
	internal object get_LocalElements() { }

	// RVA: 0x6F87794
	internal object SetContentTypeParticle(object value) { }

	// RVA: 0x6F8779C
	internal object SetBlockResolved(object value) { }

	// RVA: 0x6F877A4
	internal object SetAttributeWildcard(object value) { }

	// RVA: 0x6F877AC
	internal object set_HasWildCard(object value) { }

	// RVA: 0x6F877C0
	internal object SetAttributes(object newAttributes) { }

	// RVA: 0x6F877C8
	internal object ContainsIdAttribute(object findAll) { }

	// RVA: 0x6F87E00
	internal override object Clone() { }

	// RVA: 0x6F82680
	internal object Clone(object parentSchema) { }

	// RVA: 0x6F884E8
	private object ClearCompiledState() { }

	// RVA: 0x6F85124
	internal static object CloneAttributes(object attributes) { }

	// RVA: 0x6F8861C
	private static object CloneGroupBaseParticles(object groupBaseParticles, object parentSchema) { }

	// RVA: 0x6F880FC
	internal static object CloneParticle(object particle, object parentSchema) { }

	// RVA: 0x6F8890C
	private static object GetResolvedElementForm(object parentSchema, object element) { }

	// RVA: 0x6F87E08
	internal static object HasParticleRef(object particle, object parentSchema) { }

	// RVA: 0x6F84F64
	internal static object HasAttributeQNameRef(object attributes) { }

}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaContent
{

	// Methods

	// RVA: 0x6F8698C
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaContentModel
{

	// Properties
	public abstract object Content { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_Content() { }

	// RVA: -1
	public abstract object set_Content(object value) { }

	// RVA: 0x6F867D4
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
public enum XmlSchemaContentProcessing
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Skip;
	public const object Lax;
	public const object Strict;
}

// Namespace: System.Xml.Schema
public enum XmlSchemaContentType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TextOnly;
	public const object Empty;
	public const object ElementOnly;
	public const object Mixed;
}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaDatatype
{

	// Properties
	public abstract object ValueType { get; }
	public abstract object TokenizedType { get; }
	public virtual object Variety { get; }
	public virtual object TypeCode { get; }
	internal abstract object HasLexicalFacets { get; }
	internal abstract object HasValueFacets { get; }
	internal abstract object ValueConverter { get; }
	internal abstract object Restriction { get; }
	internal abstract object FacetsChecker { get; }
	internal abstract object BuiltInWhitespaceFacet { get; }
	internal object TypeCodeString { get; }

	// Methods

	// RVA: -1
	public abstract object get_ValueType() { }

	// RVA: -1
	public abstract object get_TokenizedType() { }

	// RVA: -1
	public abstract object ParseValue(object s, object nameTable, object nsmgr) { }

	// RVA: 0x6F8893C
	public virtual object get_Variety() { }

	// RVA: 0x6F88944
	public virtual object get_TypeCode() { }

	// RVA: 0x6F8894C
	public virtual object IsDerivedFrom(object datatype) { }

	// RVA: -1
	internal abstract object get_HasLexicalFacets() { }

	// RVA: -1
	internal abstract object get_HasValueFacets() { }

	// RVA: -1
	internal abstract object get_ValueConverter() { }

	// RVA: -1
	internal abstract object get_Restriction() { }

	// RVA: -1
	internal abstract object Compare(object value1, object value2) { }

	// RVA: -1
	internal abstract object ParseValue(object s, object nameTable, object nsmgr, object createAtomicValue) { }

	// RVA: -1
	internal abstract object TryParseValue(object s, object nameTable, object nsmgr, object typedValue) { }

	// RVA: -1
	internal abstract object TryParseValue(object value, object nameTable, object namespaceResolver, object typedValue) { }

	// RVA: -1
	internal abstract object get_FacetsChecker() { }

	// RVA: -1
	internal abstract object get_BuiltInWhitespaceFacet() { }

	// RVA: -1
	internal abstract object DeriveByRestriction(object facets, object nameTable, object schemaType) { }

	// RVA: -1
	internal abstract object DeriveByList(object schemaType) { }

	// RVA: -1
	internal abstract object VerifySchemaValid(object notations, object caller) { }

	// RVA: -1
	internal abstract object IsEqual(object o1, object o2) { }

	// RVA: -1
	internal abstract object IsComparable(object dtype) { }

	// RVA: 0x6F88954
	internal object get_TypeCodeString() { }

	// RVA: 0x6F88AB4
	internal object TypeCodeToString(object typeCode) { }

	// RVA: 0x6F89228
	internal static object ConcatenatedToString(object value) { }

	// RVA: 0x6F75AF4
	internal static object FromXmlTokenizedType(object token) { }

	// RVA: 0x6F89A94
	internal static object FromXmlTokenizedTypeXsd(object token) { }

	// RVA: 0x6F73A74
	internal static object FromXdrName(object name) { }

	// RVA: 0x6F89B1C
	internal static object DeriveByUnion(object types, object schemaType) { }

	// RVA: 0x6F706FC
	internal static object XdrCanonizeUri(object uri, object nameTable, object schemaNames) { }

	// RVA: 0x6F89B88
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
public enum XmlSchemaDerivationMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Empty;
	public const object Substitution;
	public const object Extension;
	public const object Restriction;
	public const object List;
	public const object Union;
	public const object All;
	public const object None;
}

// Namespace: System.Xml.Schema
public class XmlSchemaDocumentation
{

	// Fields
	private object source; // 0x30
	private object language; // 0x38
	private object markup; // 0x40
	private static object languageType; // 0x0

	// Properties
	public object Source { set; }
	public object Language { set; }
	public object Markup { set; }

	// Methods

	// RVA: 0x6F89B90
	public object set_Source(object value) { }

	// RVA: 0x6F89B98
	public object set_Language(object value) { }

	// RVA: 0x6F89CC0
	public object set_Markup(object value) { }

	// RVA: 0x6F89CC8
	public object .ctor() { }

	// RVA: 0x6F89CD0
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaElement
{

	// Fields
	private object isAbstract; // 0x6C
	private object hasAbstractAttribute; // 0x6D
	private object isNillable; // 0x6E
	private object hasNillableAttribute; // 0x6F
	private object isLocalTypeDerivationChecked; // 0x70
	private object block; // 0x74
	private object final; // 0x78
	private object form; // 0x7C
	private object defaultValue; // 0x80
	private object fixedValue; // 0x88
	private object name; // 0x90
	private object refName; // 0x98
	private object substitutionGroup; // 0xA0
	private object typeName; // 0xA8
	private object type; // 0xB0
	private object qualifiedName; // 0xB8
	private object elementType; // 0xC0
	private object blockResolved; // 0xC8
	private object finalResolved; // 0xCC
	private object constraints; // 0xD0
	private object elementDecl; // 0xD8

	// Properties
	public object IsAbstract { get; set; }
	public object Block { get; set; }
	public object DefaultValue { get; set; }
	public object Final { get; set; }
	public object FixedValue { get; set; }
	public object Form { get; set; }
	public object Name { get; set; }
	public object IsNillable { get; set; }
	internal object HasNillableAttribute { get; }
	internal object HasAbstractAttribute { get; }
	public object RefName { get; set; }
	public object SubstitutionGroup { get; set; }
	public object SchemaTypeName { get; set; }
	public object SchemaType { get; set; }
	public object Constraints { get; }
	public object QualifiedName { get; }
	public object ElementSchemaType { get; }
	public object BlockResolved { get; }
	public object FinalResolved { get; }
	internal object HasConstraints { get; }
	internal object IsLocalTypeDerivationChecked { get; set; }
	internal object ElementDecl { get; set; }
	internal override object NameAttribute { get; set; }
	internal override object NameString { get; }

	// Methods

	// RVA: 0x6F89DB4
	public object get_IsAbstract() { }

	// RVA: 0x6F89DBC
	public object set_IsAbstract(object value) { }

	// RVA: 0x6F89DCC
	public object get_Block() { }

	// RVA: 0x6F89DD4
	public object set_Block(object value) { }

	// RVA: 0x6F89DDC
	public object get_DefaultValue() { }

	// RVA: 0x6F89DE4
	public object set_DefaultValue(object value) { }

	// RVA: 0x6F89DEC
	public object get_Final() { }

	// RVA: 0x6F89DF4
	public object set_Final(object value) { }

	// RVA: 0x6F89DFC
	public object get_FixedValue() { }

	// RVA: 0x6F89E04
	public object set_FixedValue(object value) { }

	// RVA: 0x6F89E0C
	public object get_Form() { }

	// RVA: 0x6F89E14
	public object set_Form(object value) { }

	// RVA: 0x6F89E1C
	public object get_Name() { }

	// RVA: 0x6F89E24
	public object set_Name(object value) { }

	// RVA: 0x6F89E2C
	public object get_IsNillable() { }

	// RVA: 0x6F89E34
	public object set_IsNillable(object value) { }

	// RVA: 0x6F89E44
	internal object get_HasNillableAttribute() { }

	// RVA: 0x6F89E4C
	internal object get_HasAbstractAttribute() { }

	// RVA: 0x6F89E54
	public object get_RefName() { }

	// RVA: 0x6F89E5C
	public object set_RefName(object value) { }

	// RVA: 0x6F89F34
	public object get_SubstitutionGroup() { }

	// RVA: 0x6F89F3C
	public object set_SubstitutionGroup(object value) { }

	// RVA: 0x6F8A014
	public object get_SchemaTypeName() { }

	// RVA: 0x6F8A01C
	public object set_SchemaTypeName(object value) { }

	// RVA: 0x6F8A0F4
	public object get_SchemaType() { }

	// RVA: 0x6F8A0FC
	public object set_SchemaType(object value) { }

	// RVA: 0x6F8A104
	public object get_Constraints() { }

	// RVA: 0x6F8A180
	public object get_QualifiedName() { }

	// RVA: 0x6F8A188
	public object get_ElementSchemaType() { }

	// RVA: 0x6F8A190
	public object get_BlockResolved() { }

	// RVA: 0x6F8A198
	public object get_FinalResolved() { }

	// RVA: 0x6F8A1A0
	internal object SetQualifiedName(object value) { }

	// RVA: 0x6F8A1A8
	internal object SetElementType(object value) { }

	// RVA: 0x6F8A1B0
	internal object SetBlockResolved(object value) { }

	// RVA: 0x6F8A1B8
	internal object SetFinalResolved(object value) { }

	// RVA: 0x6F8A1C0
	internal object get_HasConstraints() { }

	// RVA: 0x6F8A1E8
	internal object get_IsLocalTypeDerivationChecked() { }

	// RVA: 0x6F8A1F0
	internal object set_IsLocalTypeDerivationChecked(object value) { }

	// RVA: 0x6F8A1F8
	internal object get_ElementDecl() { }

	// RVA: 0x6F8A200
	internal object set_ElementDecl(object value) { }

	// RVA: 0x6F8A208
	internal override object get_NameAttribute() { }

	// RVA: 0x6F8A210
	internal override object set_NameAttribute(object value) { }

	// RVA: 0x6F8A218
	internal override object get_NameString() { }

	// RVA: 0x6F8A264
	internal override object Clone() { }

	// RVA: 0x6F83120
	internal object Clone(object parentSchema) { }

	// RVA: 0x6F8A26C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaException
{

	// Fields
	private object res; // 0x88
	private object args; // 0x90
	private object sourceUri; // 0x98
	private object lineNumber; // 0xA0
	private object linePosition; // 0xA4
	private object sourceSchemaObject; // 0xA8
	private object message; // 0xB0

	// Properties
	internal object GetRes { get; }
	internal object Args { get; }
	public object SourceUri { get; }
	public object LineNumber { get; }
	public object LinePosition { get; }
	public object SourceSchemaObject { get; }
	public override object Message { get; }

	// Methods

	// RVA: 0x6F8A32C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6F8A7DC
	public override object GetObjectData(object info, object context) { }

	// RVA: 0x6F8A958
	public object .ctor() { }

	// RVA: 0x6F8A96C
	public object .ctor(object message) { }

	// RVA: 0x6F8AA94
	public object .ctor(object message, object innerException) { }

	// RVA: 0x6F8A97C
	public object .ctor(object message, object innerException, object lineNumber, object linePosition) { }

	// RVA: 0x6F8AB2C
	internal object .ctor(object res, object args) { }

	// RVA: 0x6F7F680
	internal object .ctor(object res, object arg) { }

	// RVA: 0x6F7825C
	internal object .ctor(object res, object arg, object sourceUri, object lineNumber, object linePosition) { }

	// RVA: 0x6F8AB90
	internal object .ctor(object res, object sourceUri, object lineNumber, object linePosition) { }

	// RVA: 0x6F780B4
	internal object .ctor(object res, object args, object sourceUri, object lineNumber, object linePosition) { }

	// RVA: 0x6F8AC08
	internal object .ctor(object res, object source) { }

	// RVA: 0x6F8AD24
	internal object .ctor(object res, object arg, object source) { }

	// RVA: 0x6F8AC90
	internal object .ctor(object res, object args, object source) { }

	// RVA: 0x6F8AAA0
	internal object .ctor(object res, object args, object innerException, object sourceUri, object lineNumber, object linePosition, object source) { }

	// RVA: 0x6F8A710
	internal static object CreateMessage(object res, object args) { }

	// RVA: 0x6F8AE04
	internal object get_GetRes() { }

	// RVA: 0x6F8AE0C
	internal object get_Args() { }

	// RVA: 0x6F8AE14
	public object get_SourceUri() { }

	// RVA: 0x6F8AE1C
	public object get_LineNumber() { }

	// RVA: 0x6F8AE24
	public object get_LinePosition() { }

	// RVA: 0x6F8AE2C
	public object get_SourceSchemaObject() { }

	// RVA: 0x6F7E7F8
	internal object SetSource(object sourceUri, object lineNumber, object linePosition) { }

	// RVA: 0x6F8AE34
	internal object SetSchemaObject(object source) { }

	// RVA: 0x6F8AE3C
	internal object SetSource(object source) { }

	// RVA: 0x6F8AE6C
	public override object get_Message() { }

}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaExternal
{

	// Fields
	private object location; // 0x30
	private object baseUri; // 0x38
	private object schema; // 0x40
	private object id; // 0x48
	private object moreAttributes; // 0x50
	private object compositor; // 0x58

	// Properties
	public object SchemaLocation { get; set; }
	public object Schema { get; set; }
	public object Id { get; set; }
	internal object BaseUri { get; set; }
	internal override object IdAttribute { get; set; }
	internal object Compositor { get; set; }

	// Methods

	// RVA: 0x6F8AE84
	public object get_SchemaLocation() { }

	// RVA: 0x6F8AE8C
	public object set_SchemaLocation(object value) { }

	// RVA: 0x6F8AE94
	public object get_Schema() { }

	// RVA: 0x6F8AE9C
	public object set_Schema(object value) { }

	// RVA: 0x6F8AEA4
	public object get_Id() { }

	// RVA: 0x6F8AEAC
	public object set_Id(object value) { }

	// RVA: 0x6F8AEB4
	internal object get_BaseUri() { }

	// RVA: 0x6F8AEBC
	internal object set_BaseUri(object value) { }

	// RVA: 0x6F8AEC4
	internal override object get_IdAttribute() { }

	// RVA: 0x6F8AECC
	internal override object set_IdAttribute(object value) { }

	// RVA: 0x6F8AED4
	internal override object SetUnhandledAttributes(object moreAttributes) { }

	// RVA: 0x6F8AEDC
	internal object get_Compositor() { }

	// RVA: 0x6F8AEE4
	internal object set_Compositor(object value) { }

	// RVA: 0x6F8AEEC
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
internal enum FacetType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Length;
	public const object MinLength;
	public const object MaxLength;
	public const object Pattern;
	public const object Whitespace;
	public const object Enumeration;
	public const object MinExclusive;
	public const object MinInclusive;
	public const object MaxExclusive;
	public const object MaxInclusive;
	public const object TotalDigits;
	public const object FractionDigits;
}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaFacet
{

	// Fields
	private object value; // 0x48
	private object isFixed; // 0x50
	private object facetType; // 0x54

	// Properties
	public object Value { get; set; }
	public virtual object IsFixed { get; set; }
	internal object FacetType { get; set; }

	// Methods

	// RVA: 0x6F8AEF4
	public object get_Value() { }

	// RVA: 0x6F8AEFC
	public object set_Value(object value) { }

	// RVA: 0x6F8AF04
	public virtual object get_IsFixed() { }

	// RVA: 0x6F8AF0C
	public virtual object set_IsFixed(object value) { }

	// RVA: 0x6F8AFC8
	internal object get_FacetType() { }

	// RVA: 0x6F8AFD0
	internal object set_FacetType(object value) { }

	// RVA: 0x6F8AFD8
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaNumericFacet
{

	// Methods

	// RVA: 0x6F8AFE0
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaLengthFacet
{

	// Methods

	// RVA: 0x6F8AFE8
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaMinLengthFacet
{

	// Methods

	// RVA: 0x6F8B014
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaMaxLengthFacet
{

	// Methods

	// RVA: 0x6F8B040
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaPatternFacet
{

	// Methods

	// RVA: 0x6F8B06C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaEnumerationFacet
{

	// Methods

	// RVA: 0x6F8B098
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaMinExclusiveFacet
{

	// Methods

	// RVA: 0x6F8B0C4
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaMinInclusiveFacet
{

	// Methods

	// RVA: 0x6F8B0F0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaMaxExclusiveFacet
{

	// Methods

	// RVA: 0x6F8B11C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaMaxInclusiveFacet
{

	// Methods

	// RVA: 0x6F8B148
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaTotalDigitsFacet
{

	// Methods

	// RVA: 0x6F8B174
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaFractionDigitsFacet
{

	// Methods

	// RVA: 0x6F8B1A0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaWhiteSpaceFacet
{

	// Methods

	// RVA: 0x6F8B1CC
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public enum XmlSchemaForm
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Qualified;
	public const object Unqualified;
}

// Namespace: System.Xml.Schema
public class XmlSchemaGroup
{

	// Fields
	private object name; // 0x48
	private object particle; // 0x50
	private object canonicalParticle; // 0x58
	private object qname; // 0x60
	private object redefined; // 0x68
	private object selfReferenceCount; // 0x70

	// Properties
	public object Name { get; set; }
	public object Particle { get; set; }
	public object QualifiedName { get; }
	internal object CanonicalParticle { get; set; }
	internal object Redefined { get; set; }
	internal object SelfReferenceCount { get; set; }
	internal override object NameAttribute { get; set; }

	// Methods

	// RVA: 0x6F8B1F8
	public object get_Name() { }

	// RVA: 0x6F8B200
	public object set_Name(object value) { }

	// RVA: 0x6F8B208
	public object get_Particle() { }

	// RVA: 0x6F8B210
	public object set_Particle(object value) { }

	// RVA: 0x6F8B218
	public object get_QualifiedName() { }

	// RVA: 0x6F8B220
	internal object get_CanonicalParticle() { }

	// RVA: 0x6F8B228
	internal object set_CanonicalParticle(object value) { }

	// RVA: 0x6F8B230
	internal object get_Redefined() { }

	// RVA: 0x6F8B238
	internal object set_Redefined(object value) { }

	// RVA: 0x6F8B240
	internal object get_SelfReferenceCount() { }

	// RVA: 0x6F8B248
	internal object set_SelfReferenceCount(object value) { }

	// RVA: 0x6F8B250
	internal override object get_NameAttribute() { }

	// RVA: 0x6F8B258
	internal override object set_NameAttribute(object value) { }

	// RVA: 0x6F8B260
	internal object SetQualifiedName(object value) { }

	// RVA: 0x6F8B268
	internal override object Clone() { }

	// RVA: 0x6F83364
	internal object Clone(object parentSchema) { }

	// RVA: 0x6F8B270
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaGroupBase
{

	// Properties
	public abstract object Items { get; }

	// Methods

	// RVA: -1
	public abstract object get_Items() { }

	// RVA: -1
	internal abstract object SetItems(object newItems) { }

	// RVA: 0x6F83B60
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaGroupRef
{

	// Fields
	private object refName; // 0x70
	private object particle; // 0x78
	private object refined; // 0x80

	// Properties
	public object RefName { get; set; }
	public object Particle { get; }
	internal object Redefined { get; set; }

	// Methods

	// RVA: 0x6F8B2E4
	public object get_RefName() { }

	// RVA: 0x6F88834
	public object set_RefName(object value) { }

	// RVA: 0x6F8B2EC
	public object get_Particle() { }

	// RVA: 0x6F8B2F4
	internal object SetParticle(object value) { }

	// RVA: 0x6F8B2FC
	internal object get_Redefined() { }

	// RVA: 0x6F8B304
	internal object set_Redefined(object value) { }

	// RVA: 0x6F8B30C
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaIdentityConstraint
{

	// Fields
	private object name; // 0x48
	private object selector; // 0x50
	private object fields; // 0x58
	private object qualifiedName; // 0x60
	private object compiledConstraint; // 0x68

	// Properties
	public object Name { get; set; }
	public object Selector { get; set; }
	public object Fields { get; }
	public object QualifiedName { get; }
	internal object CompiledConstraint { get; set; }
	internal override object NameAttribute { get; set; }

	// Methods

	// RVA: 0x6F8B3E8
	public object get_Name() { }

	// RVA: 0x6F8B3F0
	public object set_Name(object value) { }

	// RVA: 0x6F8B3F8
	public object get_Selector() { }

	// RVA: 0x6F8B400
	public object set_Selector(object value) { }

	// RVA: 0x6F8B408
	public object get_Fields() { }

	// RVA: 0x6F8B410
	public object get_QualifiedName() { }

	// RVA: 0x6F8B418
	internal object SetQualifiedName(object value) { }

	// RVA: 0x6F8B420
	internal object get_CompiledConstraint() { }

	// RVA: 0x6F8B428
	internal object set_CompiledConstraint(object value) { }

	// RVA: 0x6F8B430
	internal override object get_NameAttribute() { }

	// RVA: 0x6F8B438
	internal override object set_NameAttribute(object value) { }

	// RVA: 0x6F8B440
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaXPath
{

	// Fields
	private object xpath; // 0x48

	// Properties
	public object XPath { get; set; }

	// Methods

	// RVA: 0x6F8B4E0
	public object get_XPath() { }

	// RVA: 0x6F8B4E8
	public object set_XPath(object value) { }

	// RVA: 0x6F8B4F0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaUnique
{

	// Methods

	// RVA: 0x6F8B4F8
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaKey
{

	// Methods

	// RVA: 0x6F8B598
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaKeyref
{

	// Fields
	private object refer; // 0x70

	// Properties
	public object Refer { get; set; }

	// Methods

	// RVA: 0x6F8B638
	public object get_Refer() { }

	// RVA: 0x6F8B640
	public object set_Refer(object value) { }

	// RVA: 0x6F8B718
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaImport
{

	// Fields
	private object ns; // 0x60
	private object annotation; // 0x68

	// Properties
	public object Namespace { get; set; }

	// Methods

	// RVA: 0x6F8B7F8
	public object .ctor() { }

	// RVA: 0x6F8B824
	public object get_Namespace() { }

	// RVA: 0x6F8B82C
	public object set_Namespace(object value) { }

	// RVA: 0x6F8B834
	internal override object AddAnnotation(object annotation) { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaInclude
{

	// Fields
	private object annotation; // 0x60

	// Methods

	// RVA: 0x6F8B83C
	public object .ctor() { }

	// RVA: 0x6F8B868
	internal override object AddAnnotation(object annotation) { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaInfo
{

	// Fields
	private object isDefault; // 0x8
	private object isNil; // 0x9
	private object schemaElement; // 0x10
	private object schemaAttribute; // 0x18
	private object schemaType; // 0x20
	private object memberType; // 0x28
	private object validity; // 0x30
	private object contentType; // 0x34

	// Properties
	public object Validity { get; set; }
	public object IsDefault { get; set; }
	public object IsNil { get; set; }
	public object MemberType { get; set; }
	public object SchemaType { get; set; }
	public object SchemaElement { get; set; }
	public object SchemaAttribute { get; set; }
	public object ContentType { get; }
	internal object XmlType { get; }
	internal object HasDefaultValue { get; }
	internal object IsUnionType { get; }

	// Methods

	// RVA: 0x6F8B870
	public object .ctor() { }

	// RVA: 0x6F8B8C0
	internal object .ctor(object validity) { }

	// RVA: 0x6F8B8FC
	public object get_Validity() { }

	// RVA: 0x6F8B904
	public object set_Validity(object value) { }

	// RVA: 0x6F8B90C
	public object get_IsDefault() { }

	// RVA: 0x6F8B914
	public object set_IsDefault(object value) { }

	// RVA: 0x6F8B91C
	public object get_IsNil() { }

	// RVA: 0x6F8B924
	public object set_IsNil(object value) { }

	// RVA: 0x6F8B92C
	public object get_MemberType() { }

	// RVA: 0x6F8B934
	public object set_MemberType(object value) { }

	// RVA: 0x6F8B93C
	public object get_SchemaType() { }

	// RVA: 0x6F8B944
	public object set_SchemaType(object value) { }

	// RVA: 0x6F8B964
	public object get_SchemaElement() { }

	// RVA: 0x6F8B96C
	public object set_SchemaElement(object value) { }

	// RVA: 0x6F8B97C
	public object get_SchemaAttribute() { }

	// RVA: 0x6F8B984
	public object set_SchemaAttribute(object value) { }

	// RVA: 0x6F8B994
	public object get_ContentType() { }

	// RVA: 0x6F8B99C
	internal object get_XmlType() { }

	// RVA: 0x6F8B9B8
	internal object get_HasDefaultValue() { }

	// RVA: 0x6F8B9F4
	internal object get_IsUnionType() { }

	// RVA: 0x6F8B8A8
	internal object Clear() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaNotation
{

	// Fields
	private object name; // 0x48
	private object publicId; // 0x50
	private object systemId; // 0x58
	private object qname; // 0x60

	// Properties
	public object Name { get; set; }
	public object Public { get; set; }
	public object System { get; set; }
	internal object QualifiedName { get; set; }
	internal override object NameAttribute { get; set; }

	// Methods

	// RVA: 0x6F8BA60
	public object get_Name() { }

	// RVA: 0x6F8BA68
	public object set_Name(object value) { }

	// RVA: 0x6F8BA70
	public object get_Public() { }

	// RVA: 0x6F8BA78
	public object set_Public(object value) { }

	// RVA: 0x6F8BA80
	public object get_System() { }

	// RVA: 0x6F8BA88
	public object set_System(object value) { }

	// RVA: 0x6F8BA90
	internal object get_QualifiedName() { }

	// RVA: 0x6F8BA98
	internal object set_QualifiedName(object value) { }

	// RVA: 0x6F8BAA0
	internal override object get_NameAttribute() { }

	// RVA: 0x6F8BAA8
	internal override object set_NameAttribute(object value) { }

	// RVA: 0x6F8BAB0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaObject
{

	// Fields
	private object lineNum; // 0x8
	private object linePos; // 0xC
	private object sourceUri; // 0x10
	private object namespaces; // 0x18
	private object parent; // 0x20
	private object isProcessing; // 0x28

	// Properties
	public object LineNumber { get; set; }
	public object LinePosition { get; set; }
	public object SourceUri { get; set; }
	public object Parent { get; set; }
	public object Namespaces { get; set; }
	internal virtual object IdAttribute { get; set; }
	internal virtual object NameAttribute { get; set; }
	internal object IsProcessing { get; set; }

	// Methods

	// RVA: 0x6F8BB24
	public object get_LineNumber() { }

	// RVA: 0x6F8BB2C
	public object set_LineNumber(object value) { }

	// RVA: 0x6F8BB34
	public object get_LinePosition() { }

	// RVA: 0x6F8BB3C
	public object set_LinePosition(object value) { }

	// RVA: 0x6F8BB44
	public object get_SourceUri() { }

	// RVA: 0x6F8BB4C
	public object set_SourceUri(object value) { }

	// RVA: 0x6F8BB54
	public object get_Parent() { }

	// RVA: 0x6F8BB5C
	public object set_Parent(object value) { }

	// RVA: 0x6F82174
	public object get_Namespaces() { }

	// RVA: 0x6F8BB64
	public object set_Namespaces(object value) { }

	// RVA: 0x6F8BB6C
	internal virtual object OnAdd(object container, object item) { }

	// RVA: 0x6F8BB70
	internal virtual object OnRemove(object container, object item) { }

	// RVA: 0x6F8BB74
	internal virtual object OnClear(object container) { }

	// RVA: 0x6F8BB78
	internal virtual object get_IdAttribute() { }

	// RVA: 0x6F8BB80
	internal virtual object set_IdAttribute(object value) { }

	// RVA: 0x6F8BB84
	internal virtual object SetUnhandledAttributes(object moreAttributes) { }

	// RVA: 0x6F8BB88
	internal virtual object AddAnnotation(object annotation) { }

	// RVA: 0x6F8BB8C
	internal virtual object get_NameAttribute() { }

	// RVA: 0x6F8BB94
	internal virtual object set_NameAttribute(object value) { }

	// RVA: 0x6F8BB98
	internal object get_IsProcessing() { }

	// RVA: 0x6F8BBA0
	internal object set_IsProcessing(object value) { }

	// RVA: 0x6F8BBA8
	internal virtual object Clone() { }

	// RVA: 0x6F817B4
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaObjectCollection
{

	// Fields
	private object parent; // 0x10

	// Properties
	public virtual object Item { get; set; }

	// Methods

	// RVA: 0x6F817AC
	public object .ctor() { }

	// RVA: 0x6F8BC30
	public virtual object get_Item(object index) { }

	// RVA: 0x6F8BD74
	public virtual object set_Item(object index, object value) { }

	// RVA: 0x6F8BE6C
	public object GetEnumerator() { }

	// RVA: 0x6F83544
	public object Add(object item) { }

	// RVA: 0x6F8BF0C
	public object Insert(object index, object item) { }

	// RVA: 0x6F8C004
	public object Remove(object item) { }

	// RVA: 0x6F8C0EC
	protected override object OnInsert(object index, object item) { }

	// RVA: 0x6F8C154
	protected override object OnSet(object index, object oldValue, object newValue) { }

	// RVA: 0x6F8C200
	protected override object OnClear() { }

	// RVA: 0x6F8C254
	protected override object OnRemove(object index, object item) { }

	// RVA: 0x6F88564
	internal object Clone() { }

	// RVA: 0x6F8C2BC
	private object Add(object collToAdd) { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaObjectEnumerator
{

	// Fields
	private object enumerator; // 0x8

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6F8C318
	internal object .ctor(object enumerator) { }

	// RVA: 0x6F8C344
	public object MoveNext() { }

	// RVA: 0x6F8C424
	public object get_Current() { }

	// RVA: 0x6F8C550
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6F8C634
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x6F8C714
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
internal enum EnumeratorType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Keys;
	public const object Values;
	public const object DictionaryEntry;
}

// Namespace: 
internal struct XmlSchemaObjectEntry
{

	// Fields
	internal object qname; // 0xFFFFFFFFFFFFFFF8
	internal object xso; // 0x0

	// Methods

	// RVA: 0x6F8CA30
	public object .ctor(object name, object value) { }

}

// Namespace: 
internal class ValuesCollection
{

	// Fields
	private object entries; // 0x8
	private object size; // 0x10

	// Properties
	public object Count { get; }
	public object SyncRoot { get; }
	public object IsSynchronized { get; }

	// Methods

	// RVA: 0x6F8D1FC
	internal object .ctor(object entries, object size) { }

	// RVA: 0x6F8D374
	public object get_Count() { }

	// RVA: 0x6F8D37C
	public object get_SyncRoot() { }

	// RVA: 0x6F8D460
	public object get_IsSynchronized() { }

	// RVA: 0x6F8D544
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x6F8D690
	public object GetEnumerator() { }

}

// Namespace: 
internal class XSOEnumerator
{

	// Fields
	private object entries; // 0x8
	private object enumType; // 0x10
	protected object currentIndex; // 0x14
	protected object size; // 0x18
	protected object currentKey; // 0x20
	protected object currentValue; // 0x28

	// Properties
	public object Current { get; }

	// Methods

	// RVA: 0x6F8D710
	internal object .ctor(object entries, object size, object enumType) { }

	// RVA: 0x6F8D758
	public object get_Current() { }

	// RVA: 0x6F8D948
	public object MoveNext() { }

	// RVA: 0x6F8DA14
	public object Reset() { }

}

// Namespace: 
internal class XSODictionaryEnumerator
{

	// Properties
	public object Entry { get; }
	public object Key { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6F8D2E8
	internal object .ctor(object entries, object size, object enumType) { }

	// RVA: 0x6F8DA24
	public object get_Entry() { }

	// RVA: 0x6F8DB84
	public object get_Key() { }

	// RVA: 0x6F8DCC8
	public object get_Value() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaObjectTable
{

	// Fields
	private object table; // 0x8
	private object entries; // 0x10

	// Properties
	public object Count { get; }
	public object Item { get; }
	public object Values { get; }

	// Methods

	// RVA: 0x6F8C7F8
	internal object .ctor() { }

	// RVA: 0x6F8C8C0
	internal object Add(object name, object value) { }

	// RVA: 0x6F8CA38
	internal object Insert(object name, object value) { }

	// RVA: 0x6F8CC80
	internal object Replace(object name, object value) { }

	// RVA: 0x6F8CDF8
	internal object Clear() { }

	// RVA: 0x6F8CEA4
	internal object Remove(object name) { }

	// RVA: 0x6F8CBD8
	private object FindIndexByValue(object xso) { }

	// RVA: 0x6F8D004
	public object get_Count() { }

	// RVA: 0x6F8D060
	public object Contains(object name) { }

	// RVA: 0x6F8D0CC
	public object get_Item(object name) { }

	// RVA: 0x6F8D158
	public object get_Values() { }

	// RVA: 0x6F8D238
	public object GetEnumerator() { }

}

// Namespace: 
private enum Occurs
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Min;
	public const object Max;
}

// Namespace: 
private class EmptyParticle
{

	// Properties
	internal override object IsEmpty { get; }

	// Methods

	// RVA: 0x6F8EB58
	internal override object get_IsEmpty() { }

	// RVA: 0x6F8EA70
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaParticle
{

	// Fields
	private object minOccurs; // 0x48
	private object maxOccurs; // 0x58
	private object flags; // 0x68
	internal static readonly object Empty; // 0x0

	// Properties
	public object MinOccursString { get; set; }
	public object MaxOccursString { get; set; }
	public object MinOccurs { get; set; }
	public object MaxOccurs { get; set; }
	internal virtual object IsEmpty { get; }
	internal virtual object NameString { get; }

	// Methods

	// RVA: 0x6F8DE0C
	public object get_MinOccursString() { }

	// RVA: 0x6F8DEA0
	public object set_MinOccursString(object value) { }

	// RVA: 0x6F8E00C
	public object get_MaxOccursString() { }

	// RVA: 0x6F8E158
	public object set_MaxOccursString(object value) { }

	// RVA: 0x6F8E388
	public object get_MinOccurs() { }

	// RVA: 0x6F8E394
	public object set_MinOccurs(object value) { }

	// RVA: 0x6F8E4CC
	public object get_MaxOccurs() { }

	// RVA: 0x6F8E4D8
	public object set_MaxOccurs(object value) { }

	// RVA: 0x6F8E650
	internal virtual object get_IsEmpty() { }

	// RVA: 0x6F8E6C8
	internal virtual object get_NameString() { }

	// RVA: 0x6F8E714
	internal object GetQualifiedName() { }

	// RVA: 0x6F8E8BC
	protected object .ctor() { }

	// RVA: 0x6F8E93C
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaRedefine
{

	// Fields
	private object items; // 0x60
	private object attributeGroups; // 0x68
	private object types; // 0x70
	private object groups; // 0x78

	// Properties
	public object Items { get; }
	public object AttributeGroups { get; }
	public object SchemaTypes { get; }
	public object Groups { get; }

	// Methods

	// RVA: 0x6F8EB60
	public object .ctor() { }

	// RVA: 0x6F8EC28
	public object get_Items() { }

	// RVA: 0x6F8EC30
	public object get_AttributeGroups() { }

	// RVA: 0x6F8EC38
	public object get_SchemaTypes() { }

	// RVA: 0x6F8EC40
	public object get_Groups() { }

	// RVA: 0x6F8EC48
	internal override object AddAnnotation(object annotation) { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSequence
{

	// Fields
	private object items; // 0x70

	// Properties
	public override object Items { get; }
	internal override object IsEmpty { get; }

	// Methods

	// RVA: 0x6F8EC6C
	public override object get_Items() { }

	// RVA: 0x6F8EC74
	internal override object get_IsEmpty() { }

	// RVA: 0x6F8ED2C
	internal override object SetItems(object newItems) { }

	// RVA: 0x6F8ED34
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSet
{

	// Fields
	private object nameTable; // 0x8
	private object schemaNames; // 0x10
	private object schemas; // 0x18
	private object internalEventHandler; // 0x20
	private object eventHandler; // 0x28
	private object isCompiled; // 0x30
	private object schemaLocations; // 0x38
	private object chameleonSchemas; // 0x40
	private object targetNamespaces; // 0x48
	private object compileAll; // 0x50
	private object cachedCompiledInfo; // 0x58
	private object readerSettings; // 0x60
	private object schemaForSchema; // 0x68
	private object compilationSettings; // 0x70
	internal object elements; // 0x78
	internal object attributes; // 0x80
	internal object schemaTypes; // 0x88
	internal object substitutionGroups; // 0x90
	private object typeExtensions; // 0x98
	private object internalSyncObject; // 0xA0

	// Properties
	internal object InternalSyncObject { get; }
	public object IsCompiled { get; }
	public object XmlResolver { set; }
	public object CompilationSettings { get; set; }
	public object Count { get; }
	public object GlobalElements { get; }
	public object GlobalAttributes { get; }
	public object GlobalTypes { get; }
	internal object SubstitutionGroups { get; }
	internal object SchemaLocations { get; }
	internal object TypeExtensions { get; }
	internal object CompiledInfo { get; }
	internal object ReaderSettings { get; }
	internal object SortedSchemas { get; }

	// Methods

	// RVA: 0x6F8EDA0
	internal object get_InternalSyncObject() { }

	// RVA: 0x6F8EE28
	public object .ctor() { }

	// RVA: 0x6F8EE90
	public object .ctor(object nameTable) { }

	// RVA: 0x6F8F12C
	public object add_ValidationEventHandler(object value) { }

	// RVA: 0x6F8F20C
	public object remove_ValidationEventHandler(object value) { }

	// RVA: 0x6F8F2AC
	public object get_IsCompiled() { }

	// RVA: 0x6F8F2B4
	public object set_XmlResolver(object value) { }

	// RVA: 0x6F8F2D8
	public object get_CompilationSettings() { }

	// RVA: 0x6F8F2E0
	public object set_CompilationSettings(object value) { }

	// RVA: 0x6F8F2E8
	public object get_Count() { }

	// RVA: 0x6F8F338
	public object get_GlobalElements() { }

	// RVA: 0x6F8F3B0
	public object get_GlobalAttributes() { }

	// RVA: 0x6F8F428
	public object get_GlobalTypes() { }

	// RVA: 0x6F8F4A0
	internal object get_SubstitutionGroups() { }

	// RVA: 0x6F8F518
	internal object get_SchemaLocations() { }

	// RVA: 0x6F8F520
	internal object get_TypeExtensions() { }

	// RVA: 0x6F8F598
	public object Add(object schemas) { }

	// RVA: 0x6F92A88
	public object Add(object schema) { }

	// RVA: 0x6F92D14
	public object RemoveRecursive(object schemaToRemove) { }

	// RVA: 0x6F9412C
	public object Contains(object targetNamespace) { }

	// RVA: 0x6F941E0
	public object Compile() { }

	// RVA: 0x6F94BA8
	public object Reprocess(object schema) { }

	// RVA: 0x6F97070
	public object CopyTo(object schemas, object index) { }

	// RVA: 0x6F97238
	public object Schemas() { }

	// RVA: 0x6F96CC8
	public object Schemas(object targetNamespace) { }

	// RVA: 0x6F928E4
	private object Add(object targetNamespace, object schema) { }

	// RVA: 0x6F978B0
	internal object Add(object targetNamespace, object reader, object validatedNamespaces) { }

	// RVA: 0x6F925E0
	internal object FindSchemaByNSAndUrl(object schemaUri, object ns, object locationsTable) { }

	// RVA: 0x6F97288
	private object AddSchemaToSet(object schema) { }

	// RVA: 0x6F98404
	private object ProcessNewSubstitutionGroups(object substitutionGroupsTable, object resolve) { }

	// RVA: 0x6F98AD0
	private object ResolveSubstitutionGroup(object substitutionGroup, object substTable) { }

	// RVA: 0x6F93C58
	internal object Remove(object schema, object forceCompile) { }

	// RVA: 0x6F94830
	private object ClearTables() { }

	// RVA: 0x6F96EF8
	internal object PreprocessSchema(object schema, object targetNamespace) { }

	// RVA: 0x6F981E0
	internal object ParseSchema(object targetNamespace, object reader) { }

	// RVA: 0x6F90184
	internal object CopyFromCompiledSet(object otherSet) { }

	// RVA: 0x6F99720
	internal object get_CompiledInfo() { }

	// RVA: 0x6F99728
	internal object get_ReaderSettings() { }

	// RVA: 0x6F99730
	internal object GetResolver() { }

	// RVA: 0x6F99754
	internal object GetEventHandler() { }

	// RVA: 0x6F99554
	internal object GetSchemaNames(object nt) { }

	// RVA: 0x6F97E00
	internal object IsSchemaLoaded(object schemaUri, object targetNamespace, object schema) { }

	// RVA: 0x6F9975C
	internal object GetSchemaByUri(object schemaUri, object schema) { }

	// RVA: 0x6F93B38
	internal object GetTargetNamespace(object schema) { }

	// RVA: 0x6F99920
	internal object get_SortedSchemas() { }

	// RVA: 0x6F96510
	private object RemoveSchemaFromCaches(object schema) { }

	// RVA: 0x6F95620
	private object RemoveSchemaFromGlobalTables(object schema) { }

	// RVA: 0x6F99150
	private object AddToTable(object table, object qname, object item) { }

	// RVA: 0x6F99604
	private object VerifyTables() { }

	// RVA: 0x6F99928
	private object InternalValidationCallback(object sender, object e) { }

	// RVA: 0x6F93BAC
	private object SendValidationEvent(object e, object severity) { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSimpleContent
{

	// Fields
	private object content; // 0x48

	// Properties
	public override object Content { get; set; }

	// Methods

	// RVA: 0x6F99988
	public override object get_Content() { }

	// RVA: 0x6F99990
	public override object set_Content(object value) { }

	// RVA: 0x6F99998
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSimpleContentExtension
{

	// Fields
	private object attributes; // 0x48
	private object anyAttribute; // 0x50
	private object baseTypeName; // 0x58

	// Properties
	public object BaseTypeName { get; set; }
	public object Attributes { get; }
	public object AnyAttribute { get; set; }

	// Methods

	// RVA: 0x6F999A0
	public object get_BaseTypeName() { }

	// RVA: 0x6F999A8
	public object set_BaseTypeName(object value) { }

	// RVA: 0x6F99A80
	public object get_Attributes() { }

	// RVA: 0x6F99A88
	public object get_AnyAttribute() { }

	// RVA: 0x6F99A90
	public object set_AnyAttribute(object value) { }

	// RVA: 0x6F99A98
	internal object SetAttributes(object newAttributes) { }

	// RVA: 0x6F99AA0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSimpleContentRestriction
{

	// Fields
	private object baseTypeName; // 0x48
	private object baseType; // 0x50
	private object facets; // 0x58
	private object attributes; // 0x60
	private object anyAttribute; // 0x68

	// Properties
	public object BaseTypeName { get; set; }
	public object BaseType { get; set; }
	public object Facets { get; }
	public object Attributes { get; }
	public object AnyAttribute { get; set; }

	// Methods

	// RVA: 0x6F99B40
	public object get_BaseTypeName() { }

	// RVA: 0x6F99B48
	public object set_BaseTypeName(object value) { }

	// RVA: 0x6F99C20
	public object get_BaseType() { }

	// RVA: 0x6F99C28
	public object set_BaseType(object value) { }

	// RVA: 0x6F99C30
	public object get_Facets() { }

	// RVA: 0x6F99C38
	public object get_Attributes() { }

	// RVA: 0x6F99C40
	public object get_AnyAttribute() { }

	// RVA: 0x6F99C48
	public object set_AnyAttribute(object value) { }

	// RVA: 0x6F99C50
	internal object SetAttributes(object newAttributes) { }

	// RVA: 0x6F99C58
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSimpleType
{

	// Fields
	private object content; // 0x90

	// Properties
	public object Content { get; set; }

	// Methods

	// RVA: 0x6F99D10
	public object .ctor() { }

	// RVA: 0x6F99E10
	public object get_Content() { }

	// RVA: 0x6F99E18
	public object set_Content(object value) { }

	// RVA: 0x6F99E20
	internal override object Clone() { }

}

// Namespace: System.Xml.Schema
public abstract class XmlSchemaSimpleTypeContent
{

	// Methods

	// RVA: 0x6F99F40
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSimpleTypeList
{

	// Fields
	private object itemTypeName; // 0x48
	private object itemType; // 0x50
	private object baseItemType; // 0x58

	// Properties
	public object ItemTypeName { get; set; }
	public object ItemType { get; set; }
	public object BaseItemType { get; set; }

	// Methods

	// RVA: 0x6F99F48
	public object get_ItemTypeName() { }

	// RVA: 0x6F99F50
	public object set_ItemTypeName(object value) { }

	// RVA: 0x6F9A028
	public object get_ItemType() { }

	// RVA: 0x6F9A030
	public object set_ItemType(object value) { }

	// RVA: 0x6F9A038
	public object get_BaseItemType() { }

	// RVA: 0x6F9A040
	public object set_BaseItemType(object value) { }

	// RVA: 0x6F9A048
	internal override object Clone() { }

	// RVA: 0x6F9A1C0
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSimpleTypeRestriction
{

	// Fields
	private object baseTypeName; // 0x48
	private object baseType; // 0x50
	private object facets; // 0x58

	// Properties
	public object BaseTypeName { get; set; }
	public object BaseType { get; set; }
	public object Facets { get; }

	// Methods

	// RVA: 0x6F9A234
	public object get_BaseTypeName() { }

	// RVA: 0x6F9A23C
	public object set_BaseTypeName(object value) { }

	// RVA: 0x6F9A314
	public object get_BaseType() { }

	// RVA: 0x6F9A31C
	public object set_BaseType(object value) { }

	// RVA: 0x6F9A324
	public object get_Facets() { }

	// RVA: 0x6F9A32C
	internal override object Clone() { }

	// RVA: 0x6F9A4A4
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaSimpleTypeUnion
{

	// Fields
	private object baseTypes; // 0x48
	private object memberTypes; // 0x50
	private object baseMemberTypes; // 0x58

	// Properties
	public object BaseTypes { get; }
	public object MemberTypes { get; set; }
	public object BaseMemberTypes { get; }

	// Methods

	// RVA: 0x6F9A544
	public object get_BaseTypes() { }

	// RVA: 0x6F9A54C
	public object get_MemberTypes() { }

	// RVA: 0x6F9A554
	public object set_MemberTypes(object value) { }

	// RVA: 0x6F9A55C
	public object get_BaseMemberTypes() { }

	// RVA: 0x6F9A564
	internal object SetBaseMemberTypes(object baseMemberTypes) { }

	// RVA: 0x6F9A56C
	internal override object Clone() { }

	// RVA: 0x6F9A744
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class XmlSchemaSubstitutionGroup
{

	// Fields
	private object membersList; // 0x30
	private object examplar; // 0x38

	// Properties
	internal object Members { get; }
	internal object Examplar { get; set; }

	// Methods

	// RVA: 0x6F9A7B0
	internal object get_Members() { }

	// RVA: 0x6F9A7B8
	internal object get_Examplar() { }

	// RVA: 0x6F9A7C0
	internal object set_Examplar(object value) { }

	// RVA: 0x6F9A7C8
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
internal class XmlSchemaSubstitutionGroupV1Compat
{

	// Fields
	private object choice; // 0x40

	// Properties
	internal object Choice { get; }

	// Methods

	// RVA: 0x6F9A868
	internal object get_Choice() { }

	// RVA: 0x6F9A870
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public class XmlSchemaType
{

	// Fields
	private object name; // 0x48
	private object final; // 0x50
	private object derivedBy; // 0x54
	private object baseSchemaType; // 0x58
	private object datatype; // 0x60
	private object finalResolved; // 0x68
	private object elementDecl; // 0x70
	private object qname; // 0x78
	private object redefined; // 0x80
	private object contentType; // 0x88

	// Properties
	public object Name { get; set; }
	public object Final { get; set; }
	public object QualifiedName { get; }
	public object FinalResolved { get; }
	public object BaseXmlSchemaType { get; }
	public object DerivedBy { get; }
	public object Datatype { get; }
	public virtual object IsMixed { get; set; }
	public object TypeCode { get; }
	internal object ValueConverter { get; }
	internal object SchemaContentType { get; }
	internal object ElementDecl { get; set; }
	internal object Redefined { get; set; }
	internal override object NameAttribute { get; set; }

	// Methods

	// RVA: 0x6F9A950
	public static object GetBuiltInSimpleType(object qualifiedName) { }

	// RVA: 0x6F9AA6C
	public static object GetBuiltInSimpleType(object typeCode) { }

	// RVA: 0x6F9AAF4
	public static object GetBuiltInComplexType(object qualifiedName) { }

	// RVA: 0x6F9AE38
	public object get_Name() { }

	// RVA: 0x6F9AE40
	public object set_Name(object value) { }

	// RVA: 0x6F9AE48
	public object get_Final() { }

	// RVA: 0x6F9AE50
	public object set_Final(object value) { }

	// RVA: 0x6F996FC
	public object get_QualifiedName() { }

	// RVA: 0x6F9AE58
	public object get_FinalResolved() { }

	// RVA: 0x6F9AE60
	public object get_BaseXmlSchemaType() { }

	// RVA: 0x6F9AE68
	public object get_DerivedBy() { }

	// RVA: 0x6F9AE70
	public object get_Datatype() { }

	// RVA: 0x6F9AE78
	public virtual object get_IsMixed() { }

	// RVA: 0x6F9AE80
	public virtual object set_IsMixed(object value) { }

	// RVA: 0x6F9AE84
	public object get_TypeCode() { }

	// RVA: 0x6F9AFA8
	internal object get_ValueConverter() { }

	// RVA: 0x6F9B050
	internal object get_SchemaContentType() { }

	// RVA: 0x6F9B058
	internal object SetQualifiedName(object value) { }

	// RVA: 0x6F9B080
	internal object SetFinalResolved(object value) { }

	// RVA: 0x6F9B088
	internal object SetBaseSchemaType(object value) { }

	// RVA: 0x6F9B090
	internal object SetDerivedBy(object value) { }

	// RVA: 0x6F9B098
	internal object SetDatatype(object value) { }

	// RVA: 0x6F9B0A0
	internal object get_ElementDecl() { }

	// RVA: 0x6F9B0C4
	internal object set_ElementDecl(object value) { }

	// RVA: 0x6F9B0EC
	internal object get_Redefined() { }

	// RVA: 0x6F9B0F4
	internal object set_Redefined(object value) { }

	// RVA: 0x6F9B0FC
	internal object SetContentType(object value) { }

	// RVA: 0x6F9B104
	public static object IsDerivedFrom(object derivedType, object baseType, object except) { }

	// RVA: 0x6F9B384
	internal static object IsDerivedFromDatatype(object derivedDataType, object baseDataType, object except) { }

	// RVA: 0x6F9B4B4
	internal override object get_NameAttribute() { }

	// RVA: 0x6F9B4BC
	internal override object set_NameAttribute(object value) { }

	// RVA: 0x6F99D90
	public object .ctor() { }

}

// Namespace: System.Xml.Schema
public enum XmlSchemaUse
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Optional;
	public const object Prohibited;
	public const object Required;
}

// Namespace: System.Xml.Schema
public class XmlSchemaValidationException
{

	// Methods

	// RVA: 0x6F9B4C4
	protected object .ctor(object info, object context) { }

	// RVA: 0x6F9B4CC
	public override object GetObjectData(object info, object context) { }

	// RVA: 0x6F9B4D4
	public object .ctor() { }

	// RVA: 0x6F9B4E0
	internal object .ctor(object res, object arg, object sourceUri, object lineNumber, object linePosition) { }

	// RVA: 0x6F9B5AC
	internal object .ctor(object res, object args, object sourceUri, object lineNumber, object linePosition) { }

	// RVA: 0x6F9B5E0
	internal object .ctor(object res, object args, object innerException, object sourceUri, object lineNumber, object linePosition) { }

}

// Namespace: System.Xml.Schema
public sealed class XmlValueGetter
{

	// Methods

	// RVA: 0x6F9B664
	public object .ctor(object object, object method) { }

	// RVA: 0x6F9B6F8
	public virtual object Invoke() { }

}

// Namespace: System.Xml.Schema
public enum XmlSchemaValidationFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ProcessInlineSchema;
	public const object ProcessSchemaLocation;
	public const object ReportValidationWarnings;
	public const object ProcessIdentityConstraints;
	public const object AllowXmlAttributes;
}

// Namespace: System.Xml.Schema
internal enum ValidatorState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Start;
	public const object TopLevelAttribute;
	public const object TopLevelTextOrWS;
	public const object Element;
	public const object Attribute;
	public const object EndOfAttributes;
	public const object Text;
	public const object Whitespace;
	public const object EndElement;
	public const object SkipToEndElement;
	public const object Finish;
}

// Namespace: System.Xml.Schema
internal class IdRefNode
{

	// Fields
	internal object Id; // 0x8
	internal object LineNo; // 0x10
	internal object LinePos; // 0x14
	internal object Next; // 0x18

	// Methods

	// RVA: 0x6F9B70C
	internal object .ctor(object next, object id, object lineNo, object linePos) { }

}

// Namespace: System.Xml.Schema
public sealed class XmlSchemaValidator
{

	// Fields
	private object schemaSet; // 0x8
	private object validationFlags; // 0x10
	private object startIDConstraint; // 0x14
	private object isRoot; // 0x18
	private object rootHasSchema; // 0x19
	private object attrValid; // 0x1A
	private object checkEntity; // 0x1B
	private object compiledSchemaInfo; // 0x20
	private object dtdSchemaInfo; // 0x28
	private object validatedNamespaces; // 0x30
	private object validationStack; // 0x38
	private object context; // 0x40
	private object currentState; // 0x48
	private object attPresence; // 0x50
	private object wildID; // 0x58
	private object IDs; // 0x60
	private object idRefListHead; // 0x68
	private object contextQName; // 0x70
	private object NsXs; // 0x78
	private object NsXsi; // 0x80
	private object NsXmlNs; // 0x88
	private object NsXml; // 0x90
	private object partialValidationType; // 0x98
	private object textValue; // 0xA0
	private object eventHandler; // 0xA8
	private object validationEventSender; // 0xB0
	private object nameTable; // 0xB8
	private object positionInfo; // 0xC0
	private object dummyPositionInfo; // 0xC8
	private object xmlResolver; // 0xD0
	private object sourceUri; // 0xD8
	private object sourceUriString; // 0xE0
	private object nsResolver; // 0xE8
	private object processContents; // 0xF0
	private object xsiTypeString; // 0xF8
	private object xsiNilString; // 0x100
	private object xsiSchemaLocationString; // 0x108
	private object xsiNoNamespaceSchemaLocationString; // 0x110
	private static readonly object dtQName; // 0x0
	private static readonly object dtCDATA; // 0x8
	private static readonly object dtStringArray; // 0x10
	private static object EmptyParticleArray; // 0x18
	private static object EmptyAttributeArray; // 0x20
	private object xmlCharType; // 0x118
	internal static object ValidStates; // 0x28
	private static object MethodNames; // 0x30

	// Properties
	public object XmlResolver { set; }
	public object LineInfoProvider { set; }
	public object SourceUri { set; }
	public object ValidationEventSender { set; }
	internal object SchemaSet { get; }
	internal object ValidationFlags { get; }
	internal object CurrentContentType { get; }
	private object StrictlyAssessed { get; }
	private object HasSchema { get; }
	private object HasIdentityConstraints { get; }
	internal object ProcessIdentityConstraints { get; }
	internal object ReportValidationWarnings { get; }
	internal object ProcessSchemaHints { get; }

	// Methods

	// RVA: 0x6F9B75C
	public object .ctor(object nameTable, object schemas, object namespaceResolver, object validationFlags) { }

	// RVA: 0x6F9B968
	private object Init() { }

	// RVA: 0x6F9BEB4
	private object Reset() { }

	// RVA: 0x6F9C084
	public object set_XmlResolver(object value) { }

	// RVA: 0x6F9C08C
	public object set_LineInfoProvider(object value) { }

	// RVA: 0x6F9C0A4
	public object set_SourceUri(object value) { }

	// RVA: 0x6F9C100
	public object set_ValidationEventSender(object value) { }

	// RVA: 0x6F9C108
	public object add_ValidationEventHandler(object value) { }

	// RVA: 0x6F9C1A4
	public object remove_ValidationEventHandler(object value) { }

	// RVA: 0x6F9C240
	public object AddSchema(object schema) { }

	// RVA: 0x6F9CC0C
	public object Initialize() { }

	// RVA: 0x6F9CD64
	public object Initialize(object partialValidationType) { }

	// RVA: 0x6F9D034
	public object ValidateElement(object localName, object namespaceUri, object schemaInfo, object xsiType, object xsiNil, object xsiSchemaLocation, object xsiNoNamespaceSchemaLocation) { }

	// RVA: 0x6F9F2C8
	public object ValidateAttribute(object localName, object namespaceUri, object attributeValue, object schemaInfo) { }

	// RVA: 0x6F9F32C
	private object ValidateAttribute(object lName, object ns, object attributeValueGetter, object attributeStringValue, object schemaInfo) { }

	// RVA: 0x6FA0C60
	public object ValidateEndOfAttributes(object schemaInfo) { }

	// RVA: 0x6FA0FC8
	public object ValidateText(object elementValue) { }

	// RVA: 0x6FA102C
	private object ValidateText(object elementStringValue, object elementValueGetter) { }

	// RVA: 0x6FA1CA4
	public object ValidateWhitespace(object elementValue) { }

	// RVA: 0x6FA1D08
	private object ValidateWhitespace(object elementStringValue, object elementValueGetter) { }

	// RVA: 0x6FA2014
	public object ValidateEndElement(object schemaInfo) { }

	// RVA: 0x6FA2608
	public object SkipToEndElement(object schemaInfo) { }

	// RVA: 0x6FA29F8
	public object EndValidation() { }

	// RVA: 0x6FA2C80
	internal object GetUnspecifiedDefaultAttributes(object defaultAttributes, object createNodeData) { }

	// RVA: 0x6FA39BC
	internal object get_SchemaSet() { }

	// RVA: 0x6FA39C4
	internal object get_ValidationFlags() { }

	// RVA: 0x6FA39CC
	internal object get_CurrentContentType() { }

	// RVA: 0x6FA3A1C
	internal object SetDtdSchemaInfo(object dtdSchemaInfo) { }

	// RVA: 0x6FA3A2C
	private object get_StrictlyAssessed() { }

	// RVA: 0x6FA3A78
	private object get_HasSchema() { }

	// RVA: 0x6FA3AE4
	internal object GetConcatenatedValue() { }

	// RVA: 0x6FA201C
	private object InternalValidateEndElement(object schemaInfo, object typedValue) { }

	// RVA: 0x6F9E200
	private object ProcessSchemaLocations(object xsiSchemaLocation, object xsiNoNamespaceSchemaLocation) { }

	// RVA: 0x6F9D838
	private object ValidateElementContext(object elementName, object invalidElementInContext) { }

	// RVA: 0x6FA612C
	private object GetSubstitutionGroupHead(object member) { }

	// RVA: 0x6FA3B30
	private object ValidateAtomicValue(object stringValue, object memberType) { }

	// RVA: 0x6FA3E80
	private object ValidateAtomicValue(object parsedValue, object memberType) { }

	// RVA: 0x6FA7290
	private object GetTypeName(object decl) { }

	// RVA: 0x6FA15A8
	private object SaveTextValue(object value) { }

	// RVA: 0x6F9BD94
	private object Push(object elementName) { }

	// RVA: 0x6FA286C
	private object Pop() { }

	// RVA: 0x6F9DF3C
	private object FastGetElementDecl(object elementName, object particle) { }

	// RVA: 0x6F9E574
	private object CheckXsiTypeAndNil(object elementDecl, object xsiType, object xsiNil, object declFound) { }

	// RVA: 0x6F9ED74
	private object ThrowDeclNotFoundWarningOrError(object declFound) { }

	// RVA: 0x6F9EFDC
	private object CheckElementProperties() { }

	// RVA: 0x6F9F0FC
	private object ValidateStartElementIdentityConstraints() { }

	// RVA: 0x6FA00F0
	private object CheckIsXmlAttribute(object attQName) { }

	// RVA: 0x6FA7E6C
	private object AddXmlNamespaceSchema() { }

	// RVA: 0x6FA429C
	internal object CheckMixedValueConstraint(object elementValue) { }

	// RVA: 0x6FA5B2C
	private object LoadSchema(object uri, object url) { }

	// RVA: 0x6F9BF94
	internal object RecompileSchemaSet() { }

	// RVA: 0x6FA8184
	private object ProcessTokenizedType(object ttype, object name, object attrValue) { }

	// RVA: 0x6FA03E8
	private object CheckAttributeValue(object value, object attdef) { }

	// RVA: 0x6FA6F88
	private object CheckElementValue(object stringValue) { }

	// RVA: 0x6FA06D4
	private object CheckTokenizedTypes(object dtype, object typedValue, object attrValue) { }

	// RVA: 0x6FA84E8
	private object FindId(object name) { }

	// RVA: 0x6FA2AFC
	private object CheckForwardRefs() { }

	// RVA: 0x6FA08BC
	private object get_HasIdentityConstraints() { }

	// RVA: 0x6FA73B0
	internal object get_ProcessIdentityConstraints() { }

	// RVA: 0x6FA881C
	internal object get_ReportValidationWarnings() { }

	// RVA: 0x6F9C074
	internal object get_ProcessSchemaHints() { }

	// RVA: 0x6F9D554
	private object CheckStateTransition(object toState, object methodName) { }

	// RVA: 0x6F9D7C8
	private object ClearPSVI() { }

	// RVA: 0x6FA0D68
	private object CheckRequiredAttributes(object currentElementDecl) { }

	// RVA: 0x6F9F178
	private object GetSchemaElement() { }

	// RVA: 0x6FA3538
	internal object GetDefaultAttributePrefix(object attributeNS) { }

	// RVA: 0x6FA73BC
	private object AddIdentityConstraints() { }

	// RVA: 0x6FA7954
	private object ElementIdentityConstraints() { }

	// RVA: 0x6FA08DC
	private object AttributeIdentityConstraints(object name, object ns, object obj, object sobj, object datatype) { }

	// RVA: 0x6FA49FC
	private object EndElementIdentityConstraints(object typedValue, object stringValue, object datatype) { }

	// RVA: 0x6FA661C
	internal static object ElementValidationError(object name, object context, object eventHandler, object sender, object sourceUri, object lineNo, object linePos, object schemaSet) { }

	// RVA: 0x6FA43F4
	internal static object CompleteValidationError(object context, object eventHandler, object sender, object sourceUri, object lineNo, object linePos, object schemaSet) { }

	// RVA: 0x6FA1770
	internal static object PrintExpectedElements(object expected, object getParticles) { }

	// RVA: 0x6FA8F4C
	private static object PrintNames(object expected) { }

	// RVA: 0x6FA88F4
	private static object PrintNamesWithNS(object expected, object builder) { }

	// RVA: 0x6FA917C
	private static object EnumerateAny(object builder, object namespaces) { }

	// RVA: 0x6FA151C
	internal static object QNameString(object localName, object ns) { }

	// RVA: 0x6FA6354
	internal static object BuildElementName(object qname) { }

	// RVA: 0x6FA1618
	internal static object BuildElementName(object localName, object ns) { }

	// RVA: 0x6FA8544
	private object ProcessEntity(object name) { }

	// RVA: 0x6FA7348
	private object SendValidationEvent(object code) { }

	// RVA: 0x6FA01F8
	private object SendValidationEvent(object code, object args) { }

	// RVA: 0x6F9FEA8
	private object SendValidationEvent(object code, object arg) { }

	// RVA: 0x6FA63D8
	private object SendValidationEvent(object code, object arg1, object arg2) { }

	// RVA: 0x6FA7F58
	private object SendValidationEvent(object code, object args, object innerException, object severity) { }

	// RVA: 0x6F9CA18
	private object SendValidationEvent(object code, object args, object innerException) { }

	// RVA: 0x6FA8828
	private object SendValidationEvent(object e) { }

	// RVA: 0x6FA606C
	private object SendValidationEvent(object e) { }

	// RVA: 0x6F9C79C
	private object SendValidationEvent(object code, object msg, object severity) { }

	// RVA: 0x6FA8724
	private object SendValidationEvent(object e, object severity) { }

	// RVA: 0x6FA8830
	internal static object SendValidationEvent(object eventHandler, object sender, object e, object severity) { }

	// RVA: 0x6FA93FC
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
public enum XmlSchemaValidity
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NotKnown;
	public const object Valid;
	public const object Invalid;
}

// Namespace: System.Xml.Schema
public enum XmlSeverityType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Error;
	public const object Warning;
}

// Namespace: System.Xml.Schema
public enum XmlTypeCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Item;
	public const object Node;
	public const object Document;
	public const object Element;
	public const object Attribute;
	public const object Namespace;
	public const object ProcessingInstruction;
	public const object Comment;
	public const object Text;
	public const object AnyAtomicType;
	public const object UntypedAtomic;
	public const object String;
	public const object Boolean;
	public const object Decimal;
	public const object Float;
	public const object Double;
	public const object Duration;
	public const object DateTime;
	public const object Time;
	public const object Date;
	public const object GYearMonth;
	public const object GYear;
	public const object GMonthDay;
	public const object GDay;
	public const object GMonth;
	public const object HexBinary;
	public const object Base64Binary;
	public const object AnyUri;
	public const object QName;
	public const object Notation;
	public const object NormalizedString;
	public const object Token;
	public const object Language;
	public const object NmToken;
	public const object Name;
	public const object NCName;
	public const object Id;
	public const object Idref;
	public const object Entity;
	public const object Integer;
	public const object NonPositiveInteger;
	public const object NegativeInteger;
	public const object Long;
	public const object Int;
	public const object Short;
	public const object Byte;
	public const object NonNegativeInteger;
	public const object UnsignedLong;
	public const object UnsignedInt;
	public const object UnsignedShort;
	public const object UnsignedByte;
	public const object PositiveInteger;
	public const object YearMonthDuration;
	public const object DayTimeDuration;
}

// Namespace: System.Xml.Schema
internal abstract class XmlValueConverter
{

	// Methods

	// RVA: -1
	public abstract object ToBoolean(object value) { }

	// RVA: -1
	public abstract object ToBoolean(object value) { }

	// RVA: -1
	public abstract object ToBoolean(object value) { }

	// RVA: -1
	public abstract object ToBoolean(object value) { }

	// RVA: -1
	public abstract object ToBoolean(object value) { }

	// RVA: -1
	public abstract object ToBoolean(object value) { }

	// RVA: -1
	public abstract object ToInt32(object value) { }

	// RVA: -1
	public abstract object ToInt32(object value) { }

	// RVA: -1
	public abstract object ToInt32(object value) { }

	// RVA: -1
	public abstract object ToInt32(object value) { }

	// RVA: -1
	public abstract object ToInt32(object value) { }

	// RVA: -1
	public abstract object ToInt32(object value) { }

	// RVA: -1
	public abstract object ToInt64(object value) { }

	// RVA: -1
	public abstract object ToInt64(object value) { }

	// RVA: -1
	public abstract object ToInt64(object value) { }

	// RVA: -1
	public abstract object ToInt64(object value) { }

	// RVA: -1
	public abstract object ToInt64(object value) { }

	// RVA: -1
	public abstract object ToInt64(object value) { }

	// RVA: -1
	public abstract object ToDecimal(object value) { }

	// RVA: -1
	public abstract object ToDecimal(object value) { }

	// RVA: -1
	public abstract object ToDouble(object value) { }

	// RVA: -1
	public abstract object ToDouble(object value) { }

	// RVA: -1
	public abstract object ToDouble(object value) { }

	// RVA: -1
	public abstract object ToDouble(object value) { }

	// RVA: -1
	public abstract object ToDouble(object value) { }

	// RVA: -1
	public abstract object ToDouble(object value) { }

	// RVA: -1
	public abstract object ToSingle(object value) { }

	// RVA: -1
	public abstract object ToSingle(object value) { }

	// RVA: -1
	public abstract object ToSingle(object value) { }

	// RVA: -1
	public abstract object ToDateTime(object value) { }

	// RVA: -1
	public abstract object ToDateTime(object value) { }

	// RVA: -1
	public abstract object ToDateTime(object value) { }

	// RVA: -1
	public abstract object ToDateTime(object value) { }

	// RVA: -1
	public abstract object ToDateTime(object value) { }

	// RVA: -1
	public abstract object ToDateTime(object value) { }

	// RVA: -1
	public abstract object ToDateTime(object value) { }

	// RVA: -1
	public abstract object ToDateTimeOffset(object value) { }

	// RVA: -1
	public abstract object ToDateTimeOffset(object value) { }

	// RVA: -1
	public abstract object ToDateTimeOffset(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value) { }

	// RVA: -1
	public abstract object ToString(object value, object nsResolver) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType) { }

	// RVA: -1
	public abstract object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FA97B0
	protected object .ctor() { }

}

// Namespace: System.Xml.Schema
internal abstract class XmlBaseConverter
{

	// Fields
	private object schemaType; // 0x8
	private object typeCode; // 0x10
	private object clrTypeDefault; // 0x18
	protected static readonly object ICollectionType; // 0x0
	protected static readonly object IEnumerableType; // 0x8
	protected static readonly object IListType; // 0x10
	protected static readonly object ObjectArrayType; // 0x18
	protected static readonly object StringArrayType; // 0x20
	protected static readonly object XmlAtomicValueArrayType; // 0x28
	protected static readonly object DecimalType; // 0x30
	protected static readonly object Int32Type; // 0x38
	protected static readonly object Int64Type; // 0x40
	protected static readonly object StringType; // 0x48
	protected static readonly object XmlAtomicValueType; // 0x50
	protected static readonly object ObjectType; // 0x58
	protected static readonly object ByteType; // 0x60
	protected static readonly object Int16Type; // 0x68
	protected static readonly object SByteType; // 0x70
	protected static readonly object UInt16Type; // 0x78
	protected static readonly object UInt32Type; // 0x80
	protected static readonly object UInt64Type; // 0x88
	protected static readonly object XPathItemType; // 0x90
	protected static readonly object DoubleType; // 0x98
	protected static readonly object SingleType; // 0xA0
	protected static readonly object DateTimeType; // 0xA8
	protected static readonly object DateTimeOffsetType; // 0xB0
	protected static readonly object BooleanType; // 0xB8
	protected static readonly object ByteArrayType; // 0xC0
	protected static readonly object XmlQualifiedNameType; // 0xC8
	protected static readonly object UriType; // 0xD0
	protected static readonly object TimeSpanType; // 0xD8
	protected static readonly object XPathNavigatorType; // 0xE0

	// Properties
	protected object SchemaType { get; }
	protected object TypeCode { get; }
	protected object XmlTypeName { get; }
	protected object DefaultClrType { get; }

	// Methods

	// RVA: 0x6FA97B8
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FA9968
	protected object .ctor(object typeCode) { }

	// RVA: 0x6FA9A44
	protected object .ctor(object converterAtomic) { }

	// RVA: 0x6FA9AB8
	protected object .ctor(object converterAtomic, object clrTypeDefault) { }

	// RVA: 0x6FA9B10
	public override object ToBoolean(object value) { }

	// RVA: 0x6FA9C30
	public override object ToBoolean(object value) { }

	// RVA: 0x6FA9D50
	public override object ToBoolean(object value) { }

	// RVA: 0x6FA9E70
	public override object ToBoolean(object value) { }

	// RVA: 0x6FA9F90
	public override object ToBoolean(object value) { }

	// RVA: 0x6FAA0A0
	public override object ToBoolean(object value) { }

	// RVA: 0x6FAA1B0
	public override object ToDateTime(object value) { }

	// RVA: 0x6FAA2D0
	public override object ToDateTime(object value) { }

	// RVA: 0x6FAA3F4
	public override object ToDateTime(object value) { }

	// RVA: 0x6FAA514
	public override object ToDateTime(object value) { }

	// RVA: 0x6FAA634
	public override object ToDateTime(object value) { }

	// RVA: 0x6FAA754
	public override object ToDateTime(object value) { }

	// RVA: 0x6FAA864
	public override object ToDateTime(object value) { }

	// RVA: 0x6FAA974
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FAAA98
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FAABAC
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FAACC0
	public override object ToDecimal(object value) { }

	// RVA: 0x6FAADD4
	public override object ToDecimal(object value) { }

	// RVA: 0x6FAAEE8
	public override object ToDouble(object value) { }

	// RVA: 0x6FAB008
	public override object ToDouble(object value) { }

	// RVA: 0x6FAB128
	public override object ToDouble(object value) { }

	// RVA: 0x6FAB248
	public override object ToDouble(object value) { }

	// RVA: 0x6FAB368
	public override object ToDouble(object value) { }

	// RVA: 0x6FAB478
	public override object ToDouble(object value) { }

	// RVA: 0x6FAB588
	public override object ToInt32(object value) { }

	// RVA: 0x6FAB6A8
	public override object ToInt32(object value) { }

	// RVA: 0x6FAB7C8
	public override object ToInt32(object value) { }

	// RVA: 0x6FAB8E8
	public override object ToInt32(object value) { }

	// RVA: 0x6FABA08
	public override object ToInt32(object value) { }

	// RVA: 0x6FABB18
	public override object ToInt32(object value) { }

	// RVA: 0x6FABC28
	public override object ToInt64(object value) { }

	// RVA: 0x6FABD48
	public override object ToInt64(object value) { }

	// RVA: 0x6FABE68
	public override object ToInt64(object value) { }

	// RVA: 0x6FABF88
	public override object ToInt64(object value) { }

	// RVA: 0x6FAC0A8
	public override object ToInt64(object value) { }

	// RVA: 0x6FAC1B8
	public override object ToInt64(object value) { }

	// RVA: 0x6FAC2C8
	public override object ToSingle(object value) { }

	// RVA: 0x6FAC3E8
	public override object ToSingle(object value) { }

	// RVA: 0x6FAC4F8
	public override object ToSingle(object value) { }

	// RVA: 0x6FAC608
	public override object ToString(object value) { }

	// RVA: 0x6FAC70C
	public override object ToString(object value) { }

	// RVA: 0x6FAC810
	public override object ToString(object value) { }

	// RVA: 0x6FAC918
	public override object ToString(object value) { }

	// RVA: 0x6FACA4C
	public override object ToString(object value) { }

	// RVA: 0x6FACB50
	public override object ToString(object value) { }

	// RVA: 0x6FACC54
	public override object ToString(object value) { }

	// RVA: 0x6FACD58
	public override object ToString(object value) { }

	// RVA: 0x6FACE5C
	public override object ToString(object value, object nsResolver) { }

	// RVA: 0x6FACF5C
	public override object ToString(object value) { }

	// RVA: 0x6FACFAC
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FAD058
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FAD104
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FAD1E0
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FAD28C
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FAD338
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FAD3E4
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FAD448
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FAD4A8
	protected object get_SchemaType() { }

	// RVA: 0x6FAD4B0
	protected object get_TypeCode() { }

	// RVA: 0x6FAD4B8
	protected object get_XmlTypeName() { }

	// RVA: 0x6FAD74C
	protected object get_DefaultClrType() { }

	// RVA: 0x6FAD754
	protected static object IsDerivedFrom(object derivedType, object baseType) { }

	// RVA: 0x6FAD854
	protected object CreateInvalidClrMappingException(object sourceType, object destinationType) { }

	// RVA: 0x6FAD604
	protected static object QNameToString(object name) { }

	// RVA: 0x6FADB28
	protected virtual object ChangeListType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FADB8C
	protected static object StringToBase64Binary(object value) { }

	// RVA: 0x6FADC68
	protected static object StringToDate(object value) { }

	// RVA: 0x6FADCF0
	protected static object StringToDateTime(object value) { }

	// RVA: 0x6FADD78
	protected static object StringToDayTimeDuration(object value) { }

	// RVA: 0x6FADDD0
	protected static object StringToDuration(object value) { }

	// RVA: 0x6FADE28
	protected static object StringToGDay(object value) { }

	// RVA: 0x6FADEB0
	protected static object StringToGMonth(object value) { }

	// RVA: 0x6FADF38
	protected static object StringToGMonthDay(object value) { }

	// RVA: 0x6FADFC0
	protected static object StringToGYear(object value) { }

	// RVA: 0x6FAE048
	protected static object StringToGYearMonth(object value) { }

	// RVA: 0x6FAE0D0
	protected static object StringToDateOffset(object value) { }

	// RVA: 0x6FAE158
	protected static object StringToDateTimeOffset(object value) { }

	// RVA: 0x6FAE1E0
	protected static object StringToGDayOffset(object value) { }

	// RVA: 0x6FAE268
	protected static object StringToGMonthOffset(object value) { }

	// RVA: 0x6FAE2F0
	protected static object StringToGMonthDayOffset(object value) { }

	// RVA: 0x6FAE378
	protected static object StringToGYearOffset(object value) { }

	// RVA: 0x6FAE400
	protected static object StringToGYearMonthOffset(object value) { }

	// RVA: 0x6FAE488
	protected static object StringToHexBinary(object value) { }

	// RVA: 0x6FAE5D0
	protected static object StringToQName(object value, object nsResolver) { }

	// RVA: 0x6FAE940
	protected static object StringToTime(object value) { }

	// RVA: 0x6FAE9C8
	protected static object StringToTimeOffset(object value) { }

	// RVA: 0x6FAEA50
	protected static object StringToYearMonthDuration(object value) { }

	// RVA: 0x6FAEAA8
	protected static object AnyUriToString(object value) { }

	// RVA: 0x6FAEAC8
	protected static object Base64BinaryToString(object value) { }

	// RVA: 0x6FAEB50
	protected static object DateToString(object value) { }

	// RVA: 0x6FAEBE0
	protected static object DateTimeToString(object value) { }

	// RVA: 0x6FAEC70
	protected static object DayTimeDurationToString(object value) { }

	// RVA: 0x6FAECC8
	protected static object DurationToString(object value) { }

	// RVA: 0x6FAED20
	protected static object GDayToString(object value) { }

	// RVA: 0x6FAEDB0
	protected static object GMonthToString(object value) { }

	// RVA: 0x6FAEE40
	protected static object GMonthDayToString(object value) { }

	// RVA: 0x6FAEED0
	protected static object GYearToString(object value) { }

	// RVA: 0x6FAEF60
	protected static object GYearMonthToString(object value) { }

	// RVA: 0x6FAEFF0
	protected static object DateOffsetToString(object value) { }

	// RVA: 0x6FAF088
	protected static object DateTimeOffsetToString(object value) { }

	// RVA: 0x6FAF120
	protected static object GDayOffsetToString(object value) { }

	// RVA: 0x6FAF1B8
	protected static object GMonthOffsetToString(object value) { }

	// RVA: 0x6FAF250
	protected static object GMonthDayOffsetToString(object value) { }

	// RVA: 0x6FAF2E8
	protected static object GYearOffsetToString(object value) { }

	// RVA: 0x6FAF380
	protected static object GYearMonthOffsetToString(object value) { }

	// RVA: 0x6FAF418
	protected static object QNameToString(object qname, object nsResolver) { }

	// RVA: 0x6FAF6A8
	protected static object TimeToString(object value) { }

	// RVA: 0x6FAF738
	protected static object TimeOffsetToString(object value) { }

	// RVA: 0x6FAF7D0
	protected static object YearMonthDurationToString(object value) { }

	// RVA: 0x6FAF828
	internal static object DateTimeOffsetToDateTime(object value) { }

	// RVA: 0x6FAF890
	internal static object DecimalToInt32(object value) { }

	// RVA: 0x6FAFA88
	protected static object DecimalToInt64(object value) { }

	// RVA: 0x6FAFC80
	protected static object DecimalToUInt64(object value) { }

	// RVA: 0x6FAFE6C
	protected static object Int32ToByte(object value) { }

	// RVA: 0x6FAFF68
	protected static object Int32ToInt16(object value) { }

	// RVA: 0x6FB0064
	protected static object Int32ToSByte(object value) { }

	// RVA: 0x6FB0160
	protected static object Int32ToUInt16(object value) { }

	// RVA: 0x6FB025C
	protected static object Int64ToInt32(object value) { }

	// RVA: 0x6FB0354
	protected static object Int64ToUInt32(object value) { }

	// RVA: 0x6FB044C
	protected static object UntypedAtomicToDateTime(object value) { }

	// RVA: 0x6FB04D4
	protected static object UntypedAtomicToDateTimeOffset(object value) { }

	// RVA: 0x6FB055C
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class XmlNumeric10Converter
{

	// Methods

	// RVA: 0x6FB0AE8
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FB0B54
	public static object Create(object schemaType) { }

	// RVA: 0x6FB0BF8
	public override object ToDecimal(object value) { }

	// RVA: 0x6FB0D08
	public override object ToDecimal(object value) { }

	// RVA: 0x6FB1780
	public override object ToInt32(object value) { }

	// RVA: 0x6FB1808
	public override object ToInt32(object value) { }

	// RVA: 0x6FB1954
	public override object ToInt32(object value) { }

	// RVA: 0x6FB1E14
	public override object ToInt64(object value) { }

	// RVA: 0x6FB1E1C
	public override object ToInt64(object value) { }

	// RVA: 0x6FB1F68
	public override object ToInt64(object value) { }

	// RVA: 0x6FB2428
	public override object ToString(object value) { }

	// RVA: 0x6FB2504
	public override object ToString(object value) { }

	// RVA: 0x6FB258C
	public override object ToString(object value) { }

	// RVA: 0x6FB2614
	public override object ToString(object value, object nsResolver) { }

	// RVA: 0x6FB2B10
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FB364C
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FB3BB0
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FB4118
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FB46B0
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FB1200
	private object ChangeTypeWildcardDestination(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FB3094
	private object ChangeTypeWildcardSource(object value, object destinationType, object nsResolver) { }

}

// Namespace: System.Xml.Schema
internal class XmlNumeric2Converter
{

	// Methods

	// RVA: 0x6FB5A24
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FB5A90
	public static object Create(object schemaType) { }

	// RVA: 0x6FB5B34
	public override object ToDouble(object value) { }

	// RVA: 0x6FB5C34
	public override object ToDouble(object value) { }

	// RVA: 0x6FB6064
	public override object ToSingle(object value) { }

	// RVA: 0x6FB606C
	public override object ToSingle(object value) { }

	// RVA: 0x6FB616C
	public override object ToSingle(object value) { }

	// RVA: 0x6FB658C
	public override object ToString(object value) { }

	// RVA: 0x6FB6684
	public override object ToString(object value) { }

	// RVA: 0x6FB6724
	public override object ToString(object value, object nsResolver) { }

	// RVA: 0x6FB6B80
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FB7028
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FB74F4
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

}

// Namespace: System.Xml.Schema
internal class XmlDateTimeConverter
{

	// Methods

	// RVA: 0x6FB7E5C
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FB7EC8
	public static object Create(object schemaType) { }

	// RVA: 0x6FB7F6C
	public override object ToDateTime(object value) { }

	// RVA: 0x6FB7FD8
	public override object ToDateTime(object value) { }

	// RVA: 0x6FB8278
	public override object ToDateTime(object value) { }

	// RVA: 0x6FB86D0
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FB86FC
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FB899C
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FB8E14
	public override object ToString(object value) { }

	// RVA: 0x6FB9068
	public override object ToString(object value) { }

	// RVA: 0x6FB9244
	public override object ToString(object value, object nsResolver) { }

	// RVA: 0x6FB9690
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FB9B7C
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FBA040
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

}

// Namespace: System.Xml.Schema
internal class XmlBooleanConverter
{

	// Methods

	// RVA: 0x6FBA9CC
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FBAA38
	public static object Create(object schemaType) { }

	// RVA: 0x6FBAADC
	public override object ToBoolean(object value) { }

	// RVA: 0x6FBAB98
	public override object ToBoolean(object value) { }

	// RVA: 0x6FBAF18
	public override object ToString(object value) { }

	// RVA: 0x6FBAFA0
	public override object ToString(object value, object nsResolver) { }

	// RVA: 0x6FBB308
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FBB748
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FBBB60
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

}

// Namespace: System.Xml.Schema
internal class XmlMiscConverter
{

	// Methods

	// RVA: 0x6FBC2E0
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FBC34C
	public static object Create(object schemaType) { }

	// RVA: 0x6FBC3F0
	public override object ToString(object value, object nsResolver) { }

	// RVA: 0x6FBCBA0
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FBD3B4
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FBCA00
	private object ChangeTypeWildcardDestination(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FBD1DC
	private object ChangeTypeWildcardSource(object value, object destinationType, object nsResolver) { }

}

// Namespace: System.Xml.Schema
internal class XmlStringConverter
{

	// Methods

	// RVA: 0x6FBE468
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FBE4D4
	public static object Create(object schemaType) { }

	// RVA: 0x6FBE578
	public override object ToString(object value, object nsResolver) { }

	// RVA: 0x6FBE800
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FBEB48
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

}

// Namespace: System.Xml.Schema
internal class XmlUntypedConverter
{

	// Fields
	private object allowListToList; // 0x28
	public static readonly object Untyped; // 0x0
	public static readonly object UntypedList; // 0x8

	// Methods

	// RVA: 0x6FBF0D4
	protected object .ctor() { }

	// RVA: 0x6FBF244
	protected object .ctor(object atomicConverter, object allowListToList) { }

	// RVA: 0x6FBF3B8
	public override object ToBoolean(object value) { }

	// RVA: 0x6FBF474
	public override object ToBoolean(object value) { }

	// RVA: 0x6FBF81C
	public override object ToDateTime(object value) { }

	// RVA: 0x6FBF8D8
	public override object ToDateTime(object value) { }

	// RVA: 0x6FBFAB8
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FBFB74
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FBFD60
	public override object ToDecimal(object value) { }

	// RVA: 0x6FBFE1C
	public override object ToDecimal(object value) { }

	// RVA: 0x6FC0030
	public override object ToDouble(object value) { }

	// RVA: 0x6FC00EC
	public override object ToDouble(object value) { }

	// RVA: 0x6FC02F4
	public override object ToInt32(object value) { }

	// RVA: 0x6FC03B0
	public override object ToInt32(object value) { }

	// RVA: 0x6FC05B8
	public override object ToInt64(object value) { }

	// RVA: 0x6FC0674
	public override object ToInt64(object value) { }

	// RVA: 0x6FC087C
	public override object ToSingle(object value) { }

	// RVA: 0x6FC0938
	public override object ToSingle(object value) { }

	// RVA: 0x6FC0B40
	public override object ToString(object value) { }

	// RVA: 0x6FC0BC8
	public override object ToString(object value) { }

	// RVA: 0x6FC0C50
	public override object ToString(object value) { }

	// RVA: 0x6FC0CBC
	public override object ToString(object value) { }

	// RVA: 0x6FC0D28
	public override object ToString(object value) { }

	// RVA: 0x6FC0DB0
	public override object ToString(object value) { }

	// RVA: 0x6FC0E38
	public override object ToString(object value) { }

	// RVA: 0x6FC0EC0
	public override object ToString(object value) { }

	// RVA: 0x6FC0F48
	public override object ToString(object value, object nsResolver) { }

	// RVA: 0x6FC1E28
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC2288
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC24D4
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC278C
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC29F8
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC2C58
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC2EB8
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FC3E64
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FBF67C
	private object ChangeTypeWildcardDestination(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FC2088
	private object ChangeTypeWildcardSource(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FC5C28
	protected override object ChangeListType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FC5F94
	private object SupportsType(object clrType) { }

	// RVA: 0x6FC79E8
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class XmlAnyConverter
{

	// Fields
	public static readonly object Item; // 0x0
	public static readonly object AnyAtomic; // 0x8

	// Methods

	// RVA: 0x6FC7BEC
	protected object .ctor(object typeCode) { }

	// RVA: 0x6FC7C58
	public override object ToBoolean(object value) { }

	// RVA: 0x6FC7FF8
	public override object ToDateTime(object value) { }

	// RVA: 0x6FC81F8
	public override object ToDateTimeOffset(object value) { }

	// RVA: 0x6FC8400
	public override object ToDecimal(object value) { }

	// RVA: 0x6FC8608
	public override object ToDouble(object value) { }

	// RVA: 0x6FC8808
	public override object ToInt32(object value) { }

	// RVA: 0x6FC8A08
	public override object ToInt64(object value) { }

	// RVA: 0x6FC8C08
	public override object ToSingle(object value) { }

	// RVA: 0x6FC8E10
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC9260
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC94D8
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC9790
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC99FC
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC9C74
	public override object ChangeType(object value, object destinationType) { }

	// RVA: 0x6FC9EEC
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FCA144
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FC7E58
	private object ChangeTypeWildcardDestination(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FC9088
	private object ChangeTypeWildcardSource(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FCBC8C
	private object ToNavigator(object nav) { }

	// RVA: 0x6FCBD14
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class XmlAnyListConverter
{

	// Fields
	public static readonly object ItemList; // 0x0
	public static readonly object AnyAtomicList; // 0x8

	// Methods

	// RVA: 0x6FCBE14
	protected object .ctor(object atomicConverter) { }

	// RVA: 0x6FCBEFC
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FCC1CC
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal class XmlListConverter
{

	// Fields
	protected object atomicConverter; // 0x20

	// Methods

	// RVA: 0x6FCBE88
	protected object .ctor(object atomicConverter) { }

	// RVA: 0x6FBF334
	protected object .ctor(object atomicConverter, object clrTypeDefault) { }

	// RVA: 0x6FBF1D8
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FCC384
	public static object Create(object atomicConverter) { }

	// RVA: 0x6FCC624
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FC677C
	protected override object ChangeListType(object value, object destinationType, object nsResolver) { }

	// RVA: 0x6FCC744
	private object IsListType(object type) { }

	// RVA: -1
	private object ToArray(object list, object nsResolver) { }

	// RVA: 0x6FCD170
	private object ToList(object list, object nsResolver) { }

	// RVA: 0x6FCD0C0
	private object StringAsList(object value) { }

	// RVA: 0x6FCCC6C
	private object ListAsString(object list, object nsResolver) { }

	// RVA: 0x6FCC990
	private object CreateInvalidClrMappingException(object sourceType, object destinationType) { }

}

// Namespace: System.Xml.Schema
internal class XmlUnionConverter
{

	// Fields
	private object converters; // 0x20
	private object hasAtomicMember; // 0x28
	private object hasListMember; // 0x29

	// Methods

	// RVA: 0x6FCD924
	protected object .ctor(object schemaType) { }

	// RVA: 0x6FCDC24
	public static object Create(object schemaType) { }

	// RVA: 0x6FCDC88
	public override object ChangeType(object value, object destinationType, object nsResolver) { }

}

// Namespace: 
private enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Root;
	public const object Schema;
	public const object Annotation;
	public const object Include;
	public const object Import;
	public const object Element;
	public const object Attribute;
	public const object AttributeGroup;
	public const object AttributeGroupRef;
	public const object AnyAttribute;
	public const object Group;
	public const object GroupRef;
	public const object All;
	public const object Choice;
	public const object Sequence;
	public const object Any;
	public const object Notation;
	public const object SimpleType;
	public const object ComplexType;
	public const object ComplexContent;
	public const object ComplexContentRestriction;
	public const object ComplexContentExtension;
	public const object SimpleContent;
	public const object SimpleContentExtension;
	public const object SimpleContentRestriction;
	public const object SimpleTypeUnion;
	public const object SimpleTypeList;
	public const object SimpleTypeRestriction;
	public const object Unique;
	public const object Key;
	public const object KeyRef;
	public const object Selector;
	public const object Field;
	public const object MinExclusive;
	public const object MinInclusive;
	public const object MaxExclusive;
	public const object MaxInclusive;
	public const object TotalDigits;
	public const object FractionDigits;
	public const object Length;
	public const object MinLength;
	public const object MaxLength;
	public const object Enumeration;
	public const object Pattern;
	public const object WhiteSpace;
	public const object AppInfo;
	public const object Documentation;
	public const object Redefine;
}

// Namespace: 
private sealed class XsdBuildFunction
{

	// Methods

	// RVA: 0x6FDAEB4
	public object .ctor(object object, object method) { }

	// RVA: 0x6FDAF64
	public virtual object Invoke(object builder, object value) { }

}

// Namespace: 
private sealed class XsdInitFunction
{

	// Methods

	// RVA: 0x6FDB014
	public object .ctor(object object, object method) { }

	// RVA: 0x6FDB0C4
	public virtual object Invoke(object builder, object value) { }

}

// Namespace: 
private sealed class XsdEndChildFunction
{

	// Methods

	// RVA: 0x6FDB164
	public object .ctor(object object, object method) { }

	// RVA: 0x6FDB20C
	public virtual object Invoke(object builder) { }

}

// Namespace: 
private sealed class XsdAttributeEntry
{

	// Fields
	public object Attribute; // 0x8
	public object BuildFunc; // 0x10

	// Methods

	// RVA: 0x6FDB220
	public object .ctor(object a, object build) { }

}

// Namespace: 
private sealed class XsdEntry
{

	// Fields
	public object Name; // 0x8
	public object CurrentState; // 0xC
	public object NextStates; // 0x10
	public object Attributes; // 0x18
	public object InitFunc; // 0x20
	public object EndChildFunc; // 0x28
	public object ParseContent; // 0x30

	// Methods

	// RVA: 0x6FDB25C
	public object .ctor(object n, object state, object nextStates, object attributes, object init, object end, object parseContent) { }

}

// Namespace: 
private class BuilderNamespaceManager
{

	// Fields
	private object nsMgr; // 0x48
	private object reader; // 0x50

	// Methods

	// RVA: 0x6FDB2C4
	public object .ctor(object nsMgr, object reader) { }

	// RVA: 0x6FDB2FC
	public override object LookupNamespace(object prefix) { }

}

// Namespace: System.Xml.Schema
internal sealed class XsdBuilder
{

	// Fields
	private static readonly object SchemaElement; // 0x0
	private static readonly object SchemaSubelements; // 0x8
	private static readonly object AttributeSubelements; // 0x10
	private static readonly object ElementSubelements; // 0x18
	private static readonly object ComplexTypeSubelements; // 0x20
	private static readonly object SimpleContentSubelements; // 0x28
	private static readonly object SimpleContentExtensionSubelements; // 0x30
	private static readonly object SimpleContentRestrictionSubelements; // 0x38
	private static readonly object ComplexContentSubelements; // 0x40
	private static readonly object ComplexContentExtensionSubelements; // 0x48
	private static readonly object ComplexContentRestrictionSubelements; // 0x50
	private static readonly object SimpleTypeSubelements; // 0x58
	private static readonly object SimpleTypeRestrictionSubelements; // 0x60
	private static readonly object SimpleTypeListSubelements; // 0x68
	private static readonly object SimpleTypeUnionSubelements; // 0x70
	private static readonly object RedefineSubelements; // 0x78
	private static readonly object AttributeGroupSubelements; // 0x80
	private static readonly object GroupSubelements; // 0x88
	private static readonly object AllSubelements; // 0x90
	private static readonly object ChoiceSequenceSubelements; // 0x98
	private static readonly object IdentityConstraintSubelements; // 0xA0
	private static readonly object AnnotationSubelements; // 0xA8
	private static readonly object AnnotatedSubelements; // 0xB0
	private static readonly object SchemaAttributes; // 0xB8
	private static readonly object AttributeAttributes; // 0xC0
	private static readonly object ElementAttributes; // 0xC8
	private static readonly object ComplexTypeAttributes; // 0xD0
	private static readonly object SimpleContentAttributes; // 0xD8
	private static readonly object SimpleContentExtensionAttributes; // 0xE0
	private static readonly object SimpleContentRestrictionAttributes; // 0xE8
	private static readonly object ComplexContentAttributes; // 0xF0
	private static readonly object ComplexContentExtensionAttributes; // 0xF8
	private static readonly object ComplexContentRestrictionAttributes; // 0x100
	private static readonly object SimpleTypeAttributes; // 0x108
	private static readonly object SimpleTypeRestrictionAttributes; // 0x110
	private static readonly object SimpleTypeUnionAttributes; // 0x118
	private static readonly object SimpleTypeListAttributes; // 0x120
	private static readonly object AttributeGroupAttributes; // 0x128
	private static readonly object AttributeGroupRefAttributes; // 0x130
	private static readonly object GroupAttributes; // 0x138
	private static readonly object GroupRefAttributes; // 0x140
	private static readonly object ParticleAttributes; // 0x148
	private static readonly object AnyAttributes; // 0x150
	private static readonly object IdentityConstraintAttributes; // 0x158
	private static readonly object SelectorAttributes; // 0x160
	private static readonly object FieldAttributes; // 0x168
	private static readonly object NotationAttributes; // 0x170
	private static readonly object IncludeAttributes; // 0x178
	private static readonly object ImportAttributes; // 0x180
	private static readonly object FacetAttributes; // 0x188
	private static readonly object AnyAttributeAttributes; // 0x190
	private static readonly object DocumentationAttributes; // 0x198
	private static readonly object AppinfoAttributes; // 0x1A0
	private static readonly object RedefineAttributes; // 0x1A8
	private static readonly object AnnotationAttributes; // 0x1B0
	private static readonly object SchemaEntries; // 0x1B8
	private static readonly object DerivationMethodValues; // 0x1C0
	private static readonly object DerivationMethodStrings; // 0x1C8
	private static readonly object FormStringValues; // 0x1D0
	private static readonly object UseStringValues; // 0x1D8
	private static readonly object ProcessContentsStringValues; // 0x1E0
	private object reader; // 0x8
	private object positionInfo; // 0x10
	private object currentEntry; // 0x18
	private object nextEntry; // 0x20
	private object hasChild; // 0x28
	private object stateHistory; // 0x30
	private object containerStack; // 0x38
	private object nameTable; // 0x40
	private object schemaNames; // 0x48
	private object namespaceManager; // 0x50
	private object canIncludeImport; // 0x58
	private object schema; // 0x60
	private object xso; // 0x68
	private object element; // 0x70
	private object anyElement; // 0x78
	private object attribute; // 0x80
	private object anyAttribute; // 0x88
	private object complexType; // 0x90
	private object simpleType; // 0x98
	private object complexContent; // 0xA0
	private object complexContentExtension; // 0xA8
	private object complexContentRestriction; // 0xB0
	private object simpleContent; // 0xB8
	private object simpleContentExtension; // 0xC0
	private object simpleContentRestriction; // 0xC8
	private object simpleTypeUnion; // 0xD0
	private object simpleTypeList; // 0xD8
	private object simpleTypeRestriction; // 0xE0
	private object group; // 0xE8
	private object groupRef; // 0xF0
	private object all; // 0xF8
	private object choice; // 0x100
	private object sequence; // 0x108
	private object particle; // 0x110
	private object attributeGroup; // 0x118
	private object attributeGroupRef; // 0x120
	private object notation; // 0x128
	private object identityConstraint; // 0x130
	private object xpath; // 0x138
	private object include; // 0x140
	private object import; // 0x148
	private object annotation; // 0x150
	private object appInfo; // 0x158
	private object documentation; // 0x160
	private object facet; // 0x168
	private object markup; // 0x170
	private object redefine; // 0x178
	private object validationEventHandler; // 0x180
	private object unhandledAttributes; // 0x188
	private object namespaces; // 0x190

	// Properties
	private object CurrentElement { get; }
	private object ParentElement { get; }
	private object ParentContainer { get; }

	// Methods

	// RVA: 0x6FCE1F4
	internal object .ctor(object reader, object curmgr, object schema, object nameTable, object schemaNames, object eventhandler) { }

	// RVA: 0x6FCE3B4
	internal override object ProcessElement(object prefix, object name, object ns) { }

	// RVA: 0x6FCEB68
	internal override object ProcessAttribute(object prefix, object name, object ns, object value) { }

	// RVA: 0x6FCF294
	internal override object IsContentParsed() { }

	// RVA: 0x6FCF2B8
	internal override object ProcessMarkup(object markup) { }

	// RVA: 0x6FCF2C0
	internal override object ProcessCData(object value) { }

	// RVA: 0x6FCF320
	internal override object StartChildren() { }

	// RVA: 0x6FCF580
	internal override object EndChildren() { }

	// RVA: 0x6FCE718
	private object Push() { }

	// RVA: 0x6FCF5D0
	private object Pop() { }

	// RVA: 0x6FD03FC
	private object get_CurrentElement() { }

	// RVA: 0x6FD0420
	private object get_ParentElement() { }

	// RVA: 0x6FD04B0
	private object get_ParentContainer() { }

	// RVA: 0x6FCF6C8
	private object GetContainer(object state) { }

	// RVA: 0x6FCF6F0
	private object SetContainer(object state, object container) { }

	// RVA: 0x6FD0564
	private static object BuildAnnotated_Id(object builder, object value) { }

	// RVA: 0x6FD05C8
	private static object BuildSchema_AttributeFormDefault(object builder, object value) { }

	// RVA: 0x6FD0784
	private static object BuildSchema_ElementFormDefault(object builder, object value) { }

	// RVA: 0x6FD0844
	private static object BuildSchema_TargetNamespace(object builder, object value) { }

	// RVA: 0x6FD087C
	private static object BuildSchema_Version(object builder, object value) { }

	// RVA: 0x6FD08B4
	private static object BuildSchema_FinalDefault(object builder, object value) { }

	// RVA: 0x6FD0C0C
	private static object BuildSchema_BlockDefault(object builder, object value) { }

	// RVA: 0x6FD0C98
	private static object InitSchema(object builder, object value) { }

	// RVA: 0x6FD0CC4
	private static object InitInclude(object builder, object value) { }

	// RVA: 0x6FD0D90
	private static object BuildInclude_SchemaLocation(object builder, object value) { }

	// RVA: 0x6FD0DC8
	private static object InitImport(object builder, object value) { }

	// RVA: 0x6FD0E94
	private static object BuildImport_Namespace(object builder, object value) { }

	// RVA: 0x6FD0ECC
	private static object BuildImport_SchemaLocation(object builder, object value) { }

	// RVA: 0x6FD0F04
	private static object InitRedefine(object builder, object value) { }

	// RVA: 0x6FD0FD0
	private static object BuildRedefine_SchemaLocation(object builder, object value) { }

	// RVA: 0x6FD1008
	private static object EndRedefine(object builder) { }

	// RVA: 0x6FD102C
	private static object InitAttribute(object builder, object value) { }

	// RVA: 0x6FD150C
	private static object BuildAttribute_Default(object builder, object value) { }

	// RVA: 0x6FD1544
	private static object BuildAttribute_Fixed(object builder, object value) { }

	// RVA: 0x6FD157C
	private static object BuildAttribute_Form(object builder, object value) { }

	// RVA: 0x6FD163C
	private static object BuildAttribute_Use(object builder, object value) { }

	// RVA: 0x6FD16FC
	private static object BuildAttribute_Ref(object builder, object value) { }

	// RVA: 0x6FD1918
	private static object BuildAttribute_Name(object builder, object value) { }

	// RVA: 0x6FD1950
	private static object BuildAttribute_Type(object builder, object value) { }

	// RVA: 0x6FD19E4
	private static object InitElement(object builder, object value) { }

	// RVA: 0x6FD1C10
	private static object BuildElement_Abstract(object builder, object value) { }

	// RVA: 0x6FD1DCC
	private static object BuildElement_Block(object builder, object value) { }

	// RVA: 0x6FD1E58
	private static object BuildElement_Default(object builder, object value) { }

	// RVA: 0x6FD1E90
	private static object BuildElement_Form(object builder, object value) { }

	// RVA: 0x6FD1F50
	private static object BuildElement_SubstitutionGroup(object builder, object value) { }

	// RVA: 0x6FD1FE4
	private static object BuildElement_Final(object builder, object value) { }

	// RVA: 0x6FD2070
	private static object BuildElement_Fixed(object builder, object value) { }

	// RVA: 0x6FD20A8
	private static object BuildElement_MaxOccurs(object builder, object value) { }

	// RVA: 0x6FD21A0
	private static object BuildElement_MinOccurs(object builder, object value) { }

	// RVA: 0x6FD2298
	private static object BuildElement_Name(object builder, object value) { }

	// RVA: 0x6FD22D0
	private static object BuildElement_Nillable(object builder, object value) { }

	// RVA: 0x6FD2364
	private static object BuildElement_Ref(object builder, object value) { }

	// RVA: 0x6FD23F8
	private static object BuildElement_Type(object builder, object value) { }

	// RVA: 0x6FD248C
	private static object InitSimpleType(object builder, object value) { }

	// RVA: 0x6FD2920
	private static object BuildSimpleType_Name(object builder, object value) { }

	// RVA: 0x6FD2958
	private static object BuildSimpleType_Final(object builder, object value) { }

	// RVA: 0x6FD29E4
	private static object InitSimpleTypeUnion(object builder, object value) { }

	// RVA: 0x6FD2AAC
	private static object BuildSimpleTypeUnion_MemberTypes(object builder, object value) { }

	// RVA: 0x6FD2D54
	private static object InitSimpleTypeList(object builder, object value) { }

	// RVA: 0x6FD2E1C
	private static object BuildSimpleTypeList_ItemType(object builder, object value) { }

	// RVA: 0x6FD2EB0
	private static object InitSimpleTypeRestriction(object builder, object value) { }

	// RVA: 0x6FD2F78
	private static object BuildSimpleTypeRestriction_Base(object builder, object value) { }

	// RVA: 0x6FD300C
	private static object InitComplexType(object builder, object value) { }

	// RVA: 0x6FD323C
	private static object BuildComplexType_Abstract(object builder, object value) { }

	// RVA: 0x6FD32D0
	private static object BuildComplexType_Block(object builder, object value) { }

	// RVA: 0x6FD335C
	private static object BuildComplexType_Final(object builder, object value) { }

	// RVA: 0x6FD33E8
	private static object BuildComplexType_Mixed(object builder, object value) { }

	// RVA: 0x6FD349C
	private static object BuildComplexType_Name(object builder, object value) { }

	// RVA: 0x6FD34D4
	private static object InitComplexContent(object builder, object value) { }

	// RVA: 0x6FD35F8
	private static object BuildComplexContent_Mixed(object builder, object value) { }

	// RVA: 0x6FD368C
	private static object InitComplexContentExtension(object builder, object value) { }

	// RVA: 0x6FD37B8
	private static object BuildComplexContentExtension_Base(object builder, object value) { }

	// RVA: 0x6FD384C
	private static object InitComplexContentRestriction(object builder, object value) { }

	// RVA: 0x6FD3900
	private static object BuildComplexContentRestriction_Base(object builder, object value) { }

	// RVA: 0x6FD3994
	private static object InitSimpleContent(object builder, object value) { }

	// RVA: 0x6FD3AB8
	private static object InitSimpleContentExtension(object builder, object value) { }

	// RVA: 0x6FD3BE4
	private static object BuildSimpleContentExtension_Base(object builder, object value) { }

	// RVA: 0x6FD3C78
	private static object InitSimpleContentRestriction(object builder, object value) { }

	// RVA: 0x6FD3DA4
	private static object BuildSimpleContentRestriction_Base(object builder, object value) { }

	// RVA: 0x6FD3E38
	private static object InitAttributeGroup(object builder, object value) { }

	// RVA: 0x6FD3F94
	private static object BuildAttributeGroup_Name(object builder, object value) { }

	// RVA: 0x6FD3FCC
	private static object InitAttributeGroupRef(object builder, object value) { }

	// RVA: 0x6FD404C
	private static object BuildAttributeGroupRef_Ref(object builder, object value) { }

	// RVA: 0x6FD40E0
	private static object InitAnyAttribute(object builder, object value) { }

	// RVA: 0x6FD4488
	private static object BuildAnyAttribute_Namespace(object builder, object value) { }

	// RVA: 0x6FD44C0
	private static object BuildAnyAttribute_ProcessContents(object builder, object value) { }

	// RVA: 0x6FD4580
	private static object InitGroup(object builder, object value) { }

	// RVA: 0x6FD46DC
	private static object BuildGroup_Name(object builder, object value) { }

	// RVA: 0x6FD4714
	private static object InitGroupRef(object builder, object value) { }

	// RVA: 0x6FD4C80
	private static object BuildParticle_MaxOccurs(object builder, object value) { }

	// RVA: 0x6FD4CA4
	private static object BuildParticle_MinOccurs(object builder, object value) { }

	// RVA: 0x6FD4CC8
	private static object BuildGroupRef_Ref(object builder, object value) { }

	// RVA: 0x6FD4D5C
	private static object InitAll(object builder, object value) { }

	// RVA: 0x6FD4DE0
	private static object InitChoice(object builder, object value) { }

	// RVA: 0x6FD4E64
	private static object InitSequence(object builder, object value) { }

	// RVA: 0x6FD4EE4
	private static object InitAny(object builder, object value) { }

	// RVA: 0x6FD4F68
	private static object BuildAny_Namespace(object builder, object value) { }

	// RVA: 0x6FD4FA0
	private static object BuildAny_ProcessContents(object builder, object value) { }

	// RVA: 0x6FD5060
	private static object InitNotation(object builder, object value) { }

	// RVA: 0x6FD510C
	private static object BuildNotation_Name(object builder, object value) { }

	// RVA: 0x6FD5144
	private static object BuildNotation_Public(object builder, object value) { }

	// RVA: 0x6FD517C
	private static object BuildNotation_System(object builder, object value) { }

	// RVA: 0x6FD51B4
	private static object InitFacet(object builder, object value) { }

	// RVA: 0x6FD56C8
	private static object BuildFacet_Fixed(object builder, object value) { }

	// RVA: 0x6FD577C
	private static object BuildFacet_Value(object builder, object value) { }

	// RVA: 0x6FD57B4
	private static object InitIdentityConstraint(object builder, object value) { }

	// RVA: 0x6FD592C
	private static object BuildIdentityConstraint_Name(object builder, object value) { }

	// RVA: 0x6FD5964
	private static object BuildIdentityConstraint_Refer(object builder, object value) { }

	// RVA: 0x6FD5A90
	private static object InitSelector(object builder, object value) { }

	// RVA: 0x6FD5B58
	private static object BuildSelector_XPath(object builder, object value) { }

	// RVA: 0x6FD5B90
	private static object InitField(object builder, object value) { }

	// RVA: 0x6FD5C78
	private static object BuildField_XPath(object builder, object value) { }

	// RVA: 0x6FD5CB0
	private static object InitAnnotation(object builder, object value) { }

	// RVA: 0x6FD5EE8
	private static object InitAppinfo(object builder, object value) { }

	// RVA: 0x6FD5FB8
	private static object BuildAppinfo_Source(object builder, object value) { }

	// RVA: 0x6FD6044
	private static object EndAppinfo(object builder) { }

	// RVA: 0x6FD6080
	private static object InitDocumentation(object builder, object value) { }

	// RVA: 0x6FD6150
	private static object BuildDocumentation_Source(object builder, object value) { }

	// RVA: 0x6FD61D8
	private static object BuildDocumentation_XmlLang(object builder, object value) { }

	// RVA: 0x6FD6358
	private static object EndDocumentation(object builder) { }

	// RVA: 0x6FD116C
	private object AddAttribute(object value) { }

	// RVA: 0x6FD4798
	private object AddParticle(object particle) { }

	// RVA: 0x6FCE530
	private object GetNextState(object qname) { }

	// RVA: 0x6FCE9E8
	private object IsSkipableElement(object qname) { }

	// RVA: 0x6FD21C4
	private object SetMinOccurs(object particle, object value) { }

	// RVA: 0x6FD20CC
	private object SetMaxOccurs(object particle, object value) { }

	// RVA: 0x6FD1CA4
	private object ParseBoolean(object value, object attributeName) { }

	// RVA: 0x6FD0688
	private object ParseEnum(object value, object attributeName, object values) { }

	// RVA: 0x6FD1790
	private object ParseQName(object value, object attributeName) { }

	// RVA: 0x6FD0940
	private object ParseBlockFinalEnum(object value, object attributeName) { }

	// RVA: 0x6FD6040
	private static object ParseUriReference(object s) { }

	// RVA: 0x6FD6394
	private object SendValidationEvent(object code, object arg0, object arg1, object arg2) { }

	// RVA: 0x6FCEA18
	private object SendValidationEvent(object code, object msg) { }

	// RVA: 0x6FCF140
	private object SendValidationEvent(object code, object args, object severity) { }

	// RVA: 0x6FD6548
	private object SendValidationEvent(object e, object severity) { }

	// RVA: 0x6FD2D4C
	private object SendValidationEvent(object e) { }

	// RVA: 0x6FCE824
	private object RecordPosition() { }

	// RVA: 0x6FD6634
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal enum XsdDateTimeFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DateTime;
	public const object Time;
	public const object Date;
	public const object GYearMonth;
	public const object GYear;
	public const object GMonthDay;
	public const object GDay;
	public const object GMonth;
	public const object XdrDateTimeNoTz;
	public const object XdrDateTime;
	public const object XdrTimeNoTz;
	public const object AllXsd;
}

// Namespace: 
private enum DateTimeTypeCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DateTime;
	public const object Time;
	public const object Date;
	public const object GYearMonth;
	public const object GYear;
	public const object GMonthDay;
	public const object GDay;
	public const object GMonth;
	public const object XdrDateTime;
}

// Namespace: 
private enum XsdDateTimeKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unspecified;
	public const object Zulu;
	public const object LocalWestOfZulu;
	public const object LocalEastOfZulu;
}

// Namespace: 
private struct Parser
{

	// Fields
	public object typeCode; // 0xFFFFFFFFFFFFFFF8
	public object year; // 0xFFFFFFFFFFFFFFFC
	public object month; // 0x0
	public object day; // 0x4
	public object hour; // 0x8
	public object minute; // 0xC
	public object second; // 0x10
	public object fraction; // 0x14
	public object kind; // 0x18
	public object zoneHour; // 0x1C
	public object zoneMinute; // 0x20
	private object text; // 0x28
	private object length; // 0x30
	private static object Power10; // 0x0

	// Methods

	// RVA: 0x6FDB668
	public object Parse(object text, object kinds) { }

	// RVA: 0x6FE02B8
	private object ParseDate(object start) { }

	// RVA: 0x6FE0688
	private object ParseTimeAndZoneAndWhitespace(object start) { }

	// RVA: 0x6FE0AA4
	private object ParseTimeAndWhitespace(object start) { }

	// RVA: 0x6FE0D5C
	private object ParseTime(object start) { }

	// RVA: 0x6FE0770
	private object ParseZoneAndWhitespace(object start) { }

	// RVA: 0x6FE0B5C
	private object Parse4Dig(object start, object num) { }

	// RVA: 0x6FE0C98
	private object Parse2Dig(object start, object num) { }

	// RVA: 0x6FE062C
	private object ParseChar(object start, object ch) { }

	// RVA: 0x6FE02AC
	private static object Test(object left, object right) { }

	// RVA: 0x6FE1550
	private static object .cctor() { }

}

// Namespace: System.Xml.Schema
internal struct XsdDateTime
{

	// Fields
	private object dt; // 0xFFFFFFFFFFFFFFF8
	private object extra; // 0x0
	private static readonly object Lzyyyy; // 0x0
	private static readonly object Lzyyyy_; // 0xFFFFFFFFFFFFFFF4
	private static readonly object Lzyyyy_MM; // 0xFFFFFFFFFFFFFFF8
	private static readonly object Lzyyyy_MM_; // 0xFFFFFFFFFFFFFFFC
	private static readonly object Lzyyyy_MM_dd; // 0x0
	private static readonly object Lzyyyy_MM_ddT; // 0x4
	private static readonly object LzHH; // 0x8
	private static readonly object LzHH_; // 0xC
	private static readonly object LzHH_mm; // 0x10
	private static readonly object LzHH_mm_; // 0x14
	private static readonly object LzHH_mm_ss; // 0x18
	private static readonly object Lz_; // 0x1C
	private static readonly object Lz_zz; // 0x20
	private static readonly object Lz_zz_; // 0x24
	private static readonly object Lz_zz_zz; // 0x28
	private static readonly object Lz__; // 0x2C
	private static readonly object Lz__mm; // 0x30
	private static readonly object Lz__mm_; // 0x34
	private static readonly object Lz__mm__; // 0x38
	private static readonly object Lz__mm_dd; // 0x3C
	private static readonly object Lz___; // 0x40
	private static readonly object Lz___dd; // 0x44
	private static readonly object typeCodes; // 0x48

	// Properties
	private object InternalTypeCode { get; }
	private object InternalKind { get; }
	public object Year { get; }
	public object Month { get; }
	public object Day { get; }
	public object Hour { get; }
	public object Minute { get; }
	public object Second { get; }
	public object Fraction { get; }
	public object ZoneHour { get; }
	public object ZoneMinute { get; }

	// Methods

	// RVA: 0x6FDB3F0
	public object .ctor(object text, object kinds) { }

	// RVA: 0x6FDCA24
	private object .ctor(object parser) { }

	// RVA: 0x6FDC954
	private object InitiateXsdDateTime(object parser) { }

	// RVA: 0x6FDCCB8
	internal static object TryParse(object text, object kinds, object result) { }

	// RVA: 0x6FDCDC4
	public object .ctor(object dateTime, object kinds) { }

	// RVA: 0x6FDCFD0
	public object .ctor(object dateTimeOffset) { }

	// RVA: 0x6FDD04C
	public object .ctor(object dateTimeOffset, object kinds) { }

	// RVA: 0x6FDD264
	private object get_InternalTypeCode() { }

	// RVA: 0x6FDD274
	private object get_InternalKind() { }

	// RVA: 0x6FDD284
	public object get_Year() { }

	// RVA: 0x6FDD394
	public object get_Month() { }

	// RVA: 0x6FDD4A4
	public object get_Day() { }

	// RVA: 0x6FDD5B4
	public object get_Hour() { }

	// RVA: 0x6FDD6C4
	public object get_Minute() { }

	// RVA: 0x6FDD7D4
	public object get_Second() { }

	// RVA: 0x6FDD8E4
	public object get_Fraction() { }

	// RVA: 0x6FDDA0C
	public object get_ZoneHour() { }

	// RVA: 0x6FDDA1C
	public object get_ZoneMinute() { }

	// RVA: 0x6FDDA2C
	public static object op_Implicit(object xdt) { }

	// RVA: 0x6FDE130
	public static object op_Implicit(object xdt) { }

	// RVA: 0x6FDE60C
	public override object ToString() { }

	// RVA: 0x6FDF060
	private object PrintDate(object sb) { }

	// RVA: 0x6FDF3E0
	private object PrintTime(object sb) { }

	// RVA: 0x6FDF900
	private object PrintZone(object sb) { }

	// RVA: 0x6FDF814
	private object IntToCharArray(object text, object start, object value, object digits) { }

	// RVA: 0x6FDF890
	private object ShortToCharArray(object text, object start, object value) { }

	// RVA: 0x6FDFD14
	private static object .cctor() { }

}

// Namespace: 
private enum Parts
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object HasNone;
	public const object HasYears;
	public const object HasMonths;
	public const object HasDays;
	public const object HasHours;
	public const object HasMinutes;
	public const object HasSeconds;
}

// Namespace: 
public enum DurationType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Duration;
	public const object YearMonthDuration;
	public const object DayTimeDuration;
}

// Namespace: System.Xml.Schema
internal struct XsdDuration
{

	// Fields
	private object years; // 0xFFFFFFFFFFFFFFF8
	private object months; // 0xFFFFFFFFFFFFFFFC
	private object days; // 0x0
	private object hours; // 0x4
	private object minutes; // 0x8
	private object seconds; // 0xC
	private object nanoseconds; // 0x10

	// Properties
	public object IsNegative { get; }
	public object Years { get; }
	public object Months { get; }
	public object Days { get; }
	public object Hours { get; }
	public object Minutes { get; }
	public object Seconds { get; }
	public object Nanoseconds { get; }

	// Methods

	// RVA: 0x6FE15E8
	public object .ctor(object isNegative, object years, object months, object days, object hours, object minutes, object seconds, object nanoseconds) { }

	// RVA: 0x6FE1760
	public object .ctor(object timeSpan) { }

	// RVA: 0x6FE1890
	public object .ctor(object timeSpan, object durationType) { }

	// RVA: 0x6FE1BEC
	public object .ctor(object s) { }

	// RVA: 0x6FE1C68
	public object .ctor(object s, object durationType) { }

	// RVA: 0x6FE24A0
	public object get_IsNegative() { }

	// RVA: 0x6FE2538
	public object get_Years() { }

	// RVA: 0x6FE2548
	public object get_Months() { }

	// RVA: 0x6FE2558
	public object get_Days() { }

	// RVA: 0x6FE2568
	public object get_Hours() { }

	// RVA: 0x6FE2578
	public object get_Minutes() { }

	// RVA: 0x6FE2588
	public object get_Seconds() { }

	// RVA: 0x6FE2494
	public object get_Nanoseconds() { }

	// RVA: 0x6FE25A4
	public object ToTimeSpan() { }

	// RVA: 0x6FE25FC
	public object ToTimeSpan(object durationType) { }

	// RVA: 0x6FE2C30
	internal object TryToTimeSpan(object result) { }

	// RVA: 0x6FE26AC
	internal object TryToTimeSpan(object durationType, object result) { }

	// RVA: 0x6FE2C54
	public override object ToString() { }

	// RVA: 0x6FE2C5C
	internal object ToString(object durationType) { }

	// RVA: 0x6FE30E0
	internal static object TryParse(object s, object result) { }

	// RVA: 0x6FE1D64
	internal static object TryParse(object s, object durationType, object result) { }

	// RVA: 0x6FE30EC
	private static object TryParseDigits(object s, object offset, object eatDigits, object result, object numDigits) { }

}

// Namespace: System.Xml.Schema
internal sealed class XsdValidator
{

	// Fields
	private object startIDConstraint; // 0x74
	private object validationStack; // 0x78
	private object attPresence; // 0x80
	private object nsManager; // 0x88
	private object bManageNamespaces; // 0x90
	private object IDs; // 0x98
	private object idRefListHead; // 0xA0
	private object inlineSchemaParser; // 0xA8
	private object processContents; // 0xB0
	private static readonly object dtCDATA; // 0x0
	private static readonly object dtQName; // 0x8
	private static readonly object dtStringArray; // 0x10
	private object NsXmlNs; // 0xB8
	private object NsXs; // 0xC0
	private object NsXsi; // 0xC8
	private object XsiType; // 0xD0
	private object XsiNil; // 0xD8
	private object XsiSchemaLocation; // 0xE0
	private object XsiNoNamespaceSchemaLocation; // 0xE8
	private object XsdSchema; // 0xF0

	// Properties
	private object IsInlineSchemaStarted { get; }
	private object HasSchema { get; }
	public override object PreserveWhitespace { get; }
	private object HasIdentityConstraints { get; }

	// Methods

	// RVA: 0x6FE329C
	internal object .ctor(object validator) { }

	// RVA: 0x6FE374C
	internal object .ctor(object reader, object schemaCollection, object eventHandling) { }

	// RVA: 0x6FE32CC
	private object Init() { }

	// RVA: 0x6FE3894
	public override object Validate() { }

	// RVA: 0x6FE41A4
	public override object CompleteValidation() { }

	// RVA: 0x6FE39AC
	private object get_IsInlineSchemaStarted() { }

	// RVA: 0x6FE39BC
	private object ProcessInlineSchema() { }

	// RVA: 0x6FE3CA0
	private object ValidateElement() { }

	// RVA: 0x6FE42F4
	private object ValidateChildElement() { }

	// RVA: 0x6FE4630
	private object ProcessElement(object particle) { }

	// RVA: 0x6FE4B4C
	private object ProcessXsiAttributes(object xsiType, object xsiNil) { }

	// RVA: 0x6FE3EA8
	private object ValidateEndElement() { }

	// RVA: 0x6FE4A4C
	private object FastGetElementDecl(object particle) { }

	// RVA: 0x6FE569C
	private object ThoroughGetElementDecl(object elementDecl, object xsiType, object xsiNil) { }

	// RVA: 0x6FE5BA8
	private object ValidateStartElement() { }

	// RVA: 0x6FE65E4
	private object ValidateEndStartElement() { }

	// RVA: 0x6FE8BC4
	private object LoadSchemaFromLocation(object uri, object url) { }

	// RVA: 0x6FE6BA4
	private object LoadSchema(object uri, object url) { }

	// RVA: 0x6FE5B1C
	private object get_HasSchema() { }

	// RVA: 0x6FE921C
	public override object get_PreserveWhitespace() { }

	// RVA: 0x6FE926C
	private object ProcessTokenizedType(object ttype, object name) { }

	// RVA: 0x6FE6DB4
	private object CheckValue(object value, object attdef) { }

	// RVA: 0x6FE95EC
	internal object AddID(object name, object node) { }

	// RVA: 0x6FE969C
	public override object FindId(object name) { }

	// RVA: 0x6FE45E4
	public object IsXSDRoot(object localName, object ns) { }

	// RVA: 0x6FE377C
	private object Push(object elementName) { }

	// RVA: 0x6FE86BC
	private object Pop() { }

	// RVA: 0x6FE41A8
	private object CheckForwardRefs() { }

	// RVA: 0x6FE5B48
	private object ValidateStartElementIdentityConstraints() { }

	// RVA: 0x6FE7390
	private object get_HasIdentityConstraints() { }

	// RVA: 0x6FE96F8
	private object AddIdentityConstraints() { }

	// RVA: 0x6FE9C50
	private object ElementIdentityConstraints() { }

	// RVA: 0x6FE8828
	private object AttributeIdentityConstraints(object name, object ns, object obj, object sobj, object attdef) { }

	// RVA: 0x6FE879C
	private object UnWrapUnion(object typedValue) { }

	// RVA: 0x6FE73A0
	private object EndElementIdentityConstraints() { }

	// RVA: 0x6FEA184
	private static object .cctor() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class AbsoluteQuery
{

	// Methods

	// RVA: 0x6FEA240
	public object .ctor() { }

	// RVA: 0x6FEA290
	private object .ctor(object other) { }

	// RVA: 0x6FEA310
	public override object Evaluate(object context) { }

	// RVA: 0x6FEA3F0
	public override object Clone() { }

}

// Namespace: 
public enum AstType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Axis;
	public const object Operator;
	public const object Filter;
	public const object ConstantOperand;
	public const object Function;
	public const object Group;
	public const object Root;
	public const object Variable;
	public const object Error;
}

// Namespace: MS.Internal.Xml.XPath
internal abstract class AstNode
{

	// Properties
	public abstract object Type { get; }
	public abstract object ReturnType { get; }

	// Methods

	// RVA: -1
	public abstract object get_Type() { }

	// RVA: -1
	public abstract object get_ReturnType() { }

	// RVA: 0x6FEA470
	protected object .ctor() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class AttributeQuery
{

	// Fields
	private object _onAttribute; // 0x4C

	// Methods

	// RVA: 0x6FEA478
	public object .ctor(object qyParent, object Name, object Prefix, object Type) { }

	// RVA: 0x6FEA610
	private object .ctor(object other) { }

	// RVA: 0x6FEA708
	public override object Reset() { }

	// RVA: 0x6FEA7B4
	public override object Advance() { }

	// RVA: 0x6FEA930
	public override object Clone() { }

}

// Namespace: 
public enum AxisType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Ancestor;
	public const object AncestorOrSelf;
	public const object Attribute;
	public const object Child;
	public const object Descendant;
	public const object DescendantOrSelf;
	public const object Following;
	public const object FollowingSibling;
	public const object Namespace;
	public const object Parent;
	public const object Preceding;
	public const object PrecedingSibling;
	public const object Self;
	public const object None;
}

// Namespace: MS.Internal.Xml.XPath
internal class Axis
{

	// Fields
	private object _axisType; // 0x8
	private object _input; // 0x10
	private object _prefix; // 0x18
	private object _name; // 0x20
	private object _nodeType; // 0x28
	protected object abbrAxis; // 0x2C
	private object _urn; // 0x30

	// Properties
	public override object Type { get; }
	public override object ReturnType { get; }
	public object Input { get; set; }
	public object Prefix { get; }
	public object Name { get; }
	public object NodeType { get; }
	public object TypeOfAxis { get; }
	public object AbbrAxis { get; }
	public object Urn { get; set; }

	// Methods

	// RVA: 0x6FEA9F0
	public object .ctor(object axisType, object input, object prefix, object name, object nodetype) { }

	// RVA: 0x6FEAA8C
	public object .ctor(object axisType, object input) { }

	// RVA: 0x6FEAB4C
	public override object get_Type() { }

	// RVA: 0x6FEAB54
	public override object get_ReturnType() { }

	// RVA: 0x6FEAB5C
	public object get_Input() { }

	// RVA: 0x6FEAB64
	public object set_Input(object value) { }

	// RVA: 0x6FEAB6C
	public object get_Prefix() { }

	// RVA: 0x6FEAB74
	public object get_Name() { }

	// RVA: 0x6FEAB7C
	public object get_NodeType() { }

	// RVA: 0x6FEAB84
	public object get_TypeOfAxis() { }

	// RVA: 0x6FEAB8C
	public object get_AbbrAxis() { }

	// RVA: 0x6FEAB94
	public object get_Urn() { }

	// RVA: 0x6FEAB9C
	public object set_Urn(object value) { }

}

// Namespace: MS.Internal.Xml.XPath
internal abstract class BaseAxisQuery
{

	// Fields
	internal object qyInput; // 0x10
	private object _nameTest; // 0x18
	private object _name; // 0x20
	private object _prefix; // 0x28
	private object _nsUri; // 0x30
	private object _typeTest; // 0x38
	protected object currentNode; // 0x40
	protected object position; // 0x48

	// Properties
	protected object Name { get; }
	protected object Namespace { get; }
	protected object NameTest { get; }
	protected object TypeTest { get; }
	public override object CurrentPosition { get; }
	public override object Current { get; }
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FEABA4
	protected object .ctor(object qyInput) { }

	// RVA: 0x6FEA544
	protected object .ctor(object qyInput, object name, object prefix, object typeTest) { }

	// RVA: 0x6FEA690
	protected object .ctor(object other) { }

	// RVA: 0x6FEA760
	public override object Reset() { }

	// RVA: 0x6FEAC18
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FEACC0
	protected object get_Name() { }

	// RVA: 0x6FEACC8
	protected object get_Namespace() { }

	// RVA: 0x6FEACD0
	protected object get_NameTest() { }

	// RVA: 0x6FEACD8
	protected object get_TypeTest() { }

	// RVA: 0x6FEACE0
	public override object get_CurrentPosition() { }

	// RVA: 0x6FEACE8
	public override object get_Current() { }

	// RVA: 0x6FEACF0
	public virtual object matches(object e) { }

	// RVA: 0x6FEAEB0
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FEAF48
	public override object get_StaticType() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class BooleanExpr
{

	// Fields
	private object _opnd1; // 0x10
	private object _opnd2; // 0x18
	private object _isOr; // 0x20

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FEAF50
	public object .ctor(object op, object opnd1, object opnd2) { }

	// RVA: 0x6FEB0D8
	private object .ctor(object other) { }

	// RVA: 0x6FEB138
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FEB1DC
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FEB308
	public override object Clone() { }

	// RVA: 0x6FEB3A8
	public override object get_StaticType() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class BooleanFunctions
{

	// Fields
	private object _arg; // 0x10
	private object _funcType; // 0x18

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FEB09C
	public object .ctor(object funcType, object arg) { }

	// RVA: 0x6FEB3B0
	private object .ctor(object other) { }

	// RVA: 0x6FEB400
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FEB458
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FEBA3C
	internal static object toBoolean(object number) { }

	// RVA: 0x6FEBA5C
	internal static object toBoolean(object str) { }

	// RVA: 0x6FEB5EC
	internal object toBoolean(object nodeIterator) { }

	// RVA: 0x6FEBA84
	public override object get_StaticType() { }

	// RVA: 0x6FEB7F4
	private object Not(object nodeIterator) { }

	// RVA: 0x6FEB8C0
	private object Lang(object nodeIterator) { }

	// RVA: 0x6FEBA8C
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal abstract class CacheAxisQuery
{

	// Fields
	protected object outputBuffer; // 0x50

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }
	public override object Count { get; }
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FEBB1C
	public object .ctor(object qyInput, object name, object prefix, object typeTest) { }

	// RVA: 0x6FEBC40
	protected object .ctor(object other) { }

	// RVA: 0x6FEBD34
	public override object Reset() { }

	// RVA: 0x6FEBD3C
	public override object Evaluate(object context) { }

	// RVA: 0x6FEBE30
	public override object Advance() { }

	// RVA: 0x6FEBEC0
	public override object get_Current() { }

	// RVA: 0x6FEBF38
	public override object get_CurrentPosition() { }

	// RVA: 0x6FEBF40
	public override object get_Count() { }

	// RVA: 0x6FEBF94
	public override object get_Properties() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class CacheChildrenQuery
{

	// Fields
	private object _nextInput; // 0x58
	private object _elementStk; // 0x60
	private object _positionStk; // 0x68
	private object _needInput; // 0x70

	// Methods

	// RVA: 0x6FEBF9C
	public object .ctor(object qyInput, object name, object prefix, object type) { }

	// RVA: 0x6FEC1E0
	private object .ctor(object other) { }

	// RVA: 0x6FEC398
	public override object Reset() { }

	// RVA: 0x6FEC568
	public override object Advance() { }

	// RVA: 0x6FEC874
	private object DecideNextNode() { }

	// RVA: 0x6FEC7D4
	private object GetNextInput() { }

	// RVA: 0x6FECA00
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal abstract class CacheOutputQuery
{

	// Fields
	internal object input; // 0x10
	protected object outputBuffer; // 0x18

	// Properties
	public override object Current { get; }
	public override object StaticType { get; }
	public override object CurrentPosition { get; }
	public override object Count { get; }
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FECA64
	public object .ctor(object input) { }

	// RVA: 0x6FECAFC
	protected object .ctor(object other) { }

	// RVA: 0x6FECBC0
	public override object Reset() { }

	// RVA: 0x6FECBC8
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FECC20
	public override object Evaluate(object context) { }

	// RVA: 0x6FECCE0
	public override object Advance() { }

	// RVA: 0x6FECD70
	public override object get_Current() { }

	// RVA: 0x6FECDE8
	public override object get_StaticType() { }

	// RVA: 0x6FECDF0
	public override object get_CurrentPosition() { }

	// RVA: 0x6FECDF8
	public override object get_Count() { }

	// RVA: 0x6FECE4C
	public override object get_Properties() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class ChildrenQuery
{

	// Fields
	private object _iterator; // 0x50

	// Methods

	// RVA: 0x6FEC09C
	public object .ctor(object qyInput, object name, object prefix, object type) { }

	// RVA: 0x6FEC2B8
	protected object .ctor(object other) { }

	// RVA: 0x6FEC4C0
	public override object Reset() { }

	// RVA: 0x6FECE54
	public override object Advance() { }

	// RVA: 0x6FED0BC
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class ClonableStack<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private object .ctor(object collection) { }

	// RVA: -1
	public object Push(object value) { }

	// RVA: -1
	public object Pop() { }

	// RVA: -1
	public object Peek() { }

	// RVA: -1
	public object Clone() { }

}

// Namespace: 
private class UndefinedXsltContext
{

	// Fields
	private object _nsResolver; // 0x48

	// Properties
	public override object DefaultNamespace { get; }
	public override object Whitespace { get; }

	// Methods

	// RVA: 0x6FED300
	public object .ctor(object nsResolver) { }

	// RVA: 0x6FED330
	public override object get_DefaultNamespace() { }

	// RVA: 0x6FED37C
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x6FED4E8
	public override object ResolveVariable(object prefix, object name) { }

	// RVA: 0x6FED524
	public override object ResolveFunction(object prefix, object name, object ArgTypes) { }

	// RVA: 0x6FED560
	public override object get_Whitespace() { }

	// RVA: 0x6FED568
	public override object PreserveWhitespace(object node) { }

}

// Namespace: MS.Internal.Xml.XPath
internal class CompiledXpathExpr
{

	// Fields
	private object _query; // 0x8
	private object _expr; // 0x10
	private object _needContext; // 0x18

	// Properties
	internal object QueryTree { get; }

	// Methods

	// RVA: 0x6FED120
	internal object .ctor(object query, object expression, object needContext) { }

	// RVA: 0x6FED160
	internal object get_QueryTree() { }

	// RVA: 0x6FED1B0
	public override object SetContext(object nsResolver) { }

}

// Namespace: MS.Internal.Xml.XPath
internal class ContextQuery
{

	// Fields
	protected object contextNode; // 0x10

	// Properties
	public override object Current { get; }
	public override object StaticType { get; }
	public override object CurrentPosition { get; }
	public override object Count { get; }
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FEA268
	public object .ctor() { }

	// RVA: 0x6FEA2D0
	protected object .ctor(object other) { }

	// RVA: 0x6FED570
	public override object Reset() { }

	// RVA: 0x6FED578
	public override object get_Current() { }

	// RVA: 0x6FED580
	public override object Evaluate(object context) { }

	// RVA: 0x6FED5E0
	public override object Advance() { }

	// RVA: 0x6FED600
	public override object Clone() { }

	// RVA: 0x6FED680
	public override object get_StaticType() { }

	// RVA: 0x6FED688
	public override object get_CurrentPosition() { }

	// RVA: 0x6FED690
	public override object get_Count() { }

	// RVA: 0x6FED698
	public override object get_Properties() { }

}

// Namespace: MS.Internal.Xml.XPath
internal abstract class DescendantBaseQuery
{

	// Fields
	protected object matchSelf; // 0x4C
	protected object abbrAxis; // 0x4D

	// Methods

	// RVA: 0x6FED6A0
	public object .ctor(object qyParent, object Name, object Prefix, object Type, object matchSelf, object abbrAxis) { }

	// RVA: 0x6FED784
	public object .ctor(object other) { }

}

// Namespace: MS.Internal.Xml.XPath
internal class DescendantQuery
{

	// Fields
	private object _nodeIterator; // 0x50

	// Methods

	// RVA: 0x6FED804
	internal object .ctor(object qyParent, object Name, object Prefix, object Type, object matchSelf, object abbrAxis) { }

	// RVA: 0x6FED8E8
	public object .ctor(object other) { }

	// RVA: 0x6FED978
	public override object Reset() { }

	// RVA: 0x6FED9D0
	public override object Advance() { }

	// RVA: 0x6FEDD98
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class DescendantOverDescendantQuery
{

	// Fields
	private object _level; // 0x50

	// Methods

	// RVA: 0x6FEDE68
	public object .ctor(object qyParent, object matchSelf, object name, object prefix, object typeTest, object abbrAxis) { }

	// RVA: 0x6FEDF4C
	private object .ctor(object other) { }

	// RVA: 0x6FEDFD4
	public override object Reset() { }

	// RVA: 0x6FEE02C
	public override object Advance() { }

	// RVA: 0x6FEE210
	private object MoveToFirstChild() { }

	// RVA: 0x6FEE278
	private object MoveUpUntilNext() { }

	// RVA: 0x6FEE330
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class DocumentOrderQuery
{

	// Methods

	// RVA: 0x6FEE3F8
	public object .ctor(object qyParent) { }

	// RVA: 0x6FEE490
	private object .ctor(object other) { }

	// RVA: 0x6FEE494
	public override object Evaluate(object context) { }

	// RVA: 0x6FEE510
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class EmptyQuery
{

	// Properties
	public override object CurrentPosition { get; }
	public override object Count { get; }
	public override object Properties { get; }
	public override object StaticType { get; }
	public override object Current { get; }

	// Methods

	// RVA: 0x6FEE574
	public override object Advance() { }

	// RVA: 0x6FEE57C
	public override object Clone() { }

	// RVA: 0x6FEE580
	public override object Evaluate(object context) { }

	// RVA: 0x6FEE584
	public override object get_CurrentPosition() { }

	// RVA: 0x6FEE58C
	public override object get_Count() { }

	// RVA: 0x6FEE594
	public override object get_Properties() { }

	// RVA: 0x6FEE59C
	public override object get_StaticType() { }

	// RVA: 0x6FEE5A4
	public override object Reset() { }

	// RVA: 0x6FEE5A8
	public override object get_Current() { }

	// RVA: 0x6FEE5B0
	public object .ctor() { }

}

// Namespace: MS.Internal.Xml.XPath
internal abstract class ExtensionQuery
{

	// Fields
	protected object prefix; // 0x10
	protected object name; // 0x18
	protected object xsltContext; // 0x20
	private object _queryIterator; // 0x28

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }
	protected object QName { get; }
	public override object Count { get; }
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FEE5B8
	public object .ctor(object prefix, object name) { }

	// RVA: 0x6FEE5F0
	protected object .ctor(object other) { }

	// RVA: 0x6FEE6E8
	public override object Reset() { }

	// RVA: 0x6FEE734
	public override object get_Current() { }

	// RVA: 0x6FEE80C
	public override object Advance() { }

	// RVA: 0x6FEE8CC
	public override object get_CurrentPosition() { }

	// RVA: 0x6FEE91C
	protected object ProcessResult(object value) { }

	// RVA: 0x6FEEDBC
	protected object get_QName() { }

	// RVA: 0x6FEEE38
	public override object get_Count() { }

	// RVA: 0x6FEEE88
	public override object get_StaticType() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class Filter
{

	// Fields
	private object _input; // 0x8
	private object _condition; // 0x10

	// Properties
	public override object Type { get; }
	public override object ReturnType { get; }
	public object Input { get; }
	public object Condition { get; }

	// Methods

	// RVA: 0x6FEEE90
	public object .ctor(object input, object condition) { }

	// RVA: 0x6FEEEC8
	public override object get_Type() { }

	// RVA: 0x6FEEED0
	public override object get_ReturnType() { }

	// RVA: 0x6FEEED8
	public object get_Input() { }

	// RVA: 0x6FEEEE0
	public object get_Condition() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class FilterQuery
{

	// Fields
	private object _cond; // 0x50
	private object _noPosition; // 0x58

	// Properties
	public object Condition { get; }
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FEEEE8
	public object .ctor(object qyParent, object cond, object noPosition) { }

	// RVA: 0x6FEEF74
	private object .ctor(object other) { }

	// RVA: 0x6FEF004
	public override object Reset() { }

	// RVA: 0x6FEF088
	public object get_Condition() { }

	// RVA: 0x6FEF090
	public override object SetXsltContext(object input) { }

	// RVA: 0x6FEF258
	public override object Advance() { }

	// RVA: 0x6FEF2D4
	internal object EvaluatePredicate() { }

	// RVA: 0x6FEF518
	public override object get_Properties() { }

	// RVA: 0x6FEF574
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class FollSiblingQuery
{

	// Fields
	private object _elementStk; // 0x50
	private object _parentStk; // 0x58
	private object _nextInput; // 0x60

	// Methods

	// RVA: 0x6FEF644
	public object .ctor(object qyInput, object name, object prefix, object type) { }

	// RVA: 0x6FEF7A4
	private object .ctor(object other) { }

	// RVA: 0x6FEF8D4
	public override object Reset() { }

	// RVA: 0x6FEF9B4
	private object Visited(object nav) { }

	// RVA: 0x6FEFBC0
	private object FetchInput() { }

	// RVA: 0x6FEFC60
	public override object Advance() { }

	// RVA: 0x6FEFFA0
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class FollowingQuery
{

	// Fields
	private object _input; // 0x50
	private object _iterator; // 0x58

	// Methods

	// RVA: 0x6FF0004
	public object .ctor(object qyInput, object name, object prefix, object typeTest) { }

	// RVA: 0x6FF00D0
	private object .ctor(object other) { }

	// RVA: 0x6FF0168
	public override object Reset() { }

	// RVA: 0x6FF01C0
	public override object Advance() { }

	// RVA: 0x6FF05F8
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class ForwardPositionQuery
{

	// Methods

	// RVA: 0x6FF065C
	public object .ctor(object input) { }

	// RVA: 0x6FF06F4
	protected object .ctor(object other) { }

	// RVA: 0x6FF06F8
	public override object Evaluate(object context) { }

	// RVA: 0x6FF08C4
	public override object Clone() { }

}

// Namespace: 
public enum FunctionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FuncLast;
	public const object FuncPosition;
	public const object FuncCount;
	public const object FuncID;
	public const object FuncLocalName;
	public const object FuncNameSpaceUri;
	public const object FuncName;
	public const object FuncString;
	public const object FuncBoolean;
	public const object FuncNumber;
	public const object FuncTrue;
	public const object FuncFalse;
	public const object FuncNot;
	public const object FuncConcat;
	public const object FuncStartsWith;
	public const object FuncContains;
	public const object FuncSubstringBefore;
	public const object FuncSubstringAfter;
	public const object FuncSubstring;
	public const object FuncStringLength;
	public const object FuncNormalize;
	public const object FuncTranslate;
	public const object FuncLang;
	public const object FuncSum;
	public const object FuncFloor;
	public const object FuncCeiling;
	public const object FuncRound;
	public const object FuncUserDefined;
}

// Namespace: MS.Internal.Xml.XPath
internal class Function
{

	// Fields
	private object _functionType; // 0x8
	private object _argumentList; // 0x10
	private object _name; // 0x18
	private object _prefix; // 0x20
	internal static object ReturnTypes; // 0x0

	// Properties
	public override object Type { get; }
	public override object ReturnType { get; }
	public object TypeOfFunction { get; }
	public object ArgumentList { get; }
	public object Prefix { get; }
	public object Name { get; }

	// Methods

	// RVA: 0x6FF0928
	public object .ctor(object ftype, object argumentList) { }

	// RVA: 0x6FF09C4
	public object .ctor(object prefix, object name, object argumentList) { }

	// RVA: 0x6FF0A74
	public object .ctor(object ftype, object arg) { }

	// RVA: 0x6FF0BF0
	public override object get_Type() { }

	// RVA: 0x6FF0BF8
	public override object get_ReturnType() { }

	// RVA: 0x6FF0CA4
	public object get_TypeOfFunction() { }

	// RVA: 0x6FF0CAC
	public object get_ArgumentList() { }

	// RVA: 0x6FF0CB4
	public object get_Prefix() { }

	// RVA: 0x6FF0CBC
	public object get_Name() { }

	// RVA: 0x6FF0CC4
	private static object .cctor() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class FunctionQuery
{

	// Fields
	private object _args; // 0x30
	private object _function; // 0x38

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FF0D5C
	public object .ctor(object prefix, object name, object args) { }

	// RVA: 0x6FF0D9C
	private object .ctor(object other) { }

	// RVA: 0x6FF0FE0
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FF16A4
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FF1D10
	public override object get_StaticType() { }

	// RVA: 0x6FF1DF4
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class Group
{

	// Fields
	private object _groupNode; // 0x8

	// Properties
	public override object Type { get; }
	public override object ReturnType { get; }
	public object GroupNode { get; }

	// Methods

	// RVA: 0x6FF1E58
	public object .ctor(object groupNode) { }

	// RVA: 0x6FF1E84
	public override object get_Type() { }

	// RVA: 0x6FF1E8C
	public override object get_ReturnType() { }

	// RVA: 0x6FF1E94
	public object get_GroupNode() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class GroupQuery
{

	// Properties
	public override object StaticType { get; }
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FF1E9C
	public object .ctor(object qy) { }

	// RVA: 0x6FF1F10
	private object .ctor(object other) { }

	// RVA: 0x6FF1F88
	public override object Advance() { }

	// RVA: 0x6FF1FF4
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FF204C
	public override object Clone() { }

	// RVA: 0x6FF2104
	public override object get_StaticType() { }

	// RVA: 0x6FF2154
	public override object get_Properties() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class IDQuery
{

	// Methods

	// RVA: 0x6FF215C
	public object .ctor(object arg) { }

	// RVA: 0x6FF21F4
	private object .ctor(object other) { }

	// RVA: 0x6FF21F8
	public override object Evaluate(object context) { }

	// RVA: 0x6FF2520
	private object ProcessIds(object contextNode, object val) { }

	// RVA: 0x6FF264C
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class IteratorFilter
{

	// Fields
	private object _innerIterator; // 0x10
	private object _name; // 0x18
	private object _position; // 0x20

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }

	// Methods

	// RVA: 0x6FED084
	internal object .ctor(object innerIterator, object name) { }

	// RVA: 0x6FF26B0
	private object .ctor(object it) { }

	// RVA: 0x6FF2738
	public override object Clone() { }

	// RVA: 0x6FF27F4
	public override object get_Current() { }

	// RVA: 0x6FF2840
	public override object get_CurrentPosition() { }

	// RVA: 0x6FF2848
	public override object MoveNext() { }

}

// Namespace: 
private sealed class cmpXslt
{

	// Methods

	// RVA: 0x6FF7740
	public object .ctor(object object, object method) { }

	// RVA: 0x6FF7874
	public virtual object Invoke(object op, object val1, object val2) { }

}

// Namespace: 
private struct NodeSet
{

	// Fields
	private object _opnd; // 0xFFFFFFFFFFFFFFF8
	private object _current; // 0x0

	// Properties
	public object Value { get; }

	// Methods

	// RVA: 0x6FF30E8
	public object .ctor(object opnd) { }

	// RVA: 0x6FF31B0
	public object MoveNext() { }

	// RVA: 0x6FF3260
	public object Reset() { }

	// RVA: 0x6FF3214
	public object get_Value() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class LogicalExpr
{

	// Fields
	private object _op; // 0xC
	private object _opnd1; // 0x10
	private object _opnd2; // 0x18
	private static readonly object s_CompXsltE; // 0x0
	private static readonly object s_CompXsltO; // 0x8

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FF294C
	public object .ctor(object op, object opnd1, object opnd2) { }

	// RVA: 0x6FF298C
	private object .ctor(object other) { }

	// RVA: 0x6FF29EC
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FF2A90
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FF2E88
	private static object cmpQueryQueryE(object op, object val1, object val2) { }

	// RVA: 0x6FF32AC
	private static object cmpQueryQueryO(object op, object val1, object val2) { }

	// RVA: 0x6FF372C
	private static object cmpQueryNumber(object op, object val1, object val2) { }

	// RVA: 0x6FF39A0
	private static object cmpQueryStringE(object op, object val1, object val2) { }

	// RVA: 0x6FF3B84
	private static object cmpQueryStringO(object op, object val1, object val2) { }

	// RVA: 0x6FF3E50
	private static object cmpRtfQueryE(object op, object val1, object val2) { }

	// RVA: 0x6FF4114
	private static object cmpRtfQueryO(object op, object val1, object val2) { }

	// RVA: 0x6FF43F4
	private static object cmpQueryBoolE(object op, object val1, object val2) { }

	// RVA: 0x6FF4578
	private static object cmpQueryBoolO(object op, object val1, object val2) { }

	// RVA: 0x6FF4564
	private static object cmpBoolBoolE(object op, object n1, object n2) { }

	// RVA: 0x6FF479C
	private static object cmpBoolBoolE(object op, object val1, object val2) { }

	// RVA: 0x6FF4890
	private static object cmpBoolBoolO(object op, object val1, object val2) { }

	// RVA: 0x6FF4A2C
	private static object cmpBoolNumberE(object op, object val1, object val2) { }

	// RVA: 0x6FF4B54
	private static object cmpBoolNumberO(object op, object val1, object val2) { }

	// RVA: 0x6FF4CF4
	private static object cmpBoolStringE(object op, object val1, object val2) { }

	// RVA: 0x6FF4DFC
	private static object cmpRtfBoolE(object op, object val1, object val2) { }

	// RVA: 0x6FF4F90
	private static object cmpBoolStringO(object op, object val1, object val2) { }

	// RVA: 0x6FF5194
	private static object cmpRtfBoolO(object op, object val1, object val2) { }

	// RVA: 0x6FF36D0
	private static object cmpNumberNumber(object op, object n1, object n2) { }

	// RVA: 0x6FF3E0C
	private static object cmpNumberNumberO(object op, object n1, object n2) { }

	// RVA: 0x6FF5410
	private static object cmpNumberNumber(object op, object val1, object val2) { }

	// RVA: 0x6FF55D4
	private static object cmpStringNumber(object op, object val1, object val2) { }

	// RVA: 0x6FF5810
	private static object cmpRtfNumber(object op, object val1, object val2) { }

	// RVA: 0x6FF3B4C
	private static object cmpStringStringE(object op, object n1, object n2) { }

	// RVA: 0x6FF5AA4
	private static object cmpStringStringE(object op, object val1, object val2) { }

	// RVA: 0x6FF5B74
	private static object cmpRtfStringE(object op, object val1, object val2) { }

	// RVA: 0x6FF5CD0
	private static object cmpRtfRtfE(object op, object val1, object val2) { }

	// RVA: 0x6FF5E7C
	private static object cmpStringStringO(object op, object val1, object val2) { }

	// RVA: 0x6FF6084
	private static object cmpRtfStringO(object op, object val1, object val2) { }

	// RVA: 0x6FF6330
	private static object cmpRtfRtfO(object op, object val1, object val2) { }

	// RVA: 0x6FF65F8
	public override object Clone() { }

	// RVA: 0x6FF4070
	private static object Rtf(object o) { }

	// RVA: 0x6FF6698
	public override object get_StaticType() { }

	// RVA: 0x6FF66A0
	private static object .cctor() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class MergeFilterQuery
{

	// Fields
	private object _child; // 0x20

	// Methods

	// RVA: 0x6FF7A88
	public object .ctor(object input, object child) { }

	// RVA: 0x6FF7B24
	private object .ctor(object other) { }

	// RVA: 0x6FF7B68
	public override object SetXsltContext(object xsltContext) { }

	// RVA: 0x6FF7C0C
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FF7D14
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class NamespaceQuery
{

	// Fields
	private object _onNamespace; // 0x4C

	// Methods

	// RVA: 0x6FF7D98
	public object .ctor(object qyParent, object Name, object Prefix, object Type) { }

	// RVA: 0x6FF7E64
	private object .ctor(object other) { }

	// RVA: 0x6FF7EE4
	public override object Reset() { }

	// RVA: 0x6FF7F3C
	public override object Advance() { }

	// RVA: 0x6FF8070
	public override object matches(object e) { }

	// RVA: 0x6FF8150
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class NodeFunctions
{

	// Fields
	private object _arg; // 0x10
	private object _funcType; // 0x18
	private object _xsltContext; // 0x20

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FF8210
	public object .ctor(object funcType, object arg) { }

	// RVA: 0x6FF824C
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FF82FC
	private object EvaluateArg(object context) { }

	// RVA: 0x6FF83D0
	public override object Evaluate(object context) { }

	// RVA: 0x6FF8774
	public override object get_StaticType() { }

	// RVA: 0x6FF8820
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class NumberFunctions
{

	// Fields
	private object _arg; // 0x10
	private object _ftype; // 0x18

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FF88A8
	public object .ctor(object ftype, object arg) { }

	// RVA: 0x6FF88E4
	private object .ctor(object other) { }

	// RVA: 0x6FF8934
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FF4788
	internal static object Number(object arg) { }

	// RVA: 0x6FF3648
	internal static object Number(object arg) { }

	// RVA: 0x6FF898C
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FF8A64
	private object Number(object nodeIterator) { }

	// RVA: 0x6FF8E08
	private object Sum(object nodeIterator) { }

	// RVA: 0x6FF8F64
	private object Floor(object nodeIterator) { }

	// RVA: 0x6FF905C
	private object Ceiling(object nodeIterator) { }

	// RVA: 0x6FF9154
	private object Round(object nodeIterator) { }

	// RVA: 0x6FF920C
	public override object get_StaticType() { }

	// RVA: 0x6FF9214
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class NumericExpr
{

	// Fields
	private object _op; // 0xC
	private object _opnd1; // 0x10
	private object _opnd2; // 0x18

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FF92A4
	public object .ctor(object op, object opnd1, object opnd2) { }

	// RVA: 0x6FF93D8
	private object .ctor(object other) { }

	// RVA: 0x6FF9438
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FF94DC
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FF967C
	private static object GetValue(object op, object n1, object n2) { }

	// RVA: 0x6FF96E4
	public override object get_StaticType() { }

	// RVA: 0x6FF96EC
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class Operand
{

	// Fields
	private object _type; // 0x8
	private object _val; // 0x10

	// Properties
	public override object Type { get; }
	public override object ReturnType { get; }
	public object OperandValue { get; }

	// Methods

	// RVA: 0x6FF978C
	public object .ctor(object val) { }

	// RVA: 0x6FF97C0
	public object .ctor(object val) { }

	// RVA: 0x6FF9844
	public override object get_Type() { }

	// RVA: 0x6FF984C
	public override object get_ReturnType() { }

	// RVA: 0x6FF9854
	public object get_OperandValue() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class OperandQuery
{

	// Fields
	internal object val; // 0x10

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FF985C
	public object .ctor(object val) { }

	// RVA: 0x6FF9888
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x6FF9890
	public override object get_StaticType() { }

	// RVA: 0x6FF989C
	public override object Clone() { }

}

// Namespace: 
public enum Op
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object INVALID;
	public const object OR;
	public const object AND;
	public const object EQ;
	public const object NE;
	public const object LT;
	public const object LE;
	public const object GT;
	public const object GE;
	public const object PLUS;
	public const object MINUS;
	public const object MUL;
	public const object DIV;
	public const object MOD;
	public const object UNION;
}

// Namespace: MS.Internal.Xml.XPath
internal class Operator
{

	// Fields
	private static object s_invertOp; // 0x0
	private object _opType; // 0x8
	private object _opnd1; // 0x10
	private object _opnd2; // 0x18

	// Properties
	public override object Type { get; }
	public override object ReturnType { get; }
	public object OperatorType { get; }
	public object Operand1 { get; }
	public object Operand2 { get; }

	// Methods

	// RVA: 0x6FF2DE0
	public static object InvertOperator(object op) { }

	// RVA: 0x6FF98A0
	public object .ctor(object op, object opnd1, object opnd2) { }

	// RVA: 0x6FF98E0
	public override object get_Type() { }

	// RVA: 0x6FF98E8
	public override object get_ReturnType() { }

	// RVA: 0x6FF9908
	public object get_OperatorType() { }

	// RVA: 0x6FF9910
	public object get_Operand1() { }

	// RVA: 0x6FF9918
	public object get_Operand2() { }

	// RVA: 0x6FF9920
	private static object .cctor() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class ParentQuery
{

	// Methods

	// RVA: 0x6FF99B8
	public object .ctor(object qyInput, object Name, object Prefix, object Type) { }

	// RVA: 0x6FF99BC
	private object .ctor(object other) { }

	// RVA: 0x6FF99C0
	public override object Evaluate(object context) { }

	// RVA: 0x6FF9AE0
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class PreSiblingQuery
{

	// Properties
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FF9B44
	public object .ctor(object qyInput, object name, object prefix, object typeTest) { }

	// RVA: 0x6FF9B48
	protected object .ctor(object other) { }

	// RVA: 0x6FF9B4C
	private static object NotVisited(object nav, object parentStk) { }

	// RVA: 0x6FF9D78
	public override object Evaluate(object context) { }

	// RVA: 0x6FFA15C
	public override object Clone() { }

	// RVA: 0x6FFA1C0
	public override object get_Properties() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class PrecedingQuery
{

	// Fields
	private object _workIterator; // 0x50
	private object _ancestorStk; // 0x58

	// Properties
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FFA1C8
	public object .ctor(object qyInput, object name, object prefix, object typeTest) { }

	// RVA: 0x6FFA2E8
	private object .ctor(object other) { }

	// RVA: 0x6FFA3C8
	public override object Reset() { }

	// RVA: 0x6FFA470
	public override object Advance() { }

	// RVA: 0x6FFA8D8
	public override object Clone() { }

	// RVA: 0x6FFA93C
	public override object get_Properties() { }

}

// Namespace: MS.Internal.Xml.XPath
internal enum QueryProps
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Position;
	public const object Count;
	public const object Cached;
	public const object Reverse;
	public const object Merge;
}

// Namespace: MS.Internal.Xml.XPath
internal abstract class Query
{

	// Properties
	public override object Count { get; }
	public abstract object StaticType { get; }
	public virtual object Properties { get; }

	// Methods

	// RVA: 0x6FFA958
	public object .ctor() { }

	// RVA: 0x6FFA9B0
	protected object .ctor(object other) { }

	// RVA: 0x6FFAA30
	public override object MoveNext() { }

	// RVA: 0x6FFAA80
	public override object get_Count() { }

	// RVA: 0x6FFABA0
	public virtual object SetXsltContext(object context) { }

	// RVA: -1
	public abstract object Evaluate(object nodeIterator) { }

	// RVA: -1
	public abstract object Advance() { }

	// RVA: -1
	public abstract object get_StaticType() { }

	// RVA: 0x6FFABA4
	public virtual object get_Properties() { }

	// RVA: 0x6FFABAC
	public static object Clone(object input) { }

	// RVA: 0x6FFAC5C
	protected static object Clone(object input) { }

	// RVA: 0x6FFACA4
	protected static object Clone(object input) { }

	// RVA: 0x6FFACF0
	public static object Insert(object buffer, object nav) { }

	// RVA: 0x6FFB184
	private static object GetMedian(object l, object r) { }

	// RVA: 0x6FFAF88
	public static object CompareNodes(object l, object r) { }

	// RVA: 0x6FFB190
	protected object GetXPathType(object value) { }

}

// Namespace: 
private enum Flags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object SmartDesc;
	public const object PosFilter;
	public const object Filter;
}

// Namespace: 
private enum Props
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object PosFilter;
	public const object HasPosition;
	public const object HasLast;
	public const object NonFlat;
}

// Namespace: MS.Internal.Xml.XPath
internal sealed class QueryBuilder
{

	// Fields
	private object _query; // 0x8
	private object _allowVar; // 0x10
	private object _allowKey; // 0x11
	private object _allowCurrent; // 0x12
	private object _needContext; // 0x13
	private object _firstInput; // 0x18
	private object _parseDepth; // 0x20

	// Methods

	// RVA: 0x6FFB2AC
	private object Reset() { }

	// RVA: 0x6FFB2B8
	private object ProcessAxis(object root, object flags, object props) { }

	// RVA: 0x6FFBE70
	private static object CanBeNumber(object q) { }

	// RVA: 0x6FFBF0C
	private object ProcessFilter(object root, object flags, object props) { }

	// RVA: 0x6FFC49C
	private object ProcessOperator(object root, object props) { }

	// RVA: 0x6FFC6B0
	private object ProcessVariable(object root) { }

	// RVA: 0x6FFC790
	private object ProcessFunction(object root, object props) { }

	// RVA: 0x6FFCD08
	private object ProcessArguments(object args, object props) { }

	// RVA: 0x6FFBA2C
	private object ProcessNode(object root, object flags, object props) { }

	// RVA: 0x6FFCFA0
	private object Build(object root, object query) { }

	// RVA: 0x6FFCFD4
	internal object Build(object query, object allowVar, object allowKey) { }

	// RVA: 0x6FFD1D4
	internal object Build(object query, object needContext) { }

	// RVA: 0x6FFD28C
	public object .ctor() { }

}

// Namespace: MS.Internal.Xml.XPath
internal abstract class ResetableIterator
{

	// Properties
	public abstract override object CurrentPosition { get; }

	// Methods

	// RVA: 0x6FFA984
	public object .ctor() { }

	// RVA: 0x6FFA9F0
	protected object .ctor(object other) { }

	// RVA: 0x6FFD294
	protected object ResetCount() { }

	// RVA: -1
	public abstract object Reset() { }

	// RVA: -1
	public abstract override object get_CurrentPosition() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class ReversePositionQuery
{

	// Properties
	public override object CurrentPosition { get; }
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FFC494
	public object .ctor(object input) { }

	// RVA: 0x6FFD2A0
	private object .ctor(object other) { }

	// RVA: 0x6FFD2A8
	public override object Clone() { }

	// RVA: 0x6FFD310
	public override object get_CurrentPosition() { }

	// RVA: 0x6FFD370
	public override object get_Properties() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class Root
{

	// Properties
	public override object Type { get; }
	public override object ReturnType { get; }

	// Methods

	// RVA: 0x6FFD38C
	public object .ctor() { }

	// RVA: 0x6FFD394
	public override object get_Type() { }

	// RVA: 0x6FFD39C
	public override object get_ReturnType() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class StringFunctions
{

	// Fields
	private object _funcType; // 0xC
	private object _argList; // 0x10
	private static readonly object s_compareInfo; // 0x0

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FFCF60
	public object .ctor(object funcType, object argList) { }

	// RVA: 0x6FFD3D0
	private object .ctor(object other) { }

	// RVA: 0x6FFD6E4
	public override object SetXsltContext(object context) { }

	// RVA: 0x6FFD8F0
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x700013C
	internal static object toString(object num) { }

	// RVA: 0x70001A4
	internal static object toString(object b) { }

	// RVA: 0x6FFDB00
	private object toString(object nodeIterator) { }

	// RVA: 0x7000210
	public override object get_StaticType() { }

	// RVA: 0x6FFE094
	private object Concat(object nodeIterator) { }

	// RVA: 0x6FFE354
	private object StartsWith(object nodeIterator) { }

	// RVA: 0x6FFE648
	private object Contains(object nodeIterator) { }

	// RVA: 0x6FFE950
	private object SubstringBefore(object nodeIterator) { }

	// RVA: 0x6FFECC8
	private object SubstringAfter(object nodeIterator) { }

	// RVA: 0x6FFF03C
	private object Substring(object nodeIterator) { }

	// RVA: 0x6FFF5E4
	private object StringLength(object nodeIterator) { }

	// RVA: 0x6FFF8A0
	private object Normalize(object nodeIterator) { }

	// RVA: 0x6FFFC40
	private object Translate(object nodeIterator) { }

	// RVA: 0x7000238
	public override object Clone() { }

	// RVA: 0x700029C
	private static object .cctor() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class UnionExpr
{

	// Fields
	internal object qy1; // 0x10
	internal object qy2; // 0x18
	private object _advance1; // 0x20
	private object _advance2; // 0x21
	private object _currentNode; // 0x28
	private object _nextNode; // 0x30

	// Properties
	public override object StaticType { get; }
	public override object Current { get; }
	public override object CurrentPosition { get; }

	// Methods

	// RVA: 0x6FFC668
	public object .ctor(object query1, object query2) { }

	// RVA: 0x7000368
	private object .ctor(object other) { }

	// RVA: 0x700058C
	public override object Reset() { }

	// RVA: 0x7000624
	public override object SetXsltContext(object xsltContext) { }

	// RVA: 0x70006C8
	public override object Evaluate(object context) { }

	// RVA: 0x7000788
	private object ProcessSamePosition(object result) { }

	// RVA: 0x700079C
	private object ProcessBeforePosition(object res1, object res2) { }

	// RVA: 0x70007B0
	private object ProcessAfterPosition(object res1, object res2) { }

	// RVA: 0x70007C4
	public override object Advance() { }

	// RVA: 0x7000960
	public override object get_StaticType() { }

	// RVA: 0x7000968
	public override object Clone() { }

	// RVA: 0x70009CC
	public override object get_Current() { }

	// RVA: 0x70009D4
	public override object get_CurrentPosition() { }

}

// Namespace: MS.Internal.Xml.XPath
internal abstract class ValueQuery
{

	// Properties
	public sealed override object Current { get; }
	public sealed override object CurrentPosition { get; }
	public sealed override object Count { get; }

	// Methods

	// RVA: 0x6FFD3A4
	public object .ctor() { }

	// RVA: 0x6FFD6A4
	protected object .ctor(object other) { }

	// RVA: 0x7000A14
	public sealed override object Reset() { }

	// RVA: 0x7000A18
	public sealed override object get_Current() { }

	// RVA: 0x7000A54
	public sealed override object get_CurrentPosition() { }

	// RVA: 0x7000A90
	public sealed override object get_Count() { }

	// RVA: 0x7000ACC
	public sealed override object Advance() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class Variable
{

	// Fields
	private object _localname; // 0x8
	private object _prefix; // 0x10

	// Properties
	public override object Type { get; }
	public override object ReturnType { get; }
	public object Localname { get; }
	public object Prefix { get; }

	// Methods

	// RVA: 0x7000B08
	public object .ctor(object name, object prefix) { }

	// RVA: 0x7000B40
	public override object get_Type() { }

	// RVA: 0x7000B48
	public override object get_ReturnType() { }

	// RVA: 0x7000B50
	public object get_Localname() { }

	// RVA: 0x7000B58
	public object get_Prefix() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class VariableQuery
{

	// Fields
	private object _variable; // 0x30

	// Properties
	public override object StaticType { get; }

	// Methods

	// RVA: 0x6FFC77C
	public object .ctor(object name, object prefix) { }

	// RVA: 0x7000B60
	private object .ctor(object other) { }

	// RVA: 0x7000BA0
	public override object SetXsltContext(object context) { }

	// RVA: 0x7000C74
	public override object Evaluate(object nodeIterator) { }

	// RVA: 0x7000D98
	public override object get_StaticType() { }

	// RVA: 0x7000F1C
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class XPathAncestorQuery
{

	// Fields
	private object _matchSelf; // 0x58

	// Properties
	public override object CurrentPosition { get; }
	public override object Properties { get; }

	// Methods

	// RVA: 0x6FFBE3C
	public object .ctor(object qyInput, object name, object prefix, object typeTest, object matchSelf) { }

	// RVA: 0x7000F9C
	private object .ctor(object other) { }

	// RVA: 0x7000FDC
	public override object Evaluate(object context) { }

	// RVA: 0x7001180
	public override object Clone() { }

	// RVA: 0x7001200
	public override object get_CurrentPosition() { }

	// RVA: 0x7001260
	public override object get_Properties() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class XPathArrayIterator
{

	// Fields
	protected object list; // 0x10
	protected object index; // 0x18

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }
	public override object Count { get; }

	// Methods

	// RVA: 0x700127C
	public object .ctor(object it) { }

	// RVA: 0x70012CC
	public object .ctor(object nodeIterator) { }

	// RVA: 0x70014A0
	public override object Clone() { }

	// RVA: 0x700152C
	public override object get_Current() { }

	// RVA: 0x70016D4
	public override object get_CurrentPosition() { }

	// RVA: 0x70016DC
	public override object get_Count() { }

	// RVA: 0x70017C0
	public override object MoveNext() { }

	// RVA: 0x70018D0
	public override object Reset() { }

	// RVA: 0x70018D8
	public override object GetEnumerator() { }

}

// Namespace: MS.Internal.Xml.XPath
internal abstract class XPathAxisIterator
{

	// Fields
	internal object nav; // 0x10
	internal object type; // 0x18
	internal object name; // 0x20
	internal object uri; // 0x28
	internal object position; // 0x30
	internal object matchSelf; // 0x34
	internal object first; // 0x35

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }
	protected virtual object Matches { get; }

	// Methods

	// RVA: 0x70019B8
	public object .ctor(object nav, object matchSelf) { }

	// RVA: 0x70019FC
	public object .ctor(object nav, object type, object matchSelf) { }

	// RVA: 0x7001A48
	public object .ctor(object nav, object name, object namespaceURI, object matchSelf) { }

	// RVA: 0x7001B10
	public object .ctor(object it) { }

	// RVA: 0x7001BB8
	public override object get_Current() { }

	// RVA: 0x7001BC0
	public override object get_CurrentPosition() { }

	// RVA: 0x7001BC8
	protected virtual object get_Matches() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class XPathChildIterator
{

	// Methods

	// RVA: 0x7001E20
	public object .ctor(object nav, object type) { }

	// RVA: 0x7001E68
	public object .ctor(object nav, object name, object namespaceURI) { }

	// RVA: 0x7001E70
	public object .ctor(object it) { }

	// RVA: 0x7001F18
	public override object Clone() { }

	// RVA: 0x7001FF4
	public override object MoveNext() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class XPathDescendantIterator
{

	// Fields
	private object _level; // 0x38

	// Methods

	// RVA: 0x70020EC
	public object .ctor(object nav, object type, object matchSelf) { }

	// RVA: 0x7002138
	public object .ctor(object nav, object name, object namespaceURI, object matchSelf) { }

	// RVA: 0x700213C
	public object .ctor(object it) { }

	// RVA: 0x70021EC
	public override object Clone() { }

	// RVA: 0x7002250
	public override object MoveNext() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class XPathEmptyIterator
{

	// Fields
	public static object Instance; // 0x0

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }
	public override object Count { get; }

	// Methods

	// RVA: 0x70023F4
	private object .ctor() { }

	// RVA: 0x7002420
	public override object Clone() { }

	// RVA: 0x7002424
	public override object get_Current() { }

	// RVA: 0x700242C
	public override object get_CurrentPosition() { }

	// RVA: 0x7002434
	public override object get_Count() { }

	// RVA: 0x700243C
	public override object MoveNext() { }

	// RVA: 0x7002444
	public override object Reset() { }

	// RVA: 0x7002448
	private static object .cctor() { }

}

// Namespace: 
private class ParamInfo
{

	// Fields
	private object _ftype; // 0x8
	private object _minargs; // 0xC
	private object _maxargs; // 0x10
	private object _argTypes; // 0x18

	// Properties
	public object FType { get; }
	public object Minargs { get; }
	public object Maxargs { get; }
	public object ArgTypes { get; }

	// Methods

	// RVA: 0x7006850
	public object get_FType() { }

	// RVA: 0x7006858
	public object get_Minargs() { }

	// RVA: 0x7006860
	public object get_Maxargs() { }

	// RVA: 0x7006868
	public object get_ArgTypes() { }

	// RVA: 0x7006248
	internal object .ctor(object ftype, object minargs, object maxargs, object argTypes) { }

}

// Namespace: MS.Internal.Xml.XPath
internal class XPathParser
{

	// Fields
	private object _scanner; // 0x8
	private object _parseDepth; // 0x10
	private static readonly object s_temparray1; // 0x0
	private static readonly object s_temparray2; // 0x8
	private static readonly object s_temparray3; // 0x10
	private static readonly object s_temparray4; // 0x18
	private static readonly object s_temparray5; // 0x20
	private static readonly object s_temparray6; // 0x28
	private static readonly object s_temparray7; // 0x30
	private static readonly object s_temparray8; // 0x38
	private static readonly object s_temparray9; // 0x40
	private static object s_functionTable; // 0x48
	private static object s_AxesTable; // 0x50

	// Methods

	// RVA: 0x70024B0
	private object .ctor(object scanner) { }

	// RVA: 0x6FFD088
	public static object ParseXPathExpression(object xpathExpression) { }

	// RVA: 0x70025B0
	private object ParseExpression(object qyInput) { }

	// RVA: 0x7002620
	private object ParseOrExpr(object qyInput) { }

	// RVA: 0x7002750
	private object ParseAndExpr(object qyInput) { }

	// RVA: 0x7002910
	private object ParseEqualityExpr(object qyInput) { }

	// RVA: 0x7002C18
	private object ParseRelationalExpr(object qyInput) { }

	// RVA: 0x7002DE0
	private object ParseAdditiveExpr(object qyInput) { }

	// RVA: 0x7002ECC
	private object ParseMultiplicativeExpr(object qyInput) { }

	// RVA: 0x7003084
	private object ParseUnaryExpr(object qyInput) { }

	// RVA: 0x7003170
	private object ParseUnionExpr(object qyInput) { }

	// RVA: 0x7003564
	private static object IsNodeType(object scaner) { }

	// RVA: 0x7003308
	private object ParsePathExpr(object qyInput) { }

	// RVA: 0x700373C
	private object ParseFilterExpr(object qyInput) { }

	// RVA: 0x7003E98
	private object ParsePredicate(object qyInput) { }

	// RVA: 0x7003A2C
	private object ParseLocationPath(object qyInput) { }

	// RVA: 0x7003944
	private object ParseRelativeLocationPath(object qyInput) { }

	// RVA: 0x7004080
	private static object IsStep(object lexKind) { }

	// RVA: 0x70040C0
	private object ParseStep(object qyInput) { }

	// RVA: 0x70044AC
	private object ParseNodeTest(object qyInput, object axisType, object nodeType) { }

	// RVA: 0x7003678
	private static object IsPrimaryExpr(object scanner) { }

	// RVA: 0x7003BAC
	private object ParsePrimaryExpr(object qyInput) { }

	// RVA: 0x70048F8
	private object ParseMethod(object qyInput) { }

	// RVA: 0x7004878
	private object CheckToken(object t) { }

	// RVA: 0x7004010
	private object PassToken(object t) { }

	// RVA: 0x70028F0
	private object NextLex() { }

	// RVA: 0x7002880
	private object TestOp(object op) { }

	// RVA: 0x70034F8
	private object CheckNodeSet(object t) { }

	// RVA: 0x700579C
	private static object CreateFunctionTable() { }

	// RVA: 0x7006298
	private static object CreateAxesTable() { }

	// RVA: 0x7004384
	private object GetAxis() { }

	// RVA: 0x7006554
	private static object .cctor() { }

}

// Namespace: 
public enum LexKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Comma;
	public const object Slash;
	public const object At;
	public const object Dot;
	public const object LParens;
	public const object RParens;
	public const object LBracket;
	public const object RBracket;
	public const object Star;
	public const object Plus;
	public const object Minus;
	public const object Eq;
	public const object Lt;
	public const object Gt;
	public const object Bang;
	public const object Dollar;
	public const object Apos;
	public const object Quote;
	public const object Union;
	public const object Ne;
	public const object Le;
	public const object Ge;
	public const object And;
	public const object Or;
	public const object DotDot;
	public const object SlashSlash;
	public const object Name;
	public const object String;
	public const object Number;
	public const object Axe;
	public const object Eof;
}

// Namespace: MS.Internal.Xml.XPath
internal sealed class XPathScanner
{

	// Fields
	private object _xpathExpr; // 0x8
	private object _xpathExprIndex; // 0x10
	private object _kind; // 0x14
	private object _currentChar; // 0x18
	private object _name; // 0x20
	private object _prefix; // 0x28
	private object _stringValue; // 0x30
	private object _numberValue; // 0x38
	private object _canBeFunction; // 0x40
	private object _xmlCharType; // 0x48

	// Properties
	public object SourceText { get; }
	private object CurrentChar { get; }
	public object Kind { get; }
	public object Name { get; }
	public object Prefix { get; }
	public object StringValue { get; }
	public object NumberValue { get; }
	public object CanBeFunction { get; }

	// Methods

	// RVA: 0x70024DC
	public object .ctor(object xpathExpr) { }

	// RVA: 0x70068E4
	public object get_SourceText() { }

	// RVA: 0x70068EC
	private object get_CurrentChar() { }

	// RVA: 0x7006870
	private object NextChar() { }

	// RVA: 0x70068F4
	public object get_Kind() { }

	// RVA: 0x70068FC
	public object get_Name() { }

	// RVA: 0x7006904
	public object get_Prefix() { }

	// RVA: 0x700690C
	public object get_StringValue() { }

	// RVA: 0x7006914
	public object get_NumberValue() { }

	// RVA: 0x700691C
	public object get_CanBeFunction() { }

	// RVA: 0x7006924
	private object SkipSpace() { }

	// RVA: 0x700506C
	public object NextLex() { }

	// RVA: 0x7006C20
	private object ScanNumber() { }

	// RVA: 0x70069B0
	private object ScanFraction() { }

	// RVA: 0x7006AD0
	private object ScanString() { }

	// RVA: 0x7006DFC
	private object ScanName() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class XPathSelectionIterator
{

	// Fields
	private object _nav; // 0x10
	private object _query; // 0x18
	private object _position; // 0x20

	// Properties
	public override object Count { get; }
	public override object Current { get; }
	public override object CurrentPosition { get; }

	// Methods

	// RVA: 0x7006ECC
	internal object .ctor(object nav, object query) { }

	// RVA: 0x7006F44
	protected object .ctor(object it) { }

	// RVA: 0x70070B0
	public override object Reset() { }

	// RVA: 0x70070FC
	public override object MoveNext() { }

	// RVA: 0x70071E8
	public override object get_Count() { }

	// RVA: 0x7007234
	public override object get_Current() { }

	// RVA: 0x700723C
	public override object get_CurrentPosition() { }

	// RVA: 0x7007244
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal sealed class XPathSelfQuery
{

	// Methods

	// RVA: 0x6FFBE68
	public object .ctor(object qyInput, object Name, object Prefix, object Type) { }

	// RVA: 0x70072A8
	private object .ctor(object other) { }

	// RVA: 0x70072B0
	public override object Advance() { }

	// RVA: 0x7007358
	public override object Clone() { }

}

// Namespace: MS.Internal.Xml.XPath
internal class XPathSingletonIterator
{

	// Fields
	private object _nav; // 0x10
	private object _position; // 0x18

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }
	public override object Count { get; }

	// Methods

	// RVA: 0x70073C0
	public object .ctor(object nav) { }

	// RVA: 0x70073F4
	public object .ctor(object nav, object moved) { }

	// RVA: 0x7007440
	public object .ctor(object it) { }

	// RVA: 0x70074D0
	public override object Clone() { }

	// RVA: 0x7007594
	public override object get_Current() { }

	// RVA: 0x700759C
	public override object get_CurrentPosition() { }

	// RVA: 0x70075A4
	public override object get_Count() { }

	// RVA: 0x70075AC
	public override object MoveNext() { }

	// RVA: 0x70075D4
	public override object Reset() { }

}

// Namespace: MS.Internal.Xml.Cache
internal abstract class XPathDocumentBaseIterator
{

	// Fields
	protected object ctxt; // 0x10
	protected object pos; // 0x18

	// Properties
	public override object Current { get; }
	public override object CurrentPosition { get; }

	// Methods

	// RVA: 0x70075DC
	protected object .ctor(object ctxt) { }

	// RVA: 0x7007780
	protected object .ctor(object iter) { }

	// RVA: 0x7007888
	public override object get_Current() { }

	// RVA: 0x7007890
	public override object get_CurrentPosition() { }

}

// Namespace: MS.Internal.Xml.Cache
internal class XPathDocumentElementChildIterator
{

	// Fields
	private object _localName; // 0x20
	private object _namespaceUri; // 0x28

	// Methods

	// RVA: 0x7007898
	public object .ctor(object parent, object name, object namespaceURI) { }

	// RVA: 0x7007994
	public object .ctor(object iter) { }

	// RVA: 0x70079D0
	public override object Clone() { }

	// RVA: 0x7007A4C
	public override object MoveNext() { }

}

// Namespace: MS.Internal.Xml.Cache
internal class XPathDocumentKindChildIterator
{

	// Fields
	private object _typ; // 0x1C

	// Methods

	// RVA: 0x7007B3C
	public object .ctor(object parent, object typ) { }

	// RVA: 0x7007B64
	public object .ctor(object iter) { }

	// RVA: 0x7007BA0
	public override object Clone() { }

	// RVA: 0x7007C1C
	public override object MoveNext() { }

}

// Namespace: MS.Internal.Xml.Cache
internal class XPathDocumentElementDescendantIterator
{

	// Fields
	private object _end; // 0x20
	private object _localName; // 0x28
	private object _namespaceUri; // 0x30
	private object _matchSelf; // 0x38

	// Methods

	// RVA: 0x7007D00
	public object .ctor(object root, object name, object namespaceURI, object matchSelf) { }

	// RVA: 0x7007F10
	public object .ctor(object iter) { }

	// RVA: 0x7007F5C
	public override object Clone() { }

	// RVA: 0x7007FE8
	public override object MoveNext() { }

}

// Namespace: MS.Internal.Xml.Cache
internal class XPathDocumentKindDescendantIterator
{

	// Fields
	private object _end; // 0x20
	private object _typ; // 0x28
	private object _matchSelf; // 0x2C

	// Methods

	// RVA: 0x70081D8
	public object .ctor(object root, object typ, object matchSelf) { }

	// RVA: 0x7008330
	public object .ctor(object iter) { }

	// RVA: 0x700837C
	public override object Clone() { }

	// RVA: 0x7008408
	public override object MoveNext() { }

}

// Namespace: MS.Internal.Xml.Cache
internal sealed class XPathDocumentNavigator
{

	// Fields
	private object _pageCurrent; // 0x8
	private object _pageParent; // 0x10
	private object _idxCurrent; // 0x18
	private object _idxParent; // 0x1C
	private object _atomizedLocalName; // 0x20

	// Properties
	public override object Value { get; }
	public override object NodeType { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Name { get; }
	public override object Prefix { get; }
	public override object BaseURI { get; }
	public override object NameTable { get; }
	public override object UnderlyingObject { get; }
	public object LineNumber { get; }
	public object LinePosition { get; }

	// Methods

	// RVA: 0x70085F8
	public object .ctor(object pageCurrent, object idxCurrent, object pageParent, object idxParent) { }

	// RVA: 0x70076D4
	public object .ctor(object nav) { }

	// RVA: 0x7008688
	public override object get_Value() { }

	// RVA: 0x7008C3C
	public override object Clone() { }

	// RVA: 0x7008D04
	public override object get_NodeType() { }

	// RVA: 0x7008D54
	public override object get_LocalName() { }

	// RVA: 0x7008DC0
	public override object get_NamespaceURI() { }

	// RVA: 0x7008E2C
	public override object get_Name() { }

	// RVA: 0x7008F50
	public override object get_Prefix() { }

	// RVA: 0x7008FBC
	public override object get_BaseURI() { }

	// RVA: 0x7009108
	public override object get_NameTable() { }

	// RVA: 0x7009188
	public override object MoveToFirstAttribute() { }

	// RVA: 0x70092BC
	public override object MoveToNextAttribute() { }

	// RVA: 0x7009364
	public override object MoveToAttribute(object localName, object namespaceURI) { }

	// RVA: 0x70095D8
	public override object MoveToFirstNamespace(object namespaceScope) { }

	// RVA: 0x70099E4
	public override object MoveToNextNamespace(object scope) { }

	// RVA: 0x7009BCC
	public override object MoveToNext() { }

	// RVA: 0x7009CD4
	public override object MoveToFirstChild() { }

	// RVA: 0x7009E58
	public override object MoveToParent() { }

	// RVA: 0x7009F58
	public override object MoveTo(object other) { }

	// RVA: 0x7009FE4
	public override object MoveToId(object id) { }

	// RVA: 0x700A078
	public override object IsSamePosition(object other) { }

	// RVA: 0x700A130
	public override object MoveToRoot() { }

	// RVA: 0x700A1F0
	public override object MoveToChild(object localName, object namespaceURI) { }

	// RVA: 0x700A414
	public override object MoveToNext(object localName, object namespaceURI) { }

	// RVA: 0x700A604
	public override object MoveToChild(object type) { }

	// RVA: 0x700A840
	public override object MoveToNext(object type) { }

	// RVA: 0x700A9B4
	public override object MoveToFollowing(object localName, object namespaceURI, object end) { }

	// RVA: 0x700AF80
	public override object MoveToFollowing(object type, object end) { }

	// RVA: 0x700B438
	public override object SelectChildren(object type) { }

	// RVA: 0x700B4A4
	public override object SelectChildren(object name, object namespaceURI) { }

	// RVA: 0x700B544
	public override object SelectDescendants(object type, object matchSelf) { }

	// RVA: 0x700B5C0
	public override object SelectDescendants(object name, object namespaceURI, object matchSelf) { }

	// RVA: 0x700B678
	public override object ComparePosition(object other) { }

	// RVA: 0x700B924
	public override object IsDescendant(object other) { }

	// RVA: 0x700B7C4
	private object GetPrimaryLocation() { }

	// RVA: 0x700B854
	private object GetSecondaryLocation() { }

	// RVA: 0x700BAA0
	public override object get_UnderlyingObject() { }

	// RVA: 0x700BAE4
	public object HasLineInfo() { }

	// RVA: 0x700BB40
	public object get_LineNumber() { }

	// RVA: 0x700BC30
	public object get_LinePosition() { }

	// RVA: 0x700BD80
	public object GetPositionHashCode() { }

	// RVA: 0x70080A8
	public object IsElementMatch(object localName, object namespaceURI) { }

	// RVA: 0x7008550
	public object IsKindMatch(object typ) { }

	// RVA: 0x700AB38
	private object GetFollowingEnd(object end, object useParentOfVirtual, object pageEnd) { }

}

// Namespace: MS.Internal.Xml.Cache
internal struct XPathNode
{

	// Fields
	private object _info; // 0xFFFFFFFFFFFFFFF8
	private object _idxSibling; // 0x0
	private object _idxParent; // 0x2
	private object _idxSimilar; // 0x4
	private object _posOffset; // 0x6
	private object _props; // 0x8
	private object _value; // 0x10

	// Properties
	public object NodeType { get; }
	public object Prefix { get; }
	public object LocalName { get; }
	public object Name { get; }
	public object NamespaceUri { get; }
	public object Document { get; }
	public object BaseUri { get; }
	public object LineNumber { get; }
	public object LinePosition { get; }
	public object CollapsedLinePosition { get; }
	public object PageInfo { get; }
	public object IsXmlNamespaceNode { get; }
	public object HasSibling { get; }
	public object HasCollapsedText { get; }
	public object HasAttribute { get; }
	public object HasContentChild { get; }
	public object HasElementChild { get; }
	public object IsAttrNmsp { get; }
	public object IsText { get; }
	public object HasNamespaceDecls { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x7008D48
	public object get_NodeType() { }

	// RVA: 0x7008F98
	public object get_Prefix() { }

	// RVA: 0x7008D9C
	public object get_LocalName() { }

	// RVA: 0x7008ECC
	public object get_Name() { }

	// RVA: 0x7008E08
	public object get_NamespaceUri() { }

	// RVA: 0x7009164
	public object get_Document() { }

	// RVA: 0x70090B8
	public object get_BaseUri() { }

	// RVA: 0x700BC00
	public object get_LineNumber() { }

	// RVA: 0x700BD54
	public object get_LinePosition() { }

	// RVA: 0x700BD20
	public object get_CollapsedLinePosition() { }

	// RVA: 0x700BFEC
	public object get_PageInfo() { }

	// RVA: 0x700A1B4
	public object GetRoot(object pageNode) { }

	// RVA: 0x70090DC
	public object GetParent(object pageNode) { }

	// RVA: 0x70099B8
	public object GetSibling(object pageNode) { }

	// RVA: 0x700C0C8
	public object GetSimilarElement(object pageNode) { }

	// RVA: 0x700C120
	public object NameMatch(object localName, object namespaceName) { }

	// RVA: 0x700BD8C
	public object ElementMatch(object localName, object namespaceName) { }

	// RVA: 0x7009918
	public object get_IsXmlNamespaceNode() { }

	// RVA: 0x700C290
	public object get_HasSibling() { }

	// RVA: 0x7009D74
	public object get_HasCollapsedText() { }

	// RVA: 0x700C2BC
	public object get_HasAttribute() { }

	// RVA: 0x700C2D4
	public object get_HasContentChild() { }

	// RVA: 0x700C2EC
	public object get_HasElementChild() { }

	// RVA: 0x700C304
	public object get_IsAttrNmsp() { }

	// RVA: 0x700C32C
	public object get_IsText() { }

	// RVA: 0x700C44C
	public object get_HasNamespaceDecls() { }

	// RVA: 0x700C464
	public object get_Value() { }

}

// Namespace: MS.Internal.Xml.Cache
internal struct XPathNodeRef
{

	// Fields
	private object _page; // 0xFFFFFFFFFFFFFFF8
	private object _idx; // 0x0

	// Properties
	public object Page { get; }
	public object Index { get; }

	// Methods

	// RVA: 0x700C4B0
	public object .ctor(object page, object idx) { }

	// RVA: 0x700C4C8
	public object get_Page() { }

	// RVA: 0x700C4D8
	public object get_Index() { }

	// RVA: 0x700C4E8
	public override object GetHashCode() { }

}

// Namespace: MS.Internal.Xml.Cache
internal abstract class XPathNodeHelper
{

	// Methods

	// RVA: 0x70097AC
	public static object GetLocalNamespaces(object pageElem, object idxElem, object pageNmsp) { }

	// RVA: 0x7009828
	public static object GetInScopeNamespaces(object pageElem, object idxElem, object pageNmsp) { }

	// RVA: 0x7009228
	public static object GetFirstAttribute(object pageNode, object idxNode) { }

	// RVA: 0x70092CC
	public static object GetNextAttribute(object pageNode, object idxNode) { }

	// RVA: 0x7009D80
	public static object GetContentChild(object pageNode, object idxNode) { }

	// RVA: 0x7009C50
	public static object GetContentSibling(object pageNode, object idxNode) { }

	// RVA: 0x7009EEC
	public static object GetParent(object pageNode, object idxNode) { }

	// RVA: 0x700BA50
	public static object GetLocation(object pageNode, object idxNode) { }

	// RVA: 0x700A2B0
	public static object GetElementChild(object pageNode, object idxNode, object localName, object namespaceName) { }

	// RVA: 0x700A4D4
	public static object GetElementSibling(object pageNode, object idxNode, object localName, object namespaceName) { }

	// RVA: 0x700A6C8
	public static object GetContentChild(object pageNode, object idxNode, object typ) { }

	// RVA: 0x700A854
	public static object GetContentSibling(object pageNode, object idxNode, object typ) { }

	// RVA: 0x7009454
	public static object GetAttribute(object pageNode, object idxNode, object localName, object namespaceName) { }

	// RVA: 0x700AC04
	public static object GetElementFollowing(object pageCurrent, object idxCurrent, object pageEnd, object idxEnd, object localName, object namespaceName) { }

	// RVA: 0x700B27C
	public static object GetContentFollowing(object pageCurrent, object idxCurrent, object pageEnd, object idxEnd, object typ) { }

	// RVA: 0x70089D4
	public static object GetTextFollowing(object pageCurrent, object idxCurrent, object pageEnd, object idxEnd) { }

	// RVA: 0x7008938
	public static object GetNonDescendant(object pageNode, object idxNode) { }

	// RVA: 0x700C598
	private static object GetChild(object pageNode, object idxNode) { }

}

// Namespace: MS.Internal.Xml.Cache
internal sealed class XPathNodePageInfo
{

	// Fields
	private object _pageNum; // 0x8
	private object _nodeCount; // 0xC
	private object _pageNext; // 0x10

	// Properties
	public object PageNumber { get; }
	public object NodeCount { get; }
	public object NextPage { get; }

	// Methods

	// RVA: 0x700C614
	public object get_PageNumber() { }

	// RVA: 0x700C61C
	public object get_NodeCount() { }

	// RVA: 0x700C624
	public object get_NextPage() { }

}

// Namespace: MS.Internal.Xml.Cache
internal sealed class XPathNodeInfoAtom
{

	// Fields
	private object _localName; // 0x8
	private object _namespaceUri; // 0x10
	private object _prefix; // 0x18
	private object _baseUri; // 0x20
	private object _pageParent; // 0x28
	private object _pageSibling; // 0x30
	private object _pageSimilar; // 0x38
	private object _doc; // 0x40
	private object _lineNumBase; // 0x48
	private object _linePosBase; // 0x4C
	private object _pageInfo; // 0x50

	// Properties
	public object PageInfo { get; }
	public object LocalName { get; }
	public object NamespaceUri { get; }
	public object Prefix { get; }
	public object BaseUri { get; }
	public object SiblingPage { get; }
	public object SimilarElementPage { get; }
	public object ParentPage { get; }
	public object Document { get; }
	public object LineNumberBase { get; }
	public object LinePositionBase { get; }

	// Methods

	// RVA: 0x700C62C
	public object get_PageInfo() { }

	// RVA: 0x700C634
	public object get_LocalName() { }

	// RVA: 0x700C63C
	public object get_NamespaceUri() { }

	// RVA: 0x700C644
	public object get_Prefix() { }

	// RVA: 0x700C64C
	public object get_BaseUri() { }

	// RVA: 0x700C654
	public object get_SiblingPage() { }

	// RVA: 0x700C65C
	public object get_SimilarElementPage() { }

	// RVA: 0x700C664
	public object get_ParentPage() { }

	// RVA: 0x700C66C
	public object get_Document() { }

	// RVA: 0x700C674
	public object get_LineNumberBase() { }

	// RVA: 0x700C67C
	public object get_LinePositionBase() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=6
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=12
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=16
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=20
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=24
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=28
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=32
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=36
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=38
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=40
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=44
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=56
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=64
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=68
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=112
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=144
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=416
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=664
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=960
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=1212
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 0C682AB2EF0F1E326972C95528BBDE965F5D2DA9232E7A946F6E8A978A2871B5; // 0x0
	internal static readonly object 11047585FE102FBB5CADB42446612A578D88C6EF5ED076BB7AC360C4F9E4373D; // 0x44
	internal static readonly object 21AFB7EF8B4B88C006C54601484BC15AE5A8DBD2C0DD8C6622109208F8511B82; // 0x50
	internal static readonly object 24F70FC64555D9B7646AD4C0EEB8DF5286779F0E39C15ACA61305BC4A5E40BE6; // 0x410
	internal static readonly object 28045F5AB2D9A9593F1D95B0FCB77E7F5F5435DD654BAFEF68972344B51C71BD; // 0x438
	internal static readonly object 28057B619BAF672A05E1585ED28F174E67FE946D81BDAA0691F07AB772057B02; // 0x4C8
	internal static readonly object 2809A17B374DF1926EA539548F5B3750AA8ADB2BD59F5066AD6F9D439A231122; // 0x538
	internal static readonly object 2AE470BFECE0EB971895252403237B3B989F74AD83E2B858E9CEA0482E776123; // 0x9F4
	internal static readonly object 2BA62518D59E3AF30E09E458218C4A05E5DFA2949B8B8F9B5E68CC793DBFA882; // 0xA08
	internal static readonly object 2D902EC9D8EA71E1193C1C8315B1553D5154744F651BD366F1E1F437F6594A94; // 0xA30
	internal static readonly object 3B3045573362001FA1CDA1F381A331DB2A88DD59FDD9C497404D59995AA377EA; // 0xA54
	internal static readonly object 3EB9B3AB77D567D5CEBF38C4C91CDF79845F0691D47A516CE6981BF091025179; // 0xA60
	internal static readonly object 499E4F5C84E20C7347E10100E0EC90C1945EA21C7C80809E4F7F474179B39DF6; // 0xA78
	internal static readonly object 540CD885F06B2760118EA5544E069ACE0C5D184B85D9D104417C14F1E536376D; // 0xA94
	internal static readonly object 58E18897FE5FF048E82310FB4F57ADB2D53AEE59CB49B1E7094439808A1EF3F6; // 0xABA
	internal static readonly object 5B7F03A977BE72EBD5C1702238238AEB01DFFB019B05EFAAC147EF886732EDC7; // 0xAFE
	internal static readonly object 652CA39E9310E001C2C4AF271610032A5638C58598F727066CCF4E666D424CD4; // 0xB0A
	internal static readonly object 6536D9B2447DFCF9BA37F9E5A7FAB08CB5552C5AD5B20E019AEC4872283A542A; // 0xB2A
	internal static readonly object 77186ED8B389D5640B5AFAC4A22526ABA2422DCBE2986D0032E3B035D175758D; // 0xB4E
	internal static readonly object 8A36CBC1D17EC6E1CCFE7D67F79FA9C8B2D7A41B04DD58A76970CEDC8189210D; // 0xF10
	internal static readonly object 8D4DC488705859D6A837A660BDBA9E88D1BD229BC39DB97734072D04BD513ECD; // 0xF18
	internal static readonly object 92E9BC30656BF079FC6B0A200B019FF46941857D786F4C391470394CFDC95F0B; // 0xF3C
	internal static readonly object 9DA6B2C4638D1DC7611B7F458BBFE7FD49FE1B36B67239B00B8A051F4E49558F; // 0xF5C
	internal static readonly object AD6E77E234021D825C77689D82D414CDA3ABAE1ACC346D4BA2D6B1876CFC5FBC; // 0xF7C
	internal static readonly object B21FC5E8DB69C99CDEFB2C460E7C26D2D29A5ADC302365C59766D13688236919; // 0xFBC
	internal static readonly object B6E5AC1B0927F4259775820D36453E7BD957F110874896C133234263D312D88E; // 0xFD0
	internal static readonly object C332DD23F2CF4DE6107A93045ACACD787E2D9EB18B213298B98F23357F4FEA41; // 0xFFC
	internal static readonly object C3B2BED2599F3C79640DE44BA4EC7AEBB4856DBF74059DF382CF1D3026D272DA; // 0x100C
	internal static readonly object D1D9AF18AFC4E3074AF5E4C44B81B73889D033D7AF6DFEB387BBCC76B36FE8B9; // 0x1018
	internal static readonly object DA285BBFE8FD0AA22C7CB92A1E911A4206CEDB14132FE3B6EE4DB32A42CAA41D; // 0x11B8
	internal static readonly object DACC0E6568D9B10337A1A693F10D42C3175E80C378154406C6FBFA989F919F51; // 0x11D0
	internal static readonly object DB047CC748613CCCB120DE7385E37D542A79C3BF8F0E64FE6DAD349B4D26E5D7; // 0x11D8
	internal static readonly object DB7DD2341DB9D4574E432AAAFF03FB0A3E8FF2F645A337077EDF0C6FE902E660; // 0x1210
	internal static readonly object DBBF94CCF4250B303976041627BB8FC302CE57D55373C469F41F97318412037D; // 0x13B0
	internal static readonly object DD4E9C7C140CABCA5A25F4DA1F6F5BAC5D74E4568F954BF728471E711A35163E; // 0x13B6
	internal static readonly object EC3DA4AD81BE65581D24158F5E1FCDA45D908C27EC29FDFA744995062C501501; // 0x164E
	internal static readonly object EE2DCBE09BA7FF21BF36DD7FC218E094C9B3EF228148D28D21D77A0FE51553C6; // 0x165E
	internal static readonly object F1A5C5E949D525C31B086947AF16513F4999646B513457629847081D039048ED; // 0x1676
	internal static readonly object FFF813C50ED1BEC943E2CA58860CC34E0A14A5C0E858B97C7670A384005CC064; // 0x1686

	// Methods

	// RVA: 0x700C684
	internal static object ComputeStringHash(object s) { }

}

