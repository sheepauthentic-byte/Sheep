// Namespace: 
internal class <Module>
{
}

// Namespace: ImGuiNET
public class IntPtrEqualityComparer
{

	// Fields
	private static readonly object <Instance>k__BackingField; // 0x0

	// Properties
	public static object Instance { get; }

	// Methods

	// RVA: 0x6C36114
	public static object get_Instance() { }

	// RVA: 0x6C36190
	private object .ctor() { }

	// RVA: 0x6C36198
	public object Equals(object p1, object p2) { }

	// RVA: 0x6C361A8
	public object GetHashCode(object ptr) { }

	// RVA: 0x6C361D0
	private static object .cctor() { }

}

// Namespace: ImGuiNET
public struct ImDrawListPtr
{

	// Fields
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object NativePtr { get; }
	public object CmdBuffer { get; }
	public object IdxBuffer { get; }
	public object VtxBuffer { get; }

	// Methods

	// RVA: 0x6C36230
	public object Equals(object other) { }

	// RVA: 0x6C36250
	public object get_NativePtr() { }

	// RVA: 0x6C36260
	public object get_CmdBuffer() { }

	// RVA: 0x6C36374
	public object get_IdxBuffer() { }

	// RVA: 0x6C36464
	public object get_VtxBuffer() { }

}

// Namespace: ImGuiNET
public struct ImFontConfigPtr
{

	// Fields
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object NativePtr { get; }
	public object FontNo { get; }
	public object SizePixels { get; }
	public object OversampleH { get; }
	public object OversampleV { get; }
	public object PixelSnapH { get; }
	public object GlyphExtraSpacing { get; }
	public object GlyphOffset { get; }
	public object GlyphRanges { set; }
	public object GlyphMinAdvanceX { get; }
	public object GlyphMaxAdvanceX { get; }
	public object MergeMode { get; }
	public object FontBuilderFlags { get; }
	public object RasterizerMultiply { get; }
	public object EllipsisChar { get; }

	// Methods

	// RVA: 0x6C36578
	public object .ctor(object fontConfig) { }

	// RVA: 0x6C36588
	public object get_NativePtr() { }

	// RVA: 0x6C36598
	public object get_FontNo() { }

	// RVA: 0x6C365E0
	public object get_SizePixels() { }

	// RVA: 0x6C36628
	public object get_OversampleH() { }

	// RVA: 0x6C36670
	public object get_OversampleV() { }

	// RVA: 0x6C366B8
	public object get_PixelSnapH() { }

	// RVA: 0x6C36700
	public object get_GlyphExtraSpacing() { }

	// RVA: 0x6C36748
	public object get_GlyphOffset() { }

	// RVA: 0x6C36790
	public object set_GlyphRanges(object value) { }

	// RVA: 0x6C36808
	public object get_GlyphMinAdvanceX() { }

	// RVA: 0x6C36850
	public object get_GlyphMaxAdvanceX() { }

	// RVA: 0x6C36898
	public object get_MergeMode() { }

	// RVA: 0x6C368E0
	public object get_FontBuilderFlags() { }

	// RVA: 0x6C36928
	public object get_RasterizerMultiply() { }

	// RVA: 0x6C36970
	public object get_EllipsisChar() { }

}

// Namespace: ImGuiNET
public static class ImGui
{

	// Methods

	// RVA: 0x6C369B8
	public static object AlignTextToFramePadding() { }

	// RVA: 0x6C369C0
	public static object Begin(object name, object p_open) { }

	// RVA: 0x6C36D4C
	public static object Begin(object name, object p_open, object flags) { }

	// RVA: 0x6C36F14
	public static object BeginCombo(object label, object preview_value) { }

	// RVA: 0x6C37264
	public static object BeginDisabled() { }

	// RVA: 0x6C3726C
	public static object BeginDisabled(object disabled) { }

	// RVA: 0x6C37270
	public static object BeginMenu(object label) { }

	// RVA: 0x6C37424
	public static object BeginMenuBar() { }

	// RVA: 0x6C37434
	public static object BeginTable(object str_id, object columns, object flags) { }

	// RVA: 0x6C375E8
	public static object Button(object label) { }

	// RVA: 0x6C3779C
	public static object Button(object label, object size) { }

	// RVA: 0x6C37948
	public static object Checkbox(object label, object v) { }

	// RVA: 0x6C37B18
	public static object CollapsingHeader(object label) { }

	// RVA: 0x6C37CCC
	public static object CollapsingHeader(object label, object flags) { }

	// RVA: 0x6C37E78
	public static object ColorButton(object desc_id, object col) { }

	// RVA: 0x6C3802C
	public static object ColorEdit3(object label, object col) { }

	// RVA: 0x6C381E0
	public static object ColorEdit4(object label, object col, object flags) { }

	// RVA: 0x6C38394
	public static object Columns(object count) { }

	// RVA: 0x6C3839C
	public static object Columns(object count, object id) { }

	// RVA: 0x6C38544
	public static object Combo(object label, object current_item, object items, object items_count) { }

	// RVA: 0x6C38918
	public static object CreateContext() { }

	// RVA: 0x6C38928
	public static object DestroyContext(object ctx) { }

	// RVA: 0x6C38930
	public static object DragFloat(object label, object v, object v_speed, object v_min, object v_max) { }

	// RVA: 0x6C38CA0
	public static object DragScalar(object label, object data_type, object p_data, object v_speed) { }

	// RVA: 0x6C38E54
	public static object End() { }

	// RVA: 0x6C38E5C
	public static object EndCombo() { }

	// RVA: 0x6C38E64
	public static object EndDisabled() { }

	// RVA: 0x6C38E6C
	public static object EndMenu() { }

	// RVA: 0x6C38E74
	public static object EndMenuBar() { }

	// RVA: 0x6C38E7C
	public static object EndTable() { }

	// RVA: 0x6C38E84
	public static object GetColumnWidth() { }

	// RVA: 0x6C38E94
	public static object GetContentRegionAvail() { }

	// RVA: 0x6C38EA4
	public static object GetDrawData() { }

	// RVA: 0x6C38EB4
	public static object GetFont() { }

	// RVA: 0x6C38EC4
	public static object GetID(object str_id) { }

	// RVA: 0x6C39078
	public static object GetIO() { }

	// RVA: 0x6C39088
	public static object GetMouseCursor() { }

	// RVA: 0x6C39098
	public static object GetScrollX() { }

	// RVA: 0x6C390A8
	public static object GetScrollY() { }

	// RVA: 0x6C390B8
	public static object GetStyle() { }

	// RVA: 0x6C390C8
	public static object GetWindowPos() { }

	// RVA: 0x6C390D8
	public static object GetWindowSize() { }

	// RVA: 0x6C390E8
	public static object GetWindowWidth() { }

	// RVA: 0x6C390F8
	public static object Image(object user_texture_id, object image_size, object uv0, object uv1) { }

	// RVA: 0x6C39100
	public static object Indent() { }

	// RVA: 0x6C39108
	public static object IsItemClicked() { }

	// RVA: 0x6C39118
	public static object IsItemHovered() { }

	// RVA: 0x6C39128
	public static object IsMouseDown(object button) { }

	// RVA: 0x6C39138
	public static object IsMouseDragging(object button) { }

	// RVA: 0x6C39148
	public static object IsMouseReleased(object button) { }

	// RVA: 0x6C39158
	public static object LabelText(object label, object fmt) { }

	// RVA: 0x6C394A0
	public static object LoadIniSettingsFromMemory(object ini_data) { }

	// RVA: 0x6C3964C
	public static object MenuItem(object label, object shortcut, object selected) { }

	// RVA: 0x6C3999C
	public static object NewFrame() { }

	// RVA: 0x6C399A4
	public static object NextColumn() { }

	// RVA: 0x6C399AC
	public static object PlotLines(object label, object values, object values_count, object values_offset) { }

	// RVA: 0x6C39B58
	public static object PopID() { }

	// RVA: 0x6C39B60
	public static object PopStyleColor() { }

	// RVA: 0x6C39B68
	public static object PopStyleColor(object count) { }

	// RVA: 0x6C39B6C
	public static object PopStyleVar() { }

	// RVA: 0x6C39B74
	public static object PushID(object str_id) { }

	// RVA: 0x6C39D20
	public static object PushID(object int_id) { }

	// RVA: 0x6C39D28
	public static object PushStyleColor(object idx, object col) { }

	// RVA: 0x6C39D30
	public static object PushStyleVar(object idx, object val) { }

	// RVA: 0x6C39D38
	public static object RadioButton(object label, object active) { }

	// RVA: 0x6C39EEC
	public static object Render() { }

	// RVA: 0x6C39EF4
	public static object SameLine() { }

	// RVA: 0x6C39EFC
	public static object SaveIniSettingsToMemory() { }

	// RVA: 0x6C39FA4
	public static object Selectable(object label) { }

	// RVA: 0x6C3A158
	public static object Selectable(object label, object selected) { }

	// RVA: 0x6C3A304
	public static object Selectable(object label, object selected, object flags) { }

	// RVA: 0x6C3A4B0
	public static object Separator() { }

	// RVA: 0x6C3A4B8
	public static object SeparatorText(object label) { }

	// RVA: 0x6C3A664
	public static object SetColumnWidth(object column_index, object width) { }

	// RVA: 0x6C3A66C
	public static object SetCurrentContext(object ctx) { }

	// RVA: 0x6C3A674
	public static object SetNextItemAllowOverlap() { }

	// RVA: 0x6C3A67C
	public static object SetNextItemWidth(object item_width) { }

	// RVA: 0x6C3A684
	public static object SetNextWindowBgAlpha(object alpha) { }

	// RVA: 0x6C3A68C
	public static object SetNextWindowPos(object pos, object cond) { }

	// RVA: 0x6C3A694
	public static object SetNextWindowSize(object size, object cond) { }

	// RVA: 0x6C3A69C
	public static object SetScrollX(object scroll_x) { }

	// RVA: 0x6C3A6A4
	public static object SetScrollY(object scroll_y) { }

	// RVA: 0x6C3A6AC
	public static object SetWindowFocus() { }

	// RVA: 0x6C3A6B4
	public static object SetWindowSize(object size, object cond) { }

	// RVA: 0x6C3A6BC
	public static object SliderFloat(object label, object v, object v_min, object v_max) { }

	// RVA: 0x6C3AA2C
	public static object SliderFloat(object label, object v, object v_min, object v_max, object format) { }

	// RVA: 0x6C3AD74
	public static object SliderFloat4(object label, object v, object v_min, object v_max) { }

	// RVA: 0x6C3B0E4
	public static object SliderInt(object label, object v, object v_min, object v_max) { }

	// RVA: 0x6C3B454
	public static object TableHeadersRow() { }

	// RVA: 0x6C3B45C
	public static object TableNextColumn() { }

	// RVA: 0x6C3B46C
	public static object TableNextRow() { }

	// RVA: 0x6C3B474
	public static object TableSetColumnIndex(object column_n) { }

	// RVA: 0x6C3B484
	public static object TableSetupColumn(object label) { }

	// RVA: 0x6C3B630
	public static object TableSetupScrollFreeze(object cols, object rows) { }

	// RVA: 0x6C3B638
	public static object Text(object fmt) { }

	// RVA: 0x6C3B7E4
	public static object TextColored(object col, object fmt) { }

	// RVA: 0x6C3B990
	public static object TreeNode(object label) { }

	// RVA: 0x6C3BB44
	public static object TreeNodeEx(object label, object flags) { }

	// RVA: 0x6C3BCF8
	public static object TreePop() { }

	// RVA: 0x6C3BD00
	public static object Unindent() { }

	// RVA: 0x6C3BD08
	public static object InputText(object label, object input, object maxLength) { }

	// RVA: 0x6C3BD20
	public static object InputText(object label, object input, object maxLength, object flags, object callback, object user_data) { }

}

// Namespace: ImGuiNET
public struct ImGuiIOPtr
{

	// Fields
	private static readonly object s_managedAllocations; // 0x0
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object NativePtr { get; }
	public object ConfigFlags { get; }
	public object BackendFlags { get; }
	public object DisplaySize { get; }
	public object DeltaTime { get; }
	public object Fonts { get; }
	public object FontGlobalScale { get; }
	public object FontAllowUserScaling { get; }
	public object MouseDrawCursor { get; }
	public object ConfigInputTrickleEventQueue { get; }
	public object ConfigInputTextCursorBlink { get; }
	public object ConfigWindowsResizeFromEdges { get; }
	public object ConfigWindowsMoveFromTitleBarOnly { get; }
	public object ConfigMemoryCompactTimer { get; }
	public object MouseDoubleClickTime { get; }
	public object MouseDoubleClickMaxDist { get; }
	public object MouseDragThreshold { get; }
	public object KeyRepeatDelay { get; }
	public object KeyRepeatRate { get; }
	public object ClipboardUserData { set; }
	public object WantCaptureMouse { get; }
	public object WantCaptureKeyboard { get; }
	public object WantSaveIniSettings { get; }
	public object MouseDelta { get; }

	// Methods

	// RVA: 0x6C3C26C
	public object SetBackendRendererName(object name) { }

	// RVA: 0x6C3C560
	public object SetBackendPlatformName(object name) { }

	// RVA: 0x6C3C854
	public object SetIniFilename(object name) { }

	// RVA: 0x6C3CB48
	public object get_NativePtr() { }

	// RVA: 0x6C3CB58
	public object .ctor(object nativePtr) { }

	// RVA: 0x6C3CB68
	public object get_ConfigFlags() { }

	// RVA: 0x6C3CC70
	public object get_BackendFlags() { }

	// RVA: 0x6C3CD80
	public object get_DisplaySize() { }

	// RVA: 0x6C3CE90
	public object get_DeltaTime() { }

	// RVA: 0x6C3CFA0
	public object get_Fonts() { }

	// RVA: 0x6C3D0B0
	public object get_FontGlobalScale() { }

	// RVA: 0x6C3D1C0
	public object get_FontAllowUserScaling() { }

	// RVA: 0x6C3D2D0
	public object get_MouseDrawCursor() { }

	// RVA: 0x6C3D3E0
	public object get_ConfigInputTrickleEventQueue() { }

	// RVA: 0x6C3D4F0
	public object get_ConfigInputTextCursorBlink() { }

	// RVA: 0x6C3D600
	public object get_ConfigWindowsResizeFromEdges() { }

	// RVA: 0x6C3D710
	public object get_ConfigWindowsMoveFromTitleBarOnly() { }

	// RVA: 0x6C3D820
	public object get_ConfigMemoryCompactTimer() { }

	// RVA: 0x6C3D930
	public object get_MouseDoubleClickTime() { }

	// RVA: 0x6C3DA40
	public object get_MouseDoubleClickMaxDist() { }

	// RVA: 0x6C3DB50
	public object get_MouseDragThreshold() { }

	// RVA: 0x6C3DC60
	public object get_KeyRepeatDelay() { }

	// RVA: 0x6C3DD70
	public object get_KeyRepeatRate() { }

	// RVA: 0x6C3DE80
	public object set_ClipboardUserData(object value) { }

	// RVA: 0x6C3DFC8
	public object get_WantCaptureMouse() { }

	// RVA: 0x6C3E0D8
	public object get_WantCaptureKeyboard() { }

	// RVA: 0x6C3E1E8
	public object get_WantSaveIniSettings() { }

	// RVA: 0x6C3E2F8
	public object get_MouseDelta() { }

	// RVA: 0x6C3E408
	public object AddInputCharacter(object c) { }

	// RVA: 0x6C3E4BC
	public object AddKeyEvent(object key, object down) { }

	// RVA: 0x6C3E570
	public object AddMouseButtonEvent(object button, object down) { }

	// RVA: 0x6C3E624
	public object AddMousePosEvent(object x, object y) { }

	// RVA: 0x6C3E6D8
	public object AddMouseWheelEvent(object wheel_x, object wheel_y) { }

	// RVA: 0x6C3E78C
	private static object .cctor() { }

}

// Namespace: ImGuiNET
public struct ImDrawCmd
{

	// Fields
	public object ClipRect; // 0xFFFFFFFFFFFFFFF8
	public object TextureId; // 0x8
	public object VtxOffset; // 0x10
	public object IdxOffset; // 0x14
	public object ElemCount; // 0x18
	public object UserCallback; // 0x20
	public object UserCallbackData; // 0x28
}

// Namespace: ImGuiNET
public struct ImDrawCmdPtr
{

	// Fields
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object NativePtr { get; }
	public object ClipRect { get; }
	public object TextureId { get; }
	public object VtxOffset { get; }
	public object IdxOffset { get; }
	public object ElemCount { get; }

	// Methods

	// RVA: 0x6C3E89C
	public object get_NativePtr() { }

	// RVA: 0x6C3E8AC
	public object get_ClipRect() { }

	// RVA: 0x6C3E8EC
	public object get_TextureId() { }

	// RVA: 0x6C3E934
	public object get_VtxOffset() { }

	// RVA: 0x6C3E97C
	public object get_IdxOffset() { }

	// RVA: 0x6C3E9C4
	public object get_ElemCount() { }

}

// Namespace: ImGuiNET
public struct ImDrawCmdHeader
{

	// Fields
	public object ClipRect; // 0xFFFFFFFFFFFFFFF8
	public object TextureId; // 0x8
	public object VtxOffset; // 0x10
}

// Namespace: ImGuiNET
public struct ImDrawData
{

	// Fields
	public object Valid; // 0xFFFFFFFFFFFFFFF8
	public object CmdListsCount; // 0xFFFFFFFFFFFFFFFC
	public object TotalIdxCount; // 0x0
	public object TotalVtxCount; // 0x4
	public object CmdLists; // 0x8
	public object DisplayPos; // 0x18
	public object DisplaySize; // 0x20
	public object FramebufferScale; // 0x28
	public object OwnerViewport; // 0x30
}

// Namespace: ImGuiNET
public struct ImDrawDataPtr
{

	// Fields
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object NativePtr { get; }
	public object CmdListsCount { get; }
	public object TotalIdxCount { get; }
	public object TotalVtxCount { get; }
	public object CmdLists { get; }
	public object DisplayPos { get; }
	public object DisplaySize { get; }
	public object FramebufferScale { get; }
	public object CmdListsRange { get; }

	// Methods

	// RVA: 0x6C3EA0C
	public object get_NativePtr() { }

	// RVA: 0x6C3EA1C
	public object .ctor(object nativePtr) { }

	// RVA: 0x6C3EA2C
	public object get_CmdListsCount() { }

	// RVA: 0x6C3EA74
	public object get_TotalIdxCount() { }

	// RVA: 0x6C3EABC
	public object get_TotalVtxCount() { }

	// RVA: 0x6C3EB04
	public object get_CmdLists() { }

	// RVA: 0x6C3EBF4
	public object get_DisplayPos() { }

	// RVA: 0x6C3EC3C
	public object get_DisplaySize() { }

	// RVA: 0x6C3EC84
	public object get_FramebufferScale() { }

	// RVA: 0x6C3ECCC
	public object get_CmdListsRange() { }

}

// Namespace: ImGuiNET
public struct ImDrawList
{

	// Fields
	public object CmdBuffer; // 0xFFFFFFFFFFFFFFF8
	public object IdxBuffer; // 0x8
	public object VtxBuffer; // 0x18
	public object Flags; // 0x28
	public object _VtxCurrentIdx; // 0x2C
	public object _Data; // 0x30
	public object _VtxWritePtr; // 0x38
	public object _IdxWritePtr; // 0x40
	public object _Path; // 0x48
	public object _CmdHeader; // 0x58
	public object _Splitter; // 0x78
	public object _ClipRectStack; // 0x90
	public object _TextureIdStack; // 0xA0
	public object _FringeScale; // 0xB0
	public object _OwnerName; // 0xB8
}

// Namespace: ImGuiNET
public enum ImDrawListFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object AntiAliasedLines;
	public const object AntiAliasedLinesUseTex;
	public const object AntiAliasedFill;
	public const object AllowVtxOffset;
}

// Namespace: ImGuiNET
public struct ImDrawListSplitter
{

	// Fields
	public object _Current; // 0xFFFFFFFFFFFFFFF8
	public object _Count; // 0xFFFFFFFFFFFFFFFC
	public object _Channels; // 0x0
}

// Namespace: ImGuiNET
public struct ImDrawVert
{

	// Fields
	public object pos; // 0xFFFFFFFFFFFFFFF8
	public object uv; // 0x0
	public object col; // 0x8
}

// Namespace: ImGuiNET
public struct ImDrawVertPtr
{

	// Fields
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <Used4kPagesMap>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: ImGuiNET
public struct ImFont
{

	// Fields
	public object IndexAdvanceX; // 0xFFFFFFFFFFFFFFF8
	public object FallbackAdvanceX; // 0x8
	public object FontSize; // 0xC
	public object IndexLookup; // 0x10
	public object Glyphs; // 0x20
	public object FallbackGlyph; // 0x30
	public object ContainerAtlas; // 0x38
	public object ConfigData; // 0x40
	public object ConfigDataCount; // 0x48
	public object FallbackChar; // 0x4A
	public object EllipsisChar; // 0x4C
	public object EllipsisCharCount; // 0x4E
	public object EllipsisWidth; // 0x50
	public object EllipsisCharStep; // 0x54
	public object DirtyLookupTables; // 0x58
	public object Scale; // 0x5C
	public object Ascent; // 0x60
	public object Descent; // 0x64
	public object MetricsTotalSurface; // 0x68
	public object Used4kPagesMap; // 0x6C
}

// Namespace: ImGuiNET
public struct ImFontPtr
{

	// Fields
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object NativePtr { get; }
	public object Scale { get; }

	// Methods

	// RVA: 0x6C3EDAC
	public object get_NativePtr() { }

	// RVA: 0x6C3EDBC
	public object .ctor(object nativePtr) { }

	// RVA: 0x6C3EDCC
	public object get_Scale() { }

}

// Namespace: ImGuiNET
public struct ImFontAtlas
{

	// Fields
	public object Flags; // 0xFFFFFFFFFFFFFFF8
	public object TexID; // 0x0
	public object TexDesiredWidth; // 0x8
	public object TexGlyphPadding; // 0xC
	public object Locked; // 0x10
	public object UserData; // 0x18
	public object TexReady; // 0x20
	public object TexPixelsUseColors; // 0x21
	public object TexPixelsAlpha8; // 0x28
	public object TexPixelsRGBA32; // 0x30
	public object TexWidth; // 0x38
	public object TexHeight; // 0x3C
	public object TexUvScale; // 0x40
	public object TexUvWhitePixel; // 0x48
	public object Fonts; // 0x50
	public object CustomRects; // 0x60
	public object ConfigData; // 0x70
	public object TexUvLines_0; // 0x80
	public object TexUvLines_1; // 0x90
	public object TexUvLines_2; // 0xA0
	public object TexUvLines_3; // 0xB0
	public object TexUvLines_4; // 0xC0
	public object TexUvLines_5; // 0xD0
	public object TexUvLines_6; // 0xE0
	public object TexUvLines_7; // 0xF0
	public object TexUvLines_8; // 0x100
	public object TexUvLines_9; // 0x110
	public object TexUvLines_10; // 0x120
	public object TexUvLines_11; // 0x130
	public object TexUvLines_12; // 0x140
	public object TexUvLines_13; // 0x150
	public object TexUvLines_14; // 0x160
	public object TexUvLines_15; // 0x170
	public object TexUvLines_16; // 0x180
	public object TexUvLines_17; // 0x190
	public object TexUvLines_18; // 0x1A0
	public object TexUvLines_19; // 0x1B0
	public object TexUvLines_20; // 0x1C0
	public object TexUvLines_21; // 0x1D0
	public object TexUvLines_22; // 0x1E0
	public object TexUvLines_23; // 0x1F0
	public object TexUvLines_24; // 0x200
	public object TexUvLines_25; // 0x210
	public object TexUvLines_26; // 0x220
	public object TexUvLines_27; // 0x230
	public object TexUvLines_28; // 0x240
	public object TexUvLines_29; // 0x250
	public object TexUvLines_30; // 0x260
	public object TexUvLines_31; // 0x270
	public object TexUvLines_32; // 0x280
	public object TexUvLines_33; // 0x290
	public object TexUvLines_34; // 0x2A0
	public object TexUvLines_35; // 0x2B0
	public object TexUvLines_36; // 0x2C0
	public object TexUvLines_37; // 0x2D0
	public object TexUvLines_38; // 0x2E0
	public object TexUvLines_39; // 0x2F0
	public object TexUvLines_40; // 0x300
	public object TexUvLines_41; // 0x310
	public object TexUvLines_42; // 0x320
	public object TexUvLines_43; // 0x330
	public object TexUvLines_44; // 0x340
	public object TexUvLines_45; // 0x350
	public object TexUvLines_46; // 0x360
	public object TexUvLines_47; // 0x370
	public object TexUvLines_48; // 0x380
	public object TexUvLines_49; // 0x390
	public object TexUvLines_50; // 0x3A0
	public object TexUvLines_51; // 0x3B0
	public object TexUvLines_52; // 0x3C0
	public object TexUvLines_53; // 0x3D0
	public object TexUvLines_54; // 0x3E0
	public object TexUvLines_55; // 0x3F0
	public object TexUvLines_56; // 0x400
	public object TexUvLines_57; // 0x410
	public object TexUvLines_58; // 0x420
	public object TexUvLines_59; // 0x430
	public object TexUvLines_60; // 0x440
	public object TexUvLines_61; // 0x450
	public object TexUvLines_62; // 0x460
	public object TexUvLines_63; // 0x470
	public object FontBuilderIO; // 0x480
	public object FontBuilderFlags; // 0x488
	public object PackIdMouseCursors; // 0x48C
	public object PackIdLines; // 0x490
}

// Namespace: ImGuiNET
public struct ImFontAtlasPtr
{

	// Fields
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object NativePtr { get; }
	public object Flags { get; }
	public object Fonts { get; }

	// Methods

	// RVA: 0x6C3EE14
	public object get_NativePtr() { }

	// RVA: 0x6C3EE24
	public object .ctor(object nativePtr) { }

	// RVA: 0x6C3EE34
	public object get_Flags() { }

	// RVA: 0x6C3EE74
	public object get_Fonts() { }

	// RVA: 0x6C3EF64
	public object AddFontDefault() { }

	// RVA: 0x6C3EF7C
	public object AddFontFromFileTTF(object filename, object size_pixels, object font_cfg) { }

	// RVA: 0x6C3F134
	public object Build() { }

	// RVA: 0x6C3F14C
	public object Clear() { }

	// RVA: 0x6C3F158
	public object GetTexDataAsRGBA32(object out_pixels, object out_width, object out_height, object out_bytes_per_pixel) { }

	// RVA: 0x6C3F164
	public object IsBuilt() { }

	// RVA: 0x6C3F17C
	public object SetTexID(object id) { }

}

// Namespace: ImGuiNET
public enum ImFontAtlasFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NoPowerOfTwoHeight;
	public const object NoMouseCursors;
	public const object NoBakedLines;
}

// Namespace: 
public struct <Name>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: ImGuiNET
public struct ImFontConfig
{

	// Fields
	public object FontData; // 0xFFFFFFFFFFFFFFF8
	public object FontDataSize; // 0x0
	public object FontDataOwnedByAtlas; // 0x4
	public object FontNo; // 0x8
	public object SizePixels; // 0xC
	public object OversampleH; // 0x10
	public object OversampleV; // 0x14
	public object PixelSnapH; // 0x18
	public object GlyphExtraSpacing; // 0x1C
	public object GlyphOffset; // 0x24
	public object GlyphRanges; // 0x30
	public object GlyphMinAdvanceX; // 0x38
	public object GlyphMaxAdvanceX; // 0x3C
	public object MergeMode; // 0x40
	public object FontBuilderFlags; // 0x44
	public object RasterizerMultiply; // 0x48
	public object RasterizerDensity; // 0x4C
	public object EllipsisChar; // 0x50
	public object Name; // 0x52
	public object DstFont; // 0x80
}

// Namespace: ImGuiNET
public struct ImFontGlyph
{

	// Fields
	public object Colored; // 0xFFFFFFFFFFFFFFF8
	public object Visible; // 0xFFFFFFFFFFFFFFFC
	public object Codepoint; // 0x0
	public object AdvanceX; // 0x4
	public object X0; // 0x8
	public object Y0; // 0xC
	public object X1; // 0x10
	public object Y1; // 0x14
	public object U0; // 0x18
	public object V0; // 0x1C
	public object U1; // 0x20
	public object V1; // 0x24
}

// Namespace: ImGuiNET
public enum ImGuiBackendFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object HasGamepad;
	public const object HasMouseCursors;
	public const object HasSetMousePos;
	public const object RendererHasVtxOffset;
}

// Namespace: ImGuiNET
public enum ImGuiCol
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Text;
	public const object TextDisabled;
	public const object WindowBg;
	public const object ChildBg;
	public const object PopupBg;
	public const object Border;
	public const object BorderShadow;
	public const object FrameBg;
	public const object FrameBgHovered;
	public const object FrameBgActive;
	public const object TitleBg;
	public const object TitleBgActive;
	public const object TitleBgCollapsed;
	public const object MenuBarBg;
	public const object ScrollbarBg;
	public const object ScrollbarGrab;
	public const object ScrollbarGrabHovered;
	public const object ScrollbarGrabActive;
	public const object CheckMark;
	public const object SliderGrab;
	public const object SliderGrabActive;
	public const object Button;
	public const object ButtonHovered;
	public const object ButtonActive;
	public const object Header;
	public const object HeaderHovered;
	public const object HeaderActive;
	public const object Separator;
	public const object SeparatorHovered;
	public const object SeparatorActive;
	public const object ResizeGrip;
	public const object ResizeGripHovered;
	public const object ResizeGripActive;
	public const object TabHovered;
	public const object Tab;
	public const object TabSelected;
	public const object TabSelectedOverline;
	public const object TabDimmed;
	public const object TabDimmedSelected;
	public const object TabDimmedSelectedOverline;
	public const object PlotLines;
	public const object PlotLinesHovered;
	public const object PlotHistogram;
	public const object PlotHistogramHovered;
	public const object TableHeaderBg;
	public const object TableBorderStrong;
	public const object TableBorderLight;
	public const object TableRowBg;
	public const object TableRowBgAlt;
	public const object TextLink;
	public const object TextSelectedBg;
	public const object DragDropTarget;
	public const object NavHighlight;
	public const object NavWindowingHighlight;
	public const object NavWindowingDimBg;
	public const object ModalWindowDimBg;
	public const object COUNT;
}

// Namespace: ImGuiNET
public enum ImGuiColorEditFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NoAlpha;
	public const object NoPicker;
	public const object NoOptions;
	public const object NoSmallPreview;
	public const object NoInputs;
	public const object NoTooltip;
	public const object NoLabel;
	public const object NoSidePreview;
	public const object NoDragDrop;
	public const object NoBorder;
	public const object AlphaBar;
	public const object AlphaPreview;
	public const object AlphaPreviewHalf;
	public const object HDR;
	public const object DisplayRGB;
	public const object DisplayHSV;
	public const object DisplayHex;
	public const object Uint8;
	public const object Float;
	public const object PickerHueBar;
	public const object PickerHueWheel;
	public const object InputRGB;
	public const object InputHSV;
	public const object DefaultOptions;
	public const object DisplayMask;
	public const object DataTypeMask;
	public const object PickerMask;
	public const object InputMask;
}

// Namespace: ImGuiNET
public enum ImGuiComboFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object PopupAlignLeft;
	public const object HeightSmall;
	public const object HeightRegular;
	public const object HeightLarge;
	public const object HeightLargest;
	public const object NoArrowButton;
	public const object NoPreview;
	public const object WidthFitPreview;
	public const object HeightMask;
}

// Namespace: ImGuiNET
public enum ImGuiCond
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Always;
	public const object Once;
	public const object FirstUseEver;
	public const object Appearing;
}

// Namespace: ImGuiNET
public enum ImGuiConfigFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NavEnableKeyboard;
	public const object NavEnableGamepad;
	public const object NavEnableSetMousePos;
	public const object NavNoCaptureKeyboard;
	public const object NoMouse;
	public const object NoMouseCursorChange;
	public const object NoKeyboard;
	public const object IsSRGB;
	public const object IsTouchScreen;
}

// Namespace: ImGuiNET
public enum ImGuiDataType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object S8;
	public const object U8;
	public const object S16;
	public const object U16;
	public const object S32;
	public const object U32;
	public const object S64;
	public const object U64;
	public const object Float;
	public const object Double;
	public const object Bool;
	public const object COUNT;
}

// Namespace: ImGuiNET
public enum ImGuiDir
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Left;
	public const object Right;
	public const object Up;
	public const object Down;
	public const object COUNT;
}

// Namespace: ImGuiNET
public enum ImGuiHoveredFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ChildWindows;
	public const object RootWindow;
	public const object AnyWindow;
	public const object NoPopupHierarchy;
	public const object AllowWhenBlockedByPopup;
	public const object AllowWhenBlockedByActiveItem;
	public const object AllowWhenOverlappedByItem;
	public const object AllowWhenOverlappedByWindow;
	public const object AllowWhenDisabled;
	public const object NoNavOverride;
	public const object AllowWhenOverlapped;
	public const object RectOnly;
	public const object RootAndChildWindows;
	public const object ForTooltip;
	public const object Stationary;
	public const object DelayNone;
	public const object DelayShort;
	public const object DelayNormal;
	public const object NoSharedDelay;
}

// Namespace: ImGuiNET
public struct ImGuiInputTextCallbackData
{

	// Fields
	public object Ctx; // 0xFFFFFFFFFFFFFFF8
	public object EventFlag; // 0x0
	public object Flags; // 0x4
	public object UserData; // 0x8
	public object EventChar; // 0x10
	public object EventKey; // 0x14
	public object Buf; // 0x18
	public object BufTextLen; // 0x20
	public object BufSize; // 0x24
	public object BufDirty; // 0x28
	public object CursorPos; // 0x2C
	public object SelectionStart; // 0x30
	public object SelectionEnd; // 0x34
}

// Namespace: ImGuiNET
public enum ImGuiInputTextFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object CharsDecimal;
	public const object CharsHexadecimal;
	public const object CharsScientific;
	public const object CharsUppercase;
	public const object CharsNoBlank;
	public const object AllowTabInput;
	public const object EnterReturnsTrue;
	public const object EscapeClearsAll;
	public const object CtrlEnterForNewLine;
	public const object ReadOnly;
	public const object Password;
	public const object AlwaysOverwrite;
	public const object AutoSelectAll;
	public const object ParseEmptyRefVal;
	public const object DisplayEmptyRefVal;
	public const object NoHorizontalScroll;
	public const object NoUndoRedo;
	public const object CallbackCompletion;
	public const object CallbackHistory;
	public const object CallbackAlways;
	public const object CallbackCharFilter;
	public const object CallbackResize;
	public const object CallbackEdit;
}

// Namespace: 
public struct <MouseClicked>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseClickedCount>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseClickedLastCount>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseClickedTime>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseDoubleClicked>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseDown>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseDownDuration>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseDownDurationPrev>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseDownOwned>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseDownOwnedUnlessPopupClose>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseDragMaxDistanceSqr>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <MouseReleased>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: ImGuiNET
public struct ImGuiIO
{

	// Fields
	public object ConfigFlags; // 0xFFFFFFFFFFFFFFF8
	public object BackendFlags; // 0xFFFFFFFFFFFFFFFC
	public object DisplaySize; // 0x0
	public object DeltaTime; // 0x8
	public object IniSavingRate; // 0xC
	public object IniFilename; // 0x10
	public object LogFilename; // 0x18
	public object UserData; // 0x20
	public object Fonts; // 0x28
	public object FontGlobalScale; // 0x30
	public object FontAllowUserScaling; // 0x34
	public object FontDefault; // 0x38
	public object DisplayFramebufferScale; // 0x40
	public object MouseDrawCursor; // 0x48
	public object ConfigMacOSXBehaviors; // 0x49
	public object ConfigNavSwapGamepadButtons; // 0x4A
	public object ConfigInputTrickleEventQueue; // 0x4B
	public object ConfigInputTextCursorBlink; // 0x4C
	public object ConfigInputTextEnterKeepActive; // 0x4D
	public object ConfigDragClickToInputText; // 0x4E
	public object ConfigWindowsResizeFromEdges; // 0x4F
	public object ConfigWindowsMoveFromTitleBarOnly; // 0x50
	public object ConfigMemoryCompactTimer; // 0x54
	public object MouseDoubleClickTime; // 0x58
	public object MouseDoubleClickMaxDist; // 0x5C
	public object MouseDragThreshold; // 0x60
	public object KeyRepeatDelay; // 0x64
	public object KeyRepeatRate; // 0x68
	public object ConfigDebugIsDebuggerPresent; // 0x6C
	public object ConfigDebugBeginReturnValueOnce; // 0x6D
	public object ConfigDebugBeginReturnValueLoop; // 0x6E
	public object ConfigDebugIgnoreFocusLoss; // 0x6F
	public object ConfigDebugIniSettings; // 0x70
	public object BackendPlatformName; // 0x78
	public object BackendRendererName; // 0x80
	public object BackendPlatformUserData; // 0x88
	public object BackendRendererUserData; // 0x90
	public object BackendLanguageUserData; // 0x98
	public object GetClipboardTextFn; // 0xA0
	public object SetClipboardTextFn; // 0xA8
	public object ClipboardUserData; // 0xB0
	public object PlatformOpenInShellFn; // 0xB8
	public object PlatformOpenInShellUserData; // 0xC0
	public object PlatformSetImeDataFn; // 0xC8
	public object PlatformLocaleDecimalPoint; // 0xD0
	public object WantCaptureMouse; // 0xD2
	public object WantCaptureKeyboard; // 0xD3
	public object WantTextInput; // 0xD4
	public object WantSetMousePos; // 0xD5
	public object WantSaveIniSettings; // 0xD6
	public object NavActive; // 0xD7
	public object NavVisible; // 0xD8
	public object Framerate; // 0xDC
	public object MetricsRenderVertices; // 0xE0
	public object MetricsRenderIndices; // 0xE4
	public object MetricsRenderWindows; // 0xE8
	public object MetricsActiveWindows; // 0xEC
	public object MouseDelta; // 0xF0
	public object Ctx; // 0xF8
	public object MousePos; // 0x100
	public object MouseDown; // 0x108
	public object MouseWheel; // 0x110
	public object MouseWheelH; // 0x114
	public object MouseSource; // 0x118
	public object KeyCtrl; // 0x11C
	public object KeyShift; // 0x11D
	public object KeyAlt; // 0x11E
	public object KeySuper; // 0x11F
	public object KeyMods; // 0x120
	public object KeysData_0; // 0x124
	public object KeysData_1; // 0x134
	public object KeysData_2; // 0x144
	public object KeysData_3; // 0x154
	public object KeysData_4; // 0x164
	public object KeysData_5; // 0x174
	public object KeysData_6; // 0x184
	public object KeysData_7; // 0x194
	public object KeysData_8; // 0x1A4
	public object KeysData_9; // 0x1B4
	public object KeysData_10; // 0x1C4
	public object KeysData_11; // 0x1D4
	public object KeysData_12; // 0x1E4
	public object KeysData_13; // 0x1F4
	public object KeysData_14; // 0x204
	public object KeysData_15; // 0x214
	public object KeysData_16; // 0x224
	public object KeysData_17; // 0x234
	public object KeysData_18; // 0x244
	public object KeysData_19; // 0x254
	public object KeysData_20; // 0x264
	public object KeysData_21; // 0x274
	public object KeysData_22; // 0x284
	public object KeysData_23; // 0x294
	public object KeysData_24; // 0x2A4
	public object KeysData_25; // 0x2B4
	public object KeysData_26; // 0x2C4
	public object KeysData_27; // 0x2D4
	public object KeysData_28; // 0x2E4
	public object KeysData_29; // 0x2F4
	public object KeysData_30; // 0x304
	public object KeysData_31; // 0x314
	public object KeysData_32; // 0x324
	public object KeysData_33; // 0x334
	public object KeysData_34; // 0x344
	public object KeysData_35; // 0x354
	public object KeysData_36; // 0x364
	public object KeysData_37; // 0x374
	public object KeysData_38; // 0x384
	public object KeysData_39; // 0x394
	public object KeysData_40; // 0x3A4
	public object KeysData_41; // 0x3B4
	public object KeysData_42; // 0x3C4
	public object KeysData_43; // 0x3D4
	public object KeysData_44; // 0x3E4
	public object KeysData_45; // 0x3F4
	public object KeysData_46; // 0x404
	public object KeysData_47; // 0x414
	public object KeysData_48; // 0x424
	public object KeysData_49; // 0x434
	public object KeysData_50; // 0x444
	public object KeysData_51; // 0x454
	public object KeysData_52; // 0x464
	public object KeysData_53; // 0x474
	public object KeysData_54; // 0x484
	public object KeysData_55; // 0x494
	public object KeysData_56; // 0x4A4
	public object KeysData_57; // 0x4B4
	public object KeysData_58; // 0x4C4
	public object KeysData_59; // 0x4D4
	public object KeysData_60; // 0x4E4
	public object KeysData_61; // 0x4F4
	public object KeysData_62; // 0x504
	public object KeysData_63; // 0x514
	public object KeysData_64; // 0x524
	public object KeysData_65; // 0x534
	public object KeysData_66; // 0x544
	public object KeysData_67; // 0x554
	public object KeysData_68; // 0x564
	public object KeysData_69; // 0x574
	public object KeysData_70; // 0x584
	public object KeysData_71; // 0x594
	public object KeysData_72; // 0x5A4
	public object KeysData_73; // 0x5B4
	public object KeysData_74; // 0x5C4
	public object KeysData_75; // 0x5D4
	public object KeysData_76; // 0x5E4
	public object KeysData_77; // 0x5F4
	public object KeysData_78; // 0x604
	public object KeysData_79; // 0x614
	public object KeysData_80; // 0x624
	public object KeysData_81; // 0x634
	public object KeysData_82; // 0x644
	public object KeysData_83; // 0x654
	public object KeysData_84; // 0x664
	public object KeysData_85; // 0x674
	public object KeysData_86; // 0x684
	public object KeysData_87; // 0x694
	public object KeysData_88; // 0x6A4
	public object KeysData_89; // 0x6B4
	public object KeysData_90; // 0x6C4
	public object KeysData_91; // 0x6D4
	public object KeysData_92; // 0x6E4
	public object KeysData_93; // 0x6F4
	public object KeysData_94; // 0x704
	public object KeysData_95; // 0x714
	public object KeysData_96; // 0x724
	public object KeysData_97; // 0x734
	public object KeysData_98; // 0x744
	public object KeysData_99; // 0x754
	public object KeysData_100; // 0x764
	public object KeysData_101; // 0x774
	public object KeysData_102; // 0x784
	public object KeysData_103; // 0x794
	public object KeysData_104; // 0x7A4
	public object KeysData_105; // 0x7B4
	public object KeysData_106; // 0x7C4
	public object KeysData_107; // 0x7D4
	public object KeysData_108; // 0x7E4
	public object KeysData_109; // 0x7F4
	public object KeysData_110; // 0x804
	public object KeysData_111; // 0x814
	public object KeysData_112; // 0x824
	public object KeysData_113; // 0x834
	public object KeysData_114; // 0x844
	public object KeysData_115; // 0x854
	public object KeysData_116; // 0x864
	public object KeysData_117; // 0x874
	public object KeysData_118; // 0x884
	public object KeysData_119; // 0x894
	public object KeysData_120; // 0x8A4
	public object KeysData_121; // 0x8B4
	public object KeysData_122; // 0x8C4
	public object KeysData_123; // 0x8D4
	public object KeysData_124; // 0x8E4
	public object KeysData_125; // 0x8F4
	public object KeysData_126; // 0x904
	public object KeysData_127; // 0x914
	public object KeysData_128; // 0x924
	public object KeysData_129; // 0x934
	public object KeysData_130; // 0x944
	public object KeysData_131; // 0x954
	public object KeysData_132; // 0x964
	public object KeysData_133; // 0x974
	public object KeysData_134; // 0x984
	public object KeysData_135; // 0x994
	public object KeysData_136; // 0x9A4
	public object KeysData_137; // 0x9B4
	public object KeysData_138; // 0x9C4
	public object KeysData_139; // 0x9D4
	public object KeysData_140; // 0x9E4
	public object KeysData_141; // 0x9F4
	public object KeysData_142; // 0xA04
	public object KeysData_143; // 0xA14
	public object KeysData_144; // 0xA24
	public object KeysData_145; // 0xA34
	public object KeysData_146; // 0xA44
	public object KeysData_147; // 0xA54
	public object KeysData_148; // 0xA64
	public object KeysData_149; // 0xA74
	public object KeysData_150; // 0xA84
	public object KeysData_151; // 0xA94
	public object KeysData_152; // 0xAA4
	public object KeysData_153; // 0xAB4
	public object WantCaptureMouseUnlessPopupClose; // 0xAC4
	public object MousePosPrev; // 0xAC8
	public object MouseClickedPos_0; // 0xAD0
	public object MouseClickedPos_1; // 0xAD8
	public object MouseClickedPos_2; // 0xAE0
	public object MouseClickedPos_3; // 0xAE8
	public object MouseClickedPos_4; // 0xAF0
	public object MouseClickedTime; // 0xAF8
	public object MouseClicked; // 0xB20
	public object MouseDoubleClicked; // 0xB25
	public object MouseClickedCount; // 0xB2A
	public object MouseClickedLastCount; // 0xB34
	public object MouseReleased; // 0xB3E
	public object MouseDownOwned; // 0xB43
	public object MouseDownOwnedUnlessPopupClose; // 0xB48
	public object MouseWheelRequestAxisSwap; // 0xB4D
	public object MouseCtrlLeftAsRightClick; // 0xB4E
	public object MouseDownDuration; // 0xB50
	public object MouseDownDurationPrev; // 0xB64
	public object MouseDragMaxDistanceSqr; // 0xB78
	public object PenPressure; // 0xB8C
	public object AppFocusLost; // 0xB90
	public object AppAcceptingEvents; // 0xB91
	public object BackendUsingLegacyKeyArrays; // 0xB92
	public object BackendUsingLegacyNavInputArray; // 0xB93
	public object InputQueueSurrogate; // 0xB94
	public object InputQueueCharacters; // 0xB98
}

// Namespace: ImGuiNET
public enum ImGuiKey
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Tab;
	public const object LeftArrow;
	public const object RightArrow;
	public const object UpArrow;
	public const object DownArrow;
	public const object PageUp;
	public const object PageDown;
	public const object Home;
	public const object End;
	public const object Insert;
	public const object Delete;
	public const object Backspace;
	public const object Space;
	public const object Enter;
	public const object Escape;
	public const object LeftCtrl;
	public const object LeftShift;
	public const object LeftAlt;
	public const object LeftSuper;
	public const object RightCtrl;
	public const object RightShift;
	public const object RightAlt;
	public const object RightSuper;
	public const object Menu;
	public const object _0;
	public const object _1;
	public const object _2;
	public const object _3;
	public const object _4;
	public const object _5;
	public const object _6;
	public const object _7;
	public const object _8;
	public const object _9;
	public const object A;
	public const object B;
	public const object C;
	public const object D;
	public const object E;
	public const object F;
	public const object G;
	public const object H;
	public const object I;
	public const object J;
	public const object K;
	public const object L;
	public const object M;
	public const object N;
	public const object O;
	public const object P;
	public const object Q;
	public const object R;
	public const object S;
	public const object T;
	public const object U;
	public const object V;
	public const object W;
	public const object X;
	public const object Y;
	public const object Z;
	public const object F1;
	public const object F2;
	public const object F3;
	public const object F4;
	public const object F5;
	public const object F6;
	public const object F7;
	public const object F8;
	public const object F9;
	public const object F10;
	public const object F11;
	public const object F12;
	public const object F13;
	public const object F14;
	public const object F15;
	public const object F16;
	public const object F17;
	public const object F18;
	public const object F19;
	public const object F20;
	public const object F21;
	public const object F22;
	public const object F23;
	public const object F24;
	public const object Apostrophe;
	public const object Comma;
	public const object Minus;
	public const object Period;
	public const object Slash;
	public const object Semicolon;
	public const object Equal;
	public const object LeftBracket;
	public const object Backslash;
	public const object RightBracket;
	public const object GraveAccent;
	public const object CapsLock;
	public const object ScrollLock;
	public const object NumLock;
	public const object PrintScreen;
	public const object Pause;
	public const object Keypad0;
	public const object Keypad1;
	public const object Keypad2;
	public const object Keypad3;
	public const object Keypad4;
	public const object Keypad5;
	public const object Keypad6;
	public const object Keypad7;
	public const object Keypad8;
	public const object Keypad9;
	public const object KeypadDecimal;
	public const object KeypadDivide;
	public const object KeypadMultiply;
	public const object KeypadSubtract;
	public const object KeypadAdd;
	public const object KeypadEnter;
	public const object KeypadEqual;
	public const object AppBack;
	public const object AppForward;
	public const object GamepadStart;
	public const object GamepadBack;
	public const object GamepadFaceLeft;
	public const object GamepadFaceRight;
	public const object GamepadFaceUp;
	public const object GamepadFaceDown;
	public const object GamepadDpadLeft;
	public const object GamepadDpadRight;
	public const object GamepadDpadUp;
	public const object GamepadDpadDown;
	public const object GamepadL1;
	public const object GamepadR1;
	public const object GamepadL2;
	public const object GamepadR2;
	public const object GamepadL3;
	public const object GamepadR3;
	public const object GamepadLStickLeft;
	public const object GamepadLStickRight;
	public const object GamepadLStickUp;
	public const object GamepadLStickDown;
	public const object GamepadRStickLeft;
	public const object GamepadRStickRight;
	public const object GamepadRStickUp;
	public const object GamepadRStickDown;
	public const object MouseLeft;
	public const object MouseRight;
	public const object MouseMiddle;
	public const object MouseX1;
	public const object MouseX2;
	public const object MouseWheelX;
	public const object MouseWheelY;
	public const object ReservedForModCtrl;
	public const object ReservedForModShift;
	public const object ReservedForModAlt;
	public const object ReservedForModSuper;
	public const object COUNT;
	public const object ModNone;
	public const object ModCtrl;
	public const object ModShift;
	public const object ModAlt;
	public const object ModSuper;
	public const object ModMask;
	public const object NamedKey_BEGIN;
	public const object NamedKey_END;
	public const object NamedKey_COUNT;
	public const object KeysData_SIZE;
	public const object KeysData_OFFSET;
}

// Namespace: ImGuiNET
public struct ImGuiKeyData
{

	// Fields
	public object Down; // 0xFFFFFFFFFFFFFFF8
	public object DownDuration; // 0xFFFFFFFFFFFFFFFC
	public object DownDurationPrev; // 0x0
	public object AnalogValue; // 0x4
}

// Namespace: ImGuiNET
public enum ImGuiMouseButton
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
	public const object Middle;
	public const object COUNT;
}

// Namespace: ImGuiNET
public enum ImGuiMouseCursor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Arrow;
	public const object TextInput;
	public const object ResizeAll;
	public const object ResizeNS;
	public const object ResizeEW;
	public const object ResizeNESW;
	public const object ResizeNWSE;
	public const object Hand;
	public const object NotAllowed;
	public const object COUNT;
}

// Namespace: ImGuiNET
public enum ImGuiMouseSource
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Mouse;
	public const object TouchScreen;
	public const object Pen;
	public const object COUNT;
}

// Namespace: ImGuiNET
public static class ImGuiNative
{

	// Methods

	// RVA: 0x6C369BC
	public static object igAlignTextToFramePadding() { }

	// RVA: 0x6C36CA0
	public static object igBegin(object name, object p_open, object flags) { }

	// RVA: 0x6C3725C
	public static object igBeginCombo(object label, object preview_value, object flags) { }

	// RVA: 0x6C37268
	public static object igBeginDisabled(object disabled) { }

	// RVA: 0x6C3741C
	public static object igBeginMenu(object label, object enabled) { }

	// RVA: 0x6C3742C
	public static object igBeginMenuBar() { }

	// RVA: 0x6C375E0
	public static object igBeginTable(object str_id, object columns, object flags, object outer_size, object inner_width) { }

	// RVA: 0x6C37794
	public static object igButton(object label, object size) { }

	// RVA: 0x6C37B10
	public static object igCheckbox(object label, object v) { }

	// RVA: 0x6C37CC4
	public static object igCollapsingHeader_TreeNodeFlags(object label, object flags) { }

	// RVA: 0x6C38024
	public static object igColorButton(object desc_id, object col, object flags, object size) { }

	// RVA: 0x6C381D8
	public static object igColorEdit3(object label, object col, object flags) { }

	// RVA: 0x6C3838C
	public static object igColorEdit4(object label, object col, object flags) { }

	// RVA: 0x6C38398
	public static object igColumns(object count, object id, object border) { }

	// RVA: 0x6C38910
	public static object igCombo_Str_arr(object label, object current_item, object items, object items_count, object popup_max_height_in_items) { }

	// RVA: 0x6C38920
	public static object igCreateContext(object shared_font_atlas) { }

	// RVA: 0x6C3892C
	public static object igDestroyContext(object ctx) { }

	// RVA: 0x6C38C98
	public static object igDragFloat(object label, object v, object v_speed, object v_min, object v_max, object format, object flags) { }

	// RVA: 0x6C38E4C
	public static object igDragScalar(object label, object data_type, object p_data, object v_speed, object p_min, object p_max, object format, object flags) { }

	// RVA: 0x6C38E58
	public static object igEnd() { }

	// RVA: 0x6C38E60
	public static object igEndCombo() { }

	// RVA: 0x6C38E68
	public static object igEndDisabled() { }

	// RVA: 0x6C38E70
	public static object igEndMenu() { }

	// RVA: 0x6C38E78
	public static object igEndMenuBar() { }

	// RVA: 0x6C38E80
	public static object igEndTable() { }

	// RVA: 0x6C38E8C
	public static object igGetColumnWidth(object column_index) { }

	// RVA: 0x6C38EA0
	public static object igGetContentRegionAvail(object pOut) { }

	// RVA: 0x6C38EAC
	public static object igGetDrawData() { }

	// RVA: 0x6C38EBC
	public static object igGetFont() { }

	// RVA: 0x6C39070
	public static object igGetID_Str(object str_id) { }

	// RVA: 0x6C39080
	public static object igGetIO() { }

	// RVA: 0x6C39090
	public static object igGetMouseCursor() { }

	// RVA: 0x6C390A0
	public static object igGetScrollX() { }

	// RVA: 0x6C390B0
	public static object igGetScrollY() { }

	// RVA: 0x6C390C0
	public static object igGetStyle() { }

	// RVA: 0x6C390D4
	public static object igGetWindowPos(object pOut) { }

	// RVA: 0x6C390E4
	public static object igGetWindowSize(object pOut) { }

	// RVA: 0x6C390F0
	public static object igGetWindowWidth() { }

	// RVA: 0x6C390FC
	public static object igImage(object user_texture_id, object image_size, object uv0, object uv1, object tint_col, object border_col) { }

	// RVA: 0x6C39104
	public static object igIndent(object indent_w) { }

	// RVA: 0x6C3C21C
	public static object igInputText(object label, object buf, object buf_size, object flags, object callback, object user_data) { }

	// RVA: 0x6C39110
	public static object igIsItemClicked(object mouse_button) { }

	// RVA: 0x6C39120
	public static object igIsItemHovered(object flags) { }

	// RVA: 0x6C39130
	public static object igIsMouseDown_Nil(object button) { }

	// RVA: 0x6C39140
	public static object igIsMouseDragging(object button, object lock_threshold) { }

	// RVA: 0x6C39150
	public static object igIsMouseReleased_Nil(object button) { }

	// RVA: 0x6C3949C
	public static object igLabelText(object label, object fmt) { }

	// RVA: 0x6C39648
	public static object igLoadIniSettingsFromMemory(object ini_data, object ini_size) { }

	// RVA: 0x6C39994
	public static object igMenuItem_Bool(object label, object shortcut, object selected, object enabled) { }

	// RVA: 0x6C399A0
	public static object igNewFrame() { }

	// RVA: 0x6C399A8
	public static object igNextColumn() { }

	// RVA: 0x6C39B54
	public static object igPlotLines_FloatPtr(object label, object values, object values_count, object values_offset, object overlay_text, object scale_min, object scale_max, object graph_size, object stride) { }

	// RVA: 0x6C39B5C
	public static object igPopID() { }

	// RVA: 0x6C39B64
	public static object igPopStyleColor(object count) { }

	// RVA: 0x6C39B70
	public static object igPopStyleVar(object count) { }

	// RVA: 0x6C39D1C
	public static object igPushID_Str(object str_id) { }

	// RVA: 0x6C39D24
	public static object igPushID_Int(object int_id) { }

	// RVA: 0x6C39D2C
	public static object igPushStyleColor_Vec4(object idx, object col) { }

	// RVA: 0x6C39D34
	public static object igPushStyleVar_Float(object idx, object val) { }

	// RVA: 0x6C39EE4
	public static object igRadioButton_Bool(object label, object active) { }

	// RVA: 0x6C39EF0
	public static object igRender() { }

	// RVA: 0x6C39EF8
	public static object igSameLine(object offset_from_start_x, object spacing) { }

	// RVA: 0x6C39F4C
	public static object igSaveIniSettingsToMemory(object out_ini_size) { }

	// RVA: 0x6C3A150
	public static object igSelectable_Bool(object label, object selected, object flags, object size) { }

	// RVA: 0x6C3A4B4
	public static object igSeparator() { }

	// RVA: 0x6C3A660
	public static object igSeparatorText(object label) { }

	// RVA: 0x6C3A668
	public static object igSetColumnWidth(object column_index, object width) { }

	// RVA: 0x6C3A670
	public static object igSetCurrentContext(object ctx) { }

	// RVA: 0x6C3A678
	public static object igSetNextItemAllowOverlap() { }

	// RVA: 0x6C3A680
	public static object igSetNextItemWidth(object item_width) { }

	// RVA: 0x6C3A688
	public static object igSetNextWindowBgAlpha(object alpha) { }

	// RVA: 0x6C3A690
	public static object igSetNextWindowPos(object pos, object cond, object pivot) { }

	// RVA: 0x6C3A698
	public static object igSetNextWindowSize(object size, object cond) { }

	// RVA: 0x6C3A6A0
	public static object igSetScrollX_Float(object scroll_x) { }

	// RVA: 0x6C3A6A8
	public static object igSetScrollY_Float(object scroll_y) { }

	// RVA: 0x6C3A6B0
	public static object igSetWindowFocus_Nil() { }

	// RVA: 0x6C3A6B8
	public static object igSetWindowSize_Vec2(object size, object cond) { }

	// RVA: 0x6C3AA24
	public static object igSliderFloat(object label, object v, object v_min, object v_max, object format, object flags) { }

	// RVA: 0x6C3B0DC
	public static object igSliderFloat4(object label, object v, object v_min, object v_max, object format, object flags) { }

	// RVA: 0x6C3B44C
	public static object igSliderInt(object label, object v, object v_min, object v_max, object format, object flags) { }

	// RVA: 0x6C3B458
	public static object igTableHeadersRow() { }

	// RVA: 0x6C3B464
	public static object igTableNextColumn() { }

	// RVA: 0x6C3B470
	public static object igTableNextRow(object row_flags, object min_row_height) { }

	// RVA: 0x6C3B47C
	public static object igTableSetColumnIndex(object column_n) { }

	// RVA: 0x6C3B62C
	public static object igTableSetupColumn(object label, object flags, object init_width_or_weight, object user_id) { }

	// RVA: 0x6C3B634
	public static object igTableSetupScrollFreeze(object cols, object rows) { }

	// RVA: 0x6C3B7E0
	public static object igText(object fmt) { }

	// RVA: 0x6C3B98C
	public static object igTextColored(object col, object fmt) { }

	// RVA: 0x6C3BB3C
	public static object igTreeNode_Str(object label) { }

	// RVA: 0x6C3BCF0
	public static object igTreeNodeEx_Str(object label, object flags) { }

	// RVA: 0x6C3BCFC
	public static object igTreePop() { }

	// RVA: 0x6C3BD04
	public static object igUnindent(object indent_w) { }

	// RVA: 0x6C3EF6C
	public static object ImFontAtlas_AddFontDefault(object self, object font_cfg) { }

	// RVA: 0x6C3F128
	public static object ImFontAtlas_AddFontFromFileTTF(object self, object filename, object size_pixels, object font_cfg, object glyph_ranges) { }

	// RVA: 0x6C3F13C
	public static object ImFontAtlas_Build(object self) { }

	// RVA: 0x6C3F150
	public static object ImFontAtlas_Clear(object self) { }

	// RVA: 0x6C3F188
	public static object ImFontAtlas_GetGlyphRangesChineseFull(object self) { }

	// RVA: 0x6C3F190
	public static object ImFontAtlas_GetGlyphRangesChineseSimplifiedCommon(object self) { }

	// RVA: 0x6C3F198
	public static object ImFontAtlas_GetGlyphRangesCyrillic(object self) { }

	// RVA: 0x6C3F1A0
	public static object ImFontAtlas_GetGlyphRangesDefault(object self) { }

	// RVA: 0x6C3F1A8
	public static object ImFontAtlas_GetGlyphRangesJapanese(object self) { }

	// RVA: 0x6C3F1B0
	public static object ImFontAtlas_GetGlyphRangesKorean(object self) { }

	// RVA: 0x6C3F1B8
	public static object ImFontAtlas_GetGlyphRangesThai(object self) { }

	// RVA: 0x6C3F1C0
	public static object ImFontAtlas_GetGlyphRangesVietnamese(object self) { }

	// RVA: 0x6C3F15C
	public static object ImFontAtlas_GetTexDataAsRGBA32(object self, object out_pixels, object out_width, object out_height, object out_bytes_per_pixel) { }

	// RVA: 0x6C3F16C
	public static object ImFontAtlas_IsBuilt(object self) { }

	// RVA: 0x6C3F180
	public static object ImFontAtlas_SetTexID(object self, object id) { }

	// RVA: 0x6C3E460
	public static object ImGuiIO_AddInputCharacter(object self, object c) { }

	// RVA: 0x6C3E514
	public static object ImGuiIO_AddKeyEvent(object self, object key, object down) { }

	// RVA: 0x6C3E5C8
	public static object ImGuiIO_AddMouseButtonEvent(object self, object button, object down) { }

	// RVA: 0x6C3E67C
	public static object ImGuiIO_AddMousePosEvent(object self, object x, object y) { }

	// RVA: 0x6C3E730
	public static object ImGuiIO_AddMouseWheelEvent(object self, object wheel_x, object wheel_y) { }

}

// Namespace: ImGuiNET
public enum ImGuiSelectableFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NoAutoClosePopups;
	public const object SpanAllColumns;
	public const object AllowDoubleClick;
	public const object Disabled;
	public const object AllowOverlap;
	public const object Highlight;
}

// Namespace: ImGuiNET
public enum ImGuiSliderFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object AlwaysClamp;
	public const object Logarithmic;
	public const object NoRoundToFormat;
	public const object NoInput;
	public const object WrapAround;
	public const object InvalidMask;
}

// Namespace: ImGuiNET
public struct ImGuiStyle
{

	// Fields
	public object Alpha; // 0xFFFFFFFFFFFFFFF8
	public object DisabledAlpha; // 0xFFFFFFFFFFFFFFFC
	public object WindowPadding; // 0x0
	public object WindowRounding; // 0x8
	public object WindowBorderSize; // 0xC
	public object WindowMinSize; // 0x10
	public object WindowTitleAlign; // 0x18
	public object WindowMenuButtonPosition; // 0x20
	public object ChildRounding; // 0x24
	public object ChildBorderSize; // 0x28
	public object PopupRounding; // 0x2C
	public object PopupBorderSize; // 0x30
	public object FramePadding; // 0x34
	public object FrameRounding; // 0x3C
	public object FrameBorderSize; // 0x40
	public object ItemSpacing; // 0x44
	public object ItemInnerSpacing; // 0x4C
	public object CellPadding; // 0x54
	public object TouchExtraPadding; // 0x5C
	public object IndentSpacing; // 0x64
	public object ColumnsMinSpacing; // 0x68
	public object ScrollbarSize; // 0x6C
	public object ScrollbarRounding; // 0x70
	public object GrabMinSize; // 0x74
	public object GrabRounding; // 0x78
	public object LogSliderDeadzone; // 0x7C
	public object TabRounding; // 0x80
	public object TabBorderSize; // 0x84
	public object TabMinWidthForCloseButton; // 0x88
	public object TabBarBorderSize; // 0x8C
	public object TabBarOverlineSize; // 0x90
	public object TableAngledHeadersAngle; // 0x94
	public object TableAngledHeadersTextAlign; // 0x98
	public object ColorButtonPosition; // 0xA0
	public object ButtonTextAlign; // 0xA4
	public object SelectableTextAlign; // 0xAC
	public object SeparatorTextBorderSize; // 0xB4
	public object SeparatorTextAlign; // 0xB8
	public object SeparatorTextPadding; // 0xC0
	public object DisplayWindowPadding; // 0xC8
	public object DisplaySafeAreaPadding; // 0xD0
	public object MouseCursorScale; // 0xD8
	public object AntiAliasedLines; // 0xDC
	public object AntiAliasedLinesUseTex; // 0xDD
	public object AntiAliasedFill; // 0xDE
	public object CurveTessellationTol; // 0xE0
	public object CircleTessellationMaxError; // 0xE4
	public object Colors_0; // 0xE8
	public object Colors_1; // 0xF8
	public object Colors_2; // 0x108
	public object Colors_3; // 0x118
	public object Colors_4; // 0x128
	public object Colors_5; // 0x138
	public object Colors_6; // 0x148
	public object Colors_7; // 0x158
	public object Colors_8; // 0x168
	public object Colors_9; // 0x178
	public object Colors_10; // 0x188
	public object Colors_11; // 0x198
	public object Colors_12; // 0x1A8
	public object Colors_13; // 0x1B8
	public object Colors_14; // 0x1C8
	public object Colors_15; // 0x1D8
	public object Colors_16; // 0x1E8
	public object Colors_17; // 0x1F8
	public object Colors_18; // 0x208
	public object Colors_19; // 0x218
	public object Colors_20; // 0x228
	public object Colors_21; // 0x238
	public object Colors_22; // 0x248
	public object Colors_23; // 0x258
	public object Colors_24; // 0x268
	public object Colors_25; // 0x278
	public object Colors_26; // 0x288
	public object Colors_27; // 0x298
	public object Colors_28; // 0x2A8
	public object Colors_29; // 0x2B8
	public object Colors_30; // 0x2C8
	public object Colors_31; // 0x2D8
	public object Colors_32; // 0x2E8
	public object Colors_33; // 0x2F8
	public object Colors_34; // 0x308
	public object Colors_35; // 0x318
	public object Colors_36; // 0x328
	public object Colors_37; // 0x338
	public object Colors_38; // 0x348
	public object Colors_39; // 0x358
	public object Colors_40; // 0x368
	public object Colors_41; // 0x378
	public object Colors_42; // 0x388
	public object Colors_43; // 0x398
	public object Colors_44; // 0x3A8
	public object Colors_45; // 0x3B8
	public object Colors_46; // 0x3C8
	public object Colors_47; // 0x3D8
	public object Colors_48; // 0x3E8
	public object Colors_49; // 0x3F8
	public object Colors_50; // 0x408
	public object Colors_51; // 0x418
	public object Colors_52; // 0x428
	public object Colors_53; // 0x438
	public object Colors_54; // 0x448
	public object Colors_55; // 0x458
	public object HoverStationaryDelay; // 0x468
	public object HoverDelayShort; // 0x46C
	public object HoverDelayNormal; // 0x470
	public object HoverFlagsForTooltipMouse; // 0x474
	public object HoverFlagsForTooltipNav; // 0x478
}

// Namespace: ImGuiNET
public struct ImGuiStylePtr
{

	// Fields
	private readonly object <NativePtr>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object NativePtr { get; }
	public object Alpha { get; }
	public object WindowPadding { get; }
	public object WindowRounding { get; }
	public object WindowBorderSize { get; }
	public object WindowMinSize { get; }
	public object WindowTitleAlign { get; }
	public object WindowMenuButtonPosition { get; }
	public object ChildRounding { get; }
	public object ChildBorderSize { get; }
	public object PopupRounding { get; }
	public object PopupBorderSize { get; }
	public object FramePadding { get; }
	public object FrameRounding { get; }
	public object FrameBorderSize { get; }
	public object ItemSpacing { get; }
	public object ItemInnerSpacing { get; }
	public object TouchExtraPadding { get; }
	public object IndentSpacing { get; }
	public object ColumnsMinSpacing { get; }
	public object ScrollbarSize { get; }
	public object ScrollbarRounding { get; }
	public object GrabMinSize { get; }
	public object GrabRounding { get; }
	public object TabRounding { get; }
	public object TabBorderSize { get; }
	public object ColorButtonPosition { get; }
	public object ButtonTextAlign { get; }
	public object SelectableTextAlign { get; }
	public object DisplayWindowPadding { get; }
	public object DisplaySafeAreaPadding { get; }
	public object MouseCursorScale { get; }
	public object AntiAliasedLines { get; }
	public object AntiAliasedFill { get; }
	public object CurveTessellationTol { get; }
	public object CircleTessellationMaxError { get; }
	public object Colors { get; }

	// Methods

	// RVA: 0x6C3F1C8
	public object get_NativePtr() { }

	// RVA: 0x6C3F1D8
	public object .ctor(object nativePtr) { }

	// RVA: 0x6C3F1E8
	public object get_Alpha() { }

	// RVA: 0x6C3F228
	public object get_WindowPadding() { }

	// RVA: 0x6C3F270
	public object get_WindowRounding() { }

	// RVA: 0x6C3F2B8
	public object get_WindowBorderSize() { }

	// RVA: 0x6C3F300
	public object get_WindowMinSize() { }

	// RVA: 0x6C3F348
	public object get_WindowTitleAlign() { }

	// RVA: 0x6C3F390
	public object get_WindowMenuButtonPosition() { }

	// RVA: 0x6C3F3D8
	public object get_ChildRounding() { }

	// RVA: 0x6C3F420
	public object get_ChildBorderSize() { }

	// RVA: 0x6C3F468
	public object get_PopupRounding() { }

	// RVA: 0x6C3F4B0
	public object get_PopupBorderSize() { }

	// RVA: 0x6C3F4F8
	public object get_FramePadding() { }

	// RVA: 0x6C3F540
	public object get_FrameRounding() { }

	// RVA: 0x6C3F588
	public object get_FrameBorderSize() { }

	// RVA: 0x6C3F5D0
	public object get_ItemSpacing() { }

	// RVA: 0x6C3F618
	public object get_ItemInnerSpacing() { }

	// RVA: 0x6C3F660
	public object get_TouchExtraPadding() { }

	// RVA: 0x6C3F6A8
	public object get_IndentSpacing() { }

	// RVA: 0x6C3F6F0
	public object get_ColumnsMinSpacing() { }

	// RVA: 0x6C3F738
	public object get_ScrollbarSize() { }

	// RVA: 0x6C3F780
	public object get_ScrollbarRounding() { }

	// RVA: 0x6C3F7C8
	public object get_GrabMinSize() { }

	// RVA: 0x6C3F810
	public object get_GrabRounding() { }

	// RVA: 0x6C3F858
	public object get_TabRounding() { }

	// RVA: 0x6C3F8A0
	public object get_TabBorderSize() { }

	// RVA: 0x6C3F8E8
	public object get_ColorButtonPosition() { }

	// RVA: 0x6C3F930
	public object get_ButtonTextAlign() { }

	// RVA: 0x6C3F978
	public object get_SelectableTextAlign() { }

	// RVA: 0x6C3F9C0
	public object get_DisplayWindowPadding() { }

	// RVA: 0x6C3FA08
	public object get_DisplaySafeAreaPadding() { }

	// RVA: 0x6C3FA50
	public object get_MouseCursorScale() { }

	// RVA: 0x6C3FA98
	public object get_AntiAliasedLines() { }

	// RVA: 0x6C3FAE0
	public object get_AntiAliasedFill() { }

	// RVA: 0x6C3FB28
	public object get_CurveTessellationTol() { }

	// RVA: 0x6C3FB70
	public object get_CircleTessellationMaxError() { }

	// RVA: 0x6C3FBB8
	public object get_Colors() { }

}

// Namespace: ImGuiNET
public enum ImGuiStyleVar
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Alpha;
	public const object DisabledAlpha;
	public const object WindowPadding;
	public const object WindowRounding;
	public const object WindowBorderSize;
	public const object WindowMinSize;
	public const object WindowTitleAlign;
	public const object ChildRounding;
	public const object ChildBorderSize;
	public const object PopupRounding;
	public const object PopupBorderSize;
	public const object FramePadding;
	public const object FrameRounding;
	public const object FrameBorderSize;
	public const object ItemSpacing;
	public const object ItemInnerSpacing;
	public const object IndentSpacing;
	public const object CellPadding;
	public const object ScrollbarSize;
	public const object ScrollbarRounding;
	public const object GrabMinSize;
	public const object GrabRounding;
	public const object TabRounding;
	public const object TabBorderSize;
	public const object TabBarBorderSize;
	public const object TabBarOverlineSize;
	public const object TableAngledHeadersAngle;
	public const object TableAngledHeadersTextAlign;
	public const object ButtonTextAlign;
	public const object SelectableTextAlign;
	public const object SeparatorTextBorderSize;
	public const object SeparatorTextAlign;
	public const object SeparatorTextPadding;
	public const object COUNT;
}

// Namespace: ImGuiNET
public enum ImGuiTableColumnFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Disabled;
	public const object DefaultHide;
	public const object DefaultSort;
	public const object WidthStretch;
	public const object WidthFixed;
	public const object NoResize;
	public const object NoReorder;
	public const object NoHide;
	public const object NoClip;
	public const object NoSort;
	public const object NoSortAscending;
	public const object NoSortDescending;
	public const object NoHeaderLabel;
	public const object NoHeaderWidth;
	public const object PreferSortAscending;
	public const object PreferSortDescending;
	public const object IndentEnable;
	public const object IndentDisable;
	public const object AngledHeader;
	public const object IsEnabled;
	public const object IsVisible;
	public const object IsSorted;
	public const object IsHovered;
	public const object WidthMask;
	public const object IndentMask;
	public const object StatusMask;
	public const object NoDirectResize;
}

// Namespace: ImGuiNET
public enum ImGuiTableFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Resizable;
	public const object Reorderable;
	public const object Hideable;
	public const object Sortable;
	public const object NoSavedSettings;
	public const object ContextMenuInBody;
	public const object RowBg;
	public const object BordersInnerH;
	public const object BordersOuterH;
	public const object BordersInnerV;
	public const object BordersOuterV;
	public const object BordersH;
	public const object BordersV;
	public const object BordersInner;
	public const object BordersOuter;
	public const object Borders;
	public const object NoBordersInBody;
	public const object NoBordersInBodyUntilResize;
	public const object SizingFixedFit;
	public const object SizingFixedSame;
	public const object SizingStretchProp;
	public const object SizingStretchSame;
	public const object NoHostExtendX;
	public const object NoHostExtendY;
	public const object NoKeepColumnsVisible;
	public const object PreciseWidths;
	public const object NoClip;
	public const object PadOuterX;
	public const object NoPadOuterX;
	public const object NoPadInnerX;
	public const object ScrollX;
	public const object ScrollY;
	public const object SortMulti;
	public const object SortTristate;
	public const object HighlightHoveredColumn;
	public const object SizingMask;
}

// Namespace: ImGuiNET
public enum ImGuiTableRowFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Headers;
}

// Namespace: ImGuiNET
public enum ImGuiTreeNodeFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Selected;
	public const object Framed;
	public const object AllowOverlap;
	public const object NoTreePushOnOpen;
	public const object NoAutoOpenOnLog;
	public const object DefaultOpen;
	public const object OpenOnDoubleClick;
	public const object OpenOnArrow;
	public const object Leaf;
	public const object Bullet;
	public const object FramePadding;
	public const object SpanAvailWidth;
	public const object SpanFullWidth;
	public const object SpanTextWidth;
	public const object SpanAllColumns;
	public const object NavLeftJumpsBackHere;
	public const object CollapsingHeader;
}

// Namespace: ImGuiNET
public struct ImGuiViewport
{

	// Fields
	public object ID; // 0xFFFFFFFFFFFFFFF8
	public object Flags; // 0xFFFFFFFFFFFFFFFC
	public object Pos; // 0x0
	public object Size; // 0x8
	public object WorkPos; // 0x10
	public object WorkSize; // 0x18
	public object PlatformHandle; // 0x20
	public object PlatformHandleRaw; // 0x28
}

// Namespace: ImGuiNET
public enum ImGuiViewportFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object IsPlatformWindow;
	public const object IsPlatformMonitor;
	public const object OwnedByApp;
}

// Namespace: ImGuiNET
public enum ImGuiWindowFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NoTitleBar;
	public const object NoResize;
	public const object NoMove;
	public const object NoScrollbar;
	public const object NoScrollWithMouse;
	public const object NoCollapse;
	public const object AlwaysAutoResize;
	public const object NoBackground;
	public const object NoSavedSettings;
	public const object NoMouseInputs;
	public const object MenuBar;
	public const object HorizontalScrollbar;
	public const object NoFocusOnAppearing;
	public const object NoBringToFrontOnFocus;
	public const object AlwaysVerticalScrollbar;
	public const object AlwaysHorizontalScrollbar;
	public const object NoNavInputs;
	public const object NoNavFocus;
	public const object UnsavedDocument;
	public const object NoNav;
	public const object NoDecoration;
	public const object NoInputs;
	public const object ChildWindow;
	public const object Tooltip;
	public const object Popup;
	public const object Modal;
	public const object ChildMenu;
}

// Namespace: ImGuiNET
public sealed class ImGuiInputTextCallback
{

	// Methods

	// RVA: 0x6C3FD5C
	public object .ctor(object object, object method) { }

	// RVA: 0x6C3FE04
	public virtual object Invoke(object data) { }

}

// Namespace: ImGuiNET
public struct ImVector
{

	// Fields
	public readonly object Size; // 0xFFFFFFFFFFFFFFF8
	public readonly object Capacity; // 0xFFFFFFFFFFFFFFFC
	public readonly object Data; // 0x0
}

// Namespace: ImGuiNET
public struct ImVector<T0>
{

	// Fields
	public readonly object Size; // 0x0
	public readonly object Capacity; // 0x0
	public readonly object Data; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object vector) { }

}

// Namespace: ImGuiNET
public struct ImPtrVector<T0>
{

	// Fields
	public readonly object Size; // 0x0
	public readonly object Capacity; // 0x0
	public readonly object Data; // 0x0
	private readonly object _stride; // 0x0

	// Properties
	public object Item { get; }

	// Methods

	// RVA: -1
	public object .ctor(object vector, object stride) { }

	// RVA: -1
	public object .ctor(object size, object capacity, object data, object stride) { }

	// RVA: -1
	public object get_Item(object index) { }

}

// Namespace: ImGuiNET
public struct RangeAccessor<T0>
{

	// Fields
	private static readonly object s_sizeOfT; // 0x0
	public readonly object Data; // 0x0
	public readonly object Count; // 0x0

	// Properties
	public object Item { get; }

	// Methods

	// RVA: -1
	public object .ctor(object data, object count) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: ImGuiNET
public struct RangePtrAccessor<T0>
{

	// Fields
	public readonly object Data; // 0x0
	public readonly object Count; // 0x0

	// Properties
	public object Item { get; }

	// Methods

	// RVA: -1
	public object .ctor(object data, object count) { }

	// RVA: -1
	public object .ctor(object data, object count) { }

	// RVA: -1
	public object get_Item(object index) { }

}

// Namespace: ImGuiNET
internal static class Util
{

	// Methods

	// RVA: 0x6C39F54
	public static object StringFromPtr(object ptr) { }

	// RVA: 0x6C3C224
	internal static object AreStringsEqual(object a, object aLength, object b) { }

	// RVA: 0x6C36B88
	internal static object Allocate(object byteCount) { }

	// RVA: 0x6C36CA8
	internal static object Free(object ptr) { }

	// RVA: 0x6C36BF4
	internal static object GetUtf8(object s, object utf8Bytes, object utf8ByteCount) { }

}

