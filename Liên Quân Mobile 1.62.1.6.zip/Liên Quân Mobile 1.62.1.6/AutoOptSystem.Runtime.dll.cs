// Namespace: 
internal class <Module>
{
}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0xF930BC
	private static object Get() { }

	// RVA: 0xF9318C
	public object .ctor() { }

}

// Namespace: 
public class LinkInfo
{

	// Fields
	public object objectName; // 0x8
	public object lightmap; // 0x10
	public object lightmapST; // 0x18

	// Methods

	// RVA: 0xF939B0
	public object .ctor() { }

}

// Namespace: AutoOpt.Rendering.Lightmap
public class AutoOptLightmapLinkData
{

	// Fields
	public object linkInfos; // 0x10

	// Properties
	public override object Count { get; }
	public override object Item { get; set; }

	// Methods

	// RVA: 0xF932C8
	public override object get_Count() { }

	// RVA: 0xF933CC
	public override object get_Item(object index) { }

	// RVA: 0xF936DC
	public override object set_Item(object index, object value) { }

	// RVA: 0xF939B8
	public override object AddLinkInfos(object infos) { }

	// RVA: 0xF93BEC
	public override object FindLinkInfo(object node) { }

	// RVA: 0xF93354
	private object HasData() { }

	// RVA: 0xF93644
	private object ConvertToLightmapLinkInfo(object info) { }

	// RVA: 0xF93D60
	public object .ctor() { }

}

// Namespace: AutoOpt.Rendering.Lightmap
public class AutoOptLightmapLinker
{

	// Fields
	public object rootNode; // 0x18
	public object lightmapLinkData; // 0x20
	private const object kLightmapPropertyName;
	private const object kLightmapSTPropertyName;
	private object m_lightmapPropertyId; // 0x28
	private object m_lightmapSTPropertyId; // 0x2C

	// Methods

	// RVA: 0xF93DE8
	private object OnEnable() { }

	// RVA: 0xF93E6C
	private object GenerateShaderPropertyID() { }

	// RVA: 0xF93EEC
	public object ApplyLightmapData() { }

	// RVA: 0xF94358
	private object FindNode(object nodeName) { }

	// RVA: 0xF9441C
	public override object GetLightmapLinkData() { }

	// RVA: 0xF94424
	public object .ctor() { }

}

// Namespace: AutoOpt.Rendering.Lightmap
public class LightmapLinkInfo
{

	// Fields
	public object node; // 0x8
	public object renderer; // 0x10
	public object nodeName; // 0x18
	public object lightmap; // 0x20
	public object lightmapST; // 0x28

	// Methods

	// RVA: 0xF93D58
	public object .ctor() { }

}

// Namespace: AutoOpt.Rendering.Lightmap
public abstract class LightmapLinkData
{

	// Properties
	public abstract object Count { get; }
	public abstract object Item { get; set; }

	// Methods

	// RVA: -1
	public abstract object AddLinkInfos(object info) { }

	// RVA: -1
	public abstract object FindLinkInfo(object node) { }

	// RVA: -1
	public abstract object get_Count() { }

	// RVA: -1
	public abstract object get_Item(object index) { }

	// RVA: -1
	public abstract object set_Item(object index, object value) { }

	// RVA: 0xF93DE0
	protected object .ctor() { }

}

// Namespace: AutoOpt.Rendering.Lightmap
public abstract class LightmapLinker
{

	// Methods

	// RVA: -1
	public abstract object GetLightmapLinkData() { }

	// RVA: 0xF94434
	protected object .ctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=314
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=806
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 2E55024AE1300D3E5A0061AEEC197D124D09869E0A740791D7F9222E1FDC6F9D; // 0x0
	internal static readonly object AE4A9BED424BB9811AAF8A78161EC51DA3EFC1A6649087BA65DAFEAA9929C20F; // 0x326
}

