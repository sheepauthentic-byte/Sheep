// Namespace: 
internal class <Module>
{
}

// Namespace: 
internal static class SR
{

	// Methods

	// RVA: 0x6EC5648
	internal static object Format(object resourceFormat, object p1) { }

}

// Namespace: 
private enum GetBytesMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AllocateArray;
	public const object Count;
	public const object Span;
}

// Namespace: System.Numerics
public struct BigInteger
{

	// Fields
	internal readonly object _sign; // 0xFFFFFFFFFFFFFFF8
	internal readonly object _bits; // 0x0
	private static readonly object s_bnMinInt; // 0x0
	private static readonly object s_bnOneInt; // 0x0
	private static readonly object s_bnZeroInt; // 0x10
	private static readonly object s_bnMinusOneInt; // 0x20
	private static readonly object s_success; // 0x30

	// Properties
	public static object Zero { get; }
	public static object MinusOne { get; }
	public object IsZero { get; }

	// Methods

	// RVA: 0x6EC5790
	public object .ctor(object value) { }

	// RVA: 0x6EC58B8
	public object .ctor(object value) { }

	// RVA: 0x6EC5A00
	public object .ctor(object value) { }

	// RVA: 0x6EC5B60
	public object .ctor(object value) { }

	// RVA: 0x6EC5C5C
	public object .ctor(object value) { }

	// RVA: 0x6EC5CCC
	public object .ctor(object value) { }

	// RVA: 0x6EC60AC
	public object .ctor(object value) { }

	// RVA: 0x6EC62BC
	public object .ctor(object value) { }

	// RVA: 0x6EC638C
	public object .ctor(object value, object isUnsigned, object isBigEndian) { }

	// RVA: 0x6EC6C0C
	internal object .ctor(object n, object rgu) { }

	// RVA: 0x6EC6C24
	internal object .ctor(object value, object negative) { }

	// RVA: 0x6EC6DCC
	public static object get_Zero() { }

	// RVA: 0x6EC6E48
	public static object get_MinusOne() { }

	// RVA: 0x6EC6EC4
	public object get_IsZero() { }

	// RVA: 0x6EC6EE4
	public static object Parse(object value, object provider) { }

	// RVA: 0x6EC6F70
	public static object Parse(object value, object style, object provider) { }

	// RVA: 0x6EC7058
	public override object GetHashCode() { }

	// RVA: 0x6EC7108
	public override object Equals(object obj) { }

	// RVA: 0x6EC72D0
	public object Equals(object other) { }

	// RVA: 0x6EC71BC
	public object Equals(object other) { }

	// RVA: 0x6EC7480
	public object CompareTo(object other) { }

	// RVA: 0x6EC75D0
	public object CompareTo(object other) { }

	// RVA: 0x6EC7790
	public object CompareTo(object obj) { }

	// RVA: 0x6EC78A8
	public object TryWriteBytes(object destination, object bytesWritten, object isUnsigned, object isBigEndian) { }

	// RVA: 0x6EC7FA4
	internal object TryWriteOrCountBytes(object destination, object bytesWritten, object isUnsigned, object isBigEndian) { }

	// RVA: 0x6EC795C
	private object TryGetBytes(object mode, object destination, object isUnsigned, object isBigEndian, object bytesWritten) { }

	// RVA: 0x6EC8104
	public override object ToString() { }

	// RVA: 0x6EC82CC
	public object ToString(object provider) { }

	// RVA: 0x6EC83EC
	public object ToString(object format, object provider) { }

	// RVA: 0x6EC855C
	private static object Add(object leftBits, object leftSign, object rightBits, object rightSign) { }

	// RVA: 0x6EC89BC
	public static object op_Subtraction(object left, object right) { }

	// RVA: 0x6EC8A70
	private static object Subtract(object leftBits, object leftSign, object rightBits, object rightSign) { }

	// RVA: 0x6EC8F9C
	public static object op_Implicit(object value) { }

	// RVA: 0x6EC8FE0
	public static object op_Implicit(object value) { }

	// RVA: 0x6EC9024
	public static object op_Implicit(object value) { }

	// RVA: 0x6EC9068
	public static object op_Implicit(object value) { }

	// RVA: 0x6EC90AC
	public static object op_Implicit(object value) { }

	// RVA: 0x6EC9140
	public static object op_Implicit(object value) { }

	// RVA: 0x6EC86D0
	public static object op_Implicit(object value) { }

	// RVA: 0x6EC6078
	public static object op_Implicit(object value) { }

	// RVA: 0x6EC91D4
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC9388
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC9440
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC94F8
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC928C
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC95B0
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC9664
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC9730
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC9814
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC9884
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC9BA4
	public static object op_Explicit(object value) { }

	// RVA: 0x6EC9D00
	public static object op_LeftShift(object value, object shift) { }

	// RVA: 0x6EC9FB0
	public static object op_RightShift(object value, object shift) { }

	// RVA: 0x6ECA5F4
	public static object op_UnaryNegation(object value) { }

	// RVA: 0x6ECA5FC
	public static object op_Addition(object left, object right) { }

	// RVA: 0x6ECA6B0
	public static object op_Multiply(object left, object right) { }

	// RVA: 0x6ECAB40
	public static object op_Division(object dividend, object divisor) { }

	// RVA: 0x6ECAF48
	public static object op_LessThanOrEqual(object left, object right) { }

	// RVA: 0x6ECAFCC
	public static object op_Inequality(object left, object right) { }

	// RVA: 0x6ECB04C
	public static object op_LessThan(object left, object right) { }

	// RVA: 0x6ECB148
	public static object op_LessThanOrEqual(object left, object right) { }

	// RVA: 0x6ECB248
	public static object op_Equality(object left, object right) { }

	// RVA: 0x6ECB35C
	public static object op_Inequality(object left, object right) { }

	// RVA: 0x6ECB450
	public static object op_LessThan(object left, object right) { }

	// RVA: 0x6ECB550
	public static object op_LessThanOrEqual(object left, object right) { }

	// RVA: 0x6ECA504
	private static object GetPartsForBitManipulation(object x, object xd, object xl) { }

	// RVA: 0x6EC73C4
	internal static object GetDiffLength(object rgu1, object rgu2, object cu) { }

	// RVA: 0x6ECB650
	private static object .cctor() { }

}

// Namespace: System.Numerics
internal static class BigIntegerCalculator
{

	// Fields
	private static object ReducerThreshold; // 0x0
	private static object SquareThreshold; // 0x4
	private static object AllocationThreshold; // 0x8
	private static object MultiplyThreshold; // 0xC

	// Methods

	// RVA: 0x6EC8708
	public static object Add(object left, object right) { }

	// RVA: 0x6EC8800
	public static object Add(object left, object right) { }

	// RVA: 0x6ECB80C
	private static object Add(object left, object leftLength, object right, object rightLength, object bits, object bitsLength) { }

	// RVA: 0x6ECB8A0
	private static object AddSelf(object left, object leftLength, object right, object rightLength) { }

	// RVA: 0x6EC8C70
	public static object Subtract(object left, object right) { }

	// RVA: 0x6EC8DF0
	public static object Subtract(object left, object right) { }

	// RVA: 0x6ECB910
	private static object Subtract(object left, object leftLength, object right, object rightLength, object bits, object bitsLength) { }

	// RVA: 0x6EC8D44
	public static object Compare(object left, object right) { }

	// RVA: 0x6ECAD08
	public static object Divide(object left, object right) { }

	// RVA: 0x6ECADE0
	public static object Divide(object left, object right) { }

	// RVA: 0x6ECBA2C
	private static object Divide(object left, object leftLength, object right, object rightLength, object bits, object bitsLength) { }

	// RVA: 0x6ECBF38
	private static object AddDivisor(object left, object leftLength, object right, object rightLength) { }

	// RVA: 0x6ECBEF0
	private static object SubtractDivisor(object left, object leftLength, object right, object rightLength, object q) { }

	// RVA: 0x6ECBEB0
	private static object DivideGuessTooBig(object q, object valHi, object valLo, object divHi, object divLo) { }

	// RVA: 0x6ECB998
	private static object CreateCopy(object value) { }

	// RVA: 0x6ECBE38
	private static object LeadingZeros(object value) { }

	// RVA: 0x6ECA950
	public static object Square(object value) { }

	// RVA: 0x6ECBF7C
	private static object Square(object value, object valueLength, object bits, object bitsLength) { }

	// RVA: 0x6ECA850
	public static object Multiply(object left, object right) { }

	// RVA: 0x6ECAA2C
	public static object Multiply(object left, object right) { }

	// RVA: 0x6ECC7E4
	private static object Multiply(object left, object leftLength, object right, object rightLength, object bits, object bitsLength) { }

	// RVA: 0x6ECC704
	private static object SubtractCore(object left, object leftLength, object right, object rightLength, object core, object coreLength) { }

	// RVA: 0x6ECD178
	private static object .cctor() { }

}

// Namespace: 
private struct BigNumberBuffer
{

	// Fields
	public object digits; // 0xFFFFFFFFFFFFFFF8
	public object precision; // 0x0
	public object scale; // 0x4
	public object sign; // 0x8

	// Methods

	// RVA: 0x6ECD530
	public static object Create() { }

}

// Namespace: System.Numerics
internal static class BigNumber
{

	// Methods

	// RVA: 0x6ECD1CC
	internal static object TryValidateParseStyleInteger(object style, object e) { }

	// RVA: 0x6ECD310
	internal static object TryParseBigInteger(object value, object style, object info, object result) { }

	// RVA: 0x6EC6FA8
	internal static object ParseBigInteger(object value, object style, object info) { }

	// RVA: 0x6ECDB00
	internal static object ParseBigInteger(object value, object style, object info) { }

	// RVA: 0x6ECD680
	private static object HexNumberToBigInteger(object number, object value) { }

	// RVA: 0x6ECD860
	private static object NumberToBigInteger(object number, object value) { }

	// RVA: 0x6ECDC6C
	internal static object ParseFormatSpecifier(object format, object digits) { }

	// RVA: 0x6ECDD78
	private static object FormatBigIntegerToHex(object targetSpan, object value, object format, object digits, object info, object destination, object charsWritten, object spanSuccess) { }

	// RVA: 0x6EC8190
	internal static object FormatBigInteger(object value, object format, object info) { }

	// RVA: 0x6ECEBD8
	private static object FormatBigInteger(object targetSpan, object value, object formatString, object formatSpan, object info, object destination, object charsWritten, object spanSuccess) { }

}

// Namespace: System.Numerics
internal struct DoubleUlong
{

	// Fields
	public object dbl; // 0xFFFFFFFFFFFFFFF8
	public object uu; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Numerics
internal static class NumericsHelpers
{

	// Methods

	// RVA: 0x6EC5FFC
	public static object GetDoubleParts(object dbl, object sign, object exp, object man, object fFinite) { }

	// RVA: 0x6EC9A44
	public static object GetDoubleFromParts(object sign, object exp, object man) { }

	// RVA: 0x6EC6AE4
	public static object DangerousMakeTwosComplement(object d) { }

	// RVA: 0x6EC7344
	public static object MakeUlong(object uHi, object uLo) { }

	// RVA: 0x6EC86FC
	public static object Abs(object a) { }

	// RVA: 0x6ECFD18
	public static object CombineHash(object u1, object u2) { }

	// RVA: 0x6EC70AC
	public static object CombineHash(object n1, object n2) { }

	// RVA: 0x6EC99CC
	public static object CbitHighZero(object u) { }

	// RVA: 0x6ECFC24
	public static object CbitHighZero(object uu) { }

}

// Namespace: 
internal struct NumberBuffer
{

	// Fields
	public object precision; // 0xFFFFFFFFFFFFFFF8
	public object scale; // 0xFFFFFFFFFFFFFFFC
	public object sign; // 0x0
	public object overrideDigits; // 0x8

	// Properties
	public object digits { get; }

	// Methods

	// RVA: 0x6ED55D4
	public object get_digits() { }

}

// Namespace: 
private class Number
{

	// Fields
	private static object s_posCurrencyFormats; // 0x0
	private static object s_negCurrencyFormats; // 0x8
	private static object s_posPercentFormats; // 0x10
	private static object s_negPercentFormats; // 0x18
	private static object s_negNumberFormats; // 0x20
	private static object s_posNumberFormat; // 0x28

	// Methods

	// RVA: 0x6ED1EF8
	private static object IsWhite(object ch) { }

	// RVA: 0x6ED1F0C
	private static object MatchChars(object p, object pEnd, object str) { }

	// RVA: 0x6ED1FF4
	private static object MatchChars(object p, object pEnd, object str) { }

	// RVA: 0x6ED2060
	private static object ParseNumber(object str, object strEnd, object options, object number, object sb, object numfmt, object parseDecimal) { }

	// RVA: 0x6ED3090
	private static object TrailingZeros(object s, object index) { }

	// RVA: 0x6ED1D4C
	internal static object TryStringToNumber(object str, object options, object number, object sb, object numfmt, object parseDecimal) { }

	// RVA: 0x6ED3140
	internal static object Int32ToDecChars(object buffer, object index, object value, object digits) { }

	// RVA: 0x6ECFD20
	internal static object ParseFormatSpecifier(object format, object digits) { }

	// RVA: 0x6ECFEA0
	internal static object NumberToString(object sb, object number, object format, object nMaxDigits, object info, object isDecimal) { }

	// RVA: 0x6ED3298
	private static object FormatCurrency(object sb, object number, object nMinDigits, object nMaxDigits, object info) { }

	// RVA: 0x6ED46C0
	private static object wcslen(object s) { }

	// RVA: 0x6ED3564
	private static object FormatFixed(object sb, object number, object nMinDigits, object nMaxDigits, object info, object groupDigits, object sDecimal, object sGroup) { }

	// RVA: 0x6ED3AF4
	private static object FormatNumber(object sb, object number, object nMinDigits, object nMaxDigits, object info) { }

	// RVA: 0x6ED3DA8
	private static object FormatScientific(object sb, object number, object nMinDigits, object nMaxDigits, object info, object expChar) { }

	// RVA: 0x6ED49F0
	private static object FormatExponent(object sb, object info, object value, object expChar, object minDigits, object positiveSign) { }

	// RVA: 0x6ED4048
	private static object FormatGeneral(object sb, object number, object nMinDigits, object nMaxDigits, object info, object expChar, object bSuppressScientific) { }

	// RVA: 0x6ED43F4
	private static object FormatPercent(object sb, object number, object nMinDigits, object nMaxDigits, object info) { }

	// RVA: 0x6ED319C
	private static object RoundNumber(object number, object pos) { }

	// RVA: 0x6ED4D48
	private static object FindSection(object format, object section) { }

	// RVA: 0x6ED0A60
	internal static object NumberToStringFormat(object sb, object number, object format, object info) { }

	// RVA: 0x6ED4E94
	private static object .cctor() { }

}

// Namespace: System.Globalization
internal class FormatProvider
{

	// Methods

	// RVA: 0x6ECFA28
	internal static object FormatBigInteger(object sb, object precision, object scale, object sign, object format, object numberFormatInfo, object digits, object startIndex) { }

	// RVA: 0x6ECD598
	internal static object TryStringToBigInteger(object s, object styles, object numberFormatInfo, object receiver, object precision, object scale, object sign) { }

}

// Namespace: System.Text
internal struct ValueStringBuilder
{

	// Fields
	private object _arrayToReturnToPool; // 0xFFFFFFFFFFFFFFF8
	private object _chars; // 0x0
	private object _pos; // 0x10

	// Properties
	public object Length { get; }

	// Methods

	// RVA: 0x6ECE3C0
	public object .ctor(object initialBuffer) { }

	// RVA: 0x6ED5804
	public object get_Length() { }

	// RVA: 0x6ECEA0C
	public override object ToString() { }

	// RVA: 0x6ECE7BC
	public object TryCopyTo(object destination, object charsWritten) { }

	// RVA: 0x6ECE4FC
	public object Insert(object index, object value, object count) { }

	// RVA: 0x6ED59FC
	public object Append(object c) { }

	// RVA: 0x6ED5B20
	public object Append(object s) { }

	// RVA: 0x6ED5BE0
	private object AppendSlow(object s) { }

	// RVA: 0x6ED4830
	public object Append(object c, object count) { }

	// RVA: 0x6ED46EC
	public object Append(object value, object length) { }

	// RVA: 0x6ED5D64
	public object AppendSpan(object length) { }

	// RVA: 0x6ED5A8C
	private object GrowAndAppend(object c) { }

	// RVA: 0x6ED580C
	private object Grow(object requiredAdditionalCapacity) { }

	// RVA: 0x6ED5E90
	public object Dispose() { }

}

