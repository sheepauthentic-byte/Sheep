// Namespace: 
internal class <Module>
{
}

// Namespace: Mono
internal class SystemCertificateProvider
{

	// Fields
	private static object provider; // 0x0
	private static object initialized; // 0x8
	private static object x509pal; // 0x10
	private static object syncRoot; // 0x18

	// Properties
	public object X509Pal { get; }

	// Methods

	// RVA: 0x6D6AD58
	private static object GetX509Pal() { }

	// RVA: 0x6D6B010
	private static object EnsureInitialized() { }

	// RVA: 0x6D6B1A0
	public object get_X509Pal() { }

	// RVA: 0x6D6B200
	public object Import(object data, object importFlags) { }

	// RVA: 0x6D6B560
	private object Mono.ISystemCertificateProvider.Import(object data, object password, object keyStorageFlags, object importFlags) { }

	// RVA: 0x6D6B564
	public object Import(object data, object password, object keyStorageFlags, object importFlags) { }

	// RVA: 0x6D6B7D8
	private object Mono.ISystemCertificateProvider.Import(object cert, object importFlags) { }

	// RVA: 0x6D6B7DC
	public object Import(object cert, object importFlags) { }

	// RVA: 0x6D6BA20
	public object .ctor() { }

	// RVA: 0x6D6BA28
	private static object .cctor() { }

}

// Namespace: Mono
internal class SystemDependencyProvider
{

	// Fields
	private static object instance; // 0x0
	private static object syncRoot; // 0x8
	private readonly object <CertificateProvider>k__BackingField; // 0x8

	// Properties
	public static object Instance { get; }
	private object Mono.ISystemDependencyProvider.CertificateProvider { get; }
	public object CertificateProvider { get; }
	public object X509Pal { get; }

	// Methods

	// RVA: 0x6D6BAA4
	public static object get_Instance() { }

	// RVA: 0x6D6BB04
	internal static object Initialize() { }

	// RVA: 0x6D6BD2C
	private object Mono.ISystemDependencyProvider.get_CertificateProvider() { }

	// RVA: 0x6D6BD34
	public object get_CertificateProvider() { }

	// RVA: 0x6D6BD3C
	public object get_X509Pal() { }

	// RVA: 0x6D6BC78
	private object .ctor() { }

	// RVA: 0x6D6BDB0
	private static object .cctor() { }

}

// Namespace: Mono
internal static class X509Pal
{

	// Properties
	public static object Instance { get; }

	// Methods

	// RVA: 0x6D6BE2C
	public static object get_Instance() { }

}

// Namespace: Mono
internal class X509PalImplMono
{

	// Methods

	// RVA: 0x6D6BF58
	public override object Import(object data) { }

	// RVA: 0x6D6BF5C
	public override object Import(object data, object password, object keyStorageFlags) { }

	// RVA: 0x6D6BFDC
	public override object Import(object cert) { }

	// RVA: 0x6D6AF88
	public object .ctor() { }

}

// Namespace: Mono
internal abstract class X509PalImpl
{

	// Fields
	private static object signedData; // 0x0

	// Properties
	public object SupportsLegacyBasicConstraintsExtension { get; }

	// Methods

	// RVA: -1
	public abstract object Import(object data) { }

	// RVA: -1
	public abstract object Import(object data, object password, object keyStorageFlags) { }

	// RVA: -1
	public abstract object Import(object cert) { }

	// RVA: 0x6D6BFEC
	private static object PEM(object type, object data) { }

	// RVA: 0x6D6C17C
	protected static object ConvertData(object data) { }

	// RVA: 0x6D6B38C
	internal object ImportFallback(object data) { }

	// RVA: 0x6D6B758
	internal object ImportFallback(object data, object password, object keyStorageFlags) { }

	// RVA: 0x6D6C29C
	public object get_SupportsLegacyBasicConstraintsExtension() { }

	// RVA: 0x6D6C2A4
	public object GetCertContentType(object rawData) { }

	// RVA: 0x6D6BFE4
	protected object .ctor() { }

	// RVA: 0x6D6C778
	private static object .cctor() { }

}

// Namespace: Mono.Util
internal sealed class MonoPInvokeCallbackAttribute
{

	// Methods

	// RVA: 0x6D6C810
	public object .ctor(object t) { }

}

// Namespace: Mono.Unity
internal static class CertHelper
{

	// Methods

	// RVA: 0x6D6C818
	public static object AddCertificatesToNativeChain(object nativeCertificateChain, object certificates, object errorState) { }

	// RVA: 0x6D6C9FC
	public static object AddCertificateToNativeChain(object nativeCertificateChain, object certificate, object errorState) { }

}

// Namespace: Mono.Unity
internal static class Debug
{

	// Methods

	// RVA: 0x6D6CCD8
	public static object CheckAndThrow(object errorState, object context, object defaultAlert) { }

	// RVA: 0x6D6CD78
	public static object CheckAndThrow(object errorState, object verifyResult, object context, object defaultAlert) { }

}

// Namespace: 
public enum unitytls_error_code
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UNITYTLS_SUCCESS;
	public const object UNITYTLS_INVALID_ARGUMENT;
	public const object UNITYTLS_INVALID_FORMAT;
	public const object UNITYTLS_INVALID_PASSWORD;
	public const object UNITYTLS_INVALID_STATE;
	public const object UNITYTLS_BUFFER_OVERFLOW;
	public const object UNITYTLS_OUT_OF_MEMORY;
	public const object UNITYTLS_INTERNAL_ERROR;
	public const object UNITYTLS_NOT_SUPPORTED;
	public const object UNITYTLS_ENTROPY_SOURCE_FAILED;
	public const object UNITYTLS_STREAM_CLOSED;
	public const object UNITYTLS_USER_CUSTOM_ERROR_START;
	public const object UNITYTLS_USER_WOULD_BLOCK;
	public const object UNITYTLS_USER_READ_FAILED;
	public const object UNITYTLS_USER_WRITE_FAILED;
	public const object UNITYTLS_USER_UNKNOWN_ERROR;
	public const object UNITYTLS_USER_CUSTOM_ERROR_END;
}

// Namespace: 
public struct unitytls_errorstate
{

	// Fields
	private object magic; // 0xFFFFFFFFFFFFFFF8
	public object code; // 0xFFFFFFFFFFFFFFFC
	private object reserved; // 0x0
}

// Namespace: 
public struct unitytls_key
{
}

// Namespace: 
public struct unitytls_key_ref
{

	// Fields
	public object handle; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct unitytls_x509_ref
{

	// Fields
	public object handle; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct unitytls_x509list
{
}

// Namespace: 
public struct unitytls_x509list_ref
{

	// Fields
	public object handle; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public enum unitytls_x509verify_result
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UNITYTLS_X509VERIFY_SUCCESS;
	public const object UNITYTLS_X509VERIFY_NOT_DONE;
	public const object UNITYTLS_X509VERIFY_FATAL_ERROR;
	public const object UNITYTLS_X509VERIFY_FLAG_EXPIRED;
	public const object UNITYTLS_X509VERIFY_FLAG_REVOKED;
	public const object UNITYTLS_X509VERIFY_FLAG_CN_MISMATCH;
	public const object UNITYTLS_X509VERIFY_FLAG_NOT_TRUSTED;
	public const object UNITYTLS_X509VERIFY_FLAG_USER_ERROR1;
	public const object UNITYTLS_X509VERIFY_FLAG_USER_ERROR2;
	public const object UNITYTLS_X509VERIFY_FLAG_USER_ERROR3;
	public const object UNITYTLS_X509VERIFY_FLAG_USER_ERROR4;
	public const object UNITYTLS_X509VERIFY_FLAG_USER_ERROR5;
	public const object UNITYTLS_X509VERIFY_FLAG_USER_ERROR6;
	public const object UNITYTLS_X509VERIFY_FLAG_USER_ERROR7;
	public const object UNITYTLS_X509VERIFY_FLAG_USER_ERROR8;
	public const object UNITYTLS_X509VERIFY_FLAG_UNKNOWN_ERROR;
}

// Namespace: 
public sealed class unitytls_x509verify_callback
{

	// Methods

	// RVA: 0x6D6CFBC
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6D06C
	public virtual object Invoke(object userData, object cert, object result, object errorState) { }

}

// Namespace: 
public struct unitytls_tlsctx
{
}

// Namespace: 
public struct unitytls_x509name
{
}

// Namespace: 
public enum unitytls_ciphersuite
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UNITYTLS_CIPHERSUITE_INVALID;
}

// Namespace: 
public enum unitytls_protocol
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UNITYTLS_PROTOCOL_TLS_1_0;
	public const object UNITYTLS_PROTOCOL_TLS_1_1;
	public const object UNITYTLS_PROTOCOL_TLS_1_2;
	public const object UNITYTLS_PROTOCOL_INVALID;
}

// Namespace: 
public struct unitytls_tlsctx_protocolrange
{

	// Fields
	public object min; // 0xFFFFFFFFFFFFFFF8
	public object max; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: 
public sealed class unitytls_tlsctx_write_callback
{

	// Methods

	// RVA: 0x6D6D174
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6D224
	public virtual object Invoke(object userData, object data, object bufferLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_read_callback
{

	// Methods

	// RVA: 0x6D6D32C
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6D3DC
	public virtual object Invoke(object userData, object buffer, object bufferLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_trace_callback
{

	// Methods

	// RVA: 0x6D6D4CC
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6D57C
	public virtual object Invoke(object userData, object ctx, object traceMessage, object traceMessageLen) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_certificate_callback
{

	// Methods

	// RVA: 0x6D6D700
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6D7B0
	public virtual object Invoke(object userData, object ctx, object cn, object cnLen, object caList, object caListLen, object chain, object key, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_x509verify_callback
{

	// Methods

	// RVA: 0x6D6D8B0
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6D960
	public virtual object Invoke(object userData, object chain, object errorState) { }

}

// Namespace: 
public struct unitytls_tlsctx_callbacks
{

	// Fields
	public object read; // 0xFFFFFFFFFFFFFFF8
	public object write; // 0x0
	public object data; // 0x8
}

// Namespace: 
public sealed class unitytls_errorstate_create_t
{

	// Methods

	// RVA: 0x6D6E298
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6E32C
	public virtual object Invoke() { }

}

// Namespace: 
public sealed class unitytls_errorstate_raise_error_t
{

	// Methods

	// RVA: 0x6D6E3EC
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6E49C
	public virtual object Invoke(object errorState, object errorCode) { }

}

// Namespace: 
public sealed class unitytls_key_get_ref_t
{

	// Methods

	// RVA: 0x6D6E570
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6E620
	public virtual object Invoke(object key, object errorState) { }

}

// Namespace: 
public sealed class unitytls_key_parse_der_t
{

	// Methods

	// RVA: 0x6D6E748
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6E7F8
	public virtual object Invoke(object buffer, object bufferLen, object password, object passwordLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_key_parse_pem_t
{

	// Methods

	// RVA: 0x6D6E920
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6E9D0
	public virtual object Invoke(object buffer, object bufferLen, object password, object passwordLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_key_free_t
{

	// Methods

	// RVA: 0x6D6EA7C
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6EB24
	public virtual object Invoke(object key) { }

}

// Namespace: 
public sealed class unitytls_x509_export_der_t
{

	// Methods

	// RVA: 0x6D6EBF8
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6EC90
	public virtual object Invoke(object cert, object buffer, object bufferLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_x509list_get_ref_t
{

	// Methods

	// RVA: 0x6D6ED64
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6EE14
	public virtual object Invoke(object list, object errorState) { }

}

// Namespace: 
public sealed class unitytls_x509list_get_x509_t
{

	// Methods

	// RVA: 0x6D6EED8
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6EF70
	public virtual object Invoke(object list, object index, object errorState) { }

}

// Namespace: 
public sealed class unitytls_x509list_create_t
{

	// Methods

	// RVA: 0x6D6F030
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6F0D8
	public virtual object Invoke(object errorState) { }

}

// Namespace: 
public sealed class unitytls_x509list_append_t
{

	// Methods

	// RVA: 0x6D6F1B4
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6F264
	public virtual object Invoke(object list, object cert, object errorState) { }

}

// Namespace: 
public sealed class unitytls_x509list_append_der_t
{

	// Methods

	// RVA: 0x6D6F354
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6F404
	public virtual object Invoke(object list, object buffer, object bufferLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_x509list_free_t
{

	// Methods

	// RVA: 0x6D6F4B0
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6F558
	public virtual object Invoke(object list) { }

}

// Namespace: 
public sealed class unitytls_x509verify_default_ca_t
{

	// Methods

	// RVA: 0x6D6F6A8
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6F740
	public virtual object Invoke(object chain, object cn, object cnLen, object cb, object userData, object errorState) { }

}

// Namespace: 
public sealed class unitytls_x509verify_explicit_ca_t
{

	// Methods

	// RVA: 0x6D6F8A8
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6F940
	public virtual object Invoke(object chain, object trustCA, object cn, object cnLen, object cb, object userData, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_create_server_t
{

	// Methods

	// RVA: 0x6D6FAD0
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6FB68
	public virtual object Invoke(object supportedProtocols, object callbacks, object certChain, object leafCertificateKey, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_create_client_t
{

	// Methods

	// RVA: 0x6D6FD20
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6FDB8
	public virtual object Invoke(object supportedProtocols, object callbacks, object cn, object cnLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_server_require_client_authentication_t
{

	// Methods

	// RVA: 0x6D6FEC0
	public object .ctor(object object, object method) { }

	// RVA: 0x6D6FF70
	public virtual object Invoke(object ctx, object clientAuthCAList, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_set_certificate_callback_t
{

	// Methods

	// RVA: 0x6D700A0
	public object .ctor(object object, object method) { }

	// RVA: 0x6D70150
	public virtual object Invoke(object ctx, object cb, object userData, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_set_trace_callback_t
{

	// Methods

	// RVA: 0x6D70280
	public object .ctor(object object, object method) { }

	// RVA: 0x6D70330
	public virtual object Invoke(object ctx, object cb, object userData, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_set_x509verify_callback_t
{

	// Methods

	// RVA: 0x6D70460
	public object .ctor(object object, object method) { }

	// RVA: 0x6D70510
	public virtual object Invoke(object ctx, object cb, object userData, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_set_supported_ciphersuites_t
{

	// Methods

	// RVA: 0x6D70600
	public object .ctor(object object, object method) { }

	// RVA: 0x6D706B0
	public virtual object Invoke(object ctx, object supportedCiphersuites, object supportedCiphersuitesLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_get_ciphersuite_t
{

	// Methods

	// RVA: 0x6D70784
	public object .ctor(object object, object method) { }

	// RVA: 0x6D70834
	public virtual object Invoke(object ctx, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_get_protocol_t
{

	// Methods

	// RVA: 0x6D70908
	public object .ctor(object object, object method) { }

	// RVA: 0x6D709B8
	public virtual object Invoke(object ctx, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_process_handshake_t
{

	// Methods

	// RVA: 0x6D70A8C
	public object .ctor(object object, object method) { }

	// RVA: 0x6D70B3C
	public virtual object Invoke(object ctx, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_read_t
{

	// Methods

	// RVA: 0x6D70C44
	public object .ctor(object object, object method) { }

	// RVA: 0x6D70CF4
	public virtual object Invoke(object ctx, object buffer, object bufferLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_write_t
{

	// Methods

	// RVA: 0x6D70DFC
	public object .ctor(object object, object method) { }

	// RVA: 0x6D70EAC
	public virtual object Invoke(object ctx, object data, object bufferLen, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_notify_close_t
{

	// Methods

	// RVA: 0x6D70F6C
	public object .ctor(object object, object method) { }

	// RVA: 0x6D7101C
	public virtual object Invoke(object ctx, object errorState) { }

}

// Namespace: 
public sealed class unitytls_tlsctx_free_t
{

	// Methods

	// RVA: 0x6D710C8
	public object .ctor(object object, object method) { }

	// RVA: 0x6D71170
	public virtual object Invoke(object ctx) { }

}

// Namespace: 
public sealed class unitytls_random_generate_bytes_t
{

	// Methods

	// RVA: 0x6D7124C
	public object .ctor(object object, object method) { }

	// RVA: 0x6D712FC
	public virtual object Invoke(object buffer, object bufferLen, object errorState) { }

}

// Namespace: 
public class unitytls_interface_struct
{

	// Fields
	public readonly object UNITYTLS_INVALID_HANDLE; // 0x8
	public readonly object UNITYTLS_TLSCTX_PROTOCOLRANGE_DEFAULT; // 0x10
	public object unitytls_errorstate_create; // 0x18
	public object unitytls_errorstate_raise_error; // 0x20
	public object unitytls_key_get_ref; // 0x28
	public object unitytls_key_parse_der; // 0x30
	public object unitytls_key_parse_pem; // 0x38
	public object unitytls_key_free; // 0x40
	public object unitytls_x509_export_der; // 0x48
	public object unitytls_x509list_get_ref; // 0x50
	public object unitytls_x509list_get_x509; // 0x58
	public object unitytls_x509list_create; // 0x60
	public object unitytls_x509list_append; // 0x68
	public object unitytls_x509list_append_der; // 0x70
	public object unitytls_x509list_append_pem; // 0x78
	public object unitytls_x509list_free; // 0x80
	public object unitytls_x509verify_default_ca; // 0x88
	public object unitytls_x509verify_explicit_ca; // 0x90
	public object unitytls_tlsctx_create_server; // 0x98
	public object unitytls_tlsctx_create_client; // 0xA0
	public object unitytls_tlsctx_server_require_client_authentication; // 0xA8
	public object unitytls_tlsctx_set_certificate_callback; // 0xB0
	public object unitytls_tlsctx_set_trace_callback; // 0xB8
	public object unitytls_tlsctx_set_x509verify_callback; // 0xC0
	public object unitytls_tlsctx_set_supported_ciphersuites; // 0xC8
	public object unitytls_tlsctx_get_ciphersuite; // 0xD0
	public object unitytls_tlsctx_get_protocol; // 0xD8
	public object unitytls_tlsctx_process_handshake; // 0xE0
	public object unitytls_tlsctx_read; // 0xE8
	public object unitytls_tlsctx_write; // 0xF0
	public object unitytls_tlsctx_notify_close; // 0xF8
	public object unitytls_tlsctx_free; // 0x100
	public object unitytls_random_generate_bytes; // 0x108

	// Methods

	// RVA: 0x6D6E224
	public object .ctor() { }

}

// Namespace: Mono.Unity
internal static class UnityTls
{

	// Fields
	private static object marshalledInterface; // 0x0

	// Properties
	public static object IsSupported { get; }
	public static object NativeInterface { get; }

	// Methods

	// RVA: 0x6D6CEA8
	private static object GetUnityTlsInterface() { }

	// RVA: 0x6D6CEAC
	public static object get_IsSupported() { }

	// RVA: 0x6D6CC0C
	public static object get_NativeInterface() { }

}

// Namespace: Mono.Unity
internal class UnityTlsContext
{

	// Fields
	private object tlsContext; // 0x50
	private object requestedClientCertChain; // 0x58
	private object requestedClientKey; // 0x60
	private object readCallback; // 0x68
	private object writeCallback; // 0x70
	private object certificateCallback; // 0x78
	private object verifyCallback; // 0x80
	private object localClientCertificate; // 0x88
	private object remoteCertificate; // 0x90
	private object connectioninfo; // 0x98
	private object isAuthenticated; // 0xA0
	private object hasContext; // 0xA1
	private object closedGraceful; // 0xA2
	private object writeBuffer; // 0xA8
	private object readBuffer; // 0xB0
	private object handle; // 0xB8
	private object lastException; // 0xC0

	// Properties
	public override object IsAuthenticated { get; }
	internal override object LocalClientCertificate { get; }
	public override object RemoteCertificate { get; }

	// Methods

	// RVA: 0x6D71880
	public object .ctor(object parent, object options) { }

	// RVA: 0x6D724C4
	private static object ExtractNativeKeyAndChainFromManagedCertificate(object cert, object errorState, object nativeCertChain, object nativeKey) { }

	// RVA: 0x6D7299C
	public override object get_IsAuthenticated() { }

	// RVA: 0x6D729A4
	internal override object get_LocalClientCertificate() { }

	// RVA: 0x6D729AC
	public override object get_RemoteCertificate() { }

	// RVA: 0x6D729B4
	public override object Flush() { }

	// RVA: 0x6D729B8
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x6D72BA4
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x6D72D88
	public override object Renegotiate() { }

	// RVA: 0x6D72DC8
	public override object PendingRenegotiation() { }

	// RVA: 0x6D72DD0
	public override object Shutdown() { }

	// RVA: 0x6D72F7C
	protected override object Dispose(object disposing) { }

	// RVA: 0x6D73018
	public override object StartHandshake() { }

	// RVA: 0x6D73254
	public override object ProcessHandshake() { }

	// RVA: 0x6D7348C
	public override object FinishHandshake() { }

	// RVA: 0x6D71388
	private static object WriteCallback(object userData, object data, object bufferLen, object errorState) { }

	// RVA: 0x6D73620
	private object WriteCallback(object data, object bufferLen, object errorState) { }

	// RVA: 0x6D714E0
	private static object ReadCallback(object userData, object buffer, object bufferLen, object errorState) { }

	// RVA: 0x6D73AC8
	private object ReadCallback(object buffer, object bufferLen, object errorState) { }

	// RVA: 0x6D71630
	private static object VerifyCallback(object userData, object chain, object errorState) { }

	// RVA: 0x6D73F68
	private object VerifyCallback(object chain, object errorState) { }

	// RVA: 0x6D717A8
	private static object CertificateCallback(object userData, object ctx, object cn, object cnLen, object caList, object caListLen, object chain, object key, object errorState) { }

	// RVA: 0x6D74480
	private object CertificateCallback(object ctx, object cn, object cnLen, object caList, object caListLen, object chain, object key, object errorState) { }

}

// Namespace: Mono.Unity
internal static class UnityTlsConversions
{

	// Methods

	// RVA: 0x6D72460
	public static object GetMinProtocol(object protocols) { }

	// RVA: 0x6D72490
	public static object GetMaxProtocol(object protocols) { }

	// RVA: 0x6D73600
	public static object ConvertProtocolVersion(object protocol) { }

	// RVA: 0x6D6CE50
	public static object VerifyResultToAlertDescription(object verifyResult, object defaultAlert) { }

	// RVA: 0x6D74E4C
	public static object VerifyResultToPolicyErrror(object verifyResult) { }

	// RVA: 0x6D74E7C
	public static object VerifyResultToChainStatus(object verifyResult) { }

}

// Namespace: Mono.Unity
internal class UnityTlsProvider
{

	// Properties
	public override object Name { get; }
	public override object ID { get; }
	public override object SupportsSslStream { get; }
	public override object SupportsMonoExtensions { get; }
	public override object SupportsConnectionInfo { get; }
	internal override object SupportsCleanShutdown { get; }
	public override object SupportedProtocols { get; }

	// Methods

	// RVA: 0x6D74FDC
	public override object get_Name() { }

	// RVA: 0x6D75020
	public override object get_ID() { }

	// RVA: 0x6D7509C
	public override object get_SupportsSslStream() { }

	// RVA: 0x6D750A4
	public override object get_SupportsMonoExtensions() { }

	// RVA: 0x6D750AC
	public override object get_SupportsConnectionInfo() { }

	// RVA: 0x6D750B4
	internal override object get_SupportsCleanShutdown() { }

	// RVA: 0x6D750BC
	public override object get_SupportedProtocols() { }

	// RVA: 0x6D750C4
	internal override object CreateSslStream(object sslStream, object innerStream, object leaveInnerStreamOpen, object settings) { }

	// RVA: 0x6D74F60
	private static object x509verify_callback(object userData, object cert, object result, object errorState) { }

	// RVA: 0x6D7522C
	internal override object ValidateCertificate(object validator, object targetHost, object serverMode, object certificates, object wantsChain, object chain, object errors, object status11) { }

	// RVA: 0x6D75F94
	public object .ctor() { }

}

// Namespace: Mono.Unity
internal class UnityTlsStream
{

	// Methods

	// RVA: 0x6D75194
	public object .ctor(object innerStream, object leaveInnerStreamOpen, object owner, object settings, object provider) { }

	// RVA: 0x6D76158
	protected override object CreateContext(object options) { }

}

// Namespace: Mono.Unity
internal class X509ChainImplUnityTls
{

	// Fields
	private object elements; // 0x8
	private object nativeCertificateChain; // 0x10
	private object policy; // 0x18
	private object chainStatusList; // 0x20
	private object reverseOrder; // 0x28

	// Properties
	public override object IsValid { get; }
	internal object NativeCertificateChain { get; }
	public override object ChainElements { get; }
	public override object ChainPolicy { get; }

	// Methods

	// RVA: 0x6D743F8
	internal object .ctor(object nativeCertificateChain, object reverseOrder) { }

	// RVA: 0x6D761C4
	public override object get_IsValid() { }

	// RVA: 0x6D76200
	internal object get_NativeCertificateChain() { }

	// RVA: 0x6D76208
	public override object get_ChainElements() { }

	// RVA: 0x6D765C0
	public override object AddStatus(object error) { }

	// RVA: 0x6D76770
	public override object get_ChainPolicy() { }

	// RVA: 0x6D76778
	public override object Build(object certificate) { }

	// RVA: 0x6D76780
	public override object Reset() { }

	// RVA: 0x6D767E0
	protected override object Dispose(object disposing) { }

}

// Namespace: Mono.Net.Security
internal class BufferOffsetSize
{

	// Fields
	public object Buffer; // 0x8
	public object Offset; // 0x10
	public object Size; // 0x14
	public object TotalBytes; // 0x18
	public object Complete; // 0x1C

	// Properties
	public object EndOffset { get; }
	public object Remaining { get; }

	// Methods

	// RVA: 0x6D76830
	public object get_EndOffset() { }

	// RVA: 0x6D7683C
	public object get_Remaining() { }

	// RVA: 0x6D7686C
	public object .ctor(object buffer, object offset, object size) { }

	// RVA: 0x6D7697C
	public override object ToString() { }

}

// Namespace: Mono.Net.Security
internal class BufferOffsetSize2
{

	// Fields
	public readonly object InitialSize; // 0x20

	// Methods

	// RVA: 0x6D76A24
	public object .ctor(object size) { }

	// RVA: 0x6D76A98
	public object Reset() { }

	// RVA: 0x6D76B00
	public object MakeRoom(object size) { }

	// RVA: 0x6D76BD0
	public object AppendData(object buffer, object offset, object size) { }

}

// Namespace: Mono.Net.Security
internal enum AsyncOperationStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Initialize;
	public const object Continue;
	public const object ReadDone;
	public const object Complete;
}

// Namespace: Mono.Net.Security
internal class AsyncProtocolResult
{

	// Fields
	private readonly object <UserResult>k__BackingField; // 0x8
	private readonly object <Error>k__BackingField; // 0x10

	// Properties
	public object UserResult { get; }
	public object Error { get; }

	// Methods

	// RVA: 0x6D76C34
	public object get_UserResult() { }

	// RVA: 0x6D76C3C
	public object get_Error() { }

	// RVA: 0x6D76C44
	public object .ctor(object result) { }

	// RVA: 0x6D76C70
	public object .ctor(object error) { }

}

// Namespace: 
private struct <StartOperation>d__23
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <>u__1; // 0x28

	// Methods

	// RVA: 0x6D77200
	private object MoveNext() { }

	// RVA: 0x6D77640
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <ProcessOperation>d__24
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object cancellationToken; // 0x18
	public object <>4__this; // 0x20
	private object <status>5__2; // 0x28
	private object <newStatus>5__3; // 0x2C
	private object <>u__1; // 0x30
	private object <>u__2; // 0x40

	// Methods

	// RVA: 0x6D77740
	private object MoveNext() { }

	// RVA: 0x6D77F88
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <InnerRead>d__25
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <totalRead>5__2; // 0x28
	private object <requestedSize>5__3; // 0x30
	private object <>u__1; // 0x38

	// Methods

	// RVA: 0x6D78060
	private object MoveNext() { }

	// RVA: 0x6D78580
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: Mono.Net.Security
internal abstract class AsyncProtocolRequest
{

	// Fields
	private readonly object <Parent>k__BackingField; // 0x8
	private readonly object <RunSynchronously>k__BackingField; // 0x10
	private object <UserResult>k__BackingField; // 0x14
	private object Started; // 0x18
	private object RequestedSize; // 0x1C
	private object WriteRequested; // 0x20
	private readonly object locker; // 0x28

	// Properties
	public object Parent { get; }
	public object RunSynchronously { get; }
	public object Name { get; }
	public object UserResult { get; set; }

	// Methods

	// RVA: 0x6D76C9C
	public object get_Parent() { }

	// RVA: 0x6D76CA4
	public object get_RunSynchronously() { }

	// RVA: 0x6D76CAC
	public object get_Name() { }

	// RVA: 0x6D76D04
	public object get_UserResult() { }

	// RVA: 0x6D76D0C
	protected object set_UserResult(object value) { }

	// RVA: 0x6D76D14
	public object .ctor(object parent, object sync) { }

	// RVA: 0x6D76D9C
	internal object RequestRead(object size) { }

	// RVA: 0x6D76E7C
	internal object RequestWrite() { }

	// RVA: 0x6D76E88
	internal object StartOperation(object cancellationToken) { }

	// RVA: 0x6D76F88
	private object ProcessOperation(object cancellationToken) { }

	// RVA: 0x6D77060
	private object InnerRead(object cancellationToken) { }

	// RVA: -1
	protected abstract object Run(object status) { }

	// RVA: 0x6D77164
	public override object ToString() { }

}

// Namespace: Mono.Net.Security
internal class AsyncHandshakeRequest
{

	// Methods

	// RVA: 0x6D78680
	public object .ctor(object parent, object sync) { }

	// RVA: 0x6D78708
	protected override object Run(object status) { }

}

// Namespace: Mono.Net.Security
internal abstract class AsyncReadOrWriteRequest
{

	// Fields
	private readonly object <UserBuffer>k__BackingField; // 0x30
	private object <CurrentSize>k__BackingField; // 0x38

	// Properties
	protected object UserBuffer { get; }
	protected object CurrentSize { get; set; }

	// Methods

	// RVA: 0x6D78BA0
	protected object get_UserBuffer() { }

	// RVA: 0x6D78BA8
	protected object get_CurrentSize() { }

	// RVA: 0x6D78BB0
	protected object set_CurrentSize(object value) { }

	// RVA: 0x6D78BB8
	public object .ctor(object parent, object sync, object buffer, object offset, object size) { }

	// RVA: 0x6D78CA4
	public override object ToString() { }

}

// Namespace: Mono.Net.Security
internal class AsyncReadRequest
{

	// Methods

	// RVA: 0x6D78D48
	public object .ctor(object parent, object sync, object buffer, object offset, object size) { }

	// RVA: 0x6D78D4C
	protected override object Run(object status) { }

}

// Namespace: Mono.Net.Security
internal class AsyncWriteRequest
{

	// Methods

	// RVA: 0x6D78F8C
	public object .ctor(object parent, object sync, object buffer, object offset, object size) { }

	// RVA: 0x6D78F90
	protected override object Run(object status) { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_0
{

	// Fields
	public object settings; // 0x8

	// Methods

	// RVA: 0x6D79990
	public object .ctor() { }

	// RVA: 0x6D7A388
	internal object <GetValidationCallback>b__0(object s, object c, object ch, object e) { }

}

// Namespace: Mono.Net.Security
internal class ChainValidationHelper
{

	// Fields
	private readonly object owner; // 0x8
	private readonly object settings; // 0x10
	private readonly object provider; // 0x18
	private readonly object certValidationCallback; // 0x20
	private readonly object certSelectionCallback; // 0x28
	private readonly object tlsStream; // 0x30
	private readonly object request; // 0x38

	// Properties
	public object Settings { get; }

	// Methods

	// RVA: 0x6D79200
	internal static object GetInternalValidator(object owner, object provider, object settings) { }

	// RVA: 0x6D795EC
	internal static object Create(object provider, object settings, object stream) { }

	// RVA: 0x6D792EC
	private object .ctor(object owner, object provider, object settings, object cloneSettings, object stream) { }

	// RVA: 0x6D797B8
	private static object GetValidationCallback(object settings) { }

	// RVA: 0x6D79998
	private static object DefaultSelectionCallback(object targetHost, object localCertificates, object remoteCertificate, object acceptableIssuers) { }

	// RVA: 0x6D799E4
	public object get_Settings() { }

	// RVA: 0x6D799EC
	public object SelectClientCertificate(object targetHost, object localCertificates, object remoteCertificate, object acceptableIssuers, object clientCertificate) { }

	// RVA: 0x6D79A38
	public object ValidateCertificate(object host, object serverMode, object leaf, object chain) { }

	// RVA: 0x6D79B18
	private object ValidateChain(object host, object server, object leaf, object chain, object certs, object errors) { }

	// RVA: 0x6D79C20
	private object ValidateChain(object host, object server, object leaf, object chain, object certs, object errors) { }

	// RVA: 0x6D7A2A0
	private object InvokeCallback(object leaf, object chain, object errors) { }

}

// Namespace: 
private enum Operation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Handshake;
	public const object Authenticated;
	public const object Renegotiate;
	public const object Read;
	public const object Write;
	public const object Close;
}

// Namespace: 
private enum OperationType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Read;
	public const object Write;
	public const object Renegotiate;
	public const object Shutdown;
}

// Namespace: 
private struct <ProcessAuthentication>d__48
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object options; // 0x18
	public object <>4__this; // 0x20
	public object runSynchronously; // 0x28
	public object cancellationToken; // 0x30
	private object <>u__1; // 0x38

	// Methods

	// RVA: 0x6D7C1D4
	private object MoveNext() { }

	// RVA: 0x6D7CFF8
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <StartOperation>d__57
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object type; // 0x20
	public object asyncRequest; // 0x28
	public object cancellationToken; // 0x30
	private object <>u__1; // 0x38

	// Methods

	// RVA: 0x6D7D0D0
	private object MoveNext() { }

	// RVA: 0x6D7DD34
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private sealed class <>c__DisplayClass66_0
{

	// Fields
	public object <>4__this; // 0x8
	public object len; // 0x10

	// Methods

	// RVA: 0x6D7DE34
	public object .ctor() { }

	// RVA: 0x6D7DE3C
	internal object <InnerRead>b__0() { }

}

// Namespace: 
private struct <InnerRead>d__66
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	public object requestedSize; // 0x28
	public object sync; // 0x2C
	private object <>u__1; // 0x30

	// Methods

	// RVA: 0x6D7DEDC
	private object MoveNext() { }

	// RVA: 0x6D7E42C
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <InnerWrite>d__67
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object cancellationToken; // 0x18
	public object <>4__this; // 0x20
	public object sync; // 0x28
	private object <>u__1; // 0x30

	// Methods

	// RVA: 0x6D7E52C
	private object MoveNext() { }

	// RVA: 0x6D7E894
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: Mono.Net.Security
internal abstract class MobileAuthenticatedStream
{

	// Fields
	private object xobileTlsContext; // 0x30
	private object lastException; // 0x38
	private object asyncHandshakeRequest; // 0x40
	private object asyncReadRequest; // 0x48
	private object asyncWriteRequest; // 0x50
	private object readBuffer; // 0x58
	private object writeBuffer; // 0x60
	private object ioLock; // 0x68
	private object closeRequested; // 0x70
	private object shutdown; // 0x74
	private object operation; // 0x78
	private static object uniqueNameInteger; // 0x0
	private readonly object <SslStream>k__BackingField; // 0x80
	private readonly object <Settings>k__BackingField; // 0x88
	private readonly object <Provider>k__BackingField; // 0x90
	private object <TargetHost>k__BackingField; // 0x98
	private static object nextId; // 0x4
	internal readonly object ID; // 0xA0

	// Properties
	public object SslStream { get; }
	public object Settings { get; }
	public object Provider { get; }
	internal object TargetHost { get; set; }
	public override object IsAuthenticated { get; }
	public object LocalCertificate { get; }
	public object InternalLocalCertificate { get; }
	public override object CanRead { get; }
	public override object CanTimeout { get; }
	public override object CanWrite { get; }
	public override object CanSeek { get; }
	public override object Length { get; }
	public override object Position { get; set; }
	public override object ReadTimeout { get; set; }
	public override object WriteTimeout { get; set; }

	// Methods

	// RVA: 0x6D75FA4
	public object .ctor(object innerStream, object leaveInnerStreamOpen, object owner, object settings, object provider) { }

	// RVA: 0x6D7A550
	public object get_SslStream() { }

	// RVA: 0x6D7A558
	public object get_Settings() { }

	// RVA: 0x6D7A560
	public object get_Provider() { }

	// RVA: 0x6D7A568
	internal object get_TargetHost() { }

	// RVA: 0x6D7A570
	private object set_TargetHost(object value) { }

	// RVA: 0x6D7A578
	internal object CheckThrow(object authSuccessCheck, object shutdownCheck) { }

	// RVA: 0x6D77CEC
	internal static object GetSSPIException(object e) { }

	// RVA: 0x6D7A65C
	internal static object GetIOException(object e, object message) { }

	// RVA: 0x6D7A7F4
	internal static object GetInternalError() { }

	// RVA: 0x6D7A848
	internal static object GetInvalidNestedCallException() { }

	// RVA: 0x6D775F4
	internal object SetException(object e) { }

	// RVA: 0x6D7A89C
	public object AuthenticateAsClient(object targetHost, object clientCertificates, object enabledSslProtocols, object checkCertificateRevocation) { }

	// RVA: 0x6D7AC90
	public object AuthenticateAsClientAsync(object targetHost, object clientCertificates, object enabledSslProtocols, object checkCertificateRevocation) { }

	// RVA: 0x6D7ABA4
	private object ProcessAuthentication(object runSynchronously, object options, object cancellationToken) { }

	// RVA: -1
	protected abstract object CreateContext(object options) { }

	// RVA: 0x6D7AE5C
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x6D7B06C
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x6D7B14C
	public override object ReadAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x6D7B1EC
	public override object WriteAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x6D7AF50
	private object StartOperation(object type, object asyncRequest, object cancellationToken) { }

	// RVA: 0x6D73E4C
	internal object InternalRead(object buffer, object offset, object size, object outWantMore) { }

	// RVA: 0x6D7B28C
	private object InternalRead(object asyncRequest, object internalBuffer, object buffer, object offset, object size) { }

	// RVA: 0x6D738C0
	internal object InternalWrite(object buffer, object offset, object size) { }

	// RVA: 0x6D7B410
	private object InternalWrite(object asyncRequest, object internalBuffer, object buffer, object offset, object size) { }

	// RVA: 0x6D7845C
	internal object InnerRead(object sync, object requestedSize, object cancellationToken) { }

	// RVA: 0x6D77E9C
	internal object InnerWrite(object sync, object cancellationToken) { }

	// RVA: 0x6D7872C
	internal object ProcessHandshake(object status, object renegotiate) { }

	// RVA: 0x6D78DDC
	internal object ProcessRead(object userBuffer) { }

	// RVA: 0x6D7904C
	internal object ProcessWrite(object userBuffer) { }

	// RVA: 0x6D7B5E4
	public override object get_IsAuthenticated() { }

	// RVA: 0x6D7B70C
	protected override object Dispose(object disposing) { }

	// RVA: 0x6D7BA34
	public override object Flush() { }

	// RVA: 0x6D7BA84
	public object get_LocalCertificate() { }

	// RVA: 0x6D7BB78
	public object get_InternalLocalCertificate() { }

	// RVA: 0x6D7BCB0
	public override object Seek(object offset, object origin) { }

	// RVA: 0x6D7BCF0
	public override object SetLength(object value) { }

	// RVA: 0x6D7BD48
	public override object get_CanRead() { }

	// RVA: 0x6D7BDD0
	public override object get_CanTimeout() { }

	// RVA: 0x6D7BE1C
	public override object get_CanWrite() { }

	// RVA: 0x6D7BED0
	public override object get_CanSeek() { }

	// RVA: 0x6D7BED8
	public override object get_Length() { }

	// RVA: 0x6D7BF24
	public override object get_Position() { }

	// RVA: 0x6D7BF74
	public override object set_Position(object value) { }

	// RVA: 0x6D7BFB4
	public override object get_ReadTimeout() { }

	// RVA: 0x6D7C004
	public override object set_ReadTimeout(object value) { }

	// RVA: 0x6D7C05C
	public override object get_WriteTimeout() { }

	// RVA: 0x6D7C0AC
	public override object set_WriteTimeout(object value) { }

	// RVA: 0x6D7C104
	private static object .cctor() { }

	// RVA: 0x6D7C154
	private object <InnerWrite>b__67_0() { }

}

// Namespace: Mono.Net.Security
internal abstract class MobileTlsContext
{

	// Fields
	private object certificateValidator; // 0x8
	private readonly object <Options>k__BackingField; // 0x10
	private readonly object <Parent>k__BackingField; // 0x18
	private readonly object <IsServer>k__BackingField; // 0x20
	private readonly object <TargetHost>k__BackingField; // 0x28
	private readonly object <ServerName>k__BackingField; // 0x30
	private readonly object <AskForClientCertificate>k__BackingField; // 0x38
	private readonly object <EnabledProtocols>k__BackingField; // 0x3C
	private readonly object <ClientCertificates>k__BackingField; // 0x40
	private object <LocalServerCertificate>k__BackingField; // 0x48

	// Properties
	internal object Options { get; }
	internal object Parent { get; }
	public object Settings { get; }
	public abstract object IsAuthenticated { get; }
	public object IsServer { get; }
	internal object TargetHost { get; }
	protected object ServerName { get; }
	protected object AskForClientCertificate { get; }
	protected object EnabledProtocols { get; }
	protected object ClientCertificates { get; }
	internal object LocalServerCertificate { get; set; }
	internal abstract object LocalClientCertificate { get; }
	public abstract object RemoteCertificate { get; }

	// Methods

	// RVA: 0x6D72258
	protected object .ctor(object parent, object options) { }

	// RVA: 0x6D7E96C
	internal object get_Options() { }

	// RVA: 0x6D7E974
	internal object get_Parent() { }

	// RVA: 0x6D72F58
	public object get_Settings() { }

	// RVA: -1
	public abstract object get_IsAuthenticated() { }

	// RVA: 0x6D7E97C
	public object get_IsServer() { }

	// RVA: 0x6D7E984
	internal object get_TargetHost() { }

	// RVA: 0x6D7E98C
	protected object get_ServerName() { }

	// RVA: 0x6D7E994
	protected object get_AskForClientCertificate() { }

	// RVA: 0x6D7E99C
	protected object get_EnabledProtocols() { }

	// RVA: 0x6D7E9A4
	protected object get_ClientCertificates() { }

	// RVA: 0x6D7E9AC
	protected object GetProtocolVersions(object min, object max) { }

	// RVA: -1
	public abstract object StartHandshake() { }

	// RVA: -1
	public abstract object ProcessHandshake() { }

	// RVA: -1
	public abstract object FinishHandshake() { }

	// RVA: 0x6D7EAF0
	internal object get_LocalServerCertificate() { }

	// RVA: 0x6D7EAF8
	private object set_LocalServerCertificate(object value) { }

	// RVA: -1
	internal abstract object get_LocalClientCertificate() { }

	// RVA: -1
	public abstract object get_RemoteCertificate() { }

	// RVA: -1
	public abstract object Flush() { }

	// RVA: -1
	public abstract object Read(object buffer, object offset, object count) { }

	// RVA: -1
	public abstract object Write(object buffer, object offset, object count) { }

	// RVA: -1
	public abstract object Shutdown() { }

	// RVA: -1
	public abstract object PendingRenegotiation() { }

	// RVA: 0x6D73424
	protected object ValidateCertificate(object leaf, object chain) { }

	// RVA: 0x6D7EB00
	protected object SelectServerCertificate(object serverIdentity) { }

	// RVA: 0x6D747E4
	protected object SelectClientCertificate(object acceptableIssuers) { }

	// RVA: -1
	public abstract object Renegotiate() { }

	// RVA: 0x6D7B958
	public object Dispose() { }

	// RVA: 0x6D7EE54
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x6D7EE58
	protected override object Finalize() { }

}

// Namespace: Mono.Net.Security
internal abstract class MobileTlsProvider
{

	// Methods

	// RVA: -1
	internal abstract object CreateSslStream(object sslStream, object innerStream, object leaveInnerStreamOpen, object settings) { }

	// RVA: -1
	internal abstract object ValidateCertificate(object validator, object targetHost, object serverMode, object certificates, object wantsChain, object chain, object errors, object status11) { }

	// RVA: 0x6D75F9C
	protected object .ctor() { }

}

// Namespace: Mono.Net.Security
internal abstract class MonoSslAuthenticationOptions
{

	// Fields
	private object <ServerCertSelectionDelegate>k__BackingField; // 0x8

	// Properties
	public abstract object ServerMode { get; }
	public abstract object AllowRenegotiation { get; }
	public abstract object EnabledSslProtocols { get; set; }
	public abstract object EncryptionPolicy { set; }
	public abstract object CertificateRevocationCheckMode { set; }
	public abstract object TargetHost { get; set; }
	public abstract object ServerCertificate { get; }
	public abstract object ClientCertificates { get; set; }
	public abstract object ClientCertificateRequired { get; }
	internal object ServerCertSelectionDelegate { get; }

	// Methods

	// RVA: -1
	public abstract object get_ServerMode() { }

	// RVA: -1
	public abstract object get_AllowRenegotiation() { }

	// RVA: -1
	public abstract object get_EnabledSslProtocols() { }

	// RVA: -1
	public abstract object set_EnabledSslProtocols(object value) { }

	// RVA: -1
	public abstract object set_EncryptionPolicy(object value) { }

	// RVA: -1
	public abstract object set_CertificateRevocationCheckMode(object value) { }

	// RVA: -1
	public abstract object get_TargetHost() { }

	// RVA: -1
	public abstract object set_TargetHost(object value) { }

	// RVA: -1
	public abstract object get_ServerCertificate() { }

	// RVA: -1
	public abstract object get_ClientCertificates() { }

	// RVA: -1
	public abstract object set_ClientCertificates(object value) { }

	// RVA: -1
	public abstract object get_ClientCertificateRequired() { }

	// RVA: 0x6D7EF14
	internal object get_ServerCertSelectionDelegate() { }

	// RVA: 0x6D7EF1C
	protected object .ctor() { }

}

// Namespace: Mono.Net.Security
internal sealed class MonoSslClientAuthenticationOptions
{

	// Fields
	private readonly object <Options>k__BackingField; // 0x10

	// Properties
	public object Options { get; }
	public override object ServerMode { get; }
	public override object AllowRenegotiation { get; }
	public override object CertificateRevocationCheckMode { set; }
	public override object EncryptionPolicy { set; }
	public override object EnabledSslProtocols { get; set; }
	public override object TargetHost { get; set; }
	public override object ClientCertificateRequired { get; }
	public override object ClientCertificates { get; set; }
	public override object ServerCertificate { get; }

	// Methods

	// RVA: 0x6D7EF24
	public object get_Options() { }

	// RVA: 0x6D7EF2C
	public override object get_ServerMode() { }

	// RVA: 0x6D7AB34
	public object .ctor() { }

	// RVA: 0x6D7EF34
	public override object get_AllowRenegotiation() { }

	// RVA: 0x6D7EF58
	public override object set_CertificateRevocationCheckMode(object value) { }

	// RVA: 0x6D7EF7C
	public override object set_EncryptionPolicy(object value) { }

	// RVA: 0x6D7EFA0
	public override object get_EnabledSslProtocols() { }

	// RVA: 0x6D7EFC4
	public override object set_EnabledSslProtocols(object value) { }

	// RVA: 0x6D7EFE8
	public override object get_TargetHost() { }

	// RVA: 0x6D7F00C
	public override object set_TargetHost(object value) { }

	// RVA: 0x6D7F030
	public override object get_ClientCertificateRequired() { }

	// RVA: 0x6D7F070
	public override object get_ClientCertificates() { }

	// RVA: 0x6D7F094
	public override object set_ClientCertificates(object value) { }

	// RVA: 0x6D7F0B8
	public override object get_ServerCertificate() { }

}

// Namespace: Mono.Net.Security
internal static class MonoTlsProviderFactory
{

	// Fields
	private static object locker; // 0x0
	private static object initialized; // 0x8
	private static object defaultProvider; // 0x10
	private static object providerRegistration; // 0x18
	private static object providerCache; // 0x20
	internal static readonly object UnityTlsId; // 0x28
	internal static readonly object AppleTlsId; // 0x38
	internal static readonly object BtlsId; // 0x48

	// Methods

	// RVA: 0x6D7968C
	internal static object GetProviderInternal() { }

	// RVA: 0x6D7F0F8
	internal static object InitializeInternal() { }

	// RVA: 0x6D7F998
	private static object LookupProvider(object name, object throwOnError) { }

	// RVA: 0x6D7F568
	private static object InitializeProviderRegistration() { }

	// RVA: 0x6D7FFA4
	private static object PopulateUnityProviders() { }

	// RVA: 0x6D800FC
	private static object PopulateProviders() { }

	// RVA: 0x6D8038C
	internal static object IsBtlsSupported() { }

	// RVA: 0x6D7F780
	private static object CreateDefaultProviderImpl() { }

	// RVA: 0x6D80468
	internal static object GetProvider() { }

	// RVA: 0x6D804D0
	private static object .cctor() { }

}

// Namespace: 
private struct <CreateStream>d__18
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object tunnel; // 0x20
	public object cancellationToken; // 0x28
	private object <socket>5__2; // 0x30
	private object <>u__1; // 0x38

	// Methods

	// RVA: 0x6D80974
	private object MoveNext() { }

	// RVA: 0x6D8121C
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: Mono.Net.Security
internal class MonoTlsStream
{

	// Fields
	private readonly object provider; // 0x8
	private readonly object networkStream; // 0x10
	private readonly object request; // 0x18
	private readonly object settings; // 0x20
	private object sslStream; // 0x28
	private readonly object sslStreamLock; // 0x30
	private object status; // 0x38
	private object <CertificateValidationFailed>k__BackingField; // 0x3C

	// Properties
	internal object Request { get; }
	internal object ExceptionStatus { get; }
	internal object CertificateValidationFailed { get; set; }

	// Methods

	// RVA: 0x6D80604
	internal object get_Request() { }

	// RVA: 0x6D8060C
	internal object get_ExceptionStatus() { }

	// RVA: 0x6D80614
	internal object get_CertificateValidationFailed() { }

	// RVA: 0x6D8061C
	internal object set_CertificateValidationFailed(object value) { }

	// RVA: 0x6D80624
	public object .ctor(object request, object networkStream) { }

	// RVA: 0x6D80764
	internal object CreateStream(object tunnel, object cancellationToken) { }

	// RVA: 0x6D80878
	public object Dispose() { }

	// RVA: 0x6D8087C
	private object CloseSslStream() { }

}

// Namespace: Mono.Net.Security
internal static class NoReflectionHelper
{

	// Methods

	// RVA: 0x6D8131C
	internal static object GetProvider() { }

}

// Namespace: Mono.Net.Security
internal static class SystemCertificateValidator
{

	// Fields
	private static object is_macosx; // 0x0
	private static object s_flags; // 0x4

	// Methods

	// RVA: 0x6D813CC
	private static object .cctor() { }

	// RVA: 0x6D7A380
	internal static object NeedsChain(object settings) { }

}

// Namespace: 
private sealed class <>c__DisplayClass0_0
{

	// Fields
	public object callback; // 0x8

	// Methods

	// RVA: 0x6D814E0
	public object .ctor() { }

	// RVA: 0x6D814F0
	internal object <PublicToMono>b__0(object h, object c, object ch, object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object callback; // 0x8

	// Methods

	// RVA: 0x6D814E8
	public object .ctor() { }

	// RVA: 0x6D8151C
	internal object <MonoToInternal>b__0(object t, object lc, object rc, object ai) { }

}

// Namespace: Mono.Net.Security.Private
internal static class CallbackHelpers
{

	// Methods

	// RVA: 0x6D81420
	internal static object PublicToMono(object callback) { }

	// RVA: 0x6D798D0
	internal static object MonoToInternal(object callback) { }

}

// Namespace: Mono.Http
internal class NtlmSession
{

	// Fields
	private object message; // 0x8

	// Methods

	// RVA: 0x6D81548
	public object .ctor() { }

	// RVA: 0x6D81550
	public object Authenticate(object challenge, object webRequest, object credentials) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__1_0; // 0x8

	// Methods

	// RVA: 0x6D81F78
	private static object .cctor() { }

	// RVA: 0x6D81FD8
	public object .ctor() { }

	// RVA: 0x6D81FE0
	internal object <Authenticate>b__1_0(object x) { }

}

// Namespace: Mono.Http
internal class NtlmClient
{

	// Fields
	private static readonly object cache; // 0x0

	// Properties
	public object AuthenticationType { get; }

	// Methods

	// RVA: 0x6D81AD0
	public object Authenticate(object challenge, object webRequest, object credentials) { }

	// RVA: 0x6D81E94
	public object PreAuthenticate(object webRequest, object credentials) { }

	// RVA: 0x6D81E9C
	public object get_AuthenticationType() { }

	// RVA: 0x6D81EE0
	public object .ctor() { }

	// RVA: 0x6D81EE8
	private static object .cctor() { }

}

// Namespace: 
protected internal class BoringBioHandle
{

	// Methods

	// RVA: 0x6D821CC
	public object .ctor(object handle) { }

	// RVA: 0x6D821E0
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsBio
{

	// Properties
	protected internal object Handle { get; }

	// Methods

	// RVA: 0x6D82038
	internal object .ctor(object handle) { }

	// RVA: 0x6D82090
	protected internal object get_Handle() { }

	// RVA: 0x6D82138
	private static extern object mono_btls_bio_free(object handle) { }

}

// Namespace: Mono.Btls
internal class MonoBtlsBioMemory
{

	// Methods

	// RVA: 0x6D82288
	private static extern object mono_btls_bio_mem_new() { }

	// RVA: 0x6D8230C
	private static extern object mono_btls_bio_mem_get_data(object handle, object data) { }

	// RVA: 0x6D823B4
	public object .ctor() { }

	// RVA: 0x6D82488
	public object GetData() { }

}

// Namespace: Mono.Btls
internal interface IMonoBtlsBioMono
{

	// Methods

	// RVA: -1
	public abstract object Read(object buffer, object offset, object size, object wantMore) { }

	// RVA: -1
	public abstract object Write(object buffer, object offset, object size) { }

	// RVA: -1
	public abstract object Flush() { }

	// RVA: -1
	public abstract object Close() { }

}

// Namespace: 
private enum ControlCommand
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Flush;
}

// Namespace: 
private sealed class BioReadFunc
{

	// Methods

	// RVA: 0x6D83530
	public object .ctor(object object, object method) { }

	// RVA: 0x6D83D9C
	public virtual object Invoke(object bio, object data, object dataLength, object wantMore) { }

}

// Namespace: 
private sealed class BioWriteFunc
{

	// Methods

	// RVA: 0x6D835C8
	public object .ctor(object object, object method) { }

	// RVA: 0x6D83E60
	public virtual object Invoke(object bio, object data, object dataLength) { }

}

// Namespace: 
private sealed class BioControlFunc
{

	// Methods

	// RVA: 0x6D83660
	public object .ctor(object object, object method) { }

	// RVA: 0x6D83F24
	public virtual object Invoke(object bio, object command, object arg) { }

}

// Namespace: Mono.Btls
internal class MonoBtlsBioMono
{

	// Fields
	private object handle; // 0x18
	private object instance; // 0x20
	private object readFunc; // 0x28
	private object writeFunc; // 0x30
	private object controlFunc; // 0x38
	private object readFuncPtr; // 0x40
	private object writeFuncPtr; // 0x48
	private object controlFuncPtr; // 0x50
	private object backend; // 0x58

	// Methods

	// RVA: 0x6D8305C
	public object .ctor(object backend) { }

	// RVA: 0x6D834AC
	private static extern object mono_btls_bio_mono_new() { }

	// RVA: 0x6D836F8
	private static extern object mono_btls_bio_mono_initialize(object handle, object instance, object readFunc, object writeFunc, object controlFunc) { }

	// RVA: 0x6D837A8
	private object Control(object command, object arg) { }

	// RVA: 0x6D838C0
	private object OnRead(object data, object dataLength, object wantMore) { }

	// RVA: 0x6D82ADC
	private static object OnRead(object instance, object data, object dataLength, object wantMore) { }

	// RVA: 0x6D83A5C
	private object OnWrite(object data, object dataLength) { }

	// RVA: 0x6D82CE8
	private static object OnWrite(object instance, object data, object dataLength) { }

	// RVA: 0x6D82EDC
	private static object Control(object instance, object command, object arg) { }

	// RVA: 0x6D83BB4
	protected override object Close() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsContext
{

	// Fields
	private object remoteCertificate; // 0x50
	private object clientCertificate; // 0x58
	private object nativeServerCertificate; // 0x60
	private object nativeClientCertificate; // 0x68
	private object ctx; // 0x70
	private object ssl; // 0x78
	private object bio; // 0x80
	private object errbio; // 0x88
	private object connectionInfo; // 0x90
	private object certificateValidated; // 0x98
	private object isAuthenticated; // 0x99
	private object connected; // 0x9A

	// Properties
	public override object IsAuthenticated { get; }
	internal override object LocalClientCertificate { get; }
	public override object RemoteCertificate { get; }

	// Methods

	// RVA: 0x6D83F38
	public object .ctor(object parent, object options) { }

	// RVA: 0x6D83F74
	private static object GetPrivateCertificate(object certificate) { }

	// RVA: 0x6D8420C
	private object VerifyCallback(object storeCtx) { }

	// RVA: 0x6D84564
	private object SelectCallback(object acceptableIssuers) { }

	// RVA: 0x6D84B3C
	private object ServerNameCallback() { }

	// RVA: 0x6D84B9C
	public override object StartHandshake() { }

	// RVA: 0x6D84794
	private object SetPrivateCertificate(object privateCert) { }

	// RVA: 0x6D851B8
	private static object GetException(object status) { }

	// RVA: 0x6D85A14
	public override object ProcessHandshake() { }

	// RVA: 0x6D85C60
	private object DoProcessHandshake() { }

	// RVA: 0x6D85ECC
	public override object FinishHandshake() { }

	// RVA: 0x6D84D04
	private object InitializeConnection() { }

	// RVA: 0x6D84620
	private object GetPeerCertificate() { }

	// RVA: 0x6D85EF4
	private object InitializeSession() { }

	// RVA: 0x6D86854
	private static object GetProtocol(object protocol) { }

	// RVA: 0x6D868B4
	public override object Flush() { }

	// RVA: 0x6D868F4
	public override object Read(object buffer, object offset, object size) { }

	// RVA: 0x6D86BE0
	public override object Write(object buffer, object offset, object size) { }

	// RVA: 0x6D86E8C
	public override object Renegotiate() { }

	// RVA: 0x6D86ECC
	public override object Shutdown() { }

	// RVA: 0x6D86F40
	public override object PendingRenegotiation() { }

	// RVA: -1
	private object Dispose(object disposable) { }

	// RVA: 0x6D86F64
	protected override object Dispose(object disposing) { }

	// RVA: 0x6D870F0
	private object Mono.Btls.IMonoBtlsBioMono.Read(object buffer, object offset, object size, object wantMore) { }

	// RVA: 0x6D87110
	private object Mono.Btls.IMonoBtlsBioMono.Write(object buffer, object offset, object size) { }

	// RVA: 0x6D87130
	private object Mono.Btls.IMonoBtlsBioMono.Flush() { }

	// RVA: 0x6D87134
	private object Mono.Btls.IMonoBtlsBioMono.Close() { }

	// RVA: 0x6D87138
	public override object get_IsAuthenticated() { }

	// RVA: 0x6D87140
	internal override object get_LocalClientCertificate() { }

	// RVA: 0x6D87148
	public override object get_RemoteCertificate() { }

}

// Namespace: Mono.Btls
internal static class MonoBtlsError
{

	// Methods

	// RVA: 0x6D87150
	private static extern object mono_btls_error_clear_error() { }

	// RVA: 0x6D871D4
	private static extern object mono_btls_error_get_error_line(object file, object line) { }

	// RVA: 0x6D8727C
	private static extern object mono_btls_error_get_error_string_n(object error, object buf, object len) { }

	// RVA: 0x6D8732C
	private static extern object mono_btls_error_get_reason(object error) { }

	// RVA: 0x6D85BDC
	public static object ClearError() { }

	// RVA: 0x6D857C8
	public static object GetErrorString(object error) { }

	// RVA: 0x6D85574
	public static object GetError(object file, object line) { }

	// RVA: 0x6D85734
	public static object GetErrorReason(object error) { }

}

// Namespace: Mono.Btls
internal class MonoBtlsException
{

	// Methods

	// RVA: 0x6D873C0
	public object .ctor() { }

	// RVA: 0x6D85678
	public object .ctor(object error) { }

	// RVA: 0x6D859A8
	public object .ctor(object message) { }

	// RVA: 0x6D87448
	public object .ctor(object format, object args) { }

}

// Namespace: 
internal class BoringKeyHandle
{

	// Methods

	// RVA: 0x6D87E54
	internal object .ctor(object handle) { }

	// RVA: 0x6D880A8
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsKey
{

	// Properties
	internal object Handle { get; }

	// Methods

	// RVA: 0x6D874D4
	private static extern object mono_btls_key_new() { }

	// RVA: 0x6D87558
	private static extern object mono_btls_key_free(object handle) { }

	// RVA: 0x6D875EC
	private static extern object mono_btls_key_up_ref(object handle) { }

	// RVA: 0x6D87680
	private static extern object mono_btls_key_get_bytes(object handle, object data, object size, object include_private_bits) { }

	// RVA: 0x6D87728
	private static extern object mono_btls_key_assign_rsa_private_key(object handle, object der, object der_length) { }

	// RVA: 0x6D877C8
	internal object get_Handle() { }

	// RVA: 0x6D8784C
	internal object .ctor(object handle) { }

	// RVA: 0x6D87878
	public object GetBytes(object include_private_bits) { }

	// RVA: 0x6D87BE4
	public object Copy() { }

	// RVA: 0x6D87E60
	public static object CreateFromRSAPrivateKey(object privateKey) { }

}

// Namespace: 
protected internal abstract class MonoBtlsHandle
{

	// Properties
	public override object IsInvalid { get; }

	// Methods

	// RVA: 0x6D821D8
	internal object .ctor(object handle, object ownsHandle) { }

	// RVA: 0x6D88534
	public override object get_IsInvalid() { }

}

// Namespace: Mono.Btls
internal abstract class MonoBtlsObject
{

	// Fields
	private object handle; // 0x8
	private object lastError; // 0x10

	// Properties
	internal object Handle { get; }
	public object IsValid { get; }

	// Methods

	// RVA: 0x6D82064
	internal object .ctor(object handle) { }

	// RVA: 0x6D82114
	internal object get_Handle() { }

	// RVA: 0x6D8812C
	public object get_IsValid() { }

	// RVA: 0x6D87DBC
	protected object CheckThrow() { }

	// RVA: 0x6D83A40
	protected object SetException(object ex) { }

	// RVA: 0x6D827E0
	protected object CheckError(object ok, object callerName) { }

	// RVA: 0x6D87B40
	protected object CheckError(object ret, object callerName) { }

	// RVA: 0x6D85CDC
	protected internal object CheckLastError(object callerName) { }

	// RVA: 0x6D88184
	private static extern object mono_btls_free(object data) { }

	// RVA: 0x6D87B4C
	protected object FreeDataPtr(object data) { }

	// RVA: 0x6D88218
	protected virtual object Close() { }

	// RVA: 0x6D8821C
	protected object Dispose(object disposing) { }

	// RVA: 0x6D883E8
	public object Dispose() { }

	// RVA: 0x6D88488
	protected override object Finalize() { }

}

// Namespace: 
internal class BoringPkcs12Handle
{

	// Methods

	// RVA: 0x6D88B0C
	public object .ctor(object handle) { }

	// RVA: 0x6D89268
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsPkcs12
{

	// Fields
	private object privateKey; // 0x18

	// Properties
	internal object Handle { get; }
	public object Count { get; }
	public object HasPrivateKey { get; }

	// Methods

	// RVA: 0x6D88544
	internal object get_Handle() { }

	// RVA: 0x6D885C8
	private static extern object mono_btls_pkcs12_free(object handle) { }

	// RVA: 0x6D8865C
	private static extern object mono_btls_pkcs12_new() { }

	// RVA: 0x6D886E0
	private static extern object mono_btls_pkcs12_get_count(object handle) { }

	// RVA: 0x6D88774
	private static extern object mono_btls_pkcs12_get_cert(object Handle, object index) { }

	// RVA: 0x6D8881C
	private static extern object mono_btls_pkcs12_import(object chain, object data, object len, object password) { }

	// RVA: 0x6D88910
	private static extern object mono_btls_pkcs12_has_private_key(object pkcs12) { }

	// RVA: 0x6D889A4
	private static extern object mono_btls_pkcs12_get_private_key(object pkcs12) { }

	// RVA: 0x6D88A38
	internal object .ctor() { }

	// RVA: 0x6D88B18
	public object get_Count() { }

	// RVA: 0x6D88C28
	public object GetCertificate(object index) { }

	// RVA: 0x6D88E2C
	public object Import(object buffer, object password) { }

	// RVA: 0x6D88F58
	public object get_HasPrivateKey() { }

	// RVA: 0x6D8905C
	public object GetPrivateKey() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsProvider
{

	// Properties
	public override object ID { get; }
	public override object Name { get; }
	public override object SupportsSslStream { get; }
	public override object SupportsMonoExtensions { get; }
	public override object SupportsConnectionInfo { get; }
	internal override object SupportsCleanShutdown { get; }
	public override object SupportedProtocols { get; }

	// Methods

	// RVA: 0x6D892EC
	public override object get_ID() { }

	// RVA: 0x6D89368
	public override object get_Name() { }

	// RVA: 0x6D80390
	internal object .ctor() { }

	// RVA: 0x6D893AC
	public override object get_SupportsSslStream() { }

	// RVA: 0x6D893B4
	public override object get_SupportsMonoExtensions() { }

	// RVA: 0x6D893BC
	public override object get_SupportsConnectionInfo() { }

	// RVA: 0x6D893C4
	internal override object get_SupportsCleanShutdown() { }

	// RVA: 0x6D893CC
	public override object get_SupportedProtocols() { }

	// RVA: 0x6D893D4
	internal override object CreateSslStream(object sslStream, object innerStream, object leaveInnerStreamOpen, object settings) { }

	// RVA: 0x6D8946C
	internal object GetNativeCertificate(object data, object password, object flags) { }

	// RVA: 0x6D896AC
	internal object GetNativeCertificate(object certificate) { }

	// RVA: 0x6D8962C
	internal object GetNativeCertificate(object data, object password, object flags) { }

	// RVA: 0x6D86460
	internal static object GetVerifyParam(object settings, object targetHost, object serverMode) { }

	// RVA: 0x6D898C0
	internal override object ValidateCertificate(object validator, object targetHost, object serverMode, object certificates, object wantsChain, object chain, object errors, object status11) { }

	// RVA: 0x6D8A53C
	internal static object ValidateCertificate(object chain, object param) { }

	// RVA: 0x6D89FC8
	private object CheckValidationResult(object validator, object targetHost, object serverMode, object certificates, object wantsChain, object chain, object storeCtx, object success, object errors, object status11) { }

	// RVA: 0x6D8A864
	internal static object MapVerifyErrorToChainStatus(object code) { }

	// RVA: 0x6D860D4
	internal static object SetupCertificateStore(object store, object settings, object server) { }

	// RVA: 0x6D8AAE4
	private static object SetupDefaultCertificateStore(object store) { }

	// RVA: 0x6D8AB7C
	private static object AddUserStore(object store) { }

	// RVA: 0x6D8ABE0
	private static object AddMachineStore(object store) { }

	// RVA: 0x6D8AAA8
	private static object AddTrustedRoots(object store, object settings, object server) { }

	// RVA: 0x6D866B8
	public static object CreateCertificate(object x509) { }

	// RVA: 0x6D8A4A8
	public static object GetManagedChain(object chain) { }

	// RVA: 0x6D8AC44
	public static object GetBtlsCertificate(object certificate) { }

	// RVA: 0x6D8A104
	public static object GetNativeChain(object certificates) { }

}

// Namespace: Mono.Btls
internal sealed class MonoBtlsVerifyCallback
{

	// Methods

	// RVA: 0x716BE70
	public object .ctor(object object, object method) { }

	// RVA: 0x716BF8C
	public virtual object Invoke(object ctx) { }

}

// Namespace: Mono.Btls
internal sealed class MonoBtlsSelectCallback
{

	// Methods

	// RVA: 0x716C120
	public object .ctor(object object, object method) { }

	// RVA: 0x716C1C8
	public virtual object Invoke(object acceptableIssuers) { }

}

// Namespace: Mono.Btls
internal sealed class MonoBtlsServerNameCallback
{

	// Methods

	// RVA: 0x716C244
	public object .ctor(object object, object method) { }

	// RVA: 0x716C2D8
	public virtual object Invoke() { }

}

// Namespace: 
internal class BoringSslHandle
{

	// Methods

	// RVA: 0x716D548
	public object .ctor(object handle) { }

	// RVA: 0x716FB3C
	protected override object ReleaseHandle() { }

}

// Namespace: 
private sealed class PrintErrorsCallbackFunc
{

	// Methods

	// RVA: 0x716D698
	public object .ctor(object object, object method) { }

	// RVA: 0x716FC80
	public virtual object Invoke(object str, object len, object ctx) { }

}

// Namespace: Mono.Btls
internal class MonoBtlsSsl
{

	// Fields
	private object bio; // 0x18
	private object printErrorsFunc; // 0x20
	private object printErrorsFuncPtr; // 0x28

	// Properties
	internal object Handle { get; }

	// Methods

	// RVA: 0x716C4F4
	private static extern object mono_btls_ssl_destroy(object handle) { }

	// RVA: 0x716C588
	private static extern object mono_btls_ssl_new(object handle) { }

	// RVA: 0x716C61C
	private static extern object mono_btls_ssl_use_certificate(object handle, object x509) { }

	// RVA: 0x716C6C4
	private static extern object mono_btls_ssl_use_private_key(object handle, object key) { }

	// RVA: 0x716C76C
	private static extern object mono_btls_ssl_add_chain_certificate(object handle, object x509) { }

	// RVA: 0x716C814
	private static extern object mono_btls_ssl_accept(object handle) { }

	// RVA: 0x716C8A8
	private static extern object mono_btls_ssl_connect(object handle) { }

	// RVA: 0x716C93C
	private static extern object mono_btls_ssl_handshake(object handle) { }

	// RVA: 0x716C9D0
	private static extern object mono_btls_ssl_close(object handle) { }

	// RVA: 0x716CA60
	private static extern object mono_btls_ssl_shutdown(object handle) { }

	// RVA: 0x716CAF4
	private static extern object mono_btls_ssl_set_quiet_shutdown(object handle, object mode) { }

	// RVA: 0x716CB9C
	private static extern object mono_btls_ssl_set_bio(object handle, object bio) { }

	// RVA: 0x716CC44
	private static extern object mono_btls_ssl_read(object handle, object data, object len) { }

	// RVA: 0x716CCF4
	private static extern object mono_btls_ssl_write(object handle, object data, object len) { }

	// RVA: 0x716CDA0
	private static extern object mono_btls_ssl_get_error(object handle, object ret_code) { }

	// RVA: 0x716CE48
	private static extern object mono_btls_ssl_get_version(object handle) { }

	// RVA: 0x716CEDC
	private static extern object mono_btls_ssl_get_cipher(object handle) { }

	// RVA: 0x716CF70
	private static extern object mono_btls_ssl_get_peer_certificate(object handle) { }

	// RVA: 0x716D004
	private static extern object mono_btls_ssl_print_errors_cb(object func, object ctx) { }

	// RVA: 0x716D0AC
	private static extern object mono_btls_ssl_set_server_name(object handle, object name) { }

	// RVA: 0x716D154
	private static extern object mono_btls_ssl_get_server_name(object handle) { }

	// RVA: 0x716D1E8
	private static extern object mono_btls_ssl_set_renegotiate_mode(object handle, object mode) { }

	// RVA: 0x716D290
	private static extern object mono_btls_ssl_renegotiate_pending(object handle) { }

	// RVA: 0x716D324
	private static object Create_internal(object ctx) { }

	// RVA: 0x716D554
	public object .ctor(object ctx) { }

	// RVA: 0x716D730
	internal object get_Handle() { }

	// RVA: 0x716D7B8
	public object SetBio(object bio) { }

	// RVA: 0x716D900
	private object ThrowError(object callerName) { }

	// RVA: 0x716DCE4
	private object GetError(object ret_code) { }

	// RVA: 0x716DE44
	public object SetCertificate(object x509) { }

	// RVA: 0x716E084
	public object SetPrivateKey(object key) { }

	// RVA: 0x716E1E8
	public object AddIntermediateCertificate(object x509) { }

	// RVA: 0x716E3A0
	public object Accept() { }

	// RVA: 0x716E4B8
	public object Connect() { }

	// RVA: 0x716E5D0
	public object Handshake() { }

	// RVA: 0x716C35C
	private static object PrintErrorsCallback(object str, object len, object ctx) { }

	// RVA: 0x716DB28
	public object GetErrors() { }

	// RVA: 0x716E730
	public object PrintErrors() { }

	// RVA: 0x716E8CC
	public object Read(object data, object dataSize) { }

	// RVA: 0x716EA54
	public object Write(object data, object dataSize) { }

	// RVA: 0x716EC7C
	public object GetVersion() { }

	// RVA: 0x716ED94
	public object GetCipher() { }

	// RVA: 0x716EF14
	public object GetPeerCertificate() { }

	// RVA: 0x716F0E8
	public object SetServerName(object name) { }

	// RVA: 0x716F3B8
	public object GetServerName() { }

	// RVA: 0x716F548
	public object Shutdown() { }

	// RVA: 0x716F670
	public object SetQuietShutdown() { }

	// RVA: 0x716F790
	protected override object Close() { }

	// RVA: 0x716F920
	public object SetRenegotiateMode(object mode) { }

	// RVA: 0x716FA34
	public object RenegotiatePending() { }

}

// Namespace: 
internal class BoringSslCtxHandle
{

	// Methods

	// RVA: 0x7170C48
	public object .ctor(object handle) { }

	// RVA: 0x7172CB4
	protected override object ReleaseHandle() { }

}

// Namespace: 
private sealed class NativeVerifyFunc
{

	// Methods

	// RVA: 0x717103C
	public object .ctor(object object, object method) { }

	// RVA: 0x7172DE8
	public virtual object Invoke(object instance, object preverify_ok, object ctx) { }

}

// Namespace: 
private sealed class NativeSelectFunc
{

	// Methods

	// RVA: 0x71710D4
	public object .ctor(object object, object method) { }

	// RVA: 0x7172EBC
	public virtual object Invoke(object instance, object count, object sizes, object data) { }

}

// Namespace: 
private sealed class NativeServerNameFunc
{

	// Methods

	// RVA: 0x717116C
	public object .ctor(object object, object method) { }

	// RVA: 0x7172F54
	public virtual object Invoke(object instance) { }

}

// Namespace: Mono.Btls
internal class MonoBtlsSslCtx
{

	// Fields
	private object verifyFunc; // 0x18
	private object selectFunc; // 0x20
	private object serverNameFunc; // 0x28
	private object verifyFuncPtr; // 0x30
	private object selectFuncPtr; // 0x38
	private object serverNameFuncPtr; // 0x40
	private object verifyCallback; // 0x48
	private object selectCallback; // 0x50
	private object serverNameCallback; // 0x58
	private object store; // 0x60
	private object instance; // 0x68
	private object instancePtr; // 0x70

	// Properties
	internal object Handle { get; }
	public object CertificateStore { get; }

	// Methods

	// RVA: 0x716D4C0
	internal object get_Handle() { }

	// RVA: 0x7170470
	private static extern object mono_btls_ssl_ctx_new() { }

	// RVA: 0x71704F4
	private static extern object mono_btls_ssl_ctx_free(object handle) { }

	// RVA: 0x7170588
	private static extern object mono_btls_ssl_ctx_initialize(object handle, object instance) { }

	// RVA: 0x7170630
	private static extern object mono_btls_ssl_ctx_set_cert_verify_callback(object handle, object func, object cert_required) { }

	// RVA: 0x71706E0
	private static extern object mono_btls_ssl_ctx_set_cert_select_callback(object handle, object func) { }

	// RVA: 0x7170788
	private static extern object mono_btls_ssl_ctx_set_min_version(object handle, object version) { }

	// RVA: 0x7170830
	private static extern object mono_btls_ssl_ctx_set_max_version(object handle, object version) { }

	// RVA: 0x71708D8
	private static extern object mono_btls_ssl_ctx_set_ciphers(object handle, object count, object data, object allow_unsupported) { }

	// RVA: 0x7170980
	private static extern object mono_btls_ssl_ctx_set_verify_param(object handle, object param) { }

	// RVA: 0x7170A28
	private static extern object mono_btls_ssl_ctx_set_client_ca_list(object handle, object count, object sizes, object data) { }

	// RVA: 0x7170AD0
	private static extern object mono_btls_ssl_ctx_set_server_name_callback(object handle, object func) { }

	// RVA: 0x7170B78
	public object .ctor() { }

	// RVA: 0x7170C54
	internal object .ctor(object handle) { }

	// RVA: 0x7171234
	public object get_CertificateStore() { }

	// RVA: 0x717123C
	private object VerifyCallback(object preverify_ok, object ctx) { }

	// RVA: 0x716FD04
	private static object NativeVerifyCallback(object instance, object preverify_ok, object store_ctx) { }

	// RVA: 0x71700B0
	private static object NativeSelectCallback(object instance, object count, object sizes, object data) { }

	// RVA: 0x71712FC
	private static object CopyIssuers(object count, object sizesPtr, object dataPtr) { }

	// RVA: 0x7171A50
	public object SetVerifyCallback(object callback, object client_cert_required) { }

	// RVA: 0x7171BF4
	public object SetSelectCallback(object callback) { }

	// RVA: 0x7171D2C
	public object SetMinVersion(object version) { }

	// RVA: 0x7171E40
	public object SetMaxVersion(object version) { }

	// RVA: 0x7171F54
	public object SetCiphers(object ciphers, object allow_unsupported) { }

	// RVA: 0x71721EC
	public object SetVerifyParam(object param) { }

	// RVA: 0x717247C
	public object SetClientCertificateIssuers(object acceptableIssuers) { }

	// RVA: 0x7172B28
	public object SetServerNameCallback(object callback) { }

	// RVA: 0x71702E0
	private static object NativeServerNameCallback(object instance) { }

	// RVA: 0x7172C60
	protected override object Close() { }

}

// Namespace: Mono.Btls
internal enum MonoBtlsSslError
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Ssl;
	public const object WantRead;
	public const object WantWrite;
	public const object WantX509Lookup;
	public const object Syscall;
	public const object ZeroReturn;
	public const object WantConnect;
	public const object WantAccept;
	public const object WantChannelIdLookup;
	public const object PendingSession;
	public const object PendingCertificate;
	public const object WantPrivateKeyOperation;
}

// Namespace: Mono.Btls
internal enum MonoBtlsSslRenegotiateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NEVER;
	public const object ONCE;
	public const object FREELY;
	public const object IGNORE;
}

// Namespace: Mono.Btls
internal class MonoBtlsStream
{

	// Methods

	// RVA: 0x7172F68
	public object .ctor(object innerStream, object leaveInnerStreamOpen, object owner, object settings, object provider) { }

	// RVA: 0x7173004
	protected override object CreateContext(object options) { }

}

// Namespace: Mono.Btls
internal static class MonoBtlsUtils
{

	// Fields
	private static object emailOid; // 0x0

	// Methods

	// RVA: 0x7173074
	public static object Compare(object a, object b) { }

	// RVA: 0x71730FC
	private static object AppendEntry(object sb, object name, object index, object separator, object quotes) { }

	// RVA: 0x71718E0
	public static object FormatName(object name, object reversed, object separator, object quotes) { }

	// RVA: 0x7173E98
	private static object .cctor() { }

}

// Namespace: 
internal class BoringX509Handle
{

	// Methods

	// RVA: 0x716F0D4
	public object .ctor(object handle) { }

	// RVA: 0x71752F0
	protected override object ReleaseHandle() { }

	// RVA: 0x7175388
	public object StealHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsX509
{

	// Properties
	internal object Handle { get; }

	// Methods

	// RVA: 0x716DFFC
	internal object get_Handle() { }

	// RVA: 0x716F0E0
	internal object .ctor(object handle) { }

	// RVA: 0x7173F30
	private static extern object mono_btls_x509_up_ref(object handle) { }

	// RVA: 0x7173FC4
	private static extern object mono_btls_x509_from_data(object data, object len, object format) { }

	// RVA: 0x7174074
	private static extern object mono_btls_x509_get_subject_name(object handle) { }

	// RVA: 0x7174108
	private static extern object mono_btls_x509_get_raw_data(object handle, object bio, object format) { }

	// RVA: 0x71741B8
	private static extern object mono_btls_x509_cmp(object a, object b) { }

	// RVA: 0x7174260
	private static extern object mono_btls_x509_free(object handle) { }

	// RVA: 0x71742F0
	private static extern object mono_btls_x509_add_explicit_trust(object handle, object kind) { }

	// RVA: 0x7174398
	internal object Copy() { }

	// RVA: 0x7174564
	public static object LoadFromData(object buffer, object format) { }

	// RVA: 0x717483C
	public object GetSubjectName() { }

	// RVA: 0x7174A50
	public object GetSubjectNameHash() { }

	// RVA: 0x7174CDC
	public object GetRawData(object format) { }

	// RVA: 0x7174FD4
	public static object Compare(object a, object b) { }

	// RVA: 0x717516C
	public object AddExplicitTrust(object kind) { }

}

// Namespace: 
internal class BoringX509ChainHandle
{

	// Methods

	// RVA: 0x7175884
	public object .ctor(object handle) { }

	// RVA: 0x7175F18
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsX509Chain
{

	// Properties
	internal object Handle { get; }
	public object Count { get; }

	// Methods

	// RVA: 0x7175398
	internal object get_Handle() { }

	// RVA: 0x7175420
	private static extern object mono_btls_x509_chain_new() { }

	// RVA: 0x71754A4
	private static extern object mono_btls_x509_chain_get_count(object handle) { }

	// RVA: 0x7175538
	private static extern object mono_btls_x509_chain_get_cert(object Handle, object index) { }

	// RVA: 0x71755E0
	private static extern object mono_btls_x509_chain_add_cert(object chain, object x509) { }

	// RVA: 0x7175688
	private static extern object mono_btls_x509_chain_up_ref(object handle) { }

	// RVA: 0x717571C
	private static extern object mono_btls_x509_chain_free(object handle) { }

	// RVA: 0x71757B0
	public object .ctor() { }

	// RVA: 0x7175890
	internal object .ctor(object handle) { }

	// RVA: 0x7175898
	public object get_Count() { }

	// RVA: 0x71759AC
	public object GetCertificate(object index) { }

	// RVA: 0x7175BB8
	public object AddCertificate(object x509) { }

	// RVA: 0x7175D4C
	internal object Copy() { }

}

// Namespace: Mono.Btls
internal enum MonoBtlsX509Error
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OK;
	public const object UNABLE_TO_GET_ISSUER_CERT;
	public const object UNABLE_TO_GET_CRL;
	public const object UNABLE_TO_DECRYPT_CERT_SIGNATURE;
	public const object UNABLE_TO_DECRYPT_CRL_SIGNATURE;
	public const object UNABLE_TO_DECODE_ISSUER_PUBLIC_KEY;
	public const object CERT_SIGNATURE_FAILURE;
	public const object CRL_SIGNATURE_FAILURE;
	public const object CERT_NOT_YET_VALID;
	public const object CERT_HAS_EXPIRED;
	public const object CRL_NOT_YET_VALID;
	public const object CRL_HAS_EXPIRED;
	public const object ERROR_IN_CERT_NOT_BEFORE_FIELD;
	public const object ERROR_IN_CERT_NOT_AFTER_FIELD;
	public const object ERROR_IN_CRL_LAST_UPDATE_FIELD;
	public const object ERROR_IN_CRL_NEXT_UPDATE_FIELD;
	public const object OUT_OF_MEM;
	public const object DEPTH_ZERO_SELF_SIGNED_CERT;
	public const object SELF_SIGNED_CERT_IN_CHAIN;
	public const object UNABLE_TO_GET_ISSUER_CERT_LOCALLY;
	public const object UNABLE_TO_VERIFY_LEAF_SIGNATURE;
	public const object CERT_CHAIN_TOO_LONG;
	public const object CERT_REVOKED;
	public const object INVALID_CA;
	public const object PATH_LENGTH_EXCEEDED;
	public const object INVALID_PURPOSE;
	public const object CERT_UNTRUSTED;
	public const object CERT_REJECTED;
	public const object SUBJECT_ISSUER_MISMATCH;
	public const object AKID_SKID_MISMATCH;
	public const object AKID_ISSUER_SERIAL_MISMATCH;
	public const object KEYUSAGE_NO_CERTSIGN;
	public const object UNABLE_TO_GET_CRL_ISSUER;
	public const object UNHANDLED_CRITICAL_EXTENSION;
	public const object KEYUSAGE_NO_CRL_SIGN;
	public const object UNHANDLED_CRITICAL_CRL_EXTENSION;
	public const object INVALID_NON_CA;
	public const object PROXY_PATH_LENGTH_EXCEEDED;
	public const object KEYUSAGE_NO_DIGITAL_SIGNATURE;
	public const object PROXY_CERTIFICATES_NOT_ALLOWED;
	public const object INVALID_EXTENSION;
	public const object INVALID_POLICY_EXTENSION;
	public const object NO_EXPLICIT_POLICY;
	public const object DIFFERENT_CRL_SCOPE;
	public const object UNSUPPORTED_EXTENSION_FEATURE;
	public const object UNNESTED_RESOURCE;
	public const object PERMITTED_VIOLATION;
	public const object EXCLUDED_VIOLATION;
	public const object SUBTREE_MINMAX;
	public const object UNSUPPORTED_CONSTRAINT_TYPE;
	public const object UNSUPPORTED_CONSTRAINT_SYNTAX;
	public const object UNSUPPORTED_NAME_SYNTAX;
	public const object CRL_PATH_VALIDATION_ERROR;
	public const object SUITE_B_INVALID_VERSION;
	public const object SUITE_B_INVALID_ALGORITHM;
	public const object SUITE_B_INVALID_CURVE;
	public const object SUITE_B_INVALID_SIGNATURE_ALGORITHM;
	public const object SUITE_B_LOS_NOT_ALLOWED;
	public const object SUITE_B_CANNOT_SIGN_P_384_WITH_P_256;
	public const object HOSTNAME_MISMATCH;
	public const object EMAIL_MISMATCH;
	public const object IP_ADDRESS_MISMATCH;
	public const object APPLICATION_VERIFICATION;
}

// Namespace: Mono.Btls
internal enum MonoBtlsX509FileType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PEM;
	public const object ASN1;
	public const object DEFAULT;
}

// Namespace: Mono.Btls
internal enum MonoBtlsX509Format
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DER;
	public const object PEM;
}

// Namespace: 
internal class BoringX509LookupHandle
{

	// Methods

	// RVA: 0x7176580
	public object .ctor(object handle) { }

	// RVA: 0x71771FC
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsX509Lookup
{

	// Fields
	private object store; // 0x18
	private object type; // 0x20
	private object monoLookups; // 0x28

	// Properties
	internal object Handle { get; }

	// Methods

	// RVA: 0x7175F9C
	internal object get_Handle() { }

	// RVA: 0x7176024
	private static extern object mono_btls_x509_lookup_new(object store, object type) { }

	// RVA: 0x71760CC
	private static extern object mono_btls_x509_lookup_add_dir(object handle, object dir, object type) { }

	// RVA: 0x717617C
	private static extern object mono_btls_x509_lookup_add_mono(object handle, object monoLookup) { }

	// RVA: 0x7176224
	private static extern object mono_btls_x509_lookup_free(object handle) { }

	// RVA: 0x71762B8
	private static extern object mono_btls_x509_lookup_peek_lookup(object handle) { }

	// RVA: 0x717634C
	private static object Create_internal(object store, object type) { }

	// RVA: 0x717658C
	internal object .ctor(object store, object type) { }

	// RVA: 0x71765DC
	internal object GetNativeLookup() { }

	// RVA: 0x71766F0
	public object AddDirectory(object dir, object type) { }

	// RVA: 0x7176950
	internal object AddMono(object monoLookup) { }

	// RVA: 0x7176D90
	internal object AddCertificate(object certificate) { }

	// RVA: 0x7176FA0
	protected override object Close() { }

}

// Namespace: 
internal class BoringX509LookupMonoHandle
{

	// Methods

	// RVA: 0x7177B1C
	public object .ctor(object handle) { }

	// RVA: 0x7177D44
	protected override object ReleaseHandle() { }

}

// Namespace: 
private sealed class BySubjectFunc
{

	// Methods

	// RVA: 0x7177B28
	public object .ctor(object object, object method) { }

	// RVA: 0x7177E78
	public virtual object Invoke(object instance, object name, object x509_ptr) { }

}

// Namespace: Mono.Btls
internal abstract class MonoBtlsX509LookupMono
{

	// Fields
	private object gch; // 0x18
	private object instance; // 0x20
	private object bySubjectFunc; // 0x28
	private object bySubjectFuncPtr; // 0x30
	private object lookup; // 0x38

	// Properties
	internal object Handle { get; }

	// Methods

	// RVA: 0x7176CB8
	internal object get_Handle() { }

	// RVA: 0x717768C
	private static extern object mono_btls_x509_lookup_mono_new() { }

	// RVA: 0x7177710
	private static extern object mono_btls_x509_lookup_mono_init(object handle, object instance, object by_subject_func) { }

	// RVA: 0x71777C0
	private static extern object mono_btls_x509_lookup_mono_free(object handle) { }

	// RVA: 0x7177854
	internal object .ctor() { }

	// RVA: 0x7176D40
	internal object Install(object lookup) { }

	// RVA: 0x7177BC0
	protected object AddCertificate(object certificate) { }

	// RVA: -1
	protected abstract object OnGetBySubject(object name) { }

	// RVA: 0x71772FC
	private static object OnGetBySubject(object instance, object name_ptr, object x509_ptr) { }

	// RVA: 0x7177C34
	protected override object Close() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsX509LookupMonoCollection
{

	// Fields
	private object hashes; // 0x40
	private object certificates; // 0x48
	private object collection; // 0x50
	private object trust; // 0x58

	// Methods

	// RVA: 0x7177E8C
	internal object .ctor(object collection, object trust) { }

	// RVA: 0x7177EC4
	private object Initialize() { }

	// RVA: 0x7178124
	protected override object OnGetBySubject(object name) { }

	// RVA: 0x71781F8
	protected override object Close() { }

}

// Namespace: Mono.Btls
internal enum MonoBtlsX509LookupType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UNKNOWN;
	public const object FILE;
	public const object HASH_DIR;
	public const object MONO;
}

// Namespace: 
internal class BoringX509NameHandle
{

	// Fields
	private object dontFree; // 0x16

	// Methods

	// RVA: 0x7174A18
	internal object .ctor(object handle, object ownsHandle) { }

	// RVA: 0x717892C
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsX509Name
{

	// Properties
	internal object Handle { get; }

	// Methods

	// RVA: 0x7178338
	private static extern object mono_btls_x509_name_hash(object handle) { }

	// RVA: 0x71783CC
	private static extern object mono_btls_x509_name_get_entry_count(object handle) { }

	// RVA: 0x7178460
	private static extern object mono_btls_x509_name_get_entry_type(object name, object index) { }

	// RVA: 0x7178508
	private static extern object mono_btls_x509_name_get_entry_oid(object name, object index, object buffer, object size) { }

	// RVA: 0x71785B0
	private static extern object mono_btls_x509_name_get_entry_oid_data(object name, object index, object data) { }

	// RVA: 0x7178660
	private static extern object mono_btls_x509_name_get_entry_value(object name, object index, object tag, object str) { }

	// RVA: 0x7178708
	private static extern object mono_btls_x509_name_from_data(object data, object len, object use_canon_enc) { }

	// RVA: 0x71787B8
	private static extern object mono_btls_x509_name_free(object handle) { }

	// RVA: 0x717884C
	internal object get_Handle() { }

	// RVA: 0x7174A48
	internal object .ctor(object handle) { }

	// RVA: 0x7174BC8
	public object GetHash() { }

	// RVA: 0x7173D84
	public object GetEntryCount() { }

	// RVA: 0x71734E0
	public object GetEntryType(object index) { }

	// RVA: 0x7173AD8
	public object GetEntryOid(object index) { }

	// RVA: 0x717362C
	public object GetEntryOidData(object index) { }

	// RVA: 0x7173824
	public object GetEntryValue(object index, object tag) { }

	// RVA: 0x71716F4
	public static object CreateFromData(object data, object use_canon_enc) { }

}

// Namespace: Mono.Btls
internal enum MonoBtlsX509NameEntryType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object CountryName;
	public const object OrganizationName;
	public const object OrganizationalUnitName;
	public const object CommonName;
	public const object LocalityName;
	public const object StateOrProvinceName;
	public const object StreetAddress;
	public const object SerialNumber;
	public const object DomainComponent;
	public const object UserId;
	public const object Email;
	public const object DnQualifier;
	public const object Title;
	public const object Surname;
	public const object GivenName;
	public const object Initial;
}

// Namespace: 
internal class BoringX509StoreHandle
{

	// Methods

	// RVA: 0x7178D30
	public object .ctor(object handle) { }

	// RVA: 0x7179378
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsX509Store
{

	// Fields
	private object lookupHash; // 0x18

	// Properties
	internal object Handle { get; }

	// Methods

	// RVA: 0x71764F8
	internal object get_Handle() { }

	// RVA: 0x71789B8
	private static extern object mono_btls_x509_store_new() { }

	// RVA: 0x7178A3C
	private static extern object mono_btls_x509_store_from_ssl_ctx(object handle) { }

	// RVA: 0x7178AD0
	private static extern object mono_btls_x509_store_add_cert(object handle, object x509) { }

	// RVA: 0x7178B78
	private static extern object mono_btls_x509_store_free(object handle) { }

	// RVA: 0x7178C0C
	private static object Create_internal() { }

	// RVA: 0x7178D3C
	private static object Create_internal(object ctx) { }

	// RVA: 0x7178E60
	internal object .ctor() { }

	// RVA: 0x7171204
	internal object .ctor(object ctx) { }

	// RVA: 0x7176DB0
	public object AddCertificate(object x509) { }

	// RVA: 0x7178E8C
	public object AddLookup(object type) { }

	// RVA: 0x7179020
	public object AddDirectoryLookup(object dir, object type) { }

	// RVA: 0x7179060
	public object AddCollection(object collection, object trust) { }

	// RVA: 0x7179124
	protected override object Close() { }

}

// Namespace: 
internal class BoringX509StoreCtxHandle
{

	// Fields
	private object dontFree; // 0x16

	// Methods

	// RVA: 0x7179B58
	internal object .ctor(object handle, object ownsHandle) { }

	// RVA: 0x717A9F4
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsX509StoreCtx
{

	// Fields
	private object verifyResult; // 0x18

	// Properties
	internal object Handle { get; }
	public object VerifyResult { get; }

	// Methods

	// RVA: 0x71793FC
	internal object get_Handle() { }

	// RVA: 0x7179484
	private static extern object mono_btls_x509_store_ctx_new() { }

	// RVA: 0x7179508
	private static extern object mono_btls_x509_store_ctx_from_ptr(object ctx) { }

	// RVA: 0x717959C
	private static extern object mono_btls_x509_store_ctx_get_error(object handle, object error_string) { }

	// RVA: 0x7179644
	private static extern object mono_btls_x509_store_ctx_get_chain(object handle) { }

	// RVA: 0x71796D8
	private static extern object mono_btls_x509_store_ctx_init(object handle, object store, object chain) { }

	// RVA: 0x7179788
	private static extern object mono_btls_x509_store_ctx_set_param(object handle, object param) { }

	// RVA: 0x7179830
	private static extern object mono_btls_x509_store_ctx_verify_cert(object handle) { }

	// RVA: 0x71798C4
	private static extern object mono_btls_x509_store_ctx_get_untrusted(object handle) { }

	// RVA: 0x7179958
	private static extern object mono_btls_x509_store_ctx_up_ref(object handle) { }

	// RVA: 0x71799EC
	private static extern object mono_btls_x509_store_ctx_free(object handle) { }

	// RVA: 0x7179A80
	internal object .ctor() { }

	// RVA: 0x7179B88
	private static object Create_internal(object store_ctx) { }

	// RVA: 0x7171264
	internal object .ctor(object preverify_ok, object store_ctx) { }

	// RVA: 0x7179C9C
	internal object .ctor(object ptr, object verifyResult) { }

	// RVA: 0x7179CC8
	public object GetError() { }

	// RVA: 0x7179DE8
	public object GetChain() { }

	// RVA: 0x7179FBC
	public object GetUntrusted() { }

	// RVA: 0x717A190
	public object Initialize(object store, object chain) { }

	// RVA: 0x717A408
	public object SetVerifyParam(object param) { }

	// RVA: 0x717A5F8
	public object get_VerifyResult() { }

	// RVA: 0x717A690
	public object Verify() { }

	// RVA: 0x717A81C
	public object Copy() { }

}

// Namespace: Mono.Btls
internal static class MonoBtlsX509StoreManager
{

	// Fields
	private static object initialized; // 0x0
	private static object machineTrustedRootPath; // 0x8
	private static object machineIntermediateCAPath; // 0x10
	private static object machineUntrustedPath; // 0x18
	private static object userTrustedRootPath; // 0x20
	private static object userIntermediateCAPath; // 0x28
	private static object userUntrustedPath; // 0x30

	// Methods

	// RVA: 0x717AA80
	private static object Initialize() { }

	// RVA: 0x717AC38
	private static object DoInitialize() { }

	// RVA: 0x717ADA4
	public static object GetStorePath(object type) { }

}

// Namespace: Mono.Btls
internal enum MonoBtlsX509StoreType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Custom;
	public const object MachineTrustedRoots;
	public const object MachineIntermediateCA;
	public const object MachineUntrusted;
	public const object UserTrustedRoots;
	public const object UserIntermediateCA;
	public const object UserUntrusted;
}

// Namespace: Mono.Btls
internal enum MonoBtlsX509TrustKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DEFAULT;
	public const object TRUST_CLIENT;
	public const object TRUST_SERVER;
	public const object TRUST_ALL;
	public const object REJECT_CLIENT;
	public const object REJECT_SERVER;
	public const object REJECT_ALL;
}

// Namespace: 
internal class BoringX509VerifyParamHandle
{

	// Methods

	// RVA: 0x717B3BC
	public object .ctor(object handle) { }

	// RVA: 0x717BDC0
	protected override object ReleaseHandle() { }

}

// Namespace: Mono.Btls
internal class MonoBtlsX509VerifyParam
{

	// Properties
	internal object Handle { get; }
	public object CanModify { get; }

	// Methods

	// RVA: 0x71723F4
	internal object get_Handle() { }

	// RVA: 0x717AE40
	private static extern object mono_btls_x509_verify_param_copy(object handle) { }

	// RVA: 0x717AED4
	private static extern object mono_btls_x509_verify_param_lookup(object name) { }

	// RVA: 0x717AF68
	private static extern object mono_btls_x509_verify_param_can_modify(object param) { }

	// RVA: 0x717AFFC
	private static extern object mono_btls_x509_verify_param_set_host(object handle, object name, object namelen) { }

	// RVA: 0x717B0AC
	private static extern object mono_btls_x509_verify_param_set_time(object handle, object time) { }

	// RVA: 0x717B154
	private static extern object mono_btls_x509_verify_param_free(object handle) { }

	// RVA: 0x717B1E8
	internal object .ctor(object handle) { }

	// RVA: 0x717B1F0
	public object Copy() { }

	// RVA: 0x717B3C8
	public static object GetSslClient() { }

	// RVA: 0x717B6F4
	public static object GetSslServer() { }

	// RVA: 0x717B410
	public static object Lookup(object name, object fail) { }

	// RVA: 0x717B73C
	public object get_CanModify() { }

	// RVA: 0x717B844
	private object WantToModify() { }

	// RVA: 0x717B8AC
	public object SetHost(object name) { }

	// RVA: 0x717BB70
	public object SetTime(object time) { }

}

// Namespace: Mono.Btls
internal class X509CertificateImplBtls
{

	// Fields
	private object x509; // 0xA8
	private object nativePrivateKey; // 0xB0
	private object intermediateCerts; // 0xB8

	// Properties
	public override object IsValid { get; }
	internal object X509 { get; }
	internal object NativePrivateKey { get; }
	internal override object IntermediateCertificates { get; }
	public override object HasPrivateKey { get; }
	public override object PrivateKey { get; set; }

	// Methods

	// RVA: 0x717BE44
	internal object .ctor(object x509) { }

	// RVA: 0x717BE88
	private object .ctor(object other) { }

	// RVA: 0x717BF08
	internal object .ctor(object data, object format) { }

	// RVA: 0x717BF4C
	internal object .ctor(object data, object password, object keyStorageFlags) { }

	// RVA: 0x717CADC
	public override object get_IsValid() { }

	// RVA: 0x717CAF0
	internal object get_X509() { }

	// RVA: 0x717CB18
	internal object get_NativePrivateKey() { }

	// RVA: 0x717CB40
	public override object Clone() { }

	// RVA: 0x717CBB0
	protected override object GetRawCertData() { }

	// RVA: 0x717CBF8
	internal override object get_IntermediateCertificates() { }

	// RVA: 0x717CC00
	protected override object Dispose(object disposing) { }

	// RVA: 0x717CC30
	public override object get_HasPrivateKey() { }

	// RVA: 0x717CC40
	public override object get_PrivateKey() { }

	// RVA: 0x717CC6C
	public override object set_PrivateKey(object value) { }

	// RVA: 0x717CD90
	public override object GetRSAPrivateKey() { }

	// RVA: 0x717CDBC
	public override object GetDSAPrivateKey() { }

	// RVA: 0x717C330
	private object Import(object data) { }

	// RVA: 0x717C388
	private object ImportPkcs12(object data, object password) { }

	// RVA: 0x717C9F4
	private object ImportAuthenticode(object data) { }

	// RVA: 0x717CEBC
	public override object Verify(object thisCertificate) { }

}

// Namespace: Mono.Btls
internal class X509ChainImplBtls
{

	// Fields
	private object storeCtx; // 0x8
	private object chain; // 0x10
	private object untrustedChain; // 0x18
	private object elements; // 0x20
	private object untrusted; // 0x28
	private object certificates; // 0x30
	private object policy; // 0x38
	private object chainStatusList; // 0x40

	// Properties
	public override object IsValid { get; }
	internal object StoreCtx { get; }
	public override object ChainElements { get; }
	public override object ChainPolicy { get; }

	// Methods

	// RVA: 0x717D190
	internal object .ctor(object chain) { }

	// RVA: 0x717D220
	internal object .ctor(object storeCtx) { }

	// RVA: 0x717D528
	public override object get_IsValid() { }

	// RVA: 0x717D53C
	internal object get_StoreCtx() { }

	// RVA: 0x717D564
	public override object get_ChainElements() { }

	// RVA: 0x717D8B4
	public override object get_ChainPolicy() { }

	// RVA: 0x717D8BC
	public override object AddStatus(object errorCode) { }

	// RVA: 0x717DA6C
	public override object Build(object certificate) { }

	// RVA: 0x717DA74
	public override object Reset() { }

	// RVA: 0x717DAF8
	protected override object Dispose(object disposing) { }

}

// Namespace: Mono.Btls
internal class X509PalImplBtls
{

	// Fields
	private readonly object <Provider>k__BackingField; // 0x8

	// Properties
	private object Provider { get; }

	// Methods

	// RVA: 0x717DC28
	public object .ctor(object provider) { }

	// RVA: 0x717DD38
	private object get_Provider() { }

	// RVA: 0x717DD40
	public override object Import(object data) { }

	// RVA: 0x717DD6C
	public override object Import(object data, object password, object keyStorageFlags) { }

	// RVA: 0x717DD90
	public override object Import(object cert) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x718050C
	private static object .cctor() { }

	// RVA: 0x718056C
	public object .ctor() { }

	// RVA: 0x7180574
	internal object <.cctor>b__10_0(object kvp) { }

	// RVA: 0x71805B4
	internal object <.cctor>b__10_1(object kvp) { }

}

// Namespace: Internal.Cryptography
internal static class OidLookup
{

	// Fields
	private static readonly object s_lateBoundOidToFriendlyName; // 0x0
	private static readonly object s_lateBoundFriendlyNameToOid; // 0x8
	private static readonly object s_friendlyNameToOid; // 0x10
	private static readonly object s_oidToFriendlyName; // 0x18
	private static readonly object s_compatOids; // 0x20

	// Methods

	// RVA: 0x717DDB4
	public static object ToFriendlyName(object oid, object oidGroup, object fallBackToAllGroups) { }

	// RVA: 0x717E2F0
	public static object ToOid(object friendlyName, object oidGroup, object fallBackToAllGroups) { }

	// RVA: 0x717DFC8
	private static object ShouldUseCache(object oidGroup) { }

	// RVA: 0x717DFD0
	private static object NativeOidToFriendlyName(object oid, object oidGroup, object fallBackToAllGroups) { }

	// RVA: 0x717E4FC
	private static object NativeFriendlyNameToOid(object friendlyName, object oidGroup, object fallBackToAllGroups) { }

	// RVA: 0x717E824
	private static object .cctor() { }

}

// Namespace: Internal.Cryptography.Pal
internal enum GeneralNameType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OtherName;
	public const object Rfc822Name;
	public const object Email;
	public const object DnsName;
	public const object X400Address;
	public const object DirectoryName;
	public const object EdiPartyName;
	public const object UniformResourceIdentifier;
	public const object IPAddress;
	public const object RegisteredId;
}

// Namespace: 
internal struct AlgorithmIdentifier
{

	// Fields
	internal object AlgorithmId; // 0xFFFFFFFFFFFFFFF8
	internal object Parameters; // 0x0
}

// Namespace: 
private sealed class <ReadReverseRdns>d__21
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x20
	private object name; // 0x28
	public object <>3__name; // 0x30
	private object <rdnReaders>5__2; // 0x38
	private object <rdnReader>5__3; // 0x40

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<System.String,System.String>>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x7181E44
	public object .ctor(object <>1__state) { }

	// RVA: 0x7181F70
	private object System.IDisposable.Dispose() { }

	// RVA: 0x7181F74
	private object MoveNext() { }

	// RVA: 0x7182274
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<System.String,System.String>>.get_Current() { }

	// RVA: 0x7182280
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x71822C0
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x7182328
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<System.String,System.String>>.GetEnumerator() { }

	// RVA: 0x71823DC
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: Internal.Cryptography.Pal
internal struct CertificateData
{

	// Fields
	internal object RawData; // 0xFFFFFFFFFFFFFFF8
	internal object SubjectPublicKeyInfo; // 0x0
	internal object Version; // 0x8
	internal object SerialNumber; // 0x10
	internal object TbsSignature; // 0x18
	internal object Issuer; // 0x28
	internal object NotBefore; // 0x30
	internal object NotAfter; // 0x38
	internal object Subject; // 0x40
	internal object PublicKeyAlgorithm; // 0x48
	internal object PublicKey; // 0x58
	internal object IssuerUniqueId; // 0x60
	internal object SubjectUniqueId; // 0x68
	internal object Extensions; // 0x70
	internal object SignatureAlgorithm; // 0x78
	internal object SignatureValue; // 0x88

	// Methods

	// RVA: 0x7180630
	internal object .ctor(object rawData) { }

	// RVA: 0x7180F2C
	public object GetNameInfo(object nameType, object forIssuer) { }

	// RVA: 0x7181674
	private static object GetSimpleNameInfo(object name) { }

	// RVA: 0x7181B34
	private static object FindAltNameMatch(object extensionBytes, object matchType, object otherOid) { }

	// RVA: 0x7181DC0
	private static object ReadReverseRdns(object name) { }

}

// Namespace: Microsoft.Win32
internal static class NativeMethods
{

	// Methods

	// RVA: 0x7182490
	public static object DuplicateHandle(object hSourceProcessHandle, object hSourceHandle, object hTargetProcess, object targetHandle, object dwDesiredAccess, object bInheritHandle, object dwOptions) { }

	// RVA: 0x71826D0
	public static object DuplicateHandle(object hSourceProcessHandle, object hSourceHandle, object hTargetProcess, object targetHandle, object dwDesiredAccess, object bInheritHandle, object dwOptions) { }

	// RVA: 0x7182844
	public static object GetCurrentProcess() { }

	// RVA: 0x7182848
	public static object GetExitCodeProcess(object processHandle, object exitCode) { }

	// RVA: 0x718284C
	public static object GetExitCodeProcess(object processHandle, object exitCode) { }

	// RVA: 0x718296C
	public static object GetCurrentProcessId() { }

	// RVA: 0x7182970
	public static object CloseProcess(object handle) { }

}

// Namespace: Microsoft.Win32.SafeHandles
public sealed class SafeProcessHandle
{

	// Fields
	internal static object InvalidHandle; // 0x0

	// Methods

	// RVA: 0x7182974
	internal object .ctor(object handle) { }

	// RVA: 0x7182814
	public object .ctor(object existingHandle, object ownsHandle) { }

	// RVA: 0x71829A4
	protected override object ReleaseHandle() { }

	// RVA: 0x71829AC
	private static object .cctor() { }

}

// Namespace: System
internal static class IPv4AddressHelper
{

	// Methods

	// RVA: 0x7182A14
	internal static object ParseHostNumber(object str, object start, object end) { }

	// RVA: 0x7182C1C
	internal static object IsValid(object name, object start, object end, object allowIPv6, object notImplicitFile, object unknownScheme) { }

	// RVA: 0x7182A48
	private static object ParseCanonical(object name, object numbers, object start, object end) { }

	// RVA: 0x7182C48
	internal static object IsValidCanonical(object name, object start, object end, object allowIPv6, object notImplicitFile) { }

	// RVA: 0x7182F54
	internal static object ParseNonCanonical(object name, object start, object end, object notImplicitFile) { }

	// RVA: 0x7183338
	internal static object ParseCanonicalName(object str, object start, object end, object isLoopback) { }

	// RVA: 0x71836E0
	private static object Parse(object name, object numbers, object start, object end) { }

}

// Namespace: System
internal static class IPv6AddressHelper
{

	// Methods

	// RVA: 0x7183750
	internal static object FindCompressionRange(object numbers) { }

	// RVA: 0x718383C
	internal static object ShouldHaveIpv4Embedded(object numbers) { }

	// RVA: 0x7183920
	internal static object IsValidStrict(object name, object start, object end) { }

	// RVA: 0x7183DAC
	internal static object Parse(object address, object numbers, object start, object scopeId) { }

	// RVA: 0x718431C
	internal static object ParseCanonicalName(object str, object start, object isLoopback, object scopeId) { }

	// RVA: 0x7184A24
	private static object IsLoopback(object numbers) { }

	// RVA: 0x7184B10
	private static object InternalIsValid(object name, object start, object end, object validateStrictAddress) { }

	// RVA: 0x7184EF8
	internal static object IsValid(object name, object start, object end) { }

}

// Namespace: System
internal static class NotImplemented
{

	// Methods

	// RVA: 0x7184F00
	internal static object ByDesignWithMessage(object message) { }

}

// Namespace: System
public class UriBuilder
{

	// Fields
	private object _changed; // 0x8
	private object _fragment; // 0x10
	private object _host; // 0x18
	private object _password; // 0x20
	private object _path; // 0x28
	private object _port; // 0x30
	private object _query; // 0x38
	private object _scheme; // 0x40
	private object _schemeDelimiter; // 0x48
	private object _uri; // 0x50
	private object _username; // 0x58

	// Properties
	public object Path { set; }
	public object Query { get; set; }
	public object Uri { get; }

	// Methods

	// RVA: 0x7184F68
	public object .ctor(object uri) { }

	// RVA: 0x71852A0
	public object .ctor(object uri) { }

	// RVA: 0x7185114
	private object Init(object uri) { }

	// RVA: 0x7185598
	public object set_Path(object value) { }

	// RVA: 0x7185660
	public object get_Query() { }

	// RVA: 0x7185668
	public object set_Query(object value) { }

	// RVA: 0x7185730
	public object get_Uri() { }

	// RVA: 0x7185800
	public override object Equals(object rparam) { }

	// RVA: 0x7185894
	public override object GetHashCode() { }

	// RVA: 0x7185414
	private object SetFieldsFromUri(object uri) { }

	// RVA: 0x71858E8
	public override object ToString() { }

}

// Namespace: System
internal static class SecurityUtils
{

	// Methods

	// RVA: 0x7185F4C
	private static object DemandReflectionAccess(object type) { }

	// RVA: 0x7185F50
	private static object DemandGrantSet(object assembly) { }

	// RVA: 0x7185F54
	private static object HasReflectionPermission(object type) { }

	// RVA: 0x7185F5C
	internal static object SecureCreateInstance(object type) { }

	// RVA: 0x7185F68
	internal static object SecureCreateInstance(object type, object args, object allowNonPublic) { }

	// RVA: 0x7186090
	internal static object SecureCreateInstance(object type, object args) { }

	// RVA: 0x7186098
	internal static object SecureConstructorInvoke(object type, object argTypes, object args, object allowNonPublic) { }

	// RVA: 0x71860A0
	internal static object SecureConstructorInvoke(object type, object argTypes, object args, object allowNonPublic, object extraFlags) { }

	// RVA: 0x7186268
	private static object GenericArgumentsAreVisible(object method) { }

	// RVA: 0x718635C
	internal static object MethodInfoInvoke(object method, object target, object args) { }

}

// Namespace: System
internal class InvariantComparer
{

	// Fields
	private object m_compareInfo; // 0x8
	internal static readonly object Default; // 0x0

	// Methods

	// RVA: 0x71864F0
	internal object .ctor() { }

	// RVA: 0x71865C4
	public object Compare(object a, object b) { }

	// RVA: 0x71866F4
	private static object .cctor() { }

}

// Namespace: System
internal static class IriHelper
{

	// Methods

	// RVA: 0x7186750
	internal static object CheckIriUnicodeRange(object unicode, object isQuery) { }

	// RVA: 0x71867A8
	internal static object CheckIriUnicodeRange(object highSurr, object lowSurr, object surrogatePair, object isQuery) { }

	// RVA: 0x7186E2C
	internal static object CheckIsReserved(object ch, object component) { }

	// RVA: 0x7186FA8
	internal static object EscapeUnescapeIri(object pInput, object start, object end, object component) { }

}

// Namespace: 
private enum Flags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Zero;
	public const object SchemeNotCanonical;
	public const object UserNotCanonical;
	public const object HostNotCanonical;
	public const object PortNotCanonical;
	public const object PathNotCanonical;
	public const object QueryNotCanonical;
	public const object FragmentNotCanonical;
	public const object CannotDisplayCanonical;
	public const object E_UserNotCanonical;
	public const object E_HostNotCanonical;
	public const object E_PortNotCanonical;
	public const object E_PathNotCanonical;
	public const object E_QueryNotCanonical;
	public const object E_FragmentNotCanonical;
	public const object E_CannotDisplayCanonical;
	public const object ShouldBeCompressed;
	public const object FirstSlashAbsent;
	public const object BackslashInPath;
	public const object IndexMask;
	public const object HostTypeMask;
	public const object HostNotParsed;
	public const object IPv6HostType;
	public const object IPv4HostType;
	public const object DnsHostType;
	public const object UncHostType;
	public const object BasicHostType;
	public const object UnusedHostType;
	public const object UnknownHostType;
	public const object UserEscaped;
	public const object AuthorityFound;
	public const object HasUserInfo;
	public const object LoopbackHost;
	public const object NotDefaultPort;
	public const object UserDrivenParsing;
	public const object CanonicalDnsHost;
	public const object ErrorOrParsingRecursion;
	public const object DosPath;
	public const object UncPath;
	public const object ImplicitFile;
	public const object MinimalUriInfoSet;
	public const object AllUriInfoSet;
	public const object IdnHost;
	public const object HasUnicode;
	public const object HostUnicodeNormalized;
	public const object RestUnicodeNormalized;
	public const object UnicodeHost;
	public const object IntranetUri;
	public const object UseOrigUncdStrOffset;
	public const object UserIriCanonical;
	public const object PathIriCanonical;
	public const object QueryIriCanonical;
	public const object FragmentIriCanonical;
	public const object IriCanonical;
	public const object CompressedSlashes;
}

// Namespace: 
private class UriInfo
{

	// Fields
	public object Host; // 0x8
	public object ScopeId; // 0x10
	public object String; // 0x18
	public object Offset; // 0x20
	public object DnsSafeHost; // 0x30
	public object MoreInfo; // 0x38

	// Methods

	// RVA: 0x718862C
	public object .ctor() { }

}

// Namespace: 
private struct Offset
{

	// Fields
	public object Scheme; // 0xFFFFFFFFFFFFFFF8
	public object User; // 0xFFFFFFFFFFFFFFFA
	public object Host; // 0xFFFFFFFFFFFFFFFC
	public object PortValue; // 0xFFFFFFFFFFFFFFFE
	public object Path; // 0x0
	public object Query; // 0x2
	public object Fragment; // 0x4
	public object End; // 0x6
}

// Namespace: 
private class MoreInfo
{

	// Fields
	public object Path; // 0x8
	public object Query; // 0x10
	public object Fragment; // 0x18
	public object AbsoluteUri; // 0x20
	public object Hash; // 0x28
	public object RemoteUrl; // 0x30

	// Methods

	// RVA: 0x7188634
	public object .ctor() { }

}

// Namespace: 
private enum Check
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object EscapedCanonical;
	public const object DisplayCanonical;
	public const object DotSlashAttn;
	public const object DotSlashEscaped;
	public const object BackslashInPath;
	public const object ReservedFound;
	public const object NotIriCanonical;
	public const object FoundNonAscii;
}

// Namespace: System
public class Uri
{

	// Fields
	public static readonly object UriSchemeFile; // 0x0
	public static readonly object UriSchemeFtp; // 0x8
	public static readonly object UriSchemeGopher; // 0x10
	public static readonly object UriSchemeHttp; // 0x18
	public static readonly object UriSchemeHttps; // 0x20
	internal static readonly object UriSchemeWs; // 0x28
	internal static readonly object UriSchemeWss; // 0x30
	public static readonly object UriSchemeMailto; // 0x38
	public static readonly object UriSchemeNews; // 0x40
	public static readonly object UriSchemeNntp; // 0x48
	public static readonly object UriSchemeNetTcp; // 0x50
	public static readonly object UriSchemeNetPipe; // 0x58
	public static readonly object SchemeDelimiter; // 0x60
	private const object c_Max16BitUtf8SequenceLength;
	internal const object c_MaxUriBufferSize;
	private const object c_MaxUriSchemeName;
	private object m_String; // 0x8
	private object m_originalUnicodeString; // 0x10
	private object m_Syntax; // 0x18
	private object m_DnsSafeHost; // 0x20
	private object m_Flags; // 0x28
	private object m_Info; // 0x30
	private object m_iriParsing; // 0x38
	private static object s_ConfigInitialized; // 0x68
	private static object s_ConfigInitializing; // 0x69
	private static object s_IdnScope; // 0x6C
	private static object s_IriParsing; // 0x70
	private static object useDotNetRelativeOrAbsolute; // 0x71
	private const object DotNetRelativeOrAbsolute;
	internal static readonly object IsWindowsFileSystem; // 0x72
	private static object s_initLock; // 0x78
	private const object V1ToStringUnescape;
	internal const object c_DummyChar;
	internal const object c_EOL;
	internal static readonly object HexLowerChars; // 0x80
	private static readonly object _WSchars; // 0x88

	// Properties
	private object IsImplicitFile { get; }
	private object IsUncOrDosPath { get; }
	private object IsDosPath { get; }
	private object IsUncPath { get; }
	private object HostType { get; }
	private object Syntax { get; }
	private object IsNotAbsoluteUri { get; }
	private object AllowIdn { get; }
	internal object UserDrivenParsing { get; }
	private object SecuredPathIndex { get; }
	public object AbsolutePath { get; }
	private object PrivateAbsolutePath { get; }
	public object AbsoluteUri { get; }
	public object LocalPath { get; }
	public object Authority { get; }
	public object HostNameType { get; }
	public object IsDefaultPort { get; }
	public object IsFile { get; }
	public object IsLoopback { get; }
	public object PathAndQuery { get; }
	public object Segments { get; }
	public object IsUnc { get; }
	public object Host { get; }
	private static object InitializeLock { get; }
	public object Port { get; }
	public object Query { get; }
	public object Fragment { get; }
	public object Scheme { get; }
	private object OriginalStringSwitched { get; }
	public object OriginalString { get; }
	public object DnsSafeHost { get; }
	public object IsAbsoluteUri { get; }
	public object UserEscaped { get; }
	public object UserInfo { get; }
	internal object HasAuthority { get; }

	// Methods

	// RVA: 0x710BA0C
	private object get_IsImplicitFile() { }

	// RVA: 0x710BA18
	private object get_IsUncOrDosPath() { }

	// RVA: 0x710BA28
	private object get_IsDosPath() { }

	// RVA: 0x710BA34
	private object get_IsUncPath() { }

	// RVA: 0x710BA40
	private object get_HostType() { }

	// RVA: 0x710BA4C
	private object get_Syntax() { }

	// RVA: 0x710BA54
	private object get_IsNotAbsoluteUri() { }

	// RVA: 0x710BA64
	internal static object IriParsingStatic(object syntax) { }

	// RVA: 0x710BB3C
	private object get_AllowIdn() { }

	// RVA: 0x710BC58
	private object AllowIdnStatic(object syntax, object flags) { }

	// RVA: 0x710BD7C
	private object IsIntranet(object schemeHost) { }

	// RVA: 0x710BD84
	internal object get_UserDrivenParsing() { }

	// RVA: 0x710BD90
	private object SetUserDrivenParsing() { }

	// RVA: 0x710BDA4
	private object get_SecuredPathIndex() { }

	// RVA: 0x710BC48
	private object NotAny(object flags) { }

	// RVA: 0x710BE18
	private object InFact(object flags) { }

	// RVA: 0x710BD70
	private static object StaticNotAny(object allFlags, object checkFlags) { }

	// RVA: 0x710BE28
	private static object StaticInFact(object allFlags, object checkFlags) { }

	// RVA: 0x710BE34
	private object EnsureUriInfo() { }

	// RVA: 0x710C534
	private object EnsureParseRemaining() { }

	// RVA: 0x710D4F8
	private object EnsureHostString(object allowDnsOptimization) { }

	// RVA: 0x710D9F8
	public object .ctor(object uriString) { }

	// RVA: 0x710DC48
	public object .ctor(object uriString, object uriKind) { }

	// RVA: 0x710DCD8
	public object .ctor(object baseUri, object relativeUri) { }

	// RVA: 0x710DDC8
	private object CreateUri(object baseUri, object relativeUri, object dontEscape) { }

	// RVA: 0x710E7A0
	public object .ctor(object baseUri, object relativeUri) { }

	// RVA: 0x710E9E0
	private static object GetCombinedString(object baseUri, object relativeStr, object dontEscape, object result) { }

	// RVA: 0x710F9D0
	private static object GetException(object err) { }

	// RVA: 0x710FBA0
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x710FCD4
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x710FCD8
	protected object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x710FE54
	public object get_AbsolutePath() { }

	// RVA: 0x710FF18
	private object get_PrivateAbsolutePath() { }

	// RVA: 0x711000C
	public object get_AbsoluteUri() { }

	// RVA: 0x7110144
	public object get_LocalPath() { }

	// RVA: 0x7110B18
	public object get_Authority() { }

	// RVA: 0x7110B88
	public object get_HostNameType() { }

	// RVA: 0x7110CE0
	public object get_IsDefaultPort() { }

	// RVA: 0x7110DC4
	public object get_IsFile() { }

	// RVA: 0x7110E88
	public object get_IsLoopback() { }

	// RVA: 0x7110F4C
	public object get_PathAndQuery() { }

	// RVA: 0x7111018
	public object get_Segments() { }

	// RVA: 0x71112BC
	public object get_IsUnc() { }

	// RVA: 0x711132C
	public object get_Host() { }

	// RVA: 0x711139C
	private static object StaticIsFile(object syntax) { }

	// RVA: 0x71113C0
	private static object get_InitializeLock() { }

	// RVA: 0x71114C4
	private static object InitializeUriConfig() { }

	// RVA: 0x71101AC
	private object GetLocalPath() { }

	// RVA: 0x7111D58
	public object get_Port() { }

	// RVA: 0x7111E70
	public object get_Query() { }

	// RVA: 0x7111FAC
	public object get_Fragment() { }

	// RVA: 0x71120E8
	public object get_Scheme() { }

	// RVA: 0x7112154
	private object get_OriginalStringSwitched() { }

	// RVA: 0x710EDC8
	public object get_OriginalString() { }

	// RVA: 0x71121B4
	public object get_DnsSafeHost() { }

	// RVA: 0x710DDB8
	public object get_IsAbsoluteUri() { }

	// RVA: 0x71124A0
	public object get_UserEscaped() { }

	// RVA: 0x71124AC
	public object get_UserInfo() { }

	// RVA: 0x711251C
	internal static object IsGenDelim(object ch) { }

	// RVA: 0x7112540
	public static object IsHexDigit(object character) { }

	// RVA: 0x711256C
	public static object FromHex(object digit) { }

	// RVA: 0x7112600
	public override object GetHashCode() { }

	// RVA: 0x71128E0
	public override object ToString() { }

	// RVA: 0x7112CB4
	public static object op_Equality(object uri1, object uri2) { }

	// RVA: 0x710E5B8
	public static object op_Inequality(object uri1, object uri2) { }

	// RVA: 0x7112D20
	public override object Equals(object comparand) { }

	// RVA: 0x711358C
	private static object CheckForColonInFirstPathSegment(object uriString) { }

	// RVA: 0x7113658
	internal static object InternalEscapeString(object rawString) { }

	// RVA: 0x7113748
	private static object ParseScheme(object uriString, object flags, object syntax) { }

	// RVA: 0x7113DF4
	internal object ParseMinimal() { }

	// RVA: 0x7113E88
	private object PrivateParseMinimal() { }

	// RVA: 0x71155C4
	private object PrivateParseMinimalIri(object newHost, object idx) { }

	// RVA: 0x710BE64
	private object CreateUriInfo(object cF) { }

	// RVA: 0x710D560
	private object CreateHostString() { }

	// RVA: 0x7115BA4
	private static object CreateHostStringHelper(object str, object idx, object end, object flags, object scopeId) { }

	// RVA: 0x71156C0
	private object GetHostViaCustomSyntax() { }

	// RVA: 0x710FE50
	internal object GetParts(object uriParts, object formatAs) { }

	// RVA: 0x71163F0
	private object GetEscapedParts(object uriParts) { }

	// RVA: 0x7111C48
	private object GetUnescapedParts(object uriParts, object formatAs) { }

	// RVA: 0x7116F08
	private object ReCreateParts(object parts, object nonCanonical, object formatAs) { }

	// RVA: 0x7116504
	private object GetUriPartsFromUserString(object uriParts) { }

	// RVA: 0x710C544
	private object ParseRemaining() { }

	// RVA: 0x7113860
	private static object ParseSchemeCheckImplicitFile(object uriString, object length, object err, object flags, object syntax) { }

	// RVA: 0x7118990
	private static object CheckKnownSchemes(object lptr, object nChars, object syntax) { }

	// RVA: 0x710EC70
	private static object CheckSchemeSyntax(object ptr, object length, object syntax) { }

	// RVA: 0x7114614
	private object CheckAuthorityHelper(object pString, object idx, object length, object err, object flags, object syntax, object newHost) { }

	// RVA: 0x7118E10
	private object CheckAuthorityHelperHandleDnsIri(object pString, object start, object end, object startInput, object iriParsing, object hasUnicode, object syntax, object userInfoString, object flags, object justNormalized, object newHost, object err) { }

	// RVA: 0x71191F8
	private object CheckAuthorityHelperHandleAnyHostIri(object pString, object startInput, object end, object iriParsing, object hasUnicode, object syntax, object flags, object newHost, object err) { }

	// RVA: 0x7118828
	private object FindEndOfComponent(object input, object idx, object end, object delim) { }

	// RVA: 0x71196DC
	private object FindEndOfComponent(object str, object idx, object end, object delim) { }

	// RVA: 0x7115E00
	private object CheckCanonical(object str, object idx, object end, object delim) { }

	// RVA: 0x7117EC8
	private object GetCanonicalPath(object dest, object pos, object formatAs) { }

	// RVA: 0x7119788
	private static object UnescapeOnly(object pch, object start, object end, object ch1, object ch2, object ch3) { }

	// RVA: 0x71116A4
	private static object Compress(object dest, object start, object destLength, object syntax) { }

	// RVA: 0x71127E4
	internal static object CalculateCaseInsensitiveHashCode(object text) { }

	// RVA: 0x710EE30
	private static object CombineUri(object basePart, object relativePart, object uriFormat) { }

	// RVA: 0x7119980
	internal object get_HasAuthority() { }

	// RVA: 0x71145E4
	private static object IsLWS(object ch) { }

	// RVA: 0x7114600
	private static object IsAsciiLetter(object character) { }

	// RVA: 0x711998C
	internal static object IsAsciiLetterOrDigit(object character) { }

	// RVA: 0x7119A00
	internal static object IsBidiControlCharacter(object ch) { }

	// RVA: 0x71194E0
	internal static object StripBidiControlCharacter(object strToClean, object start, object length) { }

	// RVA: 0x710DA7C
	private object CreateThis(object uri, object dontEscape, object uriKind) { }

	// RVA: 0x7119A24
	private object InitializeUri(object err, object uriKind, object e) { }

	// RVA: 0x711A0D4
	private object CheckForConfigLoad(object data) { }

	// RVA: 0x711A1CC
	private object CheckForUnicode(object data) { }

	// RVA: 0x711A31C
	private object CheckForEscapedUnreserved(object data) { }

	// RVA: 0x71134A0
	public static object TryCreate(object uriString, object uriKind, object result) { }

	// RVA: 0x711A7CC
	public static object TryCreate(object baseUri, object relativeUri, object result) { }

	// RVA: 0x711A940
	public static object TryCreate(object baseUri, object relativeUri, object result) { }

	// RVA: 0x711620C
	public object GetComponents(object components, object format) { }

	// RVA: 0x711ADB4
	public object IsWellFormedOriginalString() { }

	// RVA: 0x711B388
	public static object IsWellFormedUriString(object uriString, object uriKind) { }

	// RVA: 0x711AE10
	internal object InternalIsWellFormedOriginalString() { }

	// RVA: 0x711B510
	public static object UnescapeDataString(object stringToUnescape) { }

	// RVA: 0x7118938
	internal object EscapeUnescapeIri(object input, object start, object end, object component) { }

	// RVA: 0x711B6D4
	private object .ctor(object flags, object uriParser, object uri) { }

	// RVA: 0x711A538
	internal static object CreateHelper(object uriString, object dontEscape, object uriKind, object e) { }

	// RVA: 0x710DF80
	internal static object ResolveHelper(object baseUri, object relativeUri, object newUriString, object userEscaped, object e) { }

	// RVA: 0x711AB1C
	private object GetRelativeSerializationString(object format) { }

	// RVA: 0x7112A10
	internal object GetComponentsHelper(object uriComponents, object uriFormat) { }

	// RVA: 0x711B718
	public object IsBaseOf(object uri) { }

	// RVA: 0x711B7D8
	internal object IsBaseOfHelper(object uriLink) { }

	// RVA: 0x710E624
	private object CreateThisFromUri(object otherUri) { }

	// RVA: 0x711BA1C
	private static object .cctor() { }

}

// Namespace: System
public class UriFormatException
{

	// Methods

	// RVA: 0x718863C
	public object .ctor() { }

	// RVA: 0x7185D4C
	public object .ctor(object textString) { }

	// RVA: 0x7188644
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x718864C
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

}

// Namespace: System
public enum UriKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RelativeOrAbsolute;
	public const object Absolute;
	public const object Relative;
}

// Namespace: System
public enum UriComponents
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Scheme;
	public const object UserInfo;
	public const object Host;
	public const object Port;
	public const object Path;
	public const object Query;
	public const object Fragment;
	public const object StrongPort;
	public const object NormalizedHost;
	public const object KeepDelimiter;
	public const object SerializationInfoString;
	public const object AbsoluteUri;
	public const object HostAndPort;
	public const object StrongAuthority;
	public const object SchemeAndServer;
	public const object HttpRequestUrl;
	public const object PathAndQuery;
}

// Namespace: System
public enum UriFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UriEscaped;
	public const object Unescaped;
	public const object SafeUnescaped;
}

// Namespace: System
public enum UriIdnScope
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object AllExceptIntranet;
	public const object All;
}

// Namespace: System
internal enum ParsingError
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object BadFormat;
	public const object BadScheme;
	public const object BadAuthority;
	public const object EmptyUriString;
	public const object LastRelativeUriOkErrIndex;
	public const object SchemeLimit;
	public const object SizeLimit;
	public const object MustRootedPath;
	public const object BadHostName;
	public const object NonEmptyHost;
	public const object BadPort;
	public const object BadAuthorityTerminator;
	public const object CannotCreateRelative;
}

// Namespace: System
internal enum UnescapeMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CopyOnly;
	public const object Escape;
	public const object Unescape;
	public const object EscapeUnescape;
	public const object V1ToStringFlag;
	public const object UnescapeAll;
	public const object UnescapeAllOrThrow;
}

// Namespace: System
internal static class UriHelper
{

	// Fields
	private static readonly object HexUpperChars; // 0x0

	// Methods

	// RVA: 0x7188654
	internal static object TestForSubPath(object pMe, object meLength, object pShe, object sheLength, object ignoreCase) { }

	// RVA: 0x71888B8
	internal static object EscapeString(object input, object start, object end, object dest, object destPos, object isUriString, object force1, object force2, object rsvd) { }

	// RVA: 0x718904C
	private static object EnsureDestinationSize(object pStr, object dest, object currentInputPos, object charsToAdd, object minReallocateChars, object destPos, object prevInputPos) { }

	// RVA: 0x7189550
	internal static object UnescapeString(object input, object start, object end, object dest, object destPosition, object rsvd1, object rsvd2, object rsvd3, object unescapeMode, object syntax, object isQuery) { }

	// RVA: 0x7189628
	internal static object UnescapeString(object pStr, object start, object end, object dest, object destPosition, object rsvd1, object rsvd2, object rsvd3, object unescapeMode, object syntax, object isQuery) { }

	// RVA: 0x7187BE4
	internal static object MatchUTF8Sequence(object pDest, object dest, object destOffset, object unescapedChars, object charCount, object bytes, object byteCount, object isQuery, object iriParsing) { }

	// RVA: 0x7188514
	internal static object EscapeAsciiChar(object ch, object to, object pos) { }

	// RVA: 0x7187B0C
	internal static object EscapedAscii(object digit, object next) { }

	// RVA: 0x7187B74
	internal static object IsNotSafeForUnescape(object ch) { }

	// RVA: 0x71893A0
	private static object IsReservedUnreservedOrHash(object c) { }

	// RVA: 0x7189210
	internal static object IsUnreserved(object c) { }

	// RVA: 0x718A1F0
	internal static object Is3986Unreserved(object c) { }

	// RVA: 0x718A2C8
	private static object .cctor() { }

}

// Namespace: System
public enum UriHostNameType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Basic;
	public const object Dns;
	public const object IPv4;
	public const object IPv6;
}

// Namespace: 
private enum UriQuirksVersion
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object V2;
	public const object V3;
}

// Namespace: 
private class BuiltInUriParser
{

	// Methods

	// RVA: 0x718B8B8
	internal object .ctor(object lwrCaseScheme, object defaultPort, object syntaxFlags) { }

}

// Namespace: System
public abstract class UriParser
{

	// Fields
	private const object SchemeOnlyFlags;
	private static readonly object m_Table; // 0x0
	private static object m_TempTable; // 0x8
	private object m_Flags; // 0x8
	private object m_UpdatableFlags; // 0xC
	private object m_UpdatableFlagsUsed; // 0x10
	private const object c_UpdatableFlags;
	private object m_Port; // 0x14
	private object m_Scheme; // 0x18
	internal const object NoDefaultPort;
	private const object c_InitialTableSize;
	internal static object HttpUri; // 0x10
	internal static object HttpsUri; // 0x18
	internal static object WsUri; // 0x20
	internal static object WssUri; // 0x28
	internal static object FtpUri; // 0x30
	internal static object FileUri; // 0x38
	internal static object GopherUri; // 0x40
	internal static object NntpUri; // 0x48
	internal static object NewsUri; // 0x50
	internal static object MailToUri; // 0x58
	internal static object UuidUri; // 0x60
	internal static object TelnetUri; // 0x68
	internal static object LdapUri; // 0x70
	internal static object NetTcpUri; // 0x78
	internal static object NetPipeUri; // 0x80
	internal static object VsMacrosUri; // 0x88
	private static readonly object s_QuirksVersion; // 0x90
	private const object c_MaxCapacity;
	private const object UnknownV1SyntaxFlags;
	private static readonly object HttpSyntaxFlags; // 0x94
	private const object FtpSyntaxFlags;
	private static readonly object FileSyntaxFlags; // 0x98
	private const object VsmacrosSyntaxFlags;
	private const object GopherSyntaxFlags;
	private const object NewsSyntaxFlags;
	private const object NntpSyntaxFlags;
	private const object TelnetSyntaxFlags;
	private const object LdapSyntaxFlags;
	private const object MailtoSyntaxFlags;
	private const object NetPipeSyntaxFlags;
	private const object NetTcpSyntaxFlags;

	// Properties
	internal object SchemeName { get; }
	internal object DefaultPort { get; }
	internal static object ShouldUseLegacyV2Quirks { get; }
	internal object Flags { get; }
	internal object IsSimple { get; }

	// Methods

	// RVA: 0x718A360
	internal object get_SchemeName() { }

	// RVA: 0x718A368
	internal object get_DefaultPort() { }

	// RVA: 0x718A370
	protected virtual object OnNewUri() { }

	// RVA: 0x718A374
	protected virtual object InitializeAndValidate(object uri, object parsingError) { }

	// RVA: 0x718A3B0
	protected virtual object Resolve(object baseUri, object relativeUri, object parsingError) { }

	// RVA: 0x718A5D0
	protected virtual object IsBaseOf(object baseUri, object relativeUri) { }

	// RVA: 0x718A5F8
	protected virtual object GetComponents(object uri, object components, object format) { }

	// RVA: 0x718A82C
	protected virtual object IsWellFormedOriginalString(object uri) { }

	// RVA: 0x718A18C
	internal static object get_ShouldUseLegacyV2Quirks() { }

	// RVA: 0x718A850
	private static object .cctor() { }

	// RVA: 0x718B204
	internal object get_Flags() { }

	// RVA: 0x7185EE0
	internal object NotAny(object flags) { }

	// RVA: 0x7185E74
	internal object InFact(object flags) { }

	// RVA: 0x718B26C
	internal object IsAllSet(object flags) { }

	// RVA: 0x718B20C
	private object IsFullMatch(object flags, object expected) { }

	// RVA: 0x718B2D8
	internal object .ctor(object flags) { }

	// RVA: 0x718B348
	internal static object FindOrFetchAsUnknownV1Syntax(object lwrCaseScheme) { }

	// RVA: 0x7185D54
	internal static object GetSyntax(object lwrCaseScheme) { }

	// RVA: 0x718B684
	internal object get_IsSimple() { }

	// RVA: 0x718B690
	internal object InternalOnNewUri() { }

	// RVA: 0x718B700
	internal object InternalValidate(object thisUri, object parsingError) { }

	// RVA: 0x718B758
	internal object InternalResolve(object thisBaseUri, object uriLink, object parsingError) { }

	// RVA: 0x718B7B8
	internal object InternalIsBaseOf(object thisBaseUri, object uriLink) { }

	// RVA: 0x718B810
	internal object InternalGetComponents(object thisUri, object uriComponents, object uriFormat) { }

	// RVA: 0x718B870
	internal object InternalIsWellFormedOriginalString(object thisUri) { }

}

// Namespace: System
internal class DomainNameHelper
{

	// Methods

	// RVA: 0x718B940
	internal static object ParseCanonicalName(object str, object start, object end, object loopback) { }

	// RVA: 0x718BAFC
	internal static object IsValid(object name, object pos, object returnedEnd, object notCanonical, object notImplicitFile) { }

	// RVA: 0x718BD24
	internal static object IsValidByIri(object name, object pos, object returnedEnd, object notCanonical, object notImplicitFile) { }

	// RVA: 0x718BF1C
	internal static object IdnEquivalent(object hostname, object start, object end, object allAscii, object atLeastOneValidIdn) { }

	// RVA: 0x718C260
	internal static object IdnEquivalent(object hostname, object start, object end, object allAscii, object bidiStrippedHost) { }

	// RVA: 0x718C4C8
	private static object IsIdnAce(object input, object index) { }

	// RVA: 0x718C47C
	private static object IsIdnAce(object input, object index) { }

	// RVA: 0x718C564
	internal static object UnicodeEquivalent(object idnHost, object hostname, object start, object end) { }

	// RVA: 0x718C6A8
	internal static object UnicodeEquivalent(object hostname, object start, object end, object allAscii, object atLeastOneValidIdn) { }

	// RVA: 0x718BC9C
	private static object IsASCIILetterOrDigit(object character, object notCanonical) { }

	// RVA: 0x718BCD8
	private static object IsValidDomainLabelCharacter(object character, object notCanonical) { }

}

// Namespace: System
internal class UncNameHelper
{

	// Methods

	// RVA: 0x718CC44
	internal static object ParseCanonicalName(object str, object start, object end, object loopback) { }

	// RVA: 0x718CC48
	internal static object IsValid(object name, object start, object returnedEnd, object notImplicitFile) { }

}

// Namespace: System
internal enum UriSyntaxFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object MustHaveAuthority;
	public const object OptionalAuthority;
	public const object MayHaveUserInfo;
	public const object MayHavePort;
	public const object MayHavePath;
	public const object MayHaveQuery;
	public const object MayHaveFragment;
	public const object AllowEmptyHost;
	public const object AllowUncHost;
	public const object AllowDnsHost;
	public const object AllowIPv4Host;
	public const object AllowIPv6Host;
	public const object AllowAnInternetHost;
	public const object AllowAnyOtherHost;
	public const object FileLikeUri;
	public const object MailToLikeUri;
	public const object V1_UnknownUri;
	public const object SimpleUserSyntax;
	public const object BuiltInSyntax;
	public const object ParserSchemeOnly;
	public const object AllowDOSPath;
	public const object PathIsRooted;
	public const object ConvertPathSlashes;
	public const object CompressPath;
	public const object CanonicalizeAsFilePath;
	public const object UnEscapeDotsAndSlashes;
	public const object AllowIdn;
	public const object AllowIriParsing;
}

// Namespace: System
internal static class LocalAppContextSwitches
{

	// Fields
	public static readonly object MemberDescriptorEqualsReturnsFalseIfEquivalent; // 0x0
}

// Namespace: System
internal enum IOOperation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Read;
	public const object Write;
}

// Namespace: System
internal sealed class IOAsyncCallback
{

	// Methods

	// RVA: 0x718D388
	public object .ctor(object object, object method) { }

	// RVA: 0x718D4A4
	public virtual object Invoke(object ioares) { }

}

// Namespace: System
internal abstract class IOAsyncResult
{

	// Fields
	private object async_callback; // 0x8
	private object async_state; // 0x10
	private object wait_handle; // 0x18
	private object completed_synchronously; // 0x20
	private object completed; // 0x21

	// Properties
	public object AsyncCallback { get; }
	public object AsyncState { get; }
	public object AsyncWaitHandle { get; }
	public object CompletedSynchronously { get; set; }
	public object IsCompleted { get; set; }

	// Methods

	// RVA: 0x718D4F4
	protected object .ctor() { }

	// RVA: 0x718D4FC
	protected object Init(object async_callback, object async_state) { }

	// RVA: 0x718D518
	protected object .ctor(object async_callback, object async_state) { }

	// RVA: 0x718D550
	public object get_AsyncCallback() { }

	// RVA: 0x718D558
	public object get_AsyncState() { }

	// RVA: 0x718D560
	public object get_AsyncWaitHandle() { }

	// RVA: 0x718D6A4
	public object get_CompletedSynchronously() { }

	// RVA: 0x718D6AC
	protected object set_CompletedSynchronously(object value) { }

	// RVA: 0x718D6B4
	public object get_IsCompleted() { }

	// RVA: 0x718D6BC
	protected object set_IsCompleted(object value) { }

	// RVA: -1
	internal abstract object CompleteDisposed() { }

}

// Namespace: System
internal class IOSelectorJob
{

	// Fields
	private object operation; // 0x8
	private object callback; // 0x10
	private object state; // 0x18

	// Methods

	// RVA: 0x718D7DC
	public object .ctor(object operation, object callback, object state) { }

	// RVA: 0x718D81C
	private object System.Threading.IThreadPoolWorkItem.ExecuteWorkItem() { }

	// RVA: 0x718D84C
	private object System.Threading.IThreadPoolWorkItem.MarkAborted(object tae) { }

	// RVA: 0x718D850
	public object MarkDisposed() { }

}

// Namespace: System
internal static class IOSelector
{

	// Methods

	// RVA: 0x718D89C
	public static object Add(object handle, object job) { }

}

// Namespace: System
internal static class Platform
{

	// Fields
	private static object checkedOS; // 0x0
	private static object isMacOS; // 0x1
	private static object isAix; // 0x2
	private static object isIBMi; // 0x3
	private static object isFreeBSD; // 0x4
	private static object isOpenBSD; // 0x5

	// Properties
	public static object IsMacOS { get; }
	public static object IsFreeBSD { get; }
	public static object IsOpenBSD { get; }
	public static object IsIBMi { get; }
	public static object IsAix { get; }

	// Methods

	// RVA: 0x718D8A0
	private static extern object uname(object buf) { }

	// RVA: 0x718D934
	private static object CheckOS() { }

	// RVA: 0x718DB98
	public static object get_IsMacOS() { }

	// RVA: 0x718DC94
	public static object get_IsFreeBSD() { }

	// RVA: 0x718DD14
	public static object get_IsOpenBSD() { }

	// RVA: 0x718DD94
	public static object get_IsIBMi() { }

	// RVA: 0x718DE14
	public static object get_IsAix() { }

}

// Namespace: System
public class UriTypeConverter
{

	// Methods

	// RVA: 0x718DE94
	public object .ctor() { }

	// RVA: 0x718DE9C
	private object CanConvert(object type) { }

	// RVA: 0x718DF84
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x718E060
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x718E108
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x718E2D8
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

}

// Namespace: System.Text.RegularExpressions
public class Capture
{

	// Fields
	private object <Index>k__BackingField; // 0x8
	private object <Length>k__BackingField; // 0xC
	private object <Text>k__BackingField; // 0x10

	// Properties
	public object Index { get; set; }
	public object Length { get; set; }
	internal object Text { get; set; }
	public object Value { get; }

	// Methods

	// RVA: 0x718E504
	internal object .ctor(object text, object index, object length) { }

	// RVA: 0x718E544
	public object get_Index() { }

	// RVA: 0x718E54C
	internal object set_Index(object value) { }

	// RVA: 0x718E554
	public object get_Length() { }

	// RVA: 0x718E55C
	internal object set_Length(object value) { }

	// RVA: 0x718E564
	internal object get_Text() { }

	// RVA: 0x718E56C
	internal object set_Text(object value) { }

	// RVA: 0x718E574
	public object get_Value() { }

	// RVA: 0x718E5A0
	public override object ToString() { }

	// RVA: 0x718E5CC
	internal object GetLeftSubstring() { }

	// RVA: 0x718E66C
	internal object GetRightSubstring() { }

}

// Namespace: 
private sealed class Enumerator
{

	// Fields
	private readonly object _collection; // 0x8
	private object _index; // 0x10

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x718E8B8
	internal object .ctor(object collection) { }

	// RVA: 0x718F524
	public object MoveNext() { }

	// RVA: 0x718F56C
	public object get_Current() { }

	// RVA: 0x718F5F4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x718F5F8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x718F604
	private object System.IDisposable.Dispose() { }

}

// Namespace: System.Text.RegularExpressions
public class CaptureCollection
{

	// Fields
	private readonly object _group; // 0x8
	private readonly object _capcount; // 0x10
	private object _captures; // 0x18

	// Properties
	public object IsReadOnly { get; }
	public object Count { get; }
	public object Item { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Capture>.Item { get; set; }
	private object System.Collections.IList.IsFixedSize { get; }
	private object System.Collections.IList.Item { get; set; }

	// Methods

	// RVA: 0x718E718
	internal object .ctor(object group) { }

	// RVA: 0x718E75C
	public object get_IsReadOnly() { }

	// RVA: 0x718E764
	public object get_Count() { }

	// RVA: 0x718E76C
	public object get_Item(object i) { }

	// RVA: 0x718E848
	public object GetEnumerator() { }

	// RVA: 0x718E8EC
	private object System.Collections.Generic.IEnumerable<System.Text.RegularExpressions.Capture>.GetEnumerator() { }

	// RVA: 0x718E770
	private object GetCapture(object i) { }

	// RVA: 0x718E95C
	internal object ForceInitialized() { }

	// RVA: 0x718EADC
	public object get_IsSynchronized() { }

	// RVA: 0x718EAE4
	public object get_SyncRoot() { }

	// RVA: 0x718EAEC
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x718EBA8
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x718ED40
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Capture>.IndexOf(object item) { }

	// RVA: 0x718EE1C
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Capture>.Insert(object index, object item) { }

	// RVA: 0x718EE70
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Capture>.RemoveAt(object index) { }

	// RVA: 0x718EEC4
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Capture>.get_Item(object index) { }

	// RVA: 0x718EEC8
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Capture>.set_Item(object index, object value) { }

	// RVA: 0x718EF1C
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Capture>.Add(object item) { }

	// RVA: 0x718EF70
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Capture>.Clear() { }

	// RVA: 0x718EFC4
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Capture>.Contains(object item) { }

	// RVA: 0x718F094
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Capture>.Remove(object item) { }

	// RVA: 0x718F0E8
	private object System.Collections.IList.Add(object value) { }

	// RVA: 0x718F13C
	private object System.Collections.IList.Clear() { }

	// RVA: 0x718F190
	private object System.Collections.IList.Contains(object value) { }

	// RVA: 0x718F2AC
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: 0x718F3C8
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: 0x718F41C
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: 0x718F424
	private object System.Collections.IList.Remove(object value) { }

	// RVA: 0x718F478
	private object System.Collections.IList.RemoveAt(object index) { }

	// RVA: 0x718F4CC
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: 0x718F4D0
	private object System.Collections.IList.set_Item(object index, object value) { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class CollectionDebuggerProxy<T0>
{
}

// Namespace: System.Text.RegularExpressions
public class Group
{

	// Fields
	internal static readonly object s_emptyGroup; // 0x0
	internal readonly object _caps; // 0x18
	internal object _capcount; // 0x20
	internal object _capcoll; // 0x28
	private readonly object <Name>k__BackingField; // 0x30

	// Properties
	public object Success { get; }
	public object Captures { get; }

	// Methods

	// RVA: 0x718F608
	internal object .ctor(object text, object caps, object capcount, object name) { }

	// RVA: 0x718F6B8
	public object get_Success() { }

	// RVA: 0x718F6C8
	public object get_Captures() { }

	// RVA: 0x718F750
	private static object .cctor() { }

	// RVA: 0x718F8C0
	internal object .ctor() { }

}

// Namespace: 
private sealed class Enumerator
{

	// Fields
	private readonly object _collection; // 0x8
	private object _index; // 0x10

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x718FD5C
	internal object .ctor(object collection) { }

	// RVA: 0x7190D20
	public object MoveNext() { }

	// RVA: 0x7190D8C
	public object get_Current() { }

	// RVA: 0x7190E3C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x7190E40
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x7190E4C
	private object System.IDisposable.Dispose() { }

}

// Namespace: System.Text.RegularExpressions
public class GroupCollection
{

	// Fields
	private readonly object _match; // 0x8
	private readonly object _captureMap; // 0x10
	private object _groups; // 0x18

	// Properties
	public object IsReadOnly { get; }
	public object Count { get; }
	public object Item { get; }
	public object Item { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Group>.Item { get; set; }
	private object System.Collections.IList.IsFixedSize { get; }
	private object System.Collections.IList.Item { get; set; }

	// Methods

	// RVA: 0x718F8FC
	internal object .ctor(object match, object caps) { }

	// RVA: 0x718F934
	public object get_IsReadOnly() { }

	// RVA: 0x718F93C
	public object get_Count() { }

	// RVA: 0x718F978
	public object get_Item(object groupnum) { }

	// RVA: 0x718FAC0
	public object get_Item(object groupname) { }

	// RVA: 0x718FCEC
	public object GetEnumerator() { }

	// RVA: 0x718FD90
	private object System.Collections.Generic.IEnumerable<System.Text.RegularExpressions.Group>.GetEnumerator() { }

	// RVA: 0x718F97C
	private object GetGroup(object groupnum) { }

	// RVA: 0x718FE00
	private object GetGroupImpl(object groupnum) { }

	// RVA: 0x7190204
	public object get_IsSynchronized() { }

	// RVA: 0x719020C
	public object get_SyncRoot() { }

	// RVA: 0x7190214
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x71902F4
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x71904BC
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Group>.IndexOf(object item) { }

	// RVA: 0x71905DC
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Group>.Insert(object index, object item) { }

	// RVA: 0x7190630
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Group>.RemoveAt(object index) { }

	// RVA: 0x7190684
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Group>.get_Item(object index) { }

	// RVA: 0x7190688
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Group>.set_Item(object index, object value) { }

	// RVA: 0x71906DC
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Group>.Add(object item) { }

	// RVA: 0x7190730
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Group>.Clear() { }

	// RVA: 0x7190784
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Group>.Contains(object item) { }

	// RVA: 0x7190854
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Group>.Remove(object item) { }

	// RVA: 0x71908A8
	private object System.Collections.IList.Add(object value) { }

	// RVA: 0x71908FC
	private object System.Collections.IList.Clear() { }

	// RVA: 0x7190950
	private object System.Collections.IList.Contains(object value) { }

	// RVA: 0x7190A6C
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: 0x7190B88
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: 0x7190BDC
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: 0x7190BE4
	private object System.Collections.IList.Remove(object value) { }

	// RVA: 0x7190C38
	private object System.Collections.IList.RemoveAt(object index) { }

	// RVA: 0x7190C8C
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: 0x7190C90
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: 0x7190CE4
	internal object .ctor() { }

}

// Namespace: System.Text.RegularExpressions
public class Match
{

	// Fields
	internal object _groupcoll; // 0x38
	internal object _regex; // 0x40
	internal object _textbeg; // 0x48
	internal object _textpos; // 0x4C
	internal object _textend; // 0x50
	internal object _textstart; // 0x54
	internal object _matches; // 0x58
	internal object _matchcount; // 0x60
	internal object _balancing; // 0x68
	private static readonly object <Empty>k__BackingField; // 0x0

	// Properties
	public static object Empty { get; }
	public virtual object Groups { get; }

	// Methods

	// RVA: 0x7190E50
	internal object .ctor(object regex, object capcount, object text, object begpos, object len, object startpos) { }

	// RVA: 0x7190FB0
	public static object get_Empty() { }

	// RVA: 0x719102C
	internal virtual object Reset(object regex, object text, object textbeg, object textend, object textstart) { }

	// RVA: 0x7191088
	public virtual object get_Groups() { }

	// RVA: 0x7191108
	public object NextMatch() { }

	// RVA: 0x7191450
	internal virtual object GroupToStringImpl(object groupnum) { }

	// RVA: 0x7191614
	internal object LastGroupToStringImpl() { }

	// RVA: 0x7191670
	internal virtual object AddMatch(object cap, object start, object len) { }

	// RVA: 0x71918A0
	internal virtual object BalanceMatch(object cap) { }

	// RVA: 0x7191A08
	internal virtual object RemoveMatch(object cap) { }

	// RVA: 0x7191A4C
	internal virtual object IsMatched(object cap) { }

	// RVA: 0x7191B04
	internal virtual object MatchIndex(object cap) { }

	// RVA: 0x7191BB8
	internal virtual object MatchLength(object cap) { }

	// RVA: 0x7191C6C
	internal virtual object Tidy(object textpos) { }

	// RVA: 0x7191E14
	private static object .cctor() { }

	// RVA: 0x7191EB0
	internal object .ctor() { }

}

// Namespace: System.Text.RegularExpressions
internal class MatchSparse
{

	// Fields
	internal readonly object _caps; // 0x70

	// Properties
	public override object Groups { get; }

	// Methods

	// RVA: 0x7191EEC
	internal object .ctor(object regex, object caps, object capcount, object text, object begpos, object len, object startpos) { }

	// RVA: 0x7191FA0
	public override object get_Groups() { }

}

// Namespace: 
private sealed class Enumerator
{

	// Fields
	private readonly object _collection; // 0x8
	private object _index; // 0x10

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x71924F0
	internal object .ctor(object collection) { }

	// RVA: 0x7192F64
	public object MoveNext() { }

	// RVA: 0x7192FD8
	public object get_Current() { }

	// RVA: 0x7193054
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x7193058
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x7193064
	private object System.IDisposable.Dispose() { }

}

// Namespace: System.Text.RegularExpressions
public class MatchCollection
{

	// Fields
	private readonly object _regex; // 0x8
	private readonly object _matches; // 0x10
	private object _done; // 0x18
	private readonly object _input; // 0x20
	private readonly object _beginning; // 0x28
	private readonly object _length; // 0x2C
	private object _startat; // 0x30
	private object _prevlen; // 0x34

	// Properties
	public object IsReadOnly { get; }
	public object Count { get; }
	public virtual object Item { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Match>.Item { get; set; }
	private object System.Collections.IList.IsFixedSize { get; }
	private object System.Collections.IList.Item { get; set; }

	// Methods

	// RVA: 0x7192030
	internal object .ctor(object regex, object input, object beginning, object length, object startat) { }

	// RVA: 0x719216C
	public object get_IsReadOnly() { }

	// RVA: 0x7192174
	public object get_Count() { }

	// RVA: 0x7192200
	public virtual object get_Item(object i) { }

	// RVA: 0x7192480
	public object GetEnumerator() { }

	// RVA: 0x7192524
	private object System.Collections.Generic.IEnumerable<System.Text.RegularExpressions.Match>.GetEnumerator() { }

	// RVA: 0x719226C
	private object GetMatch(object i) { }

	// RVA: 0x71921EC
	private object EnsureInitialized() { }

	// RVA: 0x7192594
	public object get_IsSynchronized() { }

	// RVA: 0x719259C
	public object get_SyncRoot() { }

	// RVA: 0x71925A0
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x71926A8
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x7192740
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Match>.IndexOf(object item) { }

	// RVA: 0x71927D0
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Match>.Insert(object index, object item) { }

	// RVA: 0x7192824
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Match>.RemoveAt(object index) { }

	// RVA: 0x7192878
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Match>.get_Item(object index) { }

	// RVA: 0x71928C4
	private object System.Collections.Generic.IList<System.Text.RegularExpressions.Match>.set_Item(object index, object value) { }

	// RVA: 0x7192918
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Match>.Add(object item) { }

	// RVA: 0x719296C
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Match>.Clear() { }

	// RVA: 0x71929C0
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Match>.Contains(object item) { }

	// RVA: 0x7192A50
	private object System.Collections.Generic.ICollection<System.Text.RegularExpressions.Match>.Remove(object item) { }

	// RVA: 0x7192AA4
	private object System.Collections.IList.Add(object value) { }

	// RVA: 0x7192AF8
	private object System.Collections.IList.Clear() { }

	// RVA: 0x7192B4C
	private object System.Collections.IList.Contains(object value) { }

	// RVA: 0x7192C68
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: 0x7192D84
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: 0x7192DD8
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: 0x7192DE0
	private object System.Collections.IList.Remove(object value) { }

	// RVA: 0x7192E34
	private object System.Collections.IList.RemoveAt(object index) { }

	// RVA: 0x7192E88
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: 0x7192ED4
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: 0x7192F28
	internal object .ctor() { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class ExclusiveReference
{

	// Fields
	private object _ref; // 0x8
	private object _obj; // 0x10
	private object _locked; // 0x18

	// Methods

	// RVA: 0x7193068
	public object Get() { }

	// RVA: 0x71930D4
	public object Release(object obj) { }

	// RVA: 0x71931D0
	public object .ctor() { }

}

// Namespace: 
internal struct CachedCodeEntryKey
{

	// Fields
	private readonly object _options; // 0xFFFFFFFFFFFFFFF8
	private readonly object _cultureKey; // 0x0
	private readonly object _pattern; // 0x8

	// Methods

	// RVA: 0x7196E4C
	public object .ctor(object options, object cultureKey, object pattern) { }

	// RVA: 0x71972F4
	public override object Equals(object obj) { }

	// RVA: 0x71973DC
	public object Equals(object other) { }

	// RVA: 0x71936B8
	public static object op_Equality(object left, object right) { }

	// RVA: 0x71974EC
	public override object GetHashCode() { }

}

// Namespace: 
internal sealed class CachedCodeEntry
{

	// Fields
	public object Next; // 0x8
	public object Previous; // 0x10
	public readonly object Key; // 0x18
	public object Code; // 0x30
	public readonly object Caps; // 0x38
	public readonly object Capnames; // 0x40
	public readonly object Capslist; // 0x48
	public readonly object Capsize; // 0x50
	public readonly object Runnerref; // 0x58
	public readonly object ReplRef; // 0x60

	// Methods

	// RVA: 0x7193EA8
	public object .ctor(object key, object capnames, object capslist, object code, object caps, object capsize, object runner, object replref) { }

}

// Namespace: System.Text.RegularExpressions
public class Regex
{

	// Fields
	private const object CacheDictionarySwitchLimit;
	private static object s_cacheSize; // 0x0
	private static readonly object s_cache; // 0x8
	private static object s_cacheCount; // 0x10
	private static object s_cacheFirst; // 0x18
	private static object s_cacheLast; // 0x20
	private static readonly object s_maximumMatchTimeout; // 0x28
	private const object DefaultMatchTimeout_ConfigKeyName;
	internal static readonly object s_defaultMatchTimeout; // 0x30
	public static readonly object InfiniteMatchTimeout; // 0x38
	protected internal object internalMatchTimeout; // 0x8
	internal const object MaxOptionShift;
	protected internal object pattern; // 0x10
	protected internal object roptions; // 0x18
	protected internal object factory; // 0x20
	protected internal object caps; // 0x28
	protected internal object capnames; // 0x30
	protected internal object capslist; // 0x38
	protected internal object capsize; // 0x40
	internal object _runnerref; // 0x48
	internal object _replref; // 0x50
	internal object _code; // 0x58
	internal object _refsInitialized; // 0x60

	// Properties
	public static object CacheSize { get; set; }
	public object Options { get; }
	public object RightToLeft { get; }

	// Methods

	// RVA: 0x71931D8
	public static object get_CacheSize() { }

	// RVA: 0x7193254
	public static object set_CacheSize(object value) { }

	// RVA: 0x7193550
	private object GetCachedCode(object key, object isToAdd) { }

	// RVA: 0x7193740
	private object GetCachedCodeEntryInternal(object key, object isToAdd) { }

	// RVA: 0x7193F2C
	private object FillCacheDictionary() { }

	// RVA: 0x7194054
	private static object TryGetCacheValue(object key, object entry) { }

	// RVA: 0x7194184
	private static object TryGetCacheValueSmall(object key, object entry) { }

	// RVA: 0x7193C1C
	private static object LookupCachedAndPromote(object key) { }

	// RVA: 0x71943FC
	public static object IsMatch(object input, object pattern) { }

	// RVA: 0x7194580
	public static object IsMatch(object input, object pattern, object options) { }

	// RVA: 0x71944E8
	public static object IsMatch(object input, object pattern, object options, object matchTimeout) { }

	// RVA: 0x7194958
	public object IsMatch(object input) { }

	// RVA: 0x71949D4
	public object IsMatch(object input, object startat) { }

	// RVA: 0x7194A5C
	public static object Match(object input, object pattern) { }

	// RVA: 0x7194B48
	public static object Match(object input, object pattern, object options, object matchTimeout) { }

	// RVA: 0x7194BE0
	public object Match(object input) { }

	// RVA: 0x7194C50
	public object Match(object input, object startat) { }

	// RVA: 0x7194CC4
	public static object Matches(object input, object pattern) { }

	// RVA: 0x7194DB0
	public static object Matches(object input, object pattern, object options, object matchTimeout) { }

	// RVA: 0x7194E48
	public object Matches(object input) { }

	// RVA: 0x7194EB8
	public object Matches(object input, object startat) { }

	// RVA: 0x7194F8C
	public static object Replace(object input, object pattern, object replacement) { }

	// RVA: 0x7195080
	public static object Replace(object input, object pattern, object replacement, object options, object matchTimeout) { }

	// RVA: 0x7195128
	public object Replace(object input, object replacement) { }

	// RVA: 0x71951A0
	public object Replace(object input, object replacement, object count, object startat) { }

	// RVA: 0x7195284
	public static object Replace(object input, object pattern, object evaluator) { }

	// RVA: 0x7195378
	public static object Replace(object input, object pattern, object evaluator, object options, object matchTimeout) { }

	// RVA: 0x7195420
	public object Replace(object input, object evaluator) { }

	// RVA: 0x7195498
	public object Replace(object input, object evaluator, object count, object startat) { }

	// RVA: 0x719556C
	private static object Replace(object evaluator, object regex, object input, object count, object startat) { }

	// RVA: 0x7195B48
	public static object Split(object input, object pattern) { }

	// RVA: 0x7195C34
	public static object Split(object input, object pattern, object options, object matchTimeout) { }

	// RVA: 0x7195CCC
	public object Split(object input) { }

	// RVA: 0x7195D44
	public object Split(object input, object count, object startat) { }

	// RVA: 0x7195E10
	private static object Split(object regex, object input, object count, object startat) { }

	// RVA: 0x7196790
	private static object .cctor() { }

	// RVA: 0x7196B4C
	protected internal static object ValidateMatchTimeout(object matchTimeout) { }

	// RVA: 0x71968D0
	private static object InitDefaultMatchTimeout() { }

	// RVA: 0x7196D08
	public object .ctor(object pattern) { }

	// RVA: 0x7196D84
	public object .ctor(object pattern, object options) { }

	// RVA: 0x7196E0C
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object si, object context) { }

	// RVA: 0x7194670
	private object .ctor(object pattern, object options, object matchTimeout, object addToCache) { }

	// RVA: 0x71970C4
	public static object Escape(object str) { }

	// RVA: 0x7197180
	public object get_Options() { }

	// RVA: 0x7195B3C
	public object get_RightToLeft() { }

	// RVA: 0x7197188
	public override object ToString() { }

	// RVA: 0x7190098
	public object GroupNameFromNumber(object i) { }

	// RVA: 0x718FB80
	public object GroupNumberFromName(object name) { }

	// RVA: 0x7196FC0
	protected object InitializeReferences() { }

	// RVA: 0x7191138
	internal object Run(object quick, object prevlen, object input, object beginning, object length, object startat) { }

	// RVA: 0x71949C8
	protected internal object UseOptionR() { }

	// RVA: 0x7197190
	internal object UseOptionInvariant() { }

}

// Namespace: System.Text.RegularExpressions
public sealed class MatchEvaluator
{

	// Methods

	// RVA: 0x7197920
	public object .ctor(object object, object method) { }

	// RVA: 0x7197A3C
	public virtual object Invoke(object match) { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexBoyerMoore
{

	// Fields
	public readonly object Positive; // 0x8
	public readonly object NegativeASCII; // 0x10
	public readonly object NegativeUnicode; // 0x18
	public readonly object Pattern; // 0x20
	public readonly object LowASCII; // 0x28
	public readonly object HighASCII; // 0x2C
	public readonly object RightToLeft; // 0x30
	public readonly object CaseInsensitive; // 0x31
	private readonly object _culture; // 0x38

	// Methods

	// RVA: 0x7197A50
	public object .ctor(object pattern, object caseInsensitive, object rightToLeft, object culture) { }

	// RVA: 0x71980B4
	private object MatchPattern(object text, object index) { }

	// RVA: 0x71982AC
	public object IsMatch(object text, object index, object beglimit, object endlimit) { }

	// RVA: 0x7198330
	public object Scan(object text, object index, object beglimit, object endlimit) { }

}

// Namespace: 
private struct LowerCaseMapping
{

	// Fields
	public readonly object ChMin; // 0xFFFFFFFFFFFFFFF8
	public readonly object ChMax; // 0xFFFFFFFFFFFFFFFA
	public readonly object LcOp; // 0xFFFFFFFFFFFFFFFC
	public readonly object Data; // 0x0

	// Methods

	// RVA: 0x719FD2C
	internal object .ctor(object chMin, object chMax, object lcOp, object data) { }

}

// Namespace: 
private sealed class SingleRangeComparer
{

	// Fields
	public static readonly object Instance; // 0x0

	// Methods

	// RVA: 0x719FD88
	private object .ctor() { }

	// RVA: 0x719FD90
	public object Compare(object x, object y) { }

	// RVA: 0x719FE08
	private static object .cctor() { }

}

// Namespace: 
private struct SingleRange
{

	// Fields
	public readonly object First; // 0xFFFFFFFFFFFFFFF8
	public readonly object Last; // 0xFFFFFFFFFFFFFFFA

	// Methods

	// RVA: 0x719916C
	internal object .ctor(object first, object last) { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexCharClass
{

	// Fields
	private static readonly object s_internalRegexIgnoreCase; // 0x0
	private static readonly object s_space; // 0x8
	private static readonly object s_notSpace; // 0x10
	private static readonly object s_word; // 0x18
	private static readonly object s_notWord; // 0x20
	public static readonly object SpaceClass; // 0x28
	public static readonly object NotSpaceClass; // 0x30
	public static readonly object WordClass; // 0x38
	public static readonly object NotWordClass; // 0x40
	public static readonly object DigitClass; // 0x48
	public static readonly object NotDigitClass; // 0x50
	private static readonly object s_definedCategories; // 0x58
	private static readonly object s_propTable; // 0x60
	private static readonly object s_lcTable; // 0x68
	private object _rangelist; // 0x8
	private object _categories; // 0x10
	private object _canonical; // 0x18
	private object _negate; // 0x19
	private object _subtractor; // 0x20

	// Properties
	public object CanMerge { get; }
	public object Negate { set; }

	// Methods

	// RVA: 0x7198718
	public object .ctor() { }

	// RVA: 0x71987DC
	private object .ctor(object negate, object ranges, object categories, object subtraction) { }

	// RVA: 0x7198834
	public object get_CanMerge() { }

	// RVA: 0x7198854
	public object set_Negate(object value) { }

	// RVA: 0x719885C
	public object AddChar(object c) { }

	// RVA: 0x71989F4
	public object AddCharClass(object cc) { }

	// RVA: 0x7198DD8
	private object AddSet(object set) { }

	// RVA: 0x7199178
	public object AddSubtraction(object sub) { }

	// RVA: 0x7198864
	public object AddRange(object first, object last) { }

	// RVA: 0x7199180
	public object AddCategoryFromName(object categoryName, object invert, object caseInsensitive, object pattern) { }

	// RVA: 0x719974C
	private object AddCategory(object category) { }

	// RVA: 0x7199770
	public object AddLowercase(object culture) { }

	// RVA: 0x7199954
	private object AddLowercaseRange(object chMin, object chMax, object culture) { }

	// RVA: 0x7199C20
	public object AddWord(object ecma, object negate) { }

	// RVA: 0x7199D4C
	public object AddSpace(object ecma, object negate) { }

	// RVA: 0x7199E78
	public object AddDigit(object ecma, object negate, object pattern) { }

	// RVA: 0x7199F50
	public static object SingletonChar(object set) { }

	// RVA: 0x7199F74
	public static object IsMergeable(object charClass) { }

	// RVA: 0x719A0F0
	public static object IsEmpty(object charClass) { }

	// RVA: 0x719A20C
	public static object IsSingleton(object set) { }

	// RVA: 0x719A354
	public static object IsSingletonInverse(object set) { }

	// RVA: 0x719A088
	private static object IsSubtraction(object charClass) { }

	// RVA: 0x719A060
	private static object IsNegated(object set) { }

	// RVA: 0x719A4A0
	public static object IsECMAWordChar(object ch) { }

	// RVA: 0x719A5F0
	public static object IsWordChar(object ch) { }

	// RVA: 0x719A584
	public static object CharInClass(object ch, object set) { }

	// RVA: 0x719A6CC
	private static object CharInClassRecursive(object ch, object set, object start) { }

	// RVA: 0x719A804
	private static object CharInClassInternal(object ch, object set, object start, object mySetLength, object myCategoryLength) { }

	// RVA: 0x719A930
	private static object CharInCategory(object ch, object set, object start, object mySetLength, object myCategoryLength) { }

	// RVA: 0x719AB68
	private static object CharInCategoryGroup(object ch, object chcategory, object category, object i) { }

	// RVA: 0x71993E4
	private static object NegateCategory(object category) { }

	// RVA: 0x719AC3C
	public static object Parse(object charClass) { }

	// RVA: 0x719ACC4
	private static object ParseRecursive(object charClass, object start) { }

	// RVA: 0x7198D18
	private object RangeCount() { }

	// RVA: 0x719AFC8
	public object ToStringClass() { }

	// RVA: 0x7198D6C
	private object GetRangeAt(object i) { }

	// RVA: 0x719B1C0
	private object Canonicalize() { }

	// RVA: 0x7199498
	private static object SetFromProperty(object capname, object invert, object pattern) { }

	// RVA: 0x719B46C
	private static object .cctor() { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexCode
{

	// Fields
	public const object Onerep;
	public const object Notonerep;
	public const object Setrep;
	public const object Oneloop;
	public const object Notoneloop;
	public const object Setloop;
	public const object Onelazy;
	public const object Notonelazy;
	public const object Setlazy;
	public const object One;
	public const object Notone;
	public const object Set;
	public const object Multi;
	public const object Ref;
	public const object Bol;
	public const object Eol;
	public const object Boundary;
	public const object Nonboundary;
	public const object Beginning;
	public const object Start;
	public const object EndZ;
	public const object End;
	public const object Nothing;
	public const object Lazybranch;
	public const object Branchmark;
	public const object Lazybranchmark;
	public const object Nullcount;
	public const object Setcount;
	public const object Branchcount;
	public const object Lazybranchcount;
	public const object Nullmark;
	public const object Setmark;
	public const object Capturemark;
	public const object Getmark;
	public const object Setjump;
	public const object Backjump;
	public const object Forejump;
	public const object Testref;
	public const object Goto;
	public const object Prune;
	public const object Stop;
	public const object ECMABoundary;
	public const object NonECMABoundary;
	public const object Mask;
	public const object Rtl;
	public const object Back;
	public const object Back2;
	public const object Ci;
	public readonly object Codes; // 0x8
	public readonly object Strings; // 0x10
	public readonly object TrackCount; // 0x18
	public readonly object Caps; // 0x20
	public readonly object CapSize; // 0x28
	public readonly object FCPrefix; // 0x30
	public readonly object BMPrefix; // 0x48
	public readonly object Anchors; // 0x50
	public readonly object RightToLeft; // 0x54

	// Methods

	// RVA: 0x719FEA0
	public object .ctor(object codes, object stringlist, object trackcount, object caps, object capsize, object bmPrefix, object fcPrefix, object anchors, object rightToLeft) { }

	// RVA: 0x719FF80
	public static object OpcodeBacktracks(object Op) { }

}

// Namespace: System.Text.RegularExpressions
internal struct RegexFCD
{

	// Fields
	private readonly object _fcStack; // 0xFFFFFFFFFFFFFFF8
	private object _intStack; // 0x0
	private object _skipAllChildren; // 0x20
	private object _skipchild; // 0x21
	private object _failed; // 0x22

	// Methods

	// RVA: 0x719FFD4
	private object .ctor(object intStack) { }

	// RVA: 0x71A00B4
	public static object FirstChars(object t) { }

	// RVA: 0x71A0668
	public static object Prefix(object tree) { }

	// RVA: 0x71A0958
	public static object Anchors(object tree) { }

	// RVA: 0x71A0B94
	private static object AnchorFromType(object type) { }

	// RVA: 0x71A0C34
	private object PushInt(object i) { }

	// RVA: 0x71A0C90
	private object IntIsEmpty() { }

	// RVA: 0x71A0CD8
	private object PopInt() { }

	// RVA: 0x71A0D38
	private object PushFC(object fc) { }

	// RVA: 0x71A0E58
	private object FCIsEmpty() { }

	// RVA: 0x71A0EB4
	private object PopFC() { }

	// RVA: 0x71A0F9C
	private object TopFC() { }

	// RVA: 0x71A05C0
	public object Dispose() { }

	// RVA: 0x71A0364
	private object RegexFCFromRegexTree(object tree) { }

	// RVA: 0x71A16B4
	private object SkipChild() { }

	// RVA: 0x71A100C
	private object CalculateFC(object NodeType, object node, object CurIndex) { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexFC
{

	// Fields
	private object _cc; // 0x8
	public object _nullable; // 0x10
	private object <CaseInsensitive>k__BackingField; // 0x11

	// Properties
	public object CaseInsensitive { get; set; }

	// Methods

	// RVA: 0x71A16C0
	public object .ctor(object nullable) { }

	// RVA: 0x71A181C
	public object .ctor(object ch, object not, object nullable, object caseInsensitive) { }

	// RVA: 0x71A1928
	public object .ctor(object charClass, object nullable, object caseInsensitive) { }

	// RVA: 0x71A1734
	public object AddFC(object fc, object concatenate) { }

	// RVA: 0x71A1A20
	public object get_CaseInsensitive() { }

	// RVA: 0x71A1A28
	private object set_CaseInsensitive(object value) { }

	// RVA: 0x71A0614
	public object GetFirstChars(object culture) { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexInterpreter
{

	// Fields
	private readonly object _code; // 0x78
	private readonly object _culture; // 0x80
	private object _operator; // 0x88
	private object _codepos; // 0x8C
	private object _rightToLeft; // 0x90
	private object _caseInsensitive; // 0x91

	// Methods

	// RVA: 0x719719C
	public object .ctor(object code, object culture) { }

	// RVA: 0x71A1A30
	protected override object InitTrackCount() { }

	// RVA: 0x71A1A58
	private object Advance(object i) { }

	// RVA: 0x71A1AF4
	private object Goto(object newpos) { }

	// RVA: 0x71A1B88
	private object Textto(object newpos) { }

	// RVA: 0x71A1B90
	private object Trackto(object newpos) { }

	// RVA: 0x71A1BBC
	private object Textstart() { }

	// RVA: 0x71A1BC4
	private object Textpos() { }

	// RVA: 0x71A1BCC
	private object Trackpos() { }

	// RVA: 0x71A1BF8
	private object TrackPush() { }

	// RVA: 0x71A1C44
	private object TrackPush(object I1) { }

	// RVA: 0x71A1CA8
	private object TrackPush(object I1, object I2) { }

	// RVA: 0x71A1D24
	private object TrackPush(object I1, object I2, object I3) { }

	// RVA: 0x71A1DB8
	private object TrackPush2(object I1) { }

	// RVA: 0x71A1E20
	private object TrackPush2(object I1, object I2) { }

	// RVA: 0x71A1EA0
	private object Backtrack() { }

	// RVA: 0x71A1AD4
	private object SetOperator(object op) { }

	// RVA: 0x71A1FC0
	private object TrackPop() { }

	// RVA: 0x71A1FD0
	private object TrackPop(object framesize) { }

	// RVA: 0x71A1FE0
	private object TrackPeek() { }

	// RVA: 0x71A2024
	private object TrackPeek(object i) { }

	// RVA: 0x71A206C
	private object StackPush(object I1) { }

	// RVA: 0x71A20B4
	private object StackPush(object I1, object I2) { }

	// RVA: 0x71A2114
	private object StackPop() { }

	// RVA: 0x71A2124
	private object StackPop(object framesize) { }

	// RVA: 0x71A2134
	private object StackPeek() { }

	// RVA: 0x71A2178
	private object StackPeek(object i) { }

	// RVA: 0x71A21C0
	private object Operator() { }

	// RVA: 0x71A21C8
	private object Operand(object i) { }

	// RVA: 0x71A2224
	private object Leftchars() { }

	// RVA: 0x71A2234
	private object Rightchars() { }

	// RVA: 0x71A2244
	private object Bump() { }

	// RVA: 0x71A2258
	private object Forwardchars() { }

	// RVA: 0x71A2284
	private object Forwardcharnext() { }

	// RVA: 0x71A2378
	private object Stringmatch(object str) { }

	// RVA: 0x71A2570
	private object Refmatch(object index, object len) { }

	// RVA: 0x71A27E8
	private object Backwardnext() { }

	// RVA: 0x71A281C
	private object CharAt(object j) { }

	// RVA: 0x71A2840
	protected override object FindFirstChar() { }

	// RVA: 0x71A2D30
	protected override object Go() { }

}

// Namespace: System.Text.RegularExpressions
public class RegexMatchTimeoutException
{

	// Fields
	private readonly object <Input>k__BackingField; // 0x88
	private readonly object <Pattern>k__BackingField; // 0x90
	private readonly object <MatchTimeout>k__BackingField; // 0x98

	// Properties
	public object Input { get; }
	public object Pattern { get; }
	public object MatchTimeout { get; }

	// Methods

	// RVA: 0x71A50FC
	public object .ctor(object regexInput, object regexPattern, object matchTimeout) { }

	// RVA: 0x71A51D4
	public object .ctor() { }

	// RVA: 0x71A526C
	protected object .ctor(object info, object context) { }

	// RVA: 0x71A53B8
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object info, object context) { }

	// RVA: 0x71A54C8
	public object get_Input() { }

	// RVA: 0x71A54D0
	public object get_Pattern() { }

	// RVA: 0x71A54D8
	public object get_MatchTimeout() { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexNode
{

	// Fields
	public object NType; // 0x8
	public object Children; // 0x10
	public object Str; // 0x18
	public object Ch; // 0x20
	public object M; // 0x24
	public object N; // 0x28
	public readonly object Options; // 0x2C
	public object Next; // 0x30

	// Methods

	// RVA: 0x71A54E0
	public object .ctor(object type, object options) { }

	// RVA: 0x71A551C
	public object .ctor(object type, object options, object ch) { }

	// RVA: 0x71A5560
	public object .ctor(object type, object options, object str) { }

	// RVA: 0x71A55A4
	public object .ctor(object type, object options, object m) { }

	// RVA: 0x71A55E8
	public object .ctor(object type, object options, object m, object n) { }

	// RVA: 0x71A5638
	public object UseOptionR() { }

	// RVA: 0x71A5644
	public object ReverseLeft() { }

	// RVA: 0x71A56D4
	private object MakeRep(object type, object min, object max) { }

	// RVA: 0x71A56EC
	private object Reduce() { }

	// RVA: 0x71A6468
	private object StripEnation(object emptyType) { }

	// RVA: 0x71A6254
	private object ReduceGroup() { }

	// RVA: 0x71A607C
	private object ReduceRep() { }

	// RVA: 0x71A62E4
	private object ReduceSet() { }

	// RVA: 0x71A57E4
	private object ReduceAlternation() { }

	// RVA: 0x71A5C6C
	private object ReduceConcatenation() { }

	// RVA: 0x71A6644
	public object MakeQuantifier(object lazy, object min, object max) { }

	// RVA: 0x71A67A4
	public object AddChild(object newChild) { }

	// RVA: 0x71A65D8
	public object Child(object i) { }

	// RVA: 0x71A6580
	public object ChildCount() { }

	// RVA: 0x71A6930
	public object Type() { }

}

// Namespace: System.Text.RegularExpressions
public enum RegexOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object IgnoreCase;
	public const object Multiline;
	public const object ExplicitCapture;
	public const object Compiled;
	public const object Singleline;
	public const object IgnorePatternWhitespace;
	public const object RightToLeft;
	public const object ECMAScript;
	public const object CultureInvariant;
}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexParser
{

	// Fields
	private object _stack; // 0x8
	private object _group; // 0x10
	private object _alternation; // 0x18
	private object _concatenation; // 0x20
	private object _unit; // 0x28
	private object _pattern; // 0x30
	private object _currentPos; // 0x38
	private object _culture; // 0x40
	private object _autocap; // 0x48
	private object _capcount; // 0x4C
	private object _captop; // 0x50
	private object _capsize; // 0x54
	private object _caps; // 0x58
	private object _capnames; // 0x60
	private object _capnumlist; // 0x68
	private object _capnamelist; // 0x70
	private object _options; // 0x78
	private object _optionsStack; // 0x80
	private object _ignoreNextParen; // 0x88
	private static readonly object s_category; // 0x0

	// Methods

	// RVA: 0x71A6938
	public static object Parse(object re, object op) { }

	// RVA: 0x71A7EA4
	public static object ParseReplacement(object rep, object caps, object capsize, object capnames, object op) { }

	// RVA: 0x71A899C
	public static object Escape(object input) { }

	// RVA: 0x71A6B58
	private object .ctor(object culture) { }

	// RVA: 0x71A6C18
	private object SetPattern(object Re) { }

	// RVA: 0x71A7078
	private object Reset(object topopts) { }

	// RVA: 0x71A7118
	private object ScanRegex() { }

	// RVA: 0x71A8018
	private object ScanReplacement() { }

	// RVA: 0x71A99FC
	private object ScanCharClass(object caseInsensitive, object scanOnly) { }

	// RVA: 0x71AA238
	private object ScanGroupOpen() { }

	// RVA: 0x71A8DCC
	private object ScanBlank() { }

	// RVA: 0x71AB368
	private object ScanBackslash(object scanOnly) { }

	// RVA: 0x71ACE50
	private object ScanBasicBackslash(object scanOnly) { }

	// RVA: 0x71ABD14
	private object ScanDollar() { }

	// RVA: 0x71AC858
	private object ScanCapname() { }

	// RVA: 0x71AD62C
	private object ScanOctal() { }

	// RVA: 0x71ABBE0
	private object ScanDecimal() { }

	// RVA: 0x71AD760
	private object ScanHex(object c) { }

	// RVA: 0x71AD8C0
	private static object HexDigit(object ch) { }

	// RVA: 0x71AD8F0
	private object ScanControl() { }

	// RVA: 0x71AD9AC
	private object IsOnlyTopOption(object option) { }

	// RVA: 0x71ACB84
	private object ScanOptions() { }

	// RVA: 0x71AC494
	private object ScanCharEscape() { }

	// RVA: 0x71AC2F0
	private object ParseProperty() { }

	// RVA: 0x71ACDC0
	private object TypeFromCode(object ch) { }

	// RVA: 0x71AD9CC
	private static object OptionFromCode(object ch) { }

	// RVA: 0x71A6C9C
	private object CountCaptures() { }

	// RVA: 0x71ADA2C
	private object NoteCaptureSlot(object i, object pos) { }

	// RVA: 0x71ADBD4
	private object NoteCaptureName(object name, object pos) { }

	// RVA: 0x71A800C
	private object NoteCaptures(object caps, object capsize, object capnames) { }

	// RVA: 0x71ADE1C
	private object AssignNameSlots() { }

	// RVA: 0x71ACAC0
	private object CaptureSlotFromName(object capname) { }

	// RVA: 0x71AC988
	private object IsCaptureSlot(object i) { }

	// RVA: 0x71ACA64
	private object IsCaptureName(object capname) { }

	// RVA: 0x71AC97C
	private object UseOptionN() { }

	// RVA: 0x71A99F0
	private object UseOptionI() { }

	// RVA: 0x71AB9D4
	private object UseOptionM() { }

	// RVA: 0x71ABA54
	private object UseOptionS() { }

	// RVA: 0x71A914C
	private object UseOptionX() { }

	// RVA: 0x71AC2E4
	private object UseOptionE() { }

	// RVA: 0x71A9440
	private static object IsSpecial(object ch) { }

	// RVA: 0x71A91C0
	private static object IsStopperX(object ch) { }

	// RVA: 0x71A94E8
	private static object IsQuantifier(object ch) { }

	// RVA: 0x71A9268
	private object IsTrueQuantifier() { }

	// RVA: 0x71ACD18
	private static object IsSpace(object ch) { }

	// RVA: 0x71A8C80
	private static object IsMetachar(object ch) { }

	// RVA: 0x71A9590
	private object AddConcatenate(object pos, object cch, object isReplacement) { }

	// RVA: 0x71AAC84
	private object PushGroup() { }

	// RVA: 0x71AB1A4
	private object PopGroup() { }

	// RVA: 0x71AAE90
	private object EmptyStack() { }

	// RVA: 0x71A8D28
	private object StartGroup(object openGroup) { }

	// RVA: 0x71AACE4
	private object AddAlternate() { }

	// RVA: 0x71ABB70
	private object AddConcatenate() { }

	// RVA: 0x71ABCBC
	private object AddConcatenate(object lazy, object min, object max) { }

	// RVA: 0x71AE76C
	private object Unit() { }

	// RVA: 0x71A98F0
	private object AddUnitOne(object ch) { }

	// RVA: 0x71ABA60
	private object AddUnitNotone(object ch) { }

	// RVA: 0x71AA09C
	private object AddUnitSet(object cc) { }

	// RVA: 0x71AE774
	private object AddUnitNode(object node) { }

	// RVA: 0x71AB9E0
	private object AddUnitType(object type) { }

	// RVA: 0x71AAF40
	private object AddGroup() { }

	// RVA: 0x71AA118
	private object PushOptions() { }

	// RVA: 0x71AB2BC
	private object PopOptions() { }

	// RVA: 0x71ADB78
	private object EmptyOptionsStack() { }

	// RVA: 0x71AAC14
	private object PopKeepOptions() { }

	// RVA: 0x71AAEA0
	private object MakeException(object message) { }

	// RVA: 0x71AE77C
	private object Textpos() { }

	// RVA: 0x71AE784
	private object Textto(object pos) { }

	// RVA: 0x71ABBAC
	private object RightCharMoveRight() { }

	// RVA: 0x71A9158
	private object MoveRight() { }

	// RVA: 0x71AC96C
	private object MoveRight(object i) { }

	// RVA: 0x71ABB60
	private object MoveLeft() { }

	// RVA: 0x71A98CC
	private object CharAt(object i) { }

	// RVA: 0x71A9194
	internal object RightChar() { }

	// RVA: 0x71AC93C
	private object RightChar(object i) { }

	// RVA: 0x71A9168
	private object CharsRight() { }

	// RVA: 0x71AE78C
	private static object .cctor() { }

}

// Namespace: System.Text.RegularExpressions
internal struct RegexPrefix
{

	// Fields
	private readonly object <CaseInsensitive>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private static readonly object <Empty>k__BackingField; // 0x0
	private readonly object <Prefix>k__BackingField; // 0x0

	// Properties
	internal object CaseInsensitive { get; }
	internal static object Empty { get; }
	internal object Prefix { get; }

	// Methods

	// RVA: 0x71AE8BC
	internal object .ctor(object prefix, object ci) { }

	// RVA: 0x71AE8D4
	internal object get_CaseInsensitive() { }

	// RVA: 0x71AE8E4
	internal static object get_Empty() { }

	// RVA: 0x71AE960
	internal object get_Prefix() { }

	// RVA: 0x71AE970
	private static object .cctor() { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexReplacement
{

	// Fields
	private const object Specials;
	public const object LeftPortion;
	public const object RightPortion;
	public const object LastGroup;
	public const object WholeString;
	private readonly object _strings; // 0x8
	private readonly object _rules; // 0x10
	private readonly object <Pattern>k__BackingField; // 0x18

	// Properties
	public object Pattern { get; }

	// Methods

	// RVA: 0x71A817C
	public object .ctor(object rep, object concat, object _caps) { }

	// RVA: 0x71AE9E4
	public static object GetOrCreate(object replRef, object replacement, object caps, object capsize, object capnames, object roptions) { }

	// RVA: 0x71AEB24
	public object get_Pattern() { }

	// RVA: 0x71AEB2C
	private object ReplacementImpl(object sb, object match) { }

	// RVA: 0x71AED88
	private object ReplacementImplRTL(object al, object match) { }

	// RVA: 0x71AF2C4
	public object Replace(object regex, object input, object count, object startat) { }

}

// Namespace: System.Text.RegularExpressions
public abstract class RegexRunner
{

	// Fields
	protected internal object runtextbeg; // 0x8
	protected internal object runtextend; // 0xC
	protected internal object runtextstart; // 0x10
	protected internal object runtext; // 0x18
	protected internal object runtextpos; // 0x20
	protected internal object runtrack; // 0x28
	protected internal object runtrackpos; // 0x30
	protected internal object runstack; // 0x38
	protected internal object runstackpos; // 0x40
	protected internal object runcrawl; // 0x48
	protected internal object runcrawlpos; // 0x50
	protected internal object runtrackcount; // 0x54
	protected internal object runmatch; // 0x58
	protected internal object runregex; // 0x60
	private object _timeout; // 0x68
	private object _ignoreTimeout; // 0x6C
	private object _timeoutOccursAt; // 0x70
	private const object TimeoutCheckFrequency;
	private object _timeoutChecksToSkip; // 0x74

	// Methods

	// RVA: 0x71AF794
	protected internal object .ctor() { }

	// RVA: 0x71AF79C
	protected internal object Scan(object regex, object text, object textbeg, object textend, object textstart, object prevlen, object quick, object timeout) { }

	// RVA: 0x71AFBEC
	private object StartTimeoutWatch() { }

	// RVA: 0x71AFC2C
	protected object CheckTimeout() { }

	// RVA: 0x71AFF04
	private object DoCheckTimeout() { }

	// RVA: -1
	protected abstract object Go() { }

	// RVA: -1
	protected abstract object FindFirstChar() { }

	// RVA: -1
	protected abstract object InitTrackCount() { }

	// RVA: 0x71AFC3C
	private object InitMatch() { }

	// RVA: 0x71AFE88
	private object TidyMatch(object quick) { }

	// RVA: 0x71AFFE8
	protected object EnsureStorage() { }

	// RVA: 0x71B01B8
	protected object IsBoundary(object index, object startpos, object endpos) { }

	// RVA: 0x71B02D8
	protected object IsECMABoundary(object index, object startpos, object endpos) { }

	// RVA: 0x71B00F8
	protected object DoubleTrack() { }

	// RVA: 0x71B0038
	protected object DoubleStack() { }

	// RVA: 0x71B03F8
	protected object DoubleCrawl() { }

	// RVA: 0x71B04B8
	protected object Crawl(object i) { }

	// RVA: 0x71B0520
	protected object Popcrawl() { }

	// RVA: 0x71B0568
	protected object Crawlpos() { }

	// RVA: 0x71B0594
	protected object Capture(object capnum, object start, object end) { }

	// RVA: 0x71B0654
	protected object TransferCapture(object capnum, object uncapnum, object start, object end) { }

	// RVA: 0x71B0900
	protected object Uncapture() { }

	// RVA: 0x71B0988
	protected object IsMatched(object cap) { }

	// RVA: 0x71B0858
	protected object MatchIndex(object cap) { }

	// RVA: 0x71B08AC
	protected object MatchLength(object cap) { }

}

// Namespace: System.Text.RegularExpressions
public abstract class RegexRunnerFactory
{

	// Methods

	// RVA: -1
	protected internal abstract object CreateInstance() { }

}

// Namespace: System.Text.RegularExpressions
internal sealed class RegexTree
{

	// Fields
	public readonly object Root; // 0x8
	public readonly object Caps; // 0x10
	public readonly object CapNumList; // 0x18
	public readonly object CapTop; // 0x20
	public readonly object CapNames; // 0x28
	public readonly object CapsList; // 0x30
	public readonly object Options; // 0x38

	// Methods

	// RVA: 0x71A7E38
	internal object .ctor(object root, object caps, object capNumList, object capTop, object capNames, object capsList, object options) { }

}

// Namespace: System.Text.RegularExpressions
internal struct RegexWriter
{

	// Fields
	private object _emitted; // 0xFFFFFFFFFFFFFFF8
	private object _intStack; // 0x18
	private readonly object _stringHash; // 0x38
	private readonly object _stringTable; // 0x40
	private object _caps; // 0x48
	private object _trackCount; // 0x50

	// Methods

	// RVA: 0x71B0A18
	private object .ctor(object emittedSpan, object intStackSpan) { }

	// RVA: 0x71B0B80
	public static object Write(object tree) { }

	// RVA: 0x71B1218
	public object Dispose() { }

	// RVA: 0x71B0CB4
	public object RegexCodeFromRegexTree(object tree) { }

	// RVA: 0x71B1EB0
	private object PatchJump(object offset, object jumpDest) { }

	// RVA: 0x71B1F24
	private object Emit(object op) { }

	// RVA: 0x71B1278
	private object Emit(object op, object opd1) { }

	// RVA: 0x71B1F9C
	private object Emit(object op, object opd1, object opd2) { }

	// RVA: 0x71B2044
	private object StringCode(object str) { }

	// RVA: 0x71B223C
	private object MapCapnum(object capnum) { }

	// RVA: 0x71B1304
	private object EmitFragment(object nodetype, object node, object curIndex) { }

}

// Namespace: System.CodeDom.Compiler
public sealed class GeneratedCodeAttribute
{

	// Fields
	private readonly object tool; // 0x8
	private readonly object version; // 0x10

	// Methods

	// RVA: 0x71B231C
	public object .ctor(object tool, object version) { }

}

// Namespace: System.Diagnostics
public class BooleanSwitch
{

	// Methods

	// RVA: 0x71B2354
	public object .ctor(object displayName, object description) { }

}

// Namespace: System.Diagnostics
public abstract class Switch
{

	// Fields
	private readonly object description; // 0x8
	private readonly object displayName; // 0x10
	private object switchValueString; // 0x18
	private object defaultValue; // 0x20
	private static object switches; // 0x0
	private static object s_LastCollectionCount; // 0x8

	// Methods

	// RVA: 0x71B241C
	protected object .ctor(object displayName, object description) { }

	// RVA: 0x71B248C
	protected object .ctor(object displayName, object description, object defaultSwitchValue) { }

	// RVA: 0x71B2760
	private static object _pruneCachedSwitches() { }

	// RVA: 0x71B2D24
	private static object .cctor() { }

}

// Namespace: System.Diagnostics
public sealed class SwitchLevelAttribute
{

	// Fields
	private object type; // 0x8

	// Properties
	public object SwitchLevelType { set; }

	// Methods

	// RVA: 0x71B2DB4
	public object .ctor(object switchLevelType) { }

	// RVA: 0x71B2DE4
	public object set_SwitchLevelType(object value) { }

}

// Namespace: System.Diagnostics
public enum TraceLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object Error;
	public const object Warning;
	public const object Info;
	public const object Verbose;
}

// Namespace: System.Diagnostics
public class TraceSwitch
{

	// Methods

	// RVA: 0x71B2EC4
	public object .ctor(object displayName, object description) { }

}

// Namespace: System.Diagnostics
internal class AsyncStreamReader
{

	// Fields
	private object stream; // 0x8
	private object encoding; // 0x10
	private object decoder; // 0x18
	private object byteBuffer; // 0x20
	private object charBuffer; // 0x28
	private object cancelOperation; // 0x30
	private object eofEvent; // 0x38
	private object syncObject; // 0x40
	private object asyncReadResult; // 0x48

	// Methods

	// RVA: 0x71B2F8C
	public virtual object Close() { }

	// RVA: 0x71B2FD0
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x71B3440
	internal object CancelOperation() { }

}

// Namespace: 
private enum StreamReadMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object undefined;
	public const object syncMode;
	public const object asyncMode;
}

// Namespace: 
private enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object HaveId;
	public const object IsLocal;
	public const object IsNt;
	public const object HaveProcessInfo;
	public const object Exited;
	public const object Associated;
	public const object IsWin2k;
	public const object HaveNtProcessInfo;
}

// Namespace: System.Diagnostics
public class Process
{

	// Fields
	private object haveProcessId; // 0x20
	private object processId; // 0x24
	private object haveProcessHandle; // 0x28
	private object m_processHandle; // 0x30
	private object isRemoteMachine; // 0x38
	private object machineName; // 0x40
	private object m_processAccess; // 0x48
	private object threads; // 0x50
	private object modules; // 0x58
	private object haveWorkingSetLimits; // 0x60
	private object havePriorityClass; // 0x61
	private object watchForExit; // 0x62
	private object watchingForExit; // 0x63
	private object onExited; // 0x68
	private object exited; // 0x70
	private object exitCode; // 0x74
	private object signaled; // 0x78
	private object haveExitTime; // 0x79
	private object raisedOnExited; // 0x7A
	private object registeredWaitHandle; // 0x80
	private object waitHandle; // 0x88
	private object synchronizingObject; // 0x90
	private object standardOutput; // 0x98
	private object standardInput; // 0xA0
	private object standardError; // 0xA8
	private object disposed; // 0xB0
	private object outputStreamReadMode; // 0xB4
	private object errorStreamReadMode; // 0xB8
	private object inputStreamReadMode; // 0xBC
	internal object output; // 0xC0
	internal object error; // 0xC8
	private object process_name; // 0xD0

	// Properties
	private object Associated { get; }
	public object HasExited { get; }
	public object Id { get; }
	public object SynchronizingObject { get; }
	public object ProcessName { get; }

	// Methods

	// RVA: 0x71B344C
	private object .ctor(object machineName, object isRemoteMachine, object processId, object processInfo) { }

	// RVA: 0x71B34EC
	private object get_Associated() { }

	// RVA: 0x71B350C
	public object get_HasExited() { }

	// RVA: 0x71B4254
	public object get_Id() { }

	// RVA: 0x71B427C
	public object get_SynchronizingObject() { }

	// RVA: 0x71B4468
	private object ReleaseProcessHandle(object handle) { }

	// RVA: 0x71B4494
	protected override object Dispose(object disposing) { }

	// RVA: 0x71B44DC
	public object Close() { }

	// RVA: 0x71B3918
	private object EnsureState(object state) { }

	// RVA: 0x71B483C
	public static object GetCurrentProcess() { }

	// RVA: 0x71B4928
	protected object OnExited() { }

	// RVA: 0x71B3A5C
	private object GetProcessHandle(object access, object throwIfExited) { }

	// RVA: 0x71B4BEC
	private object GetProcessHandle(object access) { }

	// RVA: 0x71B4828
	public object Refresh() { }

	// RVA: 0x71B46BC
	private object StopWatchingForExit() { }

	// RVA: 0x71B4BF4
	public override object ToString() { }

	// RVA: 0x71B5000
	private static object ProcessName_icall(object handle) { }

	// RVA: 0x71B5004
	private static object ProcessName_internal(object handle) { }

	// RVA: 0x71B4D74
	public object get_ProcessName() { }

	// RVA: 0x71B4160
	private object RaiseOnExited() { }

}

// Namespace: System.Diagnostics
internal class ProcessInfo
{
}

// Namespace: System.Diagnostics
public class ProcessModuleCollection
{
}

// Namespace: System.Diagnostics
public class ProcessThreadCollection
{
}

// Namespace: System.Diagnostics
internal class ProcessWaitHandle
{

	// Methods

	// RVA: 0x71B3F44
	internal object .ctor(object processHandle) { }

}

// Namespace: System.Diagnostics
public class MonitoringDescriptionAttribute
{

	// Properties
	public override object Description { get; }

	// Methods

	// RVA: 0x71B511C
	public object .ctor(object description) { }

	// RVA: 0x71B5188
	public override object get_Description() { }

}

// Namespace: System.Diagnostics
public class Stopwatch
{

	// Fields
	public static readonly object Frequency; // 0x0
	public static readonly object IsHighResolution; // 0x8
	private object elapsed; // 0x8
	private object started; // 0x10
	private object is_running; // 0x18

	// Properties
	public object Elapsed { get; }
	public object ElapsedMilliseconds { get; }
	public object ElapsedTicks { get; }

	// Methods

	// RVA: 0x71B5190
	public static object GetTimestamp() { }

	// RVA: 0x71B5194
	public static object StartNew() { }

	// RVA: 0x71B5268
	public object .ctor() { }

	// RVA: 0x71B52F0
	public object get_Elapsed() { }

	// RVA: 0x71B5534
	public object get_ElapsedMilliseconds() { }

	// RVA: 0x71B54B8
	public object get_ElapsedTicks() { }

	// RVA: 0x71B56E4
	public object Reset() { }

	// RVA: 0x71B5270
	public object Start() { }

	// RVA: 0x71B56F0
	public object Stop() { }

	// RVA: 0x71B5788
	public object Restart() { }

	// RVA: 0x71B57F4
	private static object .cctor() { }

}

// Namespace: System.Diagnostics.CodeAnalysis
public sealed class ExcludeFromCodeCoverageAttribute
{

	// Methods

	// RVA: 0x71B5850
	public object .ctor() { }

}

// Namespace: System.Security.Authentication
public class AuthenticationException
{

	// Methods

	// RVA: 0x71B5858
	public object .ctor() { }

	// RVA: 0x71B58BC
	public object .ctor(object message) { }

	// RVA: 0x71B58C4
	public object .ctor(object message, object innerException) { }

	// RVA: 0x71B58CC
	protected object .ctor(object serializationInfo, object streamingContext) { }

}

// Namespace: System.Security.Authentication
public enum SslProtocols
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Ssl2;
	public const object Ssl3;
	public const object Tls;
	public const object Tls11;
	public const object Tls12;
	public const object Tls13;
	public const object Default;
}

// Namespace: 
internal enum DerTag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Boolean;
	public const object Integer;
	public const object BitString;
	public const object OctetString;
	public const object Null;
	public const object ObjectIdentifier;
	public const object UTF8String;
	public const object Sequence;
	public const object Set;
	public const object PrintableString;
	public const object T61String;
	public const object IA5String;
	public const object UTCTime;
	public const object GeneralizedTime;
	public const object BMPString;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__45_0; // 0x8
	public static object <>9__45_1; // 0x10
	public static object <>9__51_0; // 0x18

	// Methods

	// RVA: 0x71B750C
	private static object .cctor() { }

	// RVA: 0x71B756C
	public object .ctor() { }

	// RVA: 0x71B7574
	internal object <ReadT61String>b__45_0() { }

	// RVA: 0x71B75D4
	internal object <ReadT61String>b__45_1() { }

	// RVA: 0x71B761C
	internal object <ReadTime>b__51_0() { }

}

// Namespace: System.Security.Cryptography
internal class DerSequenceReader
{

	// Fields
	internal static object s_validityDateTimeFormatInfo; // 0x0
	private static object s_utf8EncodingWithExceptionFallback; // 0x8
	private static object s_latin1Encoding; // 0x10
	private readonly object _data; // 0x8
	private readonly object _end; // 0x10
	private object _position; // 0x14
	private object <ContentLength>k__BackingField; // 0x18

	// Properties
	private object ContentLength { set; }
	internal object HasData { get; }

	// Methods

	// RVA: 0x71B58D4
	private object set_ContentLength(object value) { }

	// RVA: 0x71B58DC
	internal object .ctor(object data) { }

	// RVA: 0x71B5908
	internal object .ctor(object data, object offset, object length) { }

	// RVA: 0x71B591C
	private object .ctor(object tagToEat, object data, object offset, object length) { }

	// RVA: 0x71B5AF4
	internal object get_HasData() { }

	// RVA: 0x71B5B04
	internal object PeekTag() { }

	// RVA: 0x71B5BAC
	internal object SkipValue() { }

	// RVA: 0x71B5C08
	internal object ReadNextEncodedValue() { }

	// RVA: 0x71B5E04
	internal object ReadBoolean() { }

	// RVA: 0x71B5EE0
	internal object ReadInteger() { }

	// RVA: 0x71B5F90
	internal object ReadIntegerBytes() { }

	// RVA: 0x71B6108
	internal object ReadBitString() { }

	// RVA: 0x71B6258
	internal object ReadOctetString() { }

	// RVA: 0x71B6318
	internal object ReadOidAsString() { }

	// RVA: 0x71B6634
	internal object ReadUtf8String() { }

	// RVA: 0x71B67FC
	private object ReadCollectionWithTag(object expected) { }

	// RVA: 0x71B6970
	internal object ReadSequence() { }

	// RVA: 0x71B6978
	internal object ReadSet() { }

	// RVA: 0x71B6980
	internal object ReadPrintableString() { }

	// RVA: 0x71B6AC4
	internal object ReadIA5String() { }

	// RVA: 0x71B6C08
	internal object ReadT61String() { }

	// RVA: 0x71B6FBC
	internal object ReadX509Date() { }

	// RVA: 0x71B709C
	internal object ReadUtcTime() { }

	// RVA: 0x71B70F8
	internal object ReadGeneralizedTime() { }

	// RVA: 0x71B73C8
	internal object ReadBMPString() { }

	// RVA: 0x71B6778
	private static object TrimTrailingNulls(object value) { }

	// RVA: 0x71B7154
	private object ReadTime(object timeTag, object formatString) { }

	// RVA: 0x71B6050
	private object ReadContentAsBytes() { }

	// RVA: 0x71B5A20
	private object EatTag(object expected) { }

	// RVA: 0x71B68C8
	private static object CheckTag(object expected, object data, object position) { }

	// RVA: 0x71B5AAC
	private object EatLength() { }

	// RVA: 0x71B5CC4
	private static object ScanContentLength(object data, object offset, object end, object bytesConsumed) { }

}

// Namespace: System.Security.Cryptography
public sealed class Oid
{

	// Fields
	private object _value; // 0x8
	private object _friendlyName; // 0x10
	private object _group; // 0x18

	// Properties
	public object Value { get; set; }
	public object FriendlyName { get; }

	// Methods

	// RVA: 0x71B7768
	public object .ctor() { }

	// RVA: 0x71B7770
	public object .ctor(object oid) { }

	// RVA: 0x71B7800
	public object .ctor(object value, object friendlyName) { }

	// RVA: 0x71B7838
	public object .ctor(object oid) { }

	// RVA: 0x71B78BC
	public static object FromOidValue(object oidValue, object group) { }

	// RVA: 0x71B7A40
	public object get_Value() { }

	// RVA: 0x71B7A48
	public object set_Value(object value) { }

	// RVA: 0x71B7A50
	public object get_FriendlyName() { }

	// RVA: 0x71B7A00
	private object .ctor(object value, object friendlyName, object group) { }

}

// Namespace: System.Security.Cryptography
public sealed class OidCollection
{

	// Fields
	private readonly object _list; // 0x8

	// Properties
	public object Item { get; }
	public object Count { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }

	// Methods

	// RVA: 0x71B7B04
	public object .ctor() { }

	// RVA: 0x71B7B88
	public object Add(object oid) { }

	// RVA: 0x71B7CB8
	public object get_Item(object index) { }

	// RVA: 0x71B7D24
	public object get_Count() { }

	// RVA: 0x71B7D78
	public object GetEnumerator() { }

	// RVA: 0x71B7E1C
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x71B7E8C
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x71B80E4
	public object get_IsSynchronized() { }

	// RVA: 0x71B80EC
	public object get_SyncRoot() { }

}

// Namespace: System.Security.Cryptography
public sealed class OidEnumerator
{

	// Fields
	private readonly object _oids; // 0x8
	private object _current; // 0x10

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x71B7DE8
	internal object .ctor(object oids) { }

	// RVA: 0x71B80F0
	public object get_Current() { }

	// RVA: 0x71B8160
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x71B81D0
	public object MoveNext() { }

	// RVA: 0x71B8264
	public object Reset() { }

}

// Namespace: System.Security.Cryptography
public enum OidGroup
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object All;
	public const object HashAlgorithm;
	public const object EncryptionAlgorithm;
	public const object PublicKeyAlgorithm;
	public const object SignatureAlgorithm;
	public const object Attribute;
	public const object ExtensionOrAttribute;
	public const object EnhancedKeyUsage;
	public const object Policy;
	public const object Template;
	public const object KeyDerivationFunction;
}

// Namespace: System.Security.Cryptography
internal enum AsnDecodeStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NotDecoded;
	public const object Ok;
	public const object BadAsn;
	public const object BadTag;
	public const object BadLength;
	public const object InformationNotAvailable;
}

// Namespace: System.Security.Cryptography
public class AsnEncodedData
{

	// Fields
	internal object _oid; // 0x8
	internal object _raw; // 0x10

	// Properties
	public object Oid { get; set; }
	public object RawData { get; set; }

	// Methods

	// RVA: 0x71B8270
	protected object .ctor() { }

	// RVA: 0x71B8278
	public object .ctor(object oid, object rawData) { }

	// RVA: 0x71B8464
	public object .ctor(object oid, object rawData) { }

	// RVA: 0x71B8580
	public object .ctor(object asnEncodedData) { }

	// RVA: 0x71B86A8
	public object get_Oid() { }

	// RVA: 0x71B84FC
	public object set_Oid(object value) { }

	// RVA: 0x71B86B0
	public object get_RawData() { }

	// RVA: 0x71B8360
	public object set_RawData(object value) { }

	// RVA: 0x71B86B8
	public virtual object CopyFrom(object asnEncodedData) { }

	// RVA: 0x71B87FC
	public virtual object Format(object multiLine) { }

	// RVA: 0x71B8A30
	internal virtual object ToString(object multiLine) { }

	// RVA: 0x71B88B4
	internal object Default(object multiLine) { }

	// RVA: 0x71B8C0C
	internal object BasicConstraintsExtension(object multiLine) { }

	// RVA: 0x71B8D4C
	internal object EnhancedKeyUsageExtension(object multiLine) { }

	// RVA: 0x71B8E90
	internal object KeyUsageExtension(object multiLine) { }

	// RVA: 0x71B8FD4
	internal object SubjectKeyIdentifierExtension(object multiLine) { }

	// RVA: 0x71B9118
	internal object SubjectAltName(object multiLine) { }

	// RVA: 0x71B957C
	internal object NetscapeCertType(object multiLine) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public enum OpenFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ReadOnly;
	public const object ReadWrite;
	public const object MaxAllowed;
	public const object OpenExistingOnly;
	public const object IncludeArchived;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum StoreLocation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CurrentUser;
	public const object LocalMachine;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum StoreName
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AddressBook;
	public const object AuthRoot;
	public const object CertificateAuthority;
	public const object Disallowed;
	public const object My;
	public const object Root;
	public const object TrustedPeople;
	public const object TrustedPublisher;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X500DistinguishedNameFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Reversed;
	public const object UseSemicolons;
	public const object DoNotUsePlusSign;
	public const object DoNotUseQuotes;
	public const object UseCommas;
	public const object UseNewLines;
	public const object UseUTF8Encoding;
	public const object UseT61Encoding;
	public const object ForceUTF8Encoding;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X509ChainStatusFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoError;
	public const object NotTimeValid;
	public const object NotTimeNested;
	public const object Revoked;
	public const object NotSignatureValid;
	public const object NotValidForUsage;
	public const object UntrustedRoot;
	public const object RevocationStatusUnknown;
	public const object Cyclic;
	public const object InvalidExtension;
	public const object InvalidPolicyConstraints;
	public const object InvalidBasicConstraints;
	public const object InvalidNameConstraints;
	public const object HasNotSupportedNameConstraint;
	public const object HasNotDefinedNameConstraint;
	public const object HasNotPermittedNameConstraint;
	public const object HasExcludedNameConstraint;
	public const object PartialChain;
	public const object CtlNotTimeValid;
	public const object CtlNotSignatureValid;
	public const object CtlNotValidForUsage;
	public const object OfflineRevocation;
	public const object NoIssuanceChainPolicy;
	public const object ExplicitDistrust;
	public const object HasNotSupportedCriticalExtension;
	public const object HasWeakSignature;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X509FindType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FindByThumbprint;
	public const object FindBySubjectName;
	public const object FindBySubjectDistinguishedName;
	public const object FindByIssuerName;
	public const object FindByIssuerDistinguishedName;
	public const object FindBySerialNumber;
	public const object FindByTimeValid;
	public const object FindByTimeNotYetValid;
	public const object FindByTimeExpired;
	public const object FindByTemplateName;
	public const object FindByApplicationPolicy;
	public const object FindByCertificatePolicy;
	public const object FindByExtension;
	public const object FindByKeyUsage;
	public const object FindBySubjectKeyIdentifier;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X509KeyUsageFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object EncipherOnly;
	public const object CrlSign;
	public const object KeyCertSign;
	public const object KeyAgreement;
	public const object DataEncipherment;
	public const object KeyEncipherment;
	public const object NonRepudiation;
	public const object DigitalSignature;
	public const object DecipherOnly;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X509NameType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SimpleName;
	public const object EmailName;
	public const object UpnName;
	public const object DnsName;
	public const object DnsFromAlternativeName;
	public const object UrlName;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X509RevocationFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object EndCertificateOnly;
	public const object EntireChain;
	public const object ExcludeRoot;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X509RevocationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoCheck;
	public const object Online;
	public const object Offline;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X509SubjectKeyIdentifierHashAlgorithm
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Sha1;
	public const object ShortSha1;
	public const object CapiSha1;
}

// Namespace: System.Security.Cryptography.X509Certificates
public enum X509VerificationFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoFlag;
	public const object IgnoreNotTimeValid;
	public const object IgnoreCtlNotTimeValid;
	public const object IgnoreNotTimeNested;
	public const object IgnoreInvalidBasicConstraints;
	public const object AllowUnknownCertificateAuthority;
	public const object IgnoreWrongUsage;
	public const object IgnoreInvalidName;
	public const object IgnoreInvalidPolicy;
	public const object IgnoreEndRevocationUnknown;
	public const object IgnoreCtlSignerRevocationUnknown;
	public const object IgnoreCertificateAuthorityRevocationUnknown;
	public const object IgnoreRootRevocationUnknown;
	public const object AllFlags;
}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class PublicKey
{

	// Fields
	private object _keyValue; // 0x8
	private object _params; // 0x10
	private object _oid; // 0x18
	private static object Empty; // 0x0

	// Properties
	public object EncodedKeyValue { get; }
	public object EncodedParameters { get; }
	public object Key { get; }
	public object Oid { get; }

	// Methods

	// RVA: 0x71B9AD4
	public object .ctor(object oid, object parameters, object keyValue) { }

	// RVA: 0x71B9C30
	public object get_EncodedKeyValue() { }

	// RVA: 0x71B9C38
	public object get_EncodedParameters() { }

	// RVA: 0x71B9C40
	public object get_Key() { }

	// RVA: 0x71BA990
	public object get_Oid() { }

	// RVA: 0x71BA998
	private static object GetUnsignedBigInteger(object integer) { }

	// RVA: 0x71BA28C
	internal static object DecodeDSA(object rawPublicKey, object rawParameters) { }

	// RVA: 0x71B9E4C
	internal static object DecodeRSA(object rawPublicKey) { }

	// RVA: 0x71BAA5C
	private static object .cctor() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X500DistinguishedName
{

	// Fields
	private object name; // 0x18
	private object canonEncoding; // 0x20

	// Properties
	public object Name { get; }

	// Methods

	// RVA: 0x71BAAD0
	public object .ctor(object encodedDistinguishedName) { }

	// RVA: 0x71BAD4C
	public object .ctor(object distinguishedName) { }

	// RVA: 0x71BAD54
	public object .ctor(object distinguishedName, object flag) { }

	// RVA: 0x71BB254
	public object get_Name() { }

	// RVA: 0x71BB09C
	public object Decode(object flag) { }

	// RVA: 0x71BB2E4
	public override object Format(object multiLine) { }

	// RVA: 0x71BB25C
	private static object GetSeparator(object flag) { }

	// RVA: 0x71BAC4C
	private object DecodeRawData() { }

	// RVA: 0x71BB358
	private static object Canonize(object s) { }

	// RVA: 0x71BB5F8
	internal static object AreEqual(object name1, object name2) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509BasicConstraintsExtension
{

	// Fields
	internal const object oid;
	internal const object friendlyName;
	private object _certificateAuthority; // 0x19
	private object _hasPathLengthConstraint; // 0x1A
	private object _pathLengthConstraint; // 0x1C
	private object _status; // 0x20

	// Properties
	public object CertificateAuthority { get; }
	public object HasPathLengthConstraint { get; }
	public object PathLengthConstraint { get; }

	// Methods

	// RVA: 0x71BB81C
	public object .ctor() { }

	// RVA: 0x71B99F0
	public object .ctor(object encodedBasicConstraints, object critical) { }

	// RVA: 0x71BBB08
	public object .ctor(object certificateAuthority, object hasPathLengthConstraint, object pathLengthConstraint, object critical) { }

	// RVA: 0x71BBDF4
	public object get_CertificateAuthority() { }

	// RVA: 0x71BBE60
	public object get_HasPathLengthConstraint() { }

	// RVA: 0x71BBECC
	public object get_PathLengthConstraint() { }

	// RVA: 0x71BBF38
	public override object CopyFrom(object asnEncodedData) { }

	// RVA: 0x71BB8C8
	internal object Decode(object extension) { }

	// RVA: 0x71BBC34
	internal object Encode() { }

	// RVA: 0x71BC10C
	internal override object ToString(object multiLine) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public class X509Certificate2
{

	// Fields
	private object lazyRawData; // 0x58
	private object lazySignatureAlgorithm; // 0x60
	private object lazyVersion; // 0x68
	private object lazySubjectName; // 0x70
	private object lazyIssuerName; // 0x78
	private object lazyPublicKey; // 0x80
	private object lazyPrivateKey; // 0x88
	private object lazyExtensions; // 0x90

	// Properties
	public object Extensions { get; }
	public object HasPrivateKey { get; }
	public object PrivateKey { get; }
	public object IssuerName { get; }
	public object NotAfter { get; }
	public object NotBefore { get; }
	public object PublicKey { get; }
	public object RawData { get; }
	public object SerialNumber { get; }
	public object SignatureAlgorithm { get; }
	public object SubjectName { get; }
	public object Thumbprint { get; }
	public object Version { get; }
	internal object Impl { get; }

	// Methods

	// RVA: 0x71BC3DC
	public override object Reset() { }

	// RVA: 0x71BC440
	public object .ctor() { }

	// RVA: 0x71BC448
	public object .ctor(object rawData) { }

	// RVA: 0x71BC5F0
	public object .ctor(object rawData, object password) { }

	// RVA: 0x71BC5F8
	internal object .ctor(object impl) { }

	// RVA: 0x71BC600
	public object .ctor(object certificate) { }

	// RVA: 0x71BC608
	protected object .ctor(object info, object context) { }

	// RVA: 0x71BC650
	public object get_Extensions() { }

	// RVA: 0x71BD034
	public object get_HasPrivateKey() { }

	// RVA: 0x71BD0FC
	public object get_PrivateKey() { }

	// RVA: 0x71BD37C
	public object get_IssuerName() { }

	// RVA: 0x71BD474
	public object get_NotAfter() { }

	// RVA: 0x71BD47C
	public object get_NotBefore() { }

	// RVA: 0x71BD484
	public object get_PublicKey() { }

	// RVA: 0x71BD648
	public object get_RawData() { }

	// RVA: 0x71BD744
	public object get_SerialNumber() { }

	// RVA: 0x71BD788
	public object get_SignatureAlgorithm() { }

	// RVA: 0x71BD88C
	public object get_SubjectName() { }

	// RVA: 0x71BD984
	public object get_Thumbprint() { }

	// RVA: 0x71BD9CC
	public object get_Version() { }

	// RVA: 0x71BDAC4
	public static object GetCertContentType(object rawData) { }

	// RVA: 0x71BDB68
	public object GetNameInfo(object nameType, object forIssuer) { }

	// RVA: 0x71BDC40
	public override object ToString() { }

	// RVA: 0x71BDC4C
	public override object ToString(object verbose) { }

	// RVA: 0x71BF0E8
	public object Verify() { }

	// RVA: 0x71BCC7C
	private static object CreateCustomExtensionIfAny(object oid) { }

	// RVA: 0x71BCBEC
	internal object get_Impl() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public class X509Certificate2Collection
{

	// Fields
	private static object newline_split; // 0x0

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x71BF3A4
	public object .ctor() { }

	// RVA: 0x71BF3B4
	public object .ctor(object certificates) { }

	// RVA: 0x71BF488
	public object get_Item(object index) { }

	// RVA: 0x71BF5FC
	public object Add(object certificate) { }

	// RVA: 0x71BF3E4
	public object AddRange(object certificates) { }

	// RVA: 0x71BF6A0
	public object Contains(object certificate) { }

	// RVA: 0x71BFA78
	private object GetKeyIdentifier(object x) { }

	// RVA: 0x71C04DC
	public object Find(object findType, object findValue, object validOnly) { }

	// RVA: 0x71C18D8
	public object GetEnumerator() { }

	// RVA: 0x71C1A1C
	private static object .cctor() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509Certificate2Enumerator
{

	// Fields
	private object enumerator; // 0x8

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x71C193C
	internal object .ctor(object collection) { }

	// RVA: 0x71C1AB4
	public object get_Current() { }

	// RVA: 0x71C1BE0
	public object MoveNext() { }

	// RVA: 0x71C1CC0
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x71C1DA4
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x71C1E84
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
internal abstract class X509Certificate2Impl
{

	// Properties
	public abstract object Extensions { get; }
	public abstract object IssuerName { get; }
	public abstract object PrivateKey { get; set; }
	public abstract object SignatureAlgorithm { get; }
	public abstract object SubjectName { get; }
	public abstract object Version { get; }
	internal abstract object IntermediateCertificates { get; }

	// Methods

	// RVA: -1
	public abstract object get_Extensions() { }

	// RVA: -1
	public abstract object get_IssuerName() { }

	// RVA: -1
	public abstract object get_PrivateKey() { }

	// RVA: -1
	public abstract object set_PrivateKey(object value) { }

	// RVA: -1
	public abstract object get_SignatureAlgorithm() { }

	// RVA: -1
	public abstract object get_SubjectName() { }

	// RVA: -1
	public abstract object get_Version() { }

	// RVA: -1
	internal abstract object get_IntermediateCertificates() { }

	// RVA: -1
	public abstract object GetNameInfo(object nameType, object forIssuer) { }

	// RVA: -1
	public abstract object Verify(object thisCertificate) { }

	// RVA: -1
	public abstract object AppendPrivateKeyInfo(object sb) { }

	// RVA: 0x71C1F68
	protected object .ctor() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
internal class X509Certificate2ImplMono
{

	// Fields
	private object intermediateCerts; // 0xA8
	private object _cert; // 0xB0
	private static object empty_error; // 0x0
	private static object signedData; // 0x8

	// Properties
	public override object IsValid { get; }
	private object Cert { get; }
	public override object HasPrivateKey { get; }
	public override object PrivateKey { get; set; }
	internal override object IntermediateCertificates { get; }
	internal object MonoCertificate { get; }

	// Methods

	// RVA: 0x71C1F70
	public override object get_IsValid() { }

	// RVA: 0x71C1F80
	public object .ctor(object cert) { }

	// RVA: 0x71C1FB4
	private object .ctor(object other) { }

	// RVA: 0x71C20A4
	public object .ctor(object rawData, object password, object keyStorageFlags) { }

	// RVA: 0x71C22D4
	public override object Clone() { }

	// RVA: 0x71C23A0
	private object get_Cert() { }

	// RVA: 0x71C23C8
	protected override object GetRawCertData() { }

	// RVA: 0x71C242C
	public override object get_HasPrivateKey() { }

	// RVA: 0x71C247C
	public override object get_PrivateKey() { }

	// RVA: 0x71C2A0C
	public override object set_PrivateKey(object value) { }

	// RVA: 0x71C2C00
	public override object GetRSAPrivateKey() { }

	// RVA: 0x71C2CAC
	public override object GetDSAPrivateKey() { }

	// RVA: 0x71C225C
	private object ImportPkcs12(object rawData, object password) { }

	// RVA: 0x71C2D58
	private object ImportPkcs12(object rawData, object password) { }

	// RVA: 0x71C38C4
	public override object Verify(object thisCertificate) { }

	// RVA: 0x71C3B20
	internal override object get_IntermediateCertificates() { }

	// RVA: 0x71C3B28
	internal object get_MonoCertificate() { }

	// RVA: 0x71C3B30
	private static object .cctor() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
internal abstract class X509Certificate2ImplUnix
{

	// Fields
	private object readCertData; // 0x8
	private object certData; // 0x10

	// Properties
	public sealed override object KeyAlgorithm { get; }
	public sealed override object KeyAlgorithmParameters { get; }
	public sealed override object PublicKeyValue { get; }
	public sealed override object SerialNumber { get; }
	public sealed override object SignatureAlgorithm { get; }
	public sealed override object Version { get; }
	public sealed override object SubjectName { get; }
	public sealed override object IssuerName { get; }
	public sealed override object Subject { get; }
	public sealed override object Issuer { get; }
	public sealed override object RawData { get; }
	public sealed override object Thumbprint { get; }
	public sealed override object Extensions { get; }
	public sealed override object NotAfter { get; }
	public sealed override object NotBefore { get; }

	// Methods

	// RVA: 0x71C3BFC
	private object EnsureCertData() { }

	// RVA: -1
	protected abstract object GetRawCertData() { }

	// RVA: 0x71C3CBC
	public sealed override object get_KeyAlgorithm() { }

	// RVA: 0x71C3D84
	public sealed override object get_KeyAlgorithmParameters() { }

	// RVA: 0x71C3E4C
	public sealed override object get_PublicKeyValue() { }

	// RVA: 0x71C3F14
	public sealed override object get_SerialNumber() { }

	// RVA: 0x71C3FDC
	public sealed override object get_SignatureAlgorithm() { }

	// RVA: 0x71C40A4
	public sealed override object get_Version() { }

	// RVA: 0x71C4170
	public sealed override object get_SubjectName() { }

	// RVA: 0x71C4238
	public sealed override object get_IssuerName() { }

	// RVA: 0x71C4300
	public sealed override object get_Subject() { }

	// RVA: 0x71C435C
	public sealed override object get_Issuer() { }

	// RVA: 0x71C43B8
	public sealed override object get_RawData() { }

	// RVA: 0x71C4480
	public sealed override object get_Thumbprint() { }

	// RVA: 0x71C46B8
	public sealed override object GetNameInfo(object nameType, object forIssuer) { }

	// RVA: 0x71C47A0
	public sealed override object get_Extensions() { }

	// RVA: 0x71C4868
	public sealed override object get_NotAfter() { }

	// RVA: 0x71C4990
	public sealed override object get_NotBefore() { }

	// RVA: 0x71C4AB8
	public sealed override object AppendPrivateKeyInfo(object sb) { }

	// RVA: 0x71C4B78
	public sealed override object Export(object contentType, object password) { }

	// RVA: 0x71C4D0C
	private object ExportPkcs12(object password) { }

	// RVA: 0x71C4D74
	private object ExportPkcs12(object password) { }

	// RVA: 0x71C1FAC
	protected object .ctor() { }

}

// Namespace: 
public class X509CertificateEnumerator
{

	// Fields
	private object enumerator; // 0x8

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x71C57E8
	public object .ctor(object mappings) { }

	// RVA: 0x71C5914
	public object get_Current() { }

	// RVA: 0x71C5A40
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x71C5B24
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x71C5C04
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x71C5CE8
	public object MoveNext() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public class X509CertificateCollection
{

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x71BF3AC
	public object .ctor() { }

	// RVA: 0x71C542C
	public object .ctor(object value) { }

	// RVA: 0x71C561C
	public object get_Item(object index) { }

	// RVA: 0x71C56E0
	public object Add(object value) { }

	// RVA: 0x71C545C
	public object AddRange(object value) { }

	// RVA: 0x71C5784
	public object GetEnumerator() { }

	// RVA: 0x71C58C8
	public override object GetHashCode() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
internal class X509CertificateImplCollection
{

	// Fields
	private object list; // 0x8

	// Properties
	public object Count { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x71C36E0
	public object .ctor() { }

	// RVA: 0x71C5DC8
	private object .ctor(object other) { }

	// RVA: 0x71C5388
	public object get_Count() { }

	// RVA: 0x71C531C
	public object get_Item(object index) { }

	// RVA: 0x71C3764
	public object Add(object impl, object takeOwnership) { }

	// RVA: 0x71C2040
	public object Clone() { }

	// RVA: 0x71C60C4
	public object Dispose() { }

	// RVA: 0x71C615C
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x71C63C0
	protected override object Finalize() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public class X509Chain
{

	// Fields
	private object impl; // 0x8

	// Properties
	internal object Impl { get; }
	public object ChainElements { get; }
	public object ChainPolicy { get; }

	// Methods

	// RVA: 0x71C6478
	internal object get_Impl() { }

	// RVA: 0x71C6554
	public object .ctor() { }

	// RVA: 0x71C65C0
	public object .ctor(object useMachineContext) { }

	// RVA: 0x71C6694
	internal object .ctor(object impl) { }

	// RVA: 0x71C670C
	public object .ctor(object chainContext) { }

	// RVA: 0x71C6754
	public object get_ChainElements() { }

	// RVA: 0x71C67F4
	public object get_ChainPolicy() { }

	// RVA: 0x71C3A70
	public object Build(object certificate) { }

	// RVA: 0x71C6894
	public object Reset() { }

	// RVA: 0x71C39D0
	public static object Create() { }

	// RVA: 0x71C6934
	public object Dispose() { }

	// RVA: 0x71C69CC
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x71C6B00
	protected override object Finalize() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public class X509ChainElement
{

	// Fields
	private object certificate; // 0x8
	private object status; // 0x10
	private object info; // 0x18
	private object compressed_status_flags; // 0x20

	// Properties
	public object Certificate { get; }
	public object ChainElementStatus { get; }
	internal object StatusFlags { get; set; }

	// Methods

	// RVA: 0x71C6BB8
	internal object .ctor(object certificate) { }

	// RVA: 0x71C6C28
	public object get_Certificate() { }

	// RVA: 0x71C6C30
	public object get_ChainElementStatus() { }

	// RVA: 0x71C6C38
	internal object get_StatusFlags() { }

	// RVA: 0x71C6C40
	internal object set_StatusFlags(object value) { }

	// RVA: 0x71C6C48
	private object Count(object flags) { }

	// RVA: 0x71C6D00
	private object Set(object status, object position, object flags, object mask) { }

	// RVA: 0x71C6F34
	internal object UncompressFlags() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509ChainElementCollection
{

	// Fields
	private object _list; // 0x8

	// Properties
	public object Count { get; }
	public object IsSynchronized { get; }
	public object Item { get; }
	public object SyncRoot { get; }

	// Methods

	// RVA: 0x71C7EA0
	internal object .ctor() { }

	// RVA: 0x71C7F10
	public object get_Count() { }

	// RVA: 0x71C7F60
	public object get_IsSynchronized() { }

	// RVA: 0x71C7FB0
	public object get_Item(object index) { }

	// RVA: 0x71C8074
	public object get_SyncRoot() { }

	// RVA: 0x71C80C4
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x71C812C
	public object GetEnumerator() { }

	// RVA: 0x71C8274
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x71C82DC
	internal object Add(object certificate) { }

	// RVA: 0x71C83C4
	internal object Clear() { }

	// RVA: 0x71C8414
	internal object Contains(object certificate) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509ChainElementEnumerator
{

	// Fields
	private object enumerator; // 0x8

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x71C8194
	internal object .ctor(object enumerable) { }

	// RVA: 0x71C8588
	public object get_Current() { }

	// RVA: 0x71C86B4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x71C8798
	public object MoveNext() { }

	// RVA: 0x71C8878
	public object Reset() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
internal abstract class X509ChainImpl
{

	// Properties
	public abstract object IsValid { get; }
	public abstract object ChainElements { get; }
	public abstract object ChainPolicy { get; }

	// Methods

	// RVA: -1
	public abstract object get_IsValid() { }

	// RVA: 0x71C895C
	protected object ThrowIfContextInvalid() { }

	// RVA: -1
	public abstract object get_ChainElements() { }

	// RVA: -1
	public abstract object get_ChainPolicy() { }

	// RVA: -1
	public abstract object Build(object certificate) { }

	// RVA: -1
	public abstract object AddStatus(object errorCode) { }

	// RVA: -1
	public abstract object Reset() { }

	// RVA: 0x71C6A68
	public object Dispose() { }

	// RVA: 0x71C8A4C
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x71C8A50
	protected override object Finalize() { }

	// RVA: 0x71C8B08
	protected object .ctor() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
internal class X509ChainImplMono
{

	// Fields
	private object location; // 0x8
	private object elements; // 0x10
	private object policy; // 0x18
	private object status; // 0x20
	private static object Empty; // 0x0
	private object max_path_length; // 0x28
	private object working_issuer_name; // 0x30
	private object working_public_key; // 0x38
	private object bce_restriction; // 0x40
	private object roots; // 0x48
	private object cas; // 0x50
	private object root_store; // 0x58
	private object ca_store; // 0x60
	private object user_root_store; // 0x68
	private object user_ca_store; // 0x70
	private object collection; // 0x78

	// Properties
	public override object IsValid { get; }
	public override object ChainElements { get; }
	public override object ChainPolicy { get; }
	private object Roots { get; }
	private object CertificateAuthorities { get; }
	private object LMRootStore { get; }
	private object UserRootStore { get; }
	private object LMCAStore { get; }
	private object UserCAStore { get; }
	private object CertificateCollection { get; }

	// Methods

	// RVA: 0x71C8B10
	public object .ctor(object useMachineContext) { }

	// RVA: 0x71C8C48
	public override object get_IsValid() { }

	// RVA: 0x71C8C50
	public override object get_ChainElements() { }

	// RVA: 0x71C8C58
	public override object get_ChainPolicy() { }

	// RVA: 0x71C8C60
	public override object AddStatus(object error) { }

	// RVA: 0x71C8C64
	public override object Build(object certificate) { }

	// RVA: 0x71C997C
	public override object Reset() { }

	// RVA: 0x71C9AF0
	private object get_Roots() { }

	// RVA: 0x71CA02C
	private object get_CertificateAuthorities() { }

	// RVA: 0x71C9CA0
	private object get_LMRootStore() { }

	// RVA: 0x71C9E1C
	private object get_UserRootStore() { }

	// RVA: 0x71CA1DC
	private object get_LMCAStore() { }

	// RVA: 0x71CA328
	private object get_UserCAStore() { }

	// RVA: 0x71CAAE8
	private object get_CertificateCollection() { }

	// RVA: 0x71C94CC
	private object BuildChainFrom(object certificate) { }

	// RVA: 0x71CB110
	private object SelectBestFromCollection(object child, object c) { }

	// RVA: 0x71CAEA4
	private object FindParent(object certificate) { }

	// RVA: 0x71CB008
	private object IsChainComplete(object certificate) { }

	// RVA: 0x71CB4D8
	private object IsSelfIssued(object certificate) { }

	// RVA: 0x71C96C0
	private object ValidateChain(object flag) { }

	// RVA: 0x71CB52C
	private object Process(object n) { }

	// RVA: 0x71CBAD4
	private object PrepareForNextCertificate(object n) { }

	// RVA: 0x71CC190
	private object WrapUp() { }

	// RVA: 0x71CC550
	private object ProcessCertificateExtensions(object element) { }

	// RVA: 0x71CC500
	private object IsSignedWith(object signed, object pubkey) { }

	// RVA: 0x71CB410
	private object GetSubjectKeyIdentifier(object certificate) { }

	// RVA: 0x71CB354
	private static object GetAuthorityKeyIdentifier(object certificate) { }

	// RVA: 0x71CC8B8
	private static object GetAuthorityKeyIdentifier(object crl) { }

	// RVA: 0x71CC6F4
	private static object GetAuthorityKeyIdentifier(object ext) { }

	// RVA: 0x71CBE2C
	private object CheckRevocationOnChain(object flag) { }

	// RVA: 0x71CC968
	private object CheckRevocation(object certificate, object ca, object online) { }

	// RVA: 0x71CCBC0
	private object CheckRevocation(object certificate, object ca_cert, object online) { }

	// RVA: 0x71CD7B4
	private static object CheckCrls(object subject, object ski, object store) { }

	// RVA: 0x71CCE98
	private object FindCrl(object caCertificate) { }

	// RVA: 0x71CD418
	private object ProcessCrlExtensions(object crl) { }

	// RVA: 0x71CD0AC
	private object ProcessCrlEntryExtensions(object entry) { }

	// RVA: 0x71CDBB0
	private static object .cctor() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509ChainPolicy
{

	// Fields
	private object apps; // 0x8
	private object cert; // 0x10
	private object store; // 0x18
	private object store2; // 0x20
	private object rflag; // 0x28
	private object mode; // 0x2C
	private object timeout; // 0x30
	private object vflags; // 0x38
	private object vtime; // 0x40

	// Properties
	public object ExtraStore { get; set; }
	public object RevocationFlag { get; }
	public object RevocationMode { get; set; }
	public object VerificationFlags { get; set; }
	public object VerificationTime { get; }

	// Methods

	// RVA: 0x71C8C20
	public object .ctor() { }

	// RVA: 0x71CABFC
	public object get_ExtraStore() { }

	// RVA: 0x71CDD20
	internal object set_ExtraStore(object value) { }

	// RVA: 0x71CDD28
	public object get_RevocationFlag() { }

	// RVA: 0x71CDD30
	public object get_RevocationMode() { }

	// RVA: 0x71CDD38
	public object set_RevocationMode(object value) { }

	// RVA: 0x71CDD9C
	public object get_VerificationFlags() { }

	// RVA: 0x71CDDA4
	public object set_VerificationFlags(object value) { }

	// RVA: 0x71CDE08
	public object get_VerificationTime() { }

	// RVA: 0x71CDC24
	public object Reset() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public struct X509ChainStatus
{

	// Fields
	private object status; // 0xFFFFFFFFFFFFFFF8
	private object info; // 0x0

	// Properties
	public object Status { get; set; }
	public object StatusInformation { set; }

	// Methods

	// RVA: 0x71C9950
	internal object .ctor(object flag) { }

	// RVA: 0x71CDECC
	public object get_Status() { }

	// RVA: 0x71CDEDC
	public object set_Status(object value) { }

	// RVA: 0x71CDEEC
	public object set_StatusInformation(object value) { }

	// RVA: 0x71C6D8C
	internal static object GetInformation(object flags) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509EnhancedKeyUsageExtension
{

	// Fields
	private object _enhKeyUsage; // 0x20
	private object _status; // 0x28

	// Methods

	// RVA: 0x71BF254
	public object .ctor() { }

	// RVA: 0x71CDF04
	public object .ctor(object encodedEnhancedKeyUsages, object critical) { }

	// RVA: 0x71CE284
	public object .ctor(object enhancedKeyUsages, object critical) { }

	// RVA: 0x71CE578
	public override object CopyFrom(object asnEncodedData) { }

	// RVA: 0x71CDFE4
	internal object Decode(object extension) { }

	// RVA: 0x71CE434
	internal object Encode() { }

	// RVA: 0x71CE748
	internal override object ToString(object multiLine) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public class X509Extension
{

	// Fields
	private object _critical; // 0x18

	// Properties
	public object Critical { get; set; }

	// Methods

	// RVA: 0x71CDEFC
	protected object .ctor() { }

	// RVA: 0x71CEC18
	public object .ctor(object oid, object rawData, object critical) { }

	// RVA: 0x71CEC44
	public object get_Critical() { }

	// RVA: 0x71CEC4C
	public object set_Critical(object value) { }

	// RVA: 0x71CEC54
	public override object CopyFrom(object asnEncodedData) { }

	// RVA: 0x71CEAC0
	internal object FormatUnkownData(object data) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509ExtensionCollection
{

	// Fields
	private static object Empty; // 0x0
	private object _list; // 0x8

	// Properties
	public object Count { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x71BCB7C
	public object .ctor() { }

	// RVA: 0x71BEDE8
	public object get_Count() { }

	// RVA: 0x71CED84
	public object get_IsSynchronized() { }

	// RVA: 0x71CEDD4
	public object get_SyncRoot() { }

	// RVA: 0x71BFB50
	public object get_Item(object oid) { }

	// RVA: 0x71BCF90
	public object Add(object extension) { }

	// RVA: 0x71CEDD8
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x71BEE38
	public object GetEnumerator() { }

	// RVA: 0x71CEF74
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x71CF018
	private static object .cctor() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509ExtensionEnumerator
{

	// Fields
	private object enumerator; // 0x8

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x71CEF10
	internal object .ctor(object list) { }

	// RVA: 0x71BEEDC
	public object get_Current() { }

	// RVA: 0x71CF08C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x71BF008
	public object MoveNext() { }

	// RVA: 0x71CF170
	public object Reset() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
internal static class X509Helper2
{

	// Methods

	// RVA: 0x71CC3B0
	internal static object GetMonoCertificate(object certificate) { }

	// RVA: 0x71C6630
	internal static object CreateChainImpl(object useMachineContext) { }

	// RVA: 0x71CF254
	public static object IsValid(object impl) { }

	// RVA: 0x71C64E8
	internal static object ThrowIfContextInvalid(object impl) { }

	// RVA: 0x71C89C4
	internal static object GetInvalidChainContextException() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509KeyUsageExtension
{

	// Fields
	internal const object oid;
	internal const object friendlyName;
	internal const object all;
	private object _keyUsages; // 0x1C
	private object _status; // 0x20

	// Properties
	public object KeyUsages { get; }

	// Methods

	// RVA: 0x71BF1AC
	public object .ctor() { }

	// RVA: 0x71CF29C
	public object .ctor(object encodedKeyUsage, object critical) { }

	// RVA: 0x71CF5BC
	public object .ctor(object keyUsages, object critical) { }

	// RVA: 0x71C186C
	public object get_KeyUsages() { }

	// RVA: 0x71CF884
	public override object CopyFrom(object asnEncodedData) { }

	// RVA: 0x71CF69C
	internal object GetValidFlags(object flags) { }

	// RVA: 0x71CF37C
	internal object Decode(object extension) { }

	// RVA: 0x71CF6AC
	internal object Encode() { }

	// RVA: 0x71CFA54
	internal override object ToString(object multiLine) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509Store
{

	// Fields
	private object _name; // 0x8
	private object _location; // 0x10
	private object list; // 0x18
	private object _flags; // 0x20
	private object store; // 0x28

	// Properties
	public object Certificates { get; }
	private object Factory { get; }
	internal object Store { get; }

	// Methods

	// RVA: 0x71CA474
	public object .ctor(object storeName, object storeLocation) { }

	// RVA: 0x71C9F98
	public object get_Certificates() { }

	// RVA: 0x71D0094
	private object get_Factory() { }

	// RVA: 0x71D00B0
	internal object get_Store() { }

	// RVA: 0x71C9AD8
	public object Close() { }

	// RVA: 0x71D00B8
	public object Dispose() { }

	// RVA: 0x71CA5AC
	public object Open(object flags) { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public sealed class X509SubjectKeyIdentifierExtension
{

	// Fields
	internal const object oid;
	internal const object friendlyName;
	private object _subjectKeyIdentifier; // 0x20
	private object _ski; // 0x28
	private object _status; // 0x30

	// Properties
	public object SubjectKeyIdentifier { get; }

	// Methods

	// RVA: 0x71BF2FC
	public object .ctor() { }

	// RVA: 0x71D00D0
	public object .ctor(object encodedSubjectKeyIdentifier, object critical) { }

	// RVA: 0x71D0374
	public object .ctor(object subjectKeyIdentifier, object critical) { }

	// RVA: 0x71D0668
	public object .ctor(object subjectKeyIdentifier, object critical) { }

	// RVA: 0x71D09FC
	public object .ctor(object key, object critical) { }

	// RVA: 0x71BFF84
	public object .ctor(object key, object algorithm, object critical) { }

	// RVA: 0x71C0444
	public object get_SubjectKeyIdentifier() { }

	// RVA: 0x71D0A08
	public override object CopyFrom(object asnEncodedData) { }

	// RVA: 0x71D0BD8
	internal static object FromHexChar(object c) { }

	// RVA: 0x71D0C18
	internal static object FromHexChars(object c1, object c2) { }

	// RVA: 0x71D0854
	internal static object FromHex(object hex) { }

	// RVA: 0x71D01B0
	internal object Decode(object extension) { }

	// RVA: 0x71D05CC
	internal object Encode() { }

	// RVA: 0x71D0CB4
	internal override object ToString(object multiLine) { }

}

// Namespace: 
private enum StateFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object CaptureIdentity;
	public const object CaptureContext;
	public const object ThreadSafeContextCopy;
	public const object PostBlockStarted;
	public const object PostBlockFinished;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__17_0; // 0x8

	// Methods

	// RVA: 0x71D2438
	private static object .cctor() { }

	// RVA: 0x71D2498
	public object .ctor() { }

	// RVA: 0x71D24A0
	internal object <Complete>b__17_0(object s) { }

}

// Namespace: System.Net
internal class ContextAwareResult
{

	// Fields
	private object _context; // 0x38
	private object _lock; // 0x40
	private object _flags; // 0x48

	// Methods

	// RVA: 0x71D0F94
	private object SafeCaptureIdentity() { }

	// RVA: 0x71D0F98
	private object CleanupInternal() { }

	// RVA: 0x71D0F9C
	internal object .ctor(object myObject, object myState, object myCallBack) { }

	// RVA: 0x71D0FA4
	internal object .ctor(object captureIdentity, object forceCaptureContext, object myObject, object myState, object myCallBack) { }

	// RVA: 0x71D1014
	internal object .ctor(object captureIdentity, object forceCaptureContext, object threadSafeContextCopy, object myObject, object myState, object myCallBack) { }

	// RVA: 0x71D109C
	internal object StartPostingAsyncOp() { }

	// RVA: 0x71D10A4
	internal object StartPostingAsyncOp(object lockCapture) { }

	// RVA: 0x71D13A0
	internal object FinishPostingAsyncOp() { }

	// RVA: 0x71D19F4
	protected override object Cleanup() { }

	// RVA: 0x71D13E8
	private object CaptureOrComplete(object cachedContext, object returnContext) { }

	// RVA: 0x71D1F64
	protected override object Complete(object userToken) { }

	// RVA: 0x71D2300
	private object CompleteCallback() { }

}

// Namespace: System.Net
internal static class HttpStatusDescription
{

	// Methods

	// RVA: 0x71D252C
	internal static object Get(object code) { }

	// RVA: 0x71D2530
	internal static object Get(object code) { }

}

// Namespace: System.Net
internal static class HttpValidationHelpers
{

	// Fields
	private static readonly object s_httpTrimCharacters; // 0x0

	// Methods

	// RVA: 0x71D2E20
	public static object IsInvalidMethodOrHeaderString(object stringValue) { }

	// RVA: 0x71D2F4C
	private static object .cctor() { }

}

// Namespace: 
public class Keywords
{

	// Fields
	public const object Default;
	public const object Debug;
	public const object EnterExit;
}

// Namespace: System.Net
internal sealed class NetEventSource
{

	// Fields
	public static readonly object Log; // 0x0

	// Properties
	public static object IsEnabled { get; }

	// Methods

	// RVA: 0x71D2FE4
	public static object Enter(object thisOrContextObject, object formattableString, object memberName) { }

	// RVA: 0x71D37F8
	public static object Enter(object thisOrContextObject, object arg0, object memberName) { }

	// RVA: 0x71D3E58
	public static object Enter(object thisOrContextObject, object arg0, object arg1, object arg2, object memberName) { }

	// RVA: 0x71D3764
	private object Enter(object thisOrContextObject, object memberName, object parameters) { }

	// RVA: 0x71D4044
	public static object Exit(object thisOrContextObject, object formattableString, object memberName) { }

	// RVA: 0x71D42B4
	public static object Exit(object thisOrContextObject, object arg0, object memberName) { }

	// RVA: 0x71D4220
	private object Exit(object thisOrContextObject, object memberName, object result) { }

	// RVA: 0x71D1BB8
	public static object Info(object thisOrContextObject, object formattableString, object memberName) { }

	// RVA: 0x71D1D94
	public static object Info(object thisOrContextObject, object message, object memberName) { }

	// RVA: 0x71D4484
	private object Info(object thisOrContextObject, object memberName, object message) { }

	// RVA: 0x71D4518
	public static object Error(object thisOrContextObject, object message, object memberName) { }

	// RVA: 0x71D46E8
	private object ErrorMessage(object thisOrContextObject, object memberName, object message) { }

	// RVA: 0x71D11D0
	public static object Fail(object thisOrContextObject, object message, object memberName) { }

	// RVA: 0x71D477C
	private object CriticalFailure(object thisOrContextObject, object memberName, object message) { }

	// RVA: 0x71D4810
	public static object Associate(object first, object second, object memberName) { }

	// RVA: 0x71D49BC
	private object Associate(object thisOrContextObject, object memberName, object first, object second) { }

	// RVA: 0x71D1B30
	public static object get_IsEnabled() { }

	// RVA: 0x71D31C0
	public static object IdOf(object value) { }

	// RVA: 0x71D4C98
	public static object GetHashCode(object value) { }

	// RVA: 0x71D39B0
	public static object Format(object value) { }

	// RVA: 0x71D32FC
	private static object Format(object s) { }

	// RVA: 0x71D4A54
	private object WriteEvent(object eventId, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x71D4CE0
	public object .ctor() { }

	// RVA: 0x71D4CE8
	private static object .cctor() { }

}

// Namespace: System.Net
internal static class TcpValidationHelpers
{

	// Methods

	// RVA: 0x71D4D48
	public static object ValidatePortNumber(object port) { }

}

// Namespace: System.Net
internal class TlsStream
{

	// Fields
	private object _sslStream; // 0x40
	private object _host; // 0x48
	private object _clientCertificates; // 0x50

	// Methods

	// RVA: 0x71D4D54
	public object .ctor(object stream, object socket, object host, object clientCertificates) { }

	// RVA: 0x71D4E28
	public object AuthenticateAsClient() { }

	// RVA: 0x71D4F98
	public object BeginAuthenticateAsClient(object asyncCallback, object state) { }

	// RVA: 0x71D5120
	public object EndAuthenticateAsClient(object asyncResult) { }

	// RVA: 0x71D5178
	public override object BeginWrite(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x71D5200
	public override object EndWrite(object result) { }

	// RVA: 0x71D5258
	public override object Write(object buffer, object offset, object size) { }

	// RVA: 0x71D52C8
	public override object Read(object buffer, object offset, object size) { }

	// RVA: 0x71D5338
	public override object BeginRead(object buffer, object offset, object count, object callback, object state) { }

	// RVA: 0x71D53C0
	public override object EndRead(object asyncResult) { }

	// RVA: 0x71D5418
	public override object Close() { }

}

// Namespace: System.Net
public enum HttpStatusCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Continue;
	public const object SwitchingProtocols;
	public const object Processing;
	public const object EarlyHints;
	public const object OK;
	public const object Created;
	public const object Accepted;
	public const object NonAuthoritativeInformation;
	public const object NoContent;
	public const object ResetContent;
	public const object PartialContent;
	public const object MultiStatus;
	public const object AlreadyReported;
	public const object IMUsed;
	public const object MultipleChoices;
	public const object Ambiguous;
	public const object MovedPermanently;
	public const object Moved;
	public const object Found;
	public const object Redirect;
	public const object SeeOther;
	public const object RedirectMethod;
	public const object NotModified;
	public const object UseProxy;
	public const object Unused;
	public const object TemporaryRedirect;
	public const object RedirectKeepVerb;
	public const object PermanentRedirect;
	public const object BadRequest;
	public const object Unauthorized;
	public const object PaymentRequired;
	public const object Forbidden;
	public const object NotFound;
	public const object MethodNotAllowed;
	public const object NotAcceptable;
	public const object ProxyAuthenticationRequired;
	public const object RequestTimeout;
	public const object Conflict;
	public const object Gone;
	public const object LengthRequired;
	public const object PreconditionFailed;
	public const object RequestEntityTooLarge;
	public const object RequestUriTooLong;
	public const object UnsupportedMediaType;
	public const object RequestedRangeNotSatisfiable;
	public const object ExpectationFailed;
	public const object MisdirectedRequest;
	public const object UnprocessableEntity;
	public const object Locked;
	public const object FailedDependency;
	public const object UpgradeRequired;
	public const object PreconditionRequired;
	public const object TooManyRequests;
	public const object RequestHeaderFieldsTooLarge;
	public const object UnavailableForLegalReasons;
	public const object InternalServerError;
	public const object NotImplemented;
	public const object BadGateway;
	public const object ServiceUnavailable;
	public const object GatewayTimeout;
	public const object HttpVersionNotSupported;
	public const object VariantAlsoNegotiates;
	public const object InsufficientStorage;
	public const object LoopDetected;
	public const object NotExtended;
	public const object NetworkAuthenticationRequired;
}

// Namespace: System.Net
public class HttpVersion
{

	// Fields
	public static readonly object Unknown; // 0x0
	public static readonly object Version10; // 0x8
	public static readonly object Version11; // 0x10
	public static readonly object Version20; // 0x18

	// Methods

	// RVA: 0x71D5474
	private static object .cctor() { }

}

// Namespace: 
private sealed class ReadOnlyIPAddress
{

	// Methods

	// RVA: 0x71D73DC
	public object .ctor(object newAddress) { }

}

// Namespace: System.Net
public class IPAddress
{

	// Fields
	public static readonly object Any; // 0x0
	public static readonly object Loopback; // 0x8
	public static readonly object Broadcast; // 0x10
	public static readonly object None; // 0x18
	internal const object LoopbackMask;
	public static readonly object IPv6Any; // 0x20
	public static readonly object IPv6Loopback; // 0x28
	public static readonly object IPv6None; // 0x30
	private object _addressOrScopeId; // 0x8
	private readonly object _numbers; // 0x10
	private object _toString; // 0x18
	private object _hashCode; // 0x20
	internal const object NumberOfLabels;

	// Properties
	private object IsIPv4 { get; }
	private object IsIPv6 { get; }
	private object PrivateAddress { get; set; }
	private object PrivateScopeId { get; set; }
	public object AddressFamily { get; }
	public object ScopeId { get; }

	// Methods

	// RVA: 0x71D5570
	private object get_IsIPv4() { }

	// RVA: 0x71D5580
	private object get_IsIPv6() { }

	// RVA: 0x71D5590
	private object get_PrivateAddress() { }

	// RVA: 0x71D5598
	private object set_PrivateAddress(object value) { }

	// RVA: 0x71D55A8
	private object get_PrivateScopeId() { }

	// RVA: 0x71D55B0
	private object set_PrivateScopeId(object value) { }

	// RVA: 0x71D55C0
	public object .ctor(object newAddress) { }

	// RVA: 0x71D5644
	public object .ctor(object address, object scopeid) { }

	// RVA: 0x71D5768
	public object .ctor(object address, object scopeid) { }

	// RVA: 0x71D5984
	internal object .ctor(object numbers, object numbersLength, object scopeid) { }

	// RVA: 0x71D5A38
	private object .ctor(object numbers, object scopeid) { }

	// RVA: 0x71D5A78
	public static object TryParse(object ipString, object address) { }

	// RVA: 0x71D5D98
	public static object Parse(object ipString) { }

	// RVA: 0x71D5E34
	public object TryWriteBytes(object destination, object bytesWritten) { }

	// RVA: 0x71D6178
	private object WriteIPv6Bytes(object destination) { }

	// RVA: 0x71D63E4
	private object WriteIPv4Bytes(object destination) { }

	// RVA: 0x71D6434
	public object GetAddressBytes() { }

	// RVA: 0x71D653C
	public object get_AddressFamily() { }

	// RVA: 0x71D6554
	public object get_ScopeId() { }

	// RVA: 0x71D65A8
	public override object ToString() { }

	// RVA: 0x71D66DC
	public static object HostToNetworkOrder(object host) { }

	// RVA: 0x71D66E4
	public static object HostToNetworkOrder(object host) { }

	// RVA: 0x71D66EC
	public static object HostToNetworkOrder(object host) { }

	// RVA: 0x71D66F8
	public static object NetworkToHostOrder(object network) { }

	// RVA: 0x71D6778
	public static object NetworkToHostOrder(object network) { }

	// RVA: 0x71D67F8
	public static object NetworkToHostOrder(object network) { }

	// RVA: 0x71D6880
	public static object IsLoopback(object address) { }

	// RVA: 0x71D69B8
	internal object Equals(object comparandObj, object compareScopeId) { }

	// RVA: 0x71D6BBC
	public override object Equals(object comparand) { }

	// RVA: 0x71D6BC4
	public override object GetHashCode() { }

	// RVA: 0x71D7088
	public object MapToIPv6() { }

	// RVA: 0x71D5714
	private static object ThrowAddressNullException() { }

	// RVA: 0x71D7184
	private static object .cctor() { }

}

// Namespace: System.Net
internal class IPAddressParser
{

	// Methods

	// RVA: 0x71D5AFC
	internal static object Parse(object ipSpan, object tryParse) { }

	// RVA: 0x71D666C
	internal static object IPv4AddressToString(object address) { }

	// RVA: 0x71D79E0
	internal static object IPv4AddressToString(object address, object destination) { }

	// RVA: 0x71D7700
	private static object IPv4AddressToStringHelper(object address, object addressString) { }

	// RVA: 0x71D6654
	internal static object IPv6AddressToString(object address, object scopeId) { }

	// RVA: 0x71D7B40
	internal static object IPv6AddressToStringHelper(object address, object scopeId) { }

	// RVA: 0x71D7A68
	private static object FormatIPv4AddressNumber(object number, object addressString, object offset) { }

	// RVA: 0x71D7640
	public static object Ipv4StringToAddress(object ipSpan, object address) { }

	// RVA: 0x71D74C4
	public static object Ipv6StringToAddress(object ipSpan, object numbers, object numbersLength, object scope) { }

	// RVA: 0x71D7CFC
	private static object AppendSections(object address, object fromInclusive, object toExclusive, object buffer) { }

	// RVA: 0x71D80B4
	private static object AppendHex(object value, object buffer) { }

	// RVA: 0x71D8074
	private static object ExtractIPv4Address(object address) { }

	// RVA: 0x71D8158
	private static object Reverse(object number) { }

}

// Namespace: System.Net
public class IPEndPoint
{

	// Fields
	private object _address; // 0x8
	private object _port; // 0x10
	internal static object Any; // 0x0
	internal static object IPv6Any; // 0x8

	// Properties
	public override object AddressFamily { get; }
	public object Address { get; }
	public object Port { get; }

	// Methods

	// RVA: 0x71D8160
	public override object get_AddressFamily() { }

	// RVA: 0x71D8194
	public object .ctor(object address, object port) { }

	// RVA: 0x71D826C
	public object get_Address() { }

	// RVA: 0x71D8274
	public object get_Port() { }

	// RVA: 0x71D827C
	public override object ToString() { }

	// RVA: 0x71D8370
	public override object Serialize() { }

	// RVA: 0x71D83E4
	public override object Create(object socketAddress) { }

	// RVA: 0x71D8628
	public override object Equals(object comparand) { }

	// RVA: 0x71D8724
	public override object GetHashCode() { }

	// RVA: 0x71D8780
	private static object .cctor() { }

}

// Namespace: 
internal enum PipelineInstruction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Abort;
	public const object Advance;
	public const object Pause;
	public const object Reread;
	public const object GiveStream;
}

// Namespace: 
internal enum PipelineEntryFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UserCommand;
	public const object GiveDataStream;
	public const object CreateDataConnection;
	public const object DontLogParameter;
}

// Namespace: 
internal class PipelineEntry
{

	// Fields
	internal object Command; // 0x8
	internal object Flags; // 0x10

	// Methods

	// RVA: 0x71DB178
	internal object .ctor(object command) { }

	// RVA: 0x71DB1A4
	internal object .ctor(object command, object flags) { }

	// RVA: 0x71D993C
	internal object HasFlag(object flags) { }

}

// Namespace: System.Net
internal class CommandStream
{

	// Fields
	private static readonly object s_writeCallbackDelegate; // 0x0
	private static readonly object s_readCallbackDelegate; // 0x8
	private object _recoverableFailure; // 0x30
	protected object _request; // 0x38
	protected object _isAsync; // 0x40
	private object _aborted; // 0x41
	protected object _commands; // 0x48
	protected object _index; // 0x50
	private object _doRead; // 0x54
	private object _doSend; // 0x55
	private object _currentResponseDescription; // 0x58
	protected object _abortReason; // 0x60
	private object _buffer; // 0x68
	private object _encoding; // 0x70
	private object _decoder; // 0x78

	// Properties
	internal object RecoverableFailure { get; }
	protected object Encoding { get; set; }

	// Methods

	// RVA: 0x71D88A0
	internal object .ctor(object client) { }

	// RVA: 0x71D895C
	internal virtual object Abort(object e) { }

	// RVA: 0x71D8CAC
	protected override object Dispose(object disposing) { }

	// RVA: 0x71D8E34
	protected object InvokeRequestCallback(object obj) { }

	// RVA: 0x71D8EBC
	internal object get_RecoverableFailure() { }

	// RVA: 0x71D8EC4
	protected object MarkAsRecoverableFailure() { }

	// RVA: 0x71D8EDC
	internal object SubmitRequest(object request, object isAsync, object readInitalResponseOnConnect) { }

	// RVA: 0x71D96C8
	protected virtual object ClearState() { }

	// RVA: 0x71D9740
	protected virtual object BuildCommandsList(object request) { }

	// RVA: 0x71D9748
	protected object GenerateException(object message, object status, object innerException) { }

	// RVA: 0x71D97CC
	protected object GenerateException(object code, object statusDescription, object innerException) { }

	// RVA: 0x71D8FE0
	protected object InitCommandPipeline(object request, object commands, object isAsync) { }

	// RVA: 0x71D9888
	internal object CheckContinuePipeline() { }

	// RVA: 0x71D9070
	protected object ContinueCommandPipeline() { }

	// RVA: 0x71D994C
	private object PostSendCommandProcessing(object stream) { }

	// RVA: 0x71D9E70
	private object PostReadCommandProcessing(object stream) { }

	// RVA: 0x71DA140
	protected virtual object PipelineCallback(object entry, object response, object timeout, object stream) { }

	// RVA: 0x71DA148
	private static object ReadCallback(object asyncResult) { }

	// RVA: 0x71DAC10
	private static object WriteCallback(object asyncResult) { }

	// RVA: 0x71DAF38
	protected object get_Encoding() { }

	// RVA: 0x71DAF40
	protected object set_Encoding(object value) { }

	// RVA: 0x71DAFA0
	protected virtual object CheckValid(object response, object validThrough, object completeLength) { }

	// RVA: 0x71D9AA8
	private object ReceiveCommandResponse() { }

	// RVA: 0x71DA4C0
	private object ReceiveCommandResponseCallback(object state, object bytesRead) { }

	// RVA: 0x71DB09C
	private static object .cctor() { }

}

// Namespace: System.Net
internal class ResponseDescription
{

	// Fields
	internal object Multiline; // 0x8
	internal object Status; // 0xC
	internal object StatusDescription; // 0x10
	internal object StatusBuffer; // 0x18
	internal object StatusCodeString; // 0x20

	// Properties
	internal object PositiveIntermediate { get; }
	internal object PositiveCompletion { get; }
	internal object TransientFailure { get; }
	internal object PermanentFailure { get; }
	internal object InvalidStatusCode { get; }

	// Methods

	// RVA: 0x71DB1E0
	internal object get_PositiveIntermediate() { }

	// RVA: 0x71DB1F4
	internal object get_PositiveCompletion() { }

	// RVA: 0x71DB208
	internal object get_TransientFailure() { }

	// RVA: 0x71DB21C
	internal object get_PermanentFailure() { }

	// RVA: 0x71DB230
	internal object get_InvalidStatusCode() { }

	// RVA: 0x71DB244
	public object .ctor() { }

}

// Namespace: System.Net
internal class ReceiveState
{

	// Fields
	internal object Resp; // 0x8
	internal object ValidThrough; // 0x10
	internal object Buffer; // 0x18
	internal object Connection; // 0x20

	// Methods

	// RVA: 0x71DAFA8
	internal object .ctor(object connection) { }

}

// Namespace: System.Net
internal enum FtpLoginState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NotLoggedIn;
	public const object LoggedIn;
	public const object LoggedInButNeedsRelogin;
	public const object ReloginFailed;
}

// Namespace: 
private enum GetPathOption
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object AssumeFilename;
	public const object AssumeNoFilename;
}

// Namespace: 
private sealed class <>c__DisplayClass31_0
{

	// Fields
	public object <>4__this; // 0x8
	public object tlsStream; // 0x10

	// Methods

	// RVA: 0x71E0A7C
	public object .ctor() { }

	// RVA: 0x71E0A84
	internal object <PipelineCallback>b__0(object ar) { }

}

// Namespace: System.Net
internal class FtpControlStream
{

	// Fields
	private object _dataSocket; // 0x80
	private object _passiveEndPoint; // 0x88
	private object _tlsStream; // 0x90
	private object _bannerMessage; // 0x98
	private object _welcomeMessage; // 0xA0
	private object _exitMessage; // 0xA8
	private object _credentials; // 0xB0
	private object _currentTypeSetting; // 0xB8
	private object _contentLength; // 0xC0
	private object _lastModified; // 0xC8
	private object _dataHandshakeStarted; // 0xD0
	private object _loginDirectory; // 0xD8
	private object _establishedServerDirectory; // 0xE0
	private object _requestedServerDirectory; // 0xE8
	private object _responseUri; // 0xF0
	private object _loginState; // 0xF8
	internal object StatusCode; // 0xFC
	internal object StatusLine; // 0x100
	private static readonly object s_acceptCallbackDelegate; // 0x0
	private static readonly object s_connectCallbackDelegate; // 0x8
	private static readonly object s_SSLHandshakeCallback; // 0x10

	// Properties
	internal object Credentials { get; set; }
	internal object ContentLength { get; }
	internal object LastModified { get; }
	internal object ResponseUri { get; }
	internal object BannerMessage { get; }
	internal object WelcomeMessage { get; }
	internal object ExitMessage { get; }

	// Methods

	// RVA: 0x71DB2B8
	internal object get_Credentials() { }

	// RVA: 0x71DB3A8
	internal object set_Credentials(object value) { }

	// RVA: 0x71DB450
	internal object .ctor(object client) { }

	// RVA: 0x71DB4E8
	internal object AbortConnect() { }

	// RVA: 0x71DB588
	private static object AcceptCallback(object asyncResult) { }

	// RVA: 0x71DB9D8
	private static object ConnectCallback(object asyncResult) { }

	// RVA: 0x71DBBF4
	private static object SSLHandshakeCallback(object asyncResult) { }

	// RVA: 0x71DBE44
	private object QueueOrCreateFtpDataStream(object stream) { }

	// RVA: 0x71DC2E8
	protected override object ClearState() { }

	// RVA: 0x71DC3C8
	protected override object PipelineCallback(object entry, object response, object timeout, object stream) { }

	// RVA: 0x71DE1C0
	protected override object BuildCommandsList(object req) { }

	// RVA: 0x71DCDD8
	private object QueueOrCreateDataConection(object entry, object response, object timeout, object stream, object isSocketReady) { }

	// RVA: 0x71DF5B8
	private static object GetPathInfo(object pathOption, object uri, object path, object directory, object filename) { }

	// RVA: 0x71E00F4
	private object FormatAddress(object address, object Port) { }

	// RVA: 0x71E0258
	private object FormatAddressV6(object address, object port) { }

	// RVA: 0x71E03B0
	internal object get_ContentLength() { }

	// RVA: 0x71E03B8
	internal object get_LastModified() { }

	// RVA: 0x71E03C0
	internal object get_ResponseUri() { }

	// RVA: 0x71E03C8
	internal object get_BannerMessage() { }

	// RVA: 0x71E0418
	internal object get_WelcomeMessage() { }

	// RVA: 0x71E0468
	internal object get_ExitMessage() { }

	// RVA: 0x71DDBF4
	private object GetContentLengthFrom213Response(object responseString) { }

	// RVA: 0x71DDD48
	private object GetLastModifiedFrom213Response(object str) { }

	// RVA: 0x71DD7EC
	private object TryUpdateResponseUri(object str, object request) { }

	// RVA: 0x71DD6F0
	private object TryUpdateContentLength(object str) { }

	// RVA: 0x71DE104
	private object GetLoginDirectory(object str) { }

	// RVA: 0x71DFC54
	private object GetPortV4(object responseString) { }

	// RVA: 0x71DFE48
	private object GetPortV6(object responseString) { }

	// RVA: 0x71DF7A8
	private object CreateFtpListenerSocket(object request) { }

	// RVA: 0x71DFA18
	private object GetPortCommandLine(object request) { }

	// RVA: 0x71DF48C
	private object FormatFtpCommand(object command, object parameter) { }

	// RVA: 0x71E0020
	protected object CreateFtpDataSocket(object request, object templateSocket) { }

	// RVA: 0x71E04B8
	protected override object CheckValid(object response, object validThrough, object completeLength) { }

	// RVA: 0x71DC228
	private object IsFtpDataStreamWriteable() { }

	// RVA: 0x71E0964
	private static object .cctor() { }

}

// Namespace: System.Net
internal class FtpDataStream
{

	// Fields
	private object _request; // 0x20
	private object _networkStream; // 0x28
	private object _writeable; // 0x30
	private object _readable; // 0x31
	private object _isFullyRead; // 0x32
	private object _closing; // 0x33

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }
	public override object CanTimeout { get; }
	public override object ReadTimeout { get; set; }
	public override object WriteTimeout { get; set; }

	// Methods

	// RVA: 0x71E0C14
	internal object .ctor(object networkStream, object request, object writeOnly) { }

	// RVA: 0x71E0D74
	protected override object Dispose(object disposing) { }

	// RVA: 0x71E0F2C
	private object System.Net.ICloseEx.CloseEx(object closeState) { }

	// RVA: 0x71E1408
	private object CheckError() { }

	// RVA: 0x71E155C
	public override object get_CanRead() { }

	// RVA: 0x71E1564
	public override object get_CanSeek() { }

	// RVA: 0x71E15B0
	public override object get_CanWrite() { }

	// RVA: 0x71E15B8
	public override object get_Length() { }

	// RVA: 0x71E1604
	public override object get_Position() { }

	// RVA: 0x71E1654
	public override object set_Position(object value) { }

	// RVA: 0x71E16AC
	public override object Seek(object offset, object origin) { }

	// RVA: 0x71E17E8
	public override object Read(object buffer, object offset, object size) { }

	// RVA: 0x71E1984
	public override object Write(object buffer, object offset, object size) { }

	// RVA: 0x71E1ACC
	private object AsyncReadCallback(object ar) { }

	// RVA: 0x71E1EA0
	public override object BeginRead(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x71E217C
	public override object EndRead(object ar) { }

	// RVA: 0x71E23F4
	public override object BeginWrite(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x71E2558
	public override object EndWrite(object asyncResult) { }

	// RVA: 0x71E266C
	public override object Flush() { }

	// RVA: 0x71E26BC
	public override object SetLength(object value) { }

	// RVA: 0x71E2714
	public override object get_CanTimeout() { }

	// RVA: 0x71E2760
	public override object get_ReadTimeout() { }

	// RVA: 0x71E27B0
	public override object set_ReadTimeout(object value) { }

	// RVA: 0x71E2808
	public override object get_WriteTimeout() { }

	// RVA: 0x71E2858
	public override object set_WriteTimeout(object value) { }

	// RVA: 0x71E28B0
	internal object SetSocketTimeoutOption(object timeout) { }

}

// Namespace: System.Net
internal enum FtpOperation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DownloadFile;
	public const object ListDirectory;
	public const object ListDirectoryDetails;
	public const object UploadFile;
	public const object UploadFileUnique;
	public const object AppendFile;
	public const object DeleteFile;
	public const object GetDateTimestamp;
	public const object GetFileSize;
	public const object Rename;
	public const object MakeDirectory;
	public const object RemoveDirectory;
	public const object PrintWorkingDirectory;
	public const object Other;
}

// Namespace: System.Net
internal enum FtpMethodFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object IsDownload;
	public const object IsUpload;
	public const object TakesParameter;
	public const object MayTakeParameter;
	public const object DoesNotTakeParameter;
	public const object ParameterIsDirectory;
	public const object ShouldParseForResponseUri;
	public const object HasHttpCommand;
	public const object MustChangeWorkingDirectoryToPath;
}

// Namespace: System.Net
internal class FtpMethodInfo
{

	// Fields
	internal object Method; // 0x8
	internal object Operation; // 0x10
	internal object Flags; // 0x14
	internal object HttpCommand; // 0x18
	private static readonly object s_knownMethodInfo; // 0x0

	// Properties
	internal object IsCommandOnly { get; }
	internal object IsUpload { get; }
	internal object IsDownload { get; }
	internal object ShouldParseForResponseUri { get; }

	// Methods

	// RVA: 0x71E2954
	internal object .ctor(object method, object operation, object flags, object httpCommand) { }

	// RVA: 0x71E29A4
	internal object HasFlag(object flags) { }

	// RVA: 0x71E29B4
	internal object get_IsCommandOnly() { }

	// RVA: 0x71E29C4
	internal object get_IsUpload() { }

	// RVA: 0x71E29D0
	internal object get_IsDownload() { }

	// RVA: 0x71E29DC
	internal object get_ShouldParseForResponseUri() { }

	// RVA: 0x71E29E8
	internal static object GetMethodInfo(object method) { }

	// RVA: 0x71E2B7C
	private static object .cctor() { }

}

// Namespace: 
private enum RequestStage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CheckForError;
	public const object RequestStarted;
	public const object WriteReady;
	public const object ReadReady;
	public const object ReleaseConnection;
}

// Namespace: 
private struct <CreateConnectionAsync>d__86
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x20
	private object <client>5__2; // 0x28
	private object <>u__1; // 0x30

	// Methods

	// RVA: 0x71EA55C
	private object MoveNext() { }

	// RVA: 0x71EA910
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__114_0; // 0x8

	// Methods

	// RVA: 0x71EA928
	private static object .cctor() { }

	// RVA: 0x71EA988
	public object .ctor() { }

	// RVA: 0x71EA990
	internal object <get_ClientCertificates>b__114_0() { }

}

// Namespace: System.Net
public sealed class FtpWebRequest
{

	// Fields
	private object _syncObject; // 0x30
	private object _authInfo; // 0x38
	private readonly object _uri; // 0x40
	private object _methodInfo; // 0x48
	private object _renameTo; // 0x50
	private object _getRequestStreamStarted; // 0x58
	private object _getResponseStarted; // 0x59
	private object _startTime; // 0x60
	private object _timeout; // 0x68
	private object _remainingTimeout; // 0x6C
	private object _contentLength; // 0x70
	private object _contentOffset; // 0x78
	private object _clientCertificates; // 0x80
	private object _passive; // 0x88
	private object _binary; // 0x89
	private object _async; // 0x8A
	private object _aborted; // 0x8B
	private object _timedOut; // 0x8C
	private object _exception; // 0x90
	private object _timerQueue; // 0x98
	private object _timerCallback; // 0xA0
	private object _enableSsl; // 0xA8
	private object _connection; // 0xB0
	private object _stream; // 0xB8
	private object _requestStage; // 0xC0
	private object _onceFailed; // 0xC4
	private object _ftpRequestHeaders; // 0xC8
	private object _ftpWebResponse; // 0xD0
	private object _readWriteTimeout; // 0xD8
	private object _writeAsyncResult; // 0xE0
	private object _readAsyncResult; // 0xE8
	private object _requestCompleteAsyncResult; // 0xF0
	private static readonly object s_defaultFtpNetworkCredential; // 0x0
	private static readonly object s_DefaultTimerQueue; // 0x8

	// Properties
	internal object MethodInfo { get; }
	public override object Method { get; set; }
	public object RenameTo { get; }
	public override object Credentials { get; set; }
	public override object RequestUri { get; }
	public override object Timeout { get; }
	internal object RemainingTimeout { get; }
	public object ReadWriteTimeout { get; }
	public object ContentOffset { get; }
	public override object ContentLength { get; }
	public override object Proxy { get; set; }
	internal object Aborted { get; }
	private object TimerQueue { get; }
	public override object CachePolicy { set; }
	public object UseBinary { get; }
	public object UsePassive { get; }
	public object ClientCertificates { get; }
	public object EnableSsl { get; }
	public override object Headers { get; }
	public override object UseDefaultCredentials { get; }
	private object InUse { get; }

	// Methods

	// RVA: 0x71E314C
	internal object get_MethodInfo() { }

	// RVA: 0x71E3154
	public override object get_Method() { }

	// RVA: 0x71E3178
	public override object set_Method(object value) { }

	// RVA: 0x71E3360
	public object get_RenameTo() { }

	// RVA: 0x71E3368
	public override object get_Credentials() { }

	// RVA: 0x71E3370
	public override object set_Credentials(object value) { }

	// RVA: 0x71E3508
	public override object get_RequestUri() { }

	// RVA: 0x71E3510
	public override object get_Timeout() { }

	// RVA: 0x71E3518
	internal object get_RemainingTimeout() { }

	// RVA: 0x71E3520
	public object get_ReadWriteTimeout() { }

	// RVA: 0x71E3528
	public object get_ContentOffset() { }

	// RVA: 0x71E3530
	public override object get_ContentLength() { }

	// RVA: 0x71E3538
	public override object get_Proxy() { }

	// RVA: 0x71E3540
	public override object set_Proxy(object value) { }

	// RVA: 0x71E35AC
	internal object get_Aborted() { }

	// RVA: 0x71E35B4
	internal object .ctor(object uri) { }

	// RVA: 0x71E3C14
	public override object GetResponse() { }

	// RVA: 0x71E5B98
	public override object BeginGetResponse(object callback, object state) { }

	// RVA: 0x71E63C4
	public override object EndGetResponse(object asyncResult) { }

	// RVA: 0x71E4A74
	private object SubmitRequest(object isAsync) { }

	// RVA: 0x71E735C
	private object TranslateConnectException(object e) { }

	// RVA: 0x71E68B4
	private object CreateConnectionAsync() { }

	// RVA: 0x71E6950
	private object CreateConnection() { }

	// RVA: 0x71E6B84
	private object TimedSubmitRequestHelper(object isAsync) { }

	// RVA: 0x71E758C
	private object TimerCallback(object timer, object timeNoticed, object context) { }

	// RVA: 0x71E74EC
	private object get_TimerQueue() { }

	// RVA: 0x71E705C
	private object AttemptedRecovery(object e) { }

	// RVA: 0x71E56FC
	private object SetException(object exception) { }

	// RVA: 0x71E4514
	private object CheckError() { }

	// RVA: 0x71E834C
	internal object RequestCallback(object obj) { }

	// RVA: 0x71E8E28
	private object SyncRequestCallback(object obj) { }

	// RVA: 0x71E8360
	private object AsyncRequestCallback(object obj) { }

	// RVA: 0x71E45AC
	private object FinishRequestStage(object stage) { }

	// RVA: 0x71E96EC
	public override object Abort() { }

	// RVA: 0x71E9C80
	public override object set_CachePolicy(object value) { }

	// RVA: 0x71E9CEC
	public object get_UseBinary() { }

	// RVA: 0x71E9CF4
	public object get_UsePassive() { }

	// RVA: 0x71E9CFC
	public object get_ClientCertificates() { }

	// RVA: 0x71E9E20
	public object get_EnableSsl() { }

	// RVA: 0x71E9E28
	public override object get_Headers() { }

	// RVA: 0x71E9F6C
	public override object get_UseDefaultCredentials() { }

	// RVA: 0x71E3340
	private object get_InUse() { }

	// RVA: 0x71E5098
	private object EnsureFtpWebResponse(object exception) { }

	// RVA: 0x71EA238
	internal object DataStreamClosed(object closeState) { }

	// RVA: 0x71EA2F0
	private static object .cctor() { }

}

// Namespace: System.Net
internal class FtpWebRequestCreator
{

	// Methods

	// RVA: 0x71EA9E8
	internal object .ctor() { }

	// RVA: 0x71EA9F0
	public object Create(object uri) { }

}

// Namespace: 
internal sealed class EmptyStream
{

	// Methods

	// RVA: 0x71EAAD4
	internal object .ctor() { }

}

// Namespace: System.Net
public class FtpWebResponse
{

	// Fields
	internal object _responseStream; // 0x18
	private object _contentLength; // 0x20
	private object _responseUri; // 0x28
	private object _statusCode; // 0x30
	private object _statusLine; // 0x38
	private object _ftpRequestHeaders; // 0x40
	private object _lastModified; // 0x48
	private object _bannerMessage; // 0x50
	private object _welcomeMessage; // 0x58
	private object _exitMessage; // 0x60

	// Properties
	public override object Headers { get; }
	public override object ResponseUri { get; }
	public object StatusCode { get; }

	// Methods

	// RVA: 0x71EA0C0
	internal object .ctor(object responseStream, object contentLength, object responseUri, object statusCode, object statusLine, object lastModified, object bannerMessage, object welcomeMessage, object exitMessage) { }

	// RVA: 0x71E833C
	internal object UpdateStatus(object statusCode, object statusLine, object exitMessage) { }

	// RVA: 0x71EAA5C
	public override object GetResponseStream() { }

	// RVA: 0x71EA020
	internal object SetResponseStream(object stream) { }

	// RVA: 0x71EABE4
	public override object Close() { }

	// RVA: 0x71EAD40
	public override object get_Headers() { }

	// RVA: 0x71EAEDC
	public override object get_ResponseUri() { }

	// RVA: 0x71EAEE4
	public object get_StatusCode() { }

}

// Namespace: System.Net
internal class NetworkStreamWrapper
{

	// Fields
	private object _client; // 0x20
	private object _networkStream; // 0x28

	// Properties
	protected object UsingSecureStream { get; }
	internal object ServerAddress { get; }
	internal object Socket { get; }
	internal object NetworkStream { get; set; }
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object CanTimeout { get; }
	public override object ReadTimeout { get; set; }
	public override object WriteTimeout { get; set; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x71EAEEC
	internal object .ctor(object client) { }

	// RVA: 0x71EAF9C
	protected object get_UsingSecureStream() { }

	// RVA: 0x71EB024
	internal object get_ServerAddress() { }

	// RVA: 0x71EB0D0
	internal object get_Socket() { }

	// RVA: 0x71EB0F4
	internal object get_NetworkStream() { }

	// RVA: 0x71EB0FC
	internal object set_NetworkStream(object value) { }

	// RVA: 0x71EB104
	public override object get_CanRead() { }

	// RVA: 0x71EB150
	public override object get_CanSeek() { }

	// RVA: 0x71EB19C
	public override object get_CanWrite() { }

	// RVA: 0x71EB1E8
	public override object get_CanTimeout() { }

	// RVA: 0x71EB234
	public override object get_ReadTimeout() { }

	// RVA: 0x71EB284
	public override object set_ReadTimeout(object value) { }

	// RVA: 0x71EB2DC
	public override object get_WriteTimeout() { }

	// RVA: 0x71EB32C
	public override object set_WriteTimeout(object value) { }

	// RVA: 0x71EB384
	public override object get_Length() { }

	// RVA: 0x71EB3D0
	public override object get_Position() { }

	// RVA: 0x71EB420
	public override object set_Position(object value) { }

	// RVA: 0x71EB478
	public override object Seek(object offset, object origin) { }

	// RVA: 0x71EB4E0
	public override object Read(object buffer, object offset, object size) { }

	// RVA: 0x71EB550
	public override object Write(object buffer, object offset, object size) { }

	// RVA: 0x71EB5C0
	protected override object Dispose(object disposing) { }

	// RVA: 0x71E0BA4
	internal object CloseSocket() { }

	// RVA: 0x71EB6F0
	public object Close(object timeout) { }

	// RVA: 0x71EB740
	public override object BeginRead(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x71EB7C8
	public override object EndRead(object asyncResult) { }

	// RVA: 0x71EB820
	public override object ReadAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x71EB8A0
	public override object BeginWrite(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x71EB928
	public override object EndWrite(object asyncResult) { }

	// RVA: 0x71EB980
	public override object WriteAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x71EBA00
	public override object Flush() { }

	// RVA: 0x71EBA50
	public override object FlushAsync(object cancellationToken) { }

	// RVA: 0x71EBAA8
	public override object SetLength(object value) { }

	// RVA: 0x71E6AE0
	internal object SetSocketTimeoutOption(object timeout) { }

}

// Namespace: System.Net
public enum SecurityProtocolType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SystemDefault;
	public const object Ssl3;
	public const object Tls;
	public const object Tls11;
	public const object Tls12;
	public const object Tls13;
}

// Namespace: System.Net
public class Authorization
{

	// Fields
	private object m_Message; // 0x8
	private object m_Complete; // 0x10
	internal object ModuleAuthenticationType; // 0x18

	// Properties
	public object Message { get; }
	public object Complete { get; }

	// Methods

	// RVA: 0x71EBB00
	public object .ctor(object token) { }

	// RVA: 0x71EBBC0
	public object .ctor(object token, object finished) { }

	// RVA: 0x71EBC74
	public object get_Message() { }

	// RVA: 0x71EBC7C
	public object get_Complete() { }

}

// Namespace: System.Net
public class CredentialCache
{

	// Properties
	public static object DefaultCredentials { get; }
	public static object DefaultNetworkCredentials { get; }

	// Methods

	// RVA: 0x71EBC84
	public static object get_DefaultCredentials() { }

	// RVA: 0x71EBD00
	public static object get_DefaultNetworkCredentials() { }

}

// Namespace: System.Net
internal class SystemNetworkCredential
{

	// Fields
	internal static readonly object defaultCredential; // 0x0

	// Methods

	// RVA: 0x71EBD7C
	private object .ctor() { }

	// RVA: 0x71EBE74
	private static object .cctor() { }

}

// Namespace: System.Net
public abstract class EndPoint
{

	// Properties
	public virtual object AddressFamily { get; }

	// Methods

	// RVA: 0x71EBED0
	public virtual object get_AddressFamily() { }

	// RVA: 0x71EBF84
	public virtual object Serialize() { }

	// RVA: 0x71EC038
	public virtual object Create(object socketAddress) { }

	// RVA: 0x71EC064
	protected object .ctor() { }

}

// Namespace: System.Net
public enum FtpStatusCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undefined;
	public const object RestartMarker;
	public const object ServiceTemporarilyNotAvailable;
	public const object DataAlreadyOpen;
	public const object OpeningData;
	public const object CommandOK;
	public const object CommandExtraneous;
	public const object DirectoryStatus;
	public const object FileStatus;
	public const object SystemType;
	public const object SendUserCommand;
	public const object ClosingControl;
	public const object ClosingData;
	public const object EnteringPassive;
	public const object LoggedInProceed;
	public const object ServerWantsSecureSession;
	public const object FileActionOK;
	public const object PathnameCreated;
	public const object SendPasswordCommand;
	public const object NeedLoginAccount;
	public const object FileCommandPending;
	public const object ServiceNotAvailable;
	public const object CantOpenData;
	public const object ConnectionClosed;
	public const object ActionNotTakenFileUnavailableOrBusy;
	public const object ActionAbortedLocalProcessingError;
	public const object ActionNotTakenInsufficientSpace;
	public const object CommandSyntaxError;
	public const object ArgumentSyntaxError;
	public const object CommandNotImplemented;
	public const object BadCommandSequence;
	public const object NotLoggedIn;
	public const object AccountNeeded;
	public const object ActionNotTakenFileUnavailable;
	public const object ActionAbortedUnknownPageType;
	public const object FileActionAborted;
	public const object ActionNotTakenFilenameNotAllowed;
}

// Namespace: System.Net
public enum HttpRequestHeader
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CacheControl;
	public const object Connection;
	public const object Date;
	public const object KeepAlive;
	public const object Pragma;
	public const object Trailer;
	public const object TransferEncoding;
	public const object Upgrade;
	public const object Via;
	public const object Warning;
	public const object Allow;
	public const object ContentLength;
	public const object ContentType;
	public const object ContentEncoding;
	public const object ContentLanguage;
	public const object ContentLocation;
	public const object ContentMd5;
	public const object ContentRange;
	public const object Expires;
	public const object LastModified;
	public const object Accept;
	public const object AcceptCharset;
	public const object AcceptEncoding;
	public const object AcceptLanguage;
	public const object Authorization;
	public const object Cookie;
	public const object Expect;
	public const object From;
	public const object Host;
	public const object IfMatch;
	public const object IfModifiedSince;
	public const object IfNoneMatch;
	public const object IfRange;
	public const object IfUnmodifiedSince;
	public const object MaxForwards;
	public const object ProxyAuthorization;
	public const object Referer;
	public const object Range;
	public const object Te;
	public const object Translate;
	public const object UserAgent;
}

// Namespace: System.Net
public interface IAuthenticationModule
{

	// Properties
	public abstract object AuthenticationType { get; }

	// Methods

	// RVA: -1
	public abstract object Authenticate(object challenge, object request, object credentials) { }

	// RVA: -1
	public abstract object PreAuthenticate(object request, object credentials) { }

	// RVA: -1
	public abstract object get_AuthenticationType() { }

}

// Namespace: System.Net
public interface ICertificatePolicy
{

	// Methods

	// RVA: -1
	public abstract object CheckValidationResult(object srvPoint, object certificate, object request, object certificateProblem) { }

}

// Namespace: System.Net
public interface ICredentials
{

	// Methods

	// RVA: -1
	public abstract object GetCredential(object uri, object authType) { }

}

// Namespace: System.Net
public class IPHostEntry
{

	// Fields
	private object hostName; // 0x8
	private object aliases; // 0x10
	private object addressList; // 0x18
	internal object isTrustedHost; // 0x20

	// Properties
	public object HostName { get; set; }
	public object Aliases { set; }
	public object AddressList { get; set; }

	// Methods

	// RVA: 0x71EC06C
	public object get_HostName() { }

	// RVA: 0x71EC074
	public object set_HostName(object value) { }

	// RVA: 0x71EC07C
	public object set_Aliases(object value) { }

	// RVA: 0x71EC084
	public object get_AddressList() { }

	// RVA: 0x71EC08C
	public object set_AddressList(object value) { }

	// RVA: 0x71EC094
	public object .ctor() { }

}

// Namespace: System.Net
public interface IWebRequestCreate
{

	// Methods

	// RVA: -1
	public abstract object Create(object uri) { }

}

// Namespace: System.Net
internal class InternalException
{

	// Methods

	// RVA: 0x71E7584
	internal object .ctor() { }

}

// Namespace: System.Net
internal static class NclUtilities
{

	// Fields
	private static object _LocalAddresses; // 0x0
	private static object _LocalAddressesLock; // 0x8
	internal static object _LocalDomainName; // 0x10

	// Properties
	internal static object LocalAddresses { get; }
	private static object LocalAddressesLock { get; }

	// Methods

	// RVA: 0x71EC0A4
	internal static object IsFatal(object exception) { }

	// RVA: 0x71EC198
	internal static object IsAddressLocal(object ipAddress) { }

	// RVA: 0x71EC83C
	private static object GetLocalHost() { }

	// RVA: 0x71EC23C
	internal static object get_LocalAddresses() { }

	// RVA: 0x71EC858
	private static object get_LocalAddressesLock() { }

}

// Namespace: System.Net
internal static class ValidationHelper
{

	// Fields
	public static object EmptyArray; // 0x0
	internal static readonly object InvalidMethodChars; // 0x8
	internal static readonly object InvalidParamChars; // 0x10

	// Methods

	// RVA: 0x71EBBAC
	public static object MakeStringNull(object stringValue) { }

	// RVA: 0x71EC954
	public static object IsBlankString(object stringValue) { }

	// RVA: 0x71EC970
	public static object ValidateTcpPort(object port) { }

	// RVA: 0x71EC97C
	private static object .cctor() { }

}

// Namespace: System.Net
internal static class ExceptionHelper
{

	// Properties
	internal static object MethodNotImplementedException { get; }
	internal static object PropertyNotImplementedException { get; }
	internal static object TimeoutException { get; }
	internal static object PropertyNotSupportedException { get; }
	internal static object RequestAbortedException { get; }

	// Methods

	// RVA: 0x71EBFB0
	internal static object get_MethodNotImplementedException() { }

	// RVA: 0x71EBEFC
	internal static object get_PropertyNotImplementedException() { }

	// RVA: 0x71E4528
	internal static object get_TimeoutException() { }

	// RVA: 0x71E9F98
	internal static object get_PropertyNotSupportedException() { }

	// RVA: 0x71E1460
	internal static object get_RequestAbortedException() { }

}

// Namespace: System.Net
internal class WebRequestPrefixElement
{

	// Fields
	public object Prefix; // 0x8
	internal object creator; // 0x10
	internal object creatorType; // 0x18

	// Properties
	public object Creator { get; set; }

	// Methods

	// RVA: 0x71ECB54
	public object get_Creator() { }

	// RVA: 0x71ECD8C
	public object set_Creator(object value) { }

	// RVA: 0x71ECD94
	public object .ctor(object P, object C) { }

}

// Namespace: System.Net
public sealed class HttpContinueDelegate
{

	// Methods

	// RVA: 0x71ECE3C
	public object .ctor(object object, object method) { }

	// RVA: 0x71ECED4
	public virtual object Invoke(object StatusCode, object httpHeaders) { }

}

// Namespace: System.Net
internal enum TriState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unspecified;
	public const object False;
	public const object True;
}

// Namespace: System.Net
public class NetworkCredential
{

	// Fields
	private object m_domain; // 0x8
	private object m_userName; // 0x10
	private object m_password; // 0x18

	// Properties
	public object UserName { get; set; }
	public object Password { get; set; }
	public object Domain { get; set; }

	// Methods

	// RVA: 0x71E3B0C
	public object .ctor(object userName, object password) { }

	// RVA: 0x71EA478
	public object .ctor(object userName, object password, object domain) { }

	// RVA: 0x71ED00C
	public object get_UserName() { }

	// RVA: 0x71ECEE8
	public object set_UserName(object value) { }

	// RVA: 0x71ED014
	public object get_Password() { }

	// RVA: 0x71ECF64
	public object set_Password(object value) { }

	// RVA: 0x71ED02C
	public object get_Domain() { }

	// RVA: 0x71ECF90
	public object set_Domain(object value) { }

	// RVA: 0x71ED034
	internal object InternalGetUserName() { }

	// RVA: 0x71ED020
	internal object InternalGetPassword() { }

	// RVA: 0x71ED03C
	internal object InternalGetDomain() { }

	// RVA: 0x71ED044
	public object GetCredential(object uri, object authType) { }

}

// Namespace: System.Net
public class ProtocolViolationException
{

	// Methods

	// RVA: 0x71ED048
	public object .ctor() { }

	// RVA: 0x71ED050
	public object .ctor(object message) { }

	// RVA: 0x71ED058
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x71ED060
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71ED068
	public override object GetObjectData(object serializationInfo, object streamingContext) { }

}

// Namespace: System.Net
public class SocketAddress
{

	// Fields
	internal object m_Size; // 0x8
	internal object m_Buffer; // 0x10
	private object m_changed; // 0x18
	private object m_hash; // 0x1C

	// Properties
	public object Family { get; }
	public object Size { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x71ED070
	public object get_Family() { }

	// RVA: 0x71ED0AC
	public object get_Size() { }

	// RVA: 0x71ED0B4
	public object get_Item(object offset) { }

	// RVA: 0x71ED13C
	public object .ctor(object family, object size) { }

	// RVA: 0x71ED278
	internal object .ctor(object ipAddress) { }

	// RVA: 0x71ED5D4
	internal object .ctor(object ipaddress, object port) { }

	// RVA: 0x71ED648
	internal object GetIPAddress() { }

	// RVA: 0x71ED858
	internal object GetIPEndPoint() { }

	// RVA: 0x71ED904
	public override object Equals(object comparand) { }

	// RVA: 0x71EDA10
	public override object GetHashCode() { }

	// RVA: 0x71EDF54
	public override object ToString() { }

}

// Namespace: System.Net
public class WebException
{

	// Fields
	private object m_Status; // 0x84
	private object m_Response; // 0x88
	private object m_InternalStatus; // 0x90

	// Properties
	public object Status { get; }
	public object Response { get; }

	// Methods

	// RVA: 0x71EE220
	public object .ctor() { }

	// RVA: 0x71ECA84
	public object .ctor(object message) { }

	// RVA: 0x71E832C
	public object .ctor(object message, object innerException) { }

	// RVA: 0x71E72B4
	public object .ctor(object message, object status) { }

	// RVA: 0x71EE230
	internal object .ctor(object message, object status, object internalStatus, object innerException) { }

	// RVA: 0x71E8274
	public object .ctor(object message, object innerException, object status, object response) { }

	// RVA: 0x71EE3AC
	internal object .ctor(object message, object data, object innerException, object status, object response) { }

	// RVA: 0x71EE2EC
	internal object .ctor(object message, object innerException, object status, object response, object internalStatus) { }

	// RVA: 0x71EE498
	internal object .ctor(object message, object data, object innerException, object status, object response, object internalStatus) { }

	// RVA: 0x71EE58C
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x71EE59C
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71EE5FC
	public override object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71EE604
	public object get_Status() { }

	// RVA: 0x71EE60C
	public object get_Response() { }

}

// Namespace: System.Net
internal enum WebExceptionInternalStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RequestFatal;
	public const object ServicePointFatal;
	public const object Recoverable;
	public const object Isolated;
}

// Namespace: System.Net
public enum WebExceptionStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Success;
	public const object NameResolutionFailure;
	public const object ConnectFailure;
	public const object ReceiveFailure;
	public const object SendFailure;
	public const object PipelineFailure;
	public const object RequestCanceled;
	public const object ProtocolError;
	public const object ConnectionClosed;
	public const object TrustFailure;
	public const object SecureChannelFailure;
	public const object ServerProtocolViolation;
	public const object KeepAliveFailure;
	public const object Pending;
	public const object Timeout;
	public const object ProxyNameResolutionFailure;
	public const object UnknownError;
	public const object MessageLengthLimitExceeded;
	public const object CacheEntryNotFound;
	public const object RequestProhibitedByCachePolicy;
	public const object RequestProhibitedByProxy;
}

// Namespace: System.Net
internal static class WebExceptionMapping
{

	// Fields
	private static readonly object s_Mapping; // 0x0

	// Methods

	// RVA: 0x71EE614
	internal static object GetWebStatusString(object status) { }

	// RVA: 0x71EE7F8
	private static object .cctor() { }

}

// Namespace: System.Net
internal enum WebHeaderCollectionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object WebRequest;
	public const object WebResponse;
	public const object HttpWebRequest;
	public const object HttpWebResponse;
	public const object HttpListenerRequest;
	public const object HttpListenerResponse;
	public const object FtpWebRequest;
	public const object FtpWebResponse;
	public const object FileWebRequest;
	public const object FileWebResponse;
}

// Namespace: 
private enum RfcChar
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object High;
	public const object Reg;
	public const object Ctl;
	public const object CR;
	public const object LF;
	public const object WS;
	public const object Colon;
	public const object Delim;
}

// Namespace: System.Net
public class WebHeaderCollection
{

	// Fields
	private static readonly object HInfo; // 0x0
	private object m_CommonHeaders; // 0x58
	private object m_NumCommonHeaders; // 0x60
	private static readonly object s_CommonHeaderNames; // 0x8
	private static readonly object s_CommonHeaderHints; // 0x10
	private object m_InnerCollection; // 0x68
	private object m_Type; // 0x70
	private static readonly object HttpTrimCharacters; // 0x18
	private static object RfcCharMap; // 0x20

	// Properties
	private object InnerCollection { get; }
	private object AllowHttpRequestHeader { get; }
	public override object Count { get; }

	// Methods

	// RVA: 0x71EE86C
	private object NormalizeCommonHeaders() { }

	// RVA: 0x71EEA5C
	private object get_InnerCollection() { }

	// RVA: 0x71EEB1C
	internal static object AllowMultiValues(object name) { }

	// RVA: 0x71EED48
	private object get_AllowHttpRequestHeader() { }

	// RVA: 0x71EED88
	public object Remove(object header) { }

	// RVA: 0x71EEEB4
	internal object AddInternal(object name, object value) { }

	// RVA: 0x71EEFB4
	internal object ChangeInternal(object name, object value) { }

	// RVA: 0x71EF0B4
	internal object RemoveInternal(object name) { }

	// RVA: 0x71EF134
	internal static object CheckBadChars(object name, object isHeaderValue) { }

	// RVA: 0x71EF52C
	internal static object ContainsNonAsciiChars(object token) { }

	// RVA: 0x71EF5BC
	internal object ThrowOnRestrictedHeader(object headerName) { }

	// RVA: 0x71EF794
	public override object Add(object name, object value) { }

	// RVA: 0x71EF9F0
	public object Add(object header) { }

	// RVA: 0x71EFD7C
	public override object Set(object name, object value) { }

	// RVA: 0x71F0064
	internal object SetInternal(object name, object value) { }

	// RVA: 0x71F0340
	public override object Remove(object name) { }

	// RVA: 0x71F04B0
	public override object GetValues(object header) { }

	// RVA: 0x71F0814
	public override object ToString() { }

	// RVA: 0x71F087C
	internal static object GetAsString(object cc, object winInetCompat, object forTrace) { }

	// RVA: 0x71E9EFC
	public object .ctor() { }

	// RVA: 0x71F0BE8
	internal object .ctor(object type) { }

	// RVA: 0x71F0CD4
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F0F68
	public override object OnDeserialization(object sender) { }

	// RVA: 0x71F0F6C
	public override object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F1158
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F11B8
	public override object Get(object name) { }

	// RVA: 0x71F1568
	public override object GetEnumerator() { }

	// RVA: 0x71F1680
	public override object get_Count() { }

	// RVA: 0x71F16EC
	public override object Get(object index) { }

	// RVA: 0x71F17D0
	public override object GetKey(object index) { }

	// RVA: 0x71F18B4
	private static object .cctor() { }

}

// Namespace: System.Net
internal class CaseInsensitiveAscii
{

	// Fields
	internal static readonly object StaticInstance; // 0x0
	internal static readonly object AsciiToLower; // 0x8

	// Methods

	// RVA: 0x71F1D24
	public object GetHashCode(object myObject) { }

	// RVA: 0x71F1E68
	public object Compare(object firstObject, object secondObject) { }

	// RVA: 0x71F200C
	private object FastGetHashCode(object myString) { }

	// RVA: 0x71F212C
	public object Equals(object firstObject, object secondObject) { }

	// RVA: 0x71F2300
	public object .ctor() { }

	// RVA: 0x71F2308
	private static object .cctor() { }

}

// Namespace: 
internal class DesignerWebRequestCreate
{

	// Methods

	// RVA: 0x71F3D98
	public object Create(object uri) { }

	// RVA: 0x71F3C60
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass79_0
{

	// Fields
	public object currentUser; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x71F3604
	public object .ctor() { }

	// RVA: 0x71F3E18
	internal object <GetResponseAsync>b__1() { }

}

// Namespace: System.Net
public abstract class WebRequest
{

	// Fields
	private static object s_PrefixList; // 0x0
	private static object s_InternalSyncObject; // 0x8
	private static object s_DefaultTimerQueue; // 0x10
	private object m_AuthenticationLevel; // 0x10
	private object m_ImpersonationLevel; // 0x14
	private object m_CachePolicy; // 0x18
	private object m_CacheProtocol; // 0x20
	private object m_CacheBinding; // 0x28
	private static object webRequestCreate; // 0x18
	private static object s_DefaultWebProxy; // 0x20
	private static object s_DefaultWebProxyInitialized; // 0x28

	// Properties
	private static object InternalSyncObject { get; }
	internal static object PrefixList { get; }
	public virtual object CachePolicy { set; }
	public virtual object Method { get; set; }
	public virtual object RequestUri { get; }
	public virtual object Headers { get; }
	public virtual object ContentLength { get; }
	public virtual object Credentials { get; set; }
	public virtual object UseDefaultCredentials { get; }
	public virtual object Proxy { get; set; }
	public virtual object Timeout { get; }
	internal object CacheProtocol { get; set; }
	internal static object InternalDefaultWebProxy { get; }

	// Methods

	// RVA: 0x71F23C0
	private static object get_InternalSyncObject() { }

	// RVA: 0x71F24C4
	private static object Create(object requestUri, object useUriBase) { }

	// RVA: 0x71F29D0
	public static object Create(object requestUriString) { }

	// RVA: 0x71F2AC4
	public static object Create(object requestUri) { }

	// RVA: 0x71F27D8
	internal static object get_PrefixList() { }

	// RVA: 0x71F2BE0
	private static object PopulatePrefixList() { }

	// RVA: 0x71E39D0
	protected object .ctor() { }

	// RVA: 0x71F2E5C
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F2E64
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F2EC4
	protected virtual object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F2EC8
	public virtual object set_CachePolicy(object value) { }

	// RVA: 0x71F2F80
	private object InternalSetCachePolicy(object policy) { }

	// RVA: 0x71F3038
	public virtual object get_Method() { }

	// RVA: 0x71F3064
	public virtual object set_Method(object value) { }

	// RVA: 0x71F3090
	public virtual object get_RequestUri() { }

	// RVA: 0x71F30BC
	public virtual object get_Headers() { }

	// RVA: 0x71F30E8
	public virtual object get_ContentLength() { }

	// RVA: 0x71F3114
	public virtual object get_Credentials() { }

	// RVA: 0x71F3140
	public virtual object set_Credentials(object value) { }

	// RVA: 0x71F316C
	public virtual object get_UseDefaultCredentials() { }

	// RVA: 0x71F3198
	public virtual object get_Proxy() { }

	// RVA: 0x71F31C4
	public virtual object set_Proxy(object value) { }

	// RVA: 0x71F31F0
	public virtual object get_Timeout() { }

	// RVA: 0x71F321C
	public virtual object GetResponse() { }

	// RVA: 0x71F3248
	public virtual object BeginGetResponse(object callback, object state) { }

	// RVA: 0x71F3274
	public virtual object EndGetResponse(object asyncResult) { }

	// RVA: 0x71F32A0
	public virtual object GetResponseAsync() { }

	// RVA: 0x71F360C
	private object SafeCaptureIdenity() { }

	// RVA: 0x71F367C
	public virtual object Abort() { }

	// RVA: 0x71F36A8
	internal object get_CacheProtocol() { }

	// RVA: 0x71F36B0
	internal object set_CacheProtocol(object value) { }

	// RVA: 0x71F36B8
	internal static object get_InternalDefaultWebProxy() { }

	// RVA: 0x71F38D8
	private static object .cctor() { }

	// RVA: 0x71F3C68
	private object <GetResponseAsync>b__79_0() { }

}

// Namespace: System.Net
public abstract class WebResponse
{

	// Fields
	private object m_IsFromCache; // 0x10

	// Properties
	public virtual object IsFromCache { get; }
	public virtual object ResponseUri { get; }
	public virtual object Headers { get; }

	// Methods

	// RVA: 0x71EAA54
	protected object .ctor() { }

	// RVA: 0x71F41B0
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F41B8
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F4218
	protected virtual object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x71F421C
	public virtual object Close() { }

	// RVA: 0x71F4220
	public object Dispose() { }

	// RVA: 0x71F42B8
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x71F4374
	public virtual object get_IsFromCache() { }

	// RVA: 0x71F437C
	public virtual object GetResponseStream() { }

	// RVA: 0x71F43A8
	public virtual object get_ResponseUri() { }

	// RVA: 0x71F43D4
	public virtual object get_Headers() { }

}

// Namespace: System.Net
internal class BufferOffsetSize
{

	// Fields
	internal object Buffer; // 0x8
	internal object Offset; // 0x10
	internal object Size; // 0x14

	// Methods

	// RVA: 0x71F4400
	internal object .ctor(object buffer, object offset, object size, object copyBuffer) { }

	// RVA: 0x71F44B0
	internal object .ctor(object buffer, object copyBuffer) { }

}

// Namespace: System.Net
internal sealed class HeaderParser
{

	// Methods

	// RVA: 0x71F46E0
	public object .ctor(object object, object method) { }

	// RVA: 0x71F4788
	public virtual object Invoke(object value) { }

}

// Namespace: System.Net
internal class HeaderInfo
{

	// Fields
	internal readonly object IsRequestRestricted; // 0x8
	internal readonly object IsResponseRestricted; // 0x9
	internal readonly object Parser; // 0x10
	internal readonly object HeaderName; // 0x18
	internal readonly object AllowMultiValues; // 0x20

	// Methods

	// RVA: 0x71F479C
	internal object .ctor(object name, object requestRestricted, object responseRestricted, object multi, object p) { }

}

// Namespace: System.Net
internal class HeaderInfoTable
{

	// Fields
	private static object HeaderHashTable; // 0x0
	private static object UnknownHeaderInfo; // 0x8
	private static object SingleParser; // 0x10
	private static object MultiParser; // 0x18

	// Properties
	internal object Item { get; }

	// Methods

	// RVA: 0x71F47F4
	private static object ParseSingleValue(object value) { }

	// RVA: 0x71F486C
	private static object ParseMultiValue(object value) { }

	// RVA: 0x71F4C38
	private static object .cctor() { }

	// RVA: 0x71EEC00
	internal object get_Item(object name) { }

	// RVA: 0x71F1D1C
	public object .ctor() { }

}

// Namespace: System.Net
internal enum CloseExState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Abort;
	public const object Silent;
}

// Namespace: System.Net
internal interface ICloseEx
{

	// Methods

	// RVA: -1
	public abstract object CloseEx(object closeState) { }

}

// Namespace: 
private class ThreadContext
{

	// Fields
	internal object m_NestedIOCount; // 0x8

	// Methods

	// RVA: 0x71F65F4
	public object .ctor() { }

}

// Namespace: System.Net
internal class LazyAsyncResult
{

	// Fields
	private static object t_ThreadContext; // 0xFFFFFFFF80000000
	private object m_AsyncObject; // 0x8
	private object m_AsyncState; // 0x10
	private object m_AsyncCallback; // 0x18
	private object m_Result; // 0x20
	private object m_IntCompleted; // 0x28
	private object m_EndCalled; // 0x2C
	private object m_UserEvent; // 0x2D
	private object m_Event; // 0x30

	// Properties
	private static object CurrentThreadContext { get; }
	internal object AsyncObject { get; }
	public object AsyncState { get; }
	protected object AsyncCallback { get; }
	public object AsyncWaitHandle { get; }
	public object CompletedSynchronously { get; }
	public object IsCompleted { get; }
	internal object InternalPeekCompleted { get; }
	internal object EndCalled { get; set; }

	// Methods

	// RVA: 0x71F6548
	private static object get_CurrentThreadContext() { }

	// RVA: 0x71E20E8
	internal object .ctor(object myObject, object myState, object myCallBack) { }

	// RVA: 0x71F65FC
	internal object get_AsyncObject() { }

	// RVA: 0x71F6604
	public object get_AsyncState() { }

	// RVA: 0x71F660C
	protected object get_AsyncCallback() { }

	// RVA: 0x71F6614
	public object get_AsyncWaitHandle() { }

	// RVA: 0x71F66D4
	private object LazilyCreateEvent(object waitHandle) { }

	// RVA: 0x71F68B0
	public object get_CompletedSynchronously() { }

	// RVA: 0x71E1E60
	public object get_IsCompleted() { }

	// RVA: 0x71E6314
	internal object get_InternalPeekCompleted() { }

	// RVA: 0x71F68F0
	internal object get_EndCalled() { }

	// RVA: 0x71F68F8
	internal object set_EndCalled(object value) { }

	// RVA: 0x71F6900
	protected object ProtectedInvokeCallback(object result, object userToken) { }

	// RVA: 0x71E1E58
	internal object InvokeCallback(object result) { }

	// RVA: 0x71E6324
	internal object InvokeCallback() { }

	// RVA: 0x71F6B44
	protected virtual object Complete(object userToken) { }

	// RVA: 0x71F6D98
	private object WorkerThreadComplete(object state) { }

	// RVA: 0x71F6ED8
	protected virtual object Cleanup() { }

	// RVA: 0x71E237C
	internal object InternalWaitForCompletion() { }

	// RVA: 0x71F6EDC
	private object WaitForCompletion(object snap) { }

}

// Namespace: System.Net
internal class NetRes
{

	// Methods

	// RVA: 0x71ECA98
	public static object GetWebStatusString(object Res, object Status) { }

	// RVA: 0x71F72D4
	public static object GetWebStatusString(object Status) { }

	// RVA: 0x71F733C
	public static object GetWebStatusCodeString(object statusCode, object statusDescription) { }

}

// Namespace: 
internal abstract class Queue
{

	// Fields
	private readonly object m_DurationMilliseconds; // 0x8

	// Properties
	internal object Duration { get; }

	// Methods

	// RVA: 0x71F862C
	internal object .ctor(object durationMilliseconds) { }

	// RVA: 0x71F8658
	internal object get_Duration() { }

	// RVA: -1
	internal abstract object CreateTimer(object callback, object context) { }

}

// Namespace: 
internal abstract class Timer
{

	// Fields
	private readonly object m_StartTimeMilliseconds; // 0x8
	private readonly object m_DurationMilliseconds; // 0xC

	// Properties
	internal object StartTime { get; }
	internal object Expiration { get; }
	internal abstract object HasExpired { get; }

	// Methods

	// RVA: 0x71F8660
	internal object .ctor(object durationMilliseconds) { }

	// RVA: 0x71F8698
	internal object get_StartTime() { }

	// RVA: 0x71F86A0
	internal object get_Expiration() { }

	// RVA: -1
	internal abstract object Cancel() { }

	// RVA: -1
	internal abstract object get_HasExpired() { }

	// RVA: 0x71F86AC
	public object Dispose() { }

}

// Namespace: 
internal sealed class Callback
{

	// Methods

	// RVA: 0x71E3A00
	public object .ctor(object object, object method) { }

	// RVA: 0x71F8A38
	public virtual object Invoke(object timer, object timeNoticed, object context) { }

}

// Namespace: 
private class TimerQueue
{

	// Fields
	private object m_ThisHandle; // 0x10
	private readonly object m_Timers; // 0x18

	// Methods

	// RVA: 0x71F77D4
	internal object .ctor(object durationMilliseconds) { }

	// RVA: 0x71F8A88
	internal override object CreateTimer(object callback, object context) { }

	// RVA: 0x71F8260
	internal object Fire(object nextExpiration) { }

}

// Namespace: 
private class InfiniteTimerQueue
{

	// Methods

	// RVA: 0x71F77A8
	internal object .ctor() { }

	// RVA: 0x71F8FD0
	internal override object CreateTimer(object callback, object context) { }

}

// Namespace: 
private enum TimerState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Ready;
	public const object Fired;
	public const object Cancelled;
	public const object Sentinel;
}

// Namespace: 
private class TimerNode
{

	// Fields
	private object m_TimerState; // 0x10
	private object m_Callback; // 0x18
	private object m_Context; // 0x20
	private object m_QueueLock; // 0x28
	private object next; // 0x30
	private object prev; // 0x38

	// Properties
	internal override object HasExpired { get; }
	internal object Next { get; set; }
	internal object Prev { get; set; }

	// Methods

	// RVA: 0x71F8CA4
	internal object .ctor(object callback, object context, object durationMilliseconds, object queueLock) { }

	// RVA: 0x71F8A4C
	internal object .ctor() { }

	// RVA: 0x71F9074
	internal override object get_HasExpired() { }

	// RVA: 0x71F9084
	internal object get_Next() { }

	// RVA: 0x71F908C
	internal object set_Next(object value) { }

	// RVA: 0x71F9094
	internal object get_Prev() { }

	// RVA: 0x71F909C
	internal object set_Prev(object value) { }

	// RVA: 0x71F90A4
	internal override object Cancel() { }

	// RVA: 0x71F8D08
	internal object Fire() { }

}

// Namespace: 
private class InfiniteTimer
{

	// Fields
	private object cancelled; // 0x10

	// Properties
	internal override object HasExpired { get; }

	// Methods

	// RVA: 0x71F903C
	internal object .ctor() { }

	// RVA: 0x71F9218
	internal override object get_HasExpired() { }

	// RVA: 0x71F9220
	internal override object Cancel() { }

}

// Namespace: System.Net
internal static class TimerThread
{

	// Fields
	private static object s_Queues; // 0x0
	private static object s_NewQueues; // 0x8
	private static object s_ThreadState; // 0x10
	private static object s_ThreadReadyEvent; // 0x18
	private static object s_ThreadShutdownEvent; // 0x20
	private static object s_ThreadEvents; // 0x28
	private static object s_CacheScanIteration; // 0x30
	private static object s_QueuesCache; // 0x38

	// Methods

	// RVA: 0x71F7520
	private static object .cctor() { }

	// RVA: 0x71F3990
	internal static object CreateQueue(object durationMilliseconds) { }

	// RVA: 0x71E76EC
	internal static object GetOrCreateQueue(object durationMilliseconds) { }

	// RVA: 0x71F7868
	private static object Prod() { }

	// RVA: 0x71F79A8
	private static object ThreadProc() { }

	// RVA: 0x71F846C
	private static object StopTimerThread() { }

	// RVA: 0x71F8448
	private static object IsTickBetween(object start, object end, object comparand) { }

	// RVA: 0x71F84F4
	private static object OnDomainUnload(object sender, object e) { }

}

// Namespace: System.Net
internal enum CookieVariant
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Plain;
	public const object Rfc2109;
	public const object Rfc2965;
	public const object Default;
}

// Namespace: System.Net
public sealed class Cookie
{

	// Fields
	internal static readonly object PortSplitDelimiters; // 0x0
	internal static readonly object Reserved2Name; // 0x8
	internal static readonly object Reserved2Value; // 0x10
	private static object staticComparer; // 0x18
	private object m_comment; // 0x8
	private object m_commentUri; // 0x10
	private object m_cookieVariant; // 0x18
	private object m_discard; // 0x1C
	private object m_domain; // 0x20
	private object m_domain_implicit; // 0x28
	private object m_expires; // 0x30
	private object m_name; // 0x38
	private object m_path; // 0x40
	private object m_path_implicit; // 0x48
	private object m_port; // 0x50
	private object m_port_implicit; // 0x58
	private object m_port_list; // 0x60
	private object m_secure; // 0x68
	private object m_httpOnly; // 0x69
	private object m_timeStamp; // 0x70
	private object m_value; // 0x78
	private object m_version; // 0x80
	private object m_domainKey; // 0x88
	internal object IsQuotedVersion; // 0x90
	internal object IsQuotedDomain; // 0x91

	// Properties
	public object Comment { get; set; }
	public object CommentUri { set; }
	public object HttpOnly { set; }
	public object Discard { set; }
	public object Domain { get; set; }
	private object _Domain { get; }
	public object Expired { get; }
	public object Expires { set; }
	public object Name { get; }
	public object Path { get; set; }
	private object _Path { get; }
	internal object Plain { get; }
	public object Port { set; }
	internal object PortList { get; }
	private object _Port { get; }
	public object Secure { get; set; }
	public object Value { get; set; }
	internal object Variant { get; }
	internal object DomainKey { get; }
	public object Version { get; set; }
	private object _Version { get; }

	// Methods

	// RVA: 0x71F9248
	public object .ctor() { }

	// RVA: 0x71F9328
	public object get_Comment() { }

	// RVA: 0x71F9330
	public object set_Comment(object value) { }

	// RVA: 0x71F93AC
	public object set_CommentUri(object value) { }

	// RVA: 0x71F93B4
	public object set_HttpOnly(object value) { }

	// RVA: 0x71F93BC
	public object set_Discard(object value) { }

	// RVA: 0x71F93C4
	public object get_Domain() { }

	// RVA: 0x71F93CC
	public object set_Domain(object value) { }

	// RVA: 0x71F9464
	private object get__Domain() { }

	// RVA: 0x71F9560
	public object get_Expired() { }

	// RVA: 0x71F9648
	public object set_Expires(object value) { }

	// RVA: 0x71F9650
	public object get_Name() { }

	// RVA: 0x71F9658
	internal object InternalSetName(object value) { }

	// RVA: 0x71F9774
	public object get_Path() { }

	// RVA: 0x71F977C
	public object set_Path(object value) { }

	// RVA: 0x71F97FC
	private object get__Path() { }

	// RVA: 0x71F9550
	internal object get_Plain() { }

	// RVA: 0x71F98A4
	private static object IsDomainEqualToHost(object domain, object host) { }

	// RVA: 0x71F9918
	internal object VerifySetDefaults(object variant, object uri, object isLocalDomain, object localDomain, object set_default, object isThrow) { }

	// RVA: 0x71FA580
	private static object DomainCharsTest(object name) { }

	// RVA: 0x71FA6EC
	public object set_Port(object value) { }

	// RVA: 0x71FABE0
	internal object get_PortList() { }

	// RVA: 0x71FABE8
	private object get__Port() { }

	// RVA: 0x71FACCC
	public object get_Secure() { }

	// RVA: 0x71FACD4
	public object set_Secure(object value) { }

	// RVA: 0x71FACDC
	public object get_Value() { }

	// RVA: 0x71FACE4
	public object set_Value(object value) { }

	// RVA: 0x71FAD60
	internal object get_Variant() { }

	// RVA: 0x71FAD68
	internal object get_DomainKey() { }

	// RVA: 0x71FAD84
	public object get_Version() { }

	// RVA: 0x71FAD8C
	public object set_Version(object value) { }

	// RVA: 0x71FAE04
	private object get__Version() { }

	// RVA: 0x71FAF14
	internal static object GetComparer() { }

	// RVA: 0x71FAF90
	public override object Equals(object comparand) { }

	// RVA: 0x71FB078
	public override object GetHashCode() { }

	// RVA: 0x71FB218
	public override object ToString() { }

	// RVA: 0x71FB53C
	private static object .cctor() { }

}

// Namespace: System.Net
internal enum CookieToken
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Nothing;
	public const object NameValuePair;
	public const object Attribute;
	public const object EndToken;
	public const object EndCookie;
	public const object End;
	public const object Equals;
	public const object Comment;
	public const object CommentUrl;
	public const object CookieName;
	public const object Discard;
	public const object Domain;
	public const object Expires;
	public const object MaxAge;
	public const object Path;
	public const object Port;
	public const object Secure;
	public const object HttpOnly;
	public const object Unknown;
	public const object Version;
}

// Namespace: 
private struct RecognizedAttribute
{

	// Fields
	private object m_name; // 0xFFFFFFFFFFFFFFF8
	private object m_token; // 0x0

	// Properties
	internal object Token { get; }

	// Methods

	// RVA: 0x71FC448
	internal object .ctor(object name, object token) { }

	// RVA: 0x71FC4F8
	internal object get_Token() { }

	// RVA: 0x71FC0F8
	internal object IsEqualTo(object value) { }

}

// Namespace: System.Net
internal class CookieTokenizer
{

	// Fields
	private object m_eofCookie; // 0x8
	private object m_index; // 0xC
	private object m_length; // 0x10
	private object m_name; // 0x18
	private object m_quoted; // 0x20
	private object m_start; // 0x24
	private object m_token; // 0x28
	private object m_tokenLength; // 0x2C
	private object m_tokenStream; // 0x30
	private object m_value; // 0x38
	private static object RecognizedAttributes; // 0x0
	private static object RecognizedServerAttributes; // 0x8

	// Properties
	internal object EndOfCookie { get; set; }
	internal object Eof { get; }
	internal object Name { get; set; }
	internal object Quoted { get; set; }
	internal object Token { get; set; }
	internal object Value { get; set; }

	// Methods

	// RVA: 0x71FB6A0
	internal object .ctor(object tokenStream) { }

	// RVA: 0x71FB6E4
	internal object get_EndOfCookie() { }

	// RVA: 0x71FB6EC
	internal object set_EndOfCookie(object value) { }

	// RVA: 0x71FB6F4
	internal object get_Eof() { }

	// RVA: 0x71FB704
	internal object get_Name() { }

	// RVA: 0x71FB70C
	internal object set_Name(object value) { }

	// RVA: 0x71FB714
	internal object get_Quoted() { }

	// RVA: 0x71FB71C
	internal object set_Quoted(object value) { }

	// RVA: 0x71FB724
	internal object get_Token() { }

	// RVA: 0x71FB72C
	internal object set_Token(object value) { }

	// RVA: 0x71FB734
	internal object get_Value() { }

	// RVA: 0x71FB73C
	internal object set_Value(object value) { }

	// RVA: 0x71FB744
	internal object Extract() { }

	// RVA: 0x71FB7E4
	internal object FindNext(object ignoreComma, object ignoreEquals) { }

	// RVA: 0x71FBB90
	internal object Next(object first, object parseResponseCookies) { }

	// RVA: 0x71FBE64
	internal object Reset() { }

	// RVA: 0x71FBED8
	internal object TokenFromName(object parseResponseCookies) { }

	// RVA: 0x71FC120
	private static object .cctor() { }

}

// Namespace: System.Net
internal class CookieParser
{

	// Fields
	private object m_tokenizer; // 0x8

	// Methods

	// RVA: 0x71FC530
	internal object .ctor(object cookieString) { }

	// RVA: 0x71FC5C0
	internal object Get() { }

	// RVA: 0x71FA624
	internal static object CheckQuoted(object value) { }

}

// Namespace: System.Net
internal class Comparer
{

	// Methods

	// RVA: 0x71FCD50
	private object System.Collections.IComparer.Compare(object ol, object or) { }

	// RVA: 0x71FB698
	public object .ctor() { }

}

// Namespace: 
internal enum Stamp
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Check;
	public const object Set;
	public const object SetToUnused;
	public const object SetToMaxUsed;
}

// Namespace: 
private class CookieCollectionEnumerator
{

	// Fields
	private object m_cookies; // 0x8
	private object m_count; // 0x10
	private object m_index; // 0x14
	private object m_version; // 0x18

	// Properties
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x71FE1E8
	internal object .ctor(object cookies) { }

	// RVA: 0x71FE27C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x71FE32C
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x71FE3D4
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: System.Net
public class CookieCollection
{

	// Fields
	internal object m_version; // 0x8
	private object m_list; // 0x10
	private object m_TimeStamp; // 0x18
	private object m_has_other_versions; // 0x20
	private object m_IsReadOnly; // 0x21

	// Properties
	public object Item { get; }
	public object Count { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }
	internal object IsOtherVersionSeen { get; }

	// Methods

	// RVA: 0x71FCE4C
	public object .ctor() { }

	// RVA: 0x71FCEF8
	public object get_Item(object index) { }

	// RVA: 0x71FD030
	public object Add(object cookie) { }

	// RVA: 0x71FD5A4
	public object Add(object cookies) { }

	// RVA: 0x71FD9B4
	public object get_Count() { }

	// RVA: 0x71FDA04
	public object get_IsSynchronized() { }

	// RVA: 0x71FDA0C
	public object get_SyncRoot() { }

	// RVA: 0x71FDA10
	public object CopyTo(object array, object index) { }

	// RVA: 0x71FDA78
	internal object TimeStamp(object how) { }

	// RVA: 0x71FDB80
	internal object get_IsOtherVersionSeen() { }

	// RVA: 0x71FDB88
	internal object InternalAdd(object cookie, object isStrict) { }

	// RVA: 0x71FD148
	internal object IndexOf(object cookie) { }

	// RVA: 0x71FE190
	internal object RemoveAt(object idx) { }

	// RVA: 0x71FD8EC
	public object GetEnumerator() { }

}

// Namespace: System.Net
internal struct HeaderVariantInfo
{

	// Fields
	private object m_name; // 0xFFFFFFFFFFFFFFF8
	private object m_variant; // 0x0

	// Properties
	internal object Name { get; }
	internal object Variant { get; }

	// Methods

	// RVA: 0x71FE478
	internal object .ctor(object name, object variant) { }

	// RVA: 0x71FE490
	internal object get_Name() { }

	// RVA: 0x71FE4A0
	internal object get_Variant() { }

}

// Namespace: System.Net
public class CookieContainer
{

	// Fields
	private static readonly object HeaderInfo; // 0x0
	private object m_domainTable; // 0x8
	private object m_maxCookieSize; // 0x10
	private object m_maxCookies; // 0x14
	private object m_maxCookiesPerDomain; // 0x18
	private object m_count; // 0x1C
	private object m_fqdnMyDomain; // 0x20

	// Methods

	// RVA: 0x71FE4B0
	public object .ctor() { }

	// RVA: 0x71FE5D4
	private object AddRemoveDomain(object key, object value) { }

	// RVA: 0x71FE77C
	internal object Add(object cookie, object throwOnError) { }

	// RVA: 0x71FF090
	private object AgeCookies(object domain) { }

	// RVA: 0x720071C
	private object ExpireCollection(object cc) { }

	// RVA: 0x720093C
	internal object IsLocalDomain(object host) { }

	// RVA: 0x7200E28
	internal object CookieCutter(object uri, object headerName, object setCookieHeader, object isThrow) { }

	// RVA: 0x72015EC
	internal object InternalGetCookies(object uri) { }

	// RVA: 0x7201D0C
	private object BuildCookieCollectionFromDomainMatches(object uri, object isSecure, object port, object cookies, object domainAttribute, object matchOnlyPlainCookie) { }

	// RVA: 0x72026C0
	private object MergeUpdateCollections(object destination, object source, object port, object isSecure, object isPlainOnly) { }

	// RVA: 0x7202944
	public object GetCookieHeader(object uri) { }

	// RVA: 0x7202A38
	internal object GetCookieHeader(object uri, object optCookie2) { }

	// RVA: 0x7202E50
	private static object .cctor() { }

}

// Namespace: 
private class PathListComparer
{

	// Fields
	internal static readonly object StaticInstance; // 0x0

	// Methods

	// RVA: 0x7203804
	private object System.Collections.IComparer.Compare(object ol, object or) { }

	// RVA: 0x72039C0
	public object .ctor() { }

	// RVA: 0x72039C8
	private static object .cctor() { }

}

// Namespace: System.Net
internal class PathList
{

	// Fields
	private object m_list; // 0x8

	// Properties
	public object Count { get; }
	public object Values { get; }
	public object Item { get; set; }
	public object SyncRoot { get; }

	// Methods

	// RVA: 0x7202F88
	public object .ctor() { }

	// RVA: 0x7203034
	public object get_Count() { }

	// RVA: 0x7203084
	public object GetCookiesCount() { }

	// RVA: 0x72035B0
	public object get_Values() { }

	// RVA: 0x7203600
	public object get_Item(object s) { }

	// RVA: 0x7203658
	public object set_Item(object s, object value) { }

	// RVA: 0x72037B4
	public object GetEnumerator() { }

	// RVA: 0x7203560
	public object get_SyncRoot() { }

}

// Namespace: System.Net
public class CookieException
{

	// Methods

	// RVA: 0x7203A28
	public object .ctor() { }

	// RVA: 0x7203A30
	internal object .ctor(object message) { }

	// RVA: 0x7203A38
	internal object .ctor(object message, object inner) { }

	// RVA: 0x7203A40
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x7203A48
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x7203A50
	public override object GetObjectData(object serializationInfo, object streamingContext) { }

}

// Namespace: System.Net
public class FileWebRequest
{

	// Fields
	private static object s_GetRequestStreamCallback; // 0x0
	private static object s_GetResponseCallback; // 0x8
	private object m_connectionGroupName; // 0x30
	private object m_contentLength; // 0x38
	private object m_credentials; // 0x40
	private object m_fileAccess; // 0x48
	private object m_headers; // 0x50
	private object m_method; // 0x58
	private object m_proxy; // 0x60
	private object m_readerEvent; // 0x68
	private object m_readPending; // 0x70
	private object m_response; // 0x78
	private object m_stream; // 0x80
	private object m_syncHint; // 0x88
	private object m_timeout; // 0x8C
	private object m_uri; // 0x90
	private object m_writePending; // 0x98
	private object m_writing; // 0x99
	private object m_WriteAResult; // 0xA0
	private object m_ReadAResult; // 0xA8
	private object m_Aborted; // 0xB0

	// Properties
	internal object Aborted { get; }
	public override object ContentLength { get; }
	public override object Credentials { get; set; }
	public override object Headers { get; }
	public override object Method { get; set; }
	public override object Proxy { get; set; }
	public override object Timeout { get; }
	public override object RequestUri { get; }
	public override object UseDefaultCredentials { get; }

	// Methods

	// RVA: 0x7203A58
	internal object .ctor(object uri) { }

	// RVA: 0x7203BD0
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x7203F9C
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x7203FFC
	protected override object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x72042D4
	internal object get_Aborted() { }

	// RVA: 0x72042E4
	public override object get_ContentLength() { }

	// RVA: 0x72042EC
	public override object get_Credentials() { }

	// RVA: 0x72042F4
	public override object set_Credentials(object value) { }

	// RVA: 0x72042FC
	public override object get_Headers() { }

	// RVA: 0x7204304
	public override object get_Method() { }

	// RVA: 0x720430C
	public override object set_Method(object value) { }

	// RVA: 0x7204400
	public override object get_Proxy() { }

	// RVA: 0x7204408
	public override object set_Proxy(object value) { }

	// RVA: 0x7204410
	public override object get_Timeout() { }

	// RVA: 0x7204418
	public override object get_RequestUri() { }

	// RVA: 0x7204420
	public override object BeginGetResponse(object callback, object state) { }

	// RVA: 0x7204744
	public override object EndGetResponse(object asyncResult) { }

	// RVA: 0x7204A28
	public override object GetResponse() { }

	// RVA: 0x7204E78
	private static object GetRequestStreamCallback(object state) { }

	// RVA: 0x72051B8
	private static object GetResponseCallback(object state) { }

	// RVA: 0x7205874
	internal object UnblockReader() { }

	// RVA: 0x720596C
	public override object get_UseDefaultCredentials() { }

	// RVA: 0x720599C
	public override object Abort() { }

	// RVA: 0x7205D54
	private static object .cctor() { }

}

// Namespace: System.Net
internal class FileWebRequestCreator
{

	// Methods

	// RVA: 0x7205E30
	internal object .ctor() { }

	// RVA: 0x7205E38
	public object Create(object uri) { }

}

// Namespace: System.Net
internal sealed class FileWebStream
{

	// Fields
	private object m_request; // 0x68

	// Methods

	// RVA: 0x7205118
	public object .ctor(object request, object path, object mode, object access, object sharing) { }

	// RVA: 0x7205E9C
	public object .ctor(object request, object path, object mode, object access, object sharing, object length, object async) { }

	// RVA: 0x7205F54
	protected override object Dispose(object disposing) { }

	// RVA: 0x7206070
	private object System.Net.ICloseEx.CloseEx(object closeState) { }

	// RVA: 0x72060FC
	public override object Read(object buffer, object offset, object size) { }

	// RVA: 0x7206258
	public override object Write(object buffer, object offset, object size) { }

	// RVA: 0x7206328
	public override object BeginRead(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x7206410
	public override object EndRead(object ar) { }

	// RVA: 0x72064B8
	public override object BeginWrite(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x72065A0
	public override object EndWrite(object ar) { }

	// RVA: 0x72061CC
	private object CheckError() { }

}

// Namespace: System.Net
public class FileWebResponse
{

	// Fields
	private object m_closed; // 0x11
	private object m_contentLength; // 0x18
	private object m_fileAccess; // 0x20
	private object m_headers; // 0x28
	private object m_stream; // 0x30
	private object m_uri; // 0x38

	// Properties
	public override object Headers { get; }
	public override object ResponseUri { get; }

	// Methods

	// RVA: 0x720552C
	internal object .ctor(object request, object uri, object access, object asyncHint) { }

	// RVA: 0x7206648
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x72068B4
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x7206914
	protected override object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x7206B04
	public override object get_Headers() { }

	// RVA: 0x7206BA4
	public override object get_ResponseUri() { }

	// RVA: 0x7206B28
	private object CheckDisposed() { }

	// RVA: 0x7206BC8
	public override object Close() { }

	// RVA: 0x7206C84
	private object System.Net.ICloseEx.CloseEx(object closeState) { }

	// RVA: 0x7206E20
	public override object GetResponseStream() { }

}

// Namespace: System.Net
public interface IWebProxy
{

	// Properties
	public abstract object Credentials { get; }

	// Methods

	// RVA: -1
	public abstract object GetProxy(object destination) { }

	// RVA: -1
	public abstract object IsBypassed(object host) { }

	// RVA: -1
	public abstract object get_Credentials() { }

}

// Namespace: System.Net
public class WebProxy
{

	// Fields
	private object _UseRegistry; // 0x8
	private object _BypassOnLocal; // 0x9
	private object m_EnableAutoproxy; // 0xA
	private object _ProxyAddress; // 0x10
	private object _BypassList; // 0x18
	private object _Credentials; // 0x20
	private object _RegExBypassList; // 0x28
	private object _ProxyHostAddresses; // 0x30
	private object m_ScriptEngine; // 0x38

	// Properties
	public object Credentials { get; }
	public object UseDefaultCredentials { get; set; }
	internal object ScriptEngine { get; }

	// Methods

	// RVA: 0x7206E7C
	public object .ctor() { }

	// RVA: 0x7206ED4
	public object .ctor(object Address, object BypassOnLocal, object BypassList, object Credentials) { }

	// RVA: 0x72072E0
	public object get_Credentials() { }

	// RVA: 0x72072E8
	public object get_UseDefaultCredentials() { }

	// RVA: 0x7207370
	public object set_UseDefaultCredentials(object value) { }

	// RVA: 0x72073F8
	public object GetProxy(object destination) { }

	// RVA: 0x7206F84
	private object UpdateRegExList(object canThrow) { }

	// RVA: 0x7207730
	private object IsMatchInBypassList(object input) { }

	// RVA: 0x7207928
	private object IsLocal(object host) { }

	// RVA: 0x7207B14
	private object IsLocalInProxyHash(object host) { }

	// RVA: 0x7207C38
	public object IsBypassed(object host) { }

	// RVA: 0x7207634
	private object IsBypassedManual(object host) { }

	// RVA: 0x7207D84
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x7208170
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x72081D0
	protected virtual object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x720835C
	internal object get_ScriptEngine() { }

	// RVA: 0x7208364
	public static object CreateDefaultProxy() { }

	// RVA: 0x72083C8
	internal object .ctor(object enableAutoproxy) { }

	// RVA: 0x7208164
	internal object UnsafeUpdateFromRegistry() { }

	// RVA: 0x72075E4
	private object GetProxyAuto(object destination, object proxyUri) { }

	// RVA: 0x7207D3C
	private object IsBypassedAuto(object destination, object isBypassed) { }

	// RVA: 0x7208408
	private static object AreAllBypassed(object proxies, object checkFirstOnly) { }

	// RVA: 0x720876C
	private static object ProxyUri(object proxyName) { }

}

// Namespace: System.Net
internal class AutoWebProxyScriptEngine
{

	// Methods

	// RVA: 0x72083FC
	public object GetProxies(object destination, object proxyList) { }

	// RVA: 0x7208810
	public object GetProxies(object destination, object proxyList, object syncStatus) { }

}

// Namespace: 
internal static class HTTP_REQUEST_HEADER_ID
{

	// Fields
	private static object m_Strings; // 0x0

	// Methods

	// RVA: 0x7208CD4
	internal static object ToString(object position) { }

	// RVA: 0x7208D7C
	private static object .cctor() { }

}

// Namespace: 
internal static class HttpApi
{

	// Fields
	private static object m_Strings; // 0x0

	// Methods

	// RVA: 0x720881C
	private static object .cctor() { }

}

// Namespace: 
internal static class SecureStringHelper
{

	// Methods

	// RVA: 0x72093C0
	internal static object CreateString(object secureString) { }

	// RVA: 0x72095B0
	internal static object CreateSecureString(object plainString) { }

}

// Namespace: System.Net
internal static class UnsafeNclNativeMethods
{
}

// Namespace: System.Net
internal static class Logging
{

	// Properties
	internal static object On { get; }

	// Methods

	// RVA: 0x720473C
	internal static object get_On() { }

}

// Namespace: 
private class CallbackContext
{

	// Fields
	internal readonly object request; // 0x8
	internal readonly object certificate; // 0x10
	internal readonly object chain; // 0x18
	internal readonly object sslPolicyErrors; // 0x20
	internal object result; // 0x24

	// Methods

	// RVA: 0x7209920
	internal object .ctor(object request, object certificate, object chain, object sslPolicyErrors) { }

}

// Namespace: System.Net
internal class ServerCertValidationCallback
{

	// Fields
	private readonly object m_ValidationCallback; // 0x8
	private readonly object m_Context; // 0x10

	// Properties
	internal object ValidationCallback { get; }

	// Methods

	// RVA: 0x7209660
	internal object .ctor(object validationCallback) { }

	// RVA: 0x72096DC
	internal object get_ValidationCallback() { }

	// RVA: 0x72096E4
	internal object Callback(object state) { }

	// RVA: 0x72097AC
	internal object Invoke(object request, object certificate, object chain, object sslPolicyErrors) { }

}

// Namespace: System.Net
public class AuthenticationManager
{

	// Fields
	private static object modules; // 0x0
	private static object locker; // 0x8
	private static object credential_policy; // 0x10

	// Methods

	// RVA: 0x7209970
	private static object EnsureModules() { }

	// RVA: 0x7209D20
	public static object Authenticate(object challenge, object request, object credentials) { }

	// RVA: 0x7209E24
	private static object DoAuthenticate(object challenge, object request, object credentials) { }

	// RVA: 0x720A3AC
	public static object PreAuthenticate(object request, object credentials) { }

	// RVA: 0x720A988
	private static object .cctor() { }

}

// Namespace: System.Net
internal class BasicClient
{

	// Properties
	public object AuthenticationType { get; }

	// Methods

	// RVA: 0x720AA04
	public object Authenticate(object challenge, object webRequest, object credentials) { }

	// RVA: 0x720AE44
	private static object GetBytes(object str) { }

	// RVA: 0x720AAC8
	private static object InternalAuthenticate(object webRequest, object credentials) { }

	// RVA: 0x720AF14
	public object PreAuthenticate(object webRequest, object credentials) { }

	// RVA: 0x720AF20
	public object get_AuthenticationType() { }

	// RVA: 0x7209D18
	public object .ctor() { }

}

// Namespace: System.Net
public sealed class BindIPEndPoint
{

	// Methods

	// RVA: 0x720B2C8
	public object .ctor(object object, object method) { }

	// RVA: 0x720B3D4
	public virtual object Invoke(object servicePoint, object remoteEndPoint, object retryCount) { }

}

// Namespace: 
private struct <ProcessReadAsync>d__2
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object cancellationToken; // 0x18
	public object <>4__this; // 0x20
	public object size; // 0x28
	public object buffer; // 0x30
	public object offset; // 0x38
	private object <>u__1; // 0x40

	// Methods

	// RVA: 0x720B5F4
	private object MoveNext() { }

	// RVA: 0x720B97C
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class BufferedReadStream
{

	// Fields
	private readonly object readBuffer; // 0x38

	// Methods

	// RVA: 0x720B3E8
	public object .ctor(object operation, object innerStream, object readBuffer) { }

	// RVA: 0x720B414
	protected override object ProcessReadAsync(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x720B544
	internal object TryReadFromBuffer(object buffer, object offset, object size, object result) { }

}

// Namespace: 
internal enum Mode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object GZip;
	public const object Deflate;
}

// Namespace: System.Net
internal class ContentDecodeStream
{

	// Fields
	private readonly object <OriginalInnerStream>k__BackingField; // 0x38

	// Properties
	private object OriginalInnerStream { get; }

	// Methods

	// RVA: 0x720BA7C
	public static object Create(object operation, object innerStream, object mode) { }

	// RVA: 0x720BB88
	private object get_OriginalInnerStream() { }

	// RVA: 0x720BB5C
	private object .ctor(object operation, object decodeStream, object originalInnerStream) { }

	// RVA: 0x720BB90
	protected override object ProcessReadAsync(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x720BC10
	internal override object FinishReading(object cancellationToken) { }

}

// Namespace: System.Net
public enum DecompressionMethods
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object GZip;
	public const object Deflate;
}

// Namespace: System.Net
internal class DefaultCertificatePolicy
{
}

// Namespace: System.Net
internal class DigestHeaderParser
{

	// Fields
	private object header; // 0x8
	private object length; // 0x10
	private object pos; // 0x14
	private static object keywords; // 0x0
	private object values; // 0x18

	// Properties
	public object Realm { get; }
	public object Opaque { get; }
	public object Nonce { get; }
	public object Algorithm { get; }
	public object QOP { get; }

	// Methods

	// RVA: 0x720BD58
	public object .ctor(object header) { }

	// RVA: 0x720BE3C
	public object get_Realm() { }

	// RVA: 0x720BE70
	public object get_Opaque() { }

	// RVA: 0x720BEA8
	public object get_Nonce() { }

	// RVA: 0x720BEE0
	public object get_Algorithm() { }

	// RVA: 0x720BF18
	public object get_QOP() { }

	// RVA: 0x720BF50
	public object Parse() { }

	// RVA: 0x720C434
	private object SkipWhitespace() { }

	// RVA: 0x720C4C8
	private object GetKey() { }

	// RVA: 0x720C1B4
	private object GetKeywordAndValue(object key, object value) { }

	// RVA: 0x720C5F4
	private static object .cctor() { }

}

// Namespace: System.Net
internal class DigestSession
{

	// Fields
	private static object rng; // 0x0
	private object lastUse; // 0x8
	private object _nc; // 0x10
	private object hash; // 0x18
	private object parser; // 0x20
	private object _cnonce; // 0x28

	// Properties
	public object Algorithm { get; }
	public object Realm { get; }
	public object Nonce { get; }
	public object Opaque { get; }
	public object QOP { get; }
	public object CNonce { get; }
	public object LastUse { get; }

	// Methods

	// RVA: 0x720C728
	private static object .cctor() { }

	// RVA: 0x720C77C
	public object .ctor() { }

	// RVA: 0x720C7F8
	public object get_Algorithm() { }

	// RVA: 0x720C838
	public object get_Realm() { }

	// RVA: 0x720C874
	public object get_Nonce() { }

	// RVA: 0x720C8B4
	public object get_Opaque() { }

	// RVA: 0x720C8F4
	public object get_QOP() { }

	// RVA: 0x720C934
	public object get_CNonce() { }

	// RVA: 0x720CA6C
	public object Parse(object challenge) { }

	// RVA: 0x720CB94
	private object HashToHexString(object toBeHashed) { }

	// RVA: 0x720CDA0
	private object HA1(object username, object password) { }

	// RVA: 0x720CEE4
	private object HA2(object webRequest) { }

	// RVA: 0x720D00C
	private object Response(object username, object password, object webRequest) { }

	// RVA: 0x720D194
	public object Authenticate(object webRequest, object credentials) { }

	// RVA: 0x720D868
	public object get_LastUse() { }

}

// Namespace: System.Net
internal class DigestClient
{

	// Fields
	private static readonly object cache; // 0x0

	// Properties
	private static object Cache { get; }
	public object AuthenticationType { get; }

	// Methods

	// RVA: 0x720D870
	private static object get_Cache() { }

	// RVA: 0x720DA5C
	private static object CheckExpired(object count) { }

	// RVA: 0x720E404
	public object Authenticate(object challenge, object webRequest, object credentials) { }

	// RVA: 0x720E7A0
	public object PreAuthenticate(object webRequest, object credentials) { }

	// RVA: 0x720E9A4
	public object get_AuthenticationType() { }

	// RVA: 0x7209D10
	public object .ctor() { }

	// RVA: 0x720E9E8
	private static object .cctor() { }

}

// Namespace: 
private sealed class GetHostAddressesCallback
{

	// Methods

	// RVA: 0x720ECB0
	public object .ctor(object object, object method) { }

	// RVA: 0x720FCC4
	public virtual object Invoke(object hostName) { }

	// RVA: 0x720ED58
	public virtual object BeginInvoke(object hostName, object callback, object object) { }

	// RVA: 0x720EED0
	public virtual object EndInvoke(object result) { }

}

// Namespace: System.Net
public static class Dns
{

	// Methods

	// RVA: 0x720EA70
	public static object BeginGetHostAddresses(object hostNameOrAddress, object requestCallback, object state) { }

	// RVA: 0x720EDA8
	public static object EndGetHostAddresses(object asyncResult) { }

	// RVA: 0x720EEDC
	private static object GetHostByName_icall(object host, object h_name, object h_aliases, object h_addr_list, object hint) { }

	// RVA: 0x720EEE0
	private static object GetHostByAddr_icall(object addr, object h_name, object h_aliases, object h_addr_list, object hint) { }

	// RVA: 0x720EEE4
	private static object GetHostName_icall(object h_name) { }

	// RVA: 0x720EEE8
	private static object Error_11001(object hostName) { }

	// RVA: 0x720EF50
	private static object hostent_to_IPHostEntry(object originalHostName, object h_name, object h_aliases, object h_addrlist) { }

	// RVA: 0x720F330
	private static object GetHostByAddressFromString(object address, object parse) { }

	// RVA: 0x720F4B8
	public static object GetHostEntry(object hostNameOrAddress) { }

	// RVA: 0x720F664
	public static object GetHostEntry(object address) { }

	// RVA: 0x720F834
	public static object GetHostAddresses(object hostNameOrAddress) { }

	// RVA: 0x720F6F8
	public static object GetHostByName(object hostName) { }

	// RVA: 0x720FA60
	public static object GetHostName() { }

	// RVA: 0x720FAF8
	public static object GetHostAddressesAsync(object hostNameOrAddress) { }

}

// Namespace: 
private struct <ProcessReadAsync>d__5
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object cancellationToken; // 0x18
	public object <>4__this; // 0x20
	public object size; // 0x28
	public object buffer; // 0x30
	public object offset; // 0x38
	private object <>u__1; // 0x40

	// Methods

	// RVA: 0x720FE3C
	private object MoveNext() { }

	// RVA: 0x72101D8
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class FixedSizeReadStream
{

	// Fields
	private readonly object <ContentLength>k__BackingField; // 0x38
	private object position; // 0x40

	// Properties
	public object ContentLength { get; }

	// Methods

	// RVA: 0x720FCD8
	public object get_ContentLength() { }

	// RVA: 0x720FCE0
	public object .ctor(object operation, object innerStream, object contentLength) { }

	// RVA: 0x720FD0C
	protected override object ProcessReadAsync(object buffer, object offset, object size, object cancellationToken) { }

}

// Namespace: System.Net
internal class HttpRequestCreator
{

	// Methods

	// RVA: 0x72102D8
	internal object .ctor() { }

	// RVA: 0x72102E0
	public object Create(object uri) { }

}

// Namespace: 
private enum NtlmAuthState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Challenge;
	public const object Response;
}

// Namespace: 
private struct AuthorizationState
{

	// Fields
	private readonly object request; // 0xFFFFFFFFFFFFFFF8
	private readonly object isProxy; // 0x0
	private object isCompleted; // 0x1
	private object ntlm_auth_state; // 0x4

	// Properties
	public object IsCompleted { get; }
	public object NtlmAuthState { get; }
	public object IsNtlmAuthenticated { get; }

	// Methods

	// RVA: 0x7215194
	public object get_IsCompleted() { }

	// RVA: 0x72151A4
	public object get_NtlmAuthState() { }

	// RVA: 0x72151B4
	public object get_IsNtlmAuthenticated() { }

	// RVA: 0x72106BC
	public object .ctor(object request, object isProxy) { }

	// RVA: 0x7214334
	public object CheckAuthorization(object response, object code) { }

	// RVA: 0x7214F84
	public object Reset() { }

	// RVA: 0x72152B4
	public override object ToString() { }

}

// Namespace: 
private sealed class <>c__241<T0>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__241_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <RunWithTimeoutWorker>b__241_0(object t) { }

}

// Namespace: 
private struct <RunWithTimeoutWorker>d__241<T0>
{

	// Fields
	public object <>1__state; // 0x0
	public object <>t__builder; // 0x0
	public object workerTask; // 0x0
	public object timeout; // 0x0
	public object cts; // 0x0
	public object abort; // 0x0
	public object aborted; // 0x0
	private object <>u__1; // 0x0

	// Methods

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <MyGetResponseAsync>d__243
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <completion>5__2; // 0x28
	private object <operation>5__3; // 0x30
	private object <throwMe>5__4; // 0x38
	private object <response>5__5; // 0x40
	private object <stream>5__6; // 0x48
	private object <redirect>5__7; // 0x50
	private object <mustReadAll>5__8; // 0x51
	private object <ntlm>5__9; // 0x58
	private object <writeBuffer>5__10; // 0x60
	private object <>u__1; // 0x68
	private object <>u__2; // 0x78
	private object <>u__3; // 0x88
	private object <>u__4; // 0x90

	// Methods

	// RVA: 0x72153C8
	private object MoveNext() { }

	// RVA: 0x7216430
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <GetResponseFromData>d__244
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object stream; // 0x20
	public object cancellationToken; // 0x28
	private object <response>5__2; // 0x30
	private object <throwMe>5__3; // 0x38
	private object <redirect>5__4; // 0x40
	private object <mustReadAll>5__5; // 0x41
	private object <>u__1; // 0x48
	private object <>u__2; // 0x58

	// Methods

	// RVA: 0x7216530
	private object MoveNext() { }

	// RVA: 0x721715C
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <<GetRewriteHandler>b__271_0>d
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	private object <ms>5__2; // 0x20
	private object <>u__1; // 0x28

	// Methods

	// RVA: 0x721725C
	private object MoveNext() { }

	// RVA: 0x7217810
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
public class HttpWebRequest
{

	// Fields
	private object requestUri; // 0x30
	private object actualUri; // 0x38
	private object hostChanged; // 0x40
	private object allowAutoRedirect; // 0x41
	private object allowBuffering; // 0x42
	private object certificates; // 0x48
	private object connectionGroup; // 0x50
	private object haveContentLength; // 0x58
	private object contentLength; // 0x60
	private object continueDelegate; // 0x68
	private object cookieContainer; // 0x70
	private object credentials; // 0x78
	private object haveResponse; // 0x80
	private object requestSent; // 0x81
	private object webHeaders; // 0x88
	private object keepAlive; // 0x90
	private object maxAutoRedirect; // 0x94
	private object mediaType; // 0x98
	private object method; // 0xA0
	private object initialMethod; // 0xA8
	private object pipelined; // 0xB0
	private object preAuthenticate; // 0xB1
	private object usedPreAuth; // 0xB2
	private object version; // 0xB8
	private object force_version; // 0xC0
	private object actualVersion; // 0xC8
	private object proxy; // 0xD0
	private object sendChunked; // 0xD8
	private object servicePoint; // 0xE0
	private object timeout; // 0xE8
	private object continueTimeout; // 0xEC
	private object writeStream; // 0xF0
	private object webResponse; // 0xF8
	private object responseTask; // 0x100
	private object currentOperation; // 0x108
	private object aborted; // 0x110
	private object gotRequestStream; // 0x114
	private object redirects; // 0x118
	private object expectContinue; // 0x11C
	private object getResponseCalled; // 0x11D
	private object locker; // 0x120
	private object finished_reading; // 0x128
	private object auto_decomp; // 0x12C
	private static object defaultMaxResponseHeadersLength; // 0x0
	private static object defaultMaximumErrorResponseLength; // 0x4
	private static object defaultCachePolicy; // 0x8
	private object readWriteTimeout; // 0x130
	private object tlsProvider; // 0x138
	private object tlsSettings; // 0x140
	private object certValidationCallback; // 0x148
	private object hostHasPort; // 0x150
	private object hostUri; // 0x158
	private object auth_state; // 0x160
	private object proxy_auth_state; // 0x170
	internal object ResendContentFactory; // 0x180
	private object <ThrowOnError>k__BackingField; // 0x188
	private object unsafe_auth_blah; // 0x189

	// Properties
	public object Address { get; }
	public virtual object AllowWriteStreamBuffering { get; }
	public object AutomaticDecompression { get; }
	internal object InternalAllowBuffering { get; }
	private object MethodWithBuffer { get; }
	internal object TlsProvider { get; }
	internal object TlsSettings { get; }
	public object ClientCertificates { get; }
	public override object ContentLength { get; }
	internal object InternalContentLength { set; }
	internal object ThrowOnError { get; set; }
	public override object Credentials { get; set; }
	public static object DefaultMaximumErrorResponseLength { get; }
	public override object Headers { get; }
	public object Host { get; }
	public object KeepAlive { get; }
	public object ReadWriteTimeout { get; }
	public override object Method { get; set; }
	public object ProtocolVersion { get; }
	public override object Proxy { get; set; }
	public override object RequestUri { get; }
	public object SendChunked { get; }
	public object ServicePoint { get; }
	internal object ServicePointNoLock { get; }
	public override object Timeout { get; }
	public object TransferEncoding { get; }
	public override object UseDefaultCredentials { get; }
	public object UnsafeAuthenticatedConnectionSharing { get; }
	internal object ExpectContinue { get; set; }
	internal object AuthUri { get; }
	internal object ProxyQuery { get; }
	internal object ServerCertValidationCallback { get; }
	internal object FinishedReading { set; }
	internal object Aborted { get; }

	// Methods

	// RVA: 0x72104EC
	private static object .cctor() { }

	// RVA: 0x7210344
	public object .ctor(object uri) { }

	// RVA: 0x721058C
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x721057C
	private object ResetAuthorization() { }

	// RVA: 0x72106D0
	public object get_Address() { }

	// RVA: 0x72106D8
	public virtual object get_AllowWriteStreamBuffering() { }

	// RVA: 0x72106E0
	public object get_AutomaticDecompression() { }

	// RVA: 0x72106E8
	internal object get_InternalAllowBuffering() { }

	// RVA: 0x7210700
	private object get_MethodWithBuffer() { }

	// RVA: 0x721080C
	internal object get_TlsProvider() { }

	// RVA: 0x7210814
	internal object get_TlsSettings() { }

	// RVA: 0x721081C
	public object get_ClientCertificates() { }

	// RVA: 0x7210898
	public override object get_ContentLength() { }

	// RVA: 0x72108A0
	internal object set_InternalContentLength(object value) { }

	// RVA: 0x72108A8
	internal object get_ThrowOnError() { }

	// RVA: 0x72108B0
	internal object set_ThrowOnError(object value) { }

	// RVA: 0x72108B8
	public override object get_Credentials() { }

	// RVA: 0x72108C0
	public override object set_Credentials(object value) { }

	// RVA: 0x72108C8
	public static object get_DefaultMaximumErrorResponseLength() { }

	// RVA: 0x7210944
	public override object get_Headers() { }

	// RVA: 0x721094C
	public object get_Host() { }

	// RVA: 0x7210AC4
	public object get_KeepAlive() { }

	// RVA: 0x7210ACC
	public object get_ReadWriteTimeout() { }

	// RVA: 0x7210AD4
	public override object get_Method() { }

	// RVA: 0x7210ADC
	public override object set_Method(object value) { }

	// RVA: 0x7210D18
	public object get_ProtocolVersion() { }

	// RVA: 0x7210D20
	public override object get_Proxy() { }

	// RVA: 0x7210D28
	public override object set_Proxy(object value) { }

	// RVA: 0x7210F50
	public override object get_RequestUri() { }

	// RVA: 0x7210F58
	public object get_SendChunked() { }

	// RVA: 0x7210F60
	public object get_ServicePoint() { }

	// RVA: 0x7210F64
	internal object get_ServicePointNoLock() { }

	// RVA: 0x7210F6C
	public override object get_Timeout() { }

	// RVA: 0x7210F74
	public object get_TransferEncoding() { }

	// RVA: 0x7210FD4
	public override object get_UseDefaultCredentials() { }

	// RVA: 0x7211094
	public object get_UnsafeAuthenticatedConnectionSharing() { }

	// RVA: 0x721109C
	internal object get_ExpectContinue() { }

	// RVA: 0x72110A4
	internal object set_ExpectContinue(object value) { }

	// RVA: 0x72110AC
	internal object get_AuthUri() { }

	// RVA: 0x72110B4
	internal object get_ProxyQuery() { }

	// RVA: 0x72110F4
	internal object get_ServerCertValidationCallback() { }

	// RVA: 0x7210DF8
	internal object GetServicePoint() { }

	// RVA: 0x7211860
	private object SendRequest(object redirecting, object writeBuffer, object cancellationToken) { }

	// RVA: -1
	internal static object RunWithTimeout(object func, object timeout, object abort, object aborted, object cancellationToken) { }

	// RVA: -1
	private static object RunWithTimeoutWorker(object workerTask, object timeout, object abort, object aborted, object cts) { }

	// RVA: -1
	private object RunWithTimeout(object func) { }

	// RVA: 0x7211C58
	private object MyGetResponseAsync(object cancellationToken) { }

	// RVA: 0x7211D78
	private object GetResponseFromData(object stream, object cancellationToken) { }

	// RVA: 0x7211E90
	internal static object FlattenException(object e) { }

	// RVA: 0x7211F78
	private object GetWebException(object e) { }

	// RVA: 0x7212028
	private static object GetWebException(object e, object aborted) { }

	// RVA: 0x721221C
	internal static object CreateRequestAbortedException() { }

	// RVA: 0x72122DC
	public override object BeginGetResponse(object callback, object state) { }

	// RVA: 0x72124AC
	public override object EndGetResponse(object asyncResult) { }

	// RVA: 0x72125F0
	public override object GetResponse() { }

	// RVA: 0x7212718
	internal object set_FinishedReading(object value) { }

	// RVA: 0x7211FFC
	internal object get_Aborted() { }

	// RVA: 0x7212720
	public override object Abort() { }

	// RVA: 0x7212850
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x7212890
	protected override object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x7210D94
	private object CheckRequestStarted() { }

	// RVA: 0x72128D0
	internal object DoContinueDelegate(object statusCode, object headers) { }

	// RVA: 0x72128EC
	private object RewriteRedirectToGet() { }

	// RVA: 0x7212978
	private object Redirect(object code, object response) { }

	// RVA: 0x7212F7C
	private object GetHeaders() { }

	// RVA: 0x721391C
	private object DoPreAuthenticate() { }

	// RVA: 0x7213BBC
	internal object GetRequestHeaders() { }

	// RVA: 0x7213FEC
	private object HandleNtlmAuth(object stream, object response, object writeBuffer, object cancellationToken) { }

	// RVA: 0x721431C
	private object CheckAuthorization(object response, object code) { }

	// RVA: 0x721476C
	private object GetRewriteHandler(object response, object redirect) { }

	// RVA: 0x72149A8
	private object CheckFinalStatus(object response) { }

	// RVA: -1
	private object <RunWithTimeout>b__242_0() { }

	// RVA: 0x7215020
	private object <GetRewriteHandler>b__271_0() { }

	// RVA: 0x721511C
	public object .ctor() { }

}

// Namespace: System.Net
public class HttpWebResponse
{

	// Fields
	private object uri; // 0x18
	private object webHeaders; // 0x20
	private object cookieCollection; // 0x28
	private object method; // 0x30
	private object version; // 0x38
	private object statusCode; // 0x40
	private object statusDescription; // 0x48
	private object contentLength; // 0x50
	private object contentType; // 0x58
	private object cookie_container; // 0x60
	private object disposed; // 0x68
	private object stream; // 0x70

	// Properties
	public override object Headers { get; }
	public override object ResponseUri { get; }
	public virtual object StatusCode { get; }
	public virtual object StatusDescription { get; }

	// Methods

	// RVA: 0x7217910
	public object .ctor() { }

	// RVA: 0x7217918
	internal object .ctor(object uri, object method, object status, object headers) { }

	// RVA: 0x7216DE8
	internal object .ctor(object uri, object method, object stream, object container) { }

	// RVA: 0x7217C64
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x7218028
	public override object get_Headers() { }

	// RVA: 0x7218030
	public override object get_ResponseUri() { }

	// RVA: 0x72180D0
	public virtual object get_StatusCode() { }

	// RVA: 0x72180D8
	public virtual object get_StatusDescription() { }

	// RVA: 0x72180FC
	public override object GetResponseStream() { }

	// RVA: 0x72181A4
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x7218204
	protected override object GetObjectData(object serializationInfo, object streamingContext) { }

	// RVA: 0x72183D8
	public override object Close() { }

	// RVA: 0x7218438
	private object System.IDisposable.Dispose() { }

	// RVA: 0x721847C
	protected override object Dispose(object disposing) { }

	// RVA: 0x7218054
	private object CheckDisposed() { }

	// RVA: 0x72179D8
	private object FillCookies() { }

}

// Namespace: System.Net
public interface ICredentialPolicy
{
}

// Namespace: 
private enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object PartialSize;
	public const object Body;
	public const object BodyFinished;
	public const object Trailer;
}

// Namespace: 
private class Chunk
{

	// Fields
	public object Bytes; // 0x8
	public object Offset; // 0x10

	// Methods

	// RVA: 0x7219858
	public object .ctor(object chunk) { }

	// RVA: 0x7218954
	public object Read(object buffer, object offset, object size) { }

}

// Namespace: System.Net
internal class MonoChunkParser
{

	// Fields
	private object headers; // 0x8
	private object chunkSize; // 0x10
	private object chunkRead; // 0x14
	private object totalWritten; // 0x18
	private object state; // 0x1C
	private object saved; // 0x20
	private object sawCR; // 0x28
	private object gotit; // 0x29
	private object trailerState; // 0x2C
	private object chunks; // 0x30

	// Properties
	public object WantMore { get; }
	public object DataAvailable { get; }
	public object ChunkLeft { get; }

	// Methods

	// RVA: 0x7218490
	public object .ctor(object headers) { }

	// RVA: 0x7218548
	public object Read(object buffer, object offset, object size) { }

	// RVA: 0x721854C
	private object ReadFromChunks(object buffer, object offset, object size) { }

	// RVA: 0x7218A00
	public object Write(object buffer, object offset, object size) { }

	// RVA: 0x7218A2C
	private object InternalWrite(object buffer, object offset, object size) { }

	// RVA: 0x72196C4
	public object get_WantMore() { }

	// RVA: 0x72196E8
	public object get_DataAvailable() { }

	// RVA: 0x721984C
	public object get_ChunkLeft() { }

	// RVA: 0x7218FE4
	private object ReadBody(object buffer, object offset, object size) { }

	// RVA: 0x7218B84
	private object GetChunkSize(object buffer, object offset, object size) { }

	// RVA: 0x72198D8
	private static object RemoveChunkExtension(object input) { }

	// RVA: 0x7219148
	private object ReadCRLF(object buffer, object offset, object size) { }

	// RVA: 0x72192C4
	private object ReadTrailer(object buffer, object offset, object size) { }

	// RVA: 0x7219884
	private static object ThrowProtocolViolation(object message) { }

}

// Namespace: 
private struct <ProcessReadAsync>d__7
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object cancellationToken; // 0x18
	public object <>4__this; // 0x20
	public object buffer; // 0x28
	public object offset; // 0x30
	public object size; // 0x34
	private object <moreBytes>5__2; // 0x38
	private object <>u__1; // 0x40

	// Methods

	// RVA: 0x7219C3C
	private object MoveNext() { }

	// RVA: 0x721A0EC
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <FinishReading>d__8
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <>u__1; // 0x28
	private object <buffer>5__2; // 0x38
	private object <>u__2; // 0x40

	// Methods

	// RVA: 0x721A1EC
	private object MoveNext() { }

	// RVA: 0x721A808
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class MonoChunkStream
{

	// Fields
	private readonly object <Headers>k__BackingField; // 0x38
	private readonly object <Decoder>k__BackingField; // 0x40

	// Properties
	protected object Decoder { get; }

	// Methods

	// RVA: 0x7219938
	protected object get_Decoder() { }

	// RVA: 0x7219940
	public object .ctor(object operation, object innerStream, object headers) { }

	// RVA: 0x72199D0
	protected override object ProcessReadAsync(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x7219AFC
	internal override object FinishReading(object cancellationToken) { }

	// RVA: 0x7219BD4
	private static object ThrowExpectingChunkTrailer() { }

	// RVA: 0x7219C34
	private object <>n__0(object cancellationToken) { }

}

// Namespace: System.Net
internal class NtlmClient
{

	// Fields
	private object authObject; // 0x8

	// Properties
	public object AuthenticationType { get; }

	// Methods

	// RVA: 0x7209CA0
	public object .ctor() { }

	// RVA: 0x721A8E0
	public object Authenticate(object challenge, object webRequest, object credentials) { }

	// RVA: 0x721A9D8
	public object PreAuthenticate(object webRequest, object credentials) { }

	// RVA: 0x721A9E0
	public object get_AuthenticationType() { }

}

// Namespace: System.Net
public class ServicePoint
{

	// Fields
	private readonly object uri; // 0x8
	private object lastDnsResolve; // 0x10
	private object protocolVersion; // 0x18
	private object host; // 0x20
	private object usesProxy; // 0x28
	private object sendContinue; // 0x29
	private object useConnect; // 0x2A
	private object hostE; // 0x30
	private object useNagle; // 0x38
	private object endPointCallback; // 0x40
	private object tcp_keepalive; // 0x48
	private object tcp_keepalive_time; // 0x4C
	private object tcp_keepalive_interval; // 0x50
	private object disposed; // 0x54
	private object connectionLeaseTimeout; // 0x58
	private object receiveBufferSize; // 0x5C
	private readonly object <Key>k__BackingField; // 0x60
	private object <Scheduler>k__BackingField; // 0x68
	private object connectionLimit; // 0x70
	private object maxIdleTime; // 0x74
	private object m_ServerCertificateOrBytes; // 0x78
	private object m_ClientCertificateOrBytes; // 0x80

	// Properties
	internal object Key { get; }
	private object Scheduler { get; set; }
	public object Address { get; }
	public object ConnectionLimit { get; }
	public virtual object ProtocolVersion { get; }
	public object Expect100Continue { set; }
	public object UseNagleAlgorithm { get; set; }
	internal object SendContinue { get; set; }
	internal object UsesProxy { get; set; }
	internal object UseConnect { get; set; }
	private object HasTimedOut { get; }
	internal object HostEntry { get; }

	// Methods

	// RVA: 0x721AA24
	internal object .ctor(object key, object uri, object connectionLimit, object maxIdleTime) { }

	// RVA: 0x721AD38
	internal object get_Key() { }

	// RVA: 0x721AD40
	private object get_Scheduler() { }

	// RVA: 0x721AD48
	private object set_Scheduler(object value) { }

	// RVA: 0x721AD50
	public object get_Address() { }

	// RVA: 0x721AD58
	public object get_ConnectionLimit() { }

	// RVA: 0x721AD60
	public virtual object get_ProtocolVersion() { }

	// RVA: 0x721AD68
	public object set_Expect100Continue(object value) { }

	// RVA: 0x721AD70
	public object get_UseNagleAlgorithm() { }

	// RVA: 0x721AD78
	public object set_UseNagleAlgorithm(object value) { }

	// RVA: 0x7213870
	internal object get_SendContinue() { }

	// RVA: 0x721AD80
	internal object set_SendContinue(object value) { }

	// RVA: 0x721AD88
	public object SetTcpKeepAlive(object enabled, object keepAliveTime, object keepAliveInterval) { }

	// RVA: 0x721AE38
	internal object KeepAliveSetup(object socket) { }

	// RVA: 0x721AFBC
	private static object PutBytes(object bytes, object v, object offset) { }

	// RVA: 0x721B03C
	internal object get_UsesProxy() { }

	// RVA: 0x721B044
	internal object set_UsesProxy(object value) { }

	// RVA: 0x721B04C
	internal object get_UseConnect() { }

	// RVA: 0x721B054
	internal object set_UseConnect(object value) { }

	// RVA: 0x721B05C
	private object get_HasTimedOut() { }

	// RVA: 0x721B1C8
	internal object get_HostEntry() { }

	// RVA: 0x721B5C0
	internal object SetVersion(object version) { }

	// RVA: 0x7211AB0
	internal object SendRequest(object operation, object groupName) { }

	// RVA: 0x721B71C
	internal object FreeServicePoint() { }

	// RVA: 0x721B72C
	internal object UpdateServerCertificate(object certificate) { }

	// RVA: 0x721B790
	internal object UpdateClientCertificate(object certificate) { }

	// RVA: 0x721B7F4
	internal object CallEndPointDelegate(object sock, object remote) { }

}

// Namespace: 
internal class SPKey
{

	// Fields
	private object uri; // 0x8
	private object proxy; // 0x10
	private object use_connect; // 0x18

	// Properties
	public object UsesProxy { get; }

	// Methods

	// RVA: 0x721BE24
	public object .ctor(object uri, object proxy, object use_connect) { }

	// RVA: 0x721BF30
	public object get_UsesProxy() { }

	// RVA: 0x721BF9C
	public override object GetHashCode() { }

	// RVA: 0x721C0C0
	public override object Equals(object obj) { }

}

// Namespace: System.Net
public class ServicePointManager
{

	// Fields
	private static object servicePoints; // 0x0
	private static object policy; // 0x8
	private static object defaultConnectionLimit; // 0x10
	private static object maxServicePointIdleTime; // 0x14
	private static object maxServicePoints; // 0x18
	private static object dnsRefreshTimeout; // 0x1C
	private static object _checkCRL; // 0x20
	private static object _securityProtocol; // 0x24
	private static object expectContinue; // 0x28
	private static object useNagle; // 0x29
	private static object server_cert_cb; // 0x30
	private static object tcp_keepalive; // 0x38
	private static object tcp_keepalive_time; // 0x3C
	private static object tcp_keepalive_interval; // 0x40

	// Properties
	public static object CheckCertificateRevocationList { get; }
	public static object DnsRefreshTimeout { get; }
	public static object SecurityProtocol { get; }
	internal static object ServerCertValidationCallback { get; }
	public static object ServerCertificateValidationCallback { get; }

	// Methods

	// RVA: 0x721BA58
	private static object .cctor() { }

	// RVA: 0x721BB04
	internal static object GetLegacyCertificatePolicy() { }

	// RVA: 0x721BB80
	public static object get_CheckCertificateRevocationList() { }

	// RVA: 0x721BBFC
	public static object get_DnsRefreshTimeout() { }

	// RVA: 0x721BC78
	public static object get_SecurityProtocol() { }

	// RVA: 0x721BCF4
	internal static object get_ServerCertValidationCallback() { }

	// RVA: 0x721BD70
	public static object get_ServerCertificateValidationCallback() { }

	// RVA: 0x72110FC
	public static object FindServicePoint(object address, object proxy) { }

	// RVA: 0x721BE64
	internal static object RemoveServicePoint(object sp) { }

}

// Namespace: 
private class ConnectionGroup
{

	// Fields
	private readonly object <Scheduler>k__BackingField; // 0x8
	private readonly object <Name>k__BackingField; // 0x10
	private static object nextId; // 0x0
	public readonly object ID; // 0x18
	private object connections; // 0x20
	private object queue; // 0x28

	// Properties
	public object Scheduler { get; }

	// Methods

	// RVA: 0x721DFC4
	public object get_Scheduler() { }

	// RVA: 0x721C414
	public object .ctor(object scheduler, object name) { }

	// RVA: 0x721CC6C
	public object IsEmpty() { }

	// RVA: 0x721D424
	public object RemoveConnection(object connection) { }

	// RVA: 0x721D5C8
	public object Cleanup() { }

	// RVA: 0x721DE18
	public object EnqueueOperation(object operation) { }

	// RVA: 0x721D940
	public object GetNextOperation() { }

	// RVA: 0x721DFCC
	public object FindIdleConnection(object operation) { }

	// RVA: 0x721D6F4
	public object CreateOrReuseConnection(object operation, object force) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__4_0; // 0x8

	// Methods

	// RVA: 0x721E414
	private static object .cctor() { }

	// RVA: 0x721E474
	public object .ctor() { }

	// RVA: 0x721E47C
	internal object <Set>b__4_0(object s) { }

}

// Namespace: 
private class AsyncManualResetEvent
{

	// Fields
	private object m_tcs; // 0x8

	// Methods

	// RVA: 0x721E3AC
	public object WaitAsync(object millisecondTimeout) { }

	// RVA: 0x721C630
	public object Set() { }

	// RVA: 0x721CF68
	public object Reset() { }

	// RVA: 0x721C364
	public object .ctor(object state) { }

}

// Namespace: 
private struct <RunScheduler>d__32
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	private object <operationArray>5__2; // 0x20
	private object <idleArray>5__3; // 0x28
	private object <taskList>5__4; // 0x30
	private object <schedulerTask>5__5; // 0x38
	private object <finalCleanup>5__6; // 0x40
	private object <>u__1; // 0x48

	// Methods

	// RVA: 0x721E524
	private object MoveNext() { }

	// RVA: 0x721F5C4
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <WaitAsync>d__46
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object millisecondTimeout; // 0x18
	public object workerTask; // 0x20
	private object <cts>5__2; // 0x28
	private object <timeoutTask>5__3; // 0x30
	private object <>u__1; // 0x38

	// Methods

	// RVA: 0x721F69C
	private object MoveNext() { }

	// RVA: 0x721FC70
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class ServicePointScheduler
{

	// Fields
	private object <ServicePoint>k__BackingField; // 0x8
	private object running; // 0x10
	private object maxIdleTime; // 0x14
	private object schedulerEvent; // 0x18
	private object defaultGroup; // 0x20
	private object groups; // 0x28
	private object operations; // 0x30
	private object idleConnections; // 0x38
	private object currentConnections; // 0x40
	private object connectionLimit; // 0x44
	private object idleSince; // 0x48
	private static object nextId; // 0x0
	public readonly object ID; // 0x50

	// Properties
	private object ServicePoint { get; set; }
	public object MaxIdleTime { get; }

	// Methods

	// RVA: 0x721C34C
	private object get_ServicePoint() { }

	// RVA: 0x721C354
	private object set_ServicePoint(object value) { }

	// RVA: 0x721C35C
	public object get_MaxIdleTime() { }

	// RVA: 0x721AB04
	public object .ctor(object servicePoint, object connectionLimit, object maxIdleTime) { }

	// RVA: 0x721C528
	public object Run() { }

	// RVA: 0x721C91C
	private object RunScheduler() { }

	// RVA: 0x721C9EC
	private object Cleanup() { }

	// RVA: 0x721CD00
	private object RunSchedulerIteration() { }

	// RVA: 0x721D184
	private object OperationCompleted(object group, object operation) { }

	// RVA: 0x721D8FC
	private object CloseIdleConnection(object group, object connection) { }

	// RVA: 0x721D044
	private object SchedulerIteration(object group) { }

	// RVA: 0x721DA5C
	private object RemoveOperation(object operation) { }

	// RVA: 0x721D4D8
	private object RemoveIdleConnection(object connection) { }

	// RVA: 0x721DB4C
	private object FinalCleanup() { }

	// RVA: 0x721B5C8
	public object SendRequest(object operation, object groupName) { }

	// RVA: 0x721DBEC
	private object GetConnectionGroup(object name) { }

	// RVA: 0x721DE84
	private object OnConnectionCreated(object connection) { }

	// RVA: 0x721DE90
	private object OnConnectionClosed(object connection) { }

	// RVA: 0x721DEB8
	public static object WaitAsync(object workerTask, object millisecondTimeout) { }

	// RVA: 0x721DFC0
	private object <Run>b__31_0() { }

}

// Namespace: 
internal enum Status
{

	// Fields
	public object value__; // 0x0
	public const object Running;
	public const object Completed;
	public const object Canceled;
	public const object Faulted;
}

// Namespace: 
internal class Result
{

	// Fields
	private readonly object <Status>k__BackingField; // 0x0
	private readonly object <Error>k__BackingField; // 0x0
	private readonly object <Argument>k__BackingField; // 0x0

	// Properties
	public object Status { get; }
	public object Success { get; }
	public object Error { get; }
	public object Argument { get; }

	// Methods

	// RVA: -1
	public object get_Status() { }

	// RVA: -1
	public object get_Success() { }

	// RVA: -1
	public object get_Error() { }

	// RVA: -1
	public object get_Argument() { }

	// RVA: -1
	public object .ctor(object argument) { }

	// RVA: -1
	public object .ctor(object state, object error) { }

}

// Namespace: 
private struct <WaitForCompletion>d__15
{

	// Fields
	public object <>1__state; // 0x0
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x0
	private object <>u__1; // 0x0

	// Methods

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class WebCompletionSource<T0>
{

	// Fields
	private object completion; // 0x0
	private object currentResult; // 0x0

	// Properties
	internal object CurrentResult { get; }
	internal object Task { get; }

	// Methods

	// RVA: -1
	public object .ctor(object runAsync) { }

	// RVA: -1
	internal object get_CurrentResult() { }

	// RVA: -1
	internal object get_Task() { }

	// RVA: -1
	public object TrySetCompleted(object argument) { }

	// RVA: -1
	public object TrySetCompleted() { }

	// RVA: -1
	public object TrySetCanceled() { }

	// RVA: -1
	public object TrySetCanceled(object error) { }

	// RVA: -1
	public object TrySetException(object error) { }

	// RVA: -1
	public object ThrowOnError() { }

	// RVA: -1
	public object WaitForCompletion() { }

}

// Namespace: System.Net
internal class WebCompletionSource
{

	// Methods

	// RVA: 0x721FD70
	public object .ctor() { }

}

// Namespace: System.Net
internal enum ReadState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Status;
	public const object Headers;
	public const object Content;
	public const object Aborted;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__16_0; // 0x8
	public static object <>9__16_1; // 0x10

	// Methods

	// RVA: 0x7221CBC
	private static object .cctor() { }

	// RVA: 0x7221D1C
	public object .ctor() { }

	// RVA: 0x7221D24
	internal object <Connect>b__16_0(object targetEndPoint, object callback, object state) { }

	// RVA: 0x7221DD4
	internal object <Connect>b__16_1(object asyncResult) { }

}

// Namespace: 
private struct <Connect>d__16
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object operation; // 0x20
	public object cancellationToken; // 0x28
	private object <connectException>5__2; // 0x30
	private object <>7__wrap2; // 0x38
	private object <>7__wrap3; // 0x40
	private object <>u__1; // 0x48

	// Methods

	// RVA: 0x7221F0C
	private object MoveNext() { }

	// RVA: 0x7222A50
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <CreateStream>d__18
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object operation; // 0x20
	public object reused; // 0x28
	public object cancellationToken; // 0x30
	private object <stream>5__2; // 0x38
	private object <>u__1; // 0x40
	private object <>u__2; // 0x50

	// Methods

	// RVA: 0x7222B28
	private object MoveNext() { }

	// RVA: 0x7223480
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <InitConnection>d__19
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object operation; // 0x18
	public object cancellationToken; // 0x20
	public object <>4__this; // 0x28
	private object <reused>5__2; // 0x30
	private object <>u__1; // 0x38
	private object <>u__2; // 0x48

	// Methods

	// RVA: 0x7223580
	private object MoveNext() { }

	// RVA: 0x7223E38
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class WebConnection
{

	// Fields
	private object ntlm_credentials; // 0x8
	private object ntlm_authenticated; // 0x10
	private object unsafe_sharing; // 0x11
	private object networkStream; // 0x18
	private object socket; // 0x20
	private object monoTlsStream; // 0x28
	private object tunnel; // 0x30
	private object disposed; // 0x38
	private readonly object <ServicePoint>k__BackingField; // 0x40
	private object idleSince; // 0x48
	private object currentOperation; // 0x50

	// Properties
	public object ServicePoint { get; }
	public object Closed { get; }
	public object IdleSince { get; }
	internal object NtlmAuthenticated { get; set; }
	internal object NtlmCredential { get; set; }
	internal object UnsafeAuthenticatedConnectionSharing { get; set; }

	// Methods

	// RVA: 0x721FDCC
	public object get_ServicePoint() { }

	// RVA: 0x721FDD4
	public object .ctor(object sPoint) { }

	// RVA: 0x721FE00
	private object CanReuse() { }

	// RVA: 0x721FE38
	private object CheckReusable() { }

	// RVA: 0x721FF0C
	private object Connect(object operation, object cancellationToken) { }

	// RVA: 0x721FFF0
	private object CreateStream(object operation, object reused, object cancellationToken) { }

	// RVA: 0x7220110
	internal object InitConnection(object operation, object cancellationToken) { }

	// RVA: 0x7220224
	internal static object GetException(object status, object error) { }

	// RVA: 0x72203B0
	internal static object ReadLine(object buffer, object start, object max, object output) { }

	// RVA: 0x72205FC
	internal object CanReuseConnection(object operation) { }

	// RVA: 0x7220B44
	private object PrepareSharingNtlm(object operation) { }

	// RVA: 0x7220FA0
	private object Reset() { }

	// RVA: 0x722107C
	private object Close(object reset) { }

	// RVA: 0x722115C
	private object CloseSocket() { }

	// RVA: 0x7220B34
	public object get_Closed() { }

	// RVA: 0x7221414
	public object get_IdleSince() { }

	// RVA: 0x722141C
	public object StartOperation(object operation, object reused) { }

	// RVA: 0x72219EC
	public object Continue(object next) { }

	// RVA: 0x7221BFC
	private object Dispose(object disposing) { }

	// RVA: 0x7221C44
	public object Dispose() { }

	// RVA: 0x7221070
	private object ResetNtlm() { }

	// RVA: 0x7221C8C
	internal object get_NtlmAuthenticated() { }

	// RVA: 0x7221C94
	internal object set_NtlmAuthenticated(object value) { }

	// RVA: 0x7221C9C
	internal object get_NtlmCredential() { }

	// RVA: 0x7221CA4
	internal object set_NtlmCredential(object value) { }

	// RVA: 0x7221CAC
	internal object get_UnsafeAuthenticatedConnectionSharing() { }

	// RVA: 0x7221CB4
	internal object set_UnsafeAuthenticatedConnectionSharing(object value) { }

}

// Namespace: System.Net
internal abstract class WebConnectionStream
{

	// Fields
	protected object closed; // 0x20
	private object disposed; // 0x21
	private object locker; // 0x28
	private object read_timeout; // 0x30
	private object write_timeout; // 0x34
	private readonly object <Request>k__BackingField; // 0x38
	private readonly object <Connection>k__BackingField; // 0x40
	private readonly object <Operation>k__BackingField; // 0x48

	// Properties
	internal object Request { get; }
	internal object Connection { get; }
	internal object Operation { get; }
	internal object ServicePoint { get; }
	public override object CanTimeout { get; }
	public override object ReadTimeout { get; set; }
	public override object WriteTimeout { get; set; }
	public override object CanSeek { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x7223F38
	protected object .ctor(object cnc, object operation) { }

	// RVA: 0x7224010
	internal object get_Request() { }

	// RVA: 0x7224018
	internal object get_Connection() { }

	// RVA: 0x7224020
	internal object get_Operation() { }

	// RVA: 0x7224028
	internal object get_ServicePoint() { }

	// RVA: 0x722404C
	public override object get_CanTimeout() { }

	// RVA: 0x7224054
	public override object get_ReadTimeout() { }

	// RVA: 0x722405C
	public override object set_ReadTimeout(object value) { }

	// RVA: 0x72240C0
	public override object get_WriteTimeout() { }

	// RVA: 0x72240C8
	public override object set_WriteTimeout(object value) { }

	// RVA: 0x722412C
	protected object GetException(object e) { }

	// RVA: -1
	protected abstract object TryReadFromBufferedContent(object buffer, object offset, object count, object result) { }

	// RVA: 0x7224314
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x7224708
	public override object BeginRead(object buffer, object offset, object count, object cb, object state) { }

	// RVA: 0x722499C
	public override object EndRead(object r) { }

	// RVA: 0x7224AE0
	public override object BeginWrite(object buffer, object offset, object count, object cb, object state) { }

	// RVA: 0x7224D50
	public override object EndWrite(object r) { }

	// RVA: 0x7224E60
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x7225110
	public override object Flush() { }

	// RVA: 0x7225114
	public override object FlushAsync(object cancellationToken) { }

	// RVA: 0x7225264
	internal object InternalClose() { }

	// RVA: -1
	protected abstract object Close_internal(object disposed) { }

	// RVA: 0x7225270
	public override object Close() { }

	// RVA: 0x72252B8
	public override object Seek(object a, object b) { }

	// RVA: 0x722530C
	public override object SetLength(object a) { }

	// RVA: 0x7225360
	public override object get_CanSeek() { }

	// RVA: 0x7225368
	public override object get_Length() { }

	// RVA: 0x72253BC
	public override object get_Position() { }

	// RVA: 0x7225410
	public override object set_Position(object value) { }

}

// Namespace: 
private enum NtlmAuthState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Challenge;
	public const object Response;
}

// Namespace: 
private struct <Initialize>d__42
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object stream; // 0x20
	public object cancellationToken; // 0x28
	private object <have_auth>5__2; // 0x30
	private object <>u__1; // 0x38
	private object <>u__2; // 0x48

	// Methods

	// RVA: 0x72256DC
	private object MoveNext() { }

	// RVA: 0x72265D8
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <ReadHeaders>d__43
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object cancellationToken; // 0x18
	public object stream; // 0x20
	public object <>4__this; // 0x28
	private object <retBuffer>5__2; // 0x30
	private object <status>5__3; // 0x38
	private object <buffer>5__4; // 0x40
	private object <ms>5__5; // 0x48
	private object <>u__1; // 0x50

	// Methods

	// RVA: 0x72266B0
	private object MoveNext() { }

	// RVA: 0x7227114
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class WebConnectionTunnel
{

	// Fields
	private readonly object <Request>k__BackingField; // 0x8
	private readonly object <ConnectUri>k__BackingField; // 0x10
	private object connectRequest; // 0x18
	private object ntlmAuthState; // 0x20
	private object <Success>k__BackingField; // 0x24
	private object <CloseConnection>k__BackingField; // 0x25
	private object <StatusCode>k__BackingField; // 0x28
	private object <StatusDescription>k__BackingField; // 0x30
	private object <Challenge>k__BackingField; // 0x38
	private object <Headers>k__BackingField; // 0x40
	private object <ProxyVersion>k__BackingField; // 0x48
	private object <Data>k__BackingField; // 0x50

	// Properties
	public object Request { get; }
	public object ConnectUri { get; }
	public object Success { get; set; }
	public object CloseConnection { get; set; }
	public object StatusCode { get; set; }
	private object StatusDescription { set; }
	public object Challenge { get; set; }
	public object Headers { get; set; }
	public object ProxyVersion { get; set; }
	public object Data { get; set; }

	// Methods

	// RVA: 0x7225464
	public object get_Request() { }

	// RVA: 0x722546C
	public object get_ConnectUri() { }

	// RVA: 0x72232D0
	public object .ctor(object request, object connectUri) { }

	// RVA: 0x7225474
	public object get_Success() { }

	// RVA: 0x722547C
	private object set_Success(object value) { }

	// RVA: 0x7225484
	public object get_CloseConnection() { }

	// RVA: 0x722548C
	private object set_CloseConnection(object value) { }

	// RVA: 0x7225494
	public object get_StatusCode() { }

	// RVA: 0x722549C
	private object set_StatusCode(object value) { }

	// RVA: 0x72254A4
	private object set_StatusDescription(object value) { }

	// RVA: 0x72254AC
	public object get_Challenge() { }

	// RVA: 0x72254B4
	private object set_Challenge(object value) { }

	// RVA: 0x72254BC
	public object get_Headers() { }

	// RVA: 0x72254C4
	private object set_Headers(object value) { }

	// RVA: 0x72254CC
	public object get_ProxyVersion() { }

	// RVA: 0x72254D4
	private object set_ProxyVersion(object value) { }

	// RVA: 0x72254DC
	public object get_Data() { }

	// RVA: 0x72254E4
	private object set_Data(object value) { }

	// RVA: 0x7223308
	internal object Initialize(object stream, object cancellationToken) { }

	// RVA: 0x72254EC
	private object ReadHeaders(object stream, object cancellationToken) { }

	// RVA: 0x7225604
	private object FlushContents(object stream, object contentLength) { }

}

// Namespace: 
private struct <Run>d__58
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x20
	private object <requestStream>5__2; // 0x28
	private object <stream>5__3; // 0x30
	private object <>u__1; // 0x38
	private object <>u__2; // 0x48

	// Methods

	// RVA: 0x7228070
	private object MoveNext() { }

	// RVA: 0x7228B98
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class WebOperation
{

	// Fields
	private readonly object <Request>k__BackingField; // 0x8
	private object <Connection>k__BackingField; // 0x10
	private object <ServicePoint>k__BackingField; // 0x18
	private readonly object <WriteBuffer>k__BackingField; // 0x20
	private readonly object <IsNtlmChallenge>k__BackingField; // 0x28
	private object cts; // 0x30
	private object requestTask; // 0x38
	private object requestWrittenTask; // 0x40
	private object responseTask; // 0x48
	private object finishedTask; // 0x50
	private object writeStream; // 0x58
	private object responseStream; // 0x60
	private object disposedInfo; // 0x68
	private object closedInfo; // 0x70
	private object priorityRequest; // 0x78
	private object requestSent; // 0x80
	private object finished; // 0x84

	// Properties
	public object Request { get; }
	public object Connection { get; set; }
	public object ServicePoint { get; set; }
	public object WriteBuffer { get; }
	public object IsNtlmChallenge { get; }
	public object Aborted { get; }
	public object Closed { get; }
	public object WriteStream { get; }
	internal object Finished { get; }

	// Methods

	// RVA: 0x7227214
	public object get_Request() { }

	// RVA: 0x722721C
	public object get_Connection() { }

	// RVA: 0x7227224
	private object set_Connection(object value) { }

	// RVA: 0x722722C
	public object get_ServicePoint() { }

	// RVA: 0x7227234
	private object set_ServicePoint(object value) { }

	// RVA: 0x722723C
	public object get_WriteBuffer() { }

	// RVA: 0x7227244
	public object get_IsNtlmChallenge() { }

	// RVA: 0x722724C
	public object .ctor(object request, object writeBuffer, object isNtlmChallenge, object cancellationToken) { }

	// RVA: 0x72233EC
	public object get_Aborted() { }

	// RVA: 0x72273E0
	public object get_Closed() { }

	// RVA: 0x7227474
	public object Abort() { }

	// RVA: 0x72276A8
	public object Close() { }

	// RVA: 0x72275B4
	private object SetCanceled() { }

	// RVA: 0x7227A5C
	private object SetError(object error) { }

	// RVA: 0x72274C4
	private object SetDisposed(object field) { }

	// RVA: 0x7227B2C
	internal object CheckDisposed(object cancellationToken) { }

	// RVA: 0x7227C78
	internal object ThrowIfDisposed() { }

	// RVA: 0x7222938
	internal object ThrowIfDisposed(object cancellationToken) { }

	// RVA: 0x722469C
	internal object ThrowIfClosedOrDisposed() { }

	// RVA: 0x7223B6C
	internal object ThrowIfClosedOrDisposed(object cancellationToken) { }

	// RVA: 0x7227C0C
	private object CheckThrowDisposed(object throwIt, object field) { }

	// RVA: 0x72216D0
	internal object RegisterRequest(object servicePoint, object connection) { }

	// RVA: 0x7227CE4
	public object SetPriorityRequest(object operation) { }

	// RVA: 0x7227E80
	internal object GetRequestStreamInternal() { }

	// RVA: 0x7227EDC
	public object get_WriteStream() { }

	// RVA: 0x7227F50
	public object GetResponseStream() { }

	// RVA: 0x7227FAC
	internal object get_Finished() { }

	// RVA: 0x7221950
	internal object Run() { }

	// RVA: 0x7227FB4
	internal object CompleteRequestWritten(object stream, object error) { }

	// RVA: 0x7227784
	internal object Finish(object ok, object error) { }

	// RVA: 0x7228044
	private object <RegisterRequest>b__48_0() { }

}

// Namespace: 
private struct <ReadAsync>d__28
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	public object buffer; // 0x28
	public object offset; // 0x30
	public object size; // 0x34
	private object <>u__1; // 0x38
	private object <>u__2; // 0x48

	// Methods

	// RVA: 0x7229A04
	private object MoveNext() { }

	// RVA: 0x722A034
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal abstract class WebReadStream
{

	// Fields
	private readonly object <Operation>k__BackingField; // 0x20
	private readonly object <InnerStream>k__BackingField; // 0x28
	private object disposed; // 0x30

	// Properties
	public object Operation { get; }
	protected object InnerStream { get; }
	public override object Length { get; }
	public override object Position { get; set; }
	public override object CanSeek { get; }
	public override object CanRead { get; }
	public override object CanWrite { get; }

	// Methods

	// RVA: 0x7228BB0
	public object get_Operation() { }

	// RVA: 0x7228BB8
	protected object get_InnerStream() { }

	// RVA: 0x7228BC0
	public object .ctor(object operation, object innerStream) { }

	// RVA: 0x7228C3C
	public override object get_Length() { }

	// RVA: 0x7228C7C
	public override object get_Position() { }

	// RVA: 0x7228CBC
	public override object set_Position(object value) { }

	// RVA: 0x7228CFC
	public override object get_CanSeek() { }

	// RVA: 0x7228D04
	public override object get_CanRead() { }

	// RVA: 0x7228D0C
	public override object get_CanWrite() { }

	// RVA: 0x7228D14
	public override object SetLength(object value) { }

	// RVA: 0x7228D54
	public override object Seek(object offset, object origin) { }

	// RVA: 0x7228D94
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x7228DD4
	public override object Flush() { }

	// RVA: 0x7228E14
	protected object GetException(object e) { }

	// RVA: 0x7228FFC
	public override object Read(object buffer, object offset, object size) { }

	// RVA: 0x722934C
	public override object BeginRead(object buffer, object offset, object size, object cb, object state) { }

	// RVA: 0x72295E0
	public override object EndRead(object r) { }

	// RVA: 0x7229724
	public sealed override object ReadAsync(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: -1
	protected abstract object ProcessReadAsync(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x722984C
	internal virtual object FinishReading(object cancellationToken) { }

	// RVA: 0x72299B0
	protected override object Dispose(object disposing) { }

}

// Namespace: 
private struct <FinishWriting>d__31
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <>u__1; // 0x28

	// Methods

	// RVA: 0x722B12C
	private object MoveNext() { }

	// RVA: 0x722B548
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <WriteAsyncInner>d__33
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object buffer; // 0x20
	public object offset; // 0x28
	public object size; // 0x2C
	public object cancellationToken; // 0x30
	public object completion; // 0x38
	private object <>u__1; // 0x40
	private object <>u__2; // 0x50

	// Methods

	// RVA: 0x722B620
	private object MoveNext() { }

	// RVA: 0x722BC40
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <ProcessWrite>d__34
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	public object size; // 0x28
	public object buffer; // 0x30
	public object offset; // 0x38
	private object <>u__1; // 0x40

	// Methods

	// RVA: 0x722BD18
	private object MoveNext() { }

	// RVA: 0x722C448
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <Initialize>d__36
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <>u__1; // 0x28
	private object <>u__2; // 0x38

	// Methods

	// RVA: 0x722C520
	private object MoveNext() { }

	// RVA: 0x722C948
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <SetHeadersAsync>d__37
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	public object setInternalLength; // 0x28
	private object <>u__1; // 0x30

	// Methods

	// RVA: 0x722CA20
	private object MoveNext() { }

	// RVA: 0x722D298
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <WriteRequestAsync>d__38
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <buffer>5__2; // 0x28
	private object <>u__1; // 0x30
	private object <>u__2; // 0x40

	// Methods

	// RVA: 0x722D370
	private object MoveNext() { }

	// RVA: 0x722D97C
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <WriteChunkTrailer_inner>d__39
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <>u__1; // 0x28

	// Methods

	// RVA: 0x722DA54
	private object MoveNext() { }

	// RVA: 0x722DDA4
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <WriteChunkTrailer>d__40
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	private object <cts>5__2; // 0x20
	private object <timeoutTask>5__3; // 0x28
	private object <>u__1; // 0x30
	private object <>u__2; // 0x40

	// Methods

	// RVA: 0x722DE7C
	private object MoveNext() { }

	// RVA: 0x722E7F8
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class WebRequestStream
{

	// Fields
	private static object crlf; // 0x0
	private object writeBuffer; // 0x50
	private object requestWritten; // 0x58
	private object allowBuffering; // 0x59
	private object sendChunked; // 0x5A
	private object pendingWrite; // 0x60
	private object totalWritten; // 0x68
	private object headers; // 0x70
	private object headersSent; // 0x78
	private object completeRequestWritten; // 0x7C
	private object chunkTrailerWritten; // 0x80
	private readonly object <InnerStream>k__BackingField; // 0x88
	private readonly object <KeepAlive>k__BackingField; // 0x90

	// Properties
	internal object InnerStream { get; }
	public object KeepAlive { get; }
	public override object CanRead { get; }
	public override object CanWrite { get; }
	internal object HasWriteBuffer { get; }
	internal object WriteBufferLength { get; }

	// Methods

	// RVA: 0x7223C60
	public object .ctor(object connection, object operation, object stream, object tunnel) { }

	// RVA: 0x722A134
	internal object get_InnerStream() { }

	// RVA: 0x722A13C
	public object get_KeepAlive() { }

	// RVA: 0x722A144
	public override object get_CanRead() { }

	// RVA: 0x722A14C
	public override object get_CanWrite() { }

	// RVA: 0x722A154
	internal object get_HasWriteBuffer() { }

	// RVA: 0x722A190
	internal object get_WriteBufferLength() { }

	// RVA: 0x722A210
	internal object GetWriteBuffer() { }

	// RVA: 0x722A370
	private object FinishWriting(object cancellationToken) { }

	// RVA: 0x722A440
	public override object WriteAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x722A738
	private object WriteAsyncInner(object buffer, object offset, object size, object completion, object cancellationToken) { }

	// RVA: 0x722A834
	private object ProcessWrite(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x722A934
	private object CheckWriteOverflow(object contentLength, object totalWritten, object size) { }

	// RVA: 0x7228960
	internal object Initialize(object cancellationToken) { }

	// RVA: 0x722A9E4
	private object SetHeadersAsync(object setInternalLength, object cancellationToken) { }

	// RVA: 0x722AAC8
	internal object WriteRequestAsync(object cancellationToken) { }

	// RVA: 0x722AB9C
	private object WriteChunkTrailer_inner(object cancellationToken) { }

	// RVA: 0x722AC6C
	private object WriteChunkTrailer() { }

	// RVA: 0x722A9DC
	internal object KillBuffer() { }

	// RVA: 0x722AD40
	public override object ReadAsync(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x722AE0C
	protected override object TryReadFromBufferedContent(object buffer, object offset, object count, object result) { }

	// RVA: 0x722AE4C
	protected override object Close_internal(object disposed) { }

	// RVA: 0x722B08C
	private static object .cctor() { }

}

// Namespace: 
private struct <ReadAsync>d__40
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object cancellationToken; // 0x18
	public object buffer; // 0x20
	public object offset; // 0x28
	public object count; // 0x2C
	public object <>4__this; // 0x30
	private object <completion>5__2; // 0x38
	private object <nbytes>5__3; // 0x40
	private object <throwMe>5__4; // 0x48
	private object <>u__1; // 0x50
	private object <>u__2; // 0x60

	// Methods

	// RVA: 0x72304F4
	private object MoveNext() { }

	// RVA: 0x7230F7C
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private sealed class <>c__DisplayClass41_0
{

	// Fields
	public object <>4__this; // 0x8
	public object buffer; // 0x10
	public object offset; // 0x18
	public object size; // 0x1C

	// Methods

	// RVA: 0x722ED5C
	public object .ctor() { }

	// RVA: 0x723107C
	internal object <ProcessRead>b__0(object ct) { }

	// RVA: 0x723110C
	internal object <ProcessRead>b__1() { }

	// RVA: 0x72311A8
	internal object <ProcessRead>b__2() { }

}

// Namespace: 
private struct <ReadAllAsyncInner>d__47
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object cancellationToken; // 0x18
	public object <>4__this; // 0x20
	private object <maximumSize>5__2; // 0x28
	private object <ms>5__3; // 0x30
	private object <buffer>5__4; // 0x38
	private object <>u__1; // 0x40

	// Methods

	// RVA: 0x723124C
	private object MoveNext() { }

	// RVA: 0x72319C8
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <ReadAllAsync>d__48
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	public object resending; // 0x28
	private object <completion>5__2; // 0x30
	private object <timeoutCts>5__3; // 0x38
	private object <timeoutTask>5__4; // 0x40
	private object <>u__1; // 0x48
	private object <>u__2; // 0x58

	// Methods

	// RVA: 0x7231AC8
	private object MoveNext() { }

	// RVA: 0x72328B4
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: 
private struct <InitReadAsync>d__52
{

	// Fields
	public object <>1__state; // 0xFFFFFFFFFFFFFFF8
	public object <>t__builder; // 0x0
	public object <>4__this; // 0x18
	public object cancellationToken; // 0x20
	private object <buffer>5__2; // 0x28
	private object <state>5__3; // 0x30
	private object <position>5__4; // 0x34
	private object <>u__1; // 0x38

	// Methods

	// RVA: 0x723298C
	private object MoveNext() { }

	// RVA: 0x72331F8
	private object SetStateMachine(object stateMachine) { }

}

// Namespace: System.Net
internal class WebResponseStream
{

	// Fields
	private object innerStream; // 0x50
	private object nextReadCalled; // 0x58
	private object bufferedEntireContent; // 0x59
	private object pendingRead; // 0x60
	private object locker; // 0x68
	private object nestedRead; // 0x70
	private object read_eof; // 0x74
	private readonly object <RequestStream>k__BackingField; // 0x78
	private object <Headers>k__BackingField; // 0x80
	private object <StatusCode>k__BackingField; // 0x88
	private object <StatusDescription>k__BackingField; // 0x90
	private object <Version>k__BackingField; // 0x98
	private object <KeepAlive>k__BackingField; // 0xA0
	private object <ChunkedRead>k__BackingField; // 0xA1

	// Properties
	public object RequestStream { get; }
	public object Headers { get; set; }
	public object StatusCode { get; set; }
	public object StatusDescription { get; set; }
	public object Version { get; set; }
	public object KeepAlive { get; set; }
	public override object CanRead { get; }
	public override object CanWrite { get; }
	private object ChunkedRead { get; set; }
	private object ExpectContent { get; }

	// Methods

	// RVA: 0x722E8D0
	public object get_RequestStream() { }

	// RVA: 0x722E8D8
	public object get_Headers() { }

	// RVA: 0x722E8E0
	private object set_Headers(object value) { }

	// RVA: 0x722E8E8
	public object get_StatusCode() { }

	// RVA: 0x722E8F0
	private object set_StatusCode(object value) { }

	// RVA: 0x722E8F8
	public object get_StatusDescription() { }

	// RVA: 0x722E900
	private object set_StatusDescription(object value) { }

	// RVA: 0x722E908
	public object get_Version() { }

	// RVA: 0x722E910
	private object set_Version(object value) { }

	// RVA: 0x722E918
	public object get_KeepAlive() { }

	// RVA: 0x722E920
	private object set_KeepAlive(object value) { }

	// RVA: 0x7228A34
	public object .ctor(object request) { }

	// RVA: 0x722E928
	public override object get_CanRead() { }

	// RVA: 0x722E930
	public override object get_CanWrite() { }

	// RVA: 0x722E938
	private object get_ChunkedRead() { }

	// RVA: 0x722E940
	private object set_ChunkedRead(object value) { }

	// RVA: 0x722E948
	public override object ReadAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x722EA78
	private object ProcessRead(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x722ED64
	protected override object TryReadFromBufferedContent(object buffer, object offset, object count, object result) { }

	// RVA: 0x722EE38
	private object get_ExpectContent() { }

	// RVA: 0x722EEFC
	private object Initialize(object buffer) { }

	// RVA: 0x722F678
	private object ReadAllAsyncInner(object cancellationToken) { }

	// RVA: 0x722F780
	internal object ReadAllAsync(object resending, object cancellationToken) { }

	// RVA: 0x722F868
	public override object WriteAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x722F920
	protected override object Close_internal(object disposed) { }

	// RVA: 0x722F9E0
	private object GetReadException(object status, object error, object where) { }

	// RVA: 0x7228ABC
	internal object InitReadAsync(object cancellationToken) { }

	// RVA: 0x722FCB4
	private object GetResponse(object buffer, object pos, object state) { }

}

// Namespace: System.Net.NetworkInformation
public abstract class IPGlobalProperties
{

	// Properties
	public abstract object DomainName { get; }

	// Methods

	// RVA: 0x72332D0
	public static object GetIPGlobalProperties() { }

	// RVA: 0x7233378
	internal static object InternalGetIPGlobalProperties() { }

	// RVA: -1
	public abstract object get_DomainName() { }

	// RVA: 0x72333CC
	protected object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
public class NetworkInformationException
{

	// Methods

	// RVA: 0x72333D4
	public object .ctor() { }

	// RVA: 0x7233444
	protected object .ctor(object serializationInfo, object streamingContext) { }

}

// Namespace: System.Net.NetworkInformation
public abstract class NetworkInterface
{

	// Methods

	// RVA: 0x723344C
	public static object GetAllNetworkInterfaces() { }

	// RVA: 0x72335DC
	public virtual object GetPhysicalAddress() { }

	// RVA: 0x723361C
	protected object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
public enum NetworkInterfaceComponent
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IPv4;
	public const object IPv6;
}

// Namespace: System.Net.NetworkInformation
public class PhysicalAddress
{

	// Fields
	private object address; // 0x8
	private object changed; // 0x10
	private object hash; // 0x14
	public static readonly object None; // 0x0

	// Methods

	// RVA: 0x7233624
	public object .ctor(object address) { }

	// RVA: 0x7233658
	public override object GetHashCode() { }

	// RVA: 0x7233B64
	public override object Equals(object comparand) { }

	// RVA: 0x7233C7C
	public override object ToString() { }

	// RVA: 0x7233DBC
	public object GetAddressBytes() { }

	// RVA: 0x7233E54
	private static object .cctor() { }

}

// Namespace: System.Net.NetworkInformation
public enum NetworkInterfaceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Ethernet;
	public const object TokenRing;
	public const object Fddi;
	public const object BasicIsdn;
	public const object PrimaryIsdn;
	public const object Ppp;
	public const object Loopback;
	public const object Ethernet3Megabit;
	public const object Slip;
	public const object Atm;
	public const object GenericModem;
	public const object FastEthernetT;
	public const object Isdn;
	public const object FastEthernetFx;
	public const object Wireless80211;
	public const object AsymmetricDsl;
	public const object RateAdaptDsl;
	public const object SymmetricDsl;
	public const object VeryHighSpeedDsl;
	public const object IPOverAtm;
	public const object GigabitEthernet;
	public const object Tunnel;
	public const object MultiRateSymmetricDsl;
	public const object HighPerformanceSerialBus;
	public const object Wman;
	public const object Wwanpp;
	public const object Wwanpp2;
}

// Namespace: System.Net.NetworkInformation
internal class AixNetworkInterfaceAPI
{

	// Methods

	// RVA: 0x7233EEC
	public static extern object socket(object family, object type, object protocol) { }

	// RVA: 0x7233F90
	public static extern object close(object fd) { }

	// RVA: 0x7234020
	public static extern object ioctl(object fd, object request, object arg) { }

	// RVA: 0x72340C4
	public static extern object ioctl(object fd, object request, object arg) { }

	// RVA: 0x7234168
	public static extern object ioctl(object fd, object request, object arg) { }

	// RVA: 0x723420C
	public static extern object ioctl(object fd, object request, object arg) { }

	// RVA: 0x72342B0
	private static object ByteArrayCopy(object dst, object src, object elements) { }

	// RVA: 0x7234334
	public override object GetAllNetworkInterfaces() { }

	// RVA: 0x7235998
	public object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
internal sealed class AixNetworkInterface
{

	// Fields
	private object _ifa_flags; // 0x24
	private object _ifru_mtu; // 0x28

	// Methods

	// RVA: 0x723569C
	internal object .ctor(object name, object ifa_flags, object ifru_mtu) { }

}

// Namespace: System.Net.NetworkInformation
internal enum AixArpHardware
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ETHER;
	public const object ATM;
	public const object SLIP;
	public const object PPP;
	public const object LOOPBACK;
	public const object FDDI;
}

// Namespace: System.Net.NetworkInformation
internal enum AixAddressFamily
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AF_INET;
	public const object AF_INET6;
	public const object AF_LINK;
}

// Namespace: System.Net.NetworkInformation
internal enum AixIoctlRequest
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SIOCGSIZIFCONF;
	public const object SIOCGIFCONF;
	public const object SIOCGIFFLAGS;
	public const object SIOCGIFNETMASK;
	public const object SIOCGIFMTU;
}

// Namespace: System.Net.NetworkInformation
internal class FreeBSDNetworkInterfaceAPI
{

	// Methods

	// RVA: 0x7235A3C
	public object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
internal static class IPGlobalPropertiesFactoryPal
{

	// Methods

	// RVA: 0x7233324
	public static object Create() { }

}

// Namespace: System.Net.NetworkInformation
internal class LinuxNetworkInterfaceAPI
{

	// Methods

	// RVA: 0x7235BE8
	private static object FreeInterfaceAddresses(object ifap) { }

	// RVA: 0x7235D10
	private static object GetInterfaceAddresses(object ifap) { }

	// RVA: 0x7235E38
	public override object GetAllNetworkInterfaces() { }

	// RVA: 0x7236D44
	public object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
internal sealed class LinuxNetworkInterface
{

	// Fields
	private object iface_path; // 0x28
	private object iface_operstate_path; // 0x30
	private object iface_flags_path; // 0x38

	// Properties
	internal object IfacePath { get; }

	// Methods

	// RVA: 0x7236D4C
	internal object get_IfacePath() { }

	// RVA: 0x7236B20
	internal object .ctor(object name) { }

}

// Namespace: System.Net.NetworkInformation
internal struct ifa_ifu
{

	// Fields
	public object ifu_broadaddr; // 0xFFFFFFFFFFFFFFF8
	public object ifu_dstaddr; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Net.NetworkInformation
internal struct ifaddrs
{

	// Fields
	public object ifa_next; // 0xFFFFFFFFFFFFFFF8
	public object ifa_name; // 0x0
	public object ifa_flags; // 0x8
	public object ifa_addr; // 0x10
	public object ifa_netmask; // 0x18
	public object ifa_ifu; // 0x20
	public object ifa_data; // 0x28
}

// Namespace: System.Net.NetworkInformation
internal struct sockaddr_in
{

	// Fields
	public object sin_family; // 0xFFFFFFFFFFFFFFF8
	public object sin_port; // 0xFFFFFFFFFFFFFFFA
	public object sin_addr; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: System.Net.NetworkInformation
internal struct sockaddr_in6
{

	// Fields
	public object sin6_family; // 0xFFFFFFFFFFFFFFF8
	public object sin6_port; // 0xFFFFFFFFFFFFFFFA
	public object sin6_flowinfo; // 0xFFFFFFFFFFFFFFFC
	public object sin6_addr; // 0x0
	public object sin6_scope_id; // 0x8
}

// Namespace: System.Net.NetworkInformation
internal struct in6_addr
{

	// Fields
	public object u6_addr8; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Net.NetworkInformation
internal struct sockaddr_ll
{

	// Fields
	public object sll_family; // 0xFFFFFFFFFFFFFFF8
	public object sll_protocol; // 0xFFFFFFFFFFFFFFFA
	public object sll_ifindex; // 0xFFFFFFFFFFFFFFFC
	public object sll_hatype; // 0x0
	public object sll_pkttype; // 0x2
	public object sll_halen; // 0x3
	public object sll_addr; // 0x8
}

// Namespace: System.Net.NetworkInformation
internal enum LinuxArpHardware
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ETHER;
	public const object EETHER;
	public const object PRONET;
	public const object ATM;
	public const object SLIP;
	public const object CSLIP;
	public const object SLIP6;
	public const object CSLIP6;
	public const object PPP;
	public const object LOOPBACK;
	public const object FDDI;
	public const object TUNNEL;
	public const object TUNNEL6;
	public const object SIT;
	public const object IPDDP;
	public const object IPGRE;
	public const object IP6GRE;
}

// Namespace: System.Net.NetworkInformation
internal class MacOsNetworkInterfaceAPI
{

	// Fields
	protected readonly object AF_INET6; // 0x8

	// Methods

	// RVA: 0x7237274
	public object .ctor() { }

	// RVA: 0x7235A68
	protected object .ctor(object AF_INET6) { }

	// RVA: 0x72372A0
	public override object GetAllNetworkInterfaces() { }

}

// Namespace: System.Net.NetworkInformation
internal sealed class MacOsNetworkInterface
{

	// Fields
	private object _ifa_flags; // 0x24

	// Methods

	// RVA: 0x7238038
	internal object .ctor(object name, object ifa_flags) { }

}

// Namespace: System.Net.NetworkInformation
internal enum MacOsArpHardware
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ETHER;
	public const object ATM;
	public const object SLIP;
	public const object PPP;
	public const object LOOPBACK;
	public const object FDDI;
}

// Namespace: System.Net.NetworkInformation
internal static class SystemNetworkInterface
{

	// Fields
	private static readonly object nif; // 0x0

	// Methods

	// RVA: 0x72334B4
	public static object GetNetworkInterfaces() { }

	// RVA: 0x7238114
	private static object .cctor() { }

}

// Namespace: System.Net.NetworkInformation
internal abstract class NetworkInterfaceFactory
{

	// Methods

	// RVA: -1
	public abstract object GetAllNetworkInterfaces() { }

	// RVA: 0x723819C
	public static object Create() { }

	// RVA: 0x7238244
	protected object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
internal static class NetworkInterfaceFactoryPal
{

	// Methods

	// RVA: 0x72381F0
	public static object Create() { }

}

// Namespace: System.Net.NetworkInformation
internal abstract class CommonUnixIPGlobalProperties
{

	// Properties
	public override object DomainName { get; }

	// Methods

	// RVA: 0x7238304
	private static extern object getdomainname(object name, object len) { }

	// RVA: 0x723839C
	public override object get_DomainName() { }

	// RVA: 0x72385C0
	protected object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
internal class UnixIPGlobalProperties
{

	// Methods

	// RVA: 0x72385C8
	public object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
internal sealed class UnixNoLibCIPGlobalProperties
{

	// Properties
	public override object DomainName { get; }

	// Methods

	// RVA: 0x72385D0
	public override object get_DomainName() { }

	// RVA: 0x723861C
	public object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
internal class MibIPGlobalProperties
{

	// Fields
	public readonly object StatisticsFile; // 0x8
	public readonly object StatisticsFileIPv6; // 0x10
	public readonly object TcpFile; // 0x18
	public readonly object Tcp6File; // 0x20
	public readonly object UdpFile; // 0x28
	public readonly object Udp6File; // 0x30
	private static readonly object wsChars; // 0x0

	// Methods

	// RVA: 0x7238624
	public object .ctor(object procDir) { }

	// RVA: 0x7238798
	private static object .cctor() { }

}

// Namespace: System.Net.NetworkInformation
internal static class UnixIPGlobalPropertiesFactoryPal
{

	// Fields
	private static readonly object <PlatformNeedsLibCWorkaround>k__BackingField; // 0x0

	// Properties
	private static object PlatformNeedsLibCWorkaround { get; }

	// Methods

	// RVA: 0x7238838
	private static object get_PlatformNeedsLibCWorkaround() { }

	// RVA: 0x7235A94
	public static object Create() { }

}

// Namespace: System.Net.NetworkInformation
internal abstract class UnixNetworkInterfaceAPI
{

	// Methods

	// RVA: 0x7235DA4
	protected static extern object getifaddrs(object ifap) { }

	// RVA: 0x7235C7C
	protected static extern object freeifaddrs(object ifap) { }

	// RVA: 0x72359A0
	protected object .ctor() { }

}

// Namespace: System.Net.NetworkInformation
internal abstract class UnixNetworkInterface
{

	// Fields
	private object name; // 0x8
	protected object addresses; // 0x10
	private object macAddress; // 0x18
	private object type; // 0x20

	// Methods

	// RVA: 0x72359A8
	internal object .ctor(object name) { }

	// RVA: 0x7235744
	internal object AddAddress(object address) { }

	// RVA: 0x7235864
	internal object SetLinkLayerInfo(object index, object macAddress, object type) { }

	// RVA: 0x7238884
	public override object GetPhysicalAddress() { }

}

// Namespace: System.Net.NetworkInformation
internal static class UnixNetworkInterfaceFactoryPal
{

	// Methods

	// RVA: 0x723824C
	public static object Create() { }

}

// Namespace: System.Net.NetworkInformation.MacOsStructs
internal struct ifaddrs
{

	// Fields
	public object ifa_next; // 0xFFFFFFFFFFFFFFF8
	public object ifa_name; // 0x0
	public object ifa_flags; // 0x8
	public object ifa_addr; // 0x10
	public object ifa_netmask; // 0x18
	public object ifa_dstaddr; // 0x20
	public object ifa_data; // 0x28
}

// Namespace: System.Net.NetworkInformation.MacOsStructs
internal struct sockaddr
{

	// Fields
	public object sa_len; // 0xFFFFFFFFFFFFFFF8
	public object sa_family; // 0xFFFFFFFFFFFFFFF9
}

// Namespace: System.Net.NetworkInformation.MacOsStructs
internal struct sockaddr_in
{

	// Fields
	public object sin_len; // 0xFFFFFFFFFFFFFFF8
	public object sin_family; // 0xFFFFFFFFFFFFFFF9
	public object sin_port; // 0xFFFFFFFFFFFFFFFA
	public object sin_addr; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: System.Net.NetworkInformation.MacOsStructs
internal struct in6_addr
{

	// Fields
	public object u6_addr8; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Net.NetworkInformation.MacOsStructs
internal struct sockaddr_in6
{

	// Fields
	public object sin6_len; // 0xFFFFFFFFFFFFFFF8
	public object sin6_family; // 0xFFFFFFFFFFFFFFF9
	public object sin6_port; // 0xFFFFFFFFFFFFFFFA
	public object sin6_flowinfo; // 0xFFFFFFFFFFFFFFFC
	public object sin6_addr; // 0x0
	public object sin6_scope_id; // 0x8
}

// Namespace: System.Net.NetworkInformation.MacOsStructs
internal struct sockaddr_dl
{

	// Fields
	public object sdl_len; // 0xFFFFFFFFFFFFFFF8
	public object sdl_family; // 0xFFFFFFFFFFFFFFF9
	public object sdl_index; // 0xFFFFFFFFFFFFFFFA
	public object sdl_type; // 0xFFFFFFFFFFFFFFFC
	public object sdl_nlen; // 0xFFFFFFFFFFFFFFFD
	public object sdl_alen; // 0xFFFFFFFFFFFFFFFE
	public object sdl_slen; // 0xFFFFFFFFFFFFFFFF
	public object sdl_data; // 0x0

	// Methods

	// RVA: 0x7237E98
	internal object Read(object ptr) { }

}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct ifconf
{

	// Fields
	public object ifc_len; // 0xFFFFFFFFFFFFFFF8
	public object ifc_buf; // 0x0
}

// Namespace: 
public struct <ifr_name>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct ifreq
{

	// Fields
	public object ifr_name; // 0xFFFFFFFFFFFFFFF8
	public object ifru_addr; // 0x8
}

// Namespace: 
public struct <ifr_name>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct ifreq_flags
{

	// Fields
	public object ifr_name; // 0xFFFFFFFFFFFFFFF8
	public object ifru_flags; // 0x8
}

// Namespace: 
public struct <ifr_name>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct ifreq_mtu
{

	// Fields
	public object ifr_name; // 0xFFFFFFFFFFFFFFF8
	public object ifru_mtu; // 0x8
}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct sockaddr
{

	// Fields
	public object sa_len; // 0xFFFFFFFFFFFFFFF8
	public object sa_family; // 0xFFFFFFFFFFFFFFF9
}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct sockaddr_in
{

	// Fields
	public object sin_len; // 0xFFFFFFFFFFFFFFF8
	public object sin_family; // 0xFFFFFFFFFFFFFFF9
	public object sin_port; // 0xFFFFFFFFFFFFFFFA
	public object sin_addr; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct in6_addr
{

	// Fields
	public object u6_addr8; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct sockaddr_in6
{

	// Fields
	public object sin6_len; // 0xFFFFFFFFFFFFFFF8
	public object sin6_family; // 0xFFFFFFFFFFFFFFF9
	public object sin6_port; // 0xFFFFFFFFFFFFFFFA
	public object sin6_flowinfo; // 0xFFFFFFFFFFFFFFFC
	public object sin6_addr; // 0x0
	public object sin6_scope_id; // 0x8
}

// Namespace: System.Net.NetworkInformation.AixStructs
internal struct sockaddr_dl
{

	// Fields
	public object sdl_len; // 0xFFFFFFFFFFFFFFF8
	public object sdl_family; // 0xFFFFFFFFFFFFFFF9
	public object sdl_index; // 0xFFFFFFFFFFFFFFFA
	public object sdl_type; // 0xFFFFFFFFFFFFFFFC
	public object sdl_nlen; // 0xFFFFFFFFFFFFFFFD
	public object sdl_alen; // 0xFFFFFFFFFFFFFFFE
	public object sdl_slen; // 0xFFFFFFFFFFFFFFFF
	public object sdl_data; // 0x0

	// Methods

	// RVA: 0x72354FC
	internal object Read(object ptr) { }

}

// Namespace: System.Net.Configuration
internal sealed class DefaultProxySectionInternal
{

	// Fields
	private object webProxy; // 0x8
	private static object classSyncObject; // 0x0

	// Properties
	internal static object ClassSyncObject { get; }
	internal object WebProxy { get; }

	// Methods

	// RVA: 0x7239164
	private static object GetDefaultProxy_UsingOldMonoCode() { }

	// RVA: 0x723916C
	private static object GetSystemWebProxy() { }

	// RVA: 0x7239174
	internal static object get_ClassSyncObject() { }

	// RVA: 0x723922C
	internal static object GetSection() { }

	// RVA: 0x7239404
	internal object get_WebProxy() { }

	// RVA: 0x72393FC
	public object .ctor() { }

}

// Namespace: System.Net.Configuration
internal sealed class SettingsSectionInternal
{

	// Fields
	private static readonly object instance; // 0x0
	internal readonly object HttpListenerUnescapeRequestUrl; // 0x8
	internal readonly object IPProtectionLevel; // 0xC

	// Properties
	internal static object Section { get; }
	internal object Ipv6Enabled { get; }

	// Methods

	// RVA: 0x723940C
	internal static object get_Section() { }

	// RVA: 0x7239488
	internal object get_Ipv6Enabled() { }

	// RVA: 0x7239490
	public object .ctor() { }

	// RVA: 0x72394A8
	private static object .cctor() { }

}

// Namespace: System.Net.Cache
internal abstract class RequestCache
{

	// Fields
	internal static readonly object LineSplits; // 0x0

	// Methods

	// RVA: 0x7239518
	private static object .cctor() { }

}

// Namespace: System.Net.Cache
internal class RequestCacheValidator
{

	// Methods

	// RVA: 0x72395B8
	public object CreateValidator() { }

}

// Namespace: System.Net.Cache
internal class RequestCacheBinding
{

	// Fields
	private object m_RequestCache; // 0x8
	private object m_CacheValidator; // 0x10

	// Properties
	internal object Cache { get; }
	internal object Validator { get; }

	// Methods

	// RVA: 0x72395F8
	internal object get_Cache() { }

	// RVA: 0x7239600
	internal object get_Validator() { }

}

// Namespace: System.Net.Cache
public enum RequestCacheLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object BypassCache;
	public const object CacheOnly;
	public const object CacheIfAvailable;
	public const object Revalidate;
	public const object Reload;
	public const object NoCacheNoStore;
}

// Namespace: System.Net.Cache
public class RequestCachePolicy
{

	// Fields
	private object m_Level; // 0x8

	// Properties
	public object Level { get; }

	// Methods

	// RVA: 0x7239608
	public object .ctor(object level) { }

	// RVA: 0x7239684
	public object get_Level() { }

	// RVA: 0x723968C
	public override object ToString() { }

}

// Namespace: System.Net.Cache
internal class RequestCacheProtocol
{

	// Methods

	// RVA: 0x723972C
	public object .ctor(object arg1, object arg2) { }

}

// Namespace: System.Net.Sockets
public class NetworkStream
{

	// Fields
	private readonly object _streamSocket; // 0x20
	private readonly object _ownsSocket; // 0x28
	private object _readable; // 0x29
	private object _writeable; // 0x2A
	private object _closeTimeout; // 0x2C
	private object _cleanedUp; // 0x30
	private object _currentReadTimeout; // 0x34
	private object _currentWriteTimeout; // 0x38

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object CanTimeout { get; }
	public override object ReadTimeout { get; set; }
	public override object WriteTimeout { get; set; }
	public virtual object DataAvailable { get; }
	public override object Length { get; }
	public override object Position { get; set; }
	internal object InternalSocket { get; }

	// Methods

	// RVA: 0x7239774
	public object .ctor(object socket) { }

	// RVA: 0x72232C4
	public object .ctor(object socket, object ownsSocket) { }

	// RVA: 0x7239780
	public object .ctor(object socket, object access, object ownsSocket) { }

	// RVA: 0x7239954
	public override object get_CanRead() { }

	// RVA: 0x723995C
	public override object get_CanSeek() { }

	// RVA: 0x7239964
	public override object get_CanWrite() { }

	// RVA: 0x723996C
	public override object get_CanTimeout() { }

	// RVA: 0x7239974
	public override object get_ReadTimeout() { }

	// RVA: 0x7239A18
	public override object set_ReadTimeout(object value) { }

	// RVA: 0x7239CAC
	public override object get_WriteTimeout() { }

	// RVA: 0x7239D50
	public override object set_WriteTimeout(object value) { }

	// RVA: 0x7239DD8
	public virtual object get_DataAvailable() { }

	// RVA: 0x7239E8C
	public override object get_Length() { }

	// RVA: 0x7239EE0
	public override object get_Position() { }

	// RVA: 0x7239F34
	public override object set_Position(object value) { }

	// RVA: 0x7239F88
	public override object Seek(object offset, object origin) { }

	// RVA: 0x7239FDC
	public override object Read(object buffer, object offset, object size) { }

	// RVA: 0x723A334
	public override object Read(object destination) { }

	// RVA: 0x723A5CC
	public override object ReadByte() { }

	// RVA: 0x723A650
	public override object Write(object buffer, object offset, object size) { }

	// RVA: 0x723A9A8
	public override object Write(object source) { }

	// RVA: 0x723AC40
	public override object WriteByte(object value) { }

	// RVA: 0x723ACB8
	public object Close(object timeout) { }

	// RVA: 0x723AD20
	protected override object Dispose(object disposing) { }

	// RVA: 0x723ADC0
	protected override object Finalize() { }

	// RVA: 0x723AE7C
	public override object BeginRead(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x723B1EC
	public override object EndRead(object asyncResult) { }

	// RVA: 0x723B42C
	public override object BeginWrite(object buffer, object offset, object size, object callback, object state) { }

	// RVA: 0x723B79C
	public override object EndWrite(object asyncResult) { }

	// RVA: 0x723B9DC
	public override object ReadAsync(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x723BDE0
	public override object ReadAsync(object buffer, object cancellationToken) { }

	// RVA: 0x723C068
	public override object WriteAsync(object buffer, object offset, object size, object cancellationToken) { }

	// RVA: 0x723C47C
	public override object WriteAsync(object buffer, object cancellationToken) { }

	// RVA: 0x723C700
	public override object Flush() { }

	// RVA: 0x723C704
	public override object FlushAsync(object cancellationToken) { }

	// RVA: 0x723C7C8
	public override object SetLength(object value) { }

	// RVA: 0x7239AA0
	internal object SetSocketTimeoutOption(object mode, object timeout, object silent) { }

	// RVA: 0x723C81C
	internal object get_InternalSocket() { }

}

// Namespace: 
private sealed class CachedEventArgs
{

	// Fields
	public object TaskAccept; // 0x8
	public object TaskReceive; // 0x10
	public object TaskSend; // 0x18
	public object ValueTaskReceive; // 0x20
	public object ValueTaskSend; // 0x28

	// Methods

	// RVA: 0x7248780
	public object .ctor() { }

}

// Namespace: 
private class TaskSocketAsyncEventArgs<T0>
{

	// Fields
	internal object _builder; // 0x0
	internal object _accessed; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor() { }

	// RVA: -1
	internal object GetCompletionResponsibility(object responsibleForReturningToPool) { }

}

// Namespace: 
private sealed class Int32TaskSocketAsyncEventArgs
{

	// Fields
	internal object _wrapExceptionsInIOExceptions; // 0xC9

	// Methods

	// RVA: 0x7248728
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__14_0; // 0x8
	public static object <>9__20_0; // 0x10

	// Methods

	// RVA: 0x7249894
	private static object .cctor() { }

	// RVA: 0x72498F4
	public object .ctor() { }

	// RVA: 0x72498FC
	internal object <OnCompleted>b__14_0(object runState) { }

	// RVA: 0x72499C4
	internal object <InvokeContinuation>b__20_0(object s) { }

	// RVA: 0x7249A88
	internal object <.cctor>b__27_0(object state) { }

	// RVA: 0x7249ADC
	internal object <.cctor>b__27_1(object state) { }

}

// Namespace: 
internal sealed class AwaitableSocketAsyncEventArgs
{

	// Fields
	internal static readonly object Reserved; // 0x0
	private static readonly object s_completedSentinel; // 0x8
	private static readonly object s_availableSentinel; // 0x10
	private object _continuation; // 0xB0
	private object _executionContext; // 0xB8
	private object _scheduler; // 0xC0
	private object _token; // 0xC8
	private object <WrapExceptionsInIOExceptions>k__BackingField; // 0xCA

	// Properties
	public object WrapExceptionsInIOExceptions { get; set; }

	// Methods

	// RVA: 0x7248788
	public object .ctor() { }

	// RVA: 0x7248920
	public object get_WrapExceptionsInIOExceptions() { }

	// RVA: 0x7248928
	public object set_WrapExceptionsInIOExceptions(object value) { }

	// RVA: 0x723CC7C
	public object Reserve() { }

	// RVA: 0x7248930
	private object Release() { }

	// RVA: 0x72489AC
	protected override object OnCompleted(object _) { }

	// RVA: 0x723CDFC
	public object ReceiveAsync(object socket) { }

	// RVA: 0x723D77C
	public object SendAsyncForNetworkStream(object socket) { }

	// RVA: 0x7249028
	public object GetStatus(object token) { }

	// RVA: 0x724917C
	public object OnCompleted(object continuation, object state, object token, object flags) { }

	// RVA: 0x7248BD8
	private object InvokeContinuation(object continuation, object state, object forceAsync) { }

	// RVA: 0x72494B8
	public object GetResult(object token) { }

	// RVA: 0x724961C
	private object System.Threading.Tasks.Sources.IValueTaskSource.GetResult(object token) { }

	// RVA: 0x7249128
	private object ThrowIncorrectTokenException() { }

	// RVA: 0x7249464
	private object ThrowMultipleContinuationsException() { }

	// RVA: 0x72495F0
	private object ThrowException(object error) { }

	// RVA: 0x7248F20
	private object CreateException(object error) { }

	// RVA: 0x7249744
	private static object .cctor() { }

}

// Namespace: 
private struct WSABUF
{

	// Fields
	public object len; // 0xFFFFFFFFFFFFFFF8
	public object buf; // 0x0
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__14_0; // 0x8
	public static object <>9__14_1; // 0x10
	public static object <>9__15_0; // 0x18
	public static object <>9__15_1; // 0x20
	public static object <>9__22_0; // 0x28
	public static object <>9__22_1; // 0x30
	public static object <>9__23_0; // 0x38
	public static object <>9__23_1; // 0x40
	public static object <>9__295_0; // 0x48
	public static object <>9__297_0; // 0x50

	// Methods

	// RVA: 0x7249B30
	private static object .cctor() { }

	// RVA: 0x7249B90
	public object .ctor() { }

	// RVA: 0x7249B98
	internal object <ReceiveAsync>b__14_0() { }

	// RVA: 0x7249BF0
	internal object <ReceiveAsync>b__14_1() { }

	// RVA: 0x7249C44
	internal object <ReceiveAsyncApm>b__15_0(object iar) { }

	// RVA: 0x7249F48
	internal object <ReceiveAsyncApm>b__15_1(object iar) { }

	// RVA: 0x724A5E4
	internal object <SendAsyncForNetworkStream>b__22_0() { }

	// RVA: 0x724A63C
	internal object <SendAsyncForNetworkStream>b__22_1() { }

	// RVA: 0x724A690
	internal object <SendAsyncApm>b__23_0(object iar) { }

	// RVA: 0x724A994
	internal object <SendAsyncApm>b__23_1(object iar) { }

	// RVA: 0x724AED0
	internal object <SendAsync>b__295_0(object s) { }

	// RVA: 0x724AF78
	internal object <BeginSend>b__297_0(object s) { }

	// RVA: 0x724B020
	internal object <.cctor>b__367_0(object s, object e) { }

	// RVA: 0x724B124
	internal object <.cctor>b__367_1(object s, object e) { }

	// RVA: 0x724B210
	internal object <.cctor>b__367_2(object s, object e) { }

	// RVA: 0x724B2FC
	internal object <.cctor>b__367_3(object ares) { }

	// RVA: 0x724B6E0
	internal object <.cctor>b__367_4(object ares) { }

	// RVA: 0x724B854
	internal object <.cctor>b__367_5(object ares) { }

	// RVA: 0x724BAF4
	internal object <.cctor>b__367_6(object ares) { }

	// RVA: 0x724BE70
	internal object <.cctor>b__367_7(object ares) { }

	// RVA: 0x724C3B8
	internal object <.cctor>b__367_8(object ares) { }

	// RVA: 0x724C6C0
	internal object <.cctor>b__367_9(object ares) { }

	// RVA: 0x724C7F0
	internal object <.cctor>b__367_10(object ares) { }

	// RVA: 0x724CB54
	internal object <.cctor>b__367_11(object ares) { }

	// RVA: 0x724CE34
	internal object <.cctor>b__367_12(object ares) { }

	// RVA: 0x724CFD4
	internal object <.cctor>b__367_13(object ares) { }

	// RVA: 0x724D314
	internal object <.cctor>b__367_14(object ares) { }

	// RVA: 0x724D4D0
	internal object <.cctor>b__367_15(object ares) { }

	// RVA: 0x724D834
	internal object <.cctor>b__367_16(object ares) { }

	// RVA: 0x724D9D4
	internal object <.cctor>b__367_17(object ares) { }

}

// Namespace: 
private sealed class <>c__DisplayClass240_0
{

	// Fields
	public object sockares; // 0x8

	// Methods

	// RVA: 0x72444D0
	public object .ctor() { }

	// RVA: 0x724DCEC
	internal object <BeginConnect>b__0(object t) { }

}

// Namespace: 
private sealed class <>c__DisplayClass298_0
{

	// Fields
	public object sent_so_far; // 0x8

	// Methods

	// RVA: 0x7247248
	public object .ctor() { }

	// RVA: 0x724DE6C
	internal object <BeginSendCallback>b__0(object s) { }

}

// Namespace: 
private sealed class <>c__DisplayClass355_0
{

	// Fields
	public object <>4__this; // 0x8
	public object job; // 0x10
	public object handle; // 0x18

	// Methods

	// RVA: 0x7247CC4
	public object .ctor() { }

	// RVA: 0x724DF20
	internal object <QueueIOSelectorJob>b__0(object t) { }

}

// Namespace: System.Net.Sockets
public class Socket
{

	// Fields
	private static readonly object AcceptCompletedHandler; // 0x0
	private static readonly object ReceiveCompletedHandler; // 0x8
	private static readonly object SendCompletedHandler; // 0x10
	private static readonly object s_rentedSocketSentinel; // 0x18
	private static readonly object s_rentedInt32Sentinel; // 0x20
	private static readonly object s_zeroTask; // 0x28
	private object _cachedTaskEventArgs; // 0x8
	private static object s_InternalSyncObject; // 0x30
	internal static object s_SupportsIPv4; // 0x38
	internal static object s_SupportsIPv6; // 0x39
	internal static object s_OSSupportsIPv6; // 0x3A
	internal static object s_Initialized; // 0x3B
	private static object s_LoggingEnabled; // 0x3C
	internal static object s_PerfCountersEnabled; // 0x3D
	internal const object DefaultCloseTimeout;
	private const object SOCKET_CLOSED_CODE;
	private const object TIMEOUT_EXCEPTION_MSG;
	private object is_closed; // 0x10
	private object is_listening; // 0x11
	private object useOverlappedIO; // 0x12
	private object linger_timeout; // 0x14
	private object addressFamily; // 0x18
	private object socketType; // 0x1C
	private object protocolType; // 0x20
	internal object m_Handle; // 0x28
	internal object seed_endpoint; // 0x30
	internal object ReadSem; // 0x38
	internal object WriteSem; // 0x40
	internal object is_blocking; // 0x48
	internal object is_bound; // 0x49
	internal object is_connected; // 0x4A
	private object m_IntCleanedUp; // 0x4C
	internal object connect_in_progress; // 0x50
	internal readonly object ID; // 0x54
	private static object AcceptAsyncCallback; // 0x40
	private static object BeginAcceptCallback; // 0x48
	private static object BeginAcceptReceiveCallback; // 0x50
	private static object ConnectAsyncCallback; // 0x58
	private static object BeginConnectCallback; // 0x60
	private static object DisconnectAsyncCallback; // 0x68
	private static object BeginDisconnectCallback; // 0x70
	private static object ReceiveAsyncCallback; // 0x78
	private static object BeginReceiveCallback; // 0x80
	private static object BeginReceiveGenericCallback; // 0x88
	private static object ReceiveFromAsyncCallback; // 0x90
	private static object BeginReceiveFromCallback; // 0x98
	private static object SendAsyncCallback; // 0xA0
	private static object BeginSendGenericCallback; // 0xA8
	private static object SendToAsyncCallback; // 0xB0

	// Properties
	public static object OSSupportsIPv4 { get; }
	public static object OSSupportsIPv6 { get; }
	public object Handle { get; }
	public object AddressFamily { get; }
	public object SocketType { get; }
	public object ProtocolType { get; }
	public object ReceiveTimeout { set; }
	public object DontFragment { set; }
	public object DualMode { get; set; }
	private object IsDualMode { get; }
	private static object InternalSyncObject { get; }
	internal object CleanedUp { get; }
	public object Available { get; }
	public object LocalEndPoint { get; }
	public object Blocking { get; set; }
	public object Connected { get; }
	public object NoDelay { set; }
	public object RemoteEndPoint { get; }
	internal static object FamilyHint { get; }

	// Methods

	// RVA: 0x723C8BC
	internal object ReceiveAsync(object buffer, object socketFlags, object fromNetworkStream, object cancellationToken) { }

	// RVA: 0x723CEA0
	private object ReceiveAsyncApm(object buffer, object socketFlags) { }

	// RVA: 0x723D390
	internal object SendAsyncForNetworkStream(object buffer, object socketFlags, object cancellationToken) { }

	// RVA: 0x723D7EC
	private object SendAsyncApm(object buffer, object socketFlags) { }

	// RVA: 0x723DD34
	private static object CompleteAccept(object s, object saea) { }

	// RVA: 0x723E08C
	private static object CompleteSendReceive(object s, object saea, object isReceive) { }

	// RVA: 0x723DF8C
	private static object GetException(object error, object wrapExceptionsInIOExceptions) { }

	// RVA: 0x723E25C
	private object ReturnSocketAsyncEventArgs(object saea, object isReceive) { }

	// RVA: 0x723DF34
	private object ReturnSocketAsyncEventArgs(object saea) { }

	// RVA: 0x723E2F4
	public object .ctor(object addressFamily, object socketType, object protocolType) { }

	// RVA: 0x723EBB8
	public static object get_OSSupportsIPv4() { }

	// RVA: 0x723EC20
	public static object get_OSSupportsIPv6() { }

	// RVA: 0x723EC88
	public object get_Handle() { }

	// RVA: 0x723ECAC
	public object get_AddressFamily() { }

	// RVA: 0x723ECB4
	public object get_SocketType() { }

	// RVA: 0x723ECBC
	public object get_ProtocolType() { }

	// RVA: 0x723ECC4
	public object set_ReceiveTimeout(object value) { }

	// RVA: 0x723EE58
	public object set_DontFragment(object value) { }

	// RVA: 0x723EED0
	public object get_DualMode() { }

	// RVA: 0x723F1A0
	public object set_DualMode(object value) { }

	// RVA: 0x723F218
	private object get_IsDualMode() { }

	// RVA: 0x723F230
	internal object CanTryAddressFamily(object family) { }

	// RVA: 0x723F268
	public object Send(object buffer) { }

	// RVA: 0x723F360
	public object Send(object buffers, object socketFlags) { }

	// RVA: 0x723F2F8
	public object Send(object buffer, object offset, object size, object socketFlags) { }

	// RVA: 0x723FB84
	public object SendTo(object buffer, object size, object socketFlags, object remoteEP) { }

	// RVA: 0x723FD98
	public object Receive(object buffer) { }

	// RVA: 0x723FE28
	public object Receive(object buffer, object offset, object size, object socketFlags) { }

	// RVA: 0x723FFE8
	public object Receive(object buffers, object socketFlags) { }

	// RVA: 0x7240624
	public object ReceiveFrom(object buffer, object size, object socketFlags, object remoteEP) { }

	// RVA: 0x7240790
	public object IOControl(object ioControlCode, object optionInValue, object optionOutValue) { }

	// RVA: 0x723E9D0
	public object SetIPProtectionLevel(object level) { }

	// RVA: 0x723DCBC
	public object BeginSend(object buffer, object offset, object size, object socketFlags, object callback, object state) { }

	// RVA: 0x7240BA4
	public object EndSend(object asyncResult) { }

	// RVA: 0x723D318
	public object BeginReceive(object buffer, object offset, object size, object socketFlags, object callback, object state) { }

	// RVA: 0x7240F9C
	public object EndReceive(object asyncResult) { }

	// RVA: 0x72411B0
	private static object get_InternalSyncObject() { }

	// RVA: 0x72412B4
	internal object get_CleanedUp() { }

	// RVA: 0x723E588
	internal static object InitializeSockets() { }

	// RVA: 0x7241344
	public object Dispose() { }

	// RVA: 0x72413DC
	protected override object Finalize() { }

	// RVA: 0x7241494
	internal object InternalShutdown(object how) { }

	// RVA: 0x7241698
	internal object SetSocketOption(object optionLevel, object optionName, object optionValue, object silent) { }

	// RVA: 0x7241998
	internal object .ctor(object family, object type, object proto, object safe_handle) { }

	// RVA: 0x723EAD8
	private object SocketDefaults() { }

	// RVA: 0x723E8A8
	private static object Socket_icall(object family, object type, object proto, object error) { }

	// RVA: 0x7241B08
	public object get_Available() { }

	// RVA: 0x7241C4C
	private static object Available_internal(object safeHandle, object error) { }

	// RVA: 0x7241DC0
	private static object Available_icall(object socket, object error) { }

	// RVA: 0x7241DC4
	public object get_LocalEndPoint() { }

	// RVA: 0x7241EE8
	private static object LocalEndPoint_internal(object safeHandle, object family, object error) { }

	// RVA: 0x7242064
	private static object LocalEndPoint_icall(object socket, object family, object error) { }

	// RVA: 0x7242068
	public object get_Blocking() { }

	// RVA: 0x7242070
	public object set_Blocking(object value) { }

	// RVA: 0x7242138
	private static object Blocking_internal(object safeHandle, object block, object error) { }

	// RVA: 0x72422A4
	internal static object Blocking_icall(object socket, object block, object error) { }

	// RVA: 0x72422A8
	public object get_Connected() { }

	// RVA: 0x7241A94
	public object set_NoDelay(object value) { }

	// RVA: 0x7242300
	public object get_RemoteEndPoint() { }

	// RVA: 0x7242430
	private static object RemoteEndPoint_internal(object safeHandle, object family, object error) { }

	// RVA: 0x72425AC
	private static object RemoteEndPoint_icall(object socket, object family, object error) { }

	// RVA: 0x72425B0
	public object Poll(object microSeconds, object mode) { }

	// RVA: 0x7242764
	private static object Poll_internal(object safeHandle, object mode, object timeout, object error) { }

	// RVA: 0x72428F0
	private static object Poll_icall(object socket, object mode, object timeout, object error) { }

	// RVA: 0x72428F4
	public object Accept() { }

	// RVA: 0x7242BB4
	internal object Accept(object acceptSocket) { }

	// RVA: 0x7242CDC
	public object BeginAccept(object callback, object state) { }

	// RVA: 0x7243028
	public object EndAccept(object asyncResult) { }

	// RVA: 0x7243050
	public object EndAccept(object buffer, object bytesTransferred, object asyncResult) { }

	// RVA: 0x7242A38
	private static object Accept_internal(object safeHandle, object error, object blocking) { }

	// RVA: 0x72434E0
	private static object Accept_icall(object sock, object error, object blocking) { }

	// RVA: 0x724352C
	public object Bind(object localEP) { }

	// RVA: 0x72437C4
	private static object Bind_internal(object safeHandle, object sa, object error) { }

	// RVA: 0x7243930
	private static object Bind_icall(object sock, object sa, object error) { }

	// RVA: 0x7243934
	public object Listen(object backlog) { }

	// RVA: 0x7243A24
	private static object Listen_internal(object safeHandle, object backlog, object error) { }

	// RVA: 0x7243B90
	private static object Listen_icall(object sock, object backlog, object error) { }

	// RVA: 0x7243B94
	public object Connect(object address, object port) { }

	// RVA: 0x7243C14
	public object Connect(object remoteEP) { }

	// RVA: 0x7244198
	public object BeginConnect(object host, object port, object callback, object state) { }

	// RVA: 0x72444D8
	public object BeginConnect(object remoteEP, object callback, object state) { }

	// RVA: 0x7244BC0
	private static object BeginMConnect(object sockares) { }

	// RVA: 0x7244628
	private static object BeginSConnect(object sockares) { }

	// RVA: 0x7244E28
	public object EndConnect(object asyncResult) { }

	// RVA: 0x724404C
	private static object Connect_internal(object safeHandle, object sa, object error, object blocking) { }

	// RVA: 0x7244F14
	private static object Connect_icall(object sock, object sa, object error, object blocking) { }

	// RVA: 0x7244F18
	public object Disconnect(object reuseSocket) { }

	// RVA: 0x7245188
	public object EndDisconnect(object asyncResult) { }

	// RVA: 0x724501C
	private static object Disconnect_internal(object safeHandle, object reuse, object error) { }

	// RVA: 0x7245274
	private static object Disconnect_icall(object sock, object reuse, object error) { }

	// RVA: 0x723FE90
	public object Receive(object buffer, object offset, object size, object socketFlags, object errorCode) { }

	// RVA: 0x7245578
	private object Receive(object buffer, object offset, object size, object socketFlags, object errorCode) { }

	// RVA: 0x7240050
	public object Receive(object buffers, object socketFlags, object errorCode) { }

	// RVA: 0x7245A14
	public object Receive(object buffer, object socketFlags, object errorCode) { }

	// RVA: 0x7245B68
	public object Send(object buffer, object socketFlags, object errorCode) { }

	// RVA: 0x7245C08
	public object ReceiveAsync(object e) { }

	// RVA: 0x7240DB8
	public object BeginReceive(object buffer, object offset, object size, object socketFlags, object errorCode, object callback, object state) { }

	// RVA: 0x7241004
	public object EndReceive(object asyncResult, object errorCode) { }

	// RVA: 0x72457BC
	private static object Receive_internal(object safeHandle, object bufarray, object count, object flags, object error, object blocking) { }

	// RVA: 0x7246018
	private static object Receive_array_icall(object sock, object bufarray, object count, object flags, object error, object blocking) { }

	// RVA: 0x7245404
	private static object Receive_internal(object safeHandle, object buffer, object count, object flags, object error, object blocking) { }

	// RVA: 0x724601C
	private static object Receive_icall(object sock, object buffer, object count, object flags, object error, object blocking) { }

	// RVA: 0x7240638
	public object ReceiveFrom(object buffer, object offset, object size, object socketFlags, object remoteEP) { }

	// RVA: 0x7246020
	internal object ReceiveFrom(object buffer, object offset, object size, object socketFlags, object remoteEP, object errorCode) { }

	// RVA: 0x724637C
	private object ReceiveFrom(object buffer, object offset, object size, object socketFlags, object remoteEP, object errorCode) { }

	// RVA: 0x724664C
	private object EndReceiveFrom_internal(object sockares, object ares) { }

	// RVA: 0x7246200
	private static object ReceiveFrom_internal(object safeHandle, object buffer, object count, object flags, object sockaddr, object error, object blocking) { }

	// RVA: 0x7246760
	private static object ReceiveFrom_icall(object sock, object buffer, object count, object flags, object sockaddr, object error, object blocking) { }

	// RVA: 0x723FA00
	public object Send(object buffer, object offset, object size, object socketFlags, object errorCode) { }

	// RVA: 0x723F3C8
	public object Send(object buffers, object socketFlags, object errorCode) { }

	// RVA: 0x7246B30
	public object SendAsync(object e) { }

	// RVA: 0x7240928
	public object BeginSend(object buffer, object offset, object size, object socketFlags, object errorCode, object callback, object state) { }

	// RVA: 0x7246E64
	private static object BeginSendCallback(object sockares, object sent_so_far) { }

	// RVA: 0x7240C0C
	public object EndSend(object asyncResult, object errorCode) { }

	// RVA: 0x72468D8
	private static object Send_internal(object safeHandle, object bufarray, object count, object flags, object error, object blocking) { }

	// RVA: 0x7247260
	private static object Send_array_icall(object sock, object bufarray, object count, object flags, object error, object blocking) { }

	// RVA: 0x7246764
	private static object Send_internal(object safeHandle, object buffer, object count, object flags, object error, object blocking) { }

	// RVA: 0x7247264
	private static object Send_icall(object sock, object buffer, object count, object flags, object error, object blocking) { }

	// RVA: 0x723FB98
	public object SendTo(object buffer, object offset, object size, object socketFlags, object remoteEP) { }

	// RVA: 0x72473E4
	public object EndSendTo(object asyncResult) { }

	// RVA: 0x7247268
	private static object SendTo_internal(object safeHandle, object buffer, object count, object flags, object sa, object error, object blocking) { }

	// RVA: 0x72474D8
	private static object SendTo_icall(object sock, object buffer, object count, object flags, object sa, object error, object blocking) { }

	// RVA: 0x723EFC0
	public object GetSocketOption(object optionLevel, object optionName) { }

	// RVA: 0x72474DC
	private static object GetSocketOption_obj_internal(object safeHandle, object level, object name, object obj_val, object error) { }

	// RVA: 0x7247660
	private static object GetSocketOption_obj_icall(object socket, object level, object name, object obj_val, object error) { }

	// RVA: 0x723ED34
	public object SetSocketOption(object optionLevel, object optionName, object optionValue) { }

	// RVA: 0x72417FC
	private static object SetSocketOption_internal(object safeHandle, object level, object name, object obj_val, object byte_val, object int_val, object error) { }

	// RVA: 0x7247664
	private static object SetSocketOption_icall(object socket, object level, object name, object obj_val, object byte_val, object int_val, object error) { }

	// RVA: 0x7240794
	public object IOControl(object ioControlCode, object optionInValue, object optionOutValue) { }

	// RVA: 0x7247668
	private static object IOControl_internal(object safeHandle, object ioctl_code, object input, object output, object error) { }

	// RVA: 0x72477FC
	private static object IOControl_icall(object sock, object ioctl_code, object input, object output, object error) { }

	// RVA: 0x7247800
	public object Close() { }

	// RVA: 0x724789C
	public object Close(object timeout) { }

	// RVA: 0x7247938
	internal static object Close_icall(object socket, object error) { }

	// RVA: 0x724793C
	public object Shutdown(object how) { }

	// RVA: 0x724152C
	private static object Shutdown_internal(object safeHandle, object how, object error) { }

	// RVA: 0x7247A64
	internal static object Shutdown_icall(object socket, object how, object error) { }

	// RVA: 0x7247A68
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x7247AE0
	private object Linger(object handle) { }

	// RVA: 0x7241BC4
	private object ThrowIfDisposedAndClosed() { }

	// RVA: 0x7245278
	private object ThrowIfBufferNull(object buffer) { }

	// RVA: 0x72452D4
	private object ThrowIfBufferOutOfRange(object buffer, object offset, object size) { }

	// RVA: 0x72422B0
	private object ThrowIfUdp() { }

	// RVA: 0x7243180
	private object ValidateEndIAsyncResult(object ares, object methodName, object argName) { }

	// RVA: 0x7242EBC
	private object QueueIOSelectorJob(object sem, object handle, object job) { }

	// RVA: 0x7245E64
	private object InitSocketAsyncEventArgs(object e, object callback, object state, object operation) { }

	// RVA: 0x7247D8C
	private object SocketOperationToSocketAsyncOperation(object op) { }

	// RVA: 0x72436D8
	private object RemapIPEndPoint(object input) { }

	// RVA: 0x7247F10
	internal static object cancel_blocking_socket_operation(object thread) { }

	// RVA: 0x7247F14
	internal static object get_FamilyHint() { }

	// RVA: 0x724805C
	private static object IsProtocolSupported_internal(object networkInterface) { }

	// RVA: 0x72412C4
	private static object IsProtocolSupported(object networkInterface) { }

	// RVA: 0x7248060
	private static object .cctor() { }

}

// Namespace: System.Net.Sockets
public class SocketException
{

	// Fields
	private object m_EndPoint; // 0x88

	// Properties
	public override object Message { get; }
	public object SocketErrorCode { get; }

	// Methods

	// RVA: 0x724DF7C
	private static object WSAGetLastError_icall() { }

	// RVA: 0x723E9A4
	public object .ctor() { }

	// RVA: 0x724DF80
	internal object .ctor(object error, object message) { }

	// RVA: 0x723E2EC
	public object .ctor(object errorCode) { }

	// RVA: 0x723F9F8
	internal object .ctor(object socketError) { }

	// RVA: 0x724DF88
	protected object .ctor(object serializationInfo, object streamingContext) { }

	// RVA: 0x724DF90
	public override object get_Message() { }

	// RVA: 0x724B5EC
	public object get_SocketErrorCode() { }

}

// Namespace: System.Net.Sockets
public enum AddressFamily
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Unspecified;
	public const object Unix;
	public const object InterNetwork;
	public const object ImpLink;
	public const object Pup;
	public const object Chaos;
	public const object NS;
	public const object Ipx;
	public const object Iso;
	public const object Osi;
	public const object Ecma;
	public const object DataKit;
	public const object Ccitt;
	public const object Sna;
	public const object DecNet;
	public const object DataLink;
	public const object Lat;
	public const object HyperChannel;
	public const object AppleTalk;
	public const object NetBios;
	public const object VoiceView;
	public const object FireFox;
	public const object Banyan;
	public const object Atm;
	public const object InterNetworkV6;
	public const object Cluster;
	public const object Ieee12844;
	public const object Irda;
	public const object NetworkDesigners;
	public const object Max;
}

// Namespace: System.Net.Sockets
public enum IOControlCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AsyncIO;
	public const object NonBlockingIO;
	public const object DataToRead;
	public const object OobDataRead;
	public const object AssociateHandle;
	public const object EnableCircularQueuing;
	public const object Flush;
	public const object GetBroadcastAddress;
	public const object GetExtensionFunctionPointer;
	public const object GetQos;
	public const object GetGroupQos;
	public const object MultipointLoopback;
	public const object MulticastScope;
	public const object SetQos;
	public const object SetGroupQos;
	public const object TranslateHandle;
	public const object RoutingInterfaceQuery;
	public const object RoutingInterfaceChange;
	public const object AddressListQuery;
	public const object AddressListChange;
	public const object QueryTargetPnpHandle;
	public const object NamespaceChange;
	public const object AddressListSort;
	public const object ReceiveAll;
	public const object ReceiveAllMulticast;
	public const object ReceiveAllIgmpMulticast;
	public const object KeepAliveValues;
	public const object AbsorbRouterAlert;
	public const object UnicastInterface;
	public const object LimitBroadcasts;
	public const object BindToInterface;
	public const object MulticastInterface;
	public const object AddMulticastGroupOnInterface;
	public const object DeleteMulticastGroupFromInterface;
}

// Namespace: System.Net.Sockets
public struct IPPacketInformation
{

	// Fields
	private object address; // 0xFFFFFFFFFFFFFFF8
	private object networkInterface; // 0x0

	// Methods

	// RVA: 0x724E088
	public override object Equals(object comparand) { }

	// RVA: 0x724E178
	public override object GetHashCode() { }

}

// Namespace: System.Net.Sockets
public enum IPProtectionLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unspecified;
	public const object Unrestricted;
	public const object EdgeRestricted;
	public const object Restricted;
}

// Namespace: System.Net.Sockets
public class LingerOption
{

	// Fields
	private object enabled; // 0x8
	private object lingerTime; // 0xC

	// Properties
	public object Enabled { set; }
	public object LingerTime { set; }

	// Methods

	// RVA: 0x7247C88
	public object .ctor(object enable, object seconds) { }

	// RVA: 0x724E248
	public object set_Enabled(object value) { }

	// RVA: 0x724E250
	public object set_LingerTime(object value) { }

}

// Namespace: System.Net.Sockets
public class MulticastOption
{
}

// Namespace: System.Net.Sockets
public enum ProtocolType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IP;
	public const object IPv6HopByHopOptions;
	public const object Icmp;
	public const object Igmp;
	public const object Ggp;
	public const object IPv4;
	public const object Tcp;
	public const object Pup;
	public const object Udp;
	public const object Idp;
	public const object IPv6;
	public const object IPv6RoutingHeader;
	public const object IPv6FragmentHeader;
	public const object IPSecEncapsulatingSecurityPayload;
	public const object IPSecAuthenticationHeader;
	public const object IcmpV6;
	public const object IPv6NoNextHeader;
	public const object IPv6DestinationOptions;
	public const object ND;
	public const object Raw;
	public const object Unspecified;
	public const object Ipx;
	public const object Spx;
	public const object SpxII;
	public const object Unknown;
}

// Namespace: System.Net.Sockets
public enum SelectMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SelectRead;
	public const object SelectWrite;
	public const object SelectError;
}

// Namespace: System.Net.Sockets
public enum SocketAsyncOperation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Accept;
	public const object Connect;
	public const object Disconnect;
	public const object Receive;
	public const object ReceiveFrom;
	public const object ReceiveMessageFrom;
	public const object Send;
	public const object SendPackets;
	public const object SendTo;
}

// Namespace: System.Net.Sockets
public class SendPacketsElement
{

	// Fields
	internal object m_FilePath; // 0x8
	internal object m_Buffer; // 0x10
	internal object m_Offset; // 0x18
	internal object m_Count; // 0x1C
	private object m_endOfPacket; // 0x20
}

// Namespace: System.Net.Sockets
public enum SocketError
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Success;
	public const object SocketError;
	public const object Interrupted;
	public const object AccessDenied;
	public const object Fault;
	public const object InvalidArgument;
	public const object TooManyOpenSockets;
	public const object WouldBlock;
	public const object InProgress;
	public const object AlreadyInProgress;
	public const object NotSocket;
	public const object DestinationAddressRequired;
	public const object MessageSize;
	public const object ProtocolType;
	public const object ProtocolOption;
	public const object ProtocolNotSupported;
	public const object SocketNotSupported;
	public const object OperationNotSupported;
	public const object ProtocolFamilyNotSupported;
	public const object AddressFamilyNotSupported;
	public const object AddressAlreadyInUse;
	public const object AddressNotAvailable;
	public const object NetworkDown;
	public const object NetworkUnreachable;
	public const object NetworkReset;
	public const object ConnectionAborted;
	public const object ConnectionReset;
	public const object NoBufferSpaceAvailable;
	public const object IsConnected;
	public const object NotConnected;
	public const object Shutdown;
	public const object TimedOut;
	public const object ConnectionRefused;
	public const object HostDown;
	public const object HostUnreachable;
	public const object ProcessLimit;
	public const object SystemNotReady;
	public const object VersionNotSupported;
	public const object NotInitialized;
	public const object Disconnecting;
	public const object TypeNotFound;
	public const object HostNotFound;
	public const object TryAgain;
	public const object NoRecovery;
	public const object NoData;
	public const object IOPending;
	public const object OperationAborted;
}

// Namespace: System.Net.Sockets
public enum SocketFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object OutOfBand;
	public const object Peek;
	public const object DontRoute;
	public const object MaxIOVectorLength;
	public const object Truncated;
	public const object ControlDataTruncated;
	public const object Broadcast;
	public const object Multicast;
	public const object Partial;
}

// Namespace: System.Net.Sockets
public enum SocketOptionLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Socket;
	public const object IP;
	public const object IPv6;
	public const object Tcp;
	public const object Udp;
}

// Namespace: System.Net.Sockets
public enum SocketOptionName
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Debug;
	public const object AcceptConnection;
	public const object ReuseAddress;
	public const object KeepAlive;
	public const object DontRoute;
	public const object Broadcast;
	public const object UseLoopback;
	public const object Linger;
	public const object OutOfBandInline;
	public const object DontLinger;
	public const object ExclusiveAddressUse;
	public const object SendBuffer;
	public const object ReceiveBuffer;
	public const object SendLowWater;
	public const object ReceiveLowWater;
	public const object SendTimeout;
	public const object ReceiveTimeout;
	public const object Error;
	public const object Type;
	public const object ReuseUnicastPort;
	public const object MaxConnections;
	public const object IPOptions;
	public const object HeaderIncluded;
	public const object TypeOfService;
	public const object IpTimeToLive;
	public const object MulticastInterface;
	public const object MulticastTimeToLive;
	public const object MulticastLoopback;
	public const object AddMembership;
	public const object DropMembership;
	public const object DontFragment;
	public const object AddSourceMembership;
	public const object DropSourceMembership;
	public const object BlockSource;
	public const object UnblockSource;
	public const object PacketInformation;
	public const object HopLimit;
	public const object IPProtectionLevel;
	public const object IPv6Only;
	public const object NoDelay;
	public const object BsdUrgent;
	public const object Expedited;
	public const object NoChecksum;
	public const object ChecksumCoverage;
	public const object UpdateAcceptContext;
	public const object UpdateConnectContext;
}

// Namespace: System.Net.Sockets
public enum SocketShutdown
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Receive;
	public const object Send;
	public const object Both;
}

// Namespace: System.Net.Sockets
public enum SocketType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Stream;
	public const object Dgram;
	public const object Raw;
	public const object Rdm;
	public const object Seqpacket;
	public const object Unknown;
}

// Namespace: System.Net.Sockets
public class TcpClient
{

	// Fields
	private object m_ClientSocket; // 0x8
	private object m_Active; // 0x10
	private object m_DataStream; // 0x18
	private object m_Family; // 0x20
	private object m_CleanedUp; // 0x24

	// Properties
	public object Client { get; set; }
	public object Connected { get; }

	// Methods

	// RVA: 0x724E258
	public object .ctor() { }

	// RVA: 0x724E2FC
	public object .ctor(object family) { }

	// RVA: 0x724E4D8
	public object .ctor(object hostname, object port) { }

	// RVA: 0x724F034
	public object get_Client() { }

	// RVA: 0x724F03C
	public object set_Client(object value) { }

	// RVA: 0x724F044
	public object get_Connected() { }

	// RVA: 0x724E730
	public object Connect(object hostname, object port) { }

	// RVA: 0x724F068
	public object Connect(object remoteEP) { }

	// RVA: 0x724F240
	public object BeginConnect(object host, object port, object requestCallback, object state) { }

	// RVA: 0x724F2BC
	public object EndConnect(object asyncResult) { }

	// RVA: 0x724F30C
	public object ConnectAsync(object host, object port) { }

	// RVA: 0x724F4A0
	public object GetStream() { }

	// RVA: 0x724F604
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x724F99C
	public object Dispose() { }

	// RVA: 0x724F9E0
	protected override object Finalize() { }

	// RVA: 0x724E464
	private object initialize() { }

}

// Namespace: System.Net.Sockets
public enum TransmitFileOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UseDefaultWorkerThread;
	public const object Disconnect;
	public const object ReuseSocket;
	public const object WriteBehind;
	public const object UseSystemThread;
	public const object UseKernelApc;
}

// Namespace: System.Net.Sockets
internal sealed class SafeSocketHandle
{

	// Fields
	private object blocking_threads; // 0x18
	private object threads_stacktraces; // 0x20
	private object in_cleanup; // 0x28
	private const object SOCKET_CLOSED;
	private const object ABORT_RETRIES;
	private static object THROW_ON_ABORT_RETRIES; // 0x0

	// Methods

	// RVA: 0x723E8AC
	public object .ctor(object preexistingHandle, object ownsHandle) { }

	// RVA: 0x724FA98
	protected override object ReleaseHandle() { }

	// RVA: 0x7243398
	public object RegisterForBlockingSyscall() { }

	// RVA: 0x72503F4
	public object UnRegisterForBlockingSyscall() { }

	// RVA: 0x7250638
	private static object .cctor() { }

}

// Namespace: System.Net.Sockets
public class SocketAsyncEventArgs
{

	// Fields
	private object disposed; // 0x8
	internal object in_progress; // 0xC
	private object remote_ep; // 0x10
	private object current_socket; // 0x18
	internal object socket_async_result; // 0x20
	private object <ConnectByNameError>k__BackingField; // 0x28
	private object <AcceptSocket>k__BackingField; // 0x30
	private object <BytesTransferred>k__BackingField; // 0x38
	private object <DisconnectReuseSocket>k__BackingField; // 0x3C
	private object <LastOperation>k__BackingField; // 0x40
	private object <ReceiveMessageFromPacketInfo>k__BackingField; // 0x48
	private object <SendPacketsElements>k__BackingField; // 0x58
	private object <SendPacketsFlags>k__BackingField; // 0x60
	private object <SendPacketsSendSize>k__BackingField; // 0x64
	private object <SocketError>k__BackingField; // 0x68
	private object <SocketFlags>k__BackingField; // 0x6C
	private object <UserToken>k__BackingField; // 0x70
	private object Completed; // 0x78
	private object _buffer; // 0x80
	private object _offset; // 0x90
	private object _count; // 0x94
	private object _bufferIsExplicitArray; // 0x98
	private object _bufferList; // 0xA0
	private object _bufferListInternal; // 0xA8

	// Properties
	public object AcceptSocket { get; set; }
	public object BytesTransferred { get; set; }
	private object LastOperation { set; }
	public object RemoteEndPoint { set; }
	public object SocketError { get; set; }
	public object SocketFlags { set; }
	public object UserToken { get; set; }
	internal object CurrentSocket { get; }
	public object MemoryBuffer { get; }
	public object Offset { get; }
	public object Count { get; }
	public object BufferList { get; }

	// Methods

	// RVA: 0x72506CC
	public object get_AcceptSocket() { }

	// RVA: 0x72506D4
	public object set_AcceptSocket(object value) { }

	// RVA: 0x72506DC
	public object get_BytesTransferred() { }

	// RVA: 0x72506E4
	private object set_BytesTransferred(object value) { }

	// RVA: 0x72506EC
	private object set_LastOperation(object value) { }

	// RVA: 0x72506F4
	public object set_RemoteEndPoint(object value) { }

	// RVA: 0x72506FC
	public object get_SocketError() { }

	// RVA: 0x7250704
	public object set_SocketError(object value) { }

	// RVA: 0x725070C
	public object set_SocketFlags(object value) { }

	// RVA: 0x7250714
	public object get_UserToken() { }

	// RVA: 0x725071C
	public object set_UserToken(object value) { }

	// RVA: 0x7248878
	internal object .ctor(object flowExecutionContext) { }

	// RVA: 0x725072C
	protected override object Finalize() { }

	// RVA: 0x725073C
	private object Dispose(object disposing) { }

	// RVA: 0x7250750
	public object Dispose() { }

	// RVA: 0x7247F08
	internal object SetBytesTransferred(object value) { }

	// RVA: 0x72507F0
	internal object get_CurrentSocket() { }

	// RVA: 0x72507F8
	internal object SetCurrentSocket(object socket) { }

	// RVA: 0x7247E30
	internal object SetLastOperation(object op) { }

	// RVA: 0x7250800
	internal object Complete_internal() { }

	// RVA: 0x7250848
	protected virtual object OnCompleted(object e) { }

	// RVA: 0x7250870
	public object get_MemoryBuffer() { }

	// RVA: 0x725087C
	public object get_Offset() { }

	// RVA: 0x7250884
	public object get_Count() { }

	// RVA: 0x725088C
	public object get_BufferList() { }

	// RVA: 0x723CD04
	public object SetBuffer(object buffer) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__27_0; // 0x8

	// Methods

	// RVA: 0x72508D4
	private static object .cctor() { }

	// RVA: 0x7250934
	public object .ctor() { }

	// RVA: 0x725093C
	internal object <Complete>b__27_0(object state) { }

}

// Namespace: System.Net.Sockets
internal sealed class SocketAsyncResult
{

	// Fields
	public object socket; // 0x28
	public object operation; // 0x30
	private object DelayedException; // 0x38
	public object EndPoint; // 0x40
	public object Buffer; // 0x48
	public object Offset; // 0x58
	public object Size; // 0x5C
	public object SockFlags; // 0x60
	public object AcceptSocket; // 0x68
	public object Addresses; // 0x70
	public object Port; // 0x78
	public object Buffers; // 0x80
	public object ReuseSocket; // 0x88
	public object CurrentAddress; // 0x8C
	public object AcceptedSocket; // 0x90
	public object Total; // 0x98
	internal object error; // 0x9C
	public object EndCalled; // 0xA0

	// Properties
	public object Handle { get; }
	public object ErrorCode { get; }

	// Methods

	// RVA: 0x7242E88
	public object get_Handle() { }

	// RVA: 0x7250724
	public object .ctor() { }

	// RVA: 0x7247CCC
	public object Init(object socket, object callback, object state, object operation) { }

	// RVA: 0x7242E44
	public object .ctor(object socket, object callback, object state, object operation) { }

	// RVA: 0x7245F88
	public object get_ErrorCode() { }

	// RVA: 0x72432E4
	public object CheckIfThrowDelayedException() { }

	// RVA: 0x72508D0
	internal override object CompleteDisposed() { }

	// RVA: 0x724C168
	public object Complete() { }

	// RVA: 0x7244E20
	public object Complete(object synch) { }

	// RVA: 0x7247258
	public object Complete(object total) { }

	// RVA: 0x7244E14
	public object Complete(object e, object synch) { }

	// RVA: 0x7247250
	public object Complete(object e) { }

	// RVA: 0x724B84C
	public object Complete(object s) { }

	// RVA: 0x724BAE8
	public object Complete(object s, object total) { }

}

// Namespace: System.Net.Sockets
internal enum SocketOperation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Accept;
	public const object Connect;
	public const object Receive;
	public const object ReceiveFrom;
	public const object Send;
	public const object SendTo;
	public const object RecvJustCallback;
	public const object SendJustCallback;
	public const object Disconnect;
	public const object AcceptReceive;
	public const object ReceiveGeneric;
	public const object SendGeneric;
}

// Namespace: System.Net.Security
public class SslClientAuthenticationOptions
{

	// Fields
	private object _encryptionPolicy; // 0x8
	private object _checkCertificateRevocation; // 0xC
	private object _enabledSslProtocols; // 0x10
	private object _allowRenegotiation; // 0x14
	private object <TargetHost>k__BackingField; // 0x18
	private object <ClientCertificates>k__BackingField; // 0x20

	// Properties
	public object AllowRenegotiation { get; }
	public object TargetHost { get; set; }
	public object ClientCertificates { get; set; }
	public object CertificateRevocationCheckMode { set; }
	public object EncryptionPolicy { set; }
	public object EnabledSslProtocols { get; set; }

	// Methods

	// RVA: 0x72509D0
	public object get_AllowRenegotiation() { }

	// RVA: 0x72509D8
	public object get_TargetHost() { }

	// RVA: 0x72509E0
	public object set_TargetHost(object value) { }

	// RVA: 0x72509E8
	public object get_ClientCertificates() { }

	// RVA: 0x72509F0
	public object set_ClientCertificates(object value) { }

	// RVA: 0x72509F8
	public object set_CertificateRevocationCheckMode(object value) { }

	// RVA: 0x7250A90
	public object set_EncryptionPolicy(object value) { }

	// RVA: 0x7250B28
	public object get_EnabledSslProtocols() { }

	// RVA: 0x7250B30
	public object set_EnabledSslProtocols(object value) { }

	// RVA: 0x7250B38
	public object .ctor() { }

}

// Namespace: System.Net.Security
public abstract class AuthenticatedStream
{

	// Fields
	private object _InnerStream; // 0x20
	private object _LeaveStreamOpen; // 0x28

	// Properties
	protected object InnerStream { get; }
	public abstract object IsAuthenticated { get; }

	// Methods

	// RVA: 0x7250B48
	protected object .ctor(object innerStream, object leaveInnerStreamOpen) { }

	// RVA: 0x7250D28
	protected object get_InnerStream() { }

	// RVA: 0x7250D30
	protected override object Dispose(object disposing) { }

	// RVA: -1
	public abstract object get_IsAuthenticated() { }

}

// Namespace: System.Net.Security
public enum AuthenticationLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object MutualAuthRequested;
	public const object MutualAuthRequired;
}

// Namespace: System.Net.Security
public enum EncryptionPolicy
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RequireEncryption;
	public const object AllowNoEncryption;
	public const object NoEncryption;
}

// Namespace: System.Net.Security
public sealed class LocalCertificateSelectionCallback
{

	// Methods

	// RVA: 0x7251280
	public object .ctor(object object, object method) { }

	// RVA: 0x725138C
	public virtual object Invoke(object sender, object targetHost, object localCertificates, object remoteCertificate, object acceptableIssuers) { }

}

// Namespace: System.Net.Security
public sealed class RemoteCertificateValidationCallback
{

	// Methods

	// RVA: 0x7251744
	public object .ctor(object object, object method) { }

	// RVA: 0x7251850
	public virtual object Invoke(object sender, object certificate, object chain, object sslPolicyErrors) { }

}

// Namespace: System.Net.Security
public enum SslPolicyErrors
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object RemoteCertificateNotAvailable;
	public const object RemoteCertificateNameMismatch;
	public const object RemoteCertificateChainErrors;
}

// Namespace: System.Net.Security
internal sealed class LocalCertSelectionCallback
{

	// Methods

	// RVA: 0x7251940
	public object .ctor(object object, object method) { }

	// RVA: 0x72519F0
	public virtual object Invoke(object targetHost, object localCertificates, object remoteCertificate, object acceptableIssuers) { }

}

// Namespace: System.Net.Security
internal sealed class ServerCertSelectionCallback
{

	// Methods

	// RVA: 0x7251AA4
	public object .ctor(object object, object method) { }

	// RVA: 0x7251B4C
	public virtual object Invoke(object hostName) { }

}

// Namespace: 
private sealed class <>c__DisplayClass21_0
{

	// Fields
	public object callback; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x7252228
	public object .ctor() { }

	// RVA: 0x7252FE0
	internal object <SetAndVerifySelectionCallback>b__0(object t, object lc, object rc, object ai) { }

}

// Namespace: System.Net.Security
public class SslStream
{

	// Fields
	private object provider; // 0x30
	private object settings; // 0x38
	private object validationCallback; // 0x40
	private object selectionCallback; // 0x48
	private object impl; // 0x50
	private object explicitSettings; // 0x58

	// Properties
	internal object Impl { get; }
	internal object InternalTargetHost { get; }
	public override object IsAuthenticated { get; }
	public virtual object LocalCertificate { get; }
	public override object CanSeek { get; }
	public override object CanRead { get; }
	public override object CanTimeout { get; }
	public override object CanWrite { get; }
	public override object ReadTimeout { get; set; }
	public override object WriteTimeout { get; set; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x7251B60
	internal object get_Impl() { }

	// RVA: 0x7251C20
	internal object get_InternalTargetHost() { }

	// RVA: 0x7251C84
	private static object GetProvider() { }

	// RVA: 0x7251D00
	public object .ctor(object innerStream, object leaveInnerStreamOpen, object userCertificateValidationCallback) { }

	// RVA: 0x7251D08
	public object .ctor(object innerStream, object leaveInnerStreamOpen, object userCertificateValidationCallback, object userCertificateSelectionCallback) { }

	// RVA: 0x72520D8
	internal object .ctor(object innerStream, object leaveInnerStreamOpen, object provider, object settings) { }

	// RVA: 0x7251E24
	private object SetAndVerifyValidationCallback(object callback) { }

	// RVA: 0x7251F18
	private object SetAndVerifySelectionCallback(object callback) { }

	// RVA: 0x7252230
	public virtual object AuthenticateAsClient(object targetHost, object clientCertificates, object enabledSslProtocols, object checkCertificateRevocation) { }

	// RVA: 0x7252294
	public virtual object BeginAuthenticateAsClient(object targetHost, object clientCertificates, object enabledSslProtocols, object checkCertificateRevocation, object asyncCallback, object asyncState) { }

	// RVA: 0x7252318
	public virtual object EndAuthenticateAsClient(object asyncResult) { }

	// RVA: 0x7252324
	public virtual object AuthenticateAsClientAsync(object targetHost, object clientCertificates, object enabledSslProtocols, object checkCertificateRevocation) { }

	// RVA: 0x7252388
	public override object get_IsAuthenticated() { }

	// RVA: 0x7252414
	public virtual object get_LocalCertificate() { }

	// RVA: 0x7252478
	public override object get_CanSeek() { }

	// RVA: 0x7252480
	public override object get_CanRead() { }

	// RVA: 0x72524D0
	public override object get_CanTimeout() { }

	// RVA: 0x725251C
	public override object get_CanWrite() { }

	// RVA: 0x725256C
	public override object get_ReadTimeout() { }

	// RVA: 0x72525F8
	public override object set_ReadTimeout(object value) { }

	// RVA: 0x725268C
	public override object get_WriteTimeout() { }

	// RVA: 0x7252718
	public override object set_WriteTimeout(object value) { }

	// RVA: 0x72527AC
	public override object get_Length() { }

	// RVA: 0x7252834
	public override object get_Position() { }

	// RVA: 0x72528C0
	public override object set_Position(object value) { }

	// RVA: 0x725291C
	public override object SetLength(object value) { }

	// RVA: 0x72529B0
	public override object Seek(object offset, object origin) { }

	// RVA: 0x7252A0C
	public override object FlushAsync(object cancellationToken) { }

	// RVA: 0x7252A64
	public override object Flush() { }

	// RVA: 0x7251BC0
	private object CheckDisposed() { }

	// RVA: 0x7252AB4
	protected override object Dispose(object disposing) { }

	// RVA: 0x7252BA8
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x7252C54
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x7252D00
	public override object ReadAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x7252DBC
	public override object WriteAsync(object buffer, object offset, object count, object cancellationToken) { }

	// RVA: 0x7252E78
	public override object BeginRead(object buffer, object offset, object count, object callback, object state) { }

	// RVA: 0x7252EFC
	public override object EndRead(object asyncResult) { }

	// RVA: 0x7252F50
	public override object BeginWrite(object buffer, object offset, object count, object callback, object state) { }

	// RVA: 0x7252FD4
	public override object EndWrite(object asyncResult) { }

}

// Namespace: System.ComponentModel
public class DefaultValueAttribute
{

	// Fields
	private object _value; // 0x8

	// Properties
	public virtual object Value { get; }

	// Methods

	// RVA: 0x7253020
	public object .ctor(object value) { }

	// RVA: 0x7253098
	public object .ctor(object value) { }

	// RVA: 0x7253110
	public object .ctor(object value) { }

	// RVA: 0x7253188
	public object .ctor(object value) { }

	// RVA: 0x72531B4
	public object .ctor(object value) { }

	// RVA: 0x72531E0
	public virtual object get_Value() { }

	// RVA: 0x72531E8
	public override object Equals(object obj) { }

	// RVA: 0x7253380
	public override object GetHashCode() { }

}

// Namespace: System.ComponentModel
public sealed class EditorBrowsableAttribute
{

	// Fields
	private object browsableState; // 0x8

	// Methods

	// RVA: 0x7253388
	public object .ctor(object state) { }

	// RVA: 0x72533B4
	public override object Equals(object obj) { }

	// RVA: 0x7253458
	public override object GetHashCode() { }

}

// Namespace: System.ComponentModel
public enum EditorBrowsableState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Always;
	public const object Never;
	public const object Advanced;
}

// Namespace: System.ComponentModel
public sealed class BrowsableAttribute
{

	// Fields
	public static readonly object Yes; // 0x0
	public static readonly object No; // 0x8
	public static readonly object Default; // 0x10
	private readonly object <Browsable>k__BackingField; // 0x8

	// Properties
	public object Browsable { get; }

	// Methods

	// RVA: 0x7253460
	public object .ctor(object browsable) { }

	// RVA: 0x725348C
	public object get_Browsable() { }

	// RVA: 0x7253494
	public override object Equals(object obj) { }

	// RVA: 0x725358C
	public override object GetHashCode() { }

	// RVA: 0x7253604
	public override object IsDefaultAttribute() { }

	// RVA: 0x72536B8
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class ComponentCollection
{

	// Properties
	public virtual object Item { get; }

	// Methods

	// RVA: 0x7253744
	public virtual object get_Item(object name) { }

}

// Namespace: System.ComponentModel
public class DescriptionAttribute
{

	// Fields
	public static readonly object Default; // 0x0
	private object <DescriptionValue>k__BackingField; // 0x8

	// Properties
	public virtual object Description { get; }
	protected object DescriptionValue { get; set; }

	// Methods

	// RVA: 0x7253DA8
	public object .ctor() { }

	// RVA: 0x7253E10
	public object .ctor(object description) { }

	// RVA: 0x7253E3C
	public virtual object get_Description() { }

	// RVA: 0x7253E44
	protected object get_DescriptionValue() { }

	// RVA: 0x7253E4C
	protected object set_DescriptionValue(object value) { }

	// RVA: 0x7253E54
	public override object Equals(object obj) { }

	// RVA: 0x7253F58
	public override object GetHashCode() { }

	// RVA: 0x7253FD4
	public override object IsDefaultAttribute() { }

	// RVA: 0x7254088
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public sealed class DesignOnlyAttribute
{

	// Fields
	private readonly object <IsDesignOnly>k__BackingField; // 0x8
	public static readonly object Yes; // 0x0
	public static readonly object No; // 0x8
	public static readonly object Default; // 0x10

	// Properties
	public object IsDesignOnly { get; }

	// Methods

	// RVA: 0x725412C
	public object .ctor(object isDesignOnly) { }

	// RVA: 0x7254158
	public object get_IsDesignOnly() { }

	// RVA: 0x7254160
	public override object Equals(object obj) { }

	// RVA: 0x7254258
	public override object GetHashCode() { }

	// RVA: 0x72542D0
	public override object IsDefaultAttribute() { }

	// RVA: 0x7254374
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public sealed class DesignerCategoryAttribute
{

	// Fields
	public static readonly object Component; // 0x0
	public static readonly object Default; // 0x8
	public static readonly object Form; // 0x10
	public static readonly object Generic; // 0x18
	private readonly object <Category>k__BackingField; // 0x8

	// Properties
	public object Category { get; }
	public override object TypeId { get; }

	// Methods

	// RVA: 0x72543FC
	public object .ctor() { }

	// RVA: 0x7254464
	public object .ctor(object category) { }

	// RVA: 0x7254490
	public object get_Category() { }

	// RVA: 0x7254498
	public override object Equals(object obj) { }

	// RVA: 0x7254538
	public override object GetHashCode() { }

	// RVA: 0x7254584
	public override object IsDefaultAttribute() { }

	// RVA: 0x7254638
	public override object get_TypeId() { }

	// RVA: 0x72546A4
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public enum DesignerSerializationVisibility
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Hidden;
	public const object Visible;
	public const object Content;
}

// Namespace: System.ComponentModel
public sealed class DesignerSerializationVisibilityAttribute
{

	// Fields
	public static readonly object Content; // 0x0
	public static readonly object Hidden; // 0x8
	public static readonly object Visible; // 0x10
	public static readonly object Default; // 0x18
	private readonly object <Visibility>k__BackingField; // 0x8

	// Properties
	public object Visibility { get; }

	// Methods

	// RVA: 0x72547F8
	public object .ctor(object visibility) { }

	// RVA: 0x7254824
	public object get_Visibility() { }

	// RVA: 0x725482C
	public override object Equals(object obj) { }

	// RVA: 0x7254918
	public override object GetHashCode() { }

	// RVA: 0x7254920
	public override object IsDefaultAttribute() { }

	// RVA: 0x72549D4
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class DisplayNameAttribute
{

	// Fields
	public static readonly object Default; // 0x0
	private object <DisplayNameValue>k__BackingField; // 0x8

	// Properties
	public virtual object DisplayName { get; }
	protected object DisplayNameValue { get; set; }

	// Methods

	// RVA: 0x7254A80
	public object .ctor() { }

	// RVA: 0x7254AE8
	public object .ctor(object displayName) { }

	// RVA: 0x7254B14
	public virtual object get_DisplayName() { }

	// RVA: 0x7254B1C
	protected object get_DisplayNameValue() { }

	// RVA: 0x7254B24
	protected object set_DisplayNameValue(object value) { }

	// RVA: 0x7254B2C
	public override object Equals(object obj) { }

	// RVA: 0x7254C30
	public override object GetHashCode() { }

	// RVA: 0x7254CAC
	public override object IsDefaultAttribute() { }

	// RVA: 0x7254D60
	private static object .cctor() { }

}

// Namespace: 
private sealed class ListEntry
{

	// Fields
	internal object _next; // 0x8
	internal object _key; // 0x10
	internal object _handler; // 0x18
}

// Namespace: System.ComponentModel
public sealed class EventHandlerList
{

	// Fields
	private object _head; // 0x8
	private object _parent; // 0x10

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x7254E04
	public object get_Item(object key) { }

	// RVA: 0x7254E60
	private object Find(object key) { }

}

// Namespace: System.ComponentModel
public interface IContainer
{

	// Properties
	public abstract object Components { get; }

	// Methods

	// RVA: -1
	public abstract object get_Components() { }

	// RVA: -1
	public abstract object Remove(object component) { }

}

// Namespace: System.ComponentModel
public interface ISite
{

	// Properties
	public abstract object Container { get; }
	public abstract object DesignMode { get; }
	public abstract object Name { get; }

	// Methods

	// RVA: -1
	public abstract object get_Container() { }

	// RVA: -1
	public abstract object get_DesignMode() { }

	// RVA: -1
	public abstract object get_Name() { }

}

// Namespace: System.ComponentModel
public interface ISynchronizeInvoke
{

	// Properties
	public abstract object InvokeRequired { get; }

	// Methods

	// RVA: -1
	public abstract object get_InvokeRequired() { }

	// RVA: -1
	public abstract object BeginInvoke(object method, object args) { }

}

// Namespace: System.ComponentModel
public class InvalidEnumArgumentException
{

	// Methods

	// RVA: 0x7254E78
	public object .ctor() { }

	// RVA: 0x7254E84
	public object .ctor(object message) { }

	// RVA: 0x7254E8C
	protected object .ctor(object info, object context) { }

}

// Namespace: System.ComponentModel
public sealed class ReadOnlyAttribute
{

	// Fields
	public static readonly object Yes; // 0x0
	public static readonly object No; // 0x8
	public static readonly object Default; // 0x10
	private readonly object <IsReadOnly>k__BackingField; // 0x8

	// Properties
	public object IsReadOnly { get; }

	// Methods

	// RVA: 0x7254E94
	public object .ctor(object isReadOnly) { }

	// RVA: 0x7254EC0
	public object get_IsReadOnly() { }

	// RVA: 0x7254EC8
	public override object Equals(object value) { }

	// RVA: 0x7254FC0
	public override object GetHashCode() { }

	// RVA: 0x7254FC8
	public override object IsDefaultAttribute() { }

	// RVA: 0x725506C
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public sealed class AmbientValueAttribute
{

	// Fields
	private readonly object <Value>k__BackingField; // 0x8

	// Properties
	public object Value { get; }

	// Methods

	// RVA: 0x72550F4
	public object get_Value() { }

}

// Namespace: 
private class ArrayPropertyDescriptor
{

	// Fields
	private readonly object _index; // 0x90

	// Methods

	// RVA: 0x7255634
	public object .ctor(object arrayType, object elementType, object index) { }

	// RVA: 0x7255704
	public override object GetValue(object instance) { }

	// RVA: 0x72557BC
	public override object SetValue(object instance, object value) { }

}

// Namespace: System.ComponentModel
public class ArrayConverter
{

	// Methods

	// RVA: 0x72550FC
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x7255318
	public override object GetProperties(object context, object value, object attributes) { }

	// RVA: 0x72556F4
	public override object GetPropertiesSupported(object context) { }

	// RVA: 0x72556FC
	public object .ctor() { }

}

// Namespace: 
private struct AttributeEntry
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object index; // 0x0
}

// Namespace: System.ComponentModel
public class AttributeCollection
{

	// Fields
	public static readonly object Empty; // 0x0
	private static object s_defaultAttributes; // 0x8
	private readonly object _attributes; // 0x8
	private static readonly object s_internalSyncObject; // 0x10
	private object _foundAttributeTypes; // 0x10
	private object _index; // 0x18

	// Properties
	protected virtual object Attributes { get; }
	public object Count { get; }
	public virtual object Item { get; }
	public virtual object Item { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	private object System.Collections.ICollection.Count { get; }

	// Methods

	// RVA: 0x7255908
	public object .ctor(object attributes) { }

	// RVA: 0x7255AB4
	protected virtual object get_Attributes() { }

	// RVA: 0x7255ABC
	public object get_Count() { }

	// RVA: 0x7255B14
	public virtual object get_Item(object index) { }

	// RVA: 0x7255B84
	public virtual object get_Item(object attributeType) { }

	// RVA: 0x7256B50
	public object Contains(object attribute) { }

	// RVA: 0x72563F8
	protected object GetDefaultAttribute(object attributeType) { }

	// RVA: 0x7256C00
	public object GetEnumerator() { }

	// RVA: 0x7256C58
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x7256C60
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x7256C68
	private object System.Collections.ICollection.get_Count() { }

	// RVA: 0x7256CC0
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x7256D18
	public object CopyTo(object array, object index) { }

	// RVA: 0x7256DB8
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class AttributeProviderAttribute
{

	// Fields
	private readonly object <TypeName>k__BackingField; // 0x8
	private readonly object <PropertyName>k__BackingField; // 0x10

	// Properties
	public object TypeName { get; }
	public object PropertyName { get; }

	// Methods

	// RVA: 0x7256E90
	public object get_TypeName() { }

	// RVA: 0x7256E98
	public object get_PropertyName() { }

}

// Namespace: System.ComponentModel
public abstract class BaseNumberConverter
{

	// Properties
	internal virtual object AllowHex { get; }
	internal abstract object TargetType { get; }

	// Methods

	// RVA: 0x7256EA0
	internal object .ctor() { }

	// RVA: 0x7256EA8
	internal virtual object get_AllowHex() { }

	// RVA: -1
	internal abstract object get_TargetType() { }

	// RVA: -1
	internal abstract object FromString(object value, object radix) { }

	// RVA: -1
	internal abstract object FromString(object value, object formatInfo) { }

	// RVA: -1
	internal abstract object ToString(object value, object formatInfo) { }

	// RVA: 0x7256EB0
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x7256F7C
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x725743C
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x72577C0
	public override object CanConvertTo(object context, object destinationType) { }

}

// Namespace: System.ComponentModel
public class BooleanConverter
{

	// Fields
	private static object s_values; // 0x0

	// Methods

	// RVA: 0x7257810
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x72578DC
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x7257AE4
	public override object GetStandardValues(object context) { }

	// RVA: 0x7257C70
	public override object GetStandardValuesExclusive(object context) { }

	// RVA: 0x7257C78
	public override object GetStandardValuesSupported(object context) { }

	// RVA: 0x7257C80
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class ByteConverter
{

	// Properties
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x7257C88
	internal override object get_TargetType() { }

	// RVA: 0x7257D28
	internal override object FromString(object value, object radix) { }

	// RVA: 0x7257DC4
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x7257E40
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x7257F00
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class CharConverter
{

	// Methods

	// RVA: 0x7257F08
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x7257FD4
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x7258120
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x72582C4
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public enum CollectionChangeAction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object Remove;
	public const object Refresh;
}

// Namespace: System.ComponentModel
public class CollectionChangeEventArgs
{

	// Fields
	private readonly object <Action>k__BackingField; // 0x8
	private readonly object <Element>k__BackingField; // 0x10

	// Properties
	public virtual object Action { get; }
	public virtual object Element { get; }

	// Methods

	// RVA: 0x72582CC
	public object .ctor(object action, object element) { }

	// RVA: 0x725834C
	public virtual object get_Action() { }

	// RVA: 0x7258354
	public virtual object get_Element() { }

}

// Namespace: System.ComponentModel
public sealed class CollectionChangeEventHandler
{

	// Methods

	// RVA: 0x7258660
	public object .ctor(object object, object method) { }

	// RVA: 0x725876C
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: 
private class CultureComparer
{

	// Fields
	private object _converter; // 0x8

	// Methods

	// RVA: 0x7259CD4
	public object .ctor(object cultureConverter) { }

	// RVA: 0x7259D18
	public object Compare(object item1, object item2) { }

}

// Namespace: 
private static class CultureInfoMapper
{

	// Fields
	private static readonly object s_cultureInfoNameMap; // 0x0

	// Methods

	// RVA: 0x7259F38
	private static object CreateMap() { }

	// RVA: 0x72594D0
	public static object GetCultureInfoName(object cultureInfoDisplayName) { }

	// RVA: 0x725E024
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class CultureInfoConverter
{

	// Fields
	private object _values; // 0x8

	// Properties
	private object DefaultCultureString { get; }

	// Methods

	// RVA: 0x7258780
	private object get_DefaultCultureString() { }

	// RVA: 0x72587C4
	protected virtual object GetCultureName(object culture) { }

	// RVA: 0x7258810
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x72588DC
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x72589A8
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x72595A0
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x7259AA8
	public override object GetStandardValues(object context) { }

	// RVA: 0x7259D00
	public override object GetStandardValuesExclusive(object context) { }

	// RVA: 0x7259D08
	public override object GetStandardValuesSupported(object context) { }

	// RVA: 0x7259D10
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public abstract class CustomTypeDescriptor
{

	// Fields
	private readonly object _parent; // 0x8

	// Methods

	// RVA: 0x711BDB4
	protected object .ctor() { }

	// RVA: 0x711BDBC
	protected object .ctor(object parent) { }

	// RVA: 0x711BDE8
	public virtual object GetAttributes() { }

	// RVA: 0x711BF14
	public virtual object GetClassName() { }

	// RVA: 0x711C000
	public virtual object GetComponentName() { }

	// RVA: 0x711C0EC
	public virtual object GetConverter() { }

	// RVA: 0x711C200
	public virtual object GetDefaultEvent() { }

	// RVA: 0x711C2EC
	public virtual object GetDefaultProperty() { }

	// RVA: 0x711C3D8
	public virtual object GetEditor(object editorBaseType) { }

	// RVA: 0x711C4B8
	public virtual object GetEvents() { }

	// RVA: 0x711C5E8
	public virtual object GetEvents(object attributes) { }

	// RVA: 0x711C70C
	public virtual object GetProperties() { }

	// RVA: 0x711C83C
	public virtual object GetProperties(object attributes) { }

	// RVA: 0x711C960
	public virtual object GetPropertyOwner(object pd) { }

}

// Namespace: System.ComponentModel
public class DateTimeConverter
{

	// Methods

	// RVA: 0x711CA40
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x711CB0C
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x711CBD8
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x711CF6C
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x711D3E4
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class DecimalConverter
{

	// Properties
	internal override object AllowHex { get; }
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x711D3EC
	internal override object get_AllowHex() { }

	// RVA: 0x711D3F4
	internal override object get_TargetType() { }

	// RVA: 0x711D494
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x711D560
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x711D8D0
	internal override object FromString(object value, object radix) { }

	// RVA: 0x711D9C4
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x711DA7C
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x711DB78
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public sealed class DefaultEventAttribute
{

	// Fields
	private readonly object <Name>k__BackingField; // 0x8
	public static readonly object Default; // 0x0

	// Properties
	public object Name { get; }

	// Methods

	// RVA: 0x711DB80
	public object .ctor(object name) { }

	// RVA: 0x711DBAC
	public object get_Name() { }

	// RVA: 0x711DBB4
	public override object Equals(object obj) { }

	// RVA: 0x711DC38
	public override object GetHashCode() { }

	// RVA: 0x711DC40
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public sealed class DefaultPropertyAttribute
{

	// Fields
	private readonly object <Name>k__BackingField; // 0x8
	public static readonly object Default; // 0x0

	// Properties
	public object Name { get; }

	// Methods

	// RVA: 0x711DCA4
	public object .ctor(object name) { }

	// RVA: 0x711DCD0
	public object get_Name() { }

	// RVA: 0x711DCD8
	public override object Equals(object obj) { }

	// RVA: 0x711DD5C
	public override object GetHashCode() { }

	// RVA: 0x711DD64
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
internal sealed class DelegatingTypeDescriptionProvider
{

	// Fields
	private readonly object _type; // 0x18

	// Properties
	internal object Provider { get; }

	// Methods

	// RVA: 0x711DDC8
	internal object .ctor(object type) { }

	// RVA: 0x711DDFC
	internal object get_Provider() { }

	// RVA: 0x711DE8C
	public override object CreateInstance(object provider, object objectType, object argTypes, object args) { }

	// RVA: 0x711DF80
	public override object GetCache(object instance) { }

	// RVA: 0x711E04C
	public override object GetFullComponentName(object component) { }

	// RVA: 0x711E118
	public override object GetExtendedTypeDescriptor(object instance) { }

	// RVA: 0x711E1E4
	protected internal override object GetExtenderProviders(object instance) { }

	// RVA: 0x711E2B0
	public override object GetReflectionType(object objectType, object instance) { }

	// RVA: 0x711E38C
	public override object GetTypeDescriptor(object objectType, object instance) { }

}

// Namespace: System.ComponentModel
public class ToolboxItemAttribute
{

	// Fields
	private object _toolboxItemTypeName; // 0x8
	public static readonly object Default; // 0x0
	public static readonly object None; // 0x8

	// Properties
	public object ToolboxItemTypeName { get; }

	// Methods

	// RVA: 0x711E468
	public override object IsDefaultAttribute() { }

	// RVA: 0x711E51C
	public object .ctor(object defaultType) { }

	// RVA: 0x711E5A4
	public object .ctor(object toolboxItemTypeName) { }

	// RVA: 0x711E660
	public object get_ToolboxItemTypeName() { }

	// RVA: 0x711E6CC
	public override object Equals(object obj) { }

	// RVA: 0x711E7FC
	public override object GetHashCode() { }

	// RVA: 0x711E84C
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public sealed class DesignTimeVisibleAttribute
{

	// Fields
	private readonly object <Visible>k__BackingField; // 0x8
	public static readonly object Yes; // 0x0
	public static readonly object No; // 0x8
	public static readonly object Default; // 0x10

	// Properties
	public object Visible { get; }

	// Methods

	// RVA: 0x711E9A0
	public object .ctor(object visible) { }

	// RVA: 0x711E9CC
	public object get_Visible() { }

	// RVA: 0x711E9D4
	public override object Equals(object obj) { }

	// RVA: 0x711EA78
	public override object GetHashCode() { }

	// RVA: 0x711EB60
	public override object IsDefaultAttribute() { }

	// RVA: 0x711EC04
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class DoubleConverter
{

	// Properties
	internal override object AllowHex { get; }
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x711EC90
	internal override object get_AllowHex() { }

	// RVA: 0x711EC98
	internal override object get_TargetType() { }

	// RVA: 0x711ED38
	internal override object FromString(object value, object radix) { }

	// RVA: 0x711EE00
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x711EE7C
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x711EF3C
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public sealed class EditorAttribute
{

	// Fields
	private readonly object <EditorBaseTypeName>k__BackingField; // 0x8
	private readonly object <EditorTypeName>k__BackingField; // 0x10

	// Properties
	public object EditorBaseTypeName { get; }
	public object EditorTypeName { get; }

	// Methods

	// RVA: 0x711EF44
	public object get_EditorBaseTypeName() { }

	// RVA: 0x711EF4C
	public object get_EditorTypeName() { }

}

// Namespace: System.ComponentModel
public abstract class EventDescriptor
{

	// Properties
	public abstract object EventType { get; }

	// Methods

	// RVA: 0x711EF54
	protected object .ctor(object name, object attrs) { }

	// RVA: 0x711F120
	protected object .ctor(object descr, object attrs) { }

	// RVA: -1
	public abstract object get_EventType() { }

}

// Namespace: 
private class ArraySubsetEnumerator
{

	// Fields
	private readonly object _array; // 0x8
	private readonly object _total; // 0x10
	private object _current; // 0x14

	// Properties
	public object Current { get; }

	// Methods

	// RVA: 0x71206D4
	public object .ctor(object array, object count) { }

	// RVA: 0x7120F08
	public object MoveNext() { }

	// RVA: 0x7120F2C
	public object Reset() { }

	// RVA: 0x7120F38
	public object get_Current() { }

}

// Namespace: System.ComponentModel
public class EventDescriptorCollection
{

	// Fields
	private object _events; // 0x8
	private object _namedSort; // 0x10
	private readonly object _comparer; // 0x18
	private object _eventsOwned; // 0x20
	private object _needSort; // 0x21
	private readonly object _readOnly; // 0x22
	public static readonly object Empty; // 0x0
	private object <Count>k__BackingField; // 0x24

	// Properties
	public object Count { get; set; }
	public virtual object Item { get; }
	public virtual object Item { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	private object System.Collections.ICollection.Count { get; }
	private object System.Collections.IList.Item { get; set; }
	private object System.Collections.IList.IsReadOnly { get; }
	private object System.Collections.IList.IsFixedSize { get; }

	// Methods

	// RVA: 0x711F6A4
	public object .ctor(object events) { }

	// RVA: 0x711F7DC
	public object .ctor(object events, object readOnly) { }

	// RVA: 0x711F804
	public object get_Count() { }

	// RVA: 0x711F80C
	private object set_Count(object value) { }

	// RVA: 0x711F814
	public virtual object get_Item(object index) { }

	// RVA: 0x711F9E4
	public virtual object get_Item(object name) { }

	// RVA: 0x711FA34
	public object Add(object value) { }

	// RVA: 0x711FCA8
	public object Clear() { }

	// RVA: 0x711FCFC
	public object Contains(object value) { }

	// RVA: 0x711FDD0
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x711F934
	private object EnsureEventsOwned() { }

	// RVA: 0x711FB0C
	private object EnsureSize(object sizeNeeded) { }

	// RVA: 0x7120208
	public virtual object Find(object name, object ignoreCase) { }

	// RVA: 0x711FD6C
	public object IndexOf(object value) { }

	// RVA: 0x71203A4
	public object Insert(object index, object value) { }

	// RVA: 0x712049C
	public object Remove(object value) { }

	// RVA: 0x7120564
	public object RemoveAt(object index) { }

	// RVA: 0x7120628
	public object GetEnumerator() { }

	// RVA: 0x711FEA0
	protected object InternalSort(object names) { }

	// RVA: 0x7120714
	protected object InternalSort(object sorter) { }

	// RVA: 0x71207B4
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x71207BC
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x71207C4
	private object System.Collections.ICollection.get_Count() { }

	// RVA: 0x71207CC
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x7120878
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: 0x71208C4
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: 0x7120AD4
	private object System.Collections.IList.Add(object value) { }

	// RVA: 0x7120B6C
	private object System.Collections.IList.Contains(object value) { }

	// RVA: 0x7120C3C
	private object System.Collections.IList.Clear() { }

	// RVA: 0x7120C90
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: 0x7120D54
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: 0x7120DF4
	private object System.Collections.IList.Remove(object value) { }

	// RVA: 0x7120E8C
	private object System.Collections.IList.RemoveAt(object index) { }

	// RVA: 0x7120E90
	private object System.Collections.IList.get_IsReadOnly() { }

	// RVA: 0x7120E98
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: 0x7120EA0
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class ExpandableObjectConverter
{

	// Methods

	// RVA: 0x7120FA8
	public object .ctor() { }

	// RVA: 0x7120FB0
	public override object GetProperties(object context, object value, object attributes) { }

	// RVA: 0x712101C
	public override object GetPropertiesSupported(object context) { }

}

// Namespace: System.ComponentModel
internal sealed class ExtendedPropertyDescriptor
{

	// Fields
	private readonly object _extenderInfo; // 0x80
	private readonly object _provider; // 0x88

	// Properties
	public override object ComponentType { get; }
	public override object IsReadOnly { get; }
	public override object PropertyType { get; }
	public override object DisplayName { get; }

	// Methods

	// RVA: 0x7121024
	public object .ctor(object extenderInfo, object receiverType, object provider, object attributes) { }

	// RVA: 0x712141C
	public object .ctor(object extender, object attributes) { }

	// RVA: 0x7121590
	public override object get_ComponentType() { }

	// RVA: 0x71215E0
	public override object get_IsReadOnly() { }

	// RVA: 0x712172C
	public override object get_PropertyType() { }

	// RVA: 0x71217C0
	public override object get_DisplayName() { }

	// RVA: 0x7121CEC
	public override object GetValue(object comp) { }

	// RVA: 0x7121E80
	public override object SetValue(object component, object value) { }

	// RVA: 0x71223CC
	public override object ShouldSerializeValue(object comp) { }

}

// Namespace: System.ComponentModel
public sealed class ExtenderProvidedPropertyAttribute
{

	// Fields
	private object <ExtenderProperty>k__BackingField; // 0x8
	private object <Provider>k__BackingField; // 0x10
	private object <ReceiverType>k__BackingField; // 0x18

	// Properties
	public object ExtenderProperty { get; set; }
	public object Provider { get; set; }
	public object ReceiverType { get; set; }

	// Methods

	// RVA: 0x7121390
	internal static object Create(object extenderProperty, object receiverType, object provider) { }

	// RVA: 0x7122924
	public object .ctor() { }

	// RVA: 0x712292C
	public object get_ExtenderProperty() { }

	// RVA: 0x7122934
	private object set_ExtenderProperty(object value) { }

	// RVA: 0x712293C
	public object get_Provider() { }

	// RVA: 0x7122944
	private object set_Provider(object value) { }

	// RVA: 0x712294C
	public object get_ReceiverType() { }

	// RVA: 0x7122954
	private object set_ReceiverType(object value) { }

	// RVA: 0x712295C
	public override object Equals(object obj) { }

	// RVA: 0x7122ACC
	public override object GetHashCode() { }

	// RVA: 0x7122AD4
	public override object IsDefaultAttribute() { }

}

// Namespace: System.ComponentModel
public class GuidConverter
{

	// Methods

	// RVA: 0x7122B40
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x7122C0C
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x7122CD8
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x7122DCC
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x712314C
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public interface IBindingList
{
}

// Namespace: System.ComponentModel
public interface IComNativeDescriptorHandler
{

	// Methods

	// RVA: -1
	public abstract object GetAttributes(object component) { }

	// RVA: -1
	public abstract object GetClassName(object component) { }

	// RVA: -1
	public abstract object GetConverter(object component) { }

	// RVA: -1
	public abstract object GetDefaultEvent(object component) { }

	// RVA: -1
	public abstract object GetDefaultProperty(object component) { }

	// RVA: -1
	public abstract object GetEditor(object component, object baseEditorType) { }

	// RVA: -1
	public abstract object GetEvents(object component) { }

	// RVA: -1
	public abstract object GetEvents(object component, object attributes) { }

	// RVA: -1
	public abstract object GetProperties(object component, object attributes) { }

}

// Namespace: System.ComponentModel
public interface ICustomTypeDescriptor
{

	// Methods

	// RVA: -1
	public abstract object GetAttributes() { }

	// RVA: -1
	public abstract object GetClassName() { }

	// RVA: -1
	public abstract object GetComponentName() { }

	// RVA: -1
	public abstract object GetConverter() { }

	// RVA: -1
	public abstract object GetDefaultEvent() { }

	// RVA: -1
	public abstract object GetDefaultProperty() { }

	// RVA: -1
	public abstract object GetEditor(object editorBaseType) { }

	// RVA: -1
	public abstract object GetEvents() { }

	// RVA: -1
	public abstract object GetEvents(object attributes) { }

	// RVA: -1
	public abstract object GetProperties() { }

	// RVA: -1
	public abstract object GetProperties(object attributes) { }

	// RVA: -1
	public abstract object GetPropertyOwner(object pd) { }

}

// Namespace: System.ComponentModel
public interface IExtenderProvider
{

	// Methods

	// RVA: -1
	public abstract object CanExtend(object extendee) { }

}

// Namespace: System.ComponentModel
public interface INestedSite
{

	// Properties
	public abstract object FullName { get; }

	// Methods

	// RVA: -1
	public abstract object get_FullName() { }

}

// Namespace: System.ComponentModel
public interface ITypeDescriptorContext
{

	// Properties
	public abstract object Container { get; }

	// Methods

	// RVA: -1
	public abstract object get_Container() { }

}

// Namespace: System.ComponentModel
public class Int16Converter
{

	// Properties
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x7123154
	internal override object get_TargetType() { }

	// RVA: 0x71231F4
	internal override object FromString(object value, object radix) { }

	// RVA: 0x7123290
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x712330C
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x71233CC
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class Int32Converter
{

	// Properties
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x71233D4
	internal override object get_TargetType() { }

	// RVA: 0x7123474
	internal override object FromString(object value, object radix) { }

	// RVA: 0x7123510
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x712358C
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x712364C
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class Int64Converter
{

	// Properties
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x7123654
	internal override object get_TargetType() { }

	// RVA: 0x71236F4
	internal override object FromString(object value, object radix) { }

	// RVA: 0x7123790
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x712380C
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x71238CC
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public sealed class ListBindableAttribute
{

	// Fields
	public static readonly object Yes; // 0x0
	public static readonly object No; // 0x8
	public static readonly object Default; // 0x10
	private object _isDefault; // 0x8
	private readonly object <ListBindable>k__BackingField; // 0x9

	// Properties
	public object ListBindable { get; }

	// Methods

	// RVA: 0x71238D4
	public object .ctor(object listBindable) { }

	// RVA: 0x7123900
	public object get_ListBindable() { }

	// RVA: 0x7123908
	public override object Equals(object obj) { }

	// RVA: 0x71239AC
	public override object GetHashCode() { }

	// RVA: 0x71239B4
	public override object IsDefaultAttribute() { }

	// RVA: 0x7123A90
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class ListChangedEventArgs
{

	// Fields
	private readonly object <ListChangedType>k__BackingField; // 0x8
	private readonly object <NewIndex>k__BackingField; // 0xC
	private readonly object <OldIndex>k__BackingField; // 0x10
	private readonly object <PropertyDescriptor>k__BackingField; // 0x18

	// Properties
	public object ListChangedType { get; }
	public object NewIndex { get; }
	public object OldIndex { get; }

	// Methods

	// RVA: 0x7123B1C
	public object .ctor(object listChangedType, object newIndex) { }

	// RVA: 0x7123C24
	public object .ctor(object listChangedType, object newIndex, object propDesc) { }

	// RVA: 0x7123CAC
	public object .ctor(object listChangedType, object propDesc) { }

	// RVA: 0x7123BA0
	public object .ctor(object listChangedType, object newIndex, object oldIndex) { }

	// RVA: 0x7123D2C
	public object get_ListChangedType() { }

	// RVA: 0x7123D34
	public object get_NewIndex() { }

	// RVA: 0x7123D3C
	public object get_OldIndex() { }

}

// Namespace: System.ComponentModel
public sealed class ListChangedEventHandler
{

	// Methods

	// RVA: 0x7124048
	public object .ctor(object object, object method) { }

	// RVA: 0x7124154
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.ComponentModel
public enum ListChangedType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Reset;
	public const object ItemAdded;
	public const object ItemDeleted;
	public const object ItemMoved;
	public const object ItemChanged;
	public const object PropertyDescriptorAdded;
	public const object PropertyDescriptorDeleted;
	public const object PropertyDescriptorChanged;
}

// Namespace: System.ComponentModel
public class MarshalByValueComponent
{

	// Fields
	private static readonly object s_eventDisposed; // 0x0
	private object _site; // 0x8
	private object _events; // 0x10

	// Properties
	public virtual object Site { get; }

	// Methods

	// RVA: 0x7124168
	public object .ctor() { }

	// RVA: 0x7124170
	protected override object Finalize() { }

	// RVA: 0x7124228
	public virtual object get_Site() { }

	// RVA: 0x7124230
	public object Dispose() { }

	// RVA: 0x71242C8
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x71245A8
	public virtual object GetService(object service) { }

	// RVA: 0x7124684
	public override object ToString() { }

	// RVA: 0x7124830
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class NullableConverter
{

	// Fields
	private readonly object <NullableType>k__BackingField; // 0x8
	private readonly object <UnderlyingType>k__BackingField; // 0x10
	private readonly object <UnderlyingTypeConverter>k__BackingField; // 0x18

	// Properties
	public object NullableType { get; }
	public object UnderlyingType { get; }
	public object UnderlyingTypeConverter { get; }

	// Methods

	// RVA: 0x71248AC
	public object .ctor(object type) { }

	// RVA: 0x71249DC
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x7124AF0
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x7124C64
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x7124D78
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x7124FF4
	public override object CreateInstance(object context, object propertyValues) { }

	// RVA: 0x7125060
	public override object GetCreateInstanceSupported(object context) { }

	// RVA: 0x71250B8
	public override object GetProperties(object context, object value, object attributes) { }

	// RVA: 0x712512C
	public override object GetPropertiesSupported(object context) { }

	// RVA: 0x7125184
	public override object GetStandardValues(object context) { }

	// RVA: 0x71255B4
	public override object GetStandardValuesExclusive(object context) { }

	// RVA: 0x7125610
	public override object GetStandardValuesSupported(object context) { }

	// RVA: 0x712566C
	public override object IsValid(object context, object value) { }

	// RVA: 0x71256F4
	public object get_NullableType() { }

	// RVA: 0x71256FC
	public object get_UnderlyingType() { }

	// RVA: 0x7125704
	public object get_UnderlyingTypeConverter() { }

}

// Namespace: System.ComponentModel
public abstract class PropertyDescriptor
{

	// Fields
	private object _converter; // 0x58
	private object _valueChangedHandlers; // 0x60
	private object _editors; // 0x68
	private object _editorTypes; // 0x70
	private object _editorCount; // 0x78

	// Properties
	public abstract object ComponentType { get; }
	public virtual object Converter { get; }
	public abstract object IsReadOnly { get; }
	public abstract object PropertyType { get; }

	// Methods

	// RVA: 0x712570C
	protected object .ctor(object name, object attrs) { }

	// RVA: 0x712138C
	protected object .ctor(object descr, object attrs) { }

	// RVA: -1
	public abstract object get_ComponentType() { }

	// RVA: 0x7125710
	public virtual object get_Converter() { }

	// RVA: -1
	public abstract object get_IsReadOnly() { }

	// RVA: -1
	public abstract object get_PropertyType() { }

	// RVA: 0x7125FE4
	public override object Equals(object obj) { }

	// RVA: 0x7125D80
	protected object CreateInstance(object type) { }

	// RVA: 0x7126278
	protected override object FillAttributes(object attributeList) { }

	// RVA: 0x71263A8
	public override object GetHashCode() { }

	// RVA: 0x7126454
	protected override object GetInvocationTarget(object type, object instance) { }

	// RVA: 0x7125A18
	protected object GetTypeFromName(object typeName) { }

	// RVA: -1
	public abstract object GetValue(object component) { }

	// RVA: 0x712668C
	protected virtual object OnValueChanged(object component, object e) { }

	// RVA: -1
	public abstract object SetValue(object component, object value) { }

	// RVA: -1
	public abstract object ShouldSerializeValue(object component) { }

}

// Namespace: 
private class PropertyDescriptorEnumerator
{

	// Fields
	private object _owner; // 0x8
	private object _index; // 0x10

	// Properties
	public object Current { get; }
	public object Entry { get; }
	public object Key { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x7128270
	public object .ctor(object owner) { }

	// RVA: 0x7129244
	public object get_Current() { }

	// RVA: 0x71292B4
	public object get_Entry() { }

	// RVA: 0x712936C
	public object get_Key() { }

	// RVA: 0x7129400
	public object get_Value() { }

	// RVA: 0x7129494
	public object MoveNext() { }

	// RVA: 0x71294D8
	public object Reset() { }

}

// Namespace: System.ComponentModel
public class PropertyDescriptorCollection
{

	// Fields
	public static readonly object Empty; // 0x0
	private object _cachedFoundProperties; // 0x8
	private object _cachedIgnoreCase; // 0x10
	private object _properties; // 0x18
	private readonly object _namedSort; // 0x20
	private readonly object _comparer; // 0x28
	private object _propsOwned; // 0x30
	private object _needSort; // 0x31
	private object _readOnly; // 0x32
	private readonly object _internalSyncObject; // 0x38
	private object <Count>k__BackingField; // 0x40

	// Properties
	public object Count { get; set; }
	public virtual object Item { get; }
	public virtual object Item { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	private object System.Collections.ICollection.Count { get; }
	private object System.Collections.IDictionary.IsFixedSize { get; }
	private object System.Collections.IDictionary.IsReadOnly { get; }
	private object System.Collections.IDictionary.Item { get; set; }
	private object System.Collections.IDictionary.Keys { get; }
	private object System.Collections.IDictionary.Values { get; }
	private object System.Collections.IList.IsReadOnly { get; }
	private object System.Collections.IList.IsFixedSize { get; }
	private object System.Collections.IList.Item { get; set; }

	// Methods

	// RVA: 0x7126758
	public object .ctor(object properties) { }

	// RVA: 0x71268AC
	public object .ctor(object properties, object readOnly) { }

	// RVA: 0x71268D4
	private object .ctor(object properties, object propCount, object namedSort, object comparer) { }

	// RVA: 0x71269E0
	public object get_Count() { }

	// RVA: 0x71269E8
	private object set_Count(object value) { }

	// RVA: 0x71269F0
	public virtual object get_Item(object index) { }

	// RVA: 0x7126BC0
	public virtual object get_Item(object name) { }

	// RVA: 0x7126C10
	public object Add(object value) { }

	// RVA: 0x7126E84
	public object Clear() { }

	// RVA: 0x7126EDC
	public object Contains(object value) { }

	// RVA: 0x7126FB0
	public object CopyTo(object array, object index) { }

	// RVA: 0x7126B10
	private object EnsurePropsOwned() { }

	// RVA: 0x7126CE8
	private object EnsureSize(object sizeNeeded) { }

	// RVA: 0x71273E8
	public virtual object Find(object name, object ignoreCase) { }

	// RVA: 0x7126F4C
	public object IndexOf(object value) { }

	// RVA: 0x7127A78
	public object Insert(object index, object value) { }

	// RVA: 0x7127B70
	public object Remove(object value) { }

	// RVA: 0x7127C38
	public object RemoveAt(object index) { }

	// RVA: 0x7127CFC
	public virtual object Sort(object names) { }

	// RVA: 0x7127080
	protected object InternalSort(object names) { }

	// RVA: 0x7127D84
	protected object InternalSort(object sorter) { }

	// RVA: 0x7127E24
	public virtual object GetEnumerator() { }

	// RVA: 0x7127F70
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x7127F78
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x7127F80
	private object System.Collections.ICollection.get_Count() { }

	// RVA: 0x7127F88
	private object System.Collections.IList.Clear() { }

	// RVA: 0x7127FE0
	private object System.Collections.IDictionary.Clear() { }

	// RVA: 0x7128038
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x712807C
	private object System.Collections.IList.RemoveAt(object index) { }

	// RVA: 0x7128080
	private object System.Collections.IDictionary.Add(object key, object value) { }

	// RVA: 0x7128154
	private object System.Collections.IDictionary.Contains(object key) { }

	// RVA: 0x7128200
	private object System.Collections.IDictionary.GetEnumerator() { }

	// RVA: 0x71282A4
	private object System.Collections.IDictionary.get_IsFixedSize() { }

	// RVA: 0x71282AC
	private object System.Collections.IDictionary.get_IsReadOnly() { }

	// RVA: 0x71282B4
	private object System.Collections.IDictionary.get_Item(object key) { }

	// RVA: 0x7128354
	private object System.Collections.IDictionary.set_Item(object key, object value) { }

	// RVA: 0x7128834
	private object System.Collections.IDictionary.get_Keys() { }

	// RVA: 0x712897C
	private object System.Collections.IDictionary.get_Values() { }

	// RVA: 0x7128A5C
	private object System.Collections.IDictionary.Remove(object key) { }

	// RVA: 0x7128B8C
	private object System.Collections.IList.Add(object value) { }

	// RVA: 0x7128C24
	private object System.Collections.IList.Contains(object value) { }

	// RVA: 0x7128CF4
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: 0x7128DB8
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: 0x7128E58
	private object System.Collections.IList.get_IsReadOnly() { }

	// RVA: 0x7128E60
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: 0x7128E68
	private object System.Collections.IList.Remove(object value) { }

	// RVA: 0x7128F00
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: 0x7128F4C
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: 0x71291DC
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public sealed class ProvidePropertyAttribute
{

	// Fields
	private readonly object <PropertyName>k__BackingField; // 0x8
	private readonly object <ReceiverTypeName>k__BackingField; // 0x10

	// Properties
	public object PropertyName { get; }
	public object ReceiverTypeName { get; }

	// Methods

	// RVA: 0x71294E4
	public object get_PropertyName() { }

	// RVA: 0x71294EC
	public object get_ReceiverTypeName() { }

}

// Namespace: 
private class ReferenceComparer
{

	// Fields
	private object _converter; // 0x8

	// Methods

	// RVA: 0x712A9C4
	public object .ctor(object converter) { }

	// RVA: 0x712AA74
	public object Compare(object item1, object item2) { }

}

// Namespace: System.ComponentModel
public class ReferenceConverter
{

	// Fields
	private static readonly object s_none; // 0x0
	private object _type; // 0x8

	// Methods

	// RVA: 0x71294F4
	public object .ctor(object type) { }

	// RVA: 0x7129520
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x71295F0
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x7129A14
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x7129F70
	public override object GetStandardValues(object context) { }

	// RVA: 0x712A9F0
	public override object GetStandardValuesExclusive(object context) { }

	// RVA: 0x712A9F8
	public override object GetStandardValuesSupported(object context) { }

	// RVA: 0x712AA00
	protected virtual object IsValueAllowed(object context, object value) { }

	// RVA: 0x712AA08
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
internal sealed class ReflectEventDescriptor
{

	// Fields
	private object _type; // 0x58
	private readonly object _componentClass; // 0x60
	private object _addMethod; // 0x68
	private object _removeMethod; // 0x70
	private object _realEvent; // 0x78
	private object _filledMethods; // 0x80

	// Properties
	public override object EventType { get; }

	// Methods

	// RVA: 0x712AB3C
	public object .ctor(object componentClass, object name, object type, object attributes) { }

	// RVA: 0x712ACFC
	public object .ctor(object componentClass, object eventInfo) { }

	// RVA: 0x712AEF4
	public object .ctor(object componentType, object oldReflectEventDescriptor, object attributes) { }

	// RVA: 0x712AFD8
	public override object get_EventType() { }

	// RVA: 0x712B5D8
	protected override object FillAttributes(object attributes) { }

	// RVA: 0x712B650
	private object FillEventInfoAttribute(object realEventInfo, object attributes) { }

	// RVA: 0x712AFFC
	private object FillMethods() { }

	// RVA: 0x712BA8C
	private object FillSingleMethodAttribute(object realMethodInfo, object attributes) { }

}

// Namespace: System.ComponentModel
public class RefreshEventArgs
{

	// Fields
	private readonly object <ComponentChanged>k__BackingField; // 0x8
	private readonly object <TypeChanged>k__BackingField; // 0x10

	// Methods

	// RVA: 0x712C474
	public object .ctor(object componentChanged) { }

	// RVA: 0x712C524
	public object .ctor(object typeChanged) { }

}

// Namespace: System.ComponentModel
public sealed class RefreshEventHandler
{

	// Methods

	// RVA: 0x712C86C
	public object .ctor(object object, object method) { }

	// RVA: 0x712C988
	public virtual object Invoke(object e) { }

}

// Namespace: System.ComponentModel
public class SByteConverter
{

	// Properties
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x712C99C
	internal override object get_TargetType() { }

	// RVA: 0x712CA3C
	internal override object FromString(object value, object radix) { }

	// RVA: 0x712CAD8
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x712CB54
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x712CC14
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class SingleConverter
{

	// Properties
	internal override object AllowHex { get; }
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x712CC1C
	internal override object get_AllowHex() { }

	// RVA: 0x712CC24
	internal override object get_TargetType() { }

	// RVA: 0x712CCC4
	internal override object FromString(object value, object radix) { }

	// RVA: 0x712CD8C
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x712CE08
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x712CEC8
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class StringConverter
{

	// Methods

	// RVA: 0x712CED0
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x712CF9C
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x712D048
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class TimeSpanConverter
{

	// Methods

	// RVA: 0x712D050
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x712D11C
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x712D1E8
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x712D3F4
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x712D750
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public sealed class TypeConverterAttribute
{

	// Fields
	public static readonly object Default; // 0x0
	private readonly object <ConverterTypeName>k__BackingField; // 0x8

	// Properties
	public object ConverterTypeName { get; }

	// Methods

	// RVA: 0x712D758
	public object .ctor() { }

	// RVA: 0x712D7C0
	public object .ctor(object type) { }

	// RVA: 0x712D824
	public object get_ConverterTypeName() { }

	// RVA: 0x712D82C
	public override object Equals(object obj) { }

	// RVA: 0x712D8B0
	public override object GetHashCode() { }

	// RVA: 0x712D8FC
	private static object .cctor() { }

}

// Namespace: 
private sealed class EmptyCustomTypeDescriptor
{

	// Methods

	// RVA: 0x712DC0C
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public abstract class TypeDescriptionProvider
{

	// Fields
	private readonly object _parent; // 0x8
	private object _emptyDescriptor; // 0x10

	// Methods

	// RVA: 0x711DDF4
	protected object .ctor() { }

	// RVA: 0x712D9A0
	protected object .ctor(object parent) { }

	// RVA: 0x712D9CC
	public virtual object CreateInstance(object provider, object objectType, object argTypes, object args) { }

	// RVA: 0x712DAF4
	public virtual object GetCache(object instance) { }

	// RVA: 0x712DB4C
	public virtual object GetExtendedTypeDescriptor(object instance) { }

	// RVA: 0x712DC14
	protected internal virtual object GetExtenderProviders(object instance) { }

	// RVA: 0x712DDA8
	public virtual object GetFullComponentName(object component) { }

	// RVA: 0x712DF88
	public object GetReflectionType(object objectType) { }

	// RVA: 0x712DFD4
	public object GetReflectionType(object instance) { }

	// RVA: 0x712E080
	public virtual object GetReflectionType(object objectType, object instance) { }

	// RVA: 0x712E0EC
	public object GetTypeDescriptor(object objectType) { }

	// RVA: 0x712DEDC
	public object GetTypeDescriptor(object instance) { }

	// RVA: 0x712E138
	public virtual object GetTypeDescriptor(object objectType, object instance) { }

}

// Namespace: System.ComponentModel
public sealed class TypeDescriptionProviderAttribute
{

	// Fields
	private readonly object <TypeName>k__BackingField; // 0x8

	// Properties
	public object TypeName { get; }

	// Methods

	// RVA: 0x712E200
	public object .ctor(object typeName) { }

	// RVA: 0x712E278
	public object get_TypeName() { }

}

// Namespace: System.ComponentModel
public class UInt16Converter
{

	// Properties
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x712E280
	internal override object get_TargetType() { }

	// RVA: 0x712E320
	internal override object FromString(object value, object radix) { }

	// RVA: 0x712E3BC
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x712E438
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x712E4F8
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class UInt32Converter
{

	// Properties
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x712E500
	internal override object get_TargetType() { }

	// RVA: 0x712E5A0
	internal override object FromString(object value, object radix) { }

	// RVA: 0x712E63C
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x712E6B8
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x712E778
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class UInt64Converter
{

	// Properties
	internal override object TargetType { get; }

	// Methods

	// RVA: 0x712E780
	internal override object get_TargetType() { }

	// RVA: 0x712E820
	internal override object FromString(object value, object radix) { }

	// RVA: 0x712E8BC
	internal override object FromString(object value, object formatInfo) { }

	// RVA: 0x712E938
	internal override object ToString(object value, object formatInfo) { }

	// RVA: 0x712E9F8
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public interface IChangeTracking
{

	// Properties
	public abstract object IsChanged { get; }

	// Methods

	// RVA: -1
	public abstract object get_IsChanged() { }

	// RVA: -1
	public abstract object AcceptChanges() { }

}

// Namespace: System.ComponentModel
public interface IRevertibleChangeTracking
{

	// Methods

	// RVA: -1
	public abstract object RejectChanges() { }

}

// Namespace: System.ComponentModel
public class PropertyChangedEventArgs
{

	// Fields
	private readonly object _propertyName; // 0x8

	// Methods

	// RVA: 0x712EA00
	public object .ctor(object propertyName) { }

}

// Namespace: System.ComponentModel
public sealed class PropertyChangedEventHandler
{

	// Methods

	// RVA: 0x712ED74
	public object .ctor(object object, object method) { }

	// RVA: 0x712EE80
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.ComponentModel
public class PropertyChangingEventArgs
{

	// Fields
	private readonly object _propertyName; // 0x8

	// Methods

	// RVA: 0x712EE94
	public object .ctor(object propertyName) { }

}

// Namespace: System.ComponentModel
public sealed class PropertyChangingEventHandler
{

	// Methods

	// RVA: 0x712F208
	public object .ctor(object object, object method) { }

	// RVA: 0x712F314
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.ComponentModel
public class CollectionConverter
{

	// Methods

	// RVA: 0x712F328
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x712F4D8
	public override object GetProperties(object context, object value, object attributes) { }

	// RVA: 0x712F4E0
	public override object GetPropertiesSupported(object context) { }

	// RVA: 0x712F4E8
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public class Component
{

	// Fields
	private static readonly object EventDisposed; // 0x0
	private object site; // 0x10
	private object events; // 0x18

	// Properties
	protected virtual object CanRaiseEvents { get; }
	internal object CanRaiseEventsInternal { get; }
	public virtual object Site { get; }
	protected object DesignMode { get; }

	// Methods

	// RVA: 0x712F4F0
	protected override object Finalize() { }

	// RVA: 0x712F5A8
	protected virtual object get_CanRaiseEvents() { }

	// RVA: 0x712F5B0
	internal object get_CanRaiseEventsInternal() { }

	// RVA: 0x712F5F0
	public virtual object get_Site() { }

	// RVA: 0x712F5F8
	public object Dispose() { }

	// RVA: 0x712F690
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x712FA1C
	protected virtual object GetService(object service) { }

	// RVA: 0x712FAF8
	protected object get_DesignMode() { }

	// RVA: 0x712FBE4
	public override object ToString() { }

	// RVA: 0x712FD90
	public object .ctor() { }

	// RVA: 0x712FD98
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class ComponentConverter
{

	// Methods

	// RVA: 0x712FE14
	public object .ctor(object type) { }

	// RVA: 0x712FE84
	public override object GetProperties(object context, object value, object attributes) { }

	// RVA: 0x712FEF0
	public override object GetPropertiesSupported(object context) { }

}

// Namespace: System.ComponentModel
public class DateTimeOffsetConverter
{

	// Methods

	// RVA: 0x712FEF8
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x712FFC4
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x7130090
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x7130484
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x71310C0
	public object .ctor() { }

}

// Namespace: System.ComponentModel
public sealed class DesignerAttribute
{

	// Fields
	private readonly object designerTypeName; // 0x8
	private readonly object designerBaseTypeName; // 0x10

	// Properties
	public object DesignerBaseTypeName { get; }
	public object DesignerTypeName { get; }

	// Methods

	// RVA: 0x71310C8
	public object get_DesignerBaseTypeName() { }

	// RVA: 0x71310D0
	public object get_DesignerTypeName() { }

}

// Namespace: System.ComponentModel
public class EnumConverter
{

	// Fields
	private object values; // 0x8
	private object type; // 0x10

	// Properties
	protected object EnumType { get; }
	protected object Values { get; set; }
	protected virtual object Comparer { get; }

	// Methods

	// RVA: 0x71310D8
	public object .ctor(object type) { }

	// RVA: 0x7131104
	protected object get_EnumType() { }

	// RVA: 0x713110C
	protected object get_Values() { }

	// RVA: 0x7131114
	protected object set_Values(object value) { }

	// RVA: 0x713111C
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x7131230
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x7131344
	protected virtual object get_Comparer() { }

	// RVA: 0x71313C0
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x713192C
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x71329EC
	public override object GetStandardValues(object context) { }

	// RVA: 0x7132EBC
	public override object GetStandardValuesExclusive(object context) { }

	// RVA: 0x7132FA8
	public override object GetStandardValuesSupported(object context) { }

	// RVA: 0x7132FB0
	public override object IsValid(object context, object value) { }

}

// Namespace: System.ComponentModel
public interface IComponent
{

	// Properties
	public abstract object Site { get; }

	// Methods

	// RVA: -1
	public abstract object get_Site() { }

}

// Namespace: System.ComponentModel
public abstract class MemberDescriptor
{

	// Fields
	private object name; // 0x8
	private object displayName; // 0x10
	private object nameHash; // 0x18
	private object attributeCollection; // 0x20
	private object attributes; // 0x28
	private object originalAttributes; // 0x30
	private object attributesFiltered; // 0x38
	private object attributesFilled; // 0x39
	private object metadataVersion; // 0x3C
	private object category; // 0x40
	private object description; // 0x48
	private object lockCookie; // 0x50

	// Properties
	protected virtual object AttributeArray { get; set; }
	public virtual object Attributes { get; }
	public virtual object Name { get; }
	protected virtual object NameHashCode { get; }
	public virtual object DisplayName { get; }

	// Methods

	// RVA: 0x711EF58
	protected object .ctor(object name, object attributes) { }

	// RVA: 0x711F124
	protected object .ctor(object oldMemberDescriptor, object newAttributes) { }

	// RVA: 0x7133020
	protected virtual object get_AttributeArray() { }

	// RVA: 0x7133AA0
	protected virtual object set_AttributeArray(object value) { }

	// RVA: 0x7133B80
	public virtual object get_Attributes() { }

	// RVA: 0x7133D54
	public virtual object get_Name() { }

	// RVA: 0x7133DB0
	protected virtual object get_NameHashCode() { }

	// RVA: 0x7121A24
	public virtual object get_DisplayName() { }

	// RVA: 0x7133110
	private object CheckAttributesValid() { }

	// RVA: 0x7133DB8
	protected virtual object CreateAttributeCollection() { }

	// RVA: 0x7133E40
	public override object Equals(object obj) { }

	// RVA: 0x7126288
	protected virtual object FillAttributes(object attributeList) { }

	// RVA: 0x71331F4
	private object FilterAttributesIfNeeded() { }

	// RVA: 0x712C46C
	protected static object FindMethod(object componentClass, object name, object args, object returnType) { }

	// RVA: 0x7134114
	protected static object FindMethod(object componentClass, object name, object args, object returnType, object publicOnly) { }

	// RVA: 0x7134240
	public override object GetHashCode() { }

	// RVA: 0x712655C
	protected virtual object GetInvocationTarget(object type, object instance) { }

	// RVA: 0x7121BB0
	protected static object GetSite(object component) { }

}

// Namespace: System.ComponentModel
internal sealed class ReflectPropertyDescriptor
{

	// Fields
	private static readonly object argsNone; // 0x0
	private static readonly object noValue; // 0x8
	private static object PropDescCreateSwitch; // 0x10
	private static object PropDescUsageSwitch; // 0x18
	private static readonly object BitDefaultValueQueried; // 0x20
	private static readonly object BitGetQueried; // 0x24
	private static readonly object BitSetQueried; // 0x28
	private static readonly object BitShouldSerializeQueried; // 0x2C
	private static readonly object BitResetQueried; // 0x30
	private static readonly object BitChangedQueried; // 0x34
	private static readonly object BitIPropChangedQueried; // 0x38
	private static readonly object BitReadOnlyChecked; // 0x3C
	private static readonly object BitAmbientValueQueried; // 0x40
	private static readonly object BitSetOnDemand; // 0x44
	private object state; // 0x7C
	private object componentClass; // 0x80
	private object type; // 0x88
	private object defaultValue; // 0x90
	private object ambientValue; // 0x98
	private object propInfo; // 0xA0
	private object getMethod; // 0xA8
	private object setMethod; // 0xB0
	private object shouldSerializeMethod; // 0xB8
	private object resetMethod; // 0xC0
	private object realChangedEvent; // 0xC8
	private object receiverType; // 0xD0

	// Properties
	public override object ComponentType { get; }
	private object DefaultValue { get; }
	private object GetMethodValue { get; }
	private object IsExtender { get; }
	public override object IsReadOnly { get; }
	public override object PropertyType { get; }
	private object SetMethodValue { get; }
	private object ShouldSerializeMethodValue { get; }

	// Methods

	// RVA: 0x7134248
	public object .ctor(object componentClass, object name, object type, object attributes) { }

	// RVA: 0x7134528
	public object .ctor(object componentClass, object name, object type, object propInfo, object getMethod, object setMethod, object attrs) { }

	// RVA: 0x7134654
	public object .ctor(object componentClass, object name, object type, object receiverType, object getMethod, object setMethod, object attrs) { }

	// RVA: 0x7134720
	public object .ctor(object componentClass, object oldReflectPropertyDescriptor, object attributes) { }

	// RVA: 0x7134C08
	public override object get_ComponentType() { }

	// RVA: 0x7134C10
	private object get_DefaultValue() { }

	// RVA: 0x7134FE0
	private object get_GetMethodValue() { }

	// RVA: 0x71354E4
	private object get_IsExtender() { }

	// RVA: 0x7135550
	public override object get_IsReadOnly() { }

	// RVA: 0x7135D2C
	public override object get_PropertyType() { }

	// RVA: 0x71356A4
	private object get_SetMethodValue() { }

	// RVA: 0x7135D34
	private object get_ShouldSerializeMethodValue() { }

	// RVA: 0x7135FB4
	internal object ExtenderGetReceiverType() { }

	// RVA: 0x712177C
	internal object ExtenderGetType(object provider) { }

	// RVA: 0x7121D18
	internal object ExtenderGetValue(object provider, object component) { }

	// RVA: 0x7121EB0
	internal object ExtenderSetValue(object provider, object component, object value, object notifyDesc) { }

	// RVA: 0x71223F8
	internal object ExtenderShouldSerializeValue(object provider, object component) { }

	// RVA: 0x7135FBC
	protected override object FillAttributes(object attributes) { }

	// RVA: 0x7136CD4
	public override object GetValue(object component) { }

	// RVA: 0x713705C
	protected override object OnValueChanged(object component, object e) { }

	// RVA: 0x71371B8
	public override object SetValue(object component, object value) { }

	// RVA: 0x7137940
	public override object ShouldSerializeValue(object component) { }

	// RVA: 0x7137D4C
	private static object .cctor() { }

}

// Namespace: 
private class ReflectedTypeData
{

	// Fields
	private object _type; // 0x8
	private object _attributes; // 0x10
	private object _events; // 0x18
	private object _properties; // 0x20
	private object _converter; // 0x28
	private object _editors; // 0x30
	private object _editorTypes; // 0x38
	private object _editorCount; // 0x40

	// Properties
	internal object IsPopulated { get; }

	// Methods

	// RVA: 0x713FAA0
	internal object .ctor(object type) { }

	// RVA: 0x713F698
	internal object get_IsPopulated() { }

	// RVA: 0x7139640
	internal object GetAttributes() { }

	// RVA: 0x713A10C
	internal object GetClassName(object instance) { }

	// RVA: 0x713A194
	internal object GetComponentName(object instance) { }

	// RVA: 0x713A400
	internal object GetConverter(object instance) { }

	// RVA: 0x713AA1C
	internal object GetDefaultEvent(object instance) { }

	// RVA: 0x713AC74
	internal object GetDefaultProperty(object instance) { }

	// RVA: 0x713AED4
	internal object GetEditor(object instance, object editorBaseType) { }

	// RVA: 0x71422E0
	private static object GetEditorAttribute(object attributes, object editorBaseType) { }

	// RVA: 0x713BB80
	internal object GetEvents() { }

	// RVA: 0x713F6DC
	internal object GetProperties() { }

	// RVA: 0x7142084
	private object GetTypeFromName(object typeName) { }

	// RVA: 0x71411F4
	internal object Refresh() { }

}

// Namespace: System.ComponentModel
internal sealed class ReflectTypeDescriptionProvider
{

	// Fields
	private object _typeData; // 0x18
	private static object _typeConstructor; // 0x0
	private static object _editorTables; // 0x8
	private static object _intrinsicTypeConverters; // 0x10
	private static object _intrinsicReferenceKey; // 0x18
	private static object _intrinsicNullableKey; // 0x20
	private static object _dictionaryKey; // 0x28
	private static object _propertyCache; // 0x30
	private static object _eventCache; // 0x38
	private static object _attributeCache; // 0x40
	private static object _extendedPropertyCache; // 0x48
	private static readonly object _extenderProviderKey; // 0x50
	private static readonly object _extenderPropertiesKey; // 0x60
	private static readonly object _extenderProviderPropertiesKey; // 0x70
	private static readonly object _skipInterfaceAttributeList; // 0x80
	private static object _internalSyncObject; // 0x88

	// Properties
	private static object IntrinsicTypeConverters { get; }

	// Methods

	// RVA: 0x7137F88
	internal object .ctor() { }

	// RVA: 0x7137F90
	private static object get_IntrinsicTypeConverters() { }

	// RVA: 0x7138CBC
	internal static object AddEditorTable(object editorBaseType, object table) { }

	// RVA: 0x7138FD4
	public override object CreateInstance(object provider, object objectType, object argTypes, object args) { }

	// RVA: 0x71391FC
	private static object CreateInstance(object objectType, object callingType) { }

	// RVA: 0x7139330
	internal object GetAttributes(object type) { }

	// RVA: 0x7139D0C
	public override object GetCache(object instance) { }

	// RVA: 0x713A0A4
	internal object GetClassName(object type) { }

	// RVA: 0x713A15C
	internal object GetComponentName(object type, object instance) { }

	// RVA: 0x713A3C8
	internal object GetConverter(object type, object instance) { }

	// RVA: 0x713A9E4
	internal object GetDefaultEvent(object type, object instance) { }

	// RVA: 0x713AC3C
	internal object GetDefaultProperty(object type, object instance) { }

	// RVA: 0x713AE94
	internal object GetEditor(object type, object instance, object editorBaseType) { }

	// RVA: 0x713B628
	private static object GetEditorTable(object editorBaseType) { }

	// RVA: 0x713BB58
	internal object GetEvents(object type) { }

	// RVA: 0x713BF3C
	internal object GetExtendedAttributes(object instance) { }

	// RVA: 0x713BFB8
	internal object GetExtendedClassName(object instance) { }

	// RVA: 0x713C03C
	internal object GetExtendedComponentName(object instance) { }

	// RVA: 0x713C09C
	internal object GetExtendedConverter(object instance) { }

	// RVA: 0x713C0FC
	internal object GetExtendedDefaultEvent(object instance) { }

	// RVA: 0x713C104
	internal object GetExtendedDefaultProperty(object instance) { }

	// RVA: 0x713C10C
	internal object GetExtendedEditor(object instance, object editorBaseType) { }

	// RVA: 0x713C17C
	internal object GetExtendedEvents(object instance) { }

	// RVA: 0x713C1F8
	internal object GetExtendedProperties(object instance) { }

	// RVA: 0x713DAD0
	protected internal override object GetExtenderProviders(object instance) { }

	// RVA: 0x713E074
	private static object GetExtenders(object components, object instance, object cache) { }

	// RVA: 0x713EE2C
	internal object GetExtendedPropertyOwner(object instance, object pd) { }

	// RVA: 0x713EF20
	public override object GetExtendedTypeDescriptor(object instance) { }

	// RVA: 0x713EF28
	public override object GetFullComponentName(object component) { }

	// RVA: 0x713F0E4
	internal object GetPopulatedTypes(object module) { }

	// RVA: 0x713F6B4
	internal object GetProperties(object type) { }

	// RVA: 0x713EEB4
	internal object GetPropertyOwner(object type, object instance, object pd) { }

	// RVA: 0x713FA98
	public override object GetReflectionType(object objectType, object instance) { }

	// RVA: 0x7139358
	private object GetTypeData(object type, object createIfNeeded) { }

	// RVA: 0x713FACC
	public override object GetTypeDescriptor(object objectType, object instance) { }

	// RVA: 0x713FAD4
	private static object GetTypeFromName(object typeName) { }

	// RVA: 0x713FBFC
	internal object IsPopulated(object type) { }

	// RVA: 0x713FC30
	private static object ReflectGetAttributes(object type) { }

	// RVA: 0x712BEF8
	internal static object ReflectGetAttributes(object member) { }

	// RVA: 0x71401A4
	private static object ReflectGetEvents(object type) { }

	// RVA: 0x713C8B4
	private static object ReflectGetExtendedProperties(object provider) { }

	// RVA: 0x7140A30
	private static object ReflectGetProperties(object type) { }

	// RVA: 0x71411C8
	internal object Refresh(object type) { }

	// RVA: 0x7141208
	private static object SearchIntrinsicTable(object table, object callingType) { }

	// RVA: 0x7141D98
	private static object .cctor() { }

}

// Namespace: 
protected abstract class SimplePropertyDescriptor
{

	// Fields
	private object componentType; // 0x80
	private object propertyType; // 0x88

	// Properties
	public override object ComponentType { get; }
	public override object IsReadOnly { get; }
	public override object PropertyType { get; }

	// Methods

	// RVA: 0x7144094
	protected object .ctor(object componentType, object name, object propertyType, object attributes) { }

	// RVA: 0x71440D4
	public override object get_ComponentType() { }

	// RVA: 0x71440DC
	public override object get_IsReadOnly() { }

	// RVA: 0x7144180
	public override object get_PropertyType() { }

	// RVA: 0x7144188
	public override object ShouldSerializeValue(object component) { }

}

// Namespace: 
public class StandardValuesCollection
{

	// Fields
	private object values; // 0x8
	private object valueArray; // 0x10

	// Properties
	public object Count { get; }
	private object System.Collections.ICollection.Count { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: 0x7144190
	public object .ctor(object values) { }

	// RVA: 0x714425C
	public object get_Count() { }

	// RVA: 0x714435C
	public object CopyTo(object array, object index) { }

	// RVA: 0x7144440
	public object GetEnumerator() { }

	// RVA: 0x7144520
	private object System.Collections.ICollection.get_Count() { }

	// RVA: 0x7144524
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x714452C
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x7144534
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x7144538
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.ComponentModel
public class TypeConverter
{

	// Fields
	private const object s_UseCompatibleTypeConverterBehavior;
	private static object useCompatibleTypeConversion; // 0x0

	// Properties
	private static object UseCompatibleTypeConversion { get; }

	// Methods

	// RVA: 0x71426DC
	private static object get_UseCompatibleTypeConversion() { }

	// RVA: 0x7142730
	public object CanConvertFrom(object sourceType) { }

	// RVA: 0x714277C
	public virtual object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x7142808
	public object CanConvertTo(object destinationType) { }

	// RVA: 0x7142854
	public virtual object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x71428E0
	public object ConvertFrom(object value) { }

	// RVA: 0x7142978
	public virtual object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x7142F58
	public object ConvertFromInvariantString(object text) { }

	// RVA: 0x7143050
	public object ConvertFromInvariantString(object context, object text) { }

	// RVA: 0x71430F4
	public object ConvertFromString(object text) { }

	// RVA: 0x7143144
	public object ConvertFromString(object context, object text) { }

	// RVA: 0x7142FF0
	public object ConvertFromString(object context, object culture, object text) { }

	// RVA: 0x71431E8
	public object ConvertTo(object value, object destinationType) { }

	// RVA: 0x7143248
	public virtual object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x71436A0
	public object ConvertToInvariantString(object value) { }

	// RVA: 0x7143818
	public object ConvertToInvariantString(object context, object value) { }

	// RVA: 0x714389C
	public object ConvertToString(object value) { }

	// RVA: 0x71439BC
	public object ConvertToString(object context, object value) { }

	// RVA: 0x7143718
	public object ConvertToString(object context, object culture, object value) { }

	// RVA: 0x7143AE0
	public object CreateInstance(object propertyValues) { }

	// RVA: 0x7143B2C
	public virtual object CreateInstance(object context, object propertyValues) { }

	// RVA: 0x7142DE8
	protected object GetConvertFromException(object value) { }

	// RVA: 0x71434E0
	protected object GetConvertToException(object value, object destinationType) { }

	// RVA: 0x7143B34
	public object GetCreateInstanceSupported() { }

	// RVA: 0x7143B78
	public virtual object GetCreateInstanceSupported(object context) { }

	// RVA: 0x7143B80
	public object GetProperties(object value) { }

	// RVA: 0x7143B8C
	public object GetProperties(object context, object value) { }

	// RVA: 0x7143C98
	public virtual object GetProperties(object context, object value, object attributes) { }

	// RVA: 0x7143CA0
	public object GetPropertiesSupported() { }

	// RVA: 0x7143CE4
	public virtual object GetPropertiesSupported(object context) { }

	// RVA: 0x7143CEC
	public object GetStandardValues() { }

	// RVA: 0x7143D30
	public virtual object GetStandardValues(object context) { }

	// RVA: 0x7143D38
	public object GetStandardValuesExclusive() { }

	// RVA: 0x7143D80
	public virtual object GetStandardValuesExclusive(object context) { }

	// RVA: 0x7143D88
	public object GetStandardValuesSupported() { }

	// RVA: 0x7143DD0
	public virtual object GetStandardValuesSupported(object context) { }

	// RVA: 0x7143DD8
	public object IsValid(object value) { }

	// RVA: 0x7143E28
	public virtual object IsValid(object context, object value) { }

	// RVA: 0x714402C
	protected object SortProperties(object props, object names) { }

	// RVA: 0x714408C
	public object .ctor() { }

}

// Namespace: 
private class AttributeTypeDescriptor
{

	// Fields
	private object _attributeArray; // 0x10

	// Methods

	// RVA: 0x7155350
	internal object .ctor(object attrs, object parent) { }

	// RVA: 0x7155380
	public override object GetAttributes() { }

}

// Namespace: 
private sealed class AttributeProvider
{

	// Fields
	private object _attrs; // 0x18

	// Methods

	// RVA: 0x7145278
	internal object .ctor(object existingProvider, object attrs) { }

	// RVA: 0x71552B4
	public override object GetTypeDescriptor(object objectType, object instance) { }

}

// Namespace: 
private sealed class ComNativeTypeDescriptor
{

	// Fields
	private object _handler; // 0x8
	private object _instance; // 0x10

	// Methods

	// RVA: 0x71558BC
	internal object .ctor(object handler, object instance) { }

	// RVA: 0x71558F4
	private object System.ComponentModel.ICustomTypeDescriptor.GetAttributes() { }

	// RVA: 0x71559C8
	private object System.ComponentModel.ICustomTypeDescriptor.GetClassName() { }

	// RVA: 0x7155AA0
	private object System.ComponentModel.ICustomTypeDescriptor.GetComponentName() { }

	// RVA: 0x7155AA8
	private object System.ComponentModel.ICustomTypeDescriptor.GetConverter() { }

	// RVA: 0x7155B80
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultEvent() { }

	// RVA: 0x7155C58
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultProperty() { }

	// RVA: 0x7155D30
	private object System.ComponentModel.ICustomTypeDescriptor.GetEditor(object editorBaseType) { }

	// RVA: 0x7155E18
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents() { }

	// RVA: 0x7155EF0
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents(object attributes) { }

	// RVA: 0x7155FD8
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties() { }

	// RVA: 0x71560B4
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties(object attributes) { }

	// RVA: 0x715619C
	private object System.ComponentModel.ICustomTypeDescriptor.GetPropertyOwner(object pd) { }

}

// Namespace: 
private sealed class ComNativeDescriptionProvider
{

	// Fields
	private object _handler; // 0x18

	// Properties
	internal object Handler { get; set; }

	// Methods

	// RVA: 0x71449F0
	internal object .ctor(object handler) { }

	// RVA: 0x71556EC
	internal object get_Handler() { }

	// RVA: 0x71556F4
	internal object set_Handler(object value) { }

	// RVA: 0x71556FC
	public override object GetTypeDescriptor(object objectType, object instance) { }

}

// Namespace: 
private sealed class AttributeFilterCacheItem
{

	// Fields
	private object _filter; // 0x8
	internal object FilteredMembers; // 0x10

	// Methods

	// RVA: 0x7152E18
	internal object .ctor(object filter, object filteredMembers) { }

	// RVA: 0x7152D8C
	internal object IsValid(object filter) { }

}

// Namespace: 
private sealed class FilterCacheItem
{

	// Fields
	private object _filterService; // 0x8
	internal object FilteredMembers; // 0x10

	// Methods

	// RVA: 0x71535E0
	internal object .ctor(object filterService, object filteredMembers) { }

	// RVA: 0x7152E50
	internal object IsValid(object filterService) { }

}

// Namespace: 
private interface IUnimplemented
{
}

// Namespace: 
private sealed class MemberDescriptorComparer
{

	// Fields
	public static readonly object Instance; // 0x0

	// Methods

	// RVA: 0x71561A4
	public object Compare(object left, object right) { }

	// RVA: 0x7156304
	public object .ctor() { }

	// RVA: 0x715630C
	private static object .cctor() { }

}

// Namespace: 
private sealed class MergedTypeDescriptor
{

	// Fields
	private object _primary; // 0x8
	private object _secondary; // 0x10

	// Methods

	// RVA: 0x714F950
	internal object .ctor(object primary, object secondary) { }

	// RVA: 0x715636C
	private object System.ComponentModel.ICustomTypeDescriptor.GetAttributes() { }

	// RVA: 0x71564E8
	private object System.ComponentModel.ICustomTypeDescriptor.GetClassName() { }

	// RVA: 0x715666C
	private object System.ComponentModel.ICustomTypeDescriptor.GetComponentName() { }

	// RVA: 0x71567F0
	private object System.ComponentModel.ICustomTypeDescriptor.GetConverter() { }

	// RVA: 0x7156974
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultEvent() { }

	// RVA: 0x7156AF8
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultProperty() { }

	// RVA: 0x7156C7C
	private object System.ComponentModel.ICustomTypeDescriptor.GetEditor(object editorBaseType) { }

	// RVA: 0x7156EB0
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents() { }

	// RVA: 0x7157034
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents(object attributes) { }

	// RVA: 0x71571C8
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties() { }

	// RVA: 0x715734C
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties(object attributes) { }

	// RVA: 0x71574E0
	private object System.ComponentModel.ICustomTypeDescriptor.GetPropertyOwner(object pd) { }

}

// Namespace: 
private struct DefaultExtendedTypeDescriptor
{

	// Fields
	private object _node; // 0xFFFFFFFFFFFFFFF8
	private object _instance; // 0x0

	// Methods

	// RVA: 0x715798C
	internal object .ctor(object node, object instance) { }

	// RVA: 0x7157DEC
	private object System.ComponentModel.ICustomTypeDescriptor.GetAttributes() { }

	// RVA: 0x715818C
	private object System.ComponentModel.ICustomTypeDescriptor.GetClassName() { }

	// RVA: 0x7158494
	private object System.ComponentModel.ICustomTypeDescriptor.GetComponentName() { }

	// RVA: 0x7158738
	private object System.ComponentModel.ICustomTypeDescriptor.GetConverter() { }

	// RVA: 0x7158A8C
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultEvent() { }

	// RVA: 0x7158D30
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultProperty() { }

	// RVA: 0x7158FD4
	private object System.ComponentModel.ICustomTypeDescriptor.GetEditor(object editorBaseType) { }

	// RVA: 0x715930C
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents() { }

	// RVA: 0x71596B0
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents(object attributes) { }

	// RVA: 0x7159A54
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties() { }

	// RVA: 0x7159DA8
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties(object attributes) { }

	// RVA: 0x715A114
	private object System.ComponentModel.ICustomTypeDescriptor.GetPropertyOwner(object pd) { }

}

// Namespace: 
private struct DefaultTypeDescriptor
{

	// Fields
	private object _node; // 0xFFFFFFFFFFFFFFF8
	private object _objectType; // 0x0
	private object _instance; // 0x8

	// Methods

	// RVA: 0x7157D9C
	internal object .ctor(object node, object objectType, object instance) { }

	// RVA: 0x715A430
	private object System.ComponentModel.ICustomTypeDescriptor.GetAttributes() { }

	// RVA: 0x715A788
	private object System.ComponentModel.ICustomTypeDescriptor.GetClassName() { }

	// RVA: 0x715AA78
	private object System.ComponentModel.ICustomTypeDescriptor.GetComponentName() { }

	// RVA: 0x715AD24
	private object System.ComponentModel.ICustomTypeDescriptor.GetConverter() { }

	// RVA: 0x715B080
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultEvent() { }

	// RVA: 0x715B32C
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultProperty() { }

	// RVA: 0x715B5D8
	private object System.ComponentModel.ICustomTypeDescriptor.GetEditor(object editorBaseType) { }

	// RVA: 0x715B924
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents() { }

	// RVA: 0x715BC80
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents(object attributes) { }

	// RVA: 0x715BFF4
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties() { }

	// RVA: 0x715C350
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties(object attributes) { }

	// RVA: 0x715C6C4
	private object System.ComponentModel.ICustomTypeDescriptor.GetPropertyOwner(object pd) { }

}

// Namespace: 
private sealed class TypeDescriptionNode
{

	// Fields
	internal object Next; // 0x18
	internal object Provider; // 0x20

	// Methods

	// RVA: 0x7145D5C
	internal object .ctor(object provider) { }

	// RVA: 0x7157674
	public override object CreateInstance(object provider, object objectType, object argTypes, object args) { }

	// RVA: 0x7157838
	public override object GetCache(object instance) { }

	// RVA: 0x71578D8
	public override object GetExtendedTypeDescriptor(object instance) { }

	// RVA: 0x7157994
	protected internal override object GetExtenderProviders(object instance) { }

	// RVA: 0x7157A34
	public override object GetFullComponentName(object component) { }

	// RVA: 0x7157AD4
	public override object GetReflectionType(object objectType, object instance) { }

	// RVA: 0x7157BF8
	public override object GetTypeDescriptor(object objectType, object instance) { }

}

// Namespace: 
private sealed class TypeDescriptorComObject
{
}

// Namespace: 
private sealed class TypeDescriptorInterface
{
}

// Namespace: System.ComponentModel
public sealed class TypeDescriptor
{

	// Fields
	private static object _providerTable; // 0x0
	private static object _providerTypeTable; // 0x8
	private static object _defaultProviders; // 0x10
	private static object _associationTable; // 0x18
	private static object _metadataVersion; // 0x20
	private static object _collisionIndex; // 0x24
	private static object TraceDescriptor; // 0x28
	private const object PIPELINE_ATTRIBUTES;
	private const object PIPELINE_PROPERTIES;
	private const object PIPELINE_EVENTS;
	private static readonly object _pipelineInitializeKeys; // 0x30
	private static readonly object _pipelineMergeKeys; // 0x38
	private static readonly object _pipelineFilterKeys; // 0x40
	private static readonly object _pipelineAttributeFilterKeys; // 0x48
	private static object _internalSyncObject; // 0x50
	private static object Refreshed; // 0x58

	// Properties
	public static object ComNativeDescriptorHandler { get; set; }
	public static object ComObjectType { get; }
	public static object InterfaceType { get; }
	internal static object MetadataVersion { get; }

	// Methods

	// RVA: 0x714453C
	private object .ctor() { }

	// RVA: 0x7144544
	public static object get_ComNativeDescriptorHandler() { }

	// RVA: 0x71447D0
	public static object set_ComNativeDescriptorHandler(object value) { }

	// RVA: 0x71446A8
	public static object get_ComObjectType() { }

	// RVA: 0x7144CF0
	public static object get_InterfaceType() { }

	// RVA: 0x7144D90
	internal static object get_MetadataVersion() { }

	// RVA: 0x7144E0C
	public static object add_Refreshed(object value) { }

	// RVA: 0x7144EFC
	public static object remove_Refreshed(object value) { }

	// RVA: 0x7144FEC
	public static object AddAttributes(object type, object attributes) { }

	// RVA: 0x71452A4
	public static object AddAttributes(object instance, object attributes) { }

	// RVA: 0x714575C
	public static object AddEditorTable(object editorBaseType, object table) { }

	// RVA: 0x7144A1C
	public static object AddProvider(object provider, object type) { }

	// RVA: 0x714547C
	public static object AddProvider(object provider, object instance) { }

	// RVA: 0x71471A0
	public static object AddProviderTransparent(object provider, object type) { }

	// RVA: 0x71472C4
	public static object AddProviderTransparent(object provider, object instance) { }

	// RVA: 0x71473B4
	private static object CheckDefaultProvider(object type) { }

	// RVA: 0x7147B50
	public static object CreateAssociation(object primary, object secondary) { }

	// RVA: 0x71484A4
	public static object CreateDesigner(object component, object designerBaseType) { }

	// RVA: 0x7148A9C
	public static object CreateEvent(object componentType, object name, object type, object attributes) { }

	// RVA: 0x7148B24
	public static object CreateEvent(object componentType, object oldEventDescriptor, object attributes) { }

	// RVA: 0x7148BA4
	public static object CreateInstance(object provider, object objectType, object argTypes, object args) { }

	// RVA: 0x7148F68
	public static object CreateProperty(object componentType, object name, object type, object attributes) { }

	// RVA: 0x7148FF0
	public static object CreateProperty(object componentType, object oldPropertyDescriptor, object attributes) { }

	// RVA: 0x7149230
	private static object DebugValidate(object type, object attributes, object debugAttributes) { }

	// RVA: 0x7149234
	private static object DebugValidate(object attributes, object debugAttributes) { }

	// RVA: 0x7149238
	private static object DebugValidate(object attributes, object type) { }

	// RVA: 0x714923C
	private static object DebugValidate(object attributes, object instance, object noCustomTypeDesc) { }

	// RVA: 0x7149240
	private static object DebugValidate(object converter, object type) { }

	// RVA: 0x7149244
	private static object DebugValidate(object converter, object instance, object noCustomTypeDesc) { }

	// RVA: 0x7149248
	private static object DebugValidate(object events, object type, object attributes) { }

	// RVA: 0x714924C
	private static object DebugValidate(object events, object instance, object attributes, object noCustomTypeDesc) { }

	// RVA: 0x7149250
	private static object DebugValidate(object properties, object type, object attributes) { }

	// RVA: 0x7149254
	private static object DebugValidate(object properties, object instance, object attributes, object noCustomTypeDesc) { }

	// RVA: 0x7149258
	private static object FilterMembers(object members, object attributes) { }

	// RVA: 0x71498B8
	public static object GetAssociation(object type, object primary) { }

	// RVA: 0x7149FE4
	public static object GetAttributes(object componentType) { }

	// RVA: 0x7148A14
	public static object GetAttributes(object component) { }

	// RVA: 0x714A30C
	public static object GetAttributes(object component, object noCustomTypeDesc) { }

	// RVA: 0x714DEA4
	internal static object GetCache(object instance) { }

	// RVA: 0x714E9E8
	public static object GetClassName(object component) { }

	// RVA: 0x714EA70
	public static object GetClassName(object component, object noCustomTypeDesc) { }

	// RVA: 0x714EBA4
	public static object GetClassName(object componentType) { }

	// RVA: 0x714ECF0
	public static object GetComponentName(object component) { }

	// RVA: 0x714ED78
	public static object GetComponentName(object component, object noCustomTypeDesc) { }

	// RVA: 0x714EEAC
	public static object GetConverter(object component) { }

	// RVA: 0x714EF34
	public static object GetConverter(object component, object noCustomTypeDesc) { }

	// RVA: 0x714F068
	public static object GetConverter(object type) { }

	// RVA: 0x714F1B4
	private static object ConvertFromInvariantString(object type, object stringValue) { }

	// RVA: 0x714F2B8
	public static object GetDefaultEvent(object componentType) { }

	// RVA: 0x714F44C
	public static object GetDefaultEvent(object component) { }

	// RVA: 0x714F4D4
	public static object GetDefaultEvent(object component, object noCustomTypeDesc) { }

	// RVA: 0x714F604
	public static object GetDefaultProperty(object componentType) { }

	// RVA: 0x714F798
	public static object GetDefaultProperty(object component) { }

	// RVA: 0x714F820
	public static object GetDefaultProperty(object component, object noCustomTypeDesc) { }

	// RVA: 0x714A1A0
	internal static object GetDescriptor(object type, object typeName) { }

	// RVA: 0x714A79C
	internal static object GetDescriptor(object component, object noCustomTypeDesc) { }

	// RVA: 0x714AA24
	internal static object GetExtendedDescriptor(object component) { }

	// RVA: 0x714F988
	public static object GetEditor(object component, object editorBaseType) { }

	// RVA: 0x714F9F4
	public static object GetEditor(object component, object editorBaseType, object noCustomTypeDesc) { }

	// RVA: 0x714FBA8
	public static object GetEditor(object type, object editorBaseType) { }

	// RVA: 0x714FD64
	public static object GetEvents(object componentType) { }

	// RVA: 0x714FF28
	public static object GetEvents(object componentType, object attributes) { }

	// RVA: 0x71501E0
	public static object GetEvents(object component) { }

	// RVA: 0x71507C0
	public static object GetEvents(object component, object noCustomTypeDesc) { }

	// RVA: 0x715082C
	public static object GetEvents(object component, object attributes) { }

	// RVA: 0x7150248
	public static object GetEvents(object component, object attributes, object noCustomTypeDesc) { }

	// RVA: 0x7151074
	private static object GetExtenderCollisionSuffix(object member) { }

	// RVA: 0x7151460
	public static object GetFullComponentName(object component) { }

	// RVA: 0x7151544
	private static object GetNodeForBaseType(object searchType) { }

	// RVA: 0x7151768
	public static object GetProperties(object componentType) { }

	// RVA: 0x715192C
	public static object GetProperties(object componentType, object attributes) { }

	// RVA: 0x7151BE4
	public static object GetProperties(object component) { }

	// RVA: 0x7151CA8
	public static object GetProperties(object component, object noCustomTypeDesc) { }

	// RVA: 0x71524E0
	public static object GetProperties(object component, object attributes) { }

	// RVA: 0x71525A8
	public static object GetProperties(object component, object attributes, object noCustomTypeDesc) { }

	// RVA: 0x7151D18
	private static object GetPropertiesImpl(object component, object attributes, object noCustomTypeDesc, object noAttributes) { }

	// RVA: 0x714515C
	public static object GetProvider(object type) { }

	// RVA: 0x71453C0
	public static object GetProvider(object instance) { }

	// RVA: 0x7152624
	internal static object GetProviderRecursive(object type) { }

	// RVA: 0x71526AC
	public static object GetReflectionType(object type) { }

	// RVA: 0x7152824
	public static object GetReflectionType(object instance) { }

	// RVA: 0x7144748
	private static object NodeFor(object type) { }

	// RVA: 0x71457C8
	private static object NodeFor(object type, object createDelegator) { }

	// RVA: 0x714E960
	private static object NodeFor(object instance) { }

	// RVA: 0x7146470
	private static object NodeFor(object instance, object createDelegator) { }

	// RVA: 0x7152948
	private static object NodeRemove(object key, object provider) { }

	// RVA: 0x7150898
	private static object PipelineAttributeFilter(object pipelineType, object members, object filter, object instance, object cache) { }

	// RVA: 0x714C19C
	private static object PipelineFilter(object pipelineType, object members, object instance, object cache) { }

	// RVA: 0x714DFAC
	private static object PipelineInitialize(object pipelineType, object members, object cache) { }

	// RVA: 0x714AB6C
	private static object PipelineMerge(object pipelineType, object primary, object secondary, object instance, object cache) { }

	// RVA: 0x7153618
	private static object RaiseRefresh(object component) { }

	// RVA: 0x71536F0
	private static object RaiseRefresh(object type) { }

	// RVA: 0x71537C8
	public static object Refresh(object component) { }

	// RVA: 0x71467D0
	private static object Refresh(object component, object refreshReflectionProvider) { }

	// RVA: 0x7145D88
	public static object Refresh(object type) { }

	// RVA: 0x7153850
	public static object Refresh(object module) { }

	// RVA: 0x71543F0
	public static object Refresh(object assembly) { }

	// RVA: 0x71544D0
	public static object RemoveAssociation(object primary, object secondary) { }

	// RVA: 0x7154924
	public static object RemoveAssociations(object primary) { }

	// RVA: 0x7154A1C
	public static object RemoveProvider(object provider, object type) { }

	// RVA: 0x7154B30
	public static object RemoveProvider(object provider, object instance) { }

	// RVA: 0x7154C10
	public static object RemoveProviderTransparent(object provider, object type) { }

	// RVA: 0x7154D34
	public static object RemoveProviderTransparent(object provider, object instance) { }

	// RVA: 0x71497BC
	private static object ShouldHideMember(object member, object attribute) { }

	// RVA: 0x7154E24
	public static object SortDescriptorArray(object infos) { }

	// RVA: 0x7154F1C
	internal static object Trace(object message, object args) { }

	// RVA: 0x7154F20
	private static object .cctor() { }

}

// Namespace: System.ComponentModel
public class Win32Exception
{

	// Fields
	private readonly object nativeErrorCode; // 0x84

	// Properties
	public object NativeErrorCode { get; }

	// Methods

	// RVA: 0x715C9A0
	public object .ctor() { }

	// RVA: 0x715CA20
	public object .ctor(object error) { }

	// RVA: 0x715D864
	public object .ctor(object error, object message) { }

	// RVA: 0x715D894
	protected object .ctor(object info, object context) { }

	// RVA: 0x715D930
	public object get_NativeErrorCode() { }

	// RVA: 0x715D938
	public override object GetObjectData(object info, object context) { }

	// RVA: 0x715CA5C
	internal static object GetErrorMessage(object error) { }

}

// Namespace: System.ComponentModel
public enum RefreshProperties
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object All;
	public const object Repaint;
}

// Namespace: System.ComponentModel
public sealed class RefreshPropertiesAttribute
{

	// Fields
	public static readonly object All; // 0x0
	public static readonly object Repaint; // 0x8
	public static readonly object Default; // 0x10
	private object refresh; // 0x8

	// Properties
	public object RefreshProperties { get; }

	// Methods

	// RVA: 0x715DA0C
	public object .ctor(object refresh) { }

	// RVA: 0x715DA38
	public object get_RefreshProperties() { }

	// RVA: 0x715DA40
	public override object Equals(object value) { }

	// RVA: 0x715DAC8
	public override object GetHashCode() { }

	// RVA: 0x715DAD0
	public override object IsDefaultAttribute() { }

	// RVA: 0x715DB84
	private static object .cctor() { }

}

// Namespace: 
private class WeakKeyComparer
{

	// Methods

	// RVA: 0x715E4F4
	private object System.Collections.IEqualityComparer.Equals(object x, object y) { }

	// RVA: 0x715E6CC
	private object System.Collections.IEqualityComparer.GetHashCode(object obj) { }

	// RVA: 0x715E4EC
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualityWeakReference
{

	// Fields
	private object _hashCode; // 0x18

	// Methods

	// RVA: 0x715E410
	internal object .ctor(object o) { }

	// RVA: 0x715E718
	public override object Equals(object o) { }

	// RVA: 0x715E7E4
	public override object GetHashCode() { }

}

// Namespace: System.ComponentModel
internal sealed class WeakHashtable
{

	// Fields
	private static object _comparer; // 0x0
	private object _lastGlobalMem; // 0x48
	private object _lastHashCount; // 0x50

	// Methods

	// RVA: 0x7148434
	internal object .ctor() { }

	// RVA: 0x715DC30
	public override object Clear() { }

	// RVA: 0x715DC38
	public override object Remove(object key) { }

	// RVA: 0x71466F0
	public object SetWeak(object key, object value) { }

	// RVA: 0x715DC40
	private object ScavengeKeys() { }

	// RVA: 0x715E470
	private static object .cctor() { }

}

// Namespace: System.ComponentModel.Design
public class CheckoutException
{

	// Fields
	public static readonly object Canceled; // 0x0

	// Methods

	// RVA: 0x715E7EC
	public object .ctor() { }

	// RVA: 0x715E7F4
	public object .ctor(object message, object errorCode) { }

	// RVA: 0x715E7FC
	protected object .ctor(object info, object context) { }

	// RVA: 0x715E804
	private static object .cctor() { }

}

// Namespace: System.ComponentModel.Design
public interface IComponentChangeService
{

	// Methods

	// RVA: -1
	public abstract object OnComponentChanged(object component, object member, object oldValue, object newValue) { }

	// RVA: -1
	public abstract object OnComponentChanging(object component, object member) { }

}

// Namespace: System.ComponentModel.Design
public interface IDesigner
{
}

// Namespace: System.ComponentModel.Design
public interface IDesignerHost
{

	// Properties
	public abstract object RootComponent { get; }

	// Methods

	// RVA: -1
	public abstract object get_RootComponent() { }

	// RVA: -1
	public abstract object GetDesigner(object component) { }

}

// Namespace: System.ComponentModel.Design
public interface IDictionaryService
{

	// Methods

	// RVA: -1
	public abstract object GetValue(object key) { }

	// RVA: -1
	public abstract object SetValue(object key, object value) { }

}

// Namespace: System.ComponentModel.Design
public interface IExtenderListService
{

	// Methods

	// RVA: -1
	public abstract object GetExtenderProviders() { }

}

// Namespace: System.ComponentModel.Design
public interface IReferenceService
{

	// Methods

	// RVA: -1
	public abstract object GetReference(object name) { }

	// RVA: -1
	public abstract object GetName(object reference) { }

	// RVA: -1
	public abstract object GetReferences(object baseType) { }

}

// Namespace: System.ComponentModel.Design
public interface ITypeDescriptorFilterService
{

	// Methods

	// RVA: -1
	public abstract object FilterAttributes(object component, object attributes) { }

	// RVA: -1
	public abstract object FilterEvents(object component, object events) { }

	// RVA: -1
	public abstract object FilterProperties(object component, object properties) { }

}

// Namespace: System.ComponentModel.Design
public interface ITypeResolutionService
{

	// Methods

	// RVA: -1
	public abstract object GetType(object name) { }

}

// Namespace: System.ComponentModel.Design.Serialization
public sealed class InstanceDescriptor
{

	// Fields
	private readonly object <Arguments>k__BackingField; // 0x8
	private readonly object <IsComplete>k__BackingField; // 0x10
	private readonly object <MemberInfo>k__BackingField; // 0x18

	// Properties
	public object Arguments { get; }
	public object MemberInfo { get; }

	// Methods

	// RVA: 0x715E88C
	public object .ctor(object member, object arguments) { }

	// RVA: 0x715E894
	public object .ctor(object member, object arguments, object isComplete) { }

	// RVA: 0x715EF54
	public object get_Arguments() { }

	// RVA: 0x715EF5C
	public object get_MemberInfo() { }

	// RVA: 0x71429EC
	public object Invoke() { }

}

// Namespace: System.ComponentModel.Design.Serialization
public sealed class RootDesignerSerializerAttribute
{

	// Fields
	private object _typeId; // 0x8
	private readonly object <Reloadable>k__BackingField; // 0x10
	private readonly object <SerializerTypeName>k__BackingField; // 0x18
	private readonly object <SerializerBaseTypeName>k__BackingField; // 0x20

	// Properties
	public object SerializerBaseTypeName { get; }
	public override object TypeId { get; }

	// Methods

	// RVA: 0x715EF64
	public object .ctor(object serializerTypeName, object baseSerializerTypeName, object reloadable) { }

	// RVA: 0x715EFA4
	public object get_SerializerBaseTypeName() { }

	// RVA: 0x715EFAC
	public override object get_TypeId() { }

}

// Namespace: System.Collections
internal static class HashtableExtensions
{

	// Methods

	// RVA: -1
	public static object TryGetValue(object table, object key, object value) { }

}

// Namespace: System.Collections.Specialized
public struct BitVector32
{

	// Fields
	private object _data; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: 0x715F088
	public object get_Item(object bit) { }

	// RVA: 0x715F0A8
	public object set_Item(object bit, object value) { }

	// RVA: 0x715F0E0
	public static object CreateMask() { }

	// RVA: 0x715F0E8
	public static object CreateMask(object previous) { }

	// RVA: 0x715F15C
	public override object Equals(object o) { }

	// RVA: 0x715F2AC
	public override object GetHashCode() { }

	// RVA: 0x715F38C
	public static object ToString(object value) { }

	// RVA: 0x715F6D8
	public override object ToString() { }

}

// Namespace: System.Collections.Specialized
public class NameValueCollection
{

	// Fields
	private object _all; // 0x48
	private object _allKeys; // 0x50

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: 0x715F6E8
	public object .ctor() { }

	// RVA: 0x715F878
	public object .ctor(object capacity, object equalityComparer) { }

	// RVA: 0x715F9B8
	protected object .ctor(object info, object context) { }

	// RVA: 0x715FA54
	protected object InvalidateCachedArrays() { }

	// RVA: 0x715FA5C
	private static object GetAsOneString(object list) { }

	// RVA: 0x715FC94
	private static object GetAsStringArray(object list) { }

	// RVA: 0x715FD78
	public virtual object Add(object name, object value) { }

	// RVA: 0x716010C
	public virtual object Get(object name) { }

	// RVA: 0x71601A8
	public virtual object GetValues(object name) { }

	// RVA: 0x7160244
	public virtual object Set(object name, object value) { }

	// RVA: 0x716040C
	public virtual object Remove(object name) { }

	// RVA: 0x716072C
	public object get_Item(object name) { }

	// RVA: 0x7160778
	public object set_Item(object name, object value) { }

	// RVA: 0x71607D4
	public virtual object Get(object index) { }

	// RVA: 0x716093C
	public virtual object GetKey(object index) { }

	// RVA: 0x7160A14
	internal object .ctor(object dummy) { }

}

// Namespace: 
private class OrderedDictionaryEnumerator
{

	// Fields
	private object _objectReturnType; // 0x8
	private object _arrayEnumerator; // 0x10

	// Properties
	public object Current { get; }
	public object Entry { get; }
	public object Key { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x71616E4
	internal object .ctor(object array, object objectReturnType) { }

	// RVA: 0x7161FD4
	public object get_Current() { }

	// RVA: 0x7162230
	public object get_Entry() { }

	// RVA: 0x716243C
	public object get_Key() { }

	// RVA: 0x7162564
	public object get_Value() { }

	// RVA: 0x716268C
	public object MoveNext() { }

	// RVA: 0x716276C
	public object Reset() { }

}

// Namespace: 
private class OrderedDictionaryKeyValueCollection
{

	// Fields
	private object _objects; // 0x8
	private object _isKeys; // 0x10

	// Properties
	private object System.Collections.ICollection.Count { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: 0x7160D68
	public object .ctor(object array, object isKeys) { }

	// RVA: 0x7162850
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x7162CB4
	private object System.Collections.ICollection.get_Count() { }

	// RVA: 0x7162D04
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x7162D0C
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x7162D5C
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Collections.Specialized
public class OrderedDictionary
{

	// Fields
	private object _objectsArray; // 0x8
	private object _objectsTable; // 0x10
	private object _initialCapacity; // 0x18
	private object _comparer; // 0x20
	private object _readOnly; // 0x28
	private object _syncRoot; // 0x30
	private object _siInfo; // 0x38
	private const object KeyComparerName;
	private const object ArrayListName;
	private const object ReadOnlyName;
	private const object InitCapacityName;

	// Properties
	public object Count { get; }
	private object System.Collections.IDictionary.IsFixedSize { get; }
	public object IsReadOnly { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	public object Keys { get; }
	private object objectsArray { get; }
	private object objectsTable { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	public object Item { get; set; }
	public object Values { get; }

	// Methods

	// RVA: 0x7160AA4
	public object .ctor() { }

	// RVA: 0x7152E60
	public object .ctor(object capacity) { }

	// RVA: 0x7160AD0
	public object .ctor(object capacity, object comparer) { }

	// RVA: 0x7160B0C
	protected object .ctor(object info, object context) { }

	// RVA: 0x7160B38
	public object get_Count() { }

	// RVA: 0x7160C70
	private object System.Collections.IDictionary.get_IsFixedSize() { }

	// RVA: 0x7160C78
	public object get_IsReadOnly() { }

	// RVA: 0x7160C80
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x7160C88
	public object get_Keys() { }

	// RVA: 0x7160BE0
	private object get_objectsArray() { }

	// RVA: 0x7160DA4
	private object get_objectsTable() { }

	// RVA: 0x7160E3C
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x7153234
	public object get_Item(object key) { }

	// RVA: 0x7152E90
	public object set_Item(object key, object value) { }

	// RVA: 0x7153504
	public object get_Values() { }

	// RVA: 0x7161158
	public object Add(object key, object value) { }

	// RVA: 0x7161364
	public object Clear() { }

	// RVA: 0x7153174
	public object Contains(object key) { }

	// RVA: 0x71614F0
	public object CopyTo(object array, object index) { }

	// RVA: 0x7160EC8
	private object IndexOfKey(object key) { }

	// RVA: 0x71532F4
	public object Remove(object key) { }

	// RVA: 0x71615B8
	public virtual object GetEnumerator() { }

	// RVA: 0x7161758
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x7161884
	public virtual object GetObjectData(object info, object context) { }

	// RVA: 0x7161A74
	private object System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object sender) { }

	// RVA: 0x7161AC0
	protected virtual object OnDeserialization(object sender) { }

}

// Namespace: System.Collections.Specialized
public class StringCollection
{

	// Fields
	private readonly object data; // 0x8

	// Properties
	public object Item { get; set; }
	public object Count { get; }
	private object System.Collections.IList.IsReadOnly { get; }
	private object System.Collections.IList.IsFixedSize { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }
	private object System.Collections.IList.Item { get; set; }

	// Methods

	// RVA: 0x7162E14
	public object get_Item(object index) { }

	// RVA: 0x7162EBC
	public object set_Item(object index, object value) { }

	// RVA: 0x7162F24
	public object get_Count() { }

	// RVA: 0x7162F74
	private object System.Collections.IList.get_IsReadOnly() { }

	// RVA: 0x7162F7C
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: 0x7162F84
	public object Add(object value) { }

	// RVA: 0x7162FDC
	public object Clear() { }

	// RVA: 0x716302C
	public object Contains(object value) { }

	// RVA: 0x7163084
	public object CopyTo(object array, object index) { }

	// RVA: 0x71630EC
	public object IndexOf(object value) { }

	// RVA: 0x7163144
	public object Insert(object index, object value) { }

	// RVA: 0x71631AC
	public object get_IsSynchronized() { }

	// RVA: 0x71631B4
	public object Remove(object value) { }

	// RVA: 0x716320C
	public object RemoveAt(object index) { }

	// RVA: 0x7163264
	public object get_SyncRoot() { }

	// RVA: 0x71632B4
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: 0x716335C
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: 0x716340C
	private object System.Collections.IList.Add(object value) { }

	// RVA: 0x71634B4
	private object System.Collections.IList.Contains(object value) { }

	// RVA: 0x716355C
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: 0x7163604
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: 0x71636B4
	private object System.Collections.IList.Remove(object value) { }

	// RVA: 0x716375C
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x71637C4
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x7163814
	public object .ctor() { }

}

// Namespace: System.Collections.Specialized
public enum NotifyCollectionChangedAction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object Remove;
	public const object Replace;
	public const object Move;
	public const object Reset;
}

// Namespace: System.Collections.Specialized
public class NotifyCollectionChangedEventArgs
{

	// Fields
	private object _action; // 0x8
	private object _newItems; // 0x10
	private object _oldItems; // 0x18
	private object _newStartingIndex; // 0x20
	private object _oldStartingIndex; // 0x24

	// Methods

	// RVA: 0x7163880
	public object .ctor(object action) { }

	// RVA: 0x7163A78
	public object .ctor(object action, object changedItem, object index) { }

	// RVA: 0x7163DAC
	public object .ctor(object action, object newItem, object oldItem, object index) { }

	// RVA: 0x71640C4
	public object .ctor(object action, object newItems, object oldItems, object startingIndex) { }

	// RVA: 0x7163C9C
	private object InitializeAddOrRemove(object action, object changedItems, object startingIndex) { }

	// RVA: 0x71639E8
	private object InitializeAdd(object action, object newItems, object newStartingIndex) { }

	// RVA: 0x716429C
	private object InitializeRemove(object action, object oldItems, object oldStartingIndex) { }

	// RVA: 0x7163FC0
	private object InitializeMoveOrReplace(object action, object newItems, object oldItems, object startingIndex, object oldStartingIndex) { }

}

// Namespace: System.Collections.Specialized
public sealed class NotifyCollectionChangedEventHandler
{

	// Methods

	// RVA: 0x716465C
	public object .ctor(object object, object method) { }

	// RVA: 0x7164768
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Collections.Specialized
internal sealed class ReadOnlyList
{

	// Fields
	private readonly object _list; // 0x8

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }
	public object IsFixedSize { get; }
	public object IsSynchronized { get; }
	public object Item { get; set; }
	public object SyncRoot { get; }

	// Methods

	// RVA: 0x716432C
	internal object .ctor(object list) { }

	// RVA: 0x716477C
	public object get_Count() { }

	// RVA: 0x7164860
	public object get_IsReadOnly() { }

	// RVA: 0x7164868
	public object get_IsFixedSize() { }

	// RVA: 0x7164870
	public object get_IsSynchronized() { }

	// RVA: 0x7164954
	public object get_Item(object index) { }

	// RVA: 0x7164A28
	public object set_Item(object index, object value) { }

	// RVA: 0x7164A7C
	public object get_SyncRoot() { }

	// RVA: 0x7164B60
	public object Add(object value) { }

	// RVA: 0x7164BB4
	public object Clear() { }

	// RVA: 0x7164C08
	public object Contains(object value) { }

	// RVA: 0x7164CE0
	public object CopyTo(object array, object index) { }

	// RVA: 0x7164DC4
	public object GetEnumerator() { }

	// RVA: 0x7164EA4
	public object IndexOf(object value) { }

	// RVA: 0x7164F7C
	public object Insert(object index, object value) { }

	// RVA: 0x7164FD0
	public object Remove(object value) { }

	// RVA: 0x7165024
	public object RemoveAt(object index) { }

}

// Namespace: 
internal class NameObjectEntry
{

	// Fields
	internal object Key; // 0x8
	internal object Value; // 0x10

	// Methods

	// RVA: 0x71664E4
	internal object .ctor(object name, object value) { }

}

// Namespace: 
internal class NameObjectKeysEnumerator
{

	// Fields
	private object _pos; // 0x8
	private object _coll; // 0x10
	private object _version; // 0x18

	// Properties
	public object Current { get; }

	// Methods

	// RVA: 0x71665A4
	internal object .ctor(object coll) { }

	// RVA: 0x7166B60
	public object MoveNext() { }

	// RVA: 0x7166C88
	public object Reset() { }

	// RVA: 0x7166D1C
	public object get_Current() { }

}

// Namespace: System.Collections.Specialized
public abstract class NameObjectCollectionBase
{

	// Fields
	private object _readOnly; // 0x8
	private object _entriesArray; // 0x10
	private object _keyComparer; // 0x18
	private object _entriesTable; // 0x20
	private object _nullKeyEntry; // 0x28
	private object _serializationInfo; // 0x30
	private object _version; // 0x38
	private object _syncRoot; // 0x40
	private static object defaultComparer; // 0x0

	// Properties
	protected object IsReadOnly { get; }
	public virtual object Count { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }

	// Methods

	// RVA: 0x715F768
	protected object .ctor() { }

	// RVA: 0x7165078
	protected object .ctor(object equalityComparer) { }

	// RVA: 0x715F8F0
	protected object .ctor(object capacity, object equalityComparer) { }

	// RVA: 0x7160A9C
	internal object .ctor(object dummy) { }

	// RVA: 0x715FA28
	protected object .ctor(object info, object context) { }

	// RVA: 0x71652A4
	public virtual object GetObjectData(object info, object context) { }

	// RVA: 0x7165B7C
	public virtual object OnDeserialization(object sender) { }

	// RVA: 0x7165130
	private object Reset() { }

	// RVA: 0x71651E0
	private object Reset(object capacity) { }

	// RVA: 0x71663F4
	private object FindEntry(object key) { }

	// RVA: 0x71664DC
	protected object get_IsReadOnly() { }

	// RVA: 0x715FF4C
	protected object BaseAdd(object name, object value) { }

	// RVA: 0x7160414
	protected object BaseRemove(object name) { }

	// RVA: 0x715FF30
	protected object BaseGet(object name) { }

	// RVA: 0x7160350
	protected object BaseSet(object name, object value) { }

	// RVA: 0x7160868
	protected object BaseGet(object index) { }

	// RVA: 0x7160940
	protected object BaseGetKey(object index) { }

	// RVA: 0x716651C
	public virtual object GetEnumerator() { }

	// RVA: 0x71665F0
	public virtual object get_Count() { }

	// RVA: 0x7166640
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x71669F0
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x7166A7C
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x7166A84
	private static object .cctor() { }

}

// Namespace: System.Collections.Specialized
internal class CompatibleComparer
{

	// Fields
	private object _comparer; // 0x8
	private static object defaultComparer; // 0x0
	private object _hcp; // 0x10
	private static object defaultHashProvider; // 0x8

	// Properties
	public object Comparer { get; }
	public object HashCodeProvider { get; }
	public static object DefaultComparer { get; }
	public static object DefaultHashCodeProvider { get; }

	// Methods

	// RVA: 0x71663BC
	internal object .ctor(object comparer, object hashCodeProvider) { }

	// RVA: 0x7166DF4
	public object Equals(object a, object b) { }

	// RVA: 0x7167054
	public object GetHashCode(object obj) { }

	// RVA: 0x7167198
	public object get_Comparer() { }

	// RVA: 0x71671A0
	public object get_HashCodeProvider() { }

	// RVA: 0x7165A88
	public static object get_DefaultComparer() { }

	// RVA: 0x7165994
	public static object get_DefaultHashCodeProvider() { }

}

// Namespace: System.Collections.Generic
internal struct ValueListBuilder<T0>
{

	// Fields
	private object _span; // 0x0
	private object _arrayFromPool; // 0x0
	private object _pos; // 0x0

	// Properties
	public object Length { get; }
	public object Item { get; }

	// Methods

	// RVA: -1
	public object .ctor(object initialSpan) { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object Append(object item) { }

	// RVA: -1
	public object AsSpan() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object Grow() { }

	// RVA: -1
	public object Pop() { }

}

// Namespace: System.Collections.Generic
internal sealed class ICollectionDebugView<T0>
{
}

// Namespace: System.Collections.Generic
internal sealed class IDictionaryDebugView<T0, T1>
{
}

// Namespace: System.Collections.Generic
internal sealed class DictionaryKeyCollectionDebugView<T0, T1>
{
}

// Namespace: System.Collections.Generic
internal sealed class DictionaryValueCollectionDebugView<T0, T1>
{
}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object _list; // 0x0
	private object _node; // 0x0
	private object _version; // 0x0
	private object _current; // 0x0
	private object _index; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object list) { }

	// RVA: -1
	private object .ctor(object info, object context) { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object info, object context) { }

	// RVA: -1
	private object System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object sender) { }

}

// Namespace: System.Collections.Generic
public class LinkedList<T0>
{

	// Fields
	internal object head; // 0x0
	internal object count; // 0x0
	internal object version; // 0x0
	private object _syncRoot; // 0x0
	private object _siInfo; // 0x0
	private const object VersionName;
	private const object CountName;
	private const object ValuesName;

	// Properties
	public object Count { get; }
	public object First { get; }
	public object Last { get; }
	private object System.Collections.Generic.ICollection<T>.IsReadOnly { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object collection) { }

	// RVA: -1
	protected object .ctor(object info, object context) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_First() { }

	// RVA: -1
	public object get_Last() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<T>.Add(object value) { }

	// RVA: -1
	public object AddBefore(object node, object value) { }

	// RVA: -1
	public object AddFirst(object value) { }

	// RVA: -1
	public object AddLast(object value) { }

	// RVA: -1
	public object AddLast(object node) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object value) { }

	// RVA: -1
	public object CopyTo(object array, object index) { }

	// RVA: -1
	public object Find(object value) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	public object Remove(object value) { }

	// RVA: -1
	public object Remove(object node) { }

	// RVA: -1
	public object RemoveFirst() { }

	// RVA: -1
	public object RemoveLast() { }

	// RVA: -1
	public virtual object GetObjectData(object info, object context) { }

	// RVA: -1
	public virtual object OnDeserialization(object sender) { }

	// RVA: -1
	private object InternalInsertNodeBefore(object node, object newNode) { }

	// RVA: -1
	private object InternalInsertNodeToEmptyList(object newNode) { }

	// RVA: -1
	internal object InternalRemoveNode(object node) { }

	// RVA: -1
	internal object ValidateNewNode(object node) { }

	// RVA: -1
	internal object ValidateNode(object node) { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Collections.Generic
public sealed class LinkedListNode<T0>
{

	// Fields
	internal object list; // 0x0
	internal object next; // 0x0
	internal object prev; // 0x0
	internal object item; // 0x0

	// Properties
	public object List { get; }
	public object Next { get; }
	public object Value { get; set; }

	// Methods

	// RVA: -1
	public object .ctor(object value) { }

	// RVA: -1
	internal object .ctor(object list, object value) { }

	// RVA: -1
	public object get_List() { }

	// RVA: -1
	public object get_Next() { }

	// RVA: -1
	public object get_Value() { }

	// RVA: -1
	public object set_Value(object value) { }

	// RVA: -1
	internal object Invalidate() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object _treeEnum; // 0x0
	private object _getEnumeratorRetType; // 0x0

	// Properties
	public object Current { get; }
	internal object NotStartedOrEnded { get; }
	private object System.Collections.IEnumerator.Current { get; }
	private object System.Collections.IDictionaryEnumerator.Key { get; }
	private object System.Collections.IDictionaryEnumerator.Value { get; }
	private object System.Collections.IDictionaryEnumerator.Entry { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary, object getEnumeratorRetType) { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	internal object get_NotStartedOrEnded() { }

	// RVA: -1
	internal object Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IDictionaryEnumerator.get_Key() { }

	// RVA: -1
	private object System.Collections.IDictionaryEnumerator.get_Value() { }

	// RVA: -1
	private object System.Collections.IDictionaryEnumerator.get_Entry() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object _dictEnum; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: 
private sealed class <>c__DisplayClass5_0
{

	// Fields
	public object array; // 0x0
	public object index; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CopyTo>b__0(object node) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object index; // 0x0
	public object objects; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <System.Collections.ICollection.CopyTo>b__0(object node) { }

}

// Namespace: 
public sealed class KeyCollection
{

	// Fields
	private object _dictionary; // 0x0

	// Properties
	public object Count { get; }
	private object System.Collections.Generic.ICollection<TKey>.IsReadOnly { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: -1
	public object .ctor(object dictionary) { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TKey>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object CopyTo(object array, object index) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TKey>.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TKey>.Add(object item) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TKey>.Clear() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TKey>.Contains(object item) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TKey>.Remove(object item) { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object _dictEnum; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: 
private sealed class <>c__DisplayClass5_0
{

	// Fields
	public object array; // 0x0
	public object index; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CopyTo>b__0(object node) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object index; // 0x0
	public object objects; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <System.Collections.ICollection.CopyTo>b__0(object node) { }

}

// Namespace: 
public sealed class ValueCollection
{

	// Fields
	private object _dictionary; // 0x0

	// Properties
	public object Count { get; }
	private object System.Collections.Generic.ICollection<TValue>.IsReadOnly { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: -1
	public object .ctor(object dictionary) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TValue>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object CopyTo(object array, object index) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TValue>.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TValue>.Add(object item) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TValue>.Clear() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TValue>.Contains(object item) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TValue>.Remove(object item) { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

}

// Namespace: 
internal sealed class KeyValuePairComparer
{

	// Fields
	internal object keyComparer; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object keyComparer) { }

	// RVA: -1
	public override object Compare(object x, object y) { }

}

// Namespace: 
private sealed class <>c__DisplayClass34_0
{

	// Fields
	public object found; // 0x0
	public object value; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <ContainsValue>b__0(object node) { }

}

// Namespace: 
private sealed class <>c__DisplayClass34_1
{

	// Fields
	public object valueComparer; // 0x0
	public object CS$<>8__locals1; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <ContainsValue>b__1(object node) { }

}

// Namespace: System.Collections.Generic
public class SortedDictionary<T0, T1>
{

	// Fields
	private object _keys; // 0x0
	private object _values; // 0x0
	private object _set; // 0x0

	// Properties
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.IsReadOnly { get; }
	public object Item { get; set; }
	public object Count { get; }
	public object Keys { get; }
	private object System.Collections.Generic.IDictionary<TKey,TValue>.Keys { get; }
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Keys { get; }
	public object Values { get; }
	private object System.Collections.Generic.IDictionary<TKey,TValue>.Values { get; }
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Values { get; }
	private object System.Collections.IDictionary.IsFixedSize { get; }
	private object System.Collections.IDictionary.IsReadOnly { get; }
	private object System.Collections.IDictionary.Keys { get; }
	private object System.Collections.IDictionary.Values { get; }
	private object System.Collections.IDictionary.Item { get; set; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Add(object keyValuePair) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Contains(object keyValuePair) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Remove(object keyValuePair) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_IsReadOnly() { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Keys() { }

	// RVA: -1
	private object System.Collections.Generic.IDictionary<TKey,TValue>.get_Keys() { }

	// RVA: -1
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Keys() { }

	// RVA: -1
	public object get_Values() { }

	// RVA: -1
	private object System.Collections.Generic.IDictionary<TKey,TValue>.get_Values() { }

	// RVA: -1
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Values() { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object ContainsValue(object value) { }

	// RVA: -1
	public object CopyTo(object array, object index) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	private object System.Collections.IDictionary.get_IsFixedSize() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Keys() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Values() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Item(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.set_Item(object key, object value) { }

	// RVA: -1
	private object System.Collections.IDictionary.Add(object key, object value) { }

	// RVA: -1
	private object System.Collections.IDictionary.Contains(object key) { }

	// RVA: -1
	private static object IsCompatibleKey(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IDictionary.Remove(object key) { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Collections.Generic
internal sealed class TreeSet<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	public object .ctor(object siInfo, object context) { }

	// RVA: -1
	internal override object AddIfNotPresent(object item) { }

}

// Namespace: 
private struct Enumerator
{

	// Fields
	private object _sortedList; // 0x0
	private object _key; // 0x0
	private object _value; // 0x0
	private object _index; // 0x0
	private object _version; // 0x0
	private object _getEnumeratorRetType; // 0x0

	// Properties
	private object System.Collections.IDictionaryEnumerator.Key { get; }
	private object System.Collections.IDictionaryEnumerator.Entry { get; }
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }
	private object System.Collections.IDictionaryEnumerator.Value { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object sortedList, object getEnumeratorRetType) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object System.Collections.IDictionaryEnumerator.get_Key() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	private object System.Collections.IDictionaryEnumerator.get_Entry() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IDictionaryEnumerator.get_Value() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: 
private sealed class SortedListKeyEnumerator
{

	// Fields
	private object _sortedList; // 0x0
	private object _index; // 0x0
	private object _version; // 0x0
	private object _currentKey; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object sortedList) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: 
private sealed class SortedListValueEnumerator
{

	// Fields
	private object _sortedList; // 0x0
	private object _index; // 0x0
	private object _version; // 0x0
	private object _currentValue; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object sortedList) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: 
private sealed class KeyList
{

	// Fields
	private object _dict; // 0x0

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	public object Add(object key) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object key) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object Insert(object index, object value) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object IndexOf(object key) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object RemoveAt(object index) { }

}

// Namespace: 
private sealed class ValueList
{

	// Fields
	private object _dict; // 0x0

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	internal object .ctor(object dictionary) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	public object Add(object key) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object value) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	public object Insert(object index, object value) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object IndexOf(object value) { }

	// RVA: -1
	public object Remove(object value) { }

	// RVA: -1
	public object RemoveAt(object index) { }

}

// Namespace: System.Collections.Generic
public class SortedList<T0, T1>
{

	// Fields
	private object keys; // 0x0
	private object values; // 0x0
	private object _size; // 0x0
	private object version; // 0x0
	private object comparer; // 0x0
	private object keyList; // 0x0
	private object valueList; // 0x0
	private object _syncRoot; // 0x0

	// Properties
	public object Capacity { set; }
	public object Count { get; }
	public object Keys { get; }
	private object System.Collections.Generic.IDictionary<TKey,TValue>.Keys { get; }
	private object System.Collections.IDictionary.Keys { get; }
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Keys { get; }
	public object Values { get; }
	private object System.Collections.Generic.IDictionary<TKey,TValue>.Values { get; }
	private object System.Collections.IDictionary.Values { get; }
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Values { get; }
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.IsReadOnly { get; }
	private object System.Collections.IDictionary.IsReadOnly { get; }
	private object System.Collections.IDictionary.IsFixedSize { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	public object Item { get; set; }
	private object System.Collections.IDictionary.Item { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Add(object keyValuePair) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Contains(object keyValuePair) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Remove(object keyValuePair) { }

	// RVA: -1
	public object set_Capacity(object value) { }

	// RVA: -1
	private object System.Collections.IDictionary.Add(object key, object value) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Keys() { }

	// RVA: -1
	private object System.Collections.Generic.IDictionary<TKey,TValue>.get_Keys() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Keys() { }

	// RVA: -1
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Keys() { }

	// RVA: -1
	public object get_Values() { }

	// RVA: -1
	private object System.Collections.Generic.IDictionary<TKey,TValue>.get_Values() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Values() { }

	// RVA: -1
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Values() { }

	// RVA: -1
	private object GetKeyListHelper() { }

	// RVA: -1
	private object GetValueListHelper() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_IsFixedSize() { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	private object System.Collections.IDictionary.Contains(object key) { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object ContainsValue(object value) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	private object EnsureCapacity(object min) { }

	// RVA: -1
	private object GetByIndex(object index) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IDictionary.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object GetKey(object index) { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Item(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.set_Item(object key, object value) { }

	// RVA: -1
	public object IndexOfKey(object key) { }

	// RVA: -1
	public object IndexOfValue(object value) { }

	// RVA: -1
	private object Insert(object index, object key, object value) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.Remove(object key) { }

	// RVA: -1
	private static object IsCompatibleKey(object key) { }

}

// Namespace: 
internal sealed class Node
{

	// Fields
	private object <Item>k__BackingField; // 0x0
	private object <Left>k__BackingField; // 0x0
	private object <Right>k__BackingField; // 0x0
	private object <Color>k__BackingField; // 0x0

	// Properties
	public object Item { get; set; }
	public object Left { get; set; }
	public object Right { get; set; }
	public object Color { get; set; }
	public object IsBlack { get; }
	public object IsRed { get; }
	public object Is2Node { get; }
	public object Is4Node { get; }

	// Methods

	// RVA: -1
	public object .ctor(object item, object color) { }

	// RVA: -1
	public static object IsNonNullRed(object node) { }

	// RVA: -1
	public static object IsNullOrBlack(object node) { }

	// RVA: -1
	public object get_Item() { }

	// RVA: -1
	public object set_Item(object value) { }

	// RVA: -1
	public object get_Left() { }

	// RVA: -1
	public object set_Left(object value) { }

	// RVA: -1
	public object get_Right() { }

	// RVA: -1
	public object set_Right(object value) { }

	// RVA: -1
	public object get_Color() { }

	// RVA: -1
	public object set_Color(object value) { }

	// RVA: -1
	public object get_IsBlack() { }

	// RVA: -1
	public object get_IsRed() { }

	// RVA: -1
	public object get_Is2Node() { }

	// RVA: -1
	public object get_Is4Node() { }

	// RVA: -1
	public object ColorBlack() { }

	// RVA: -1
	public object ColorRed() { }

	// RVA: -1
	public object GetRotation(object current, object sibling) { }

	// RVA: -1
	public object GetSibling(object node) { }

	// RVA: -1
	public object Split4Node() { }

	// RVA: -1
	public object Rotate(object rotation) { }

	// RVA: -1
	public object RotateLeft() { }

	// RVA: -1
	public object RotateLeftRight() { }

	// RVA: -1
	public object RotateRight() { }

	// RVA: -1
	public object RotateRightLeft() { }

	// RVA: -1
	public object Merge2Nodes() { }

	// RVA: -1
	public object ReplaceChild(object child, object newChild) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private static readonly object s_dummyNode; // 0x0
	private object _tree; // 0x0
	private object _version; // 0x0
	private object _stack; // 0x0
	private object _current; // 0x0
	private object _reverse; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }
	internal object NotStartedOrEnded { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object set) { }

	// RVA: -1
	internal object .ctor(object set, object reverse) { }

	// RVA: -1
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object info, object context) { }

	// RVA: -1
	private object System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object sender) { }

	// RVA: -1
	private object Initialize() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	internal object get_NotStartedOrEnded() { }

	// RVA: -1
	internal object Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass52_0
{

	// Fields
	public object index; // 0x0
	public object count; // 0x0
	public object array; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CopyTo>b__0(object node) { }

}

// Namespace: 
private sealed class <>c__DisplayClass53_0
{

	// Fields
	public object index; // 0x0
	public object objects; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <System.Collections.ICollection.CopyTo>b__0(object node) { }

}

// Namespace: System.Collections.Generic
public class SortedSet<T0>
{

	// Fields
	private object root; // 0x0
	private object comparer; // 0x0
	private object count; // 0x0
	private object version; // 0x0
	private object _syncRoot; // 0x0
	private object siInfo; // 0x0
	private const object ComparerName;
	private const object CountName;
	private const object ItemsName;
	private const object VersionName;
	private const object TreeName;
	private const object NodeValueName;
	private const object EnumStartName;
	private const object ReverseName;
	private const object EnumVersionName;
	private const object MinName;
	private const object MaxName;
	private const object LowerBoundActiveName;
	private const object UpperBoundActiveName;
	internal const object StackAllocThreshold;

	// Properties
	public object Count { get; }
	private object System.Collections.Generic.ICollection<T>.IsReadOnly { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	protected object .ctor(object info, object context) { }

	// RVA: -1
	internal virtual object InOrderTreeWalk(object action) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	internal virtual object VersionCheck() { }

	// RVA: -1
	internal virtual object IsWithinRange(object item) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<T>.Add(object item) { }

	// RVA: -1
	internal virtual object AddIfNotPresent(object item) { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	internal virtual object DoRemove(object item) { }

	// RVA: -1
	public virtual object Clear() { }

	// RVA: -1
	public virtual object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object index) { }

	// RVA: -1
	public object CopyTo(object array, object index, object count) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object InsertionBalance(object current, object parent, object grandParent, object greatGrandParent) { }

	// RVA: -1
	private object ReplaceChildOrRoot(object parent, object child, object newChild) { }

	// RVA: -1
	private object ReplaceNode(object match, object parentOfMatch, object successor, object parentOfSuccessor) { }

	// RVA: -1
	internal virtual object FindNode(object item) { }

	// RVA: -1
	internal object UpdateVersion() { }

	// RVA: -1
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object info, object context) { }

	// RVA: -1
	protected virtual object GetObjectData(object info, object context) { }

	// RVA: -1
	private object System.Runtime.Serialization.IDeserializationCallback.OnDeserialization(object sender) { }

	// RVA: -1
	protected virtual object OnDeserialization(object sender) { }

	// RVA: -1
	private static object Log2(object value) { }

}

// Namespace: System.Collections.Generic
internal enum NodeColor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Black;
	public const object Red;
}

// Namespace: System.Collections.Generic
internal sealed class TreeWalkPredicate<T0>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object node) { }

}

// Namespace: System.Collections.Generic
internal enum TreeRotation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object LeftRight;
	public const object Right;
	public const object RightLeft;
}

// Namespace: System.Collections.Generic
public interface ISet<T0>
{
}

// Namespace: System.IO
public class FileSystemEventArgs
{
}

// Namespace: System.IO
public class RenamedEventArgs
{
}

// Namespace: System.IO
public sealed class RenamedEventHandler
{

	// Methods

	// RVA: 0x71674AC
	public object .ctor(object object, object method) { }

	// RVA: 0x71675B8
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.IO.Compression
public enum CompressionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Decompress;
	public const object Compress;
}

// Namespace: System.IO.Compression
public class GZipStream
{

	// Fields
	private object _deflateStream; // 0x20

	// Properties
	public override object CanRead { get; }
	public override object CanWrite { get; }
	public override object CanSeek { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x71675CC
	public object .ctor(object stream, object mode) { }

	// RVA: 0x716767C
	public object .ctor(object stream, object mode, object leaveOpen) { }

	// RVA: 0x7167738
	public override object get_CanRead() { }

	// RVA: 0x7167788
	public override object get_CanWrite() { }

	// RVA: 0x71677D8
	public override object get_CanSeek() { }

	// RVA: 0x7167828
	public override object get_Length() { }

	// RVA: 0x716787C
	public override object get_Position() { }

	// RVA: 0x71678D0
	public override object set_Position(object value) { }

	// RVA: 0x7167924
	public override object Flush() { }

	// RVA: 0x7167984
	public override object Seek(object offset, object origin) { }

	// RVA: 0x71679D8
	public override object SetLength(object value) { }

	// RVA: 0x7167A2C
	public override object ReadByte() { }

	// RVA: 0x7167A74
	public override object BeginRead(object array, object offset, object count, object asyncCallback, object asyncState) { }

	// RVA: 0x7167B44
	public override object EndRead(object asyncResult) { }

	// RVA: 0x7167B98
	public override object Read(object array, object offset, object count) { }

	// RVA: 0x7167C00
	public override object Read(object buffer) { }

	// RVA: 0x7167E48
	public override object BeginWrite(object array, object offset, object count, object asyncCallback, object asyncState) { }

	// RVA: 0x7167F18
	public override object EndWrite(object asyncResult) { }

	// RVA: 0x7167F24
	public override object Write(object array, object offset, object count) { }

	// RVA: 0x7167F8C
	public override object Write(object buffer) { }

	// RVA: 0x71681A8
	public override object CopyTo(object destination, object bufferSize) { }

	// RVA: 0x7168208
	protected override object Dispose(object disposing) { }

	// RVA: 0x71682D0
	public override object ReadAsync(object array, object offset, object count, object cancellationToken) { }

	// RVA: 0x7168348
	public override object ReadAsync(object buffer, object cancellationToken) { }

	// RVA: 0x7168434
	public override object WriteAsync(object array, object offset, object count, object cancellationToken) { }

	// RVA: 0x71684AC
	public override object WriteAsync(object buffer, object cancellationToken) { }

	// RVA: 0x7168598
	public override object FlushAsync(object cancellationToken) { }

	// RVA: 0x716796C
	private object CheckDeflateStream() { }

	// RVA: 0x71685E8
	private static object ThrowStreamClosedException() { }

}

// Namespace: 
private sealed class ReadMethod
{

	// Methods

	// RVA: 0x7169950
	public object .ctor(object object, object method) { }

	// RVA: 0x716A638
	public virtual object Invoke(object array, object offset, object count) { }

	// RVA: 0x7169A00
	public virtual object BeginInvoke(object array, object offset, object count, object callback, object object) { }

	// RVA: 0x716A180
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
private sealed class WriteMethod
{

	// Methods

	// RVA: 0x7169E74
	public object .ctor(object object, object method) { }

	// RVA: 0x716A71C
	public virtual object Invoke(object array, object offset, object count) { }

	// RVA: 0x7169F24
	public virtual object BeginInvoke(object array, object offset, object count, object callback, object object) { }

	// RVA: 0x716A320
	public virtual object EndInvoke(object result) { }

}

// Namespace: System.IO.Compression
public class DeflateStream
{

	// Fields
	private object base_stream; // 0x20
	private object mode; // 0x28
	private object leaveOpen; // 0x2C
	private object disposed; // 0x2D
	private object native; // 0x30

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x7168640
	public object .ctor(object stream, object mode) { }

	// RVA: 0x7167730
	internal object .ctor(object stream, object mode, object leaveOpen, object windowsBits) { }

	// RVA: 0x716864C
	internal object .ctor(object compressedStream, object mode, object leaveOpen, object gzip) { }

	// RVA: 0x7168A34
	protected override object Finalize() { }

	// RVA: 0x7168AF0
	protected override object Dispose(object disposing) { }

	// RVA: 0x7168D30
	private object ReadInternal(object array, object offset, object count) { }

	// RVA: 0x716842C
	internal object ReadAsyncMemory(object destination, object cancellationToken) { }

	// RVA: 0x7167CEC
	internal object ReadCore(object destination) { }

	// RVA: 0x7168E58
	public override object Read(object array, object offset, object count) { }

	// RVA: 0x71690A0
	private object WriteInternal(object array, object offset, object count) { }

	// RVA: 0x7168590
	internal object WriteAsyncMemory(object source, object cancellationToken) { }

	// RVA: 0x71680FC
	internal object WriteCore(object source) { }

	// RVA: 0x71691C0
	public override object Write(object array, object offset, object count) { }

	// RVA: 0x7169424
	public override object Flush() { }

	// RVA: 0x71695B0
	public override object BeginRead(object array, object offset, object count, object asyncCallback, object asyncState) { }

	// RVA: 0x7169AD4
	public override object BeginWrite(object array, object offset, object count, object asyncCallback, object asyncState) { }

	// RVA: 0x7169FF8
	public override object EndRead(object asyncResult) { }

	// RVA: 0x716A1B4
	public override object EndWrite(object asyncResult) { }

	// RVA: 0x716A32C
	public override object Seek(object offset, object origin) { }

	// RVA: 0x716A36C
	public override object SetLength(object value) { }

	// RVA: 0x716A3AC
	public override object get_CanRead() { }

	// RVA: 0x716A418
	public override object get_CanSeek() { }

	// RVA: 0x716A420
	public override object get_CanWrite() { }

	// RVA: 0x716A490
	public override object get_Length() { }

	// RVA: 0x716A4D0
	public override object get_Position() { }

	// RVA: 0x716A510
	public override object set_Position(object value) { }

}

// Namespace: 
private sealed class UnmanagedReadOrWrite
{

	// Methods

	// RVA: 0x716AAA0
	public object .ctor(object object, object method) { }

	// RVA: 0x716B3B0
	public virtual object Invoke(object buffer, object length, object data) { }

}

// Namespace: 
private sealed class SafeDeflateStreamHandle
{

	// Properties
	public override object IsInvalid { get; }

	// Methods

	// RVA: 0x716B3C4
	public override object get_IsInvalid() { }

	// RVA: 0x716B2EC
	private object .ctor() { }

	// RVA: 0x716B3D4
	protected override object ReleaseHandle() { }

}

// Namespace: System.IO.Compression
internal class DeflateStreamNative
{

	// Fields
	private object feeder; // 0x8
	private object base_stream; // 0x10
	private object z_stream; // 0x18
	private object data; // 0x20
	private object disposed; // 0x28
	private object io_buffer; // 0x30
	private object last_error; // 0x38

	// Methods

	// RVA: 0x716AA98
	private object .ctor() { }

	// RVA: 0x71687F8
	public static object Create(object compressedStream, object mode, object gzip) { }

	// RVA: 0x716ABDC
	protected override object Finalize() { }

	// RVA: 0x7168BF4
	public object Dispose(object disposing) { }

	// RVA: 0x71694F8
	public object Flush() { }

	// RVA: 0x7168D84
	public object ReadZStream(object buffer, object length) { }

	// RVA: 0x71690F0
	public object WriteZStream(object buffer, object length) { }

	// RVA: 0x716A818
	private static object UnmanagedRead(object buffer, object length, object data) { }

	// RVA: 0x716AEDC
	private object UnmanagedRead(object buffer, object length) { }

	// RVA: 0x716A9CC
	private static object UnmanagedWrite(object buffer, object length, object data) { }

	// RVA: 0x716B0DC
	private object UnmanagedWrite(object buffer, object length) { }

	// RVA: 0x716ACE4
	private object CheckResult(object result, object where) { }

	// RVA: 0x716AB38
	private static extern object CreateZStream(object compress, object gzip, object feeder, object data) { }

	// RVA: 0x716B2FC
	private static extern object CloseZStream(object stream) { }

	// RVA: 0x716AC70
	private static extern object Flush(object stream) { }

	// RVA: 0x716ADC4
	private static extern object ReadZStream(object stream, object buffer, object length) { }

	// RVA: 0x716AE50
	private static extern object WriteZStream(object stream, object buffer, object length) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=6
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=9
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=10
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=12
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=14
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=32
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=44
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=128
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=256
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 00C700F38385659BA060672F86D4A9A5376EADF9ED1CABB1C63290A0FDEFE36A; // 0x0
	internal static readonly object 04D9D643E5A26924DC98C9906714082D395DCB17CEE9674D5EBFEC15D098C2B5; // 0x100
	internal static readonly object 063691760A57230E8119DF650327304D68AE1C009E476E48BE8C73DCA199D374; // 0x120
	internal static readonly object 07FEA8B695D401E2B3BBDA6126C123DAA87153BB12384B21272ACC90823AC9A3; // 0x140
	internal static readonly object 1417FCAA8455DC8E3C88BF916DD5C75746A2597CC052F212A8E4394C890E012B; // 0x150
	internal static readonly object 27625E383C3A91E8B65BC745FF5D4048C82B883CCD293B07DED697BF82733811; // 0x158
	internal static readonly object 2EF83B43314F8CD03190EEE30ECCF048DA37791237F27C62A579F23EACE9FD70; // 0x161
	internal static readonly object 3505B8A2248AC03FE41ACADF8F29294572BBADEE1DD2E1A45D025766681C012C; // 0x188
	internal static readonly object 356A582FCE68ACAE8FC944F7B4F0C0DA2BFF4A90D3767C75905F3EDE2E4E66CF; // 0x190
	internal static readonly object 684312AFB7719E57993D2826FFBAF7EA965614F20F91D999FB19B01E21AA62E6; // 0x19C
	internal static readonly object 6C8F647E1FCD63826D12272FF0930E9C16F1FFEF719948703A4C0F3B90052885; // 0x1A8
	internal static readonly object 8109EF063456779751E8A4AEE94A0BE9AE32827B6EB153ABD7F40057FF2C9CE3; // 0x1B0
	internal static readonly object 9001C3EDE1D7E939C07996B84F82F7CBE59A7266C1FC2735E959E3C8609602E8; // 0x230
	internal static readonly object 9F58F1261D211553DE8FBC1AFA477C84EA3974B9BFF38223D771D0CDA787E15A; // 0x25C
	internal static readonly object B849624EC20707184A433E21DAAC963906D4B261A19BD8F139F0E269E59E308C; // 0x262
	internal static readonly object BB6BB42AC5453BD8AA992CCB8929F1CB7D4E112E3FC56E57D711E106D1F72859; // 0x2E8
	internal static readonly object DFA7289CF8D8029ACEE90F30530C6926950E8DD20285772458F271AFD015BAD5; // 0x2F0
	internal static readonly object E478CC6C0579E2198C99BFDE0ABAADC66644AF69312CB9D6E94E2D4E3559482A; // 0x2FE

	// Methods

	// RVA: 0x7166330
	internal static object ComputeStringHash(object s) { }

}

// Namespace: System.Configuration
public interface IConfigurationSectionHandler
{
}

// Namespace: System.Net.Configuration
public sealed class BypassElement
{
}

// Namespace: System.Net.Configuration
public sealed class BypassElementCollection
{

	// Methods

	// RVA: 0x716B478
	public object .ctor() { }

}

// Namespace: System.Net.Configuration
public sealed class ConnectionManagementElement
{
}

// Namespace: System.Net.Configuration
public sealed class ConnectionManagementElementCollection
{

	// Methods

	// RVA: 0x716B4B4
	public object .ctor() { }

}

// Namespace: System.Net.Configuration
public sealed class ConnectionManagementSection
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B4F0
	public object .ctor() { }

	// RVA: 0x716B52C
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class DefaultProxySection
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B568
	public object .ctor() { }

	// RVA: 0x716B5A4
	protected override object get_Properties() { }

	// RVA: 0x716B5E0
	protected override object Reset(object parentElement) { }

}

// Namespace: System.Net.Configuration
public sealed class ProxyElement
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B61C
	public object .ctor() { }

	// RVA: 0x716B658
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class HttpWebRequestElement
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B694
	public object .ctor() { }

	// RVA: 0x716B6D0
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class Ipv6Element
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B70C
	public object .ctor() { }

	// RVA: 0x716B748
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class NetSectionGroup
{

	// Methods

	// RVA: 0x716B784
	public object .ctor() { }

}

// Namespace: System.Net.Configuration
public sealed class SettingsSection
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B7C0
	public object .ctor() { }

	// RVA: 0x716B7FC
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class PerformanceCountersElement
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B838
	public object .ctor() { }

	// RVA: 0x716B874
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class ServicePointManagerElement
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B8B0
	public object .ctor() { }

	// RVA: 0x716B8EC
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class SocketElement
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B928
	public object .ctor() { }

	// RVA: 0x716B964
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class WebProxyScriptElement
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716B9A0
	public object .ctor() { }

	// RVA: 0x716B9DC
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class WebRequestModulesSection
{

	// Properties
	protected override object Properties { get; }

	// Methods

	// RVA: 0x716BA18
	public object .ctor() { }

	// RVA: 0x716BA54
	protected override object get_Properties() { }

}

// Namespace: System.Net.Configuration
public sealed class WebRequestModuleElementCollection
{

	// Methods

	// RVA: 0x716BA90
	public object .ctor() { }

}

// Namespace: System.Net.Configuration
public sealed class WebRequestModuleElement
{
}

// Namespace: System.Diagnostics
public class DiagnosticsConfigurationHandler
{

	// Methods

	// RVA: 0x716BACC
	public object .ctor() { }

	// RVA: 0x716BB08
	public virtual object Create(object parent, object configContext, object section) { }

}

// Namespace: Unity
internal sealed class ThrowStub
{

	// Methods

	// RVA: 0x716BB44
	public static object ThrowNotSupportedException() { }

}

