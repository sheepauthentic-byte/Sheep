// Namespace: 
internal class <Module>
{
}

// Namespace: Microsoft.CodeAnalysis
internal sealed class EmbeddedAttribute
{

	// Methods

	// RVA: 0x734ACD8
	public object .ctor() { }

}

// Namespace: System.Runtime.CompilerServices
internal sealed class IsUnmanagedAttribute
{

	// Methods

	// RVA: 0x734ACE0
	public object .ctor() { }

}

// Namespace: AOT
public class MonoPInvokeCallbackAttribute
{

	// Methods

	// RVA: 0x734ACE8
	public object .ctor(object type) { }

}

// Namespace: UnityEngineInternal
internal enum LightmapType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoLightmap;
	public const object StaticLightmap;
	public const object DynamicLightmap;
}

// Namespace: UnityEngineInternal
public struct MathfInternal
{

	// Fields
	public static object FloatMinNormal; // 0x0
	public static object FloatMinDenormal; // 0xFFFFFFFFFFFFFFF4
	public static object IsFlushToZeroEnabled; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x734ACF0
	private static object .cctor() { }

}

// Namespace: UnityEngineInternal
public enum TypeInferenceRules
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TypeReferencedByFirstArgument;
	public const object TypeReferencedBySecondArgument;
	public const object ArrayOfTypeReferencedByFirstArgument;
	public const object TypeOfFirstArgument;
}

// Namespace: UnityEngineInternal
public class TypeInferenceRuleAttribute
{

	// Fields
	private readonly object _rule; // 0x8

	// Methods

	// RVA: 0x734AD5C
	public object .ctor(object rule) { }

	// RVA: 0x734ADEC
	public object .ctor(object rule) { }

	// RVA: 0x734AE18
	public override object ToString() { }

}

// Namespace: UnityEngineInternal
public class GenericStack
{

	// Methods

	// RVA: 0x734AE20
	public object .ctor() { }

}

// Namespace: Unity.Jobs
public interface IJob
{

	// Methods

	// RVA: -1
	public abstract object Execute() { }

}

// Namespace: 
internal sealed class ExecuteJobFunction
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object data, object additionalPtr, object bufferRangePatchData, object ranges, object jobIndex) { }

}

// Namespace: 
internal struct JobStruct<T0>
{

	// Fields
	internal static readonly object jobReflectionData; // 0x0

	// Methods

	// RVA: -1
	internal static object Initialize() { }

	// RVA: -1
	public static object Execute(object data, object additionalPtr, object bufferRangePatchData, object ranges, object jobIndex) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Unity.Jobs
public static class IJobExtensions
{

	// Methods

	// RVA: -1
	public static object EarlyJobInit() { }

	// RVA: -1
	private static object GetReflectionData() { }

	// RVA: -1
	public static object Schedule(object jobData, object dependsOn) { }

	// RVA: -1
	public static object Run(object jobData) { }

}

// Namespace: Unity.Jobs
public interface IJobFor
{

	// Methods

	// RVA: -1
	public abstract object Execute(object index) { }

}

// Namespace: 
public sealed class ExecuteJobFunction
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object data, object additionalPtr, object bufferRangePatchData, object ranges, object jobIndex) { }

}

// Namespace: 
internal struct ForJobStruct<T0>
{

	// Fields
	internal static readonly object jobReflectionData; // 0x0

	// Methods

	// RVA: -1
	internal static object Initialize() { }

	// RVA: -1
	public static object Execute(object jobData, object additionalPtr, object bufferRangePatchData, object ranges, object jobIndex) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Unity.Jobs
public static class IJobForExtensions
{

	// Methods

	// RVA: -1
	public static object EarlyJobInit() { }

	// RVA: -1
	private static object GetReflectionData() { }

	// RVA: -1
	public static object ScheduleParallel(object jobData, object arrayLength, object innerloopBatchCount, object dependency) { }

	// RVA: -1
	public static object Run(object jobData, object arrayLength) { }

}

// Namespace: Unity.Jobs
public interface IJobParallelFor
{

	// Methods

	// RVA: -1
	public abstract object Execute(object index) { }

}

// Namespace: 
public sealed class ExecuteJobFunction
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object data, object additionalPtr, object bufferRangePatchData, object ranges, object jobIndex) { }

}

// Namespace: 
internal struct ParallelForJobStruct<T0>
{

	// Fields
	internal static readonly object jobReflectionData; // 0x0

	// Methods

	// RVA: -1
	internal static object Initialize() { }

	// RVA: -1
	public static object Execute(object jobData, object additionalPtr, object bufferRangePatchData, object ranges, object jobIndex) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Unity.Jobs
public static class IJobParallelForExtensions
{

	// Methods

	// RVA: -1
	public static object EarlyJobInit() { }

	// RVA: -1
	private static object GetReflectionData() { }

	// RVA: -1
	public static object Schedule(object jobData, object arrayLength, object innerloopBatchCount, object dependsOn) { }

}

// Namespace: Unity.Jobs
public struct JobHandle
{

	// Fields
	internal object jobGroup; // 0xFFFFFFFFFFFFFFF8
	internal object version; // 0x0

	// Properties
	public object IsCompleted { get; }

	// Methods

	// RVA: 0x734AE28
	public object Complete() { }

	// RVA: 0x734AF30
	public object get_IsCompleted() { }

	// RVA: 0x734B020
	public static object ScheduleBatchedJobs() { }

	// RVA: 0x734AE84
	private static object ScheduleBatchedJobsAndComplete(object job) { }

	// RVA: 0x734AF80
	private static object ScheduleBatchedJobsAndIsCompleted(object job) { }

	// RVA: 0x734B060
	public static object CombineDependencies(object jobs) { }

	// RVA: 0x734B178
	public static object CombineDependencies(object jobs) { }

	// RVA: 0x734B10C
	internal static object CombineDependenciesInternalPtr(object jobs, object count) { }

	// RVA: 0x734B2BC
	public object Equals(object other) { }

	// RVA: 0x734B250
	private static object CombineDependenciesInternalPtr_Injected(object jobs, object count, object ret) { }

}

// Namespace: Unity.Jobs.LowLevel.Unsafe
public sealed class JobProducerTypeAttribute
{

	// Fields
	private readonly object <ProducerType>k__BackingField; // 0x8

	// Methods

	// RVA: 0x734B2DC
	public object .ctor(object producerType) { }

}

// Namespace: Unity.Jobs.LowLevel.Unsafe
public struct JobRanges
{

	// Fields
	internal object BatchSize; // 0xFFFFFFFFFFFFFFF8
	internal object NumJobs; // 0xFFFFFFFFFFFFFFFC
	public object TotalIterationCount; // 0x0
	internal object StartEndIndex; // 0x8
}

// Namespace: Unity.Jobs.LowLevel.Unsafe
public enum ScheduleMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Run;
	public const object Batched;
	public const object Parallel;
	public const object Single;
}

// Namespace: 
public struct JobScheduleParameters
{

	// Fields
	public object Dependency; // 0xFFFFFFFFFFFFFFF8
	public object ScheduleMode; // 0x8
	public object ReflectionData; // 0x10
	public object JobDataPtr; // 0x18

	// Methods

	// RVA: 0x734B894
	public object .ctor(object i_jobData, object i_reflectionData, object i_dependency, object i_scheduleMode) { }

}

// Namespace: 
internal sealed class PanicFunction_
{

	// Methods

	// RVA: 0x734B974
	public object .ctor(object object, object method) { }

	// RVA: 0x734BA08
	public virtual object Invoke() { }

}

// Namespace: Unity.Jobs.LowLevel.Unsafe
public static class JobsUtility
{

	// Fields
	internal static object PanicFunction; // 0x0

	// Properties
	public static object IsExecutingJob { get; }
	public static object JobCompilerEnabled { set; }
	public static object ThreadIndexCount { get; }

	// Methods

	// RVA: 0x734B308
	public static object GetJobRange(object ranges, object jobIndex, object beginIndex, object endIndex) { }

	// RVA: 0x734B35C
	public static object GetWorkStealingRange(object ranges, object jobIndex, object beginIndex, object endIndex) { }

	// RVA: 0x734B3DC
	public static object Schedule(object parameters) { }

	// RVA: 0x734B49C
	public static object ScheduleParallelFor(object parameters, object arrayLength, object innerloopBatchCount) { }

	// RVA: 0x734B590
	public static object ScheduleParallelForTransform(object parameters, object transfromAccesssArray) { }

	// RVA: 0x734B668
	private static object CreateJobReflectionData(object wrapperJobType, object userJobType, object managedJobFunction0, object managedJobFunction1, object managedJobFunction2) { }

	// RVA: 0x734B6F0
	public static object CreateJobReflectionData(object type, object managedJobFunction0, object managedJobFunction1, object managedJobFunction2) { }

	// RVA: 0x734B75C
	public static object get_IsExecutingJob() { }

	// RVA: 0x734B79C
	public static object set_JobCompilerEnabled(object value) { }

	// RVA: 0x734B7EC
	public static object get_ThreadIndexCount() { }

	// RVA: 0x734B82C
	private static object InvokePanicFunction() { }

	// RVA: 0x734B438
	private static object Schedule_Injected(object parameters, object ret) { }

	// RVA: 0x734B510
	private static object ScheduleParallelFor_Injected(object parameters, object arrayLength, object innerloopBatchCount, object ret) { }

	// RVA: 0x734B5FC
	private static object ScheduleParallelForTransform_Injected(object parameters, object transfromAccesssArray, object ret) { }

}

// Namespace: Unity.IL2CPP.CompilerServices
internal class Il2CppEagerStaticClassConstructionAttribute
{

	// Methods

	// RVA: 0x734BA1C
	public object .ctor() { }

}

// Namespace: Unity.Profiling
public sealed class IgnoredByDeepProfilerAttribute
{

	// Methods

	// RVA: 0x734BA24
	public object .ctor() { }

}

// Namespace: Unity.Profiling
public struct ProfilerCategory
{

	// Fields
	private readonly object m_CategoryId; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object Name { get; }
	public static object Render { get; }
	public static object Scripts { get; }
	public static object GPU { get; }

	// Methods

	// RVA: 0x734BA2C
	public object .ctor(object categoryName) { }

	// RVA: 0x734BB40
	internal object .ctor(object category) { }

	// RVA: 0x734BB50
	public object get_Name() { }

	// RVA: 0x734BE2C
	public override object ToString() { }

	// RVA: 0x734BF4C
	public static object get_Render() { }

	// RVA: 0x734BF54
	public static object get_Scripts() { }

	// RVA: 0x734BF5C
	public static object get_GPU() { }

	// RVA: 0x734BF64
	public static object op_Implicit(object category) { }

}

// Namespace: Unity.Profiling
public enum ProfilerCategoryColor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Render;
	public const object Scripts;
	public const object BurstJobs;
	public const object Other;
	public const object Physics;
	public const object Animation;
	public const object Audio;
	public const object AudioJob;
	public const object AudioUpdateJob;
	public const object Lighting;
	public const object GC;
	public const object VSync;
	public const object Memory;
	public const object Internal;
	public const object UI;
	public const object Build;
	public const object Input;
}

// Namespace: 
public struct AutoScope
{

	// Fields
	internal readonly object m_Ptr; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x734C40C
	internal object .ctor(object markerPtr) { }

	// RVA: 0x734C4F4
	public object Dispose() { }

}

// Namespace: Unity.Profiling
public struct ProfilerMarker
{

	// Fields
	internal readonly object m_Ptr; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x734BF6C
	public object .ctor(object name) { }

	// RVA: 0x734C0AC
	public object .ctor(object category, object name) { }

	// RVA: 0x734C174
	public object Begin() { }

	// RVA: 0x734C264
	public object End() { }

	// RVA: 0x734C354
	public object Auto() { }

}

// Namespace: Unity.Profiling
public enum ProfilerMarkerDataUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undefined;
	public const object TimeNanoseconds;
	public const object Bytes;
	public const object Count;
	public const object Percent;
	public const object FrequencyHz;
}

// Namespace: Unity.Profiling
public enum ProfilerCounterOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object FlushOnEndOfFrame;
	public const object ResetToZeroOnFlush;
}

// Namespace: Unity.Profiling
public enum ProfilerRecorderOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object StartImmediately;
	public const object KeepAliveDuringDomainReload;
	public const object CollectOnlyOnCurrentThread;
	public const object WrapAroundWhenCapacityReached;
	public const object SumAllSamplesInFrame;
	public const object GpuRecorder;
	public const object Default;
}

// Namespace: 
internal enum ControlOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object Stop;
	public const object Reset;
	public const object Release;
	public const object SetFilterToCurrentThread;
	public const object SetToCollectFromAllThreads;
}

// Namespace: Unity.Profiling
public struct ProfilerRecorder
{

	// Fields
	internal object handle; // 0xFFFFFFFFFFFFFFF8
	internal const object SharedRecorder;

	// Properties
	public object Valid { get; }
	public object LastValue { get; }

	// Methods

	// RVA: 0x734C5DC
	public object .ctor(object category, object statName, object capacity, object options) { }

	// RVA: 0x734C820
	public object .ctor(object statHandle, object capacity, object options) { }

	// RVA: 0x734C908
	public object get_Valid() { }

	// RVA: 0x734CA54
	public object Start() { }

	// RVA: 0x734CBC8
	public object Stop() { }

	// RVA: 0x734CC70
	public object get_LastValue() { }

	// RVA: 0x734C6F8
	private static object Create(object statHandle, object maxSampleCount, object options) { }

	// RVA: 0x734CB54
	private static object Control(object handle, object options) { }

	// RVA: 0x734CD24
	private static object GetLastValue(object handle) { }

	// RVA: 0x734C97C
	private static object GetValid(object handle) { }

	// RVA: 0x734CF14
	public object Dispose() { }

	// RVA: 0x734CAF4
	private object CheckInitializedAndThrow() { }

	// RVA: 0x734CD90
	private static object Create_Injected(object statHandle, object maxSampleCount, object options, object ret) { }

	// RVA: 0x734CE10
	private static object Control_Injected(object handle, object options) { }

	// RVA: 0x734CE74
	private static object GetLastValue_Injected(object handle) { }

	// RVA: 0x734CEC4
	private static object GetValid_Injected(object handle) { }

}

// Namespace: Unity.Profiling
internal sealed class ProfilerRecorderDebugView
{
}

// Namespace: Unity.Profiling
public struct DebugScreenCapture
{

	// Fields
	private object <RawImageDataReference>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <ImageFormat>k__BackingField; // 0x8
	private object <Width>k__BackingField; // 0xC
	private object <Height>k__BackingField; // 0x10

	// Properties
	public object RawImageDataReference { set; }
	public object ImageFormat { set; }
	public object Width { set; }
	public object Height { set; }

	// Methods

	// RVA: 0x734D034
	public object set_RawImageDataReference(object value) { }

	// RVA: 0x734D044
	public object set_ImageFormat(object value) { }

	// RVA: 0x734D054
	public object set_Width(object value) { }

	// RVA: 0x734D064
	public object set_Height(object value) { }

}

// Namespace: Unity.Profiling.LowLevel
public enum MarkerFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Script;
	public const object ScriptInvoke;
	public const object ScriptDeepProfiler;
	public const object AvailabilityEditor;
	public const object AvailabilityNonDevelopment;
	public const object Warning;
	public const object Counter;
	public const object SampleGPU;
}

// Namespace: Unity.Profiling.LowLevel
public enum ProfilerMarkerDataType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object InstanceId;
	public const object Int32;
	public const object UInt32;
	public const object Int64;
	public const object UInt64;
	public const object Float;
	public const object Double;
	public const object String16;
	public const object Blob8;
	public const object GfxResourceId;
}

// Namespace: Unity.Profiling.LowLevel.Unsafe
public struct ProfilerRecorderDescription
{

	// Fields
	private readonly object category; // 0xFFFFFFFFFFFFFFF8
	private readonly object flags; // 0xFFFFFFFFFFFFFFFA
	private readonly object dataType; // 0xFFFFFFFFFFFFFFFC
	private readonly object unitType; // 0xFFFFFFFFFFFFFFFD
	private readonly object reserved0; // 0x0
	private readonly object nameUtf8Len; // 0x4
	private readonly object nameUtf8; // 0x8

	// Properties
	public object Category { get; }
	public object Flags { get; }
	public object UnitType { get; }
	public object Name { get; }

	// Methods

	// RVA: 0x734D074
	public object get_Category() { }

	// RVA: 0x734D084
	public object get_Flags() { }

	// RVA: 0x734D094
	public object get_UnitType() { }

	// RVA: 0x734D0A4
	public object get_Name() { }

}

// Namespace: Unity.Profiling.LowLevel.Unsafe
public struct ProfilerRecorderHandle
{

	// Fields
	internal readonly object handle; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object Valid { get; }

	// Methods

	// RVA: 0x734D0C4
	internal object .ctor(object handle) { }

	// RVA: 0x734D0D4
	public object get_Valid() { }

	// RVA: 0x734D0FC
	public static object GetDescription(object handle) { }

	// RVA: 0x734D298
	public static object GetAvailable(object outRecorderHandleList) { }

	// RVA: 0x734C698
	internal static object GetByName(object category, object name) { }

	// RVA: 0x734D354
	internal static object GetByName__Unmanaged(object category, object name, object nameLen) { }

	// RVA: 0x734D204
	private static object GetDescriptionInternal(object handle) { }

	// RVA: 0x734D2E8
	private static object GetByName_Injected(object category, object name, object ret) { }

	// RVA: 0x734D3C4
	private static object GetByName__Unmanaged_Injected(object category, object name, object nameLen, object ret) { }

	// RVA: 0x734D444
	private static object GetDescriptionInternal_Injected(object handle, object ret) { }

}

// Namespace: Unity.Profiling.LowLevel.Unsafe
public struct ProfilerCategoryDescription
{

	// Fields
	public readonly object Id; // 0xFFFFFFFFFFFFFFF8
	public readonly object Flags; // 0xFFFFFFFFFFFFFFFA
	public readonly object Color; // 0xFFFFFFFFFFFFFFFC
	private readonly object reserved0; // 0x0
	public readonly object NameUtf8Len; // 0x4
	public readonly object NameUtf8; // 0x8
}

// Namespace: Unity.Profiling.LowLevel.Unsafe
public static class ProfilerUnsafeUtility
{

	// Methods

	// RVA: 0x734BA84
	internal static object CreateCategory(object name, object colorIndex) { }

	// RVA: 0x734D4A8
	internal static object CreateCategory__Unmanaged(object name, object nameLen, object colorIndex) { }

	// RVA: 0x734BBE0
	public static object GetCategoryDescription(object categoryId) { }

	// RVA: 0x734BFCC
	public static object CreateMarker(object name, object categoryId, object flags, object metadataCount) { }

	// RVA: 0x734D578
	internal static object CreateMarker__Unmanaged(object name, object nameLen, object categoryId, object flags, object metadataCount) { }

	// RVA: 0x734D600
	internal static object GetMarker(object name) { }

	// RVA: 0x734D650
	internal static object SetMarkerMetadata__Unmanaged(object markerPtr, object index, object name, object nameLen, object type, object unit) { }

	// RVA: 0x734C1C4
	public static object BeginSample(object markerPtr) { }

	// RVA: 0x734C2B4
	public static object EndSample(object markerPtr) { }

	// RVA: 0x734D6EC
	internal static object CreateCounterValue__Unmanaged(object counterPtr, object name, object nameLen, object categoryId, object flags, object dataType, object dataUnit, object dataSize, object counterOptions) { }

	// RVA: 0x734BC84
	internal static object Utf8ToString(object chars, object charsLen) { }

	// RVA: 0x734D514
	private static object GetCategoryDescription_Injected(object categoryId, object ret) { }

}

// Namespace: Unity.Profiling.Memory
public class MemorySnapshotMetadata
{

	// Fields
	private object <Description>k__BackingField; // 0x8
	private object <Data>k__BackingField; // 0x10

	// Properties
	public object Description { get; set; }
	internal object Data { get; }

	// Methods

	// RVA: 0x734D790
	public object get_Description() { }

	// RVA: 0x734D798
	public object set_Description(object value) { }

	// RVA: 0x734D7A0
	internal object get_Data() { }

	// RVA: 0x734D7A8
	public object .ctor() { }

}

// Namespace: Unity.Profiling.Memory
public static class MemoryProfiler
{

	// Fields
	private static object m_SnapshotFinished; // 0x0
	private static object m_SaveScreenshotToDisk; // 0x8
	private static object CreatingMetadata; // 0x10

	// Methods

	// RVA: 0x734D7B0
	private static object PrepareMetadata() { }

	// RVA: 0x734DACC
	internal static object WriteIntToByteArray(object array, object offset, object value) { }

	// RVA: 0x734DB5C
	internal static object WriteStringToByteArray(object array, object offset, object value) { }

	// RVA: 0x734DC84
	private static object FinalizeSnapshot(object path, object result) { }

	// RVA: 0x734DD0C
	private static object SaveScreenshotToDisk(object path, object result, object pixelsPtr, object pixelsCount, object format, object width, object height) { }

}

// Namespace: Unity.Profiling.Stats
public enum CounterDataType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Duration;
	public const object Int32;
	public const object UInt32;
	public const object Float;
}

// Namespace: Unity.Profiling.Stats
public enum CounterFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ClearEveryFrame;
}

// Namespace: Unity.Profiling.Stats
public struct Counter
{

	// Fields
	internal object NativeObject; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object Name { get; }
	public object Category { get; }
	public object DataType { get; }
	public object Enabled { get; set; }

	// Methods

	// RVA: 0x734DE10
	public object get_Name() { }

	// RVA: 0x734DFC8
	public object get_Category() { }

	// RVA: 0x734E1A8
	public object get_DataType() { }

	// RVA: 0x734E360
	public object get_Enabled() { }

	// RVA: 0x734E518
	public object set_Enabled(object value) { }

	// RVA: 0x734E6FC
	public object .ctor(object displayName, object category, object type, object flags) { }

}

// Namespace: Unity.Profiling.Stats
public struct Category
{

	// Fields
	internal object NativeObject; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x734E92C
	public object .ctor(object displayName) { }

}

// Namespace: Unity.Profiling.Stats
public struct FrameStats
{

	// Fields
	internal object FrameNum; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x734EADC
	public object GetDurationMicroSeconds(object counter) { }

	// RVA: 0x734ECC0
	public object GetInt32(object counter) { }

	// RVA: 0x734EEA4
	public object GetUInt32(object counter) { }

	// RVA: 0x734F088
	public object GetFloat(object counter) { }

}

// Namespace: Unity.Profiling.Stats
public struct StatsScopeDuration
{

	// Fields
	private object m_Disposed; // 0xFFFFFFFFFFFFFFF8
	private object m_Counter; // 0x0

	// Methods

	// RVA: 0x734F2A0
	public object .ctor(object counter) { }

	// RVA: 0x734F470
	public object Dispose() { }

	// RVA: 0x734F478
	private object Dispose(object disposing) { }

}

// Namespace: Unity.Profiling.Stats
public static class InGameStats
{

	// Fields
	private static object cachedCounters; // 0x0

	// Properties
	public static object Counters { get; }

	// Methods

	// RVA: 0x734F65C
	public static object get_Counters() { }

	// RVA: 0x734F9A4
	public static object GetLastFrameStats() { }

	// RVA: 0x734F3BC
	public static object BeginDuration(object counter) { }

	// RVA: 0x734F5A8
	public static object EndDuration(object counter) { }

	// RVA: 0x734FB24
	public static object SetInt32(object counter, object value) { }

	// RVA: 0x734FC40
	public static object SetFloat(object counter, object value) { }

	// RVA: 0x734F914
	internal static object GetNumCounters() { }

	// RVA: 0x734F954
	internal static object GetCounterByIndex(object index) { }

	// RVA: 0x734E414
	internal static object CounterGetEnabled(object counter) { }

	// RVA: 0x734E5D8
	internal static object CounterSetEnabled(object counter, object enabled) { }

	// RVA: 0x734DEC4
	internal static object CounterGetName(object counter) { }

	// RVA: 0x734E100
	internal static object CounterGetCategory(object counter) { }

	// RVA: 0x734E25C
	internal static object CounterGetDataType(object counter) { }

	// RVA: 0x734E150
	internal static object CategoryGetName(object category) { }

	// RVA: 0x734E7D4
	internal static object CreateCounter(object displayName, object category, object type, object flags) { }

	// RVA: 0x734E9DC
	internal static object CreateCategory(object displayName) { }

	// RVA: 0x734FA84
	internal static object RecordSampleBeginDuration(object counter) { }

	// RVA: 0x734FAD4
	internal static object RecordSampleEndDuration(object counter) { }

	// RVA: 0x734FBDC
	internal static object RecordSampleSetInt32(object counter, object value) { }

	// RVA: 0x734FCEC
	internal static object RecordSampleSetFloat(object counter, object value) { }

	// RVA: 0x734FA44
	internal static object GetCurrentFrameNum() { }

	// RVA: 0x734EB9C
	internal static object FrameStatsGetDurationMicroSeconds(object frame, object counter) { }

	// RVA: 0x734ED80
	internal static object FrameStatsGetInt32(object frame, object counter) { }

	// RVA: 0x734EF64
	internal static object FrameStatsGetUInt32(object frame, object counter) { }

	// RVA: 0x734F148
	internal static object FrameStatsGetFloat(object frame, object counter) { }

	// RVA: 0x734FD50
	private static object .cctor() { }

}

// Namespace: Unity.IO.LowLevel.Unsafe
public enum FileState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Absent;
	public const object Exists;
}

// Namespace: Unity.IO.LowLevel.Unsafe
public enum AssetLoadingSubsystem
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Other;
	public const object Texture;
	public const object VirtualTexture;
	public const object Mesh;
	public const object Audio;
	public const object Scripts;
	public const object EntitiesScene;
	public const object EntitiesStreamBinaryReader;
	public const object FileInfo;
	public const object ContentLoading;
}

// Namespace: Unity.IO.LowLevel.Unsafe
public enum Priority
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PriorityLow;
	public const object PriorityHigh;
}

// Namespace: Unity.IO.LowLevel.Unsafe
public enum ProcessingState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object InQueue;
	public const object Reading;
	public const object Completed;
	public const object Failed;
	public const object Canceled;
}

// Namespace: Unity.IO.LowLevel.Unsafe
public enum FileReadType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Sync;
	public const object Async;
}

// Namespace: Unity.IO.LowLevel.Unsafe
public struct AsyncReadManagerRequestMetric
{

	// Fields
	private readonly object <AssetName>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private readonly object <FileName>k__BackingField; // 0x0
	private readonly object <OffsetBytes>k__BackingField; // 0x8
	private readonly object <SizeBytes>k__BackingField; // 0x10
	private readonly object <AssetTypeId>k__BackingField; // 0x18
	private readonly object <CurrentBytesRead>k__BackingField; // 0x20
	private readonly object <BatchReadCount>k__BackingField; // 0x28
	private readonly object <IsBatchRead>k__BackingField; // 0x2C
	private readonly object <State>k__BackingField; // 0x30
	private readonly object <ReadType>k__BackingField; // 0x34
	private readonly object <PriorityLevel>k__BackingField; // 0x38
	private readonly object <Subsystem>k__BackingField; // 0x3C
	private readonly object <RequestTimeMicroseconds>k__BackingField; // 0x40
	private readonly object <TimeInQueueMicroseconds>k__BackingField; // 0x48
	private readonly object <TotalTimeMicroseconds>k__BackingField; // 0x50
}

// Namespace: Unity.IO.LowLevel.Unsafe
public class AsyncReadManagerMetricsFilters
{

	// Fields
	internal object TypeIDs; // 0x8
	internal object States; // 0x10
	internal object ReadTypes; // 0x18
	internal object PriorityLevels; // 0x20
	internal object Subsystems; // 0x28
}

// Namespace: Unity.IO.Archive
public enum ArchiveStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object InProgress;
	public const object Complete;
	public const object Failed;
}

// Namespace: Unity.IO.Archive
public struct ArchiveFileInfo
{

	// Fields
	public object Filename; // 0xFFFFFFFFFFFFFFF8
	public object FileSize; // 0x0
}

// Namespace: Unity.IO.Archive
public struct ArchiveHandle
{

	// Fields
	internal object Handle; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Unity.IO.Archive
public static class ArchiveFileInterface
{
}

// Namespace: Unity.Collections
public sealed class ReadOnlyAttribute
{

	// Methods

	// RVA: 0x7350678
	public object .ctor() { }

}

// Namespace: Unity.Collections
public sealed class WriteOnlyAttribute
{

	// Methods

	// RVA: 0x7350680
	public object .ctor() { }

}

// Namespace: Unity.Collections
public sealed class DeallocateOnJobCompletionAttribute
{
}

// Namespace: Unity.Collections
public sealed class NativeFixedLengthAttribute
{
}

// Namespace: Unity.Collections
public sealed class NativeMatchesParallelForLengthAttribute
{
}

// Namespace: Unity.Collections
public sealed class NativeDisableParallelForRestrictionAttribute
{
}

// Namespace: Unity.Collections
public enum Allocator
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Invalid;
	public const object None;
	public const object Temp;
	public const object TempJob;
	public const object Persistent;
	public const object AudioKernel;
	public const object FirstUserIndex;
}

// Namespace: Unity.Collections
internal enum LeakCategory
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Invalid;
	public const object Malloc;
	public const object TempJob;
	public const object Persistent;
	public const object LightProbesQuery;
	public const object NativeTest;
	public const object MeshDataArray;
	public const object TransformAccessArray;
	public const object NavMeshQuery;
}

// Namespace: Unity.Collections
public enum NativeArrayOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UninitializedMemory;
	public const object ClearMemory;
}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object m_Array; // 0x0
	private object m_Index; // 0x0
	private object value; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object array) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object m_Array; // 0x0
	private object m_Index; // 0x0
	private object value; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object array) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
public struct ReadOnly
{

	// Fields
	internal object m_Buffer; // 0x0
	internal object m_Length; // 0x0

	// Properties
	public object Length { get; }
	public object Item { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object buffer, object length) { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: Unity.Collections
public struct NativeArray<T0>
{

	// Fields
	internal object m_Buffer; // 0x0
	internal object m_Length; // 0x0
	internal object m_AllocatorLabel; // 0x0

	// Properties
	public object Length { get; }
	public object Item { get; set; }
	public object IsCreated { get; }

	// Methods

	// RVA: -1
	public object .ctor(object length, object allocator, object options) { }

	// RVA: -1
	public object .ctor(object array, object allocator) { }

	// RVA: -1
	public object .ctor(object array, object allocator) { }

	// RVA: -1
	private static object Allocate(object length, object allocator, object array) { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object get_IsCreated() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object CopyFrom(object array) { }

	// RVA: -1
	public object CopyFrom(object array) { }

	// RVA: -1
	public object ToArray() { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public static object op_Equality(object left, object right) { }

	// RVA: -1
	public static object Copy(object src, object dst) { }

	// RVA: -1
	public static object Copy(object src, object dst) { }

	// RVA: -1
	public static object Copy(object src, object dst, object length) { }

	// RVA: -1
	public static object Copy(object src, object dst, object length) { }

	// RVA: -1
	public static object Copy(object src, object srcIndex, object dst, object dstIndex, object length) { }

	// RVA: -1
	private static object CopySafe(object src, object srcIndex, object dst, object dstIndex, object length) { }

	// RVA: -1
	private static object CopySafe(object src, object srcIndex, object dst, object dstIndex, object length) { }

	// RVA: -1
	private static object CopySafe(object src, object srcIndex, object dst, object dstIndex, object length) { }

	// RVA: -1
	public object AsReadOnly() { }

}

// Namespace: Unity.Collections
internal struct NativeArrayDispose
{

	// Fields
	internal object m_Buffer; // 0xFFFFFFFFFFFFFFF8
	internal object m_AllocatorLabel; // 0x0

	// Methods

	// RVA: 0x7350688
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeArrayDisposeJob
{

	// Fields
	internal object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73507BC
	public object Execute() { }

	// RVA: 0x735082C
	internal static object RegisterNativeArrayDisposeJobReflectionData() { }

}

// Namespace: Unity.Collections
internal sealed class NativeArrayDebugView<T0>
{
}

// Namespace: Unity.Collections
internal sealed class NativeArrayReadOnlyDebugView<T0>
{
}

// Namespace: Unity.Collections
public static class NativeSliceExtensions
{

	// Methods

	// RVA: -1
	public static object Slice(object thisArray, object start, object length) { }

	// RVA: -1
	public static object Slice(object thisSlice, object start, object length) { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object m_Array; // 0x0
	private object m_Index; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object array) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Unity.Collections
public struct NativeSlice<T0>
{

	// Fields
	internal object m_Buffer; // 0x0
	internal object m_Stride; // 0x0
	internal object m_Length; // 0x0

	// Properties
	public object Item { get; set; }
	public object Stride { get; }
	public object Length { get; }

	// Methods

	// RVA: -1
	public object .ctor(object slice, object start, object length) { }

	// RVA: -1
	public object .ctor(object array) { }

	// RVA: -1
	public static object op_Implicit(object array) { }

	// RVA: -1
	public object .ctor(object array, object start, object length) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object CopyFrom(object slice) { }

	// RVA: -1
	public object CopyFrom(object array) { }

	// RVA: -1
	public object get_Stride() { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public override object GetHashCode() { }

}

// Namespace: Unity.Collections
internal sealed class NativeSliceDebugView<T0>
{
}

// Namespace: 
internal struct SharedStatic<T0>
{

	// Fields
	private readonly object _buffer; // 0x0

	// Properties
	public object Data { get; }

	// Methods

	// RVA: -1
	private object .ctor(object buffer) { }

	// RVA: -1
	public object get_Data() { }

	// RVA: -1
	public static object GetOrCreate(object alignment) { }

}

// Namespace: 
internal static class SharedStatic
{

	// Methods

	// RVA: 0x7350870
	public static object GetOrCreateSharedStaticInternal(object getHashCode64, object getSubHashCode64, object sizeOf, object alignment) { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal static class BurstLike
{
}

// Namespace: 
private struct HashCode64<T0>
{

	// Fields
	public static readonly object Value; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal static class BurstRuntime
{

	// Methods

	// RVA: -1
	public static object GetHashCode64() { }

	// RVA: 0x735095C
	internal static object HashStringWithFNV1A64(object text) { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeContainerAttribute
{

	// Methods

	// RVA: 0x73509F4
	public object .ctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeContainerIsReadOnlyAttribute
{

	// Methods

	// RVA: 0x73509FC
	public object .ctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeContainerIsAtomicWriteOnlyAttribute
{
}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeContainerSupportsMinMaxWriteRestrictionAttribute
{

	// Methods

	// RVA: 0x7350A04
	public object .ctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeContainerSupportsDeallocateOnJobCompletionAttribute
{

	// Methods

	// RVA: 0x7350A0C
	public object .ctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeContainerSupportsDeferredConvertListToArray
{

	// Methods

	// RVA: 0x7350A14
	public object .ctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeSetThreadIndexAttribute
{
}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeContainerNeedsThreadIndexAttribute
{
}

// Namespace: Unity.Collections.LowLevel.Unsafe
public class WriteAccessRequiredAttribute
{

	// Methods

	// RVA: 0x7350A1C
	public object .ctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeDisableUnsafePtrRestrictionAttribute
{

	// Methods

	// RVA: 0x7350A24
	public object .ctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeDisableContainerSafetyRestrictionAttribute
{

	// Methods

	// RVA: 0x7350A2C
	public object .ctor() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public sealed class NativeSetClassTypeToNullOnScheduleAttribute
{
}

// Namespace: Unity.Collections.LowLevel.Unsafe
public static class NativeArrayUnsafeUtility
{

	// Methods

	// RVA: -1
	public static object ConvertExistingDataToNativeArray(object dataPointer, object length, object allocator) { }

	// RVA: -1
	public static object GetUnsafePtr(object nativeArray) { }

	// RVA: -1
	public static object GetUnsafeReadOnlyPtr(object nativeArray) { }

	// RVA: -1
	public static object GetUnsafeBufferPointerWithoutChecks(object nativeArray) { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public static class NativeSliceUnsafeUtility
{

	// Methods

	// RVA: -1
	public static object ConvertExistingDataToNativeSlice(object dataPointer, object stride, object length) { }

	// RVA: -1
	public static object GetUnsafePtr(object nativeSlice) { }

	// RVA: -1
	public static object GetUnsafeReadOnlyPtr(object nativeSlice) { }

}

// Namespace: 
private struct AlignOfHelper<T0>
{

	// Fields
	public object dummy; // 0x0
	public object data; // 0x0
}

// Namespace: Unity.Collections.LowLevel.Unsafe
public static class UnsafeUtility
{

	// Methods

	// RVA: 0x7350A34
	internal static object LeakRecord(object handle, object category, object callstacksToSkip) { }

	// RVA: 0x7350AA0
	internal static object LeakErase(object handle, object category) { }

	// RVA: 0x7350B04
	public static object MallocTracked(object size, object alignment, object allocator, object callstacksToSkip) { }

	// RVA: 0x73506F0
	public static object FreeTracked(object memory, object allocator) { }

	// RVA: 0x734DC18
	public static object MemCpy(object destination, object source, object size) { }

	// RVA: 0x7350B84
	public static object MemCpyStride(object destination, object destinationStride, object source, object sourceStride, object elementSize, object count) { }

	// RVA: 0x7350C20
	public static object MemSet(object destination, object value, object size) { }

	// RVA: 0x7350C8C
	public static object MemClear(object destination, object size) { }

	// RVA: 0x7350CFC
	public static object MemCmp(object ptr1, object ptr2, object size) { }

	// RVA: 0x7350D68
	public static object SizeOf(object type) { }

	// RVA: 0x7350DB8
	public static object IsBlittable(object type) { }

	// RVA: 0x7350E08
	private static object IsBlittableValueType(object t) { }

	// RVA: 0x7350E80
	private static object GetReasonForTypeNonBlittableImpl(object t, object name) { }

	// RVA: 0x735110C
	internal static object IsArrayBlittable(object arr) { }

	// RVA: 0x73511D0
	internal static object GetReasonForArrayNonBlittable(object arr) { }

	// RVA: -1
	public static object AlignOf() { }

	// RVA: -1
	public static object CopyPtrToStructure(object ptr, object output) { }

	// RVA: -1
	private static object InternalCopyPtrToStructure(object ptr, object output) { }

	// RVA: -1
	public static object ReadArrayElement(object source, object index) { }

	// RVA: -1
	public static object ReadArrayElementWithStride(object source, object index, object stride) { }

	// RVA: -1
	public static object WriteArrayElement(object destination, object index, object value) { }

	// RVA: -1
	public static object WriteArrayElementWithStride(object destination, object index, object stride, object value) { }

	// RVA: -1
	public static object AddressOf(object output) { }

	// RVA: -1
	public static object SizeOf() { }

	// RVA: -1
	public static object As(object from) { }

	// RVA: -1
	public static object AsRef(object ptr) { }

	// RVA: -1
	public static object EnumToInt(object enumValue) { }

	// RVA: -1
	private static object InternalEnumToInt(object enumValue, object intValue) { }

	// RVA: -1
	public static object EnumEquals(object lhs, object rhs) { }

}

// Namespace: Unity.Burst
public class BurstAuthorizedExternalMethodAttribute
{

	// Methods

	// RVA: 0x7351280
	public object .ctor() { }

}

// Namespace: Unity.Burst
public class BurstDiscardAttribute
{

	// Methods

	// RVA: 0x7351288
	public object .ctor() { }

}

// Namespace: 
public enum BurstLogType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Info;
	public const object Warning;
	public const object Error;
}

// Namespace: Unity.Burst.LowLevel
internal static class BurstCompilerService
{

	// Methods

	// RVA: 0x7351290
	public static object CompileAsyncDelegateMethod(object delegateMethod, object compilerOptions) { }

	// RVA: 0x73512F4
	public static object GetAsyncCompiledAsyncDelegateMethod(object userID) { }

	// RVA: 0x73508F0
	public static object GetOrCreateSharedMemory(object key, object size_of, object alignment) { }

	// RVA: 0x7351344
	public static object Log(object userData, object logType, object message, object filename, object lineNumber) { }

	// RVA: 0x73513CC
	public static object RuntimeLog(object userData, object logType, object message, object filename, object lineNumber) { }

}

// Namespace: JetBrains.Annotations
public sealed class CanBeNullAttribute
{

	// Methods

	// RVA: 0x7351454
	public object .ctor() { }

}

// Namespace: JetBrains.Annotations
public sealed class NotNullAttribute
{

	// Methods

	// RVA: 0x735145C
	public object .ctor() { }

}

// Namespace: JetBrains.Annotations
public sealed class PureAttribute
{

	// Methods

	// RVA: 0x7351464
	public object .ctor() { }

}

// Namespace: UnityEngine
public struct SortingLayer
{

	// Fields
	private object m_Id; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x735146C
	public static object GetLayerValueFromID(object id) { }

}

// Namespace: UnityEngine
public enum WeightedMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object In;
	public const object Out;
	public const object Both;
}

// Namespace: UnityEngine
public struct Keyframe
{

	// Fields
	private object m_Time; // 0xFFFFFFFFFFFFFFF8
	private object m_Value; // 0xFFFFFFFFFFFFFFFC
	private object m_InTangent; // 0x0
	private object m_OutTangent; // 0x4
	private object m_WeightedMode; // 0x8
	private object m_InWeight; // 0xC
	private object m_OutWeight; // 0x10

	// Properties
	public object time { get; set; }
	public object value { get; set; }
	public object inTangent { get; set; }
	public object outTangent { get; set; }
	public object inWeight { get; set; }
	public object outWeight { get; set; }
	public object weightedMode { get; set; }

	// Methods

	// RVA: 0x73514BC
	public object .ctor(object time, object value) { }

	// RVA: 0x73514DC
	public object .ctor(object time, object value, object inTangent, object outTangent) { }

	// RVA: 0x7351504
	public object get_time() { }

	// RVA: 0x7351514
	public object set_time(object value) { }

	// RVA: 0x7351524
	public object get_value() { }

	// RVA: 0x7351534
	public object set_value(object value) { }

	// RVA: 0x7351544
	public object get_inTangent() { }

	// RVA: 0x7351554
	public object set_inTangent(object value) { }

	// RVA: 0x7351564
	public object get_outTangent() { }

	// RVA: 0x7351574
	public object set_outTangent(object value) { }

	// RVA: 0x7351584
	public object get_inWeight() { }

	// RVA: 0x7351594
	public object set_inWeight(object value) { }

	// RVA: 0x73515A4
	public object get_outWeight() { }

	// RVA: 0x73515B4
	public object set_outWeight(object value) { }

	// RVA: 0x73515C4
	public object get_weightedMode() { }

	// RVA: 0x73515D4
	public object set_weightedMode(object value) { }

}

// Namespace: UnityEngine
public enum WrapMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Once;
	public const object Loop;
	public const object PingPong;
	public const object Default;
	public const object ClampForever;
	public const object Clamp;
}

// Namespace: UnityEngine
public class AnimationCurve
{

	// Fields
	internal object m_Ptr; // 0x8

	// Properties
	public object keys { get; }
	public object Item { get; }
	public object length { get; }
	public object preWrapMode { get; set; }
	public object postWrapMode { get; set; }

	// Methods

	// RVA: 0x7351600
	private static object Internal_Destroy(object ptr) { }

	// RVA: 0x7351650
	private static object Internal_Create(object keys) { }

	// RVA: 0x73516A0
	private object Internal_Equals(object other) { }

	// RVA: 0x7351704
	private object Internal_CopyFrom(object other) { }

	// RVA: 0x7351768
	protected override object Finalize() { }

	// RVA: 0x7351820
	public object Evaluate(object time) { }

	// RVA: 0x7351884
	public object get_keys() { }

	// RVA: 0x7351924
	public object AddKey(object key) { }

	// RVA: 0x73519A0
	private object AddKey_Internal(object key) { }

	// RVA: 0x7351A68
	public object ClearKeys() { }

	// RVA: 0x7351AB8
	public object RemoveKey(object index) { }

	// RVA: 0x7351B1C
	public object get_Item(object index) { }

	// RVA: 0x7351C34
	public object get_length() { }

	// RVA: 0x7351BB0
	private object GetKey(object index) { }

	// RVA: 0x73518D4
	private object GetKeys() { }

	// RVA: 0x7351CF0
	public static object Linear(object timeStart, object valueStart, object timeEnd, object valueEnd) { }

	// RVA: 0x7351EAC
	public static object EaseInOut(object timeStart, object valueStart, object timeEnd, object valueEnd) { }

	// RVA: 0x7351FF8
	public object get_preWrapMode() { }

	// RVA: 0x7352048
	public object set_preWrapMode(object value) { }

	// RVA: 0x73520AC
	public object get_postWrapMode() { }

	// RVA: 0x73520FC
	public object set_postWrapMode(object value) { }

	// RVA: 0x7351E50
	public object .ctor(object keys) { }

	// RVA: 0x7352160
	public object .ctor() { }

	// RVA: 0x73521C8
	public override object Equals(object o) { }

	// RVA: 0x7352390
	public object Equals(object other) { }

	// RVA: 0x735247C
	public override object GetHashCode() { }

	// RVA: 0x7352488
	public object CopyFrom(object other) { }

	// RVA: 0x7351A04
	private object AddKey_Internal_Injected(object key) { }

	// RVA: 0x7351C84
	private object GetKey_Injected(object index, object ret) { }

}

// Namespace: UnityEngine
public struct UnityDrawStats
{

	// Fields
	private object m_Batches; // 0xFFFFFFFFFFFFFFF8
	private object m_Calls; // 0xFFFFFFFFFFFFFFFC
	private object m_Tris; // 0x0
	private object m_Verts; // 0x8
	private object m_SetPassCalls; // 0x10

	// Properties
	public object batches { get; }
	public object calls { get; }
	public object tris { get; }
	public object verts { get; }
	public object setPassCalls { get; }

	// Methods

	// RVA: 0x7352500
	public object get_batches() { }

	// RVA: 0x7352510
	public object get_calls() { }

	// RVA: 0x7352520
	public object get_tris() { }

	// RVA: 0x7352530
	public object get_verts() { }

	// RVA: 0x7352540
	public object get_setPassCalls() { }

}

// Namespace: 
public sealed class FataErrorCallback
{

	// Methods

	// RVA: 0x7354534
	public object .ctor(object object, object method) { }

	// RVA: 0x73545E4
	public virtual object Invoke(object module, object error) { }

}

// Namespace: 
public sealed class LowMemoryCallback
{

	// Methods

	// RVA: 0x7354650
	public object .ctor(object object, object method) { }

	// RVA: 0x73546E4
	public virtual object Invoke() { }

}

// Namespace: 
public sealed class MemoryUsageChangedCallback
{

	// Methods

	// RVA: 0x7354790
	public object .ctor(object object, object method) { }

	// RVA: 0x7354838
	public virtual object Invoke(object usage) { }

}

// Namespace: 
public sealed class LogCallback
{

	// Methods

	// RVA: 0x7354960
	public object .ctor(object object, object method) { }

	// RVA: 0x7354A10
	public virtual object Invoke(object condition, object stackTrace, object type) { }

}

// Namespace: UnityEngine
public class Application
{

	// Fields
	private static object s_FataErrorCallbackHandler; // 0x0
	private static object s_FataErrorCallbackHandlerThreaded; // 0x8
	private static object lowMemory; // 0x10
	private static object memoryUsageChanged; // 0x18
	private static object s_LogCallbackHandler; // 0x20
	private static object s_LogCallbackHandlerThreaded; // 0x28
	private static object focusChanged; // 0x30
	private static object deepLinkActivated; // 0x38
	private static object wantsToQuit; // 0x40
	private static object quitting; // 0x48
	private static object unloading; // 0x50
	private static object s_currentCancellationTokenSource; // 0x58

	// Properties
	public static object isPlaying { get; }
	public static object isFocused { get; }
	public static object runInBackground { set; }
	public static object isBatchMode { get; }
	public static object dataPath { get; }
	public static object streamingAssetsPath { get; }
	public static object persistentDataPath { get; }
	public static object temporaryCachePath { get; }
	public static object unityVersion { get; }
	public static object unityBuildVersion { get; }
	public static object productName { get; }
	public static object targetFrameRate { get; set; }
	public static object backgroundLoadingPriority { get; set; }
	public static object platform { get; }
	public static object isMobilePlatform { get; }
	public static object systemLanguage { get; }
	public static object internetReachability { get; }
	public static object vulkanEnablePreTransform { get; }
	public static object enableNativeGfxJobs { get; }
	public static object isEditor { get; }

	// Methods

	// RVA: 0x7352550
	public static object Quit(object exitCode) { }

	// RVA: 0x73525A0
	public static object Quit() { }

	// RVA: 0x735263C
	public static object get_isPlaying() { }

	// RVA: 0x735267C
	public static object get_isFocused() { }

	// RVA: 0x73526BC
	public static object set_runInBackground(object value) { }

	// RVA: 0x735270C
	public static object get_isBatchMode() { }

	// RVA: 0x735274C
	public static object get_dataPath() { }

	// RVA: 0x735278C
	public static object get_streamingAssetsPath() { }

	// RVA: 0x73527CC
	public static object get_persistentDataPath() { }

	// RVA: 0x735280C
	public static object get_temporaryCachePath() { }

	// RVA: 0x735284C
	public static object get_unityVersion() { }

	// RVA: 0x735288C
	public static object get_unityBuildVersion() { }

	// RVA: 0x73528CC
	public static object get_productName() { }

	// RVA: 0x735290C
	public static object OpenURL(object url) { }

	// RVA: 0x735295C
	public static object SetPreferIOSDisplaylink(object bPrefer) { }

	// RVA: 0x73529AC
	public static object get_targetFrameRate() { }

	// RVA: 0x73529EC
	public static object set_targetFrameRate(object value) { }

	// RVA: 0x7352A3C
	private static object SetLogCallbackDefined(object defined) { }

	// RVA: 0x7352A8C
	private static object CallFataErrorCallback(object module, object error, object invokedOnMainThread) { }

	// RVA: 0x7352B78
	public static object SetStackTraceLogType(object logType, object stackTraceType) { }

	// RVA: 0x7352BDC
	public static object get_backgroundLoadingPriority() { }

	// RVA: 0x7352C1C
	public static object set_backgroundLoadingPriority(object value) { }

	// RVA: 0x7352C6C
	public static object RequestUserAuthorization(object mode) { }

	// RVA: 0x7352CBC
	public static object HasUserAuthorization(object mode) { }

	// RVA: 0x7352D0C
	public static object GetDrawStats() { }

	// RVA: 0x7352E1C
	public static object GetWaitForPresentTime() { }

	// RVA: 0x7352E5C
	public static object SupportsBackbufferSRGB() { }

	// RVA: 0x7352E9C
	public static object get_platform() { }

	// RVA: 0x7352EDC
	public static object get_isMobilePlatform() { }

	// RVA: 0x7352FC0
	public static object get_systemLanguage() { }

	// RVA: 0x7353000
	public static object get_internetReachability() { }

	// RVA: 0x7353040
	public static object get_vulkanEnablePreTransform() { }

	// RVA: 0x7353080
	public static object get_enableNativeGfxJobs() { }

	// RVA: 0x73530C0
	public static object add_lowMemory(object value) { }

	// RVA: 0x73531B0
	public static object remove_lowMemory(object value) { }

	// RVA: 0x73532A0
	internal static object CallLowMemory(object usage) { }

	// RVA: 0x7353404
	internal static object HasLogCallback() { }

	// RVA: 0x73534C4
	public static object add_logMessageReceived(object value) { }

	// RVA: 0x73535F0
	public static object remove_logMessageReceived(object value) { }

	// RVA: 0x73536E8
	public static object add_logMessageReceivedThreaded(object value) { }

	// RVA: 0x7353814
	public static object remove_logMessageReceivedThreaded(object value) { }

	// RVA: 0x735390C
	private static object CallLogCallback(object logString, object stackTrace, object type, object invokedOnMainThread) { }

	// RVA: 0x7353A04
	private static object Internal_ApplicationWantsToQuit() { }

	// RVA: 0x7353DB4
	private static object Internal_ApplicationQuit() { }

	// RVA: 0x7353EBC
	private static object Internal_ApplicationUnload() { }

	// RVA: 0x7353F74
	internal static object InvokeOnBeforeRender() { }

	// RVA: 0x73541BC
	internal static object InvokeFocusChanged(object focus) { }

	// RVA: 0x7354288
	internal static object InvokeDeepLinkActivated(object url) { }

	// RVA: 0x7354354
	public static object LoadLevel(object name) { }

	// RVA: 0x73543BC
	public static object get_isEditor() { }

	// RVA: 0x73543C4
	private static object .cctor() { }

	// RVA: 0x7352DCC
	private static object GetDrawStats_Injected(object ret) { }

}

// Namespace: UnityEngine
public enum ApplicationMemoryUsage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Low;
	public const object Medium;
	public const object High;
	public const object Critical;
}

// Namespace: UnityEngine
public struct ApplicationMemoryUsageChange
{

	// Fields
	private object <memoryUsage>k__BackingField; // 0xFFFFFFFFFFFFFFF8

	// Properties
	private object memoryUsage { set; }

	// Methods

	// RVA: 0x7354A24
	private object set_memoryUsage(object value) { }

	// RVA: 0x73533FC
	public object .ctor(object usage) { }

}

// Namespace: UnityEngine
public enum StackTraceLogType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ScriptOnly;
	public const object Full;
}

// Namespace: UnityEngine
public enum NetworkReachability
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NotReachable;
	public const object ReachableViaCarrierDataNetwork;
	public const object ReachableViaLocalAreaNetwork;
}

// Namespace: UnityEngine
public enum UserAuthorization
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WebCam;
	public const object Microphone;
}

// Namespace: UnityEngine
public enum SendMessageOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RequireReceiver;
	public const object DontRequireReceiver;
}

// Namespace: UnityEngine
public enum PrimitiveType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Sphere;
	public const object Capsule;
	public const object Cylinder;
	public const object Cube;
	public const object Plane;
	public const object Quad;
}

// Namespace: UnityEngine
public enum Space
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object World;
	public const object Self;
}

// Namespace: UnityEngine
public enum RuntimePlatform
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OSXEditor;
	public const object OSXPlayer;
	public const object WindowsPlayer;
	public const object OSXWebPlayer;
	public const object OSXDashboardPlayer;
	public const object WindowsWebPlayer;
	public const object WindowsEditor;
	public const object IPhonePlayer;
	public const object XBOX360;
	public const object PS3;
	public const object Android;
	public const object NaCl;
	public const object FlashPlayer;
	public const object LinuxPlayer;
	public const object LinuxEditor;
	public const object WebGLPlayer;
	public const object MetroPlayerX86;
	public const object WSAPlayerX86;
	public const object MetroPlayerX64;
	public const object WSAPlayerX64;
	public const object MetroPlayerARM;
	public const object WSAPlayerARM;
	public const object WP8Player;
	public const object BlackBerryPlayer;
	public const object TizenPlayer;
	public const object PSP2;
	public const object PS4;
	public const object PSM;
	public const object XboxOne;
	public const object SamsungTVPlayer;
	public const object WiiU;
	public const object tvOS;
	public const object Switch;
	public const object Lumin;
	public const object Stadia;
	public const object CloudRendering;
	public const object GameCoreScarlett;
	public const object GameCoreXboxSeries;
	public const object GameCoreXboxOne;
	public const object PS5;
	public const object EmbeddedLinuxArm64;
	public const object EmbeddedLinuxArm32;
	public const object EmbeddedLinuxX64;
	public const object EmbeddedLinuxX86;
	public const object LinuxServer;
	public const object WindowsServer;
	public const object OSXServer;
	public const object QNXArm32;
	public const object QNXArm64;
	public const object QNXX64;
	public const object QNXX86;
	public const object OpenHarmony;
}

// Namespace: UnityEngine
public enum SystemLanguage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Afrikaans;
	public const object Arabic;
	public const object Basque;
	public const object Belarusian;
	public const object Bulgarian;
	public const object Catalan;
	public const object Chinese;
	public const object Czech;
	public const object Danish;
	public const object Dutch;
	public const object English;
	public const object Estonian;
	public const object Faroese;
	public const object Finnish;
	public const object French;
	public const object German;
	public const object Greek;
	public const object Hebrew;
	public const object Icelandic;
	public const object Indonesian;
	public const object Italian;
	public const object Japanese;
	public const object Korean;
	public const object Latvian;
	public const object Lithuanian;
	public const object Norwegian;
	public const object Polish;
	public const object Portuguese;
	public const object Romanian;
	public const object Russian;
	public const object SerboCroatian;
	public const object Slovak;
	public const object Slovenian;
	public const object Spanish;
	public const object Swedish;
	public const object Thai;
	public const object Turkish;
	public const object Ukrainian;
	public const object Vietnamese;
	public const object ChineseSimplified;
	public const object ChineseTraditional;
	public const object Hindi;
	public const object Unknown;
	public const object Hungarian;
}

// Namespace: UnityEngine
public enum LogType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Error;
	public const object Assert;
	public const object Warning;
	public const object Log;
	public const object Exception;
}

// Namespace: UnityEngine
public enum LogOption
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NoStacktrace;
}

// Namespace: UnityEngine
public enum ThreadPriority
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Low;
	public const object BelowNormal;
	public const object Normal;
	public const object High;
}

// Namespace: UnityEngine
internal class BootConfigData
{

	// Fields
	private object m_Ptr; // 0x8

	// Methods

	// RVA: 0x7354A3C
	private static object WrapBootConfigData(object nativeHandle) { }

	// RVA: 0x7354AA0
	private object .ctor(object nativeHandle) { }

}

// Namespace: UnityEngine
public sealed class AraTrail
{

	// Methods

	// RVA: 0x7354B28
	public static object PreCullAraTrail(object camera) { }

}

// Namespace: 
public enum MonoOrStereoscopicEye
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
	public const object Mono;
}

// Namespace: 
public enum SceneViewFilterMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object ShowFiltered;
}

// Namespace: 
public sealed class CameraCallback
{

	// Methods

	// RVA: 0x73581A8
	public object .ctor(object object, object method) { }

	// RVA: 0x7358250
	public virtual object Invoke(object cam) { }

}

// Namespace: UnityEngine
public sealed class Camera
{

	// Fields
	public const object kMinAperture;
	public const object kMaxAperture;
	public const object kMinBladeCount;
	public const object kMaxBladeCount;
	public static object onPreCull; // 0x0
	public static object onPreRender; // 0x8
	public static object onPostRender; // 0x10

	// Properties
	public object nearClipPlane { get; set; }
	public object farClipPlane { get; set; }
	public object fieldOfView { get; set; }
	public object renderingPath { get; set; }
	public object allowHDR { get; set; }
	public object allowMSAA { get; set; }
	public object orthographicSize { get; set; }
	public object orthographic { get; set; }
	public object depth { get; set; }
	public object aspect { get; set; }
	public object cullingMask { get; set; }
	public object eventMask { get; }
	public object cameraType { get; set; }
	public object useOcclusionCulling { get; set; }
	public object cullingMatrix { set; }
	public object backgroundColor { get; set; }
	public object clearFlags { get; set; }
	public object depthTextureMode { get; set; }
	public object rect { get; set; }
	public object pixelRect { get; set; }
	public object pixelWidth { get; }
	public object pixelHeight { get; }
	public object targetTexture { get; set; }
	public object activeTexture { get; }
	public object targetDisplay { get; }
	public object cameraToWorldMatrix { get; }
	public object worldToCameraMatrix { get; set; }
	public object projectionMatrix { get; set; }
	public object nonJitteredProjectionMatrix { get; set; }
	public static object main { get; }
	public static object current { get; }
	public static object allCamerasCount { get; }
	public static object allCameras { get; }
	public object sceneViewFilterMode { get; }
	public object commandBufferCount { get; }

	// Methods

	// RVA: 0x7354B78
	public object .ctor() { }

	// RVA: 0x7354B80
	public object get_nearClipPlane() { }

	// RVA: 0x7354BD0
	public object set_nearClipPlane(object value) { }

	// RVA: 0x7354C34
	public object get_farClipPlane() { }

	// RVA: 0x7354C84
	public object set_farClipPlane(object value) { }

	// RVA: 0x7354CE8
	public object get_fieldOfView() { }

	// RVA: 0x7354D38
	public object set_fieldOfView(object value) { }

	// RVA: 0x7354D9C
	public object get_renderingPath() { }

	// RVA: 0x7354DEC
	public object set_renderingPath(object value) { }

	// RVA: 0x7354E50
	public object get_allowHDR() { }

	// RVA: 0x7354EA0
	public object set_allowHDR(object value) { }

	// RVA: 0x7354F04
	public object get_allowMSAA() { }

	// RVA: 0x7354F54
	public object set_allowMSAA(object value) { }

	// RVA: 0x7354FB8
	public object get_orthographicSize() { }

	// RVA: 0x7355008
	public object set_orthographicSize(object value) { }

	// RVA: 0x735506C
	public object get_orthographic() { }

	// RVA: 0x73550BC
	public object set_orthographic(object value) { }

	// RVA: 0x7355120
	public object get_depth() { }

	// RVA: 0x7355170
	public object set_depth(object value) { }

	// RVA: 0x73551D4
	public object get_aspect() { }

	// RVA: 0x7355224
	public object set_aspect(object value) { }

	// RVA: 0x7355288
	public object get_cullingMask() { }

	// RVA: 0x73552D8
	public object set_cullingMask(object value) { }

	// RVA: 0x735533C
	public object get_eventMask() { }

	// RVA: 0x735538C
	public object get_cameraType() { }

	// RVA: 0x73553DC
	public object set_cameraType(object value) { }

	// RVA: 0x7355440
	public object get_useOcclusionCulling() { }

	// RVA: 0x7355490
	public object set_useOcclusionCulling(object value) { }

	// RVA: 0x73554F4
	public object set_cullingMatrix(object value) { }

	// RVA: 0x73555BC
	public object get_backgroundColor() { }

	// RVA: 0x7355680
	public object set_backgroundColor(object value) { }

	// RVA: 0x7355758
	public object get_clearFlags() { }

	// RVA: 0x73557A8
	public object set_clearFlags(object value) { }

	// RVA: 0x735580C
	public object get_depthTextureMode() { }

	// RVA: 0x735585C
	public object set_depthTextureMode(object value) { }

	// RVA: 0x73558C0
	public object SetReplacementShader(object shader, object replacementTag) { }

	// RVA: 0x735592C
	public object get_rect() { }

	// RVA: 0x73559F0
	public object set_rect(object value) { }

	// RVA: 0x7355AC8
	public object get_pixelRect() { }

	// RVA: 0x7355B8C
	public object set_pixelRect(object value) { }

	// RVA: 0x7355C64
	public object get_pixelWidth() { }

	// RVA: 0x7355CB4
	public object get_pixelHeight() { }

	// RVA: 0x7355D04
	public object get_targetTexture() { }

	// RVA: 0x7355D54
	public object set_targetTexture(object value) { }

	// RVA: 0x7355DB8
	public object get_activeTexture() { }

	// RVA: 0x7355E08
	public object get_targetDisplay() { }

	// RVA: 0x7355E58
	private object SetTargetBuffersImpl(object color, object depth) { }

	// RVA: 0x7355F24
	public object SetTargetBuffers(object colorBuffer, object depthBuffer) { }

	// RVA: 0x7355F84
	public object get_cameraToWorldMatrix() { }

	// RVA: 0x7356064
	public object get_worldToCameraMatrix() { }

	// RVA: 0x7356144
	public object set_worldToCameraMatrix(object value) { }

	// RVA: 0x735620C
	public object get_projectionMatrix() { }

	// RVA: 0x73562EC
	public object set_projectionMatrix(object value) { }

	// RVA: 0x73563B4
	public object get_nonJitteredProjectionMatrix() { }

	// RVA: 0x7356494
	public object set_nonJitteredProjectionMatrix(object value) { }

	// RVA: 0x735655C
	public object ResetWorldToCameraMatrix() { }

	// RVA: 0x73565AC
	public object ResetProjectionMatrix() { }

	// RVA: 0x73565FC
	public object CalculateObliqueMatrix(object clipPlane) { }

	// RVA: 0x73566F0
	public object WorldToScreenPoint(object position, object eye) { }

	// RVA: 0x73567F0
	public object WorldToViewportPoint(object position, object eye) { }

	// RVA: 0x73568F0
	public object ViewportToWorldPoint(object position, object eye) { }

	// RVA: 0x73569F0
	public object ScreenToWorldPoint(object position, object eye) { }

	// RVA: 0x7356AF0
	public object WorldToScreenPoint(object position) { }

	// RVA: 0x7356B64
	public object WorldToViewportPoint(object position) { }

	// RVA: 0x7356BD8
	public object ViewportToWorldPoint(object position) { }

	// RVA: 0x7356C4C
	public object ScreenToWorldPoint(object position) { }

	// RVA: 0x7356CC0
	public object ScreenToViewportPoint(object position) { }

	// RVA: 0x7356D9C
	private object ViewportPointToRay(object pos, object eye) { }

	// RVA: 0x7356EA4
	public object ViewportPointToRay(object pos, object eye) { }

	// RVA: 0x7356F34
	public object ViewportPointToRay(object pos) { }

	// RVA: 0x7356FC0
	private object ScreenPointToRay(object pos, object eye) { }

	// RVA: 0x73570C8
	public object ScreenPointToRay(object pos, object eye) { }

	// RVA: 0x7357158
	public object ScreenPointToRay(object pos) { }

	// RVA: 0x73571E4
	private object CalculateFrustumCornersInternal(object viewport, object z, object eye, object outCorners) { }

	// RVA: 0x73572FC
	public object CalculateFrustumCorners(object viewport, object z, object eye, object outCorners) { }

	// RVA: 0x7357438
	public static object get_main() { }

	// RVA: 0x7357478
	public static object get_current() { }

	// RVA: 0x73574B8
	private static object GetAllCamerasCount() { }

	// RVA: 0x73574F8
	private static object GetAllCamerasImpl(object cam) { }

	// RVA: 0x7357548
	public static object get_allCamerasCount() { }

	// RVA: 0x7357588
	public static object get_allCameras() { }

	// RVA: 0x735763C
	public static object GetAllCameras(object cameras) { }

	// RVA: 0x7357738
	private object RenderToCubemapImpl(object tex, object faceMask) { }

	// RVA: 0x73577A4
	public object RenderToCubemap(object cubemap, object faceMask) { }

	// RVA: 0x7357810
	private object GetFilterMode() { }

	// RVA: 0x7357860
	public object get_sceneViewFilterMode() { }

	// RVA: 0x73578B0
	public object Render() { }

	// RVA: 0x7357900
	public object RenderWithShader(object shader, object replacementTag) { }

	// RVA: 0x735796C
	public object RenderDontRestore() { }

	// RVA: 0x73579BC
	public static object SetupCurrent(object cur) { }

	// RVA: 0x7357A0C
	public object CopyFrom(object other) { }

	// RVA: 0x7357A70
	public object get_commandBufferCount() { }

	// RVA: 0x7357AC0
	public object RemoveAllCommandBuffers() { }

	// RVA: 0x7357B10
	private object AddCommandBufferImpl(object evt, object buffer) { }

	// RVA: 0x7357B7C
	private object RemoveCommandBufferImpl(object evt, object buffer) { }

	// RVA: 0x7357BE8
	public object AddCommandBuffer(object evt, object buffer) { }

	// RVA: 0x7357D28
	public object RemoveCommandBuffer(object evt, object buffer) { }

	// RVA: 0x7357E68
	public object GetCommandBuffers(object evt) { }

	// RVA: 0x7357ECC
	private static object FireOnPreCull(object cam) { }

	// RVA: 0x7357F48
	private static object FireOnPreRender(object cam) { }

	// RVA: 0x7357FC4
	private static object FireOnPostRender(object cam) { }

	// RVA: 0x7358040
	public object TryGetCullingParameters(object cullingParameters) { }

	// RVA: 0x735809C
	private static object GetCullingParameters_Internal(object camera, object stereoAware, object cullingParameters, object managedCullingParametersSize) { }

	// RVA: 0x7355558
	private object set_cullingMatrix_Injected(object value) { }

	// RVA: 0x735561C
	private object get_backgroundColor_Injected(object ret) { }

	// RVA: 0x73556F4
	private object set_backgroundColor_Injected(object value) { }

	// RVA: 0x735598C
	private object get_rect_Injected(object ret) { }

	// RVA: 0x7355A64
	private object set_rect_Injected(object value) { }

	// RVA: 0x7355B28
	private object get_pixelRect_Injected(object ret) { }

	// RVA: 0x7355C00
	private object set_pixelRect_Injected(object value) { }

	// RVA: 0x7355EB8
	private object SetTargetBuffersImpl_Injected(object color, object depth) { }

	// RVA: 0x7356000
	private object get_cameraToWorldMatrix_Injected(object ret) { }

	// RVA: 0x73560E0
	private object get_worldToCameraMatrix_Injected(object ret) { }

	// RVA: 0x73561A8
	private object set_worldToCameraMatrix_Injected(object value) { }

	// RVA: 0x7356288
	private object get_projectionMatrix_Injected(object ret) { }

	// RVA: 0x7356350
	private object set_projectionMatrix_Injected(object value) { }

	// RVA: 0x7356430
	private object get_nonJitteredProjectionMatrix_Injected(object ret) { }

	// RVA: 0x73564F8
	private object set_nonJitteredProjectionMatrix_Injected(object value) { }

	// RVA: 0x7356684
	private object CalculateObliqueMatrix_Injected(object clipPlane, object ret) { }

	// RVA: 0x7356770
	private object WorldToScreenPoint_Injected(object position, object eye, object ret) { }

	// RVA: 0x7356870
	private object WorldToViewportPoint_Injected(object position, object eye, object ret) { }

	// RVA: 0x7356970
	private object ViewportToWorldPoint_Injected(object position, object eye, object ret) { }

	// RVA: 0x7356A70
	private object ScreenToWorldPoint_Injected(object position, object eye, object ret) { }

	// RVA: 0x7356D30
	private object ScreenToViewportPoint_Injected(object position, object ret) { }

	// RVA: 0x7356E24
	private object ViewportPointToRay_Injected(object pos, object eye, object ret) { }

	// RVA: 0x7357048
	private object ScreenPointToRay_Injected(object pos, object eye, object ret) { }

	// RVA: 0x7357268
	private object CalculateFrustumCornersInternal_Injected(object viewport, object z, object eye, object outCorners) { }

}

// Namespace: UnityEngine
public struct BoundingSphere
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object radius; // 0x4

	// Methods

	// RVA: 0x7358264
	public object .ctor(object pos, object rad) { }

}

// Namespace: UnityEngine
internal enum CullingQueryOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object IgnoreVisibility;
	public const object IgnoreDistance;
}

// Namespace: UnityEngine
public struct CullingGroupEvent
{

	// Fields
	private object m_Index; // 0xFFFFFFFFFFFFFFF8
	private object m_PrevState; // 0xFFFFFFFFFFFFFFFC
	private object m_ThisState; // 0xFFFFFFFFFFFFFFFD
}

// Namespace: 
public sealed class StateChanged
{

	// Methods

	// RVA: 0x73587A0
	public object .ctor(object object, object method) { }

	// RVA: 0x7358838
	public virtual object Invoke(object sphere) { }

}

// Namespace: UnityEngine
public class CullingGroup
{

	// Fields
	internal object m_Ptr; // 0x8
	private object m_OnStateChanged; // 0x10

	// Methods

	// RVA: 0x7358318
	public object .ctor() { }

	// RVA: 0x73583D4
	protected override object Finalize() { }

	// RVA: 0x73584F4
	private object DisposeInternal() { }

	// RVA: 0x7358544
	public object Dispose() { }

	// RVA: 0x73585A4
	public object QueryIndices(object visible, object result, object firstIndex) { }

	// RVA: 0x7358618
	private object QueryIndices(object visible, object distanceIndex, object options, object result, object firstIndex) { }

	// RVA: 0x73586B4
	private static object SendEvents(object cullingGroup, object eventsPtr, object count) { }

	// RVA: 0x7358384
	private static object Init(object scripting) { }

	// RVA: 0x73584A4
	private object FinalizerFailure() { }

}

// Namespace: UnityEngine
public class FlareLayer
{
}

// Namespace: 
public enum ReflectionProbeEvent
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ReflectionProbeAdded;
	public const object ReflectionProbeRemoved;
}

// Namespace: UnityEngine
public sealed class ReflectionProbe
{

	// Fields
	private static object reflectionProbeChanged; // 0x0
	private static object registeredDefaultReflectionSetActions; // 0x8
	private static object registeredDefaultReflectionTextureActions; // 0x10

	// Properties
	public object mode { get; }
	public object bakedTexture { get; }
	public object customBakedTexture { get; }

	// Methods

	// RVA: 0x735884C
	public object get_mode() { }

	// RVA: 0x735889C
	public object get_bakedTexture() { }

	// RVA: 0x73588EC
	public object get_customBakedTexture() { }

	// RVA: 0x735893C
	private static object CallReflectionProbeEvent(object probe, object probeEvent) { }

	// RVA: 0x73589E8
	private static object CallSetDefaultReflection(object defaultReflectionCubemap) { }

	// RVA: 0x7358BD0
	private static object .cctor() { }

}

// Namespace: 
public struct ZSTD_inBuffer
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8
	public object Size; // 0x0
	public object Position; // 0x8
}

// Namespace: 
public struct ZSTD_outBuffer
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8
	public object Size; // 0x0
	public object Position; // 0x8
}

// Namespace: 
public enum ZSTD_cParameter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ZSTD_c_compressionLevel;
	public const object ZSTD_c_windowLog;
	public const object ZSTD_c_hashLog;
	public const object ZSTD_c_chainLog;
	public const object ZSTD_c_searchLog;
	public const object ZSTD_c_minMatch;
	public const object ZSTD_c_targetLength;
	public const object ZSTD_c_strategy;
	public const object ZSTD_c_enableLongDistanceMatching;
	public const object ZSTD_c_ldmHashLog;
	public const object ZSTD_c_ldmMinMatch;
	public const object ZSTD_c_ldmBucketSizeLog;
	public const object ZSTD_c_ldmHashRateLog;
	public const object ZSTD_c_contentSizeFlag;
	public const object ZSTD_c_checksumFlag;
	public const object ZSTD_c_dictIDFlag;
	public const object ZSTD_c_nbWorkers;
	public const object ZSTD_c_jobSize;
	public const object ZSTD_c_overlapLog;
}

// Namespace: UnityEngine
public sealed class Compression
{

	// Methods

	// RVA: 0x7358CB0
	public static object ZSTD_createCCtx() { }

	// RVA: 0x7358CF0
	public static object ZSTD_freeCCtx(object cctx) { }

	// RVA: 0x7358D40
	public static object ZSTD_CCtx_setParameter(object cctx, object param, object value) { }

	// RVA: 0x7358DAC
	public static object ZSTD_compress2(object cctx, object dst, object dstCapacity, object src, object srcSize) { }

	// RVA: 0x7358E34
	public static object ZSTD_createDCtx() { }

	// RVA: 0x7358E74
	public static object ZSTD_freeDCtx(object dctx) { }

	// RVA: 0x7358EC4
	public static object ZSTD_createDDict(object dictBuffer, object dictSize) { }

	// RVA: 0x7358F28
	public static object ZSTD_DCtx_refPrefix(object dctx, object prefix, object prefixSize) { }

	// RVA: 0x7358F94
	public static object ZSTD_decompressDCtx(object dctx, object dst, object dstCapacity, object src, object srcSize) { }

	// RVA: 0x735901C
	public static object ZSTD_getFrameContentSize(object src, object srcSize) { }

	// RVA: 0x7359080
	public static object ZSTD_isError(object code) { }

	// RVA: 0x73590D0
	public static object ZSTD_getErrorName(object code) { }

	// RVA: 0x7359120
	public static object ZSTD_createDStream() { }

	// RVA: 0x7359160
	public static object ZSTD_freeDStream(object zds) { }

	// RVA: 0x73591B0
	public static object ZSTD_resetDStream(object zds) { }

	// RVA: 0x7359200
	public static object ZSTD_initDStream_usingDDict(object zds, object ddict) { }

	// RVA: 0x7359264
	public static object ZSTD_decompressStream(object zds, object outputBuffer, object inputBuffer) { }

	// RVA: 0x73592D0
	public static object ZSTD_DStreamInSize() { }

	// RVA: 0x7359310
	public static object ZSTD_DStreamOutSize() { }

	// RVA: 0x7359350
	public static object ZSTD_compress_usingDict(object cctx, object dst, object dstCapacity, object src, object srcSize, object dict, object dictSize, object compressionLevel) { }

}

// Namespace: UnityEngine
public enum ConsoleVariableFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ECVF_FlagMask;
	public const object ECVF_Default;
	public const object ECVF_Cheat;
	public const object ECVF_ReadOnly;
	public const object ECVF_Unregistered;
	public const object ECVF_CreatedFromIni;
	public const object ECVF_RenderThreadSafe;
	public const object ECVF_Scalability;
	public const object ECVF_ScalabilityGroup;
	public const object ECVF_SetFlagMask;
	public const object ECVF_Set_NoSinkCall_Unsafe;
	public const object ECVF_SetByMask;
	public const object ECVF_SetByConstructor;
	public const object ECVF_SetByScalability;
	public const object ECVF_SetByGameSetting;
	public const object ECVF_SetByProjectSetting;
	public const object ECVF_SetBySystemSettingsIni;
	public const object ECVF_SetByDeviceProfile;
	public const object ECVF_SetByConsoleVariablesIni;
	public const object ECVF_SetByCommandline;
	public const object ECVF_SetByCode;
	public const object ECVF_SetByConsole;
}

// Namespace: UnityEngine
public class ConsoleManager
{

	// Methods

	// RVA: 0x73593EC
	private static object SetConsoleVariableString(object name, object InValue, object withCurrentPriority, object flags) { }

	// RVA: 0x735946C
	private static object SetConsoleVariableBool(object name, object InValue, object withCurrentPriority, object flags) { }

	// RVA: 0x73594EC
	private static object SetConsoleVariableFloat(object name, object InValue, object withCurrentPriority, object flags) { }

	// RVA: 0x735956C
	private static object SetConsoleVariableInt(object name, object InValue, object withCurrentPriority, object flags) { }

	// RVA: 0x73595EC
	public static object GetConsoleVariableBool(object name) { }

	// RVA: 0x735963C
	public static object SetConsoleVariable(object name, object InValue, object withCurrentPriority, object flags) { }

	// RVA: 0x73596BC
	public static object SetConsoleVariable(object name, object InValue, object withCurrentPriority, object flags) { }

	// RVA: 0x735973C
	public static object SetConsoleVariable(object name, object InValue, object withCurrentPriority, object flags) { }

	// RVA: 0x73597BC
	public static object SetConsoleVariable(object name, object InValue, object withCurrentPriority, object flags) { }

}

// Namespace: UnityEngine
internal sealed class DebugLogHandler
{

	// Methods

	// RVA: 0x735983C
	internal static object Internal_Log(object level, object options, object msg, object obj) { }

	// RVA: 0x73598BC
	internal static object Internal_LogException(object ex, object obj) { }

	// RVA: 0x7359920
	public object LogFormat(object logType, object context, object format, object args) { }

	// RVA: 0x735998C
	public object LogException(object exception, object context) { }

	// RVA: 0x7359A48
	public object .ctor() { }

}

// Namespace: UnityEngine
public class Debug
{

	// Fields
	internal static readonly object s_DefaultLogger; // 0x0
	internal static object s_Logger; // 0x8

	// Properties
	public static object unityLogger { get; }
	public static object isDebugBuild { get; }

	// Methods

	// RVA: 0x7359A50
	public static object get_unityLogger() { }

	// RVA: 0x7359ACC
	public static object DrawLine(object start, object end, object color) { }

	// RVA: 0x7359CF0
	public static object DrawLine(object start, object end) { }

	// RVA: 0x7359C10
	public static object DrawLine(object start, object end, object color, object duration, object depthTest) { }

	// RVA: 0x7359EA8
	public static object DrawRay(object start, object dir, object color) { }

	// RVA: 0x735A0E8
	public static object DrawRay(object start, object dir) { }

	// RVA: 0x7359F8C
	public static object DrawRay(object start, object dir, object color, object duration, object depthTest) { }

	// RVA: 0x735A19C
	public static object ExtractStackTraceNoAlloc(object buffer, object bufferMax, object projectFolder) { }

	// RVA: 0x735A208
	public static object Log(object message) { }

	// RVA: 0x735A3E8
	public static object Log(object message, object context) { }

	// RVA: 0x735A55C
	public static object LogFormat(object format, object args) { }

	// RVA: 0x735A6D0
	public static object LogError(object message) { }

	// RVA: 0x735A834
	public static object LogError(object message, object context) { }

	// RVA: 0x735A9A8
	public static object LogErrorFormat(object format, object args) { }

	// RVA: 0x735AB1C
	public static object LogErrorFormat(object context, object format, object args) { }

	// RVA: 0x7353C50
	public static object LogException(object exception) { }

	// RVA: 0x735AC94
	public static object LogException(object exception, object context) { }

	// RVA: 0x735AE04
	public static object LogWarning(object message) { }

	// RVA: 0x735AF68
	public static object LogWarning(object message, object context) { }

	// RVA: 0x735B0DC
	public static object LogWarningFormat(object format, object args) { }

	// RVA: 0x735B250
	public static object LogWarningFormat(object context, object format, object args) { }

	// RVA: 0x735B3C8
	public static object Assert(object condition) { }

	// RVA: 0x735B54C
	public static object Assert(object condition, object message) { }

	// RVA: 0x735B6BC
	public static object LogAssertion(object message) { }

	// RVA: 0x735B820
	public static object LogAssertionFormat(object format, object args) { }

	// RVA: 0x735B994
	public static object get_isDebugBuild() { }

	// RVA: 0x735B9D4
	internal static object CallOverridenDebugHandler(object exception, object obj) { }

	// RVA: 0x735BDD8
	internal static object IsLoggingEnabled() { }

	// RVA: 0x735C0CC
	private static object .cctor() { }

	// RVA: 0x7359E14
	private static object DrawLine_Injected(object start, object end, object color, object duration, object depthTest) { }

}

// Namespace: UnityEngine
public struct ExposedReference<T0>
{

	// Fields
	public object exposedName; // 0x0
	public object defaultValue; // 0x0

	// Methods

	// RVA: -1
	public object Resolve(object resolver) { }

}

// Namespace: UnityEngine
public interface IExposedPropertyTable
{

	// Methods

	// RVA: -1
	public abstract object GetReferenceValue(object id, object idValid) { }

}

// Namespace: 
internal class Expression
{

	// Fields
	internal readonly object rpnTokens; // 0x8
	internal readonly object hasVariables; // 0x10

	// Methods

	// RVA: 0x735EA8C
	internal object .ctor(object expression) { }

	// RVA: -1
	public object Evaluate(object value, object index, object count) { }

}

// Namespace: 
private struct PcgRandom
{

	// Fields
	private readonly object increment; // 0xFFFFFFFFFFFFFFF8
	private object state; // 0x0

	// Methods

	// RVA: 0x735EA18
	public object .ctor(object state, object sequence) { }

	// RVA: 0x735E468
	public object GetUInt() { }

	// RVA: 0x735EBA8
	private static object RotateRight(object v, object rot) { }

	// RVA: 0x735EB5C
	private static object XshRr(object s) { }

	// RVA: 0x735EB14
	private object Step() { }

}

// Namespace: 
private enum Op
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object Sub;
	public const object Mul;
	public const object Div;
	public const object Mod;
	public const object Neg;
	public const object Pow;
	public const object Sqrt;
	public const object Sin;
	public const object Cos;
	public const object Tan;
	public const object Floor;
	public const object Ceil;
	public const object Round;
	public const object Rand;
	public const object Linear;
}

// Namespace: 
private enum Associativity
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
}

// Namespace: 
private class Operator
{

	// Fields
	public readonly object op; // 0x8
	public readonly object precedence; // 0xC
	public readonly object associativity; // 0x10
	public readonly object inputs; // 0x14

	// Methods

	// RVA: 0x735EA40
	public object .ctor(object op, object precedence, object inputs, object associativity) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__14_0; // 0x8

	// Methods

	// RVA: 0x735EBD0
	private static object .cctor() { }

	// RVA: 0x735EC30
	public object .ctor() { }

	// RVA: 0x735EC38
	internal object <ExpressionToTokens>b__14_0(object f) { }

}

// Namespace: UnityEngine
public class ExpressionEvaluator
{

	// Fields
	private static object s_Random; // 0x0
	private static object s_Operators; // 0x10

	// Methods

	// RVA: -1
	internal static object Evaluate(object expression, object value, object delayed) { }

	// RVA: -1
	private static object EvaluateTokens(object tokens, object value, object index, object count) { }

	// RVA: 0x735C1B4
	private static object EvaluateDouble(object tokens, object value, object index, object count) { }

	// RVA: 0x735D0AC
	private static object InfixToRPN(object tokens) { }

	// RVA: 0x735D8A0
	private static object NeedToPop(object operatorStack, object newOperator) { }

	// RVA: 0x735DA70
	private static object ExpressionToTokens(object expression, object hasVariables) { }

	// RVA: 0x735CB9C
	private static object IsCommand(object token) { }

	// RVA: 0x735D044
	private static object IsVariable(object token) { }

	// RVA: 0x735D75C
	private static object IsDelayedFunction(object token) { }

	// RVA: 0x735CA20
	private static object IsOperator(object token) { }

	// RVA: 0x735CACC
	private static object TokenToOperator(object token) { }

	// RVA: 0x735E06C
	private static object PreFormatExpression(object expression) { }

	// RVA: 0x735E2DC
	private static object FixUnaryOperators(object tokens) { }

	// RVA: 0x735CCD8
	private static object EvaluateOp(object values, object op, object index, object count) { }

	// RVA: -1
	private static object TryParse(object expression, object result) { }

	// RVA: 0x735E49C
	private static object .cctor() { }

}

// Namespace: UnityEngine
public struct Bounds
{

	// Fields
	private object m_Center; // 0xFFFFFFFFFFFFFFF8
	private object m_Extents; // 0x4

	// Properties
	public object center { get; set; }
	public object size { get; set; }
	public object extents { get; set; }
	public object min { get; set; }
	public object max { get; set; }

	// Methods

	// RVA: 0x735ED38
	public object .ctor(object center, object size) { }

	// RVA: 0x735ED88
	public override object GetHashCode() { }

	// RVA: 0x735EF20
	public override object Equals(object other) { }

	// RVA: 0x735F0D8
	public object Equals(object other) { }

	// RVA: 0x735F180
	public object get_center() { }

	// RVA: 0x735F198
	public object set_center(object value) { }

	// RVA: 0x735F1B0
	public object get_size() { }

	// RVA: 0x735F1E0
	public object set_size(object value) { }

	// RVA: 0x735F220
	public object get_extents() { }

	// RVA: 0x735F238
	public object set_extents(object value) { }

	// RVA: 0x735F250
	public object get_min() { }

	// RVA: 0x735F290
	public object set_min(object value) { }

	// RVA: 0x735F330
	public object get_max() { }

	// RVA: 0x735F370
	public object set_max(object value) { }

	// RVA: 0x735F410
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x735F48C
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x735F50C
	public object SetMinMax(object min, object max) { }

	// RVA: 0x735F57C
	public object Encapsulate(object point) { }

	// RVA: 0x735F66C
	public object Encapsulate(object bounds) { }

	// RVA: 0x735F844
	public object Expand(object amount) { }

	// RVA: 0x735F894
	public object Expand(object amount) { }

	// RVA: 0x735F8F4
	public object Intersects(object bounds) { }

	// RVA: 0x735FA2C
	public object IntersectRay(object ray) { }

	// RVA: 0x735FB80
	public object IntersectRay(object ray, object distance) { }

	// RVA: 0x735FC68
	public override object ToString() { }

	// RVA: 0x735FC8C
	public object ToString(object format) { }

	// RVA: 0x735FCA8
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x735FE78
	public object Contains(object point) { }

	// RVA: 0x735FFA8
	public object SqrDistance(object point) { }

	// RVA: 0x735FAA0
	private static object IntersectRayAABB(object ray, object bounds, object dist) { }

	// RVA: 0x7360144
	public object ClosestPoint(object point) { }

	// RVA: 0x735FEEC
	private static object Contains_Injected(object _unity_self, object point) { }

	// RVA: 0x736001C
	private static object SqrDistance_Injected(object _unity_self, object point) { }

	// RVA: 0x73600D8
	private static object IntersectRayAABB_Injected(object ray, object bounds, object dist) { }

	// RVA: 0x73601B4
	private static object ClosestPoint_Injected(object _unity_self, object point, object ret) { }

}

// Namespace: UnityEngine
public struct BoundsInt
{

	// Fields
	private object m_Position; // 0xFFFFFFFFFFFFFFF8
	private object m_Size; // 0x4

	// Properties
	public object position { get; set; }
	public object size { get; set; }

	// Methods

	// RVA: 0x736028C
	public object get_position() { }

	// RVA: 0x73602AC
	public object set_position(object value) { }

	// RVA: 0x73602C4
	public object get_size() { }

	// RVA: 0x73602E4
	public object set_size(object value) { }

	// RVA: 0x73602FC
	public object .ctor(object position, object size) { }

	// RVA: 0x7360324
	public override object ToString() { }

	// RVA: 0x73604E4
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7360888
	public override object Equals(object other) { }

	// RVA: 0x7360AA8
	public object Equals(object other) { }

	// RVA: 0x7360B70
	public override object GetHashCode() { }

}

// Namespace: UnityEngine
public sealed class GeometryUtility
{

	// Methods

	// RVA: 0x7360D30
	public static object CalculateFrustumPlanes(object camera) { }

	// RVA: 0x7360EAC
	public static object CalculateFrustumPlanesNoAlloc(object worldToProjectionMatrix, object planes) { }

	// RVA: 0x7360D9C
	public static object CalculateFrustumPlanes(object camera, object planes) { }

	// RVA: 0x7360EEC
	public static object CalculateFrustumPlanes(object worldToProjectionMatrix, object planes) { }

	// RVA: 0x7361064
	public static object TestPlanesAABB(object planes, object bounds) { }

	// RVA: 0x7361000
	private static object Internal_ExtractPlanes(object planes, object worldToProjectionMatrix) { }

	// RVA: 0x73610C8
	private static object TestPlanesAABB_Injected(object planes, object bounds) { }

	// RVA: 0x736112C
	private static object Internal_ExtractPlanes_Injected(object planes, object worldToProjectionMatrix) { }

}

// Namespace: UnityEngine
public struct Plane
{

	// Fields
	internal const object size;
	private object m_Normal; // 0xFFFFFFFFFFFFFFF8
	private object m_Distance; // 0x4

	// Properties
	public object normal { get; set; }
	public object distance { get; set; }

	// Methods

	// RVA: 0x7361190
	public object get_normal() { }

	// RVA: 0x73611A8
	public object set_normal(object value) { }

	// RVA: 0x73611C0
	public object get_distance() { }

	// RVA: 0x73611D0
	public object set_distance(object value) { }

	// RVA: 0x73611E0
	public object .ctor(object inNormal, object inPoint) { }

	// RVA: 0x7361420
	public object .ctor(object inNormal, object d) { }

	// RVA: 0x7361628
	public object SetNormalAndPosition(object inNormal, object inPoint) { }

	// RVA: 0x7361868
	public object GetDistanceToPoint(object point) { }

	// RVA: 0x73618B0
	public object GetSide(object point) { }

	// RVA: 0x7361908
	public object Raycast(object ray, object enter) { }

	// RVA: 0x7361B20
	public override object ToString() { }

	// RVA: 0x7361D0C
	public object ToString(object format, object formatProvider) { }

}

// Namespace: UnityEngine
public struct Ray
{

	// Fields
	private object m_Origin; // 0xFFFFFFFFFFFFFFF8
	private object m_Direction; // 0x4

	// Properties
	public object origin { get; set; }
	public object direction { get; set; }

	// Methods

	// RVA: 0x7361EDC
	public object .ctor(object origin, object direction) { }

	// RVA: 0x73620EC
	public object get_origin() { }

	// RVA: 0x7362104
	public object set_origin(object value) { }

	// RVA: 0x736211C
	public object get_direction() { }

	// RVA: 0x7362134
	public object set_direction(object value) { }

	// RVA: 0x7362334
	public object GetPoint(object distance) { }

	// RVA: 0x7362384
	public override object ToString() { }

	// RVA: 0x73623A8
	public object ToString(object format) { }

	// RVA: 0x73623C4
	public object ToString(object format, object formatProvider) { }

}

// Namespace: UnityEngine
public struct Ray2D
{

	// Fields
	private object m_Origin; // 0xFFFFFFFFFFFFFFF8
	private object m_Direction; // 0x0

	// Properties
	public object origin { get; set; }
	public object direction { get; set; }

	// Methods

	// RVA: 0x7362594
	public object .ctor(object origin, object direction) { }

	// RVA: 0x7362784
	public object get_origin() { }

	// RVA: 0x7362794
	public object set_origin(object value) { }

	// RVA: 0x73627A4
	public object get_direction() { }

	// RVA: 0x73627B4
	public object set_direction(object value) { }

	// RVA: 0x736299C
	public object GetPoint(object distance) { }

	// RVA: 0x73629C4
	public override object ToString() { }

	// RVA: 0x73629E8
	public object ToString(object format) { }

	// RVA: 0x7362A04
	public object ToString(object format, object formatProvider) { }

}

// Namespace: UnityEngine
public struct Rect
{

	// Fields
	private object m_XMin; // 0xFFFFFFFFFFFFFFF8
	private object m_YMin; // 0xFFFFFFFFFFFFFFFC
	private object m_Width; // 0x0
	private object m_Height; // 0x4

	// Properties
	public static object zero { get; }
	public object x { get; set; }
	public object y { get; set; }
	public object position { get; set; }
	public object center { get; set; }
	public object min { get; set; }
	public object max { get; set; }
	public object width { get; set; }
	public object height { get; set; }
	public object size { get; set; }
	public object xMin { get; set; }
	public object yMin { get; set; }
	public object xMax { get; set; }
	public object yMax { get; set; }

	// Methods

	// RVA: 0x7362BD4
	public object .ctor(object x, object y, object width, object height) { }

	// RVA: 0x7362BEC
	public object .ctor(object position, object size) { }

	// RVA: 0x7362C04
	public object .ctor(object source) { }

	// RVA: 0x7362C1C
	public static object get_zero() { }

	// RVA: 0x7362C30
	public static object MinMaxRect(object xmin, object ymin, object xmax, object ymax) { }

	// RVA: 0x7362C3C
	public object Set(object x, object y, object width, object height) { }

	// RVA: 0x7362C54
	public object get_x() { }

	// RVA: 0x7362C64
	public object set_x(object value) { }

	// RVA: 0x7362C74
	public object get_y() { }

	// RVA: 0x7362C84
	public object set_y(object value) { }

	// RVA: 0x7362C94
	public object get_position() { }

	// RVA: 0x7362CA4
	public object set_position(object value) { }

	// RVA: 0x7362CB4
	public object get_center() { }

	// RVA: 0x7362CE4
	public object set_center(object value) { }

	// RVA: 0x7362D1C
	public object get_min() { }

	// RVA: 0x7362D2C
	public object set_min(object value) { }

	// RVA: 0x7362D64
	public object get_max() { }

	// RVA: 0x7362D84
	public object set_max(object value) { }

	// RVA: 0x7362DAC
	public object get_width() { }

	// RVA: 0x7362DBC
	public object set_width(object value) { }

	// RVA: 0x7362DCC
	public object get_height() { }

	// RVA: 0x7362DDC
	public object set_height(object value) { }

	// RVA: 0x7362DEC
	public object get_size() { }

	// RVA: 0x7362DFC
	public object set_size(object value) { }

	// RVA: 0x7362E0C
	public object get_xMin() { }

	// RVA: 0x7362E1C
	public object set_xMin(object value) { }

	// RVA: 0x7362E54
	public object get_yMin() { }

	// RVA: 0x7362E64
	public object set_yMin(object value) { }

	// RVA: 0x7362E9C
	public object get_xMax() { }

	// RVA: 0x7362EBC
	public object set_xMax(object value) { }

	// RVA: 0x7362EDC
	public object get_yMax() { }

	// RVA: 0x7362EFC
	public object set_yMax(object value) { }

	// RVA: 0x7362F1C
	public object Contains(object point) { }

	// RVA: 0x7362FA4
	public object Contains(object point) { }

	// RVA: 0x736302C
	private static object OrderMinMax(object rect) { }

	// RVA: 0x7363058
	public object Overlaps(object other) { }

	// RVA: 0x73630F0
	public object Overlaps(object other, object allowInverse) { }

	// RVA: 0x7363210
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7363234
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7363258
	public override object GetHashCode() { }

	// RVA: 0x7363380
	public override object Equals(object other) { }

	// RVA: 0x7363498
	public object Equals(object other) { }

	// RVA: 0x73635E8
	public override object ToString() { }

	// RVA: 0x73635F4
	public object ToString(object format, object formatProvider) { }

}

// Namespace: UnityEngine
public struct RectInt
{

	// Fields
	private object m_XMin; // 0xFFFFFFFFFFFFFFF8
	private object m_YMin; // 0xFFFFFFFFFFFFFFFC
	private object m_Width; // 0x0
	private object m_Height; // 0x4

	// Properties
	public object x { get; set; }
	public object y { get; set; }
	public object width { get; set; }
	public object height { get; set; }
	public object xMin { get; }
	public object yMin { get; }
	public object xMax { get; }
	public object yMax { get; }

	// Methods

	// RVA: 0x7363880
	public object get_x() { }

	// RVA: 0x7363890
	public object set_x(object value) { }

	// RVA: 0x73638A0
	public object get_y() { }

	// RVA: 0x73638B0
	public object set_y(object value) { }

	// RVA: 0x73638C0
	public object get_width() { }

	// RVA: 0x73638D0
	public object set_width(object value) { }

	// RVA: 0x73638E0
	public object get_height() { }

	// RVA: 0x73638F0
	public object set_height(object value) { }

	// RVA: 0x7363900
	public object get_xMin() { }

	// RVA: 0x73639E0
	public object get_yMin() { }

	// RVA: 0x7363AC0
	public object get_xMax() { }

	// RVA: 0x7363BA0
	public object get_yMax() { }

	// RVA: 0x7363C80
	public object .ctor(object xMin, object yMin, object width, object height) { }

	// RVA: 0x7363C98
	public object Overlaps(object other) { }

	// RVA: 0x73642F0
	public override object ToString() { }

	// RVA: 0x736455C
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x73647AC
	public object Equals(object other) { }

}

// Namespace: UnityEngine
public class RectOffset
{

	// Fields
	internal object m_Ptr; // 0x8
	private readonly object m_SourceStyle; // 0x10

	// Properties
	public object left { get; set; }
	public object right { get; set; }
	public object top { get; set; }
	public object bottom { get; set; }
	public object horizontal { get; }
	public object vertical { get; }

	// Methods

	// RVA: 0x736498C
	public object .ctor() { }

	// RVA: 0x7364A28
	internal object .ctor(object sourceStyle, object source) { }

	// RVA: 0x7364A60
	protected override object Finalize() { }

	// RVA: 0x7364BAC
	public object .ctor(object left, object right, object top, object bottom) { }

	// RVA: 0x7364EB0
	public override object ToString() { }

	// RVA: 0x7365198
	public object ToString(object format) { }

	// RVA: 0x73651A4
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7364B44
	private object Destroy() { }

	// RVA: 0x73649E8
	private static object InternalCreate() { }

	// RVA: 0x73655BC
	private static object InternalDestroy(object ptr) { }

	// RVA: 0x736547C
	public object get_left() { }

	// RVA: 0x7364D20
	public object set_left(object value) { }

	// RVA: 0x73654CC
	public object get_right() { }

	// RVA: 0x7364D84
	public object set_right(object value) { }

	// RVA: 0x736551C
	public object get_top() { }

	// RVA: 0x7364DE8
	public object set_top(object value) { }

	// RVA: 0x736556C
	public object get_bottom() { }

	// RVA: 0x7364E4C
	public object set_bottom(object value) { }

	// RVA: 0x736560C
	public object get_horizontal() { }

	// RVA: 0x736565C
	public object get_vertical() { }

	// RVA: 0x73656AC
	public object Add(object rect) { }

	// RVA: 0x7365784
	public object Remove(object rect) { }

	// RVA: 0x7365718
	private object Add_Injected(object rect, object ret) { }

	// RVA: 0x73657F0
	private object Remove_Injected(object rect, object ret) { }

}

// Namespace: UnityEngine
public sealed class DynamicGI
{

	// Methods

	// RVA: 0x736585C
	public static object UpdateEnvironment() { }

}

// Namespace: UnityEngine
public sealed class LightingSettings
{

	// Methods

	// RVA: 0x736589C
	internal object LightingSettingsDontStripMe() { }

}

// Namespace: UnityEngine
public sealed class Gizmos
{

	// Properties
	public static object color { get; set; }
	public static object matrix { get; set; }

	// Methods

	// RVA: 0x73658A0
	public static object DrawLine(object from, object to) { }

	// RVA: 0x7365960
	public static object DrawWireSphere(object center, object radius) { }

	// RVA: 0x7365A24
	public static object DrawSphere(object center, object radius) { }

	// RVA: 0x7365AE8
	public static object DrawWireCube(object center, object size) { }

	// RVA: 0x7365BA8
	public static object DrawCube(object center, object size) { }

	// RVA: 0x7365C68
	public static object DrawIcon(object center, object name, object allowScaling) { }

	// RVA: 0x7365CDC
	public static object DrawIcon(object center, object name, object allowScaling, object tint) { }

	// RVA: 0x7365DD0
	public static object get_color() { }

	// RVA: 0x7365E74
	public static object set_color(object value) { }

	// RVA: 0x7365F2C
	public static object get_matrix() { }

	// RVA: 0x7365FE4
	public static object set_matrix(object value) { }

	// RVA: 0x7366084
	public static object DrawRay(object from, object direction) { }

	// RVA: 0x73658FC
	private static object DrawLine_Injected(object from, object to) { }

	// RVA: 0x73659C0
	private static object DrawWireSphere_Injected(object center, object radius) { }

	// RVA: 0x7365A84
	private static object DrawSphere_Injected(object center, object radius) { }

	// RVA: 0x7365B44
	private static object DrawWireCube_Injected(object center, object size) { }

	// RVA: 0x7365C04
	private static object DrawCube_Injected(object center, object size) { }

	// RVA: 0x7365D50
	private static object DrawIcon_Injected(object center, object name, object allowScaling, object tint) { }

	// RVA: 0x7365E24
	private static object get_color_Injected(object ret) { }

	// RVA: 0x7365EDC
	private static object set_color_Injected(object value) { }

	// RVA: 0x7365F94
	private static object get_matrix_Injected(object ret) { }

	// RVA: 0x7366034
	private static object set_matrix_Injected(object value) { }

}

// Namespace: 
private struct OrderBlock
{

	// Fields
	internal object order; // 0xFFFFFFFFFFFFFFF8
	internal object callback; // 0x0
}

// Namespace: UnityEngine
internal static class BeforeRenderHelper
{

	// Fields
	private static object s_OrderBlocks; // 0x0

	// Methods

	// RVA: 0x7353FDC
	public static object Invoke() { }

	// RVA: 0x73660EC
	private static object .cctor() { }

}

// Namespace: UnityEngine
public static class CustomRenderTextureManager
{

	// Fields
	private static object textureLoaded; // 0x0
	private static object textureUnloaded; // 0x8

	// Methods

	// RVA: 0x7366220
	private static object InvokeOnTextureLoaded_Internal(object source) { }

	// RVA: 0x736629C
	private static object InvokeOnTextureUnloaded_Internal(object source) { }

}

// Namespace: 
public sealed class DisplaysUpdatedDelegate
{

	// Methods

	// RVA: 0x7366D2C
	public object .ctor(object object, object method) { }

	// RVA: 0x7366DC0
	public virtual object Invoke() { }

}

// Namespace: UnityEngine
public class Display
{

	// Fields
	internal object nativeDisplay; // 0x8
	public static object displays; // 0x0
	private static object _mainDisplay; // 0x8
	private static object m_ActiveEditorGameViewTarget; // 0x10
	private static object onDisplaysUpdated; // 0x18

	// Properties
	public object renderingWidth { get; }
	public object renderingHeight { get; }
	public object systemWidth { get; }
	public object systemHeight { get; }
	public static object main { get; }

	// Methods

	// RVA: 0x7366318
	internal object .ctor() { }

	// RVA: 0x7366360
	internal object .ctor(object nativeDisplay) { }

	// RVA: 0x736638C
	public object get_renderingWidth() { }

	// RVA: 0x73664BC
	public object get_renderingHeight() { }

	// RVA: 0x7366580
	public object get_systemWidth() { }

	// RVA: 0x73666B0
	public object get_systemHeight() { }

	// RVA: 0x7366774
	public static object RelativeMouseAt(object inputMouseCoordinates) { }

	// RVA: 0x73668E0
	public static object get_main() { }

	// RVA: 0x736695C
	internal static object RecreateDisplayList(object nativeDisplay) { }

	// RVA: 0x7366B20
	internal static object FireDisplaysUpdated() { }

	// RVA: 0x7366644
	private static object GetSystemExtImpl(object nativeDisplay, object w, object h) { }

	// RVA: 0x7366450
	private static object GetRenderingExtImpl(object nativeDisplay, object w, object h) { }

	// RVA: 0x7366860
	private static object RelativeMouseAtImpl(object x, object y, object rx, object ry) { }

	// RVA: 0x7366BD8
	private static object .cctor() { }

}

// Namespace: UnityEngine
internal enum EnabledOrientation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object kAutorotateToPortrait;
	public const object kAutorotateToPortraitUpsideDown;
	public const object kAutorotateToLandscapeLeft;
	public const object kAutorotateToLandscapeRight;
}

// Namespace: UnityEngine
public enum FullScreenMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ExclusiveFullScreen;
	public const object FullScreenWindow;
	public const object MaximizedWindow;
	public const object Windowed;
}

// Namespace: UnityEngine
public struct RefreshRate
{

	// Fields
	public object numerator; // 0xFFFFFFFFFFFFFFF8
	public object denominator; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object value { get; }

	// Methods

	// RVA: 0x7366DD4
	public object get_value() { }

	// RVA: 0x7366DFC
	public object Equals(object other) { }

	// RVA: 0x7366E7C
	public object CompareTo(object other) { }

	// RVA: 0x7366F34
	public override object ToString() { }

}

// Namespace: UnityEngine
public sealed class Screen
{

	// Properties
	public static object width { get; }
	public static object height { get; }
	public static object dpi { get; }
	public static object orientation { set; }
	public static object sleepTimeout { set; }
	public static object autorotateToPortrait { set; }
	public static object autorotateToPortraitUpsideDown { set; }
	public static object autorotateToLandscapeLeft { set; }
	public static object autorotateToLandscapeRight { set; }
	public static object currentResolution { get; }
	public static object fullScreen { get; }
	public static object deviceWidth { get; }
	public static object deviceHeight { get; }

	// Methods

	// RVA: 0x736700C
	public static object get_width() { }

	// RVA: 0x736704C
	public static object get_height() { }

	// RVA: 0x736708C
	public static object get_dpi() { }

	// RVA: 0x73670CC
	private static object RequestOrientation(object orient) { }

	// RVA: 0x736711C
	public static object set_orientation(object value) { }

	// RVA: 0x73671D8
	public static object set_sleepTimeout(object value) { }

	// RVA: 0x7367228
	private static object SetOrientationEnabled(object orient, object enabled) { }

	// RVA: 0x736728C
	public static object set_autorotateToPortrait(object value) { }

	// RVA: 0x73672E4
	public static object set_autorotateToPortraitUpsideDown(object value) { }

	// RVA: 0x736733C
	public static object set_autorotateToLandscapeLeft(object value) { }

	// RVA: 0x7367394
	public static object set_autorotateToLandscapeRight(object value) { }

	// RVA: 0x73673EC
	public static object get_currentResolution() { }

	// RVA: 0x736748C
	public static object get_fullScreen() { }

	// RVA: 0x73674CC
	public static object SetResolution(object width, object height, object fullscreenMode, object preferredRefreshRate) { }

	// RVA: 0x73675BC
	public static object SetResolution(object width, object height, object fullscreen, object preferredRefreshRate) { }

	// RVA: 0x736763C
	public static object SetResolution(object width, object height, object fullscreen) { }

	// RVA: 0x73676B8
	public static object get_deviceWidth() { }

	// RVA: 0x73676F8
	public static object get_deviceHeight() { }

	// RVA: 0x736743C
	private static object get_currentResolution_Injected(object ret) { }

	// RVA: 0x736753C
	private static object SetResolution_Injected(object width, object height, object fullscreenMode, object preferredRefreshRate) { }

}

// Namespace: UnityEngine
public struct RenderBuffer
{

	// Fields
	internal object m_RenderTextureInstanceID; // 0xFFFFFFFFFFFFFFF8
	internal object m_BufferPtr; // 0x0
}

// Namespace: UnityEngine
public enum ComputeBufferMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Immutable;
	public const object Dynamic;
	public const object Circular;
	public const object StreamOut;
	public const object SubUpdates;
}

// Namespace: UnityEngine
public class Graphics
{

	// Fields
	internal static readonly object kMaxDrawMeshInstanceCount; // 0x0
	internal static object s_RenderInstancedDataLayouts; // 0x8

	// Methods

	// RVA: 0x7367738
	private static object Internal_GetMaxDrawMeshInstanceCount() { }

	// RVA: 0x7367778
	private static object Internal_SetNullRT() { }

	// RVA: 0x73677B8
	private static object Internal_SetRTSimple(object color, object depth, object mip, object face, object depthSlice) { }

	// RVA: 0x7367910
	private static object CopyTexture_Slice_AllMips(object src, object srcElement, object dst, object dstElement) { }

	// RVA: 0x7367990
	private static object CopyTexture_Slice(object src, object srcElement, object srcMip, object dst, object dstElement, object dstMip) { }

	// RVA: 0x7367A2C
	private static object CopyTexture_Region(object src, object srcElement, object srcMip, object srcX, object srcY, object srcWidth, object srcHeight, object dst, object dstElement, object dstMip, object dstX, object dstY) { }

	// RVA: 0x7367AD8
	internal static object Internal_DrawTexture(object args) { }

	// RVA: 0x7367B28
	private static object Internal_DrawMesh(object mesh, object submeshIndex, object matrix, object material, object layer, object camera, object properties, object castShadows, object receiveShadows, object probeAnchor, object lightProbeUsage, object lightProbeProxyVolume) { }

	// RVA: 0x7367CF8
	private static object Internal_BlitMaterial5(object source, object dest, object mat, object pass, object setRT) { }

	// RVA: 0x7367D80
	private static object Blit2(object source, object dest) { }

	// RVA: 0x7367DE4
	public static object ExecuteCommandBuffer(object buffer) { }

	// RVA: 0x7367E34
	internal static object SetRenderTargetImpl(object colorBuffer, object depthBuffer, object mipLevel, object face, object depthSlice) { }

	// RVA: 0x7367F74
	internal static object SetRenderTargetImpl(object rt, object mipLevel, object face, object depthSlice) { }

	// RVA: 0x7368138
	public static object SetRenderTarget(object rt, object mipLevel, object face, object depthSlice) { }

	// RVA: 0x73681B8
	public static object CopyTexture(object src, object srcElement, object dst, object dstElement) { }

	// RVA: 0x7368274
	public static object CopyTexture(object src, object srcElement, object srcMip, object dst, object dstElement, object dstMip) { }

	// RVA: 0x7368348
	public static object CopyTexture(object src, object srcElement, object srcMip, object srcX, object srcY, object srcWidth, object srcHeight, object dst, object dstElement, object dstMip, object dstX, object dstY) { }

	// RVA: 0x7368444
	private static object DrawTextureImpl(object screenRect, object texture, object sourceRect, object leftBorder, object rightBorder, object topBorder, object bottomBorder, object color, object mat, object pass) { }

	// RVA: 0x73685B0
	public static object DrawTexture(object screenRect, object texture, object sourceRect, object leftBorder, object rightBorder, object topBorder, object bottomBorder, object color, object mat, object pass) { }

	// RVA: 0x7368710
	public static object DrawTexture(object screenRect, object texture, object sourceRect, object leftBorder, object rightBorder, object topBorder, object bottomBorder, object mat, object pass) { }

	// RVA: 0x7368834
	public static object DrawTexture(object screenRect, object texture, object leftBorder, object rightBorder, object topBorder, object bottomBorder, object mat, object pass) { }

	// RVA: 0x7368990
	public static object DrawTexture(object screenRect, object texture, object mat, object pass) { }

	// RVA: 0x7368B14
	public static object DrawMesh(object mesh, object matrix, object material, object layer, object camera, object submeshIndex, object properties, object castShadows, object receiveShadows, object probeAnchor, object lightProbeUsage, object lightProbeProxyVolume) { }

	// RVA: 0x7368D20
	public static object Blit(object source, object dest) { }

	// RVA: 0x7368DD8
	public static object Blit(object source, object dest, object mat, object pass) { }

	// RVA: 0x7368E98
	public static object Blit(object source, object dest, object mat) { }

	// RVA: 0x7368F9C
	public static object DrawMesh(object mesh, object matrix, object material, object layer) { }

	// RVA: 0x736905C
	public static object DrawMesh(object mesh, object matrix, object material, object layer, object camera, object submeshIndex, object properties, object castShadows, object receiveShadows, object probeAnchor, object useLightProbes) { }

	// RVA: 0x7369154
	public static object DrawTexture(object screenRect, object texture, object sourceRect, object leftBorder, object rightBorder, object topBorder, object bottomBorder, object color, object mat) { }

	// RVA: 0x73692B0
	public static object DrawTexture(object screenRect, object texture) { }

	// RVA: 0x7369348
	public static object SetRenderTarget(object rt) { }

	// RVA: 0x736940C
	private static object .cctor() { }

	// RVA: 0x7367888
	private static object Internal_SetRTSimple_Injected(object color, object depth, object mip, object face, object depthSlice) { }

	// RVA: 0x7367C34
	private static object Internal_DrawMesh_Injected(object mesh, object submeshIndex, object matrix, object material, object layer, object camera, object properties, object castShadows, object receiveShadows, object probeAnchor, object lightProbeUsage, object lightProbeProxyVolume) { }

}

// Namespace: UnityEngine
public sealed class GL
{

	// Properties
	public static object invertCulling { get; set; }
	public static object modelview { set; }

	// Methods

	// RVA: 0x73694C8
	public static object Vertex3(object x, object y, object z) { }

	// RVA: 0x7369538
	public static object Vertex(object v) { }

	// RVA: 0x73695A8
	public static object TexCoord3(object x, object y, object z) { }

	// RVA: 0x7369618
	public static object TexCoord(object v) { }

	// RVA: 0x7369688
	public static object TexCoord2(object x, object y) { }

	// RVA: 0x73696EC
	private static object ImmediateColor(object r, object g, object b, object a) { }

	// RVA: 0x7369764
	public static object Color(object c) { }

	// RVA: 0x73697DC
	public static object get_invertCulling() { }

	// RVA: 0x736981C
	public static object set_invertCulling(object value) { }

	// RVA: 0x736986C
	private static object SetViewMatrix(object m) { }

	// RVA: 0x736990C
	public static object set_modelview(object value) { }

	// RVA: 0x736997C
	public static object MultMatrix(object m) { }

	// RVA: 0x7369A1C
	public static object IssuePluginEvent(object eventID) { }

	// RVA: 0x7369A6C
	public static object PushMatrix() { }

	// RVA: 0x7369AAC
	public static object PopMatrix() { }

	// RVA: 0x7369AEC
	public static object LoadOrtho() { }

	// RVA: 0x7369B2C
	public static object LoadPixelMatrix() { }

	// RVA: 0x7369B6C
	public static object LoadProjectionMatrix(object mat) { }

	// RVA: 0x7369C0C
	public static object GetGPUProjectionMatrix(object proj, object renderIntoTexture) { }

	// RVA: 0x7369CFC
	private static object GLLoadPixelMatrixScript(object left, object right, object bottom, object top) { }

	// RVA: 0x7369D74
	public static object LoadPixelMatrix(object left, object right, object bottom, object top) { }

	// RVA: 0x7369DEC
	private static object GLIssuePluginEvent(object callback, object eventID) { }

	// RVA: 0x7369E50
	public static object IssuePluginEvent(object callback, object eventID) { }

	// RVA: 0x7369F24
	public static object Begin(object mode) { }

	// RVA: 0x7369F74
	public static object End() { }

	// RVA: 0x7369FB4
	private static object GLClear(object clearDepth, object clearColor, object backgroundColor, object depth) { }

	// RVA: 0x736A0B0
	public static object Clear(object clearDepth, object clearColor, object backgroundColor, object depth) { }

	// RVA: 0x736A12C
	public static object Clear(object clearDepth, object clearColor, object backgroundColor) { }

	// RVA: 0x736A19C
	public static object Viewport(object pixelRect) { }

	// RVA: 0x73698BC
	private static object SetViewMatrix_Injected(object m) { }

	// RVA: 0x73699CC
	private static object MultMatrix_Injected(object m) { }

	// RVA: 0x7369BBC
	private static object LoadProjectionMatrix_Injected(object mat) { }

	// RVA: 0x7369C90
	private static object GetGPUProjectionMatrix_Injected(object proj, object renderIntoTexture, object ret) { }

	// RVA: 0x736A030
	private static object GLClear_Injected(object clearDepth, object clearColor, object backgroundColor, object depth) { }

	// RVA: 0x736A204
	private static object Viewport_Injected(object pixelRect) { }

}

// Namespace: UnityEngine
public static class ScalableBufferManager
{

	// Properties
	public static object widthScaleFactor { get; }
	public static object heightScaleFactor { get; }

	// Methods

	// RVA: 0x736A254
	public static object get_widthScaleFactor() { }

	// RVA: 0x736A294
	public static object get_heightScaleFactor() { }

	// RVA: 0x736A2D4
	public static object ResizeBuffers(object widthScale, object heightScale) { }

}

// Namespace: UnityEngine
public sealed class LightmapData
{

	// Fields
	internal object m_Light; // 0x8
	internal object m_Dir; // 0x10
	internal object m_ShadowMask; // 0x18

	// Properties
	public object lightmapColor { get; set; }
	public object lightmapDir { get; set; }
	public object shadowMask { get; set; }

	// Methods

	// RVA: 0x736A36C
	public object get_lightmapColor() { }

	// RVA: 0x736A374
	public object set_lightmapColor(object value) { }

	// RVA: 0x736A37C
	public object get_lightmapDir() { }

	// RVA: 0x736A384
	public object set_lightmapDir(object value) { }

	// RVA: 0x736A38C
	public object get_shadowMask() { }

	// RVA: 0x736A394
	public object set_shadowMask(object value) { }

	// RVA: 0x736A39C
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class LightmapSettings
{

	// Properties
	public static object lightmaps { get; set; }
	public static object lightmapsMode { get; set; }

	// Methods

	// RVA: 0x736A3A4
	public static object get_lightmaps() { }

	// RVA: 0x736A3E4
	public static object set_lightmaps(object value) { }

	// RVA: 0x736A434
	public static object get_lightmapsMode() { }

	// RVA: 0x736A474
	public static object set_lightmapsMode(object value) { }

}

// Namespace: UnityEngine
public sealed class LightProbes
{

	// Fields
	private static object lightProbesUpdated; // 0x0
	private static object tetrahedralizationCompleted; // 0x8
	private static object needsRetetrahedralization; // 0x10

	// Methods

	// RVA: 0x736A4E0
	private static object Internal_CallLightProbesUpdatedFunction() { }

	// RVA: 0x736A548
	private static object Internal_CallTetrahedralizationCompletedFunction() { }

	// RVA: 0x736A5B0
	private static object Internal_CallNeedsRetetrahedralizationFunction() { }

}

// Namespace: UnityEngine
public enum HDRSettingResult
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object HDRSettingResult_Succeeded;
	public const object HDRSettingResult_NeedReboot;
	public const object HDRSettingResult_NotSupported;
	public const object HDRSettingResult_NotAllowed;
	public const object HDRSettingResult_Failed;
}

// Namespace: UnityEngine
public class HDROutputSettings
{

	// Fields
	private object m_DisplayIndex; // 0x8
	public static object displays; // 0x0
	private static object _mainDisplay; // 0x8

	// Methods

	// RVA: 0x736A618
	internal object .ctor() { }

	// RVA: 0x736A640
	public static object RequestHDRModeChangeEx(object wantsHDR, object isHDRContentAvailable) { }

	// RVA: 0x736A6A4
	public static object RequestHDRModeChangeEx2(object wantsHDR) { }

	// RVA: 0x736A6F4
	public static object IsHDREnabled() { }

	// RVA: 0x736A734
	public static object IsHDRAvailable() { }

	// RVA: 0x736A774
	public static object IsHDRWanted() { }

	// RVA: 0x736A7B4
	public static object SetHDRAllowed(object value) { }

	// RVA: 0x736A804
	public static object IsHDRAllowed() { }

	// RVA: 0x736A844
	public static object IsHDRSupported() { }

	// RVA: 0x736A884
	public static object FlushUserData() { }

	// RVA: 0x736A8C4
	private static object .cctor() { }

}

// Namespace: UnityEngine
public struct Resolution
{

	// Fields
	private object m_Width; // 0xFFFFFFFFFFFFFFF8
	private object m_Height; // 0xFFFFFFFFFFFFFFFC
	private object m_RefreshRate; // 0x0

	// Properties
	public object width { get; }
	public object height { get; }

	// Methods

	// RVA: 0x736A994
	public object get_width() { }

	// RVA: 0x736A9A4
	public object get_height() { }

	// RVA: 0x736A9B4
	public override object ToString() { }

}

// Namespace: UnityEngine
internal struct RenderInstancedDataLayout
{

	// Fields
	private readonly object <size>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private readonly object <offsetObjectToWorld>k__BackingField; // 0xFFFFFFFFFFFFFFFC
	private readonly object <offsetPrevObjectToWorld>k__BackingField; // 0x0
	private readonly object <offsetRenderingLayerMask>k__BackingField; // 0x4
}

// Namespace: UnityEngine
internal struct Internal_DrawTextureArguments
{

	// Fields
	public object screenRect; // 0xFFFFFFFFFFFFFFF8
	public object sourceRect; // 0x8
	public object leftBorder; // 0x18
	public object rightBorder; // 0x1C
	public object topBorder; // 0x20
	public object bottomBorder; // 0x24
	public object leftBorderColor; // 0x28
	public object rightBorderColor; // 0x38
	public object topBorderColor; // 0x48
	public object bottomBorderColor; // 0x58
	public object color; // 0x68
	public object borderWidths; // 0x78
	public object cornerRadiuses; // 0x88
	public object smoothCorners; // 0x98
	public object pass; // 0x9C
	public object texture; // 0xA0
	public object mat; // 0xA8
}

// Namespace: UnityEngine
public sealed class QualitySettings
{

	// Fields
	private static object activeQualityLevelChanged; // 0x0

	// Properties
	public static object pixelLightCount { get; set; }
	public static object antiAliasing { get; set; }
	public static object EnableSRP { get; set; }
	public static object skinWeights { get; set; }
	public static object names { get; }
	public static object activeColorSpace { get; }

	// Methods

	// RVA: 0x736AB84
	internal static object OnActiveQualityLevelChanged(object previousQualityLevel, object currentQualityLevel) { }

	// RVA: 0x736AC08
	public static object SetQualityLevel(object index) { }

	// RVA: 0x736ACC4
	public static object get_pixelLightCount() { }

	// RVA: 0x736AD04
	public static object set_pixelLightCount(object value) { }

	// RVA: 0x736AD54
	public static object get_antiAliasing() { }

	// RVA: 0x736AD94
	public static object set_antiAliasing(object value) { }

	// RVA: 0x736ADE4
	public static object get_EnableSRP() { }

	// RVA: 0x736AE24
	public static object set_EnableSRP(object value) { }

	// RVA: 0x736AE74
	public static object get_skinWeights() { }

	// RVA: 0x736AEB4
	public static object set_skinWeights(object value) { }

	// RVA: 0x736AF04
	public static object GetQualityLevel() { }

	// RVA: 0x736AC60
	public static object SetQualityLevel(object index, object applyExpensiveChanges) { }

	// RVA: 0x736AF44
	public static object get_names() { }

	// RVA: 0x736AF84
	public static object RequestHDRModeChangeEx(object wantsHDR, object isHDRContentAvailable) { }

	// RVA: 0x736B03C
	public static object RequestHDRModeChangeEx(object wantsHDR) { }

	// RVA: 0x736B0E8
	public static object IsHDREnabled() { }

	// RVA: 0x736B178
	public static object IsHDRAvailable() { }

	// RVA: 0x736B208
	public static object IsHDRWanted() { }

	// RVA: 0x736B298
	public static object SetHDRAllowed(object value) { }

	// RVA: 0x736B344
	public static object IsHDRAllowed() { }

	// RVA: 0x736B3D4
	public static object IsHDRSupported() { }

	// RVA: 0x736B464
	public static object FlushUserData() { }

	// RVA: 0x736B4F4
	public static object get_activeColorSpace() { }

}

// Namespace: UnityEngine
public sealed class ImageEffectAllowedInSceneView
{

	// Methods

	// RVA: 0x736B534
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class TrailRenderer
{

	// Properties
	public object time { get; set; }
	public object startWidth { get; set; }
	public object endWidth { get; set; }
	public object emitting { get; set; }
	public object positionCount { get; }

	// Methods

	// RVA: 0x736B53C
	public object get_time() { }

	// RVA: 0x736B58C
	public object set_time(object value) { }

	// RVA: 0x736B5F0
	public object get_startWidth() { }

	// RVA: 0x736B640
	public object set_startWidth(object value) { }

	// RVA: 0x736B6A4
	public object get_endWidth() { }

	// RVA: 0x736B6F4
	public object set_endWidth(object value) { }

	// RVA: 0x736B758
	public object get_emitting() { }

	// RVA: 0x736B7A8
	public object set_emitting(object value) { }

	// RVA: 0x736B80C
	public object get_positionCount() { }

	// RVA: 0x736B85C
	public object Clear() { }

}

// Namespace: UnityEngine
public sealed class LineRenderer
{

	// Properties
	public object startWidth { set; }
	public object endWidth { set; }
	public object useWorldSpace { set; }
	public object startColor { set; }
	public object endColor { set; }
	public object positionCount { set; }

	// Methods

	// RVA: 0x736B8AC
	public object SetWidth(object start, object end) { }

	// RVA: 0x736BA20
	public object SetColors(object start, object end) { }

	// RVA: 0x736BBB4
	public object SetVertexCount(object count) { }

	// RVA: 0x736B958
	public object set_startWidth(object value) { }

	// RVA: 0x736B9BC
	public object set_endWidth(object value) { }

	// RVA: 0x736BC7C
	public object set_useWorldSpace(object value) { }

	// RVA: 0x736BACC
	public object set_startColor(object value) { }

	// RVA: 0x736BB40
	public object set_endColor(object value) { }

	// RVA: 0x736BC18
	public object set_positionCount(object value) { }

	// RVA: 0x736BDA8
	public object SetPosition(object index, object position) { }

	// RVA: 0x736BCE0
	private object set_startColor_Injected(object value) { }

	// RVA: 0x736BD44
	private object set_endColor_Injected(object value) { }

	// RVA: 0x736BE14
	private object SetPosition_Injected(object index, object position) { }

}

// Namespace: UnityEngine
public sealed class MaterialPropertyBlock
{

	// Fields
	internal object m_Ptr; // 0x8

	// Methods

	// RVA: 0x736BE80
	private object SetIntImpl(object name, object value) { }

	// RVA: 0x736BEEC
	private object SetFloatImpl(object name, object value) { }

	// RVA: 0x736BF64
	private object SetVectorImpl(object name, object value) { }

	// RVA: 0x736C03C
	private object SetColorImpl(object name, object value) { }

	// RVA: 0x736C114
	private object SetMatrixImpl(object name, object value) { }

	// RVA: 0x736C1EC
	private object SetTextureImpl(object name, object value) { }

	// RVA: 0x736C258
	private object SetRenderTextureImpl(object name, object value, object element) { }

	// RVA: 0x736C2D8
	private object SetFloatArrayImpl(object name, object values, object count) { }

	// RVA: 0x736C358
	private object SetVectorArrayImpl(object name, object values, object count) { }

	// RVA: 0x736C3D8
	private static object CreateImpl() { }

	// RVA: 0x736C418
	private static object DestroyImpl(object mpb) { }

	// RVA: 0x736C468
	private object Clear(object keepMemory) { }

	// RVA: 0x736C4CC
	public object Clear() { }

	// RVA: 0x736C524
	public object RemoveFloatImpl(object nameID) { }

	// RVA: 0x736C588
	public object RemoveIntImpl(object nameID) { }

	// RVA: 0x736C5EC
	public object RemoveVectorImpl(object nameID) { }

	// RVA: 0x736C650
	public object RemoveMatrixImpl(object nameID) { }

	// RVA: 0x736C6B4
	public object RemoveTextureImpl(object nameID) { }

	// RVA: 0x736C718
	public object RemoveConstantBufferImpl(object nameID) { }

	// RVA: 0x736C77C
	public object RemoveBufferImpl(object nameID) { }

	// RVA: 0x736C7E0
	private object SetGlobalKeywordStateImpl(object keyword, object value) { }

	// RVA: -1
	public object Remove(object nameID, object constant) { }

	// RVA: 0x736C8B4
	private object SetFloatArray(object name, object values, object count) { }

	// RVA: 0x736C9F8
	private object SetVectorArray(object name, object values, object count) { }

	// RVA: 0x736CB3C
	public object .ctor() { }

	// RVA: 0x736CB98
	protected override object Finalize() { }

	// RVA: 0x736CCB8
	private object Dispose() { }

	// RVA: 0x736CD84
	public object SetInt(object nameID, object value) { }

	// RVA: 0x736CDF4
	public object SetFloat(object name, object value) { }

	// RVA: 0x736CEEC
	public object SetFloat(object nameID, object value) { }

	// RVA: 0x736CF64
	public object SetInteger(object name, object value) { }

	// RVA: 0x736D004
	public object SetInteger(object nameID, object value) { }

	// RVA: 0x736D070
	public object SetVector(object name, object value) { }

	// RVA: 0x736D124
	public object SetVector(object nameID, object value) { }

	// RVA: 0x736D190
	public object SetColor(object name, object value) { }

	// RVA: 0x736D244
	public object SetColor(object nameID, object value) { }

	// RVA: 0x736D2B0
	public object SetMatrix(object name, object value) { }

	// RVA: 0x736D350
	public object SetMatrix(object nameID, object value) { }

	// RVA: 0x736D3C4
	public object SetTexture(object name, object value) { }

	// RVA: 0x736D464
	public object SetTexture(object nameID, object value) { }

	// RVA: 0x736D4D0
	public object SetTexture(object name, object value, object element) { }

	// RVA: 0x736D580
	public object SetFloatArray(object name, object values) { }

	// RVA: 0x736D5F4
	public object SetVectorArray(object name, object values) { }

	// RVA: 0x736D6B4
	public object SetVectorArray(object nameID, object values) { }

	// RVA: 0x736D6D4
	public object EnableKeyword(object name) { }

	// RVA: 0x736D738
	public object EnableKeyword(object keyword) { }

	// RVA: 0x736D794
	public object DisableKeyword(object name) { }

	// RVA: 0x736D7F8
	public object DisableKeyword(object keyword) { }

	// RVA: 0x736BFD0
	private object SetVectorImpl_Injected(object name, object value) { }

	// RVA: 0x736C0A8
	private object SetColorImpl_Injected(object name, object value) { }

	// RVA: 0x736C180
	private object SetMatrixImpl_Injected(object name, object value) { }

	// RVA: 0x736C848
	private object SetGlobalKeywordStateImpl_Injected(object keyword, object value) { }

}

// Namespace: UnityEngine
public class Renderer
{

	// Properties
	public object bounds { get; }
	public object localBounds { set; }
	public object enabled { get; set; }
	public object isVisible { get; }
	public object shadowCastingMode { get; set; }
	public object receiveShadows { get; set; }
	public object giType { get; set; }
	public object forceRenderingOff { get; set; }
	public object staticShadowCaster { get; }
	public object motionVectorGenerationMode { get; set; }
	public object lightProbeUsage { get; set; }
	public object reflectionProbeUsage { get; set; }
	public object renderingLayerMask { set; }
	public object sortingLayerID { get; set; }
	public object sortingOrder { get; set; }
	internal object sortingGroupID { get; }
	internal object sortingGroupOrder { get; }
	public object isPartOfStaticBatch { get; }
	public object localToWorldMatrix { get; }
	public object probeAnchor { get; set; }
	public object lightmapIndex { get; set; }
	public object lightmapScaleOffset { get; set; }
	public object materials { get; set; }
	public object material { get; set; }
	public object sharedMaterial { get; set; }
	public object sharedMaterials { get; set; }

	// Methods

	// RVA: 0x736D854
	public object get_bounds() { }

	// RVA: 0x736D930
	public object set_localBounds(object value) { }

	// RVA: 0x736D9F8
	private object SetStaticLightmapST(object st) { }

	// RVA: 0x736DAD0
	private object GetMaterial() { }

	// RVA: 0x736DB20
	private object GetSharedMaterial() { }

	// RVA: 0x736DB70
	private object SetMaterial(object m) { }

	// RVA: 0x736DBD4
	private object GetMaterialArray() { }

	// RVA: 0x736DC24
	private object CopySharedMaterialArray(object m) { }

	// RVA: 0x736DC88
	private object SetMaterialArray(object m, object length) { }

	// RVA: 0x736DCF4
	private object SetMaterialArray(object m) { }

	// RVA: 0x736DD80
	internal object Internal_SetPropertyBlock(object properties) { }

	// RVA: 0x736DDE4
	internal object Internal_GetPropertyBlock(object dest) { }

	// RVA: 0x736DE48
	internal object Internal_SetPropertyBlockMaterialIndex(object properties, object materialIndex) { }

	// RVA: 0x736DEB4
	internal object Internal_GetPropertyBlockMaterialIndex(object dest, object materialIndex) { }

	// RVA: 0x736DF20
	public object HasPropertyBlock() { }

	// RVA: 0x736DF70
	internal object Internal_SetBatchPerDrawPropertyBlock(object properties) { }

	// RVA: 0x736DFD4
	internal object Internal_GetBatchPerDrawPropertyBlock(object dest) { }

	// RVA: 0x736E038
	internal object Internal_SetBatchPerDrawPropertyBlockMaterialIndex(object properties, object materialIndex) { }

	// RVA: 0x736E0A4
	internal object Internal_GetBatchPerDrawPropertyBlockMaterialIndex(object dest, object materialIndex) { }

	// RVA: 0x736E110
	public object SetPropertyBlock(object properties) { }

	// RVA: 0x736E174
	public object SetPropertyBlock(object properties, object materialIndex) { }

	// RVA: 0x736E1E0
	public object GetPropertyBlock(object properties) { }

	// RVA: 0x736E244
	public object GetPropertyBlock(object properties, object materialIndex) { }

	// RVA: 0x736E2B0
	public object SetBatchPerDrawPropertyBlock(object properties) { }

	// RVA: 0x736E314
	public object SetBatchPerDrawPropertyBlock(object properties, object materialIndex) { }

	// RVA: 0x736E380
	public object GetBatchPerDrawPropertyBlock(object properties) { }

	// RVA: 0x736E3E4
	public object GetBatchPerDrawPropertyBlock(object properties, object materialIndex) { }

	// RVA: 0x736E450
	public object get_enabled() { }

	// RVA: 0x736E4A0
	public object set_enabled(object value) { }

	// RVA: 0x736E504
	public object get_isVisible() { }

	// RVA: 0x736E554
	public object get_shadowCastingMode() { }

	// RVA: 0x736E5A4
	public object set_shadowCastingMode(object value) { }

	// RVA: 0x736E608
	public object get_receiveShadows() { }

	// RVA: 0x736E658
	public object set_receiveShadows(object value) { }

	// RVA: 0x736E6BC
	public object get_giType() { }

	// RVA: 0x736E70C
	public object set_giType(object value) { }

	// RVA: 0x736E770
	public object get_forceRenderingOff() { }

	// RVA: 0x736E7C0
	public object set_forceRenderingOff(object value) { }

	// RVA: 0x736E824
	private object GetIsStaticShadowCaster() { }

	// RVA: 0x736E874
	public object get_staticShadowCaster() { }

	// RVA: 0x736E8C4
	public object get_motionVectorGenerationMode() { }

	// RVA: 0x736E914
	public object set_motionVectorGenerationMode(object value) { }

	// RVA: 0x736E978
	public object get_lightProbeUsage() { }

	// RVA: 0x736E9C8
	public object set_lightProbeUsage(object value) { }

	// RVA: 0x736EA2C
	public object get_reflectionProbeUsage() { }

	// RVA: 0x736EA7C
	public object set_reflectionProbeUsage(object value) { }

	// RVA: 0x736EAE0
	public object set_renderingLayerMask(object value) { }

	// RVA: 0x736EB44
	public object get_sortingLayerID() { }

	// RVA: 0x736EB94
	public object set_sortingLayerID(object value) { }

	// RVA: 0x736EBF8
	public object get_sortingOrder() { }

	// RVA: 0x736EC48
	public object set_sortingOrder(object value) { }

	// RVA: 0x736ECAC
	internal object get_sortingGroupID() { }

	// RVA: 0x736ECFC
	internal object get_sortingGroupOrder() { }

	// RVA: 0x736ED4C
	public object get_isPartOfStaticBatch() { }

	// RVA: 0x736ED9C
	public object get_localToWorldMatrix() { }

	// RVA: 0x736EE7C
	public object get_probeAnchor() { }

	// RVA: 0x736EECC
	public object set_probeAnchor(object value) { }

	// RVA: 0x736EF30
	private object GetLightmapIndex(object lt) { }

	// RVA: 0x736EF94
	private object SetLightmapIndex(object index, object lt) { }

	// RVA: 0x736F000
	private object GetLightmapST(object lt) { }

	// RVA: 0x736F0DC
	public object get_lightmapIndex() { }

	// RVA: 0x736F134
	public object set_lightmapIndex(object value) { }

	// RVA: 0x736F1A0
	public object get_lightmapScaleOffset() { }

	// RVA: 0x736F204
	public object set_lightmapScaleOffset(object value) { }

	// RVA: 0x736F278
	private object GetMaterialCount() { }

	// RVA: 0x736F2C8
	private object GetSharedMaterialArray() { }

	// RVA: 0x736F318
	public object get_materials() { }

	// RVA: 0x736F368
	public object set_materials(object value) { }

	// RVA: 0x736F3F4
	public object get_material() { }

	// RVA: 0x736F444
	public object set_material(object value) { }

	// RVA: 0x736F4A8
	public object get_sharedMaterial() { }

	// RVA: 0x736F4F8
	public object set_sharedMaterial(object value) { }

	// RVA: 0x736F55C
	public object get_sharedMaterials() { }

	// RVA: 0x736F5AC
	public object set_sharedMaterials(object value) { }

	// RVA: 0x736F638
	public object SetMaterials(object materials) { }

	// RVA: 0x736F734
	public object GetSharedMaterials(object m) { }

	// RVA: 0x736F870
	public object .ctor() { }

	// RVA: 0x736D8CC
	private object get_bounds_Injected(object ret) { }

	// RVA: 0x736D994
	private object set_localBounds_Injected(object value) { }

	// RVA: 0x736DA6C
	private object SetStaticLightmapST_Injected(object st) { }

	// RVA: 0x736EE18
	private object get_localToWorldMatrix_Injected(object ret) { }

	// RVA: 0x736F070
	private object GetLightmapST_Injected(object lt, object ret) { }

}

// Namespace: UnityEngine
public sealed class RenderSettings
{

	// Properties
	public static object fog { get; set; }
	public static object fogStartDistance { get; set; }
	public static object fogEndDistance { get; set; }
	public static object fogMode { get; set; }
	public static object fogColor { get; set; }
	public static object fogDensity { get; set; }
	public static object ambientMode { get; }
	public static object ambientLight { get; set; }
	public static object skybox { get; }
	public static object ambientProbe { get; }
	public static object customReflection { get; }
	public static object customReflectionTexture { get; }

	// Methods

	// RVA: 0x736F878
	public static object get_fog() { }

	// RVA: 0x736F8B8
	public static object set_fog(object value) { }

	// RVA: 0x736F908
	public static object get_fogStartDistance() { }

	// RVA: 0x736F948
	public static object set_fogStartDistance(object value) { }

	// RVA: 0x736F99C
	public static object get_fogEndDistance() { }

	// RVA: 0x736F9DC
	public static object set_fogEndDistance(object value) { }

	// RVA: 0x736FA30
	public static object get_fogMode() { }

	// RVA: 0x736FA70
	public static object set_fogMode(object value) { }

	// RVA: 0x736FAC0
	public static object get_fogColor() { }

	// RVA: 0x736FB64
	public static object set_fogColor(object value) { }

	// RVA: 0x736FC1C
	public static object get_fogDensity() { }

	// RVA: 0x736FC5C
	public static object set_fogDensity(object value) { }

	// RVA: 0x736FCB0
	public static object get_ambientMode() { }

	// RVA: 0x736FCF0
	public static object get_ambientLight() { }

	// RVA: 0x736FD94
	public static object set_ambientLight(object value) { }

	// RVA: 0x736FE4C
	public static object get_skybox() { }

	// RVA: 0x736FE8C
	public static object get_ambientProbe() { }

	// RVA: 0x736FF5C
	public static object get_customReflection() { }

	// RVA: 0x7370030
	public static object get_customReflectionTexture() { }

	// RVA: 0x736FB14
	private static object get_fogColor_Injected(object ret) { }

	// RVA: 0x736FBCC
	private static object set_fogColor_Injected(object value) { }

	// RVA: 0x736FD44
	private static object get_ambientLight_Injected(object ret) { }

	// RVA: 0x736FDFC
	private static object set_ambientLight_Injected(object value) { }

	// RVA: 0x736FF0C
	private static object get_ambientProbe_Injected(object ret) { }

}

// Namespace: UnityEngine
public sealed class Shader
{

	// Properties
	public object maximumLOD { set; }
	public object isSupported { get; }
	public object keywordSpace { get; }
	public object renderQueue { get; }
	public object subshaderCount { get; }

	// Methods

	// RVA: 0x7370070
	public static object Find(object name) { }

	// RVA: 0x7370138
	public object set_maximumLOD(object value) { }

	// RVA: 0x737019C
	public object get_isSupported() { }

	// RVA: 0x73701EC
	public object get_keywordSpace() { }

	// RVA: 0x73702AC
	public static object EnableKeyword(object keyword) { }

	// RVA: 0x73702FC
	public static object DisableKeyword(object keyword) { }

	// RVA: 0x737034C
	public static object IsKeywordEnabled(object keyword) { }

	// RVA: 0x737039C
	public object get_renderQueue() { }

	// RVA: 0x73703EC
	public static object WarmupCollectedShaders() { }

	// RVA: 0x737042C
	internal static object TagToID(object name) { }

	// RVA: 0x737047C
	internal static object IDToTag(object name) { }

	// RVA: 0x736CE9C
	public static object PropertyToID(object name) { }

	// RVA: 0x73704CC
	public object get_subshaderCount() { }

	// RVA: 0x737051C
	public object FindSubshaderTagValue(object subshaderIndex, object tagName) { }

	// RVA: 0x7370674
	private object Internal_FindSubshaderTagValue(object subShaderIndex, object tagName) { }

	// RVA: 0x73706E0
	private static object SetGlobalFloatImpl(object name, object value) { }

	// RVA: 0x7370744
	private static object SetGlobalVectorImpl(object name, object value) { }

	// RVA: 0x737081C
	private static object SetGlobalMatrixImpl(object name, object value) { }

	// RVA: 0x73708E4
	private static object SetGlobalTextureImpl(object name, object value) { }

	// RVA: 0x7370948
	public static object SetGlobalFloat(object name, object value) { }

	// RVA: 0x73709F0
	public static object SetGlobalFloat(object nameID, object value) { }

	// RVA: 0x7370A54
	public static object SetGlobalVector(object name, object value) { }

	// RVA: 0x7370B1C
	public static object SetGlobalVector(object nameID, object value) { }

	// RVA: 0x7370B90
	public static object SetGlobalColor(object name, object value) { }

	// RVA: 0x7370C58
	public static object SetGlobalColor(object nameID, object value) { }

	// RVA: 0x7370CCC
	public static object SetGlobalMatrix(object name, object value) { }

	// RVA: 0x7370D6C
	public static object SetGlobalMatrix(object nameID, object value) { }

	// RVA: 0x7370DE8
	public static object SetGlobalTexture(object name, object value) { }

	// RVA: 0x7370E90
	public static object SetGlobalTexture(object nameID, object value) { }

	// RVA: 0x7370EF4
	private object .ctor() { }

	// RVA: 0x7370F7C
	private static object GetPropertyName(object shader, object propertyIndex) { }

	// RVA: 0x7370FE0
	private static object GetPropertyType(object shader, object propertyIndex) { }

	// RVA: 0x7371044
	private static object GetPropertyTextureDefaultName(object shader, object propertyIndex) { }

	// RVA: 0x73710A8
	private static object CheckPropertyIndex(object s, object propertyIndex) { }

	// RVA: 0x7371160
	public object GetPropertyCount() { }

	// RVA: 0x73711B0
	public object FindPropertyIndex(object propertyName) { }

	// RVA: 0x7371214
	public object GetPropertyName(object propertyIndex) { }

	// RVA: 0x7371280
	public object GetPropertyType(object propertyIndex) { }

	// RVA: 0x73712EC
	public object GetPropertyTextureDefaultName(object propertyIndex) { }

	// RVA: 0x7370248
	private object get_keywordSpace_Injected(object ret) { }

	// RVA: 0x73707B8
	private static object SetGlobalVectorImpl_Injected(object name, object value) { }

	// RVA: 0x7370880
	private static object SetGlobalMatrixImpl_Injected(object name, object value) { }

}

// Namespace: UnityEngine
public class Material
{

	// Properties
	public object shader { get; set; }
	public object color { get; set; }
	public object mainTexture { get; set; }
	public object mainTextureOffset { set; }
	public object mainTextureScale { set; }
	public object renderQueue { get; set; }
	public object enableInstancing { set; }
	public object passCount { get; }
	public object shaderKeywords { get; set; }

	// Methods

	// RVA: 0x73713E0
	private static object CreateWithShader(object self, object shader) { }

	// RVA: 0x7371444
	private static object CreateWithMaterial(object self, object source) { }

	// RVA: 0x73714A8
	private static object CreateWithString(object self) { }

	// RVA: 0x73714F8
	public object .ctor(object shader) { }

	// RVA: 0x73715C8
	public object .ctor(object source) { }

	// RVA: 0x7371698
	public object .ctor(object contents) { }

	// RVA: 0x737175C
	public object get_shader() { }

	// RVA: 0x73717AC
	public object set_shader(object value) { }

	// RVA: 0x7371810
	public object get_color() { }

	// RVA: 0x7371AA0
	public object set_color(object value) { }

	// RVA: 0x7371D04
	public object get_mainTexture() { }

	// RVA: 0x7371F2C
	public object set_mainTexture(object value) { }

	// RVA: 0x7372144
	public object set_mainTextureOffset(object value) { }

	// RVA: 0x7372378
	public object set_mainTextureScale(object value) { }

	// RVA: 0x7371934
	private object GetFirstPropertyNameIdByAttribute(object attributeFlag) { }

	// RVA: 0x73725AC
	public object HasProperty(object nameID) { }

	// RVA: 0x7372610
	public object HasProperty(object name) { }

	// RVA: 0x73726BC
	private object HasFloatImpl(object name) { }

	// RVA: 0x7372720
	public object HasFloat(object name) { }

	// RVA: 0x73727CC
	public object HasFloat(object nameID) { }

	// RVA: 0x7372830
	public object HasInt(object name) { }

	// RVA: 0x73728DC
	private object HasIntImpl(object name) { }

	// RVA: 0x7372940
	public object HasInteger(object nameID) { }

	// RVA: 0x73729A4
	private object HasTextureImpl(object name) { }

	// RVA: 0x7372A08
	public object HasTexture(object nameID) { }

	// RVA: 0x7372A6C
	private object HasVectorImpl(object name) { }

	// RVA: 0x7372AD0
	public object HasVector(object name) { }

	// RVA: 0x7372B7C
	public object HasVector(object nameID) { }

	// RVA: 0x7372BE0
	public object HasColor(object name) { }

	// RVA: 0x7372C8C
	public object HasColor(object nameID) { }

	// RVA: 0x7372CF0
	public object get_renderQueue() { }

	// RVA: 0x7372D40
	public object set_renderQueue(object value) { }

	// RVA: 0x7372DA4
	public object EnableKeyword(object keyword) { }

	// RVA: 0x7372E08
	public object DisableKeyword(object keyword) { }

	// RVA: 0x7372E6C
	public object IsKeywordEnabled(object keyword) { }

	// RVA: 0x7372ED0
	public object set_enableInstancing(object value) { }

	// RVA: 0x7372F34
	public object get_passCount() { }

	// RVA: 0x7372F84
	public object SetShaderPassEnabled(object passName, object enabled) { }

	// RVA: 0x7372FF0
	public object GetShaderPassEnabled(object passName) { }

	// RVA: 0x7373054
	public object FindPass(object passName) { }

	// RVA: 0x73730B8
	public object SetOverrideTag(object tag, object val) { }

	// RVA: 0x7373124
	private object GetTagImpl(object tag, object currentSubShaderOnly, object defaultValue) { }

	// RVA: 0x73731A4
	public object GetTag(object tag, object searchFallbacks) { }

	// RVA: 0x7373234
	public object SetPass(object pass) { }

	// RVA: 0x7373298
	public object CopyPropertiesFromMaterial(object mat) { }

	// RVA: 0x73732FC
	private object GetShaderKeywords() { }

	// RVA: 0x737334C
	private object SetShaderKeywords(object names) { }

	// RVA: 0x73733B0
	public object get_shaderKeywords() { }

	// RVA: 0x7373400
	public object set_shaderKeywords(object value) { }

	// RVA: 0x7373464
	public object ComputeCRC() { }

	// RVA: 0x73734B4
	private object SetIntImpl(object name, object value) { }

	// RVA: 0x7373520
	private object SetFloatImpl(object name, object value) { }

	// RVA: 0x7373598
	private object SetColorImpl(object name, object value) { }

	// RVA: 0x7373670
	private object SetMatrixImpl(object name, object value) { }

	// RVA: 0x7373748
	private object SetTextureImpl(object name, object value) { }

	// RVA: 0x73737B4
	private object SetBufferImpl(object name, object value) { }

	// RVA: 0x7373820
	private object GetIntImpl(object name) { }

	// RVA: 0x7373884
	private object GetFloatImpl(object name) { }

	// RVA: 0x73738E8
	private object GetColorImpl(object name) { }

	// RVA: 0x73739C4
	private object GetTextureImpl(object name) { }

	// RVA: 0x7373A28
	private object SetFloatArrayImpl(object name, object values, object count) { }

	// RVA: 0x7373AA8
	private object SetVectorArrayImpl(object name, object values, object count) { }

	// RVA: 0x7373B28
	private object GetTextureScaleAndOffsetImpl(object name) { }

	// RVA: 0x7373C04
	private object SetTextureOffsetImpl(object name, object offset) { }

	// RVA: 0x7373CD8
	private object SetTextureScaleImpl(object name, object scale) { }

	// RVA: 0x7373DAC
	private object SetFloatArray(object name, object values, object count) { }

	// RVA: 0x7373EF0
	private object SetVectorArray(object name, object values, object count) { }

	// RVA: 0x7374034
	public object SetInt(object name, object value) { }

	// RVA: 0x73740D4
	public object SetInt(object nameID, object value) { }

	// RVA: 0x7374144
	public object SetFloat(object name, object value) { }

	// RVA: 0x73741EC
	public object SetFloat(object nameID, object value) { }

	// RVA: 0x7374264
	public object SetInteger(object nameID, object value) { }

	// RVA: 0x7371C50
	public object SetColor(object name, object value) { }

	// RVA: 0x7371BE4
	public object SetColor(object nameID, object value) { }

	// RVA: 0x73742D0
	public object SetVector(object name, object value) { }

	// RVA: 0x7374384
	public object SetVector(object nameID, object value) { }

	// RVA: 0x73743F0
	public object SetMatrix(object name, object value) { }

	// RVA: 0x7374490
	public object SetMatrix(object nameID, object value) { }

	// RVA: 0x73720A4
	public object SetTexture(object name, object value) { }

	// RVA: 0x7372038
	public object SetTexture(object nameID, object value) { }

	// RVA: 0x7374504
	public object SetBuffer(object nameID, object value) { }

	// RVA: 0x7374570
	public object SetFloatArray(object name, object values) { }

	// RVA: 0x73745E4
	public object SetVectorArray(object name, object values) { }

	// RVA: 0x73746A4
	public object SetVectorArray(object nameID, object values) { }

	// RVA: 0x73746C4
	public object GetInt(object name) { }

	// RVA: 0x7374778
	public object GetFloat(object name) { }

	// RVA: 0x7374824
	public object GetFloat(object nameID) { }

	// RVA: 0x7374888
	public object GetInteger(object nameID) { }

	// RVA: 0x7371A08
	public object GetColor(object name) { }

	// RVA: 0x7371998
	public object GetColor(object nameID) { }

	// RVA: 0x73748EC
	public object GetVector(object name) { }

	// RVA: 0x7374984
	public object GetVector(object nameID) { }

	// RVA: 0x7371E80
	public object GetTexture(object name) { }

	// RVA: 0x7371E1C
	public object GetTexture(object nameID) { }

	// RVA: 0x73722D8
	public object SetTextureOffset(object name, object value) { }

	// RVA: 0x7372270
	public object SetTextureOffset(object nameID, object value) { }

	// RVA: 0x737250C
	public object SetTextureScale(object name, object value) { }

	// RVA: 0x73724A4
	public object SetTextureScale(object nameID, object value) { }

	// RVA: 0x73749F4
	public object GetTextureOffset(object name) { }

	// RVA: 0x7374A88
	public object GetTextureOffset(object nameID) { }

	// RVA: 0x7374AF4
	public object GetTextureScale(object name) { }

	// RVA: 0x7374B88
	public object GetTextureScale(object nameID) { }

	// RVA: 0x7373604
	private object SetColorImpl_Injected(object name, object value) { }

	// RVA: 0x73736DC
	private object SetMatrixImpl_Injected(object name, object value) { }

	// RVA: 0x7373958
	private object GetColorImpl_Injected(object name, object ret) { }

	// RVA: 0x7373B98
	private object GetTextureScaleAndOffsetImpl_Injected(object name, object ret) { }

	// RVA: 0x7373C6C
	private object SetTextureOffsetImpl_Injected(object name, object offset) { }

	// RVA: 0x7373D40
	private object SetTextureScaleImpl_Injected(object name, object scale) { }

}

// Namespace: 
public enum Target
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Vertex;
	public const object Index;
	public const object CopySource;
	public const object CopyDestination;
	public const object Structured;
	public const object Raw;
	public const object Append;
	public const object Counter;
	public const object IndirectArguments;
	public const object Constant;
}

// Namespace: 
public enum UsageFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object LockBufferForWrite;
}

// Namespace: UnityEngine
public sealed class GraphicsBuffer
{

	// Fields
	internal object m_Ptr; // 0x8

	// Properties
	public object count { get; }
	public object target { get; }

	// Methods

	// RVA: 0x7374BF4
	protected override object Finalize() { }

	// RVA: 0x7374DC4
	public object Dispose() { }

	// RVA: 0x7374CF0
	private object Dispose(object disposing) { }

	// RVA: 0x7374F20
	private static object RequiresCompute(object target) { }

	// RVA: 0x7374F2C
	private static object IsVertexIndexOrCopyOnly(object target) { }

	// RVA: 0x7374F38
	private static object InitBuffer(object target, object usageFlags, object count, object stride) { }

	// RVA: 0x7374ED0
	private static object DestroyBuffer(object buf) { }

	// RVA: 0x7374FB8
	public object .ctor(object target, object count, object stride) { }

	// RVA: 0x7375008
	private object InternalInitialization(object target, object usageFlags, object count, object stride) { }

	// RVA: 0x7375338
	public object Release() { }

	// RVA: 0x737533C
	public object get_count() { }

	// RVA: 0x737538C
	public object get_target() { }

	// RVA: 0x73753DC
	public object SetData(object data) { }

	// RVA: -1
	public object SetData(object data, object nativeBufferStartIndex, object graphicsBufferStartIndex, object count) { }

	// RVA: 0x7375640
	private object InternalSetNativeData(object data, object nativeBufferStartIndex, object graphicsBufferStartIndex, object count, object elemSize) { }

	// RVA: 0x73755A4
	private object InternalSetData(object data, object managedBufferStartIndex, object graphicsBufferStartIndex, object count, object elemSize) { }

	// RVA: 0x73756DC
	public object GetNativeBufferPtr() { }

}

// Namespace: UnityEngine
public struct LightBakingOutput
{

	// Fields
	public object probeOcclusionLightIndex; // 0xFFFFFFFFFFFFFFF8
	public object occlusionMaskChannel; // 0xFFFFFFFFFFFFFFFC
	public object lightmapBakeType; // 0x0
	public object mixedLightingMode; // 0x4
	public object isBaked; // 0x8
}

// Namespace: UnityEngine
public sealed class Light
{

	// Fields
	private object m_BakedIndex; // 0x10

	// Properties
	public object type { get; set; }
	public object spotAngle { get; set; }
	public object innerSpotAngle { set; }
	public object color { get; set; }
	public object colorTemperature { get; set; }
	public object useColorTemperature { get; set; }
	public object intensity { get; set; }
	public object bounceIntensity { get; }
	public object shadowBias { set; }
	public object range { get; set; }
	public object bakingOutput { get; set; }
	public object cullingMask { get; set; }
	public object shadows { get; set; }
	public object shadowStrength { get; }
	public object cookieSize { get; }
	public object cookie { get; }

	// Methods

	// RVA: 0x7375760
	public object get_type() { }

	// RVA: 0x73757B0
	public object set_type(object value) { }

	// RVA: 0x7375814
	public object get_spotAngle() { }

	// RVA: 0x7375864
	public object set_spotAngle(object value) { }

	// RVA: 0x73758C8
	public object set_innerSpotAngle(object value) { }

	// RVA: 0x737592C
	public object get_color() { }

	// RVA: 0x73759F0
	public object set_color(object value) { }

	// RVA: 0x7375AC8
	public object get_colorTemperature() { }

	// RVA: 0x7375B18
	public object set_colorTemperature(object value) { }

	// RVA: 0x7375B7C
	public object get_useColorTemperature() { }

	// RVA: 0x7375BCC
	public object set_useColorTemperature(object value) { }

	// RVA: 0x7375C30
	public object get_intensity() { }

	// RVA: 0x7375C80
	public object set_intensity(object value) { }

	// RVA: 0x7375CE4
	public object get_bounceIntensity() { }

	// RVA: 0x7375D34
	public object set_shadowBias(object value) { }

	// RVA: 0x7375D98
	public object get_range() { }

	// RVA: 0x7375DE8
	public object set_range(object value) { }

	// RVA: 0x7375E4C
	public object get_bakingOutput() { }

	// RVA: 0x7375F28
	public object set_bakingOutput(object value) { }

	// RVA: 0x7375FF0
	public object get_cullingMask() { }

	// RVA: 0x7376040
	public object set_cullingMask(object value) { }

	// RVA: 0x73760A4
	public object get_shadows() { }

	// RVA: 0x73760F4
	public object set_shadows(object value) { }

	// RVA: 0x7376158
	public object get_shadowStrength() { }

	// RVA: 0x73761A8
	public object get_cookieSize() { }

	// RVA: 0x73761F8
	public object get_cookie() { }

	// RVA: 0x737598C
	private object get_color_Injected(object ret) { }

	// RVA: 0x7375A64
	private object set_color_Injected(object value) { }

	// RVA: 0x7375EC4
	private object get_bakingOutput_Injected(object ret) { }

	// RVA: 0x7375F8C
	private object set_bakingOutput_Injected(object value) { }

}

// Namespace: UnityEngine
public sealed class MeshFilter
{

	// Properties
	public object sharedMesh { get; set; }
	public object mesh { get; set; }

	// Methods

	// RVA: 0x7376248
	private object DontStripMeshFilter() { }

	// RVA: 0x737624C
	public object get_sharedMesh() { }

	// RVA: 0x737629C
	public object set_sharedMesh(object value) { }

	// RVA: 0x7376300
	public object get_mesh() { }

	// RVA: 0x7376350
	public object set_mesh(object value) { }

}

// Namespace: UnityEngine
public enum RenderingPath
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UsePlayerSettings;
	public const object VertexLit;
	public const object Forward;
	public const object DeferredLighting;
	public const object DeferredShading;
}

// Namespace: UnityEngine
public enum CameraType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Game;
	public const object SceneView;
	public const object Preview;
	public const object VR;
	public const object Reflection;
}

// Namespace: UnityEngine
public enum ComputeBufferType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Raw;
	public const object Append;
	public const object Counter;
	public const object Constant;
	public const object Structured;
	public const object DrawIndirect;
	public const object IndirectArguments;
	public const object GPUMemory;
}

// Namespace: UnityEngine
public enum LightType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Spot;
	public const object Directional;
	public const object Point;
	public const object Area;
	public const object Rectangle;
	public const object Disc;
}

// Namespace: UnityEngine
public enum LightShadows
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Hard;
	public const object Soft;
}

// Namespace: UnityEngine
public enum FogMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Linear;
	public const object Exponential;
	public const object ExponentialSquared;
}

// Namespace: UnityEngine
public enum LightmapBakeType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Realtime;
	public const object Baked;
	public const object Mixed;
}

// Namespace: UnityEngine
public enum GIRepresentation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object LM;
	public const object VLM;
	public const object VLMToLM;
	public const object CPUProbe;
}

// Namespace: UnityEngine
public enum GIMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ContributeToGI;
	public const object DontContributeToGI;
}

// Namespace: UnityEngine
public enum SMMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CastShadow;
	public const object DontCastShadow;
}

// Namespace: UnityEngine
public enum CPUProbeUpdateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PerFrame;
	public const object PerInterval;
	public const object Passive;
}

// Namespace: UnityEngine
public enum CPUProbeAnchorMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Position;
	public const object RendererBound;
}

// Namespace: UnityEngine
public enum MixedLightingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IndirectOnly;
	public const object Shadowmask;
	public const object Subtractive;
}

// Namespace: UnityEngine
public enum ShadowObjectsFilter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AllObjects;
	public const object DynamicOnly;
	public const object StaticOnly;
}

// Namespace: UnityEngine
public enum CameraClearFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Skybox;
	public const object Color;
	public const object SolidColor;
	public const object Depth;
	public const object Nothing;
}

// Namespace: UnityEngine
public enum DepthTextureMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Depth;
	public const object DepthNormals;
	public const object MotionVectors;
}

// Namespace: UnityEngine
public enum SkinWeights
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object OneBone;
	public const object TwoBones;
	public const object FourBones;
	public const object Unlimited;
}

// Namespace: UnityEngine
public enum MeshTopology
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Triangles;
	public const object Quads;
	public const object Lines;
	public const object LineStrip;
	public const object Points;
}

// Namespace: UnityEngine
public enum ColorSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Uninitialized;
	public const object Gamma;
	public const object Linear;
}

// Namespace: UnityEngine
public enum ScreenOrientation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Portrait;
	public const object PortraitUpsideDown;
	public const object LandscapeLeft;
	public const object LandscapeRight;
	public const object AutoRotation;
	public const object Unknown;
	public const object Landscape;
}

// Namespace: UnityEngine
public enum FilterMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Point;
	public const object Bilinear;
	public const object Trilinear;
}

// Namespace: UnityEngine
public enum TextureWrapMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Repeat;
	public const object Clamp;
	public const object Mirror;
	public const object MirrorOnce;
}

// Namespace: UnityEngine
public enum NPOTSupport
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Restricted;
	public const object Full;
}

// Namespace: UnityEngine
public enum TextureFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Alpha8;
	public const object ARGB4444;
	public const object RGB24;
	public const object RGBA32;
	public const object ARGB32;
	public const object RGB565;
	public const object R16;
	public const object DXT1;
	public const object DXT5;
	public const object RGBA4444;
	public const object BGRA32;
	public const object RHalf;
	public const object RGHalf;
	public const object RGBAHalf;
	public const object RFloat;
	public const object RGFloat;
	public const object RGBAFloat;
	public const object YUY2;
	public const object RGB9e5Float;
	public const object BC4;
	public const object BC5;
	public const object BC6H;
	public const object BC7;
	public const object DXT1Crunched;
	public const object DXT5Crunched;
	public const object PVRTC_RGB2;
	public const object PVRTC_RGBA2;
	public const object PVRTC_RGB4;
	public const object PVRTC_RGBA4;
	public const object ETC_RGB4;
	public const object ASTC_3x3x3;
	public const object ASTC_4x4x4;
	public const object ASTC_HDR_3x3x3;
	public const object ASTC_HDR_4x4x4;
	public const object EAC_R;
	public const object EAC_R_SIGNED;
	public const object EAC_RG;
	public const object EAC_RG_SIGNED;
	public const object ETC2_RGB;
	public const object ETC2_RGBA1;
	public const object ETC2_RGBA8;
	public const object ASTC_4x4;
	public const object ASTC_5x5;
	public const object ASTC_6x6;
	public const object ASTC_8x8;
	public const object ASTC_10x10;
	public const object ASTC_12x12;
	public const object ETC_RGB4_3DS;
	public const object ETC_RGBA8_3DS;
	public const object RG16;
	public const object R8;
	public const object ETC_RGB4Crunched;
	public const object ETC2_RGBA8Crunched;
	public const object ASTC_HDR_4x4;
	public const object ASTC_HDR_5x5;
	public const object ASTC_HDR_6x6;
	public const object ASTC_HDR_8x8;
	public const object ASTC_HDR_10x10;
	public const object ASTC_HDR_12x12;
	public const object RG32;
	public const object RGB48;
	public const object RGBA64;
	public const object ASTC_RGB_4x4;
	public const object ASTC_RGB_5x5;
	public const object ASTC_RGB_6x6;
	public const object ASTC_RGB_8x8;
	public const object ASTC_RGB_10x10;
	public const object ASTC_RGB_12x12;
	public const object ASTC_RGBA_4x4;
	public const object ASTC_RGBA_5x5;
	public const object ASTC_RGBA_6x6;
	public const object ASTC_RGBA_8x8;
	public const object ASTC_RGBA_10x10;
	public const object ASTC_RGBA_12x12;
}

// Namespace: UnityEngine
internal enum TextureColorSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Linear;
	public const object sRGB;
}

// Namespace: UnityEngine
public enum CubemapFace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object PositiveX;
	public const object NegativeX;
	public const object PositiveY;
	public const object NegativeY;
	public const object PositiveZ;
	public const object NegativeZ;
}

// Namespace: UnityEngine
public enum RenderTextureFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ARGB32;
	public const object Depth;
	public const object ARGBHalf;
	public const object Shadowmap;
	public const object RGB565;
	public const object ARGB4444;
	public const object ARGB1555;
	public const object Default;
	public const object ARGB2101010;
	public const object DefaultHDR;
	public const object ARGB64;
	public const object ARGBFloat;
	public const object RGFloat;
	public const object RGHalf;
	public const object RFloat;
	public const object RHalf;
	public const object R8;
	public const object ARGBInt;
	public const object RGInt;
	public const object RInt;
	public const object BGRA32;
	public const object RGB111110Float;
	public const object RG32;
	public const object RGBAUShort;
	public const object RG16;
	public const object BGRA10101010_XR;
	public const object BGR101010_XR;
	public const object R16;
}

// Namespace: UnityEngine
public enum VRTextureUsage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object OneEye;
	public const object TwoEyes;
	public const object DeviceSpecific;
}

// Namespace: UnityEngine
public enum RenderTextureCreationFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MipMap;
	public const object AutoGenerateMips;
	public const object SRGB;
	public const object EyeTexture;
	public const object EnableRandomWrite;
	public const object CreatedFromScript;
	public const object AllowVerticalFlip;
	public const object NoResolvedColorSurface;
	public const object DynamicallyScalable;
	public const object BindMS;
}

// Namespace: UnityEngine
public enum RenderTextureReadWrite
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Linear;
	public const object sRGB;
}

// Namespace: UnityEngine
public enum RenderTextureMemoryless
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Color;
	public const object Depth;
	public const object MSAA;
}

// Namespace: UnityEngine
public enum LightmapsMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NonDirectional;
	public const object CombinedDirectional;
}

// Namespace: UnityEngine
public sealed class LightProbeProxyVolume
{
}

// Namespace: UnityEngine
public enum MotionVectorGenerationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Camera;
	public const object Object;
	public const object ForceNoMotion;
}

// Namespace: UnityEngine
public class SkinnedMeshRenderer
{

	// Properties
	public object rootBone { get; set; }
	public object bones { get; set; }
	public object sharedMesh { get; set; }
	public object vertexBufferTarget { get; set; }

	// Methods

	// RVA: 0x73763B4
	public object get_rootBone() { }

	// RVA: 0x7376404
	public object set_rootBone(object value) { }

	// RVA: 0x7376468
	public object get_bones() { }

	// RVA: 0x73764B8
	public object set_bones(object value) { }

	// RVA: 0x737651C
	public object get_sharedMesh() { }

	// RVA: 0x737656C
	public object set_sharedMesh(object value) { }

	// RVA: 0x73765D0
	public object SetBlendShapeWeight(object index, object value) { }

	// RVA: 0x7376648
	public object BakeMesh(object mesh) { }

	// RVA: 0x73766B4
	public object BakeMesh(object mesh, object useScale) { }

	// RVA: 0x7376720
	public object GetVertexBuffer() { }

	// RVA: 0x737681C
	private object GetVertexBufferImpl() { }

	// RVA: 0x737686C
	public object get_vertexBufferTarget() { }

	// RVA: 0x73768BC
	public object set_vertexBufferTarget(object value) { }

	// RVA: 0x7376920
	public object .ctor() { }

}

// Namespace: UnityEngine
public class MeshRenderer
{

	// Properties
	public object additionalVertexStreams { set; }

	// Methods

	// RVA: 0x7376928
	private object DontStripMeshRenderer() { }

	// RVA: 0x737692C
	public object set_additionalVertexStreams(object value) { }

	// RVA: 0x7376990
	public object .ctor() { }

}

// Namespace: UnityEngine
public enum LODFadeMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object CrossFade;
	public const object SpeedTree;
}

// Namespace: 
public struct MeshData
{

	// Fields
	internal object m_Ptr; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine
public sealed class Mesh
{

	// Properties
	public object indexFormat { get; set; }
	public object vertexBufferTarget { get; set; }
	public object indexBufferTarget { get; set; }
	public object blendShapeCount { get; }
	public object bindposes { get; set; }
	public object isReadable { get; }
	internal object canAccess { get; }
	public object vertexCount { get; }
	public object subMeshCount { get; set; }
	public object bounds { get; set; }
	public object vertices { get; set; }
	public object normals { get; set; }
	public object tangents { get; set; }
	public object uv { get; set; }
	public object uv2 { set; }
	public object uv3 { set; }
	public object colors { get; set; }
	public object colors32 { get; set; }
	public object triangles { get; set; }
	public object boneWeights { get; set; }

	// Methods

	// RVA: 0x7376998
	private static object Internal_Create(object mono) { }

	// RVA: 0x73769E8
	public object .ctor() { }

	// RVA: 0x7376AAC
	internal static object FromInstanceID(object id) { }

	// RVA: 0x7376AFC
	public object get_indexFormat() { }

	// RVA: 0x7376B4C
	public object set_indexFormat(object value) { }

	// RVA: 0x7376BB0
	public object SetIndexBufferParams(object indexCount, object format) { }

	// RVA: 0x7376C1C
	private object InternalSetIndexBufferData(object data, object dataStart, object meshBufferStart, object count, object elemSize, object flags) { }

	// RVA: 0x7376CC0
	private object SetVertexBufferParamsFromArray(object vertexCount, object attributes) { }

	// RVA: 0x7376D2C
	private object InternalSetVertexBufferData(object stream, object data, object dataStart, object meshBufferStart, object count, object elemSize, object flags) { }

	// RVA: 0x7376DC8
	private object GetVertexAttributesArray(object attributes) { }

	// RVA: 0x7376E2C
	private object GetTrianglesImpl(object submesh, object applyBaseVertex) { }

	// RVA: 0x7376E98
	private object GetIndicesImpl(object submesh, object applyBaseVertex) { }

	// RVA: 0x7376F04
	private object SetIndicesImpl(object submesh, object topology, object indicesFormat, object indices, object arrayStart, object arraySize, object calculateBounds, object baseVertex) { }

	// RVA: 0x7376FA8
	private object PrintErrorCantAccessChannel(object ch) { }

	// RVA: 0x737700C
	public object HasVertexAttribute(object attr) { }

	// RVA: 0x7377070
	public object GetVertexAttributeOffset(object attr) { }

	// RVA: 0x73770D4
	private object SetArrayForChannelImpl(object channel, object format, object dim, object values, object arraySize, object valuesStart, object valuesCount, object flags) { }

	// RVA: 0x7377178
	private object GetAllocArrayFromChannelImpl(object channel, object format, object dim) { }

	// RVA: 0x73771F8
	private object GetArrayFromChannelImpl(object channel, object format, object dim, object values) { }

	// RVA: 0x7377280
	public object GetVertexBufferStride(object stream) { }

	// RVA: 0x73772E4
	private object GetVertexBufferImpl(object index) { }

	// RVA: 0x7377348
	private object GetIndexBufferImpl() { }

	// RVA: 0x7377398
	public object get_vertexBufferTarget() { }

	// RVA: 0x73773E8
	public object set_vertexBufferTarget(object value) { }

	// RVA: 0x737744C
	public object get_indexBufferTarget() { }

	// RVA: 0x737749C
	public object set_indexBufferTarget(object value) { }

	// RVA: 0x7377500
	public object get_blendShapeCount() { }

	// RVA: 0x7377550
	public object GetBlendShapeName(object shapeIndex) { }

	// RVA: 0x73775B4
	private object GetBoneWeightsImpl() { }

	// RVA: 0x7377604
	private object SetBoneWeightsImpl(object weights) { }

	// RVA: 0x7377668
	public object get_bindposes() { }

	// RVA: 0x73776B8
	public object set_bindposes(object value) { }

	// RVA: 0x737771C
	public object get_isReadable() { }

	// RVA: 0x737776C
	internal object get_canAccess() { }

	// RVA: 0x73777BC
	public object get_vertexCount() { }

	// RVA: 0x737780C
	public object get_subMeshCount() { }

	// RVA: 0x737785C
	public object set_subMeshCount(object value) { }

	// RVA: 0x73778C0
	public object SetSubMesh(object index, object desc, object flags) { }

	// RVA: 0x73779C0
	public object GetSubMesh(object index) { }

	// RVA: 0x7377AB0
	public object get_bounds() { }

	// RVA: 0x7377B8C
	public object set_bounds(object value) { }

	// RVA: 0x7377C54
	private object ClearImpl(object keepVertexLayout) { }

	// RVA: 0x7377CB8
	private object RecalculateBoundsImpl(object flags) { }

	// RVA: 0x7377D1C
	private object RecalculateNormalsImpl(object flags) { }

	// RVA: 0x7377D80
	private object MarkDynamicImpl() { }

	// RVA: 0x7377DD0
	private object UploadMeshDataImpl(object markNoLongerReadable) { }

	// RVA: 0x7377E34
	private object GetTopologyImpl(object submesh) { }

	// RVA: 0x7377E98
	private object CombineMeshesImpl(object combine, object mergeSubMeshes, object useMatrices, object hasLightmapData) { }

	// RVA: 0x7377F20
	internal static object GetUVChannel(object uvIndex) { }

	// RVA: 0x7377F98
	internal static object DefaultDimensionForChannel(object channel) { }

	// RVA: -1
	private object GetAllocArrayFromChannel(object channel, object format, object dim) { }

	// RVA: -1
	private object GetAllocArrayFromChannel(object channel) { }

	// RVA: 0x7378038
	private object SetSizedArrayForChannel(object channel, object format, object dim, object values, object valuesArrayLength, object valuesStart, object valuesCount, object flags) { }

	// RVA: -1
	private object SetArrayForChannel(object channel, object format, object dim, object values, object flags) { }

	// RVA: -1
	private object SetArrayForChannel(object channel, object values, object flags) { }

	// RVA: -1
	private object SetListForChannel(object channel, object format, object dim, object values, object start, object length, object flags) { }

	// RVA: -1
	private object SetListForChannel(object channel, object values, object start, object length, object flags) { }

	// RVA: -1
	private object GetListForChannel(object buffer, object capacity, object channel, object dim) { }

	// RVA: -1
	private object GetListForChannel(object buffer, object capacity, object channel, object dim, object channelType) { }

	// RVA: 0x73782EC
	public object get_vertices() { }

	// RVA: 0x7378348
	public object set_vertices(object value) { }

	// RVA: 0x73783B0
	public object get_normals() { }

	// RVA: 0x737840C
	public object set_normals(object value) { }

	// RVA: 0x7378474
	public object get_tangents() { }

	// RVA: 0x73784D0
	public object set_tangents(object value) { }

	// RVA: 0x7378538
	public object get_uv() { }

	// RVA: 0x7378594
	public object set_uv(object value) { }

	// RVA: 0x73785FC
	public object set_uv2(object value) { }

	// RVA: 0x7378664
	public object set_uv3(object value) { }

	// RVA: 0x73786CC
	public object get_colors() { }

	// RVA: 0x7378728
	public object set_colors(object value) { }

	// RVA: 0x7378790
	public object get_colors32() { }

	// RVA: 0x73787F4
	public object set_colors32(object value) { }

	// RVA: 0x7378864
	public object SetVertices(object inVertices) { }

	// RVA: 0x7378910
	public object SetVertices(object inVertices, object start, object length) { }

	// RVA: 0x7378990
	public object SetVertices(object inVertices, object start, object length, object flags) { }

	// RVA: 0x7378A1C
	public object SetNormals(object inNormals) { }

	// RVA: 0x7378AC8
	public object SetNormals(object inNormals, object start, object length) { }

	// RVA: 0x7378B48
	public object SetNormals(object inNormals, object start, object length, object flags) { }

	// RVA: 0x7378BD4
	public object SetTangents(object inTangents) { }

	// RVA: 0x7378C80
	public object SetTangents(object inTangents, object start, object length) { }

	// RVA: 0x7378D00
	public object SetTangents(object inTangents, object start, object length, object flags) { }

	// RVA: 0x7378D8C
	public object SetColors(object inColors) { }

	// RVA: 0x7378E38
	public object SetColors(object inColors, object start, object length) { }

	// RVA: 0x7378EB8
	public object SetColors(object inColors, object start, object length, object flags) { }

	// RVA: 0x7378F44
	public object SetColors(object inColors) { }

	// RVA: 0x7379008
	public object SetColors(object inColors, object start, object length) { }

	// RVA: 0x73790A0
	public object SetColors(object inColors, object start, object length, object flags) { }

	// RVA: -1
	private object SetUvsImpl(object uvIndex, object dim, object uvs, object start, object length, object flags) { }

	// RVA: 0x7379144
	public object SetUVs(object channel, object uvs) { }

	// RVA: 0x7379288
	public object SetUVs(object channel, object uvs) { }

	// RVA: 0x73791F8
	public object SetUVs(object channel, object uvs, object start, object length) { }

	// RVA: 0x73793CC
	public object SetUVs(object channel, object uvs, object start, object length, object flags) { }

	// RVA: 0x737933C
	public object SetUVs(object channel, object uvs, object start, object length) { }

	// RVA: 0x7379460
	public object SetUVs(object channel, object uvs, object start, object length, object flags) { }

	// RVA: -1
	private object GetUVsImpl(object uvIndex, object uvs, object dim) { }

	// RVA: 0x73794F4
	public object GetUVs(object channel, object uvs) { }

	// RVA: 0x7379568
	public object GetVertexAttributes(object attributes) { }

	// RVA: 0x73795CC
	public object SetVertexBufferParams(object vertexCount, object attributes) { }

	// RVA: -1
	public object SetVertexBufferData(object data, object dataStart, object meshBufferStart, object count, object stream, object flags) { }

	// RVA: 0x7379638
	public object GetVertexBuffer(object index) { }

	// RVA: 0x7379740
	public object GetIndexBuffer() { }

	// RVA: 0x737983C
	private object PrintErrorCantAccessIndices() { }

	// RVA: 0x73798E8
	private object CheckCanAccessSubmesh(object submesh, object errorAboutTriangles) { }

	// RVA: 0x7379AF0
	private object CheckCanAccessSubmeshTriangles(object submesh) { }

	// RVA: 0x7379AF8
	private object CheckCanAccessSubmeshIndices(object submesh) { }

	// RVA: 0x7379B00
	public object get_triangles() { }

	// RVA: 0x7379C4C
	public object set_triangles(object value) { }

	// RVA: 0x7379E74
	public object GetTriangles(object submesh) { }

	// RVA: 0x7379F1C
	public object GetTriangles(object submesh, object applyBaseVertex) { }

	// RVA: 0x7379FC8
	public object GetIndices(object submesh) { }

	// RVA: 0x737A070
	public object GetIndices(object submesh, object applyBaseVertex) { }

	// RVA: -1
	public object SetIndexBufferData(object data, object dataStart, object meshBufferStart, object count, object flags) { }

	// RVA: 0x737A11C
	private object CheckIndicesArrayRange(object valuesLength, object start, object length) { }

	// RVA: 0x7379DC8
	private object SetTrianglesImpl(object submesh, object indicesFormat, object triangles, object trianglesArrayLength, object start, object length, object calculateBounds, object baseVertex) { }

	// RVA: 0x737A2C4
	public object SetTriangles(object triangles, object submesh) { }

	// RVA: 0x737A388
	public object SetTriangles(object triangles, object submesh, object calculateBounds, object baseVertex) { }

	// RVA: 0x737A45C
	public object SetTriangles(object triangles, object trianglesStart, object trianglesLength, object submesh, object calculateBounds, object baseVertex) { }

	// RVA: 0x737A524
	public object SetTriangles(object triangles, object submesh) { }

	// RVA: 0x737A63C
	public object SetTriangles(object triangles, object submesh, object calculateBounds) { }

	// RVA: 0x737A5A8
	public object SetTriangles(object triangles, object submesh, object calculateBounds, object baseVertex) { }

	// RVA: 0x737A6C4
	public object SetTriangles(object triangles, object trianglesStart, object trianglesLength, object submesh, object calculateBounds, object baseVertex) { }

	// RVA: 0x737A7D0
	public object SetIndices(object indices, object topology, object submesh) { }

	// RVA: 0x737A970
	public object SetIndices(object indices, object topology, object submesh, object calculateBounds) { }

	// RVA: 0x737A898
	public object SetIndices(object indices, object topology, object submesh, object calculateBounds, object baseVertex) { }

	// RVA: 0x737AA44
	public object SetIndices(object indices, object indicesStart, object indicesLength, object topology, object submesh, object calculateBounds, object baseVertex) { }

	// RVA: 0x737AB28
	public object SetIndices(object indices, object topology, object submesh, object calculateBounds, object baseVertex) { }

	// RVA: 0x737ABD0
	public object SetIndices(object indices, object indicesStart, object indicesLength, object topology, object submesh, object calculateBounds, object baseVertex) { }

	// RVA: 0x737ACF0
	public object get_boneWeights() { }

	// RVA: 0x737AD40
	public object set_boneWeights(object value) { }

	// RVA: 0x737ADA4
	public object Clear(object keepVertexLayout) { }

	// RVA: 0x737AE08
	public object Clear() { }

	// RVA: 0x737AE60
	public object RecalculateBounds() { }

	// RVA: 0x737AFA8
	public object RecalculateNormals() { }

	// RVA: 0x737AE68
	public object RecalculateBounds(object flags) { }

	// RVA: 0x737AFB0
	public object RecalculateNormals(object flags) { }

	// RVA: 0x737B0F0
	public object MarkDynamic() { }

	// RVA: 0x737B184
	public object UploadMeshData(object markNoLongerReadable) { }

	// RVA: 0x737B234
	public object GetTopology(object submesh) { }

	// RVA: 0x737B34C
	public object CombineMeshes(object combine, object mergeSubMeshes, object useMatrices) { }

	// RVA: 0x7377940
	private object SetSubMesh_Injected(object index, object desc, object flags) { }

	// RVA: 0x7377A44
	private object GetSubMesh_Injected(object index, object ret) { }

	// RVA: 0x7377B28
	private object get_bounds_Injected(object ret) { }

	// RVA: 0x7377BF0
	private object set_bounds_Injected(object value) { }

}

// Namespace: UnityEngine
internal struct StaticBatchingHelper
{

	// Methods

	// RVA: 0x737B3D4
	internal static object CombineMeshes(object gos, object staticBatchRoot) { }

}

// Namespace: UnityEngine
public struct BlendShape
{

	// Fields
	private object m_FirstVertex; // 0xFFFFFFFFFFFFFFF8
	private object m_VertexCount; // 0xFFFFFFFFFFFFFFFC
	private object m_HasNormals; // 0x0
	private object m_HasTangents; // 0x1
}

// Namespace: UnityEngine
public struct BoneWeight
{

	// Fields
	private object m_Weight0; // 0xFFFFFFFFFFFFFFF8
	private object m_Weight1; // 0xFFFFFFFFFFFFFFFC
	private object m_Weight2; // 0x0
	private object m_Weight3; // 0x4
	private object m_BoneIndex0; // 0x8
	private object m_BoneIndex1; // 0xC
	private object m_BoneIndex2; // 0x10
	private object m_BoneIndex3; // 0x14

	// Properties
	public object weight0 { get; set; }
	public object weight1 { get; set; }
	public object weight2 { get; set; }
	public object weight3 { get; set; }
	public object boneIndex0 { get; set; }
	public object boneIndex1 { get; set; }
	public object boneIndex2 { get; set; }
	public object boneIndex3 { get; set; }

	// Methods

	// RVA: 0x737B47C
	public object get_weight0() { }

	// RVA: 0x737B48C
	public object set_weight0(object value) { }

	// RVA: 0x737B49C
	public object get_weight1() { }

	// RVA: 0x737B4AC
	public object set_weight1(object value) { }

	// RVA: 0x737B4BC
	public object get_weight2() { }

	// RVA: 0x737B4CC
	public object set_weight2(object value) { }

	// RVA: 0x737B4DC
	public object get_weight3() { }

	// RVA: 0x737B4EC
	public object set_weight3(object value) { }

	// RVA: 0x737B4FC
	public object get_boneIndex0() { }

	// RVA: 0x737B50C
	public object set_boneIndex0(object value) { }

	// RVA: 0x737B51C
	public object get_boneIndex1() { }

	// RVA: 0x737B52C
	public object set_boneIndex1(object value) { }

	// RVA: 0x737B53C
	public object get_boneIndex2() { }

	// RVA: 0x737B54C
	public object set_boneIndex2(object value) { }

	// RVA: 0x737B55C
	public object get_boneIndex3() { }

	// RVA: 0x737B56C
	public object set_boneIndex3(object value) { }

	// RVA: 0x737B57C
	public override object GetHashCode() { }

	// RVA: 0x737B698
	public override object Equals(object other) { }

	// RVA: 0x737B74C
	public object Equals(object other) { }

}

// Namespace: UnityEngine
public struct CombineInstance
{

	// Fields
	private object m_MeshInstanceID; // 0xFFFFFFFFFFFFFFF8
	private object m_SubMeshIndex; // 0xFFFFFFFFFFFFFFFC
	private object m_Transform; // 0x0
	private object m_LightmapScaleOffset; // 0x40
	private object m_RealtimeLightmapScaleOffset; // 0x50

	// Properties
	public object mesh { get; set; }
	public object subMeshIndex { set; }
	public object transform { set; }

	// Methods

	// RVA: 0x737B908
	public object get_mesh() { }

	// RVA: 0x737B920
	public object set_mesh(object value) { }

	// RVA: 0x737BAB0
	public object set_subMeshIndex(object value) { }

	// RVA: 0x737BAC0
	public object set_transform(object value) { }

}

// Namespace: UnityEngine
public class Texture
{

	// Fields
	public static readonly object GenerateAllMips; // 0x0

	// Properties
	public object mipmapCount { get; }
	public virtual object graphicsFormat { get; }
	public virtual object width { get; set; }
	public virtual object height { get; set; }
	public virtual object dimension { get; set; }
	public virtual object isReadable { get; }
	internal object isReadableForGetData { get; }
	public object wrapMode { get; set; }
	public object wrapModeU { get; set; }
	public object wrapModeV { get; set; }
	public object wrapModeW { get; set; }
	public object filterMode { get; set; }
	public object anisoLevel { get; set; }
	public object mipMapBias { set; }
	public object texelSize { get; }
	internal object activeTextureColorSpace { get; }
	public object isDataSRGB { get; }

	// Methods

	// RVA: 0x737BAF0
	public object .ctor() { }

	// RVA: 0x737BB78
	public object get_mipmapCount() { }

	// RVA: 0x737BBC8
	public virtual object get_graphicsFormat() { }

	// RVA: 0x737BC50
	private object GetDataWidth() { }

	// RVA: 0x737BCA0
	private object GetDataHeight() { }

	// RVA: 0x737BCF0
	private object GetDimension() { }

	// RVA: 0x737BD40
	public virtual object get_width() { }

	// RVA: 0x737BD90
	public virtual object set_width(object value) { }

	// RVA: 0x737BDD0
	public virtual object get_height() { }

	// RVA: 0x737BE20
	public virtual object set_height(object value) { }

	// RVA: 0x737BE60
	public virtual object get_dimension() { }

	// RVA: 0x737BEB0
	public virtual object set_dimension(object value) { }

	// RVA: 0x737BEF0
	public virtual object get_isReadable() { }

	// RVA: 0x737BF40
	internal object get_isReadableForGetData() { }

	// RVA: 0x737BF80
	public object get_wrapMode() { }

	// RVA: 0x737BFD0
	public object set_wrapMode(object value) { }

	// RVA: 0x737C034
	public object get_wrapModeU() { }

	// RVA: 0x737C084
	public object set_wrapModeU(object value) { }

	// RVA: 0x737C0E8
	public object get_wrapModeV() { }

	// RVA: 0x737C138
	public object set_wrapModeV(object value) { }

	// RVA: 0x737C19C
	public object get_wrapModeW() { }

	// RVA: 0x737C1EC
	public object set_wrapModeW(object value) { }

	// RVA: 0x737C250
	public object get_filterMode() { }

	// RVA: 0x737C2A0
	public object set_filterMode(object value) { }

	// RVA: 0x737C304
	public object get_anisoLevel() { }

	// RVA: 0x737C354
	public object set_anisoLevel(object value) { }

	// RVA: 0x737C3B8
	public object set_mipMapBias(object value) { }

	// RVA: 0x737C41C
	public object get_texelSize() { }

	// RVA: 0x737C4DC
	private object Internal_GetActiveTextureColorSpace() { }

	// RVA: 0x737C52C
	internal object get_activeTextureColorSpace() { }

	// RVA: 0x737C594
	private object Internal_GetStoredColorSpace() { }

	// RVA: 0x737C5E4
	public object get_isDataSRGB() { }

	// RVA: 0x737C64C
	internal object GetTextureColorSpace(object linear) { }

	// RVA: 0x737C654
	internal object GetTextureColorSpace(object format) { }

	// RVA: 0x737C6BC
	internal object ValidateFormat(object format) { }

	// RVA: 0x737C8D0
	internal object ValidateFormat(object format, object usage) { }

	// RVA: 0x737CACC
	internal object CreateNonReadableException(object t) { }

	// RVA: 0x737CB78
	internal object CreateNativeArrayLengthOverflowException() { }

	// RVA: 0x737CBF0
	private static object .cctor() { }

	// RVA: 0x737C478
	private object get_texelSize_Injected(object ret) { }

}

// Namespace: UnityEngine
public sealed class Texture2D
{

	// Fields
	internal const object streamingMipmapsPriorityMin;
	internal const object streamingMipmapsPriorityMax;

	// Properties
	public object format { get; }
	public static object whiteTexture { get; }
	public static object blackTexture { get; }
	public static object normalTexture { get; }
	public override object isReadable { get; }

	// Methods

	// RVA: 0x737CC40
	public object get_format() { }

	// RVA: 0x737CC90
	public static object get_whiteTexture() { }

	// RVA: 0x737CCD0
	public static object get_blackTexture() { }

	// RVA: 0x737CD10
	public static object get_normalTexture() { }

	// RVA: 0x737CD50
	private static object Internal_CreateImpl(object mono, object w, object h, object mipCount, object format, object colorSpace, object flags, object nativeTex, object mipmapLimitGroupName) { }

	// RVA: 0x737CDF4
	private static object Internal_Create(object mono, object w, object h, object mipCount, object format, object colorSpace, object flags, object nativeTex, object mipmapLimitGroupName) { }

	// RVA: 0x737CEF0
	public override object get_isReadable() { }

	// RVA: 0x737CF40
	private object ApplyImpl(object updateMipmaps, object makeNoLongerReadable) { }

	// RVA: 0x737CFAC
	private object ReinitializeImpl(object width, object height) { }

	// RVA: 0x737D018
	private object SetPixelImpl(object image, object mip, object x, object y, object color) { }

	// RVA: 0x737D140
	private object GetPixelImpl(object image, object mip, object x, object y) { }

	// RVA: 0x737D26C
	private object GetPixelBilinearImpl(object image, object mip, object u, object v) { }

	// RVA: 0x737D398
	private object ReinitializeWithTextureFormatImpl(object width, object height, object textureFormat, object hasMipMap) { }

	// RVA: 0x737D420
	private object ReadPixelsImpl(object source, object destX, object destY, object recalculateMipMaps) { }

	// RVA: 0x737D52C
	private object SetPixelsImpl(object x, object y, object w, object h, object pixel, object miplevel, object frame) { }

	// RVA: 0x737D5C8
	private object LoadRawTextureDataImpl(object data, object size) { }

	// RVA: 0x737D634
	private object LoadRawTextureDataImplArray(object data) { }

	// RVA: 0x737D698
	private object SetPixelDataImplArray(object data, object mipLevel, object elementSize, object dataArraySize, object sourceDataStartIndex) { }

	// RVA: 0x737D734
	private object GetWritableImageData(object frame) { }

	// RVA: 0x737D798
	private object GetRawImageDataSize() { }

	// RVA: 0x737D7E8
	private static object GenerateAtlasImpl(object sizes, object padding, object atlasSize, object rect) { }

	// RVA: 0x737D868
	public object UpdateExternalTexture(object nativeTex) { }

	// RVA: 0x737D8CC
	private object SetAllPixels32(object colors, object miplevel) { }

	// RVA: 0x737D938
	private object SetBlockOfPixels32(object x, object y, object blockWidth, object blockHeight, object colors, object miplevel) { }

	// RVA: 0x737D9DC
	public object GetRawTextureData() { }

	// RVA: 0x737DA2C
	public object GetPixels(object x, object y, object blockWidth, object blockHeight, object miplevel) { }

	// RVA: 0x737DAC8
	public object GetPixels(object x, object y, object blockWidth, object blockHeight) { }

	// RVA: 0x737DB58
	public object GetPixels32(object miplevel) { }

	// RVA: 0x737DBBC
	public object GetPixels32() { }

	// RVA: 0x737DC14
	public static object SetDefaultFillValue(object value) { }

	// RVA: 0x737DC64
	public object PackTextures(object textures, object padding, object maximumAtlasSize, object makeNoLongerReadable, object useNewPacking) { }

	// RVA: 0x737DD00
	public object PackTextures(object textures, object padding, object maximumAtlasSize) { }

	// RVA: 0x737DD74
	internal object ValidateFormat(object format, object width, object height) { }

	// RVA: 0x737DED0
	internal object ValidateFormat(object format, object width, object height) { }

	// RVA: 0x737E058
	internal object .ctor(object width, object height, object format, object flags, object mipCount, object nativeTex, object mipmapLimitGroupName) { }

	// RVA: 0x737E21C
	public object .ctor(object width, object height, object format, object mipCount, object flags) { }

	// RVA: 0x737E24C
	internal object .ctor(object width, object height, object textureFormat, object mipCount, object linear, object nativeTex, object createUninitialized, object ignoreMipmapLimit, object mipmapLimitGroupName) { }

	// RVA: 0x737E46C
	public object .ctor(object width, object height, object textureFormat, object mipCount, object linear) { }

	// RVA: 0x737E498
	public object .ctor(object width, object height, object textureFormat, object mipChain, object linear) { }

	// RVA: 0x737E590
	public object .ctor(object width, object height, object textureFormat, object mipChain) { }

	// RVA: 0x737E674
	public object .ctor(object width, object height) { }

	// RVA: 0x737E71C
	public static object CreateExternalTexture(object width, object height, object format, object mipChain, object linear, object nativeTex) { }

	// RVA: 0x737E834
	public object SetPixel(object x, object y, object color) { }

	// RVA: 0x737E918
	public object SetPixels(object x, object y, object blockWidth, object blockHeight, object colors, object miplevel) { }

	// RVA: 0x737E9F0
	public object SetPixels(object colors, object miplevel) { }

	// RVA: 0x737EB10
	public object SetPixels(object colors) { }

	// RVA: 0x737EC1C
	public object GetPixel(object x, object y) { }

	// RVA: 0x737ECE4
	public object GetPixelBilinear(object u, object v) { }

	// RVA: 0x737EDAC
	public object LoadRawTextureData(object data, object size) { }

	// RVA: 0x737EF28
	public object LoadRawTextureData(object data) { }

	// RVA: -1
	public object SetPixelData(object data, object mipLevel, object sourceDataStartIndex) { }

	// RVA: -1
	public object GetRawTextureData() { }

	// RVA: 0x737F088
	public object Apply(object updateMipmaps, object makeNoLongerReadable) { }

	// RVA: 0x737F12C
	public object Apply() { }

	// RVA: 0x737F1D8
	public object Reinitialize(object width, object height) { }

	// RVA: 0x737F27C
	public object Reinitialize(object width, object height, object format, object hasMipMap) { }

	// RVA: 0x737F304
	public object Resize(object width, object height) { }

	// RVA: 0x737F3A8
	public object ReadPixels(object source, object destX, object destY, object recalculateMipMaps) { }

	// RVA: 0x737F494
	public object ReadPixels(object source, object destX, object destY) { }

	// RVA: 0x737F49C
	public static object GenerateAtlas(object sizes, object padding, object atlasSize, object results) { }

	// RVA: 0x737F66C
	public object SetPixels32(object colors, object miplevel) { }

	// RVA: 0x737F6D8
	public object SetPixels32(object colors) { }

	// RVA: 0x737F744
	public object SetPixels32(object x, object y, object blockWidth, object blockHeight, object colors, object miplevel) { }

	// RVA: 0x737F7E8
	public object SetPixels32(object x, object y, object blockWidth, object blockHeight, object colors) { }

	// RVA: 0x737F870
	public object GetPixels(object miplevel) { }

	// RVA: 0x737F938
	public object GetPixels() { }

	// RVA: 0x737D0A4
	private object SetPixelImpl_Injected(object image, object mip, object x, object y, object color) { }

	// RVA: 0x737D1D0
	private object GetPixelImpl_Injected(object image, object mip, object x, object y, object ret) { }

	// RVA: 0x737D2FC
	private object GetPixelBilinearImpl_Injected(object image, object mip, object u, object v, object ret) { }

	// RVA: 0x737D4A4
	private object ReadPixelsImpl_Injected(object source, object destX, object destY, object recalculateMipMaps) { }

}

// Namespace: UnityEngine
public sealed class Cubemap
{

	// Properties
	public override object isReadable { get; }

	// Methods

	// RVA: 0x737F9EC
	private static object Internal_CreateImpl(object mono, object ext, object mipCount, object format, object colorSpace, object flags, object nativeTex) { }

	// RVA: 0x737FA90
	private static object Internal_Create(object mono, object ext, object mipCount, object format, object colorSpace, object flags, object nativeTex) { }

	// RVA: 0x737FB6C
	private object ApplyImpl(object updateMipmaps, object makeNoLongerReadable) { }

	// RVA: 0x737FBD8
	public override object get_isReadable() { }

	// RVA: 0x737FC28
	private object GetPixelImpl(object image, object mip, object x, object y) { }

	// RVA: 0x737FD54
	public object SetPixels(object colors, object face, object miplevel) { }

	// RVA: 0x737FDD4
	private object SetPixelDataImplArray(object data, object mipLevel, object face, object elementSize, object dataArraySize, object sourceDataStartIndex) { }

	// RVA: 0x737FE78
	public object SetPixels(object colors, object face) { }

	// RVA: 0x737FEEC
	internal object ValidateFormat(object format, object width) { }

	// RVA: 0x737FFEC
	internal object ValidateFormat(object format, object width) { }

	// RVA: 0x738014C
	public object .ctor(object width, object format, object flags) { }

	// RVA: 0x7380270
	public object .ctor(object width, object format, object flags, object mipCount) { }

	// RVA: 0x73801E4
	public object .ctor(object width, object format, object flags) { }

	// RVA: 0x73802C0
	public object .ctor(object width, object format, object flags, object mipCount) { }

	// RVA: 0x7380518
	internal object .ctor(object width, object textureFormat, object mipCount, object nativeTex, object createUninitialized) { }

	// RVA: 0x7380734
	public object .ctor(object width, object textureFormat, object mipChain) { }

	// RVA: 0x73807F0
	public object .ctor(object width, object textureFormat, object mipChain, object createUninitialized) { }

	// RVA: 0x73808B0
	public object .ctor(object width, object format, object mipCount) { }

	// RVA: 0x73808BC
	public object .ctor(object width, object format, object mipCount, object createUninitialized) { }

	// RVA: -1
	public object SetPixelData(object data, object mipLevel, object face, object sourceDataStartIndex) { }

	// RVA: 0x73808C8
	public object GetPixel(object face, object x, object y) { }

	// RVA: 0x73808D0
	public object GetPixel(object face, object x, object y, object mip) { }

	// RVA: 0x73809A8
	public object Apply(object updateMipmaps, object makeNoLongerReadable) { }

	// RVA: 0x7380A4C
	public object Apply(object updateMipmaps) { }

	// RVA: 0x73804BC
	private static object ValidateIsNotCrunched(object flags) { }

	// RVA: 0x737FCB8
	private object GetPixelImpl_Injected(object image, object mip, object x, object y, object ret) { }

}

// Namespace: UnityEngine
public sealed class Texture3D
{

	// Properties
	public object depth { get; }
	public object format { get; }
	public override object isReadable { get; }

	// Methods

	// RVA: 0x7380AEC
	public object get_depth() { }

	// RVA: 0x7380B3C
	public object get_format() { }

	// RVA: 0x7380B8C
	public override object get_isReadable() { }

	// RVA: 0x7380BDC
	private static object Internal_CreateImpl(object mono, object w, object h, object d, object mipCount, object format, object colorSpace, object flags, object nativeTex) { }

	// RVA: 0x7380C80
	private static object Internal_Create(object mono, object w, object h, object d, object mipCount, object format, object colorSpace, object flags, object nativeTex) { }

	// RVA: 0x7380D7C
	private object ApplyImpl(object updateMipmaps, object makeNoLongerReadable) { }

	// RVA: 0x7380DE8
	public object GetPixels(object miplevel) { }

	// RVA: 0x7380E4C
	public object GetPixels() { }

	// RVA: 0x7380EA4
	public object SetPixels32(object colors, object miplevel) { }

	// RVA: 0x7380F10
	public object SetPixels32(object colors) { }

	// RVA: 0x7380F7C
	public object .ctor(object width, object height, object depth, object format, object flags) { }

	// RVA: 0x73810D0
	public object .ctor(object width, object height, object depth, object format, object flags, object mipCount) { }

	// RVA: 0x738102C
	public object .ctor(object width, object height, object depth, object format, object flags) { }

	// RVA: 0x7381138
	public object .ctor(object width, object height, object depth, object format, object flags, object mipCount) { }

	// RVA: 0x738139C
	public object .ctor(object width, object height, object depth, object textureFormat, object mipCount) { }

	// RVA: 0x73813C0
	public object .ctor(object width, object height, object depth, object textureFormat, object mipCount, object nativeTex) { }

	// RVA: 0x73813E0
	public object .ctor(object width, object height, object depth, object textureFormat, object mipCount, object nativeTex, object createUninitialized) { }

	// RVA: 0x7381614
	public object .ctor(object width, object height, object depth, object textureFormat, object mipChain) { }

	// RVA: 0x7381704
	public object .ctor(object width, object height, object depth, object textureFormat, object mipChain, object createUninitialized) { }

	// RVA: 0x73817F8
	public object .ctor(object width, object height, object depth, object textureFormat, object mipChain, object nativeTex) { }

	// RVA: 0x73818F4
	public object Apply(object updateMipmaps, object makeNoLongerReadable) { }

	// RVA: 0x7381998
	public object Apply() { }

	// RVA: 0x7381340
	private static object ValidateIsNotCrunched(object flags) { }

}

// Namespace: UnityEngine
public sealed class Texture2DArray
{

	// Properties
	public static object allSlices { get; }
	public override object isReadable { get; }

	// Methods

	// RVA: 0x7381A44
	public static object get_allSlices() { }

	// RVA: 0x7381A84
	public override object get_isReadable() { }

	// RVA: 0x7381AD4
	private static object Internal_CreateImpl(object mono, object w, object h, object d, object mipCount, object format, object colorSpace, object flags) { }

	// RVA: 0x7381B70
	private static object Internal_Create(object mono, object w, object h, object d, object mipCount, object format, object colorSpace, object flags) { }

	// RVA: 0x7381C5C
	internal object ValidateFormat(object format, object width, object height) { }

	// RVA: 0x7381D68
	internal object ValidateFormat(object format, object width, object height) { }

	// RVA: 0x7381EF0
	public object .ctor(object width, object height, object depth, object format, object flags) { }

	// RVA: 0x7382044
	public object .ctor(object width, object height, object depth, object format, object flags, object mipCount) { }

	// RVA: 0x7381FA0
	public object .ctor(object width, object height, object depth, object format, object flags) { }

	// RVA: 0x738229C
	public object .ctor(object width, object height, object depth, object format, object flags, object mipCount) { }

	// RVA: 0x73824A4
	public object .ctor(object width, object height, object depth, object textureFormat, object mipCount, object linear, object createUninitialized) { }

	// RVA: 0x73826EC
	public object .ctor(object width, object height, object depth, object textureFormat, object mipCount, object linear) { }

	// RVA: 0x738270C
	public object .ctor(object width, object height, object depth, object textureFormat, object mipChain, object linear, object createUninitialized) { }

	// RVA: 0x7382810
	public object .ctor(object width, object height, object depth, object textureFormat, object mipChain, object linear) { }

	// RVA: 0x738290C
	public object .ctor(object width, object height, object depth, object textureFormat, object mipChain) { }

	// RVA: 0x7382240
	private static object ValidateIsNotCrunched(object flags) { }

}

// Namespace: UnityEngine
public sealed class CubemapArray
{

	// Properties
	public override object isReadable { get; }

	// Methods

	// RVA: 0x73829FC
	public override object get_isReadable() { }

	// RVA: 0x7382A4C
	private static object Internal_CreateImpl(object mono, object ext, object count, object mipCount, object format, object colorSpace, object flags) { }

	// RVA: 0x7382AF0
	private static object Internal_Create(object mono, object ext, object count, object mipCount, object format, object colorSpace, object flags) { }

	// RVA: 0x7382BCC
	public object .ctor(object width, object cubemapCount, object format, object flags) { }

	// RVA: 0x7382D10
	public object .ctor(object width, object cubemapCount, object format, object flags, object mipCount) { }

	// RVA: 0x7382C74
	public object .ctor(object width, object cubemapCount, object format, object flags) { }

	// RVA: 0x7382D70
	public object .ctor(object width, object cubemapCount, object format, object flags, object mipCount) { }

	// RVA: 0x7382FD8
	public object .ctor(object width, object cubemapCount, object textureFormat, object mipCount, object linear, object createUninitialized) { }

	// RVA: 0x73831FC
	public object .ctor(object width, object cubemapCount, object textureFormat, object mipCount, object linear) { }

	// RVA: 0x7383204
	public object .ctor(object width, object cubemapCount, object textureFormat, object mipChain, object linear, object createUninitialized) { }

	// RVA: 0x7383304
	public object .ctor(object width, object cubemapCount, object textureFormat, object mipChain, object linear) { }

	// RVA: 0x73833E4
	public object .ctor(object width, object cubemapCount, object textureFormat, object mipChain) { }

	// RVA: 0x7382F7C
	private static object ValidateIsNotCrunched(object flags) { }

}

// Namespace: UnityEngine
public class RenderTexture
{

	// Properties
	public override object width { get; set; }
	public override object height { get; set; }
	public override object dimension { get; set; }
	public object graphicsFormat { get; set; }
	public object useMipMap { get; set; }
	public object vrUsage { set; }
	public object memorylessMode { set; }
	public object format { get; }
	public object stencilFormat { set; }
	public object depthStencilFormat { set; }
	public object autoGenerateMips { set; }
	public object volumeDepth { get; set; }
	public object antiAliasing { get; set; }
	public object bindTextureMS { set; }
	public object enableRandomWrite { get; set; }
	public object useDynamicScale { get; set; }
	public static object active { get; set; }
	public object colorBuffer { get; }
	public object depthBuffer { get; }
	public object depth { get; set; }
	public object descriptor { get; }

	// Methods

	// RVA: 0x73834B0
	public override object get_width() { }

	// RVA: 0x7383500
	public override object set_width(object value) { }

	// RVA: 0x7383564
	public override object get_height() { }

	// RVA: 0x73835B4
	public override object set_height(object value) { }

	// RVA: 0x7383618
	public override object get_dimension() { }

	// RVA: 0x7383668
	public override object set_dimension(object value) { }

	// RVA: 0x73836CC
	private object GetColorFormat(object suppressWarnings) { }

	// RVA: 0x7383730
	private object SetColorFormat(object format) { }

	// RVA: 0x7383794
	public object get_graphicsFormat() { }

	// RVA: 0x73837EC
	public object set_graphicsFormat(object value) { }

	// RVA: 0x7383850
	public object get_useMipMap() { }

	// RVA: 0x73838A0
	public object set_useMipMap(object value) { }

	// RVA: 0x7383904
	public object set_vrUsage(object value) { }

	// RVA: 0x7383968
	public object set_memorylessMode(object value) { }

	// RVA: 0x73839CC
	public object get_format() { }

	// RVA: 0x7383BCC
	public object set_stencilFormat(object value) { }

	// RVA: 0x7383C30
	public object set_depthStencilFormat(object value) { }

	// RVA: 0x7383C94
	public object set_autoGenerateMips(object value) { }

	// RVA: 0x7383CF8
	public object get_volumeDepth() { }

	// RVA: 0x7383D48
	public object set_volumeDepth(object value) { }

	// RVA: 0x7383DAC
	public object get_antiAliasing() { }

	// RVA: 0x7383DFC
	public object set_antiAliasing(object value) { }

	// RVA: 0x7383E60
	public object set_bindTextureMS(object value) { }

	// RVA: 0x7383EC4
	public object get_enableRandomWrite() { }

	// RVA: 0x7383F14
	public object set_enableRandomWrite(object value) { }

	// RVA: 0x7383F78
	public object get_useDynamicScale() { }

	// RVA: 0x7383FC8
	public object set_useDynamicScale(object value) { }

	// RVA: 0x738402C
	private static object GetActive() { }

	// RVA: 0x738406C
	private static object SetActive(object rt) { }

	// RVA: 0x73840BC
	public static object get_active() { }

	// RVA: 0x73840FC
	public static object set_active(object value) { }

	// RVA: 0x738414C
	private object GetColorBuffer() { }

	// RVA: 0x738420C
	private object GetDepthBuffer() { }

	// RVA: 0x73842CC
	private object SetMipMapCount(object count) { }

	// RVA: 0x7384330
	public object get_colorBuffer() { }

	// RVA: 0x738438C
	public object get_depthBuffer() { }

	// RVA: 0x73843E8
	public object DiscardContents(object discardColor, object discardDepth) { }

	// RVA: 0x7384454
	public object MarkRestoreExpected() { }

	// RVA: 0x73844A4
	public object DiscardContents() { }

	// RVA: 0x7384504
	public object Create() { }

	// RVA: 0x7384554
	public object Release() { }

	// RVA: 0x73845A4
	public object GenerateMips() { }

	// RVA: 0x73845F4
	internal object SetSRGBReadWrite(object srgb) { }

	// RVA: 0x7384658
	private static object Internal_Create(object rt) { }

	// RVA: 0x73846A8
	private object SetRenderTextureDescriptor(object desc) { }

	// RVA: 0x7383B44
	private object GetDescriptor() { }

	// RVA: 0x73847D4
	private static object GetTemporary_Internal(object desc) { }

	// RVA: 0x7384874
	public static object ReleaseTemporary(object temp) { }

	// RVA: 0x73848C4
	public object get_depth() { }

	// RVA: 0x7384914
	public object set_depth(object value) { }

	// RVA: 0x7384978
	protected internal object .ctor() { }

	// RVA: 0x7384A58
	public object .ctor(object desc) { }

	// RVA: 0x7384FE4
	public object .ctor(object textureToCopy) { }

	// RVA: 0x7385304
	public object .ctor(object width, object height, object depth, object format) { }

	// RVA: 0x73853AC
	public object .ctor(object width, object height, object depth, object format) { }

	// RVA: 0x7385448
	public object .ctor(object width, object height, object depth, object format, object mipCount) { }

	// RVA: 0x7385844
	public object .ctor(object width, object height, object colorFormat, object depthStencilFormat, object mipCount) { }

	// RVA: 0x7385B70
	public object .ctor(object width, object height, object colorFormat, object depthStencilFormat) { }

	// RVA: 0x7385C0C
	public object .ctor(object width, object height, object depth, object format, object readWrite) { }

	// RVA: 0x7385FF0
	public object .ctor(object width, object height, object depth, object format) { }

	// RVA: 0x738619C
	public object .ctor(object width, object height, object depth) { }

	// RVA: 0x738608C
	public object .ctor(object width, object height, object depth, object format, object mipCount) { }

	// RVA: 0x7385D2C
	private object Initialize(object width, object height, object depth, object format, object readWrite, object mipCount) { }

	// RVA: 0x7385798
	internal static object GetDepthStencilFormatLegacy(object depthBits, object colorFormat) { }

	// RVA: 0x7385270
	public object get_descriptor() { }

	// RVA: 0x7384BC0
	private static object ValidateRenderTextureDesc(object desc) { }

	// RVA: 0x738622C
	internal static object GetCompatibleFormat(object renderTextureFormat, object readWrite) { }

	// RVA: 0x738639C
	public static object GetTemporary(object desc) { }

	// RVA: 0x7386460
	private static object GetTemporaryImpl(object width, object height, object depthBuffer, object colorFormat, object antiAliasing, object memorylessMode, object vrUsage, object useDynamicScale) { }

	// RVA: 0x7386734
	public static object GetTemporary(object width, object height, object depthBuffer, object format) { }

	// RVA: 0x7386760
	public static object GetTemporary(object width, object height, object depthBuffer, object format, object readWrite, object antiAliasing) { }

	// RVA: 0x73867C8
	public static object GetTemporary(object width, object height, object depthBuffer, object format, object readWrite) { }

	// RVA: 0x738682C
	public static object GetTemporary(object width, object height, object depthBuffer, object format) { }

	// RVA: 0x7386890
	public static object GetTemporary(object width, object height, object depthBuffer) { }

	// RVA: 0x73868F4
	public static object GetTemporary(object width, object height) { }

	// RVA: 0x73841A8
	private object GetColorBuffer_Injected(object ret) { }

	// RVA: 0x7384268
	private object GetDepthBuffer_Injected(object ret) { }

	// RVA: 0x738470C
	private object SetRenderTextureDescriptor_Injected(object desc) { }

	// RVA: 0x7384770
	private object GetDescriptor_Injected(object ret) { }

	// RVA: 0x7384824
	private static object GetTemporary_Internal_Injected(object desc) { }

}

// Namespace: UnityEngine
public sealed class CustomRenderTexture
{
}

// Namespace: UnityEngine
public struct RenderTextureDescriptor
{

	// Fields
	private object <width>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <height>k__BackingField; // 0xFFFFFFFFFFFFFFFC
	private object <msaaSamples>k__BackingField; // 0x0
	private object <volumeDepth>k__BackingField; // 0x4
	private object <mipCount>k__BackingField; // 0x8
	private object _graphicsFormat; // 0xC
	private object <stencilFormat>k__BackingField; // 0x10
	private object <depthStencilFormat>k__BackingField; // 0x14
	private object <dimension>k__BackingField; // 0x18
	private object <shadowSamplingMode>k__BackingField; // 0x1C
	private object <vrUsage>k__BackingField; // 0x20
	private object _flags; // 0x24
	private object <memoryless>k__BackingField; // 0x28

	// Properties
	public object width { get; set; }
	public object height { get; set; }
	public object msaaSamples { get; set; }
	public object volumeDepth { get; set; }
	public object mipCount { set; }
	public object graphicsFormat { get; set; }
	public object depthStencilFormat { get; set; }
	public object depthBufferBits { get; set; }
	public object dimension { get; set; }
	public object shadowSamplingMode { get; set; }
	public object vrUsage { get; set; }
	public object memoryless { get; set; }
	public object useMipMap { get; }
	public object autoGenerateMips { get; }
	public object enableRandomWrite { get; }
	public object bindMS { get; }
	internal object createdFromScript { set; }
	public object useDynamicScale { get; set; }

	// Methods

	// RVA: 0x738694C
	public object get_width() { }

	// RVA: 0x738695C
	public object set_width(object value) { }

	// RVA: 0x738696C
	public object get_height() { }

	// RVA: 0x738697C
	public object set_height(object value) { }

	// RVA: 0x738698C
	public object get_msaaSamples() { }

	// RVA: 0x738699C
	public object set_msaaSamples(object value) { }

	// RVA: 0x73869AC
	public object get_volumeDepth() { }

	// RVA: 0x73869BC
	public object set_volumeDepth(object value) { }

	// RVA: 0x73869CC
	public object set_mipCount(object value) { }

	// RVA: 0x7386394
	public object get_graphicsFormat() { }

	// RVA: 0x73869E4
	public object set_graphicsFormat(object value) { }

	// RVA: 0x7386CA0
	public object get_depthStencilFormat() { }

	// RVA: 0x7386CB0
	public object set_depthStencilFormat(object value) { }

	// RVA: 0x7386B54
	public object get_depthBufferBits() { }

	// RVA: 0x7386BE4
	public object set_depthBufferBits(object value) { }

	// RVA: 0x7386E04
	public object get_dimension() { }

	// RVA: 0x7386E14
	public object set_dimension(object value) { }

	// RVA: 0x7386E24
	public object get_shadowSamplingMode() { }

	// RVA: 0x7386E34
	public object set_shadowSamplingMode(object value) { }

	// RVA: 0x7386E44
	public object get_vrUsage() { }

	// RVA: 0x7386E54
	public object set_vrUsage(object value) { }

	// RVA: 0x7386E64
	public object get_memoryless() { }

	// RVA: 0x7386E74
	public object set_memoryless(object value) { }

	// RVA: 0x738664C
	public object .ctor(object width, object height, object colorFormat, object depthStencilFormat) { }

	// RVA: 0x7386E84
	public object .ctor(object width, object height, object colorFormat, object depthStencilFormat, object mipCount) { }

	// RVA: 0x7386B38
	private object SetOrClearRenderTextureCreationFlag(object value, object flag) { }

	// RVA: 0x7387044
	public object get_useMipMap() { }

	// RVA: 0x738705C
	public object get_autoGenerateMips() { }

	// RVA: 0x7387074
	public object get_enableRandomWrite() { }

	// RVA: 0x738708C
	public object get_bindMS() { }

	// RVA: 0x7386440
	internal object set_createdFromScript(object value) { }

	// RVA: 0x73870C4
	public object get_useDynamicScale() { }

	// RVA: 0x7386714
	public object set_useDynamicScale(object value) { }

}

// Namespace: UnityEngine
public class Handheld
{

	// Methods

	// RVA: 0x73870FC
	public static object Vibrate() { }

}

// Namespace: UnityEngine
public struct Hash128
{

	// Fields
	internal object u64_0; // 0xFFFFFFFFFFFFFFF8
	internal object u64_1; // 0x0
	private const object kConst;

	// Methods

	// RVA: 0x738713C
	public object .ctor(object u64_0, object u64_1) { }

	// RVA: 0x738714C
	public object CompareTo(object rhs) { }

	// RVA: 0x7387224
	public override object ToString() { }

	// RVA: 0x7387358
	public static object Parse(object hashString) { }

	// RVA: 0x738728C
	private static object Hash128ToStringImpl(object hash) { }

	// RVA: 0x7387468
	private static object ComputeFromArray(object data, object start, object count, object elemSize, object hash) { }

	// RVA: -1
	public static object Compute(object data) { }

	// RVA: 0x73874F0
	public object Append(object val) { }

	// RVA: 0x7387718
	public override object Equals(object obj) { }

	// RVA: 0x7387880
	public object Equals(object obj) { }

	// RVA: 0x73878A8
	public override object GetHashCode() { }

	// RVA: 0x738791C
	public object CompareTo(object obj) { }

	// RVA: 0x73877C4
	public static object op_Equality(object hash1, object hash2) { }

	// RVA: 0x7387AF4
	public static object op_Inequality(object hash1, object hash2) { }

	// RVA: 0x7387198
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x73871B0
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x73875A8
	private object ShortHash4(object data) { }

	// RVA: 0x7387B04
	private static object ShortEnd(object h0, object h1, object h2, object h3) { }

	// RVA: 0x7387D50
	private static object Rot64(object x, object k) { }

	// RVA: 0x73873B4
	private static object Parse_Injected(object hashString, object ret) { }

	// RVA: 0x7387418
	private static object Hash128ToStringImpl_Injected(object hash) { }

}

// Namespace: UnityEngine
public enum CursorMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object ForceSoftware;
}

// Namespace: UnityEngine
public enum CursorLockMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Locked;
	public const object Confined;
}

// Namespace: UnityEngine
public class Cursor
{

	// Properties
	public static object visible { set; }
	public static object lockState { get; }

	// Methods

	// RVA: 0x7387D64
	public static object SetCursor(object texture, object hotspot, object cursorMode) { }

	// RVA: 0x7387E38
	public static object set_visible(object value) { }

	// RVA: 0x7387E88
	public static object get_lockState() { }

	// RVA: 0x7387DCC
	private static object SetCursor_Injected(object texture, object hotspot, object cursorMode) { }

}

// Namespace: UnityEngine
public enum KeyCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Backspace;
	public const object Delete;
	public const object Tab;
	public const object Clear;
	public const object Return;
	public const object Pause;
	public const object Escape;
	public const object Space;
	public const object Keypad0;
	public const object Keypad1;
	public const object Keypad2;
	public const object Keypad3;
	public const object Keypad4;
	public const object Keypad5;
	public const object Keypad6;
	public const object Keypad7;
	public const object Keypad8;
	public const object Keypad9;
	public const object KeypadPeriod;
	public const object KeypadDivide;
	public const object KeypadMultiply;
	public const object KeypadMinus;
	public const object KeypadPlus;
	public const object KeypadEnter;
	public const object KeypadEquals;
	public const object UpArrow;
	public const object DownArrow;
	public const object RightArrow;
	public const object LeftArrow;
	public const object Insert;
	public const object Home;
	public const object End;
	public const object PageUp;
	public const object PageDown;
	public const object F1;
	public const object F2;
	public const object F3;
	public const object F4;
	public const object F5;
	public const object F6;
	public const object F7;
	public const object F8;
	public const object F9;
	public const object F10;
	public const object F11;
	public const object F12;
	public const object F13;
	public const object F14;
	public const object F15;
	public const object Alpha0;
	public const object Alpha1;
	public const object Alpha2;
	public const object Alpha3;
	public const object Alpha4;
	public const object Alpha5;
	public const object Alpha6;
	public const object Alpha7;
	public const object Alpha8;
	public const object Alpha9;
	public const object Exclaim;
	public const object DoubleQuote;
	public const object Hash;
	public const object Dollar;
	public const object Percent;
	public const object Ampersand;
	public const object Quote;
	public const object LeftParen;
	public const object RightParen;
	public const object Asterisk;
	public const object Plus;
	public const object Comma;
	public const object Minus;
	public const object Period;
	public const object Slash;
	public const object Colon;
	public const object Semicolon;
	public const object Less;
	public const object Equals;
	public const object Greater;
	public const object Question;
	public const object At;
	public const object LeftBracket;
	public const object Backslash;
	public const object RightBracket;
	public const object Caret;
	public const object Underscore;
	public const object BackQuote;
	public const object A;
	public const object B;
	public const object C;
	public const object D;
	public const object E;
	public const object F;
	public const object G;
	public const object H;
	public const object I;
	public const object J;
	public const object K;
	public const object L;
	public const object M;
	public const object N;
	public const object O;
	public const object P;
	public const object Q;
	public const object R;
	public const object S;
	public const object T;
	public const object U;
	public const object V;
	public const object W;
	public const object X;
	public const object Y;
	public const object Z;
	public const object LeftCurlyBracket;
	public const object Pipe;
	public const object RightCurlyBracket;
	public const object Tilde;
	public const object Numlock;
	public const object CapsLock;
	public const object ScrollLock;
	public const object RightShift;
	public const object LeftShift;
	public const object RightControl;
	public const object LeftControl;
	public const object RightAlt;
	public const object LeftAlt;
	public const object LeftMeta;
	public const object LeftCommand;
	public const object LeftApple;
	public const object LeftWindows;
	public const object RightMeta;
	public const object RightCommand;
	public const object RightApple;
	public const object RightWindows;
	public const object AltGr;
	public const object Help;
	public const object Print;
	public const object SysReq;
	public const object Break;
	public const object Menu;
	public const object Mouse0;
	public const object Mouse1;
	public const object Mouse2;
	public const object Mouse3;
	public const object Mouse4;
	public const object Mouse5;
	public const object Mouse6;
	public const object JoystickButton0;
	public const object JoystickButton1;
	public const object JoystickButton2;
	public const object JoystickButton3;
	public const object JoystickButton4;
	public const object JoystickButton5;
	public const object JoystickButton6;
	public const object JoystickButton7;
	public const object JoystickButton8;
	public const object JoystickButton9;
	public const object JoystickButton10;
	public const object JoystickButton11;
	public const object JoystickButton12;
	public const object JoystickButton13;
	public const object JoystickButton14;
	public const object JoystickButton15;
	public const object JoystickButton16;
	public const object JoystickButton17;
	public const object JoystickButton18;
	public const object JoystickButton19;
	public const object Joystick1Button0;
	public const object Joystick1Button1;
	public const object Joystick1Button2;
	public const object Joystick1Button3;
	public const object Joystick1Button4;
	public const object Joystick1Button5;
	public const object Joystick1Button6;
	public const object Joystick1Button7;
	public const object Joystick1Button8;
	public const object Joystick1Button9;
	public const object Joystick1Button10;
	public const object Joystick1Button11;
	public const object Joystick1Button12;
	public const object Joystick1Button13;
	public const object Joystick1Button14;
	public const object Joystick1Button15;
	public const object Joystick1Button16;
	public const object Joystick1Button17;
	public const object Joystick1Button18;
	public const object Joystick1Button19;
	public const object Joystick2Button0;
	public const object Joystick2Button1;
	public const object Joystick2Button2;
	public const object Joystick2Button3;
	public const object Joystick2Button4;
	public const object Joystick2Button5;
	public const object Joystick2Button6;
	public const object Joystick2Button7;
	public const object Joystick2Button8;
	public const object Joystick2Button9;
	public const object Joystick2Button10;
	public const object Joystick2Button11;
	public const object Joystick2Button12;
	public const object Joystick2Button13;
	public const object Joystick2Button14;
	public const object Joystick2Button15;
	public const object Joystick2Button16;
	public const object Joystick2Button17;
	public const object Joystick2Button18;
	public const object Joystick2Button19;
	public const object Joystick3Button0;
	public const object Joystick3Button1;
	public const object Joystick3Button2;
	public const object Joystick3Button3;
	public const object Joystick3Button4;
	public const object Joystick3Button5;
	public const object Joystick3Button6;
	public const object Joystick3Button7;
	public const object Joystick3Button8;
	public const object Joystick3Button9;
	public const object Joystick3Button10;
	public const object Joystick3Button11;
	public const object Joystick3Button12;
	public const object Joystick3Button13;
	public const object Joystick3Button14;
	public const object Joystick3Button15;
	public const object Joystick3Button16;
	public const object Joystick3Button17;
	public const object Joystick3Button18;
	public const object Joystick3Button19;
	public const object Joystick4Button0;
	public const object Joystick4Button1;
	public const object Joystick4Button2;
	public const object Joystick4Button3;
	public const object Joystick4Button4;
	public const object Joystick4Button5;
	public const object Joystick4Button6;
	public const object Joystick4Button7;
	public const object Joystick4Button8;
	public const object Joystick4Button9;
	public const object Joystick4Button10;
	public const object Joystick4Button11;
	public const object Joystick4Button12;
	public const object Joystick4Button13;
	public const object Joystick4Button14;
	public const object Joystick4Button15;
	public const object Joystick4Button16;
	public const object Joystick4Button17;
	public const object Joystick4Button18;
	public const object Joystick4Button19;
	public const object Joystick5Button0;
	public const object Joystick5Button1;
	public const object Joystick5Button2;
	public const object Joystick5Button3;
	public const object Joystick5Button4;
	public const object Joystick5Button5;
	public const object Joystick5Button6;
	public const object Joystick5Button7;
	public const object Joystick5Button8;
	public const object Joystick5Button9;
	public const object Joystick5Button10;
	public const object Joystick5Button11;
	public const object Joystick5Button12;
	public const object Joystick5Button13;
	public const object Joystick5Button14;
	public const object Joystick5Button15;
	public const object Joystick5Button16;
	public const object Joystick5Button17;
	public const object Joystick5Button18;
	public const object Joystick5Button19;
	public const object Joystick6Button0;
	public const object Joystick6Button1;
	public const object Joystick6Button2;
	public const object Joystick6Button3;
	public const object Joystick6Button4;
	public const object Joystick6Button5;
	public const object Joystick6Button6;
	public const object Joystick6Button7;
	public const object Joystick6Button8;
	public const object Joystick6Button9;
	public const object Joystick6Button10;
	public const object Joystick6Button11;
	public const object Joystick6Button12;
	public const object Joystick6Button13;
	public const object Joystick6Button14;
	public const object Joystick6Button15;
	public const object Joystick6Button16;
	public const object Joystick6Button17;
	public const object Joystick6Button18;
	public const object Joystick6Button19;
	public const object Joystick7Button0;
	public const object Joystick7Button1;
	public const object Joystick7Button2;
	public const object Joystick7Button3;
	public const object Joystick7Button4;
	public const object Joystick7Button5;
	public const object Joystick7Button6;
	public const object Joystick7Button7;
	public const object Joystick7Button8;
	public const object Joystick7Button9;
	public const object Joystick7Button10;
	public const object Joystick7Button11;
	public const object Joystick7Button12;
	public const object Joystick7Button13;
	public const object Joystick7Button14;
	public const object Joystick7Button15;
	public const object Joystick7Button16;
	public const object Joystick7Button17;
	public const object Joystick7Button18;
	public const object Joystick7Button19;
	public const object Joystick8Button0;
	public const object Joystick8Button1;
	public const object Joystick8Button2;
	public const object Joystick8Button3;
	public const object Joystick8Button4;
	public const object Joystick8Button5;
	public const object Joystick8Button6;
	public const object Joystick8Button7;
	public const object Joystick8Button8;
	public const object Joystick8Button9;
	public const object Joystick8Button10;
	public const object Joystick8Button11;
	public const object Joystick8Button12;
	public const object Joystick8Button13;
	public const object Joystick8Button14;
	public const object Joystick8Button15;
	public const object Joystick8Button16;
	public const object Joystick8Button17;
	public const object Joystick8Button18;
	public const object Joystick8Button19;
}

// Namespace: UnityEngine
public interface ILogger
{

	// Properties
	public abstract object logHandler { get; }
	public abstract object logEnabled { get; set; }
	public abstract object filterLogType { set; }

	// Methods

	// RVA: -1
	public abstract object get_logHandler() { }

	// RVA: -1
	public abstract object get_logEnabled() { }

	// RVA: -1
	public abstract object set_logEnabled(object value) { }

	// RVA: -1
	public abstract object set_filterLogType(object value) { }

	// RVA: -1
	public abstract object Log(object logType, object message) { }

	// RVA: -1
	public abstract object Log(object logType, object message, object context) { }

	// RVA: -1
	public abstract object LogError(object tag, object message) { }

	// RVA: -1
	public abstract object LogFormat(object logType, object format, object args) { }

}

// Namespace: UnityEngine
public interface ILogHandler
{

	// Methods

	// RVA: -1
	public abstract object LogFormat(object logType, object context, object format, object args) { }

	// RVA: -1
	public abstract object LogException(object exception, object context) { }

}

// Namespace: UnityEngine
public class Logger
{

	// Fields
	private object <logHandler>k__BackingField; // 0x8
	private object <logEnabled>k__BackingField; // 0x10
	private object <filterLogType>k__BackingField; // 0x14

	// Properties
	public object logHandler { get; set; }
	public object logEnabled { get; set; }
	public object filterLogType { get; set; }

	// Methods

	// RVA: 0x7387EC8
	public object .ctor(object logHandler) { }

	// RVA: 0x7387F00
	public object get_logHandler() { }

	// RVA: 0x7387F08
	public object set_logHandler(object value) { }

	// RVA: 0x7387F10
	public object get_logEnabled() { }

	// RVA: 0x7387F18
	public object set_logEnabled(object value) { }

	// RVA: 0x7387F20
	public object get_filterLogType() { }

	// RVA: 0x7387F28
	public object set_filterLogType(object value) { }

	// RVA: 0x7387F30
	public object IsLogTypeAllowed(object logType) { }

	// RVA: 0x7387F68
	private static object GetString(object message) { }

	// RVA: 0x73880C8
	public object Log(object logType, object message) { }

	// RVA: 0x7388278
	public object Log(object logType, object message, object context) { }

	// RVA: 0x7388438
	public object LogError(object tag, object message) { }

	// RVA: 0x7388608
	public object LogException(object exception, object context) { }

	// RVA: 0x7388710
	public object LogFormat(object logType, object format, object args) { }

	// RVA: 0x7388838
	public object LogFormat(object logType, object context, object format, object args) { }

}

// Namespace: UnityEngine
internal class UnityLogWriter
{

	// Properties
	public override object Encoding { get; }

	// Methods

	// RVA: 0x7388970
	public static object WriteStringToUnityLog(object s) { }

	// RVA: 0x73889C8
	private static object WriteStringToUnityLogImpl(object s) { }

	// RVA: 0x7388A18
	public static object Init() { }

	// RVA: 0x7388BA8
	public override object get_Encoding() { }

	// RVA: 0x7388BB0
	public override object Write(object value) { }

	// RVA: 0x7388C8C
	public override object Write(object s) { }

	// RVA: 0x7388CE8
	public override object Write(object buffer, object index, object count) { }

	// RVA: 0x7388B20
	public object .ctor() { }

}

// Namespace: UnityEngine
public struct Color
{

	// Fields
	public object r; // 0xFFFFFFFFFFFFFFF8
	public object g; // 0xFFFFFFFFFFFFFFFC
	public object b; // 0x0
	public object a; // 0x4

	// Properties
	public static object red { get; }
	public static object green { get; }
	public static object blue { get; }
	public static object white { get; }
	public static object black { get; }
	public static object yellow { get; }
	public static object cyan { get; }
	public static object magenta { get; }
	public static object gray { get; }
	public static object grey { get; }
	public static object clear { get; }
	public object grayscale { get; }
	public object linear { get; }
	public object gamma { get; }
	public object maxColorComponent { get; }
	public object Item { get; set; }

	// Methods

	// RVA: 0x7388D44
	public object .ctor(object r, object g, object b, object a) { }

	// RVA: 0x7388D5C
	public object .ctor(object r, object g, object b) { }

	// RVA: 0x7388D84
	public override object ToString() { }

	// RVA: 0x7388DA8
	public object ToString(object format) { }

	// RVA: 0x7388DC4
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7389014
	public override object GetHashCode() { }

	// RVA: 0x738910C
	public override object Equals(object other) { }

	// RVA: 0x738920C
	public object Equals(object other) { }

	// RVA: 0x7389330
	public static object op_Addition(object a, object b) { }

	// RVA: 0x7389344
	public static object op_Subtraction(object a, object b) { }

	// RVA: 0x7389358
	public static object op_Multiply(object a, object b) { }

	// RVA: 0x738936C
	public static object op_Multiply(object a, object b) { }

	// RVA: 0x7389380
	public static object op_Multiply(object b, object a) { }

	// RVA: 0x7389398
	public static object op_Division(object a, object b) { }

	// RVA: 0x73893AC
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x73893F0
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7389434
	public static object Lerp(object a, object b, object t) { }

	// RVA: 0x7389484
	public static object LerpUnclamped(object a, object b, object t) { }

	// RVA: 0x73894BC
	internal object RGBMultiplied(object multiplier) { }

	// RVA: 0x73894F4
	public static object get_red() { }

	// RVA: 0x7389508
	public static object get_green() { }

	// RVA: 0x738951C
	public static object get_blue() { }

	// RVA: 0x7389530
	public static object get_white() { }

	// RVA: 0x7389544
	public static object get_black() { }

	// RVA: 0x7389558
	public static object get_yellow() { }

	// RVA: 0x738957C
	public static object get_cyan() { }

	// RVA: 0x7389590
	public static object get_magenta() { }

	// RVA: 0x73895A4
	public static object get_gray() { }

	// RVA: 0x73895B8
	public static object get_grey() { }

	// RVA: 0x73895CC
	public static object get_clear() { }

	// RVA: 0x73895E0
	public object get_grayscale() { }

	// RVA: 0x7389648
	public object get_linear() { }

	// RVA: 0x738986C
	public object get_gamma() { }

	// RVA: 0x7389A90
	public object get_maxColorComponent() { }

	// RVA: 0x7389AC8
	public static object op_Implicit(object c) { }

	// RVA: 0x7389ACC
	public static object op_Implicit(object v) { }

	// RVA: 0x7389AD0
	public object get_Item(object index) { }

	// RVA: 0x7389BCC
	public object set_Item(object index, object value) { }

	// RVA: 0x7389CC8
	public static object RGBToHSV(object rgbColor, object H, object S, object V) { }

	// RVA: 0x7389E0C
	private static object RGBToHSVHelper(object offset, object dominantcolor, object colorone, object colortwo, object H, object S, object V) { }

	// RVA: 0x7389E7C
	public static object HSVToRGB(object H, object S, object V) { }

	// RVA: 0x7389FE4
	public static object HSVToRGB(object H, object S, object V, object hdr) { }

}

// Namespace: UnityEngine
public struct Color32
{

	// Fields
	private object rgba; // 0xFFFFFFFFFFFFFFF8
	public object r; // 0xFFFFFFFFFFFFFFF8
	public object g; // 0xFFFFFFFFFFFFFFF9
	public object b; // 0xFFFFFFFFFFFFFFFA
	public object a; // 0xFFFFFFFFFFFFFFFB

	// Methods

	// RVA: 0x738A188
	public object .ctor(object r, object g, object b, object a) { }

	// RVA: 0x738A1B0
	public static object op_Implicit(object c) { }

	// RVA: 0x738A4C4
	public static object op_Implicit(object c) { }

	// RVA: 0x738A500
	public override object ToString() { }

	// RVA: 0x738A740
	public object ToString(object format, object formatProvider) { }

}

// Namespace: UnityEngine
public class ColorUtility
{

	// Methods

	// RVA: 0x738A964
	internal static object DoTryParseHtmlColor(object htmlString, object color) { }

	// RVA: 0x738A9C8
	public static object TryParseHtmlString(object htmlString, object color) { }

}

// Namespace: UnityEngine
public struct GradientColorKey
{

	// Fields
	public object color; // 0xFFFFFFFFFFFFFFF8
	public object time; // 0x8

	// Methods

	// RVA: 0x738AA7C
	public object .ctor(object col, object time) { }

}

// Namespace: UnityEngine
public struct GradientAlphaKey
{

	// Fields
	public object alpha; // 0xFFFFFFFFFFFFFFF8
	public object time; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x738AA9C
	public object .ctor(object alpha, object time) { }

}

// Namespace: UnityEngine
public enum GradientMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Blend;
	public const object Fixed;
	public const object PerceptualBlend;
}

// Namespace: UnityEngine
public class Gradient
{

	// Fields
	internal object m_Ptr; // 0x8

	// Properties
	public object colorKeys { get; }
	public object alphaKeys { get; }
	public object mode { get; }

	// Methods

	// RVA: 0x738AAC8
	private static object Init() { }

	// RVA: 0x738AB08
	private object Cleanup() { }

	// RVA: 0x738AB58
	private object Internal_Equals(object other) { }

	// RVA: 0x738ABBC
	public object .ctor() { }

	// RVA: 0x738AC18
	protected override object Finalize() { }

	// RVA: 0x738ACD0
	public object Evaluate(object time) { }

	// RVA: 0x738ADB8
	public object get_colorKeys() { }

	// RVA: 0x738AE08
	public object get_alphaKeys() { }

	// RVA: 0x738AE58
	public object get_mode() { }

	// RVA: 0x738AEA8
	public object SetKeys(object colorKeys, object alphaKeys) { }

	// RVA: 0x738AF14
	public override object Equals(object o) { }

	// RVA: 0x738B0C8
	public object Equals(object other) { }

	// RVA: 0x738B1B4
	public override object GetHashCode() { }

	// RVA: 0x738AD40
	private object Evaluate_Injected(object time, object ret) { }

}

// Namespace: UnityEngine
public struct Matrix4x4
{

	// Fields
	public object m00; // 0xFFFFFFFFFFFFFFF8
	public object m10; // 0xFFFFFFFFFFFFFFFC
	public object m20; // 0x0
	public object m30; // 0x4
	public object m01; // 0x8
	public object m11; // 0xC
	public object m21; // 0x10
	public object m31; // 0x14
	public object m02; // 0x18
	public object m12; // 0x1C
	public object m22; // 0x20
	public object m32; // 0x24
	public object m03; // 0x28
	public object m13; // 0x2C
	public object m23; // 0x30
	public object m33; // 0x34
	private static readonly object zeroMatrix; // 0x0
	private static readonly object identityMatrix; // 0x30

	// Properties
	public object rotation { get; }
	public object lossyScale { get; }
	public object determinant { get; }
	public object inverse { get; }
	public object transpose { get; }
	public object Item { get; set; }
	public object Item { get; set; }
	public static object zero { get; }
	public static object identity { get; }

	// Methods

	// RVA: 0x738B1C0
	private object GetRotation() { }

	// RVA: 0x738B2E0
	private object GetLossyScale() { }

	// RVA: 0x738B408
	private object GetDeterminant() { }

	// RVA: 0x738B4F8
	public object get_rotation() { }

	// RVA: 0x738B5B4
	public object get_lossyScale() { }

	// RVA: 0x738B678
	public object get_determinant() { }

	// RVA: 0x738B718
	public static object TRS(object pos, object q, object s) { }

	// RVA: 0x738B82C
	public object SetTRS(object pos, object q, object s) { }

	// RVA: 0x738B96C
	public static object Inverse3DAffine(object input, object result) { }

	// RVA: 0x738BA34
	public static object Inverse(object m) { }

	// RVA: 0x738BB14
	public object get_inverse() { }

	// RVA: 0x738BC1C
	public static object Transpose(object m) { }

	// RVA: 0x738BCFC
	public object get_transpose() { }

	// RVA: 0x738BE04
	public static object Ortho(object left, object right, object bottom, object top, object zNear, object zFar) { }

	// RVA: 0x738BF58
	public static object Perspective(object fov, object aspect, object zNear, object zFar) { }

	// RVA: 0x738C078
	public static object LookAt(object from, object to, object up) { }

	// RVA: 0x738C18C
	public object .ctor(object column0, object column1, object column2, object column3) { }

	// RVA: 0x738C1C8
	public object get_Item(object row, object column) { }

	// RVA: 0x738C2D0
	public object set_Item(object row, object column, object value) { }

	// RVA: 0x738C1D0
	public object get_Item(object index) { }

	// RVA: 0x738C2D8
	public object set_Item(object index, object value) { }

	// RVA: 0x738C3E8
	public override object GetHashCode() { }

	// RVA: 0x738C694
	public override object Equals(object other) { }

	// RVA: 0x738C8AC
	public object Equals(object other) { }

	// RVA: 0x738C9C4
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x738CA68
	public static object op_Multiply(object lhs, object vector) { }

	// RVA: 0x738CA9C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x738CB90
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x738C588
	public object GetColumn(object index) { }

	// RVA: 0x738CC8C
	public object GetRow(object index) { }

	// RVA: 0x738CD98
	public object GetPosition() { }

	// RVA: 0x738CDB0
	public object SetColumn(object index, object column) { }

	// RVA: 0x738CEAC
	public object SetRow(object index, object row) { }

	// RVA: 0x738CF88
	public object MultiplyPoint(object point) { }

	// RVA: 0x738D088
	public object MultiplyPoint3x4(object point) { }

	// RVA: 0x738D140
	public object MultiplyVector(object vector) { }

	// RVA: 0x738D1D8
	public static object Scale(object vector) { }

	// RVA: 0x738D204
	public static object Translate(object vector) { }

	// RVA: 0x738D238
	public static object Rotate(object q) { }

	// RVA: 0x738D2D0
	public static object get_zero() { }

	// RVA: 0x738D334
	public static object get_identity() { }

	// RVA: 0x738D398
	public override object ToString() { }

	// RVA: 0x738D3BC
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x738D90C
	private static object .cctor() { }

	// RVA: 0x738B220
	private static object GetRotation_Injected(object _unity_self, object ret) { }

	// RVA: 0x738B344
	private static object GetLossyScale_Injected(object _unity_self, object ret) { }

	// RVA: 0x738B458
	private static object GetDeterminant_Injected(object _unity_self) { }

	// RVA: 0x738B7AC
	private static object TRS_Injected(object pos, object q, object s, object ret) { }

	// RVA: 0x738B9D0
	private static object Inverse3DAffine_Injected(object input, object result) { }

	// RVA: 0x738BAB0
	private static object Inverse_Injected(object m, object ret) { }

	// RVA: 0x738BC98
	private static object Transpose_Injected(object m, object ret) { }

	// RVA: 0x738BEB4
	private static object Ortho_Injected(object left, object right, object bottom, object top, object zNear, object zFar, object ret) { }

	// RVA: 0x738BFF0
	private static object Perspective_Injected(object fov, object aspect, object zNear, object zFar, object ret) { }

	// RVA: 0x738C10C
	private static object LookAt_Injected(object from, object to, object up, object ret) { }

}

// Namespace: UnityEngine
public struct Vector3
{

	// Fields
	public const object kEpsilon;
	public const object kEpsilonNormalSqrt;
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	private static readonly object zeroVector; // 0x0
	private static readonly object oneVector; // 0xFFFFFFFFFFFFFFFC
	private static readonly object upVector; // 0x8
	private static readonly object downVector; // 0x14
	private static readonly object leftVector; // 0x20
	private static readonly object rightVector; // 0x2C
	private static readonly object forwardVector; // 0x38
	private static readonly object backVector; // 0x44
	private static readonly object positiveInfinityVector; // 0x50
	private static readonly object negativeInfinityVector; // 0x5C

	// Properties
	public object Item { get; set; }
	public object normalized { get; }
	public object magnitude { get; }
	public object sqrMagnitude { get; }
	public static object zero { get; }
	public static object one { get; }
	public static object forward { get; }
	public static object back { get; }
	public static object up { get; }
	public static object down { get; }
	public static object left { get; }
	public static object right { get; }
	public static object positiveInfinity { get; }
	public static object negativeInfinity { get; }

	// Methods

	// RVA: 0x738D988
	public static object Slerp(object a, object b, object t) { }

	// RVA: 0x738DA88
	public static object SlerpUnclamped(object a, object b, object t) { }

	// RVA: 0x738DB88
	private static object OrthoNormalize2(object a, object b) { }

	// RVA: 0x738DBEC
	public static object OrthoNormalize(object normal, object tangent) { }

	// RVA: 0x738DC50
	private static object OrthoNormalize3(object a, object b, object c) { }

	// RVA: 0x738DCBC
	public static object OrthoNormalize(object normal, object tangent, object binormal) { }

	// RVA: 0x738DD28
	public static object RotateTowards(object current, object target, object maxRadiansDelta, object maxMagnitudeDelta) { }

	// RVA: 0x738DE38
	public static object Lerp(object a, object b, object t) { }

	// RVA: 0x738DE78
	public static object LerpUnclamped(object a, object b, object t) { }

	// RVA: 0x738DEA0
	public static object MoveTowards(object current, object target, object maxDistanceDelta) { }

	// RVA: 0x738DFC0
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime, object maxSpeed) { }

	// RVA: 0x738E288
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime) { }

	// RVA: 0x738E058
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime, object maxSpeed, object deltaTime) { }

	// RVA: 0x738E320
	public object get_Item(object index) { }

	// RVA: 0x738E428
	public object set_Item(object index, object value) { }

	// RVA: 0x738E530
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x738E548
	public object .ctor(object x, object y) { }

	// RVA: 0x738E560
	public object Set(object newX, object newY, object newZ) { }

	// RVA: 0x738E578
	public static object Scale(object a, object b) { }

	// RVA: 0x738E588
	public object Scale(object scale) { }

	// RVA: 0x738E5C8
	public static object Cross(object lhs, object rhs) { }

	// RVA: 0x738E5F8
	public override object GetHashCode() { }

	// RVA: 0x738E6A4
	public override object Equals(object other) { }

	// RVA: 0x738E82C
	public object Equals(object other) { }

	// RVA: 0x738E88C
	public static object Reflect(object inDirection, object inNormal) { }

	// RVA: 0x738E8C4
	public static object Normalize(object value) { }

	// RVA: 0x738E9B4
	public object Normalize() { }

	// RVA: 0x738EB94
	public object get_normalized() { }

	// RVA: 0x738ED6C
	public static object Dot(object lhs, object rhs) { }

	// RVA: 0x738ED84
	public static object Project(object vector, object onNormal) { }

	// RVA: 0x738EE98
	public static object ProjectOnPlane(object vector, object planeNormal) { }

	// RVA: 0x738EF74
	public static object Angle(object from, object to) { }

	// RVA: 0x738F0A0
	public static object SignedAngle(object from, object to, object axis) { }

	// RVA: 0x738F230
	public static object Distance(object a, object b) { }

	// RVA: 0x738F2D4
	public static object ClampMagnitude(object vector, object maxLength) { }

	// RVA: 0x738F3AC
	public static object Magnitude(object vector) { }

	// RVA: 0x738F430
	public object get_magnitude() { }

	// RVA: 0x738F538
	public static object SqrMagnitude(object vector) { }

	// RVA: 0x738F550
	public object get_sqrMagnitude() { }

	// RVA: 0x738F590
	public static object Min(object lhs, object rhs) { }

	// RVA: 0x738F5AC
	public static object Max(object lhs, object rhs) { }

	// RVA: 0x738F5C8
	public static object get_zero() { }

	// RVA: 0x738F618
	public static object get_one() { }

	// RVA: 0x738F668
	public static object get_forward() { }

	// RVA: 0x738F6B8
	public static object get_back() { }

	// RVA: 0x738F708
	public static object get_up() { }

	// RVA: 0x738F758
	public static object get_down() { }

	// RVA: 0x738F7A8
	public static object get_left() { }

	// RVA: 0x738F7F8
	public static object get_right() { }

	// RVA: 0x738F848
	public static object get_positiveInfinity() { }

	// RVA: 0x738F898
	public static object get_negativeInfinity() { }

	// RVA: 0x738F8E8
	public static object op_Addition(object a, object b) { }

	// RVA: 0x738F8F8
	public static object op_Subtraction(object a, object b) { }

	// RVA: 0x738F908
	public static object op_UnaryNegation(object a) { }

	// RVA: 0x738F918
	public static object op_Multiply(object a, object d) { }

	// RVA: 0x738F928
	public static object op_Multiply(object d, object a) { }

	// RVA: 0x738F93C
	public static object op_Division(object a, object d) { }

	// RVA: 0x738F94C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x738F984
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x738F9BC
	public override object ToString() { }

	// RVA: 0x738F9E0
	public object ToString(object format) { }

	// RVA: 0x738F9FC
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x738FC0C
	private static object .cctor() { }

	// RVA: 0x738DA08
	private static object Slerp_Injected(object a, object b, object t, object ret) { }

	// RVA: 0x738DB08
	private static object SlerpUnclamped_Injected(object a, object b, object t, object ret) { }

	// RVA: 0x738DDB0
	private static object RotateTowards_Injected(object current, object target, object maxRadiansDelta, object maxMagnitudeDelta, object ret) { }

}

// Namespace: UnityEngine
public struct Quaternion
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public object w; // 0x4
	private static readonly object identityQuaternion; // 0x0
	public const object kEpsilon;

	// Properties
	public object Item { get; set; }
	public static object identity { get; }
	public object eulerAngles { get; set; }
	public object normalized { get; }

	// Methods

	// RVA: 0x738FC9C
	public static object FromToRotation(object fromDirection, object toDirection) { }

	// RVA: 0x738FD74
	public static object Inverse(object rotation) { }

	// RVA: 0x738FE38
	public static object Slerp(object a, object b, object t) { }

	// RVA: 0x738FF34
	public static object SlerpUnclamped(object a, object b, object t) { }

	// RVA: 0x7390030
	public static object Lerp(object a, object b, object t) { }

	// RVA: 0x739012C
	public static object LerpUnclamped(object a, object b, object t) { }

	// RVA: 0x7390228
	private static object Internal_FromEulerRad(object euler) { }

	// RVA: 0x73902EC
	private static object Internal_ToEulerRad(object rotation) { }

	// RVA: 0x73903B4
	private static object Internal_ToAxisAngleRad(object q, object axis, object angle) { }

	// RVA: 0x7390488
	public static object AngleAxis(object angle, object axis) { }

	// RVA: 0x7390570
	public static object LookRotation(object forward, object upwards) { }

	// RVA: 0x7390648
	public static object LookRotation(object forward) { }

	// RVA: 0x7390708
	public object get_Item(object index) { }

	// RVA: 0x7390844
	public object set_Item(object index, object value) { }

	// RVA: 0x7390980
	public object .ctor(object x, object y, object z, object w) { }

	// RVA: 0x7390998
	public object Set(object newX, object newY, object newZ, object newW) { }

	// RVA: 0x73909B0
	public static object get_identity() { }

	// RVA: 0x7390A00
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7390A80
	public static object op_Multiply(object rotation, object point) { }

	// RVA: 0x7390B24
	private static object IsEqualUsingDot(object dot) { }

	// RVA: 0x7390B3C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7390B70
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7390BA4
	public static object Dot(object a, object b) { }

	// RVA: 0x7390BC4
	public object SetLookRotation(object view) { }

	// RVA: 0x7390D5C
	public object SetLookRotation(object view, object up) { }

	// RVA: 0x7390E3C
	public static object Angle(object a, object b) { }

	// RVA: 0x7390EA8
	private static object Internal_MakePositive(object euler) { }

	// RVA: 0x7390F68
	public object get_eulerAngles() { }

	// RVA: 0x73911D8
	public object set_eulerAngles(object value) { }

	// RVA: 0x73912D8
	public static object Euler(object x, object y, object z) { }

	// RVA: 0x7391354
	public static object Euler(object euler) { }

	// RVA: 0x73913D0
	public object ToAngleAxis(object angle, object axis) { }

	// RVA: 0x73914D0
	public object SetFromToRotation(object fromDirection, object toDirection) { }

	// RVA: 0x73915B0
	public static object RotateTowards(object from, object to, object maxDegreesDelta) { }

	// RVA: 0x73916E8
	public static object Normalize(object q) { }

	// RVA: 0x73917D8
	public object Normalize() { }

	// RVA: 0x73919B0
	public object get_normalized() { }

	// RVA: 0x7391B80
	public override object GetHashCode() { }

	// RVA: 0x7391C54
	public override object Equals(object other) { }

	// RVA: 0x7391D54
	public object Equals(object other) { }

	// RVA: 0x7391E78
	public override object ToString() { }

	// RVA: 0x7391E9C
	public object ToString(object format) { }

	// RVA: 0x7391EB8
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7392108
	private static object .cctor() { }

	// RVA: 0x738FD08
	private static object FromToRotation_Injected(object fromDirection, object toDirection, object ret) { }

	// RVA: 0x738FDD4
	private static object Inverse_Injected(object rotation, object ret) { }

	// RVA: 0x738FEB4
	private static object Slerp_Injected(object a, object b, object t, object ret) { }

	// RVA: 0x738FFB0
	private static object SlerpUnclamped_Injected(object a, object b, object t, object ret) { }

	// RVA: 0x73900AC
	private static object Lerp_Injected(object a, object b, object t, object ret) { }

	// RVA: 0x73901A8
	private static object LerpUnclamped_Injected(object a, object b, object t, object ret) { }

	// RVA: 0x7390288
	private static object Internal_FromEulerRad_Injected(object euler, object ret) { }

	// RVA: 0x7390350
	private static object Internal_ToEulerRad_Injected(object rotation, object ret) { }

	// RVA: 0x739041C
	private static object Internal_ToAxisAngleRad_Injected(object q, object axis, object angle) { }

	// RVA: 0x73904F8
	private static object AngleAxis_Injected(object angle, object axis, object ret) { }

	// RVA: 0x73905DC
	private static object LookRotation_Injected(object forward, object upwards, object ret) { }

}

// Namespace: UnityEngine
public struct Mathf
{

	// Fields
	public static readonly object Epsilon; // 0x0

	// Methods

	// RVA: 0x739215C
	public static object ClosestPowerOfTwo(object value) { }

	// RVA: 0x737DE80
	public static object IsPowerOfTwo(object value) { }

	// RVA: 0x73921AC
	public static object NextPowerOfTwo(object value) { }

	// RVA: 0x7389730
	public static object GammaToLinearSpace(object value) { }

	// RVA: 0x7389954
	public static object LinearToGammaSpace(object value) { }

	// RVA: 0x73921FC
	public static object CorrelatedColorTemperatureToRGB(object kelvin) { }

	// RVA: 0x73922C4
	public static object PerlinNoise(object x, object y) { }

	// RVA: 0x7392320
	public static object Sin(object f) { }

	// RVA: 0x7392388
	public static object Cos(object f) { }

	// RVA: 0x73923F0
	public static object Tan(object f) { }

	// RVA: 0x7392458
	public static object Asin(object f) { }

	// RVA: 0x73924C0
	public static object Acos(object f) { }

	// RVA: 0x7392528
	public static object Atan(object f) { }

	// RVA: 0x7392590
	public static object Atan2(object y, object x) { }

	// RVA: 0x7392600
	public static object Sqrt(object f) { }

	// RVA: 0x7392680
	public static object Abs(object f) { }

	// RVA: 0x7392700
	public static object Abs(object value) { }

	// RVA: 0x7392788
	public static object Min(object a, object b) { }

	// RVA: 0x7392794
	public static object Min(object values) { }

	// RVA: 0x73927F4
	public static object Min(object a, object b) { }

	// RVA: 0x7392800
	public static object Min(object values) { }

	// RVA: 0x73928C4
	public static object Max(object a, object b) { }

	// RVA: 0x73928D0
	public static object Max(object values) { }

	// RVA: 0x7392930
	public static object Max(object a, object b) { }

	// RVA: 0x739293C
	public static object Max(object values) { }

	// RVA: 0x7392A00
	public static object Pow(object f, object p) { }

	// RVA: 0x7392A74
	public static object Exp(object power) { }

	// RVA: 0x7392ADC
	public static object Log(object f, object p) { }

	// RVA: 0x7392B50
	public static object Log(object f) { }

	// RVA: 0x7392BB8
	public static object Log10(object f) { }

	// RVA: 0x7392C20
	public static object Ceil(object f) { }

	// RVA: 0x7392CA0
	public static object Floor(object f) { }

	// RVA: 0x7392D20
	public static object Round(object f) { }

	// RVA: 0x7392E44
	public static object CeilToInt(object f) { }

	// RVA: 0x7392EBC
	public static object FloorToInt(object f) { }

	// RVA: 0x7392F34
	public static object RoundToInt(object f) { }

	// RVA: 0x7393044
	public static object Sign(object f) { }

	// RVA: 0x7393058
	public static object Clamp(object value, object min, object max) { }

	// RVA: 0x739306C
	public static object Clamp(object value, object min, object max) { }

	// RVA: 0x7393080
	public static object Clamp01(object value) { }

	// RVA: 0x739309C
	public static object Lerp(object a, object b, object t) { }

	// RVA: 0x73930C4
	public static object LerpUnclamped(object a, object b, object t) { }

	// RVA: 0x73930D4
	public static object LerpAngle(object a, object b, object t) { }

	// RVA: 0x7393140
	public static object MoveTowards(object current, object target, object maxDelta) { }

	// RVA: 0x7393164
	public static object MoveTowardsAngle(object current, object target, object maxDelta) { }

	// RVA: 0x73931E8
	public static object SmoothStep(object from, object to, object t) { }

	// RVA: 0x7393230
	public static object Gamma(object value, object absmax, object gamma) { }

	// RVA: 0x7393278
	public static object Approximately(object a, object b) { }

	// RVA: 0x7393310
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime, object maxSpeed) { }

	// RVA: 0x739350C
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime) { }

	// RVA: 0x739342C
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime, object maxSpeed, object deltaTime) { }

	// RVA: 0x739362C
	public static object SmoothDampAngle(object current, object target, object currentVelocity, object smoothTime, object maxSpeed) { }

	// RVA: 0x7393798
	public static object SmoothDampAngle(object current, object target, object currentVelocity, object smoothTime) { }

	// RVA: 0x7393908
	public static object SmoothDampAngle(object current, object target, object currentVelocity, object smoothTime, object maxSpeed, object deltaTime) { }

	// RVA: 0x7393A38
	public static object Repeat(object t, object length) { }

	// RVA: 0x7393A60
	public static object InverseLerp(object a, object b, object value) { }

	// RVA: 0x7393A98
	public static object DeltaAngle(object current, object target) { }

	// RVA: 0x7393AE8
	internal static object ClampToFloat(object value) { }

	// RVA: 0x7393B68
	internal static object ClampToInt(object value) { }

	// RVA: 0x7393B84
	internal static object ClampToUInt(object value) { }

	// RVA: 0x7393B9C
	internal static object GetNumberOfDecimalsForMinimumDifference(object minDifference) { }

	// RVA: 0x7393C2C
	internal static object RoundBasedOnMinimumDifference(object valueToRound, object minDifference) { }

	// RVA: 0x7393D1C
	internal static object DiscardLeastSignificantDecimal(object v) { }

	// RVA: 0x7393E98
	private static object .cctor() { }

	// RVA: 0x7392260
	private static object CorrelatedColorTemperatureToRGB_Injected(object kelvin, object ret) { }

}

// Namespace: UnityEngine
public struct Vector2
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	private static readonly object zeroVector; // 0x0
	private static readonly object oneVector; // 0xFFFFFFFFFFFFFFF8
	private static readonly object upVector; // 0x0
	private static readonly object downVector; // 0x8
	private static readonly object leftVector; // 0x10
	private static readonly object rightVector; // 0x18
	private static readonly object positiveInfinityVector; // 0x20
	private static readonly object negativeInfinityVector; // 0x28
	public const object kEpsilon;
	public const object kEpsilonNormalSqrt;

	// Properties
	public object Item { get; set; }
	public object normalized { get; }
	public object magnitude { get; }
	public object sqrMagnitude { get; }
	public static object zero { get; }
	public static object one { get; }
	public static object up { get; }
	public static object down { get; }
	public static object left { get; }
	public static object right { get; }
	public static object positiveInfinity { get; }
	public static object negativeInfinity { get; }

	// Methods

	// RVA: 0x7393F28
	public object get_Item(object index) { }

	// RVA: 0x739400C
	public object set_Item(object index, object value) { }

	// RVA: 0x73940F0
	public object .ctor(object x, object y) { }

	// RVA: 0x7394100
	public object Set(object newX, object newY) { }

	// RVA: 0x7394110
	public static object Lerp(object a, object b, object t) { }

	// RVA: 0x7394144
	public static object LerpUnclamped(object a, object b, object t) { }

	// RVA: 0x7394160
	public static object MoveTowards(object current, object target, object maxDistanceDelta) { }

	// RVA: 0x7394234
	public static object Scale(object a, object b) { }

	// RVA: 0x7394240
	public object Scale(object scale) { }

	// RVA: 0x7394268
	public object Normalize() { }

	// RVA: 0x7394430
	public object get_normalized() { }

	// RVA: 0x73945C8
	public override object ToString() { }

	// RVA: 0x73945EC
	public object ToString(object format) { }

	// RVA: 0x7394608
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x73947D8
	public override object GetHashCode() { }

	// RVA: 0x739484C
	public override object Equals(object other) { }

	// RVA: 0x73949B4
	public object Equals(object other) { }

	// RVA: 0x73949FC
	public static object Reflect(object inDirection, object inNormal) { }

	// RVA: 0x7394A24
	public static object Perpendicular(object inDirection) { }

	// RVA: 0x7394A34
	public static object Dot(object lhs, object rhs) { }

	// RVA: 0x7394A44
	public object get_magnitude() { }

	// RVA: 0x7394B2C
	public object get_sqrMagnitude() { }

	// RVA: 0x7394B4C
	public static object Angle(object from, object to) { }

	// RVA: 0x7394C50
	public static object SignedAngle(object from, object to) { }

	// RVA: 0x7394D6C
	public static object Distance(object a, object b) { }

	// RVA: 0x7394DF4
	public static object ClampMagnitude(object vector, object maxLength) { }

	// RVA: 0x7394ED0
	public static object SqrMagnitude(object a) { }

	// RVA: 0x7394EE0
	public object SqrMagnitude() { }

	// RVA: 0x7394F00
	public static object Min(object lhs, object rhs) { }

	// RVA: 0x7394F14
	public static object Max(object lhs, object rhs) { }

	// RVA: 0x7394F28
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime, object maxSpeed) { }

	// RVA: 0x7395140
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime) { }

	// RVA: 0x7394F9C
	public static object SmoothDamp(object current, object target, object currentVelocity, object smoothTime, object maxSpeed, object deltaTime) { }

	// RVA: 0x73951B4
	public static object op_Addition(object a, object b) { }

	// RVA: 0x73951C0
	public static object op_Subtraction(object a, object b) { }

	// RVA: 0x73951CC
	public static object op_Multiply(object a, object b) { }

	// RVA: 0x73951D8
	public static object op_Division(object a, object b) { }

	// RVA: 0x73951E4
	public static object op_UnaryNegation(object a) { }

	// RVA: 0x73951F0
	public static object op_Multiply(object a, object d) { }

	// RVA: 0x73951FC
	public static object op_Multiply(object d, object a) { }

	// RVA: 0x739520C
	public static object op_Division(object a, object d) { }

	// RVA: 0x7395218
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7395244
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7395270
	public static object op_Implicit(object v) { }

	// RVA: 0x7395274
	public static object op_Implicit(object v) { }

	// RVA: 0x739527C
	public static object get_zero() { }

	// RVA: 0x73952C8
	public static object get_one() { }

	// RVA: 0x7395314
	public static object get_up() { }

	// RVA: 0x7395360
	public static object get_down() { }

	// RVA: 0x73953AC
	public static object get_left() { }

	// RVA: 0x73953F8
	public static object get_right() { }

	// RVA: 0x7395444
	public static object get_positiveInfinity() { }

	// RVA: 0x7395490
	public static object get_negativeInfinity() { }

	// RVA: 0x73954DC
	private static object .cctor() { }

}

// Namespace: UnityEngine
public struct Vector2Int
{

	// Fields
	private object m_X; // 0xFFFFFFFFFFFFFFF8
	private object m_Y; // 0xFFFFFFFFFFFFFFFC
	private static readonly object s_Zero; // 0x0
	private static readonly object s_One; // 0xFFFFFFFFFFFFFFF8
	private static readonly object s_Up; // 0x0
	private static readonly object s_Down; // 0x8
	private static readonly object s_Left; // 0x10
	private static readonly object s_Right; // 0x18

	// Properties
	public object x { get; set; }
	public object y { get; set; }
	public static object zero { get; }
	public static object one { get; }

	// Methods

	// RVA: 0x7395590
	public object get_x() { }

	// RVA: 0x73955A0
	public object set_x(object value) { }

	// RVA: 0x73955B0
	public object get_y() { }

	// RVA: 0x73955C0
	public object set_y(object value) { }

	// RVA: 0x73955D0
	public object .ctor(object x, object y) { }

	// RVA: 0x73955E0
	public static object Max(object lhs, object rhs) { }

	// RVA: 0x7395600
	public static object op_Implicit(object v) { }

	// RVA: 0x7395610
	public static object FloorToInt(object v) { }

	// RVA: 0x73956F4
	public static object op_UnaryNegation(object v) { }

	// RVA: 0x7395704
	public static object op_Multiply(object a, object b) { }

	// RVA: 0x7395718
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7395724
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7395730
	public override object Equals(object other) { }

	// RVA: 0x7395898
	public object Equals(object other) { }

	// RVA: 0x73958E8
	public override object GetHashCode() { }

	// RVA: 0x7395990
	public override object ToString() { }

	// RVA: 0x73959B4
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7395B74
	public static object get_zero() { }

	// RVA: 0x7395BC0
	public static object get_one() { }

	// RVA: 0x7395C0C
	private static object .cctor() { }

}

// Namespace: UnityEngine
public struct Vector3Int
{

	// Fields
	private object m_X; // 0xFFFFFFFFFFFFFFF8
	private object m_Y; // 0xFFFFFFFFFFFFFFFC
	private object m_Z; // 0x0
	private static readonly object s_Zero; // 0x0
	private static readonly object s_One; // 0xFFFFFFFFFFFFFFFC
	private static readonly object s_Up; // 0x8
	private static readonly object s_Down; // 0x14
	private static readonly object s_Left; // 0x20
	private static readonly object s_Right; // 0x2C
	private static readonly object s_Forward; // 0x38
	private static readonly object s_Back; // 0x44

	// Properties
	public object x { get; set; }
	public object y { get; set; }
	public object z { get; set; }
	public static object zero { get; }

	// Methods

	// RVA: 0x7395C98
	public object get_x() { }

	// RVA: 0x7395CA8
	public object set_x(object value) { }

	// RVA: 0x7395CB8
	public object get_y() { }

	// RVA: 0x7395CC8
	public object set_y(object value) { }

	// RVA: 0x7395CD8
	public object get_z() { }

	// RVA: 0x7395CE8
	public object set_z(object value) { }

	// RVA: 0x7395CF8
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x7395D10
	public static object op_Implicit(object v) { }

	// RVA: 0x7395D24
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7395D44
	public override object Equals(object other) { }

	// RVA: 0x7395EC4
	public object Equals(object other) { }

	// RVA: 0x7395F24
	public override object GetHashCode() { }

	// RVA: 0x739602C
	public override object ToString() { }

	// RVA: 0x7396050
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7396258
	public static object get_zero() { }

	// RVA: 0x73962A8
	private static object .cctor() { }

}

// Namespace: UnityEngine
public struct Vector4
{

	// Fields
	public const object kEpsilon;
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public object w; // 0x4
	private static readonly object zeroVector; // 0x0
	private static readonly object oneVector; // 0x0
	private static readonly object positiveInfinityVector; // 0x10
	private static readonly object negativeInfinityVector; // 0x20

	// Properties
	public object Item { get; set; }
	public object normalized { get; }
	public object magnitude { get; }
	public object sqrMagnitude { get; }
	public static object zero { get; }
	public static object one { get; }
	public static object positiveInfinity { get; }
	public static object negativeInfinity { get; }

	// Methods

	// RVA: 0x7396328
	public object get_Item(object index) { }

	// RVA: 0x7396464
	public object set_Item(object index, object value) { }

	// RVA: 0x73965A0
	public object .ctor(object x, object y, object z, object w) { }

	// RVA: 0x73965B8
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x73965D8
	public object .ctor(object x, object y) { }

	// RVA: 0x73965F0
	public object Set(object newX, object newY, object newZ, object newW) { }

	// RVA: 0x7396608
	public static object Lerp(object a, object b, object t) { }

	// RVA: 0x7396658
	public static object LerpUnclamped(object a, object b, object t) { }

	// RVA: 0x7396690
	public static object MoveTowards(object current, object target, object maxDistanceDelta) { }

	// RVA: 0x73967F0
	public static object Scale(object a, object b) { }

	// RVA: 0x7396804
	public object Scale(object scale) { }

	// RVA: 0x739683C
	public override object GetHashCode() { }

	// RVA: 0x7396910
	public override object Equals(object other) { }

	// RVA: 0x7396AB8
	public object Equals(object other) { }

	// RVA: 0x7396B30
	public static object Normalize(object a) { }

	// RVA: 0x7396C30
	public object Normalize() { }

	// RVA: 0x7396E20
	public object get_normalized() { }

	// RVA: 0x7397010
	public static object Dot(object a, object b) { }

	// RVA: 0x7397030
	public static object Project(object a, object b) { }

	// RVA: 0x7397080
	public static object Distance(object a, object b) { }

	// RVA: 0x7397140
	public static object Magnitude(object a) { }

	// RVA: 0x73971D0
	public object get_magnitude() { }

	// RVA: 0x73972E0
	public object get_sqrMagnitude() { }

	// RVA: 0x7397328
	public static object Min(object lhs, object rhs) { }

	// RVA: 0x739734C
	public static object Max(object lhs, object rhs) { }

	// RVA: 0x7397370
	public static object get_zero() { }

	// RVA: 0x73973C0
	public static object get_one() { }

	// RVA: 0x7397410
	public static object get_positiveInfinity() { }

	// RVA: 0x7397460
	public static object get_negativeInfinity() { }

	// RVA: 0x73974B0
	public static object op_Addition(object a, object b) { }

	// RVA: 0x73974C4
	public static object op_Subtraction(object a, object b) { }

	// RVA: 0x73974D8
	public static object op_UnaryNegation(object a) { }

	// RVA: 0x73974EC
	public static object op_Multiply(object a, object d) { }

	// RVA: 0x7397500
	public static object op_Multiply(object d, object a) { }

	// RVA: 0x7397518
	public static object op_Division(object a, object d) { }

	// RVA: 0x739752C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7397570
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x73975B4
	public static object op_Implicit(object v) { }

	// RVA: 0x73975BC
	public static object op_Implicit(object v) { }

	// RVA: 0x73975C0
	public static object op_Implicit(object v) { }

	// RVA: 0x73975CC
	public static object op_Implicit(object v) { }

	// RVA: 0x73975D0
	public override object ToString() { }

	// RVA: 0x73975F4
	public object ToString(object format) { }

	// RVA: 0x7397610
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7397860
	public static object SqrMagnitude(object a) { }

	// RVA: 0x7397880
	public object SqrMagnitude() { }

	// RVA: 0x73978C8
	private static object .cctor() { }

}

// Namespace: UnityEngine
public struct TypeDispatchData
{

	// Fields
	public object changed; // 0xFFFFFFFFFFFFFFF8
	public object changedID; // 0x0
	public object destroyedID; // 0x10
	public object changeReasons; // 0x20
	public object changeReasonDetailMsgs; // 0x30
	public object label; // 0x38
	public object changedIDDynamicArrayPtr; // 0x40
	public object destroyedIDDynamicArrayPtr; // 0x48
	public object changeReasonsDynamicArrayPtr; // 0x50

	// Methods

	// RVA: 0x7397964
	public object Dispose() { }

}

// Namespace: UnityEngine
public struct TransformDispatchData
{

	// Fields
	public object transformedID; // 0xFFFFFFFFFFFFFFF8
	public object parentID; // 0x8
	public object localToWorldMatrices; // 0x18
	public object positions; // 0x28
	public object rotations; // 0x38
	public object scales; // 0x48
	public object label; // 0x58
	public object dynamicArrayPtrStruct; // 0x60

	// Methods

	// RVA: 0x7397AFC
	public object Dispose() { }

}

// Namespace: UnityEngine
public struct SkinnedMeshRendererTransformDispatchData
{

	// Fields
	public object rendererID; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x7397C9C
	public object Dispose() { }

}

// Namespace: UnityEngine
public enum ObjectChangeReason
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Others;
	public const object HistoricalChanges;
	public const object SkinnedMeshRenderer_BlendShapeWeights;
	public const object MaterialPropertyBlock;
	public const object EveryThing;
}

// Namespace: UnityEngine
public enum ObjectChangeReasonLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ReasonCode;
	public const object ReasonCodeAndDetailMsg;
}

// Namespace: 
public sealed class DispatchAction
{

	// Methods

	// RVA: 0x7399A58
	public object .ctor(object object, object method) { }

	// RVA: 0x7399DFC
	public virtual object Invoke(object data, object allocator) { }

}

// Namespace: 
public sealed class TransformTypeDispatchAction
{

	// Methods

	// RVA: 0x7399AF0
	public object .ctor(object object, object method) { }

	// RVA: 0x7399F4C
	public virtual object Invoke(object data) { }

}

// Namespace: 
public sealed class TransformComponentDispatchAction
{

	// Methods

	// RVA: 0x7399B88
	public object .ctor(object object, object method) { }

	// RVA: 0x739A274
	public virtual object Invoke(object data) { }

}

// Namespace: 
public sealed class SkinnedMeshRendererDispatchAction
{

	// Methods

	// RVA: 0x7399CA4
	public object .ctor(object object, object method) { }

	// RVA: 0x739A320
	public virtual object Invoke(object data, object allocator) { }

}

// Namespace: 
public enum TransformTrackingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object GlobalTRS;
	public const object LocalTRS;
	public const object Hierarchy;
}

// Namespace: 
public enum TypeTrackingFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SceneObjects;
	public const object Assets;
	public const object EditorOnlyObjects;
	public const object Default;
	public const object All;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x739A334
	private static object .cctor() { }

	// RVA: 0x739A394
	public object .ctor() { }

	// RVA: 0x739A39C
	internal object <.cctor>b__88_0(object changed, object changedID, object destroyedID, object changedIDDynamicArrayPtr, object destroyedIDDynamicArrayPtr, object changedCount, object destroyedCount, object changeReasons, object changeReasonsDynamicArrayPtr, object changeReasonDetailMsgs, object callback, object allocator) { }

	// RVA: 0x739A4E8
	internal object <.cctor>b__88_1(object transformed, object parents, object localToWorldMatrices, object positions, object rotations, object scales, object count, object dynamicArrayPtr, object callback, object allocator) { }

	// RVA: 0x739A6FC
	internal object <.cctor>b__88_2(object rendererID, object count, object callback, object allocator) { }

}

// Namespace: UnityEngine
public sealed class ObjectDispatcher
{

	// Fields
	public static object dispatchData; // 0x0
	private static object updateDispatchDataDelegate; // 0x60
	public static object transformDispatchData; // 0x68
	private static object updateTransformDispatchDataDelegate; // 0xD8
	public static object transformComponentDispatchData; // 0xE0
	private static object updateTransformComponentDispatchDataDelegate; // 0xE8
	public static object SkinnedMeshRendererDispatchData; // 0xF0
	private static object updateSkinnedMeshRendererDispatchDataDelegate; // 0x100
	private object m_Ptr; // 0x8
	private static object s_TypeDispatch; // 0x108
	private static object s_TransformDispatch; // 0x110
	private static object s_SkinnedMeshRendererBonesTransformDispatch; // 0x118

	// Properties
	public object valid { get; }

	// Methods

	// RVA: 0x7397D48
	public object get_valid() { }

	// RVA: 0x7397D58
	public object .ctor() { }

	// RVA: 0x7397E4C
	protected override object Finalize() { }

	// RVA: 0x7398034
	public object Dispose() { }

	// RVA: 0x7397F60
	private object Dispose(object disposing) { }

	// RVA: 0x7398198
	private object ValidateSystemHandleAndThrow() { }

	// RVA: 0x739820C
	private object ValidateTypeAndThrow(object type) { }

	// RVA: 0x7398338
	private object ValidateComponentTypeAndThrow(object type) { }

	// RVA: 0x7398464
	public object DispatchTypeChangesAndClear(object type, object callback, object allocator, object sortByInstanceID, object noScriptingArray) { }

	// RVA: 0x7398650
	public object DispatchTransformChangesAndClear(object type, object trackingType, object callback, object allocator, object filterDisableObject) { }

	// RVA: 0x739883C
	public static object UpdateDispatchData(object data, object allocator) { }

	// RVA: 0x73988F4
	public static object UpdateTransformDispatchData(object data) { }

	// RVA: 0x73989B0
	public static object UpdateSkinnedmeshrendererTransformDispatchData(object data, object allocator) { }

	// RVA: 0x7398A64
	public static object UpdateTransformComponentDispatchData(object instances) { }

	// RVA: 0x7398AF0
	public object GetTypeChangesAndClear(object type, object allocator, object sortByInstanceID, object noScriptingArray) { }

	// RVA: 0x7398BB4
	public object GetTransformChangesAndClear(object type, object trackingType, object allocator, object filterDisableObject) { }

	// RVA: 0x7398C8C
	public object EnableTypeTracking(object reasonLevel, object typeTrackingMask, object types) { }

	// RVA: 0x7398E74
	public object DisableTypeTracking(object types) { }

	// RVA: 0x7399034
	public object EnableTransformTracking(object trackingType, object types) { }

	// RVA: 0x7399204
	public object DisableTransformTracking(object trackingType, object types) { }

	// RVA: -1
	public object GetTypeChangesAndClear(object allocator, object sortByInstanceID, object noScriptingArray) { }

	// RVA: -1
	public object GetTransformChangesAndClear(object trackingType, object allocator, object filterDisableObject) { }

	// RVA: -1
	public object EnableTypeTracking(object typeTrackingMask, object reasonLevel) { }

	// RVA: -1
	public object DisableTypeTracking() { }

	// RVA: 0x73993D4
	public object SetTypeTrackingReasonLevel(object reasonLevel, object types) { }

	// RVA: 0x73995A4
	public object SetTypeTrackingReasonLevel(object reasonLevel, object type) { }

	// RVA: -1
	public object SetTypeTrackingReasonLevel(object reasonLevel) { }

	// RVA: -1
	public object EnableTransformTracking(object trackingType) { }

	// RVA: -1
	public object DisableTransformTracking(object trackingType) { }

	// RVA: 0x7397E0C
	private static object CreateDispatchSystemHandle() { }

	// RVA: 0x7398148
	private static object DestroyDispatchSystemHandle(object ptr) { }

	// RVA: 0x7398DF4
	private static object EnableTypeTracking(object ptr, object type, object typeTrackingMask, object reasonLevel) { }

	// RVA: 0x7398FD0
	private static object DisableTypeTracking(object ptr, object type) { }

	// RVA: 0x7399538
	private static object SetTypeTrackingReasonLevel(object ptr, object type, object reasonLevel) { }

	// RVA: 0x7399198
	private static object EnableTransformTracking(object ptr, object type, object trackingType) { }

	// RVA: 0x7399368
	private static object DisableTransformTracking(object ptr, object type, object trackingType) { }

	// RVA: 0x73985AC
	private static object DispatchTypeChangesAndClear(object ptr, object type, object callback, object sortByInstanceID, object noScriptingArray, object param, object allocator) { }

	// RVA: 0x7398798
	private static object DispatchTransformDataChangesAndClear(object ptr, object type, object trackingType, object callback, object param, object allocator, object filterDisableObject) { }

	// RVA: 0x7397A74
	public static object DeleteTypeDispatchDataDynamicArray(object changed, object destroyed, object changeReasons, object allocator) { }

	// RVA: 0x7397C30
	public static object DeleteTransformDispatchDataDynamicArray(object dynamicArrayPtr, object allocator) { }

	// RVA: 0x73996AC
	private static object .cctor() { }

}

// Namespace: UnityEngine
internal class NumericFieldDraggerUtility
{

	// Fields
	private static object s_UseYSign; // 0x0

	// Methods

	// RVA: 0x739A7A0
	internal static object Acceleration(object shiftPressed, object altPressed) { }

	// RVA: 0x739A7C4
	internal static object NiceDelta(object deviceDelta, object acceleration) { }

	// RVA: 0x739A91C
	internal static object CalculateFloatDragSensitivity(object value) { }

	// RVA: 0x739A9C4
	internal static object CalculateFloatDragSensitivity(object value, object minValue, object maxValue) { }

	// RVA: 0x739AA6C
	internal static object CalculateIntDragSensitivity(object value) { }

	// RVA: 0x739AB8C
	internal static object CalculateIntDragSensitivity(object value) { }

	// RVA: 0x739AB0C
	private static object CalculateIntDragSensitivity(object value) { }

	// RVA: 0x739AC20
	internal static object CalculateIntDragSensitivity(object value, object minValue, object maxValue) { }

}

// Namespace: UnityEngine
internal interface IPlayerEditorConnectionNative
{

	// Methods

	// RVA: -1
	public abstract object Initialize() { }

	// RVA: -1
	public abstract object DisconnectAll() { }

	// RVA: -1
	public abstract object SendMessage(object messageId, object data, object playerId) { }

	// RVA: -1
	public abstract object TrySendMessage(object messageId, object data, object playerId) { }

	// RVA: -1
	public abstract object Poll() { }

	// RVA: -1
	public abstract object RegisterInternal(object messageId) { }

	// RVA: -1
	public abstract object UnregisterInternal(object messageId) { }

	// RVA: -1
	public abstract object IsConnected() { }

}

// Namespace: UnityEngine
internal class PlayerConnectionInternal
{

	// Methods

	// RVA: 0x739ACC8
	private object UnityEngine.IPlayerEditorConnectionNative.SendMessage(object messageId, object data, object playerId) { }

	// RVA: 0x739AE64
	private object UnityEngine.IPlayerEditorConnectionNative.TrySendMessage(object messageId, object data, object playerId) { }

	// RVA: 0x739B000
	private object UnityEngine.IPlayerEditorConnectionNative.Poll() { }

	// RVA: 0x739B080
	private object UnityEngine.IPlayerEditorConnectionNative.RegisterInternal(object messageId) { }

	// RVA: 0x739B170
	private object UnityEngine.IPlayerEditorConnectionNative.UnregisterInternal(object messageId) { }

	// RVA: 0x739B260
	private object UnityEngine.IPlayerEditorConnectionNative.Initialize() { }

	// RVA: 0x739B2E0
	private object UnityEngine.IPlayerEditorConnectionNative.IsConnected() { }

	// RVA: 0x739B360
	private object UnityEngine.IPlayerEditorConnectionNative.DisconnectAll() { }

	// RVA: 0x739B320
	private static object IsConnected() { }

	// RVA: 0x739B2A0
	private static object Initialize() { }

	// RVA: 0x739B120
	private static object RegisterInternal(object messageId) { }

	// RVA: 0x739B210
	private static object UnregisterInternal(object messageId) { }

	// RVA: 0x739ADF8
	private static object SendMessage(object messageId, object data, object playerId) { }

	// RVA: 0x739AF94
	private static object TrySendMessage(object messageId, object data, object playerId) { }

	// RVA: 0x739B040
	private static object PollInternal() { }

	// RVA: 0x739B3A0
	private static object DisconnectAll() { }

	// RVA: 0x739B3E0
	public object .ctor() { }

}

// Namespace: UnityEngine
public class PlayerPrefsException
{

	// Methods

	// RVA: 0x739B3E8
	public object .ctor(object error) { }

}

// Namespace: UnityEngine
public class PlayerPrefs
{

	// Methods

	// RVA: 0x739B454
	private static object TrySetInt(object key, object value) { }

	// RVA: 0x739B4B8
	private static object TrySetFloat(object key, object value) { }

	// RVA: 0x739B51C
	private static object TrySetSetString(object key, object value) { }

	// RVA: 0x739B580
	public static object SetInt(object key, object value) { }

	// RVA: 0x739B620
	public static object GetInt(object key, object defaultValue) { }

	// RVA: 0x739B684
	public static object GetInt(object key) { }

	// RVA: 0x739B6DC
	public static object SetFloat(object key, object value) { }

	// RVA: 0x739B77C
	public static object GetFloat(object key, object defaultValue) { }

	// RVA: 0x739B7E0
	public static object GetFloat(object key) { }

	// RVA: 0x739B838
	public static object SetString(object key, object value) { }

	// RVA: 0x739B8D8
	public static object GetString(object key, object defaultValue) { }

	// RVA: 0x739B93C
	public static object GetString(object key) { }

	// RVA: 0x739B9DC
	public static object HasKey(object key) { }

	// RVA: 0x739BA2C
	public static object DeleteKey(object key) { }

	// RVA: 0x739BA7C
	public static object DeleteAll() { }

	// RVA: 0x739BABC
	public static object Save() { }

}

// Namespace: UnityEngine
public abstract class PropertyAttribute
{

	// Methods

	// RVA: 0x739BAFC
	protected object .ctor() { }

}

// Namespace: UnityEngine
public class InspectorNameAttribute
{

	// Fields
	public readonly object displayName; // 0x8

	// Methods

	// RVA: 0x739BB04
	public object .ctor(object displayName) { }

}

// Namespace: UnityEngine
public class TooltipAttribute
{

	// Fields
	public readonly object tooltip; // 0x8

	// Methods

	// RVA: 0x739BB30
	public object .ctor(object tooltip) { }

}

// Namespace: UnityEngine
public class SpaceAttribute
{

	// Fields
	public readonly object height; // 0x8

	// Methods

	// RVA: 0x739BB5C
	public object .ctor() { }

	// RVA: 0x739BB88
	public object .ctor(object height) { }

}

// Namespace: UnityEngine
public class HeaderAttribute
{

	// Fields
	public readonly object header; // 0x8

	// Methods

	// RVA: 0x739BBBC
	public object .ctor(object header) { }

}

// Namespace: UnityEngine
public sealed class RangeAttribute
{

	// Fields
	public readonly object min; // 0x8
	public readonly object max; // 0xC

	// Methods

	// RVA: 0x739BBE8
	public object .ctor(object min, object max) { }

}

// Namespace: UnityEngine
public sealed class MinAttribute
{

	// Fields
	public readonly object min; // 0x8

	// Methods

	// RVA: 0x739BC20
	public object .ctor(object min) { }

}

// Namespace: UnityEngine
public sealed class MultilineAttribute
{

	// Fields
	public readonly object lines; // 0x8

	// Methods

	// RVA: 0x739BC54
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class TextAreaAttribute
{

	// Fields
	public readonly object minLines; // 0x8
	public readonly object maxLines; // 0xC

	// Methods

	// RVA: 0x739BC80
	public object .ctor() { }

	// RVA: 0x739BCAC
	public object .ctor(object minLines, object maxLines) { }

}

// Namespace: UnityEngine
public sealed class ColorUsageAttribute
{

	// Fields
	public readonly object showAlpha; // 0x8
	public readonly object hdr; // 0x9
	public readonly object minBrightness; // 0xC
	public readonly object maxBrightness; // 0x10
	public readonly object minExposureValue; // 0x14
	public readonly object maxExposureValue; // 0x18

	// Methods

	// RVA: 0x739BCE4
	public object .ctor(object showAlpha, object hdr) { }

	// RVA: 0x739BD34
	public object .ctor(object showAlpha, object hdr, object minBrightness, object maxBrightness, object minExposureValue, object maxExposureValue) { }

}

// Namespace: UnityEngine
internal class PropertyNameUtils
{

	// Methods

	// RVA: 0x739BDAC
	public static object PropertyNameFromString(object name) { }

	// RVA: 0x739BE08
	private static object PropertyNameFromString_Injected(object name, object ret) { }

}

// Namespace: UnityEngine
public struct PropertyName
{

	// Fields
	internal object id; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x739BE6C
	public object .ctor(object name) { }

	// RVA: 0x739BED4
	public object .ctor(object other) { }

	// RVA: 0x739BF4C
	public static object IsNullOrEmpty(object prop) { }

	// RVA: 0x739BF58
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x739BF64
	public override object GetHashCode() { }

	// RVA: 0x739BF74
	public override object Equals(object other) { }

	// RVA: 0x739C018
	public object Equals(object other) { }

	// RVA: 0x739C0DC
	public static object op_Implicit(object name) { }

	// RVA: 0x739C138
	public override object ToString() { }

}

// Namespace: UnityEngine
public static class Random
{

	// Properties
	public static object value { get; }
	public static object insideUnitCircle { get; }
	public static object onUnitSphere { get; }

	// Methods

	// RVA: 0x739C250
	public static object InitState(object seed) { }

	// RVA: 0x739C2A0
	public static object Range(object minInclusive, object maxInclusive) { }

	// RVA: 0x739C2FC
	public static object Range(object minInclusive, object maxExclusive) { }

	// RVA: 0x739C360
	private static object RandomRangeInt(object minInclusive, object maxExclusive) { }

	// RVA: 0x739C3C4
	public static object get_value() { }

	// RVA: 0x739C404
	private static object GetRandomUnitCircle(object output) { }

	// RVA: 0x739C454
	public static object get_insideUnitCircle() { }

	// RVA: 0x739C4A4
	public static object get_onUnitSphere() { }

	// RVA: 0x739C4FC
	private static object get_onUnitSphere_Injected(object ret) { }

}

// Namespace: UnityEngine
public class CloneObjectRequest
{
}

// Namespace: UnityEngine
public class ResourceRequest
{

	// Fields
	internal object m_Path; // 0x18
	internal object m_Type; // 0x20

	// Properties
	public object asset { get; }

	// Methods

	// RVA: 0x739C624
	protected virtual object GetResult() { }

	// RVA: 0x739C7A0
	public object get_asset() { }

	// RVA: 0x739C7E0
	public object .ctor() { }

}

// Namespace: UnityEngine
internal static class ResourcesAPIInternal
{

	// Methods

	// RVA: 0x739C7F0
	public static object FindObjectsOfTypeAll(object type) { }

	// RVA: 0x739C840
	public static object FindShaderByName(object name) { }

	// RVA: 0x739C890
	public static object Load(object path, object systemTypeInstance) { }

	// RVA: 0x739C8F4
	public static object LoadAll(object path, object systemTypeInstance) { }

	// RVA: 0x739C958
	internal static object LoadAsyncInternal(object path, object type) { }

	// RVA: 0x739C9BC
	public static object UnloadAsset(object assetToUnload) { }

}

// Namespace: UnityEngine
public class ResourcesAPI
{

	// Fields
	private static object s_DefaultAPI; // 0x0
	private static object <overrideAPI>k__BackingField; // 0x8

	// Properties
	internal static object ActiveAPI { get; }
	public static object overrideAPI { get; }

	// Methods

	// RVA: 0x739CA0C
	internal static object get_ActiveAPI() { }

	// RVA: 0x739CB0C
	public static object get_overrideAPI() { }

	// RVA: 0x739CB88
	protected internal object .ctor() { }

	// RVA: 0x739CB90
	protected internal virtual object FindObjectsOfTypeAll(object systemTypeInstance) { }

	// RVA: 0x739CBE0
	protected internal virtual object FindShaderByName(object name) { }

	// RVA: 0x739CC30
	protected internal virtual object Load(object path, object systemTypeInstance) { }

	// RVA: 0x739CC98
	protected internal virtual object LoadAll(object path, object systemTypeInstance) { }

	// RVA: 0x739CD00
	protected internal virtual object LoadAsync(object path, object systemTypeInstance) { }

	// RVA: 0x739CD68
	protected internal virtual object UnloadAsset(object assetToUnload) { }

	// RVA: 0x739CDB8
	private static object .cctor() { }

}

// Namespace: UnityEngine
public sealed class Resources
{

	// Fields
	private static object <LogErrorWhenUsingUnityResLoad>k__BackingField; // 0x0

	// Properties
	public static object LogErrorWhenUsingUnityResLoad { get; }

	// Methods

	// RVA: 0x739CE18
	public static object get_LogErrorWhenUsingUnityResLoad() { }

	// RVA: -1
	internal static object ConvertObjects(object rawObjects) { }

	// RVA: 0x739CE64
	internal static object TryLogErrorWhenUsingUnityResLoad() { }

	// RVA: 0x739CF54
	public static object FindObjectsOfTypeAll(object type) { }

	// RVA: -1
	public static object FindObjectsOfTypeAll() { }

	// RVA: 0x739D004
	public static object Load(object path) { }

	// RVA: -1
	public static object Load(object path) { }

	// RVA: 0x739C630
	public static object Load(object path, object systemTypeInstance) { }

	// RVA: 0x739D08C
	public static object LoadAsync(object path) { }

	// RVA: 0x739D114
	public static object LoadAsync(object path, object type) { }

	// RVA: 0x739D284
	public static object LoadAll(object path, object systemTypeInstance) { }

	// RVA: 0x739D3F4
	public static object GetBuiltinResource(object type, object path) { }

	// RVA: -1
	public static object GetBuiltinResource(object path) { }

	// RVA: 0x739D458
	public static object UnloadAsset(object assetToUnload) { }

	// RVA: 0x739D508
	public static object UnloadUnusedAssets() { }

	// RVA: 0x739D548
	public static object InstanceIDToObject(object instanceID) { }

	// RVA: 0x739D598
	private static object InstanceIDToObjectList(object instanceIDs, object instanceCount, object objects) { }

	// RVA: 0x739D604
	public static object InstanceIDToObjectList(object instanceIDs, object objects) { }

}

// Namespace: UnityEngine
public class AsyncOperation
{

	// Fields
	internal object m_Ptr; // 0x8
	private object m_completeCallback; // 0x10

	// Properties
	public object isDone { get; }

	// Methods

	// RVA: 0x739D808
	private static object InternalDestroy(object ptr) { }

	// RVA: 0x739D858
	public object get_isDone() { }

	// RVA: 0x739D8A8
	protected override object Finalize() { }

	// RVA: 0x739D960
	internal object InvokeCompletionEvent() { }

	// RVA: 0x739D99C
	public object add_completed(object value) { }

	// RVA: 0x739DACC
	public object remove_completed(object value) { }

	// RVA: 0x739C7E8
	public object .ctor() { }

}

// Namespace: UnityEngine
internal class AttributeHelperEngine
{

	// Fields
	public static object _disallowMultipleComponentArray; // 0x0
	public static object _executeInEditModeArray; // 0x8
	public static object _requireComponentArray; // 0x10

	// Methods

	// RVA: 0x739DB90
	private static object GetParentTypeDisallowingMultipleInclusion(object type) { }

	// RVA: 0x739DCE8
	private static object GetRequiredComponents(object klass) { }

	// RVA: 0x739E3EC
	private static object GetExecuteMode(object klass) { }

	// RVA: 0x739E580
	private static object CheckIsEditorScript(object klass) { }

	// RVA: 0x739E6D4
	private static object GetDefaultExecutionOrderFor(object klass) { }

	// RVA: -1
	private static object GetCustomAttributeOfType(object klass) { }

	// RVA: 0x739E788
	private static object .cctor() { }

}

// Namespace: UnityEngine
public sealed class DisallowMultipleComponent
{

	// Methods

	// RVA: 0x739E85C
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class RequireComponent
{

	// Fields
	public object m_Type0; // 0x8
	public object m_Type1; // 0x10
	public object m_Type2; // 0x18

	// Methods

	// RVA: 0x739E864
	public object .ctor(object requiredComponent) { }

	// RVA: 0x739E890
	public object .ctor(object requiredComponent, object requiredComponent2) { }

}

// Namespace: UnityEngine
public sealed class AddComponentMenu
{

	// Fields
	private object m_AddComponentMenu; // 0x8
	private object m_Ordering; // 0x10

	// Methods

	// RVA: 0x739E8C8
	public object .ctor(object menuName) { }

	// RVA: 0x739E8F8
	public object .ctor(object menuName, object order) { }

}

// Namespace: UnityEngine
public sealed class CreateAssetMenuAttribute
{

	// Fields
	private object <menuName>k__BackingField; // 0x8
	private object <fileName>k__BackingField; // 0x10
	private object <order>k__BackingField; // 0x18

	// Properties
	public object menuName { set; }
	public object fileName { set; }
	public object order { set; }

	// Methods

	// RVA: 0x739E934
	public object set_menuName(object value) { }

	// RVA: 0x739E93C
	public object set_fileName(object value) { }

	// RVA: 0x739E944
	public object set_order(object value) { }

	// RVA: 0x739E94C
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class ContextMenu
{

	// Fields
	public readonly object menuItem; // 0x8
	public readonly object validate; // 0x10
	public readonly object priority; // 0x14

	// Methods

	// RVA: 0x739E954
	public object .ctor(object itemName) { }

	// RVA: 0x739E990
	public object .ctor(object itemName, object isValidateFunction) { }

	// RVA: 0x739E9D8
	public object .ctor(object itemName, object isValidateFunction, object priority) { }

}

// Namespace: UnityEngine
public sealed class ExecuteInEditMode
{

	// Methods

	// RVA: 0x739EA1C
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class ExecuteAlways
{

	// Methods

	// RVA: 0x739EA24
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class HideInInspector
{

	// Methods

	// RVA: 0x739EA2C
	public object .ctor() { }

}

// Namespace: UnityEngine
public class HelpURLAttribute
{

	// Fields
	internal readonly object m_Url; // 0x8
	internal readonly object m_Dispatcher; // 0x10
	internal readonly object m_DispatchingFieldName; // 0x18

	// Methods

	// RVA: 0x739EA34
	public object .ctor(object url) { }

}

// Namespace: UnityEngine
public class DefaultExecutionOrder
{

	// Fields
	private object m_Order; // 0x8

	// Properties
	public object order { get; }

	// Methods

	// RVA: 0x739EAA0
	public object .ctor(object order) { }

	// RVA: 0x739E780
	public object get_order() { }

}

// Namespace: UnityEngine
public class AssemblyIsEditorAssembly
{
}

// Namespace: UnityEngine
public class ExcludeFromPresetAttribute
{

	// Methods

	// RVA: 0x739EACC
	public object .ctor() { }

}

// Namespace: UnityEngine
public class Behaviour
{

	// Properties
	public object enabled { get; set; }
	public object isActiveAndEnabled { get; }

	// Methods

	// RVA: 0x739EAD4
	public object get_enabled() { }

	// RVA: 0x739EB24
	public object set_enabled(object value) { }

	// RVA: 0x739EB88
	public object get_isActiveAndEnabled() { }

	// RVA: 0x739EBD8
	public object .ctor() { }

}

// Namespace: UnityEngine
internal struct CastHelper<T0>
{

	// Fields
	public object t; // 0x0
	public object onePointerFurtherThanT; // 0x0
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__2_0; // 0x8

	// Methods

	// RVA: 0x739EF9C
	private static object .cctor() { }

	// RVA: 0x739EFFC
	public object .ctor() { }

	// RVA: 0x739F004
	internal object <InitAssemblyRedirections>b__2_0(object _, object args) { }

}

// Namespace: UnityEngine
internal static class ClassLibraryInitializer
{

	// Methods

	// RVA: 0x739ECE8
	private static object Init() { }

	// RVA: 0x739ECF0
	private static object InitStdErrWithHandle(object fileHandle) { }

	// RVA: 0x739EE7C
	private static object InitAssemblyRedirections() { }

}

// Namespace: UnityEngine
internal struct AssemblyVersion
{

	// Fields
	public object major; // 0xFFFFFFFFFFFFFFF8
	public object minor; // 0xFFFFFFFFFFFFFFFA
	public object build; // 0xFFFFFFFFFFFFFFFC
	public object revision; // 0xFFFFFFFFFFFFFFFE

	// Methods

	// RVA: 0x739F13C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x739F150
	public override object ToString() { }

	// RVA: 0x739F310
	public override object Equals(object other) { }

	// RVA: 0x739F4B8
	public override object GetHashCode() { }

}

// Namespace: UnityEngine
internal struct AssemblyFullName
{

	// Fields
	public object Name; // 0xFFFFFFFFFFFFFFF8
	public object Version; // 0x0
	public object PublicKeyToken; // 0x8
	public object Culture; // 0x10

	// Methods

	// RVA: 0x739F6DC
	public override object Equals(object other) { }

	// RVA: 0x739F7C4
	public override object GetHashCode() { }

	// RVA: 0x739F8EC
	public override object ToString() { }

}

// Namespace: UnityEngine
public class Component
{

	// Properties
	public object transform { get; }
	public object gameObject { get; }
	public object tag { get; set; }

	// Methods

	// RVA: 0x739FAA8
	public object get_transform() { }

	// RVA: 0x739FAF8
	public object get_gameObject() { }

	// RVA: 0x739FB48
	public object GetComponent(object type) { }

	// RVA: 0x739FC54
	internal object GetComponentFastPath(object type, object oneFurtherThanResultValue) { }

	// RVA: -1
	public object GetComponent() { }

	// RVA: 0x739FCC0
	public object TryGetComponent(object type, object component) { }

	// RVA: -1
	public object TryGetComponent(object component) { }

	// RVA: 0x739FE80
	public object GetComponent(object type) { }

	// RVA: 0x739FEE4
	public object GetComponentInChildren(object t, object includeInactive) { }

	// RVA: 0x73A0004
	public object GetComponentInChildren(object t) { }

	// RVA: -1
	public object GetComponentInChildren(object includeInactive) { }

	// RVA: -1
	public object GetComponentInChildren() { }

	// RVA: 0x73A00B4
	public object GetComponentsInChildren(object t, object includeInactive) { }

	// RVA: 0x73A0264
	public object GetComponentsInChildren(object t) { }

	// RVA: -1
	public object GetComponentsInChildren(object includeInactive) { }

	// RVA: -1
	public object GetComponentsInChildren(object includeInactive, object result) { }

	// RVA: -1
	public object GetComponentsInChildren() { }

	// RVA: -1
	public object GetComponentsInChildren(object results) { }

	// RVA: 0x73A0358
	public object GetComponentInParent(object t, object includeInactive) { }

	// RVA: 0x73A0478
	public object GetComponentInParent(object t) { }

	// RVA: -1
	public object GetComponentInParent(object includeInactive) { }

	// RVA: -1
	public object GetComponentInParent() { }

	// RVA: 0x73A0528
	public object GetComponentsInParent(object t, object includeInactive) { }

	// RVA: 0x73A06D8
	public object GetComponentsInParent(object t) { }

	// RVA: -1
	public object GetComponentsInParent(object includeInactive) { }

	// RVA: -1
	public object GetComponentsInParent(object includeInactive, object results) { }

	// RVA: -1
	public object GetComponentsInParent() { }

	// RVA: 0x73A06E0
	public object GetComponents(object type) { }

	// RVA: 0x73A0888
	private object GetComponentsForListInternal(object searchType, object resultList) { }

	// RVA: 0x73A08F4
	public object GetComponents(object type, object results) { }

	// RVA: -1
	public object GetComponents(object results) { }

	// RVA: 0x73A0960
	public object get_tag() { }

	// RVA: 0x73A0A40
	public object set_tag(object value) { }

	// RVA: -1
	public object GetComponents() { }

	// RVA: 0x73A0B4C
	public object CompareTag(object tag) { }

	// RVA: 0x73A0C58
	public object SendMessageUpwards(object methodName, object value, object options) { }

	// RVA: 0x73A0CD8
	public object SendMessageUpwards(object methodName, object value) { }

	// RVA: 0x73A0D4C
	public object SendMessageUpwards(object methodName) { }

	// RVA: 0x73A0DC0
	public object SendMessageUpwards(object methodName, object options) { }

	// RVA: 0x73A0E38
	public object SendMessage(object methodName, object value) { }

	// RVA: 0x73A0F2C
	public object SendMessage(object methodName) { }

	// RVA: 0x73A0EAC
	public object SendMessage(object methodName, object value, object options) { }

	// RVA: 0x73A0FA0
	public object SendMessage(object methodName, object options) { }

	// RVA: 0x73A1018
	public object BroadcastMessage(object methodName, object parameter, object options) { }

	// RVA: 0x73A1098
	public object BroadcastMessage(object methodName, object parameter) { }

	// RVA: 0x73A110C
	public object BroadcastMessage(object methodName) { }

	// RVA: 0x73A1180
	public object BroadcastMessage(object methodName, object options) { }

	// RVA: 0x739EC60
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class Coroutine
{

	// Fields
	internal object m_Ptr; // 0x8

	// Methods

	// RVA: 0x73A121C
	private object .ctor() { }

	// RVA: 0x73A1224
	protected override object Finalize() { }

	// RVA: 0x73A12DC
	private static object ReleaseCoroutine(object ptr) { }

}

// Namespace: UnityEngine
internal class SetupCoroutine
{

	// Methods

	// RVA: 0x73A132C
	public static object InvokeMoveNext(object enumerator, object returnValueAddress) { }

	// RVA: 0x73A1480
	public static object InvokeMember(object behaviour, object name, object variable) { }

}

// Namespace: UnityEngine
public abstract class CustomYieldInstruction
{

	// Properties
	public abstract object keepWaiting { get; }
	public object Current { get; }

	// Methods

	// RVA: -1
	public abstract object get_keepWaiting() { }

	// RVA: 0x73A15B4
	public object get_Current() { }

	// RVA: 0x73A15BC
	public object MoveNext() { }

	// RVA: 0x73A15FC
	public virtual object Reset() { }

	// RVA: 0x73A1600
	protected object .ctor() { }

}

// Namespace: UnityEngine
internal struct EnumData
{

	// Fields
	public object values; // 0xFFFFFFFFFFFFFFF8
	public object flagValues; // 0x0
	public object displayNames; // 0x8
	public object names; // 0x10
	public object tooltip; // 0x18
	public object flags; // 0x20
	public object underlyingType; // 0x28
	public object unsigned; // 0x30
	public object serializable; // 0x31
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__2_5; // 0x8
	public static object <>9__2_1; // 0x10
	public static object <>9__2_2; // 0x18
	public static object <>9__2_3; // 0x20
	public static object <>9__2_4; // 0x28

	// Methods

	// RVA: 0x73A36C4
	private static object .cctor() { }

	// RVA: 0x73A3724
	public object .ctor() { }

	// RVA: 0x73A372C
	internal object <GetCachedEnumData>b__2_5(object f) { }

	// RVA: 0x73A377C
	internal object <GetCachedEnumData>b__2_1(object f) { }

	// RVA: 0x73A37FC
	internal object <GetCachedEnumData>b__2_2(object f) { }

	// RVA: 0x73A38B0
	internal object <GetCachedEnumData>b__2_3(object v) { }

	// RVA: 0x73A3918
	internal object <GetCachedEnumData>b__2_4(object v) { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object nicifyName; // 0x8

	// Methods

	// RVA: 0x73A28E8
	public object .ctor() { }

	// RVA: 0x73A3980
	internal object <GetCachedEnumData>b__0(object f) { }

}

// Namespace: 
private struct <>c__DisplayClass8_0
{

	// Fields
	public object nicifyName; // 0xFFFFFFFFFFFFFFF8
	public object field; // 0x0
}

// Namespace: UnityEngine
internal static class EnumDataUtility
{

	// Fields
	private static readonly object s_NonObsoleteEnumData; // 0x0
	private static readonly object s_EnumData; // 0x8

	// Methods

	// RVA: 0x73A1644
	internal static object GetCachedEnumData(object enumType, object excludeObsolete, object nicifyName) { }

	// RVA: 0x73A2A64
	internal static object HandleInspectorOrderAttribute(object enumType, object enumData) { }

	// RVA: 0x73A28F0
	private static object CheckObsoleteAddition(object field, object excludeObsolete) { }

	// RVA: 0x73A3150
	private static object EnumTooltipFromEnumField(object field) { }

	// RVA: 0x73A32F4
	private static object EnumNameFromEnumField(object field, object nicifyName) { }

	// RVA: 0x73A3614
	private static object .cctor() { }

	// RVA: 0x73A3574
	internal static object <EnumNameFromEnumField>g__NicifyName|8_0(object ) { }

}

// Namespace: UnityEngine
public class ExcludeFromObjectFactoryAttribute
{

	// Methods

	// RVA: 0x73A3A14
	public object .ctor() { }

}

// Namespace: UnityEngine
internal sealed class ExtensionOfNativeClassAttribute
{

	// Methods

	// RVA: 0x73A3A1C
	public object .ctor() { }

}

// Namespace: UnityEngine
internal class FailedToLoadScriptObject
{
}

// Namespace: UnityEngine
public sealed class GameObject
{

	// Properties
	public object transform { get; }
	public object layer { get; set; }
	public object active { get; set; }
	public object activeSelf { get; }
	public object activeSelfInThread { get; }
	public object activeInHierarchy { get; }
	public object isStatic { get; set; }
	internal object isStaticBatchable { get; }
	public object tag { get; set; }
	public object scene { get; }
	public object sceneCullingMask { get; }
	public object gameObject { get; }

	// Methods

	// RVA: 0x73A3A40
	public static object CreatePrimitive(object type) { }

	// RVA: -1
	public object GetComponent() { }

	// RVA: 0x739FBF0
	public object GetComponent(object type) { }

	// RVA: 0x73A3A90
	internal object GetComponentFastPath(object type, object oneFurtherThanResultValue) { }

	// RVA: 0x73A3AFC
	internal object GetComponentByName(object type) { }

	// RVA: 0x73A3B60
	public object GetComponent(object type) { }

	// RVA: 0x739FF98
	public object GetComponentInChildren(object type, object includeInactive) { }

	// RVA: 0x73A3BC4
	public object GetComponentInChildren(object type) { }

	// RVA: -1
	public object GetComponentInChildren() { }

	// RVA: -1
	public object GetComponentInChildren(object includeInactive) { }

	// RVA: 0x73A040C
	public object GetComponentInParent(object type, object includeInactive) { }

	// RVA: 0x73A3C30
	public object GetComponentInParent(object type) { }

	// RVA: -1
	public object GetComponentInParent() { }

	// RVA: -1
	public object GetComponentInParent(object includeInactive) { }

	// RVA: 0x73A3C9C
	private object GetComponentsInternal(object type, object useSearchTypeAsArrayReturnType, object recursive, object includeInactive, object reverse, object resultList) { }

	// RVA: 0x73A07D4
	public object GetComponents(object type) { }

	// RVA: -1
	public object GetComponents() { }

	// RVA: 0x73A3D40
	public object GetComponents(object type, object results) { }

	// RVA: -1
	public object GetComponents(object results) { }

	// RVA: 0x73A3DAC
	public object GetComponentsInChildren(object type) { }

	// RVA: 0x73A01AC
	public object GetComponentsInChildren(object type, object includeInactive) { }

	// RVA: -1
	public object GetComponentsInChildren(object includeInactive) { }

	// RVA: -1
	public object GetComponentsInChildren(object includeInactive, object results) { }

	// RVA: -1
	public object GetComponentsInChildren() { }

	// RVA: -1
	public object GetComponentsInChildren(object results) { }

	// RVA: 0x73A3E60
	public object GetComponentsInParent(object type) { }

	// RVA: 0x73A0620
	public object GetComponentsInParent(object type, object includeInactive) { }

	// RVA: -1
	public object GetComponentsInParent(object includeInactive, object results) { }

	// RVA: -1
	public object GetComponentsInParent(object includeInactive) { }

	// RVA: -1
	public object GetComponentsInParent() { }

	// RVA: -1
	public object TryGetComponent(object component) { }

	// RVA: 0x739FD30
	public object TryGetComponent(object type, object component) { }

	// RVA: 0x73A3F14
	internal object TryGetComponentInternal(object type) { }

	// RVA: 0x73A3FE8
	internal object TryGetComponentFastPath(object type, object oneFurtherThanResultValue) { }

	// RVA: 0x73A4054
	public static object FindWithTag(object tag) { }

	// RVA: 0x73A40F4
	public object SendMessageUpwards(object methodName, object options) { }

	// RVA: 0x73A41EC
	public object SendMessage(object methodName, object options) { }

	// RVA: 0x73A42E4
	public object BroadcastMessage(object methodName, object options) { }

	// RVA: 0x73A43DC
	internal object AddComponentInternal(object className) { }

	// RVA: 0x73A4440
	private object Internal_AddComponentWithType(object componentType) { }

	// RVA: 0x73A44A4
	public object AddComponent(object componentType) { }

	// RVA: -1
	public object AddComponent() { }

	// RVA: 0x73A4508
	public object get_transform() { }

	// RVA: 0x73A4558
	public object get_layer() { }

	// RVA: 0x73A45A8
	public object set_layer(object value) { }

	// RVA: 0x73A460C
	public object get_active() { }

	// RVA: 0x73A465C
	public object set_active(object value) { }

	// RVA: 0x73A46C0
	public object SetActive(object value) { }

	// RVA: 0x73A4724
	public object get_activeSelf() { }

	// RVA: 0x73A4774
	public object get_activeSelfInThread() { }

	// RVA: 0x73A47C4
	public object get_activeInHierarchy() { }

	// RVA: 0x73A4814
	public object SetActiveRecursively(object state) { }

	// RVA: 0x73A4878
	public object get_isStatic() { }

	// RVA: 0x73A48C8
	public object set_isStatic(object value) { }

	// RVA: 0x73A492C
	internal object get_isStaticBatchable() { }

	// RVA: 0x73A09F0
	public object get_tag() { }

	// RVA: 0x73A0AE8
	public object set_tag(object value) { }

	// RVA: 0x73A0BF4
	public object CompareTag(object tag) { }

	// RVA: 0x73A40A4
	public static object FindGameObjectWithTag(object tag) { }

	// RVA: 0x73A497C
	public static object FindGameObjectsWithTag(object tag) { }

	// RVA: 0x73A416C
	public object SendMessageUpwards(object methodName, object value, object options) { }

	// RVA: 0x73A49CC
	public object SendMessageUpwards(object methodName, object value) { }

	// RVA: 0x73A4A40
	public object SendMessageUpwards(object methodName) { }

	// RVA: 0x73A4264
	public object SendMessage(object methodName, object value, object options) { }

	// RVA: 0x73A4AB4
	public object SendMessage(object methodName, object value) { }

	// RVA: 0x73A4B28
	public object SendMessage(object methodName) { }

	// RVA: 0x73A435C
	public object BroadcastMessage(object methodName, object parameter, object options) { }

	// RVA: 0x73A4B9C
	public object BroadcastMessage(object methodName, object parameter) { }

	// RVA: 0x73A4C10
	public object BroadcastMessage(object methodName) { }

	// RVA: 0x73A4C84
	public object .ctor(object name) { }

	// RVA: 0x73A4DB8
	public object .ctor() { }

	// RVA: 0x73A4E84
	public object .ctor(object name, object components) { }

	// RVA: 0x73A4D54
	private static object Internal_CreateGameObject(object self, object name) { }

	// RVA: 0x73A4FD4
	public static object Find(object name) { }

	// RVA: 0x73A5024
	public object get_scene() { }

	// RVA: 0x73A50E4
	public object get_sceneCullingMask() { }

	// RVA: 0x73A5134
	public object get_gameObject() { }

	// RVA: 0x73A5080
	private object get_scene_Injected(object ret) { }

}

// Namespace: UnityEngine
public sealed class InspectorOrderAttribute
{

	// Fields
	private object <m_inspectorSort>k__BackingField; // 0x8
	private object <m_sortDirection>k__BackingField; // 0xC

	// Properties
	internal object m_inspectorSort { get; }
	internal object m_sortDirection { get; }

	// Methods

	// RVA: 0x73A5138
	internal object get_m_inspectorSort() { }

	// RVA: 0x73A5140
	internal object get_m_sortDirection() { }

}

// Namespace: UnityEngine
public enum InspectorSort
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ByName;
	public const object ByValue;
}

// Namespace: UnityEngine
public enum InspectorSortDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Ascending;
	public const object Descending;
}

// Namespace: UnityEngine
public struct LayerMask
{

	// Fields
	private object m_Mask; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object value { get; }

	// Methods

	// RVA: 0x73A5148
	public static object op_Implicit(object mask) { }

	// RVA: 0x73A514C
	public static object op_Implicit(object intVal) { }

	// RVA: 0x73A5150
	public object get_value() { }

	// RVA: 0x73A5160
	public static object NameToLayer(object layerName) { }

	// RVA: 0x73A51B0
	public static object GetMask(object layerNames) { }

}

// Namespace: UnityEngine
public struct LazyLoadReference<T0>
{

	// Fields
	private object m_InstanceID; // 0x0
}

// Namespace: UnityEngine
internal static class ManagedStreamHelpers
{

	// Methods

	// RVA: 0x73A52AC
	internal static object ValidateLoadFromStream(object stream) { }

	// RVA: 0x73A53F4
	internal static object ManagedStreamRead(object buffer, object offset, object count, object stream, object returnValueAddress) { }

	// RVA: 0x73A5500
	internal static object ManagedStreamSeek(object offset, object origin, object stream, object returnValueAddress) { }

	// RVA: 0x73A55FC
	internal static object ManagedStreamLength(object stream, object returnValueAddress) { }

}

// Namespace: UnityEngine
public class MonoBehaviour
{

	// Fields
	private object m_CancellationTokenSource; // 0x10

	// Properties
	public object destroyCancellationToken { get; }
	public object useGUILayout { get; set; }

	// Methods

	// RVA: 0x73A56DC
	public object get_destroyCancellationToken() { }

	// RVA: 0x73A57D0
	private object RaiseCancellation() { }

	// RVA: 0x73A57E4
	public object IsInvoking() { }

	// RVA: 0x73A5884
	public object CancelInvoke() { }

	// RVA: 0x73A5924
	public object Invoke(object methodName, object time) { }

	// RVA: 0x73A5A24
	public object InvokeRepeating(object methodName, object time, object repeatRate) { }

	// RVA: 0x73A5B80
	public object CancelInvoke(object methodName) { }

	// RVA: 0x73A5C48
	public object IsInvoking(object methodName) { }

	// RVA: 0x73A5D10
	public object StartCoroutine(object methodName) { }

	// RVA: 0x73A5D18
	public object StartCoroutine(object methodName, object value) { }

	// RVA: 0x73A5EF8
	public object StartCoroutine(object routine) { }

	// RVA: 0x73A6084
	public object StartCoroutine_Auto(object routine) { }

	// RVA: 0x73A6088
	public object StopCoroutine(object routine) { }

	// RVA: 0x73A6214
	public object StopCoroutine(object routine) { }

	// RVA: 0x73A63A0
	public object StopCoroutine(object methodName) { }

	// RVA: 0x73A6404
	public object StopAllCoroutines() { }

	// RVA: 0x73A6454
	public object get_useGUILayout() { }

	// RVA: 0x73A64A4
	public object set_useGUILayout(object value) { }

	// RVA: 0x73A6508
	public static object print(object message) { }

	// RVA: 0x73A58D4
	private static object Internal_CancelInvokeAll(object self) { }

	// RVA: 0x73A5834
	private static object Internal_IsInvokingAll(object self) { }

	// RVA: 0x73A59A4
	private static object InvokeDelayed(object self, object methodName, object time, object repeatRate) { }

	// RVA: 0x73A5BE4
	private static object CancelInvoke(object self, object methodName) { }

	// RVA: 0x73A5CAC
	private static object IsInvoking(object self, object methodName) { }

	// RVA: 0x73A5E3C
	private static object IsObjectMonoBehaviour(object obj) { }

	// RVA: 0x73A5E8C
	private object StartCoroutineManaged(object methodName, object value) { }

	// RVA: 0x73A6020
	private object StartCoroutineManaged2(object enumerator) { }

	// RVA: 0x73A633C
	private object StopCoroutineManaged(object routine) { }

	// RVA: 0x73A61B0
	private object StopCoroutineFromEnumeratorManaged(object routine) { }

	// RVA: 0x73A6590
	internal object GetScriptClassName() { }

	// RVA: 0x73A5780
	private object OnCancellationTokenCreated() { }

	// RVA: 0x73A65E0
	public object .ctor() { }

}

// Namespace: UnityEngine
internal sealed class NoAllocHelpers
{

	// Methods

	// RVA: -1
	public static object ResizeList(object list, object size) { }

	// RVA: -1
	public static object EnsureListElemCount(object list, object count) { }

	// RVA: 0x73A6668
	public static object SafeLength(object values) { }

	// RVA: -1
	public static object SafeLength(object values) { }

	// RVA: -1
	public static object ExtractArrayFromListT(object list) { }

	// RVA: 0x73A6678
	internal static object Internal_ResizeList(object list, object size) { }

	// RVA: 0x73A66DC
	public static object ExtractArrayFromList(object list) { }

}

// Namespace: UnityEngine
public struct RangeInt
{

	// Fields
	public object start; // 0xFFFFFFFFFFFFFFF8
	public object length; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object end { get; }

	// Methods

	// RVA: 0x73A672C
	public object get_end() { }

	// RVA: 0x73A6744
	public object .ctor(object start, object length) { }

}

// Namespace: UnityEngine
public enum RuntimeInitializeLoadType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AfterSceneLoad;
	public const object BeforeSceneLoad;
	public const object AfterAssembliesLoaded;
	public const object BeforeSplashScreen;
	public const object SubsystemRegistration;
}

// Namespace: UnityEngine
public class RuntimeInitializeOnLoadMethodAttribute
{

	// Fields
	private object m_LoadType; // 0x8

	// Properties
	private object loadType { set; }

	// Methods

	// RVA: 0x73A6754
	public object .ctor() { }

	// RVA: 0x73A6784
	public object .ctor(object loadType) { }

	// RVA: 0x73A677C
	private object set_loadType(object value) { }

}

// Namespace: UnityEngine
public class ScriptableObject
{

	// Methods

	// RVA: 0x73A67CC
	public object .ctor() { }

	// RVA: 0x73A68E0
	public static object CreateInstance(object type) { }

	// RVA: -1
	public static object CreateInstance() { }

	// RVA: 0x73A6890
	private static object CreateScriptableObject(object self) { }

	// RVA: 0x73A6938
	internal static object CreateScriptableObjectInstanceFromType(object type, object applyDefaultsAndReset) { }

}

// Namespace: UnityEngine
internal class ScriptingRuntime
{

	// Methods

	// RVA: 0x73A699C
	public static object GetAllUserAssemblies() { }

}

// Namespace: 
private struct TestClass
{

	// Fields
	public object value; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine
internal class ScriptingUtility
{

	// Methods

	// RVA: 0x73A69DC
	private static object IsManagedCodeWorking() { }

}

// Namespace: UnityEngine
public class SelectionBaseAttribute
{

	// Methods

	// RVA: 0x73A69E4
	public object .ctor() { }

}

// Namespace: UnityEngine
public static class StackTraceUtility
{

	// Fields
	private static object projectFolder; // 0x0

	// Methods

	// RVA: 0x73A69EC
	internal static object SetProjectFolder(object folder) { }

	// RVA: 0x73A6B08
	public static object ExtractStackTrace() { }

	// RVA: 0x73A76F4
	private static object PreprocessStacktrace(object stackTraceString) { }

	// RVA: 0x73A7CAC
	internal static object ExtractStringFromExceptionInternal(object exceptiono, object message, object stackTrace) { }

	// RVA: 0x73A8114
	internal static object GetFullMethodNameFromMethodBase(object mb) { }

	// RVA: 0x73A6C94
	internal static object ExtractFormattedStackTrace(object stackTrace) { }

	// RVA: 0x73A856C
	private static object .cctor() { }

}

// Namespace: UnityEngine
public class UnityException
{

	// Methods

	// RVA: 0x73A85D8
	public object .ctor() { }

	// RVA: 0x73A5B04
	public object .ctor(object message) { }

	// RVA: 0x73A8664
	protected object .ctor(object info, object context) { }

}

// Namespace: 
private static class EncodingUtility
{

	// Fields
	internal static readonly object encodingLookup; // 0x0
	internal static readonly object targetEncoding; // 0x8

	// Methods

	// RVA: 0x73A8C2C
	private static object .cctor() { }

}

// Namespace: UnityEngine
public class TextAsset
{

	// Properties
	public object bytes { get; }
	public object text { get; }

	// Methods

	// RVA: 0x73A86E8
	public object get_bytes() { }

	// RVA: 0x73A8738
	public object get_text() { }

	// RVA: 0x73A8B78
	public override object ToString() { }

	// RVA: 0x73A87EC
	internal static object DecodeString(object bytes) { }

}

// Namespace: UnityEngine
public class TrackedReference
{

	// Fields
	internal object m_Ptr; // 0x8

	// Methods

	// RVA: 0x73A9094
	protected object .ctor() { }

	// RVA: 0x73A909C
	public static object op_Equality(object x, object y) { }

	// RVA: 0x73A90FC
	public static object op_Inequality(object x, object y) { }

	// RVA: 0x73A9188
	public override object Equals(object o) { }

	// RVA: 0x73A928C
	public override object GetHashCode() { }

	// RVA: 0x73A9298
	public static object op_Implicit(object exists) { }

}

// Namespace: UnityEngine
internal sealed class UnhandledExceptionHandler
{

	// Methods

	// RVA: 0x73A92C0
	private static object RegisterUECatcher() { }

	// RVA: 0x73A9360
	private static object HandleUnhandledException(object sender, object args) { }

	// RVA: 0x73A9584
	private static object PrintException(object title, object e) { }

	// RVA: 0x73A9638
	private static object iOSNativeUnhandledExceptionHandler(object managedExceptionType, object managedExceptionMessage, object managedExceptionStack) { }

}

// Namespace: UnityEngine
public enum HideFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object HideInHierarchy;
	public const object HideInInspector;
	public const object DontSaveInEditor;
	public const object NotEditable;
	public const object DontSaveInBuild;
	public const object DontUnloadUnusedAsset;
	public const object DontSave;
	public const object HideAndDontSave;
}

// Namespace: UnityEngine
public enum FindObjectsSortMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object InstanceID;
}

// Namespace: UnityEngine
public enum FindObjectsInactive
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Exclude;
	public const object Include;
}

// Namespace: UnityEngine
public class Object
{

	// Fields
	private object m_CachedPtr; // 0x8
	internal static object OffsetOfInstanceIDInCPlusPlusObject; // 0x0
	private const object objectIsNullMessage;
	private const object cloneDestroyedMessage;

	// Properties
	public object name { get; set; }
	public object namehash { get; }
	public object hideFlags { get; set; }

	// Methods

	// RVA: 0x73A96C0
	public object GetInstanceID() { }

	// RVA: 0x73A9850
	public override object GetHashCode() { }

	// RVA: 0x73A9858
	public override object Equals(object other) { }

	// RVA: 0x73A9B74
	public static object op_Implicit(object exists) { }

	// RVA: 0x73A9A94
	private static object CompareBaseObjects(object lhs, object rhs) { }

	// RVA: 0x73A9C00
	private static object IsNativeObjectAlive(object o) { }

	// RVA: 0x73A9C28
	private object GetCachedPtr() { }

	// RVA: 0x73A9C30
	public object get_name() { }

	// RVA: 0x73A9D2C
	public object set_name(object value) { }

	// RVA: 0x73A9E48
	public object get_namehash() { }

	// RVA: 0x73A9F44
	public static object Clone(object original) { }

	// RVA: 0x73AA0DC
	public static object Instantiate(object original, object position, object rotation) { }

	// RVA: 0x73AA4A8
	public static object Instantiate(object original, object position, object rotation, object parent) { }

	// RVA: 0x73AA8F4
	public static object Instantiate(object original) { }

	// RVA: 0x73AAAD8
	public static object Instantiate(object original, object parent) { }

	// RVA: 0x73AAB44
	public static object Instantiate(object original, object parent, object instantiateInWorldSpace) { }

	// RVA: -1
	public static object Instantiate(object original) { }

	// RVA: -1
	public static object Instantiate(object original, object position, object rotation) { }

	// RVA: -1
	public static object Instantiate(object original, object position, object rotation, object parent) { }

	// RVA: -1
	public static object Instantiate(object original, object parent) { }

	// RVA: -1
	public static object Instantiate(object original, object parent, object worldPositionStays) { }

	// RVA: 0x73AAE70
	public static object Destroy(object obj, object t) { }

	// RVA: 0x73AAED4
	public static object Destroy(object obj) { }

	// RVA: 0x73AAF88
	public static object DestroyImmediate(object obj, object allowDestroyingAssets) { }

	// RVA: 0x73AAFEC
	public static object DestroyImmediate(object obj) { }

	// RVA: 0x73AB0A0
	public static object FindObjectsOfType(object type) { }

	// RVA: 0x73AB154
	public static object FindObjectsOfType(object type, object includeInactive) { }

	// RVA: 0x73AB1B8
	public static object FindObjectsByType(object type, object sortMode) { }

	// RVA: 0x73AB260
	public static object FindObjectsByType(object type, object findObjectsInactive, object sortMode) { }

	// RVA: 0x73AB2CC
	public static object DontDestroyOnLoad(object target) { }

	// RVA: 0x73AB31C
	public object get_hideFlags() { }

	// RVA: 0x73AB36C
	public object set_hideFlags(object value) { }

	// RVA: 0x73AB3D0
	public static object DestroyObject(object obj) { }

	// RVA: -1
	public static object FindObjectsOfType() { }

	// RVA: -1
	public static object FindObjectsByType(object sortMode) { }

	// RVA: -1
	public static object FindObjectsOfType(object includeInactive) { }

	// RVA: -1
	public static object FindObjectsByType(object findObjectsInactive, object sortMode) { }

	// RVA: -1
	public static object FindObjectOfType() { }

	// RVA: -1
	public static object FindFirstObjectByType() { }

	// RVA: 0x73AA03C
	private static object CheckNullArgument(object arg, object message) { }

	// RVA: 0x73AB484
	public static object FindObjectOfType(object type) { }

	// RVA: 0x73AB564
	public static object FindFirstObjectByType(object type) { }

	// RVA: 0x73AB654
	public static object FindAnyObjectByType(object type) { }

	// RVA: 0x73AB744
	public static object FindObjectOfType(object type, object includeInactive) { }

	// RVA: 0x73AB828
	public static object FindFirstObjectByType(object type, object findObjectsInactive) { }

	// RVA: 0x73AB91C
	public static object FindAnyObjectByType(object type, object findObjectsInactive) { }

	// RVA: 0x73ABA10
	public override object ToString() { }

	// RVA: 0x73A9A08
	public static object op_Equality(object x, object y) { }

	// RVA: 0x73A3F78
	public static object op_Inequality(object x, object y) { }

	// RVA: 0x73A9810
	private static object GetOffsetOfInstanceIDInCPlusPlusObject() { }

	// RVA: 0x73AA08C
	private static object Internal_CloneSingle(object data) { }

	// RVA: 0x73AAE04
	private static object Internal_CloneSingleWithParent(object data, object parent, object worldPositionStays) { }

	// RVA: 0x73AA3E8
	private static object Internal_InstantiateSingle(object data, object pos, object rot) { }

	// RVA: 0x73AA82C
	private static object Internal_InstantiateSingleWithParent(object data, object parent, object pos, object rot) { }

	// RVA: 0x73ABABC
	private static object ToString(object obj) { }

	// RVA: 0x73A9CDC
	private static object GetName(object obj) { }

	// RVA: 0x73A9EF4
	private static object GetNameHash(object obj) { }

	// RVA: 0x73ABBF8
	public static object CompareName(object obj, object name) { }

	// RVA: 0x73ABC5C
	public static object NameStartsWith(object obj, object name) { }

	// RVA: 0x73ABCC0
	public static object NameContains(object obj, object name) { }

	// RVA: 0x73ABD24
	public static object IsPersistent(object obj) { }

	// RVA: 0x73A9DE4
	private static object SetName(object obj, object name) { }

	// RVA: 0x73ABD74
	public static object FindObjectFromInstanceID(object instanceID) { }

	// RVA: 0x73ABDC4
	public static object GetObjectPathFromInstanceID(object instanceID) { }

	// RVA: 0x73ABE14
	public static object GetObjectPath(object obj) { }

	// RVA: 0x73A11F8
	public object .ctor() { }

	// RVA: 0x73ABFBC
	private static object .cctor() { }

	// RVA: 0x73ABB0C
	private static object Internal_InstantiateSingle_Injected(object data, object pos, object rot) { }

	// RVA: 0x73ABB78
	private static object Internal_InstantiateSingleWithParent_Injected(object data, object parent, object pos, object rot) { }

}

// Namespace: 
private struct WorkRequest
{

	// Fields
	private readonly object m_DelagateCallback; // 0xFFFFFFFFFFFFFFF8
	private readonly object m_DelagateState; // 0x0
	private readonly object m_WaitHandle; // 0x8

	// Methods

	// RVA: 0x73AC518
	public object .ctor(object callback, object state, object waitHandle) { }

	// RVA: 0x73ACA14
	public object Invoke() { }

}

// Namespace: UnityEngine
internal sealed class UnitySynchronizationContext
{

	// Fields
	private readonly object m_AsyncWorkQueue; // 0x10
	private readonly object m_CurrentFrameWork; // 0x18
	private readonly object m_MainThreadID; // 0x20
	private object m_TrackedCount; // 0x24

	// Methods

	// RVA: 0x73AC00C
	private object .ctor(object mainThreadID) { }

	// RVA: 0x73AC0C4
	private object .ctor(object queue, object mainThreadID) { }

	// RVA: 0x73AC168
	public override object Send(object callback, object state) { }

	// RVA: 0x73AC524
	public override object OperationStarted() { }

	// RVA: 0x73AC530
	public override object OperationCompleted() { }

	// RVA: 0x73AC53C
	public override object Post(object callback, object state) { }

	// RVA: 0x73AC720
	public override object CreateCopy() { }

	// RVA: 0x73AC7FC
	public object Exec() { }

	// RVA: 0x73ACB00
	private object HasPendingTasks() { }

	// RVA: 0x73ACB74
	private static object InitializeSynchronizationContext() { }

	// RVA: 0x73ACBF4
	private static object ExecuteTasks() { }

	// RVA: 0x73ACC5C
	private static object ExecutePendingTasks(object millisecondsTimeout) { }

}

// Namespace: UnityEngine
public sealed class WaitForEndOfFrame
{

	// Methods

	// RVA: 0x73ACEAC
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class WaitForFixedUpdate
{

	// Methods

	// RVA: 0x73ACEB4
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class WaitForSeconds
{

	// Fields
	internal object m_Seconds; // 0x8

	// Methods

	// RVA: 0x73ACED8
	public object .ctor(object seconds) { }

}

// Namespace: UnityEngine
public class WaitForSecondsRealtime
{

	// Fields
	private object <waitTime>k__BackingField; // 0x8
	private object m_WaitUntilTime; // 0xC

	// Properties
	public object waitTime { get; set; }
	public override object keepWaiting { get; }

	// Methods

	// RVA: 0x73ACF0C
	public object get_waitTime() { }

	// RVA: 0x73ACF14
	public object set_waitTime(object value) { }

	// RVA: 0x73ACF1C
	public override object get_keepWaiting() { }

	// RVA: 0x73AD044
	public object .ctor(object time) { }

	// RVA: 0x73AD080
	public override object Reset() { }

}

// Namespace: UnityEngine
public sealed class WaitUntil
{

	// Fields
	private object m_Predicate; // 0x8

	// Properties
	public override object keepWaiting { get; }

	// Methods

	// RVA: 0x73AD08C
	public override object get_keepWaiting() { }

	// RVA: 0x73AD0C4
	public object .ctor(object predicate) { }

}

// Namespace: UnityEngine
public class YieldInstruction
{

	// Methods

	// RVA: 0x739DB88
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class SerializeField
{

	// Methods

	// RVA: 0x73AD0FC
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class SerializeReference
{
}

// Namespace: UnityEngine
public sealed class PreferBinarySerialization
{

	// Methods

	// RVA: 0x73AD104
	public object .ctor() { }

}

// Namespace: UnityEngine
public interface ISerializationCallbackReceiver
{

	// Methods

	// RVA: -1
	public abstract object OnBeforeSerialize() { }

	// RVA: -1
	public abstract object OnAfterDeserialize() { }

}

// Namespace: UnityEngine
public sealed class BatchPerDrawPropertyBlock
{

	// Fields
	internal object m_Ptr; // 0x8

	// Methods

	// RVA: 0x73AD10C
	private object SetVectorImpl(object name, object value) { }

	// RVA: 0x73AD1E4
	private object SetMatrixImpl(object name, object value) { }

	// RVA: 0x73AD2BC
	private object SetTextureImpl(object name, object value) { }

	// RVA: 0x73AD328
	private object SetVectorArrayImpl(object name, object values, object count) { }

	// RVA: 0x73AD3A8
	private static object CreateImpl() { }

	// RVA: 0x73AD3E8
	private static object DestroyImpl(object mpb) { }

	// RVA: 0x73AD438
	private object Clear(object keepMemory) { }

	// RVA: 0x73AD49C
	public object Clear() { }

	// RVA: 0x73AD4F4
	public object RemoveTextureImpl(object nameID) { }

	// RVA: 0x73AD558
	private object GetGlobalKeywordStateImpl(object keyword) { }

	// RVA: 0x73AD62C
	private object SetGlobalKeywordStateImpl(object keyword, object value) { }

	// RVA: 0x73AD700
	private object SetVectorArray(object name, object values, object count) { }

	// RVA: 0x73AD844
	public object .ctor() { }

	// RVA: 0x73AD8A0
	protected override object Finalize() { }

	// RVA: 0x73AD9C0
	private object Dispose() { }

	// RVA: 0x73ADA8C
	public object SetVector(object nameID, object value) { }

	// RVA: 0x73ADAF8
	public object SetMatrix(object nameID, object value) { }

	// RVA: 0x73ADB6C
	public object SetTexture(object nameID, object value) { }

	// RVA: 0x73ADBD8
	public object SetVectorArray(object nameID, object values) { }

	// RVA: 0x73ADBF8
	public object EnableKeyword(object name) { }

	// RVA: 0x73ADC5C
	public object EnableKeyword(object keyword) { }

	// RVA: 0x73ADCB8
	public object DisableKeyword(object name) { }

	// RVA: 0x73ADD1C
	public object DisableKeyword(object keyword) { }

	// RVA: 0x73ADD78
	public object GetKeyword(object keyword) { }

	// RVA: 0x73AD178
	private object SetVectorImpl_Injected(object name, object value) { }

	// RVA: 0x73AD250
	private object SetMatrixImpl_Injected(object name, object value) { }

	// RVA: 0x73AD5C8
	private object GetGlobalKeywordStateImpl_Injected(object keyword) { }

	// RVA: 0x73AD694
	private object SetGlobalKeywordStateImpl_Injected(object keyword, object value) { }

}

// Namespace: UnityEngine
public sealed class ComputeBuffer
{

	// Fields
	internal object m_Ptr; // 0x8

	// Properties
	public object count { get; }
	public object stride { get; }
	private object usage { get; }
	public object name { set; }

	// Methods

	// RVA: 0x73ADDE8
	protected override object Finalize() { }

	// RVA: 0x73ADFC0
	public object Dispose() { }

	// RVA: 0x73ADEE8
	private object Dispose(object disposing) { }

	// RVA: 0x73AE11C
	private static object InitBuffer(object count, object stride, object type, object usage) { }

	// RVA: 0x73AE0CC
	private static object DestroyBuffer(object buf) { }

	// RVA: 0x73AE19C
	public object .ctor(object count, object stride) { }

	// RVA: 0x73AE390
	public object .ctor(object count, object stride, object type) { }

	// RVA: 0x73AE398
	public object .ctor(object count, object stride, object type, object usage) { }

	// RVA: 0x73AE1A8
	private object .ctor(object count, object stride, object type, object usage, object stackDepth) { }

	// RVA: 0x73AE3DC
	public object Release() { }

	// RVA: 0x73AE3E0
	private static object IsValidBuffer(object buf) { }

	// RVA: 0x73AE430
	public object IsValid() { }

	// RVA: 0x73AE4A0
	public object get_count() { }

	// RVA: 0x73AE4F0
	public object get_stride() { }

	// RVA: 0x73AE540
	private object get_usage() { }

	// RVA: 0x73AE590
	public object SetData(object data) { }

	// RVA: -1
	public object SetData(object data) { }

	// RVA: 0x73AE7BC
	public object SetData(object data, object managedBufferStartIndex, object computeBufferStartIndex, object count) { }

	// RVA: -1
	public object SetData(object data, object nativeBufferStartIndex, object computeBufferStartIndex, object count) { }

	// RVA: 0x73AEA88
	private object InternalSetNativeData(object data, object nativeBufferStartIndex, object computeBufferStartIndex, object count, object elemSize) { }

	// RVA: 0x73AE720
	private object InternalSetData(object data, object managedBufferStartIndex, object computeBufferStartIndex, object count, object elemSize) { }

	// RVA: 0x73AEB24
	private object BeginBufferWrite(object offset, object size) { }

	// RVA: -1
	public object BeginWrite(object computeBufferStartIndex, object count) { }

	// RVA: 0x73AEB90
	private object EndBufferWrite(object bytesWritten) { }

	// RVA: -1
	public object EndWrite(object countWritten) { }

	// RVA: 0x73AEBF4
	public object set_name(object value) { }

	// RVA: 0x73AEC58
	private object SetName(object name) { }

	// RVA: 0x73AECBC
	public object SetCounterValue(object counterValue) { }

}

// Namespace: UnityEngine
public sealed class ComputeShader
{

	// Properties
	public object keywordSpace { get; }

	// Methods

	// RVA: 0x73AED20
	public object FindKernel(object name) { }

	// RVA: 0x73AED84
	public object SetInt(object nameID, object val) { }

	// RVA: 0x73AEDF0
	public object SetTexture(object kernelIndex, object nameID, object texture, object mipLevel) { }

	// RVA: 0x73AEE78
	private object Internal_SetBuffer(object kernelIndex, object nameID, object buffer) { }

	// RVA: 0x73AEEF8
	public object SetBuffer(object kernelIndex, object nameID, object buffer) { }

	// RVA: 0x73AEF78
	public object GetKernelThreadGroupSizes(object kernelIndex, object x, object y, object z) { }

	// RVA: 0x73AF000
	public object Dispatch(object kernelIndex, object threadGroupsX, object threadGroupsY, object threadGroupsZ) { }

	// RVA: 0x73AF088
	public object get_keywordSpace() { }

	// RVA: 0x73AF148
	public object EnableKeyword(object keyword) { }

	// RVA: 0x73AF1AC
	public object DisableKeyword(object keyword) { }

	// RVA: 0x73AF210
	public object SetInt(object name, object val) { }

	// RVA: 0x73AF274
	public object SetBool(object name, object val) { }

	// RVA: 0x73AF2E8
	public object SetTexture(object kernelIndex, object name, object texture) { }

	// RVA: 0x73AF360
	public object SetBuffer(object kernelIndex, object name, object buffer) { }

	// RVA: 0x73AF0E4
	private object get_keywordSpace_Injected(object ret) { }

}

// Namespace: UnityEngine
public sealed class ShaderVariantCollection
{

	// Properties
	public object isWarmedUp { get; }

	// Methods

	// RVA: 0x73AF3D4
	public object get_isWarmedUp() { }

	// RVA: 0x73AF424
	public object WarmUp() { }

}

// Namespace: UnityEngine
public sealed class StaticBatchingUtility
{

	// Fields
	internal static object s_CombineMarker; // 0x0

	// Methods

	// RVA: 0x73AF474
	public static object Combine(object staticBatchRoot) { }

	// RVA: 0x73AF980
	public static object Combine(object gos, object staticBatchRoot) { }

	// RVA: 0x73AF5B0
	private static object CombineRoot(object staticBatchRoot) { }

	// RVA: 0x73AFAB4
	private static object .cctor() { }

}

// Namespace: UnityEngine
internal class LowerResBlitTexture
{

	// Methods

	// RVA: 0x73AFB34
	internal object LowerResBlitTextureDontStripMe() { }

}

// Namespace: UnityEngine
internal class PreloadData
{

	// Methods

	// RVA: 0x73AFB38
	internal object PreloadDataDontStripMe() { }

}

// Namespace: UnityEngine
public enum OperatingSystemFamily
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Other;
	public const object MacOSX;
	public const object Windows;
	public const object Linux;
}

// Namespace: UnityEngine
public enum DeviceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Handheld;
	public const object Console;
	public const object Desktop;
}

// Namespace: UnityEngine
public sealed class SystemInfo
{

	// Properties
	public static object operatingSystem { get; }
	public static object operatingSystemFamily { get; }
	public static object processorType { get; }
	public static object processorCount { get; }
	public static object systemMemorySize { get; }
	public static object deviceUniqueIdentifier { get; }
	public static object deviceName { get; }
	public static object deviceModel { get; }
	public static object supportsGyroscope { get; }
	public static object deviceType { get; }
	public static object graphicsMemorySize { get; }
	public static object graphicsDeviceName { get; }
	public static object graphicsDeviceVendor { get; }
	public static object graphicsDeviceID { get; }
	public static object graphicsDeviceType { get; }
	public static object graphicsDeviceVersion { get; }
	public static object graphicsShaderLevel { get; }
	public static object graphicsMultiThreaded { get; }
	public static object supportsRenderTextures { get; }
	public static object supportsImageEffects { get; }
	public static object supports3DTextures { get; }
	public static object supports3DRenderTextures { get; }
	public static object copyTextureSupport { get; }
	public static object supportsComputeShaders { get; }
	public static object supportsInstancing { get; }
	public static object supportedRenderTargetCount { get; }
	public static object usesReversedZBuffer { get; }
	public static object supportSIMDGroupIntrinsics { get; }
	public static object npotSupport { get; }
	public static object maxTextureSize { get; }
	internal static object maxRenderTextureSize { get; }
	public static object maxGraphicsBufferSize { get; }
	public static object supportsIndirectArgumentsBuffer { get; }

	// Methods

	// RVA: 0x73AFB3C
	public static object get_operatingSystem() { }

	// RVA: 0x73AFBBC
	public static object get_operatingSystemFamily() { }

	// RVA: 0x73AFC3C
	public static object get_processorType() { }

	// RVA: 0x73AFCBC
	public static object get_processorCount() { }

	// RVA: 0x73AFD3C
	public static object get_systemMemorySize() { }

	// RVA: 0x73AFDBC
	public static object get_deviceUniqueIdentifier() { }

	// RVA: 0x73AFE3C
	public static object get_deviceName() { }

	// RVA: 0x73AFEBC
	public static object get_deviceModel() { }

	// RVA: 0x73AFF3C
	public static object get_supportsGyroscope() { }

	// RVA: 0x73AFFBC
	public static object get_deviceType() { }

	// RVA: 0x73B003C
	public static object get_graphicsMemorySize() { }

	// RVA: 0x73B00BC
	public static object get_graphicsDeviceName() { }

	// RVA: 0x73B013C
	public static object get_graphicsDeviceVendor() { }

	// RVA: 0x73B01BC
	public static object get_graphicsDeviceID() { }

	// RVA: 0x73B023C
	public static object get_graphicsDeviceType() { }

	// RVA: 0x73B02BC
	public static object get_graphicsDeviceVersion() { }

	// RVA: 0x73B033C
	public static object get_graphicsShaderLevel() { }

	// RVA: 0x73B03BC
	public static object get_graphicsMultiThreaded() { }

	// RVA: 0x73B043C
	public static object get_supportsRenderTextures() { }

	// RVA: 0x73B0444
	public static object get_supportsImageEffects() { }

	// RVA: 0x73B044C
	public static object get_supports3DTextures() { }

	// RVA: 0x73B04CC
	public static object get_supports3DRenderTextures() { }

	// RVA: 0x73B054C
	public static object get_copyTextureSupport() { }

	// RVA: 0x73B05CC
	public static object get_supportsComputeShaders() { }

	// RVA: 0x73B064C
	public static object get_supportsInstancing() { }

	// RVA: 0x73B06CC
	public static object get_supportedRenderTargetCount() { }

	// RVA: 0x73B074C
	public static object get_usesReversedZBuffer() { }

	// RVA: 0x73B07CC
	public static object get_supportSIMDGroupIntrinsics() { }

	// RVA: 0x73B084C
	private static object IsValidEnumValue(object value) { }

	// RVA: 0x73B08E4
	public static object SupportsRenderTextureFormat(object format) { }

	// RVA: 0x73B0A7C
	public static object SupportsTextureFormat(object format) { }

	// RVA: 0x73B0C14
	public static object get_npotSupport() { }

	// RVA: 0x73B0C94
	public static object get_maxTextureSize() { }

	// RVA: 0x73B0D14
	internal static object get_maxRenderTextureSize() { }

	// RVA: 0x73AE39C
	public static object get_maxGraphicsBufferSize() { }

	// RVA: 0x73B0DD4
	public static object get_supportsIndirectArgumentsBuffer() { }

	// RVA: 0x73AFB7C
	private static object GetOperatingSystem() { }

	// RVA: 0x73AFBFC
	private static object GetOperatingSystemFamily() { }

	// RVA: 0x73AFC7C
	private static object GetProcessorType() { }

	// RVA: 0x73AFCFC
	private static object GetProcessorCount() { }

	// RVA: 0x73AFD7C
	private static object GetPhysicalMemoryMB() { }

	// RVA: 0x73AFDFC
	private static object GetDeviceUniqueIdentifier() { }

	// RVA: 0x73AFE7C
	private static object GetDeviceName() { }

	// RVA: 0x73AFEFC
	private static object GetDeviceModel() { }

	// RVA: 0x73AFF7C
	private static object IsGyroAvailable() { }

	// RVA: 0x73AFFFC
	private static object GetDeviceType() { }

	// RVA: 0x73B007C
	private static object GetGraphicsMemorySize() { }

	// RVA: 0x73B00FC
	private static object GetGraphicsDeviceName() { }

	// RVA: 0x73B017C
	private static object GetGraphicsDeviceVendor() { }

	// RVA: 0x73B01FC
	private static object GetGraphicsDeviceID() { }

	// RVA: 0x73B027C
	private static object GetGraphicsDeviceType() { }

	// RVA: 0x73B02FC
	private static object GetGraphicsDeviceVersion() { }

	// RVA: 0x73B037C
	private static object GetGraphicsShaderLevel() { }

	// RVA: 0x73B03FC
	private static object GetGraphicsMultiThreaded() { }

	// RVA: 0x73B048C
	private static object Supports3DTextures() { }

	// RVA: 0x73B050C
	private static object Supports3DRenderTextures() { }

	// RVA: 0x73B058C
	private static object GetCopyTextureSupport() { }

	// RVA: 0x73B060C
	private static object SupportsComputeShaders() { }

	// RVA: 0x73B068C
	private static object SupportsInstancing() { }

	// RVA: 0x73B070C
	private static object SupportedRenderTargetCount() { }

	// RVA: 0x73B078C
	private static object UsesReversedZBuffer() { }

	// RVA: 0x73B080C
	private static object SupportSIMDGroupIntrinsics() { }

	// RVA: 0x73B0A2C
	private static object HasRenderTextureNative(object format) { }

	// RVA: 0x73B0BC4
	private static object SupportsTextureFormatNative(object format) { }

	// RVA: 0x73B0C54
	private static object GetNPOTSupport() { }

	// RVA: 0x73B0CD4
	private static object GetMaxTextureSize() { }

	// RVA: 0x73B0D54
	private static object GetMaxRenderTextureSize() { }

	// RVA: 0x73B0D94
	private static object MaxGraphicsBufferSize() { }

	// RVA: 0x73B0E54
	public static object IsFormatSupported(object format, object usage) { }

	// RVA: 0x73B0EB8
	public static object GetCompatibleFormat(object format, object usage) { }

	// RVA: 0x73B0F1C
	public static object GetGraphicsFormat(object format) { }

	// RVA: 0x73B0E14
	private static object SupportsIndirectArgumentsBuffer() { }

}

// Namespace: UnityEngine
internal class SystemClock
{

	// Fields
	private static readonly object s_Epoch; // 0x0

	// Properties
	public static object now { get; }

	// Methods

	// RVA: 0x73B0F6C
	public static object get_now() { }

	// RVA: 0x73B0FDC
	private static object .cctor() { }

}

// Namespace: UnityEngine
public class Time
{

	// Properties
	public static object time { get; }
	public static object timeSinceLevelLoad { get; }
	public static object deltaTime { get; }
	public static object fixedTime { get; }
	public static object unscaledTime { get; }
	public static object unscaledDeltaTime { get; }
	public static object fixedDeltaTime { get; set; }
	public static object maximumDeltaTime { get; }
	public static object timeScale { get; set; }
	public static object frameCount { get; }
	public static object renderedFrameCount { get; }
	public static object realtimeSinceStartup { get; }
	public static object realtimeSinceStartupAsDouble { get; }

	// Methods

	// RVA: 0x73B105C
	public static object get_time() { }

	// RVA: 0x73B109C
	public static object get_timeSinceLevelLoad() { }

	// RVA: 0x73B10DC
	public static object get_deltaTime() { }

	// RVA: 0x73B111C
	public static object get_fixedTime() { }

	// RVA: 0x73B115C
	public static object get_unscaledTime() { }

	// RVA: 0x73B119C
	public static object get_unscaledDeltaTime() { }

	// RVA: 0x73B11DC
	public static object get_fixedDeltaTime() { }

	// RVA: 0x73B121C
	public static object set_fixedDeltaTime(object value) { }

	// RVA: 0x73B1270
	public static object get_maximumDeltaTime() { }

	// RVA: 0x73B12B0
	public static object get_timeScale() { }

	// RVA: 0x73B12F0
	public static object set_timeScale(object value) { }

	// RVA: 0x73B1344
	public static object get_frameCount() { }

	// RVA: 0x73B1384
	public static object get_renderedFrameCount() { }

	// RVA: 0x73AD004
	public static object get_realtimeSinceStartup() { }

	// RVA: 0x73B13C4
	public static object get_realtimeSinceStartupAsDouble() { }

}

// Namespace: UnityEngine
internal struct TouchScreenKeyboard_InternalConstructorHelperArguments
{

	// Fields
	public object keyboardType; // 0xFFFFFFFFFFFFFFF8
	public object autocorrection; // 0xFFFFFFFFFFFFFFFC
	public object multiline; // 0x0
	public object secure; // 0x4
	public object alert; // 0x8
	public object characterLimit; // 0xC
}

// Namespace: 
public enum Status
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Visible;
	public const object Done;
	public const object Canceled;
	public const object LostFocus;
}

// Namespace: UnityEngine
public class TouchScreenKeyboard
{

	// Fields
	internal object m_Ptr; // 0x8
	private static object <disableInPlaceEditing>k__BackingField; // 0x0

	// Properties
	public static object isSupported { get; }
	internal static object disableInPlaceEditing { get; }
	public static object isInPlaceEditingAllowed { get; }
	internal static object isRequiredToForceOpen { get; }
	public object text { get; set; }
	public static object hideInput { get; set; }
	public object active { get; set; }
	public object status { get; }
	public object characterLimit { set; }
	public object canGetSelection { get; }
	public object canSetSelection { get; }
	public object selection { get; set; }
	public static object area { get; }

	// Methods

	// RVA: 0x73B1404
	private static object Internal_Destroy(object ptr) { }

	// RVA: 0x73B1454
	private object Destroy() { }

	// RVA: 0x73B1520
	protected override object Finalize() { }

	// RVA: 0x73B1640
	public object .ctor(object text, object keyboardType, object autocorrection, object multiline, object secure, object alert, object textPlaceholder, object characterLimit) { }

	// RVA: 0x73B17A0
	private static object TouchScreenKeyboard_InternalConstructorHelper(object arguments, object text, object textPlaceholder) { }

	// RVA: 0x73B180C
	public static object get_isSupported() { }

	// RVA: 0x73B18EC
	internal static object get_disableInPlaceEditing() { }

	// RVA: 0x73B1938
	public static object get_isInPlaceEditingAllowed() { }

	// RVA: 0x73B1974
	internal static object get_isRequiredToForceOpen() { }

	// RVA: 0x73B19B4
	private static object IsRequiredToForceOpen() { }

	// RVA: 0x73B19F4
	public static object Open(object text, object keyboardType, object autocorrection, object multiline, object secure, object alert, object textPlaceholder, object characterLimit) { }

	// RVA: 0x73B1AB0
	public static object Open(object text, object keyboardType, object autocorrection, object multiline, object secure) { }

	// RVA: 0x73B1B84
	public static object Open(object text, object keyboardType) { }

	// RVA: 0x73B1C44
	public object get_text() { }

	// RVA: 0x73B1C94
	public object set_text(object value) { }

	// RVA: 0x73B1CF8
	public static object get_hideInput() { }

	// RVA: 0x73B1D38
	public static object set_hideInput(object value) { }

	// RVA: 0x73B1D88
	public object get_active() { }

	// RVA: 0x73B1DD8
	public object set_active(object value) { }

	// RVA: 0x73B1E3C
	public object get_status() { }

	// RVA: 0x73B1E8C
	public object set_characterLimit(object value) { }

	// RVA: 0x73B1EF0
	public object get_canGetSelection() { }

	// RVA: 0x73B1F40
	public object get_canSetSelection() { }

	// RVA: 0x73B1F90
	public object get_selection() { }

	// RVA: 0x73B204C
	public object set_selection(object value) { }

	// RVA: 0x73B1FE8
	private static object GetSelection(object start, object length) { }

	// RVA: 0x73B2168
	private static object SetSelection(object start, object length) { }

	// RVA: 0x73B21CC
	public static object get_area() { }

	// RVA: 0x73B2220
	private static object get_area_Injected(object ret) { }

}

// Namespace: UnityEngine
public enum TouchScreenKeyboardType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object ASCIICapable;
	public const object NumbersAndPunctuation;
	public const object URL;
	public const object NumberPad;
	public const object PhonePad;
	public const object NamePhonePad;
	public const object EmailAddress;
	public const object NintendoNetworkAccount;
	public const object Social;
	public const object Search;
	public const object DecimalPad;
	public const object OneTimeCode;
}

// Namespace: UnityEngine
internal static class UINumericFieldsUtils
{

	// Fields
	public static readonly object k_AllowedCharactersForFloat; // 0x0
	public static readonly object k_AllowedCharactersForInt; // 0x8
	public static readonly object k_DoubleFieldFormatString; // 0x10
	public static readonly object k_FloatFieldFormatString; // 0x18
	public static readonly object k_IntFieldFormatString; // 0x20

	// Methods

	// RVA: 0x73B2270
	public static object TryConvertStringToDouble(object str, object value, object expr) { }

	// RVA: 0x73B2418
	public static object TryConvertStringToDouble(object str, object initialValueAsString, object value) { }

	// RVA: 0x73B2584
	public static object TryConvertStringToFloat(object str, object initialValueAsString, object value) { }

	// RVA: 0x73B2624
	public static object TryConvertStringToLong(object str, object value, object expr) { }

	// RVA: 0x73B26B4
	public static object TryConvertStringToLong(object str, object initialValueAsString, object value) { }

	// RVA: 0x73B28E4
	public static object TryConvertStringToULong(object str, object value, object expr) { }

	// RVA: 0x73B2974
	public static object TryConvertStringToULong(object str, object initialValueAsString, object value) { }

	// RVA: 0x73B2BA4
	public static object TryConvertStringToInt(object str, object initialValueAsString, object value) { }

	// RVA: 0x73B2C44
	public static object TryConvertStringToUInt(object str, object initialValueAsString, object value) { }

	// RVA: 0x73B2CE4
	private static object .cctor() { }

}

// Namespace: UnityEngine
public static class FrameDebugger
{

	// Properties
	public static object enabled { get; }

	// Methods

	// RVA: 0x73B2DC8
	public static object get_enabled() { }

	// RVA: 0x73B2E44
	internal static object IsLocalEnabled() { }

	// RVA: 0x73B2E84
	internal static object IsRemoteEnabled() { }

}

// Namespace: UnityEngine
public enum DrivenTransformProperties
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object All;
	public const object AnchoredPositionX;
	public const object AnchoredPositionY;
	public const object AnchoredPositionZ;
	public const object Rotation;
	public const object ScaleX;
	public const object ScaleY;
	public const object ScaleZ;
	public const object AnchorMinX;
	public const object AnchorMinY;
	public const object AnchorMaxX;
	public const object AnchorMaxY;
	public const object SizeDeltaX;
	public const object SizeDeltaY;
	public const object PivotX;
	public const object PivotY;
	public const object AnchoredPosition;
	public const object AnchoredPosition3D;
	public const object Scale;
	public const object AnchorMin;
	public const object AnchorMax;
	public const object Anchors;
	public const object SizeDelta;
	public const object Pivot;
}

// Namespace: UnityEngine
public struct DrivenRectTransformTracker
{

	// Methods

	// RVA: 0x73B2EC4
	public object Add(object driver, object rectTransform, object drivenProperties) { }

	// RVA: 0x73B2ECC
	public object Clear() { }

}

// Namespace: 
public enum Edge
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
	public const object Top;
	public const object Bottom;
}

// Namespace: 
public enum Axis
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Horizontal;
	public const object Vertical;
}

// Namespace: 
public sealed class ReapplyDrivenProperties
{

	// Methods

	// RVA: 0x73B4EE0
	public object .ctor(object object, object method) { }

	// RVA: 0x73B4F88
	public virtual object Invoke(object driven) { }

}

// Namespace: UnityEngine
public sealed class RectTransform
{

	// Fields
	private static object reapplyDrivenProperties; // 0x0

	// Properties
	public object rect { get; }
	public object anchorMin { get; set; }
	public object anchorMax { get; set; }
	public object anchoredPosition { get; set; }
	public object sizeDelta { get; set; }
	public object pivot { get; set; }
	public object anchoredPosition3D { get; set; }
	public object offsetMin { get; set; }
	public object offsetMax { get; set; }
	public object drivenByObject { get; }

	// Methods

	// RVA: 0x73B2ED4
	public static object add_reapplyDrivenProperties(object value) { }

	// RVA: 0x73B2F94
	public static object remove_reapplyDrivenProperties(object value) { }

	// RVA: 0x73B3054
	public object get_rect() { }

	// RVA: 0x73B3118
	public object get_anchorMin() { }

	// RVA: 0x73B31D8
	public object set_anchorMin(object value) { }

	// RVA: 0x73B32AC
	public object get_anchorMax() { }

	// RVA: 0x73B336C
	public object set_anchorMax(object value) { }

	// RVA: 0x73B3440
	public object get_anchoredPosition() { }

	// RVA: 0x73B3500
	public object set_anchoredPosition(object value) { }

	// RVA: 0x73B35D4
	public object get_sizeDelta() { }

	// RVA: 0x73B3694
	public object set_sizeDelta(object value) { }

	// RVA: 0x73B3768
	public object get_pivot() { }

	// RVA: 0x73B3828
	public object set_pivot(object value) { }

	// RVA: 0x73B38FC
	public object get_anchoredPosition3D() { }

	// RVA: 0x73B3A00
	public object set_anchoredPosition3D(object value) { }

	// RVA: 0x73B3B40
	public object get_offsetMin() { }

	// RVA: 0x73B3C14
	public object set_offsetMin(object value) { }

	// RVA: 0x73B3E54
	public object get_offsetMax() { }

	// RVA: 0x73B3F70
	public object set_offsetMax(object value) { }

	// RVA: 0x73B41B8
	public object get_drivenByObject() { }

	// RVA: 0x73B4208
	public object ForceUpdateRectTransforms() { }

	// RVA: 0x73B4258
	public object GetLocalCorners(object fourCornersArray) { }

	// RVA: 0x73B4384
	public object GetWorldCorners(object fourCornersArray) { }

	// RVA: 0x73B45FC
	public object SetInsetAndSizeFromParentEdge(object edge, object inset, object size) { }

	// RVA: 0x73B48EC
	public object SetSizeWithCurrentAnchors(object axis, object size) { }

	// RVA: 0x73B4C78
	internal static object SendReapplyDrivenProperties(object driven) { }

	// RVA: 0x73B4AB0
	private object GetParentSize() { }

	// RVA: 0x73B4D44
	public object .ctor() { }

	// RVA: 0x73B30B4
	private object get_rect_Injected(object ret) { }

	// RVA: 0x73B3174
	private object get_anchorMin_Injected(object ret) { }

	// RVA: 0x73B3248
	private object set_anchorMin_Injected(object value) { }

	// RVA: 0x73B3308
	private object get_anchorMax_Injected(object ret) { }

	// RVA: 0x73B33DC
	private object set_anchorMax_Injected(object value) { }

	// RVA: 0x73B349C
	private object get_anchoredPosition_Injected(object ret) { }

	// RVA: 0x73B3570
	private object set_anchoredPosition_Injected(object value) { }

	// RVA: 0x73B3630
	private object get_sizeDelta_Injected(object ret) { }

	// RVA: 0x73B3704
	private object set_sizeDelta_Injected(object value) { }

	// RVA: 0x73B37C4
	private object get_pivot_Injected(object ret) { }

	// RVA: 0x73B3898
	private object set_pivot_Injected(object value) { }

}

// Namespace: 
private class Enumerator
{

	// Fields
	private object outer; // 0x8
	private object currentIndex; // 0x10

	// Properties
	public object Current { get; }

	// Methods

	// RVA: 0x73B83D8
	internal object .ctor(object outer) { }

	// RVA: 0x73B8F58
	public object get_Current() { }

	// RVA: 0x73B8FD0
	public object MoveNext() { }

	// RVA: 0x73B9044
	public object Reset() { }

}

// Namespace: UnityEngine
public class Transform
{

	// Properties
	public object position { get; set; }
	public object localPosition { get; set; }
	public object eulerAngles { get; set; }
	public object localEulerAngles { get; set; }
	public object right { get; set; }
	public object up { get; set; }
	public object forward { get; set; }
	public object rotation { get; set; }
	public object localRotation { get; set; }
	public object localScale { get; set; }
	public object parent { get; set; }
	internal object parentInternal { get; set; }
	public object worldToLocalMatrix { get; }
	public object localToWorldMatrix { get; }
	public object root { get; }
	public object childCount { get; }
	public object lossyScale { get; }
	public object hasChanged { get; set; }
	public object hierarchyCapacity { get; set; }
	public object hierarchyCount { get; }

	// Methods

	// RVA: 0x73B4DCC
	protected object .ctor() { }

	// RVA: 0x73B4F9C
	public object get_position() { }

	// RVA: 0x73B5064
	public object set_position(object value) { }

	// RVA: 0x73B513C
	public object SetPositionOpt(object pos) { }

	// RVA: 0x73B399C
	public object get_localPosition() { }

	// RVA: 0x73B3ACC
	public object set_localPosition(object value) { }

	// RVA: 0x73B52DC
	public object SetLocalPositionOpt(object pos) { }

	// RVA: 0x73B53B4
	public object get_eulerAngles() { }

	// RVA: 0x73B549C
	public object set_eulerAngles(object value) { }

	// RVA: 0x73B5588
	public object get_localEulerAngles() { }

	// RVA: 0x73B5670
	public object set_localEulerAngles(object value) { }

	// RVA: 0x73B575C
	public object get_right() { }

	// RVA: 0x73B581C
	public object set_right(object value) { }

	// RVA: 0x73B58E4
	public object get_up() { }

	// RVA: 0x73B59A4
	public object set_up(object value) { }

	// RVA: 0x73B5A6C
	public object get_forward() { }

	// RVA: 0x73B5B2C
	public object set_forward(object value) { }

	// RVA: 0x73B543C
	public object get_rotation() { }

	// RVA: 0x73B5514
	public object set_rotation(object value) { }

	// RVA: 0x73B5610
	public object get_localRotation() { }

	// RVA: 0x73B56E8
	public object set_localRotation(object value) { }

	// RVA: 0x73B5D1C
	public object get_localScale() { }

	// RVA: 0x73B5DE4
	public object set_localScale(object value) { }

	// RVA: 0x73B4CF4
	public object get_parent() { }

	// RVA: 0x73B5F0C
	public object set_parent(object value) { }

	// RVA: 0x73B5EBC
	internal object get_parentInternal() { }

	// RVA: 0x73B5FF4
	internal object set_parentInternal(object value) { }

	// RVA: 0x73B6060
	private object GetParent() { }

	// RVA: 0x73B60B0
	public object SetParent(object p) { }

	// RVA: 0x73B611C
	public object SetParent(object parent, object worldPositionStays) { }

	// RVA: 0x73B6188
	public object IsOddNegativeScaleTransform() { }

	// RVA: 0x73B61D8
	public object get_worldToLocalMatrix() { }

	// RVA: 0x73B4580
	public object get_localToWorldMatrix() { }

	// RVA: 0x73B631C
	public object SetPositionAndRotation(object position, object rotation) { }

	// RVA: 0x73B63F0
	public object SetLocalPositionAndRotation(object localPosition, object localRotation) { }

	// RVA: 0x73B64C4
	public object GetPositionAndRotation(object position, object rotation) { }

	// RVA: 0x73B6530
	public object GetLocalPositionAndRotation(object localPosition, object localRotation) { }

	// RVA: 0x73B659C
	public object Translate(object translation, object relativeTo) { }

	// RVA: 0x73B6774
	public object Translate(object translation) { }

	// RVA: 0x73B677C
	public object Translate(object x, object y, object z, object relativeTo) { }

	// RVA: 0x73B6780
	public object Translate(object x, object y, object z) { }

	// RVA: 0x73B6788
	public object Translate(object translation, object relativeTo) { }

	// RVA: 0x73B69AC
	public object Translate(object x, object y, object z, object relativeTo) { }

	// RVA: 0x73B69B0
	public object Rotate(object eulers, object relativeTo) { }

	// RVA: 0x73B6D9C
	public object Rotate(object eulers) { }

	// RVA: 0x73B6DA4
	public object Rotate(object xAngle, object yAngle, object zAngle, object relativeTo) { }

	// RVA: 0x73B6DA8
	public object Rotate(object xAngle, object yAngle, object zAngle) { }

	// RVA: 0x73B6DB0
	internal object RotateAroundInternal(object axis, object angle) { }

	// RVA: 0x73B6E94
	public object Rotate(object axis, object angle, object relativeTo) { }

	// RVA: 0x73B6FE0
	public object Rotate(object axis, object angle) { }

	// RVA: 0x73B6FE8
	public object RotateAround(object point, object axis, object angle) { }

	// RVA: 0x73B7140
	public object LookAt(object target, object worldUp) { }

	// RVA: 0x73B7328
	public object LookAt(object target) { }

	// RVA: 0x73B72C0
	public object LookAt(object worldPosition, object worldUp) { }

	// RVA: 0x73B7548
	public object LookAt(object worldPosition) { }

	// RVA: 0x73B74E0
	private object Internal_LookAt(object worldPosition, object worldUp) { }

	// RVA: 0x73B6704
	public object TransformDirection(object direction) { }

	// RVA: 0x73B76E0
	public object TransformDirection(object x, object y, object z) { }

	// RVA: 0x73B7750
	public object InverseTransformDirection(object direction) { }

	// RVA: 0x73B782C
	public object InverseTransformDirection(object x, object y, object z) { }

	// RVA: 0x73B789C
	public object TransformVector(object vector) { }

	// RVA: 0x73B7978
	public object TransformVector(object x, object y, object z) { }

	// RVA: 0x73B79E8
	public object InverseTransformVector(object vector) { }

	// RVA: 0x73B7AC4
	public object InverseTransformVector(object x, object y, object z) { }

	// RVA: 0x73B7B34
	public object TransformPoint(object position) { }

	// RVA: 0x73B7C10
	public object TransformPoint(object x, object y, object z) { }

	// RVA: 0x73B7C80
	public object InverseTransformPoint(object position) { }

	// RVA: 0x73B7D5C
	public object InverseTransformPoint(object x, object y, object z) { }

	// RVA: 0x73B7DCC
	public object get_root() { }

	// RVA: 0x73B7E1C
	private object GetRoot() { }

	// RVA: 0x73B7E6C
	public object get_childCount() { }

	// RVA: 0x73B7EBC
	public object DetachChildren() { }

	// RVA: 0x73B7F0C
	public object SetAsFirstSibling() { }

	// RVA: 0x73B7F5C
	public object SetAsLastSibling() { }

	// RVA: 0x73B7FAC
	public object SetSiblingIndex(object index) { }

	// RVA: 0x73B8010
	public object GetSiblingIndex() { }

	// RVA: 0x73B8060
	private static object FindRelativeTransformWithPath(object transform, object path, object isActiveOnly) { }

	// RVA: 0x73B80CC
	public object Find(object n) { }

	// RVA: 0x73B8184
	public object get_lossyScale() { }

	// RVA: 0x73B824C
	public object IsChildOf(object parent) { }

	// RVA: 0x73B82B0
	public object get_hasChanged() { }

	// RVA: 0x73B8300
	public object set_hasChanged(object value) { }

	// RVA: 0x73B8364
	public object FindChild(object n) { }

	// RVA: 0x73B8368
	public object GetEnumerator() { }

	// RVA: 0x73B840C
	public object GetChild(object index) { }

	// RVA: 0x73B8470
	public object get_hierarchyCapacity() { }

	// RVA: 0x73B8510
	public object set_hierarchyCapacity(object value) { }

	// RVA: 0x73B84C0
	private object internal_getHierarchyCapacity() { }

	// RVA: 0x73B8574
	private object internal_setHierarchyCapacity(object value) { }

	// RVA: 0x73B85D8
	public object get_hierarchyCount() { }

	// RVA: 0x73B8628
	private object internal_getHierarchyCount() { }

	// RVA: 0x73B8678
	public object GetLocalPositionInThread() { }

	// RVA: 0x73B8740
	public object SetLocalPositionInThread(object pos) { }

	// RVA: 0x73B8818
	public object GetLocalRotationInThread() { }

	// RVA: 0x73B88DC
	public object SetLocalRotationInThread(object quat) { }

	// RVA: 0x73B89B4
	public object GetPositionInThread() { }

	// RVA: 0x73B8A7C
	public object SetPositionInThread(object pos) { }

	// RVA: 0x73B8B54
	public object GetRotationInThread() { }

	// RVA: 0x73B8C18
	public object SetRotationInThread(object quat) { }

	// RVA: 0x73B8CF0
	public object GetLocalScaleInThread() { }

	// RVA: 0x73B8DB8
	public object SetLocalScaleInThread(object scale) { }

	// RVA: 0x73B8E90
	public object GetWorldScaleInThread() { }

	// RVA: 0x73B5000
	private object get_position_Injected(object ret) { }

	// RVA: 0x73B50D8
	private object set_position_Injected(object value) { }

	// RVA: 0x73B51B0
	private object SetPositionOpt_Injected(object pos) { }

	// RVA: 0x73B5214
	private object get_localPosition_Injected(object ret) { }

	// RVA: 0x73B5278
	private object set_localPosition_Injected(object value) { }

	// RVA: 0x73B5350
	private object SetLocalPositionOpt_Injected(object pos) { }

	// RVA: 0x73B5B8C
	private object get_rotation_Injected(object ret) { }

	// RVA: 0x73B5BF0
	private object set_rotation_Injected(object value) { }

	// RVA: 0x73B5C54
	private object get_localRotation_Injected(object ret) { }

	// RVA: 0x73B5CB8
	private object set_localRotation_Injected(object value) { }

	// RVA: 0x73B5D80
	private object get_localScale_Injected(object ret) { }

	// RVA: 0x73B5E58
	private object set_localScale_Injected(object value) { }

	// RVA: 0x73B6254
	private object get_worldToLocalMatrix_Injected(object ret) { }

	// RVA: 0x73B62B8
	private object get_localToWorldMatrix_Injected(object ret) { }

	// RVA: 0x73B6384
	private object SetPositionAndRotation_Injected(object position, object rotation) { }

	// RVA: 0x73B6458
	private object SetLocalPositionAndRotation_Injected(object localPosition, object localRotation) { }

	// RVA: 0x73B6E1C
	private object RotateAroundInternal_Injected(object axis, object angle) { }

	// RVA: 0x73B7608
	private object Internal_LookAt_Injected(object worldPosition, object worldUp) { }

	// RVA: 0x73B7674
	private object TransformDirection_Injected(object direction, object ret) { }

	// RVA: 0x73B77C0
	private object InverseTransformDirection_Injected(object direction, object ret) { }

	// RVA: 0x73B790C
	private object TransformVector_Injected(object vector, object ret) { }

	// RVA: 0x73B7A58
	private object InverseTransformVector_Injected(object vector, object ret) { }

	// RVA: 0x73B7BA4
	private object TransformPoint_Injected(object position, object ret) { }

	// RVA: 0x73B7CF0
	private object InverseTransformPoint_Injected(object position, object ret) { }

	// RVA: 0x73B81E8
	private object get_lossyScale_Injected(object ret) { }

	// RVA: 0x73B86DC
	private object GetLocalPositionInThread_Injected(object ret) { }

	// RVA: 0x73B87B4
	private object SetLocalPositionInThread_Injected(object pos) { }

	// RVA: 0x73B8878
	private object GetLocalRotationInThread_Injected(object ret) { }

	// RVA: 0x73B8950
	private object SetLocalRotationInThread_Injected(object quat) { }

	// RVA: 0x73B8A18
	private object GetPositionInThread_Injected(object ret) { }

	// RVA: 0x73B8AF0
	private object SetPositionInThread_Injected(object pos) { }

	// RVA: 0x73B8BB4
	private object GetRotationInThread_Injected(object ret) { }

	// RVA: 0x73B8C8C
	private object SetRotationInThread_Injected(object quat) { }

	// RVA: 0x73B8D54
	private object GetLocalScaleInThread_Injected(object ret) { }

	// RVA: 0x73B8E2C
	private object SetLocalScaleInThread_Injected(object scale) { }

	// RVA: 0x73B8EF4
	private object GetWorldScaleInThread_Injected(object ret) { }

}

// Namespace: UnityEngine
public enum SpriteMaskInteraction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object VisibleInsideMask;
	public const object VisibleOutsideMask;
}

// Namespace: UnityEngine
public sealed class SpriteRenderer
{

	// Fields
	private object m_SpriteChangeEvent; // 0x10

	// Properties
	public object sprite { get; set; }
	public object color { get; set; }

	// Methods

	// RVA: 0x73B9050
	private object InvokeSpriteChanged() { }

	// RVA: 0x73B914C
	public object get_sprite() { }

	// RVA: 0x73B919C
	public object set_sprite(object value) { }

	// RVA: 0x73B9200
	public object get_color() { }

	// RVA: 0x73B92C4
	public object set_color(object value) { }

	// RVA: 0x73B9260
	private object get_color_Injected(object ret) { }

	// RVA: 0x73B9338
	private object set_color_Injected(object value) { }

}

// Namespace: UnityEngine
public enum SpriteMeshType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FullRect;
	public const object Tight;
}

// Namespace: UnityEngine
public enum SpritePackingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Tight;
	public const object Rectangle;
}

// Namespace: UnityEngine
public enum SpritePackingRotation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object FlipHorizontal;
	public const object FlipVertical;
	public const object Rotate180;
	public const object Any;
}

// Namespace: UnityEngine
public struct SecondarySpriteTexture
{

	// Fields
	public object name; // 0xFFFFFFFFFFFFFFF8
	public object texture; // 0x0
}

// Namespace: UnityEngine
public sealed class Sprite
{

	// Properties
	public object bounds { get; }
	public object rect { get; }
	public object border { get; }
	public object texture { get; }
	public object pixelsPerUnit { get; }
	public object associatedAlphaSplitTexture { get; }
	public object pivot { get; }
	public object packed { get; }
	public object packingMode { get; }
	public object packingRotation { get; }
	public object textureRect { get; }
	public object vertices { get; }
	public object triangles { get; }
	public object uv { get; }

	// Methods

	// RVA: 0x73B93D8
	public object .ctor() { }

	// RVA: 0x73B9460
	internal object GetPackingMode() { }

	// RVA: 0x73B94B0
	internal object GetPackingRotation() { }

	// RVA: 0x73B9500
	internal object GetPacked() { }

	// RVA: 0x73B9550
	internal object GetTextureRect() { }

	// RVA: 0x73B9614
	internal object GetInnerUVs() { }

	// RVA: 0x73B96D8
	internal object GetOuterUVs() { }

	// RVA: 0x73B979C
	internal object GetPadding() { }

	// RVA: 0x73B9860
	internal static object CreateSprite(object texture, object rect, object pivot, object pixelsPerUnit, object extrude, object meshType, object border, object generateFallbackPhysicsShape, object secondaryTexture) { }

	// RVA: 0x73B99BC
	public object get_bounds() { }

	// RVA: 0x73B9A98
	public object get_rect() { }

	// RVA: 0x73B9B5C
	public object get_border() { }

	// RVA: 0x73B9C20
	public object get_texture() { }

	// RVA: 0x73B9C70
	public object get_pixelsPerUnit() { }

	// RVA: 0x73B9CC0
	public object get_associatedAlphaSplitTexture() { }

	// RVA: 0x73B9D10
	public object get_pivot() { }

	// RVA: 0x73B9DD0
	public object get_packed() { }

	// RVA: 0x73B9E38
	public object get_packingMode() { }

	// RVA: 0x73B9E88
	public object get_packingRotation() { }

	// RVA: 0x73B9ED8
	public object get_textureRect() { }

	// RVA: 0x73B9F38
	public object get_vertices() { }

	// RVA: 0x73B9F88
	public object get_triangles() { }

	// RVA: 0x73B9FD8
	public object get_uv() { }

	// RVA: 0x73BA028
	public static object Create(object texture, object rect, object pivot, object pixelsPerUnit, object extrude, object meshType, object border, object generateFallbackPhysicsShape) { }

	// RVA: 0x73BA038
	public static object Create(object texture, object rect, object pivot, object pixelsPerUnit, object extrude, object meshType, object border, object generateFallbackPhysicsShape, object secondaryTextures) { }

	// RVA: 0x73BA5F0
	public static object Create(object texture, object rect, object pivot, object pixelsPerUnit, object extrude, object meshType, object border) { }

	// RVA: 0x73BA604
	public static object Create(object texture, object rect, object pivot, object pixelsPerUnit, object extrude, object meshType) { }

	// RVA: 0x73BA6FC
	public static object Create(object texture, object rect, object pivot, object pixelsPerUnit, object extrude) { }

	// RVA: 0x73BA7E8
	public static object Create(object texture, object rect, object pivot, object pixelsPerUnit) { }

	// RVA: 0x73BA8D0
	public static object Create(object texture, object rect, object pivot) { }

	// RVA: 0x73B95B0
	private object GetTextureRect_Injected(object ret) { }

	// RVA: 0x73B9674
	private object GetInnerUVs_Injected(object ret) { }

	// RVA: 0x73B9738
	private object GetOuterUVs_Injected(object ret) { }

	// RVA: 0x73B97FC
	private object GetPadding_Injected(object ret) { }

	// RVA: 0x73B9910
	private static object CreateSprite_Injected(object texture, object rect, object pivot, object pixelsPerUnit, object extrude, object meshType, object border, object generateFallbackPhysicsShape, object secondaryTexture) { }

	// RVA: 0x73B9A34
	private object get_bounds_Injected(object ret) { }

	// RVA: 0x73B9AF8
	private object get_rect_Injected(object ret) { }

	// RVA: 0x73B9BBC
	private object get_border_Injected(object ret) { }

	// RVA: 0x73B9D6C
	private object get_pivot_Injected(object ret) { }

}

// Namespace: UnityEngine._Scripting.APIUpdating
internal class APIUpdaterRuntimeHelpers
{

	// Methods

	// RVA: 0x73BA9B0
	internal static object GetMovedFromAttributeDataForType(object sourceType, object assembly, object nsp, object klass) { }

	// RVA: 0x73BAB2C
	internal static object GetObsoleteTypeRedirection(object sourceType, object assemblyName, object nsp, object className) { }

}

// Namespace: UnityEngine.Sprites
public sealed class DataUtility
{

	// Methods

	// RVA: 0x73BAF00
	public static object GetInnerUV(object sprite) { }

	// RVA: 0x73BAF20
	public static object GetOuterUV(object sprite) { }

	// RVA: 0x73BAF40
	public static object GetPadding(object sprite) { }

	// RVA: 0x73BAF60
	public static object GetMinSize(object sprite) { }

}

// Namespace: UnityEngine.U2D
public struct SpriteBone
{

	// Fields
	private object m_Name; // 0xFFFFFFFFFFFFFFF8
	private object m_Guid; // 0x0
	private object m_Position; // 0x8
	private object m_Rotation; // 0x14
	private object m_Length; // 0x24
	private object m_ParentId; // 0x28
	private object m_Color; // 0x2C
}

// Namespace: UnityEngine.U2D
public class SpriteAtlasManager
{

	// Fields
	private static object atlasRequested; // 0x0
	private static object atlasRegistered; // 0x8

	// Methods

	// RVA: 0x73BB0E8
	private static object RequestAtlas(object tag) { }

	// RVA: 0x73BB1A8
	public static object add_atlasRegistered(object value) { }

	// RVA: 0x73BB27C
	public static object remove_atlasRegistered(object value) { }

	// RVA: 0x73BB350
	private static object PostRegisteredAtlas(object spriteAtlas) { }

	// RVA: 0x73BB3CC
	internal static object Register(object spriteAtlas) { }

}

// Namespace: UnityEngine.U2D
public class SpriteAtlas
{

	// Properties
	public object spriteCount { get; }

	// Methods

	// RVA: 0x73BB41C
	public object get_spriteCount() { }

	// RVA: 0x73BB46C
	public object CanBindTo(object sprite) { }

	// RVA: 0x73BB4D0
	public object GetSprite(object name) { }

	// RVA: 0x73BB534
	public object GetSprites(object sprites) { }

	// RVA: 0x73BB598
	private object GetSpritesScripting(object sprites) { }

}

// Namespace: 
public sealed class ProfilerOutputCallback
{

	// Methods

	// RVA: 0x73BBF64
	public object .ctor(object object, object method) { }

	// RVA: 0x73BC00C
	public virtual object Invoke(object output) { }

}

// Namespace: 
public sealed class threadMonitorANRCallback
{

	// Methods

	// RVA: 0x73BC134
	public object .ctor(object object, object method) { }

	// RVA: 0x73BC1E4
	public virtual object Invoke(object threadName, object threadId, object ctxData) { }

}

// Namespace: UnityEngine.Profiling
public sealed class Profiler
{

	// Fields
	private static object s_ProfilerOutputCallbackHandlerThreaded; // 0x0
	private static readonly object s_ANRCallbackLockObj; // 0x8
	private static object s_ThreadAnrCallbackHandlerThreaded; // 0x10

	// Properties
	public static object supported { get; }
	public static object logFile { set; }
	public static object enableBinaryLog { set; }
	public static object enabled { set; }
	public static object enableAllocationCallstacks { set; }

	// Methods

	// RVA: 0x73BB5FC
	public static object get_supported() { }

	// RVA: 0x73BB63C
	public static object set_logFile(object value) { }

	// RVA: 0x73BB68C
	public static object set_enableBinaryLog(object value) { }

	// RVA: 0x73BB6DC
	public static object set_enabled(object value) { }

	// RVA: 0x73BB72C
	public static object set_enableAllocationCallstacks(object value) { }

	// RVA: 0x73BB77C
	public static object BeginSample(object name) { }

	// RVA: 0x73BB904
	private static object ValidateArguments(object name) { }

	// RVA: 0x73BB8A0
	private static object BeginSampleImpl(object name, object targetObject) { }

	// RVA: 0x73BB984
	public static object EndSample() { }

	// RVA: 0x73BB9C4
	public static object GetRuntimeMemorySize(object o) { }

	// RVA: 0x73BBA78
	public static object GetRuntimeMemorySizeLong(object o) { }

	// RVA: 0x73BBAC8
	public static object GetObjectPathNameString(object o) { }

	// RVA: 0x73BBB18
	public static object GetMonoHeapSizeLong() { }

	// RVA: 0x73BBB58
	public static object GetMonoUsedSizeLong() { }

	// RVA: 0x73BBB98
	public static object GetTotalAllocatedMemoryLong() { }

	// RVA: 0x73BBBD8
	public static object GetTotalReservedMemoryLong() { }

	// RVA: 0x73BBC18
	private static object CallProfilerOutputCallback(object output) { }

	// RVA: 0x73BBCBC
	private static object InvokeThreadAnrCallback(object threadName, object threadId, object ctxData) { }

	// RVA: 0x73BBE2C
	private static object .cctor() { }

}

// Namespace: 
public sealed class EndOfFrameCallback
{

	// Methods

	// RVA: 0x73BC2B8
	public object .ctor(object object, object method) { }

	// RVA: 0x73BC34C
	public virtual object Invoke() { }

}

// Namespace: UnityEngine.Profiling
public sealed class EngineFrameState
{

	// Fields
	private static object s_EndOfFrameCallbackHandler; // 0x0

	// Methods

	// RVA: 0x73BC1F8
	private static object CallEngineFrameStateEndOfFrameCallback() { }

}

// Namespace: UnityEngine.Profiling
public sealed class Recorder
{

	// Fields
	internal static object s_InvalidRecorder; // 0x0
	private object m_RecorderCPU; // 0x8
	private object m_RecorderGPU; // 0x10

	// Properties
	public object isValid { get; }
	public object enabled { set; }

	// Methods

	// RVA: 0x73BC360
	internal object .ctor() { }

	// RVA: 0x73BC368
	internal object .ctor(object handle) { }

	// RVA: 0x73BC430
	protected override object Finalize() { }

	// RVA: 0x73BC4DC
	public object get_isValid() { }

	// RVA: 0x73BC4EC
	public object set_enabled(object value) { }

	// RVA: 0x73BC568
	private object SetEnabled(object state) { }

	// RVA: 0x73BC5E4
	private static object .cctor() { }

}

// Namespace: UnityEngine.Profiling
public class Sampler
{

	// Fields
	internal object m_Ptr; // 0x8
	internal static object s_InvalidSampler; // 0x0

	// Methods

	// RVA: 0x73BC644
	internal object .ctor() { }

	// RVA: 0x73BC64C
	internal object .ctor(object ptr) { }

	// RVA: 0x73BC678
	public object GetRecorder() { }

	// RVA: 0x73BC708
	public static object Get(object name) { }

	// RVA: 0x73BC7C0
	private static object .cctor() { }

}

// Namespace: UnityEngine.Jobs
public interface IJobParallelForTransform
{

	// Methods

	// RVA: -1
	public abstract object Execute(object index, object transform) { }

}

// Namespace: 
private struct TransformJobData
{

	// Fields
	public object TransformAccessArray; // 0x0
	public object IsReadOnly; // 0x0
}

// Namespace: 
public sealed class ExecuteJobFunction
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object jobData, object additionalPtr, object bufferRangePatchData, object ranges, object jobIndex) { }

}

// Namespace: 
internal struct TransformParallelForLoopStruct<T0>
{

	// Fields
	internal static readonly object jobReflectionData; // 0x0

	// Methods

	// RVA: -1
	internal static object Initialize() { }

	// RVA: -1
	public static object Execute(object jobData, object jobData2, object bufferRangePatchData, object ranges, object jobIndex) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.Jobs
public static class IJobParallelForTransformExtensions
{

	// Methods

	// RVA: -1
	public static object EarlyJobInit() { }

	// RVA: -1
	private static object GetReflectionData() { }

	// RVA: -1
	public static object Schedule(object jobData, object transforms, object dependsOn) { }

}

// Namespace: UnityEngine.Jobs
public struct TransformAccess
{

	// Fields
	private object hierarchy; // 0xFFFFFFFFFFFFFFF8
	private object index; // 0x0

	// Properties
	public object position { get; }
	public object rotation { get; }
	public object localToWorldMatrix { get; }

	// Methods

	// RVA: 0x73BC820
	public object get_position() { }

	// RVA: 0x73BC948
	public object get_rotation() { }

	// RVA: 0x73BCA68
	public object get_localToWorldMatrix() { }

	// RVA: 0x73BCBC0
	public object SetPositionAndRotation(object position, object rotation) { }

	// RVA: 0x73BCC28
	private static object SetPositionAndRotation_Internal(object access, object position, object rotation) { }

	// RVA: 0x73BC884
	private static object GetPosition(object access, object p) { }

	// RVA: 0x73BC9A8
	private static object GetRotation(object access, object r) { }

	// RVA: 0x73BCAE4
	private static object GetLocalToWorldMatrix(object access, object m) { }

}

// Namespace: UnityEngine.Jobs
public struct TransformAccessArray
{

	// Fields
	private object m_TransformArray; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object isCreated { get; }

	// Methods

	// RVA: 0x73BCCF8
	public object .ctor(object capacity, object desiredJobCount) { }

	// RVA: 0x73BCD60
	public static object Allocate(object capacity, object desiredJobCount, object array) { }

	// RVA: 0x73BCE98
	public object get_isCreated() { }

	// RVA: 0x73BCEB8
	public object Dispose() { }

	// RVA: 0x73BCFD0
	internal object GetTransformAccessArrayForSchedule() { }

	// RVA: 0x73BCFE0
	public object Add(object transform) { }

	// RVA: 0x73BD10C
	public object RemoveAtSwapBack(object index) { }

	// RVA: 0x73BCE34
	private static object Create(object capacity, object desiredJobCount) { }

	// RVA: 0x73BCF1C
	private static object DestroyTransformAccessArray(object transformArray) { }

	// RVA: 0x73BD044
	private static object Add(object transformArrayIntPtr, object transform) { }

	// RVA: 0x73BD170
	private static object RemoveAtSwapBack(object transformArrayIntPtr, object index) { }

	// RVA: 0x73BD238
	internal static object GetSortedTransformAccess(object transformArrayIntPtr) { }

	// RVA: 0x73BD288
	internal static object GetSortedToUserIndex(object transformArrayIntPtr) { }

}

// Namespace: UnityEngine.Events
public enum PersistentListenerMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object EventDefined;
	public const object Void;
	public const object Object;
	public const object Int;
	public const object Float;
	public const object String;
	public const object Bool;
}

// Namespace: UnityEngine.Events
internal class UnityEventTools
{

	// Methods

	// RVA: 0x73BD2D8
	internal static object TidyAssemblyTypeName(object assemblyTypeName) { }

}

// Namespace: UnityEngine.Events
internal class ArgumentCache
{

	// Fields
	private object m_ObjectArgument; // 0x8
	private object m_ObjectArgumentAssemblyTypeName; // 0x10
	private object m_IntArgument; // 0x18
	private object m_FloatArgument; // 0x1C
	private object m_StringArgument; // 0x20
	private object m_BoolArgument; // 0x28

	// Properties
	public object unityObjectArgument { get; }
	public object unityObjectArgumentAssemblyTypeName { get; }
	public object intArgument { get; }
	public object floatArgument { get; }
	public object stringArgument { get; }
	public object boolArgument { get; }

	// Methods

	// RVA: 0x73BD534
	public object get_unityObjectArgument() { }

	// RVA: 0x73BD53C
	public object get_unityObjectArgumentAssemblyTypeName() { }

	// RVA: 0x73BD544
	public object get_intArgument() { }

	// RVA: 0x73BD54C
	public object get_floatArgument() { }

	// RVA: 0x73BD554
	public object get_stringArgument() { }

	// RVA: 0x73BD55C
	public object get_boolArgument() { }

	// RVA: 0x73BD564
	public object OnBeforeSerialize() { }

	// RVA: 0x73BD58C
	public object OnAfterDeserialize() { }

	// RVA: 0x73BD5B4
	public object .ctor() { }

}

// Namespace: UnityEngine.Events
internal abstract class BaseInvokableCall
{

	// Methods

	// RVA: 0x73BD5BC
	protected object .ctor() { }

	// RVA: 0x73BD5C4
	protected object .ctor(object target, object function) { }

	// RVA: -1
	public abstract object Invoke(object args) { }

	// RVA: -1
	protected static object ThrowOnInvalidArg(object arg) { }

	// RVA: 0x73BD6D8
	protected static object AllowInvoke(object delegate) { }

	// RVA: -1
	public abstract object Find(object targetObj, object method) { }

}

// Namespace: UnityEngine.Events
internal class InvokableCall
{

	// Fields
	private object Delegate; // 0x8

	// Methods

	// RVA: 0x73BD7A0
	private object add_Delegate(object value) { }

	// RVA: 0x73BD844
	private object remove_Delegate(object value) { }

	// RVA: 0x73BD8E8
	public object .ctor(object target, object theFunction) { }

	// RVA: 0x73BDA40
	public object .ctor(object action) { }

	// RVA: 0x73BDAEC
	public override object Invoke(object args) { }

	// RVA: 0x73BDBE4
	public object Invoke() { }

	// RVA: 0x73BDCDC
	public override object Find(object targetObj, object method) { }

}

// Namespace: UnityEngine.Events
internal class InvokableCall<T0>
{

	// Fields
	private object Delegate; // 0x0

	// Methods

	// RVA: -1
	protected object add_Delegate(object value) { }

	// RVA: -1
	protected object remove_Delegate(object value) { }

	// RVA: -1
	public object .ctor(object target, object theFunction) { }

	// RVA: -1
	public object .ctor(object action) { }

	// RVA: -1
	public override object Invoke(object args) { }

	// RVA: -1
	public virtual object Invoke(object args0) { }

	// RVA: -1
	public override object Find(object targetObj, object method) { }

}

// Namespace: UnityEngine.Events
internal class InvokableCall<T0, T1>
{

	// Fields
	private object Delegate; // 0x0

	// Methods

	// RVA: -1
	protected object add_Delegate(object value) { }

	// RVA: -1
	protected object remove_Delegate(object value) { }

	// RVA: -1
	public object .ctor(object target, object theFunction) { }

	// RVA: -1
	public object .ctor(object action) { }

	// RVA: -1
	public override object Invoke(object args) { }

	// RVA: -1
	public object Invoke(object args0, object args1) { }

	// RVA: -1
	public override object Find(object targetObj, object method) { }

}

// Namespace: UnityEngine.Events
internal class InvokableCall<T0, T1, T2>
{

	// Fields
	private object Delegate; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object target, object theFunction) { }

	// RVA: -1
	public override object Invoke(object args) { }

	// RVA: -1
	public object Invoke(object args0, object args1, object args2) { }

	// RVA: -1
	public override object Find(object targetObj, object method) { }

}

// Namespace: UnityEngine.Events
internal class InvokableCall<T0, T1, T2, T3>
{

	// Fields
	private object Delegate; // 0x0

	// Methods

	// RVA: -1
	protected object add_Delegate(object value) { }

	// RVA: -1
	protected object remove_Delegate(object value) { }

	// RVA: -1
	public object .ctor(object target, object theFunction) { }

	// RVA: -1
	public object .ctor(object action) { }

	// RVA: -1
	public override object Invoke(object args) { }

	// RVA: -1
	public object Invoke(object args0, object args1, object args2, object args3) { }

	// RVA: -1
	public override object Find(object targetObj, object method) { }

}

// Namespace: UnityEngine.Events
internal class CachedInvokableCall<T0>
{

	// Fields
	private readonly object m_Arg1; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object target, object theFunction, object argument) { }

	// RVA: -1
	public override object Invoke(object args) { }

	// RVA: -1
	public override object Invoke(object arg0) { }

}

// Namespace: UnityEngine.Events
public enum UnityEventCallState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object EditorAndRuntime;
	public const object RuntimeOnly;
}

// Namespace: UnityEngine.Events
internal class PersistentCall
{

	// Fields
	private object m_Target; // 0x8
	private object m_TargetAssemblyTypeName; // 0x10
	private object m_MethodName; // 0x18
	private object m_Mode; // 0x20
	private object m_Arguments; // 0x28
	private object m_CallState; // 0x30

	// Properties
	public object target { get; }
	public object targetAssemblyTypeName { get; }
	public object methodName { get; }
	public object mode { get; }
	public object arguments { get; }

	// Methods

	// RVA: 0x73BDD6C
	public object get_target() { }

	// RVA: 0x73BDD74
	public object get_targetAssemblyTypeName() { }

	// RVA: 0x73BDE78
	public object get_methodName() { }

	// RVA: 0x73BDE80
	public object get_mode() { }

	// RVA: 0x73BDE88
	public object get_arguments() { }

	// RVA: 0x73BDE90
	public object IsValid() { }

	// RVA: 0x73BDEDC
	public object GetRuntimeCall(object theEvent) { }

	// RVA: 0x73BE4F4
	private static object GetObjectCall(object target, object method, object arguments) { }

	// RVA: 0x73BE9F4
	public object OnBeforeSerialize() { }

	// RVA: 0x73BEA1C
	public object OnAfterDeserialize() { }

	// RVA: 0x73BEA44
	public object .ctor() { }

}

// Namespace: UnityEngine.Events
internal class PersistentCallGroup
{

	// Fields
	private object m_Calls; // 0x8

	// Methods

	// RVA: 0x73BEABC
	public object .ctor() { }

	// RVA: 0x73BEB40
	public object Initialize(object invokableList, object unityEventBase) { }

}

// Namespace: UnityEngine.Events
internal class InvokableCallList
{

	// Fields
	private readonly object m_PersistentCalls; // 0x8
	private readonly object m_RuntimeCalls; // 0x10
	private object m_ExecutingCalls; // 0x18
	private object m_NeedsUpdate; // 0x20

	// Methods

	// RVA: 0x73BED58
	public object AddPersistentInvokableCall(object call) { }

	// RVA: 0x73BEEAC
	public object AddListener(object call) { }

	// RVA: 0x73BEFC0
	public object RemoveListener(object targetObj, object method) { }

	// RVA: 0x73BF384
	public object Clear() { }

	// RVA: 0x73BF44C
	public object ClearPersistent() { }

	// RVA: 0x73BF514
	public object PrepareInvoke() { }

	// RVA: 0x73BF5F0
	public object .ctor() { }

}

// Namespace: UnityEngine.Events
public abstract class UnityEventBase
{

	// Fields
	private object m_Calls; // 0x8
	private object m_PersistentCalls; // 0x10
	private object m_CallsDirty; // 0x18

	// Methods

	// RVA: 0x73BF6A8
	protected object .ctor() { }

	// RVA: 0x73BF7A4
	private object UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize() { }

	// RVA: 0x73BF81C
	private object UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize() { }

	// RVA: -1
	protected abstract object FindMethod_Impl(object name, object targetObjType) { }

	// RVA: -1
	internal abstract object GetDelegate(object target, object theFunction) { }

	// RVA: 0x73BE2A8
	internal object FindMethod(object call) { }

	// RVA: 0x73BF858
	internal object FindMethod(object name, object listenerType, object mode, object argumentType) { }

	// RVA: 0x73BF7E0
	private object DirtyPersistentCalls() { }

	// RVA: 0x73BFEB4
	private object RebuildPersistentCallsIfNeeded() { }

	// RVA: 0x73BFF04
	internal object AddCall(object call) { }

	// RVA: 0x73BFF24
	protected object RemoveListener(object targetObj, object method) { }

	// RVA: 0x73BFF44
	public object RemoveAllListeners() { }

	// RVA: 0x73BFF64
	internal object PrepareInvoke() { }

	// RVA: 0x73BFFC4
	public override object ToString() { }

	// RVA: 0x73BFC20
	public static object GetValidMethodInfo(object objectType, object functionName, object argumentTypes) { }

}

// Namespace: UnityEngine.Events
public sealed class UnityAction
{

	// Methods

	// RVA: 0x73C00D4
	public object .ctor(object object, object method) { }

	// RVA: 0x73C0168
	public virtual object Invoke() { }

}

// Namespace: UnityEngine.Events
public class UnityEvent
{

	// Fields
	private object m_InvokeArray; // 0x20

	// Methods

	// RVA: 0x73C017C
	public object .ctor() { }

	// RVA: 0x73C0184
	public object AddListener(object call) { }

	// RVA: 0x73C02AC
	public object RemoveListener(object call) { }

	// RVA: 0x73C02F8
	protected override object FindMethod_Impl(object name, object targetObjType) { }

	// RVA: 0x73C0360
	internal override object GetDelegate(object target, object theFunction) { }

	// RVA: 0x73C01C0
	private static object GetDelegate(object action) { }

	// RVA: 0x73C03CC
	public object Invoke() { }

}

// Namespace: UnityEngine.Events
public sealed class UnityAction<T0>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg0) { }

}

// Namespace: UnityEngine.Events
public class UnityEvent<T0>
{

	// Fields
	private object m_InvokeArray; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object AddListener(object call) { }

	// RVA: -1
	public object RemoveListener(object call) { }

	// RVA: -1
	protected override object FindMethod_Impl(object name, object targetObjType) { }

	// RVA: -1
	internal override object GetDelegate(object target, object theFunction) { }

	// RVA: -1
	private static object GetDelegate(object action) { }

	// RVA: -1
	public object Invoke(object arg0) { }

}

// Namespace: UnityEngine.Events
public sealed class UnityAction<T0, T1>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg0, object arg1) { }

}

// Namespace: UnityEngine.Events
public class UnityEvent<T0, T1>
{

	// Fields
	private object m_InvokeArray; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object AddListener(object call) { }

	// RVA: -1
	public object RemoveListener(object call) { }

	// RVA: -1
	protected override object FindMethod_Impl(object name, object targetObjType) { }

	// RVA: -1
	internal override object GetDelegate(object target, object theFunction) { }

	// RVA: -1
	private static object GetDelegate(object action) { }

	// RVA: -1
	public object Invoke(object arg0, object arg1) { }

}

// Namespace: UnityEngine.Events
public sealed class UnityAction<T0, T1, T2>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg0, object arg1, object arg2) { }

}

// Namespace: UnityEngine.Events
public class UnityEvent<T0, T1, T2>
{

	// Fields
	private object m_InvokeArray; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	protected override object FindMethod_Impl(object name, object targetObjType) { }

	// RVA: -1
	internal override object GetDelegate(object target, object theFunction) { }

	// RVA: -1
	public object Invoke(object arg0, object arg1, object arg2) { }

}

// Namespace: UnityEngine.Events
public sealed class UnityAction<T0, T1, T2, T3>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg0, object arg1, object arg2, object arg3) { }

}

// Namespace: UnityEngine.Events
public class UnityEvent<T0, T1, T2, T3>
{

	// Fields
	private object m_InvokeArray; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object AddListener(object call) { }

	// RVA: -1
	public object RemoveListener(object call) { }

	// RVA: -1
	protected override object FindMethod_Impl(object name, object targetObjType) { }

	// RVA: -1
	internal override object GetDelegate(object target, object theFunction) { }

	// RVA: -1
	private static object GetDelegate(object action) { }

	// RVA: -1
	public object Invoke(object arg0, object arg1, object arg2, object arg3) { }

}

// Namespace: UnityEngine.Serialization
public class FormerlySerializedAsAttribute
{

	// Fields
	private object m_oldName; // 0x8

	// Methods

	// RVA: 0x73C05DC
	public object .ctor(object oldName) { }

}

// Namespace: 
public enum Mode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Disabled;
	public const object Enabled;
	public const object Manual;
}

// Namespace: UnityEngine.Scripting
public static class GarbageCollector
{

	// Fields
	private static object GCModeChanged; // 0x0

	// Properties
	public static object GCMode { set; }

	// Methods

	// RVA: 0x73C0608
	public static object set_GCMode(object value) { }

	// RVA: 0x73C0748
	private static object SetMode(object mode) { }

	// RVA: 0x73C0708
	private static object GetMode() { }

}

// Namespace: UnityEngine.Scripting
public class PreserveAttribute
{

	// Methods

	// RVA: 0x73C0798
	public object .ctor() { }

}

// Namespace: UnityEngine.Scripting.APIUpdating
internal struct MovedFromAttributeData
{

	// Fields
	public object className; // 0xFFFFFFFFFFFFFFF8
	public object nameSpace; // 0x0
	public object assembly; // 0x8
	public object classHasChanged; // 0x10
	public object nameSpaceHasChanged; // 0x11
	public object assemblyHasChanged; // 0x12
	public object autoUdpateAPI; // 0x13

	// Methods

	// RVA: 0x73C08B0
	public object Set(object autoUpdateAPI, object sourceNamespace, object sourceAssembly, object sourceClassName) { }

}

// Namespace: UnityEngine.Scripting.APIUpdating
public class MovedFromAttribute
{

	// Fields
	internal object data; // 0x8

	// Methods

	// RVA: 0x73C0918
	public object .ctor(object autoUpdateAPI, object sourceNamespace, object sourceAssembly, object sourceClassName) { }

	// RVA: 0x73C098C
	public object .ctor(object sourceNamespace) { }

}

// Namespace: UnityEngine.SceneManagement
public struct Scene
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object handle { get; }
	public object name { get; }
	public object isLoaded { get; }
	public object buildIndex { get; }
	public object rootCount { get; }

	// Methods

	// RVA: 0x73C09D4
	private static object IsValidInternal(object sceneHandle) { }

	// RVA: 0x73C0A24
	private static object GetNameInternal(object sceneHandle) { }

	// RVA: 0x73C0A74
	private static object GetIsLoadedInternal(object sceneHandle) { }

	// RVA: 0x73C0AC4
	private static object GetBuildIndexInternal(object sceneHandle) { }

	// RVA: 0x73C0B14
	private static object GetRootCountInternal(object sceneHandle) { }

	// RVA: 0x73C0B64
	private static object GetRootGameObjectsInternal(object sceneHandle, object resultRootList) { }

	// RVA: 0x73C0BC8
	public object get_handle() { }

	// RVA: 0x73C0BD8
	public object IsValid() { }

	// RVA: 0x73C0C78
	public object get_name() { }

	// RVA: 0x73C0D18
	public object get_isLoaded() { }

	// RVA: 0x73C0DB8
	public object get_buildIndex() { }

	// RVA: 0x73C0E58
	public object get_rootCount() { }

	// RVA: 0x73C0EF8
	public object GetRootGameObjects() { }

	// RVA: 0x73C0FE0
	public object GetRootGameObjects(object rootGameObjects) { }

	// RVA: 0x73C12E4
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x73C12F0
	public override object GetHashCode() { }

	// RVA: 0x73C1300
	public override object Equals(object other) { }

}

// Namespace: UnityEngine.SceneManagement
internal static class SceneManagerAPIInternal
{

	// Methods

	// RVA: 0x73C1448
	public static object GetNumScenesInBuildSettings() { }

	// RVA: 0x73C1488
	public static object LoadSceneAsyncNameIndexInternal(object sceneName, object sceneBuildIndex, object parameters, object mustCompleteNextFrame) { }

	// RVA: 0x73C1578
	public static object UnloadSceneNameIndexInternal(object sceneName, object sceneBuildIndex, object immediately, object options, object outSuccess) { }

	// RVA: 0x73C14F8
	private static object LoadSceneAsyncNameIndexInternal_Injected(object sceneName, object sceneBuildIndex, object parameters, object mustCompleteNextFrame) { }

}

// Namespace: UnityEngine.SceneManagement
public class SceneManagerAPI
{

	// Fields
	private static object s_DefaultAPI; // 0x0
	private static object <overrideAPI>k__BackingField; // 0x8

	// Properties
	internal static object ActiveAPI { get; }
	public static object overrideAPI { get; }

	// Methods

	// RVA: 0x73C1600
	internal static object get_ActiveAPI() { }

	// RVA: 0x73C1700
	public static object get_overrideAPI() { }

	// RVA: 0x73C177C
	protected internal object .ctor() { }

	// RVA: 0x73C1784
	protected internal virtual object GetNumScenesInBuildSettings() { }

	// RVA: 0x73C17C4
	protected internal virtual object LoadSceneAsyncByNameOrIndex(object sceneName, object sceneBuildIndex, object parameters, object mustCompleteNextFrame) { }

	// RVA: 0x73C1830
	protected internal virtual object UnloadSceneAsyncByNameOrIndex(object sceneName, object sceneBuildIndex, object immediately, object options, object outSuccess) { }

	// RVA: 0x73C18A0
	protected internal virtual object LoadFirstScene(object mustLoadAsync) { }

	// RVA: 0x73C18A8
	private static object .cctor() { }

}

// Namespace: UnityEngine.SceneManagement
public class SceneManager
{

	// Fields
	internal static object s_AllowLoadScene; // 0x0
	private static object sceneLoaded; // 0x8
	private static object sceneUnloaded; // 0x10
	private static object activeSceneChanged; // 0x18

	// Properties
	public static object sceneCount { get; }
	public static object loadedSceneCount { get; }
	public static object sceneCountInBuildSettings { get; }

	// Methods

	// RVA: 0x73C1908
	public static object get_sceneCount() { }

	// RVA: 0x73C1948
	public static object get_loadedSceneCount() { }

	// RVA: 0x73C1988
	public static object get_sceneCountInBuildSettings() { }

	// RVA: 0x73C1A28
	public static object GetActiveScene() { }

	// RVA: 0x73C1B20
	public static object SetActiveScene(object scene) { }

	// RVA: 0x73C1C24
	public static object GetSceneAt(object index) { }

	// RVA: 0x73C1D40
	private static object LoadSceneAsyncNameIndexInternal(object sceneName, object sceneBuildIndex, object parameters, object mustCompleteNextFrame) { }

	// RVA: 0x73C1E60
	private static object UnloadSceneNameIndexInternal(object sceneName, object sceneBuildIndex, object immediately, object options, object outSuccess) { }

	// RVA: 0x73C1F98
	internal static object LoadFirstScene_Internal(object async) { }

	// RVA: 0x73C2048
	public static object add_sceneLoaded(object value) { }

	// RVA: 0x73C215C
	public static object remove_sceneLoaded(object value) { }

	// RVA: 0x73C2270
	public static object add_activeSceneChanged(object value) { }

	// RVA: 0x73C2384
	public static object remove_activeSceneChanged(object value) { }

	// RVA: 0x73C2498
	public static object LoadScene(object sceneName, object mode) { }

	// RVA: 0x73C252C
	public static object LoadScene(object sceneName, object parameters) { }

	// RVA: 0x73C2664
	public static object UnloadSceneAsync(object sceneName) { }

	// RVA: 0x73C26E4
	private static object Internal_SceneLoaded(object scene, object mode) { }

	// RVA: 0x73C27B8
	private static object Internal_SceneUnloaded(object scene) { }

	// RVA: 0x73C2884
	private static object Internal_ActiveSceneChanged(object previousActiveScene, object newActiveScene) { }

	// RVA: 0x73C2958
	private static object .cctor() { }

	// RVA: 0x73C1AD0
	private static object GetActiveScene_Injected(object ret) { }

	// RVA: 0x73C1BD4
	private static object SetActiveScene_Injected(object scene) { }

	// RVA: 0x73C1CDC
	private static object GetSceneAt_Injected(object index, object ret) { }

}

// Namespace: UnityEngine.SceneManagement
public enum LoadSceneMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Single;
	public const object Additive;
}

// Namespace: UnityEngine.SceneManagement
public enum LocalPhysicsMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Physics2D;
	public const object Physics3D;
}

// Namespace: UnityEngine.SceneManagement
public struct LoadSceneParameters
{

	// Fields
	private object m_LoadSceneMode; // 0xFFFFFFFFFFFFFFF8
	private object m_LocalPhysicsMode; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x73C2524
	public object .ctor(object mode) { }

}

// Namespace: UnityEngine.SceneManagement
public enum UnloadSceneOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object UnloadAllEmbeddedSceneObjects;
}

// Namespace: UnityEngine.LowLevel
internal struct PlayerLoopSystemInternal
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object updateDelegate; // 0x0
	public object updateFunction; // 0x8
	public object loopConditionFunction; // 0x10
	public object numSubSystems; // 0x18
}

// Namespace: 
public sealed class UpdateFunction
{

	// Methods

	// RVA: 0x73C2B18
	public object .ctor(object object, object method) { }

	// RVA: 0x73C2BAC
	public virtual object Invoke() { }

}

// Namespace: UnityEngine.LowLevel
public struct PlayerLoopSystem
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object subSystemList; // 0x0
	public object updateDelegate; // 0x8
	public object updateFunction; // 0x10
	public object loopConditionFunction; // 0x18

	// Methods

	// RVA: 0x73C2A28
	public override object ToString() { }

}

// Namespace: UnityEngine.LowLevel
public class PlayerLoop
{

	// Methods

	// RVA: 0x73C2BC0
	public static object GetCurrentPlayerLoop() { }

	// RVA: 0x73C2F18
	public static object SetPlayerLoop(object loop) { }

	// RVA: 0x73C3020
	private static object PlayerLoopSystemToInternal(object sys, object internalSys) { }

	// RVA: 0x73C2C70
	private static object InternalToPlayerLoopSystem(object internalSys, object offset) { }

	// RVA: 0x73C2C30
	private static object GetCurrentPlayerLoopInternal() { }

	// RVA: 0x73C3268
	private static object SetPlayerLoopInternal(object loop) { }

}

// Namespace: 
public struct WaitForLastPresentationAndUpdateTime
{
}

// Namespace: UnityEngine.PlayerLoop
public struct TimeUpdate
{
}

// Namespace: 
public struct ProfilerStartFrame
{
}

// Namespace: 
public struct UpdateCameraMotionVectors
{
}

// Namespace: 
public struct DirectorSampleTime
{
}

// Namespace: 
public struct AsyncUploadTimeSlicedUpdate
{
}

// Namespace: 
public struct SynchronizeState
{
}

// Namespace: 
public struct SynchronizeInputs
{
}

// Namespace: 
public struct XREarlyUpdate
{
}

// Namespace: UnityEngine.PlayerLoop
public struct Initialization
{
}

// Namespace: 
public struct PollPlayerConnection
{
}

// Namespace: 
public struct PollHtcsPlayerConnection
{
}

// Namespace: 
public struct GpuTimestamp
{
}

// Namespace: 
public struct AnalyticsCoreStatsUpdate
{
}

// Namespace: 
public struct UnityWebRequestUpdate
{
}

// Namespace: 
public struct UpdateStreamingManager
{
}

// Namespace: 
public struct ExecuteMainThreadJobs
{
}

// Namespace: 
public struct ProcessMouseInWindow
{
}

// Namespace: 
public struct ClearIntermediateRenderers
{
}

// Namespace: 
public struct ClearLines
{
}

// Namespace: 
public struct PresentBeforeUpdate
{
}

// Namespace: 
public struct ResetFrameStatsAfterPresent
{
}

// Namespace: 
public struct UpdateAsyncReadbackManager
{
}

// Namespace: 
public struct UpdateTextureStreamingManager
{
}

// Namespace: 
public struct UpdatePreloading
{
}

// Namespace: 
public struct UpdateContentLoading
{
}

// Namespace: 
public struct RendererNotifyInvisible
{
}

// Namespace: 
public struct PlayerCleanupCachedData
{
}

// Namespace: 
public struct UpdateMainGameViewRect
{
}

// Namespace: 
public struct UpdateCanvasRectTransform
{
}

// Namespace: 
public struct UpdateInputManager
{
}

// Namespace: 
public struct ProcessRemoteInput
{
}

// Namespace: 
public struct XRUpdate
{
}

// Namespace: 
public struct ScriptRunDelayedStartupFrame
{
}

// Namespace: 
public struct UpdateKinect
{
}

// Namespace: 
public struct DeliverIosPlatformEvents
{
}

// Namespace: 
public struct DispatchEventQueueEvents
{
}

// Namespace: 
public struct Physics2DEarlyUpdate
{
}

// Namespace: 
public struct PhysicsResetInterpolatedTransformPosition
{
}

// Namespace: 
public struct SpriteAtlasManagerUpdate
{
}

// Namespace: 
public struct TangoUpdate
{
}

// Namespace: 
public struct ARCoreUpdate
{
}

// Namespace: 
public struct PerformanceAnalyticsUpdate
{
}

// Namespace: UnityEngine.PlayerLoop
public struct EarlyUpdate
{
}

// Namespace: 
public struct ClearLines
{
}

// Namespace: 
public struct DirectorFixedSampleTime
{
}

// Namespace: 
public struct AudioFixedUpdate
{
}

// Namespace: 
public struct ScriptRunBehaviourFixedUpdate
{
}

// Namespace: 
public struct DirectorFixedUpdate
{
}

// Namespace: 
public struct LegacyFixedAnimationUpdate
{
}

// Namespace: 
public struct XRFixedUpdate
{
}

// Namespace: 
public struct PhysicsFixedUpdate
{
}

// Namespace: 
public struct Physics2DFixedUpdate
{
}

// Namespace: 
private struct PhysicsClothFixedUpdate
{
}

// Namespace: 
public struct DirectorFixedUpdatePostPhysics
{
}

// Namespace: 
public struct ScriptRunDelayedFixedFrameRate
{
}

// Namespace: 
public struct NewInputFixedUpdate
{
}

// Namespace: UnityEngine.PlayerLoop
public struct FixedUpdate
{
}

// Namespace: 
public struct PhysicsUpdate
{
}

// Namespace: 
public struct Physics2DUpdate
{
}

// Namespace: 
internal struct PhysicsClothUpdate
{
}

// Namespace: 
public struct CheckTexFieldInput
{
}

// Namespace: 
public struct IMGUISendQueuedEvents
{
}

// Namespace: 
public struct SendMouseEvents
{
}

// Namespace: 
public struct AIUpdate
{
}

// Namespace: 
public struct WindUpdate
{
}

// Namespace: 
public struct UpdateVideo
{
}

// Namespace: 
public struct NewInputUpdate
{
}

// Namespace: UnityEngine.PlayerLoop
public struct PreUpdate
{
}

// Namespace: 
public struct ScriptRunBehaviourUpdate
{
}

// Namespace: 
public struct DirectorUpdate
{
}

// Namespace: 
public struct ScriptRunDelayedDynamicFrameRate
{
}

// Namespace: 
public struct ScriptRunDelayedTasks
{
}

// Namespace: 
public struct NPBDClothManagerUpdateBeforeAnimation
{
}

// Namespace: UnityEngine.PlayerLoop
public struct Update
{
}

// Namespace: 
public struct Physics2DLateUpdate
{
}

// Namespace: 
public struct PhysicsLateUpdate
{
}

// Namespace: 
public struct AIUpdatePostScript
{
}

// Namespace: 
public struct DirectorUpdateAnimationBegin
{
}

// Namespace: 
public struct LegacyAnimationUpdate
{
}

// Namespace: 
public struct DirectorUpdateAnimationEnd
{
}

// Namespace: 
public struct DirectorDeferredEvaluate
{
}

// Namespace: 
public struct UIElementsUpdatePanels
{
}

// Namespace: 
public struct UpdateNetworkManager
{
}

// Namespace: 
public struct UpdateMasterServerInterface
{
}

// Namespace: 
public struct EndGraphicsJobsAfterScriptUpdate
{
}

// Namespace: 
public struct ParticleSystemBeginUpdateAll
{
}

// Namespace: 
public struct ScriptRunBehaviourLateUpdate
{
}

// Namespace: 
public struct ConstraintManagerUpdate
{
}

// Namespace: UnityEngine.PlayerLoop
public struct PreLateUpdate
{
}

// Namespace: 
public struct PlayerSendFrameStarted
{
}

// Namespace: 
public struct UpdateRectTransform
{
}

// Namespace: 
public struct UpdateCanvasRectTransform
{
}

// Namespace: 
public struct PlayerUpdateCanvases
{
}

// Namespace: 
public struct UpdateAudio
{
}

// Namespace: 
public struct UpdateVideo
{
}

// Namespace: 
public struct DirectorLateUpdate
{
}

// Namespace: 
public struct ScriptRunDelayedDynamicFrameRate
{
}

// Namespace: 
public struct VFXUpdate
{
}

// Namespace: 
public struct ParticleSystemEndUpdateAll
{
}

// Namespace: 
public struct EndGraphicsJobsAfterScriptLateUpdate
{
}

// Namespace: 
public struct UpdateSubstance
{
}

// Namespace: 
public struct UpdateCustomRenderTextures
{
}

// Namespace: 
public struct XRPostLateUpdate
{
}

// Namespace: 
public struct UpdateAllRenderers
{
}

// Namespace: 
public struct UpdateLightProbeProxyVolumes
{
}

// Namespace: 
public struct EnlightenRuntimeUpdate
{
}

// Namespace: 
public struct UpdateAllSkinnedMeshes
{
}

// Namespace: 
public struct ProcessWebSendMessages
{
}

// Namespace: 
public struct SortingGroupsUpdate
{
}

// Namespace: 
public struct UpdateVideoTextures
{
}

// Namespace: 
public struct DirectorRenderImage
{
}

// Namespace: 
public struct PlayerEmitCanvasGeometry
{
}

// Namespace: 
internal struct PlayerRenderUIEBatchModeOffscreen
{
}

// Namespace: 
public struct FinishFrameRendering
{
}

// Namespace: 
public struct BatchModeUpdate
{
}

// Namespace: 
public struct PlayerSendFrameComplete
{
}

// Namespace: 
public struct UpdateCaptureScreenshot
{
}

// Namespace: 
public struct PresentAfterDraw
{
}

// Namespace: 
public struct ClearImmediateRenderers
{
}

// Namespace: 
public struct XRPostPresent
{
}

// Namespace: 
public struct UpdateResolution
{
}

// Namespace: 
public struct InputEndFrame
{
}

// Namespace: 
public struct GUIClearEvents
{
}

// Namespace: 
public struct ShaderHandleErrors
{
}

// Namespace: 
public struct ResetInputAxis
{
}

// Namespace: 
public struct ThreadedLoadingDebug
{
}

// Namespace: 
public struct ProfilerSynchronizeStats
{
}

// Namespace: 
public struct MemoryFrameMaintenance
{
}

// Namespace: 
public struct ExecuteGameCenterCallbacks
{
}

// Namespace: 
public struct XRPreEndFrame
{
}

// Namespace: 
public struct ProfilerEndFrame
{
}

// Namespace: 
public struct GraphicsWarmupPreloadedShaders
{
}

// Namespace: 
public struct ProcessShaderWarmUpMainLoop
{
}

// Namespace: 
public struct PlayerSendFramePostPresent
{
}

// Namespace: 
public struct PhysicsSkinnedClothBeginUpdate
{
}

// Namespace: 
public struct PhysicsSkinnedClothFinishUpdate
{
}

// Namespace: 
public struct TriggerEndOfFrameCallbacks
{
}

// Namespace: 
public struct ObjectDispatcherPostLateUpdate
{
}

// Namespace: 
public struct NPBDClothManagerBeginUpdate
{
}

// Namespace: 
public struct NPBDClothManagerEndUpdate
{
}

// Namespace: UnityEngine.PlayerLoop
public struct PostLateUpdate
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__5_0() { }

	// RVA: -1
	internal object <.cctor>b__5_1(object l) { }

}

// Namespace: UnityEngine.Pool
public class CollectionPool<T0, T1>
{

	// Fields
	internal static readonly object s_Pool; // 0x0

	// Methods

	// RVA: -1
	public static object Get() { }

	// RVA: -1
	public static object Get(object value) { }

	// RVA: -1
	public static object Release(object toRelease) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.Pool
public interface IObjectPool<T0>
{

	// Methods

	// RVA: -1
	public abstract object Release(object element) { }

}

// Namespace: UnityEngine.Pool
public class ObjectPool<T0>
{

	// Fields
	internal readonly object m_List; // 0x0
	private readonly object m_CreateFunc; // 0x0
	private readonly object m_ActionOnGet; // 0x0
	private readonly object m_ActionOnRelease; // 0x0
	private readonly object m_ActionOnDestroy; // 0x0
	private readonly object m_MaxSize; // 0x0
	internal object m_CollectionCheck; // 0x0
	private object <CountAll>k__BackingField; // 0x0

	// Properties
	public object CountAll { get; set; }
	public object CountInactive { get; }

	// Methods

	// RVA: -1
	public object get_CountAll() { }

	// RVA: -1
	private object set_CountAll(object value) { }

	// RVA: -1
	public object get_CountInactive() { }

	// RVA: -1
	public object .ctor(object createFunc, object actionOnGet, object actionOnRelease, object actionOnDestroy, object collectionCheck, object defaultCapacity, object maxSize) { }

	// RVA: -1
	public object Get() { }

	// RVA: -1
	public object Get(object v) { }

	// RVA: -1
	public object Release(object element) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: UnityEngine.Pool
public struct PooledObject<T0>
{

	// Fields
	private readonly object m_ToReturn; // 0x0
	private readonly object m_Pool; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor(object value, object pool) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

}

// Namespace: UnityEngine.Networking.PlayerConnection
public class MessageEventArgs
{

	// Fields
	public object playerId; // 0x8
	public object data; // 0x10

	// Methods

	// RVA: 0x73C32B8
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass12_0
{

	// Fields
	public object messageId; // 0x8

	// Methods

	// RVA: 0x73C3AC8
	public object .ctor() { }

	// RVA: 0x73C56F0
	internal object <Register>b__0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass13_0
{

	// Fields
	public object messageId; // 0x8

	// Methods

	// RVA: 0x73C3FEC
	public object .ctor() { }

	// RVA: 0x73C5778
	internal object <Unregister>b__0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass20_0
{

	// Fields
	public object msgReceived; // 0x8

	// Methods

	// RVA: 0x73C4B34
	public object .ctor() { }

	// RVA: 0x73C57D0
	internal object <BlockUntilRecvMsg>b__0(object args) { }

}

// Namespace: UnityEngine.Networking.PlayerConnection
public class PlayerConnection
{

	// Fields
	internal static object connectionNative; // 0x0
	private object m_PlayerEditorConnectionEvents; // 0x10
	private object m_connectedPlayers; // 0x18
	private object m_IsInitilized; // 0x20
	private static object s_Instance; // 0x8

	// Properties
	public static object instance { get; }
	public object isConnected { get; }

	// Methods

	// RVA: 0x73C32C0
	public static object get_instance() { }

	// RVA: 0x73C3484
	public object get_isConnected() { }

	// RVA: 0x73C33EC
	private static object CreateInstance() { }

	// RVA: 0x73C3680
	public object OnEnable() { }

	// RVA: 0x73C35E8
	private object GetConnectionNativeApi() { }

	// RVA: 0x73C37D8
	public object Register(object messageId, object callback) { }

	// RVA: 0x73C3DA8
	public object Unregister(object messageId, object callback) { }

	// RVA: 0x73C418C
	public object RegisterConnection(object callback) { }

	// RVA: 0x73C434C
	public object RegisterDisconnection(object callback) { }

	// RVA: 0x73C43CC
	public object UnregisterConnection(object callback) { }

	// RVA: 0x73C444C
	public object UnregisterDisconnection(object callback) { }

	// RVA: 0x73C44CC
	public object Send(object messageId, object data) { }

	// RVA: 0x73C46A8
	public object TrySend(object messageId, object data) { }

	// RVA: 0x73C4884
	public object BlockUntilRecvMsg(object messageId, object timeout) { }

	// RVA: 0x73C4B3C
	public object DisconnectAll() { }

	// RVA: 0x73C4CA0
	private static object MessageCallbackInternal(object data, object size, object guid, object messageId) { }

	// RVA: 0x73C52F4
	private static object ConnectedCallbackInternal(object playerId) { }

	// RVA: 0x73C5458
	private static object DisconnectedCallback(object playerId) { }

	// RVA: 0x73C5528
	public object .ctor() { }

}

// Namespace: 
public class MessageEvent
{

	// Methods

	// RVA: 0x73C58C0
	public object .ctor() { }

}

// Namespace: 
public class ConnectionChangeEvent
{

	// Methods

	// RVA: 0x73C5920
	public object .ctor() { }

}

// Namespace: 
public class MessageTypeSubscribers
{

	// Fields
	private object m_messageTypeId; // 0x8
	public object subscriberCount; // 0x10
	public object messageCallback; // 0x18

	// Properties
	public object MessageTypeId { get; set; }

	// Methods

	// RVA: 0x73C5748
	public object get_MessageTypeId() { }

	// RVA: 0x73C5888
	public object set_MessageTypeId(object value) { }

	// RVA: 0x73C57EC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object messageId; // 0x8

	// Methods

	// RVA: 0x73C57DC
	public object .ctor() { }

	// RVA: 0x73C5978
	internal object <InvokeMessageIdSubscribers>b__0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass7_0
{

	// Fields
	public object messageId; // 0x8

	// Methods

	// RVA: 0x73C57E4
	public object .ctor() { }

	// RVA: 0x73C59D0
	internal object <AddAndCreate>b__0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object messageId; // 0x8

	// Methods

	// RVA: 0x73C5918
	public object .ctor() { }

	// RVA: 0x73C5A28
	internal object <UnregisterManagedCallback>b__0(object x) { }

}

// Namespace: UnityEngine.Networking.PlayerConnection
internal class PlayerEditorConnectionEvents
{

	// Fields
	public object messageTypeSubscribers; // 0x8
	public object connectionEvent; // 0x10
	public object disconnectionEvent; // 0x18

	// Methods

	// RVA: 0x73C4DD8
	public object InvokeMessageIdSubscribers(object messageId, object data, object playerId) { }

	// RVA: 0x73C3AD0
	public object AddAndCreate(object messageId) { }

	// RVA: 0x73C3FF4
	public object UnregisterManagedCallback(object messageId, object callback) { }

	// RVA: 0x73C55D8
	public object .ctor() { }

}

// Namespace: UnityEngine.iOS
public enum DeviceGeneration
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object iPhone;
	public const object iPhone3G;
	public const object iPhone3GS;
	public const object iPodTouch1Gen;
	public const object iPodTouch2Gen;
	public const object iPodTouch3Gen;
	public const object iPad1Gen;
	public const object iPhone4;
	public const object iPodTouch4Gen;
	public const object iPad2Gen;
	public const object iPhone4S;
	public const object iPad3Gen;
	public const object iPhone5;
	public const object iPodTouch5Gen;
	public const object iPadMini1Gen;
	public const object iPad4Gen;
	public const object iPhone5C;
	public const object iPhone5S;
	public const object iPadAir1;
	public const object iPadMini2Gen;
	public const object iPhone6;
	public const object iPhone6Plus;
	public const object iPadMini3Gen;
	public const object iPadAir2;
	public const object iPhone6S;
	public const object iPhone6SPlus;
	public const object iPadPro1Gen;
	public const object iPadMini4Gen;
	public const object iPhoneSE1Gen;
	public const object iPadPro10Inch1Gen;
	public const object iPhone7;
	public const object iPhone7Plus;
	public const object iPodTouch6Gen;
	public const object iPad5Gen;
	public const object iPadPro2Gen;
	public const object iPadPro10Inch2Gen;
	public const object iPhone8;
	public const object iPhone8Plus;
	public const object iPhoneX;
	public const object iPhoneXS;
	public const object iPhoneXSMax;
	public const object iPhoneXR;
	public const object iPadPro11Inch;
	public const object iPadPro3Gen;
	public const object iPad6Gen;
	public const object iPadAir3Gen;
	public const object iPadMini5Gen;
	public const object iPhone11;
	public const object iPhone11Pro;
	public const object iPhone11ProMax;
	public const object iPodTouch7Gen;
	public const object iPad7Gen;
	public const object iPhoneSE2Gen;
	public const object iPadPro11Inch2Gen;
	public const object iPadPro4Gen;
	public const object iPhone12Mini;
	public const object iPhone12;
	public const object iPhone12Pro;
	public const object iPhone12ProMax;
	public const object iPad8Gen;
	public const object iPadAir4Gen;
	public const object iPad9Gen;
	public const object iPadMini6Gen;
	public const object iPhone13;
	public const object iPhone13Mini;
	public const object iPhone13Pro;
	public const object iPhone13ProMax;
	public const object iPadPro5Gen;
	public const object iPadPro11Inch3Gen;
	public const object iPhoneSE3Gen;
	public const object iPadAir5Gen;
	public const object iPhone14;
	public const object iPhone14Plus;
	public const object iPhone14Pro;
	public const object iPhone14ProMax;
	public const object iPadPro6Gen;
	public const object iPadPro11Inch4Gen;
	public const object iPad10Gen;
	public const object iPhoneUnknown;
	public const object iPadUnknown;
	public const object iPodTouchUnknown;
}

// Namespace: UnityEngine.iOS
public sealed class Device
{

	// Properties
	public static object systemVersion { get; }
	public static object generation { get; }

	// Methods

	// RVA: 0x73C5A80
	public static object get_systemVersion() { }

	// RVA: 0x73C5AC0
	public static object get_generation() { }

	// RVA: 0x73C5B00
	public static object SetNoBackupFlag(object path) { }

}

// Namespace: UnityEngine.Internal
public class DefaultValueAttribute
{

	// Fields
	private object DefaultValue; // 0x8

	// Properties
	public object Value { get; }

	// Methods

	// RVA: 0x73C5B50
	public object .ctor(object value) { }

	// RVA: 0x73C5B7C
	public object get_Value() { }

	// RVA: 0x73C5B84
	public override object Equals(object obj) { }

	// RVA: 0x73C5C60
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Internal
public class ExcludeFromDocsAttribute
{

	// Methods

	// RVA: 0x73C5CB0
	public object .ctor() { }

}

// Namespace: UnityEngine.Rendering
public struct AsyncGPUReadbackRequest
{

	// Fields
	internal object m_Ptr; // 0xFFFFFFFFFFFFFFF8
	internal object m_Version; // 0x0

	// Properties
	public object done { get; }
	public object hasError { get; }
	public object layerCount { get; }
	public object layerDataSize { get; }

	// Methods

	// RVA: 0x73C5CB8
	public object WaitForCompletion() { }

	// RVA: -1
	public object GetData(object layer) { }

	// RVA: 0x73C5DA8
	public object get_done() { }

	// RVA: 0x73C5E98
	public object get_hasError() { }

	// RVA: 0x73C5F88
	public object get_layerCount() { }

	// RVA: 0x73C6078
	public object get_layerDataSize() { }

	// RVA: 0x73C5DF8
	private object IsDone() { }

	// RVA: 0x73C5EE8
	private object HasError() { }

	// RVA: 0x73C5FD8
	private object GetLayerCount() { }

	// RVA: 0x73C60C8
	private object GetLayerDataSize() { }

	// RVA: 0x73C63E8
	internal object SetScriptingCallback(object callback) { }

	// RVA: 0x73C6514
	private object GetDataRaw(object layer) { }

	// RVA: 0x73C5D08
	private static object WaitForCompletion_Injected(object _unity_self) { }

	// RVA: 0x73C6168
	private static object IsDone_Injected(object _unity_self) { }

	// RVA: 0x73C6208
	private static object HasError_Injected(object _unity_self) { }

	// RVA: 0x73C62A8
	private static object GetLayerCount_Injected(object _unity_self) { }

	// RVA: 0x73C6348
	private static object GetLayerDataSize_Injected(object _unity_self) { }

	// RVA: 0x73C644C
	private static object SetScriptingCallback_Injected(object _unity_self, object callback) { }

	// RVA: 0x73C6578
	private static object GetDataRaw_Injected(object _unity_self, object layer) { }

}

// Namespace: UnityEngine.Rendering
internal struct AsyncRequestNativeArrayData
{

	// Fields
	public object nativeArrayBuffer; // 0xFFFFFFFFFFFFFFF8
	public object lengthInBytes; // 0x0

	// Methods

	// RVA: -1
	public static object CreateAndCheckAccess(object array) { }

}

// Namespace: UnityEngine.Rendering
public static class AsyncGPUReadback
{

	// Methods

	// RVA: -1
	public static object RequestIntoNativeArray(object output, object src, object callback) { }

	// RVA: -1
	public static object RequestIntoNativeArray(object output, object src, object mipIndex, object callback) { }

	// RVA: 0x73C6640
	private static object Request_Internal_ComputeBuffer_1(object buffer, object data) { }

	// RVA: 0x73C6718
	private static object Request_Internal_Texture_1(object src, object mipIndex, object data, object needEncode) { }

	// RVA: 0x73C66AC
	private static object Request_Internal_ComputeBuffer_1_Injected(object buffer, object data, object ret) { }

	// RVA: 0x73C679C
	private static object Request_Internal_Texture_1_Injected(object src, object mipIndex, object data, object needEncode, object ret) { }

}

// Namespace: UnityEngine.Rendering
public enum IndexFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UInt16;
	public const object UInt32;
}

// Namespace: UnityEngine.Rendering
public enum MeshUpdateFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object DontValidateIndices;
	public const object DontResetBoneBounds;
	public const object DontNotifyMeshUsers;
	public const object DontRecalculateBounds;
}

// Namespace: UnityEngine.Rendering
public enum VertexAttributeFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Float32;
	public const object Float16;
	public const object UNorm8;
	public const object SNorm8;
	public const object UNorm16;
	public const object SNorm16;
	public const object UInt8;
	public const object SInt8;
	public const object UInt16;
	public const object SInt16;
	public const object UInt32;
	public const object SInt32;
}

// Namespace: UnityEngine.Rendering
public enum VertexAttribute
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Position;
	public const object Normal;
	public const object Tangent;
	public const object Color;
	public const object TexCoord0;
	public const object TexCoord1;
	public const object TexCoord2;
	public const object TexCoord3;
	public const object TexCoord4;
	public const object TexCoord5;
	public const object TexCoord6;
	public const object TexCoord7;
	public const object BlendWeight;
	public const object BlendIndices;
}

// Namespace: UnityEngine.Rendering
public enum RenderBufferLoadAction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Load;
	public const object Clear;
	public const object DontCare;
}

// Namespace: UnityEngine.Rendering
public enum RenderBufferStoreAction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Store;
	public const object Resolve;
	public const object StoreAndResolve;
	public const object DontCare;
}

// Namespace: UnityEngine.Rendering
public enum FastMemoryFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object SpillTop;
	public const object SpillBottom;
}

// Namespace: UnityEngine.Rendering
public enum BlendMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Zero;
	public const object One;
	public const object DstColor;
	public const object SrcColor;
	public const object OneMinusDstColor;
	public const object SrcAlpha;
	public const object OneMinusSrcColor;
	public const object DstAlpha;
	public const object OneMinusDstAlpha;
	public const object SrcAlphaSaturate;
	public const object OneMinusSrcAlpha;
}

// Namespace: UnityEngine.Rendering
public enum BlendOp
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object Subtract;
	public const object ReverseSubtract;
	public const object Min;
	public const object Max;
	public const object LogicalClear;
	public const object LogicalSet;
	public const object LogicalCopy;
	public const object LogicalCopyInverted;
	public const object LogicalNoop;
	public const object LogicalInvert;
	public const object LogicalAnd;
	public const object LogicalNand;
	public const object LogicalOr;
	public const object LogicalNor;
	public const object LogicalXor;
	public const object LogicalEquivalence;
	public const object LogicalAndReverse;
	public const object LogicalAndInverted;
	public const object LogicalOrReverse;
	public const object LogicalOrInverted;
	public const object Multiply;
	public const object Screen;
	public const object Overlay;
	public const object Darken;
	public const object Lighten;
	public const object ColorDodge;
	public const object ColorBurn;
	public const object HardLight;
	public const object SoftLight;
	public const object Difference;
	public const object Exclusion;
	public const object HSLHue;
	public const object HSLSaturation;
	public const object HSLColor;
	public const object HSLLuminosity;
}

// Namespace: UnityEngine.Rendering
public enum CompareFunction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Disabled;
	public const object Never;
	public const object Less;
	public const object Equal;
	public const object LessEqual;
	public const object Greater;
	public const object NotEqual;
	public const object GreaterEqual;
	public const object Always;
}

// Namespace: UnityEngine.Rendering
public enum CullMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object Front;
	public const object Back;
}

// Namespace: UnityEngine.Rendering
public enum ColorWriteMask
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Alpha;
	public const object Blue;
	public const object Green;
	public const object Red;
	public const object All;
}

// Namespace: UnityEngine.Rendering
public enum StencilOp
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Keep;
	public const object Zero;
	public const object Replace;
	public const object IncrementSaturate;
	public const object DecrementSaturate;
	public const object Invert;
	public const object IncrementWrap;
	public const object DecrementWrap;
}

// Namespace: UnityEngine.Rendering
public enum AmbientMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Skybox;
	public const object Trilight;
	public const object Flat;
	public const object Custom;
}

// Namespace: UnityEngine.Rendering
public enum CameraEvent
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BeforeDepthTexture;
	public const object AfterDepthTexture;
	public const object BeforeDepthNormalsTexture;
	public const object AfterDepthNormalsTexture;
	public const object BeforeGBuffer;
	public const object AfterGBuffer;
	public const object BeforeLighting;
	public const object AfterLighting;
	public const object BeforeFinalPass;
	public const object AfterFinalPass;
	public const object BeforeForwardOpaque;
	public const object AfterForwardOpaque;
	public const object BeforeImageEffectsOpaque;
	public const object AfterImageEffectsOpaque;
	public const object BeforeSkybox;
	public const object AfterSkybox;
	public const object BeforeForwardAlpha;
	public const object AfterForwardAlpha;
	public const object BeforeImageEffects;
	public const object AfterImageEffects;
	public const object AfterEverything;
	public const object BeforeReflections;
	public const object AfterReflections;
	public const object BeforeHaloAndLensFlares;
	public const object AfterHaloAndLensFlares;
}

// Namespace: UnityEngine.Rendering
internal static class CameraEventUtils
{

	// Methods

	// RVA: 0x73C6824
	public static object IsValid(object value) { }

}

// Namespace: UnityEngine.Rendering
public enum BuiltinRenderTextureType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PropertyName;
	public const object BufferPtr;
	public const object RenderTexture;
	public const object BindableTexture;
	public const object None;
	public const object CurrentActive;
	public const object CameraTarget;
	public const object Depth;
	public const object DepthNormals;
	public const object ResolvedDepth;
	public const object PrepassNormalsSpec;
	public const object PrepassLight;
	public const object PrepassLightSpec;
	public const object GBuffer0;
	public const object GBuffer1;
	public const object GBuffer2;
	public const object GBuffer3;
	public const object Reflections;
	public const object MotionVectors;
	public const object GBuffer4;
	public const object GBuffer5;
	public const object GBuffer6;
	public const object GBuffer7;
}

// Namespace: UnityEngine.Rendering
public enum GIType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UnityDefault;
	public const object UniformLightmap;
	public const object DirectionalLightmap;
	public const object LightProbe;
	public const object VLM;
	public const object Unset;
}

// Namespace: UnityEngine.Rendering
public enum ShadowCastingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object On;
	public const object TwoSided;
	public const object ShadowsOnly;
}

// Namespace: UnityEngine.Rendering
public enum GraphicsDeviceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OpenGL2;
	public const object Direct3D9;
	public const object Direct3D11;
	public const object PlayStation3;
	public const object Null;
	public const object Xbox360;
	public const object OpenGLES2;
	public const object OpenGLES3;
	public const object PlayStationVita;
	public const object PlayStation4;
	public const object XboxOne;
	public const object PlayStationMobile;
	public const object Metal;
	public const object OpenGLCore;
	public const object Direct3D12;
	public const object N3DS;
	public const object Vulkan;
	public const object Switch;
	public const object XboxOneD3D12;
	public const object GameCoreXboxOne;
	public const object GameCoreScarlett;
	public const object GameCoreXboxSeries;
	public const object PlayStation5;
	public const object PlayStation5NGGC;
}

// Namespace: UnityEngine.Rendering
public struct SubMeshDescriptor
{

	// Fields
	private object <bounds>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <topology>k__BackingField; // 0x10
	private object <indexStart>k__BackingField; // 0x14
	private object <indexCount>k__BackingField; // 0x18
	private object <baseVertex>k__BackingField; // 0x1C
	private object <firstVertex>k__BackingField; // 0x20
	private object <vertexCount>k__BackingField; // 0x24

	// Properties
	public object bounds { get; }
	public object topology { get; set; }
	public object indexStart { get; set; }
	public object indexCount { get; set; }
	public object baseVertex { get; set; }
	public object firstVertex { get; }
	public object vertexCount { get; }

	// Methods

	// RVA: 0x73C6830
	public object get_bounds() { }

	// RVA: 0x73C6858
	public object get_topology() { }

	// RVA: 0x73C6868
	public object set_topology(object value) { }

	// RVA: 0x73C6878
	public object get_indexStart() { }

	// RVA: 0x73C6888
	public object set_indexStart(object value) { }

	// RVA: 0x73C6898
	public object get_indexCount() { }

	// RVA: 0x73C68A8
	public object set_indexCount(object value) { }

	// RVA: 0x73C68B8
	public object get_baseVertex() { }

	// RVA: 0x73C68C8
	public object set_baseVertex(object value) { }

	// RVA: 0x73C68D8
	public object get_firstVertex() { }

	// RVA: 0x73C68E8
	public object get_vertexCount() { }

	// RVA: 0x73C68F8
	public override object ToString() { }

}

// Namespace: UnityEngine.Rendering
public struct VertexAttributeDescriptor
{

	// Fields
	private object <attribute>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <format>k__BackingField; // 0xFFFFFFFFFFFFFFFC
	private object <dimension>k__BackingField; // 0x0
	private object <stream>k__BackingField; // 0x4

	// Properties
	public object attribute { get; set; }
	public object format { get; set; }
	public object dimension { get; set; }
	public object stream { get; set; }

	// Methods

	// RVA: 0x73C6BA8
	public object get_attribute() { }

	// RVA: 0x73C6BB8
	public object set_attribute(object value) { }

	// RVA: 0x73C6BC8
	public object get_format() { }

	// RVA: 0x73C6BD8
	public object set_format(object value) { }

	// RVA: 0x73C6BE8
	public object get_dimension() { }

	// RVA: 0x73C6BF8
	public object set_dimension(object value) { }

	// RVA: 0x73C6C08
	public object get_stream() { }

	// RVA: 0x73C6C18
	public object set_stream(object value) { }

	// RVA: 0x73C6C28
	public object .ctor(object attribute, object format, object dimension, object stream) { }

	// RVA: 0x73C6C40
	public override object ToString() { }

	// RVA: 0x73C6E28
	public override object GetHashCode() { }

	// RVA: 0x73C6E70
	public override object Equals(object other) { }

	// RVA: 0x73C6F44
	public object Equals(object other) { }

}

// Namespace: UnityEngine.Rendering
public struct RenderTargetIdentifier
{

	// Fields
	private object m_Type; // 0xFFFFFFFFFFFFFFF8
	private object m_NameID; // 0xFFFFFFFFFFFFFFFC
	private object m_InstanceID; // 0x0
	private object m_BufferPointer; // 0x8
	private object m_MipLevel; // 0x10
	private object m_CubeFace; // 0x14
	private object m_DepthSlice; // 0x18

	// Methods

	// RVA: 0x73C70A0
	public object .ctor(object type) { }

	// RVA: 0x73C70E0
	public object .ctor(object nameID) { }

	// RVA: 0x73C7120
	public object .ctor(object renderTargetIdentifier, object mipLevel, object cubeFace, object depthSlice) { }

	// RVA: 0x73C7170
	public object .ctor(object tex) { }

	// RVA: 0x73C7330
	public object .ctor(object tex, object mipLevel, object cubeFace, object depthSlice) { }

	// RVA: 0x73C7508
	public static object op_Implicit(object type) { }

	// RVA: 0x73C7528
	public static object op_Implicit(object nameID) { }

	// RVA: 0x73C7548
	public static object op_Implicit(object tex) { }

	// RVA: 0x73C7594
	public override object ToString() { }

	// RVA: 0x73C7850
	public override object GetHashCode() { }

	// RVA: 0x73C7904
	public object Equals(object rhs) { }

	// RVA: 0x73C7A88
	public override object Equals(object obj) { }

}

// Namespace: UnityEngine.Rendering
public enum RenderTargetFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ReadOnlyDepth;
	public const object ReadOnlyStencil;
	public const object ReadOnlyDepthStencil;
}

// Namespace: UnityEngine.Rendering
public struct RenderTargetBinding
{

	// Fields
	private object m_ColorRenderTargets; // 0xFFFFFFFFFFFFFFF8
	private object m_DepthRenderTarget; // 0x0
	private object m_ColorLoadActions; // 0x28
	private object m_ColorStoreActions; // 0x30
	private object m_DepthLoadAction; // 0x38
	private object m_DepthStoreAction; // 0x3C
	private object m_Flags; // 0x40

	// Properties
	public object colorRenderTargets { get; set; }
	public object depthRenderTarget { get; set; }
	public object colorLoadActions { get; set; }
	public object colorStoreActions { get; set; }
	public object depthLoadAction { get; set; }
	public object depthStoreAction { get; set; }
	public object flags { get; set; }

	// Methods

	// RVA: 0x73C8074
	public object get_colorRenderTargets() { }

	// RVA: 0x73C8084
	public object set_colorRenderTargets(object value) { }

	// RVA: 0x73C8094
	public object get_depthRenderTarget() { }

	// RVA: 0x73C80C0
	public object set_depthRenderTarget(object value) { }

	// RVA: 0x73C80EC
	public object get_colorLoadActions() { }

	// RVA: 0x73C80FC
	public object set_colorLoadActions(object value) { }

	// RVA: 0x73C810C
	public object get_colorStoreActions() { }

	// RVA: 0x73C811C
	public object set_colorStoreActions(object value) { }

	// RVA: 0x73C812C
	public object get_depthLoadAction() { }

	// RVA: 0x73C813C
	public object set_depthLoadAction(object value) { }

	// RVA: 0x73C814C
	public object get_depthStoreAction() { }

	// RVA: 0x73C815C
	public object set_depthStoreAction(object value) { }

	// RVA: 0x73C816C
	public object get_flags() { }

	// RVA: 0x73C817C
	public object set_flags(object value) { }

}

// Namespace: UnityEngine.Rendering
public enum ReflectionProbeUsage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object BlendProbes;
	public const object BlendProbesAndSkybox;
	public const object Simple;
}

// Namespace: UnityEngine.Rendering
public enum ReflectionProbeMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Baked;
	public const object Realtime;
	public const object Custom;
}

// Namespace: UnityEngine.Rendering
public enum ShadowSamplingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CompareDepths;
	public const object RawDepth;
	public const object None;
}

// Namespace: UnityEngine.Rendering
public enum LightProbeUsage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Off;
	public const object BlendProbes;
	public const object UseProxyVolume;
	public const object CustomProvided;
}

// Namespace: UnityEngine.Rendering
public enum TextureDimension
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object None;
	public const object Any;
	public const object Tex2D;
	public const object Tex3D;
	public const object Cube;
	public const object Tex2DArray;
	public const object CubeArray;
}

// Namespace: UnityEngine.Rendering
public enum CopyTextureSupport
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Basic;
	public const object Copy3D;
	public const object DifferentTypes;
	public const object TextureToRT;
	public const object RTToTexture;
}

// Namespace: UnityEngine.Rendering
public enum CommandBufferExecutionFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object AsyncCompute;
}

// Namespace: UnityEngine.Rendering
public enum RTClearFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Color;
	public const object Depth;
	public const object Stencil;
	public const object All;
	public const object DepthStencil;
	public const object ColorDepth;
	public const object ColorStencil;
}

// Namespace: UnityEngine.Rendering
public enum RenderTextureSubElement
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Color;
	public const object Depth;
	public const object Stencil;
	public const object Default;
}

// Namespace: UnityEngine.Rendering
public sealed class GraphicsSettings
{

	// Properties
	public static object lightsUseLinearIntensity { get; }
	internal static object useScriptableRenderPipelineBatching { set; }
	public static object logWhenShaderIsCompiled { get; set; }
	private static object INTERNAL_currentRenderPipeline { get; }
	public static object currentRenderPipeline { get; }
	public static object renderPipelineAsset { get; set; }
	private static object INTERNAL_defaultRenderPipeline { get; set; }
	public static object defaultRenderPipeline { get; set; }
	public static object allowOneDrawShadowCmdCulling { set; }

	// Methods

	// RVA: 0x73C818C
	public static object get_lightsUseLinearIntensity() { }

	// RVA: 0x73C81CC
	internal static object set_useScriptableRenderPipelineBatching(object value) { }

	// RVA: 0x73C821C
	public static object get_logWhenShaderIsCompiled() { }

	// RVA: 0x73C825C
	public static object set_logWhenShaderIsCompiled(object value) { }

	// RVA: 0x73C82AC
	private static object get_INTERNAL_currentRenderPipeline() { }

	// RVA: 0x73C82EC
	public static object get_currentRenderPipeline() { }

	// RVA: 0x73C83AC
	public static object get_renderPipelineAsset() { }

	// RVA: 0x73C852C
	public static object set_renderPipelineAsset(object value) { }

	// RVA: 0x73C85CC
	private static object get_INTERNAL_defaultRenderPipeline() { }

	// RVA: 0x73C860C
	private static object set_INTERNAL_defaultRenderPipeline(object value) { }

	// RVA: 0x73C846C
	public static object get_defaultRenderPipeline() { }

	// RVA: 0x73C857C
	public static object set_defaultRenderPipeline(object value) { }

	// RVA: 0x73C865C
	public static object set_allowOneDrawShadowCmdCulling(object value) { }

}

// Namespace: UnityEngine.Rendering
public class OnDemandRendering
{

	// Fields
	private static object m_RenderFrameInterval; // 0x0

	// Properties
	public static object renderFrameInterval { get; set; }

	// Methods

	// RVA: 0x73C86AC
	public static object get_renderFrameInterval() { }

	// RVA: 0x73C8728
	public static object set_renderFrameInterval(object value) { }

	// RVA: 0x73C87E0
	internal static object GetRenderFrameInterval(object frameInterval) { }

	// RVA: 0x73C88A4
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public class CommandBuffer
{

	// Fields
	internal object m_Ptr; // 0x8

	// Properties
	public object name { set; }
	public object sizeInBytes { get; }

	// Methods

	// RVA: 0x73C88F4
	public object RequestAsyncReadback(object src, object callback) { }

	// RVA: 0x73C89EC
	private object Internal_RequestAsyncReadback_3(object src, object callback, object nativeArrayData) { }

	// RVA: 0x73C8A6C
	public object SetInvertCulling(object invertCulling) { }

	// RVA: 0x73C8AD0
	private static object InitBuffer() { }

	// RVA: 0x73C8B10
	private object ReleaseBuffer() { }

	// RVA: 0x73C8B60
	public object SetComputeFloatParam(object computeShader, object nameID, object val) { }

	// RVA: 0x73C8BE0
	public object SetComputeIntParam(object computeShader, object nameID, object val) { }

	// RVA: 0x73C8C60
	public object SetComputeVectorParam(object computeShader, object nameID, object val) { }

	// RVA: 0x73C8D54
	public object SetComputeMatrixParam(object computeShader, object nameID, object val) { }

	// RVA: 0x73C8E54
	private object Internal_SetComputeTextureParam(object computeShader, object kernelIndex, object nameID, object rt, object mipLevel, object element) { }

	// RVA: 0x73C8EF8
	private object Internal_SetComputeBufferParam(object computeShader, object kernelIndex, object nameID, object buffer) { }

	// RVA: 0x73C8F80
	private object Internal_SetComputeGraphicsBufferParam(object computeShader, object kernelIndex, object nameID, object buffer) { }

	// RVA: 0x73C9008
	private object Internal_DispatchCompute(object computeShader, object kernelIndex, object threadGroupsX, object threadGroupsY, object threadGroupsZ) { }

	// RVA: 0x73C90A4
	private object Internal_DispatchComputeIndirect(object computeShader, object kernelIndex, object indirectBuffer, object argsOffset) { }

	// RVA: 0x73C912C
	private object Internal_SetRayTracingConstantComputeBufferParam(object rayTracingShader, object nameID, object buffer, object offset, object size) { }

	// RVA: 0x73C91C8
	private object Internal_SetRayTracingInts(object rayTracingShader, object nameID, object values) { }

	// RVA: 0x73C9248
	public object SetRayTracingShaderPass(object rayTracingShader, object passName) { }

	// RVA: 0x73C92B4
	private object Internal_DispatchRays(object rayTracingShader, object rayGenShaderName, object width, object height, object depth, object camera) { }

	// RVA: 0x73C9358
	private object Internal_GenerateMips(object rt) { }

	// RVA: 0x73C9420
	private object CopyCounterValueCC(object src, object dst, object dstOffsetBytes) { }

	// RVA: 0x73C94A0
	public object set_name(object value) { }

	// RVA: 0x73C9504
	public object get_sizeInBytes() { }

	// RVA: 0x73C9554
	public object Clear() { }

	// RVA: 0x73C95A4
	private object Internal_DrawMesh(object mesh, object matrix, object material, object submeshIndex, object shaderPass, object properties) { }

	// RVA: 0x73C96EC
	private object Internal_DrawRenderer(object renderer, object material, object submeshIndex, object shaderPass) { }

	// RVA: 0x73C9774
	private object Internal_DrawRendererList(object rendererList) { }

	// RVA: 0x73C983C
	private object Internal_DrawProcedural(object matrix, object material, object shaderPass, object topology, object vertexCount, object instanceCount, object properties) { }

	// RVA: 0x73C9974
	private object Internal_DrawProceduralIndexedIndirect(object indexBuffer, object matrix, object material, object shaderPass, object topology, object bufferWithArgs, object argsOffset, object properties) { }

	// RVA: 0x73C9ABC
	private object Internal_DrawMeshInstanced(object mesh, object submeshIndex, object material, object shaderPass, object matrices, object count, object properties) { }

	// RVA: 0x73C9B58
	public object SetViewport(object pixelRect) { }

	// RVA: 0x73C9C30
	public object EnableScissorRect(object scissor) { }

	// RVA: 0x73C9D08
	public object DisableScissorRect() { }

	// RVA: 0x73C9D58
	private object CopyTexture_Internal(object src, object srcElement, object srcMip, object srcX, object srcY, object srcWidth, object srcHeight, object dst, object dstElement, object dstMip, object dstX, object dstY, object mode) { }

	// RVA: 0x73C9E0C
	private object Blit_Texture(object source, object dest, object mat, object pass, object scale, object offset, object sourceDepthSlice, object destDepthSlice) { }

	// RVA: 0x73C9F58
	private object Blit_Identifier(object source, object dest, object mat, object pass, object scale, object offset, object sourceDepthSlice, object destDepthSlice) { }

	// RVA: 0x73CA0A4
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format, object antiAliasing, object enableRandomWrite, object memorylessMode, object useDynamicScale) { }

	// RVA: 0x73CA160
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format, object antiAliasing, object enableRandomWrite, object memorylessMode) { }

	// RVA: 0x73CA218
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format, object antiAliasing) { }

	// RVA: 0x73CA2CC
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format) { }

	// RVA: 0x73CA374
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format, object readWrite, object antiAliasing, object enableRandomWrite, object memorylessMode, object useDynamicScale) { }

	// RVA: 0x73CA46C
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format, object readWrite, object antiAliasing, object enableRandomWrite, object memorylessMode) { }

	// RVA: 0x73CA568
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format, object readWrite, object antiAliasing, object enableRandomWrite) { }

	// RVA: 0x73CA660
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format, object readWrite, object antiAliasing) { }

	// RVA: 0x73CA75C
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format, object readWrite) { }

	// RVA: 0x73CA858
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter, object format) { }

	// RVA: 0x73CA950
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer, object filter) { }

	// RVA: 0x73CAA00
	public object GetTemporaryRT(object nameID, object width, object height, object depthBuffer) { }

	// RVA: 0x73CAAAC
	public object ReleaseTemporaryRT(object nameID) { }

	// RVA: 0x73CAB10
	public object ClearRenderTarget(object clearFlags, object backgroundColor, object depth, object stencil) { }

	// RVA: 0x73CAC28
	public object ClearRenderTarget(object clearDepth, object clearColor, object backgroundColor) { }

	// RVA: 0x73CAD08
	public object ClearRenderTarget(object clearDepth, object clearColor, object backgroundColor, object depth) { }

	// RVA: 0x73CADF4
	public object SetGlobalFloat(object nameID, object value) { }

	// RVA: 0x73CAE6C
	public object SetGlobalInt(object nameID, object value) { }

	// RVA: 0x73CAED8
	public object SetGlobalInteger(object nameID, object value) { }

	// RVA: 0x73CAF44
	public object SetGlobalVector(object nameID, object value) { }

	// RVA: 0x73CB01C
	public object SetGlobalColor(object nameID, object value) { }

	// RVA: 0x73CB0F4
	public object SetGlobalMatrix(object nameID, object value) { }

	// RVA: 0x73CB1CC
	public object EnableShaderKeyword(object keyword) { }

	// RVA: 0x73CB230
	private object EnableMaterialKeyword(object material, object keyword) { }

	// RVA: 0x73CB308
	private object EnableComputeKeyword(object computeShader, object keyword) { }

	// RVA: 0x73CB3E0
	public object EnableKeyword(object material, object keyword) { }

	// RVA: 0x73CB454
	public object EnableKeyword(object computeShader, object keyword) { }

	// RVA: 0x73CB4C8
	public object DisableShaderKeyword(object keyword) { }

	// RVA: 0x73CB52C
	private object DisableMaterialKeyword(object material, object keyword) { }

	// RVA: 0x73CB604
	private object DisableComputeKeyword(object computeShader, object keyword) { }

	// RVA: 0x73CB6DC
	public object DisableKeyword(object material, object keyword) { }

	// RVA: 0x73CB750
	public object DisableKeyword(object computeShader, object keyword) { }

	// RVA: 0x73CB7C4
	private object SetMaterialKeyword(object material, object keyword, object value) { }

	// RVA: 0x73CB8C4
	public object SetKeyword(object material, object keyword, object value) { }

	// RVA: 0x73CB940
	public object SetViewProjectionMatrices(object view, object proj) { }

	// RVA: 0x73C8980
	private object ValidateAgainstExecutionFlags(object requiredFlags, object invalidFlags) { }

	// RVA: 0x73CBA18
	public object SetGlobalFloatArray(object nameID, object values) { }

	// RVA: 0x73CBA84
	public object SetGlobalVectorArray(object nameID, object values) { }

	// RVA: 0x73CBAF0
	public object SetGlobalMatrixArray(object nameID, object values) { }

	// RVA: 0x73CBB5C
	private object SetGlobalTexture_Impl(object nameID, object rt, object element) { }

	// RVA: 0x73CBBDC
	private object SetGlobalBufferInternal(object nameID, object value) { }

	// RVA: 0x73CBC48
	public object BeginSample(object name) { }

	// RVA: 0x73CBCAC
	public object EndSample(object name) { }

	// RVA: 0x73CBD10
	private object IssuePluginEventAndDataInternal(object callback, object eventID, object data) { }

	// RVA: 0x73CBD90
	private object SetGlobalConstantBufferInternal(object buffer, object nameID, object offset, object size) { }

	// RVA: 0x73CBE18
	public object SetRenderTarget(object rt) { }

	// RVA: 0x73CBF60
	public object SetRenderTarget(object rt, object loadAction, object storeAction) { }

	// RVA: 0x73CC06C
	public object SetRenderTarget(object rt, object colorLoadAction, object colorStoreAction, object depthLoadAction, object depthStoreAction) { }

	// RVA: 0x73CC190
	public object SetRenderTarget(object rt, object mipLevel) { }

	// RVA: 0x73CC2CC
	public object SetRenderTarget(object rt, object mipLevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x73CC440
	public object SetRenderTarget(object color, object depth) { }

	// RVA: 0x73CC5A4
	public object SetRenderTarget(object color, object depth, object mipLevel, object cubemapFace, object depthSlice) { }

	// RVA: 0x73CC73C
	public object SetRenderTarget(object color, object colorLoadAction, object colorStoreAction, object depth, object depthLoadAction, object depthStoreAction) { }

	// RVA: 0x73CC87C
	public object SetRenderTarget(object colors, object depth) { }

	// RVA: 0x73CCAF8
	public object SetRenderTarget(object binding) { }

	// RVA: 0x73CBEC4
	private object SetRenderTargetSingle_Internal(object rt, object colorLoadAction, object colorStoreAction, object depthLoadAction, object depthStoreAction) { }

	// RVA: 0x73CC508
	private object SetRenderTargetColorDepth_Internal(object color, object depth, object colorLoadAction, object colorStoreAction, object depthLoadAction, object depthStoreAction, object flags) { }

	// RVA: 0x73CCA5C
	private object SetRenderTargetMulti_Internal(object colors, object depth, object colorLoadActions, object colorStoreActions, object depthLoadAction, object depthStoreAction, object flags) { }

	// RVA: 0x73CD1C0
	public object SetBufferData(object buffer, object data) { }

	// RVA: 0x73CD358
	private object InternalSetComputeBufferData(object buffer, object data, object managedBufferStartIndex, object graphicsBufferStartIndex, object count, object elemSize) { }

	// RVA: 0x73CD3FC
	public object SetBufferData(object buffer, object data) { }

	// RVA: 0x73CD638
	public object SetBufferData(object buffer, object data, object managedBufferStartIndex, object graphicsBufferStartIndex, object count) { }

	// RVA: 0x73CD594
	private object InternalSetGraphicsBufferData(object buffer, object data, object managedBufferStartIndex, object graphicsBufferStartIndex, object count, object elemSize) { }

	// RVA: 0x73CD90C
	private object SetupCameraProperties_Internal(object camera, object setRenderTarget) { }

	// RVA: 0x73CD978
	public object SetupCameraProperties(object camera, object setRenderTarget) { }

	// RVA: 0x73CDA00
	protected override object Finalize() { }

	// RVA: 0x73CDB1C
	public object Dispose() { }

	// RVA: 0x73CDABC
	private object Dispose(object disposing) { }

	// RVA: 0x73CDBF0
	public object .ctor() { }

	// RVA: 0x73CDC4C
	public object Release() { }

	// RVA: 0x73CDD20
	public object SetComputeFloatParam(object computeShader, object name, object val) { }

	// RVA: 0x73CDD94
	public object SetComputeIntParam(object computeShader, object name, object val) { }

	// RVA: 0x73CDE08
	public object SetComputeVectorParam(object computeShader, object name, object val) { }

	// RVA: 0x73CDEA4
	public object SetComputeMatrixParam(object computeShader, object name, object val) { }

	// RVA: 0x73CDF2C
	public object SetComputeTextureParam(object computeShader, object kernelIndex, object name, object rt) { }

	// RVA: 0x73CDFB0
	public object SetComputeTextureParam(object computeShader, object kernelIndex, object nameID, object rt) { }

	// RVA: 0x73CE02C
	public object SetComputeTextureParam(object computeShader, object kernelIndex, object name, object rt, object mipLevel, object element) { }

	// RVA: 0x73CE0C0
	public object SetComputeBufferParam(object computeShader, object kernelIndex, object nameID, object buffer) { }

	// RVA: 0x73CE148
	public object SetComputeBufferParam(object computeShader, object kernelIndex, object name, object buffer) { }

	// RVA: 0x73CE1C4
	public object SetComputeBufferParam(object computeShader, object kernelIndex, object name, object buffer) { }

	// RVA: 0x73CE240
	public object DispatchCompute(object computeShader, object kernelIndex, object threadGroupsX, object threadGroupsY, object threadGroupsZ) { }

	// RVA: 0x73CE2DC
	public object DispatchCompute(object computeShader, object kernelIndex, object indirectBuffer, object argsOffset) { }

	// RVA: 0x73CE3B0
	public object SetRayTracingConstantBufferParam(object rayTracingShader, object name, object buffer, object offset, object size) { }

	// RVA: 0x73CE43C
	public object SetRayTracingIntParams(object rayTracingShader, object name, object values) { }

	// RVA: 0x73CE4B0
	public object DispatchRays(object rayTracingShader, object rayGenName, object width, object height, object depth, object camera) { }

	// RVA: 0x73CE554
	public object GenerateMips(object rt) { }

	// RVA: 0x73CE5F0
	public object GenerateMips(object rt) { }

	// RVA: 0x73CE758
	public object DrawMesh(object mesh, object matrix, object material, object submeshIndex, object shaderPass, object properties) { }

	// RVA: 0x73CEA40
	public object DrawMesh(object mesh, object matrix, object material, object submeshIndex, object shaderPass) { }

	// RVA: 0x73CEA74
	public object DrawMesh(object mesh, object matrix, object material, object submeshIndex) { }

	// RVA: 0x73CEAAC
	public object DrawMesh(object mesh, object matrix, object material) { }

	// RVA: 0x73CEAE8
	public object DrawRenderer(object renderer, object material, object submeshIndex, object shaderPass) { }

	// RVA: 0x73CED50
	public object DrawRenderer(object renderer, object material, object submeshIndex) { }

	// RVA: 0x73CED58
	public object DrawRendererList(object rendererList) { }

	// RVA: 0x73CEDD4
	public object DrawProcedural(object matrix, object material, object shaderPass, object topology, object vertexCount, object instanceCount, object properties) { }

	// RVA: 0x73CEF6C
	public object DrawProcedural(object matrix, object material, object shaderPass, object topology, object vertexCount, object instanceCount) { }

	// RVA: 0x73CEFA0
	public object DrawProceduralIndirect(object indexBuffer, object matrix, object material, object shaderPass, object topology, object bufferWithArgs, object argsOffset, object properties) { }

	// RVA: 0x73CF18C
	public object DrawMeshInstanced(object mesh, object submeshIndex, object material, object shaderPass, object matrices, object count, object properties) { }

	// RVA: 0x73CF574
	public object DrawMeshInstanced(object mesh, object submeshIndex, object material, object shaderPass, object matrices, object count) { }

	// RVA: 0x73CF594
	public object CopyCounterValue(object src, object dst, object dstOffsetBytes) { }

	// RVA: 0x73CF614
	public object CopyTexture(object src, object srcElement, object srcMip, object dst, object dstElement, object dstMip) { }

	// RVA: 0x73CF6C8
	public object CopyTexture(object src, object srcElement, object srcMip, object srcX, object srcY, object srcWidth, object srcHeight, object dst, object dstElement, object dstMip, object dstX, object dstY) { }

	// RVA: 0x73CF77C
	public object Blit(object source, object dest) { }

	// RVA: 0x73CF848
	public object Blit(object source, object dest, object mat) { }

	// RVA: 0x73CF918
	public object Blit(object source, object dest, object mat, object pass) { }

	// RVA: 0x73CF9F4
	public object Blit(object source, object dest) { }

	// RVA: 0x73CFAC0
	public object SetGlobalFloat(object name, object value) { }

	// RVA: 0x73CFB2C
	public object SetGlobalInt(object name, object value) { }

	// RVA: 0x73CFB90
	public object SetGlobalVector(object name, object value) { }

	// RVA: 0x73CFC24
	public object SetGlobalColor(object name, object value) { }

	// RVA: 0x73CFCB8
	public object SetGlobalMatrix(object name, object value) { }

	// RVA: 0x73CFD38
	public object SetGlobalFloatArray(object propertyName, object values) { }

	// RVA: 0x73CFD9C
	public object SetGlobalVectorArray(object propertyName, object values) { }

	// RVA: 0x73CFE00
	public object SetGlobalTexture(object name, object value) { }

	// RVA: 0x73CFF04
	public object SetGlobalTexture(object nameID, object value) { }

	// RVA: 0x73CFF78
	public object SetGlobalTexture(object name, object value, object element) { }

	// RVA: 0x73CFE84
	public object SetGlobalTexture(object nameID, object value, object element) { }

	// RVA: 0x73D0000
	public object SetGlobalBuffer(object nameID, object value) { }

	// RVA: 0x73D006C
	public object SetGlobalConstantBuffer(object buffer, object name, object offset, object size) { }

	// RVA: 0x73D00E8
	public object IssuePluginEventAndData(object callback, object eventID, object data) { }

	// RVA: 0x73C8CD4
	private object SetComputeVectorParam_Injected(object computeShader, object nameID, object val) { }

	// RVA: 0x73C8DD4
	private object SetComputeMatrixParam_Injected(object computeShader, object nameID, object val) { }

	// RVA: 0x73C93BC
	private object Internal_GenerateMips_Injected(object rt) { }

	// RVA: 0x73C9648
	private object Internal_DrawMesh_Injected(object mesh, object matrix, object material, object submeshIndex, object shaderPass, object properties) { }

	// RVA: 0x73C97D8
	private object Internal_DrawRendererList_Injected(object rendererList) { }

	// RVA: 0x73C98D8
	private object Internal_DrawProcedural_Injected(object matrix, object material, object shaderPass, object topology, object vertexCount, object instanceCount, object properties) { }

	// RVA: 0x73C9A18
	private object Internal_DrawProceduralIndexedIndirect_Injected(object indexBuffer, object matrix, object material, object shaderPass, object topology, object bufferWithArgs, object argsOffset, object properties) { }

	// RVA: 0x73C9BCC
	private object SetViewport_Injected(object pixelRect) { }

	// RVA: 0x73C9CA4
	private object EnableScissorRect_Injected(object scissor) { }

	// RVA: 0x73C9EB4
	private object Blit_Texture_Injected(object source, object dest, object mat, object pass, object scale, object offset, object sourceDepthSlice, object destDepthSlice) { }

	// RVA: 0x73CA000
	private object Blit_Identifier_Injected(object source, object dest, object mat, object pass, object scale, object offset, object sourceDepthSlice, object destDepthSlice) { }

	// RVA: 0x73CAB94
	private object ClearRenderTarget_Injected(object clearFlags, object backgroundColor, object depth, object stencil) { }

	// RVA: 0x73CAFB0
	private object SetGlobalVector_Injected(object nameID, object value) { }

	// RVA: 0x73CB088
	private object SetGlobalColor_Injected(object nameID, object value) { }

	// RVA: 0x73CB160
	private object SetGlobalMatrix_Injected(object nameID, object value) { }

	// RVA: 0x73CB29C
	private object EnableMaterialKeyword_Injected(object material, object keyword) { }

	// RVA: 0x73CB374
	private object EnableComputeKeyword_Injected(object computeShader, object keyword) { }

	// RVA: 0x73CB598
	private object DisableMaterialKeyword_Injected(object material, object keyword) { }

	// RVA: 0x73CB670
	private object DisableComputeKeyword_Injected(object computeShader, object keyword) { }

	// RVA: 0x73CB844
	private object SetMaterialKeyword_Injected(object material, object keyword, object value) { }

	// RVA: 0x73CB9AC
	private object SetViewProjectionMatrices_Injected(object view, object proj) { }

	// RVA: 0x73CCFEC
	private object SetRenderTargetSingle_Internal_Injected(object rt, object colorLoadAction, object colorStoreAction, object depthLoadAction, object depthStoreAction) { }

	// RVA: 0x73CD088
	private object SetRenderTargetColorDepth_Internal_Injected(object color, object depth, object colorLoadAction, object colorStoreAction, object depthLoadAction, object depthStoreAction, object flags) { }

	// RVA: 0x73CD124
	private object SetRenderTargetMulti_Internal_Injected(object colors, object depth, object colorLoadActions, object colorStoreActions, object depthLoadAction, object depthStoreAction, object flags) { }

}

// Namespace: UnityEngine.Rendering
public static class CommandBufferExtensions
{

	// Methods

	// RVA: 0x73D01DC
	private static object Internal_SwitchIntoFastMemory(object cmd, object rt, object fastMemoryFlags, object residency, object copyContents) { }

	// RVA: 0x73D0270
	private static object Internal_SwitchOutOfFastMemory(object cmd, object rt, object copyContents) { }

	// RVA: 0x73D02DC
	public static object SwitchIntoFastMemory(object cmd, object rid, object fastMemoryFlags, object residency, object copyContents) { }

	// RVA: 0x73D0370
	public static object SwitchOutOfFastMemory(object cmd, object rid, object copyContents) { }

}

// Namespace: UnityEngine.Rendering
public struct SphericalHarmonicsL2
{

	// Fields
	private object shr0; // 0xFFFFFFFFFFFFFFF8
	private object shr1; // 0xFFFFFFFFFFFFFFFC
	private object shr2; // 0x0
	private object shr3; // 0x4
	private object shr4; // 0x8
	private object shr5; // 0xC
	private object shr6; // 0x10
	private object shr7; // 0x14
	private object shr8; // 0x18
	private object shg0; // 0x1C
	private object shg1; // 0x20
	private object shg2; // 0x24
	private object shg3; // 0x28
	private object shg4; // 0x2C
	private object shg5; // 0x30
	private object shg6; // 0x34
	private object shg7; // 0x38
	private object shg8; // 0x3C
	private object shb0; // 0x40
	private object shb1; // 0x44
	private object shb2; // 0x48
	private object shb3; // 0x4C
	private object shb4; // 0x50
	private object shb5; // 0x54
	private object shb6; // 0x58
	private object shb7; // 0x5C
	private object shb8; // 0x60

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: 0x73D03DC
	public object AddDirectionalLight(object direction, object color, object intensity) { }

	// RVA: 0x73D0454
	private static object AddDirectionalLightInternal(object sh, object direction, object color) { }

	// RVA: 0x73D059C
	public object get_Item(object rgb, object coefficient) { }

	// RVA: 0x73D06F4
	public object set_Item(object rgb, object coefficient, object value) { }

	// RVA: 0x73D084C
	public override object GetHashCode() { }

	// RVA: 0x73D0A34
	public override object Equals(object other) { }

	// RVA: 0x73D0B00
	public object Equals(object other) { }

	// RVA: 0x73D0E7C
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x73D0C7C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x73D0530
	private static object AddDirectionalLightInternal_Injected(object sh, object direction, object color) { }

}

// Namespace: UnityEngine.Rendering
public struct BatchID
{

	// Fields
	public static readonly object Null; // 0x0
	public object value; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73D0ECC
	public override object GetHashCode() { }

	// RVA: 0x73D0EE0
	public override object Equals(object obj) { }

	// RVA: 0x73D0F9C
	public object Equals(object other) { }

	// RVA: 0x73D1078
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public struct BatchMaterialID
{

	// Fields
	public static readonly object Null; // 0x0
	public object value; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73D10C4
	public override object GetHashCode() { }

	// RVA: 0x73D10D8
	public override object Equals(object obj) { }

	// RVA: 0x73D1194
	public object Equals(object other) { }

	// RVA: 0x73D1270
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public struct BatchMeshID
{

	// Fields
	public static readonly object Null; // 0x0
	public object value; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73D12BC
	public override object GetHashCode() { }

	// RVA: 0x73D12D0
	public override object Equals(object obj) { }

	// RVA: 0x73D138C
	public object Equals(object other) { }

	// RVA: 0x73D1468
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public enum BatchDrawCommandFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object FlipWinding;
	public const object HasMotion;
	public const object IsLightMapped;
	public const object HasSortingPosition;
	public const object LODCrossFade;
	public const object EnableUserPerBatchKeywordSetup;
	public const object EnableUserPerBatchTextureSetup;
	public const object IsSkinnedMeshRenderer;
}

// Namespace: UnityEngine.Rendering
public enum BatchCullingFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object CullLightmappedShadowCasters;
}

// Namespace: UnityEngine.Rendering
public enum BatchCullingViewType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Camera;
	public const object Light;
	public const object Picking;
	public const object SelectionOutline;
}

// Namespace: UnityEngine.Rendering
public enum BatchCullingProjectionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Perspective;
	public const object Orthographic;
}

// Namespace: UnityEngine.Rendering
public enum LayerCullType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object kLayerCullNone;
	public const object kLayerCullPlanar;
	public const object kLayerCullSpherical;
}

// Namespace: UnityEngine.Rendering
public struct BatchPackedCullingViewID
{

	// Fields
	internal object handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73D14B4
	public override object GetHashCode() { }

	// RVA: 0x73D14C8
	public object Equals(object other) { }

	// RVA: 0x73D14E8
	public override object Equals(object obj) { }

}

// Namespace: UnityEngine.Rendering
public struct PropertyBundle
{

	// Fields
	public object nameIDs; // 0xFFFFFFFFFFFFFFF8
	public object descriptions; // 0x0
	public object valueBuffer; // 0x8
	public object count; // 0x10
}

// Namespace: UnityEngine.Rendering
public struct BatchDrawCommand
{

	// Fields
	public object visibleOffset; // 0xFFFFFFFFFFFFFFF8
	public object visibleCount; // 0xFFFFFFFFFFFFFFFC
	public object batchID; // 0x0
	public object materialID; // 0x4
	public object meshID; // 0x8
	public object submeshIndex; // 0xC
	public object splitVisibilityMask; // 0xE
	public object flags; // 0x10
	public object sortingPosition; // 0x14
	public object constantKeywordAndTextureIndices; // 0x18
	public object constantKeywordsOffset; // 0x20
	public object constantTexturesOffset; // 0x24
	public object perBatchPropBlockHash; // 0x28
	public object dynamicKeywords; // 0x30
	public object constantKeywords; // 0x50
	public object dynamicTextures; // 0x70
	public object constantTextures; // 0x90
}

// Namespace: UnityEngine.Rendering
public struct BatchFilterSettings
{

	// Fields
	public object renderingLayerMask; // 0xFFFFFFFFFFFFFFF8
	public object layer; // 0xFFFFFFFFFFFFFFFC
	private object m_motionMode; // 0xFFFFFFFFFFFFFFFD
	private object m_shadowMode; // 0xFFFFFFFFFFFFFFFE
	private object m_receiveShadows; // 0xFFFFFFFFFFFFFFFF
	private object m_staticShadowCaster; // 0x0
	private object m_allDepthSorted; // 0x1
}

// Namespace: UnityEngine.Rendering
public struct BatchDrawRange
{

	// Fields
	public object drawCommandsBegin; // 0xFFFFFFFFFFFFFFF8
	public object drawCommandsCount; // 0xFFFFFFFFFFFFFFFC
	public object filterSettings; // 0x0
}

// Namespace: UnityEngine.Rendering
public struct BatchCullingOutputDrawCommands
{

	// Fields
	public object drawCommands; // 0xFFFFFFFFFFFFFFF8
	public object visibleInstances; // 0x0
	public object drawRanges; // 0x8
	public object instanceSortingPositions; // 0x10
	public object drawCommandPickingInstanceIDs; // 0x18
	public object drawCommandCount; // 0x20
	public object visibleInstanceCount; // 0x24
	public object drawRangeCount; // 0x28
	public object instanceSortingPositionFloatCount; // 0x2C
}

// Namespace: UnityEngine.Rendering
public struct CullingSplit
{

	// Fields
	public object sphereCenter; // 0xFFFFFFFFFFFFFFF8
	public object sphereRadius; // 0x4
	public object cullingPlaneOffset; // 0x8
	public object cullingPlaneCount; // 0xC
	public object cascadeBlendCullingFactor; // 0x10
	public object nearPlane; // 0x14
	public object cullingMatrix; // 0x18
}

// Namespace: UnityEngine.Rendering
public struct BatchCullingContext
{

	// Fields
	public object cullingPlanes; // 0xFFFFFFFFFFFFFFF8
	public readonly object cullingSplits; // 0x8
	public readonly object layerFarCullDistances; // 0x18
	public readonly object LayerCullType; // 0x28
	public readonly object lodParameters; // 0x2C
	public readonly object localToWorldMatrix; // 0x48
	public readonly object viewType; // 0x88
	public readonly object projectionType; // 0x8C
	public readonly object cullingFlags; // 0x90
	public readonly object viewID; // 0x98
	public readonly object cullingLayerMask; // 0xA0
	public readonly object sceneCullingMask; // 0xA8
	public readonly object isOrthographic; // 0xB0
	public readonly object receiverPlaneOffset; // 0xB4
	public readonly object receiverPlaneCount; // 0xB8
	public readonly object shadowCullDistance; // 0xBC
	public readonly object cullRendererListParameters; // 0xC0

	// Methods

	// RVA: 0x73D17C0
	internal object .ctor(object inCullingPlanes, object inCullingSplits, object inLayerFarCullDistances, object inLayerCullType, object inLodParameters, object inLocalToWorldMatrix, object inViewType, object inProjectionType, object inBatchCullingFlags, object inViewID, object inCullingLayerMask, object inSceneCullingMask, object inReceiverPlaneOffset, object inReceiverPlaneCount, object inShadowCullDistance, object inCullRendererListParameters) { }

}

// Namespace: UnityEngine.Rendering
public struct BatchCullingOutput
{

	// Fields
	public object drawCommands; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.Rendering
internal struct BatchRendererCullingOutput
{

	// Fields
	public object cullingJobsFence; // 0xFFFFFFFFFFFFFFF8
	public object localToWorldMatrix; // 0x8
	public object cullingPlanes; // 0x48
	public object cullingPlaneCount; // 0x50
	public object receiverPlaneOffset; // 0x54
	public object receiverPlaneCount; // 0x58
	public object cullingSplits; // 0x60
	public object cullingSplitCount; // 0x68
	public object viewType; // 0x6C
	public object projectionType; // 0x70
	public object cullingFlags; // 0x74
	public object viewID; // 0x78
	public object cullingLayerMask; // 0x80
	public object sceneCullingMask; // 0x88
	public object drawCommands; // 0x90
}

// Namespace: UnityEngine.Rendering
public struct CullRendererListParameters
{

	// Fields
	public object cullRendererListEnabled; // 0xFFFFFFFFFFFFFFF8
	public object cullRendererListMode; // 0xFFFFFFFFFFFFFFFC
	public object cullRendererListSorted; // 0x0
}

// Namespace: UnityEngine.Rendering
internal struct ScriptingCullRendererListParameters
{

	// Fields
	public object cullRendererListEnabled; // 0xFFFFFFFFFFFFFFF8
	public object cullRendererListMode; // 0xFFFFFFFFFFFFFFFC
	public object cullRendererListPtr; // 0x0
	public object cullRendererListSize; // 0x8
	public object layerFarCullDistances; // 0x10
	public object layerCullType; // 0x18
	public object layerFarCullDistancesSize; // 0x1C
	public object shadowCullDistance; // 0x20
}

// Namespace: 
public sealed class OnPerformCulling
{

	// Methods

	// RVA: 0x73D2344
	public object .ctor(object object, object method) { }

	// RVA: 0x73D2450
	public virtual object Invoke(object rendererGroup, object cullingContext, object cullingOutput, object userContext) { }

}

// Namespace: 
public sealed class OnFinishCulling
{

	// Methods

	// RVA: 0x73D27BC
	public object .ctor(object object, object method) { }

	// RVA: 0x73D28C8
	public virtual object Invoke(object rendererGroup, object userContext) { }

}

// Namespace: UnityEngine.Rendering
public class BatchRendererGroup
{

	// Fields
	private object m_GroupHandle; // 0x8
	private object m_PerformCulling; // 0x10
	private object m_FinishCulling; // 0x18

	// Methods

	// RVA: 0x73D194C
	private static object InvokeOnPerformCulling(object group, object context, object lodParameters, object scriptingCullRendererListParameters, object userContext) { }

	// RVA: 0x73D1C5C
	private static object InvokeOnFinishCulling(object group, object userContext) { }

}

// Namespace: UnityEngine.Rendering
public sealed class GPUDrivenRendererDataCallback
{

	// Methods

	// RVA: 0x73D2974
	public object .ctor(object object, object method) { }

	// RVA: 0x73D2A1C
	public virtual object Invoke(object rendererData) { }

}

// Namespace: UnityEngine.Rendering
public sealed class GPUDrivenLODGroupDataCallback
{

	// Methods

	// RVA: 0x73D2AC8
	public object .ctor(object object, object method) { }

	// RVA: 0x73D2B70
	public virtual object Invoke(object lodGroupData) { }

}

// Namespace: UnityEngine.Rendering
public sealed class GPUDrivenLODGroupTransformCallback
{

	// Methods

	// RVA: 0x73D2C1C
	public object .ctor(object object, object method) { }

	// RVA: 0x73D2CC4
	public virtual object Invoke(object lodGroupData) { }

}

// Namespace: UnityEngine.Rendering
public sealed class GPUDrivenSkinnedMeshRendererDataCallback
{

	// Methods

	// RVA: 0x73D2D70
	public object .ctor(object object, object method) { }

	// RVA: 0x73D2E18
	public virtual object Invoke(object skinnedMeshRendererData) { }

}

// Namespace: UnityEngine.Rendering
public sealed class GPUDrivenSkinnedMeshRendererSkinningDataCallback
{

	// Methods

	// RVA: 0x73D2EC4
	public object .ctor(object object, object method) { }

	// RVA: 0x73D2F6C
	public virtual object Invoke(object data) { }

}

// Namespace: UnityEngine.Rendering
public sealed class GPUDrivenMeshSkinningVertexDataCallback
{

	// Methods

	// RVA: 0x73D3018
	public object .ctor(object object, object method) { }

	// RVA: 0x73D30C0
	public virtual object Invoke(object meshSkinningData) { }

}

// Namespace: UnityEngine.Rendering
public sealed class GPUDrivenMeshSkinningWeightsDataCallback
{

	// Methods

	// RVA: 0x73D316C
	public object .ctor(object object, object method) { }

	// RVA: 0x73D3214
	public virtual object Invoke(object meshSkinningData) { }

}

// Namespace: UnityEngine.Rendering
public enum GPUDrivenInvalidRendererReasons
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object InvalidInstanceID;
	public const object ObjectIsNotRenderer;
	public const object RendererTypeNotSupported;
	public const object RendererDisabled;
	public const object NotSRPBatcherCompatible;
	public const object MissingDotsInstancingKeyword;
	public const object RendererHasNoMesh;
	public const object MeshHasNoVertexChannel;
	public const object CustomPropertiesNotHyperCompatible;
	public const object MissingHyperSkinningKeyword;
	public const object CustomPropertiesContainIncompatibleType;
	public const object CustomPropertiesContainBuiltInPerRenderer;
	public const object CustomPropertiesContainArrays;
	public const object SkinnedRendererOptimizedBonesInvalid;
	public const object RendererHasErrorMaterial;
	public const object MonoDoesNotAllowHyperRendering;
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenPackedRendererData
{

	// Fields
	private object data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73D3228
	public object .ctor() { }

}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenPackedMaterialData
{

	// Fields
	private object data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73D3238
	public object .ctor() { }

}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenRendererEditorData
{

	// Fields
	public object sceneCullingMask; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenCustomPropertyInfo
{

	// Fields
	public object floatTypeOffset; // 0xFFFFFFFFFFFFFFF8
	public object floatValueDataOffset; // 0xFFFFFFFFFFFFFFFC
	public object intTypeOffset; // 0x0
	public object intValueDataOffset; // 0x4
	public object vectorTypeOffset; // 0x8
	public object vectorValueDataOffset; // 0xC
	public object matrixTypeOffset; // 0x10
	public object matrixValueDataOffset; // 0x14
	public object keywordTypeOffset; // 0x18
	public object keywordValueDataOffset; // 0x1C
	public object textureTypeOffset; // 0x20
	public object textureValueDataOffset; // 0x24
	public object endHyperTypeOffset; // 0x28
	public object endHyperValueDataOffset; // 0x2C
	public object dynamicTypeHash; // 0x30
	public object dynamicTypeLayoutHash; // 0x34
	public object hyperPerBatchTypeHash; // 0x38
	public object hyperPerBatchTypeLayoutHash; // 0x3C
	public object hash; // 0x40
	public object layoutHash; // 0x44
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenRendererGroupData
{

	// Fields
	public object rendererGroupID; // 0xFFFFFFFFFFFFFFF8
	public object changeReasons; // 0x8
	public object localBounds; // 0x18
	public object gameObjectLayer; // 0x28
	public object renderingLayerMask; // 0x38
	public object rendererActivity; // 0x48
	public object lodGroupID; // 0x58
	public object packedRendererData; // 0x68
	public object rendererPriority; // 0x78
	public object meshIndex; // 0x88
	public object subMeshStartIndex; // 0x98
	public object staticBatchingSubMeshCount; // 0xA8
	public object materialsOffset; // 0xB8
	public object materialsCount; // 0xC8
	public object editorData; // 0xD8
	public object localToWorldMatrix; // 0xE8
	public object prevLocalToWorldMatrix; // 0xF8
	public object rendererGroupIndex; // 0x108
	public object instancesOffset; // 0x118
	public object instancesCount; // 0x128
	public object invalidRendererGroupID; // 0x138
	public object invalidRendererReasons; // 0x148
	public object meshID; // 0x158
	public object subMeshCount; // 0x168
	public object subMeshDescOffset; // 0x178
	public object subMeshDesc; // 0x188
	public object materialIndex; // 0x198
	public object materialID; // 0x1A8
	public object packedMaterialData; // 0x1B8
	public object materialFilterFlags; // 0x1C8
	public object customPropNames; // 0x1D8
	public object customPropDescs; // 0x1E8
	public object customPropValueBuffer; // 0x1F8
	public object customPropInfo; // 0x208
	public object customPropIndex; // 0x218
	public object skinnedRendererIDs; // 0x228
	public object skinnedRendererMeshIDs; // 0x238
	public object skinnedRendererBonesPerVertex; // 0x248
	public object skinnedRendererBonesCount; // 0x258
	public object skinnedRendererHasMotion; // 0x268
}

// Namespace: UnityEngine.Rendering
internal struct GPUDrivenRendererGroupDataNative
{

	// Fields
	public object rendererGroupCount; // 0xFFFFFFFFFFFFFFF8
	public object rendererGroupID; // 0x0
	public object changeReasons; // 0x8
	public object localBounds; // 0x10
	public object gameObjectLayer; // 0x18
	public object renderingLayerMask; // 0x20
	public object rendererActivity; // 0x28
	public object lodGroupID; // 0x30
	public object packedRendererData; // 0x38
	public object rendererPriority; // 0x40
	public object meshIndex; // 0x48
	public object subMeshStartIndex; // 0x50
	public object staticBatchingSubMeshCount; // 0x58
	public object materialsOffset; // 0x60
	public object materialsCount; // 0x68
	public object editorData; // 0x70
	public object localToWorldMatrix; // 0x78
	public object prevLocalToWorldMatrix; // 0x80
	public object invalidRendererGroupIDCount; // 0x88
	public object invalidRendererGroupID; // 0x90
	public object invalidRendererReasons; // 0x98
	public object meshCount; // 0xA0
	public object meshID; // 0xA8
	public object subMeshCount; // 0xB0
	public object subMeshDescOffset; // 0xB8
	public object subMeshDescCount; // 0xC0
	public object subMeshDesc; // 0xC8
	public object materialIndexCount; // 0xD0
	public object materialIndex; // 0xD8
	public object materialCount; // 0xE0
	public object materialID; // 0xE8
	public object packedMaterialData; // 0xF0
	public object materialFilterFlags; // 0xF8
	public object customPropNames; // 0x100
	public object customPropDescs; // 0x108
	public object customPropValueBuffer; // 0x110
	public object customPropInfo; // 0x118
	public object customPropIndex; // 0x120
	public object customPropValueBufferSize; // 0x128
	public object customPropNamesCount; // 0x12C
	public object customPropDescsCount; // 0x130
	public object customPropInfoCount; // 0x134
	public object customPropIndexCount; // 0x138
	public object skinnedRendererCount; // 0x13C
	public object skinnedRendererIDs; // 0x140
	public object skinnedRendererMeshIDs; // 0x148
	public object skinnedRendererBonesPerVertex; // 0x150
	public object skinnedRendererBonesCount; // 0x158
	public object skinnedRendererHasMotion; // 0x160
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenLODGroupData
{

	// Fields
	public object lodGroupID; // 0xFFFFFFFFFFFFFFF8
	public object lodOffset; // 0x8
	public object lodCount; // 0x18
	public object fadeMode; // 0x28
	public object worldSpaceReferencePoint; // 0x38
	public object worldSpaceSize; // 0x48
	public object renderersCount; // 0x58
	public object lastLODIsBillboard; // 0x68
	public object invalidLODGroupID; // 0x78
	public object lodRenderersCount; // 0x88
	public object lodScreenRelativeTransitionHeight; // 0x98
	public object lodFadeTransitionWidth; // 0xA8
}

// Namespace: UnityEngine.Rendering
internal struct GPUDrivenLODGroupDataNative
{

	// Fields
	public object lodGroupCount; // 0xFFFFFFFFFFFFFFF8
	public object lodGroupID; // 0x0
	public object lodOffset; // 0x8
	public object lodCount; // 0x10
	public object fadeMode; // 0x18
	public object worldSpaceReferencePoint; // 0x20
	public object worldSpaceSize; // 0x28
	public object renderersCount; // 0x30
	public object lastLODIsBillboard; // 0x38
	public object invalidLODGroupCount; // 0x40
	public object invalidLODGroupID; // 0x48
	public object lodDataCount; // 0x50
	public object lodRenderersCount; // 0x58
	public object lodScreenRelativeTransitionHeight; // 0x60
	public object lodFadeTransitionWidth; // 0x68
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenRendererBlendShapeRun
{

	// Fields
	public object firstVertex; // 0xFFFFFFFFFFFFFFF8
	public object vertexCount; // 0xFFFFFFFFFFFFFFFC
	public object weight; // 0x0
	public object flags; // 0x4
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenSkinnedMeshRendererDynamicData
{

	// Fields
	public object rendererID; // 0xFFFFFFFFFFFFFFF8
	public object localToWorldMatrix; // 0x8
}

// Namespace: UnityEngine.Rendering
internal struct GPUDrivenSkinnedMeshRendererDynamicDataNative
{

	// Fields
	public object rendererCount; // 0xFFFFFFFFFFFFFFF8
	public object rendererID; // 0x0
	public object localToWorldMatrix; // 0x8
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenSkinnedMeshRendererSkinningData
{

	// Fields
	public object rendererID; // 0xFFFFFFFFFFFFFFF8
	public object mixedRendererIDs; // 0x8
	public object mixedBlendShapeRunsOffsets; // 0x18
	public object mixedBlendShapeRunsCounts; // 0x28
	public object onlyBoneSkinningRendererIDs; // 0x38
	public object onlyBlendShapeRendererIDs; // 0x48
	public object onlyBlendShapeRunsOffsets; // 0x58
	public object onlyBlendShapeRunsCounts; // 0x68
	public object blendShapeRuns; // 0x78
}

// Namespace: UnityEngine.Rendering
internal struct GPUDrivenSkinnedMeshRendererSkinningDataNative
{

	// Fields
	public object mixedRendererCount; // 0xFFFFFFFFFFFFFFF8
	public object mixedRendererIDs; // 0x0
	public object mixedBlendShapeRunsOffsets; // 0x8
	public object mixedBlendShapeRunsCounts; // 0x10
	public object onlyBoneSkinningRendererCount; // 0x18
	public object onlyBoneSkinningRendererIDs; // 0x20
	public object onlyBlendShapeRendererCount; // 0x28
	public object onlyBlendShapeRendererIDs; // 0x30
	public object onlyBlendShapeRunsOffsets; // 0x38
	public object onlyBlendShapeRunsCounts; // 0x40
	public object blendShapeRunsCount; // 0x48
	public object blendShapeRuns; // 0x50
}

// Namespace: UnityEngine.Rendering
public struct BlendShapeVertex
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object vertex; // 0xFFFFFFFFFFFFFFFC
	public object normal; // 0x8
	public object tangent; // 0x14
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenMeshSkinningVertexData
{

	// Fields
	public object meshIDs; // 0xFFFFFFFFFFFFFFF8
	public object vertexCounts; // 0x8
	public object positionPtrs; // 0x18
	public object positionStrides; // 0x28
	public object normalPtrs; // 0x38
	public object normalStrides; // 0x48
	public object tangentPtrs; // 0x58
	public object tangentStrides; // 0x68
	public object blendShapePtrs; // 0x78
	public object blendShapeCounts; // 0x88
	public object blendShapeVertexPtrs; // 0x98
	public object blendShapeVertexCounts; // 0xA8
}

// Namespace: UnityEngine.Rendering
internal struct GPUDrivenMeshSkinningVertexDataNative
{

	// Fields
	public object meshCount; // 0xFFFFFFFFFFFFFFF8
	public object meshIDs; // 0x0
	public object vertexCounts; // 0x8
	public object positionPtrs; // 0x10
	public object positionStrides; // 0x18
	public object normalPtrs; // 0x20
	public object normalStrides; // 0x28
	public object tangentPtrs; // 0x30
	public object tangentStrides; // 0x38
	public object blendShapePtrs; // 0x40
	public object blendShapeCounts; // 0x48
	public object blendShapeVertexPtrs; // 0x50
	public object blendShapeVertexCounts; // 0x58
}

// Namespace: UnityEngine.Rendering
public struct GPUDrivenMeshSkinningWeightsData
{

	// Fields
	public object meshIDs; // 0xFFFFFFFFFFFFFFF8
	public object bonesPerVertex; // 0x8
	public object vertexCounts; // 0x18
	public object boneWeightsPtrs; // 0x28
}

// Namespace: UnityEngine.Rendering
internal struct GPUDrivenMeshSkinningWeightsDataNative
{

	// Fields
	public object meshCount; // 0xFFFFFFFFFFFFFFF8
	public object meshIDs; // 0x0
	public object bonesPerVertex; // 0x8
	public object vertexCounts; // 0x10
	public object boneWeightsPtrs; // 0x18
}

// Namespace: UnityEngine.Rendering
public class GPUDrivenProcessor
{

	// Fields
	private object m_Handle; // 0x8
	private object m_RendererDataCallback; // 0x10
	private object m_LodGroupDataCallback; // 0x18
	private object m_LodGroupTransformCallback; // 0x20
	private object m_SkinnedMeshRendererCallback; // 0x28
	private object m_SkinnedMeshRendererSkinningDataCallback; // 0x30
	private object m_MeshSkinningVertexDataCallback; // 0x38
	private object m_MeshSkinningWeightsDataCallback; // 0x40

	// Methods

	// RVA: 0x73D3248
	private object CallbackRendererDataNative(object nativeData) { }

	// RVA: 0x73D39B8
	private object CallbackLODGroupDataNative(object nativeData) { }

	// RVA: 0x73D3C30
	private object CallbackLODGroupTransformNative(object nativeData) { }

	// RVA: 0x73D3EA8
	private object CallbackSkinnedMeshRendererDynamicDataNative(object nativeData) { }

	// RVA: 0x73D3F7C
	private object CallbackSkinnedMeshRendererSkinningDataNative(object nativeData) { }

	// RVA: 0x73D412C
	private object CallbackMeshSkinningVertexDataNative(object nativeData) { }

	// RVA: 0x73D4354
	private object CallbackMeshSkinningWeightsDataNative(object nativeData) { }

	// RVA: 0x73D448C
	private object CallbackRendererData(object nativeData) { }

	// RVA: 0x73D4490
	private object CallbackLODGroupData(object nativeData) { }

	// RVA: 0x73D4494
	private object CallbackLODGroupTransform(object nativeData) { }

	// RVA: 0x73D4498
	private object CallbackSkinnedMeshRendererDynamicData(object nativeData) { }

	// RVA: 0x73D449C
	private object CallbackSkinnedMeshRendererSkinningData(object nativeData) { }

	// RVA: 0x73D44A0
	private object CallbackMeshSkinningVertexData(object nativeData) { }

	// RVA: 0x73D44A4
	private object CallbackMeshSkinningWeightsData(object nativeData) { }

}

// Namespace: UnityEngine.Rendering
public struct AttachmentDescriptor
{

	// Fields
	private object m_LoadAction; // 0xFFFFFFFFFFFFFFF8
	private object m_StoreAction; // 0xFFFFFFFFFFFFFFFC
	private object m_Format; // 0x0
	private object m_LoadStoreTarget; // 0x8
	private object m_ResolveTarget; // 0x30
	private object m_ClearColor; // 0x58
	private object m_ClearDepth; // 0x68
	private object m_ClearStencil; // 0x6C

	// Properties
	public object loadAction { set; }
	public object storeAction { set; }

	// Methods

	// RVA: 0x73D44A8
	public object set_loadAction(object value) { }

	// RVA: 0x73D44B8
	public object set_storeAction(object value) { }

	// RVA: 0x73D44C8
	public object ConfigureTarget(object target, object loadExistingContents, object storeResults) { }

	// RVA: 0x73D4554
	public object .ctor(object format) { }

	// RVA: 0x73D4618
	public object .ctor(object format) { }

	// RVA: 0x73D47B0
	public object Equals(object other) { }

	// RVA: 0x73D4A0C
	public override object Equals(object obj) { }

	// RVA: 0x73D4BB4
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
public struct BlendState
{

	// Fields
	private object m_BlendState0; // 0xFFFFFFFFFFFFFFF8
	private object m_BlendState1; // 0x0
	private object m_BlendState2; // 0x8
	private object m_BlendState3; // 0x10
	private object m_BlendState4; // 0x18
	private object m_BlendState5; // 0x20
	private object m_BlendState6; // 0x28
	private object m_BlendState7; // 0x30
	private object m_SeparateMRTBlendStates; // 0x38
	private object m_AlphaToMask; // 0x39
	private object m_Padding; // 0x3A

	// Properties
	public static object defaultValue { get; }
	public object alphaToMask { set; }

	// Methods

	// RVA: 0x73D4D0C
	public static object get_defaultValue() { }

	// RVA: 0x73D4D68
	public object .ctor(object separateMRTBlend, object alphaToMask) { }

	// RVA: 0x73D4E60
	public object set_alphaToMask(object value) { }

	// RVA: 0x73D4F40
	public object Equals(object other) { }

	// RVA: 0x73D5068
	public override object Equals(object obj) { }

	// RVA: 0x73D51F0
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
internal struct CoreCameraValues
{

	// Fields
	private object filterMode; // 0xFFFFFFFFFFFFFFF8
	private object cullingMask; // 0xFFFFFFFFFFFFFFFC
	private object instanceID; // 0x0

	// Methods

	// RVA: 0x73D52E0
	public object Equals(object other) { }

	// RVA: 0x73D5348
	public override object Equals(object obj) { }

	// RVA: 0x73D54D0
	public override object GetHashCode() { }

}

// Namespace: 
public struct <layerCullDistances>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <m_CameraCullPlanes>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <m_ShadowCullPlanes>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.Rendering
public struct CameraProperties
{

	// Fields
	private object screenRect; // 0xFFFFFFFFFFFFFFF8
	private object viewDir; // 0x8
	private object projectionNear; // 0x14
	private object projectionFar; // 0x18
	private object cameraNear; // 0x1C
	private object cameraFar; // 0x20
	private object cameraAspect; // 0x24
	private object cameraToWorld; // 0x28
	private object actualWorldToClip; // 0x68
	private object cameraClipToWorld; // 0xA8
	private object cameraWorldToClip; // 0xE8
	private object implicitProjection; // 0x128
	private object stereoWorldToClipLeft; // 0x168
	private object stereoWorldToClipRight; // 0x1A8
	private object worldToCamera; // 0x1E8
	private object up; // 0x228
	private object right; // 0x234
	private object transformDirection; // 0x240
	private object cameraEuler; // 0x24C
	private object velocity; // 0x258
	private object farPlaneWorldSpaceLength; // 0x264
	private object rendererCount; // 0x268
	internal object m_ShadowCullPlanes; // 0x26C
	internal object m_CameraCullPlanes; // 0x2CC
	private object baseFarDistance; // 0x32C
	private object shadowCullCenter; // 0x330
	internal object layerCullDistances; // 0x33C
	private object layerCullSpherical; // 0x3BC
	private object coreCameraValues; // 0x3C0
	private object cameraType; // 0x3CC
	private object projectionIsOblique; // 0x3D0
	private object isImplicitProjectionMatrix; // 0x3D4

	// Methods

	// RVA: 0x73D5510
	public object GetShadowCullingPlane(object index) { }

	// RVA: 0x73D55F8
	public object GetCameraCullingPlane(object index) { }

	// RVA: 0x73D56E0
	public object Equals(object other) { }

	// RVA: 0x73D62C0
	public override object Equals(object obj) { }

	// RVA: 0x73D6498
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
public enum CullingOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ForceEvenIfCameraIsNotActive;
	public const object OcclusionCull;
	public const object NeedsLighting;
	public const object NeedsReflectionProbes;
	public const object Stereo;
	public const object DisablePerObjectCulling;
	public const object ShadowCasters;
}

// Namespace: 
public struct <m_CullingPlanes>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <m_LayerFarCullDistances>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.Rendering
public struct ScriptableCullingParameters
{

	// Fields
	private object m_IsOrthographic; // 0xFFFFFFFFFFFFFFF8
	private object m_LODParameters; // 0xFFFFFFFFFFFFFFFC
	public static readonly object maximumCullingPlaneCount; // 0x0
	internal object m_CullingPlanes; // 0x18
	private object m_CullingPlaneCount; // 0xB8
	private object m_CullingMask; // 0xBC
	private object m_SceneMask; // 0xC0
	private object m_ViewID; // 0xC8
	public static readonly object layerCount; // 0xFFFFFFFFFFFFFFF4
	internal object m_LayerFarCullDistances; // 0xD0
	private object m_LayerCull; // 0x150
	private object m_CullingMatrix; // 0x154
	private object m_Origin; // 0x194
	private object m_ShadowDistance; // 0x1A0
	private object m_ShadowNearPlaneOffset; // 0x1A4
	private object m_CullingOptions; // 0x1A8
	private object m_ReflectionProbeSortingCriteria; // 0x1AC
	private object m_CameraProperties; // 0x1B0
	private object m_AccurateOcclusionThreshold; // 0x590
	private object m_MaximumPortalCullingJobs; // 0x594
	private object m_StereoViewMatrix; // 0x598
	private object m_StereoProjectionMatrix; // 0x5D8
	private object m_StereoSeparationDistance; // 0x618
	private object m_maximumVisibleLights; // 0x61C
	private object m_ConservativeEnclosingSphere; // 0x620
	private object m_NumIterationsEnclosingSphere; // 0x624

	// Properties
	public object cullingPlaneCount { get; }
	public object shadowDistance { set; }

	// Methods

	// RVA: 0x73D7034
	public object get_cullingPlaneCount() { }

	// RVA: 0x73D7044
	public object set_shadowDistance(object value) { }

	// RVA: 0x73D7054
	public object GetLayerCullingDistance(object layerIndex) { }

	// RVA: 0x73D7130
	public object GetCullingPlane(object index) { }

	// RVA: 0x73D7278
	public object Equals(object other) { }

	// RVA: 0x73D7688
	public override object Equals(object obj) { }

	// RVA: 0x73D7890
	public override object GetHashCode() { }

	// RVA: 0x73D7B14
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public struct CullingResults
{

	// Fields
	internal object ptr; // 0xFFFFFFFFFFFFFFF8
	private object m_AllocationInfo; // 0x0

	// Properties
	public object visibleLights { get; }

	// Methods

	// RVA: 0x73D7B68
	private static object GetShadowCasterBounds(object cullingResultsPtr, object lightIndex, object bounds) { }

	// RVA: 0x73D7BD4
	public object get_visibleLights() { }

	// RVA: -1
	private object GetNativeArray(object dataPointer, object length) { }

	// RVA: 0x73D7CA8
	public object GetShadowCasterBounds(object lightIndex, object outBounds) { }

	// RVA: 0x73D7D80
	public object Equals(object other) { }

	// RVA: 0x73D7EA8
	public override object Equals(object obj) { }

	// RVA: 0x73D7FD4
	public override object GetHashCode() { }

	// RVA: 0x73D8040
	public static object op_Equality(object left, object right) { }

}

// Namespace: UnityEngine.Rendering
internal struct CullingAllocationInfo
{

	// Fields
	public object visibleLightsPtr; // 0xFFFFFFFFFFFFFFF8
	public object visibleOffscreenVertexLightsPtr; // 0x0
	public object visibleReflectionProbesPtr; // 0x8
	public object visibleLightCount; // 0x10
	public object visibleOffscreenVertexLightCount; // 0x14
	public object visibleReflectionProbeCount; // 0x18
}

// Namespace: UnityEngine.Rendering
public enum CullRendererListMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DrawWithCulling;
	public const object DrawDirect;
}

// Namespace: UnityEngine.Rendering
public struct DepthState
{

	// Fields
	private object m_WriteEnabled; // 0xFFFFFFFFFFFFFFF8
	private object m_CompareFunction; // 0xFFFFFFFFFFFFFFF9

	// Properties
	public static object defaultValue { get; }

	// Methods

	// RVA: 0x73D80C8
	public static object get_defaultValue() { }

	// RVA: 0x73D8128
	public object .ctor(object writeEnabled, object compareFunction) { }

	// RVA: 0x73D8228
	public object Equals(object other) { }

	// RVA: 0x73D8278
	public override object Equals(object obj) { }

	// RVA: 0x73D83E0
	public override object GetHashCode() { }

}

// Namespace: 
public struct <shaderPassNames>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.Rendering
public struct DrawingSettings
{

	// Fields
	public static readonly object maxShaderPasses; // 0x0
	private object m_SortingSettings; // 0xFFFFFFFFFFFFFFF8
	internal object shaderPassNames; // 0x58
	private object m_PerObjectData; // 0x98
	private object m_Flags; // 0x9C
	private object m_AllowMultiplePassesWithTheSameName; // 0xA0
	private object m_ReplacementShaderInstanceId; // 0xA4
	private object m_ReplacementTag; // 0xA8
	private object m_OverrideShaderID; // 0xAC
	private object m_OverrideShaderPassIndex; // 0xB0
	private object m_OverrideMaterialInstanceId; // 0xB4
	private object m_OverrideMaterialPassIndex; // 0xB8
	private object m_fallbackMaterialInstanceId; // 0xBC
	private object m_MainLightIndex; // 0xC0
	private object m_UseSrpBatcher; // 0xC4
	private object m_MotionVectorGPUInstancing; // 0xC8

	// Properties
	public object sortingSettings { set; }
	public object perObjectData { set; }
	public object enableDynamicBatching { set; }
	public object enableInstancing { set; }
	public object overrideMaterial { set; }
	public object overrideShader { set; }
	public object overrideMaterialPassIndex { set; }
	public object overrideShaderPassIndex { set; }
	public object allowMultiplePassesWithTheSameName { set; }
	public object replacementShader { set; }
	public object replacementTag { set; }
	public object MotionVectorGPUInstancing { set; }

	// Methods

	// RVA: 0x73D8464
	public object .ctor(object shaderPassName, object sortingSettings) { }

	// RVA: 0x73D85AC
	public object set_sortingSettings(object value) { }

	// RVA: 0x73D85C0
	public object set_perObjectData(object value) { }

	// RVA: 0x73D85D0
	public object set_enableDynamicBatching(object value) { }

	// RVA: 0x73D85F8
	public object set_enableInstancing(object value) { }

	// RVA: 0x73D8638
	public object set_overrideMaterial(object value) { }

	// RVA: 0x73D86C0
	public object set_overrideShader(object value) { }

	// RVA: 0x73D8748
	public object set_overrideMaterialPassIndex(object value) { }

	// RVA: 0x73D8758
	public object set_overrideShaderPassIndex(object value) { }

	// RVA: 0x73D8768
	public object set_allowMultiplePassesWithTheSameName(object value) { }

	// RVA: 0x73D8778
	public object set_replacementShader(object value) { }

	// RVA: 0x73D8800
	public object set_replacementTag(object value) { }

	// RVA: 0x73D8810
	public object set_MotionVectorGPUInstancing(object value) { }

	// RVA: 0x73D8820
	public object GetShaderPassName(object index) { }

	// RVA: 0x73D89A0
	public object SetShaderPassName(object index, object shaderPassName) { }

	// RVA: 0x73D8B20
	public object Equals(object other) { }

	// RVA: 0x73D8D78
	public override object Equals(object obj) { }

	// RVA: 0x73D8FE0
	public override object GetHashCode() { }

	// RVA: 0x73D9124
	public static object op_Equality(object left, object right) { }

	// RVA: 0x73D924C
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public enum DrawRendererFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object EnableDynamicBatching;
	public const object EnableInstancing;
}

// Namespace: UnityEngine.Rendering
public struct FilteringSettings
{

	// Fields
	private object m_RenderQueueRange; // 0xFFFFFFFFFFFFFFF8
	private object m_LayerMask; // 0x0
	private object m_RenderingLayerMask; // 0x4
	private object m_ExcludeMotionVectorObjects; // 0x8
	private object m_SortingLayerRange; // 0xC
	private object m_SortingOrderRange; // 0x10

	// Properties
	public object layerMask { set; }
	public object renderingLayerMask { set; }
	public object excludeMotionVectorObjects { set; }
	public object sortingLayerRange { set; }
	public object sortingOrderRange { set; }

	// Methods

	// RVA: 0x73D929C
	public object .ctor(object renderQueueRange, object layerMask, object renderingLayerMask, object excludeMotionVectorObjects) { }

	// RVA: 0x73D9464
	public object set_layerMask(object value) { }

	// RVA: 0x73D9474
	public object set_renderingLayerMask(object value) { }

	// RVA: 0x73D9484
	public object set_excludeMotionVectorObjects(object value) { }

	// RVA: 0x73D9494
	public object set_sortingLayerRange(object value) { }

	// RVA: 0x73D94A4
	public object set_sortingOrderRange(object value) { }

	// RVA: 0x73D94B4
	public object Equals(object other) { }

	// RVA: 0x73D96B0
	public override object Equals(object obj) { }

	// RVA: 0x73D9804
	public override object GetHashCode() { }

	// RVA: 0x73D9930
	public static object op_Equality(object left, object right) { }

}

// Namespace: UnityEngine.Rendering
public struct LODParameters
{

	// Fields
	private object m_IsOrthographic; // 0xFFFFFFFFFFFFFFF8
	private object m_CameraPosition; // 0xFFFFFFFFFFFFFFFC
	private object m_FieldOfView; // 0x8
	private object m_OrthoSize; // 0xC
	private object m_CameraPixelHeight; // 0x10

	// Methods

	// RVA: 0x73D9A20
	public object Equals(object other) { }

	// RVA: 0x73D9B64
	public override object Equals(object obj) { }

	// RVA: 0x73D9C9C
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
public enum PerObjectData
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object LightProbe;
	public const object ReflectionProbes;
	public const object LightProbeProxyVolume;
	public const object Lightmaps;
	public const object LightData;
	public const object MotionVectors;
	public const object LightIndices;
	public const object ReflectionProbeData;
	public const object OcclusionProbe;
	public const object OcclusionProbeProxyVolume;
	public const object ShadowMask;
	public const object YarpLightmap;
}

// Namespace: UnityEngine.Rendering
public struct RasterState
{

	// Fields
	public static readonly object defaultValue; // 0x0
	private object m_CullingMode; // 0xFFFFFFFFFFFFFFF8
	private object m_OffsetUnits; // 0xFFFFFFFFFFFFFFFC
	private object m_OffsetFactor; // 0x0
	private object m_DepthClip; // 0x4
	private object m_Conservative; // 0x5
	private object m_Padding1; // 0x6
	private object m_Padding2; // 0x7

	// Properties
	public object offsetUnits { set; }
	public object offsetFactor { set; }

	// Methods

	// RVA: 0x73D9DE0
	public object .ctor(object cullingMode, object offsetUnits, object offsetFactor, object depthClip) { }

	// RVA: 0x73D9F30
	public object set_offsetUnits(object value) { }

	// RVA: 0x73D9F40
	public object set_offsetFactor(object value) { }

	// RVA: 0x73D9F50
	public object Equals(object other) { }

	// RVA: 0x73DA060
	public override object Equals(object obj) { }

	// RVA: 0x73DA180
	public override object GetHashCode() { }

	// RVA: 0x73DA25C
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public enum ReflectionProbeSortingCriteria
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Importance;
	public const object Size;
	public const object ImportanceThenSize;
}

// Namespace: UnityEngine.Rendering
public struct RendererList
{

	// Fields
	internal object context; // 0xFFFFFFFFFFFFFFF8
	internal object index; // 0x0
	internal object frame; // 0x4
	internal object type; // 0x8
	public static readonly object nullRendererList; // 0x0

	// Properties
	public object isValid { get; }

	// Methods

	// RVA: 0x73DA340
	public object get_isValid() { }

	// RVA: 0x73DA4E8
	internal object .ctor(object ctx, object indx) { }

	// RVA: 0x73DA508
	private static object .cctor() { }

	// RVA: 0x73DA3EC
	private static object get_isValid_Injected(object _unity_self) { }

}

// Namespace: UnityEngine.Rendering
public struct RendererListParams
{

	// Fields
	public static readonly object Invalid; // 0x0
	public object cullingResults; // 0xFFFFFFFFFFFFFFF8
	public object drawSettings; // 0x8
	public object filteringSettings; // 0xDC
	public object tagName; // 0xF8
	public object isPassTagName; // 0xFC
	public object tagValues; // 0x100
	public object stateBlocks; // 0x118

	// Properties
	internal object numStateBlocks { get; }
	internal object stateBlocksPtr { get; }
	internal object tagsValuePtr { get; }

	// Methods

	// RVA: 0x73DA59C
	internal object get_numStateBlocks() { }

	// RVA: 0x73DA698
	internal object get_stateBlocksPtr() { }

	// RVA: 0x73DA7CC
	internal object get_tagsValuePtr() { }

	// RVA: 0x73DA8FC
	internal object Validate() { }

	// RVA: 0x73DADC0
	public object Equals(object other) { }

	// RVA: 0x73DB164
	public override object Equals(object obj) { }

	// RVA: 0x73DB36C
	public override object GetHashCode() { }

	// RVA: 0x73DB514
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public abstract class RenderPipeline
{

	// Fields
	private static object s_cameras; // 0x0
	private object <disposed>k__BackingField; // 0x8

	// Properties
	public object disposed { get; set; }

	// Methods

	// RVA: -1
	protected abstract object Render(object context, object cameras) { }

	// RVA: -1
	protected virtual object ProcessRenderRequests(object context, object camera, object renderRequest) { }

	// RVA: 0x73DB58C
	protected static object BeginContextRendering(object context, object cameras) { }

	// RVA: 0x73DB740
	protected static object BeginCameraRendering(object context, object camera) { }

	// RVA: 0x73DB8E0
	protected static object EndContextRendering(object context, object cameras) { }

	// RVA: 0x73DBA94
	protected static object EndCameraRendering(object context, object camera) { }

	// RVA: 0x73DBC34
	protected virtual object Render(object context, object cameras) { }

	// RVA: 0x73DBDB0
	internal object InternalRender(object context, object cameras) { }

	// RVA: -1
	internal object InternalProcessRenderRequests(object context, object camera, object renderRequest) { }

	// RVA: 0x73DBE70
	public object get_disposed() { }

	// RVA: 0x73DBE78
	private object set_disposed(object value) { }

	// RVA: 0x73DBE80
	internal object Dispose() { }

	// RVA: 0x73DBF18
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x73DBF1C
	protected object .ctor() { }

}

// Namespace: UnityEngine.Rendering
public abstract class RenderPipelineAsset
{

	// Properties
	public virtual object renderingLayerMaskNames { get; }
	public virtual object prefixedRenderingLayerMaskNames { get; }
	public virtual object defaultMaterial { get; }
	public virtual object autodeskInteractiveShader { get; }
	public virtual object autodeskInteractiveTransparentShader { get; }
	public virtual object autodeskInteractiveMaskedShader { get; }
	public virtual object terrainDetailLitShader { get; }
	public virtual object terrainDetailGrassShader { get; }
	public virtual object terrainDetailGrassBillboardShader { get; }
	public virtual object defaultParticleMaterial { get; }
	public virtual object defaultLineMaterial { get; }
	public virtual object defaultTerrainMaterial { get; }
	public virtual object defaultUIMaterial { get; }
	public virtual object defaultUIOverdrawMaterial { get; }
	public virtual object defaultUIETC1SupportedMaterial { get; }
	public virtual object default2DMaterial { get; }
	public virtual object default2DMaskMaterial { get; }
	public virtual object defaultShader { get; }
	public virtual object defaultSpeedTree7Shader { get; }
	public virtual object defaultSpeedTree8Shader { get; }
	public virtual object renderPipelineShaderTag { get; }

	// Methods

	// RVA: 0x73DBF24
	internal object InternalCreatePipeline() { }

	// RVA: 0x73DC168
	public virtual object get_renderingLayerMaskNames() { }

	// RVA: 0x73DC170
	public virtual object get_prefixedRenderingLayerMaskNames() { }

	// RVA: 0x73DC178
	public virtual object get_defaultMaterial() { }

	// RVA: 0x73DC180
	public virtual object get_autodeskInteractiveShader() { }

	// RVA: 0x73DC188
	public virtual object get_autodeskInteractiveTransparentShader() { }

	// RVA: 0x73DC190
	public virtual object get_autodeskInteractiveMaskedShader() { }

	// RVA: 0x73DC198
	public virtual object get_terrainDetailLitShader() { }

	// RVA: 0x73DC1A0
	public virtual object get_terrainDetailGrassShader() { }

	// RVA: 0x73DC1A8
	public virtual object get_terrainDetailGrassBillboardShader() { }

	// RVA: 0x73DC1B0
	public virtual object get_defaultParticleMaterial() { }

	// RVA: 0x73DC1B8
	public virtual object get_defaultLineMaterial() { }

	// RVA: 0x73DC1C0
	public virtual object get_defaultTerrainMaterial() { }

	// RVA: 0x73DC1C8
	public virtual object get_defaultUIMaterial() { }

	// RVA: 0x73DC1D0
	public virtual object get_defaultUIOverdrawMaterial() { }

	// RVA: 0x73DC1D8
	public virtual object get_defaultUIETC1SupportedMaterial() { }

	// RVA: 0x73DC1E0
	public virtual object get_default2DMaterial() { }

	// RVA: 0x73DC1E8
	public virtual object get_default2DMaskMaterial() { }

	// RVA: 0x73DC1F0
	public virtual object get_defaultShader() { }

	// RVA: 0x73DC1F8
	public virtual object get_defaultSpeedTree7Shader() { }

	// RVA: 0x73DC200
	public virtual object get_defaultSpeedTree8Shader() { }

	// RVA: 0x73DC208
	public virtual object get_renderPipelineShaderTag() { }

	// RVA: -1
	protected abstract object CreatePipeline() { }

	// RVA: 0x73DC254
	protected virtual object OnValidate() { }

	// RVA: 0x73DC9A4
	protected virtual object OnDisable() { }

	// RVA: 0x73DCA0C
	protected object .ctor() { }

}

// Namespace: UnityEngine.Rendering
public static class RenderPipelineManager
{

	// Fields
	internal static object s_CurrentPipelineAsset; // 0x0
	private static object s_Cameras; // 0x8
	private static object s_CurrentPipelineType; // 0x10
	private static object s_CurrentPipeline; // 0x18
	private static object beginContextRendering; // 0x20
	private static object endContextRendering; // 0x28
	private static object beginFrameRendering; // 0x30
	private static object beginCameraRendering; // 0x38
	private static object endFrameRendering; // 0x40
	private static object endCameraRendering; // 0x48
	private static object activeRenderPipelineTypeChanged; // 0x50
	private static object activeRenderPipelineAssetChanged; // 0x58

	// Properties
	public static object currentPipeline { get; set; }

	// Methods

	// RVA: 0x73DCA14
	public static object get_currentPipeline() { }

	// RVA: 0x73DCA90
	private static object set_currentPipeline(object value) { }

	// RVA: 0x73DCB8C
	public static object add_beginCameraRendering(object value) { }

	// RVA: 0x73DCCA0
	public static object remove_beginCameraRendering(object value) { }

	// RVA: 0x73DCDB4
	public static object add_endCameraRendering(object value) { }

	// RVA: 0x73DCEC8
	public static object remove_endCameraRendering(object value) { }

	// RVA: 0x73DB618
	internal static object BeginContextRendering(object context, object cameras) { }

	// RVA: 0x73DB834
	internal static object BeginCameraRendering(object context, object camera) { }

	// RVA: 0x73DB96C
	internal static object EndContextRendering(object context, object cameras) { }

	// RVA: 0x73DBB88
	internal static object EndCameraRendering(object context, object camera) { }

	// RVA: 0x73DCFDC
	internal static object OnActiveRenderPipelineTypeChanged() { }

	// RVA: 0x73DD06C
	internal static object OnActiveRenderPipelineAssetChanged(object from, object to) { }

	// RVA: 0x73DD194
	internal static object HandleRenderPipelineChange(object pipelineAsset) { }

	// RVA: 0x73DC370
	internal static object CleanupRenderPipeline() { }

	// RVA: 0x73DD370
	private static object GetCurrentPipelineAssetType() { }

	// RVA: 0x73DD3EC
	private static object DoRenderLoop_Internal(object pipe, object loopPtr, object renderRequest) { }

	// RVA: 0x73DC718
	internal static object PrepareRenderPipeline(object pipelineAsset) { }

	// RVA: 0x73DD8E0
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public struct RenderQueueRange
{

	// Fields
	private object m_LowerBound; // 0xFFFFFFFFFFFFFFF8
	private object m_UpperBound; // 0xFFFFFFFFFFFFFFFC
	public static readonly object minimumBound; // 0x0
	public static readonly object maximumBound; // 0xFFFFFFFFFFFFFFF4

	// Properties
	public static object all { get; }
	public static object opaque { get; }
	public static object transparent { get; }
	public object lowerBound { get; }
	public object upperBound { get; }

	// Methods

	// RVA: 0x73DD974
	public object .ctor(object lowerBound, object upperBound) { }

	// RVA: 0x73D9378
	public static object get_all() { }

	// RVA: 0x73DDB14
	public static object get_opaque() { }

	// RVA: 0x73DDB1C
	public static object get_transparent() { }

	// RVA: 0x73DDB28
	public object get_lowerBound() { }

	// RVA: 0x73DDB38
	public object get_upperBound() { }

	// RVA: 0x73D9598
	public object Equals(object other) { }

	// RVA: 0x73DDB70
	public override object Equals(object obj) { }

	// RVA: 0x73D9890
	public override object GetHashCode() { }

	// RVA: 0x73DDD1C
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public struct RenderStateBlock
{

	// Fields
	private object m_BlendState; // 0xFFFFFFFFFFFFFFF8
	private object m_RasterState; // 0x3C
	private object m_DepthState; // 0x4C
	private object m_StencilState; // 0x4E
	private object m_StencilReference; // 0x5C
	private object m_Mask; // 0x60

	// Properties
	public object blendState { set; }
	public object rasterState { set; }
	public object depthState { set; }

	// Methods

	// RVA: 0x73DDD70
	public object .ctor(object mask) { }

	// RVA: 0x73DDEFC
	public object set_blendState(object value) { }

	// RVA: 0x73DDF10
	public object set_rasterState(object value) { }

	// RVA: 0x73DDF28
	public object set_depthState(object value) { }

	// RVA: 0x73DDF38
	public object Equals(object other) { }

	// RVA: 0x73DE234
	public override object Equals(object obj) { }

	// RVA: 0x73DE3CC
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
public enum RenderStateMask
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Nothing;
	public const object Blend;
	public const object Raster;
	public const object Depth;
	public const object Stencil;
	public const object Everything;
}

// Namespace: UnityEngine.Rendering
public struct RenderTargetBlendState
{

	// Fields
	private object m_WriteMask; // 0xFFFFFFFFFFFFFFF8
	private object m_SourceColorBlendMode; // 0xFFFFFFFFFFFFFFF9
	private object m_DestinationColorBlendMode; // 0xFFFFFFFFFFFFFFFA
	private object m_SourceAlphaBlendMode; // 0xFFFFFFFFFFFFFFFB
	private object m_DestinationAlphaBlendMode; // 0xFFFFFFFFFFFFFFFC
	private object m_ColorBlendOperation; // 0xFFFFFFFFFFFFFFFD
	private object m_AlphaBlendOperation; // 0xFFFFFFFFFFFFFFFE
	private object m_Padding; // 0xFFFFFFFFFFFFFFFF

	// Properties
	public static object defaultValue { get; }

	// Methods

	// RVA: 0x73DE5C8
	public static object get_defaultValue() { }

	// RVA: 0x73DE5D4
	public object .ctor(object writeMask, object sourceColorBlendMode, object destinationColorBlendMode, object sourceAlphaBlendMode, object destinationAlphaBlendMode, object colorBlendOperation, object alphaBlendOperation) { }

	// RVA: 0x73DE61C
	public object Equals(object other) { }

	// RVA: 0x73DE70C
	public override object Equals(object obj) { }

	// RVA: 0x73DE818
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
public struct ScriptableRenderContext
{

	// Fields
	private static readonly object kRenderTypeTag; // 0x0
	private object m_Ptr; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73DE974
	private static object BeginRenderPass_Internal(object self, object width, object height, object volumeDepth, object samples, object colors, object colorCount, object depthAttachmentIndex) { }

	// RVA: 0x73DEA10
	private static object BeginSubPass_Internal(object self, object colors, object colorCount, object inputs, object inputCount, object isDepthReadOnly, object isStencilReadOnly) { }

	// RVA: 0x73DEAB4
	private static object EndSubPass_Internal(object self) { }

	// RVA: 0x73DEB04
	private static object EndRenderPass_Internal(object self) { }

	// RVA: 0x73DEB54
	private static object Internal_Cull(object parameters, object renderLoop, object results) { }

	// RVA: 0x73DEC78
	private static object Internal_CullRendererList(object parameters, object mode, object rendererInstanceIDs, object rendererInstanceIDCount, object renderLoop, object results) { }

	// RVA: 0x73DEDF4
	private static object Internal_UICull(object parameters, object renderLoop, object results) { }

	// RVA: 0x73DEF18
	internal static object InitializeSortSettings(object camera, object sortingSettings) { }

	// RVA: 0x73DEF7C
	private object Submit_Internal() { }

	// RVA: 0x73DF124
	private object GetCameras_Internal(object listType, object resultList) { }

	// RVA: 0x73DF2F8
	private object DrawRenderers_Internal(object cullResults, object drawingSettings, object filteringSettings, object tagName, object isPassTagName, object tagValues, object stateBlocks, object stateCount) { }

	// RVA: 0x73DF5A4
	private object ExecuteCommandBuffer_Internal(object commandBuffer) { }

	// RVA: 0x73DF778
	private object SetupCameraProperties_Internal(object camera, object stereoSetup, object eye, object setRenderTarget) { }

	// RVA: 0x73DF998
	private object CreateRendererList_Internal(object cullResults, object drawingSettings, object filteringSettings, object tagName, object isPassTagName, object tagValues, object stateBlocks, object stateCount) { }

	// RVA: 0x73DFCAC
	private object CreateShadowRendererList_Internal(object shadowDrawinSettings) { }

	// RVA: 0x73DFED8
	private object ExecLowestCulling_Internal(object sceneCamera, object uiCamera) { }

	// RVA: 0x73E00AC
	private object ExecLowestPipelineDraw_Internal(object sceneCamera, object uiCamera) { }

	// RVA: 0x73E0280
	private object SetSupportLightmap_Internal(object value) { }

	// RVA: 0x73E0454
	private object RenderCameraUseBuiltin_Internal(object camera) { }

	// RVA: 0x73DD7A0
	internal object .ctor(object ptr) { }

	// RVA: 0x73E0630
	public object BeginRenderPass(object width, object height, object samples, object attachments, object depthAttachmentIndex) { }

	// RVA: 0x73E0748
	public object BeginSubPass(object colors, object inputs, object isDepthReadOnly, object isStencilReadOnly) { }

	// RVA: 0x73E0878
	public object BeginSubPass(object colors, object isDepthReadOnly, object isStencilReadOnly) { }

	// RVA: 0x73E097C
	public object EndSubPass() { }

	// RVA: 0x73E0AE4
	public object EndRenderPass() { }

	// RVA: 0x73E0C4C
	public object Submit() { }

	// RVA: 0x73DD7A8
	internal object GetCameras(object results) { }

	// RVA: 0x73E0E3C
	public object DrawRenderers(object cullingResults, object drawingSettings, object filteringSettings) { }

	// RVA: 0x73E0FA4
	public object ExecuteCommandBuffer(object commandBuffer) { }

	// RVA: 0x73E1148
	public object SetupCameraProperties(object camera, object setRenderTarget) { }

	// RVA: 0x73E1294
	public object SetupCameraProperties(object camera, object stereoSetup, object eye, object setRenderTarget) { }

	// RVA: 0x73E14C4
	public object Cull(object parameters) { }

	// RVA: 0x73E15E0
	public object CullRendererList(object parameters, object mode, object rendererInstanceIDs) { }

	// RVA: 0x73E174C
	public object UICull(object parameters) { }

	// RVA: 0x73E1868
	public object Equals(object other) { }

	// RVA: 0x73E1958
	public override object Equals(object obj) { }

	// RVA: 0x73E1A64
	public override object GetHashCode() { }

	// RVA: 0x73E1A78
	public object CreateRendererList(object param) { }

	// RVA: 0x73E1D78
	public object CreateShadowRendererList(object settings) { }

	// RVA: 0x73E1EBC
	public object ExecLowestCulling(object sceneCamera, object uiCamera) { }

	// RVA: 0x73E20B4
	public object ExecLowestPipelineDraw(object sceneCamera, object uiCamera) { }

	// RVA: 0x73E22AC
	public object SetSupportLightmap(object value) { }

	// RVA: 0x73E24AC
	public object RenderCameraUseBuiltin(object camera) { }

	// RVA: 0x73E26AC
	private static object .cctor() { }

	// RVA: 0x73DEC0C
	private static object Internal_Cull_Injected(object parameters, object renderLoop, object results) { }

	// RVA: 0x73DED58
	private static object Internal_CullRendererList_Injected(object parameters, object mode, object rendererInstanceIDs, object rendererInstanceIDCount, object renderLoop, object results) { }

	// RVA: 0x73DEEAC
	private static object Internal_UICull_Injected(object parameters, object renderLoop, object results) { }

	// RVA: 0x73DF028
	private static object Submit_Internal_Injected(object _unity_self) { }

	// RVA: 0x73DF1D8
	private static object GetCameras_Internal_Injected(object _unity_self, object listType, object resultList) { }

	// RVA: 0x73DF3FC
	private static object DrawRenderers_Internal_Injected(object _unity_self, object cullResults, object drawingSettings, object filteringSettings, object tagName, object isPassTagName, object tagValues, object stateBlocks, object stateCount) { }

	// RVA: 0x73DF65C
	private static object ExecuteCommandBuffer_Internal_Injected(object _unity_self, object commandBuffer) { }

	// RVA: 0x73DF844
	private static object SetupCameraProperties_Internal_Injected(object _unity_self, object camera, object stereoSetup, object eye, object setRenderTarget) { }

	// RVA: 0x73DFAC8
	private static object CreateRendererList_Internal_Injected(object _unity_self, object cullResults, object drawingSettings, object filteringSettings, object tagName, object isPassTagName, object tagValues, object stateBlocks, object stateCount, object ret) { }

	// RVA: 0x73DFD8C
	private static object CreateShadowRendererList_Internal_Injected(object _unity_self, object shadowDrawinSettings, object ret) { }

	// RVA: 0x73DFF8C
	private static object ExecLowestCulling_Internal_Injected(object _unity_self, object sceneCamera, object uiCamera) { }

	// RVA: 0x73E0160
	private static object ExecLowestPipelineDraw_Internal_Injected(object _unity_self, object sceneCamera, object uiCamera) { }

	// RVA: 0x73E0338
	private static object SetSupportLightmap_Internal_Injected(object _unity_self, object value) { }

	// RVA: 0x73E050C
	private static object RenderCameraUseBuiltin_Internal_Injected(object _unity_self, object camera) { }

}

// Namespace: UnityEngine.Rendering
public struct ShaderTagId
{

	// Fields
	public static readonly object none; // 0x0
	private object m_Id; // 0xFFFFFFFFFFFFFFF8

	// Properties
	internal object id { get; set; }
	public object name { get; }

	// Methods

	// RVA: 0x73E2720
	public object .ctor(object name) { }

	// RVA: 0x73E2778
	internal object get_id() { }

	// RVA: 0x73E2788
	internal object set_id(object value) { }

	// RVA: 0x73E2798
	public object get_name() { }

	// RVA: 0x73E27B0
	public override object Equals(object obj) { }

	// RVA: 0x73E2854
	public object Equals(object other) { }

	// RVA: 0x73DB4E8
	public override object GetHashCode() { }

	// RVA: 0x73DB0F0
	public static object op_Equality(object tag1, object tag2) { }

	// RVA: 0x73E2940
	public static object op_Inequality(object tag1, object tag2) { }

}

// Namespace: UnityEngine.Rendering
public struct ShadowDrawingSettings
{

	// Fields
	private object m_CullingResults; // 0xFFFFFFFFFFFFFFF8
	private object m_LightIndex; // 0x8
	private object m_UseRenderingLayerMaskTest; // 0xC
	private object m_SplitData; // 0x10
	private object m_ObjectsFilter; // 0x10C
	private object m_ProjectionType; // 0x110

	// Properties
	public object splitData { set; }
	public object objectsFilter { set; }

	// Methods

	// RVA: 0x73E294C
	public object set_splitData(object value) { }

	// RVA: 0x73E2964
	public object set_objectsFilter(object value) { }

	// RVA: 0x73E2974
	public object .ctor(object cullingResults, object lightIndex, object projectionType) { }

	// RVA: 0x73E2BFC
	public object Equals(object other) { }

	// RVA: 0x73E2FD4
	public override object Equals(object obj) { }

	// RVA: 0x73E31AC
	public override object GetHashCode() { }

}

// Namespace: 
public struct <m_CullingPlanes>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.Rendering
public struct ShadowSplitData
{

	// Fields
	public static readonly object maximumCullingPlaneCount; // 0x0
	private object m_CullingPlaneCount; // 0xFFFFFFFFFFFFFFF8
	internal object m_CullingPlanes; // 0xFFFFFFFFFFFFFFFC
	private object m_CullingSphere; // 0x9C
	private object m_ShadowCascadeBlendCullingFactor; // 0xAC
	private object m_CullingNearPlane; // 0xB0
	private object m_CullingMatrix; // 0xB4

	// Properties
	public object cullingPlaneCount { get; set; }
	public object shadowCascadeBlendCullingFactor { set; }

	// Methods

	// RVA: 0x73E3338
	public object get_cullingPlaneCount() { }

	// RVA: 0x73E3348
	public object set_cullingPlaneCount(object value) { }

	// RVA: 0x73E2A50
	public object set_shadowCascadeBlendCullingFactor(object value) { }

	// RVA: 0x73E3430
	public object GetCullingPlane(object index) { }

	// RVA: 0x73E3590
	public object SetCullingPlane(object index, object plane) { }

	// RVA: 0x73E2DE8
	public object Equals(object other) { }

	// RVA: 0x73E37B0
	public override object Equals(object obj) { }

	// RVA: 0x73E32A8
	public override object GetHashCode() { }

	// RVA: 0x73E3AAC
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public enum SortingCriteria
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object SortingLayer;
	public const object RenderQueue;
	public const object BackToFront;
	public const object QuantizedFrontToBack;
	public const object OptimizeStateChanges;
	public const object CanvasOrder;
	public const object SortStaticBatchingCriteria;
	public const object SortLightMap;
	public const object SortGeometry;
	public const object SortUseBuildInDistanceCalc;
	public const object SortFirstPassFirst;
	public const object SortPassOrder;
	public const object SortUseBuildInMaterialSorting;
	public const object SortUseUnity5LegacySorter;
	public const object RendererPriority;
	public const object SortPerBatchKeywords;
	public const object SortPerBatchTextures;
	public const object CommonOpaque;
	public const object CommonTransparent;
}

// Namespace: UnityEngine.Rendering
public struct SortingLayerRange
{

	// Fields
	private object m_LowerBound; // 0xFFFFFFFFFFFFFFF8
	private object m_UpperBound; // 0xFFFFFFFFFFFFFFFA

	// Properties
	public static object all { get; }

	// Methods

	// RVA: 0x73D9380
	public static object get_all() { }

	// RVA: 0x73E3AFC
	public object Equals(object other) { }

	// RVA: 0x73E3B44
	public override object Equals(object obj) { }

	// RVA: 0x73E3CA4
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
public enum DistanceMetric
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Perspective;
	public const object Orthographic;
	public const object CustomAxis;
}

// Namespace: UnityEngine.Rendering
public struct SortingSettings
{

	// Fields
	private object m_WorldToCameraMatrix; // 0xFFFFFFFFFFFFFFF8
	private object m_CameraPosition; // 0x38
	private object m_CustomAxis; // 0x44
	private object m_Criteria; // 0x50
	private object m_DistanceMetric; // 0x54

	// Properties
	public object criteria { get; set; }

	// Methods

	// RVA: 0x73E3CB4
	public object .ctor(object camera) { }

	// RVA: 0x73E3D6C
	public object get_criteria() { }

	// RVA: 0x73E3E34
	public object set_criteria(object value) { }

	// RVA: 0x73E3E44
	public object Equals(object other) { }

	// RVA: 0x73E4014
	public override object Equals(object obj) { }

	// RVA: 0x73E4168
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
public struct StencilState
{

	// Fields
	private object m_Enabled; // 0xFFFFFFFFFFFFFFF8
	private object m_ReadMask; // 0xFFFFFFFFFFFFFFF9
	private object m_WriteMask; // 0xFFFFFFFFFFFFFFFA
	private object m_Padding; // 0xFFFFFFFFFFFFFFFB
	private object m_CompareFunctionFront; // 0xFFFFFFFFFFFFFFFC
	private object m_PassOperationFront; // 0xFFFFFFFFFFFFFFFD
	private object m_FailOperationFront; // 0xFFFFFFFFFFFFFFFE
	private object m_ZFailOperationFront; // 0xFFFFFFFFFFFFFFFF
	private object m_CompareFunctionBack; // 0x0
	private object m_PassOperationBack; // 0x1
	private object m_FailOperationBack; // 0x2
	private object m_ZFailOperationBack; // 0x3

	// Properties
	public static object defaultValue { get; }
	public object enabled { set; }
	public object readMask { set; }
	public object writeMask { set; }
	public object compareFunctionFront { set; }
	public object passOperationFront { set; }
	public object failOperationFront { set; }
	public object zFailOperationFront { set; }
	public object compareFunctionBack { set; }
	public object passOperationBack { set; }
	public object failOperationBack { set; }
	public object zFailOperationBack { set; }

	// Methods

	// RVA: 0x73DDE84
	public static object get_defaultValue() { }

	// RVA: 0x73E42FC
	public object .ctor(object enabled, object readMask, object writeMask, object compareFunction, object passOperation, object failOperation, object zFailOperation) { }

	// RVA: 0x73E43C8
	public object .ctor(object enabled, object readMask, object writeMask, object compareFunctionFront, object passOperationFront, object failOperationFront, object zFailOperationFront, object compareFunctionBack, object passOperationBack, object failOperationBack, object zFailOperationBack) { }

	// RVA: 0x73E465C
	public object set_enabled(object value) { }

	// RVA: 0x73E473C
	public object set_readMask(object value) { }

	// RVA: 0x73E474C
	public object set_writeMask(object value) { }

	// RVA: 0x73E475C
	public object set_compareFunctionFront(object value) { }

	// RVA: 0x73E476C
	public object set_passOperationFront(object value) { }

	// RVA: 0x73E477C
	public object set_failOperationFront(object value) { }

	// RVA: 0x73E478C
	public object set_zFailOperationFront(object value) { }

	// RVA: 0x73E479C
	public object set_compareFunctionBack(object value) { }

	// RVA: 0x73E47AC
	public object set_passOperationBack(object value) { }

	// RVA: 0x73E47BC
	public object set_failOperationBack(object value) { }

	// RVA: 0x73E47CC
	public object set_zFailOperationBack(object value) { }

	// RVA: 0x73DE140
	public object Equals(object other) { }

	// RVA: 0x73E488C
	public override object Equals(object obj) { }

	// RVA: 0x73DE4C4
	public override object GetHashCode() { }

}

// Namespace: 
public enum ReflectionProbeModes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Rotation;
}

// Namespace: 
public enum LightmapMixedBakeModes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object IndirectOnly;
	public const object Subtractive;
	public const object Shadowmask;
}

// Namespace: UnityEngine.Rendering
public class SupportedRenderingFeatures
{

	// Fields
	private static object s_Active; // 0x0
	private object <reflectionProbeModes>k__BackingField; // 0x8
	private object <defaultMixedLightingModes>k__BackingField; // 0xC
	private object <mixedLightingModes>k__BackingField; // 0x10
	private object <lightmapBakeTypes>k__BackingField; // 0x14
	private object <lightmapsModes>k__BackingField; // 0x18
	private object <enlightenLightmapper>k__BackingField; // 0x1C
	private object <enlighten>k__BackingField; // 0x1D
	private object <lightProbeProxyVolumes>k__BackingField; // 0x1E
	private object <motionVectors>k__BackingField; // 0x1F
	private object <receiveShadows>k__BackingField; // 0x20
	private object <reflectionProbes>k__BackingField; // 0x21
	private object <reflectionProbesBlendDistance>k__BackingField; // 0x22
	private object <rendererPriority>k__BackingField; // 0x23
	private object <rendersUIOverlay>k__BackingField; // 0x24
	private object <overridesEnvironmentLighting>k__BackingField; // 0x25
	private object <overridesFog>k__BackingField; // 0x26
	private object <overridesRealtimeReflectionProbes>k__BackingField; // 0x27
	private object <overridesOtherLightingSettings>k__BackingField; // 0x28
	private object <editableMaterialRenderQueue>k__BackingField; // 0x29
	private object <overridesLODBias>k__BackingField; // 0x2A
	private object <overridesMaximumLODLevel>k__BackingField; // 0x2B
	private object <overridesEnableLODCrossFade>k__BackingField; // 0x2C
	private object <rendererProbes>k__BackingField; // 0x2D
	private object <particleSystemInstancing>k__BackingField; // 0x2E
	private object <autoAmbientProbeBaking>k__BackingField; // 0x2F
	private object <autoDefaultReflectionProbeBaking>k__BackingField; // 0x30
	private object <overridesShadowmask>k__BackingField; // 0x31
	private object <overridesLightProbeSystem>k__BackingField; // 0x32
	private object <supportsHDR>k__BackingField; // 0x33
	private object <overridesLightProbeSystemWarningMessage>k__BackingField; // 0x38

	// Properties
	public static object active { get; set; }
	public object defaultMixedLightingModes { get; }
	public object mixedLightingModes { get; }
	public object lightmapBakeTypes { get; }
	public object lightmapsModes { get; }
	public object enlightenLightmapper { get; }
	public object enlighten { get; }
	public object rendersUIOverlay { get; }
	public object autoAmbientProbeBaking { get; }
	public object autoDefaultReflectionProbeBaking { get; }

	// Methods

	// RVA: 0x73E49DC
	public static object get_active() { }

	// RVA: 0x73DD2E4
	public static object set_active(object value) { }

	// RVA: 0x73E4B40
	public object get_defaultMixedLightingModes() { }

	// RVA: 0x73E4B48
	public object get_mixedLightingModes() { }

	// RVA: 0x73E4B50
	public object get_lightmapBakeTypes() { }

	// RVA: 0x73E4B58
	public object get_lightmapsModes() { }

	// RVA: 0x73E4B60
	public object get_enlightenLightmapper() { }

	// RVA: 0x73E4B68
	public object get_enlighten() { }

	// RVA: 0x73E4B70
	public object get_rendersUIOverlay() { }

	// RVA: 0x73E4B78
	public object get_autoAmbientProbeBaking() { }

	// RVA: 0x73E4B80
	public object get_autoDefaultReflectionProbeBaking() { }

	// RVA: 0x73E4B88
	internal static object FallbackMixedLightingModeByRef(object fallbackModePtr) { }

	// RVA: 0x73E4DF8
	internal static object IsMixedLightingModeSupported(object mixedMode) { }

	// RVA: 0x73E4E70
	internal static object IsMixedLightingModeSupportedByRef(object mixedMode, object isSupportedPtr) { }

	// RVA: 0x73E5040
	internal static object IsLightmapBakeTypeSupported(object bakeType) { }

	// RVA: 0x73E50B8
	internal static object IsLightmapBakeTypeSupportedByRef(object bakeType, object isSupportedPtr) { }

	// RVA: 0x73E5290
	internal static object IsLightmapsModeSupportedByRef(object mode, object isSupportedPtr) { }

	// RVA: 0x73E5324
	internal static object IsLightmapperSupportedByRef(object lightmapper, object isSupportedPtr) { }

	// RVA: 0x73E53CC
	internal static object IsUIOverlayRenderedBySRP(object isSupportedPtr) { }

	// RVA: 0x73E5478
	internal static object IsAutoAmbientProbeBakingSupported(object isSupportedPtr) { }

	// RVA: 0x73E5524
	internal static object IsAutoDefaultReflectionProbeBakingSupported(object isSupportedPtr) { }

	// RVA: 0x73E55D0
	internal static object FallbackLightmapperByRef(object lightmapperPtr) { }

	// RVA: 0x73DD24C
	public object .ctor() { }

	// RVA: 0x73E55F0
	private static object .cctor() { }

}

// Namespace: UnityEngine.Rendering
public struct VisibleLight
{

	// Fields
	private object m_LightType; // 0xFFFFFFFFFFFFFFF8
	private object m_FinalColor; // 0xFFFFFFFFFFFFFFFC
	private object m_ScreenRect; // 0xC
	private object m_LocalToWorldMatrix; // 0x1C
	private object m_Range; // 0x5C
	private object m_SpotAngle; // 0x60
	private object m_InstanceId; // 0x64
	private object m_Flags; // 0x68

	// Properties
	public object light { get; }

	// Methods

	// RVA: 0x73E56C4
	public object get_light() { }

	// RVA: 0x73E583C
	public object Equals(object other) { }

	// RVA: 0x73E5A4C
	public override object Equals(object obj) { }

	// RVA: 0x73E5BF4
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
internal enum VisibleLightFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IntersectsNearPlane;
	public const object IntersectsFarPlane;
}

// Namespace: UnityEngine.Rendering
public struct VisibleReflectionProbe
{

	// Fields
	private object m_Bounds; // 0xFFFFFFFFFFFFFFF8
	private object m_LocalToWorldMatrix; // 0x10
	private object m_HdrData; // 0x50
	private object m_Center; // 0x60
	private object m_BlendDistance; // 0x6C
	private object m_Importance; // 0x70
	private object m_BoxProjection; // 0x74
	private object m_InstanceId; // 0x78
	private object m_TextureId; // 0x7C

	// Methods

	// RVA: 0x73E5CF8
	public object Equals(object other) { }

	// RVA: 0x73E5ED4
	public override object Equals(object obj) { }

	// RVA: 0x73E607C
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.Rendering
public struct GlobalKeyword
{

	// Fields
	internal readonly object m_Name; // 0xFFFFFFFFFFFFFFF8
	internal readonly object m_Index; // 0x0

	// Methods

	// RVA: 0x73E62D0
	private static object GetGlobalKeywordCount() { }

	// RVA: 0x73E6310
	private static object GetGlobalKeywordIndex(object keyword) { }

	// RVA: 0x73E6360
	private static object CreateGlobalKeyword(object keyword) { }

	// RVA: 0x73E63B0
	public static object Create(object name) { }

	// RVA: 0x73E6410
	public object .ctor(object name) { }

	// RVA: 0x73E6578
	public override object ToString() { }

}

// Namespace: UnityEngine.Rendering
public struct LocalKeyword
{

	// Fields
	internal readonly object m_SpaceInfo; // 0xFFFFFFFFFFFFFFF8
	internal readonly object m_Name; // 0x0
	internal readonly object m_Index; // 0x8

	// Properties
	public object isValid { get; }

	// Methods

	// RVA: 0x73E6628
	private static object GetShaderKeywordCount(object shader) { }

	// RVA: 0x73E6678
	private static object GetShaderKeywordIndex(object shader, object keyword) { }

	// RVA: 0x73E66DC
	private static object GetComputeShaderKeywordCount(object shader) { }

	// RVA: 0x73E672C
	private static object GetComputeShaderKeywordIndex(object shader, object keyword) { }

	// RVA: 0x73E6790
	private static object IsValid(object spaceInfo, object keyword) { }

	// RVA: 0x73E6860
	public object get_isValid() { }

	// RVA: 0x73E6910
	public object .ctor(object shader, object name) { }

	// RVA: 0x73E6B1C
	public object .ctor(object shader, object name) { }

	// RVA: 0x73E6D28
	public override object ToString() { }

	// RVA: 0x73E6D38
	public override object Equals(object o) { }

	// RVA: 0x73E6E04
	public object Equals(object rhs) { }

	// RVA: 0x73E6F60
	public override object GetHashCode() { }

	// RVA: 0x73E67FC
	private static object IsValid_Injected(object spaceInfo, object keyword) { }

}

// Namespace: UnityEngine.Rendering
public struct LocalKeywordSpace
{

	// Fields
	private readonly object m_KeywordSpace; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73E6FE0
	private object GetKeyword(object name) { }

	// RVA: 0x73E7148
	public object FindKeyword(object name) { }

	// RVA: 0x73E724C
	public override object Equals(object o) { }

	// RVA: 0x73E72EC
	public object Equals(object rhs) { }

	// RVA: 0x73E6F14
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x73E6F9C
	public override object GetHashCode() { }

	// RVA: 0x73E7060
	private static object GetKeyword_Injected(object _unity_self, object name, object ret) { }

}

// Namespace: UnityEngine.Rendering
public enum ShaderPropertyType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Color;
	public const object Vector;
	public const object Float;
	public const object Range;
	public const object Texture;
	public const object Int;
}

// Namespace: UnityEngine.Rendering
public enum ShaderPropertyFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object HideInInspector;
	public const object PerRendererData;
	public const object NoScaleOffset;
	public const object Normal;
	public const object HDR;
	public const object Gamma;
	public const object NonModifiableTextureData;
	public const object MainTexture;
	public const object MainColor;
}

// Namespace: UnityEngine.Rendering
public sealed class SortingGroup
{

	// Properties
	internal static object invalidSortingGroupID { get; }
	public object sortingLayerID { get; }
	public object sortingOrder { get; set; }

	// Methods

	// RVA: 0x73E73B0
	internal static object get_invalidSortingGroupID() { }

	// RVA: 0x73E73F0
	internal static object GetSortingGroupByIndex(object index) { }

	// RVA: 0x73E7440
	public object get_sortingLayerID() { }

	// RVA: 0x73E7490
	public object get_sortingOrder() { }

	// RVA: 0x73E74E0
	public object set_sortingOrder(object value) { }

	// RVA: 0x73E7544
	public object .ctor() { }

}

// Namespace: UnityEngine.Rendering.RendererUtils
public struct RendererListDesc
{

	// Fields
	public object sortingCriteria; // 0xFFFFFFFFFFFFFFF8
	public object rendererConfiguration; // 0xFFFFFFFFFFFFFFFC
	public object renderQueueRange; // 0x0
	public object stateBlock; // 0x8
	public object overrideShader; // 0x78
	public object overrideMaterial; // 0x80
	public object allowMultiplePassesWithTheSameName; // 0x88
	public object replacementShader; // 0x90
	public object replacementTag; // 0x98
	public object excludeObjectMotionVectors; // 0x9C
	public object layerMask; // 0xA0
	public object renderingLayerMask; // 0xA4
	public object overrideMaterialPassIndex; // 0xA8
	public object overrideShaderPassIndex; // 0xAC
	public object MotionVectorGPUInstancing; // 0xB0
	private object <cullingResult>k__BackingField; // 0xB8
	private object <camera>k__BackingField; // 0xC8
	private object <passName>k__BackingField; // 0xD0
	private object <passNames>k__BackingField; // 0xD8
	private static readonly object s_EmptyName; // 0x0

	// Properties
	internal object cullingResult { get; set; }
	internal object camera { get; set; }
	internal object passName { get; set; }
	internal object passNames { get; set; }

	// Methods

	// RVA: 0x73E7588
	internal object get_cullingResult() { }

	// RVA: 0x73E75A0
	private object set_cullingResult(object value) { }

	// RVA: 0x73E75B0
	internal object get_camera() { }

	// RVA: 0x73E75C0
	internal object set_camera(object value) { }

	// RVA: 0x73E75D0
	internal object get_passName() { }

	// RVA: 0x73E75E0
	private object set_passName(object value) { }

	// RVA: 0x73E75F0
	internal object get_passNames() { }

	// RVA: 0x73E7600
	private object set_passNames(object value) { }

	// RVA: 0x73E7610
	public object .ctor(object passName, object cullingResult, object camera) { }

	// RVA: 0x73E77B4
	public object .ctor(object passNames, object cullingResult, object camera) { }

	// RVA: 0x73E7998
	public object IsValid() { }

	// RVA: 0x73E7B50
	public static object ConvertToParameters(object desc) { }

	// RVA: 0x73E8650
	private static object .cctor() { }

}

// Namespace: 
internal enum Flags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Evaluate;
	public const object SeekOccured;
	public const object Loop;
	public const object Hold;
	public const object EffectivePlayStateDelayed;
	public const object EffectivePlayStatePlaying;
}

// Namespace: 
public enum EvaluationType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Evaluate;
	public const object Playback;
}

// Namespace: UnityEngine.Playables
public struct FrameData
{

	// Fields
	internal object m_FrameID; // 0xFFFFFFFFFFFFFFF8
	internal object m_DeltaTime; // 0x0
	internal object m_Weight; // 0x8
	internal object m_EffectiveWeight; // 0xC
	internal object m_EffectiveParentDelay; // 0x10
	internal object m_EffectiveParentSpeed; // 0x18
	internal object m_EffectiveSpeed; // 0x1C
	internal object m_Flags; // 0x20
	internal object m_Output; // 0x28

	// Properties
	public object deltaTime { get; }
	public object effectiveParentSpeed { get; }
	public object effectiveSpeed { get; }
	public object evaluationType { get; }
	public object seekOccurred { get; }
	public object timeLooped { get; }
	public object timeHeld { get; }
	public object output { get; }
	public object effectivePlayState { get; }

	// Methods

	// RVA: 0x73E86C4
	private object HasFlags(object flag) { }

	// RVA: 0x73E86E4
	public object get_deltaTime() { }

	// RVA: 0x73E86FC
	public object get_effectiveParentSpeed() { }

	// RVA: 0x73E870C
	public object get_effectiveSpeed() { }

	// RVA: 0x73E871C
	public object get_evaluationType() { }

	// RVA: 0x73E873C
	public object get_seekOccurred() { }

	// RVA: 0x73E8754
	public object get_timeLooped() { }

	// RVA: 0x73E876C
	public object get_timeHeld() { }

	// RVA: 0x73E8784
	public object get_output() { }

	// RVA: 0x73E879C
	public object get_effectivePlayState() { }

}

// Namespace: UnityEngine.Playables
internal struct FrameRate
{

	// Fields
	public static readonly object k_24Fps; // 0x0
	public static readonly object k_23_976Fps; // 0xFFFFFFFFFFFFFFF4
	public static readonly object k_25Fps; // 0xFFFFFFFFFFFFFFF8
	public static readonly object k_30Fps; // 0xFFFFFFFFFFFFFFFC
	public static readonly object k_29_97Fps; // 0x0
	public static readonly object k_50Fps; // 0x4
	public static readonly object k_60Fps; // 0x8
	public static readonly object k_59_94Fps; // 0xC
	private object m_Rate; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object dropFrame { get; }
	public object rate { get; }

	// Methods

	// RVA: 0x73E87CC
	public object get_dropFrame() { }

	// RVA: 0x73E87E4
	public object get_rate() { }

	// RVA: 0x73E88E4
	public object .ctor(object frameRate, object drop) { }

	// RVA: 0x73E8904
	public object IsValid() { }

	// RVA: 0x73E8924
	public object Equals(object other) { }

	// RVA: 0x73E8944
	public override object Equals(object obj) { }

	// RVA: 0x73E8ABC
	public static object op_Equality(object a, object b) { }

	// RVA: 0x73E8B48
	public override object GetHashCode() { }

	// RVA: 0x73E8B58
	public override object ToString() { }

	// RVA: 0x73E8BC0
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x73E8EC0
	internal static object DoubleToFrameRate(object framerate) { }

	// RVA: 0x73E9068
	private static object .cctor() { }

}

// Namespace: UnityEngine.Playables
public interface INotification
{

	// Properties
	public abstract object id { get; }

	// Methods

	// RVA: -1
	public abstract object get_id() { }

}

// Namespace: UnityEngine.Playables
public interface INotificationReceiver
{

	// Methods

	// RVA: -1
	public abstract object OnNotify(object origin, object notification, object context) { }

}

// Namespace: UnityEngine.Playables
public interface IPlayable
{

	// Methods

	// RVA: -1
	public abstract object GetHandle() { }

}

// Namespace: UnityEngine.Playables
public interface IPlayableBehaviour
{

	// Methods

	// RVA: -1
	public abstract object OnGraphStart(object playable) { }

	// RVA: -1
	public abstract object OnGraphStop(object playable) { }

	// RVA: -1
	public abstract object OnPlayableCreate(object playable) { }

	// RVA: -1
	public abstract object OnPlayableDestroy(object playable) { }

	// RVA: -1
	public abstract object OnBehaviourPlay(object playable, object info) { }

	// RVA: -1
	public abstract object OnBehaviourPause(object playable, object info) { }

	// RVA: -1
	public abstract object PrepareFrame(object playable, object info) { }

	// RVA: -1
	public abstract object ProcessFrame(object playable, object info, object playerData) { }

}

// Namespace: UnityEngine.Playables
public interface IPlayableOutput
{

	// Methods

	// RVA: -1
	public abstract object GetHandle() { }

}

// Namespace: UnityEngine.Playables
public enum DirectorWrapMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Hold;
	public const object Loop;
	public const object None;
}

// Namespace: UnityEngine.Playables
public struct Playable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Properties
	public static object Null { get; }

	// Methods

	// RVA: 0x73E90C4
	public static object get_Null() { }

	// RVA: 0x73E9140
	public static object Create(object graph, object inputCount) { }

	// RVA: 0x73E9270
	internal object .ctor(object handle) { }

	// RVA: 0x73E9280
	public object GetHandle() { }

	// RVA: -1
	public object IsPlayableOfType() { }

	// RVA: 0x73E9298
	public object GetPlayableType() { }

	// RVA: 0x73E9484
	public object Equals(object other) { }

	// RVA: 0x73E9630
	private static object .cctor() { }

}

// Namespace: UnityEngine.Playables
public interface IPlayableAsset
{

	// Properties
	public abstract object duration { get; }

	// Methods

	// RVA: -1
	public abstract object CreatePlayable(object graph, object owner) { }

	// RVA: -1
	public abstract object get_duration() { }

}

// Namespace: UnityEngine.Playables
public abstract class PlayableAsset
{

	// Properties
	public virtual object duration { get; }
	public virtual object outputs { get; }

	// Methods

	// RVA: -1
	public abstract object CreatePlayable(object graph, object owner) { }

	// RVA: 0x73E9788
	public virtual object get_duration() { }

	// RVA: 0x73E9804
	public virtual object get_outputs() { }

	// RVA: 0x73E9880
	internal static object Internal_CreatePlayable(object asset, object graph, object go, object ptr) { }

	// RVA: 0x73E99F4
	internal static object Internal_GetPlayableAssetDuration(object asset, object ptrToDouble) { }

	// RVA: 0x73E9A50
	protected object .ctor() { }

}

// Namespace: UnityEngine.Playables
public abstract class PlayableBehaviour
{

	// Methods

	// RVA: 0x73E9A58
	public object .ctor() { }

	// RVA: 0x73E9A60
	public virtual object OnGraphStart(object playable) { }

	// RVA: 0x73E9A64
	public virtual object OnGraphStop(object playable) { }

	// RVA: 0x73E9A68
	public virtual object OnPlayableCreate(object playable) { }

	// RVA: 0x73E9A6C
	public virtual object OnPlayableDestroy(object playable) { }

	// RVA: 0x73E9A70
	public virtual object OnBehaviourPlay(object playable, object info) { }

	// RVA: 0x73E9A74
	public virtual object OnBehaviourPause(object playable, object info) { }

	// RVA: 0x73E9A78
	public virtual object PrepareFrame(object playable, object info) { }

	// RVA: 0x73E9A7C
	public virtual object ProcessFrame(object playable, object info, object playerData) { }

	// RVA: 0x73E9A80
	public virtual object Clone() { }

}

// Namespace: 
internal sealed class CreateOutputMethod
{

	// Methods

	// RVA: 0x73E9DEC
	public object .ctor(object object, object method) { }

	// RVA: 0x73E9E84
	public virtual object Invoke(object graph, object name) { }

}

// Namespace: UnityEngine.Playables
public struct PlayableBinding
{

	// Fields
	private object m_StreamName; // 0xFFFFFFFFFFFFFFF8
	private object m_SourceObject; // 0x0
	private object m_SourceBindingType; // 0x8
	private object m_CreateOutputMethod; // 0x10
	public static readonly object None; // 0x0
	public static readonly object DefaultDuration; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object streamName { get; }
	public object sourceObject { get; }

	// Methods

	// RVA: 0x73E9AC4
	public object get_streamName() { }

	// RVA: 0x73E9AD4
	public object get_sourceObject() { }

	// RVA: 0x73E9AE4
	internal object CreateOutput(object graph) { }

	// RVA: 0x73E9C68
	internal static object CreateInternal(object name, object sourceObject, object sourceType, object createFunction) { }

	// RVA: 0x73E9C74
	private static object .cctor() { }

}

// Namespace: UnityEngine.Playables
public enum PlayableTraversalMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Mix;
	public const object Passthrough;
}

// Namespace: UnityEngine.Playables
public static class PlayableExtensions
{

	// Methods

	// RVA: -1
	public static object IsValid(object playable) { }

	// RVA: -1
	public static object Destroy(object playable) { }

	// RVA: -1
	public static object GetGraph(object playable) { }

	// RVA: -1
	public static object GetPlayState(object playable) { }

	// RVA: -1
	public static object Play(object playable) { }

	// RVA: -1
	public static object Pause(object playable) { }

	// RVA: -1
	public static object SetSpeed(object playable, object value) { }

	// RVA: -1
	public static object GetSpeed(object playable) { }

	// RVA: -1
	public static object SetDuration(object playable, object value) { }

	// RVA: -1
	public static object GetDuration(object playable) { }

	// RVA: -1
	public static object SetTime(object playable, object value) { }

	// RVA: -1
	public static object GetTime(object playable) { }

	// RVA: -1
	public static object GetPreviousTime(object playable) { }

	// RVA: -1
	public static object SetDone(object playable, object value) { }

	// RVA: -1
	public static object IsDone(object playable) { }

	// RVA: -1
	public static object SetPropagateSetTime(object playable, object value) { }

	// RVA: -1
	public static object SetInputCount(object playable, object value) { }

	// RVA: -1
	public static object GetInputCount(object playable) { }

	// RVA: -1
	public static object GetInput(object playable, object inputPort) { }

	// RVA: -1
	public static object SetInputWeight(object playable, object inputIndex, object weight) { }

	// RVA: -1
	public static object SetInputWeight(object playable, object input, object weight) { }

	// RVA: -1
	public static object GetInputWeight(object playable, object inputIndex) { }

	// RVA: -1
	public static object DisconnectInput(object playable, object inputPort) { }

	// RVA: -1
	public static object SetTraversalMode(object playable, object mode) { }

	// RVA: -1
	internal static object GetTimeWrapMode(object playable) { }

	// RVA: -1
	internal static object SetTimeWrapMode(object playable, object value) { }

}

// Namespace: UnityEngine.Playables
public enum DirectorUpdateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DSPClock;
	public const object GameTime;
	public const object UnscaledGameTime;
	public const object Manual;
}

// Namespace: UnityEngine.Playables
public struct PlayableGraph
{

	// Fields
	internal object m_Handle; // 0xFFFFFFFFFFFFFFF8
	internal object m_Version; // 0x0

	// Methods

	// RVA: 0x73E9E98
	public object GetRootPlayable(object index) { }

	// RVA: -1
	public object Connect(object source, object sourceOutputPort, object destination, object destinationInputPort) { }

	// RVA: -1
	public object Disconnect(object input, object inputPort) { }

	// RVA: -1
	public object DestroyPlayable(object playable) { }

	// RVA: -1
	public object DestroySubgraph(object playable) { }

	// RVA: 0x73E9FD8
	public object Evaluate() { }

	// RVA: 0x73EA0EC
	public static object Create() { }

	// RVA: 0x73EA140
	public static object Create(object name) { }

	// RVA: 0x73EA200
	public object Destroy() { }

	// RVA: 0x73EA2F0
	public object IsValid() { }

	// RVA: 0x73EA3E0
	public object IsPlaying() { }

	// RVA: 0x73EA4D0
	public object Play() { }

	// RVA: 0x73EA5C0
	public object Stop() { }

	// RVA: 0x73EA030
	public object Evaluate(object deltaTime) { }

	// RVA: 0x73EA778
	public object SetTimeUpdateMode(object value) { }

	// RVA: 0x73EA8A4
	public object GetResolver() { }

	// RVA: 0x73EA994
	public object GetPlayableCount() { }

	// RVA: 0x73EAA84
	public object GetRootPlayableCount() { }

	// RVA: 0x73EAB74
	internal object SynchronizeEvaluation(object playable) { }

	// RVA: 0x73E9214
	internal object CreatePlayableHandle() { }

	// RVA: 0x73EAD58
	internal object CreateScriptOutputInternal(object name, object handle) { }

	// RVA: 0x73E9F04
	internal object GetRootPlayableInternal(object index) { }

	// RVA: 0x73EAF70
	internal object IsMatchFrameRateEnabled() { }

	// RVA: 0x73EB060
	internal object GetFrameRate() { }

	// RVA: 0x73EB178
	private object ConnectInternal(object source, object sourceOutputPort, object destination, object destinationInputPort) { }

	// RVA: 0x73EB2EC
	private object DisconnectInternal(object playable, object inputPort) { }

	// RVA: 0x73EB424
	private object DestroyPlayableInternal(object playable) { }

	// RVA: 0x73EB54C
	private object DestroySubgraphInternal(object playable) { }

	// RVA: 0x73EA19C
	private static object Create_Injected(object name, object ret) { }

	// RVA: 0x73EA250
	private static object Destroy_Injected(object _unity_self) { }

	// RVA: 0x73EA340
	private static object IsValid_Injected(object _unity_self) { }

	// RVA: 0x73EA430
	private static object IsPlaying_Injected(object _unity_self) { }

	// RVA: 0x73EA520
	private static object Play_Injected(object _unity_self) { }

	// RVA: 0x73EA610
	private static object Stop_Injected(object _unity_self) { }

	// RVA: 0x73EA6B0
	private static object Evaluate_Injected(object _unity_self, object deltaTime) { }

	// RVA: 0x73EA7DC
	private static object SetTimeUpdateMode_Injected(object _unity_self, object value) { }

	// RVA: 0x73EA8F4
	private static object GetResolver_Injected(object _unity_self) { }

	// RVA: 0x73EA9E4
	private static object GetPlayableCount_Injected(object _unity_self) { }

	// RVA: 0x73EAAD4
	private static object GetRootPlayableCount_Injected(object _unity_self) { }

	// RVA: 0x73EABE4
	private static object SynchronizeEvaluation_Injected(object _unity_self, object playable) { }

	// RVA: 0x73EAC9C
	private static object CreatePlayableHandle_Injected(object _unity_self, object ret) { }

	// RVA: 0x73EADC4
	private static object CreateScriptOutputInternal_Injected(object _unity_self, object name, object handle) { }

	// RVA: 0x73EAE9C
	private static object GetRootPlayableInternal_Injected(object _unity_self, object index, object ret) { }

	// RVA: 0x73EAFC0
	private static object IsMatchFrameRateEnabled_Injected(object _unity_self) { }

	// RVA: 0x73EB0BC
	private static object GetFrameRate_Injected(object _unity_self, object ret) { }

	// RVA: 0x73EB1F0
	private static object ConnectInternal_Injected(object _unity_self, object source, object sourceOutputPort, object destination, object destinationInputPort) { }

	// RVA: 0x73EB354
	private static object DisconnectInternal_Injected(object _unity_self, object playable, object inputPort) { }

	// RVA: 0x73EB494
	private static object DestroyPlayableInternal_Injected(object _unity_self, object playable) { }

	// RVA: 0x73EB5BC
	private static object DestroySubgraphInternal_Injected(object _unity_self, object playable) { }

}

// Namespace: UnityEngine.Playables
public enum PlayState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Paused;
	public const object Playing;
	public const object Delayed;
}

// Namespace: UnityEngine.Playables
public struct PlayableHandle
{

	// Fields
	internal object m_Handle; // 0xFFFFFFFFFFFFFFF8
	internal object m_Version; // 0x0
	private static readonly object m_Null; // 0x0

	// Properties
	public static object Null { get; }

	// Methods

	// RVA: -1
	internal object GetObject() { }

	// RVA: -1
	internal object IsPlayableOfType() { }

	// RVA: 0x73E970C
	public static object get_Null() { }

	// RVA: 0x73EB674
	internal object GetInput(object inputPort) { }

	// RVA: 0x73EB844
	internal object SetInputWeight(object inputIndex, object weight) { }

	// RVA: 0x73EBAF8
	internal object GetInputWeight(object inputIndex) { }

	// RVA: 0x73EBD24
	internal object Destroy() { }

	// RVA: 0x73E95A0
	public static object op_Equality(object x, object y) { }

	// RVA: 0x73EBF48
	public override object Equals(object p) { }

	// RVA: 0x73EC050
	public object Equals(object other) { }

	// RVA: 0x73EC168
	public override object GetHashCode() { }

	// RVA: 0x73EBF14
	internal static object CompareVersion(object lhs, object rhs) { }

	// RVA: 0x73EB9B4
	internal object CheckInputBounds(object inputIndex) { }

	// RVA: 0x73EC1DC
	internal object CheckInputBounds(object inputIndex, object acceptAny) { }

	// RVA: 0x73EC5D4
	internal object IsValid() { }

	// RVA: 0x73E93D0
	internal object GetPlayableType() { }

	// RVA: 0x73EC878
	internal object SetScriptInstance(object scriptInstance) { }

	// RVA: 0x73ECA4C
	internal object GetPlayState() { }

	// RVA: 0x73ECBF4
	internal object Play() { }

	// RVA: 0x73ECD9C
	internal object Pause() { }

	// RVA: 0x73ECF44
	internal object GetSpeed() { }

	// RVA: 0x73ED0EC
	internal object SetSpeed(object value) { }

	// RVA: 0x73ED2A8
	internal object GetTime() { }

	// RVA: 0x73ED450
	internal object SetTime(object value) { }

	// RVA: 0x73ED60C
	internal object IsDone() { }

	// RVA: 0x73ED7B4
	internal object SetDone(object value) { }

	// RVA: 0x73ED988
	internal object GetDuration() { }

	// RVA: 0x73EDB30
	internal object SetDuration(object value) { }

	// RVA: 0x73EDCEC
	internal object SetPropagateSetTime(object value) { }

	// RVA: 0x73EBE54
	internal object GetGraph() { }

	// RVA: 0x73EC50C
	internal object GetInputCount() { }

	// RVA: 0x73EE0D8
	internal object SetInputCount(object value) { }

	// RVA: 0x73EE2AC
	internal object SetInputWeight(object input, object weight) { }

	// RVA: 0x73EE4A4
	internal object GetPreviousTime() { }

	// RVA: 0x73EE64C
	internal object SetTraversalMode(object mode) { }

	// RVA: 0x73EE820
	internal object GetTimeWrapMode() { }

	// RVA: 0x73EE9C8
	internal object SetTimeWrapMode(object mode) { }

	// RVA: 0x73EEB9C
	private object GetScriptInstance() { }

	// RVA: 0x73EB77C
	private object GetInputHandle(object index) { }

	// RVA: 0x73EBA28
	private object SetInputWeightFromIndex(object index, object weight) { }

	// RVA: 0x73EBC64
	private object GetInputWeightFromIndex(object index) { }

	// RVA: 0x73EF0B8
	private static object .cctor() { }

	// RVA: 0x73EC680
	private static object IsValid_Injected(object _unity_self) { }

	// RVA: 0x73EC77C
	private static object GetPlayableType_Injected(object _unity_self) { }

	// RVA: 0x73EC930
	private static object SetScriptInstance_Injected(object _unity_self, object scriptInstance) { }

	// RVA: 0x73ECAF8
	private static object GetPlayState_Injected(object _unity_self) { }

	// RVA: 0x73ECCA0
	private static object Play_Injected(object _unity_self) { }

	// RVA: 0x73ECE48
	private static object Pause_Injected(object _unity_self) { }

	// RVA: 0x73ECFF0
	private static object GetSpeed_Injected(object _unity_self) { }

	// RVA: 0x73ED198
	private static object SetSpeed_Injected(object _unity_self, object value) { }

	// RVA: 0x73ED354
	private static object GetTime_Injected(object _unity_self) { }

	// RVA: 0x73ED4FC
	private static object SetTime_Injected(object _unity_self, object value) { }

	// RVA: 0x73ED6B8
	private static object IsDone_Injected(object _unity_self) { }

	// RVA: 0x73ED86C
	private static object SetDone_Injected(object _unity_self, object value) { }

	// RVA: 0x73EDA34
	private static object GetDuration_Injected(object _unity_self) { }

	// RVA: 0x73EDBDC
	private static object SetDuration_Injected(object _unity_self, object value) { }

	// RVA: 0x73EDDA4
	private static object SetPropagateSetTime_Injected(object _unity_self, object value) { }

	// RVA: 0x73EDEC0
	private static object GetGraph_Injected(object _unity_self, object ret) { }

	// RVA: 0x73EDFDC
	private static object GetInputCount_Injected(object _unity_self) { }

	// RVA: 0x73EE190
	private static object SetInputCount_Injected(object _unity_self, object value) { }

	// RVA: 0x73EE36C
	private static object SetInputWeight_Injected(object _unity_self, object input, object weight) { }

	// RVA: 0x73EE550
	private static object GetPreviousTime_Injected(object _unity_self) { }

	// RVA: 0x73EE704
	private static object SetTraversalMode_Injected(object _unity_self, object mode) { }

	// RVA: 0x73EE8CC
	private static object GetTimeWrapMode_Injected(object _unity_self) { }

	// RVA: 0x73EEA80
	private static object SetTimeWrapMode_Injected(object _unity_self, object mode) { }

	// RVA: 0x73EEC48
	private static object GetScriptInstance_Injected(object _unity_self) { }

	// RVA: 0x73EED44
	private static object GetInputHandle_Injected(object _unity_self, object index, object ret) { }

	// RVA: 0x73EEE70
	private static object SetInputWeightFromIndex_Injected(object _unity_self, object index, object weight) { }

	// RVA: 0x73EEF9C
	private static object GetInputWeightFromIndex_Injected(object _unity_self, object index) { }

}

// Namespace: UnityEngine.Playables
public struct PlayableOutput
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayableOutput; // 0x0

	// Properties
	public static object Null { get; }

	// Methods

	// RVA: 0x73E9BE4
	public static object get_Null() { }

	// RVA: 0x73EF104
	internal object .ctor(object handle) { }

	// RVA: 0x73EF114
	public object GetHandle() { }

	// RVA: -1
	public object IsPlayableOutputOfType() { }

	// RVA: 0x73EF12C
	public object Equals(object other) { }

	// RVA: 0x73EF2D8
	private static object .cctor() { }

}

// Namespace: UnityEngine.Playables
public static class PlayableOutputExtensions
{

	// Methods

	// RVA: -1
	public static object SetReferenceObject(object output, object value) { }

	// RVA: -1
	public static object SetUserData(object output, object value) { }

	// RVA: -1
	public static object GetSourcePlayable(object output) { }

	// RVA: -1
	public static object SetSourcePlayable(object output, object value) { }

	// RVA: -1
	public static object SetSourcePlayable(object output, object value, object port) { }

	// RVA: -1
	public static object GetSourceOutputPort(object output) { }

	// RVA: -1
	public static object SetWeight(object output, object value) { }

	// RVA: -1
	public static object PushNotification(object output, object origin, object notification, object context) { }

	// RVA: -1
	public static object AddNotificationReceiver(object output, object receiver) { }

}

// Namespace: UnityEngine.Playables
public struct PlayableOutputHandle
{

	// Fields
	internal object m_Handle; // 0xFFFFFFFFFFFFFFF8
	internal object m_Version; // 0x0
	private static readonly object m_Null; // 0x0

	// Properties
	public static object Null { get; }

	// Methods

	// RVA: 0x73EF3B4
	public static object get_Null() { }

	// RVA: -1
	internal object IsPlayableOutputOfType() { }

	// RVA: 0x73EF430
	public override object GetHashCode() { }

	// RVA: 0x73EF248
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x73EF4D8
	public override object Equals(object p) { }

	// RVA: 0x73EF5E0
	public object Equals(object other) { }

	// RVA: 0x73EF4A4
	internal static object CompareVersion(object lhs, object rhs) { }

	// RVA: 0x73EF6F8
	internal object IsValid() { }

	// RVA: 0x73EF8A0
	internal object GetPlayableOutputType() { }

	// RVA: 0x73EFA48
	internal object SetReferenceObject(object target) { }

	// RVA: 0x73EFC1C
	internal object SetUserData(object target) { }

	// RVA: 0x73EFDF0
	internal object GetSourcePlayable() { }

	// RVA: 0x73EFFC4
	internal object SetSourcePlayable(object target, object port) { }

	// RVA: 0x73F01A0
	internal object GetSourceOutputPort() { }

	// RVA: 0x73F0348
	internal object SetWeight(object weight) { }

	// RVA: 0x73F0504
	internal object PushNotification(object origin, object notification, object context) { }

	// RVA: 0x73F0714
	internal object AddNotificationReceiver(object receiver) { }

	// RVA: 0x73F08E8
	private static object .cctor() { }

	// RVA: 0x73EF7A4
	private static object IsValid_Injected(object _unity_self) { }

	// RVA: 0x73EF94C
	private static object GetPlayableOutputType_Injected(object _unity_self) { }

	// RVA: 0x73EFB00
	private static object SetReferenceObject_Injected(object _unity_self, object target) { }

	// RVA: 0x73EFCD4
	private static object SetUserData_Injected(object _unity_self, object target) { }

	// RVA: 0x73EFEA8
	private static object GetSourcePlayable_Injected(object _unity_self, object ret) { }

	// RVA: 0x73F007C
	private static object SetSourcePlayable_Injected(object _unity_self, object target, object port) { }

	// RVA: 0x73F024C
	private static object GetSourceOutputPort_Injected(object _unity_self) { }

	// RVA: 0x73F03F4
	private static object SetWeight_Injected(object _unity_self, object weight) { }

	// RVA: 0x73F05CC
	private static object PushNotification_Injected(object _unity_self, object origin, object notification, object context) { }

	// RVA: 0x73F07CC
	private static object AddNotificationReceiver_Injected(object _unity_self, object receiver) { }

}

// Namespace: UnityEngine.Playables
public struct ScriptPlayable<T0>
{

	// Fields
	private object m_Handle; // 0x0
	private static readonly object m_NullPlayable; // 0x0

	// Properties
	public static object Null { get; }

	// Methods

	// RVA: -1
	public static object get_Null() { }

	// RVA: -1
	public static object Create(object graph, object inputCount) { }

	// RVA: -1
	public static object Create(object graph, object template, object inputCount) { }

	// RVA: -1
	private static object CreateHandle(object graph, object template, object inputCount) { }

	// RVA: -1
	private static object CreateScriptInstance() { }

	// RVA: -1
	private static object CloneScriptInstance(object source) { }

	// RVA: -1
	private static object CloneScriptInstanceFromEngineObject(object source) { }

	// RVA: -1
	private static object CloneScriptInstanceFromIClonable(object source) { }

	// RVA: -1
	internal object .ctor(object handle) { }

	// RVA: -1
	public object GetHandle() { }

	// RVA: -1
	public object GetBehaviour() { }

	// RVA: -1
	public static object op_Implicit(object playable) { }

	// RVA: -1
	public static object op_Explicit(object playable) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.Playables
public static class ScriptPlayableBinding
{

	// Methods

	// RVA: 0x73F0934
	public static object Create(object name, object key, object type) { }

	// RVA: 0x73F0A50
	private static object CreateScriptOutput(object graph, object name) { }

}

// Namespace: UnityEngine.Playables
public struct ScriptPlayableOutput
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public static object Null { get; }

	// Methods

	// RVA: 0x73F0AEC
	public static object Create(object graph, object name) { }

	// RVA: 0x73F0C58
	internal object .ctor(object handle) { }

	// RVA: 0x73F0B8C
	public static object get_Null() { }

	// RVA: 0x73F0DE8
	public object GetHandle() { }

	// RVA: 0x73F0B88
	public static object op_Implicit(object output) { }

}

// Namespace: UnityEngine.Device
public static class SystemInfo
{

	// Properties
	public static object systemMemorySize { get; }
	public static object deviceUniqueIdentifier { get; }
	public static object deviceName { get; }
	public static object deviceModel { get; }
	public static object deviceType { get; }
	public static object graphicsMemorySize { get; }
	public static object graphicsDeviceName { get; }
	public static object graphicsDeviceID { get; }
	public static object graphicsDeviceType { get; }
	public static object supportedRenderTargetCount { get; }
	public static object maxGraphicsBufferSize { get; }

	// Methods

	// RVA: 0x73F0E00
	public static object get_systemMemorySize() { }

	// RVA: 0x73F0E08
	public static object get_deviceUniqueIdentifier() { }

	// RVA: 0x73F0E10
	public static object get_deviceName() { }

	// RVA: 0x73F0E18
	public static object get_deviceModel() { }

	// RVA: 0x73F0E20
	public static object get_deviceType() { }

	// RVA: 0x73F0E28
	public static object get_graphicsMemorySize() { }

	// RVA: 0x73F0E30
	public static object get_graphicsDeviceName() { }

	// RVA: 0x73F0E38
	public static object get_graphicsDeviceID() { }

	// RVA: 0x73F0E40
	public static object get_graphicsDeviceType() { }

	// RVA: 0x73F0E48
	public static object get_supportedRenderTargetCount() { }

	// RVA: 0x73F0E50
	public static object SupportsRenderTextureFormat(object format) { }

	// RVA: 0x73F0E58
	public static object SupportsTextureFormat(object format) { }

	// RVA: 0x73F0E60
	public static object get_maxGraphicsBufferSize() { }

	// RVA: 0x73F0E68
	public static object IsFormatSupported(object format, object usage) { }

}

// Namespace: UnityEngine.Experimental.U2D
internal struct SpriteIntermediateRendererInfo
{

	// Fields
	public object SpriteID; // 0xFFFFFFFFFFFFFFF8
	public object TextureID; // 0xFFFFFFFFFFFFFFFC
	public object MaterialID; // 0x0
	public object Color; // 0x4
	public object Transform; // 0x14
	public object Bounds; // 0x54
	public object Layer; // 0x6C
	public object SortingLayer; // 0x70
	public object SortingOrder; // 0x74
	public object SceneCullingMask; // 0x78
	public object IndexData; // 0x80
	public object VertexData; // 0x88
	public object IndexCount; // 0x90
	public object VertexCount; // 0x94
	public object ShaderChannelMask; // 0x98
}

// Namespace: UnityEngine.Experimental.U2D
internal class SpriteRendererGroup
{
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public enum LightType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Directional;
	public const object Point;
	public const object Spot;
	public const object Rectangle;
	public const object Disc;
	public const object SpotPyramidShape;
	public const object SpotBoxShape;
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public enum LightMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Realtime;
	public const object Mixed;
	public const object Baked;
	public const object Unknown;
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public enum FalloffType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object InverseSquared;
	public const object InverseSquaredNoRangeAttenuation;
	public const object Linear;
	public const object Legacy;
	public const object Undefined;
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public enum AngularFalloffType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LUT;
	public const object AnalyticAndInnerAngle;
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public struct LinearColor
{

	// Fields
	private object m_red; // 0xFFFFFFFFFFFFFFF8
	private object m_green; // 0xFFFFFFFFFFFFFFFC
	private object m_blue; // 0x0
	private object m_intensity; // 0x4

	// Properties
	public object red { get; set; }
	public object green { get; set; }
	public object blue { get; set; }

	// Methods

	// RVA: 0x73F0E7C
	public object get_red() { }

	// RVA: 0x73F0E8C
	public object set_red(object value) { }

	// RVA: 0x73F0F48
	public object get_green() { }

	// RVA: 0x73F0F58
	public object set_green(object value) { }

	// RVA: 0x73F1014
	public object get_blue() { }

	// RVA: 0x73F1024
	public object set_blue(object value) { }

	// RVA: 0x73F10E0
	public static object Convert(object color, object intensity) { }

	// RVA: 0x73F13C0
	public static object Black() { }

}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public struct DirectionalLight
{

	// Fields
	public object instanceID; // 0xFFFFFFFFFFFFFFF8
	public object shadow; // 0xFFFFFFFFFFFFFFFC
	public object mode; // 0xFFFFFFFFFFFFFFFD
	public object position; // 0x0
	public object orientation; // 0xC
	public object color; // 0x1C
	public object indirectColor; // 0x2C
	public object penumbraWidthRadian; // 0x3C
	public object direction; // 0x40
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public struct PointLight
{

	// Fields
	public object instanceID; // 0xFFFFFFFFFFFFFFF8
	public object shadow; // 0xFFFFFFFFFFFFFFFC
	public object mode; // 0xFFFFFFFFFFFFFFFD
	public object position; // 0x0
	public object orientation; // 0xC
	public object color; // 0x1C
	public object indirectColor; // 0x2C
	public object range; // 0x3C
	public object sphereRadius; // 0x40
	public object falloff; // 0x44
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public struct SpotLight
{

	// Fields
	public object instanceID; // 0xFFFFFFFFFFFFFFF8
	public object shadow; // 0xFFFFFFFFFFFFFFFC
	public object mode; // 0xFFFFFFFFFFFFFFFD
	public object position; // 0x0
	public object orientation; // 0xC
	public object color; // 0x1C
	public object indirectColor; // 0x2C
	public object range; // 0x3C
	public object sphereRadius; // 0x40
	public object coneAngle; // 0x44
	public object innerConeAngle; // 0x48
	public object falloff; // 0x4C
	public object angularFalloff; // 0x4D
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public struct RectangleLight
{

	// Fields
	public object instanceID; // 0xFFFFFFFFFFFFFFF8
	public object shadow; // 0xFFFFFFFFFFFFFFFC
	public object mode; // 0xFFFFFFFFFFFFFFFD
	public object position; // 0x0
	public object orientation; // 0xC
	public object color; // 0x1C
	public object indirectColor; // 0x2C
	public object range; // 0x3C
	public object width; // 0x40
	public object height; // 0x44
	public object falloff; // 0x48
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public struct DiscLight
{

	// Fields
	public object instanceID; // 0xFFFFFFFFFFFFFFF8
	public object shadow; // 0xFFFFFFFFFFFFFFFC
	public object mode; // 0xFFFFFFFFFFFFFFFD
	public object position; // 0x0
	public object orientation; // 0xC
	public object color; // 0x1C
	public object indirectColor; // 0x2C
	public object range; // 0x3C
	public object radius; // 0x40
	public object falloff; // 0x44
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public struct Cookie
{

	// Fields
	public object instanceID; // 0xFFFFFFFFFFFFFFF8
	public object scale; // 0xFFFFFFFFFFFFFFFC
	public object sizes; // 0x0
}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public struct LightDataGI
{

	// Fields
	public object instanceID; // 0xFFFFFFFFFFFFFFF8
	public object cookieID; // 0xFFFFFFFFFFFFFFFC
	public object cookieScale; // 0x0
	public object color; // 0x4
	public object indirectColor; // 0x14
	public object orientation; // 0x24
	public object position; // 0x34
	public object range; // 0x40
	public object coneAngle; // 0x44
	public object innerConeAngle; // 0x48
	public object shape0; // 0x4C
	public object shape1; // 0x50
	public object type; // 0x54
	public object mode; // 0x55
	public object shadow; // 0x56
	public object falloff; // 0x57

	// Methods

	// RVA: 0x73F1750
	public object Init(object light, object cookie) { }

	// RVA: 0x73F1830
	public object Init(object light, object cookie) { }

	// RVA: 0x73F1920
	public object Init(object light, object cookie) { }

	// RVA: 0x73F1A18
	public object Init(object light, object cookie) { }

	// RVA: 0x73F1B00
	public object Init(object light, object cookie) { }

	// RVA: 0x73F1BF0
	public object InitNoBake(object lightInstanceID) { }

}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public static class LightmapperUtils
{

	// Methods

	// RVA: 0x73F1C10
	public static object Extract(object baketype) { }

	// RVA: 0x73F1C28
	public static object ExtractIndirect(object l) { }

	// RVA: 0x73F1CB4
	public static object ExtractInnerCone(object l) { }

	// RVA: 0x73F1D18
	private static object ExtractColorTemperature(object l) { }

	// RVA: 0x73F1DB0
	private static object ApplyColorTemperature(object cct, object lightColor) { }

	// RVA: 0x73F1E04
	public static object Extract(object l, object dir) { }

	// RVA: 0x73F2074
	public static object Extract(object l, object point) { }

	// RVA: 0x73F22FC
	public static object Extract(object l, object spot) { }

	// RVA: 0x73F25E4
	public static object Extract(object l, object rect) { }

	// RVA: 0x73F286C
	public static object Extract(object l, object disc) { }

	// RVA: 0x73F2AF4
	public static object Extract(object l, object cookie) { }

}

// Namespace: 
public sealed class RequestLightsDelegate
{

	// Methods

	// RVA: 0x73F30D0
	public object .ctor(object object, object method) { }

	// RVA: 0x73F3234
	public virtual object Invoke(object requests, object lightsOutput) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x73F3248
	private static object .cctor() { }

	// RVA: 0x73F32A8
	public object .ctor() { }

	// RVA: 0x73F32B0
	internal object <.cctor>b__7_0(object requests, object lightsOutput) { }

}

// Namespace: UnityEngine.Experimental.GlobalIllumination
public static class Lightmapping
{

	// Fields
	private static readonly object s_DefaultDelegate; // 0x0
	private static object s_RequestLightsDelegate; // 0x8

	// Methods

	// RVA: 0x73F2CF8
	public static object SetDelegate(object del) { }

	// RVA: 0x73F2DB8
	public static object GetDelegate() { }

	// RVA: 0x73F2E34
	public static object ResetDelegate() { }

	// RVA: 0x73F2EB8
	internal static object RequestLights(object lights, object outLightsPtr, object outLightsCount) { }

	// RVA: 0x73F2F90
	private static object .cctor() { }

}

// Namespace: UnityEngine.Experimental.Playables
public struct CameraPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73F36EC
	public object GetHandle() { }

	// RVA: 0x73F3704
	public object Equals(object other) { }

}

// Namespace: UnityEngine.Experimental.Playables
public struct MaterialEffectPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73F38CC
	public object GetHandle() { }

	// RVA: 0x73F38E4
	public object Equals(object other) { }

}

// Namespace: UnityEngine.Experimental.Playables
public struct TextureMixerPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73F3AAC
	public object GetHandle() { }

	// RVA: 0x73F3AC4
	public object Equals(object other) { }

}

// Namespace: UnityEngine.Experimental.Playables
public struct TexturePlayableOutput
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x73F3C8C
	public object GetHandle() { }

}

// Namespace: UnityEngine.Experimental.Rendering
internal class BuiltinRuntimeReflectionSystem
{

	// Methods

	// RVA: 0x73F3CA4
	public object TickRealtimeProbes() { }

	// RVA: 0x73F3D24
	public object Dispose() { }

	// RVA: 0x73F3D28
	private object Dispose(object disposing) { }

	// RVA: 0x73F3CE4
	private static object BuiltinUpdate() { }

	// RVA: 0x73F3D2C
	private static object Internal_BuiltinRuntimeReflectionSystem_New() { }

	// RVA: 0x73F3D84
	public object .ctor() { }

}

// Namespace: UnityEngine.Experimental.Rendering
public interface IScriptableRuntimeReflectionSystem
{

	// Methods

	// RVA: -1
	public abstract object TickRealtimeProbes() { }

}

// Namespace: UnityEngine.Experimental.Rendering
public static class ScriptableRuntimeReflectionSystemSettings
{

	// Fields
	private static object s_Instance; // 0x0

	// Properties
	private static object Internal_ScriptableRuntimeReflectionSystemSettings_system { set; }
	private static object Internal_ScriptableRuntimeReflectionSystemSettings_instance { get; }

	// Methods

	// RVA: 0x73F3D8C
	private static object set_Internal_ScriptableRuntimeReflectionSystemSettings_system(object value) { }

	// RVA: 0x73F3F50
	private static object get_Internal_ScriptableRuntimeReflectionSystemSettings_instance() { }

	// RVA: 0x73F3FCC
	private static object ScriptingDirtyReflectionSystemInstance() { }

	// RVA: 0x73F400C
	private static object .cctor() { }

}

// Namespace: UnityEngine.Experimental.Rendering
internal class ScriptableRuntimeReflectionSystemWrapper
{

	// Fields
	private object <implementation>k__BackingField; // 0x8

	// Properties
	internal object implementation { get; set; }

	// Methods

	// RVA: 0x73F4090
	internal object get_implementation() { }

	// RVA: 0x73F4098
	internal object set_implementation(object value) { }

	// RVA: 0x73F40A0
	private object Internal_ScriptableRuntimeReflectionSystemWrapper_TickRealtimeProbes(object result) { }

	// RVA: 0x73F4088
	public object .ctor() { }

}

// Namespace: UnityEngine.Experimental.Rendering
public enum WaitForPresentSyncPoint
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BeginFrame;
	public const object EndFrame;
}

// Namespace: UnityEngine.Experimental.Rendering
public static class GraphicsDeviceSettings
{

	// Properties
	public static object waitForPresentSyncPoint { set; }

	// Methods

	// RVA: 0x73F418C
	public static object set_waitForPresentSyncPoint(object value) { }

}

// Namespace: UnityEngine.Experimental.Rendering
public enum TextureCreationFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object MipChain;
	public const object DontInitializePixels;
	public const object Crunch;
	public const object DontUploadUponCreate;
	public const object IgnoreMipmapLimit;
}

// Namespace: UnityEngine.Experimental.Rendering
public enum FormatUsage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Sample;
	public const object Linear;
	public const object Sparse;
	public const object Render;
	public const object Blend;
	public const object GetPixels;
	public const object SetPixels;
	public const object SetPixels32;
	public const object ReadPixels;
	public const object LoadStore;
	public const object MSAA2x;
	public const object MSAA4x;
	public const object MSAA8x;
	public const object StencilSampling;
}

// Namespace: UnityEngine.Experimental.Rendering
public enum DefaultFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LDR;
	public const object HDR;
	public const object DepthStencil;
	public const object Shadow;
	public const object Video;
}

// Namespace: UnityEngine.Experimental.Rendering
public enum GraphicsFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object R8_SRGB;
	public const object R8G8_SRGB;
	public const object R8G8B8_SRGB;
	public const object R8G8B8A8_SRGB;
	public const object R8_UNorm;
	public const object R8G8_UNorm;
	public const object R8G8B8_UNorm;
	public const object R8G8B8A8_UNorm;
	public const object R8_SNorm;
	public const object R8G8_SNorm;
	public const object R8G8B8_SNorm;
	public const object R8G8B8A8_SNorm;
	public const object R8_UInt;
	public const object R8G8_UInt;
	public const object R8G8B8_UInt;
	public const object R8G8B8A8_UInt;
	public const object R8_SInt;
	public const object R8G8_SInt;
	public const object R8G8B8_SInt;
	public const object R8G8B8A8_SInt;
	public const object R16_UNorm;
	public const object R16G16_UNorm;
	public const object R16G16B16_UNorm;
	public const object R16G16B16A16_UNorm;
	public const object R16_SNorm;
	public const object R16G16_SNorm;
	public const object R16G16B16_SNorm;
	public const object R16G16B16A16_SNorm;
	public const object R16_UInt;
	public const object R16G16_UInt;
	public const object R16G16B16_UInt;
	public const object R16G16B16A16_UInt;
	public const object R16_SInt;
	public const object R16G16_SInt;
	public const object R16G16B16_SInt;
	public const object R16G16B16A16_SInt;
	public const object R32_UInt;
	public const object R32G32_UInt;
	public const object R32G32B32_UInt;
	public const object R32G32B32A32_UInt;
	public const object R32_SInt;
	public const object R32G32_SInt;
	public const object R32G32B32_SInt;
	public const object R32G32B32A32_SInt;
	public const object R16_SFloat;
	public const object R16G16_SFloat;
	public const object R16G16B16_SFloat;
	public const object R16G16B16A16_SFloat;
	public const object R32_SFloat;
	public const object R32G32_SFloat;
	public const object R32G32B32_SFloat;
	public const object R32G32B32A32_SFloat;
	public const object B8G8R8_SRGB;
	public const object B8G8R8A8_SRGB;
	public const object B8G8R8_UNorm;
	public const object B8G8R8A8_UNorm;
	public const object B8G8R8_SNorm;
	public const object B8G8R8A8_SNorm;
	public const object B8G8R8_UInt;
	public const object B8G8R8A8_UInt;
	public const object B8G8R8_SInt;
	public const object B8G8R8A8_SInt;
	public const object R4G4B4A4_UNormPack16;
	public const object B4G4R4A4_UNormPack16;
	public const object R5G6B5_UNormPack16;
	public const object B5G6R5_UNormPack16;
	public const object R5G5B5A1_UNormPack16;
	public const object B5G5R5A1_UNormPack16;
	public const object A1R5G5B5_UNormPack16;
	public const object E5B9G9R9_UFloatPack32;
	public const object B10G11R11_UFloatPack32;
	public const object A2B10G10R10_UNormPack32;
	public const object A2B10G10R10_UIntPack32;
	public const object A2B10G10R10_SIntPack32;
	public const object A2R10G10B10_UNormPack32;
	public const object A2R10G10B10_UIntPack32;
	public const object A2R10G10B10_SIntPack32;
	public const object A2R10G10B10_XRSRGBPack32;
	public const object A2R10G10B10_XRUNormPack32;
	public const object R10G10B10_XRSRGBPack32;
	public const object R10G10B10_XRUNormPack32;
	public const object A10R10G10B10_XRSRGBPack32;
	public const object A10R10G10B10_XRUNormPack32;
	public const object D16_UNorm;
	public const object D24_UNorm;
	public const object D24_UNorm_S8_UInt;
	public const object D32_SFloat;
	public const object D32_SFloat_S8_UInt;
	public const object S8_UInt;
	public const object RGB_DXT1_SRGB;
	public const object RGBA_DXT1_SRGB;
	public const object RGB_DXT1_UNorm;
	public const object RGBA_DXT1_UNorm;
	public const object RGBA_DXT3_SRGB;
	public const object RGBA_DXT3_UNorm;
	public const object RGBA_DXT5_SRGB;
	public const object RGBA_DXT5_UNorm;
	public const object R_BC4_UNorm;
	public const object R_BC4_SNorm;
	public const object RG_BC5_UNorm;
	public const object RG_BC5_SNorm;
	public const object RGB_BC6H_UFloat;
	public const object RGB_BC6H_SFloat;
	public const object RGBA_BC7_SRGB;
	public const object RGBA_BC7_UNorm;
	public const object RGB_PVRTC_2Bpp_SRGB;
	public const object RGB_PVRTC_2Bpp_UNorm;
	public const object RGB_PVRTC_4Bpp_SRGB;
	public const object RGB_PVRTC_4Bpp_UNorm;
	public const object RGBA_PVRTC_2Bpp_SRGB;
	public const object RGBA_PVRTC_2Bpp_UNorm;
	public const object RGBA_PVRTC_4Bpp_SRGB;
	public const object RGBA_PVRTC_4Bpp_UNorm;
	public const object RGB_ETC_UNorm;
	public const object RGB_ETC2_SRGB;
	public const object RGB_ETC2_UNorm;
	public const object RGB_A1_ETC2_SRGB;
	public const object RGB_A1_ETC2_UNorm;
	public const object RGBA_ETC2_SRGB;
	public const object RGBA_ETC2_UNorm;
	public const object R_EAC_UNorm;
	public const object R_EAC_SNorm;
	public const object RG_EAC_UNorm;
	public const object RG_EAC_SNorm;
	public const object RGBA_ASTC4X4_SRGB;
	public const object RGBA_ASTC4X4_UNorm;
	public const object RGBA_ASTC5X5_SRGB;
	public const object RGBA_ASTC5X5_UNorm;
	public const object RGBA_ASTC6X6_SRGB;
	public const object RGBA_ASTC6X6_UNorm;
	public const object RGBA_ASTC8X8_SRGB;
	public const object RGBA_ASTC8X8_UNorm;
	public const object RGBA_ASTC10X10_SRGB;
	public const object RGBA_ASTC10X10_UNorm;
	public const object RGBA_ASTC12X12_SRGB;
	public const object RGBA_ASTC12X12_UNorm;
	public const object YUV2;
	public const object DepthAuto;
	public const object ShadowAuto;
	public const object VideoAuto;
	public const object RGBA_ASTC4X4_UFloat;
	public const object RGBA_ASTC5X5_UFloat;
	public const object RGBA_ASTC6X6_UFloat;
	public const object RGBA_ASTC8X8_UFloat;
	public const object RGBA_ASTC10X10_UFloat;
	public const object RGBA_ASTC12X12_UFloat;
	public const object D16_UNorm_S8_UInt;
	public const object RGBA_ASTC3X3X3_SRGB;
	public const object RGBA_ASTC3X3X3_UNorm;
	public const object RGBA_ASTC3X3X3_UFloat;
	public const object RGBA_ASTC4X4X4_SRGB;
	public const object RGBA_ASTC4X4X4_UNorm;
	public const object RGBA_ASTC4X4X4_UFloat;
}

// Namespace: UnityEngine.Experimental.Rendering
public class GraphicsFormatUtility
{

	// Fields
	private static readonly object tableNoStencil; // 0x0
	private static readonly object tableStencil; // 0x8

	// Methods

	// RVA: 0x73F41DC
	internal static object GetFormat(object texture) { }

	// RVA: 0x73F422C
	public static object GetGraphicsFormat(object format, object isSRGB) { }

	// RVA: 0x73F42E4
	private static object GetGraphicsFormat_Native_TextureFormat(object format, object isSRGB) { }

	// RVA: 0x73F4348
	public static object GetGraphicsFormat(object format, object isSRGB) { }

	// RVA: 0x73F4400
	private static object GetGraphicsFormat_Native_RenderTextureFormat(object format, object isSRGB) { }

	// RVA: 0x73F4464
	public static object GetGraphicsFormat(object format, object readWrite) { }

	// RVA: 0x73F4584
	private static object GetDepthStencilFormatFromBitsLegacy_Native(object minimumDepthBits) { }

	// RVA: 0x73F45D4
	internal static object GetDepthStencilFormat(object minimumDepthBits) { }

	// RVA: 0x73F4680
	public static object GetDepthBits(object format) { }

	// RVA: 0x73F46D0
	public static object GetDepthStencilFormat(object minimumDepthBits, object minimumStencilBits) { }

	// RVA: 0x73F4920
	public static object IsSRGBFormat(object format) { }

	// RVA: 0x73F4970
	public static object GetRenderTextureFormat(object format) { }

	// RVA: 0x73F49C0
	private static object IsCompressedFormat_Native_TextureFormat(object format) { }

	// RVA: 0x73F4A10
	public static object IsCompressedFormat(object format) { }

	// RVA: 0x73F4ABC
	private static object CanDecompressFormat(object format, object wholeImage) { }

	// RVA: 0x73F4B20
	internal static object CanDecompressFormat(object format) { }

	// RVA: 0x73F4BD4
	public static object IsDepthStencilFormat(object format) { }

	// RVA: 0x73F4C24
	public static object IsPVRTCFormat(object format) { }

	// RVA: 0x73F4C74
	public static object IsCrunchFormat(object format) { }

	// RVA: 0x73F4CC4
	private static object .cctor() { }

}

// Namespace: UnityEngine.Experimental.Rendering
public static class ShaderWarmup
{

	// Methods

	// RVA: 0x73F4DA0
	public static object WarmupShaderWithKeyWord(object shader, object keyWords) { }

}

// Namespace: UnityEngine.Experimental.Rendering
public sealed class RayTracingShader
{
}

// Namespace: UnityEngine.Assertions
public static class Assert
{

	// Fields
	public static object raiseExceptions; // 0x0

	// Methods

	// RVA: 0x73F4E04
	private static object Fail(object message, object userMessage) { }

	// RVA: 0x73F4FD8
	public static object IsTrue(object condition) { }

	// RVA: 0x73F50B4
	public static object IsTrue(object condition, object message) { }

	// RVA: 0x73F5210
	public static object IsFalse(object condition, object message) { }

	// RVA: -1
	public static object AreEqual(object expected, object actual) { }

	// RVA: -1
	public static object AreEqual(object expected, object actual, object message) { }

	// RVA: -1
	public static object AreEqual(object expected, object actual, object message, object comparer) { }

	// RVA: 0x73F52B0
	public static object AreEqual(object expected, object actual, object message) { }

	// RVA: -1
	public static object IsNull(object value) { }

	// RVA: -1
	public static object IsNull(object value, object message) { }

	// RVA: 0x73F55D0
	public static object IsNull(object value, object message) { }

	// RVA: -1
	public static object IsNotNull(object value) { }

	// RVA: -1
	public static object IsNotNull(object value, object message) { }

	// RVA: 0x73F5840
	public static object IsNotNull(object value, object message) { }

	// RVA: 0x73F5934
	public static object AreEqual(object expected, object actual) { }

	// RVA: 0x73F59D0
	private static object .cctor() { }

}

// Namespace: UnityEngine.Assertions
public class AssertionException
{

	// Fields
	private object m_UserMessage; // 0x88

	// Properties
	public override object Message { get; }

	// Methods

	// RVA: 0x73F4F58
	public object .ctor(object message, object userMessage) { }

	// RVA: 0x73F5A20
	public override object get_Message() { }

}

// Namespace: UnityEngine.Assertions
internal class AssertionMessageUtil
{

	// Methods

	// RVA: 0x73F5A94
	public static object GetMessage(object failureMessage) { }

	// RVA: 0x73F5B94
	public static object GetMessage(object failureMessage, object expected) { }

	// RVA: 0x73F53C0
	public static object GetEqualityMessage(object actual, object expected, object expectEqual) { }

	// RVA: 0x73F56C4
	public static object NullFailureMessage(object value, object expectNull) { }

	// RVA: 0x73F5154
	public static object BooleanFailureMessage(object expected) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=6
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=20
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 0EBBFED81071BF15F38AA1387D6D74E5788591B4AA6E85C7B739CF903789D438; // 0x0
	internal static readonly object 39D974909C7E64675317DD1A8583B8D8DE92E68B180532FADD22B482AD93DC83; // 0x6
	internal static readonly object C77A066B9EC0272B121AD30CBAEDA4AD20F986D49CC6D0007EBF45888D8B09BF; // 0x1A
}

