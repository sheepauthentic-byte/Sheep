// Namespace: 
internal class <Module>
{
}

// Namespace: 
internal sealed class Locale
{

	// Methods

	// RVA: 0x39459F8
	public static object GetText(object msg) { }

	// RVA: 0x39459FC
	public static object GetText(object fmt, object args) { }

}

// Namespace: Mono.Security
public class ASN1
{

	// Fields
	private object m_nTag; // 0x8
	private object m_aValue; // 0x10
	private object elist; // 0x18

	// Properties
	public object Count { get; }
	public object Tag { get; }
	public object Length { get; }
	public object Value { get; set; }
	public object Item { get; }

	// Methods

	// RVA: 0x3945A04
	public object .ctor(object tag) { }

	// RVA: 0x3945A34
	public object .ctor(object tag, object data) { }

	// RVA: 0x3945A70
	public object .ctor(object data) { }

	// RVA: 0x3945D14
	public object get_Count() { }

	// RVA: 0x3945D68
	public object get_Tag() { }

	// RVA: 0x3945D70
	public object get_Length() { }

	// RVA: 0x3945D88
	public object get_Value() { }

	// RVA: 0x3945E38
	public object set_Value(object value) { }

	// RVA: 0x3945EF4
	private object CompareArray(object array1, object array2) { }

	// RVA: 0x3945F7C
	public object CompareValue(object value) { }

	// RVA: 0x3946010
	public object Add(object asn1) { }

	// RVA: 0x39460C4
	public virtual object GetBytes() { }

	// RVA: 0x3945BF0
	protected object Decode(object asn1, object anPos, object anLength) { }

	// RVA: 0x3946904
	protected object DecodeTLV(object asn1, object pos, object tag, object length, object content) { }

	// RVA: 0x3946A2C
	public object get_Item(object index) { }

	// RVA: 0x3946BBC
	public object Element(object index, object anTag) { }

	// RVA: 0x3946D84
	public override object ToString() { }

}

// Namespace: Mono.Security
public static class ASN1Convert
{

	// Methods

	// RVA: 0x39470D0
	public static object FromInt32(object value) { }

	// RVA: 0x3947294
	public static object FromOid(object oid) { }

	// RVA: 0x3947370
	public static object FromUnsignedBigInteger(object big) { }

	// RVA: 0x3947484
	public static object ToInt32(object asn1) { }

	// RVA: 0x39475BC
	public static object ToOid(object asn1) { }

	// RVA: 0x3947870
	public static object ToDateTime(object time) { }

}

// Namespace: Mono.Security
internal sealed class BitConverterLE
{

	// Methods

	// RVA: 0x3947E04
	private static object GetUIntBytes(object bytes) { }

	// RVA: 0x3947EB0
	private static object GetULongBytes(object bytes) { }

	// RVA: 0x3947270
	internal static object GetBytes(object value) { }

	// RVA: 0x3947F9C
	internal static object GetBytes(object value) { }

	// RVA: 0x3947FC0
	private static object UShortFromBytes(object dst, object src, object startIndex) { }

	// RVA: 0x3948014
	private static object UIntFromBytes(object dst, object src, object startIndex) { }

	// RVA: 0x3948098
	internal static object ToInt32(object value, object startIndex) { }

	// RVA: 0x39480C8
	internal static object ToUInt16(object value, object startIndex) { }

	// RVA: 0x3948128
	internal static object ToUInt32(object value, object startIndex) { }

}

// Namespace: 
public class ContentInfo
{

	// Fields
	private object contentType; // 0x8
	private object content; // 0x10

	// Properties
	public object ASN1 { get; }
	public object Content { get; set; }
	public object ContentType { get; set; }

	// Methods

	// RVA: 0x3948158
	public object .ctor() { }

	// RVA: 0x39481D4
	public object .ctor(object oid) { }

	// RVA: 0x3948254
	public object .ctor(object data) { }

	// RVA: 0x39482C0
	public object .ctor(object asn1) { }

	// RVA: 0x39484B0
	public object get_ASN1() { }

	// RVA: 0x3948584
	public object get_Content() { }

	// RVA: 0x394858C
	public object set_Content(object value) { }

	// RVA: 0x3948594
	public object get_ContentType() { }

	// RVA: 0x394859C
	public object set_ContentType(object value) { }

	// RVA: 0x39484B4
	internal object GetASN1() { }

}

// Namespace: 
public class EncryptedData
{

	// Fields
	private object _version; // 0x8
	private object _content; // 0x10
	private object _encryptionAlgorithm; // 0x18
	private object _encrypted; // 0x20

	// Properties
	public object EncryptionAlgorithm { get; }
	public object EncryptedContent { get; }

	// Methods

	// RVA: 0x39485A4
	public object .ctor() { }

	// RVA: 0x39485CC
	public object .ctor(object asn1) { }

	// RVA: 0x3948984
	public object get_EncryptionAlgorithm() { }

	// RVA: 0x394898C
	public object get_EncryptedContent() { }

}

// Namespace: 
public class SignedData
{

	// Fields
	private object version; // 0x8
	private object hashAlgorithm; // 0x10
	private object contentInfo; // 0x18
	private object certs; // 0x20
	private object crls; // 0x28
	private object signerInfo; // 0x30
	private object mda; // 0x38

	// Properties
	public object Certificates { get; }
	public object ContentInfo { get; }
	public object HashName { set; }
	public object SignerInfo { get; }

	// Methods

	// RVA: 0x3948A04
	public object .ctor(object asn1) { }

	// RVA: 0x3949C00
	public object get_Certificates() { }

	// RVA: 0x3949C08
	public object get_ContentInfo() { }

	// RVA: 0x3949BD8
	public object set_HashName(object value) { }

	// RVA: 0x3949C10
	public object get_SignerInfo() { }

	// RVA: 0x39499CC
	internal object OidToName(object oid) { }

}

// Namespace: 
public class SignerInfo
{

	// Fields
	private object version; // 0x8
	private object hashAlgorithm; // 0x10
	private object authenticatedAttributes; // 0x18
	private object unauthenticatedAttributes; // 0x20
	private object signature; // 0x28
	private object issuer; // 0x30
	private object serial; // 0x38
	private object ski; // 0x40

	// Properties
	public object IssuerName { get; }
	public object SerialNumber { get; }
	public object AuthenticatedAttributes { get; }
	public object HashName { get; set; }
	public object Signature { get; }
	public object UnauthenticatedAttributes { get; }
	public object Version { get; }

	// Methods

	// RVA: 0x394993C
	public object .ctor() { }

	// RVA: 0x39493D8
	public object .ctor(object asn1) { }

	// RVA: 0x3949DF4
	public object get_IssuerName() { }

	// RVA: 0x3949DFC
	public object get_SerialNumber() { }

	// RVA: 0x3949E74
	public object get_AuthenticatedAttributes() { }

	// RVA: 0x3949E7C
	public object get_HashName() { }

	// RVA: 0x3949E84
	public object set_HashName(object value) { }

	// RVA: 0x3949E8C
	public object get_Signature() { }

	// RVA: 0x3949F04
	public object get_UnauthenticatedAttributes() { }

	// RVA: 0x3949F0C
	public object get_Version() { }

}

// Namespace: Mono.Security
public sealed class PKCS7
{
}

// Namespace: Mono.Security.X509
internal class SafeBag
{

	// Fields
	private object _bagOID; // 0x8
	private object _asn1; // 0x10

	// Properties
	public object BagOID { get; }
	public object ASN1 { get; }

	// Methods

	// RVA: 0x3949F14
	public object .ctor(object bagOID, object asn1) { }

	// RVA: 0x3949F4C
	public object get_BagOID() { }

	// RVA: 0x3949F54
	public object get_ASN1() { }

}

// Namespace: 
public class DeriveBytes
{

	// Fields
	private static object keyDiversifier; // 0x0
	private static object ivDiversifier; // 0x8
	private static object macDiversifier; // 0x10
	private object _hashName; // 0x8
	private object _iterations; // 0x10
	private object _password; // 0x18
	private object _salt; // 0x20

	// Properties
	public object HashName { set; }
	public object IterationCount { set; }
	public object Password { set; }
	public object Salt { set; }

	// Methods

	// RVA: 0x394CFAC
	public object .ctor() { }

	// RVA: 0x3954340
	public object set_HashName(object value) { }

	// RVA: 0x3954348
	public object set_IterationCount(object value) { }

	// RVA: 0x394CFB4
	public object set_Password(object value) { }

	// RVA: 0x394D07C
	public object set_Salt(object value) { }

	// RVA: 0x3954350
	private object Adjust(object a, object aOff, object b) { }

	// RVA: 0x3954414
	private object Derive(object diversifier, object n) { }

	// RVA: 0x394D138
	public object DeriveKey(object size) { }

	// RVA: 0x394D1AC
	public object DeriveIV(object size) { }

	// RVA: 0x3950050
	public object DeriveMAC(object size) { }

	// RVA: 0x3954A14
	private static object .cctor() { }

}

// Namespace: Mono.Security.X509
public class PKCS12
{

	// Fields
	private object _password; // 0x8
	private object _keyBags; // 0x10
	private object _secretBags; // 0x18
	private object _certs; // 0x20
	private object _keyBagsChanged; // 0x28
	private object _secretBagsChanged; // 0x29
	private object _certsChanged; // 0x2A
	private object _iterations; // 0x2C
	private object _safeBags; // 0x30
	private object _rng; // 0x38
	private static object password_max_length; // 0x0

	// Properties
	public object Password { set; }
	public object IterationCount { get; set; }
	public object Keys { get; }
	public object Certificates { get; }
	internal object RNG { get; }
	public static object MaximumPasswordLength { get; }

	// Methods

	// RVA: 0x3949F5C
	public object .ctor() { }

	// RVA: 0x394A038
	public object .ctor(object data) { }

	// RVA: 0x394ABB0
	public object .ctor(object data, object password) { }

	// RVA: 0x394A2E0
	private object Decode(object data) { }

	// RVA: 0x394B810
	protected override object Finalize() { }

	// RVA: 0x394A0B4
	public object set_Password(object value) { }

	// RVA: 0x394B8BC
	public object get_IterationCount() { }

	// RVA: 0x394B8C4
	public object set_IterationCount(object value) { }

	// RVA: 0x394B8CC
	public object get_Keys() { }

	// RVA: 0x394C378
	public object get_Certificates() { }

	// RVA: 0x394C8BC
	internal object get_RNG() { }

	// RVA: 0x394ADD8
	private object Compare(object expected, object actual) { }

	// RVA: 0x394C8F4
	private object GetSymmetricAlgorithm(object algorithmOid, object salt, object iterationCount) { }

	// RVA: 0x394C16C
	public object Decrypt(object algorithmOid, object salt, object iterationCount, object encryptedData) { }

	// RVA: 0x394B6D0
	public object Decrypt(object ed) { }

	// RVA: 0x394D268
	public object Encrypt(object algorithmOid, object salt, object iterationCount, object data) { }

	// RVA: 0x394D4E4
	private object GetExistingParameters(object found) { }

	// RVA: 0x394DDB8
	private object AddPrivateKey(object pki) { }

	// RVA: 0x394AE60
	private object ReadSafeBag(object safeBag) { }

	// RVA: 0x394E0C8
	private object Pkcs8ShroudedKeyBagSafeBag(object aa, object attributes) { }

	// RVA: 0x394F168
	private object CertificateSafeBag(object x509, object attributes) { }

	// RVA: 0x394ABF4
	private object MAC(object password, object salt, object iterations, object data) { }

	// RVA: 0x39500C4
	public object GetBytes() { }

	// RVA: 0x3952BD8
	private object EncryptedContentInfo(object safeBags, object algorithmOid) { }

	// RVA: 0x3952BD0
	public object AddCertificate(object cert) { }

	// RVA: 0x3952F40
	public object AddCertificate(object cert, object attributes) { }

	// RVA: 0x3952BC8
	public object RemoveCertificate(object cert) { }

	// RVA: 0x3953300
	public object RemoveCertificate(object cert, object attrs) { }

	// RVA: 0x3953BC8
	private object CompareAsymmetricAlgorithm(object a1, object a2) { }

	// RVA: 0x3953CD8
	public object AddPkcs8ShroudedKeyBag(object aa, object attributes) { }

	// RVA: 0x3954110
	public object Clone() { }

	// RVA: 0x3954274
	public static object get_MaximumPasswordLength() { }

	// RVA: 0x39542F0
	private static object .cctor() { }

}

// Namespace: Mono.Security.X509
public sealed class X501
{

	// Fields
	private static object countryName; // 0x0
	private static object organizationName; // 0x8
	private static object organizationalUnitName; // 0x10
	private static object commonName; // 0x18
	private static object localityName; // 0x20
	private static object stateOrProvinceName; // 0x28
	private static object streetAddress; // 0x30
	private static object serialNumber; // 0x38
	private static object domainComponent; // 0x40
	private static object userid; // 0x48
	private static object email; // 0x50
	private static object dnQualifier; // 0x58
	private static object title; // 0x60
	private static object surname; // 0x68
	private static object givenName; // 0x70
	private static object initial; // 0x78

	// Methods

	// RVA: 0x3949C18
	public static object ToString(object seq) { }

	// RVA: 0x3955870
	public static object ToString(object seq, object reversed, object separator, object quotes) { }

	// RVA: 0x3954B2C
	private static object AppendEntry(object sb, object entry, object quotes) { }

	// RVA: 0x3955B40
	private static object GetAttributeFromOid(object attributeType) { }

	// RVA: 0x3956C90
	private static object IsOid(object oid) { }

	// RVA: 0x3956D4C
	private static object ReadAttribute(object value, object pos) { }

	// RVA: 0x3956EB0
	private static object IsHex(object c) { }

	// RVA: 0x3956FC4
	private static object ReadHex(object value, object pos) { }

	// RVA: 0x39571CC
	private static object ReadEscaped(object sb, object value, object pos) { }

	// RVA: 0x39573A8
	private static object ReadQuoted(object sb, object value, object pos) { }

	// RVA: 0x3957564
	private static object ReadValue(object value, object pos) { }

	// RVA: 0x395784C
	public static object FromString(object rdn) { }

	// RVA: 0x3957A98
	private static object .cctor() { }

}

// Namespace: 
public class X509CrlEntry
{

	// Fields
	private object sn; // 0x8
	private object revocationDate; // 0x10
	private object extensions; // 0x18

	// Properties
	public object SerialNumber { get; }
	public object RevocationDate { get; }
	public object Extensions { get; }

	// Methods

	// RVA: 0x3958794
	internal object .ctor(object entry) { }

	// RVA: 0x3958FA8
	public object get_SerialNumber() { }

	// RVA: 0x3959624
	public object get_RevocationDate() { }

	// RVA: 0x395962C
	public object get_Extensions() { }

}

// Namespace: Mono.Security.X509
public class X509Crl
{

	// Fields
	private object issuer; // 0x8
	private object version; // 0x10
	private object thisUpdate; // 0x18
	private object nextUpdate; // 0x20
	private object entries; // 0x28
	private object signatureOID; // 0x30
	private object signature; // 0x38
	private object extensions; // 0x40
	private object encoded; // 0x48
	private object hash_value; // 0x50

	// Properties
	public object Extensions { get; }
	public object Hash { get; }
	public object IssuerName { get; }
	public object NextUpdate { get; }

	// Methods

	// RVA: 0x3957ECC
	public object .ctor(object crl) { }

	// RVA: 0x3957FD8
	private object Parse(object crl) { }

	// RVA: 0x39589FC
	public object get_Extensions() { }

	// RVA: 0x3958A04
	public object get_Hash() { }

	// RVA: 0x3958C50
	public object get_IssuerName() { }

	// RVA: 0x3958C58
	public object get_NextUpdate() { }

	// RVA: 0x3958C60
	private object Compare(object array1, object array2) { }

	// RVA: 0x3958CC8
	public object GetCrlEntry(object x509) { }

	// RVA: 0x3958D64
	public object GetCrlEntry(object serialNumber) { }

	// RVA: 0x395902C
	internal object VerifySignature(object dsa) { }

	// RVA: 0x3959370
	internal object VerifySignature(object rsa) { }

	// RVA: 0x395948C
	public object VerifySignature(object aa) { }

}

// Namespace: Mono.Security.X509
public class X509Certificate
{

	// Fields
	private object decoder; // 0x8
	private object m_encodedcert; // 0x10
	private object m_from; // 0x18
	private object m_until; // 0x20
	private object issuer; // 0x28
	private object m_issuername; // 0x30
	private object m_keyalgo; // 0x38
	private object m_keyalgoparams; // 0x40
	private object subject; // 0x48
	private object m_subject; // 0x50
	private object m_publickey; // 0x58
	private object signature; // 0x60
	private object m_signaturealgo; // 0x68
	private object m_signaturealgoparams; // 0x70
	private object certhash; // 0x78
	private object _rsa; // 0x80
	private object _dsa; // 0x88
	private object version; // 0x90
	private object serialnumber; // 0x98
	private object issuerUniqueID; // 0xA0
	private object subjectUniqueID; // 0xA8
	private object extensions; // 0xB0
	private static object encoding_error; // 0x0

	// Properties
	public object DSA { get; set; }
	public object Extensions { get; }
	public object Hash { get; }
	public virtual object IssuerName { get; }
	public virtual object KeyAlgorithm { get; }
	public virtual object KeyAlgorithmParameters { get; set; }
	public virtual object PublicKey { get; }
	public virtual object RSA { get; set; }
	public virtual object RawData { get; }
	public virtual object SerialNumber { get; }
	public virtual object Signature { get; }
	public virtual object SubjectName { get; }
	public virtual object ValidFrom { get; }
	public virtual object ValidUntil { get; }
	public object Version { get; }
	public object IsCurrent { get; }
	public object IsSelfSigned { get; }

	// Methods

	// RVA: 0x3959634
	private object Parse(object data) { }

	// RVA: 0x3949194
	public object .ctor(object data) { }

	// RVA: 0x395A290
	private object GetUnsignedBigInteger(object integer) { }

	// RVA: 0x394D980
	public object get_DSA() { }

	// RVA: 0x395A3C0
	public object set_DSA(object value) { }

	// RVA: 0x395A3D0
	public object get_Extensions() { }

	// RVA: 0x395A3D8
	public object get_Hash() { }

	// RVA: 0x395A6C8
	public virtual object get_IssuerName() { }

	// RVA: 0x395A6D0
	public virtual object get_KeyAlgorithm() { }

	// RVA: 0x395A6D8
	public virtual object get_KeyAlgorithmParameters() { }

	// RVA: 0x395A750
	public virtual object set_KeyAlgorithmParameters(object value) { }

	// RVA: 0x395A758
	public virtual object get_PublicKey() { }

	// RVA: 0x395A7D0
	public virtual object get_RSA() { }

	// RVA: 0x395A98C
	public virtual object set_RSA(object value) { }

	// RVA: 0x395A99C
	public virtual object get_RawData() { }

	// RVA: 0x395AA14
	public virtual object get_SerialNumber() { }

	// RVA: 0x395AA8C
	public virtual object get_Signature() { }

	// RVA: 0x395AF3C
	public virtual object get_SubjectName() { }

	// RVA: 0x395AF44
	public virtual object get_ValidFrom() { }

	// RVA: 0x395AF4C
	public virtual object get_ValidUntil() { }

	// RVA: 0x395AF54
	public object get_Version() { }

	// RVA: 0x395AF5C
	public object get_IsCurrent() { }

	// RVA: 0x395AFC8
	public object WasCurrent(object instant) { }

	// RVA: 0x395B0D4
	internal object VerifySignature(object dsa) { }

	// RVA: 0x395B1EC
	internal object VerifySignature(object rsa) { }

	// RVA: 0x395B364
	public object VerifySignature(object aa) { }

	// RVA: 0x395B4FC
	public object get_IsSelfSigned() { }

	// RVA: 0x395B640
	public virtual object GetObjectData(object info, object context) { }

	// RVA: 0x395A100
	private static object PEM(object type, object data) { }

	// RVA: 0x395B6B0
	private static object .cctor() { }

}

// Namespace: 
public class X509CertificateEnumerator
{

	// Fields
	private object enumerator; // 0x8

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x395BBB8
	public object .ctor(object mappings) { }

	// RVA: 0x394D854
	public object get_Current() { }

	// RVA: 0x395BD9C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x395BE80
	private object System.Collections.IEnumerator.MoveNext() { }

	// RVA: 0x395BF60
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x394DCD8
	public object MoveNext() { }

}

// Namespace: Mono.Security.X509
public class X509CertificateCollection
{

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x394918C
	public object .ctor() { }

	// RVA: 0x395B71C
	public object get_Item(object index) { }

	// RVA: 0x3949334
	public object Add(object value) { }

	// RVA: 0x395B7E0
	public object AddRange(object value) { }

	// RVA: 0x395B9A0
	public object Contains(object value) { }

	// RVA: 0x394D7F0
	public object GetEnumerator() { }

	// RVA: 0x395BC98
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x395BCE8
	public override object GetHashCode() { }

	// RVA: 0x395B9BC
	public object IndexOf(object value) { }

	// RVA: 0x395BD34
	private object Compare(object array1, object array2) { }

}

// Namespace: Mono.Security.X509
public class X509Chain
{

	// Fields
	private object roots; // 0x8
	private object certs; // 0x10
	private object _root; // 0x18
	private object _chain; // 0x20
	private object _status; // 0x28

	// Properties
	public object TrustAnchors { get; }

	// Methods

	// RVA: 0x395C044
	public object .ctor() { }

	// RVA: 0x395C0B4
	public object get_TrustAnchors() { }

	// RVA: 0x395C350
	public object LoadCertificates(object collection) { }

	// RVA: 0x395C370
	public object Build(object leaf) { }

	// RVA: 0x395D1EC
	public object Reset() { }

	// RVA: 0x395D074
	private object IsValid(object cert) { }

	// RVA: 0x395C97C
	private object FindCertificateParent(object child) { }

	// RVA: 0x395CBB0
	private object FindCertificateRoot(object potentialRoot) { }

	// RVA: 0x395D244
	private object IsTrusted(object potentialTrusted) { }

	// RVA: 0x395CE9C
	private object IsParent(object child, object parent) { }

}

// Namespace: Mono.Security.X509
public enum X509ChainStatusFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object InvalidBasicConstraints;
	public const object NoError;
	public const object NotSignatureValid;
	public const object NotTimeNested;
	public const object NotTimeValid;
	public const object PartialChain;
	public const object UntrustedRoot;
}

// Namespace: Mono.Security.X509
public class X509Extension
{

	// Fields
	protected object extnOid; // 0x8
	protected object extnCritical; // 0x10
	protected object extnValue; // 0x18

	// Properties
	public object Oid { get; }
	public object Critical { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x395D3EC
	public object .ctor(object asn1) { }

	// RVA: 0x395D794
	public object .ctor(object extension) { }

	// RVA: 0x395D98C
	protected virtual object Decode() { }

	// RVA: 0x395D990
	protected virtual object Encode() { }

	// RVA: 0x395D994
	public object get_Oid() { }

	// RVA: 0x395D99C
	public object get_Critical() { }

	// RVA: 0x395D934
	public object get_Value() { }

	// RVA: 0x395D9A4
	public override object Equals(object obj) { }

	// RVA: 0x395DB0C
	public override object GetHashCode() { }

	// RVA: 0x395DB58
	private object WriteLine(object sb, object n, object pos) { }

	// RVA: 0x395E2F4
	public override object ToString() { }

}

// Namespace: Mono.Security.X509
public sealed class X509ExtensionCollection
{

	// Fields
	private object readOnly; // 0x10

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x395E41C
	public object .ctor() { }

	// RVA: 0x395887C
	public object .ctor(object asn1) { }

	// RVA: 0x395E424
	public object IndexOf(object oid) { }

	// RVA: 0x395E5B8
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x395D2F8
	public object get_Item(object oid) { }

}

// Namespace: Mono.Security.X509
public class X509Store
{

	// Fields
	private object _storePath; // 0x8
	private object _certificates; // 0x10
	private object _crls; // 0x18
	private object _crl; // 0x20
	private object _newFormat; // 0x21

	// Properties
	public object Certificates { get; }
	public object Crls { get; }

	// Methods

	// RVA: 0x395E608
	internal object .ctor(object path, object crl, object newFormat) { }

	// RVA: 0x395E64C
	public object get_Certificates() { }

	// RVA: 0x395E964
	public object get_Crls() { }

	// RVA: 0x395ECCC
	private object Load(object filename) { }

	// RVA: 0x395EF40
	private object LoadCertificate(object filename) { }

	// RVA: 0x395EFB0
	private object LoadCrl(object filename) { }

	// RVA: 0x395F020
	private object CheckStore(object path, object throwException) { }

	// RVA: 0x395E68C
	private object BuildCertificatesCollection(object storeName) { }

	// RVA: 0x395E9FC
	private object BuildCrlsCollection(object storeName) { }

}

// Namespace: Mono.Security.X509
public sealed class X509StoreManager
{

	// Fields
	private static object _userPath; // 0x0
	private static object _localMachinePath; // 0x8
	private static object _newUserPath; // 0x10
	private static object _newLocalMachinePath; // 0x18
	private static object _userStore; // 0x20
	private static object _machineStore; // 0x28

	// Properties
	internal static object CurrentUserPath { get; }
	internal static object LocalMachinePath { get; }
	internal static object NewCurrentUserPath { get; }
	internal static object NewLocalMachinePath { get; }
	public static object CurrentUser { get; }
	public static object LocalMachine { get; }
	public static object TrustedRootCertificates { get; }

	// Methods

	// RVA: 0x395F108
	internal static object get_CurrentUserPath() { }

	// RVA: 0x395F208
	internal static object get_LocalMachinePath() { }

	// RVA: 0x395F308
	internal static object get_NewCurrentUserPath() { }

	// RVA: 0x395F408
	internal static object get_NewLocalMachinePath() { }

	// RVA: 0x395F508
	public static object get_CurrentUser() { }

	// RVA: 0x395F604
	public static object get_LocalMachine() { }

	// RVA: 0x395C148
	public static object get_TrustedRootCertificates() { }

}

// Namespace: Mono.Security.X509
public class X509Stores
{

	// Fields
	private object _storePath; // 0x8
	private object _newFormat; // 0x10
	private object _trusted; // 0x18

	// Properties
	public object TrustedRoot { get; }

	// Methods

	// RVA: 0x395F5C8
	internal object .ctor(object path, object newFormat) { }

	// RVA: 0x395F6C4
	public object get_TrustedRoot() { }

	// RVA: 0x395F7B0
	public object Open(object storeName, object create) { }

}

// Namespace: 
public abstract class AttributeTypeAndValue
{

	// Fields
	private object oid; // 0x8
	private object attrValue; // 0x10
	private object upperBound; // 0x18
	private object encoding; // 0x1C

	// Properties
	public object Value { set; }

	// Methods

	// RVA: 0x395F8E8
	protected object .ctor(object oid, object upperBound) { }

	// RVA: 0x395F92C
	protected object .ctor(object oid, object upperBound, object encoding) { }

	// RVA: 0x39579E0
	public object set_Value(object value) { }

	// RVA: 0x395F970
	internal object GetASN1(object encoding) { }

	// RVA: 0x3957A90
	internal object GetASN1() { }

	// RVA: 0x395FB30
	private object SelectBestEncoding() { }

}

// Namespace: 
public class CommonName
{

	// Methods

	// RVA: 0x3956714
	public object .ctor() { }

}

// Namespace: 
public class SerialNumber
{

	// Methods

	// RVA: 0x3956BE4
	public object .ctor() { }

}

// Namespace: 
public class LocalityName
{

	// Methods

	// RVA: 0x3956784
	public object .ctor() { }

}

// Namespace: 
public class StateOrProvinceName
{

	// Methods

	// RVA: 0x39567F4
	public object .ctor() { }

}

// Namespace: 
public class OrganizationName
{

	// Methods

	// RVA: 0x3956634
	public object .ctor() { }

}

// Namespace: 
public class OrganizationalUnitName
{

	// Methods

	// RVA: 0x39566A4
	public object .ctor() { }

}

// Namespace: 
public class EmailAddress
{

	// Methods

	// RVA: 0x3956864
	public object .ctor() { }

}

// Namespace: 
public class DomainComponent
{

	// Methods

	// RVA: 0x39568D4
	public object .ctor() { }

}

// Namespace: 
public class UserId
{

	// Methods

	// RVA: 0x3956944
	public object .ctor() { }

}

// Namespace: 
public class Oid
{

	// Methods

	// RVA: 0x3956C54
	public object .ctor(object oid) { }

}

// Namespace: 
public class Title
{

	// Methods

	// RVA: 0x3956A24
	public object .ctor() { }

}

// Namespace: 
public class CountryName
{

	// Methods

	// RVA: 0x39565C4
	public object .ctor() { }

}

// Namespace: 
public class DnQualifier
{

	// Methods

	// RVA: 0x39569B4
	public object .ctor() { }

}

// Namespace: 
public class Surname
{

	// Methods

	// RVA: 0x3956A94
	public object .ctor() { }

}

// Namespace: 
public class GivenName
{

	// Methods

	// RVA: 0x3956B04
	public object .ctor() { }

}

// Namespace: 
public class Initial
{

	// Methods

	// RVA: 0x3956B74
	public object .ctor() { }

}

// Namespace: Mono.Security.X509
public class X520
{
}

// Namespace: Mono.Security.X509.Extensions
public class AuthorityKeyIdentifierExtension
{

	// Fields
	private object aki; // 0x20

	// Properties
	public object Identifier { get; }

	// Methods

	// RVA: 0x395FBB0
	public object .ctor(object extension) { }

	// RVA: 0x395FBB4
	protected override object Decode() { }

	// RVA: 0x395FD1C
	protected override object Encode() { }

	// RVA: 0x395FE38
	public object get_Identifier() { }

	// RVA: 0x395FEB0
	public override object ToString() { }

}

// Namespace: Mono.Security.X509.Extensions
public class BasicConstraintsExtension
{

	// Fields
	private object cA; // 0x20
	private object pathLenConstraint; // 0x24

	// Properties
	public object CertificateAuthority { get; }

	// Methods

	// RVA: 0x395D3E8
	public object .ctor(object extension) { }

	// RVA: 0x3960070
	protected override object Decode() { }

	// RVA: 0x39601CC
	protected override object Encode() { }

	// RVA: 0x396030C
	public object get_CertificateAuthority() { }

	// RVA: 0x3960314
	public override object ToString() { }

}

// Namespace: Mono.Security.Protocol.Ntlm
public class ChallengeResponse
{

	// Fields
	private static object magic; // 0x0
	private static object nullEncMagic; // 0x8
	private object _disposed; // 0x8
	private object _challenge; // 0x10
	private object _lmpwd; // 0x18
	private object _ntpwd; // 0x20

	// Properties
	public object Password { set; }
	public object Challenge { set; }
	public object LM { get; }
	public object NT { get; }

	// Methods

	// RVA: 0x39604DC
	public object .ctor() { }

	// RVA: 0x3960558
	public object .ctor(object password, object challenge) { }

	// RVA: 0x3960C88
	protected override object Finalize() { }

	// RVA: 0x39605F8
	public object set_Password(object value) { }

	// RVA: 0x3960B30
	public object set_Challenge(object value) { }

	// RVA: 0x3960F94
	public object get_LM() { }

	// RVA: 0x39613F8
	public object get_NT() { }

	// RVA: 0x3960D70
	public object Dispose() { }

	// RVA: 0x3961460
	private object Dispose(object disposing) { }

	// RVA: 0x3960FFC
	private object GetResponse(object pwd) { }

	// RVA: 0x39614EC
	private object PrepareDESKey(object key56bits, object position) { }

	// RVA: 0x3960E10
	private object PasswordToKey(object password, object position) { }

	// RVA: 0x39616E4
	private static object .cctor() { }

}

// Namespace: Mono.Security.Protocol.Ntlm
public static class ChallengeResponse2
{

	// Fields
	private static object magic; // 0x0
	private static object nullEncMagic; // 0x8

	// Methods

	// RVA: 0x39617C0
	private static object Compute_LM(object password, object challenge) { }

	// RVA: 0x3962188
	private static object Compute_NTLM_Password(object password) { }

	// RVA: 0x39622E0
	private static object Compute_NTLM(object password, object challenge) { }

	// RVA: 0x3962350
	private static object Compute_NTLMv2_Session(object password, object challenge, object lm, object ntlm) { }

	// RVA: 0x39625E0
	private static object Compute_NTLMv2(object type2, object username, object password, object domain) { }

	// RVA: 0x3962B88
	public static object Compute(object type2, object level, object username, object password, object domain, object lm, object ntlm) { }

	// RVA: 0x3961D7C
	private static object GetResponse(object challenge, object pwd) { }

	// RVA: 0x3962E30
	private static object PrepareDESKey(object key56bits, object position) { }

	// RVA: 0x3961BD4
	private static object PasswordToKey(object password, object position) { }

	// RVA: 0x3963028
	private static object .cctor() { }

}

// Namespace: Mono.Security.Protocol.Ntlm
public abstract class MessageBase
{

	// Fields
	private static object header; // 0x0
	private object _type; // 0x8
	private object _flags; // 0xC

	// Properties
	public object Flags { get; set; }
	public object Type { get; }

	// Methods

	// RVA: 0x3963104
	protected object .ctor(object messageType) { }

	// RVA: 0x3963130
	public object get_Flags() { }

	// RVA: 0x3963138
	public object set_Flags(object value) { }

	// RVA: 0x3963140
	public object get_Type() { }

	// RVA: 0x3963148
	protected object PrepareMessage(object messageSize) { }

	// RVA: 0x3963258
	protected virtual object Decode(object message) { }

	// RVA: 0x3963414
	protected object CheckHeader(object message) { }

	// RVA: -1
	public abstract object GetBytes() { }

	// RVA: 0x3963588
	private static object .cctor() { }

}

// Namespace: Mono.Security.Protocol.Ntlm
public enum NtlmAuthLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LM_and_NTLM;
	public const object LM_and_NTLM_and_try_NTLMv2_Session;
	public const object NTLM_only;
	public const object NTLMv2_only;
}

// Namespace: Mono.Security.Protocol.Ntlm
public enum NtlmFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NegotiateUnicode;
	public const object NegotiateOem;
	public const object RequestTarget;
	public const object NegotiateNtlm;
	public const object NegotiateDomainSupplied;
	public const object NegotiateWorkstationSupplied;
	public const object NegotiateAlwaysSign;
	public const object NegotiateNtlm2Key;
	public const object Negotiate128;
	public const object Negotiate56;
}

// Namespace: Mono.Security.Protocol.Ntlm
public static class NtlmSettings
{

	// Fields
	private static object defaultAuthLevel; // 0x0

	// Properties
	public static object DefaultAuthLevel { get; }

	// Methods

	// RVA: 0x3963620
	public static object get_DefaultAuthLevel() { }

	// RVA: 0x396369C
	private static object .cctor() { }

}

// Namespace: Mono.Security.Protocol.Ntlm
public class Type1Message
{

	// Fields
	private object _host; // 0x10
	private object _domain; // 0x18

	// Properties
	public object Domain { set; }
	public object Host { set; }

	// Methods

	// RVA: 0x39636EC
	public object .ctor() { }

	// RVA: 0x396377C
	public object set_Domain(object value) { }

	// RVA: 0x3963804
	public object set_Host(object value) { }

	// RVA: 0x396388C
	protected override object Decode(object message) { }

	// RVA: 0x39639C0
	public override object GetBytes() { }

}

// Namespace: Mono.Security.Protocol.Ntlm
public class Type2Message
{

	// Fields
	private object _nonce; // 0x10
	private object _targetName; // 0x18
	private object _targetInfo; // 0x20

	// Properties
	public object Nonce { get; }
	public object TargetName { get; }
	public object TargetInfo { get; }

	// Methods

	// RVA: 0x3963CB8
	public object .ctor(object message) { }

	// RVA: 0x3963D74
	protected override object Finalize() { }

	// RVA: 0x3963E18
	public object get_Nonce() { }

	// RVA: 0x3963E9C
	public object get_TargetName() { }

	// RVA: 0x3963EA4
	public object get_TargetInfo() { }

	// RVA: 0x3963F28
	protected override object Decode(object message) { }

	// RVA: 0x39640E4
	public override object GetBytes() { }

}

// Namespace: Mono.Security.Protocol.Ntlm
public class Type3Message
{

	// Fields
	private object _level; // 0x10
	private object _challenge; // 0x18
	private object _host; // 0x20
	private object _domain; // 0x28
	private object _username; // 0x30
	private object _password; // 0x38
	private object _type2; // 0x40
	private object _lm; // 0x48
	private object _nt; // 0x50

	// Properties
	public object Domain { set; }
	public object Password { set; }
	public object Username { set; }

	// Methods

	// RVA: 0x39641B4
	public object .ctor(object type2) { }

	// RVA: 0x396444C
	protected override object Finalize() { }

	// RVA: 0x3964538
	public object set_Domain(object value) { }

	// RVA: 0x39645C0
	public object set_Password(object value) { }

	// RVA: 0x39645C8
	public object set_Username(object value) { }

	// RVA: 0x39645D0
	protected override object Decode(object message) { }

	// RVA: 0x39648C4
	private object DecodeString(object buffer, object offset, object len) { }

	// RVA: 0x3964960
	private object EncodeString(object text) { }

	// RVA: 0x3964A34
	public override object GetBytes() { }

}

// Namespace: Mono.Security.Interface
public enum AlertLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Warning;
	public const object Fatal;
}

// Namespace: Mono.Security.Interface
public enum AlertDescription
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CloseNotify;
	public const object UnexpectedMessage;
	public const object BadRecordMAC;
	public const object DecryptionFailed_RESERVED;
	public const object RecordOverflow;
	public const object DecompressionFailure;
	public const object HandshakeFailure;
	public const object NoCertificate_RESERVED;
	public const object BadCertificate;
	public const object UnsupportedCertificate;
	public const object CertificateRevoked;
	public const object CertificateExpired;
	public const object CertificateUnknown;
	public const object IlegalParameter;
	public const object UnknownCA;
	public const object AccessDenied;
	public const object DecodeError;
	public const object DecryptError;
	public const object ExportRestriction;
	public const object ProtocolVersion;
	public const object InsuficientSecurity;
	public const object InternalError;
	public const object UserCancelled;
	public const object NoRenegotiation;
	public const object UnsupportedExtension;
}

// Namespace: Mono.Security.Interface
public class Alert
{

	// Fields
	private object level; // 0x8
	private object description; // 0x9

	// Properties
	public object Level { get; }
	public object Description { get; }

	// Methods

	// RVA: 0x39650DC
	public object get_Level() { }

	// RVA: 0x39650E4
	public object get_Description() { }

	// RVA: 0x39650EC
	public object .ctor(object description) { }

	// RVA: 0x396516C
	private object inferAlertLevel() { }

	// RVA: 0x39651B8
	public override object ToString() { }

}

// Namespace: Mono.Security.Interface
public class ValidationResult
{

	// Fields
	private object trusted; // 0x8
	private object user_denied; // 0x9
	private object error_code; // 0xC
	private object policy_errors; // 0x10

	// Properties
	public object Trusted { get; }
	public object UserDenied { get; }

	// Methods

	// RVA: 0x396527C
	public object .ctor(object trusted, object user_denied, object error_code, object policy_errors) { }

	// RVA: 0x39652D0
	public object get_Trusted() { }

	// RVA: 0x39652D8
	public object get_UserDenied() { }

}

// Namespace: Mono.Security.Interface
public interface ICertificateValidator
{
}

// Namespace: Mono.Security.Interface
public enum CipherSuiteCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TLS_NULL_WITH_NULL_NULL;
	public const object TLS_RSA_WITH_NULL_MD5;
	public const object TLS_RSA_WITH_NULL_SHA;
	public const object TLS_RSA_EXPORT_WITH_RC4_40_MD5;
	public const object TLS_RSA_WITH_RC4_128_MD5;
	public const object TLS_RSA_WITH_RC4_128_SHA;
	public const object TLS_RSA_EXPORT_WITH_RC2_CBC_40_MD5;
	public const object TLS_RSA_WITH_IDEA_CBC_SHA;
	public const object TLS_RSA_EXPORT_WITH_DES40_CBC_SHA;
	public const object TLS_RSA_WITH_DES_CBC_SHA;
	public const object TLS_RSA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_DH_DSS_EXPORT_WITH_DES40_CBC_SHA;
	public const object TLS_DH_DSS_WITH_DES_CBC_SHA;
	public const object TLS_DH_DSS_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_DH_RSA_EXPORT_WITH_DES40_CBC_SHA;
	public const object TLS_DH_RSA_WITH_DES_CBC_SHA;
	public const object TLS_DH_RSA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA;
	public const object TLS_DHE_DSS_WITH_DES_CBC_SHA;
	public const object TLS_DHE_DSS_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA;
	public const object TLS_DHE_RSA_WITH_DES_CBC_SHA;
	public const object TLS_DHE_RSA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_DH_anon_EXPORT_WITH_RC4_40_MD5;
	public const object TLS_DH_anon_WITH_RC4_128_MD5;
	public const object TLS_DH_anon_EXPORT_WITH_DES40_CBC_SHA;
	public const object TLS_DH_anon_WITH_DES_CBC_SHA;
	public const object TLS_DH_anon_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_RSA_WITH_AES_128_CBC_SHA;
	public const object TLS_DH_DSS_WITH_AES_128_CBC_SHA;
	public const object TLS_DH_RSA_WITH_AES_128_CBC_SHA;
	public const object TLS_DHE_DSS_WITH_AES_128_CBC_SHA;
	public const object TLS_DHE_RSA_WITH_AES_128_CBC_SHA;
	public const object TLS_DH_anon_WITH_AES_128_CBC_SHA;
	public const object TLS_RSA_WITH_AES_256_CBC_SHA;
	public const object TLS_DH_DSS_WITH_AES_256_CBC_SHA;
	public const object TLS_DH_RSA_WITH_AES_256_CBC_SHA;
	public const object TLS_DHE_DSS_WITH_AES_256_CBC_SHA;
	public const object TLS_DHE_RSA_WITH_AES_256_CBC_SHA;
	public const object TLS_DH_anon_WITH_AES_256_CBC_SHA;
	public const object TLS_RSA_WITH_CAMELLIA_128_CBC_SHA;
	public const object TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA;
	public const object TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA;
	public const object TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA;
	public const object TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA;
	public const object TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA;
	public const object TLS_RSA_WITH_CAMELLIA_256_CBC_SHA;
	public const object TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA;
	public const object TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA;
	public const object TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA;
	public const object TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA;
	public const object TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA;
	public const object TLS_RSA_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_DH_DSS_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_DH_RSA_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_DH_anon_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_RSA_WITH_CAMELLIA_256_CBC_SHA256;
	public const object TLS_DH_DSS_WITH_CAMELLIA_256_CBC_SHA256;
	public const object TLS_DH_RSA_WITH_CAMELLIA_256_CBC_SHA256;
	public const object TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA256;
	public const object TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA256;
	public const object TLS_DH_anon_WITH_CAMELLIA_256_CBC_SHA256;
	public const object TLS_RSA_WITH_SEED_CBC_SHA;
	public const object TLS_DH_DSS_WITH_SEED_CBC_SHA;
	public const object TLS_DH_RSA_WITH_SEED_CBC_SHA;
	public const object TLS_DHE_DSS_WITH_SEED_CBC_SHA;
	public const object TLS_DHE_RSA_WITH_SEED_CBC_SHA;
	public const object TLS_DH_anon_WITH_SEED_CBC_SHA;
	public const object TLS_PSK_WITH_RC4_128_SHA;
	public const object TLS_PSK_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_PSK_WITH_AES_128_CBC_SHA;
	public const object TLS_PSK_WITH_AES_256_CBC_SHA;
	public const object TLS_DHE_PSK_WITH_RC4_128_SHA;
	public const object TLS_DHE_PSK_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_DHE_PSK_WITH_AES_128_CBC_SHA;
	public const object TLS_DHE_PSK_WITH_AES_256_CBC_SHA;
	public const object TLS_RSA_PSK_WITH_RC4_128_SHA;
	public const object TLS_RSA_PSK_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_RSA_PSK_WITH_AES_128_CBC_SHA;
	public const object TLS_RSA_PSK_WITH_AES_256_CBC_SHA;
	public const object TLS_ECDH_ECDSA_WITH_NULL_SHA;
	public const object TLS_ECDH_ECDSA_WITH_RC4_128_SHA;
	public const object TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA;
	public const object TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA;
	public const object TLS_ECDHE_ECDSA_WITH_NULL_SHA;
	public const object TLS_ECDHE_ECDSA_WITH_RC4_128_SHA;
	public const object TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA;
	public const object TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA;
	public const object TLS_ECDH_RSA_WITH_NULL_SHA;
	public const object TLS_ECDH_RSA_WITH_RC4_128_SHA;
	public const object TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_ECDH_RSA_WITH_AES_128_CBC_SHA;
	public const object TLS_ECDH_RSA_WITH_AES_256_CBC_SHA;
	public const object TLS_ECDHE_RSA_WITH_NULL_SHA;
	public const object TLS_ECDHE_RSA_WITH_RC4_128_SHA;
	public const object TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA;
	public const object TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA;
	public const object TLS_ECDH_anon_WITH_NULL_SHA;
	public const object TLS_ECDH_anon_WITH_RC4_128_SHA;
	public const object TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_ECDH_anon_WITH_AES_128_CBC_SHA;
	public const object TLS_ECDH_anon_WITH_AES_256_CBC_SHA;
	public const object TLS_PSK_WITH_NULL_SHA;
	public const object TLS_DHE_PSK_WITH_NULL_SHA;
	public const object TLS_RSA_PSK_WITH_NULL_SHA;
	public const object TLS_SRP_SHA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_SRP_SHA_RSA_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_SRP_SHA_DSS_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_SRP_SHA_WITH_AES_128_CBC_SHA;
	public const object TLS_SRP_SHA_RSA_WITH_AES_128_CBC_SHA;
	public const object TLS_SRP_SHA_DSS_WITH_AES_128_CBC_SHA;
	public const object TLS_SRP_SHA_WITH_AES_256_CBC_SHA;
	public const object TLS_SRP_SHA_RSA_WITH_AES_256_CBC_SHA;
	public const object TLS_SRP_SHA_DSS_WITH_AES_256_CBC_SHA;
	public const object TLS_RSA_WITH_NULL_SHA256;
	public const object TLS_RSA_WITH_AES_128_CBC_SHA256;
	public const object TLS_RSA_WITH_AES_256_CBC_SHA256;
	public const object TLS_DH_DSS_WITH_AES_128_CBC_SHA256;
	public const object TLS_DH_RSA_WITH_AES_128_CBC_SHA256;
	public const object TLS_DHE_DSS_WITH_AES_128_CBC_SHA256;
	public const object TLS_DHE_RSA_WITH_AES_128_CBC_SHA256;
	public const object TLS_DH_DSS_WITH_AES_256_CBC_SHA256;
	public const object TLS_DH_RSA_WITH_AES_256_CBC_SHA256;
	public const object TLS_DHE_DSS_WITH_AES_256_CBC_SHA256;
	public const object TLS_DHE_RSA_WITH_AES_256_CBC_SHA256;
	public const object TLS_DH_anon_WITH_AES_128_CBC_SHA256;
	public const object TLS_DH_anon_WITH_AES_256_CBC_SHA256;
	public const object TLS_RSA_WITH_AES_128_GCM_SHA256;
	public const object TLS_RSA_WITH_AES_256_GCM_SHA384;
	public const object TLS_DHE_RSA_WITH_AES_128_GCM_SHA256;
	public const object TLS_DHE_RSA_WITH_AES_256_GCM_SHA384;
	public const object TLS_DH_RSA_WITH_AES_128_GCM_SHA256;
	public const object TLS_DH_RSA_WITH_AES_256_GCM_SHA384;
	public const object TLS_DHE_DSS_WITH_AES_128_GCM_SHA256;
	public const object TLS_DHE_DSS_WITH_AES_256_GCM_SHA384;
	public const object TLS_DH_DSS_WITH_AES_128_GCM_SHA256;
	public const object TLS_DH_DSS_WITH_AES_256_GCM_SHA384;
	public const object TLS_DH_anon_WITH_AES_128_GCM_SHA256;
	public const object TLS_DH_anon_WITH_AES_256_GCM_SHA384;
	public const object TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256;
	public const object TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384;
	public const object TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256;
	public const object TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384;
	public const object TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256;
	public const object TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384;
	public const object TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256;
	public const object TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384;
	public const object TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256;
	public const object TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384;
	public const object TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256;
	public const object TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384;
	public const object TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256;
	public const object TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384;
	public const object TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256;
	public const object TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384;
	public const object TLS_PSK_WITH_AES_128_GCM_SHA256;
	public const object TLS_PSK_WITH_AES_256_GCM_SHA384;
	public const object TLS_DHE_PSK_WITH_AES_128_GCM_SHA256;
	public const object TLS_DHE_PSK_WITH_AES_256_GCM_SHA384;
	public const object TLS_RSA_PSK_WITH_AES_128_GCM_SHA256;
	public const object TLS_RSA_PSK_WITH_AES_256_GCM_SHA384;
	public const object TLS_PSK_WITH_AES_128_CBC_SHA256;
	public const object TLS_PSK_WITH_AES_256_CBC_SHA384;
	public const object TLS_PSK_WITH_NULL_SHA256;
	public const object TLS_PSK_WITH_NULL_SHA384;
	public const object TLS_DHE_PSK_WITH_AES_128_CBC_SHA256;
	public const object TLS_DHE_PSK_WITH_AES_256_CBC_SHA384;
	public const object TLS_DHE_PSK_WITH_NULL_SHA256;
	public const object TLS_DHE_PSK_WITH_NULL_SHA384;
	public const object TLS_RSA_PSK_WITH_AES_128_CBC_SHA256;
	public const object TLS_RSA_PSK_WITH_AES_256_CBC_SHA384;
	public const object TLS_RSA_PSK_WITH_NULL_SHA256;
	public const object TLS_RSA_PSK_WITH_NULL_SHA384;
	public const object TLS_ECDHE_PSK_WITH_RC4_128_SHA;
	public const object TLS_ECDHE_PSK_WITH_3DES_EDE_CBC_SHA;
	public const object TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA;
	public const object TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA;
	public const object TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA256;
	public const object TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA384;
	public const object TLS_ECDHE_PSK_WITH_NULL_SHA;
	public const object TLS_ECDHE_PSK_WITH_NULL_SHA256;
	public const object TLS_ECDHE_PSK_WITH_NULL_SHA384;
	public const object TLS_EMPTY_RENEGOTIATION_INFO_SCSV;
	public const object TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_CBC_SHA384;
	public const object TLS_ECDH_ECDSA_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_ECDH_ECDSA_WITH_CAMELLIA_256_CBC_SHA384;
	public const object TLS_ECDHE_RSA_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_ECDHE_RSA_WITH_CAMELLIA_256_CBC_SHA384;
	public const object TLS_ECDH_RSA_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_ECDH_RSA_WITH_CAMELLIA_256_CBC_SHA384;
	public const object TLS_RSA_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_RSA_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_DHE_RSA_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_DHE_RSA_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_DH_RSA_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_DH_RSA_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_DHE_DSS_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_DHE_DSS_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_DH_DSS_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_DH_DSS_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_DH_anon_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_DH_anon_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_ECDHE_ECDSA_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_ECDHE_ECDSA_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_ECDH_ECDSA_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_ECDH_ECDSA_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_ECDHE_RSA_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_ECDHE_RSA_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_ECDH_RSA_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_ECDH_RSA_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_PSK_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_PSK_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_DHE_PSK_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_DHE_PSK_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_RSA_PSK_WITH_CAMELLIA_128_GCM_SHA256;
	public const object TLS_RSA_PSK_WITH_CAMELLIA_256_GCM_SHA384;
	public const object TLS_PSK_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_PSK_WITH_CAMELLIA_256_CBC_SHA384;
	public const object TLS_DHE_PSK_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_DHE_PSK_WITH_CAMELLIA_256_CBC_SHA384;
	public const object TLS_RSA_PSK_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_RSA_PSK_WITH_CAMELLIA_256_CBC_SHA384;
	public const object TLS_ECDHE_PSK_WITH_CAMELLIA_128_CBC_SHA256;
	public const object TLS_ECDHE_PSK_WITH_CAMELLIA_256_CBC_SHA384;
	public const object TLS_RSA_WITH_AES_128_CCM;
	public const object TLS_RSA_WITH_AES_256_CCM;
	public const object TLS_DHE_RSA_WITH_AES_128_CCM;
	public const object TLS_DHE_RSA_WITH_AES_256_CCM;
	public const object TLS_RSA_WITH_AES_128_CCM_8;
	public const object TLS_RSA_WITH_AES_256_CCM_8;
	public const object TLS_DHE_RSA_WITH_AES_128_CCM_8;
	public const object TLS_DHE_RSA_WITH_AES_256_CCM_8;
	public const object TLS_PSK_WITH_AES_128_CCM;
	public const object TLS_PSK_WITH_AES_256_CCM;
	public const object TLS_DHE_PSK_WITH_AES_128_CCM;
	public const object TLS_DHE_PSK_WITH_AES_256_CCM;
	public const object TLS_PSK_WITH_AES_128_CCM_8;
	public const object TLS_PSK_WITH_AES_256_CCM_8;
	public const object TLS_PSK_DHE_WITH_AES_128_CCM_8;
	public const object TLS_PSK_DHE_WITH_AES_256_CCM_8;
	public const object TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256;
	public const object TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256;
	public const object TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256;
	public const object TLS_RSA_WITH_ESTREAM_SALSA20_SHA1;
	public const object TLS_RSA_WITH_SALSA20_SHA1;
	public const object TLS_ECDHE_RSA_WITH_ESTREAM_SALSA20_SHA1;
	public const object TLS_ECDHE_RSA_WITH_SALSA20_SHA1;
	public const object TLS_ECDHE_ECDSA_WITH_ESTREAM_SALSA20_SHA1;
	public const object TLS_ECDHE_ECDSA_WITH_SALSA20_SHA1;
	public const object TLS_PSK_WITH_ESTREAM_SALSA20_SHA1;
	public const object TLS_PSK_WITH_SALSA20_SHA1;
	public const object TLS_ECDHE_PSK_WITH_ESTREAM_SALSA20_SHA1;
	public const object TLS_ECDHE_PSK_WITH_SALSA20_SHA1;
	public const object TLS_RSA_PSK_WITH_ESTREAM_SALSA20_SHA1;
	public const object TLS_RSA_PSK_WITH_SALSA20_SHA1;
	public const object TLS_DHE_PSK_WITH_ESTREAM_SALSA20_SHA1;
	public const object TLS_DHE_PSK_WITH_SALSA20_SHA1;
	public const object TLS_DHE_RSA_WITH_ESTREAM_SALSA20_SHA1;
	public const object TLS_DHE_RSA_WITH_SALSA20_SHA1;
	public const object TLS_FALLBACK_SCSV;
}

// Namespace: Mono.Security.Interface
public class MonoTlsConnectionInfo
{

	// Fields
	private object <CipherSuiteCode>k__BackingField; // 0x8
	private object <ProtocolVersion>k__BackingField; // 0xC
	private object <PeerDomainName>k__BackingField; // 0x10

	// Properties
	public object CipherSuiteCode { get; set; }
	public object ProtocolVersion { get; set; }
	public object PeerDomainName { set; }

	// Methods

	// RVA: 0x39652E0
	public object get_CipherSuiteCode() { }

	// RVA: 0x39652E8
	public object set_CipherSuiteCode(object value) { }

	// RVA: 0x39652F0
	public object get_ProtocolVersion() { }

	// RVA: 0x39652F8
	public object set_ProtocolVersion(object value) { }

	// RVA: 0x3965300
	public object set_PeerDomainName(object value) { }

	// RVA: 0x3965308
	public override object ToString() { }

	// RVA: 0x39653CC
	public object .ctor() { }

}

// Namespace: Mono.Security.Interface
public enum MonoSslPolicyErrors
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object RemoteCertificateNotAvailable;
	public const object RemoteCertificateNameMismatch;
	public const object RemoteCertificateChainErrors;
}

// Namespace: Mono.Security.Interface
public sealed class MonoRemoteCertificateValidationCallback
{

	// Methods

	// RVA: 0x39654B0
	public object .ctor(object object, object method) { }

	// RVA: 0x3965560
	public virtual object Invoke(object targetHost, object certificate, object chain, object sslPolicyErrors) { }

}

// Namespace: Mono.Security.Interface
public sealed class MonoLocalCertificateSelectionCallback
{

	// Methods

	// RVA: 0x3965650
	public object .ctor(object object, object method) { }

	// RVA: 0x3965700
	public virtual object Invoke(object targetHost, object localCertificates, object remoteCertificate, object acceptableIssuers) { }

}

// Namespace: Mono.Security.Interface
public abstract class MonoTlsProvider
{

	// Properties
	public abstract object ID { get; }
	public abstract object Name { get; }
	public abstract object SupportsSslStream { get; }
	public abstract object SupportsConnectionInfo { get; }
	public abstract object SupportsMonoExtensions { get; }
	public abstract object SupportedProtocols { get; }
	internal abstract object SupportsCleanShutdown { get; }

	// Methods

	// RVA: 0x3965714
	internal object .ctor() { }

	// RVA: -1
	public abstract object get_ID() { }

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: -1
	public abstract object get_SupportsSslStream() { }

	// RVA: -1
	public abstract object get_SupportsConnectionInfo() { }

	// RVA: -1
	public abstract object get_SupportsMonoExtensions() { }

	// RVA: -1
	public abstract object get_SupportedProtocols() { }

	// RVA: -1
	internal abstract object get_SupportsCleanShutdown() { }

}

// Namespace: Mono.Security.Interface
public static class MonoTlsProviderFactory
{

	// Methods

	// RVA: 0x396571C
	public static object GetProvider() { }

}

// Namespace: Mono.Security.Interface
public sealed class MonoTlsSettings
{

	// Fields
	private object <RemoteCertificateValidationCallback>k__BackingField; // 0x8
	private object <ClientCertificateSelectionCallback>k__BackingField; // 0x10
	private object <CertificateValidationTime>k__BackingField; // 0x18
	private object <TrustAnchors>k__BackingField; // 0x28
	private object <UserSettings>k__BackingField; // 0x30
	private object <CertificateSearchPaths>k__BackingField; // 0x38
	private object <SendCloseNotify>k__BackingField; // 0x40
	private object <ClientCertificateIssuers>k__BackingField; // 0x48
	private object <DisallowUnauthenticatedCertificateRequest>k__BackingField; // 0x50
	private object <EnabledProtocols>k__BackingField; // 0x54
	private object <EnabledCiphers>k__BackingField; // 0x60
	private object cloned; // 0x68
	private object checkCertName; // 0x69
	private object checkCertRevocationStatus; // 0x6A
	private object useServicePointManagerCallback; // 0x6B
	private object skipSystemValidators; // 0x6D
	private object callbackNeedsChain; // 0x6E
	private object certificateValidator; // 0x70
	private static object defaultSettings; // 0x0

	// Properties
	public object RemoteCertificateValidationCallback { get; set; }
	public object ClientCertificateSelectionCallback { get; set; }
	public object UseServicePointManagerCallback { get; set; }
	public object CallbackNeedsCertificateChain { get; }
	public object CertificateValidationTime { get; set; }
	public object TrustAnchors { get; set; }
	public object UserSettings { get; set; }
	internal object CertificateSearchPaths { get; set; }
	internal object SendCloseNotify { get; set; }
	public object ClientCertificateIssuers { get; set; }
	public object DisallowUnauthenticatedCertificateRequest { get; set; }
	public object EnabledProtocols { get; set; }
	public object EnabledCiphers { get; set; }
	public static object DefaultSettings { get; }
	public object CertificateValidator { get; }

	// Methods

	// RVA: 0x3965798
	public object get_RemoteCertificateValidationCallback() { }

	// RVA: 0x39657A0
	public object set_RemoteCertificateValidationCallback(object value) { }

	// RVA: 0x39657A8
	public object get_ClientCertificateSelectionCallback() { }

	// RVA: 0x39657B0
	public object set_ClientCertificateSelectionCallback(object value) { }

	// RVA: 0x39657B8
	public object get_UseServicePointManagerCallback() { }

	// RVA: 0x39657C0
	public object set_UseServicePointManagerCallback(object value) { }

	// RVA: 0x39657C8
	public object get_CallbackNeedsCertificateChain() { }

	// RVA: 0x39657D0
	public object get_CertificateValidationTime() { }

	// RVA: 0x39657DC
	public object set_CertificateValidationTime(object value) { }

	// RVA: 0x39657E4
	public object get_TrustAnchors() { }

	// RVA: 0x39657EC
	public object set_TrustAnchors(object value) { }

	// RVA: 0x39657F4
	public object get_UserSettings() { }

	// RVA: 0x39657FC
	public object set_UserSettings(object value) { }

	// RVA: 0x3965804
	internal object get_CertificateSearchPaths() { }

	// RVA: 0x396580C
	internal object set_CertificateSearchPaths(object value) { }

	// RVA: 0x3965814
	internal object get_SendCloseNotify() { }

	// RVA: 0x396581C
	internal object set_SendCloseNotify(object value) { }

	// RVA: 0x3965824
	public object get_ClientCertificateIssuers() { }

	// RVA: 0x396582C
	public object set_ClientCertificateIssuers(object value) { }

	// RVA: 0x3965834
	public object get_DisallowUnauthenticatedCertificateRequest() { }

	// RVA: 0x396583C
	public object set_DisallowUnauthenticatedCertificateRequest(object value) { }

	// RVA: 0x3965844
	public object get_EnabledProtocols() { }

	// RVA: 0x396584C
	public object set_EnabledProtocols(object value) { }

	// RVA: 0x3965854
	public object get_EnabledCiphers() { }

	// RVA: 0x396585C
	public object set_EnabledCiphers(object value) { }

	// RVA: 0x3965864
	public object .ctor() { }

	// RVA: 0x3965878
	public static object get_DefaultSettings() { }

	// RVA: 0x3965928
	public static object CopyDefaultSettings() { }

	// RVA: 0x3965A64
	public object get_CertificateValidator() { }

	// RVA: 0x3965A6C
	public object CloneWithValidator(object validator) { }

	// RVA: 0x3965A00
	public object Clone() { }

	// RVA: 0x3965AF4
	private object .ctor(object other) { }

}

// Namespace: Mono.Security.Interface
public sealed class TlsException
{

	// Fields
	private object alert; // 0x88

	// Methods

	// RVA: 0x3965C40
	public object .ctor(object alert) { }

	// RVA: 0x3965D28
	public object .ctor(object alert, object message) { }

	// RVA: 0x3965DA8
	public object .ctor(object description) { }

	// RVA: 0x3965E54
	public object .ctor(object description, object message) { }

}

// Namespace: Mono.Security.Interface
public enum TlsProtocolCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Tls10;
	public const object Tls11;
	public const object Tls12;
}

// Namespace: Mono.Security.Interface
public enum TlsProtocols
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Zero;
	public const object Tls10Client;
	public const object Tls10Server;
	public const object Tls10;
	public const object Tls11Client;
	public const object Tls11Server;
	public const object Tls11;
	public const object Tls12Client;
	public const object Tls12Server;
	public const object Tls12;
	public const object ClientMask;
	public const object ServerMask;
}

// Namespace: Mono.Security.Cryptography
public sealed class CryptoConvert
{

	// Methods

	// RVA: 0x3965F80
	public static object ToHex(object input) { }

	// RVA: 0x396613C
	private static object FromHexChar(object c) { }

	// RVA: 0x39661EC
	public static object FromHex(object hex) { }

}

// Namespace: Mono.Security.Cryptography
public abstract class MD2
{

	// Methods

	// RVA: 0x3966418
	protected object .ctor() { }

	// RVA: 0x3966444
	public static object Create() { }

}

// Namespace: Mono.Security.Cryptography
public class MD2Managed
{

	// Fields
	private object state; // 0x20
	private object checksum; // 0x28
	private object buffer; // 0x30
	private object count; // 0x38
	private object x; // 0x40
	private static readonly object PI_SUBST; // 0x0

	// Methods

	// RVA: 0x396655C
	private object Padding(object nLength) { }

	// RVA: 0x3966498
	public object .ctor() { }

	// RVA: 0x396667C
	public override object Initialize() { }

	// RVA: 0x39666E8
	protected override object HashCore(object array, object ibStart, object cbSize) { }

	// RVA: 0x3966AAC
	protected override object HashFinal() { }

	// RVA: 0x39667C8
	private object MD2Transform(object state, object checksum, object block, object index) { }

	// RVA: 0x3966C5C
	private static object .cctor() { }

}

// Namespace: Mono.Security.Cryptography
public abstract class MD4
{

	// Methods

	// RVA: 0x3966CF4
	protected object .ctor() { }

	// RVA: 0x3966D20
	public static object Create() { }

}

// Namespace: Mono.Security.Cryptography
public class MD4Managed
{

	// Fields
	private object state; // 0x20
	private object buffer; // 0x28
	private object count; // 0x30
	private object x; // 0x38
	private object digest; // 0x40

	// Methods

	// RVA: 0x3966D74
	public object .ctor() { }

	// RVA: 0x3966E5C
	public override object Initialize() { }

	// RVA: 0x3966F30
	protected override object HashCore(object array, object ibStart, object cbSize) { }

	// RVA: 0x39676E8
	protected override object HashFinal() { }

	// RVA: 0x3967990
	private object Padding(object nLength) { }

	// RVA: 0x3967A1C
	private object F(object x, object y, object z) { }

	// RVA: 0x3967A2C
	private object G(object x, object y, object z) { }

	// RVA: 0x3967A40
	private object H(object x, object y, object z) { }

	// RVA: 0x3967A4C
	private object ROL(object x, object n) { }

	// RVA: 0x3967A58
	private object FF(object a, object b, object c, object d, object x, object s) { }

	// RVA: 0x3967A80
	private object GG(object a, object b, object c, object d, object x, object s) { }

	// RVA: 0x3967AB8
	private object HH(object a, object b, object c, object d, object x, object s) { }

	// RVA: 0x3967878
	private object Encode(object output, object input) { }

	// RVA: 0x3967AE8
	private object Decode(object output, object input, object index) { }

	// RVA: 0x3967060
	private object MD4Transform(object state, object block, object index) { }

}

// Namespace: Mono.Security.Cryptography
public sealed class PKCS1
{

	// Fields
	private static object emptySHA1; // 0x0
	private static object emptySHA256; // 0x8
	private static object emptySHA384; // 0x10
	private static object emptySHA512; // 0x18

	// Methods

	// RVA: 0x3967BA4
	private static object Compare(object array1, object array2) { }

	// RVA: 0x3967C2C
	public static object I2OSP(object x, object size) { }

	// RVA: 0x3967CD0
	public static object OS2IP(object x) { }

	// RVA: 0x3967DB4
	public static object RSAVP1(object rsa, object s) { }

	// RVA: 0x3967E0C
	public static object Verify_v15(object rsa, object hash, object hashValue, object signature, object tryNonStandardEncoding) { }

	// RVA: 0x3968138
	public static object Encode_v15(object hash, object hashValue, object emLength) { }

	// RVA: 0x3968568
	internal static object HashNameFromOid(object oid, object throwOnError) { }

	// RVA: 0x3968A9C
	internal static object CreateFromOid(object oid) { }

	// RVA: 0x3968B04
	internal static object CreateFromName(object name) { }

	// RVA: 0x3968FE8
	private static object .cctor() { }

}

// Namespace: 
public class PrivateKeyInfo
{

	// Fields
	private object _version; // 0x8
	private object _algorithm; // 0x10
	private object _key; // 0x18
	private object _list; // 0x20

	// Properties
	public object Algorithm { get; set; }
	public object PrivateKey { get; set; }

	// Methods

	// RVA: 0x3969144
	public object .ctor() { }

	// RVA: 0x39691B8
	public object .ctor(object data) { }

	// RVA: 0x3969510
	public object get_Algorithm() { }

	// RVA: 0x3969518
	public object set_Algorithm(object value) { }

	// RVA: 0x3969520
	public object get_PrivateKey() { }

	// RVA: 0x3969598
	public object set_PrivateKey(object value) { }

	// RVA: 0x3969238
	private object Decode(object data) { }

	// RVA: 0x396969C
	public object GetBytes() { }

	// RVA: 0x3969BEC
	private static object RemoveLeadingZero(object bigInt) { }

	// RVA: 0x3969C94
	private static object Normalize(object bigInt, object length) { }

	// RVA: 0x3969DC0
	public static object DecodeRSA(object keypair) { }

	// RVA: 0x396A318
	public static object Encode(object rsa) { }

	// RVA: 0x396A550
	public static object DecodeDSA(object privateKey, object dsaParameters) { }

	// RVA: 0x396A6A8
	public static object Encode(object dsa) { }

	// RVA: 0x396A754
	public static object Encode(object aa) { }

}

// Namespace: 
public class EncryptedPrivateKeyInfo
{

	// Fields
	private object _algorithm; // 0x8
	private object _salt; // 0x10
	private object _iterations; // 0x18
	private object _data; // 0x20

	// Properties
	public object Algorithm { get; set; }
	public object EncryptedData { get; set; }
	public object Salt { get; }
	public object IterationCount { get; set; }

	// Methods

	// RVA: 0x396A880
	public object .ctor() { }

	// RVA: 0x396A888
	public object .ctor(object data) { }

	// RVA: 0x396AB98
	public object get_Algorithm() { }

	// RVA: 0x396ABA0
	public object set_Algorithm(object value) { }

	// RVA: 0x396ABA8
	public object get_EncryptedData() { }

	// RVA: 0x396AC20
	public object set_EncryptedData(object value) { }

	// RVA: 0x396ACBC
	public object get_Salt() { }

	// RVA: 0x396ADA4
	public object get_IterationCount() { }

	// RVA: 0x396ADAC
	public object set_IterationCount(object value) { }

	// RVA: 0x396A8B8
	private object Decode(object data) { }

	// RVA: 0x396AE20
	public object GetBytes() { }

}

// Namespace: Mono.Security.Cryptography
public sealed class PKCS8
{
}

// Namespace: 
public sealed class KeyGeneratedEventHandler
{

	// Methods

	// RVA: 0x396E5B8
	public object .ctor(object object, object method) { }

	// RVA: 0x396E6C4
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: Mono.Security.Cryptography
public class RSAManaged
{

	// Fields
	private object isCRTpossible; // 0x18
	private object keyBlinding; // 0x19
	private object keypairGenerated; // 0x1A
	private object m_disposed; // 0x1B
	private object d; // 0x20
	private object p; // 0x28
	private object q; // 0x30
	private object dp; // 0x38
	private object dq; // 0x40
	private object qInv; // 0x48
	private object n; // 0x50
	private object e; // 0x58
	private object KeyGenerated; // 0x60

	// Properties
	public override object KeySize { get; }
	public object PublicOnly { get; }

	// Methods

	// RVA: 0x396B028
	public object .ctor() { }

	// RVA: 0x396B030
	public object .ctor(object keySize) { }

	// RVA: 0x396B110
	protected override object Finalize() { }

	// RVA: 0x396B1C8
	private object GenerateKeyPair() { }

	// RVA: 0x396C190
	public override object get_KeySize() { }

	// RVA: 0x396C248
	public object get_PublicOnly() { }

	// RVA: 0x396C438
	public override object EncryptValue(object rgb) { }

	// RVA: 0x396CAB4
	public override object ExportParameters(object includePrivateParameters) { }

	// RVA: 0x396D12C
	public override object ImportParameters(object parameters) { }

	// RVA: 0x396D638
	protected override object Dispose(object disposing) { }

	// RVA: 0x396DBE0
	public override object ToXmlString(object includePrivateParameters) { }

	// RVA: 0x396C97C
	private object GetPaddedValue(object value, object length) { }

}

// Namespace: Mono.Security.Authenticode
public class AuthenticodeBase
{

	// Fields
	private object fileblock; // 0x8
	private object fs; // 0x10
	private object blockNo; // 0x18
	private object blockLength; // 0x1C
	private object peOffset; // 0x20
	private object dirSecurityOffset; // 0x24
	private object dirSecuritySize; // 0x28
	private object coffSymbolTableOffset; // 0x2C
	private object pe64; // 0x30

	// Properties
	internal object PEOffset { get; }

	// Methods

	// RVA: 0x396E6D8
	public object .ctor() { }

	// RVA: 0x396E740
	internal object get_PEOffset() { }

	// RVA: 0x396E868
	internal object Open(object filename) { }

	// RVA: 0x396E968
	internal object Open(object rawdata) { }

	// RVA: 0x396E918
	internal object Close() { }

	// RVA: 0x396E784
	internal object ReadFirstBlock() { }

	// RVA: 0x396EA10
	internal object ProcessFirstBlock() { }

	// RVA: 0x396ED24
	internal object GetSecurityEntry() { }

	// RVA: 0x396EE7C
	internal object GetHash(object hash) { }

}

// Namespace: Mono.Security.Authenticode
public class AuthenticodeDeformatter
{

	// Fields
	private object filename; // 0x38
	private object rawdata; // 0x40
	private object hash; // 0x48
	private object coll; // 0x50
	private object signedHash; // 0x58
	private object timestamp; // 0x60
	private object signingCertificate; // 0x68
	private object reason; // 0x70
	private object trustedRoot; // 0x74
	private object trustedTimestampRoot; // 0x75
	private object entry; // 0x78
	private object signerChain; // 0x80
	private object timestampChain; // 0x88

	// Properties
	public object RawData { set; }
	public object SigningCertificate { get; }

	// Methods

	// RVA: 0x396F4AC
	public object .ctor() { }

	// RVA: 0x396F574
	public object .ctor(object rawData) { }

	// RVA: 0x396F5A0
	public object set_RawData(object value) { }

	// RVA: 0x396FC5C
	public object get_SigningCertificate() { }

	// RVA: 0x396F754
	private object CheckSignature() { }

	// RVA: 0x3970914
	private object CompareIssuerSerial(object issuer, object serial, object x509) { }

	// RVA: 0x396FC64
	private object VerifySignature(object sd, object calculatedMessageDigest, object ha) { }

	// RVA: 0x3970AA0
	private object VerifyCounterSignature(object cs, object signature) { }

	// RVA: 0x396F680
	private object Reset() { }

}

// Namespace: 
public enum Sign
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Negative;
	public const object Zero;
	public const object Positive;
}

// Namespace: 
public sealed class ModulusRing
{

	// Fields
	private object mod; // 0x8
	private object constant; // 0x10

	// Methods

	// RVA: 0x3973E58
	public object .ctor(object modulus) { }

	// RVA: 0x3974294
	public object BarrettReduction(object x) { }

	// RVA: 0x3974D78
	public object Multiply(object a, object b) { }

	// RVA: 0x3974FC4
	public object Difference(object a, object b) { }

	// RVA: 0x3973FB4
	public object Pow(object a, object k) { }

	// RVA: 0x3975204
	public object Pow(object b, object exp) { }

}

// Namespace: 
private sealed class Kernel
{

	// Methods

	// RVA: 0x3971C54
	public static object Subtract(object big, object small) { }

	// RVA: 0x39749C8
	public static object MinusEq(object big, object small) { }

	// RVA: 0x3974B00
	public static object PlusEq(object bi1, object bi2) { }

	// RVA: 0x3971A9C
	public static object Compare(object bi1, object bi2) { }

	// RVA: 0x39734E4
	public static object SingleByteDivideInPlace(object n, object d) { }

	// RVA: 0x3971EB4
	public static object DwordMod(object n, object d) { }

	// RVA: 0x39752E4
	public static object DwordDivMod(object n, object d) { }

	// RVA: 0x3971F34
	public static object multiByteDivide(object bi1, object bi2) { }

	// RVA: 0x39726A0
	public static object LeftShift(object bi, object n) { }

	// RVA: 0x397294C
	public static object RightShift(object bi, object n) { }

	// RVA: 0x3972588
	public static object Multiply(object x, object xOffset, object xLen, object y, object yOffset, object yLen, object d, object dOffset) { }

	// RVA: 0x397488C
	public static object MultiplyMod2p32pmod(object x, object xOffset, object xLen, object y, object yOffest, object yLen, object d, object dOffset, object mod) { }

	// RVA: 0x397553C
	public static object modInverse(object bi, object modulus) { }

	// RVA: 0x397386C
	public static object modInverse(object bi, object modulus) { }

}

// Namespace: Mono.Math
public class BigInteger
{

	// Fields
	private object length; // 0x8
	private object data; // 0x10
	internal static readonly object smallPrimes; // 0x0
	private static object rng; // 0x8

	// Properties
	private static object Rng { get; }

	// Methods

	// RVA: 0x3971668
	public object .ctor(object sign, object len) { }

	// RVA: 0x39716E0
	public object .ctor(object bi) { }

	// RVA: 0x39717C0
	public object .ctor(object bi, object len) { }

	// RVA: 0x396C65C
	public object .ctor(object inData) { }

	// RVA: 0x3971958
	public object .ctor(object ui) { }

	// RVA: 0x396B748
	public static object op_Implicit(object value) { }

	// RVA: 0x396BE88
	public static object op_Implicit(object value) { }

	// RVA: 0x396BF9C
	public static object op_Subtraction(object bi1, object bi2) { }

	// RVA: 0x396B8A4
	public static object op_Modulus(object bi, object ui) { }

	// RVA: 0x396C158
	public static object op_Modulus(object bi1, object bi2) { }

	// RVA: 0x3972554
	public static object op_Division(object bi1, object bi2) { }

	// RVA: 0x396BA30
	public static object op_Multiply(object bi1, object bi2) { }

	// RVA: 0x397269C
	public static object op_LeftShift(object bi1, object shiftVal) { }

	// RVA: 0x3972948
	public static object op_RightShift(object bi1, object shiftVal) { }

	// RVA: 0x3972B70
	private static object get_Rng() { }

	// RVA: 0x3972C58
	public static object GenerateRandom(object bits, object rng) { }

	// RVA: 0x3972E7C
	public static object GenerateRandom(object bits) { }

	// RVA: 0x396BDB0
	public object BitCount() { }

	// RVA: 0x3972EE4
	public object TestBit(object bitNum) { }

	// RVA: 0x3972F8C
	public object SetBit(object bitNum) { }

	// RVA: 0x3972FE8
	public object SetBit(object bitNum, object value) { }

	// RVA: 0x3973074
	public object LowestSetBit() { }

	// RVA: 0x396CE88
	public object GetBytes() { }

	// RVA: 0x39719EC
	public static object op_Equality(object bi1, object ui) { }

	// RVA: 0x3973120
	public static object op_Inequality(object bi1, object ui) { }

	// RVA: 0x396C330
	public static object op_Equality(object bi1, object bi2) { }

	// RVA: 0x396B928
	public static object op_Inequality(object bi1, object bi2) { }

	// RVA: 0x39731D0
	public static object op_GreaterThan(object bi1, object bi2) { }

	// RVA: 0x396BE70
	public static object op_LessThan(object bi1, object bi2) { }

	// RVA: 0x39731EC
	public static object op_GreaterThanOrEqual(object bi1, object bi2) { }

	// RVA: 0x3973208
	public static object op_LessThanOrEqual(object bi1, object bi2) { }

	// RVA: 0x3973224
	public object ToString(object radix) { }

	// RVA: 0x3973284
	public object ToString(object radix, object characterSet) { }

	// RVA: 0x39718F0
	private object Normalize() { }

	// RVA: 0x396CA4C
	public object Clear() { }

	// RVA: 0x39735B8
	public override object GetHashCode() { }

	// RVA: 0x3973680
	public override object ToString() { }

	// RVA: 0x39736DC
	public override object Equals(object o) { }

	// RVA: 0x396C154
	public object ModInverse(object modulus) { }

	// RVA: 0x396C8F0
	public object ModPow(object exp, object n) { }

	// RVA: 0x396B810
	public static object GeneratePseudoPrime(object bits) { }

	// RVA: 0x3974168
	public object Incr2() { }

	// RVA: 0x39741FC
	private static object .cctor() { }

}

// Namespace: Mono.Math.Prime
public enum ConfidenceFactor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ExtraLow;
	public const object Low;
	public const object Medium;
	public const object High;
	public const object ExtraHigh;
	public const object Provable;
}

// Namespace: Mono.Math.Prime
public sealed class PrimalityTest
{

	// Methods

	// RVA: 0x39759A0
	public object .ctor(object object, object method) { }

	// RVA: 0x3975AAC
	public virtual object Invoke(object bi, object confidence) { }

}

// Namespace: Mono.Math.Prime
public sealed class PrimalityTests
{

	// Methods

	// RVA: 0x3975AC0
	private static object GetSPPRounds(object bi, object confidence) { }

	// RVA: 0x3975CB0
	public static object RabinMillerTest(object n, object confidence) { }

}

// Namespace: Mono.Math.Prime.Generator
public abstract class PrimeGeneratorBase
{

	// Properties
	public virtual object Confidence { get; }
	public virtual object PrimalityTest { get; }
	public virtual object TrialDivisionBounds { get; }

	// Methods

	// RVA: 0x3976228
	public virtual object get_Confidence() { }

	// RVA: 0x3976230
	public virtual object get_PrimalityTest() { }

	// RVA: 0x39762A8
	public virtual object get_TrialDivisionBounds() { }

	// RVA: -1
	public abstract object GenerateNewPrime(object bits) { }

	// RVA: 0x39762B0
	protected object .ctor() { }

}

// Namespace: Mono.Math.Prime.Generator
public class SequentialSearchPrimeGeneratorBase
{

	// Methods

	// RVA: 0x39762B8
	protected virtual object GenerateSearchBase(object bits, object context) { }

	// RVA: 0x39763D0
	public override object GenerateNewPrime(object bits) { }

	// RVA: 0x397641C
	public virtual object GenerateNewPrime(object bits, object context) { }

	// RVA: 0x3976898
	protected virtual object IsPrimeAcceptable(object bi, object context) { }

	// RVA: 0x3974160
	public object .ctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=3
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=9
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=10
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=18
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=20
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=32
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=48
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=64
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=256
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=3132
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 001D686DB504E20C792EAA07FE09224A45FF328E24A80072D04D16ABC5C2B5D2; // 0x0
	internal static readonly object 25E3E48132FBDBE9B7C0C6C54D7C10A5DE12A105AA3E5DE2A0DC808BF245B7A5; // 0x40
	internal static readonly object 290C4A052C215D096172EB81AEE671FB3286E5C1DB5E73F96021FC09825DDB88; // 0xC80
	internal static readonly object 32D0830B8EE1D49A66F395C8EA80E02BFC07C2A12A8EA8C8B484AF02108A1950; // 0xC88
	internal static readonly object 35BF50EEF3270FD8CA09E66FC5B0481C5A151B14F6A634854E32F63633D49DCB; // 0xC8B
	internal static readonly object 3C0C410618682C4DF0474E034114CC8E562F05A512B521AC367571017BDFA75D; // 0xC8E
	internal static readonly object 44F5B1A2C48314502ACCBF186D1A2F9F7F176825898F32F1A2047B956194F174; // 0xC91
	internal static readonly object 4800FBFC4566EB02D1727A4B1C949CCBC7535C216A0766564C199308631B5DD6; // 0xC94
	internal static readonly object 533B8C444F951E83EFF7305E3807B66CE0005DE0A2D0A44873C130895A3BE6AA; // 0xCC4
	internal static readonly object 55D0BF716B334D123E0088CFB3F8E2FEA17AF5025BB527F95EEB09BA978EA329; // 0xCD8
	internal static readonly object 59BE5A634187B8A57216EFF5371A47732C05744B1C1A0A6382A6D5622C9FFDCE; // 0xDD8
	internal static readonly object 5DF6E0E2761359D30A8275058E299FCC0381534545F55CF43E41983F5D4C9456; // 0xDDB
	internal static readonly object 5F8C6B3C66B972606D85E7651F67ADBD02E8316876884674E8328FA710747E5B; // 0xDFB
	internal static readonly object 60C6ED13AF98DBFEEDA8F8197FFFCC349BB04395CC81DF0D477CBC57BF5B398B; // 0xDFE
	internal static readonly object 64B3E7D737AFF47D4C3BBD81D2D06D697DDD8EB60F29E13E4425D19D8BBCA1F7; // 0xE08
	internal static readonly object 6772A9B8BF207A3CFE6EE68769D6985B69522183F24A2A3D41BC3B4602953426; // 0xE18
	internal static readonly object 684312AFB7719E57993D2826FFBAF7EA965614F20F91D999FB19B01E21AA62E6; // 0xE20
	internal static readonly object 6AA56C4BCD208911792AD24C7681FEFB93BED51903AFC54860C9BD37E41E5A31; // 0xE29
	internal static readonly object 796E63069E193A008CB4E85573AA1FE53C5F4E58B42A7F61FD0EEE1D89B5120B; // 0xE69
	internal static readonly object 7C8975E1E60A5C8337F28EDF8C33C3B180360B7279644A9BC1AF3C51E6220BF5; // 0xE6C
	internal static readonly object 850D7367E4FB0766E2CBC3ACF5AB42B4E98348E58E5A789845D4FCCDB63D2AEE; // 0xEAC
	internal static readonly object 992F16C986809AB68C7466CC3EC6F12B2506A962EA539753E5D84A2FB7FF8A24; // 0xEB0
	internal static readonly object 9A65C09A11757751BFED67A414E00B188DC4C7757FCB6CBD33A916DDE4A3D925; // 0xEB8
	internal static readonly object 9ACEFCC0C950280B64AB9E045E38C34ABF71EC70A0DC61B9C621C6BFB4F78047; // 0xEBB
	internal static readonly object B1E34F4A11EE411B83415EF0B252A0B2BBCFCAC2E592865E09C12E4252C93A75; // 0xECD
	internal static readonly object C92FAD7F348A682E7D5B7E74C76B5D019174EE7BC87545B25A1FDD49FBCC2D0B; // 0xED0
	internal static readonly object E17B8359E685992B0DE6242AAA24FCB7404173CBB7FF8646FF7D658139F41B5F; // 0xED3
	internal static readonly object F83B332BE4E6A5A4B1C56AAF6DB52657DA495E149870057D8590AB9D7A6167AD; // 0xED6
	internal static readonly object FB6D7301FFDCB5FBA5807A19B4F0606947897C1105240B6BBA815352DBBE2064; // 0xF16

	// Methods

	// RVA: 0x3968A10
	internal static object ComputeStringHash(object s) { }

}

