// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public enum RigidbodyConstraints
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object FreezePositionX;
	public const object FreezePositionY;
	public const object FreezePositionZ;
	public const object FreezeRotationX;
	public const object FreezeRotationY;
	public const object FreezeRotationZ;
	public const object FreezePosition;
	public const object FreezeRotation;
	public const object FreezeAll;
}

// Namespace: UnityEngine
public enum ForceMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Force;
	public const object Acceleration;
	public const object Impulse;
	public const object VelocityChange;
}

// Namespace: UnityEngine
public enum MeshColliderCookingOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object InflateConvexMesh;
	public const object CookForFasterSimulation;
	public const object EnableMeshCleaning;
	public const object WeldColocatedVertices;
	public const object UseFastMidphase;
}

// Namespace: UnityEngine
public enum RigidbodyInterpolation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Interpolate;
	public const object Extrapolate;
}

// Namespace: UnityEngine
public struct JointMotor
{

	// Fields
	private object m_TargetVelocity; // 0xFFFFFFFFFFFFFFF8
	private object m_Force; // 0xFFFFFFFFFFFFFFFC
	private object m_FreeSpin; // 0x0

	// Properties
	public object targetVelocity { get; set; }
	public object force { get; set; }
	public object freeSpin { get; set; }

	// Methods

	// RVA: 0x7479E6C
	public object get_targetVelocity() { }

	// RVA: 0x7479E7C
	public object set_targetVelocity(object value) { }

	// RVA: 0x7479E8C
	public object get_force() { }

	// RVA: 0x7479E9C
	public object set_force(object value) { }

	// RVA: 0x7479EAC
	public object get_freeSpin() { }

	// RVA: 0x7479ECC
	public object set_freeSpin(object value) { }

}

// Namespace: UnityEngine
public struct JointSpring
{

	// Fields
	public object spring; // 0xFFFFFFFFFFFFFFF8
	public object damper; // 0xFFFFFFFFFFFFFFFC
	public object targetPosition; // 0x0
}

// Namespace: UnityEngine
public struct JointLimits
{

	// Fields
	private object m_Min; // 0xFFFFFFFFFFFFFFF8
	private object m_Max; // 0xFFFFFFFFFFFFFFFC
	private object m_Bounciness; // 0x0
	private object m_BounceMinVelocity; // 0x4
	private object m_ContactDistance; // 0x8
	public object minBounce; // 0xC
	public object maxBounce; // 0x10
}

// Namespace: UnityEngine
public class ControllerColliderHit
{

	// Fields
	internal object m_Controller; // 0x8
	internal object m_Collider; // 0x10
	internal object m_Point; // 0x18
	internal object m_Normal; // 0x24
	internal object m_MoveDirection; // 0x30
	internal object m_MoveLength; // 0x3C
	internal object m_Push; // 0x40
}

// Namespace: UnityEngine
public class Collision
{

	// Fields
	private object m_Header; // 0x8
	private object m_Pair; // 0x30
	private object m_Flipped; // 0x58
	private object m_LegacyContacts; // 0x60

	// Properties
	public object body { get; }
	public object collider { get; }
	public object gameObject { get; }
	internal object Flipped { set; }

	// Methods

	// RVA: 0x7479F18
	public object get_body() { }

	// RVA: 0x747A15C
	public object get_collider() { }

	// RVA: 0x747A390
	public object get_gameObject() { }

	// RVA: 0x747A468
	internal object set_Flipped(object value) { }

	// RVA: 0x747A470
	public object .ctor() { }

	// RVA: 0x747A4B8
	internal object .ctor(object header, object pair, object flipped) { }

	// RVA: 0x747A600
	internal object Reuse(object header, object pair) { }

}

// Namespace: UnityEngine
public enum QueryTriggerInteraction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UseGlobal;
	public const object Ignore;
	public const object Collide;
}

// Namespace: UnityEngine
public enum CollisionDetectionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Discrete;
	public const object Continuous;
	public const object ContinuousDynamic;
	public const object ContinuousSpeculative;
}

// Namespace: UnityEngine
public class ArticulationBody
{

	// Methods

	// RVA: 0x747A630
	public object .ctor() { }

}

// Namespace: 
public sealed class ContactEventDelegate
{

	// Methods

	// RVA: 0x748A05C
	public object .ctor(object object, object method) { }

	// RVA: 0x748A0F4
	public virtual object Invoke(object scene, object headerArray) { }

}

// Namespace: UnityEngine
public class Physics
{

	// Fields
	private static object ContactModifyEvent; // 0x0
	private static object ContactModifyEventCCD; // 0x8
	internal const object k_MaxFloatMinusEpsilon;
	public const object IgnoreRaycastLayer;
	public const object DefaultRaycastLayers;
	public const object AllLayers;
	public const object kIgnoreRaycastLayer;
	public const object kDefaultRaycastLayers;
	public const object kAllLayers;
	private static object ContactEvent; // 0x10
	private static readonly object s_ReusableCollision; // 0x18

	// Properties
	public static object gravity { get; set; }
	public static object defaultContactOffset { get; set; }
	public static object sleepThreshold { get; set; }
	public static object queriesHitTriggers { get; set; }
	public static object queriesHitBackfaces { get; set; }
	public static object bounceThreshold { get; set; }
	public static object defaultMaxDepenetrationVelocity { get; set; }
	public static object defaultSolverIterations { get; set; }
	public static object defaultSolverVelocityIterations { get; set; }
	public static object simulationMode { get; set; }
	public static object defaultMaxAngularSpeed { get; set; }
	public static object improvedPatchFriction { get; set; }
	public static object invokeCollisionCallbacks { get; set; }
	public static object defaultPhysicsScene { get; }
	public static object autoSyncTransforms { get; set; }
	public static object reuseCollisionCallbacks { get; set; }
	public static object interCollisionDistance { get; set; }
	public static object interCollisionStiffness { get; set; }
	public static object interCollisionSettingsToggle { get; set; }
	public static object clothGravity { get; set; }
	public static object minPenetrationForPenalty { get; set; }
	public static object bounceTreshold { get; set; }
	public static object sleepVelocity { get; set; }
	public static object sleepAngularVelocity { get; set; }
	public static object maxAngularVelocity { get; set; }
	public static object solverIterationCount { get; set; }
	public static object solverVelocityIterationCount { get; set; }
	public static object penetrationPenaltyForce { get; set; }
	public static object autoSimulation { get; set; }

	// Methods

	// RVA: 0x747A638
	public static object add_ContactModifyEvent(object value) { }

	// RVA: 0x747A748
	public static object remove_ContactModifyEvent(object value) { }

	// RVA: 0x747A858
	public static object add_ContactModifyEventCCD(object value) { }

	// RVA: 0x747A96C
	public static object remove_ContactModifyEventCCD(object value) { }

	// RVA: 0x747AA80
	private static object OnSceneContactModify(object scene, object buffer, object count, object isCCD) { }

	// RVA: 0x747ABA4
	public static object get_gravity() { }

	// RVA: 0x747ACA8
	public static object set_gravity(object value) { }

	// RVA: 0x747ADB0
	public static object get_defaultContactOffset() { }

	// RVA: 0x747ADF0
	public static object set_defaultContactOffset(object value) { }

	// RVA: 0x747AE44
	public static object get_sleepThreshold() { }

	// RVA: 0x747AE84
	public static object set_sleepThreshold(object value) { }

	// RVA: 0x747AED8
	public static object get_queriesHitTriggers() { }

	// RVA: 0x747AF18
	public static object set_queriesHitTriggers(object value) { }

	// RVA: 0x747AF68
	public static object get_queriesHitBackfaces() { }

	// RVA: 0x747AFA8
	public static object set_queriesHitBackfaces(object value) { }

	// RVA: 0x747AFF8
	public static object get_bounceThreshold() { }

	// RVA: 0x747B038
	public static object set_bounceThreshold(object value) { }

	// RVA: 0x747B08C
	public static object get_defaultMaxDepenetrationVelocity() { }

	// RVA: 0x747B0CC
	public static object set_defaultMaxDepenetrationVelocity(object value) { }

	// RVA: 0x747B120
	public static object get_defaultSolverIterations() { }

	// RVA: 0x747B160
	public static object set_defaultSolverIterations(object value) { }

	// RVA: 0x747B1B0
	public static object get_defaultSolverVelocityIterations() { }

	// RVA: 0x747B1F0
	public static object set_defaultSolverVelocityIterations(object value) { }

	// RVA: 0x747B240
	public static object get_simulationMode() { }

	// RVA: 0x747B280
	public static object set_simulationMode(object value) { }

	// RVA: 0x747B2D0
	public static object get_defaultMaxAngularSpeed() { }

	// RVA: 0x747B310
	public static object set_defaultMaxAngularSpeed(object value) { }

	// RVA: 0x747B364
	public static object get_improvedPatchFriction() { }

	// RVA: 0x747B3A4
	public static object set_improvedPatchFriction(object value) { }

	// RVA: 0x747B3F4
	public static object get_invokeCollisionCallbacks() { }

	// RVA: 0x747B434
	public static object set_invokeCollisionCallbacks(object value) { }

	// RVA: 0x747B484
	public static object get_defaultPhysicsScene() { }

	// RVA: 0x747B57C
	public static object IgnoreCollision(object collider1, object collider2, object ignore) { }

	// RVA: 0x747B5E8
	public static object IgnoreCollision(object collider1, object collider2) { }

	// RVA: 0x747B690
	public static object IgnoreLayerCollision(object layer1, object layer2, object ignore) { }

	// RVA: 0x747B6FC
	public static object IgnoreLayerCollision(object layer1, object layer2) { }

	// RVA: 0x747B7A4
	public static object GetIgnoreLayerCollision(object layer1, object layer2) { }

	// RVA: 0x747B808
	public static object GetIgnoreCollision(object collider1, object collider2) { }

	// RVA: 0x747B86C
	public static object Raycast(object origin, object direction, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747BBB4
	public static object Raycast(object origin, object direction, object maxDistance, object layerMask) { }

	// RVA: 0x747BD1C
	public static object Raycast(object origin, object direction, object maxDistance) { }

	// RVA: 0x747BE78
	public static object Raycast(object origin, object direction) { }

	// RVA: 0x747BFCC
	public static object Raycast(object origin, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747C338
	public static object Raycast(object origin, object direction, object hitInfo, object maxDistance, object layerMask) { }

	// RVA: 0x747C4A8
	public static object Raycast(object origin, object direction, object hitInfo, object maxDistance) { }

	// RVA: 0x747C614
	public static object Raycast(object origin, object direction, object hitInfo) { }

	// RVA: 0x747C778
	public static object Raycast(object ray, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747C8B4
	public static object Raycast(object ray, object maxDistance, object layerMask) { }

	// RVA: 0x747C9E4
	public static object Raycast(object ray, object maxDistance) { }

	// RVA: 0x747CB10
	public static object Raycast(object ray) { }

	// RVA: 0x747CC34
	public static object Raycast(object ray, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747CD78
	public static object Raycast(object ray, object hitInfo, object maxDistance, object layerMask) { }

	// RVA: 0x747CE3C
	public static object Raycast(object ray, object hitInfo, object maxDistance) { }

	// RVA: 0x747CF70
	public static object Raycast(object ray, object hitInfo) { }

	// RVA: 0x747D09C
	public static object Linecast(object start, object end, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747D248
	public static object Linecast(object start, object end, object layerMask) { }

	// RVA: 0x747D2F4
	public static object Linecast(object start, object end) { }

	// RVA: 0x747D394
	public static object Linecast(object start, object end, object hitInfo, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747D550
	public static object Linecast(object start, object end, object hitInfo, object layerMask) { }

	// RVA: 0x747D604
	public static object Linecast(object start, object end, object hitInfo) { }

	// RVA: 0x747D6B4
	public static object CapsuleCast(object point1, object point2, object radius, object direction, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747D860
	public static object CapsuleCast(object point1, object point2, object radius, object direction, object maxDistance, object layerMask) { }

	// RVA: 0x747D97C
	public static object CapsuleCast(object point1, object point2, object radius, object direction, object maxDistance) { }

	// RVA: 0x747DA8C
	public static object CapsuleCast(object point1, object point2, object radius, object direction) { }

	// RVA: 0x747DB80
	public static object CapsuleCast(object point1, object point2, object radius, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747DD04
	public static object CapsuleCast(object point1, object point2, object radius, object direction, object hitInfo, object maxDistance, object layerMask) { }

	// RVA: 0x747DE28
	public static object CapsuleCast(object point1, object point2, object radius, object direction, object hitInfo, object maxDistance) { }

	// RVA: 0x747DF48
	public static object CapsuleCast(object point1, object point2, object radius, object direction, object hitInfo) { }

	// RVA: 0x747E04C
	public static object SphereCast(object origin, object radius, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747E3C8
	public static object SphereCast(object origin, object radius, object direction, object hitInfo, object maxDistance, object layerMask) { }

	// RVA: 0x747E494
	public static object SphereCast(object origin, object radius, object direction, object hitInfo, object maxDistance) { }

	// RVA: 0x747E55C
	public static object SphereCast(object origin, object radius, object direction, object hitInfo) { }

	// RVA: 0x747E624
	public static object SphereCast(object ray, object radius, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747E708
	public static object SphereCast(object ray, object radius, object maxDistance, object layerMask) { }

	// RVA: 0x747E850
	public static object SphereCast(object ray, object radius, object maxDistance) { }

	// RVA: 0x747E994
	public static object SphereCast(object ray, object radius) { }

	// RVA: 0x747EAD8
	public static object SphereCast(object ray, object radius, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747EBA8
	public static object SphereCast(object ray, object radius, object hitInfo, object maxDistance, object layerMask) { }

	// RVA: 0x747ECD8
	public static object SphereCast(object ray, object radius, object hitInfo, object maxDistance) { }

	// RVA: 0x747EDFC
	public static object SphereCast(object ray, object radius, object hitInfo) { }

	// RVA: 0x747EF20
	public static object BoxCast(object center, object halfExtents, object direction, object orientation, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747F0C0
	public static object BoxCast(object center, object halfExtents, object direction, object orientation, object maxDistance, object layerMask) { }

	// RVA: 0x747F1F0
	public static object BoxCast(object center, object halfExtents, object direction, object orientation, object maxDistance) { }

	// RVA: 0x747F314
	public static object BoxCast(object center, object halfExtents, object direction, object orientation) { }

	// RVA: 0x747F410
	public static object BoxCast(object center, object halfExtents, object direction) { }

	// RVA: 0x747F514
	public static object BoxCast(object center, object halfExtents, object direction, object hitInfo, object orientation, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747F67C
	public static object BoxCast(object center, object halfExtents, object direction, object hitInfo, object orientation, object maxDistance, object layerMask) { }

	// RVA: 0x747F7B4
	public static object BoxCast(object center, object halfExtents, object direction, object hitInfo, object orientation, object maxDistance) { }

	// RVA: 0x747F8E8
	public static object BoxCast(object center, object halfExtents, object direction, object hitInfo, object orientation) { }

	// RVA: 0x747F9F4
	public static object BoxCast(object center, object halfExtents, object direction, object hitInfo) { }

	// RVA: 0x747FB00
	private static object Internal_RaycastAll(object physicsScene, object ray, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x747FC6C
	public static object RaycastAll(object origin, object direction, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747FFB0
	public static object RaycastAll(object origin, object direction, object maxDistance, object layerMask) { }

	// RVA: 0x748006C
	public static object RaycastAll(object origin, object direction, object maxDistance) { }

	// RVA: 0x748011C
	public static object RaycastAll(object origin, object direction) { }

	// RVA: 0x74801C4
	public static object RaycastAll(object ray, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7480284
	public static object RaycastAll(object ray, object maxDistance, object layerMask) { }

	// RVA: 0x7480338
	public static object RaycastAll(object ray, object maxDistance) { }

	// RVA: 0x74803E8
	public static object RaycastAll(object ray) { }

	// RVA: 0x7480490
	public static object RaycastNonAlloc(object ray, object results, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7480848
	public static object RaycastNonAlloc(object ray, object results, object maxDistance, object layerMask) { }

	// RVA: 0x7480988
	public static object RaycastNonAlloc(object ray, object results, object maxDistance) { }

	// RVA: 0x7480ABC
	public static object RaycastNonAlloc(object ray, object results) { }

	// RVA: 0x7480BE8
	public static object RaycastNonAlloc(object origin, object direction, object results, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7480D64
	public static object RaycastNonAlloc(object origin, object direction, object results, object maxDistance, object layerMask) { }

	// RVA: 0x7480ED4
	public static object RaycastNonAlloc(object origin, object direction, object results, object maxDistance) { }

	// RVA: 0x7481040
	public static object RaycastNonAlloc(object origin, object direction, object results) { }

	// RVA: 0x74811A4
	private static object Query_CapsuleCastAll(object physicsScene, object p0, object p1, object radius, object direction, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7481340
	public static object CapsuleCastAll(object point1, object point2, object radius, object direction, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7481604
	public static object CapsuleCastAll(object point1, object point2, object radius, object direction, object maxDistance, object layerMask) { }

	// RVA: 0x7481720
	public static object CapsuleCastAll(object point1, object point2, object radius, object direction, object maxDistance) { }

	// RVA: 0x7481830
	public static object CapsuleCastAll(object point1, object point2, object radius, object direction) { }

	// RVA: 0x7481924
	private static object Query_SphereCastAll(object physicsScene, object origin, object radius, object direction, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7481AB0
	public static object SphereCastAll(object origin, object radius, object direction, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7481D60
	public static object SphereCastAll(object origin, object radius, object direction, object maxDistance, object layerMask) { }

	// RVA: 0x7481E24
	public static object SphereCastAll(object origin, object radius, object direction, object maxDistance) { }

	// RVA: 0x7481EDC
	public static object SphereCastAll(object origin, object radius, object direction) { }

	// RVA: 0x7481F94
	public static object SphereCastAll(object ray, object radius, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x748205C
	public static object SphereCastAll(object ray, object radius, object maxDistance, object layerMask) { }

	// RVA: 0x748217C
	public static object SphereCastAll(object ray, object radius, object maxDistance) { }

	// RVA: 0x7482298
	public static object SphereCastAll(object ray, object radius) { }

	// RVA: 0x74823B4
	private static object OverlapCapsule_Internal(object physicsScene, object point0, object point1, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7482530
	public static object OverlapCapsule(object point0, object point1, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7482708
	public static object OverlapCapsule(object point0, object point1, object radius, object layerMask) { }

	// RVA: 0x74827C4
	public static object OverlapCapsule(object point0, object point1, object radius) { }

	// RVA: 0x7482874
	private static object OverlapSphere_Internal(object physicsScene, object position, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74829DC
	public static object OverlapSphere(object position, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7482B8C
	public static object OverlapSphere(object position, object radius, object layerMask) { }

	// RVA: 0x7482C20
	public static object OverlapSphere(object position, object radius) { }

	// RVA: 0x7482CA8
	internal static object Simulate_Internal(object physicsScene, object step) { }

	// RVA: 0x7482DBC
	public static object Simulate(object step) { }

	// RVA: 0x7482FD8
	internal static object InterpolateBodies_Internal(object physicsScene) { }

	// RVA: 0x74830DC
	internal static object ResetInterpolationPoses_Internal(object physicsScene) { }

	// RVA: 0x74831E0
	public static object SyncTransforms() { }

	// RVA: 0x7483220
	public static object get_autoSyncTransforms() { }

	// RVA: 0x7483260
	public static object set_autoSyncTransforms(object value) { }

	// RVA: 0x74832B0
	public static object get_reuseCollisionCallbacks() { }

	// RVA: 0x74832F0
	public static object set_reuseCollisionCallbacks(object value) { }

	// RVA: 0x7483340
	private static object Query_ComputePenetration(object colliderA, object positionA, object rotationA, object colliderB, object positionB, object rotationB, object direction, object distance) { }

	// RVA: 0x74834DC
	public static object ComputePenetration(object colliderA, object positionA, object rotationA, object colliderB, object positionB, object rotationB, object direction, object distance) { }

	// RVA: 0x748369C
	private static object Query_ClosestPoint(object collider, object position, object rotation, object point) { }

	// RVA: 0x7483814
	public static object ClosestPoint(object point, object collider, object position, object rotation) { }

	// RVA: 0x7483984
	public static object get_interCollisionDistance() { }

	// RVA: 0x74839C4
	public static object set_interCollisionDistance(object value) { }

	// RVA: 0x7483A18
	public static object get_interCollisionStiffness() { }

	// RVA: 0x7483A58
	public static object set_interCollisionStiffness(object value) { }

	// RVA: 0x7483AAC
	public static object get_interCollisionSettingsToggle() { }

	// RVA: 0x7483AEC
	public static object set_interCollisionSettingsToggle(object value) { }

	// RVA: 0x7483B3C
	public static object get_clothGravity() { }

	// RVA: 0x7483C40
	public static object set_clothGravity(object value) { }

	// RVA: 0x7483D48
	public static object OverlapSphereNonAlloc(object position, object radius, object results, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7483F48
	public static object OverlapSphereNonAlloc(object position, object radius, object results, object layerMask) { }

	// RVA: 0x7483FE4
	public static object OverlapSphereNonAlloc(object position, object radius, object results) { }

	// RVA: 0x748407C
	private static object CheckSphere_Internal(object physicsScene, object position, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74841E4
	public static object CheckSphere(object position, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7484394
	public static object CheckSphere(object position, object radius, object layerMask) { }

	// RVA: 0x7484428
	public static object CheckSphere(object position, object radius) { }

	// RVA: 0x74844B0
	public static object CapsuleCastNonAlloc(object point1, object point2, object radius, object direction, object results, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7484834
	public static object CapsuleCastNonAlloc(object point1, object point2, object radius, object direction, object results, object maxDistance, object layerMask) { }

	// RVA: 0x7484958
	public static object CapsuleCastNonAlloc(object point1, object point2, object radius, object direction, object results, object maxDistance) { }

	// RVA: 0x7484A78
	public static object CapsuleCastNonAlloc(object point1, object point2, object radius, object direction, object results) { }

	// RVA: 0x7484B7C
	public static object SphereCastNonAlloc(object origin, object radius, object direction, object results, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7484ECC
	public static object SphereCastNonAlloc(object origin, object radius, object direction, object results, object maxDistance, object layerMask) { }

	// RVA: 0x7484F98
	public static object SphereCastNonAlloc(object origin, object radius, object direction, object results, object maxDistance) { }

	// RVA: 0x7485060
	public static object SphereCastNonAlloc(object origin, object radius, object direction, object results) { }

	// RVA: 0x7485128
	public static object SphereCastNonAlloc(object ray, object radius, object results, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74851F8
	public static object SphereCastNonAlloc(object ray, object radius, object results, object maxDistance, object layerMask) { }

	// RVA: 0x7485328
	public static object SphereCastNonAlloc(object ray, object radius, object results, object maxDistance) { }

	// RVA: 0x748544C
	public static object SphereCastNonAlloc(object ray, object radius, object results) { }

	// RVA: 0x7485570
	private static object CheckCapsule_Internal(object physicsScene, object start, object end, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74856EC
	public static object CheckCapsule(object start, object end, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74858C4
	public static object CheckCapsule(object start, object end, object radius, object layerMask) { }

	// RVA: 0x7485980
	public static object CheckCapsule(object start, object end, object radius) { }

	// RVA: 0x7485A30
	private static object CheckBox_Internal(object physicsScene, object center, object halfExtents, object orientation, object layermask, object queryTriggerInteraction) { }

	// RVA: 0x7485BA8
	public static object CheckBox(object center, object halfExtents, object orientation, object layermask, object queryTriggerInteraction) { }

	// RVA: 0x7485D94
	public static object CheckBox(object center, object halfExtents, object orientation, object layerMask) { }

	// RVA: 0x7485EA0
	public static object CheckBox(object center, object halfExtents, object orientation) { }

	// RVA: 0x7485FA0
	public static object CheckBox(object center, object halfExtents) { }

	// RVA: 0x7486094
	private static object OverlapBox_Internal(object physicsScene, object center, object halfExtents, object orientation, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x748620C
	public static object OverlapBox(object center, object halfExtents, object orientation, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74863F8
	public static object OverlapBox(object center, object halfExtents, object orientation, object layerMask) { }

	// RVA: 0x7486504
	public static object OverlapBox(object center, object halfExtents, object orientation) { }

	// RVA: 0x7486604
	public static object OverlapBox(object center, object halfExtents) { }

	// RVA: 0x74866F8
	public static object OverlapBoxNonAlloc(object center, object halfExtents, object results, object orientation, object mask, object queryTriggerInteraction) { }

	// RVA: 0x748693C
	public static object OverlapBoxNonAlloc(object center, object halfExtents, object results, object orientation, object mask) { }

	// RVA: 0x7486A50
	public static object OverlapBoxNonAlloc(object center, object halfExtents, object results, object orientation) { }

	// RVA: 0x7486B60
	public static object OverlapBoxNonAlloc(object center, object halfExtents, object results) { }

	// RVA: 0x7486C5C
	public static object BoxCastNonAlloc(object center, object halfExtents, object direction, object results, object orientation, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7486F38
	public static object BoxCastNonAlloc(object center, object halfExtents, object direction, object results, object orientation) { }

	// RVA: 0x7487044
	public static object BoxCastNonAlloc(object center, object halfExtents, object direction, object results, object orientation, object maxDistance) { }

	// RVA: 0x7487178
	public static object BoxCastNonAlloc(object center, object halfExtents, object direction, object results, object orientation, object maxDistance, object layerMask) { }

	// RVA: 0x74872B0
	public static object BoxCastNonAlloc(object center, object halfExtents, object direction, object results) { }

	// RVA: 0x74873BC
	private static object Internal_BoxCastAll(object physicsScene, object center, object halfExtents, object direction, object orientation, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x748755C
	public static object BoxCastAll(object center, object halfExtents, object direction, object orientation, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7487850
	public static object BoxCastAll(object center, object halfExtents, object direction, object orientation, object maxDistance, object layerMask) { }

	// RVA: 0x7487980
	public static object BoxCastAll(object center, object halfExtents, object direction, object orientation, object maxDistance) { }

	// RVA: 0x7487AA4
	public static object BoxCastAll(object center, object halfExtents, object direction, object orientation) { }

	// RVA: 0x7487BA0
	public static object BoxCastAll(object center, object halfExtents, object direction) { }

	// RVA: 0x7487CA4
	public static object OverlapCapsuleNonAlloc(object point0, object point1, object radius, object results, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7487ED8
	public static object OverlapCapsuleNonAlloc(object point0, object point1, object radius, object results, object layerMask) { }

	// RVA: 0x7487F9C
	public static object OverlapCapsuleNonAlloc(object point0, object point1, object radius, object results) { }

	// RVA: 0x748805C
	private static object Internal_RebuildBroadphaseRegions(object bounds, object subdivisions) { }

	// RVA: 0x7488178
	public static object RebuildBroadphaseRegions(object worldBounds, object subdivisions) { }

	// RVA: 0x7488310
	public static object BakeMesh(object meshID, object convex, object cookingOptions) { }

	// RVA: 0x748837C
	public static object BakeMesh(object meshID, object convex) { }

	// RVA: 0x7488424
	internal static object ResolveShapeToCollider(object shapePtr) { }

	// RVA: 0x7488474
	internal static object ResolveActorToComponent(object actorPtr) { }

	// RVA: 0x74884C4
	internal static object ResolveShapeToInstanceID(object shapePtr) { }

	// RVA: 0x7488514
	internal static object ResolveActorToInstanceID(object actorPtr) { }

	// RVA: 0x7488564
	internal static object GetColliderByInstanceID(object instanceID) { }

	// RVA: 0x74885B4
	internal static object GetBodyByInstanceID(object instanceID) { }

	// RVA: 0x7488604
	internal static object TranslateTriangleIndex(object shapePtr, object rawIndex) { }

	// RVA: 0x7488668
	internal static object TranslateTriangleIndexFromID(object instanceID, object faceIndex) { }

	// RVA: 0x74886CC
	internal static object IsShapeTrigger(object shapePtr) { }

	// RVA: 0x748871C
	private static object SendOnCollisionEnter(object component, object collision) { }

	// RVA: 0x7488780
	private static object SendOnCollisionStay(object component, object collision) { }

	// RVA: 0x74887E4
	private static object SendOnCollisionExit(object component, object collision) { }

	// RVA: 0x7488848
	internal static object GetActorLinearVelocity(object actorPtr) { }

	// RVA: 0x7488970
	internal static object GetActorAngularVelocity(object actorPtr) { }

	// RVA: 0x7488A98
	public static object get_minPenetrationForPenalty() { }

	// RVA: 0x7488AA0
	public static object set_minPenetrationForPenalty(object value) { }

	// RVA: 0x7488AA4
	public static object get_bounceTreshold() { }

	// RVA: 0x7488B34
	public static object set_bounceTreshold(object value) { }

	// RVA: 0x7488BDC
	public static object get_sleepVelocity() { }

	// RVA: 0x7488BE4
	public static object set_sleepVelocity(object value) { }

	// RVA: 0x7488BE8
	public static object get_sleepAngularVelocity() { }

	// RVA: 0x7488BF0
	public static object set_sleepAngularVelocity(object value) { }

	// RVA: 0x7488BF4
	public static object get_maxAngularVelocity() { }

	// RVA: 0x7488BFC
	public static object set_maxAngularVelocity(object value) { }

	// RVA: 0x7488C00
	public static object get_solverIterationCount() { }

	// RVA: 0x7488C90
	public static object set_solverIterationCount(object value) { }

	// RVA: 0x7488D3C
	public static object get_solverVelocityIterationCount() { }

	// RVA: 0x7488DCC
	public static object set_solverVelocityIterationCount(object value) { }

	// RVA: 0x7488E78
	public static object get_penetrationPenaltyForce() { }

	// RVA: 0x7488E80
	public static object set_penetrationPenaltyForce(object value) { }

	// RVA: 0x7488E84
	public static object get_autoSimulation() { }

	// RVA: 0x7488F2C
	public static object set_autoSimulation(object value) { }

	// RVA: 0x7488FD0
	public static object add_ContactEvent(object value) { }

	// RVA: 0x74890C0
	public static object remove_ContactEvent(object value) { }

	// RVA: 0x74891B0
	private static object OnSceneContact(object scene, object buffer, object count) { }

	// RVA: 0x74895E0
	private static object ReportContacts(object array) { }

	// RVA: 0x7489D1C
	private static object GetCollisionToReport(object header, object pair, object flipped) { }

	// RVA: 0x7489F1C
	public object .ctor() { }

	// RVA: 0x7489F24
	private static object .cctor() { }

	// RVA: 0x747AC58
	private static object get_gravity_Injected(object ret) { }

	// RVA: 0x747AD60
	private static object set_gravity_Injected(object value) { }

	// RVA: 0x747B52C
	private static object get_defaultPhysicsScene_Injected(object ret) { }

	// RVA: 0x747FBD8
	private static object Internal_RaycastAll_Injected(object physicsScene, object ray, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x74812A4
	private static object Query_CapsuleCastAll_Injected(object physicsScene, object p0, object p1, object radius, object direction, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7481A0C
	private static object Query_SphereCastAll_Injected(object physicsScene, object origin, object radius, object direction, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7482494
	private static object OverlapCapsule_Internal_Injected(object physicsScene, object point0, object point1, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7482948
	private static object OverlapSphere_Internal_Injected(object physicsScene, object position, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7482D58
	private static object Simulate_Internal_Injected(object physicsScene, object step) { }

	// RVA: 0x748308C
	private static object InterpolateBodies_Internal_Injected(object physicsScene) { }

	// RVA: 0x7483190
	private static object ResetInterpolationPoses_Internal_Injected(object physicsScene) { }

	// RVA: 0x7483440
	private static object Query_ComputePenetration_Injected(object colliderA, object positionA, object rotationA, object colliderB, object positionB, object rotationB, object direction, object distance) { }

	// RVA: 0x748378C
	private static object Query_ClosestPoint_Injected(object collider, object position, object rotation, object point, object ret) { }

	// RVA: 0x7483BF0
	private static object get_clothGravity_Injected(object ret) { }

	// RVA: 0x7483CF8
	private static object set_clothGravity_Injected(object value) { }

	// RVA: 0x7484150
	private static object CheckSphere_Internal_Injected(object physicsScene, object position, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7485650
	private static object CheckCapsule_Internal_Injected(object physicsScene, object start, object end, object radius, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7485B0C
	private static object CheckBox_Internal_Injected(object physicsScene, object center, object halfExtents, object orientation, object layermask, object queryTriggerInteraction) { }

	// RVA: 0x7486170
	private static object OverlapBox_Internal_Injected(object physicsScene, object center, object halfExtents, object orientation, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74874C0
	private static object Internal_BoxCastAll_Injected(object physicsScene, object center, object halfExtents, object direction, object orientation, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7488114
	private static object Internal_RebuildBroadphaseRegions_Injected(object bounds, object subdivisions) { }

	// RVA: 0x748890C
	private static object GetActorLinearVelocity_Injected(object actorPtr, object ret) { }

	// RVA: 0x7488A34
	private static object GetActorAngularVelocity_Injected(object actorPtr, object ret) { }

}

// Namespace: UnityEngine
public struct ModifiableContactPair
{

	// Fields
	private object actor; // 0xFFFFFFFFFFFFFFF8
	private object otherActor; // 0x0
	private object shape; // 0x8
	private object otherShape; // 0x10
	public object rotation; // 0x18
	public object position; // 0x28
	public object otherRotation; // 0x34
	public object otherPosition; // 0x44
	private object numContacts; // 0x50
	private object contacts; // 0x58
}

// Namespace: UnityEngine
public class PhysicMaterial
{

	// Methods

	// RVA: 0x748A10C
	public object .ctor() { }

	// RVA: 0x748A1CC
	private static object Internal_CreateDynamicsMaterial(object mat, object name) { }

}

// Namespace: UnityEngine
public struct RaycastHit
{

	// Fields
	internal object m_Point; // 0xFFFFFFFFFFFFFFF8
	internal object m_Normal; // 0x4
	internal object m_FaceID; // 0x10
	internal object m_Distance; // 0x14
	internal object m_UV; // 0x18
	internal object m_Collider; // 0x20

	// Properties
	public object collider { get; }
	public object point { get; }
	public object normal { get; }
	public object distance { get; set; }
	public object transform { get; }
	public object rigidbody { get; }

	// Methods

	// RVA: 0x748A230
	public object get_collider() { }

	// RVA: 0x748A418
	public object get_point() { }

	// RVA: 0x748A430
	public object get_normal() { }

	// RVA: 0x748A448
	public object get_distance() { }

	// RVA: 0x748A458
	public object set_distance(object value) { }

	// RVA: 0x748A468
	public object get_transform() { }

	// RVA: 0x748A6EC
	public object get_rigidbody() { }

}

// Namespace: UnityEngine
public class Rigidbody
{

	// Properties
	public object velocity { get; set; }
	public object angularVelocity { get; set; }
	public object drag { get; set; }
	public object angularDrag { get; set; }
	public object mass { get; set; }
	public object useGravity { get; set; }
	public object maxDepenetrationVelocity { get; set; }
	public object isKinematic { get; set; }
	public object freezeRotation { get; set; }
	public object constraints { get; set; }
	public object collisionDetectionMode { get; set; }
	public object automaticCenterOfMass { get; set; }
	public object centerOfMass { get; set; }
	public object worldCenterOfMass { get; }
	public object automaticInertiaTensor { get; set; }
	public object inertiaTensorRotation { get; set; }
	public object inertiaTensor { get; set; }
	public object detectCollisions { get; set; }
	public object position { get; set; }
	public object rotation { get; set; }
	public object interpolation { get; set; }
	public object solverIterations { get; set; }
	public object sleepThreshold { get; set; }
	public object maxAngularVelocity { get; set; }
	public object maxLinearVelocity { get; set; }
	public object solverVelocityIterations { get; set; }
	public object excludeLayers { get; set; }
	public object includeLayers { get; set; }
	public object sleepVelocity { get; set; }
	public object sleepAngularVelocity { get; set; }
	public object useConeFriction { get; set; }
	public object solverIterationCount { get; set; }
	public object solverVelocityIterationCount { get; set; }

	// Methods

	// RVA: 0x748A9AC
	public object get_velocity() { }

	// RVA: 0x748AA74
	public object set_velocity(object value) { }

	// RVA: 0x748AB4C
	public object get_angularVelocity() { }

	// RVA: 0x748AC14
	public object set_angularVelocity(object value) { }

	// RVA: 0x748ACEC
	public object get_drag() { }

	// RVA: 0x748AD3C
	public object set_drag(object value) { }

	// RVA: 0x748ADA0
	public object get_angularDrag() { }

	// RVA: 0x748ADF0
	public object set_angularDrag(object value) { }

	// RVA: 0x748AE54
	public object get_mass() { }

	// RVA: 0x748AEA4
	public object set_mass(object value) { }

	// RVA: 0x748AF08
	public object SetDensity(object density) { }

	// RVA: 0x748AF6C
	public object get_useGravity() { }

	// RVA: 0x748AFBC
	public object set_useGravity(object value) { }

	// RVA: 0x748B020
	public object get_maxDepenetrationVelocity() { }

	// RVA: 0x748B070
	public object set_maxDepenetrationVelocity(object value) { }

	// RVA: 0x748B0D4
	public object get_isKinematic() { }

	// RVA: 0x748B124
	public object set_isKinematic(object value) { }

	// RVA: 0x748B188
	public object get_freezeRotation() { }

	// RVA: 0x748B1D8
	public object set_freezeRotation(object value) { }

	// RVA: 0x748B23C
	public object get_constraints() { }

	// RVA: 0x748B28C
	public object set_constraints(object value) { }

	// RVA: 0x748B2F0
	public object get_collisionDetectionMode() { }

	// RVA: 0x748B340
	public object set_collisionDetectionMode(object value) { }

	// RVA: 0x748B3A4
	public object get_automaticCenterOfMass() { }

	// RVA: 0x748B3F4
	public object set_automaticCenterOfMass(object value) { }

	// RVA: 0x748B458
	public object get_centerOfMass() { }

	// RVA: 0x748B520
	public object set_centerOfMass(object value) { }

	// RVA: 0x748B5F8
	public object get_worldCenterOfMass() { }

	// RVA: 0x748B6C0
	public object get_automaticInertiaTensor() { }

	// RVA: 0x748B710
	public object set_automaticInertiaTensor(object value) { }

	// RVA: 0x748B774
	public object get_inertiaTensorRotation() { }

	// RVA: 0x748B838
	public object set_inertiaTensorRotation(object value) { }

	// RVA: 0x748B910
	public object get_inertiaTensor() { }

	// RVA: 0x748B9D8
	public object set_inertiaTensor(object value) { }

	// RVA: 0x748BAB0
	public object get_detectCollisions() { }

	// RVA: 0x748BB00
	public object set_detectCollisions(object value) { }

	// RVA: 0x748BB64
	public object get_position() { }

	// RVA: 0x748BC2C
	public object set_position(object value) { }

	// RVA: 0x748BD04
	public object get_rotation() { }

	// RVA: 0x748BDC8
	public object set_rotation(object value) { }

	// RVA: 0x748BEA0
	public object get_interpolation() { }

	// RVA: 0x748BEF0
	public object set_interpolation(object value) { }

	// RVA: 0x748BF54
	public object get_solverIterations() { }

	// RVA: 0x748BFA4
	public object set_solverIterations(object value) { }

	// RVA: 0x748C008
	public object get_sleepThreshold() { }

	// RVA: 0x748C058
	public object set_sleepThreshold(object value) { }

	// RVA: 0x748C0BC
	public object get_maxAngularVelocity() { }

	// RVA: 0x748C10C
	public object set_maxAngularVelocity(object value) { }

	// RVA: 0x748C170
	public object get_maxLinearVelocity() { }

	// RVA: 0x748C1C0
	public object set_maxLinearVelocity(object value) { }

	// RVA: 0x748C224
	public object MovePosition(object position) { }

	// RVA: 0x748C2FC
	public object MoveRotation(object rot) { }

	// RVA: 0x748C3D4
	public object Move(object position, object rotation) { }

	// RVA: 0x748C4A8
	public object Sleep() { }

	// RVA: 0x748C4F8
	public object IsSleeping() { }

	// RVA: 0x748C548
	public object WakeUp() { }

	// RVA: 0x748C598
	public object ResetCenterOfMass() { }

	// RVA: 0x748C5E8
	public object ResetInertiaTensor() { }

	// RVA: 0x748C638
	public object GetRelativePointVelocity(object relativePoint) { }

	// RVA: 0x748C714
	public object GetPointVelocity(object worldPoint) { }

	// RVA: 0x748C7F0
	public object get_solverVelocityIterations() { }

	// RVA: 0x748C840
	public object set_solverVelocityIterations(object value) { }

	// RVA: 0x748C8A4
	public object get_excludeLayers() { }

	// RVA: 0x748C964
	public object set_excludeLayers(object value) { }

	// RVA: 0x748CA38
	public object get_includeLayers() { }

	// RVA: 0x748CAF8
	public object set_includeLayers(object value) { }

	// RVA: 0x748CBCC
	public object GetAccumulatedForce(object step) { }

	// RVA: 0x748CCB8
	public object GetAccumulatedForce() { }

	// RVA: 0x748CD30
	public object GetAccumulatedTorque(object step) { }

	// RVA: 0x748CE1C
	public object GetAccumulatedTorque() { }

	// RVA: 0x748CE94
	public object AddForce(object force, object mode) { }

	// RVA: 0x748CF6C
	public object AddForce(object force) { }

	// RVA: 0x748CFCC
	public object AddForce(object x, object y, object z, object mode) { }

	// RVA: 0x748D038
	public object AddForce(object x, object y, object z) { }

	// RVA: 0x748D098
	public object AddRelativeForce(object force, object mode) { }

	// RVA: 0x748D170
	public object AddRelativeForce(object force) { }

	// RVA: 0x748D1D0
	public object AddRelativeForce(object x, object y, object z, object mode) { }

	// RVA: 0x748D23C
	public object AddRelativeForce(object x, object y, object z) { }

	// RVA: 0x748D29C
	public object AddTorque(object torque, object mode) { }

	// RVA: 0x748D374
	public object AddTorque(object torque) { }

	// RVA: 0x748D3D4
	public object AddTorque(object x, object y, object z, object mode) { }

	// RVA: 0x748D440
	public object AddTorque(object x, object y, object z) { }

	// RVA: 0x748D4A0
	public object AddRelativeTorque(object torque, object mode) { }

	// RVA: 0x748D578
	public object AddRelativeTorque(object torque) { }

	// RVA: 0x748D5D8
	public object AddRelativeTorque(object x, object y, object z, object mode) { }

	// RVA: 0x748D644
	public object AddRelativeTorque(object x, object y, object z) { }

	// RVA: 0x748D6A4
	public object AddForceAtPosition(object force, object position, object mode) { }

	// RVA: 0x748D79C
	public object AddForceAtPosition(object force, object position) { }

	// RVA: 0x748D808
	public object AddExplosionForce(object explosionForce, object explosionPosition, object explosionRadius, object upwardsModifier, object mode) { }

	// RVA: 0x748D938
	public object AddExplosionForce(object explosionForce, object explosionPosition, object explosionRadius, object upwardsModifier) { }

	// RVA: 0x748D9C0
	public object AddExplosionForce(object explosionForce, object explosionPosition, object explosionRadius) { }

	// RVA: 0x748DA3C
	private object Internal_ClosestPointOnBounds(object point, object outPos, object distance) { }

	// RVA: 0x748DB30
	public object ClosestPointOnBounds(object position) { }

	// RVA: 0x748DC00
	private object SweepTest(object direction, object maxDistance, object queryTriggerInteraction, object hasHit) { }

	// RVA: 0x748DD4C
	public object SweepTest(object direction, object hitInfo, object maxDistance, object queryTriggerInteraction) { }

	// RVA: 0x748DEA4
	public object SweepTest(object direction, object hitInfo, object maxDistance) { }

	// RVA: 0x748DEAC
	public object SweepTest(object direction, object hitInfo) { }

	// RVA: 0x748DEBC
	private object Internal_SweepTestAll(object direction, object maxDistance, object queryTriggerInteraction) { }

	// RVA: 0x748DFB8
	public object SweepTestAll(object direction, object maxDistance, object queryTriggerInteraction) { }

	// RVA: 0x748E120
	public object SweepTestAll(object direction, object maxDistance) { }

	// RVA: 0x748E128
	public object SweepTestAll(object direction) { }

	// RVA: 0x748E138
	public object get_sleepVelocity() { }

	// RVA: 0x748E140
	public object set_sleepVelocity(object value) { }

	// RVA: 0x748E144
	public object get_sleepAngularVelocity() { }

	// RVA: 0x748E14C
	public object set_sleepAngularVelocity(object value) { }

	// RVA: 0x748E150
	public object SetMaxAngularVelocity(object a) { }

	// RVA: 0x748E1B4
	public object get_useConeFriction() { }

	// RVA: 0x748E1BC
	public object set_useConeFriction(object value) { }

	// RVA: 0x748E1C0
	public object get_solverIterationCount() { }

	// RVA: 0x748E210
	public object set_solverIterationCount(object value) { }

	// RVA: 0x748E274
	public object get_solverVelocityIterationCount() { }

	// RVA: 0x748E2C4
	public object set_solverVelocityIterationCount(object value) { }

	// RVA: 0x748E328
	public object .ctor() { }

	// RVA: 0x748AA10
	private object get_velocity_Injected(object ret) { }

	// RVA: 0x748AAE8
	private object set_velocity_Injected(object value) { }

	// RVA: 0x748ABB0
	private object get_angularVelocity_Injected(object ret) { }

	// RVA: 0x748AC88
	private object set_angularVelocity_Injected(object value) { }

	// RVA: 0x748B4BC
	private object get_centerOfMass_Injected(object ret) { }

	// RVA: 0x748B594
	private object set_centerOfMass_Injected(object value) { }

	// RVA: 0x748B65C
	private object get_worldCenterOfMass_Injected(object ret) { }

	// RVA: 0x748B7D4
	private object get_inertiaTensorRotation_Injected(object ret) { }

	// RVA: 0x748B8AC
	private object set_inertiaTensorRotation_Injected(object value) { }

	// RVA: 0x748B974
	private object get_inertiaTensor_Injected(object ret) { }

	// RVA: 0x748BA4C
	private object set_inertiaTensor_Injected(object value) { }

	// RVA: 0x748BBC8
	private object get_position_Injected(object ret) { }

	// RVA: 0x748BCA0
	private object set_position_Injected(object value) { }

	// RVA: 0x748BD64
	private object get_rotation_Injected(object ret) { }

	// RVA: 0x748BE3C
	private object set_rotation_Injected(object value) { }

	// RVA: 0x748C298
	private object MovePosition_Injected(object position) { }

	// RVA: 0x748C370
	private object MoveRotation_Injected(object rot) { }

	// RVA: 0x748C43C
	private object Move_Injected(object position, object rotation) { }

	// RVA: 0x748C6A8
	private object GetRelativePointVelocity_Injected(object relativePoint, object ret) { }

	// RVA: 0x748C784
	private object GetPointVelocity_Injected(object worldPoint, object ret) { }

	// RVA: 0x748C900
	private object get_excludeLayers_Injected(object ret) { }

	// RVA: 0x748C9D4
	private object set_excludeLayers_Injected(object value) { }

	// RVA: 0x748CA94
	private object get_includeLayers_Injected(object ret) { }

	// RVA: 0x748CB68
	private object set_includeLayers_Injected(object value) { }

	// RVA: 0x748CC40
	private object GetAccumulatedForce_Injected(object step, object ret) { }

	// RVA: 0x748CDA4
	private object GetAccumulatedTorque_Injected(object step, object ret) { }

	// RVA: 0x748CF00
	private object AddForce_Injected(object force, object mode) { }

	// RVA: 0x748D104
	private object AddRelativeForce_Injected(object force, object mode) { }

	// RVA: 0x748D308
	private object AddTorque_Injected(object torque, object mode) { }

	// RVA: 0x748D50C
	private object AddRelativeTorque_Injected(object torque, object mode) { }

	// RVA: 0x748D71C
	private object AddForceAtPosition_Injected(object force, object position, object mode) { }

	// RVA: 0x748D89C
	private object AddExplosionForce_Injected(object explosionForce, object explosionPosition, object explosionRadius, object upwardsModifier, object mode) { }

	// RVA: 0x748DAB0
	private object Internal_ClosestPointOnBounds_Injected(object point, object outPos, object distance) { }

	// RVA: 0x748DCB0
	private object SweepTest_Injected(object direction, object maxDistance, object queryTriggerInteraction, object hasHit, object ret) { }

	// RVA: 0x748DF38
	private object Internal_SweepTestAll_Injected(object direction, object maxDistance, object queryTriggerInteraction) { }

}

// Namespace: UnityEngine
public class Collider
{

	// Properties
	public object enabled { get; set; }
	public object attachedRigidbody { get; }
	public object attachedArticulationBody { get; }
	public object isTrigger { get; set; }
	public object contactOffset { get; set; }
	public object bounds { get; }
	public object hasModifiableContacts { get; set; }
	public object providesContacts { get; set; }
	public object layerOverridePriority { get; set; }
	public object excludeLayers { get; set; }
	public object includeLayers { get; set; }
	public object sharedMaterial { get; set; }
	public object material { get; set; }

	// Methods

	// RVA: 0x748E330
	public object get_enabled() { }

	// RVA: 0x748E380
	public object set_enabled(object value) { }

	// RVA: 0x748A954
	public object get_attachedRigidbody() { }

	// RVA: 0x748E3E4
	public object get_attachedArticulationBody() { }

	// RVA: 0x748E434
	public object get_isTrigger() { }

	// RVA: 0x748E484
	public object set_isTrigger(object value) { }

	// RVA: 0x748E4E8
	public object get_contactOffset() { }

	// RVA: 0x748E538
	public object set_contactOffset(object value) { }

	// RVA: 0x748E59C
	public object ClosestPoint(object position) { }

	// RVA: 0x748E678
	public object get_bounds() { }

	// RVA: 0x748E754
	public object get_hasModifiableContacts() { }

	// RVA: 0x748E7A4
	public object set_hasModifiableContacts(object value) { }

	// RVA: 0x748E808
	public object get_providesContacts() { }

	// RVA: 0x748E858
	public object set_providesContacts(object value) { }

	// RVA: 0x748E8BC
	public object get_layerOverridePriority() { }

	// RVA: 0x748E90C
	public object set_layerOverridePriority(object value) { }

	// RVA: 0x748E970
	public object get_excludeLayers() { }

	// RVA: 0x748EA30
	public object set_excludeLayers(object value) { }

	// RVA: 0x748EB04
	public object get_includeLayers() { }

	// RVA: 0x748EBC4
	public object set_includeLayers(object value) { }

	// RVA: 0x748EC98
	public object get_sharedMaterial() { }

	// RVA: 0x748ECE8
	public object set_sharedMaterial(object value) { }

	// RVA: 0x748ED4C
	public object get_material() { }

	// RVA: 0x748ED9C
	public object set_material(object value) { }

	// RVA: 0x748EE00
	private object Raycast(object ray, object maxDistance, object hasHit) { }

	// RVA: 0x748EF38
	public object Raycast(object ray, object hitInfo, object maxDistance) { }

	// RVA: 0x748EFF4
	private object Internal_ClosestPointOnBounds(object point, object outPos, object distance) { }

	// RVA: 0x748F0E8
	public object ClosestPointOnBounds(object position) { }

	// RVA: 0x748F1B8
	public object .ctor() { }

	// RVA: 0x748E60C
	private object ClosestPoint_Injected(object position, object ret) { }

	// RVA: 0x748E6F0
	private object get_bounds_Injected(object ret) { }

	// RVA: 0x748E9CC
	private object get_excludeLayers_Injected(object ret) { }

	// RVA: 0x748EAA0
	private object set_excludeLayers_Injected(object value) { }

	// RVA: 0x748EB60
	private object get_includeLayers_Injected(object ret) { }

	// RVA: 0x748EC34
	private object set_includeLayers_Injected(object value) { }

	// RVA: 0x748EEA4
	private object Raycast_Injected(object ray, object maxDistance, object hasHit, object ret) { }

	// RVA: 0x748F068
	private object Internal_ClosestPointOnBounds_Injected(object point, object outPos, object distance) { }

}

// Namespace: UnityEngine
public class CharacterController
{
}

// Namespace: UnityEngine
public class MeshCollider
{

	// Properties
	public object sharedMesh { get; }

	// Methods

	// RVA: 0x748F1C0
	public object get_sharedMesh() { }

}

// Namespace: UnityEngine
public class CapsuleCollider
{

	// Properties
	public object center { get; set; }
	public object radius { get; set; }
	public object height { get; set; }
	public object direction { get; set; }

	// Methods

	// RVA: 0x748F210
	public object get_center() { }

	// RVA: 0x748F2D8
	public object set_center(object value) { }

	// RVA: 0x748F3B0
	public object get_radius() { }

	// RVA: 0x748F400
	public object set_radius(object value) { }

	// RVA: 0x748F464
	public object get_height() { }

	// RVA: 0x748F4B4
	public object set_height(object value) { }

	// RVA: 0x748F518
	public object get_direction() { }

	// RVA: 0x748F568
	public object set_direction(object value) { }

	// RVA: 0x748F274
	private object get_center_Injected(object ret) { }

	// RVA: 0x748F34C
	private object set_center_Injected(object value) { }

}

// Namespace: UnityEngine
public class BoxCollider
{

	// Properties
	public object center { get; set; }
	public object size { get; set; }
	public object extents { get; set; }

	// Methods

	// RVA: 0x748F5CC
	public object get_center() { }

	// RVA: 0x748F694
	public object set_center(object value) { }

	// RVA: 0x748F76C
	public object get_size() { }

	// RVA: 0x748F834
	public object set_size(object value) { }

	// RVA: 0x748F90C
	public object get_extents() { }

	// RVA: 0x748F984
	public object set_extents(object value) { }

	// RVA: 0x748FA04
	public object .ctor() { }

	// RVA: 0x748F630
	private object get_center_Injected(object ret) { }

	// RVA: 0x748F708
	private object set_center_Injected(object value) { }

	// RVA: 0x748F7D0
	private object get_size_Injected(object ret) { }

	// RVA: 0x748F8A8
	private object set_size_Injected(object value) { }

}

// Namespace: UnityEngine
public class SphereCollider
{

	// Properties
	public object center { get; set; }
	public object radius { get; set; }

	// Methods

	// RVA: 0x748FA0C
	public object get_center() { }

	// RVA: 0x748FAD4
	public object set_center(object value) { }

	// RVA: 0x748FBAC
	public object get_radius() { }

	// RVA: 0x748FBFC
	public object set_radius(object value) { }

	// RVA: 0x748FA70
	private object get_center_Injected(object ret) { }

	// RVA: 0x748FB48
	private object set_center_Injected(object value) { }

}

// Namespace: UnityEngine
public class Joint
{

	// Methods

	// RVA: 0x748FC60
	public object .ctor() { }

}

// Namespace: UnityEngine
public class HingeJoint
{

	// Properties
	public object motor { get; set; }
	public object limits { get; set; }
	public object spring { get; set; }
	public object useMotor { get; set; }
	public object useLimits { get; set; }
	public object extendedLimits { get; set; }
	public object useSpring { get; set; }
	public object velocity { get; }
	public object angle { get; }
	public object useAcceleration { get; set; }

	// Methods

	// RVA: 0x748FC68
	public object get_motor() { }

	// RVA: 0x748FD30
	public object set_motor(object value) { }

	// RVA: 0x748FE08
	public object get_limits() { }

	// RVA: 0x748FEE8
	public object set_limits(object value) { }

	// RVA: 0x748FFB0
	public object get_spring() { }

	// RVA: 0x7490078
	public object set_spring(object value) { }

	// RVA: 0x7490150
	public object get_useMotor() { }

	// RVA: 0x74901A0
	public object set_useMotor(object value) { }

	// RVA: 0x7490204
	public object get_useLimits() { }

	// RVA: 0x7490254
	public object set_useLimits(object value) { }

	// RVA: 0x74902B8
	public object get_extendedLimits() { }

	// RVA: 0x7490308
	public object set_extendedLimits(object value) { }

	// RVA: 0x749036C
	public object get_useSpring() { }

	// RVA: 0x74903BC
	public object set_useSpring(object value) { }

	// RVA: 0x7490420
	public object get_velocity() { }

	// RVA: 0x7490470
	public object get_angle() { }

	// RVA: 0x74904C0
	public object get_useAcceleration() { }

	// RVA: 0x7490510
	public object set_useAcceleration(object value) { }

	// RVA: 0x7490574
	public object .ctor() { }

	// RVA: 0x748FCCC
	private object get_motor_Injected(object ret) { }

	// RVA: 0x748FDA4
	private object set_motor_Injected(object value) { }

	// RVA: 0x748FE84
	private object get_limits_Injected(object ret) { }

	// RVA: 0x748FF4C
	private object set_limits_Injected(object value) { }

	// RVA: 0x7490014
	private object get_spring_Injected(object ret) { }

	// RVA: 0x74900EC
	private object set_spring_Injected(object value) { }

}

// Namespace: UnityEngine
public struct ContactPoint
{

	// Fields
	internal object m_Point; // 0xFFFFFFFFFFFFFFF8
	internal object m_Normal; // 0x4
	internal object m_Impulse; // 0x10
	internal object m_ThisColliderInstanceID; // 0x1C
	internal object m_OtherColliderInstanceID; // 0x20
	internal object m_Separation; // 0x24
}

// Namespace: UnityEngine
public struct PhysicsScene
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x749057C
	public override object ToString() { }

	// RVA: 0x749067C
	public override object GetHashCode() { }

	// RVA: 0x749068C
	public override object Equals(object other) { }

	// RVA: 0x74907D4
	public object Equals(object other) { }

	// RVA: 0x747B9D8
	public object Raycast(object origin, object direction, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74907F4
	private static object Internal_RaycastTest(object physicsScene, object ray, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747C148
	public object Raycast(object origin, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x749090C
	private static object Internal_Raycast(object physicsScene, object ray, object maxDistance, object hit, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74805D4
	public object Raycast(object origin, object direction, object raycastHits, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7490A3C
	private static object Internal_RaycastNonAlloc(object physicsScene, object ray, object raycastHits, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7490B6C
	private static object Query_CapsuleCast(object physicsScene, object point1, object point2, object radius, object direction, object maxDistance, object hitInfo, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7490CBC
	private static object Internal_CapsuleCast(object physicsScene, object point1, object point2, object radius, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747D844
	public object CapsuleCast(object point1, object point2, object radius, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7490E48
	private static object Internal_CapsuleCastNonAlloc(object physicsScene, object p0, object p1, object radius, object direction, object raycastHits, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x74846D8
	public object CapsuleCast(object point1, object point2, object radius, object direction, object results, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74910F4
	private static object OverlapCapsuleNonAlloc_Internal(object physicsScene, object point0, object point1, object radius, object results, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7487E40
	public object OverlapCapsule(object point0, object point1, object radius, object results, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74912B4
	private static object Query_SphereCast(object physicsScene, object origin, object radius, object direction, object maxDistance, object hitInfo, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74913EC
	private static object Internal_SphereCast(object physicsScene, object origin, object radius, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747E270
	public object SphereCast(object origin, object radius, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x749169C
	private static object Internal_SphereCastNonAlloc(object physicsScene, object origin, object radius, object direction, object raycastHits, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7484D88
	public object SphereCast(object origin, object radius, object direction, object results, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491918
	private static object OverlapSphereNonAlloc_Internal(object physicsScene, object position, object radius, object results, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7483EBC
	public object OverlapSphere(object position, object radius, object results, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491AC8
	private static object Query_BoxCast(object physicsScene, object center, object halfExtents, object direction, object orientation, object maxDistance, object outHit, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491C28
	private static object Internal_BoxCast(object physicsScene, object center, object halfExtents, object orientation, object direction, object hitInfo, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x747F094
	public object BoxCast(object center, object halfExtents, object direction, object hitInfo, object orientation, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491DD4
	private static object OverlapBoxNonAlloc_Internal(object physicsScene, object center, object halfExtents, object results, object orientation, object mask, object queryTriggerInteraction) { }

	// RVA: 0x74868A8
	public object OverlapBox(object center, object halfExtents, object results, object orientation, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491F9C
	private static object Internal_BoxCastNonAlloc(object physicsScene, object center, object halfExtents, object direction, object raycastHits, object orientation, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7486DCC
	public object BoxCast(object center, object halfExtents, object direction, object results, object orientation, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7490878
	private static object Internal_RaycastTest_Injected(object physicsScene, object ray, object maxDistance, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x74909A0
	private static object Internal_Raycast_Injected(object physicsScene, object ray, object maxDistance, object hit, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7490AD0
	private static object Internal_RaycastNonAlloc_Injected(object physicsScene, object ray, object raycastHits, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7490C18
	private static object Query_CapsuleCast_Injected(object physicsScene, object point1, object point2, object radius, object direction, object maxDistance, object hitInfo, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7490EF4
	private static object Internal_CapsuleCastNonAlloc_Injected(object physicsScene, object p0, object p1, object radius, object direction, object raycastHits, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7491188
	private static object OverlapCapsuleNonAlloc_Internal_Injected(object physicsScene, object point0, object point1, object radius, object results, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491350
	private static object Query_SphereCast_Injected(object physicsScene, object origin, object radius, object direction, object maxDistance, object hitInfo, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491738
	private static object Internal_SphereCastNonAlloc_Injected(object physicsScene, object origin, object radius, object direction, object raycastHits, object maxDistance, object mask, object queryTriggerInteraction) { }

	// RVA: 0x74919A0
	private static object OverlapSphereNonAlloc_Internal_Injected(object physicsScene, object position, object radius, object results, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491B7C
	private static object Query_BoxCast_Injected(object physicsScene, object center, object halfExtents, object direction, object orientation, object maxDistance, object outHit, object layerMask, object queryTriggerInteraction) { }

	// RVA: 0x7491E64
	private static object OverlapBoxNonAlloc_Internal_Injected(object physicsScene, object center, object halfExtents, object results, object orientation, object mask, object queryTriggerInteraction) { }

	// RVA: 0x7492050
	private static object Internal_BoxCastNonAlloc_Injected(object physicsScene, object center, object halfExtents, object direction, object raycastHits, object orientation, object maxDistance, object mask, object queryTriggerInteraction) { }

}

// Namespace: UnityEngine
public enum SimulationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FixedUpdate;
	public const object Update;
	public const object Script;
}

// Namespace: UnityEngine
public struct ContactPairHeader
{

	// Fields
	internal readonly object m_BodyID; // 0xFFFFFFFFFFFFFFF8
	internal readonly object m_OtherBodyID; // 0xFFFFFFFFFFFFFFFC
	internal readonly object m_StartPtr; // 0x0
	internal readonly object m_NbPairs; // 0x8
	internal readonly object m_Flags; // 0xC
	internal readonly object m_RelativeVelocity; // 0x10

	// Properties
	public object Body { get; }
	public object OtherBody { get; }
	internal object HasRemovedBody { get; }

	// Methods

	// RVA: 0x747A0A8
	public object get_Body() { }

	// RVA: 0x7479FF4
	public object get_OtherBody() { }

	// RVA: 0x7489CEC
	internal object get_HasRemovedBody() { }

	// RVA: 0x7489CFC
	public object GetContactPair(object index) { }

	// RVA: 0x749229C
	internal object GetContactPair_Internal(object index) { }

}

// Namespace: UnityEngine
public struct ContactPair
{

	// Fields
	private const object c_InvalidFaceIndex;
	internal readonly object m_ColliderID; // 0xFFFFFFFFFFFFFFF8
	internal readonly object m_OtherColliderID; // 0xFFFFFFFFFFFFFFFC
	internal readonly object m_StartPtr; // 0x0
	internal readonly object m_NbPoints; // 0x8
	internal readonly object m_Flags; // 0xC
	internal readonly object m_Events; // 0xE
	internal readonly object m_ImpulseSum; // 0x10

	// Properties
	public object Collider { get; }
	public object OtherCollider { get; }
	public object IsCollisionEnter { get; }
	public object IsCollisionExit { get; }
	public object IsCollisionStay { get; }
	internal object HasRemovedCollider { get; }

	// Methods

	// RVA: 0x747A2E4
	public object get_Collider() { }

	// RVA: 0x747A238
	public object get_OtherCollider() { }

	// RVA: 0x7489D10
	public object get_IsCollisionEnter() { }

	// RVA: 0x7489F10
	public object get_IsCollisionExit() { }

	// RVA: 0x7489F04
	public object get_IsCollisionStay() { }

	// RVA: 0x7489D00
	internal object get_HasRemovedCollider() { }

	// RVA: 0x747A594
	internal object ExtractContactsArray(object managedContainer, object flipped) { }

	// RVA: 0x74924C4
	private static object ExtractContactsArray_Injected(object _unity_self, object managedContainer, object flipped) { }

}

// Namespace: UnityEngine
internal enum CollisionPairHeaderFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RemovedActor;
	public const object RemovedOtherActor;
}

// Namespace: UnityEngine
internal enum CollisionPairFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object RemovedShape;
	public const object RemovedOtherShape;
	public const object ActorPairHasFirstTouch;
	public const object ActorPairLostTouch;
	public const object InternalHasImpulses;
	public const object InternalContactsAreFlipped;
}

// Namespace: UnityEngine
internal enum CollisionPairEventFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SolveContacts;
	public const object ModifyContacts;
	public const object NotifyTouchFound;
	public const object NotifyTouchPersists;
	public const object NotifyTouchLost;
	public const object NotifyTouchCCD;
	public const object NotifyThresholdForceFound;
	public const object NotifyThresholdForcePersists;
	public const object NotifyThresholdForceLost;
	public const object NotifyContactPoint;
	public const object DetectDiscreteContact;
	public const object DetectCCDContact;
	public const object PreSolverVelocity;
	public const object PostSolverVelocity;
	public const object ContactEventPose;
	public const object NextFree;
	public const object ContactDefault;
	public const object TriggerDefault;
}

