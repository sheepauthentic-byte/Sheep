// Namespace: 
internal class <Module>
{
}

// Namespace: Google.Protobuf
internal static class ByteArray
{

	// Methods

	// RVA: 0x361997C
	internal static object Copy(object src, object srcOffset, object dst, object dstOffset, object count) { }

}

// Namespace: Google.Protobuf
public sealed class ByteString
{

	// Fields
	private static readonly object empty; // 0x0
	private readonly object bytes; // 0x8

	// Properties
	public static object Empty { get; }
	public object Length { get; }
	public object IsEmpty { get; }

	// Methods

	// RVA: 0x3619A24
	internal static object AttachBytes(object bytes) { }

	// RVA: 0x3619A8C
	private object .ctor(object bytes) { }

	// RVA: 0x3619AB8
	public static object get_Empty() { }

	// RVA: 0x3619B34
	public object get_Length() { }

	// RVA: 0x3619B58
	public object get_IsEmpty() { }

	// RVA: 0x3619B84
	public object ToByteArray() { }

	// RVA: 0x3619C08
	public object ToBase64() { }

	// RVA: 0x3619C98
	public static object CopyFrom(object bytes) { }

	// RVA: 0x3619D68
	public static object CopyFrom(object bytes, object offset, object count) { }

	// RVA: 0x3619E1C
	public object GetEnumerator() { }

	// RVA: 0x3619EFC
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x3619F00
	public object CreateCodedInput() { }

	// RVA: 0x361A0D0
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x361A178
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x361A284
	public override object Equals(object obj) { }

	// RVA: 0x361A3C4
	public override object GetHashCode() { }

	// RVA: 0x361A420
	public object Equals(object other) { }

	// RVA: 0x361A544
	internal object WriteRawBytesTo(object outputStream) { }

	// RVA: 0x361A6A4
	private static object .cctor() { }

}

// Namespace: Google.Protobuf
public sealed class CodedInputStream
{

	// Fields
	private static object encoding; // 0x0
	private readonly object leaveOpen; // 0x8
	private readonly object buffer; // 0x10
	private object bufferSize; // 0x18
	private object bufferSizeAfterLimit; // 0x1C
	private object bufferPos; // 0x20
	private object input; // 0x28
	private object lastTag; // 0x30
	private object nextTag; // 0x34
	private object hasNextTag; // 0x38
	private object totalBytesRetired; // 0x3C
	private object currentLimit; // 0x40
	private object recursionDepth; // 0x44
	private readonly object recursionLimit; // 0x48
	private readonly object sizeLimit; // 0x4C
	private object <DiscardUnknownFields>k__BackingField; // 0x50

	// Properties
	public object Position { get; }
	internal object LastTag { get; }
	internal object DiscardUnknownFields { get; set; }
	internal object ReachedLimit { get; }
	public object IsAtEnd { get; }

	// Methods

	// RVA: 0x361A734
	public static object SetEncoding(object e) { }

	// RVA: 0x361A004
	public object .ctor(object buffer) { }

	// RVA: 0x361A830
	public object .ctor(object input) { }

	// RVA: 0x361A8C4
	public object .ctor(object input, object leaveOpen) { }

	// RVA: 0x361A7C0
	internal object .ctor(object input, object buffer, object bufferPos, object bufferSize, object leaveOpen) { }

	// RVA: 0x361A964
	public object get_Position() { }

	// RVA: 0x361A9D4
	public object Reset() { }

	// RVA: 0x361AA30
	public object Reset(object inStream) { }

	// RVA: 0x361AA90
	internal object get_LastTag() { }

	// RVA: 0x361AA98
	internal object get_DiscardUnknownFields() { }

	// RVA: 0x361AAA0
	internal object set_DiscardUnknownFields(object value) { }

	// RVA: 0x361AAA8
	public object Dispose() { }

	// RVA: 0x361AAD8
	internal object CheckReadEndOfStreamTag() { }

	// RVA: 0x361AB88
	public object PeekTag() { }

	// RVA: 0x361ABCC
	public object ReadTag() { }

	// RVA: 0x361B0A0
	public object SkipLastField() { }

	// RVA: 0x361B1D8
	internal object SkipGroup(object startGroupTag) { }

	// RVA: 0x361B4D4
	public object ReadDouble() { }

	// RVA: 0x361B7A0
	public object ReadFloat() { }

	// RVA: 0x361B91C
	public object ReadUInt64() { }

	// RVA: 0x361BD20
	public object ReadInt64() { }

	// RVA: 0x361BD24
	public object ReadInt32() { }

	// RVA: 0x361B324
	public object ReadFixed64() { }

	// RVA: 0x361B320
	public object ReadFixed32() { }

	// RVA: 0x361BD28
	public object ReadBool() { }

	// RVA: 0x361BD44
	public object ReadString() { }

	// RVA: 0x361C44C
	public object ReadMessage(object builder) { }

	// RVA: 0x361C6EC
	public object ReadBytes() { }

	// RVA: 0x361C8A4
	public object ReadUInt32() { }

	// RVA: 0x361C8A8
	public object ReadEnum() { }

	// RVA: 0x361C8AC
	public object ReadSFixed32() { }

	// RVA: 0x361C8B0
	public object ReadSFixed64() { }

	// RVA: 0x361B328
	public object ReadLength() { }

	// RVA: 0x361C8B4
	public object MaybeConsumeTag(object tag) { }

	// RVA: 0x361C924
	private object SlowReadRawVarint32() { }

	// RVA: 0x361ACF0
	internal object ReadRawVarint32() { }

	// RVA: 0x361B920
	internal object ReadRawVarint64() { }

	// RVA: 0x361B7B8
	internal object ReadRawLittleEndian32() { }

	// RVA: 0x361B4EC
	internal object ReadRawLittleEndian64() { }

	// RVA: 0x361C608
	internal object PushLimit(object byteLimit) { }

	// RVA: 0x361CE98
	private object RecomputeBufferSizeAfterLimit() { }

	// RVA: 0x361C6B8
	internal object PopLimit(object oldLimit) { }

	// RVA: 0x361C688
	internal object get_ReachedLimit() { }

	// RVA: 0x361AFEC
	public object get_IsAtEnd() { }

	// RVA: 0x361CEC8
	private object RefillBuffer(object mustSucceed) { }

	// RVA: 0x361CD38
	internal object ReadRawByte() { }

	// RVA: 0x361BED4
	internal object ReadRawBytes(object size) { }

	// RVA: 0x361B32C
	private object SkipRawBytes(object size) { }

	// RVA: 0x361D158
	private object SkipImpl(object amountToSkip) { }

	// RVA: 0x361D3DC
	private static object .cctor() { }

}

// Namespace: 
public sealed class OutOfSpaceException
{

	// Methods

	// RVA: 0x361F2E4
	internal object .ctor() { }

}

// Namespace: Google.Protobuf
public sealed class CodedOutputStream
{

	// Fields
	private static object encoding; // 0x0
	public static readonly object DefaultBufferSize; // 0x8
	private readonly object leaveOpen; // 0x8
	private readonly object buffer; // 0x10
	private readonly object limit; // 0x18
	private object position; // 0x1C
	private readonly object output; // 0x20

	// Properties
	public object Position { get; }
	public object SpaceLeft { get; }

	// Methods

	// RVA: 0x361D430
	public static object ComputeUInt64Size(object value) { }

	// RVA: 0x361D61C
	public static object ComputeInt64Size(object value) { }

	// RVA: 0x361D778
	public static object ComputeInt32Size(object value) { }

	// RVA: 0x361D84C
	public static object ComputeFixed64Size(object value) { }

	// RVA: 0x361D854
	public static object ComputeFixed32Size(object value) { }

	// RVA: 0x361D85C
	public static object ComputeBoolSize(object value) { }

	// RVA: 0x361D864
	public static object ComputeStringSize(object value) { }

	// RVA: 0x361DA18
	public static object ComputeMessageSize(object value) { }

	// RVA: 0x361DB94
	public static object ComputeBytesSize(object value) { }

	// RVA: 0x361DC9C
	public static object ComputeUInt32Size(object value) { }

	// RVA: 0x361DD2C
	public static object ComputeEnumSize(object value) { }

	// RVA: 0x361D988
	public static object ComputeLengthSize(object length) { }

	// RVA: 0x361D814
	public static object ComputeRawVarint32Size(object value) { }

	// RVA: 0x361D58C
	public static object ComputeRawVarint64Size(object value) { }

	// RVA: 0x361DE20
	public static object ComputeTagSize(object fieldNumber) { }

	// RVA: 0x361DEBC
	public static object SetEncoding(object e) { }

	// RVA: 0x361DF48
	public object .ctor(object flatArray) { }

	// RVA: 0x361DFA0
	private object .ctor(object buffer, object offset, object length) { }

	// RVA: 0x361DFF0
	private object .ctor(object output, object buffer, object leaveOpen) { }

	// RVA: 0x361E0B0
	public object .ctor(object output) { }

	// RVA: 0x361E128
	public object .ctor(object output, object bufferSize, object leaveOpen) { }

	// RVA: 0x361E220
	public object get_Position() { }

	// RVA: 0x361E284
	public object Reset() { }

	// RVA: 0x361E2D8
	public object WriteDouble(object value) { }

	// RVA: 0x361E6BC
	public object WriteFloat(object value) { }

	// RVA: 0x361E8C0
	public object WriteUInt64(object value) { }

	// RVA: 0x361EA1C
	public object WriteInt64(object value) { }

	// RVA: 0x361EA20
	public object WriteInt32(object value) { }

	// RVA: 0x361EBB0
	public object WriteFixed64(object value) { }

	// RVA: 0x361EBB4
	public object WriteFixed32(object value) { }

	// RVA: 0x361EBB8
	public object WriteBool(object value) { }

	// RVA: 0x361ECA0
	public object WriteString(object value) { }

	// RVA: 0x361EF40
	public object WriteMessage(object value) { }

	// RVA: 0x361F09C
	public object WriteBytes(object value) { }

	// RVA: 0x361F100
	public object WriteUInt32(object value) { }

	// RVA: 0x361F104
	public object WriteEnum(object value) { }

	// RVA: 0x361F114
	public object WriteSFixed32(object value) { }

	// RVA: 0x361F118
	public object WriteSFixed64(object value) { }

	// RVA: 0x361EF18
	public object WriteLength(object length) { }

	// RVA: 0x361F11C
	public object WriteTag(object fieldNumber, object type) { }

	// RVA: 0x361F124
	public object WriteTag(object tag) { }

	// RVA: 0x361F128
	public object WriteRawTag(object b1) { }

	// RVA: 0x361F194
	public object WriteRawTag(object b1, object b2) { }

	// RVA: 0x361EA30
	internal object WriteRawVarint32(object value) { }

	// RVA: 0x361E8C4
	internal object WriteRawVarint64(object value) { }

	// RVA: 0x361E6C4
	internal object WriteRawLittleEndian32(object value) { }

	// RVA: 0x361E2E0
	internal object WriteRawLittleEndian64(object value) { }

	// RVA: 0x361EC34
	internal object WriteRawByte(object value) { }

	// RVA: 0x361EF1C
	internal object WriteRawBytes(object value) { }

	// RVA: 0x361A588
	internal object WriteRawBytes(object value, object offset, object length) { }

	// RVA: 0x361F248
	private object RefreshBuffer() { }

	// RVA: 0x361F340
	public object Dispose() { }

	// RVA: 0x361F398
	public object Flush() { }

	// RVA: 0x361F3A8
	public object CheckNoSpaceLeft() { }

	// RVA: 0x361F464
	public object get_SpaceLeft() { }

	// RVA: 0x361F4CC
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__2_0; // 0x18
	public static object <>9__2_1; // 0x20
	public static object <>9__3_0; // 0x28
	public static object <>9__3_1; // 0x30
	public static object <>9__5_0; // 0x38
	public static object <>9__5_1; // 0x40
	public static object <>9__6_0; // 0x48
	public static object <>9__6_1; // 0x50
	public static object <>9__7_0; // 0x58
	public static object <>9__7_1; // 0x60
	public static object <>9__10_0; // 0x68
	public static object <>9__10_1; // 0x70

	// Methods

	// RVA: 0x362035C
	private static object .cctor() { }

	// RVA: 0x36203BC
	public object .ctor() { }

	// RVA: 0x36203C4
	internal object <ForString>b__0_0(object input) { }

	// RVA: 0x36203E4
	internal object <ForString>b__0_1(object output, object value) { }

	// RVA: 0x3620408
	internal object <ForBool>b__2_0(object input) { }

	// RVA: 0x3620438
	internal object <ForBool>b__2_1(object output, object value) { }

	// RVA: 0x36204B4
	internal object <ForInt32>b__3_0(object input) { }

	// RVA: 0x36204D4
	internal object <ForInt32>b__3_1(object output, object value) { }

	// RVA: 0x362050C
	internal object <ForFixed32>b__5_0(object input) { }

	// RVA: 0x362052C
	internal object <ForFixed32>b__5_1(object output, object value) { }

	// RVA: 0x3620550
	internal object <ForSFixed32>b__6_0(object input) { }

	// RVA: 0x3620570
	internal object <ForSFixed32>b__6_1(object output, object value) { }

	// RVA: 0x3620594
	internal object <ForUInt32>b__7_0(object input) { }

	// RVA: 0x36205B4
	internal object <ForUInt32>b__7_1(object output, object value) { }

	// RVA: 0x36205D8
	internal object <ForFixed64>b__10_0(object input) { }

	// RVA: 0x36205F8
	internal object <ForFixed64>b__10_1(object output, object value) { }

}

// Namespace: 
private sealed class <>c__DisplayClass16_0<T0>
{

	// Fields
	public object parser; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <ForMessage>b__0(object input) { }

}

// Namespace: 
private sealed class <>c__16<T0>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__16_1; // 0x0
	public static object <>9__16_2; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <ForMessage>b__16_1(object output, object value) { }

	// RVA: -1
	internal object <ForMessage>b__16_2(object message) { }

}

// Namespace: Google.Protobuf
public static class FieldCodec
{

	// Methods

	// RVA: 0x361F528
	public static object ForString(object tag) { }

	// RVA: 0x361F750
	public static object ForBool(object tag) { }

	// RVA: 0x361F978
	public static object ForInt32(object tag) { }

	// RVA: 0x361FBA0
	public static object ForFixed32(object tag) { }

	// RVA: 0x361FD7C
	public static object ForSFixed32(object tag) { }

	// RVA: 0x361FF58
	public static object ForUInt32(object tag) { }

	// RVA: 0x3620180
	public static object ForFixed64(object tag) { }

	// RVA: -1
	public static object ForMessage(object tag, object parser) { }

}

// Namespace: 
private sealed class <>c__DisplayClass27_0
{

	// Fields
	public object fixedSize; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.ctor>b__0(object _) { }

}

// Namespace: Google.Protobuf
public sealed class FieldCodec<T0>
{

	// Fields
	private static readonly object EqualityComparer; // 0x0
	private static readonly object DefaultDefault; // 0x0
	private static readonly object TypeSupportsPacking; // 0x0
	private readonly object <PackedRepeatedField>k__BackingField; // 0x0
	private readonly object <ValueWriter>k__BackingField; // 0x0
	private readonly object <ValueSizeCalculator>k__BackingField; // 0x0
	private readonly object <ValueReader>k__BackingField; // 0x0
	private readonly object <FixedSize>k__BackingField; // 0x0
	private readonly object <Tag>k__BackingField; // 0x0
	private readonly object <DefaultValue>k__BackingField; // 0x0
	private readonly object tagSize; // 0x0

	// Properties
	internal object PackedRepeatedField { get; }
	internal object ValueWriter { get; }
	internal object ValueSizeCalculator { get; }
	internal object ValueReader { get; }
	internal object FixedSize { get; }
	internal object Tag { get; }
	internal object DefaultValue { get; }

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	internal static object IsPackedRepeatedField(object tag) { }

	// RVA: -1
	internal object get_PackedRepeatedField() { }

	// RVA: -1
	internal object get_ValueWriter() { }

	// RVA: -1
	internal object get_ValueSizeCalculator() { }

	// RVA: -1
	internal object get_ValueReader() { }

	// RVA: -1
	internal object get_FixedSize() { }

	// RVA: -1
	internal object get_Tag() { }

	// RVA: -1
	internal object get_DefaultValue() { }

	// RVA: -1
	internal object .ctor(object reader, object writer, object fixedSize, object tag) { }

	// RVA: -1
	internal object .ctor(object reader, object writer, object sizeCalculator, object tag) { }

	// RVA: -1
	internal object .ctor(object reader, object writer, object sizeCalculator, object tag, object defaultValue) { }

	// RVA: -1
	public object WriteTagAndValue(object output, object value) { }

	// RVA: -1
	public object Read(object input) { }

	// RVA: -1
	public object CalculateSizeWithTag(object value) { }

	// RVA: -1
	private object IsDefault(object value) { }

}

// Namespace: Google.Protobuf
internal static class FrameworkPortability
{

	// Fields
	internal static readonly object CompiledRegexWhereAvailable; // 0x0

	// Methods

	// RVA: 0x362061C
	private static object .cctor() { }

}

// Namespace: Google.Protobuf
public interface ICustomDiagnosticMessage
{

	// Methods

	// RVA: -1
	public abstract object ToDiagnosticString() { }

}

// Namespace: Google.Protobuf
public interface IMessage
{

	// Properties
	public abstract object Descriptor { get; }

	// Methods

	// RVA: -1
	public abstract object MergeFrom(object input) { }

	// RVA: -1
	public abstract object WriteTo(object output) { }

	// RVA: -1
	public abstract object CalculateSize() { }

	// RVA: -1
	public abstract object get_Descriptor() { }

}

// Namespace: Google.Protobuf
public sealed class InvalidProtocolBufferException
{

	// Methods

	// RVA: 0x361B318
	internal object .ctor(object message) { }

	// RVA: 0x361AB10
	internal static object MoreDataAvailable() { }

	// RVA: 0x361B45C
	internal static object TruncatedMessage() { }

	// RVA: 0x361CE20
	internal static object NegativeSize() { }

	// RVA: 0x361CDA8
	internal static object MalformedVarint() { }

	// RVA: 0x361B028
	internal static object InvalidTag() { }

	// RVA: 0x361B3E4
	internal static object RecursionLimitExceeded() { }

	// RVA: 0x361D0A0
	internal static object SizeLimitExceeded() { }

}

// Namespace: 
public sealed class Settings
{

	// Fields
	private static readonly object <Default>k__BackingField; // 0x0
	private readonly object <FormatDefaultValues>k__BackingField; // 0x8
	private readonly object <TypeRegistry>k__BackingField; // 0x10
	private readonly object <FormatEnumsAsIntegers>k__BackingField; // 0x18

	// Properties
	public static object Default { get; }
	public object TypeRegistry { get; }
	public object FormatEnumsAsIntegers { get; }

	// Methods

	// RVA: 0x362905C
	public static object get_Default() { }

	// RVA: 0x36290D8
	private static object .cctor() { }

	// RVA: 0x36292C8
	public object get_TypeRegistry() { }

	// RVA: 0x36292D0
	public object get_FormatEnumsAsIntegers() { }

	// RVA: 0x3629138
	public object .ctor(object formatDefaultValues) { }

	// RVA: 0x36292D8
	public object .ctor(object formatDefaultValues, object typeRegistry) { }

	// RVA: 0x36293DC
	private object .ctor(object formatDefaultValues, object typeRegistry, object formatEnumsAsIntegers) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__2_0; // 0x8
	public static object <>9__2_1; // 0x10
	public static object <>9__2_2; // 0x18
	public static object <>9__2_3; // 0x20

	// Methods

	// RVA: 0x36298BC
	private static object .cctor() { }

	// RVA: 0x362991C
	public object .ctor() { }

	// RVA: 0x3629924
	internal object <GetNameMapping>b__2_0(object f) { }

	// RVA: 0x3629948
	internal object <GetNameMapping>b__2_1(object f) { }

	// RVA: 0x36299E0
	internal object <GetNameMapping>b__2_2(object f) { }

	// RVA: 0x3629A34
	internal object <GetNameMapping>b__2_3(object f) { }

}

// Namespace: 
private static class OriginalEnumValueHelper
{

	// Fields
	private static readonly object dictionaries; // 0x0

	// Methods

	// RVA: 0x3624CCC
	internal static object GetOriginalName(object value) { }

	// RVA: 0x36294C0
	private static object GetNameMapping(object enumType) { }

	// RVA: 0x362982C
	private static object .cctor() { }

}

// Namespace: Google.Protobuf
public sealed class JsonFormatter
{

	// Fields
	private static readonly object <Default>k__BackingField; // 0x0
	private static readonly object diagnosticFormatter; // 0x8
	private static readonly object CommonRepresentations; // 0x10
	private readonly object settings; // 0x8

	// Properties
	public static object Default { get; }
	private object DiagnosticOnly { get; }

	// Methods

	// RVA: 0x3620734
	public static object get_Default() { }

	// RVA: 0x36207B0
	private static object .cctor() { }

	// RVA: 0x3621904
	private object get_DiagnosticOnly() { }

	// RVA: 0x36218D8
	public object .ctor(object settings) { }

	// RVA: 0x3621974
	public object Format(object message) { }

	// RVA: 0x3621A18
	public object Format(object message, object writer) { }

	// RVA: 0x3622728
	public static object ToDiagnosticString(object message) { }

	// RVA: 0x3622478
	private object WriteMessage(object writer, object message) { }

	// RVA: 0x3622864
	private object WriteMessageFields(object writer, object message, object assumeFirstFieldWritten) { }

	// RVA: 0x3623D6C
	internal static object ToJsonName(object name) { }

	// RVA: 0x36227E4
	private static object WriteNull(object writer) { }

	// RVA: 0x362343C
	public object WriteValue(object writer, object value) { }

	// RVA: 0x3621D4C
	private object WriteWellKnownTypeValue(object writer, object descriptor, object value) { }

	// RVA: 0x362508C
	private object WriteTimestamp(object writer, object value) { }

	// RVA: 0x36256B4
	private object WriteDuration(object writer, object value) { }

	// RVA: 0x3625CDC
	private object WriteFieldMask(object writer, object value) { }

	// RVA: 0x3627384
	private object WriteAny(object writer, object value) { }

	// RVA: 0x3628730
	private object WriteDiagnosticOnlyAny(object writer, object value) { }

	// RVA: 0x3626168
	private object WriteStruct(object writer, object message) { }

	// RVA: 0x3626C54
	private object WriteStructFieldValue(object writer, object message) { }

	// RVA: 0x3624848
	internal object WriteList(object writer, object list) { }

	// RVA: 0x3623F50
	internal object WriteDictionary(object writer, object dictionary) { }

	// RVA: 0x3623068
	internal static object WriteString(object writer, object text) { }

	// RVA: 0x3628EA0
	private static object HexEncodeUtf16CodeUnit(object writer, object c) { }

}

// Namespace: Google.Protobuf
public static class MessageExtensions
{

	// Methods

	// RVA: 0x3629AF4
	public static object MergeDelimitedFrom(object message, object input) { }

	// RVA: 0x3629CDC
	public static object ToByteArray(object message) { }

	// RVA: 0x3629F04
	public static object WriteTo(object message, object output) { }

	// RVA: 0x362A10C
	internal static object MergeFrom(object message, object data, object discardUnknownFields) { }

	// RVA: 0x362A360
	internal static object MergeFrom(object message, object data, object discardUnknownFields) { }

	// RVA: 0x362A524
	internal static object MergeFrom(object message, object input, object discardUnknownFields) { }

	// RVA: 0x3629AFC
	internal static object MergeDelimitedFrom(object message, object input, object discardUnknownFields) { }

}

// Namespace: Google.Protobuf
public class MessageParser
{

	// Fields
	private object factory; // 0x8
	private readonly object <DiscardUnknownFields>k__BackingField; // 0x10

	// Properties
	internal object DiscardUnknownFields { get; }

	// Methods

	// RVA: 0x362A750
	internal object get_DiscardUnknownFields() { }

	// RVA: 0x362A758
	internal object .ctor(object factory, object discardUnknownFields) { }

	// RVA: 0x3628E40
	public object ParseFrom(object data) { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object factory; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.ctor>b__0() { }

}

// Namespace: Google.Protobuf
public sealed class MessageParser<T0>
{

	// Fields
	private readonly object factory; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object factory) { }

	// RVA: -1
	internal object .ctor(object factory, object discardUnknownFields) { }

	// RVA: -1
	public object CreateTemplate() { }

	// RVA: -1
	public object ParseFrom(object data) { }

	// RVA: -1
	public object ParseFrom(object input) { }

}

// Namespace: Google.Protobuf
public static class ProtoPreconditions
{

	// Methods

	// RVA: -1
	public static object CheckNotNull(object value, object name) { }

	// RVA: -1
	internal static object CheckNotNullUnconstrained(object value, object name) { }

}

// Namespace: Google.Protobuf
internal sealed class UnknownField
{

	// Fields
	private object varintList; // 0x8
	private object fixed32List; // 0x10
	private object fixed64List; // 0x18
	private object lengthDelimitedList; // 0x20

	// Methods

	// RVA: 0x362A794
	public object .ctor() { }

	// RVA: 0x362A79C
	public override object Equals(object other) { }

	// RVA: 0x362A8C8
	public override object GetHashCode() { }

	// RVA: 0x362A99C
	internal object WriteTo(object fieldNumber, object output) { }

	// RVA: 0x362AF30
	internal object GetSerializedSize(object fieldNumber) { }

	// RVA: 0x362B54C
	internal object MergeFrom(object other) { }

	// RVA: -1
	private static object AddAll(object current, object extras) { }

	// RVA: 0x362B630
	internal object AddVarint(object value) { }

	// RVA: 0x362B698
	internal object AddFixed32(object value) { }

	// RVA: 0x362B700
	internal object AddFixed64(object value) { }

	// RVA: 0x362B768
	internal object AddLengthDelimited(object value) { }

	// RVA: -1
	private static object Add(object list, object value) { }

}

// Namespace: Google.Protobuf
public sealed class UnknownFieldSet
{

	// Fields
	private readonly object fields; // 0x8
	private object lastFieldNumber; // 0x10
	private object lastField; // 0x18

	// Methods

	// RVA: 0x362B7D0
	internal object .ctor() { }

	// RVA: 0x362B854
	internal object HasField(object field) { }

	// RVA: 0x362B92C
	public object WriteTo(object output) { }

	// RVA: 0x362BC9C
	public object CalculateSize() { }

	// RVA: 0x362C014
	public override object Equals(object other) { }

	// RVA: 0x362C5F0
	public override object GetHashCode() { }

	// RVA: 0x362C9A0
	private object GetOrAddField(object number) { }

	// RVA: 0x362CB40
	internal object AddOrReplaceField(object number, object field) { }

	// RVA: 0x362CC90
	private object MergeFieldFrom(object input) { }

	// RVA: 0x362CF78
	public static object MergeFieldFrom(object unknownFields, object input) { }

	// RVA: 0x362D08C
	private object MergeFrom(object other) { }

	// RVA: 0x362D4C0
	public static object MergeFrom(object unknownFields, object other) { }

	// RVA: 0x362D3E4
	private object MergeField(object number, object field) { }

}

// Namespace: 
public enum WireType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Varint;
	public const object Fixed64;
	public const object LengthDelimited;
	public const object StartGroup;
	public const object EndGroup;
	public const object Fixed32;
}

// Namespace: Google.Protobuf
public static class WireFormat
{

	// Methods

	// RVA: 0x361B1D0
	public static object GetTagWireType(object tag) { }

	// RVA: 0x361B020
	public static object GetTagFieldNumber(object tag) { }

	// RVA: 0x361DEB4
	public static object MakeTag(object fieldNumber, object wireType) { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public static class AnyReflection
{

	// Fields
	private static object descriptor; // 0x0

	// Properties
	public static object Descriptor { get; }

	// Methods

	// RVA: 0x362D59C
	public static object get_Descriptor() { }

	// RVA: 0x362D618
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x362E4F0
	private static object .cctor() { }

	// RVA: 0x362E550
	public object .ctor() { }

	// RVA: 0x362E558
	internal object <.cctor>b__37_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Any
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object typeUrl_; // 0x10
	private object value_; // 0x18

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object TypeUrl { get; set; }
	public object Value { get; set; }

	// Methods

	// RVA: 0x362DA04
	public static object get_Parser() { }

	// RVA: 0x3627218
	public static object get_Descriptor() { }

	// RVA: 0x362DA80
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x362DAE8
	public object .ctor() { }

	// RVA: 0x362DBD8
	public object get_TypeUrl() { }

	// RVA: 0x362DBE0
	public object set_TypeUrl(object value) { }

	// RVA: 0x362DC60
	public object get_Value() { }

	// RVA: 0x362DC68
	public object set_Value(object value) { }

	// RVA: 0x362DCE8
	public override object Equals(object other) { }

	// RVA: 0x362DD68
	public object Equals(object other) { }

	// RVA: 0x362DE44
	public override object GetHashCode() { }

	// RVA: 0x362DF38
	public override object ToString() { }

	// RVA: 0x362DFB8
	public object WriteTo(object output) { }

	// RVA: 0x362E0EC
	public object CalculateSize() { }

	// RVA: 0x362E1DC
	public object MergeFrom(object input) { }

	// RVA: 0x3628D88
	public static object GetTypeName(object typeUrl) { }

	// RVA: 0x362E3E0
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public static class DurationReflection
{

	// Fields
	private static object descriptor; // 0x0

	// Properties
	public static object Descriptor { get; }

	// Methods

	// RVA: 0x362E5AC
	public static object get_Descriptor() { }

	// RVA: 0x362E628
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x362F5D4
	private static object .cctor() { }

	// RVA: 0x362F634
	public object .ctor() { }

	// RVA: 0x362F63C
	internal object <.cctor>b__46_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Duration
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object seconds_; // 0x10
	private object nanos_; // 0x18

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Seconds { get; set; }
	public object Nanos { get; set; }

	// Methods

	// RVA: 0x362EA38
	public static object get_Parser() { }

	// RVA: 0x3625548
	public static object get_Descriptor() { }

	// RVA: 0x362EAB4
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x362EB1C
	public object .ctor() { }

	// RVA: 0x362EB24
	public object get_Seconds() { }

	// RVA: 0x362EB2C
	public object set_Seconds(object value) { }

	// RVA: 0x362EB34
	public object get_Nanos() { }

	// RVA: 0x362EB3C
	public object set_Nanos(object value) { }

	// RVA: 0x362EB44
	public override object Equals(object other) { }

	// RVA: 0x362EC04
	public object Equals(object other) { }

	// RVA: 0x362EC50
	public override object GetHashCode() { }

	// RVA: 0x362ECF8
	public override object ToString() { }

	// RVA: 0x362ED78
	public object WriteTo(object output) { }

	// RVA: 0x362EE9C
	public object CalculateSize() { }

	// RVA: 0x362F0A0
	public object MergeFrom(object input) { }

	// RVA: 0x362F1FC
	internal static object IsNormalized(object seconds, object nanoseconds) { }

	// RVA: 0x3627EEC
	internal static object ToJson(object seconds, object nanoseconds, object diagnosticOnly) { }

	// RVA: 0x362F454
	public object ToDiagnosticString() { }

	// RVA: 0x362F2C8
	internal static object AppendNanoseconds(object builder, object nanos) { }

	// RVA: 0x362F4C4
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public static class FieldMaskReflection
{

	// Fields
	private static object descriptor; // 0x0

	// Properties
	public static object Descriptor { get; }

	// Methods

	// RVA: 0x362F694
	public static object get_Descriptor() { }

	// RVA: 0x362F710
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__25_0; // 0x8

	// Methods

	// RVA: 0x36304E4
	private static object .cctor() { }

	// RVA: 0x3630544
	public object .ctor() { }

	// RVA: 0x363054C
	internal object <ToJson>b__25_0(object p) { }

	// RVA: 0x3630658
	internal object <.cctor>b__28_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class FieldMask
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_paths_codec; // 0x8
	private readonly object paths_; // 0x10

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Paths { get; }

	// Methods

	// RVA: 0x362FAFC
	public static object get_Parser() { }

	// RVA: 0x3625B70
	public static object get_Descriptor() { }

	// RVA: 0x362FB78
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x362FBE0
	public object .ctor() { }

	// RVA: 0x362FC60
	public object get_Paths() { }

	// RVA: 0x362FC68
	public override object Equals(object other) { }

	// RVA: 0x362FD58
	public object Equals(object other) { }

	// RVA: 0x362FE0C
	public override object GetHashCode() { }

	// RVA: 0x362FE98
	public override object ToString() { }

	// RVA: 0x362FF18
	public object WriteTo(object output) { }

	// RVA: 0x362FFEC
	public object CalculateSize() { }

	// RVA: 0x36300B4
	public object MergeFrom(object input) { }

	// RVA: 0x3628300
	internal static object ToJson(object paths, object diagnosticOnly) { }

	// RVA: 0x3630278
	private static object ValidatePath(object input) { }

	// RVA: 0x3630330
	public object ToDiagnosticString() { }

	// RVA: 0x36303C0
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public static class SourceContextReflection
{

	// Fields
	private static object descriptor; // 0x0

	// Properties
	public static object Descriptor { get; }

	// Methods

	// RVA: 0x3630710
	public static object get_Descriptor() { }

	// RVA: 0x363078C
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3631524
	private static object .cctor() { }

	// RVA: 0x3631584
	public object .ctor() { }

	// RVA: 0x363158C
	internal object <.cctor>b__25_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class SourceContext
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object fileName_; // 0x10

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object FileName { get; set; }

	// Methods

	// RVA: 0x3630B78
	public static object get_Parser() { }

	// RVA: 0x3630BF4
	public static object get_Descriptor() { }

	// RVA: 0x3630D60
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3630DC8
	public object .ctor() { }

	// RVA: 0x3630E28
	public object get_FileName() { }

	// RVA: 0x3630E30
	public object set_FileName(object value) { }

	// RVA: 0x3630EB0
	public override object Equals(object other) { }

	// RVA: 0x3630F64
	public object Equals(object other) { }

	// RVA: 0x3630FD0
	public override object GetHashCode() { }

	// RVA: 0x3631080
	public override object ToString() { }

	// RVA: 0x3631100
	public object WriteTo(object output) { }

	// RVA: 0x36311B4
	public object CalculateSize() { }

	// RVA: 0x3631254
	public object MergeFrom(object input) { }

	// RVA: 0x3631414
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public static class StructReflection
{

	// Fields
	private static object descriptor; // 0x0

	// Properties
	public static object Descriptor { get; }

	// Methods

	// RVA: 0x3631620
	public static object get_Descriptor() { }

	// RVA: 0x363169C
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public enum NullValue
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NullValue;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x36329D8
	private static object .cctor() { }

	// RVA: 0x3632A38
	public object .ctor() { }

	// RVA: 0x3632A40
	internal object <.cctor>b__25_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Struct
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _map_fields_codec; // 0x8
	private readonly object fields_; // 0x10

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Fields { get; }

	// Methods

	// RVA: 0x3631FCC
	public static object get_Parser() { }

	// RVA: 0x3625FFC
	public static object get_Descriptor() { }

	// RVA: 0x3632048
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x36320B0
	public object .ctor() { }

	// RVA: 0x3632130
	public object get_Fields() { }

	// RVA: 0x3632138
	public override object Equals(object other) { }

	// RVA: 0x3632228
	public object Equals(object other) { }

	// RVA: 0x36322DC
	public override object GetHashCode() { }

	// RVA: 0x3632368
	public override object ToString() { }

	// RVA: 0x36323E8
	public object WriteTo(object output) { }

	// RVA: 0x36324BC
	public object CalculateSize() { }

	// RVA: 0x3632584
	public object MergeFrom(object other) { }

	// RVA: 0x3632608
	public object MergeFrom(object input) { }

	// RVA: 0x36327CC
	private static object .cctor() { }

}

// Namespace: 
public enum KindOneofCase
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NullValue;
	public const object NumberValue;
	public const object StringValue;
	public const object BoolValue;
	public const object StructValue;
	public const object ListValue;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3634CD8
	private static object .cctor() { }

	// RVA: 0x3634D38
	public object .ctor() { }

	// RVA: 0x3634D40
	internal object <.cctor>b__56_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Value
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object kind_; // 0x10
	private object kindCase_; // 0x18

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object NullValue { get; }
	public object NumberValue { get; set; }
	public object StringValue { get; set; }
	public object BoolValue { get; set; }
	public object StructValue { get; set; }
	public object ListValue { get; set; }
	public object KindCase { get; }

	// Methods

	// RVA: 0x3632AF8
	public static object get_Parser() { }

	// RVA: 0x3626AE8
	public static object get_Descriptor() { }

	// RVA: 0x3632B74
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3632BDC
	public object .ctor() { }

	// RVA: 0x3632BE4
	public object get_NullValue() { }

	// RVA: 0x3632C7C
	public object get_NumberValue() { }

	// RVA: 0x3632D08
	public object set_NumberValue(object value) { }

	// RVA: 0x3632D84
	public object get_StringValue() { }

	// RVA: 0x3632E14
	public object set_StringValue(object value) { }

	// RVA: 0x3632E9C
	public object get_BoolValue() { }

	// RVA: 0x3632F3C
	public object set_BoolValue(object value) { }

	// RVA: 0x3632FB0
	public object get_StructValue() { }

	// RVA: 0x363302C
	public object set_StructValue(object value) { }

	// RVA: 0x3633044
	public object get_ListValue() { }

	// RVA: 0x36330C0
	public object set_ListValue(object value) { }

	// RVA: 0x36330D8
	public object get_KindCase() { }

	// RVA: 0x36330E0
	public override object Equals(object other) { }

	// RVA: 0x3633160
	public object Equals(object other) { }

	// RVA: 0x36336E0
	public override object GetHashCode() { }

	// RVA: 0x3633BFC
	public override object ToString() { }

	// RVA: 0x3633C7C
	public object WriteTo(object output) { }

	// RVA: 0x36341D0
	public object CalculateSize() { }

	// RVA: 0x36345FC
	public object MergeFrom(object input) { }

	// RVA: 0x3634BC8
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3635654
	private static object .cctor() { }

	// RVA: 0x36356B4
	public object .ctor() { }

	// RVA: 0x36356BC
	internal object <.cctor>b__25_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class ListValue
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_values_codec; // 0x8
	private readonly object values_; // 0x10

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }

	// Methods

	// RVA: 0x3634D98
	public static object get_Parser() { }

	// RVA: 0x362697C
	public static object get_Descriptor() { }

	// RVA: 0x3634E14
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3634AC4
	public object .ctor() { }

	// RVA: 0x3634E7C
	public override object Equals(object other) { }

	// RVA: 0x3634F6C
	public object Equals(object other) { }

	// RVA: 0x3635020
	public override object GetHashCode() { }

	// RVA: 0x36350AC
	public override object ToString() { }

	// RVA: 0x363512C
	public object WriteTo(object output) { }

	// RVA: 0x3635200
	public object CalculateSize() { }

	// RVA: 0x3634B44
	public object MergeFrom(object other) { }

	// RVA: 0x36352C8
	public object MergeFrom(object input) { }

	// RVA: 0x363548C
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public static class TimestampReflection
{

	// Fields
	private static object descriptor; // 0x0

	// Properties
	public static object Descriptor { get; }

	// Methods

	// RVA: 0x3635774
	public static object get_Descriptor() { }

	// RVA: 0x36357F0
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x36365B8
	private static object .cctor() { }

	// RVA: 0x3636618
	public object .ctor() { }

	// RVA: 0x3636620
	internal object <.cctor>b__46_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Timestamp
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object seconds_; // 0x10
	private object nanos_; // 0x18
	private static readonly object UnixEpoch; // 0x8

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Seconds { get; set; }
	public object Nanos { get; set; }

	// Methods

	// RVA: 0x3635C00
	public static object get_Parser() { }

	// RVA: 0x3624F20
	public static object get_Descriptor() { }

	// RVA: 0x3635C7C
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3635CE4
	public object .ctor() { }

	// RVA: 0x3635CEC
	public object get_Seconds() { }

	// RVA: 0x3635CF4
	public object set_Seconds(object value) { }

	// RVA: 0x3635CFC
	public object get_Nanos() { }

	// RVA: 0x3635D04
	public object set_Nanos(object value) { }

	// RVA: 0x3635D0C
	public override object Equals(object other) { }

	// RVA: 0x3635DCC
	public object Equals(object other) { }

	// RVA: 0x3635E18
	public override object GetHashCode() { }

	// RVA: 0x3635EC0
	public override object ToString() { }

	// RVA: 0x3635F40
	public object WriteTo(object output) { }

	// RVA: 0x3636064
	public object CalculateSize() { }

	// RVA: 0x3636268
	public object MergeFrom(object input) { }

	// RVA: 0x36363C4
	private static object IsNormalized(object seconds, object nanoseconds) { }

	// RVA: 0x3627B18
	internal static object ToJson(object seconds, object nanoseconds, object diagnosticOnly) { }

	// RVA: 0x36363F8
	public object ToDiagnosticString() { }

	// RVA: 0x3636468
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public static class TypeReflection
{

	// Fields
	private static object descriptor; // 0x0

	// Properties
	public static object Descriptor { get; }

	// Methods

	// RVA: 0x3636678
	public static object get_Descriptor() { }

	// RVA: 0x36366F4
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public enum Syntax
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Proto2;
	public const object Proto3;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3638B8C
	private static object .cctor() { }

	// RVA: 0x3638BEC
	public object .ctor() { }

	// RVA: 0x3638BF4
	internal object <.cctor>b__50_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Type
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private static readonly object _repeated_fields_codec; // 0x8
	private readonly object fields_; // 0x18
	private static readonly object _repeated_oneofs_codec; // 0x10
	private readonly object oneofs_; // 0x20
	private static readonly object _repeated_options_codec; // 0x18
	private readonly object options_; // 0x28
	private object sourceContext_; // 0x30
	private object syntax_; // 0x38

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object SourceContext { get; }
	public object Syntax { get; }

	// Methods

	// RVA: 0x36378CC
	public static object get_Parser() { }

	// RVA: 0x3637948
	public static object get_Descriptor() { }

	// RVA: 0x3637AB4
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3637B1C
	public object .ctor() { }

	// RVA: 0x3637C50
	public object get_Name() { }

	// RVA: 0x3637C58
	public object set_Name(object value) { }

	// RVA: 0x3637CD8
	public object get_SourceContext() { }

	// RVA: 0x3637CE0
	public object get_Syntax() { }

	// RVA: 0x3637CE8
	public override object Equals(object other) { }

	// RVA: 0x3637D68
	public object Equals(object other) { }

	// RVA: 0x3637EC4
	public override object GetHashCode() { }

	// RVA: 0x363807C
	public override object ToString() { }

	// RVA: 0x36380FC
	public object WriteTo(object output) { }

	// RVA: 0x3638394
	public object CalculateSize() { }

	// RVA: 0x3638664
	public object MergeFrom(object input) { }

	// RVA: 0x3638914
	private static object .cctor() { }

}

// Namespace: 
public enum Kind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TypeUnknown;
	public const object TypeDouble;
	public const object TypeFloat;
	public const object TypeInt64;
	public const object TypeUint64;
	public const object TypeInt32;
	public const object TypeFixed64;
	public const object TypeFixed32;
	public const object TypeBool;
	public const object TypeString;
	public const object TypeGroup;
	public const object TypeMessage;
	public const object TypeBytes;
	public const object TypeUint32;
	public const object TypeEnum;
	public const object TypeSfixed32;
	public const object TypeSfixed64;
	public const object TypeSint32;
	public const object TypeSint64;
}

// Namespace: 
public enum Cardinality
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Optional;
	public const object Required;
	public const object Repeated;
}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x363A574
	private static object .cctor() { }

	// RVA: 0x363A5D4
	public object .ctor() { }

	// RVA: 0x363A5DC
	internal object <.cctor>b__71_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Field
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object kind_; // 0x10
	private object cardinality_; // 0x14
	private object number_; // 0x18
	private object name_; // 0x20
	private object typeUrl_; // 0x28
	private object oneofIndex_; // 0x30
	private object packed_; // 0x34
	private static readonly object _repeated_options_codec; // 0x8
	private readonly object options_; // 0x38
	private object jsonName_; // 0x40
	private object defaultValue_; // 0x48

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Kind { get; }
	public object Cardinality { get; }
	public object Number { get; set; }
	public object Name { get; set; }
	public object TypeUrl { get; set; }
	public object OneofIndex { get; set; }
	public object Packed { get; set; }
	public object JsonName { get; set; }
	public object DefaultValue { get; set; }

	// Methods

	// RVA: 0x3638C48
	public static object get_Parser() { }

	// RVA: 0x3638CC4
	public static object get_Descriptor() { }

	// RVA: 0x3638E30
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3638E98
	public object .ctor() { }

	// RVA: 0x3638F44
	public object get_Kind() { }

	// RVA: 0x3638F4C
	public object get_Cardinality() { }

	// RVA: 0x3638F54
	public object get_Number() { }

	// RVA: 0x3638F5C
	public object set_Number(object value) { }

	// RVA: 0x3638F64
	public object get_Name() { }

	// RVA: 0x3638F6C
	public object set_Name(object value) { }

	// RVA: 0x3638FEC
	public object get_TypeUrl() { }

	// RVA: 0x3638FF4
	public object set_TypeUrl(object value) { }

	// RVA: 0x3639074
	public object get_OneofIndex() { }

	// RVA: 0x363907C
	public object set_OneofIndex(object value) { }

	// RVA: 0x3639084
	public object get_Packed() { }

	// RVA: 0x363908C
	public object set_Packed(object value) { }

	// RVA: 0x3639094
	public object get_JsonName() { }

	// RVA: 0x363909C
	public object set_JsonName(object value) { }

	// RVA: 0x363911C
	public object get_DefaultValue() { }

	// RVA: 0x3639124
	public object set_DefaultValue(object value) { }

	// RVA: 0x36391A4
	public override object Equals(object other) { }

	// RVA: 0x3639224
	public object Equals(object other) { }

	// RVA: 0x3639378
	public override object GetHashCode() { }

	// RVA: 0x3639608
	public override object ToString() { }

	// RVA: 0x3639688
	public object WriteTo(object output) { }

	// RVA: 0x3639BC8
	public object CalculateSize() { }

	// RVA: 0x363A0C8
	public object MergeFrom(object input) { }

	// RVA: 0x363A3AC
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x363B7D0
	private static object .cctor() { }

	// RVA: 0x363B830
	public object .ctor() { }

	// RVA: 0x363B838
	internal object <.cctor>b__45_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Enum
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private static readonly object _repeated_enumvalue_codec; // 0x8
	private readonly object enumvalue_; // 0x18
	private static readonly object _repeated_options_codec; // 0x10
	private readonly object options_; // 0x20
	private object sourceContext_; // 0x28
	private object syntax_; // 0x30

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object SourceContext { get; }
	public object Syntax { get; }

	// Methods

	// RVA: 0x363A6C0
	public static object get_Parser() { }

	// RVA: 0x363A73C
	public static object get_Descriptor() { }

	// RVA: 0x363A8A8
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x363A910
	public object .ctor() { }

	// RVA: 0x363A9FC
	public object get_Name() { }

	// RVA: 0x363AA04
	public object set_Name(object value) { }

	// RVA: 0x363AA84
	public object get_SourceContext() { }

	// RVA: 0x363AA8C
	public object get_Syntax() { }

	// RVA: 0x363AA94
	public override object Equals(object other) { }

	// RVA: 0x363AB14
	public object Equals(object other) { }

	// RVA: 0x363AC38
	public override object GetHashCode() { }

	// RVA: 0x363ADB0
	public override object ToString() { }

	// RVA: 0x363AE30
	public object WriteTo(object output) { }

	// RVA: 0x363B088
	public object CalculateSize() { }

	// RVA: 0x363B314
	public object MergeFrom(object input) { }

	// RVA: 0x363B56C
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x363C728
	private static object .cctor() { }

	// RVA: 0x363C788
	public object .ctor() { }

	// RVA: 0x363C790
	internal object <.cctor>b__35_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class EnumValue
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private object number_; // 0x18
	private static readonly object _repeated_options_codec; // 0x8
	private readonly object options_; // 0x20

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Number { get; set; }

	// Methods

	// RVA: 0x363B88C
	public static object get_Parser() { }

	// RVA: 0x363B908
	public static object get_Descriptor() { }

	// RVA: 0x363BA74
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x363BADC
	public object .ctor() { }

	// RVA: 0x363BB80
	public object get_Name() { }

	// RVA: 0x363BB88
	public object set_Name(object value) { }

	// RVA: 0x363BC08
	public object get_Number() { }

	// RVA: 0x363BC10
	public object set_Number(object value) { }

	// RVA: 0x363BC18
	public override object Equals(object other) { }

	// RVA: 0x363BC98
	public object Equals(object other) { }

	// RVA: 0x363BD84
	public override object GetHashCode() { }

	// RVA: 0x363BE94
	public override object ToString() { }

	// RVA: 0x363BF14
	public object WriteTo(object output) { }

	// RVA: 0x363C0DC
	public object CalculateSize() { }

	// RVA: 0x363C30C
	public object MergeFrom(object input) { }

	// RVA: 0x363C560
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x363D370
	private static object .cctor() { }

	// RVA: 0x363D3D0
	public object .ctor() { }

	// RVA: 0x363D3D8
	internal object <.cctor>b__30_0() { }

}

// Namespace: Google.Protobuf.WellKnownTypes
public sealed class Option
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private object value_; // 0x18

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Value { get; }

	// Methods

	// RVA: 0x363C86C
	public static object get_Parser() { }

	// RVA: 0x363C8E8
	public static object get_Descriptor() { }

	// RVA: 0x363CA54
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x363CABC
	public object .ctor() { }

	// RVA: 0x363CB1C
	public object get_Name() { }

	// RVA: 0x363CB24
	public object set_Name(object value) { }

	// RVA: 0x363CBA4
	public object get_Value() { }

	// RVA: 0x363CBAC
	public override object Equals(object other) { }

	// RVA: 0x363CC88
	public object Equals(object other) { }

	// RVA: 0x363CD18
	public override object GetHashCode() { }

	// RVA: 0x363CDF4
	public override object ToString() { }

	// RVA: 0x363CE74
	public object WriteTo(object output) { }

	// RVA: 0x363CF8C
	public object CalculateSize() { }

	// RVA: 0x363D05C
	public object MergeFrom(object input) { }

	// RVA: 0x363D260
	private static object .cctor() { }

}

// Namespace: 
private struct FieldValue
{

	// Fields
	private readonly object <Number>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private readonly object <ByteString>k__BackingField; // 0x0

	// Methods

	// RVA: 0x363D858
	internal object .ctor(object number) { }

	// RVA: 0x363D5BC
	internal object .ctor(object byteString) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class CustomOptions
{

	// Fields
	internal static readonly object Empty; // 0x0
	private readonly object valuesByField; // 0x8

	// Methods

	// RVA: 0x363D430
	private object .ctor() { }

	// RVA: 0x363D4B0
	internal object ReadOrSkipUnknownField(object input) { }

	// RVA: 0x363D5C4
	private object AddValue(object field, object value) { }

	// RVA: 0x363D860
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.Reflection
internal static class DescriptorReflection
{

	// Fields
	private static object descriptor; // 0x0

	// Properties
	public static object Descriptor { get; }

	// Methods

	// RVA: 0x363D974
	public static object get_Descriptor() { }

	// RVA: 0x363D9F0
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x36427E4
	private static object .cctor() { }

	// RVA: 0x3642844
	public object .ctor() { }

	// RVA: 0x364284C
	internal object <.cctor>b__25_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class FileDescriptorSet
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_file_codec; // 0x8
	private readonly object file_; // 0x10

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }

	// Methods

	// RVA: 0x3641E00
	public static object get_Parser() { }

	// RVA: 0x3641E7C
	public static object get_Descriptor() { }

	// RVA: 0x3641FE8
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3642050
	public object .ctor() { }

	// RVA: 0x36420D0
	public override object Equals(object other) { }

	// RVA: 0x36421C0
	public object Equals(object other) { }

	// RVA: 0x3642274
	public override object GetHashCode() { }

	// RVA: 0x3642300
	public override object ToString() { }

	// RVA: 0x3642388
	public object WriteTo(object output) { }

	// RVA: 0x3642460
	public object CalculateSize() { }

	// RVA: 0x364252C
	public object MergeFrom(object input) { }

	// RVA: 0x364261C
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3644824
	private static object .cctor() { }

	// RVA: 0x3644884
	public object .ctor() { }

	// RVA: 0x364488C
	internal object <.cctor>b__80_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class FileDescriptorProto
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private object package_; // 0x18
	private static readonly object _repeated_dependency_codec; // 0x8
	private readonly object dependency_; // 0x20
	private static readonly object _repeated_publicDependency_codec; // 0x10
	private readonly object publicDependency_; // 0x28
	private static readonly object _repeated_weakDependency_codec; // 0x18
	private readonly object weakDependency_; // 0x30
	private static readonly object _repeated_messageType_codec; // 0x20
	private readonly object messageType_; // 0x38
	private static readonly object _repeated_enumType_codec; // 0x28
	private readonly object enumType_; // 0x40
	private static readonly object _repeated_service_codec; // 0x30
	private readonly object service_; // 0x48
	private static readonly object _repeated_extension_codec; // 0x38
	private readonly object extension_; // 0x50
	private object options_; // 0x58
	private object sourceCodeInfo_; // 0x60
	private object syntax_; // 0x68

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Package { get; set; }
	public object Dependency { get; }
	public object PublicDependency { get; }
	public object MessageType { get; }
	public object EnumType { get; }
	public object Service { get; }
	public object Options { get; }
	public object SourceCodeInfo { get; }
	public object Syntax { get; set; }

	// Methods

	// RVA: 0x3642904
	public static object get_Parser() { }

	// RVA: 0x3642980
	public static object get_Descriptor() { }

	// RVA: 0x3642AEC
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3642B54
	public object .ctor() { }

	// RVA: 0x3642D68
	public object get_Name() { }

	// RVA: 0x3642D70
	public object set_Name(object value) { }

	// RVA: 0x3642DF0
	public object get_Package() { }

	// RVA: 0x3642DF8
	public object set_Package(object value) { }

	// RVA: 0x3642E78
	public object get_Dependency() { }

	// RVA: 0x3642E80
	public object get_PublicDependency() { }

	// RVA: 0x3642E88
	public object get_MessageType() { }

	// RVA: 0x3642E90
	public object get_EnumType() { }

	// RVA: 0x3642E98
	public object get_Service() { }

	// RVA: 0x3642EA0
	public object get_Options() { }

	// RVA: 0x3642EA8
	public object get_SourceCodeInfo() { }

	// RVA: 0x3642EB0
	public object get_Syntax() { }

	// RVA: 0x3642EB8
	public object set_Syntax(object value) { }

	// RVA: 0x3642F38
	public override object Equals(object other) { }

	// RVA: 0x3642FB8
	public object Equals(object other) { }

	// RVA: 0x364320C
	public override object GetHashCode() { }

	// RVA: 0x3643564
	public override object ToString() { }

	// RVA: 0x36435EC
	public object WriteTo(object output) { }

	// RVA: 0x3643990
	public object CalculateSize() { }

	// RVA: 0x3643D28
	public object MergeFrom(object input) { }

	// RVA: 0x3644440
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3646E7C
	private static object .cctor() { }

	// RVA: 0x3646EDC
	public object .ctor() { }

	// RVA: 0x3646EE4
	internal object <.cctor>b__35_0() { }

}

// Namespace: 
internal sealed class ExtensionRange
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object start_; // 0x10
	private object end_; // 0x14
	private object options_; // 0x18

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Start { get; set; }
	public object End { get; set; }
	public object Options { get; }

	// Methods

	// RVA: 0x36464A4
	public static object get_Parser() { }

	// RVA: 0x3646520
	public static object get_Descriptor() { }

	// RVA: 0x3646638
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x36466A0
	public object .ctor() { }

	// RVA: 0x36466A8
	public object get_Start() { }

	// RVA: 0x36466B0
	public object set_Start(object value) { }

	// RVA: 0x36466B8
	public object get_End() { }

	// RVA: 0x36466C0
	public object set_End(object value) { }

	// RVA: 0x36466C8
	public object get_Options() { }

	// RVA: 0x36466D0
	public override object Equals(object other) { }

	// RVA: 0x36467B8
	public object Equals(object other) { }

	// RVA: 0x3646854
	public override object GetHashCode() { }

	// RVA: 0x3646930
	public override object ToString() { }

	// RVA: 0x36469B8
	public object WriteTo(object output) { }

	// RVA: 0x3646A9C
	public object CalculateSize() { }

	// RVA: 0x3646B80
	public object MergeFrom(object input) { }

	// RVA: 0x3646D6C
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x364769C
	private static object .cctor() { }

	// RVA: 0x36476FC
	public object .ctor() { }

	// RVA: 0x3647704
	internal object <.cctor>b__30_0() { }

}

// Namespace: 
internal sealed class ReservedRange
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object start_; // 0x10
	private object end_; // 0x14

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Start { get; set; }
	public object End { get; set; }

	// Methods

	// RVA: 0x3646F3C
	public static object get_Parser() { }

	// RVA: 0x3646FB8
	public static object get_Descriptor() { }

	// RVA: 0x36470D0
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3647138
	public object .ctor() { }

	// RVA: 0x3647140
	public object get_Start() { }

	// RVA: 0x3647148
	public object set_Start(object value) { }

	// RVA: 0x3647150
	public object get_End() { }

	// RVA: 0x3647158
	public object set_End(object value) { }

	// RVA: 0x3647160
	public override object Equals(object other) { }

	// RVA: 0x3647220
	public object Equals(object other) { }

	// RVA: 0x364726C
	public override object GetHashCode() { }

	// RVA: 0x3647310
	public override object ToString() { }

	// RVA: 0x3647398
	public object WriteTo(object output) { }

	// RVA: 0x3647444
	public object CalculateSize() { }

	// RVA: 0x36474FC
	public object MergeFrom(object input) { }

	// RVA: 0x364758C
	private static object .cctor() { }

}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x364775C
	private static object .cctor() { }

	// RVA: 0x36477BC
	public object .ctor() { }

	// RVA: 0x36477C4
	internal object <.cctor>b__71_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class DescriptorProto
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private static readonly object _repeated_field_codec; // 0x8
	private readonly object field_; // 0x18
	private static readonly object _repeated_extension_codec; // 0x10
	private readonly object extension_; // 0x20
	private static readonly object _repeated_nestedType_codec; // 0x18
	private readonly object nestedType_; // 0x28
	private static readonly object _repeated_enumType_codec; // 0x20
	private readonly object enumType_; // 0x30
	private static readonly object _repeated_extensionRange_codec; // 0x28
	private readonly object extensionRange_; // 0x38
	private static readonly object _repeated_oneofDecl_codec; // 0x30
	private readonly object oneofDecl_; // 0x40
	private object options_; // 0x48
	private static readonly object _repeated_reservedRange_codec; // 0x38
	private readonly object reservedRange_; // 0x50
	private static readonly object _repeated_reservedName_codec; // 0x40
	private readonly object reservedName_; // 0x58

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Field { get; }
	public object NestedType { get; }
	public object EnumType { get; }
	public object OneofDecl { get; }
	public object Options { get; }

	// Methods

	// RVA: 0x36448E0
	public static object get_Parser() { }

	// RVA: 0x364495C
	public static object get_Descriptor() { }

	// RVA: 0x3644AC8
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3644B30
	public object .ctor() { }

	// RVA: 0x3644D7C
	public object get_Name() { }

	// RVA: 0x3644D84
	public object set_Name(object value) { }

	// RVA: 0x3644E04
	public object get_Field() { }

	// RVA: 0x3644E0C
	public object get_NestedType() { }

	// RVA: 0x3644E14
	public object get_EnumType() { }

	// RVA: 0x3644E1C
	public object get_OneofDecl() { }

	// RVA: 0x3644E24
	public object get_Options() { }

	// RVA: 0x3644E2C
	public override object Equals(object other) { }

	// RVA: 0x3644EAC
	public object Equals(object other) { }

	// RVA: 0x3645110
	public override object GetHashCode() { }

	// RVA: 0x36453E8
	public override object ToString() { }

	// RVA: 0x3645470
	public object WriteTo(object output) { }

	// RVA: 0x3645784
	public object CalculateSize() { }

	// RVA: 0x3645AC0
	public object MergeFrom(object input) { }

	// RVA: 0x3645F88
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3648180
	private static object .cctor() { }

	// RVA: 0x36481E0
	public object .ctor() { }

	// RVA: 0x36481E8
	internal object <.cctor>b__25_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class ExtensionRangeOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x10

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }

	// Methods

	// RVA: 0x3647818
	public static object get_Parser() { }

	// RVA: 0x3647894
	public static object get_Descriptor() { }

	// RVA: 0x3647A00
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3646CEC
	public object .ctor() { }

	// RVA: 0x3647A68
	public override object Equals(object other) { }

	// RVA: 0x3647B58
	public object Equals(object other) { }

	// RVA: 0x3647C0C
	public override object GetHashCode() { }

	// RVA: 0x3647C98
	public override object ToString() { }

	// RVA: 0x3647D20
	public object WriteTo(object output) { }

	// RVA: 0x3647DF8
	public object CalculateSize() { }

	// RVA: 0x3647EC4
	public object MergeFrom(object input) { }

	// RVA: 0x3647FB8
	private static object .cctor() { }

}

// Namespace: 
internal enum Type
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Double;
	public const object Float;
	public const object Int64;
	public const object Uint64;
	public const object Int32;
	public const object Fixed64;
	public const object Fixed32;
	public const object Bool;
	public const object String;
	public const object Group;
	public const object Message;
	public const object Bytes;
	public const object Uint32;
	public const object Enum;
	public const object Sfixed32;
	public const object Sfixed64;
	public const object Sint32;
	public const object Sint64;
}

// Namespace: 
internal enum Label
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Optional;
	public const object Required;
	public const object Repeated;
}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3649758
	private static object .cctor() { }

	// RVA: 0x36497B8
	public object .ctor() { }

	// RVA: 0x36497C0
	internal object <.cctor>b__71_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class FieldDescriptorProto
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private object number_; // 0x18
	private object label_; // 0x1C
	private object type_; // 0x20
	private object typeName_; // 0x28
	private object extendee_; // 0x30
	private object defaultValue_; // 0x38
	private object oneofIndex_; // 0x40
	private object jsonName_; // 0x48
	private object options_; // 0x50

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Number { get; set; }
	public object Label { get; }
	public object Type { get; }
	public object TypeName { get; set; }
	public object Extendee { get; set; }
	public object DefaultValue { get; set; }
	public object OneofIndex { get; set; }
	public object JsonName { get; set; }
	public object Options { get; }

	// Methods

	// RVA: 0x36482A0
	public static object get_Parser() { }

	// RVA: 0x364831C
	public static object get_Descriptor() { }

	// RVA: 0x3648488
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x36484F0
	public object .ctor() { }

	// RVA: 0x3648564
	private object OnConstruction() { }

	// RVA: 0x3648570
	public object get_Name() { }

	// RVA: 0x3648578
	public object set_Name(object value) { }

	// RVA: 0x36485F8
	public object get_Number() { }

	// RVA: 0x3648600
	public object set_Number(object value) { }

	// RVA: 0x3648608
	public object get_Label() { }

	// RVA: 0x3648610
	public object get_Type() { }

	// RVA: 0x3648618
	public object get_TypeName() { }

	// RVA: 0x3648620
	public object set_TypeName(object value) { }

	// RVA: 0x36486A0
	public object get_Extendee() { }

	// RVA: 0x36486A8
	public object set_Extendee(object value) { }

	// RVA: 0x3648728
	public object get_DefaultValue() { }

	// RVA: 0x3648730
	public object set_DefaultValue(object value) { }

	// RVA: 0x36487B0
	public object get_OneofIndex() { }

	// RVA: 0x36487B8
	public object set_OneofIndex(object value) { }

	// RVA: 0x36487C0
	public object get_JsonName() { }

	// RVA: 0x36487C8
	public object set_JsonName(object value) { }

	// RVA: 0x3648848
	public object get_Options() { }

	// RVA: 0x3648850
	public override object Equals(object other) { }

	// RVA: 0x36488D0
	public object Equals(object other) { }

	// RVA: 0x36489F8
	public override object GetHashCode() { }

	// RVA: 0x3648C64
	public override object ToString() { }

	// RVA: 0x3648CEC
	public object WriteTo(object output) { }

	// RVA: 0x3648FBC
	public object CalculateSize() { }

	// RVA: 0x3649270
	public object MergeFrom(object input) { }

	// RVA: 0x3649648
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x364A310
	private static object .cctor() { }

	// RVA: 0x364A370
	public object .ctor() { }

	// RVA: 0x364A378
	internal object <.cctor>b__30_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class OneofDescriptorProto
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private object options_; // 0x18

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Options { get; }

	// Methods

	// RVA: 0x3649868
	public static object get_Parser() { }

	// RVA: 0x36498E4
	public static object get_Descriptor() { }

	// RVA: 0x3649A50
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3649AB8
	public object .ctor() { }

	// RVA: 0x3649B18
	public object get_Name() { }

	// RVA: 0x3649B20
	public object set_Name(object value) { }

	// RVA: 0x3649BA0
	public object get_Options() { }

	// RVA: 0x3649BA8
	public override object Equals(object other) { }

	// RVA: 0x3649C84
	public object Equals(object other) { }

	// RVA: 0x3649D14
	public override object GetHashCode() { }

	// RVA: 0x3649DF0
	public override object ToString() { }

	// RVA: 0x3649E78
	public object WriteTo(object output) { }

	// RVA: 0x3649F38
	public object CalculateSize() { }

	// RVA: 0x364A014
	public object MergeFrom(object input) { }

	// RVA: 0x364A200
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x364BCE4
	private static object .cctor() { }

	// RVA: 0x364BD44
	public object .ctor() { }

	// RVA: 0x364BD4C
	internal object <.cctor>b__30_0() { }

}

// Namespace: 
internal sealed class EnumReservedRange
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object start_; // 0x10
	private object end_; // 0x14

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Start { get; set; }
	public object End { get; set; }

	// Methods

	// RVA: 0x364B584
	public static object get_Parser() { }

	// RVA: 0x364B600
	public static object get_Descriptor() { }

	// RVA: 0x364B718
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x364B780
	public object .ctor() { }

	// RVA: 0x364B788
	public object get_Start() { }

	// RVA: 0x364B790
	public object set_Start(object value) { }

	// RVA: 0x364B798
	public object get_End() { }

	// RVA: 0x364B7A0
	public object set_End(object value) { }

	// RVA: 0x364B7A8
	public override object Equals(object other) { }

	// RVA: 0x364B868
	public object Equals(object other) { }

	// RVA: 0x364B8B4
	public override object GetHashCode() { }

	// RVA: 0x364B958
	public override object ToString() { }

	// RVA: 0x364B9E0
	public object WriteTo(object output) { }

	// RVA: 0x364BA8C
	public object CalculateSize() { }

	// RVA: 0x364BB44
	public object MergeFrom(object input) { }

	// RVA: 0x364BBD4
	private static object .cctor() { }

}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x364BDA4
	private static object .cctor() { }

	// RVA: 0x364BE04
	public object .ctor() { }

	// RVA: 0x364BE0C
	internal object <.cctor>b__46_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class EnumDescriptorProto
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private static readonly object _repeated_value_codec; // 0x8
	private readonly object value_; // 0x18
	private object options_; // 0x20
	private static readonly object _repeated_reservedRange_codec; // 0x10
	private readonly object reservedRange_; // 0x28
	private static readonly object _repeated_reservedName_codec; // 0x18
	private readonly object reservedName_; // 0x30

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Value { get; }
	public object Options { get; }

	// Methods

	// RVA: 0x364A40C
	public static object get_Parser() { }

	// RVA: 0x364A488
	public static object get_Descriptor() { }

	// RVA: 0x364A5F4
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x364A65C
	public object .ctor() { }

	// RVA: 0x364A790
	public object get_Name() { }

	// RVA: 0x364A798
	public object set_Name(object value) { }

	// RVA: 0x364A818
	public object get_Value() { }

	// RVA: 0x364A820
	public object get_Options() { }

	// RVA: 0x364A828
	public override object Equals(object other) { }

	// RVA: 0x364A8A8
	public object Equals(object other) { }

	// RVA: 0x364AA08
	public override object GetHashCode() { }

	// RVA: 0x364AB94
	public override object ToString() { }

	// RVA: 0x364AC1C
	public object WriteTo(object output) { }

	// RVA: 0x364ADF8
	public object CalculateSize() { }

	// RVA: 0x364AFE4
	public object MergeFrom(object input) { }

	// RVA: 0x364B308
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x364C9E4
	private static object .cctor() { }

	// RVA: 0x364CA44
	public object .ctor() { }

	// RVA: 0x364CA4C
	internal object <.cctor>b__35_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class EnumValueDescriptorProto
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private object number_; // 0x18
	private object options_; // 0x20

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Number { get; set; }
	public object Options { get; }

	// Methods

	// RVA: 0x364BE60
	public static object get_Parser() { }

	// RVA: 0x364BEDC
	public static object get_Descriptor() { }

	// RVA: 0x364C048
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x364C0B0
	public object .ctor() { }

	// RVA: 0x364C110
	public object get_Name() { }

	// RVA: 0x364C118
	public object set_Name(object value) { }

	// RVA: 0x364C198
	public object get_Number() { }

	// RVA: 0x364C1A0
	public object set_Number(object value) { }

	// RVA: 0x364C1A8
	public object get_Options() { }

	// RVA: 0x364C1B0
	public override object Equals(object other) { }

	// RVA: 0x364C29C
	public object Equals(object other) { }

	// RVA: 0x364C33C
	public override object GetHashCode() { }

	// RVA: 0x364C440
	public override object ToString() { }

	// RVA: 0x364C4C8
	public object WriteTo(object output) { }

	// RVA: 0x364C5C0
	public object CalculateSize() { }

	// RVA: 0x364C6C8
	public object MergeFrom(object input) { }

	// RVA: 0x364C8D4
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x364D84C
	private static object .cctor() { }

	// RVA: 0x364D8AC
	public object .ctor() { }

	// RVA: 0x364D8B4
	internal object <.cctor>b__35_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class ServiceDescriptorProto
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private static readonly object _repeated_method_codec; // 0x8
	private readonly object method_; // 0x18
	private object options_; // 0x20

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object Method { get; }
	public object Options { get; }

	// Methods

	// RVA: 0x364CAE0
	public static object get_Parser() { }

	// RVA: 0x364CB5C
	public static object get_Descriptor() { }

	// RVA: 0x364CCC8
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x364CD30
	public object .ctor() { }

	// RVA: 0x364CDD4
	public object get_Name() { }

	// RVA: 0x364CDDC
	public object set_Name(object value) { }

	// RVA: 0x364CE5C
	public object get_Method() { }

	// RVA: 0x364CE64
	public object get_Options() { }

	// RVA: 0x364CE6C
	public override object Equals(object other) { }

	// RVA: 0x364CEEC
	public object Equals(object other) { }

	// RVA: 0x364CFDC
	public override object GetHashCode() { }

	// RVA: 0x364D0F0
	public override object ToString() { }

	// RVA: 0x364D178
	public object WriteTo(object output) { }

	// RVA: 0x364D2C0
	public object CalculateSize() { }

	// RVA: 0x364D414
	public object MergeFrom(object input) { }

	// RVA: 0x364D684
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x364E944
	private static object .cctor() { }

	// RVA: 0x364E9A4
	public object .ctor() { }

	// RVA: 0x364E9AC
	internal object <.cctor>b__50_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class MethodDescriptorProto
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object name_; // 0x10
	private object inputType_; // 0x18
	private object outputType_; // 0x20
	private object options_; // 0x28
	private object clientStreaming_; // 0x30
	private object serverStreaming_; // 0x31

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object Name { get; set; }
	public object InputType { get; set; }
	public object OutputType { get; set; }
	public object Options { get; }
	public object ClientStreaming { get; set; }
	public object ServerStreaming { get; set; }

	// Methods

	// RVA: 0x364D990
	public static object get_Parser() { }

	// RVA: 0x364DA0C
	public static object get_Descriptor() { }

	// RVA: 0x364DB78
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x364DBE0
	public object .ctor() { }

	// RVA: 0x364DC44
	public object get_Name() { }

	// RVA: 0x364DC4C
	public object set_Name(object value) { }

	// RVA: 0x364DCCC
	public object get_InputType() { }

	// RVA: 0x364DCD4
	public object set_InputType(object value) { }

	// RVA: 0x364DD54
	public object get_OutputType() { }

	// RVA: 0x364DD5C
	public object set_OutputType(object value) { }

	// RVA: 0x364DDDC
	public object get_Options() { }

	// RVA: 0x364DDE4
	public object get_ClientStreaming() { }

	// RVA: 0x364DDEC
	public object set_ClientStreaming(object value) { }

	// RVA: 0x364DDF4
	public object get_ServerStreaming() { }

	// RVA: 0x364DDFC
	public object set_ServerStreaming(object value) { }

	// RVA: 0x364DE04
	public override object Equals(object other) { }

	// RVA: 0x364DE84
	public object Equals(object other) { }

	// RVA: 0x364DF4C
	public override object GetHashCode() { }

	// RVA: 0x364E174
	public override object ToString() { }

	// RVA: 0x364E1FC
	public object WriteTo(object output) { }

	// RVA: 0x364E3CC
	public object CalculateSize() { }

	// RVA: 0x364E554
	public object MergeFrom(object input) { }

	// RVA: 0x364E834
	private static object .cctor() { }

}

// Namespace: 
internal enum OptimizeMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Speed;
	public const object CodeSize;
	public const object LiteRuntime;
}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3650DEC
	private static object .cctor() { }

	// RVA: 0x3650E4C
	public object .ctor() { }

	// RVA: 0x3650E54
	internal object <.cctor>b__130_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class FileOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object <CustomOptions>k__BackingField; // 0x10
	private object javaPackage_; // 0x18
	private object javaOuterClassname_; // 0x20
	private object javaMultipleFiles_; // 0x28
	private object javaGenerateEqualsAndHash_; // 0x29
	private object javaStringCheckUtf8_; // 0x2A
	private object optimizeFor_; // 0x2C
	private object goPackage_; // 0x30
	private object ccGenericServices_; // 0x38
	private object javaGenericServices_; // 0x39
	private object pyGenericServices_; // 0x3A
	private object phpGenericServices_; // 0x3B
	private object deprecated_; // 0x3C
	private object ccEnableArenas_; // 0x3D
	private object objcClassPrefix_; // 0x40
	private object csharpNamespace_; // 0x48
	private object swiftPrefix_; // 0x50
	private object phpClassPrefix_; // 0x58
	private object phpNamespace_; // 0x60
	private object phpMetadataNamespace_; // 0x68
	private object rubyPackage_; // 0x70
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x78

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	internal object CustomOptions { get; set; }
	public object JavaPackage { get; set; }
	public object JavaOuterClassname { get; set; }
	public object JavaMultipleFiles { get; set; }
	public object JavaGenerateEqualsAndHash { get; set; }
	public object JavaStringCheckUtf8 { get; set; }
	public object OptimizeFor { get; }
	public object GoPackage { get; set; }
	public object CcGenericServices { get; set; }
	public object JavaGenericServices { get; set; }
	public object PyGenericServices { get; set; }
	public object PhpGenericServices { get; set; }
	public object Deprecated { get; set; }
	public object CcEnableArenas { get; set; }
	public object ObjcClassPrefix { get; set; }
	public object CsharpNamespace { get; set; }
	public object SwiftPrefix { get; set; }
	public object PhpClassPrefix { get; set; }
	public object PhpNamespace { get; set; }
	public object PhpMetadataNamespace { get; set; }
	public object RubyPackage { get; set; }

	// Methods

	// RVA: 0x364EA44
	public static object get_Parser() { }

	// RVA: 0x364EAC0
	public static object get_Descriptor() { }

	// RVA: 0x364EC2C
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x364EC94
	internal object get_CustomOptions() { }

	// RVA: 0x364EC9C
	private object set_CustomOptions(object value) { }

	// RVA: 0x36442D4
	public object .ctor() { }

	// RVA: 0x364ECA4
	public object get_JavaPackage() { }

	// RVA: 0x364ECAC
	public object set_JavaPackage(object value) { }

	// RVA: 0x364ED2C
	public object get_JavaOuterClassname() { }

	// RVA: 0x364ED34
	public object set_JavaOuterClassname(object value) { }

	// RVA: 0x364EDB4
	public object get_JavaMultipleFiles() { }

	// RVA: 0x364EDBC
	public object set_JavaMultipleFiles(object value) { }

	// RVA: 0x364EDC4
	public object get_JavaGenerateEqualsAndHash() { }

	// RVA: 0x364EDCC
	public object set_JavaGenerateEqualsAndHash(object value) { }

	// RVA: 0x364EDD4
	public object get_JavaStringCheckUtf8() { }

	// RVA: 0x364EDDC
	public object set_JavaStringCheckUtf8(object value) { }

	// RVA: 0x364EDE4
	public object get_OptimizeFor() { }

	// RVA: 0x364EDEC
	public object get_GoPackage() { }

	// RVA: 0x364EDF4
	public object set_GoPackage(object value) { }

	// RVA: 0x364EE74
	public object get_CcGenericServices() { }

	// RVA: 0x364EE7C
	public object set_CcGenericServices(object value) { }

	// RVA: 0x364EE84
	public object get_JavaGenericServices() { }

	// RVA: 0x364EE8C
	public object set_JavaGenericServices(object value) { }

	// RVA: 0x364EE94
	public object get_PyGenericServices() { }

	// RVA: 0x364EE9C
	public object set_PyGenericServices(object value) { }

	// RVA: 0x364EEA4
	public object get_PhpGenericServices() { }

	// RVA: 0x364EEAC
	public object set_PhpGenericServices(object value) { }

	// RVA: 0x364EEB4
	public object get_Deprecated() { }

	// RVA: 0x364EEBC
	public object set_Deprecated(object value) { }

	// RVA: 0x364EEC4
	public object get_CcEnableArenas() { }

	// RVA: 0x364EECC
	public object set_CcEnableArenas(object value) { }

	// RVA: 0x364EED4
	public object get_ObjcClassPrefix() { }

	// RVA: 0x364EEDC
	public object set_ObjcClassPrefix(object value) { }

	// RVA: 0x364EF5C
	public object get_CsharpNamespace() { }

	// RVA: 0x364EF64
	public object set_CsharpNamespace(object value) { }

	// RVA: 0x364EFE4
	public object get_SwiftPrefix() { }

	// RVA: 0x364EFEC
	public object set_SwiftPrefix(object value) { }

	// RVA: 0x364F06C
	public object get_PhpClassPrefix() { }

	// RVA: 0x364F074
	public object set_PhpClassPrefix(object value) { }

	// RVA: 0x364F0F4
	public object get_PhpNamespace() { }

	// RVA: 0x364F0FC
	public object set_PhpNamespace(object value) { }

	// RVA: 0x364F17C
	public object get_PhpMetadataNamespace() { }

	// RVA: 0x364F184
	public object set_PhpMetadataNamespace(object value) { }

	// RVA: 0x364F204
	public object get_RubyPackage() { }

	// RVA: 0x364F20C
	public object set_RubyPackage(object value) { }

	// RVA: 0x364F28C
	public override object Equals(object other) { }

	// RVA: 0x364F30C
	public object Equals(object other) { }

	// RVA: 0x364F53C
	public override object GetHashCode() { }

	// RVA: 0x364FB30
	public override object ToString() { }

	// RVA: 0x364FBB8
	public object WriteTo(object output) { }

	// RVA: 0x3650204
	public object CalculateSize() { }

	// RVA: 0x3650654
	public object MergeFrom(object input) { }

	// RVA: 0x3650C24
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3651B0C
	private static object .cctor() { }

	// RVA: 0x3651B6C
	public object .ctor() { }

	// RVA: 0x3651B74
	internal object <.cctor>b__49_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class MessageOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object <CustomOptions>k__BackingField; // 0x10
	private object messageSetWireFormat_; // 0x18
	private object noStandardDescriptorAccessor_; // 0x19
	private object deprecated_; // 0x1A
	private object mapEntry_; // 0x1B
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x20

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	internal object CustomOptions { get; set; }
	public object MessageSetWireFormat { get; set; }
	public object NoStandardDescriptorAccessor { get; set; }
	public object Deprecated { get; set; }
	public object MapEntry { get; set; }

	// Methods

	// RVA: 0x3650EA8
	public static object get_Parser() { }

	// RVA: 0x3650F24
	public static object get_Descriptor() { }

	// RVA: 0x3651090
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x36510F8
	internal object get_CustomOptions() { }

	// RVA: 0x3651100
	private object set_CustomOptions(object value) { }

	// RVA: 0x3645ED4
	public object .ctor() { }

	// RVA: 0x3651108
	public object get_MessageSetWireFormat() { }

	// RVA: 0x3651110
	public object set_MessageSetWireFormat(object value) { }

	// RVA: 0x3651118
	public object get_NoStandardDescriptorAccessor() { }

	// RVA: 0x3651120
	public object set_NoStandardDescriptorAccessor(object value) { }

	// RVA: 0x3651128
	public object get_Deprecated() { }

	// RVA: 0x3651130
	public object set_Deprecated(object value) { }

	// RVA: 0x3651138
	public object get_MapEntry() { }

	// RVA: 0x3651140
	public object set_MapEntry(object value) { }

	// RVA: 0x3651148
	public override object Equals(object other) { }

	// RVA: 0x36511C8
	public object Equals(object other) { }

	// RVA: 0x36512D0
	public override object GetHashCode() { }

	// RVA: 0x3651488
	public override object ToString() { }

	// RVA: 0x3651510
	public object WriteTo(object output) { }

	// RVA: 0x36516C4
	public object CalculateSize() { }

	// RVA: 0x36517BC
	public object MergeFrom(object input) { }

	// RVA: 0x3651944
	private static object .cctor() { }

}

// Namespace: 
internal enum CType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object String;
	public const object Cord;
	public const object StringPiece;
}

// Namespace: 
internal enum JSType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object JsNormal;
	public const object JsString;
	public const object JsNumber;
}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x36529DC
	private static object .cctor() { }

	// RVA: 0x3652A3C
	public object .ctor() { }

	// RVA: 0x3652A44
	internal object <.cctor>b__60_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class FieldOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object <CustomOptions>k__BackingField; // 0x10
	private object ctype_; // 0x18
	private object packed_; // 0x1C
	private object jstype_; // 0x20
	private object lazy_; // 0x24
	private object deprecated_; // 0x25
	private object weak_; // 0x26
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x28

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	internal object CustomOptions { get; set; }
	public object Ctype { get; }
	public object Packed { get; set; }
	public object Jstype { get; }
	public object Lazy { get; set; }
	public object Deprecated { get; set; }
	public object Weak { get; set; }

	// Methods

	// RVA: 0x3651BC8
	public static object get_Parser() { }

	// RVA: 0x3651C44
	public static object get_Descriptor() { }

	// RVA: 0x3651DB0
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3651E18
	internal object get_CustomOptions() { }

	// RVA: 0x3651E20
	private object set_CustomOptions(object value) { }

	// RVA: 0x3649588
	public object .ctor() { }

	// RVA: 0x3651E28
	private object OnConstruction() { }

	// RVA: 0x3651E34
	public object get_Ctype() { }

	// RVA: 0x3651E3C
	public object get_Packed() { }

	// RVA: 0x3651E44
	public object set_Packed(object value) { }

	// RVA: 0x3651E4C
	public object get_Jstype() { }

	// RVA: 0x3651E54
	public object get_Lazy() { }

	// RVA: 0x3651E5C
	public object set_Lazy(object value) { }

	// RVA: 0x3651E64
	public object get_Deprecated() { }

	// RVA: 0x3651E6C
	public object set_Deprecated(object value) { }

	// RVA: 0x3651E74
	public object get_Weak() { }

	// RVA: 0x3651E7C
	public object set_Weak(object value) { }

	// RVA: 0x3651E84
	public override object Equals(object other) { }

	// RVA: 0x3651F04
	public object Equals(object other) { }

	// RVA: 0x365202C
	public override object GetHashCode() { }

	// RVA: 0x3652230
	public override object ToString() { }

	// RVA: 0x36522B8
	public object WriteTo(object output) { }

	// RVA: 0x36524DC
	public object CalculateSize() { }

	// RVA: 0x365264C
	public object MergeFrom(object input) { }

	// RVA: 0x3652814
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x365341C
	private static object .cctor() { }

	// RVA: 0x365347C
	public object .ctor() { }

	// RVA: 0x3653484
	internal object <.cctor>b__29_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class OneofOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object <CustomOptions>k__BackingField; // 0x10
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x18

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	internal object CustomOptions { get; set; }

	// Methods

	// RVA: 0x3652A98
	public static object get_Parser() { }

	// RVA: 0x3652B14
	public static object get_Descriptor() { }

	// RVA: 0x3652C80
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3652CE8
	internal object get_CustomOptions() { }

	// RVA: 0x3652CF0
	private object set_CustomOptions(object value) { }

	// RVA: 0x364A14C
	public object .ctor() { }

	// RVA: 0x3652CF8
	public override object Equals(object other) { }

	// RVA: 0x3652DE8
	public object Equals(object other) { }

	// RVA: 0x3652E9C
	public override object GetHashCode() { }

	// RVA: 0x3652F28
	public override object ToString() { }

	// RVA: 0x3652FB0
	public object WriteTo(object output) { }

	// RVA: 0x3653088
	public object CalculateSize() { }

	// RVA: 0x3653154
	public object MergeFrom(object input) { }

	// RVA: 0x3653254
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3654048
	private static object .cctor() { }

	// RVA: 0x36540A8
	public object .ctor() { }

	// RVA: 0x36540B0
	internal object <.cctor>b__39_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class EnumOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object <CustomOptions>k__BackingField; // 0x10
	private object allowAlias_; // 0x18
	private object deprecated_; // 0x19
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x20

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	internal object CustomOptions { get; set; }
	public object AllowAlias { get; set; }
	public object Deprecated { get; set; }

	// Methods

	// RVA: 0x36534D8
	public static object get_Parser() { }

	// RVA: 0x3653554
	public static object get_Descriptor() { }

	// RVA: 0x36536C0
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3653728
	internal object get_CustomOptions() { }

	// RVA: 0x3653730
	private object set_CustomOptions(object value) { }

	// RVA: 0x364B254
	public object .ctor() { }

	// RVA: 0x3653738
	public object get_AllowAlias() { }

	// RVA: 0x3653740
	public object set_AllowAlias(object value) { }

	// RVA: 0x3653748
	public object get_Deprecated() { }

	// RVA: 0x3653750
	public object set_Deprecated(object value) { }

	// RVA: 0x3653758
	public override object Equals(object other) { }

	// RVA: 0x365387C
	public object Equals(object other) { }

	// RVA: 0x3653964
	public override object GetHashCode() { }

	// RVA: 0x3653AA4
	public override object ToString() { }

	// RVA: 0x3653B2C
	public object WriteTo(object output) { }

	// RVA: 0x3653C68
	public object CalculateSize() { }

	// RVA: 0x3653D40
	public object MergeFrom(object input) { }

	// RVA: 0x3653E80
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3654BAC
	private static object .cctor() { }

	// RVA: 0x3654C0C
	public object .ctor() { }

	// RVA: 0x3654C14
	internal object <.cctor>b__34_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class EnumValueOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object <CustomOptions>k__BackingField; // 0x10
	private object deprecated_; // 0x18
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x20

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	internal object CustomOptions { get; set; }
	public object Deprecated { get; set; }

	// Methods

	// RVA: 0x3654104
	public static object get_Parser() { }

	// RVA: 0x3654180
	public static object get_Descriptor() { }

	// RVA: 0x36542EC
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3654354
	internal object get_CustomOptions() { }

	// RVA: 0x365435C
	private object set_CustomOptions(object value) { }

	// RVA: 0x364C820
	public object .ctor() { }

	// RVA: 0x3654364
	public object get_Deprecated() { }

	// RVA: 0x365436C
	public object set_Deprecated(object value) { }

	// RVA: 0x3654374
	public override object Equals(object other) { }

	// RVA: 0x3654488
	public object Equals(object other) { }

	// RVA: 0x3654560
	public override object GetHashCode() { }

	// RVA: 0x3654678
	public override object ToString() { }

	// RVA: 0x3654700
	public object WriteTo(object output) { }

	// RVA: 0x3654800
	public object CalculateSize() { }

	// RVA: 0x36548C8
	public object MergeFrom(object input) { }

	// RVA: 0x36549E4
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3655714
	private static object .cctor() { }

	// RVA: 0x3655774
	public object .ctor() { }

	// RVA: 0x365577C
	internal object <.cctor>b__34_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class ServiceOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object <CustomOptions>k__BackingField; // 0x10
	private object deprecated_; // 0x18
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x20

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	internal object CustomOptions { get; set; }
	public object Deprecated { get; set; }

	// Methods

	// RVA: 0x3654C68
	public static object get_Parser() { }

	// RVA: 0x3654CE4
	public static object get_Descriptor() { }

	// RVA: 0x3654E50
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3654EB8
	internal object get_CustomOptions() { }

	// RVA: 0x3654EC0
	private object set_CustomOptions(object value) { }

	// RVA: 0x364D5D0
	public object .ctor() { }

	// RVA: 0x3654EC8
	public object get_Deprecated() { }

	// RVA: 0x3654ED0
	public object set_Deprecated(object value) { }

	// RVA: 0x3654ED8
	public override object Equals(object other) { }

	// RVA: 0x3654FEC
	public object Equals(object other) { }

	// RVA: 0x36550C4
	public override object GetHashCode() { }

	// RVA: 0x36551DC
	public override object ToString() { }

	// RVA: 0x3655264
	public object WriteTo(object output) { }

	// RVA: 0x3655368
	public object CalculateSize() { }

	// RVA: 0x3655430
	public object MergeFrom(object input) { }

	// RVA: 0x365554C
	private static object .cctor() { }

}

// Namespace: 
internal enum IdempotencyLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IdempotencyUnknown;
	public const object NoSideEffects;
	public const object Idempotent;
}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x365636C
	private static object .cctor() { }

	// RVA: 0x36563CC
	public object .ctor() { }

	// RVA: 0x36563D4
	internal object <.cctor>b__40_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class MethodOptions
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object <CustomOptions>k__BackingField; // 0x10
	private object deprecated_; // 0x18
	private object idempotencyLevel_; // 0x1C
	private static readonly object _repeated_uninterpretedOption_codec; // 0x8
	private readonly object uninterpretedOption_; // 0x20

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	internal object CustomOptions { get; set; }
	public object Deprecated { get; set; }
	public object IdempotencyLevel { get; }

	// Methods

	// RVA: 0x36557D0
	public static object get_Parser() { }

	// RVA: 0x365584C
	public static object get_Descriptor() { }

	// RVA: 0x36559B8
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3655A20
	internal object get_CustomOptions() { }

	// RVA: 0x3655A28
	private object set_CustomOptions(object value) { }

	// RVA: 0x364E780
	public object .ctor() { }

	// RVA: 0x3655A30
	public object get_Deprecated() { }

	// RVA: 0x3655A38
	public object set_Deprecated(object value) { }

	// RVA: 0x3655A40
	public object get_IdempotencyLevel() { }

	// RVA: 0x3655A48
	public override object Equals(object other) { }

	// RVA: 0x3655B6C
	public object Equals(object other) { }

	// RVA: 0x3655C54
	public override object GetHashCode() { }

	// RVA: 0x3655D94
	public override object ToString() { }

	// RVA: 0x3655E1C
	public object WriteTo(object output) { }

	// RVA: 0x3655F5C
	public object CalculateSize() { }

	// RVA: 0x3656064
	public object MergeFrom(object input) { }

	// RVA: 0x36561A4
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3658138
	private static object .cctor() { }

	// RVA: 0x3658198
	public object .ctor() { }

	// RVA: 0x36581A0
	internal object <.cctor>b__30_0() { }

}

// Namespace: 
internal sealed class NamePart
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private object namePart_; // 0x10
	private object isExtension_; // 0x18

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object NamePart_ { get; set; }
	public object IsExtension { get; set; }

	// Methods

	// RVA: 0x3657804
	public static object get_Parser() { }

	// RVA: 0x3657880
	public static object get_Descriptor() { }

	// RVA: 0x3657998
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3657A00
	public object .ctor() { }

	// RVA: 0x3657A60
	public object get_NamePart_() { }

	// RVA: 0x3657A68
	public object set_NamePart_(object value) { }

	// RVA: 0x3657AE8
	public object get_IsExtension() { }

	// RVA: 0x3657AF0
	public object set_IsExtension(object value) { }

	// RVA: 0x3657AF8
	public override object Equals(object other) { }

	// RVA: 0x3657BBC
	public object Equals(object other) { }

	// RVA: 0x3657C38
	public override object GetHashCode() { }

	// RVA: 0x3657D44
	public override object ToString() { }

	// RVA: 0x3657DCC
	public object WriteTo(object output) { }

	// RVA: 0x3657E90
	public object CalculateSize() { }

	// RVA: 0x3657F38
	public object MergeFrom(object input) { }

	// RVA: 0x3658028
	private static object .cctor() { }

}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3658234
	private static object .cctor() { }

	// RVA: 0x3658294
	public object .ctor() { }

	// RVA: 0x365829C
	internal object <.cctor>b__56_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class UninterpretedOption
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_name_codec; // 0x8
	private readonly object name_; // 0x10
	private object identifierValue_; // 0x18
	private object positiveIntValue_; // 0x20
	private object negativeIntValue_; // 0x28
	private object doubleValue_; // 0x30
	private object stringValue_; // 0x38
	private object aggregateValue_; // 0x40

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object IdentifierValue { get; set; }
	public object PositiveIntValue { get; set; }
	public object NegativeIntValue { get; set; }
	public object DoubleValue { get; set; }
	public object StringValue { get; set; }
	public object AggregateValue { get; set; }

	// Methods

	// RVA: 0x3656428
	public static object get_Parser() { }

	// RVA: 0x36564A4
	public static object get_Descriptor() { }

	// RVA: 0x3656610
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3656678
	public object .ctor() { }

	// RVA: 0x365679C
	public object get_IdentifierValue() { }

	// RVA: 0x36567A4
	public object set_IdentifierValue(object value) { }

	// RVA: 0x3656824
	public object get_PositiveIntValue() { }

	// RVA: 0x365682C
	public object set_PositiveIntValue(object value) { }

	// RVA: 0x3656834
	public object get_NegativeIntValue() { }

	// RVA: 0x365683C
	public object set_NegativeIntValue(object value) { }

	// RVA: 0x3656844
	public object get_DoubleValue() { }

	// RVA: 0x365684C
	public object set_DoubleValue(object value) { }

	// RVA: 0x3656854
	public object get_StringValue() { }

	// RVA: 0x365685C
	public object set_StringValue(object value) { }

	// RVA: 0x36568DC
	public object get_AggregateValue() { }

	// RVA: 0x36568E4
	public object set_AggregateValue(object value) { }

	// RVA: 0x3656964
	public override object Equals(object other) { }

	// RVA: 0x36569E4
	public object Equals(object other) { }

	// RVA: 0x3656BFC
	public override object GetHashCode() { }

	// RVA: 0x3656EA4
	public override object ToString() { }

	// RVA: 0x3656F2C
	public object WriteTo(object output) { }

	// RVA: 0x3657198
	public object CalculateSize() { }

	// RVA: 0x36573B8
	public object MergeFrom(object input) { }

	// RVA: 0x365763C
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3659C24
	private static object .cctor() { }

	// RVA: 0x3659C84
	public object .ctor() { }

	// RVA: 0x3659C8C
	internal object <.cctor>b__45_0() { }

}

// Namespace: 
internal sealed class Location
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_path_codec; // 0x8
	private readonly object path_; // 0x10
	private static readonly object _repeated_span_codec; // 0x10
	private readonly object span_; // 0x18
	private object leadingComments_; // 0x20
	private object trailingComments_; // 0x28
	private static readonly object _repeated_leadingDetachedComments_codec; // 0x18
	private readonly object leadingDetachedComments_; // 0x30

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object LeadingComments { get; set; }
	public object TrailingComments { get; set; }

	// Methods

	// RVA: 0x3658C54
	public static object get_Parser() { }

	// RVA: 0x3658CD0
	public static object get_Descriptor() { }

	// RVA: 0x3658DE8
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3658E50
	public object .ctor() { }

	// RVA: 0x3658F54
	public object get_LeadingComments() { }

	// RVA: 0x3658F5C
	public object set_LeadingComments(object value) { }

	// RVA: 0x3658FDC
	public object get_TrailingComments() { }

	// RVA: 0x3658FE4
	public object set_TrailingComments(object value) { }

	// RVA: 0x3659064
	public override object Equals(object other) { }

	// RVA: 0x36590E4
	public object Equals(object other) { }

	// RVA: 0x3659230
	public override object GetHashCode() { }

	// RVA: 0x36593C8
	public override object ToString() { }

	// RVA: 0x3659450
	public object WriteTo(object output) { }

	// RVA: 0x365964C
	public object CalculateSize() { }

	// RVA: 0x3659848
	public object MergeFrom(object input) { }

	// RVA: 0x3659ACC
	private static object .cctor() { }

}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3659CE4
	private static object .cctor() { }

	// RVA: 0x3659D44
	public object .ctor() { }

	// RVA: 0x3659D4C
	internal object <.cctor>b__26_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class SourceCodeInfo
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_location_codec; // 0x8
	private readonly object location_; // 0x10

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }

	// Methods

	// RVA: 0x36582F0
	public static object get_Parser() { }

	// RVA: 0x365836C
	public static object get_Descriptor() { }

	// RVA: 0x36584D8
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x36443C0
	public object .ctor() { }

	// RVA: 0x3658540
	public override object Equals(object other) { }

	// RVA: 0x3658630
	public object Equals(object other) { }

	// RVA: 0x36586E4
	public override object GetHashCode() { }

	// RVA: 0x3658770
	public override object ToString() { }

	// RVA: 0x36587F8
	public object WriteTo(object output) { }

	// RVA: 0x36588D0
	public object CalculateSize() { }

	// RVA: 0x365899C
	public object MergeFrom(object input) { }

	// RVA: 0x3658A8C
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x365B3C4
	private static object .cctor() { }

	// RVA: 0x365B424
	public object .ctor() { }

	// RVA: 0x365B42C
	internal object <.cctor>b__40_0() { }

}

// Namespace: 
internal sealed class Annotation
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_path_codec; // 0x8
	private readonly object path_; // 0x10
	private object sourceFile_; // 0x18
	private object begin_; // 0x20
	private object end_; // 0x24

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }
	public object SourceFile { get; set; }
	public object Begin { get; set; }
	public object End { get; set; }

	// Methods

	// RVA: 0x365A788
	public static object get_Parser() { }

	// RVA: 0x365A804
	public static object get_Descriptor() { }

	// RVA: 0x365A91C
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x365A984
	public object .ctor() { }

	// RVA: 0x365AA24
	public object get_SourceFile() { }

	// RVA: 0x365AA2C
	public object set_SourceFile(object value) { }

	// RVA: 0x365AAAC
	public object get_Begin() { }

	// RVA: 0x365AAB4
	public object set_Begin(object value) { }

	// RVA: 0x365AABC
	public object get_End() { }

	// RVA: 0x365AAC4
	public object set_End(object value) { }

	// RVA: 0x365AACC
	public override object Equals(object other) { }

	// RVA: 0x365AB4C
	public object Equals(object other) { }

	// RVA: 0x365AC34
	public override object GetHashCode() { }

	// RVA: 0x365AD50
	public override object ToString() { }

	// RVA: 0x365ADD8
	public object WriteTo(object output) { }

	// RVA: 0x365AF6C
	public object CalculateSize() { }

	// RVA: 0x365B0E4
	public object MergeFrom(object input) { }

	// RVA: 0x365B29C
	private static object .cctor() { }

}

// Namespace: 
public static class Types
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x365B504
	private static object .cctor() { }

	// RVA: 0x365B564
	public object .ctor() { }

	// RVA: 0x365B56C
	internal object <.cctor>b__26_0() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class GeneratedCodeInfo
{

	// Fields
	private static readonly object _parser; // 0x0
	private object _unknownFields; // 0x8
	private static readonly object _repeated_annotation_codec; // 0x8
	private readonly object annotation_; // 0x10

	// Properties
	public static object Parser { get; }
	public static object Descriptor { get; }
	private object pb::Google.Protobuf.IMessage.Descriptor { get; }

	// Methods

	// RVA: 0x3659DA4
	public static object get_Parser() { }

	// RVA: 0x3659E20
	public static object get_Descriptor() { }

	// RVA: 0x3659F8C
	private object pb::Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: 0x3659FF4
	public object .ctor() { }

	// RVA: 0x365A074
	public override object Equals(object other) { }

	// RVA: 0x365A164
	public object Equals(object other) { }

	// RVA: 0x365A218
	public override object GetHashCode() { }

	// RVA: 0x365A2A4
	public override object ToString() { }

	// RVA: 0x365A32C
	public object WriteTo(object output) { }

	// RVA: 0x365A404
	public object CalculateSize() { }

	// RVA: 0x365A4D0
	public object MergeFrom(object input) { }

	// RVA: 0x365A5C0
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.Reflection
public abstract class DescriptorBase
{

	// Fields
	private readonly object file; // 0x8
	private readonly object fullName; // 0x10
	private readonly object index; // 0x18

	// Properties
	public abstract object Name { get; }
	public object FullName { get; }
	public object File { get; }

	// Methods

	// RVA: 0x365B624
	internal object .ctor(object file, object fullName, object index) { }

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: 0x365B664
	public object get_FullName() { }

	// RVA: 0x365B66C
	public object get_File() { }

}

// Namespace: 
private struct DescriptorIntPair
{

	// Fields
	private readonly object number; // 0xFFFFFFFFFFFFFFF8
	private readonly object descriptor; // 0x0

	// Methods

	// RVA: 0x365CB4C
	internal object .ctor(object descriptor, object number) { }

	// RVA: 0x365D5AC
	public object Equals(object other) { }

	// RVA: 0x365D5F4
	public override object Equals(object obj) { }

	// RVA: 0x365D75C
	public override object GetHashCode() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class DescriptorPool
{

	// Fields
	private readonly object descriptorsByName; // 0x8
	private readonly object fieldsByNumber; // 0x10
	private readonly object enumValuesByNumber; // 0x18
	private readonly object dependencies; // 0x20
	private static readonly object ValidationRegex; // 0x0

	// Methods

	// RVA: 0x365B674
	internal object .ctor(object dependencyFiles) { }

	// RVA: 0x365B8A8
	private object ImportPublicDependencies(object file) { }

	// RVA: -1
	internal object FindSymbol(object fullName) { }

	// RVA: 0x365BC68
	internal object AddPackage(object fullName, object file) { }

	// RVA: 0x365C254
	internal object AddSymbol(object descriptor) { }

	// RVA: 0x365C7A0
	private static object ValidateSymbolName(object descriptor) { }

	// RVA: 0x365CA4C
	internal object FindFieldByNumber(object messageDescriptor, object number) { }

	// RVA: 0x365CB58
	internal object AddFieldByNumber(object field) { }

	// RVA: 0x365CF18
	internal object AddEnumValueByNumber(object enumValue) { }

	// RVA: 0x365D10C
	internal object LookupSymbol(object name, object relativeTo) { }

	// RVA: 0x365D49C
	private static object .cctor() { }

}

// Namespace: 
internal sealed class IndexedConverter<T0, T1>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object element, object index) { }

}

// Namespace: Google.Protobuf.Reflection
internal static class DescriptorUtil
{

	// Methods

	// RVA: -1
	internal static object ConvertAndMakeReadOnly(object input, object converter) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class DescriptorValidationException
{

	// Fields
	private readonly object name; // 0x88
	private readonly object description; // 0x90

	// Methods

	// RVA: 0x365C058
	internal object .ctor(object problemDescriptor, object description) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object file; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x365DA84
	public object .ctor() { }

	// RVA: 0x365DB78
	internal object <.ctor>b__0(object value, object i) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class EnumDescriptor
{

	// Fields
	private readonly object proto; // 0x20
	private readonly object containingType; // 0x28
	private readonly object values; // 0x30
	private readonly object clrType; // 0x38

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x365D81C
	internal object .ctor(object proto, object file, object parent, object index, object clrType) { }

	// RVA: 0x365DB54
	public override object get_Name() { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class EnumValueDescriptor
{

	// Fields
	private readonly object enumDescriptor; // 0x20
	private readonly object proto; // 0x28

	// Properties
	internal object Proto { get; }
	public override object Name { get; }
	public object Number { get; }
	public object EnumDescriptor { get; }

	// Methods

	// RVA: 0x365DBFC
	internal object .ctor(object proto, object file, object parent, object index) { }

	// RVA: 0x365DCF4
	internal object get_Proto() { }

	// RVA: 0x365DCFC
	public override object get_Name() { }

	// RVA: 0x365D0E8
	public object get_Number() { }

	// RVA: 0x365DD20
	public object get_EnumDescriptor() { }

}

// Namespace: Google.Protobuf.Reflection
internal abstract class FieldAccessorBase
{

	// Fields
	private readonly object getValueDelegate; // 0x8
	private readonly object descriptor; // 0x10

	// Properties
	public object Descriptor { get; }

	// Methods

	// RVA: 0x365DD28
	internal object .ctor(object property, object descriptor) { }

	// RVA: 0x365DF4C
	public object get_Descriptor() { }

	// RVA: 0x365DF54
	public object GetValue(object message) { }

	// RVA: -1
	public abstract object SetValue(object message, object value) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class FieldDescriptor
{

	// Fields
	private object enumType; // 0x20
	private object messageType; // 0x28
	private object fieldType; // 0x30
	public readonly object propertyName; // 0x38
	private object accessor; // 0x40
	private readonly object <ContainingType>k__BackingField; // 0x48
	private readonly object <ContainingOneof>k__BackingField; // 0x50
	private readonly object <JsonName>k__BackingField; // 0x58
	private readonly object <Proto>k__BackingField; // 0x60

	// Properties
	public object ContainingType { get; }
	public object ContainingOneof { get; }
	public object JsonName { get; }
	internal object Proto { get; }
	public override object Name { get; }
	public object Accessor { get; }
	public object IsRepeated { get; }
	public object IsMap { get; }
	public object FieldType { get; }
	public object FieldNumber { get; }

	// Methods

	// RVA: 0x365DF80
	public object get_ContainingType() { }

	// RVA: 0x365DF88
	public object get_ContainingOneof() { }

	// RVA: 0x365DF90
	public object get_JsonName() { }

	// RVA: 0x365DF98
	internal object get_Proto() { }

	// RVA: 0x365DFA0
	internal object .ctor(object proto, object file, object parent, object index, object propertyName) { }

	// RVA: 0x365E3D4
	public override object get_Name() { }

	// RVA: 0x365E3F8
	public object get_Accessor() { }

	// RVA: 0x365E364
	private static object GetFieldTypeFromProtoType(object type) { }

	// RVA: 0x365E400
	public object get_IsRepeated() { }

	// RVA: 0x365E42C
	public object get_IsMap() { }

	// RVA: 0x365E490
	public object get_FieldType() { }

	// RVA: 0x365CEF4
	public object get_FieldNumber() { }

	// RVA: 0x365E498
	public object CompareTo(object other) { }

	// RVA: 0x365E534
	internal object CrossLink() { }

	// RVA: 0x365E904
	private object CreateAccessor() { }

}

// Namespace: Google.Protobuf.Reflection
public enum FieldType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Double;
	public const object Float;
	public const object Int64;
	public const object UInt64;
	public const object Int32;
	public const object Fixed64;
	public const object Fixed32;
	public const object Bool;
	public const object String;
	public const object Group;
	public const object Message;
	public const object Bytes;
	public const object UInt32;
	public const object SFixed32;
	public const object SFixed64;
	public const object SInt32;
	public const object SInt64;
	public const object Enum;
}

// Namespace: 
private sealed class <>c__DisplayClass1_0
{

	// Fields
	public object <>4__this; // 0x8
	public object generatedCodeInfo; // 0x10

	// Methods

	// RVA: 0x365F4D4
	public object .ctor() { }

	// RVA: 0x36611FC
	internal object <.ctor>b__0(object message, object index) { }

	// RVA: 0x36617CC
	internal object <.ctor>b__1(object enumType, object index) { }

	// RVA: 0x366188C
	internal object <.ctor>b__2(object service, object index) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class FileDescriptor
{

	// Fields
	private readonly object <Proto>k__BackingField; // 0x8
	private readonly object <MessageTypes>k__BackingField; // 0x10
	private readonly object <EnumTypes>k__BackingField; // 0x18
	private readonly object <Services>k__BackingField; // 0x20
	private readonly object <Dependencies>k__BackingField; // 0x28
	private readonly object <PublicDependencies>k__BackingField; // 0x30
	private readonly object <SerializedData>k__BackingField; // 0x38
	private readonly object <DescriptorPool>k__BackingField; // 0x40

	// Properties
	internal object Proto { get; }
	public object Name { get; }
	public object Package { get; }
	public object MessageTypes { get; }
	public object Services { get; }
	public object PublicDependencies { get; }
	private object Google.Protobuf.Reflection.IDescriptor.FullName { get; }
	private object Google.Protobuf.Reflection.IDescriptor.File { get; }
	internal object DescriptorPool { get; }

	// Methods

	// RVA: 0x365F028
	private static object .cctor() { }

	// RVA: 0x365F1A4
	private object .ctor(object descriptorData, object proto, object dependencies, object pool, object allowUnknownDependencies, object generatedCodeInfo) { }

	// RVA: 0x365DA8C
	internal object ComputeFullName(object parent, object name) { }

	// RVA: 0x365F4DC
	private static object DeterminePublicDependencies(object this, object proto, object dependencies, object allowUnknownDependencies) { }

	// RVA: 0x365FA8C
	internal object get_Proto() { }

	// RVA: 0x365C034
	public object get_Name() { }

	// RVA: 0x365BC44
	public object get_Package() { }

	// RVA: 0x365FA94
	public object get_MessageTypes() { }

	// RVA: 0x365FA9C
	public object get_Services() { }

	// RVA: 0x365FAA4
	public object get_PublicDependencies() { }

	// RVA: 0x365FAAC
	private object Google.Protobuf.Reflection.IDescriptor.get_FullName() { }

	// RVA: 0x365FAD0
	private object Google.Protobuf.Reflection.IDescriptor.get_File() { }

	// RVA: 0x365FAD4
	internal object get_DescriptorPool() { }

	// RVA: 0x365FADC
	private static object BuildFrom(object descriptorData, object proto, object dependencies, object allowUnknownDependencies, object generatedCodeInfo) { }

	// RVA: 0x365FC74
	private object CrossLink() { }

	// RVA: 0x3660E80
	public static object FromGeneratedCode(object descriptorData, object dependencies, object generatedCodeInfo) { }

	// RVA: 0x3661198
	public override object ToString() { }

	// RVA: -1
	public static object ForceReflectionInitialization() { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class GeneratedClrTypeInfo
{

	// Fields
	private static readonly object EmptyNames; // 0x0
	private static readonly object EmptyCodeInfo; // 0x8
	private object <ClrType>k__BackingField; // 0x8
	private readonly object <Parser>k__BackingField; // 0x10
	private readonly object <PropertyNames>k__BackingField; // 0x18
	private readonly object <OneofNames>k__BackingField; // 0x20
	private readonly object <NestedTypes>k__BackingField; // 0x28
	private readonly object <NestedEnums>k__BackingField; // 0x30

	// Properties
	public object ClrType { get; set; }
	public object Parser { get; }
	public object PropertyNames { get; }
	public object OneofNames { get; }
	public object NestedTypes { get; }
	public object NestedEnums { get; }

	// Methods

	// RVA: 0x3661AF0
	public object get_ClrType() { }

	// RVA: 0x3661AF8
	private object set_ClrType(object value) { }

	// RVA: 0x3661B00
	public object get_Parser() { }

	// RVA: 0x3661B08
	public object get_PropertyNames() { }

	// RVA: 0x3661B10
	public object get_OneofNames() { }

	// RVA: 0x3661B18
	public object get_NestedTypes() { }

	// RVA: 0x3661B20
	public object get_NestedEnums() { }

	// RVA: 0x3661B28
	public object .ctor(object clrType, object parser, object propertyNames, object oneofNames, object nestedEnums, object nestedTypes) { }

	// RVA: 0x3661CD8
	public object .ctor(object nestedEnums, object nestedTypes) { }

	// RVA: 0x3661CF4
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.Reflection
public interface IDescriptor
{

	// Properties
	public abstract object Name { get; }
	public abstract object FullName { get; }
	public abstract object File { get; }

	// Methods

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: -1
	public abstract object get_FullName() { }

	// RVA: -1
	public abstract object get_File() { }

}

// Namespace: Google.Protobuf.Reflection
public interface IFieldAccessor
{

	// Properties
	public abstract object Descriptor { get; }

	// Methods

	// RVA: -1
	public abstract object get_Descriptor() { }

	// RVA: -1
	public abstract object GetValue(object message) { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class MapFieldAccessor
{

	// Methods

	// RVA: 0x365EF6C
	internal object .ctor(object property, object descriptor) { }

	// RVA: 0x3661D94
	public override object SetValue(object message, object value) { }

}

// Namespace: 
public sealed class FieldCollection
{

	// Fields
	private readonly object messageDescriptor; // 0x8

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x3662234
	internal object .ctor(object messageDescriptor) { }

	// RVA: 0x3662BC8
	public object InDeclarationOrder() { }

	// RVA: 0x3662BEC
	public object InFieldNumberOrder() { }

	// RVA: 0x3662C10
	public object get_Item(object number) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object file; // 0x8
	public object <>4__this; // 0x10
	public object generatedCodeInfo; // 0x18

	// Methods

	// RVA: 0x3661DE8
	public object .ctor() { }

	// RVA: 0x3662CAC
	internal object <.ctor>b__0(object oneof, object index) { }

	// RVA: 0x3662EA0
	internal object <.ctor>b__1(object type, object index) { }

	// RVA: 0x3662F68
	internal object <.ctor>b__2(object type, object index) { }

	// RVA: 0x3663030
	internal object <.ctor>b__3(object field, object index) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__4_4; // 0x8

	// Methods

	// RVA: 0x36630F4
	private static object .cctor() { }

	// RVA: 0x3663154
	public object .ctor() { }

	// RVA: 0x366315C
	internal object <.ctor>b__4_4(object field) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class MessageDescriptor
{

	// Fields
	private static readonly object WellKnownTypeNames; // 0x0
	private readonly object fieldsInDeclarationOrder; // 0x20
	private readonly object fieldsInNumberOrder; // 0x28
	private readonly object jsonFieldMap; // 0x30
	private readonly object <Proto>k__BackingField; // 0x38
	private readonly object <ClrType>k__BackingField; // 0x40
	private readonly object <Parser>k__BackingField; // 0x48
	private readonly object <ContainingType>k__BackingField; // 0x50
	private readonly object <Fields>k__BackingField; // 0x58
	private readonly object <NestedTypes>k__BackingField; // 0x60
	private readonly object <EnumTypes>k__BackingField; // 0x68
	private readonly object <Oneofs>k__BackingField; // 0x70

	// Properties
	public override object Name { get; }
	internal object Proto { get; }
	public object ClrType { get; }
	public object Parser { get; }
	internal object IsWellKnownType { get; }
	internal object IsWrapperType { get; }
	public object Fields { get; }
	public object NestedTypes { get; }
	public object Oneofs { get; }

	// Methods

	// RVA: 0x36612BC
	internal object .ctor(object proto, object file, object parent, object typeIndex, object generatedCodeInfo) { }

	// RVA: 0x3661DF0
	private static object CreateJsonFieldMap(object fields) { }

	// RVA: 0x3662260
	public override object get_Name() { }

	// RVA: 0x3662284
	internal object get_Proto() { }

	// RVA: 0x366228C
	public object get_ClrType() { }

	// RVA: 0x3662294
	public object get_Parser() { }

	// RVA: 0x366229C
	internal object get_IsWellKnownType() { }

	// RVA: 0x3662394
	internal object get_IsWrapperType() { }

	// RVA: 0x3662450
	public object get_Fields() { }

	// RVA: 0x3662458
	public object get_NestedTypes() { }

	// RVA: 0x3662460
	public object get_Oneofs() { }

	// RVA: 0x3662468
	public object FindFieldByNumber(object number) { }

	// RVA: 0x3660278
	internal object CrossLink() { }

	// RVA: 0x3662994
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class MethodDescriptor
{

	// Fields
	private readonly object proto; // 0x20
	private readonly object service; // 0x28
	private object inputType; // 0x30
	private object outputType; // 0x38

	// Properties
	internal object Proto { get; }
	public override object Name { get; }

	// Methods

	// RVA: 0x3663188
	internal object .ctor(object proto, object file, object parent, object index) { }

	// RVA: 0x3663264
	internal object get_Proto() { }

	// RVA: 0x366326C
	public override object get_Name() { }

	// RVA: 0x3663290
	internal object CrossLink() { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class OneofAccessor
{

	// Fields
	private readonly object caseDelegate; // 0x8
	private readonly object clearDelegate; // 0x10
	private object descriptor; // 0x18

	// Methods

	// RVA: 0x3663458
	internal object .ctor(object caseProperty, object clearMethod, object descriptor) { }

	// RVA: 0x3663880
	public object GetCaseFieldDescriptor(object message) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class OneofDescriptor
{

	// Fields
	private readonly object proto; // 0x20
	private object containingType; // 0x28
	private object fields; // 0x30
	private readonly object accessor; // 0x38

	// Properties
	public override object Name { get; }
	public object ContainingType { get; }
	public object Accessor { get; }

	// Methods

	// RVA: 0x3662D74
	internal object .ctor(object proto, object file, object parent, object index, object clrName) { }

	// RVA: 0x3663B00
	public override object get_Name() { }

	// RVA: 0x3663B24
	public object get_ContainingType() { }

	// RVA: 0x3663B2C
	public object get_Accessor() { }

	// RVA: 0x36624A8
	internal object CrossLink() { }

	// RVA: 0x3663920
	private object CreateAccessor(object clrName) { }

}

// Namespace: Google.Protobuf.Reflection
public class OriginalNameAttribute
{

	// Fields
	private object <Name>k__BackingField; // 0x8
	private object <PreferredAlias>k__BackingField; // 0x10

	// Properties
	public object Name { get; set; }
	public object PreferredAlias { get; set; }

	// Methods

	// RVA: 0x3663B34
	public object get_Name() { }

	// RVA: 0x3663B3C
	public object set_Name(object value) { }

	// RVA: 0x3663B44
	public object get_PreferredAlias() { }

	// RVA: 0x3663B4C
	public object set_PreferredAlias(object value) { }

	// RVA: 0x3663B54
	public object .ctor(object name) { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class PackageDescriptor
{

	// Fields
	private readonly object name; // 0x8
	private readonly object fullName; // 0x10
	private readonly object file; // 0x18

	// Properties
	public object Name { get; }
	public object FullName { get; }
	public object File { get; }

	// Methods

	// RVA: 0x365C214
	internal object .ctor(object name, object fullName, object file) { }

	// RVA: 0x3663BE8
	public object get_Name() { }

	// RVA: 0x3663BF0
	public object get_FullName() { }

	// RVA: 0x3663BF8
	public object get_File() { }

}

// Namespace: 
private interface IReflectionHelper
{

	// Methods

	// RVA: -1
	public abstract object CreateFuncIMessageInt32(object method) { }

	// RVA: -1
	public abstract object CreateActionIMessage(object method) { }

	// RVA: -1
	public abstract object CreateFuncIMessageObject(object method) { }

	// RVA: -1
	public abstract object CreateActionIMessageObject(object method) { }

}

// Namespace: 
private sealed class <>c__DisplayClass0_0
{

	// Fields
	public object del; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateFuncIMessageInt32>b__0(object message) { }

}

// Namespace: 
private sealed class <>c__DisplayClass0_1
{

	// Fields
	public object del; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateFuncIMessageInt32>b__1(object message) { }

}

// Namespace: 
private sealed class <>c__DisplayClass1_0
{

	// Fields
	public object del; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateActionIMessage>b__0(object message) { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object del; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateFuncIMessageObject>b__0(object message) { }

}

// Namespace: 
private sealed class <>c__DisplayClass3_0
{

	// Fields
	public object del; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateActionIMessageObject>b__0(object message, object arg) { }

}

// Namespace: 
private class ReflectionHelper<T0, T1>
{

	// Methods

	// RVA: -1
	public object CreateFuncIMessageInt32(object method) { }

	// RVA: -1
	public object CreateActionIMessage(object method) { }

	// RVA: -1
	public object CreateFuncIMessageObject(object method) { }

	// RVA: -1
	public object CreateActionIMessageObject(object method) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
public enum SampleEnum
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object X;
}

// Namespace: Google.Protobuf.Reflection
internal static class ReflectionUtil
{

	// Fields
	internal static readonly object EmptyTypes; // 0x0
	private static readonly object <CanConvertEnumFuncToInt32Func>k__BackingField; // 0x8

	// Properties
	private static object CanConvertEnumFuncToInt32Func { get; }

	// Methods

	// RVA: 0x3663C00
	private static object .cctor() { }

	// RVA: -1
	internal static object ForceInitialize() { }

	// RVA: 0x365DDE4
	internal static object CreateFuncIMessageObject(object method) { }

	// RVA: 0x366358C
	internal static object CreateFuncIMessageInt32(object method) { }

	// RVA: 0x36641AC
	internal static object CreateActionIMessageObject(object method) { }

	// RVA: 0x36636F0
	internal static object CreateActionIMessage(object method) { }

	// RVA: 0x3664010
	private static object GetReflectionHelper(object t1, object t2) { }

	// RVA: 0x3664368
	private static object get_CanConvertEnumFuncToInt32Func() { }

	// RVA: 0x3663E58
	private static object CheckCanConvertEnumFuncToInt32Func() { }

	// RVA: 0x3664008
	public static object SampleEnumMethod() { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class RepeatedFieldAccessor
{

	// Methods

	// RVA: 0x365EEB0
	internal object .ctor(object property, object descriptor) { }

	// RVA: 0x36643E4
	public override object SetValue(object message, object value) { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object file; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x3664438
	public object .ctor() { }

	// RVA: 0x3664464
	internal object <.ctor>b__0(object method, object i) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class ServiceDescriptor
{

	// Fields
	private readonly object proto; // 0x20
	private readonly object methods; // 0x28

	// Properties
	public override object Name { get; }

	// Methods

	// RVA: 0x366190C
	internal object .ctor(object proto, object file, object index) { }

	// RVA: 0x3664440
	public override object get_Name() { }

	// RVA: 0x3660B48
	internal object CrossLink() { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object <>4__this; // 0x8
	public object defaultValue; // 0x10

	// Methods

	// RVA: 0x36644E8
	public object .ctor() { }

	// RVA: 0x366455C
	internal object <.ctor>b__0(object message) { }

}

// Namespace: Google.Protobuf.Reflection
internal sealed class SingleFieldAccessor
{

	// Fields
	private readonly object setValueDelegate; // 0x18
	private readonly object clearDelegate; // 0x20

	// Methods

	// RVA: 0x365EB34
	internal object .ctor(object property, object descriptor) { }

	// RVA: 0x36644F0
	public override object SetValue(object message, object value) { }

}

// Namespace: Google.Protobuf.Reflection
public sealed class TypeRegistry
{

	// Fields
	private static readonly object <Empty>k__BackingField; // 0x0
	private readonly object fullNameToMessageMap; // 0x8

	// Properties
	public static object Empty { get; }

	// Methods

	// RVA: 0x36645C0
	public static object get_Empty() { }

	// RVA: 0x366463C
	public object .ctor(object fullNameToMessageMap) { }

	// RVA: 0x3664668
	public object Find(object fullName) { }

	// RVA: 0x36646EC
	private static object .cctor() { }

}

// Namespace: Google.Protobuf.Collections
public static class Lists
{

	// Methods

	// RVA: -1
	public static object Equals(object left, object right) { }

	// RVA: -1
	public static object GetHashCode(object list) { }

}

// Namespace: 
private class DictionaryEnumerator
{

	// Fields
	private readonly object enumerator; // 0x0

	// Properties
	public object Current { get; }
	public object Entry { get; }
	public object Key { get; }
	public object Value { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object enumerator) { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public object get_Entry() { }

	// RVA: -1
	public object get_Key() { }

	// RVA: -1
	public object get_Value() { }

}

// Namespace: 
internal class MessageAdapter
{

	// Fields
	private static readonly object ZeroLengthMessageStreamData; // 0x0
	private readonly object codec; // 0x0
	private object <Key>k__BackingField; // 0x0
	private object <Value>k__BackingField; // 0x0

	// Properties
	internal object Key { get; set; }
	internal object Value { get; set; }
	private object Google.Protobuf.IMessage.Descriptor { get; }

	// Methods

	// RVA: -1
	internal object get_Key() { }

	// RVA: -1
	internal object set_Key(object value) { }

	// RVA: -1
	internal object get_Value() { }

	// RVA: -1
	internal object set_Value(object value) { }

	// RVA: -1
	internal object .ctor(object codec) { }

	// RVA: -1
	internal object Reset() { }

	// RVA: -1
	public object MergeFrom(object input) { }

	// RVA: -1
	public object WriteTo(object output) { }

	// RVA: -1
	public object CalculateSize() { }

	// RVA: -1
	private object Google.Protobuf.IMessage.get_Descriptor() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
public sealed class Codec
{

	// Fields
	private readonly object keyCodec; // 0x0
	private readonly object valueCodec; // 0x0
	private readonly object mapTag; // 0x0

	// Properties
	internal object MapTag { get; }

	// Methods

	// RVA: -1
	public object .ctor(object keyCodec, object valueCodec, object mapTag) { }

	// RVA: -1
	internal object get_MapTag() { }

}

// Namespace: 
private class MapView<T0>
{

	// Fields
	private readonly object parent; // 0x0
	private readonly object projection; // 0x0
	private readonly object containsCheck; // 0x0

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object parent, object projection, object containsCheck) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	public object get_IsSynchronized() { }

	// RVA: -1
	public object get_SyncRoot() { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object CopyTo(object array, object index) { }

}

// Namespace: 
private sealed class <>c__DisplayClass10_0
{

	// Fields
	public object value; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <ContainsValue>b__0(object pair) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__17_0; // 0x0
	public static object <>9__19_0; // 0x0
	public static object <>9__44_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <get_Keys>b__17_0(object pair) { }

	// RVA: -1
	internal object <get_Values>b__19_0(object pair) { }

	// RVA: -1
	internal object <System.Collections.ICollection.CopyTo>b__44_0(object pair) { }

}

// Namespace: Google.Protobuf.Collections
public sealed class MapField<T0, T1>
{

	// Fields
	private static readonly object ValueEqualityComparer; // 0x0
	private static readonly object KeyEqualityComparer; // 0x0
	private static readonly object KeyIsNullable; // 0x0
	private static readonly object ValueIsNullable; // 0x0
	private readonly object map; // 0x0
	private readonly object list; // 0x0

	// Properties
	public object Item { get; set; }
	public object Keys { get; }
	public object Values { get; }
	public object Count { get; }
	public object IsReadOnly { get; }
	private object System.Collections.IDictionary.IsFixedSize { get; }
	private object System.Collections.IDictionary.Keys { get; }
	private object System.Collections.IDictionary.Values { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	private object System.Collections.IDictionary.Item { get; set; }
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Keys { get; }
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.Values { get; }

	// Methods

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	private object ContainsValue(object value) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object get_Keys() { }

	// RVA: -1
	public object get_Values() { }

	// RVA: -1
	public object Add(object entries) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Add(object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Contains(object item) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Remove(object item) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	public override object Equals(object other) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object AddEntriesFrom(object input, object codec) { }

	// RVA: -1
	public object WriteTo(object output, object codec) { }

	// RVA: -1
	public object CalculateSize(object codec) { }

	// RVA: -1
	public override object ToString() { }

	// RVA: -1
	private object System.Collections.IDictionary.Add(object key, object value) { }

	// RVA: -1
	private object System.Collections.IDictionary.Contains(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IDictionary.Remove(object key) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	private object System.Collections.IDictionary.get_IsFixedSize() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Keys() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Values() { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Item(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.set_Item(object key, object value) { }

	// RVA: -1
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Keys() { }

	// RVA: -1
	private object System.Collections.Generic.IReadOnlyDictionary<TKey,TValue>.get_Values() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
private class BitwiseDoubleEqualityComparerImpl
{

	// Methods

	// RVA: 0x3664CB4
	public override object Equals(object x, object y) { }

	// RVA: 0x3664CC8
	public override object GetHashCode(object obj) { }

	// RVA: 0x3664B54
	public object .ctor() { }

}

// Namespace: 
private class BitwiseSingleEqualityComparerImpl
{

	// Methods

	// RVA: 0x3664CF0
	public override object Equals(object x, object y) { }

	// RVA: 0x3664D0C
	public override object GetHashCode(object obj) { }

	// RVA: 0x3664BAC
	public object .ctor() { }

}

// Namespace: 
private class BitwiseNullableDoubleEqualityComparerImpl
{

	// Methods

	// RVA: 0x3664D38
	public override object Equals(object x, object y) { }

	// RVA: 0x3664EA0
	public override object GetHashCode(object obj) { }

	// RVA: 0x3664C04
	public object .ctor() { }

}

// Namespace: 
private class BitwiseNullableSingleEqualityComparerImpl
{

	// Methods

	// RVA: 0x3665004
	public override object Equals(object x, object y) { }

	// RVA: 0x3665168
	public override object GetHashCode(object obj) { }

	// RVA: 0x3664C5C
	public object .ctor() { }

}

// Namespace: Google.Protobuf.Collections
public static class ProtobufEqualityComparers
{

	// Fields
	private static readonly object <BitwiseDoubleEqualityComparer>k__BackingField; // 0x0
	private static readonly object <BitwiseSingleEqualityComparer>k__BackingField; // 0x8
	private static readonly object <BitwiseNullableDoubleEqualityComparer>k__BackingField; // 0x10
	private static readonly object <BitwiseNullableSingleEqualityComparer>k__BackingField; // 0x18

	// Properties
	public static object BitwiseDoubleEqualityComparer { get; }
	public static object BitwiseSingleEqualityComparer { get; }
	public static object BitwiseNullableDoubleEqualityComparer { get; }
	public static object BitwiseNullableSingleEqualityComparer { get; }

	// Methods

	// RVA: -1
	public static object GetEqualityComparer() { }

	// RVA: 0x3664794
	public static object get_BitwiseDoubleEqualityComparer() { }

	// RVA: 0x3664810
	public static object get_BitwiseSingleEqualityComparer() { }

	// RVA: 0x366488C
	public static object get_BitwiseNullableDoubleEqualityComparer() { }

	// RVA: 0x3664908
	public static object get_BitwiseNullableSingleEqualityComparer() { }

	// RVA: 0x3664984
	private static object .cctor() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object list; // 0x0
	private object index; // 0x0
	private object current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	internal object .ctor(object list) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	private object MoveNextRare() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: Google.Protobuf.Collections
public sealed class RepeatedField<T0>
{

	// Fields
	private static readonly object ElementIsNullable; // 0x0
	private static readonly object EqualityComparer; // 0x0
	private static readonly object EmptyArray; // 0x0
	private object array; // 0x0
	private object count; // 0x0

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }
	public object Item { get; set; }
	private object System.Collections.IList.IsFixedSize { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	private object System.Collections.IList.Item { get; set; }

	// Methods

	// RVA: -1
	public object AddEntriesFrom(object input, object codec) { }

	// RVA: -1
	public object CalculateSize(object codec) { }

	// RVA: -1
	private object CalculatePackedDataSize(object codec) { }

	// RVA: -1
	public object WriteTo(object output, object codec) { }

	// RVA: -1
	public object EnsureSize(object size) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	public object AddRange(object values) { }

	// RVA: -1
	public object Add(object values) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object IndexOf(object item) { }

	// RVA: -1
	public object Insert(object index, object item) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	public override object ToString() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: -1
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: -1
	private object System.Collections.IList.Add(object value) { }

	// RVA: -1
	private object System.Collections.IList.Contains(object value) { }

	// RVA: -1
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: -1
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: -1
	private object System.Collections.IList.Remove(object value) { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private static object .cctor() { }

}

