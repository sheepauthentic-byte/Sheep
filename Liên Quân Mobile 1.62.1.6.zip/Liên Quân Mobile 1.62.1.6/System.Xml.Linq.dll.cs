// Namespace: 
internal class <Module>
{
}

// Namespace: 
internal static class SR
{

	// Methods

	// RVA: 0x6EEB294
	internal static object Format(object resourceFormat, object p1) { }

	// RVA: 0x6EEB308
	internal static object Format(object resourceFormat, object p1, object p2) { }

}

// Namespace: System.Xml.Linq
internal class BaseUriAnnotation
{

	// Fields
	internal object baseUri; // 0x8

	// Methods

	// RVA: 0x6EEB38C
	public object .ctor(object baseUri) { }

}

// Namespace: System.Xml.Linq
internal class LineInfoAnnotation
{

	// Fields
	internal object lineNumber; // 0x8
	internal object linePosition; // 0xC

	// Methods

	// RVA: 0x6EEB3B8
	public object .ctor(object lineNumber, object linePosition) { }

}

// Namespace: System.Xml.Linq
internal class LineInfoEndElementAnnotation
{

	// Methods

	// RVA: 0x6EEB3F0
	public object .ctor(object lineNumber, object linePosition) { }

}

// Namespace: System.Xml.Linq
public class XAttribute
{

	// Fields
	internal object next; // 0x18
	internal object name; // 0x20
	internal object value; // 0x28

	// Properties
	public object IsNamespaceDeclaration { get; }
	public object Name { get; }
	public override object NodeType { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6EEB428
	public object .ctor(object name, object value) { }

	// RVA: 0x6EEBB5C
	public object .ctor(object other) { }

	// RVA: 0x6EEBBD8
	public object get_IsNamespaceDeclaration() { }

	// RVA: 0x6EEBCB0
	public object get_Name() { }

	// RVA: 0x6EEBCB8
	public override object get_NodeType() { }

	// RVA: 0x6EEBCC0
	public object get_Value() { }

	// RVA: 0x6EEBCC8
	public override object ToString() { }

	// RVA: 0x6EEC0B8
	internal object GetPrefixOfNamespace(object ns) { }

	// RVA: 0x6EEB8F8
	private static object ValidateAttribute(object name, object value) { }

}

// Namespace: System.Xml.Linq
public class XCData
{

	// Properties
	public override object NodeType { get; }

	// Methods

	// RVA: 0x6EEC510
	public object .ctor(object value) { }

	// RVA: 0x6EEC600
	public object .ctor(object other) { }

	// RVA: 0x6EEC6F8
	public override object get_NodeType() { }

	// RVA: 0x6EEC700
	public override object WriteTo(object writer) { }

	// RVA: 0x6EEC794
	internal override object CloneNode() { }

}

// Namespace: System.Xml.Linq
public class XComment
{

	// Fields
	internal object value; // 0x20

	// Properties
	public override object NodeType { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6EEC84C
	public object .ctor(object value) { }

	// RVA: 0x6EEC8CC
	public object .ctor(object other) { }

	// RVA: 0x6EEC948
	public override object get_NodeType() { }

	// RVA: 0x6EEC950
	public object get_Value() { }

	// RVA: 0x6EEC958
	public override object WriteTo(object writer) { }

	// RVA: 0x6EEC9EC
	internal override object CloneNode() { }

}

// Namespace: 
private sealed class ContentReader
{

	// Fields
	private readonly object _eCache; // 0x8
	private readonly object _aCache; // 0x18
	private readonly object _lineInfo; // 0x28
	private object _currentContainer; // 0x30
	private object _baseUri; // 0x38

	// Methods

	// RVA: 0x6EEEBBC
	public object .ctor(object rootContainer) { }

	// RVA: 0x6EEF718
	public object .ctor(object rootContainer, object r, object o) { }

	// RVA: 0x6EEEBE8
	public object ReadContentFrom(object rootContainer, object r) { }

	// RVA: 0x6EEF7FC
	public object ReadContentFrom(object rootContainer, object r, object o) { }

}

// Namespace: 
private sealed class <Nodes>d__18
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	public object <>4__this; // 0x20
	private object <n>5__2; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Xml.Linq.XNode>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6EEDDFC
	public object .ctor(object <>1__state) { }

	// RVA: 0x6EF14F0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6EF14F4
	private object MoveNext() { }

	// RVA: 0x6EF15C4
	private object System.Collections.Generic.IEnumerator<System.Xml.Linq.XNode>.get_Current() { }

	// RVA: 0x6EF15CC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6EF160C
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x6EF1614
	private object System.Collections.Generic.IEnumerable<System.Xml.Linq.XNode>.GetEnumerator() { }

	// RVA: 0x6EF16C0
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Xml.Linq
public abstract class XContainer
{

	// Fields
	internal object content; // 0x20

	// Properties
	public object LastNode { get; }

	// Methods

	// RVA: 0x6EECAA4
	internal object .ctor() { }

	// RVA: 0x6EECAAC
	internal object .ctor(object other) { }

	// RVA: 0x6EECDB4
	public object get_LastNode() { }

	// RVA: 0x6EECF14
	public object Add(object content) { }

	// RVA: 0x6EEDD80
	public object Nodes() { }

	// RVA: 0x6EEDE34
	internal virtual object AddAttribute(object a) { }

	// RVA: 0x6EEDE38
	internal virtual object AddAttributeSkipNotify(object a) { }

	// RVA: 0x6EED46C
	internal object AddContentSkipNotify(object content) { }

	// RVA: 0x6EED8CC
	internal object AddNode(object n) { }

	// RVA: 0x6EEDE3C
	internal object AddNodeSkipNotify(object n) { }

	// RVA: 0x6EED988
	internal object AddString(object s) { }

	// RVA: 0x6EEDFD0
	internal object AddStringSkipNotify(object s) { }

	// RVA: 0x6EEE308
	internal object AppendNode(object n) { }

	// RVA: 0x6EECCCC
	internal object AppendNodeSkipNotify(object n) { }

	// RVA: 0x6EEE960
	internal override object AppendText(object sb) { }

	// RVA: 0x6EEE1F0
	internal object ConvertTextToNode() { }

	// RVA: 0x6EEB4FC
	internal static object GetStringValue(object value) { }

	// RVA: 0x6EEEA84
	internal object ReadContentFrom(object r) { }

	// RVA: 0x6EEF5AC
	internal object ReadContentFrom(object r, object o) { }

	// RVA: 0x6EF0B54
	internal object RemoveNode(object n) { }

	// RVA: 0x6EF0E34
	internal virtual object ValidateNode(object node, object previous) { }

	// RVA: 0x6EF0E38
	internal virtual object ValidateString(object s) { }

	// RVA: 0x6EF0E3C
	internal object WriteContentTo(object writer) { }

}

// Namespace: System.Xml.Linq
public class XDeclaration
{

	// Fields
	private object _version; // 0x8
	private object _encoding; // 0x10
	private object _standalone; // 0x18

	// Properties
	public object Encoding { get; }
	public object Standalone { get; }
	public object Version { get; }

	// Methods

	// RVA: 0x6EF176C
	public object .ctor(object version, object encoding, object standalone) { }

	// RVA: 0x6EF17AC
	public object .ctor(object other) { }

	// RVA: 0x6EF1830
	public object get_Encoding() { }

	// RVA: 0x6EF1838
	public object get_Standalone() { }

	// RVA: 0x6EF1840
	public object get_Version() { }

	// RVA: 0x6EF1848
	public override object ToString() { }

}

// Namespace: System.Xml.Linq
public class XDocument
{

	// Fields
	private object _declaration; // 0x28

	// Properties
	public object Declaration { get; set; }
	public override object NodeType { get; }
	public object Root { get; }

	// Methods

	// RVA: 0x6EF1B7C
	public object .ctor() { }

	// RVA: 0x6EF1B84
	public object .ctor(object other) { }

	// RVA: 0x6EF1C10
	public object get_Declaration() { }

	// RVA: 0x6EF1C18
	public object set_Declaration(object value) { }

	// RVA: 0x6EF1C20
	public override object get_NodeType() { }

	// RVA: 0x6EF1C28
	public object get_Root() { }

	// RVA: 0x6EF1C80
	public override object WriteTo(object writer) { }

	// RVA: 0x6EF1E10
	internal override object AddAttribute(object a) { }

	// RVA: 0x6EF1E64
	internal override object AddAttributeSkipNotify(object a) { }

	// RVA: 0x6EF1EB8
	internal override object CloneNode() { }

	// RVA: -1
	private object GetFirstNode() { }

	// RVA: 0x6EF1FB0
	internal static object IsWhitespace(object s) { }

	// RVA: 0x6EF2044
	internal override object ValidateNode(object node, object previous) { }

	// RVA: 0x6EF224C
	private object ValidateDocument(object previous, object allowBefore, object allowAfter) { }

	// RVA: 0x6EF2398
	internal override object ValidateString(object s) { }

}

// Namespace: System.Xml.Linq
public class XDocumentType
{

	// Fields
	private object _name; // 0x20
	private object _publicId; // 0x28
	private object _systemId; // 0x30
	private object _internalSubset; // 0x38

	// Properties
	public object InternalSubset { get; }
	public object Name { get; }
	public override object NodeType { get; }
	public object PublicId { get; }
	public object SystemId { get; }

	// Methods

	// RVA: 0x6EF11E8
	public object .ctor(object name, object publicId, object systemId, object internalSubset) { }

	// RVA: 0x6EF2468
	public object .ctor(object other) { }

	// RVA: 0x6EF24EC
	public object get_InternalSubset() { }

	// RVA: 0x6EF24F4
	public object get_Name() { }

	// RVA: 0x6EF24FC
	public override object get_NodeType() { }

	// RVA: 0x6EF2504
	public object get_PublicId() { }

	// RVA: 0x6EF250C
	public object get_SystemId() { }

	// RVA: 0x6EF2514
	public override object WriteTo(object writer) { }

	// RVA: 0x6EF25C4
	internal override object CloneNode() { }

}

// Namespace: 
private sealed class <GetAttributes>d__116
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	public object <>4__this; // 0x20
	private object name; // 0x28
	public object <>3__name; // 0x30
	private object <a>5__2; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Xml.Linq.XAttribute>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6EF3678
	public object .ctor(object <>1__state) { }

	// RVA: 0x6EF42A0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6EF42A4
	private object MoveNext() { }

	// RVA: 0x6EF437C
	private object System.Collections.Generic.IEnumerator<System.Xml.Linq.XAttribute>.get_Current() { }

	// RVA: 0x6EF4384
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6EF43C4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x6EF43CC
	private object System.Collections.Generic.IEnumerable<System.Xml.Linq.XAttribute>.GetEnumerator() { }

	// RVA: 0x6EF4488
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Xml.Linq
public class XElement
{

	// Fields
	internal object name; // 0x28
	internal object lastAttr; // 0x30

	// Properties
	public object HasAttributes { get; }
	public object IsEmpty { get; }
	public object Name { get; }
	public override object NodeType { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6EF109C
	public object .ctor(object name) { }

	// RVA: 0x6EF2628
	public object .ctor(object other) { }

	// RVA: 0x6EEDD00
	public object .ctor(object other) { }

	// RVA: 0x6EF2724
	public object get_HasAttributes() { }

	// RVA: 0x6EF2734
	public object get_IsEmpty() { }

	// RVA: 0x6EF2744
	public object get_Name() { }

	// RVA: 0x6EF274C
	public override object get_NodeType() { }

	// RVA: 0x6EF2754
	public object get_Value() { }

	// RVA: 0x6EF2808
	public object Attribute(object name) { }

	// RVA: 0x6EF2850
	public object Attributes() { }

	// RVA: 0x6EEC234
	public object GetPrefixOfNamespace(object ns) { }

	// RVA: 0x6EF2A9C
	public override object WriteTo(object writer) { }

	// RVA: 0x6EF2E8C
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6EF2E94
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6EF3128
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6EF3170
	internal override object AddAttribute(object a) { }

	// RVA: 0x6EF34D8
	internal override object AddAttributeSkipNotify(object a) { }

	// RVA: 0x6EF3278
	internal object AppendAttribute(object a) { }

	// RVA: 0x6EF1114
	internal object AppendAttributeSkipNotify(object a) { }

	// RVA: 0x6EF3614
	internal override object CloneNode() { }

	// RVA: 0x6EF28D0
	private object GetAttributes(object name) { }

	// RVA: 0x6EF2960
	private object GetNamespaceOfPrefixInScope(object prefix, object outOfScope) { }

	// RVA: 0x6EF3060
	private object ReadElementFrom(object r, object o) { }

	// RVA: 0x6EF36B0
	private object ReadElementFromImpl(object r, object o) { }

	// RVA: 0x6EF1370
	internal object SetEndElementLineInfo(object lineNumber, object linePosition) { }

	// RVA: 0x6EF4160
	internal override object ValidateNode(object node, object previous) { }

}

// Namespace: 
public sealed class ExtractKeyDelegate
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object value) { }

}

// Namespace: 
private struct Entry
{

	// Fields
	public object Value; // 0x0
	public object HashCode; // 0x0
	public object Next; // 0x0
}

// Namespace: 
private sealed class XHashtableState
{

	// Fields
	private object _buckets; // 0x0
	private object _entries; // 0x0
	private object _numEntries; // 0x0
	private object _extractKey; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object extractKey, object capacity) { }

	// RVA: -1
	public object Resize() { }

	// RVA: -1
	public object TryGetValue(object key, object index, object count, object value) { }

	// RVA: -1
	public object TryAdd(object value, object newValue) { }

	// RVA: -1
	private object FindEntry(object hashCode, object key, object index, object count, object entryIndex) { }

	// RVA: -1
	private static object ComputeHashCode(object key, object index, object count) { }

}

// Namespace: System.Xml.Linq
internal sealed class XHashtable<T0>
{

	// Fields
	private object _state; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object extractKey, object capacity) { }

	// RVA: -1
	public object TryGetValue(object key, object index, object count, object value) { }

	// RVA: -1
	public object Add(object value) { }

}

// Namespace: System.Xml.Linq
internal struct NamespaceCache
{

	// Fields
	private object _ns; // 0xFFFFFFFFFFFFFFF8
	private object _namespaceName; // 0x0

	// Methods

	// RVA: 0x6EF0FF8
	public object Get(object namespaceName) { }

}

// Namespace: System.Xml.Linq
internal struct ElementWriter
{

	// Fields
	private object _writer; // 0xFFFFFFFFFFFFFFF8
	private object _resolver; // 0x0

	// Methods

	// RVA: 0x6EF2B20
	public object .ctor(object writer) { }

	// RVA: 0x6EF2B2C
	public object WriteElement(object e) { }

	// RVA: 0x6EF4C38
	private object GetPrefixOfNamespace(object ns, object allowDefaultNamespace) { }

	// RVA: 0x6EF4608
	private object PushAncestors(object e) { }

	// RVA: 0x6EF4FDC
	private object PushElement(object e) { }

	// RVA: 0x6EF4AB0
	private object WriteEndElement() { }

	// RVA: 0x6EF4B70
	private object WriteFullEndElement() { }

	// RVA: 0x6EF48B0
	private object WriteStartElement(object e) { }

}

// Namespace: 
private class NamespaceDeclaration
{

	// Fields
	public object prefix; // 0x8
	public object ns; // 0x10
	public object scope; // 0x18
	public object prev; // 0x20

	// Methods

	// RVA: 0x6EF550C
	public object .ctor() { }

}

// Namespace: System.Xml.Linq
internal struct NamespaceResolver
{

	// Fields
	private object _scope; // 0xFFFFFFFFFFFFFFF8
	private object _declaration; // 0x0
	private object _rover; // 0x8

	// Methods

	// RVA: 0x6EF517C
	public object PushScope() { }

	// RVA: 0x6EF5244
	public object PopScope() { }

	// RVA: 0x6EF518C
	public object Add(object prefix, object ns) { }

	// RVA: 0x6EF4F28
	public object AddFirst(object prefix, object ns) { }

	// RVA: 0x6EF4D78
	public object GetPrefixOfNamespace(object ns, object allowDefaultNamespace) { }

}

// Namespace: System.Xml.Linq
public enum XObjectChange
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object Remove;
	public const object Name;
	public const object Value;
}

// Namespace: System.Xml.Linq
public enum LoadOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object PreserveWhitespace;
	public const object SetBaseUri;
	public const object SetLineInfo;
}

// Namespace: System.Xml.Linq
public enum SaveOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object DisableFormatting;
	public const object OmitDuplicateNamespaces;
}

// Namespace: System.Xml.Linq
public sealed class XName
{

	// Fields
	private object _ns; // 0x8
	private object _localName; // 0x10
	private object _hashCode; // 0x18

	// Properties
	public object LocalName { get; }
	public object Namespace { get; }
	public object NamespaceName { get; }

	// Methods

	// RVA: 0x6EF5678
	internal object .ctor(object ns, object localName) { }

	// RVA: 0x6EF5778
	public object get_LocalName() { }

	// RVA: 0x6EF5780
	public object get_Namespace() { }

	// RVA: 0x6EEBC8C
	public object get_NamespaceName() { }

	// RVA: 0x6EF5788
	public override object ToString() { }

	// RVA: 0x6EF5830
	public static object Get(object expandedName) { }

	// RVA: 0x6EF5FC8
	public static object Get(object localName, object namespaceName) { }

	// RVA: 0x6EF6000
	public static object op_Implicit(object expandedName) { }

	// RVA: 0x6EF600C
	public override object Equals(object obj) { }

	// RVA: 0x6EF6018
	public override object GetHashCode() { }

	// RVA: 0x6EEB4F0
	public static object op_Equality(object left, object right) { }

	// RVA: 0x6EF6020
	private object System.IEquatable<System.Xml.Linq.XName>.Equals(object other) { }

	// RVA: 0x6EF602C
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object info, object context) { }

	// RVA: 0x6EF606C
	internal object .ctor() { }

}

// Namespace: System.Xml.Linq
public sealed class XNamespace
{

	// Fields
	private static object s_namespaces; // 0x0
	private static object s_refNone; // 0x8
	private static object s_refXml; // 0x10
	private static object s_refXmlns; // 0x18
	private object _namespaceName; // 0x8
	private object _hashCode; // 0x10
	private object _names; // 0x18

	// Properties
	public object NamespaceName { get; }
	public static object None { get; }
	public static object Xml { get; }
	public static object Xmlns { get; }

	// Methods

	// RVA: 0x6EF60A8
	internal object .ctor(object namespaceName) { }

	// RVA: 0x6EF61C0
	public object get_NamespaceName() { }

	// RVA: 0x6EF1038
	public object GetName(object localName) { }

	// RVA: 0x6EF61C8
	public override object ToString() { }

	// RVA: 0x6EF5F54
	public static object get_None() { }

	// RVA: 0x6EF62CC
	public static object get_Xml() { }

	// RVA: 0x6EF6338
	public static object get_Xmlns() { }

	// RVA: 0x6EF3E8C
	public static object Get(object namespaceName) { }

	// RVA: 0x6EF63A4
	public static object op_Implicit(object namespaceName) { }

	// RVA: 0x6EF63B0
	public override object Equals(object obj) { }

	// RVA: 0x6EF63BC
	public override object GetHashCode() { }

	// RVA: 0x6EF2954
	public static object op_Equality(object left, object right) { }

	// RVA: 0x6EF63C4
	public static object op_Inequality(object left, object right) { }

	// RVA: 0x6EF5E10
	internal object GetName(object localName, object index, object count) { }

	// RVA: 0x6EF59EC
	internal static object Get(object namespaceName, object index, object count) { }

	// RVA: 0x6EF63D0
	private static object ExtractLocalName(object n) { }

	// RVA: 0x6EF63F0
	private static object ExtractNamespace(object r) { }

	// RVA: 0x6EF61D0
	private static object EnsureNamespace(object refNmsp, object namespaceName) { }

}

// Namespace: System.Xml.Linq
public abstract class XNode
{

	// Fields
	internal object next; // 0x18

	// Methods

	// RVA: 0x6EEC8C4
	internal object .ctor() { }

	// RVA: 0x6EF6488
	public object Remove() { }

	// RVA: 0x6EF64EC
	public override object ToString() { }

	// RVA: -1
	public abstract object WriteTo(object writer) { }

	// RVA: 0x6EF6A64
	internal virtual object AppendText(object sb) { }

	// RVA: -1
	internal abstract object CloneNode() { }

	// RVA: 0x6EF660C
	private object GetXmlString(object o) { }

}

// Namespace: System.Xml.Linq
public abstract class XObject
{

	// Fields
	internal object parent; // 0x8
	internal object annotations; // 0x10

	// Properties
	public object BaseUri { get; }
	public abstract object NodeType { get; }
	public object Parent { get; }
	private object System.Xml.IXmlLineInfo.LineNumber { get; }
	private object System.Xml.IXmlLineInfo.LinePosition { get; }
	internal object HasBaseUri { get; }

	// Methods

	// RVA: 0x6EEB4E8
	internal object .ctor() { }

	// RVA: 0x6EF1450
	public object get_BaseUri() { }

	// RVA: -1
	public abstract object get_NodeType() { }

	// RVA: 0x6EF6A68
	public object get_Parent() { }

	// RVA: 0x6EF3EF0
	public object AddAnnotation(object annotation) { }

	// RVA: 0x6EF6AF0
	private object AnnotationForSealedType(object type) { }

	// RVA: -1
	public object Annotation() { }

	// RVA: 0x6EF6C54
	private object System.Xml.IXmlLineInfo.HasLineInfo() { }

	// RVA: 0x6EF6CB8
	private object System.Xml.IXmlLineInfo.get_LineNumber() { }

	// RVA: 0x6EF6D1C
	private object System.Xml.IXmlLineInfo.get_LinePosition() { }

	// RVA: 0x6EF13EC
	internal object get_HasBaseUri() { }

	// RVA: 0x6EEE694
	internal object NotifyChanged(object sender, object e) { }

	// RVA: 0x6EEE5E0
	internal object NotifyChanging(object sender, object e) { }

	// RVA: 0x6EF1284
	internal object SetBaseUri(object baseUri) { }

	// RVA: 0x6EF12F4
	internal object SetLineInfo(object lineNumber, object linePosition) { }

	// RVA: 0x6EED3EC
	internal object SkipNotify() { }

	// RVA: 0x6EF6514
	internal object GetSaveOptionsFromAnnotations() { }

}

// Namespace: System.Xml.Linq
internal class XObjectChangeAnnotation
{

	// Fields
	internal object changing; // 0x8
	internal object changed; // 0x10
}

// Namespace: System.Xml.Linq
public class XObjectChangeEventArgs
{

	// Fields
	private object _objectChange; // 0x8
	public static readonly object Add; // 0x0
	public static readonly object Remove; // 0x8
	public static readonly object Name; // 0x10
	public static readonly object Value; // 0x18

	// Methods

	// RVA: 0x6EF6D80
	public object .ctor(object objectChange) { }

	// RVA: 0x6EF6DF0
	private static object .cctor() { }

}

// Namespace: System.Xml.Linq
public class XProcessingInstruction
{

	// Fields
	internal object target; // 0x20
	internal object data; // 0x28

	// Properties
	public object Data { get; }
	public override object NodeType { get; }
	public object Target { get; }

	// Methods

	// RVA: 0x6EF115C
	public object .ctor(object target, object data) { }

	// RVA: 0x6EF707C
	public object .ctor(object other) { }

	// RVA: 0x6EF70F8
	public object get_Data() { }

	// RVA: 0x6EF7100
	public override object get_NodeType() { }

	// RVA: 0x6EF7108
	public object get_Target() { }

	// RVA: 0x6EF7110
	public override object WriteTo(object writer) { }

	// RVA: 0x6EF71B0
	internal override object CloneNode() { }

	// RVA: 0x6EF6F98
	private static object ValidateName(object name) { }

}

// Namespace: System.Xml.Linq
public class XStreamingElement
{

	// Fields
	internal object name; // 0x8
	internal object content; // 0x10
}

// Namespace: System.Xml.Linq
public class XText
{

	// Fields
	internal object text; // 0x20

	// Properties
	public override object NodeType { get; }
	public object Value { get; set; }

	// Methods

	// RVA: 0x6EEC588
	public object .ctor(object value) { }

	// RVA: 0x6EEC67C
	public object .ctor(object other) { }

	// RVA: 0x6EF7214
	public override object get_NodeType() { }

	// RVA: 0x6EF721C
	public object get_Value() { }

	// RVA: 0x6EEE748
	public object set_Value(object value) { }

	// RVA: 0x6EF7224
	public override object WriteTo(object writer) { }

	// RVA: 0x6EF735C
	internal override object AppendText(object sb) { }

	// RVA: 0x6EF7388
	internal override object CloneNode() { }

}

// Namespace: System.Text
internal static class StringBuilderCache
{

	// Fields
	private static object t_cachedInstance; // 0xFFFFFFFF80000000

	// Methods

	// RVA: 0x6EF19C8
	public static object Acquire(object capacity) { }

	// RVA: 0x6EF7440
	public static object Release(object sb) { }

	// RVA: 0x6EF1AA4
	public static object GetStringAndRelease(object sb) { }

}

// Namespace: Unity
internal sealed class ThrowStub
{

	// Methods

	// RVA: 0x6EF74C4
	public static object ThrowNotSupportedException() { }

}

