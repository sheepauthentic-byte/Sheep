// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public class NPBDCloth
{
}

// Namespace: UnityEngine
public class NPBDDynamicBone
{

	// Methods

	// RVA: 0x743AD18
	public object .ctor() { }

}

