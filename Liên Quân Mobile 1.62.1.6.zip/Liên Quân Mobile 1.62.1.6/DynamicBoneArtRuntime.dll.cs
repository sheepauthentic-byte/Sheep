// Namespace: 
internal class <Module>
{
}

// Namespace: 
public class DynamicBoneArt
{

	// Fields
	public object StiffnessForce; // 0x18
	public object DragForce; // 0x1C
	public object DynamicBones; // 0x20
	public object Advance; // 0x28
	public object DynamicRatio; // 0x2C
	public object TPosAnimationClamp; // 0x30
	public object AutoResetToTPos; // 0x34
	public static object GloballyEnabled; // 0x0

	// Methods

	// RVA: 0x101BF48
	private object LateUpdate() { }

	// RVA: 0x101C83C
	public object ResetTipPos() { }

	// RVA: 0x101CABC
	public object CopyPropertyFrom(object src) { }

	// RVA: 0x101CAF8
	public object .ctor() { }

	// RVA: 0x101CB8C
	private static object .cctor() { }

}

// Namespace: 
public class DynamicBoneNodeArt
{

	// Fields
	public object Child; // 0x18
	private object BoneAxis; // 0x20
	private object StiffnessFactor; // 0x2C
	private object SpringForce; // 0x30
	private object SpringLength; // 0x3C
	private object TPosLocalRotation; // 0x40
	private object Trans; // 0x50
	private object CurrTipPos; // 0x58
	private object PrevTipPos; // 0x64
	private object StartTimeStamp; // 0x70
	private object OrigRotation; // 0x78

	// Methods

	// RVA: 0x101CBDC
	private object Awake() { }

	// RVA: 0x101C9CC
	public object ResetTipPos() { }

	// RVA: 0x101C170
	public object UpdateSpring(object currTime, object root) { }

	// RVA: 0x101CE10
	public object .ctor() { }

}

// Namespace: 
public class DynamicBoneNodePro
{

	// Fields
	public object m_Child; // 0x18
	public object m_BoneAxis; // 0x20
	public object m_StiffnessFactor; // 0x2C
	public object m_SpringForce; // 0x30
	public object m_SpringLength; // 0x3C
	public object m_TPosLocalRotation; // 0x40
	public object m_Trans; // 0x50
	public object m_CurrTipPos; // 0x58
	public object m_PrevTipPos; // 0x64
	public object m_StartTimeStamp; // 0x70
	public object m_NavParent; // 0x78
	public object m_OrigRotation; // 0x80

	// Methods

	// RVA: 0x101CE34
	private object Awake() { }

	// RVA: 0x101D050
	public object .ctor() { }

}

// Namespace: 
public enum UpdateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object AnimatePhysics;
	public const object UnscaledTime;
}

// Namespace: 
public struct HeadInfo
{

	// Fields
	private object headIndex; // 0xFFFFFFFFFFFFFFF8
	public object particleCount; // 0xFFFFFFFFFFFFFFFC
	public object jobDataOffset; // 0x0
	public object rootParentBoneWorldPos; // 0x4
	public object rootParentBoneWorldRot; // 0x10

	// Methods

	// RVA: 0x101E058
	public object SetHeadIndex(object index) { }

	// RVA: 0x101E068
	public object GetHeadIndex() { }

}

// Namespace: 
public struct Particle
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object initLocalPosition; // 0xFFFFFFFFFFFFFFFC
	public object initLocalRotation; // 0x8
	public object localPosition; // 0x18
	public object localRotation; // 0x24
	public object parentScale; // 0x34
	public object worldPosition; // 0x40
	public object worldRotation; // 0x4C
	public object stiffnessForce; // 0x5C
	public object dragForce; // 0x60
	public object boneAxis; // 0x64
	public object stiffnessFactor; // 0x70
	public object springForce; // 0x74
	public object springLength; // 0x80
	public object tPosLocalRotation; // 0x84
	public object currTipPos; // 0x94
	public object prevTipPos; // 0xA0
	public object startTimeStamp; // 0xB0
	public object origRotation; // 0xB8
}

// Namespace: 
public class DynamicBoneParallelPro
{

	// Fields
	public const object MAX_TRANSFORM_LIMIT;
	public object m_Root; // 0x18
	public object m_StiffnessForce; // 0x20
	public object m_DragForce; // 0x24
	public object m_DynamicBones; // 0x28
	public object m_UpdateMode; // 0x30
	public object m_Particles; // 0x38
	public object m_particleTransformArr; // 0x48
	private object m_ParticleCount; // 0x50
	public object m_rootParentTransform; // 0x58
	public object m_headInfo; // 0x60

	// Methods

	// RVA: 0x101D074
	private object Start() { }

	// RVA: 0x101D268
	private object OnEnable() { }

	// RVA: 0x101D690
	private object OnDisable() { }

	// RVA: 0x101D8E0
	public object ResetHeadIndexAndDataOffset(object headIndex) { }

	// RVA: 0x101D904
	public object ClearJobData() { }

	// RVA: 0x101D128
	public object SetupParticles() { }

	// RVA: 0x101D96C
	private object RefreshChildNodes(object root) { }

	// RVA: 0x101DA4C
	private object BoneNodesQuery(object trans, object list) { }

	// RVA: 0x101DC8C
	private object AppendParticles(object node) { }

	// RVA: 0x101D79C
	private object InitTransforms() { }

	// RVA: 0x101E044
	public object .ctor() { }

}

// Namespace: 
private struct RootPosApplyJob
{

	// Fields
	public object ParticleHeadInfo; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x101F2A4
	public object Execute(object index, object transform) { }

}

// Namespace: 
private struct PrepareParticleJob
{

	// Fields
	public object ParticleHeadInfo; // 0xFFFFFFFFFFFFFFF8
	public object ParticleInfo; // 0x8
	public object HeadCount; // 0x18

	// Methods

	// RVA: 0x101F368
	public object Execute() { }

}

// Namespace: 
private struct UpdateParticleJob
{

	// Fields
	public object ParticleHeadInfo; // 0xFFFFFFFFFFFFFFF8
	public object ParticleInfo; // 0x8
	public object HeadCount; // 0x18
	public object FpsCurrent; // 0x20
	public object LastUpdatetime; // 0x28
	public object DeltaTime; // 0x30

	// Methods

	// RVA: 0x101F518
	public object Execute(object index) { }

}

// Namespace: 
private struct ApplyParticleToTransform
{

	// Fields
	public object ParticleHeadInfo; // 0xFFFFFFFFFFFFFFF8
	public object ParticleInfo; // 0x8
	public object HeadCount; // 0x18

	// Methods

	// RVA: 0x101FBA8
	public object Execute(object index) { }

}

// Namespace: 
private struct FinalJob
{

	// Fields
	public object ParticleInfo; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x101FE08
	public object Execute(object index, object transform) { }

}

// Namespace: 
public class DynamicBoneParallelProMng
{

	// Fields
	private static object m_instance; // 0x0
	private static object m_GloballyEnabled; // 0x8
	private static object s_LastUpdatetime; // 0x10
	private static object s_AccumTime; // 0x18
	private static object s_Accum; // 0x20
	private static object s_FpsCalcFrames; // 0x28
	private static object s_FpsCurrent; // 0x30
	private static object s_DeltaTime; // 0x38
	public static object isApplicationQuitting; // 0x40
	private object m_dynamicBoneList; // 0x18
	private object m_particleInfo; // 0x20
	private object m_headInfo; // 0x28
	private object m_headRootTransform; // 0x30
	private object m_particleTransformArr; // 0x38
	private object m_DbDataLen; // 0x40
	private object m_lastJobHandle; // 0x48
	private object m_loadingQueue; // 0x58
	private object m_removeQueue; // 0x60

	// Properties
	public static object Instance { get; }

	// Methods

	// RVA: 0x101E078
	private object Update() { }

	// RVA: 0x101D32C
	public static object get_Instance() { }

	// RVA: 0x101E2CC
	private object Awake() { }

	// RVA: 0x101E18C
	public object Init() { }

	// RVA: 0x101D624
	public object OnEnter(object target) { }

	// RVA: 0x101D874
	public object OnExit(object target) { }

	// RVA: 0x101E558
	private object UpdateQueue() { }

	// RVA: 0x101EDF4
	private object LateUpdate() { }

	// RVA: 0x101F0C4
	private object OnDestroy() { }

	// RVA: 0x101F1A8
	public object .ctor() { }

	// RVA: 0x101F240
	private static object .cctor() { }

}

// Namespace: 
private sealed class <CreateTarget>d__11
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <perLineCount>5__2; // 0x20
	private object <target>5__3; // 0x28
	private object <i>5__4; // 0x30

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x1020178
	public object .ctor(object <>1__state) { }

	// RVA: 0x1020518
	private object System.IDisposable.Dispose() { }

	// RVA: 0x102051C
	private object MoveNext() { }

	// RVA: 0x10208A8
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x10208B0
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x10208F0
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
public class DynamicBoneTest
{

	// Fields
	public object createBtn; // 0x18
	public object inputFd; // 0x20
	public object dropdown; // 0x28
	public object prefabCpp; // 0x30
	public object prefabParallel; // 0x38
	public object targetCount; // 0x40
	public object targetInterval; // 0x44
	private object goList; // 0x48
	private readonly object defaultMap; // 0x50

	// Methods

	// RVA: 0x101FECC
	private object Start() { }

	// RVA: 0x1020098
	private object CreatePlayers() { }

	// RVA: 0x102010C
	private object CreateTarget() { }

	// RVA: 0x10201A4
	private object OnPlayersNumChanged(object value) { }

	// RVA: 0x1020474
	public object .ctor() { }

}

// Namespace: 
internal class __JobReflectionRegistrationOutput__3971200472
{

	// Methods

	// RVA: 0x10208F8
	public static object CreateJobReflectionData() { }

	// RVA: 0x1020A50
	public static object EarlyInit() { }

}

