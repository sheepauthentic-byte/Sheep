// Namespace: 
internal class <Module>
{
}

