// Namespace: 
internal class <Module>
{
}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0x6C49294
	private static object Get() { }

	// RVA: 0x6C49364
	public object .ctor() { }

}

// Namespace: 
public enum Token
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Null;
	public const object True;
	public const object False;
	public const object Colon;
	public const object Comma;
	public const object String;
	public const object Number;
	public const object CurlyOpen;
	public const object CurlyClose;
	public const object SquaredOpen;
	public const object SquaredClose;
}

// Namespace: SharpJson
internal class Lexer
{

	// Fields
	private object <lineNumber>k__BackingField; // 0x8
	private object <parseNumbersAsFloat>k__BackingField; // 0xC
	private object json; // 0x10
	private object index; // 0x18
	private object success; // 0x1C
	private object stringBuffer; // 0x20

	// Properties
	public object hasError { get; }
	public object lineNumber { get; set; }
	public object parseNumbersAsFloat { get; set; }

	// Methods

	// RVA: 0x6C494A0
	public object get_hasError() { }

	// RVA: 0x6C494B0
	public object get_lineNumber() { }

	// RVA: 0x6C494B8
	private object set_lineNumber(object value) { }

	// RVA: 0x6C494C0
	public object get_parseNumbersAsFloat() { }

	// RVA: 0x6C494C8
	public object set_parseNumbersAsFloat(object value) { }

	// RVA: 0x6C494D0
	public object .ctor(object text) { }

	// RVA: 0x6C49574
	public object Reset() { }

	// RVA: 0x6C49588
	public object ParseString() { }

	// RVA: 0x6C49B88
	private object GetNumberString() { }

	// RVA: 0x6C49D10
	public object ParseFloatNumber() { }

	// RVA: 0x6C49E6C
	public object ParseDoubleNumber() { }

	// RVA: 0x6C49C60
	private object GetLastIndexOfNumber(object index) { }

	// RVA: 0x6C49AA0
	private object SkipWhiteSpaces() { }

	// RVA: 0x6C49FC8
	public object LookAhead() { }

	// RVA: 0x6C4A250
	public object NextToken() { }

	// RVA: 0x6C4A004
	private static object NextToken(object json, object index) { }

}

// Namespace: SharpJson
public class JsonDecoder
{

	// Fields
	private object <errorMessage>k__BackingField; // 0x8
	private object <parseNumbersAsFloat>k__BackingField; // 0x10
	private object lexer; // 0x18

	// Properties
	public object errorMessage { get; set; }
	public object parseNumbersAsFloat { get; set; }

	// Methods

	// RVA: 0x6C4A278
	public object get_errorMessage() { }

	// RVA: 0x6C4A280
	private object set_errorMessage(object value) { }

	// RVA: 0x6C4A288
	public object get_parseNumbersAsFloat() { }

	// RVA: 0x6C4A290
	public object set_parseNumbersAsFloat(object value) { }

	// RVA: 0x6C4A298
	public object .ctor() { }

	// RVA: 0x6C4A2C4
	public object Decode(object text) { }

	// RVA: 0x6C4A708
	public static object DecodeText(object text) { }

	// RVA: 0x6C4A778
	private object ParseObject() { }

	// RVA: 0x6C4AB50
	private object ParseArray() { }

	// RVA: 0x6C4A3B4
	private object ParseValue() { }

	// RVA: 0x6C4AAA4
	private object TriggerError(object message) { }

	// RVA: -1
	private object EvalLexer(object value) { }

}

// Namespace: Spine
public class Animation
{

	// Fields
	internal object name; // 0x8
	internal object timelines; // 0x10
	internal object timelineIds; // 0x18
	internal object duration; // 0x20

	// Properties
	public object Timelines { get; set; }
	public object Duration { get; set; }
	public object Name { get; }

	// Methods

	// RVA: 0x6C4AE78
	public object .ctor(object name, object timelines, object duration) { }

	// RVA: 0x6C4B220
	public object get_Timelines() { }

	// RVA: 0x6C4B228
	public object set_Timelines(object value) { }

	// RVA: 0x6C4AF2C
	public object SetTimelines(object timelines) { }

	// RVA: 0x6C4B22C
	public object get_Duration() { }

	// RVA: 0x6C4B234
	public object set_Duration(object value) { }

	// RVA: 0x6C4B23C
	public object get_Name() { }

	// RVA: 0x6C4B244
	public object HasTimeline(object propertyIds) { }

	// RVA: 0x6C4B30C
	public object Apply(object skeleton, object lastTime, object time, object loop, object events, object alpha, object blend, object direction) { }

	// RVA: 0x6C4B4C4
	public override object ToString() { }

}

// Namespace: Spine
public enum MixBlend
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Setup;
	public const object First;
	public const object Replace;
	public const object Add;
}

// Namespace: Spine
public enum MixDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object In;
	public const object Out;
}

// Namespace: Spine
internal enum Property
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Rotate;
	public const object X;
	public const object Y;
	public const object ScaleX;
	public const object ScaleY;
	public const object ShearX;
	public const object ShearY;
	public const object RGB;
	public const object Alpha;
	public const object RGB2;
	public const object Attachment;
	public const object Deform;
	public const object Event;
	public const object DrawOrder;
	public const object IkConstraint;
	public const object TransformConstraint;
	public const object PathConstraintPosition;
	public const object PathConstraintSpacing;
	public const object PathConstraintMix;
}

// Namespace: Spine
public abstract class Timeline
{

	// Fields
	private readonly object propertyIds; // 0x8
	internal readonly object frames; // 0x10

	// Properties
	public object PropertyIds { get; }
	public object Frames { get; }
	public virtual object FrameEntries { get; }
	public object FrameCount { get; }
	public object Duration { get; }

	// Methods

	// RVA: 0x6C4B4CC
	public object .ctor(object frameCount, object propertyIds) { }

	// RVA: 0x6C4B5C8
	public object get_PropertyIds() { }

	// RVA: 0x6C4B5D0
	public object get_Frames() { }

	// RVA: 0x6C4B5D8
	public virtual object get_FrameEntries() { }

	// RVA: 0x6C4B5E0
	public object get_FrameCount() { }

	// RVA: 0x6C4B640
	public object get_Duration() { }

	// RVA: -1
	public abstract object Apply(object skeleton, object lastTime, object time, object events, object alpha, object blend, object direction) { }

	// RVA: 0x6C4B6B4
	internal static object Search(object frames, object time) { }

	// RVA: 0x6C4B71C
	internal static object Search(object frames, object time, object step) { }

}

// Namespace: Spine
public interface IBoneTimeline
{

	// Properties
	public abstract object BoneIndex { get; }

	// Methods

	// RVA: -1
	public abstract object get_BoneIndex() { }

}

// Namespace: Spine
public interface ISlotTimeline
{

	// Properties
	public abstract object SlotIndex { get; }

	// Methods

	// RVA: -1
	public abstract object get_SlotIndex() { }

}

// Namespace: Spine
public abstract class CurveTimeline
{

	// Fields
	public const object LINEAR;
	public const object STEPPED;
	public const object BEZIER;
	public const object BEZIER_SIZE;
	internal object curves; // 0x18

	// Methods

	// RVA: 0x6C4B788
	public object .ctor(object frameCount, object bezierCount, object propertyIds) { }

	// RVA: 0x6C4B83C
	public object SetLinear(object frame) { }

	// RVA: 0x6C4B878
	public object SetStepped(object frame) { }

	// RVA: 0x6C4B8B8
	public object GetCurveType(object frame) { }

	// RVA: 0x6C4B910
	public object Shrink(object bezierCount) { }

	// RVA: 0x6C4B9F8
	public object SetBezier(object bezier, object frame, object value, object time1, object value1, object cx1, object cy1, object cx2, object cy2, object time2, object value2) { }

	// RVA: 0x6C4BC08
	public object GetBezierValue(object time, object frameIndex, object valueOffset, object i) { }

}

// Namespace: Spine
public abstract class CurveTimeline1
{

	// Fields
	public const object ENTRIES;
	internal const object VALUE;

	// Properties
	public override object FrameEntries { get; }

	// Methods

	// RVA: 0x6C4BDF0
	public object .ctor(object frameCount, object bezierCount, object propertyId) { }

	// RVA: 0x6C4BEF8
	public override object get_FrameEntries() { }

	// RVA: 0x6C4BF00
	public object SetFrame(object frame, object time, object value) { }

	// RVA: 0x6C4BF54
	public object GetCurveValue(object time) { }

}

// Namespace: Spine
public abstract class CurveTimeline2
{

	// Fields
	public const object ENTRIES;
	internal const object VALUE1;
	internal const object VALUE2;

	// Properties
	public override object FrameEntries { get; }

	// Methods

	// RVA: 0x6C4C090
	public object .ctor(object frameCount, object bezierCount, object propertyId1, object propertyId2) { }

	// RVA: 0x6C4C1B0
	public override object get_FrameEntries() { }

	// RVA: 0x6C4C1B8
	public object SetFrame(object frame, object time, object value1, object value2) { }

}

// Namespace: Spine
public class RotateTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4C218
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4C2D0
	public object get_BoneIndex() { }

	// RVA: 0x6C4C2D8
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class TranslateTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4C474
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4C570
	public object get_BoneIndex() { }

	// RVA: 0x6C4C578
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

	// RVA: 0x6C4C748
	public object GetCurveValue(object x, object y, object time) { }

}

// Namespace: Spine
public class TranslateXTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4C938
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4C9F4
	public object get_BoneIndex() { }

	// RVA: 0x6C4C9FC
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class TranslateYTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4CB94
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4CC50
	public object get_BoneIndex() { }

	// RVA: 0x6C4CC58
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class ScaleTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4CDF0
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4CEEC
	public object get_BoneIndex() { }

	// RVA: 0x6C4CEF4
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class ScaleXTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4D454
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4D510
	public object get_BoneIndex() { }

	// RVA: 0x6C4D518
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class ScaleYTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4D7A0
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4D85C
	public object get_BoneIndex() { }

	// RVA: 0x6C4D864
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class ShearTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4DAEC
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4DBE8
	public object get_BoneIndex() { }

	// RVA: 0x6C4DBF0
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class ShearXTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4DF48
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4E004
	public object get_BoneIndex() { }

	// RVA: 0x6C4E00C
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class ShearYTimeline
{

	// Fields
	private readonly object boneIndex; // 0x20

	// Properties
	public object BoneIndex { get; }

	// Methods

	// RVA: 0x6C4E1A4
	public object .ctor(object frameCount, object bezierCount, object boneIndex) { }

	// RVA: 0x6C4E260
	public object get_BoneIndex() { }

	// RVA: 0x6C4E268
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class RGBATimeline
{

	// Fields
	public const object ENTRIES;
	protected const object R;
	protected const object G;
	protected const object B;
	protected const object A;
	private readonly object slotIndex; // 0x20

	// Properties
	public override object FrameEntries { get; }
	public object SlotIndex { get; }

	// Methods

	// RVA: 0x6C4E400
	public object .ctor(object frameCount, object bezierCount, object slotIndex) { }

	// RVA: 0x6C4E5AC
	public override object get_FrameEntries() { }

	// RVA: 0x6C4E5B4
	public object get_SlotIndex() { }

	// RVA: 0x6C4E5BC
	public object SetFrame(object frame, object time, object r, object g, object b, object a) { }

	// RVA: 0x6C4E63C
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class RGBTimeline
{

	// Fields
	public const object ENTRIES;
	protected const object R;
	protected const object G;
	protected const object B;
	private readonly object slotIndex; // 0x20

	// Properties
	public override object FrameEntries { get; }
	public object SlotIndex { get; }

	// Methods

	// RVA: 0x6C4EA98
	public object .ctor(object frameCount, object bezierCount, object slotIndex) { }

	// RVA: 0x6C4EBFC
	public override object get_FrameEntries() { }

	// RVA: 0x6C4EC04
	public object get_SlotIndex() { }

	// RVA: 0x6C4EC0C
	public object SetFrame(object frame, object time, object r, object g, object b) { }

	// RVA: 0x6C4EC80
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class AlphaTimeline
{

	// Fields
	private readonly object slotIndex; // 0x20

	// Properties
	public object SlotIndex { get; }

	// Methods

	// RVA: 0x6C4F06C
	public object .ctor(object frameCount, object bezierCount, object slotIndex) { }

	// RVA: 0x6C4F128
	public object get_SlotIndex() { }

	// RVA: 0x6C4F130
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class RGBA2Timeline
{

	// Fields
	public const object ENTRIES;
	protected const object R;
	protected const object G;
	protected const object B;
	protected const object A;
	protected const object R2;
	protected const object G2;
	protected const object B2;
	private readonly object slotIndex; // 0x20

	// Properties
	public override object FrameEntries { get; }
	public object SlotIndex { get; }

	// Methods

	// RVA: 0x6C4F2B8
	public object .ctor(object frameCount, object bezierCount, object slotIndex) { }

	// RVA: 0x6C4F4AC
	public override object get_FrameEntries() { }

	// RVA: 0x6C4F4B4
	public object get_SlotIndex() { }

	// RVA: 0x6C4F4BC
	public object SetFrame(object frame, object time, object r, object g, object b, object a, object r2, object g2, object b2) { }

	// RVA: 0x6C4F574
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class RGB2Timeline
{

	// Fields
	public const object ENTRIES;
	protected const object R;
	protected const object G;
	protected const object B;
	protected const object R2;
	protected const object G2;
	protected const object B2;
	private readonly object slotIndex; // 0x20

	// Properties
	public override object FrameEntries { get; }
	public object SlotIndex { get; }

	// Methods

	// RVA: 0x6C4FB9C
	public object .ctor(object frameCount, object bezierCount, object slotIndex) { }

	// RVA: 0x6C4FD48
	public override object get_FrameEntries() { }

	// RVA: 0x6C4FD50
	public object get_SlotIndex() { }

	// RVA: 0x6C4FD58
	public object SetFrame(object frame, object time, object r, object g, object b, object r2, object g2, object b2) { }

	// RVA: 0x6C4FDFC
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class AttachmentTimeline
{

	// Fields
	private readonly object slotIndex; // 0x18
	private readonly object attachmentNames; // 0x20

	// Properties
	public object SlotIndex { get; }
	public object AttachmentNames { get; }

	// Methods

	// RVA: 0x6C503D8
	public object .ctor(object frameCount, object slotIndex) { }

	// RVA: 0x6C504E0
	public object get_SlotIndex() { }

	// RVA: 0x6C504E8
	public object get_AttachmentNames() { }

	// RVA: 0x6C504F0
	public object SetFrame(object frame, object time, object attachmentName) { }

	// RVA: 0x6C50558
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

	// RVA: 0x6C50708
	private object SetAttachment(object skeleton, object slot, object attachmentName) { }

}

// Namespace: Spine
public class DeformTimeline
{

	// Fields
	private readonly object slotIndex; // 0x20
	private readonly object attachment; // 0x28
	internal object vertices; // 0x30

	// Properties
	public object SlotIndex { get; }
	public object Attachment { get; }
	public object Vertices { get; }

	// Methods

	// RVA: 0x6C50774
	public object .ctor(object frameCount, object bezierCount, object slotIndex, object attachment) { }

	// RVA: 0x6C50984
	public object get_SlotIndex() { }

	// RVA: 0x6C5098C
	public object get_Attachment() { }

	// RVA: 0x6C50994
	public object get_Vertices() { }

	// RVA: 0x6C5099C
	public object SetFrame(object frame, object time, object vertices) { }

	// RVA: 0x6C50A04
	public object setBezier(object bezier, object frame, object value, object time1, object value1, object cx1, object cy1, object cx2, object cy2, object time2, object value2) { }

	// RVA: 0x6C50C38
	private object GetCurvePercent(object time, object frame) { }

	// RVA: 0x6C50F0C
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class EventTimeline
{

	// Fields
	private static readonly object propertyIds; // 0x0
	private readonly object events; // 0x18

	// Properties
	public object Events { get; }

	// Methods

	// RVA: 0x6C51ED4
	public object .ctor(object frameCount) { }

	// RVA: 0x6C51F70
	public object get_Events() { }

	// RVA: 0x6C51F78
	public object SetFrame(object frame, object e) { }

	// RVA: 0x6C5202C
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

	// RVA: 0x6C5228C
	private static object .cctor() { }

}

// Namespace: Spine
public class DrawOrderTimeline
{

	// Fields
	private static readonly object propertyIds; // 0x0
	private readonly object drawOrders; // 0x18

	// Properties
	public object DrawOrders { get; }

	// Methods

	// RVA: 0x6C52338
	public object .ctor(object frameCount) { }

	// RVA: 0x6C523D4
	public object get_DrawOrders() { }

	// RVA: 0x6C523DC
	public object SetFrame(object frame, object time, object drawOrder) { }

	// RVA: 0x6C52444
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

	// RVA: 0x6C526F0
	private static object .cctor() { }

}

// Namespace: Spine
public class IkConstraintTimeline
{

	// Fields
	public const object ENTRIES;
	private const object MIX;
	private const object SOFTNESS;
	private const object BEND_DIRECTION;
	private const object COMPRESS;
	private const object STRETCH;
	private readonly object ikConstraintIndex; // 0x20

	// Properties
	public override object FrameEntries { get; }
	public object IkConstraintIndex { get; }

	// Methods

	// RVA: 0x6C5279C
	public object .ctor(object frameCount, object bezierCount, object ikConstraintIndex) { }

	// RVA: 0x6C52900
	public override object get_FrameEntries() { }

	// RVA: 0x6C52908
	public object get_IkConstraintIndex() { }

	// RVA: 0x6C52910
	public object SetFrame(object frame, object time, object mix, object softness, object bendDirection, object compress, object stretch) { }

	// RVA: 0x6C529C4
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class TransformConstraintTimeline
{

	// Fields
	public const object ENTRIES;
	private const object ROTATE;
	private const object X;
	private const object Y;
	private const object SCALEX;
	private const object SCALEY;
	private const object SHEARY;
	private readonly object transformConstraintIndex; // 0x20

	// Properties
	public override object FrameEntries { get; }
	public object TransformConstraintIndex { get; }

	// Methods

	// RVA: 0x6C52D78
	public object .ctor(object frameCount, object bezierCount, object transformConstraintIndex) { }

	// RVA: 0x6C52EDC
	public override object get_FrameEntries() { }

	// RVA: 0x6C52EE4
	public object get_TransformConstraintIndex() { }

	// RVA: 0x6C52EEC
	public object SetFrame(object frame, object time, object mixRotate, object mixX, object mixY, object mixScaleX, object mixScaleY, object mixShearY) { }

	// RVA: 0x6C52F90
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class PathConstraintPositionTimeline
{

	// Fields
	private readonly object pathConstraintIndex; // 0x20

	// Properties
	public object PathConstraintIndex { get; }

	// Methods

	// RVA: 0x6C534A0
	public object .ctor(object frameCount, object bezierCount, object pathConstraintIndex) { }

	// RVA: 0x6C5355C
	public object get_PathConstraintIndex() { }

	// RVA: 0x6C53564
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class PathConstraintSpacingTimeline
{

	// Fields
	private readonly object pathConstraintIndex; // 0x20

	// Properties
	public object PathConstraintIndex { get; }

	// Methods

	// RVA: 0x6C536B4
	public object .ctor(object frameCount, object bezierCount, object pathConstraintIndex) { }

	// RVA: 0x6C53770
	public object get_PathConstraintIndex() { }

	// RVA: 0x6C53778
	public override object Apply(object skeleton, object lastTime, object time, object events, object alpha, object blend, object direction) { }

}

// Namespace: Spine
public class PathConstraintMixTimeline
{

	// Fields
	public const object ENTRIES;
	private const object ROTATE;
	private const object X;
	private const object Y;
	private readonly object pathConstraintIndex; // 0x20

	// Properties
	public override object FrameEntries { get; }
	public object PathConstraintIndex { get; }

	// Methods

	// RVA: 0x6C538C8
	public object .ctor(object frameCount, object bezierCount, object pathConstraintIndex) { }

	// RVA: 0x6C53A2C
	public override object get_FrameEntries() { }

	// RVA: 0x6C53A34
	public object get_PathConstraintIndex() { }

	// RVA: 0x6C53A3C
	public object SetFrame(object frame, object time, object mixRotate, object mixX, object mixY) { }

	// RVA: 0x6C53AB0
	public override object Apply(object skeleton, object lastTime, object time, object firedEvents, object alpha, object blend, object direction) { }

}

// Namespace: 
public sealed class TrackEntryDelegate
{

	// Methods

	// RVA: 0x6C58E38
	public object .ctor(object object, object method) { }

	// RVA: 0x6C58F54
	public virtual object Invoke(object trackEntry) { }

	// RVA: 0x6C58F68
	public virtual object BeginInvoke(object trackEntry, object callback, object object) { }

	// RVA: 0x6C58FB8
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class TrackEntryEventDelegate
{

	// Methods

	// RVA: 0x6C592C8
	public object .ctor(object object, object method) { }

	// RVA: 0x6C593D4
	public virtual object Invoke(object trackEntry, object e) { }

	// RVA: 0x6C593E8
	public virtual object BeginInvoke(object trackEntry, object e, object callback, object object) { }

	// RVA: 0x6C59444
	public virtual object EndInvoke(object result) { }

}

// Namespace: Spine
public class AnimationState
{

	// Fields
	internal static readonly object EmptyAnimation; // 0x0
	internal const object Subsequent;
	internal const object First;
	internal const object HoldSubsequent;
	internal const object HoldFirst;
	internal const object HoldMix;
	internal const object Setup;
	internal const object Current;
	protected object data; // 0x8
	private readonly object tracks; // 0x10
	private readonly object events; // 0x18
	private object Start; // 0x20
	private object Interrupt; // 0x28
	private object End; // 0x30
	private object Dispose; // 0x38
	private object Complete; // 0x40
	private object Event; // 0x48
	private readonly object queue; // 0x50
	private readonly object propertyIds; // 0x58
	private object animationsChanged; // 0x60
	private object timeScale; // 0x64
	private object unkeyedState; // 0x68
	private readonly object trackEntryPool; // 0x70

	// Properties
	public object TimeScale { get; set; }
	public object Data { get; set; }
	public object Tracks { get; }

	// Methods

	// RVA: 0x6C53E40
	internal object OnStart(object entry) { }

	// RVA: 0x6C53E5C
	internal object OnInterrupt(object entry) { }

	// RVA: 0x6C53E78
	internal object OnEnd(object entry) { }

	// RVA: 0x6C53E94
	internal object OnDispose(object entry) { }

	// RVA: 0x6C53EB0
	internal object OnComplete(object entry) { }

	// RVA: 0x6C53ECC
	internal object OnEvent(object entry, object e) { }

	// RVA: 0x6C53EE8
	public object add_Start(object value) { }

	// RVA: 0x6C53F8C
	public object remove_Start(object value) { }

	// RVA: 0x6C54030
	public object add_Interrupt(object value) { }

	// RVA: 0x6C540D4
	public object remove_Interrupt(object value) { }

	// RVA: 0x6C54178
	public object add_End(object value) { }

	// RVA: 0x6C5421C
	public object remove_End(object value) { }

	// RVA: 0x6C542C0
	public object add_Dispose(object value) { }

	// RVA: 0x6C54364
	public object remove_Dispose(object value) { }

	// RVA: 0x6C54408
	public object add_Complete(object value) { }

	// RVA: 0x6C544AC
	public object remove_Complete(object value) { }

	// RVA: 0x6C54550
	public object add_Event(object value) { }

	// RVA: 0x6C545F4
	public object remove_Event(object value) { }

	// RVA: 0x6C54698
	public object AssignEventSubscribersFrom(object src) { }

	// RVA: 0x6C546CC
	public object AddEventSubscribersFrom(object src) { }

	// RVA: 0x6C549EC
	public object .ctor(object data) { }

	// RVA: 0x6C54C40
	public object Update(object delta) { }

	// RVA: 0x6C5514C
	private object UpdateMixingFrom(object to, object delta) { }

	// RVA: 0x6C55268
	public object Apply(object skeleton) { }

	// RVA: 0x6C56BD0
	public object ApplyEventTimelinesOnly(object skeleton, object issueEvents) { }

	// RVA: 0x6C55B30
	private object ApplyMixingFrom(object to, object skeleton, object blend) { }

	// RVA: 0x6C56F64
	private object ApplyMixingFromEventTimelinesOnly(object to, object skeleton, object issueEvents) { }

	// RVA: 0x6C56394
	private object ApplyAttachmentTimeline(object timeline, object skeleton, object time, object blend, object attachments) { }

	// RVA: 0x6C57264
	private object SetAttachment(object skeleton, object slot, object attachmentName, object attachments) { }

	// RVA: 0x6C56520
	private static object ApplyRotateTimeline(object timeline, object skeleton, object time, object alpha, object blend, object timelinesRotation, object i, object firstFrame) { }

	// RVA: 0x6C569C0
	private object QueueEvents(object entry, object animationTime) { }

	// RVA: 0x6C57328
	public object ClearTracks() { }

	// RVA: 0x6C5740C
	public object ClearTrack(object trackIndex) { }

	// RVA: 0x6C54E88
	private object SetCurrent(object index, object current, object interrupt) { }

	// RVA: 0x6C57650
	public object SetAnimation(object trackIndex, object animationName, object loop) { }

	// RVA: 0x6C57730
	public object SetAnimation(object trackIndex, object animation, object loop) { }

	// RVA: 0x6C57ACC
	public object AddAnimation(object trackIndex, object animationName, object loop, object delay) { }

	// RVA: 0x6C57BBC
	public object AddAnimation(object trackIndex, object animation, object loop, object delay) { }

	// RVA: 0x6C57E60
	public object SetEmptyAnimation(object trackIndex, object mixDuration) { }

	// RVA: 0x6C57F00
	public object AddEmptyAnimation(object trackIndex, object mixDuration, object delay) { }

	// RVA: 0x6C57FD4
	public object SetEmptyAnimations(object mixDuration) { }

	// RVA: 0x6C57594
	private object ExpandToIndex(object index) { }

	// RVA: 0x6C579A0
	private object NewTrackEntry(object trackIndex, object animation, object loop, object last) { }

	// RVA: 0x6C550E0
	public object ClearNext(object entry) { }

	// RVA: 0x6C55A18
	private object AnimationsChanged() { }

	// RVA: 0x6C58120
	private object ComputeHold(object entry) { }

	// RVA: 0x6C58770
	public object GetCurrent(object trackIndex) { }

	// RVA: 0x6C587D8
	public object ClearListenerNotifications() { }

	// RVA: 0x6C587FC
	public object get_TimeScale() { }

	// RVA: 0x6C58804
	public object set_TimeScale(object value) { }

	// RVA: 0x6C5880C
	public object get_Data() { }

	// RVA: 0x6C58814
	public object set_Data(object value) { }

	// RVA: 0x6C5888C
	public object get_Tracks() { }

	// RVA: 0x6C58894
	public override object ToString() { }

	// RVA: 0x6C58A78
	private static object .cctor() { }

	// RVA: 0x6C58B54
	private object <.ctor>b__45_0() { }

}

// Namespace: Spine
public class TrackEntry
{

	// Fields
	internal object animation; // 0x8
	internal object previous; // 0x10
	internal object next; // 0x18
	internal object mixingFrom; // 0x20
	internal object mixingTo; // 0x28
	private object Start; // 0x30
	private object Interrupt; // 0x38
	private object End; // 0x40
	private object Dispose; // 0x48
	private object Complete; // 0x50
	private object Event; // 0x58
	internal object trackIndex; // 0x60
	internal object loop; // 0x64
	internal object holdPrevious; // 0x65
	internal object reverse; // 0x66
	internal object eventThreshold; // 0x68
	internal object attachmentThreshold; // 0x6C
	internal object drawOrderThreshold; // 0x70
	internal object animationStart; // 0x74
	internal object animationEnd; // 0x78
	internal object animationLast; // 0x7C
	internal object nextAnimationLast; // 0x80
	internal object delay; // 0x84
	internal object trackTime; // 0x88
	internal object trackLast; // 0x8C
	internal object nextTrackLast; // 0x90
	internal object trackEnd; // 0x94
	internal object timeScale; // 0x98
	internal object alpha; // 0x9C
	internal object mixTime; // 0xA0
	internal object mixDuration; // 0xA4
	internal object interruptAlpha; // 0xA8
	internal object totalAlpha; // 0xAC
	internal object mixBlend; // 0xB0
	internal readonly object timelineMode; // 0xB8
	internal readonly object timelineHoldMix; // 0xC0
	internal readonly object timelinesRotation; // 0xC8

	// Properties
	public object TrackIndex { get; }
	public object Animation { get; }
	public object Loop { get; set; }
	public object Delay { get; set; }
	public object TrackTime { get; set; }
	public object TrackEnd { get; set; }
	public object TrackComplete { get; }
	public object AnimationStart { get; set; }
	public object AnimationEnd { get; set; }
	public object AnimationLast { get; set; }
	public object AnimationTime { get; }
	public object TimeScale { get; set; }
	public object Alpha { get; set; }
	public object InterruptAlpha { get; }
	public object EventThreshold { get; set; }
	public object AttachmentThreshold { get; set; }
	public object DrawOrderThreshold { get; set; }
	public object Next { get; }
	public object Previous { get; }
	public object IsComplete { get; }
	public object MixTime { get; set; }
	public object MixDuration { get; set; }
	public object MixBlend { get; set; }
	public object MixingFrom { get; }
	public object MixingTo { get; }
	public object HoldPrevious { get; set; }
	public object Reverse { get; set; }
	public object IsEmptyAnimation { get; }

	// Methods

	// RVA: 0x6C59450
	public object add_Start(object value) { }

	// RVA: 0x6C594F4
	public object remove_Start(object value) { }

	// RVA: 0x6C59598
	public object add_Interrupt(object value) { }

	// RVA: 0x6C5963C
	public object remove_Interrupt(object value) { }

	// RVA: 0x6C596E0
	public object add_End(object value) { }

	// RVA: 0x6C59784
	public object remove_End(object value) { }

	// RVA: 0x6C59828
	public object add_Dispose(object value) { }

	// RVA: 0x6C598CC
	public object remove_Dispose(object value) { }

	// RVA: 0x6C59970
	public object add_Complete(object value) { }

	// RVA: 0x6C59A14
	public object remove_Complete(object value) { }

	// RVA: 0x6C59AB8
	public object add_Event(object value) { }

	// RVA: 0x6C59B5C
	public object remove_Event(object value) { }

	// RVA: 0x6C59C00
	internal object OnStart() { }

	// RVA: 0x6C59C20
	internal object OnInterrupt() { }

	// RVA: 0x6C59C40
	internal object OnEnd() { }

	// RVA: 0x6C59C60
	internal object OnDispose() { }

	// RVA: 0x6C59C80
	internal object OnComplete() { }

	// RVA: 0x6C59CA0
	internal object OnEvent(object e) { }

	// RVA: 0x6C59CC4
	public object Reset() { }

	// RVA: 0x6C59DA8
	public object get_TrackIndex() { }

	// RVA: 0x6C59DB0
	public object get_Animation() { }

	// RVA: 0x6C59DB8
	public object get_Loop() { }

	// RVA: 0x6C59DC0
	public object set_Loop(object value) { }

	// RVA: 0x6C59DC8
	public object get_Delay() { }

	// RVA: 0x6C59DD0
	public object set_Delay(object value) { }

	// RVA: 0x6C59DD8
	public object get_TrackTime() { }

	// RVA: 0x6C59DE0
	public object set_TrackTime(object value) { }

	// RVA: 0x6C59DE8
	public object get_TrackEnd() { }

	// RVA: 0x6C59DF0
	public object set_TrackEnd(object value) { }

	// RVA: 0x6C57DFC
	public object get_TrackComplete() { }

	// RVA: 0x6C59DF8
	public object get_AnimationStart() { }

	// RVA: 0x6C59E00
	public object set_AnimationStart(object value) { }

	// RVA: 0x6C59E08
	public object get_AnimationEnd() { }

	// RVA: 0x6C59E10
	public object set_AnimationEnd(object value) { }

	// RVA: 0x6C59E18
	public object get_AnimationLast() { }

	// RVA: 0x6C59E20
	public object set_AnimationLast(object value) { }

	// RVA: 0x6C562C0
	public object get_AnimationTime() { }

	// RVA: 0x6C59E28
	public object get_TimeScale() { }

	// RVA: 0x6C59E30
	public object set_TimeScale(object value) { }

	// RVA: 0x6C59E38
	public object get_Alpha() { }

	// RVA: 0x6C59E40
	public object set_Alpha(object value) { }

	// RVA: 0x6C59E48
	public object get_InterruptAlpha() { }

	// RVA: 0x6C59E50
	public object get_EventThreshold() { }

	// RVA: 0x6C59E58
	public object set_EventThreshold(object value) { }

	// RVA: 0x6C59E60
	public object get_AttachmentThreshold() { }

	// RVA: 0x6C59E68
	public object set_AttachmentThreshold(object value) { }

	// RVA: 0x6C59E70
	public object get_DrawOrderThreshold() { }

	// RVA: 0x6C59E78
	public object set_DrawOrderThreshold(object value) { }

	// RVA: 0x6C59E80
	public object get_Next() { }

	// RVA: 0x6C59E88
	public object get_Previous() { }

	// RVA: 0x6C59E90
	public object get_IsComplete() { }

	// RVA: 0x6C59EA8
	public object get_MixTime() { }

	// RVA: 0x6C59EB0
	public object set_MixTime(object value) { }

	// RVA: 0x6C59EB8
	public object get_MixDuration() { }

	// RVA: 0x6C59EC0
	public object set_MixDuration(object value) { }

	// RVA: 0x6C59EC8
	public object get_MixBlend() { }

	// RVA: 0x6C59ED0
	public object set_MixBlend(object value) { }

	// RVA: 0x6C59ED8
	public object get_MixingFrom() { }

	// RVA: 0x6C59EE0
	public object get_MixingTo() { }

	// RVA: 0x6C59EE8
	public object get_HoldPrevious() { }

	// RVA: 0x6C59EF0
	public object set_HoldPrevious(object value) { }

	// RVA: 0x6C59EF8
	public object get_Reverse() { }

	// RVA: 0x6C59F00
	public object set_Reverse(object value) { }

	// RVA: 0x6C59F08
	public object get_IsEmptyAnimation() { }

	// RVA: 0x6C59F7C
	public object ResetRotationDirections() { }

	// RVA: 0x6C59FDC
	public override object ToString() { }

	// RVA: 0x6C5A03C
	public object AllowImmediateQueue() { }

	// RVA: 0x6C5A050
	public object .ctor() { }

}

// Namespace: 
private struct EventQueueEntry
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object entry; // 0x0
	public object e; // 0x8

	// Methods

	// RVA: 0x6C5A52C
	public object .ctor(object eventType, object trackEntry, object e) { }

}

// Namespace: 
private enum EventType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object Interrupt;
	public const object End;
	public const object Dispose;
	public const object Complete;
	public const object Event;
}

// Namespace: Spine
internal class EventQueue
{

	// Fields
	private readonly object eventQueueEntries; // 0x8
	internal object drainDisabled; // 0x10
	private readonly object state; // 0x18
	private readonly object trackEntryPool; // 0x20
	private object AnimationsChanged; // 0x28

	// Methods

	// RVA: 0x6C5A170
	internal object add_AnimationsChanged(object value) { }

	// RVA: 0x6C5A214
	internal object remove_AnimationsChanged(object value) { }

	// RVA: 0x6C5A2B8
	internal object .ctor(object state, object HandleAnimationsChanged, object trackEntryPool) { }

	// RVA: 0x6C5A3E0
	internal object Start(object entry) { }

	// RVA: 0x6C5A538
	internal object Interrupt(object entry) { }

	// RVA: 0x6C5A684
	internal object End(object entry) { }

	// RVA: 0x6C5A7E8
	internal object Dispose(object entry) { }

	// RVA: 0x6C5A934
	internal object Complete(object entry) { }

	// RVA: 0x6C5AA80
	internal object Event(object entry, object e) { }

	// RVA: 0x6C5ABDC
	internal object Drain() { }

	// RVA: 0x6C5AEE8
	internal object Clear() { }

}

// Namespace: 
public interface IPoolable
{

	// Methods

	// RVA: -1
	public abstract object Reset() { }

}

// Namespace: Spine
internal class Pool<T0>
{

	// Fields
	public readonly object max; // 0x0
	private readonly object freeObjects; // 0x0
	private object <Peak>k__BackingField; // 0x0

	// Properties
	public object Count { get; }
	public object Peak { get; set; }

	// Methods

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Peak() { }

	// RVA: -1
	private object set_Peak(object value) { }

	// RVA: -1
	public object .ctor(object initialCapacity, object max) { }

	// RVA: -1
	public object Obtain() { }

	// RVA: -1
	public object Free(object obj) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	protected object Reset(object obj) { }

}

// Namespace: Spine
public static class HashSetExtensions
{

	// Methods

	// RVA: -1
	public static object AddAll(object set, object addSet) { }

}

// Namespace: 
public struct AnimationPair
{

	// Fields
	public readonly object a1; // 0xFFFFFFFFFFFFFFF8
	public readonly object a2; // 0x0

	// Methods

	// RVA: 0x6C5B370
	public object .ctor(object a1, object a2) { }

	// RVA: 0x6C5B4EC
	public override object ToString() { }

}

// Namespace: 
public class AnimationPairComparer
{

	// Fields
	public static readonly object Instance; // 0x0

	// Methods

	// RVA: 0x6C5B5E4
	private object System.Collections.Generic.IEqualityComparer<Spine.AnimationStateData.AnimationPair>.Equals(object x, object y) { }

	// RVA: 0x6C5B5F4
	private object System.Collections.Generic.IEqualityComparer<Spine.AnimationStateData.AnimationPair>.GetHashCode(object obj) { }

	// RVA: 0x6C5B688
	public object .ctor() { }

	// RVA: 0x6C5B690
	private static object .cctor() { }

}

// Namespace: Spine
public class AnimationStateData
{

	// Fields
	internal object skeletonData; // 0x8
	private readonly object animationToMixTime; // 0x10
	internal object defaultMix; // 0x18

	// Properties
	public object SkeletonData { get; }
	public object DefaultMix { get; set; }

	// Methods

	// RVA: 0x6C5AFAC
	public object get_SkeletonData() { }

	// RVA: 0x6C5AFB4
	public object get_DefaultMix() { }

	// RVA: 0x6C5AFBC
	public object set_DefaultMix(object value) { }

	// RVA: 0x6C5AFC4
	public object .ctor(object skeletonData) { }

	// RVA: 0x6C5B0EC
	public object SetMix(object fromName, object toName, object duration) { }

	// RVA: 0x6C5B220
	public object SetMix(object from, object to, object duration) { }

	// RVA: 0x6C5B378
	public object GetMix(object from, object to) { }

}

// Namespace: 
private sealed class <>c__DisplayClass10_0
{

	// Fields
	public object page; // 0x8
	public object entry; // 0x10
	public object region; // 0x18

	// Methods

	// RVA: 0x6C5CBD4
	public object .ctor() { }

	// RVA: 0x6C5D210
	internal object <.ctor>b__0() { }

	// RVA: 0x6C5D318
	internal object <.ctor>b__1() { }

	// RVA: 0x6C5D488
	internal object <.ctor>b__2() { }

	// RVA: 0x6C5D678
	internal object <.ctor>b__3() { }

	// RVA: 0x6C5D760
	internal object <.ctor>b__4() { }

	// RVA: 0x6C5D7F0
	internal object <.ctor>b__5() { }

	// RVA: 0x6C5D8F8
	internal object <.ctor>b__6() { }

	// RVA: 0x6C5DA00
	internal object <.ctor>b__7() { }

	// RVA: 0x6C5DBB0
	internal object <.ctor>b__8() { }

	// RVA: 0x6C5DCC0
	internal object <.ctor>b__9() { }

	// RVA: 0x6C5DDC8
	internal object <.ctor>b__10() { }

	// RVA: 0x6C5DF80
	internal object <.ctor>b__11() { }

	// RVA: 0x6C5E098
	internal object <.ctor>b__12() { }

}

// Namespace: Spine
public class Atlas
{

	// Fields
	private readonly object pages; // 0x8
	private object regions; // 0x10
	private object textureLoader; // 0x18

	// Properties
	public object Regions { get; }
	public object Pages { get; }

	// Methods

	// RVA: 0x6C5B6F0
	public object GetEnumerator() { }

	// RVA: 0x6C5B78C
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x6C5B828
	public object get_Regions() { }

	// RVA: 0x6C5B830
	public object get_Pages() { }

	// RVA: 0x6C5B838
	public object .ctor(object pages, object regions) { }

	// RVA: 0x6C5B9B0
	public object .ctor(object reader, object imagesDir, object textureLoader) { }

	// RVA: 0x6C5CBDC
	private static object ReadEntry(object entry, object line) { }

	// RVA: 0x6C5CEA4
	public object FlipV() { }

	// RVA: 0x6C5CF80
	public object FindRegion(object name) { }

	// RVA: 0x6C5D08C
	public object Dispose() { }

}

// Namespace: Spine
public enum Format
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Alpha;
	public const object Intensity;
	public const object LuminanceAlpha;
	public const object RGB565;
	public const object RGBA4444;
	public const object RGB888;
	public const object RGBA8888;
}

// Namespace: Spine
public enum TextureFilter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Nearest;
	public const object Linear;
	public const object MipMap;
	public const object MipMapNearestNearest;
	public const object MipMapLinearNearest;
	public const object MipMapNearestLinear;
	public const object MipMapLinearLinear;
}

// Namespace: Spine
public enum TextureWrap
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MirroredRepeat;
	public const object ClampToEdge;
	public const object Repeat;
}

// Namespace: Spine
public class AtlasPage
{

	// Fields
	public object name; // 0x8
	public object width; // 0x10
	public object height; // 0x14
	public object format; // 0x18
	public object minFilter; // 0x1C
	public object magFilter; // 0x20
	public object uWrap; // 0x24
	public object vWrap; // 0x28
	public object pma; // 0x2C
	public object rendererObject; // 0x30

	// Methods

	// RVA: 0x6C5E144
	public object Clone() { }

	// RVA: 0x6C5CE84
	public object .ctor() { }

}

// Namespace: Spine
public class AtlasRegion
{

	// Fields
	public object page; // 0x8
	public object name; // 0x10
	public object x; // 0x18
	public object y; // 0x1C
	public object width; // 0x20
	public object height; // 0x24
	public object u; // 0x28
	public object v; // 0x2C
	public object u2; // 0x30
	public object v2; // 0x34
	public object offsetX; // 0x38
	public object offsetY; // 0x3C
	public object originalWidth; // 0x40
	public object originalHeight; // 0x44
	public object degrees; // 0x48
	public object rotate; // 0x4C
	public object index; // 0x50
	public object names; // 0x58
	public object values; // 0x60

	// Methods

	// RVA: 0x6C5E1D8
	public object Clone() { }

	// RVA: 0x6C5CE9C
	public object .ctor() { }

}

// Namespace: Spine
public interface TextureLoader
{

	// Methods

	// RVA: -1
	public abstract object Load(object page, object path) { }

	// RVA: -1
	public abstract object Unload(object texture) { }

}

// Namespace: Spine
public class AtlasAttachmentLoader
{

	// Fields
	private object atlasArray; // 0x8

	// Methods

	// RVA: 0x6C5E26C
	public object .ctor(object atlasArray) { }

	// RVA: 0x6C5E2F8
	public object NewRegionAttachment(object skin, object name, object path) { }

	// RVA: 0x6C5E69C
	public object NewMeshAttachment(object skin, object name, object path) { }

	// RVA: 0x6C5E8CC
	public object NewBoundingBoxAttachment(object skin, object name) { }

	// RVA: 0x6C5E9F8
	public object NewPathAttachment(object skin, object name) { }

	// RVA: 0x6C5EB24
	public object NewPointAttachment(object skin, object name) { }

	// RVA: 0x6C5EB8C
	public object NewClippingAttachment(object skin, object name) { }

	// RVA: 0x6C5E4A8
	public object FindRegion(object name) { }

}

// Namespace: Spine
public abstract class Attachment
{

	// Fields
	private object <Name>k__BackingField; // 0x8

	// Properties
	public object Name { get; set; }

	// Methods

	// RVA: 0x6C5ECB8
	public object get_Name() { }

	// RVA: 0x6C5ECC0
	private object set_Name(object value) { }

	// RVA: 0x6C5ECC8
	protected object .ctor(object name) { }

	// RVA: 0x6C5ED54
	public override object ToString() { }

	// RVA: -1
	public abstract object Copy() { }

}

// Namespace: Spine
public interface IHasRendererObject
{

	// Properties
	public abstract object RendererObject { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_RendererObject() { }

	// RVA: -1
	public abstract object set_RendererObject(object value) { }

}

// Namespace: Spine
public interface AttachmentLoader
{

	// Methods

	// RVA: -1
	public abstract object NewRegionAttachment(object skin, object name, object path) { }

	// RVA: -1
	public abstract object NewMeshAttachment(object skin, object name, object path) { }

	// RVA: -1
	public abstract object NewBoundingBoxAttachment(object skin, object name) { }

	// RVA: -1
	public abstract object NewPathAttachment(object skin, object name) { }

	// RVA: -1
	public abstract object NewPointAttachment(object skin, object name) { }

	// RVA: -1
	public abstract object NewClippingAttachment(object skin, object name) { }

}

// Namespace: Spine
public enum AttachmentType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Region;
	public const object Boundingbox;
	public const object Mesh;
	public const object Linkedmesh;
	public const object Path;
	public const object Point;
	public const object Clipping;
}

// Namespace: Spine
public class BoundingBoxAttachment
{

	// Methods

	// RVA: 0x6C5E96C
	public object .ctor(object name) { }

	// RVA: 0x6C5EEA8
	public override object Copy() { }

}

// Namespace: Spine
public class ClippingAttachment
{

	// Fields
	internal object endSlot; // 0x38

	// Properties
	public object EndSlot { get; set; }

	// Methods

	// RVA: 0x6C5F090
	public object get_EndSlot() { }

	// RVA: 0x6C5F098
	public object set_EndSlot(object value) { }

	// RVA: 0x6C5EC2C
	public object .ctor(object name) { }

	// RVA: 0x6C5F0A0
	public override object Copy() { }

}

// Namespace: Spine
public class MeshAttachment
{

	// Fields
	internal object regionOffsetX; // 0x38
	internal object regionOffsetY; // 0x3C
	internal object regionWidth; // 0x40
	internal object regionHeight; // 0x44
	internal object regionOriginalWidth; // 0x48
	internal object regionOriginalHeight; // 0x4C
	private object parentMesh; // 0x50
	internal object uvs; // 0x58
	internal object regionUVs; // 0x60
	internal object triangles; // 0x68
	internal object r; // 0x70
	internal object g; // 0x74
	internal object b; // 0x78
	internal object a; // 0x7C
	internal object hulllength; // 0x80
	private object <Path>k__BackingField; // 0x88
	private object <RendererObject>k__BackingField; // 0x90
	private object <RegionU>k__BackingField; // 0x98
	private object <RegionV>k__BackingField; // 0x9C
	private object <RegionU2>k__BackingField; // 0xA0
	private object <RegionV2>k__BackingField; // 0xA4
	private object <RegionDegrees>k__BackingField; // 0xA8
	private object <Edges>k__BackingField; // 0xB0
	private object <Width>k__BackingField; // 0xB8
	private object <Height>k__BackingField; // 0xBC

	// Properties
	public object HullLength { get; set; }
	public object RegionUVs { get; set; }
	public object UVs { get; set; }
	public object Triangles { get; set; }
	public object R { get; set; }
	public object G { get; set; }
	public object B { get; set; }
	public object A { get; set; }
	public object Path { get; set; }
	public object RendererObject { get; set; }
	public object RegionU { get; set; }
	public object RegionV { get; set; }
	public object RegionU2 { get; set; }
	public object RegionV2 { get; set; }
	public object RegionDegrees { get; set; }
	public object RegionOffsetX { get; set; }
	public object RegionOffsetY { get; set; }
	public object RegionWidth { get; set; }
	public object RegionHeight { get; set; }
	public object RegionOriginalWidth { get; set; }
	public object RegionOriginalHeight { get; set; }
	public object ParentMesh { get; set; }
	public object Edges { get; set; }
	public object Width { get; set; }
	public object Height { get; set; }

	// Methods

	// RVA: 0x6C5F170
	public object get_HullLength() { }

	// RVA: 0x6C5F178
	public object set_HullLength(object value) { }

	// RVA: 0x6C5F180
	public object get_RegionUVs() { }

	// RVA: 0x6C5F188
	public object set_RegionUVs(object value) { }

	// RVA: 0x6C5F190
	public object get_UVs() { }

	// RVA: 0x6C5F198
	public object set_UVs(object value) { }

	// RVA: 0x6C5F1A0
	public object get_Triangles() { }

	// RVA: 0x6C5F1A8
	public object set_Triangles(object value) { }

	// RVA: 0x6C5F1B0
	public object get_R() { }

	// RVA: 0x6C5F1B8
	public object set_R(object value) { }

	// RVA: 0x6C5F1C0
	public object get_G() { }

	// RVA: 0x6C5F1C8
	public object set_G(object value) { }

	// RVA: 0x6C5F1D0
	public object get_B() { }

	// RVA: 0x6C5F1D8
	public object set_B(object value) { }

	// RVA: 0x6C5F1E0
	public object get_A() { }

	// RVA: 0x6C5F1E8
	public object set_A(object value) { }

	// RVA: 0x6C5F1F0
	public object get_Path() { }

	// RVA: 0x6C5F1F8
	public object set_Path(object value) { }

	// RVA: 0x6C5F200
	public object get_RendererObject() { }

	// RVA: 0x6C5F208
	public object set_RendererObject(object value) { }

	// RVA: 0x6C5F210
	public object get_RegionU() { }

	// RVA: 0x6C5F218
	public object set_RegionU(object value) { }

	// RVA: 0x6C5F220
	public object get_RegionV() { }

	// RVA: 0x6C5F228
	public object set_RegionV(object value) { }

	// RVA: 0x6C5F230
	public object get_RegionU2() { }

	// RVA: 0x6C5F238
	public object set_RegionU2(object value) { }

	// RVA: 0x6C5F240
	public object get_RegionV2() { }

	// RVA: 0x6C5F248
	public object set_RegionV2(object value) { }

	// RVA: 0x6C5F250
	public object get_RegionDegrees() { }

	// RVA: 0x6C5F258
	public object set_RegionDegrees(object value) { }

	// RVA: 0x6C5F260
	public object get_RegionOffsetX() { }

	// RVA: 0x6C5F268
	public object set_RegionOffsetX(object value) { }

	// RVA: 0x6C5F270
	public object get_RegionOffsetY() { }

	// RVA: 0x6C5F278
	public object set_RegionOffsetY(object value) { }

	// RVA: 0x6C5F280
	public object get_RegionWidth() { }

	// RVA: 0x6C5F288
	public object set_RegionWidth(object value) { }

	// RVA: 0x6C5F290
	public object get_RegionHeight() { }

	// RVA: 0x6C5F298
	public object set_RegionHeight(object value) { }

	// RVA: 0x6C5F2A0
	public object get_RegionOriginalWidth() { }

	// RVA: 0x6C5F2A8
	public object set_RegionOriginalWidth(object value) { }

	// RVA: 0x6C5F2B0
	public object get_RegionOriginalHeight() { }

	// RVA: 0x6C5F2B8
	public object set_RegionOriginalHeight(object value) { }

	// RVA: 0x6C5F2C0
	public object get_ParentMesh() { }

	// RVA: 0x6C5F2C8
	public object set_ParentMesh(object value) { }

	// RVA: 0x6C5F304
	public object get_Edges() { }

	// RVA: 0x6C5F30C
	public object set_Edges(object value) { }

	// RVA: 0x6C5F314
	public object get_Width() { }

	// RVA: 0x6C5F31C
	public object set_Width(object value) { }

	// RVA: 0x6C5F324
	public object get_Height() { }

	// RVA: 0x6C5F32C
	public object set_Height(object value) { }

	// RVA: 0x6C5E830
	public object .ctor(object name) { }

	// RVA: 0x6C5F334
	public object UpdateUVs() { }

	// RVA: 0x6C5F724
	public override object Copy() { }

	// RVA: 0x6C5F9A0
	public object NewLinkedMesh() { }

}

// Namespace: Spine
public class PathAttachment
{

	// Fields
	internal object lengths; // 0x38
	internal object closed; // 0x40
	internal object constantSpeed; // 0x41

	// Properties
	public object Lengths { get; set; }
	public object Closed { get; set; }
	public object ConstantSpeed { get; set; }

	// Methods

	// RVA: 0x6C5FAD0
	public object get_Lengths() { }

	// RVA: 0x6C5FAD8
	public object set_Lengths(object value) { }

	// RVA: 0x6C5FAE0
	public object get_Closed() { }

	// RVA: 0x6C5FAE8
	public object set_Closed(object value) { }

	// RVA: 0x6C5FAF0
	public object get_ConstantSpeed() { }

	// RVA: 0x6C5FAF8
	public object set_ConstantSpeed(object value) { }

	// RVA: 0x6C5EA98
	public object .ctor(object name) { }

	// RVA: 0x6C5FB00
	public override object Copy() { }

}

// Namespace: Spine
public class PointAttachment
{

	// Fields
	internal object x; // 0x10
	internal object y; // 0x14
	internal object rotation; // 0x18

	// Properties
	public object X { get; set; }
	public object Y { get; set; }
	public object Rotation { get; set; }

	// Methods

	// RVA: 0x6C5FC34
	public object get_X() { }

	// RVA: 0x6C5FC3C
	public object set_X(object value) { }

	// RVA: 0x6C5FC44
	public object get_Y() { }

	// RVA: 0x6C5FC4C
	public object set_Y(object value) { }

	// RVA: 0x6C5FC54
	public object get_Rotation() { }

	// RVA: 0x6C5FC5C
	public object set_Rotation(object value) { }

	// RVA: 0x6C5EB88
	public object .ctor(object name) { }

	// RVA: 0x6C5FC64
	public object ComputeWorldPosition(object bone, object ox, object oy) { }

	// RVA: 0x6C5FCF8
	public object ComputeWorldRotation(object bone) { }

	// RVA: 0x6C60044
	public override object Copy() { }

}

// Namespace: Spine
public class RegionAttachment
{

	// Fields
	public const object BLX;
	public const object BLY;
	public const object ULX;
	public const object ULY;
	public const object URX;
	public const object URY;
	public const object BRX;
	public const object BRY;
	internal object x; // 0x10
	internal object y; // 0x14
	internal object rotation; // 0x18
	internal object scaleX; // 0x1C
	internal object scaleY; // 0x20
	internal object width; // 0x24
	internal object height; // 0x28
	internal object regionOffsetX; // 0x2C
	internal object regionOffsetY; // 0x30
	internal object regionWidth; // 0x34
	internal object regionHeight; // 0x38
	internal object regionOriginalWidth; // 0x3C
	internal object regionOriginalHeight; // 0x40
	internal object offset; // 0x48
	internal object uvs; // 0x50
	internal object r; // 0x58
	internal object g; // 0x5C
	internal object b; // 0x60
	internal object a; // 0x64
	private object <Path>k__BackingField; // 0x68
	private object <RendererObject>k__BackingField; // 0x70

	// Properties
	public object X { get; set; }
	public object Y { get; set; }
	public object Rotation { get; set; }
	public object ScaleX { get; set; }
	public object ScaleY { get; set; }
	public object Width { get; set; }
	public object Height { get; set; }
	public object R { get; set; }
	public object G { get; set; }
	public object B { get; set; }
	public object A { get; set; }
	public object Path { get; set; }
	public object RendererObject { get; set; }
	public object RegionOffsetX { get; set; }
	public object RegionOffsetY { get; set; }
	public object RegionWidth { get; set; }
	public object RegionHeight { get; set; }
	public object RegionOriginalWidth { get; set; }
	public object RegionOriginalHeight { get; set; }
	public object Offset { get; }
	public object UVs { get; }

	// Methods

	// RVA: 0x6C600CC
	public object get_X() { }

	// RVA: 0x6C600D4
	public object set_X(object value) { }

	// RVA: 0x6C600DC
	public object get_Y() { }

	// RVA: 0x6C600E4
	public object set_Y(object value) { }

	// RVA: 0x6C600EC
	public object get_Rotation() { }

	// RVA: 0x6C600F4
	public object set_Rotation(object value) { }

	// RVA: 0x6C600FC
	public object get_ScaleX() { }

	// RVA: 0x6C60104
	public object set_ScaleX(object value) { }

	// RVA: 0x6C6010C
	public object get_ScaleY() { }

	// RVA: 0x6C60114
	public object set_ScaleY(object value) { }

	// RVA: 0x6C6011C
	public object get_Width() { }

	// RVA: 0x6C60124
	public object set_Width(object value) { }

	// RVA: 0x6C6012C
	public object get_Height() { }

	// RVA: 0x6C60134
	public object set_Height(object value) { }

	// RVA: 0x6C6013C
	public object get_R() { }

	// RVA: 0x6C60144
	public object set_R(object value) { }

	// RVA: 0x6C6014C
	public object get_G() { }

	// RVA: 0x6C60154
	public object set_G(object value) { }

	// RVA: 0x6C6015C
	public object get_B() { }

	// RVA: 0x6C60164
	public object set_B(object value) { }

	// RVA: 0x6C6016C
	public object get_A() { }

	// RVA: 0x6C60174
	public object set_A(object value) { }

	// RVA: 0x6C6017C
	public object get_Path() { }

	// RVA: 0x6C60184
	public object set_Path(object value) { }

	// RVA: 0x6C6018C
	public object get_RendererObject() { }

	// RVA: 0x6C60194
	public object set_RendererObject(object value) { }

	// RVA: 0x6C6019C
	public object get_RegionOffsetX() { }

	// RVA: 0x6C601A4
	public object set_RegionOffsetX(object value) { }

	// RVA: 0x6C601AC
	public object get_RegionOffsetY() { }

	// RVA: 0x6C601B4
	public object set_RegionOffsetY(object value) { }

	// RVA: 0x6C601BC
	public object get_RegionWidth() { }

	// RVA: 0x6C601C4
	public object set_RegionWidth(object value) { }

	// RVA: 0x6C601CC
	public object get_RegionHeight() { }

	// RVA: 0x6C601D4
	public object set_RegionHeight(object value) { }

	// RVA: 0x6C601DC
	public object get_RegionOriginalWidth() { }

	// RVA: 0x6C601E4
	public object set_RegionOriginalWidth(object value) { }

	// RVA: 0x6C601EC
	public object get_RegionOriginalHeight() { }

	// RVA: 0x6C601F4
	public object set_RegionOriginalHeight(object value) { }

	// RVA: 0x6C601FC
	public object get_Offset() { }

	// RVA: 0x6C60204
	public object get_UVs() { }

	// RVA: 0x6C5E528
	public object .ctor(object name) { }

	// RVA: 0x6C6020C
	public object UpdateOffset() { }

	// RVA: 0x6C5E5B0
	public object SetUVs(object u, object v, object u2, object v2, object degrees) { }

	// RVA: 0x6C60498
	public object ComputeWorldVertices(object bone, object worldVertices, object offset, object stride) { }

	// RVA: 0x6C60614
	public override object Copy() { }

}

// Namespace: Spine
public abstract class VertexAttachment
{

	// Fields
	private static object nextID; // 0x0
	private static readonly object nextIdLock; // 0x8
	internal readonly object id; // 0x10
	internal object bones; // 0x18
	internal object vertices; // 0x20
	internal object worldVerticesLength; // 0x28
	internal object deformAttachment; // 0x30

	// Properties
	public object Id { get; }
	public object Bones { get; set; }
	public object Vertices { get; set; }
	public object WorldVerticesLength { get; set; }
	public object DeformAttachment { get; set; }

	// Methods

	// RVA: 0x6C60750
	public object get_Id() { }

	// RVA: 0x6C60758
	public object get_Bones() { }

	// RVA: 0x6C60760
	public object set_Bones(object value) { }

	// RVA: 0x6C60768
	public object get_Vertices() { }

	// RVA: 0x6C60770
	public object set_Vertices(object value) { }

	// RVA: 0x6C60778
	public object get_WorldVerticesLength() { }

	// RVA: 0x6C60780
	public object set_WorldVerticesLength(object value) { }

	// RVA: 0x6C60788
	public object get_DeformAttachment() { }

	// RVA: 0x6C60790
	public object set_DeformAttachment(object value) { }

	// RVA: 0x6C5ED5C
	public object .ctor(object name) { }

	// RVA: 0x6C60798
	public object ComputeWorldVertices(object slot, object worldVertices) { }

	// RVA: 0x6C607B0
	public object ComputeWorldVertices(object slot, object start, object count, object worldVertices, object offset, object stride) { }

	// RVA: 0x6C5EF60
	internal object CopyTo(object attachment) { }

	// RVA: 0x6C60E68
	private static object .cctor() { }

}

// Namespace: Spine
public enum BlendMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Additive;
	public const object Multiply;
	public const object Screen;
}

// Namespace: Spine
public class Bone
{

	// Fields
	public static object yDown; // 0x0
	internal object data; // 0x8
	internal object skeleton; // 0x10
	internal object parent; // 0x18
	internal object children; // 0x20
	internal object x; // 0x28
	internal object y; // 0x2C
	internal object rotation; // 0x30
	internal object scaleX; // 0x34
	internal object scaleY; // 0x38
	internal object shearX; // 0x3C
	internal object shearY; // 0x40
	internal object ax; // 0x44
	internal object ay; // 0x48
	internal object arotation; // 0x4C
	internal object ascaleX; // 0x50
	internal object ascaleY; // 0x54
	internal object ashearX; // 0x58
	internal object ashearY; // 0x5C
	internal object a; // 0x60
	internal object b; // 0x64
	internal object worldX; // 0x68
	internal object c; // 0x6C
	internal object d; // 0x70
	internal object worldY; // 0x74
	internal object sorted; // 0x78
	internal object active; // 0x79

	// Properties
	public object Data { get; }
	public object Skeleton { get; }
	public object Parent { get; }
	public object Children { get; }
	public object Active { get; }
	public object X { get; set; }
	public object Y { get; set; }
	public object Rotation { get; set; }
	public object ScaleX { get; set; }
	public object ScaleY { get; set; }
	public object ShearX { get; set; }
	public object ShearY { get; set; }
	public object AppliedRotation { get; set; }
	public object AX { get; set; }
	public object AY { get; set; }
	public object AScaleX { get; set; }
	public object AScaleY { get; set; }
	public object AShearX { get; set; }
	public object AShearY { get; set; }
	public object A { get; set; }
	public object B { get; set; }
	public object C { get; set; }
	public object D { get; set; }
	public object WorldX { get; set; }
	public object WorldY { get; set; }
	public object WorldRotationX { get; }
	public object WorldRotationY { get; }
	public object WorldScaleX { get; }
	public object WorldScaleY { get; }
	public object WorldToLocalRotationX { get; }
	public object WorldToLocalRotationY { get; }

	// Methods

	// RVA: 0x6C60EF0
	public object get_Data() { }

	// RVA: 0x6C60EF8
	public object get_Skeleton() { }

	// RVA: 0x6C60F00
	public object get_Parent() { }

	// RVA: 0x6C60F08
	public object get_Children() { }

	// RVA: 0x6C60F10
	public object get_Active() { }

	// RVA: 0x6C60F18
	public object get_X() { }

	// RVA: 0x6C60F20
	public object set_X(object value) { }

	// RVA: 0x6C60F28
	public object get_Y() { }

	// RVA: 0x6C60F30
	public object set_Y(object value) { }

	// RVA: 0x6C60F38
	public object get_Rotation() { }

	// RVA: 0x6C60F40
	public object set_Rotation(object value) { }

	// RVA: 0x6C60F48
	public object get_ScaleX() { }

	// RVA: 0x6C60F50
	public object set_ScaleX(object value) { }

	// RVA: 0x6C60F58
	public object get_ScaleY() { }

	// RVA: 0x6C60F60
	public object set_ScaleY(object value) { }

	// RVA: 0x6C60F68
	public object get_ShearX() { }

	// RVA: 0x6C60F70
	public object set_ShearX(object value) { }

	// RVA: 0x6C60F78
	public object get_ShearY() { }

	// RVA: 0x6C60F80
	public object set_ShearY(object value) { }

	// RVA: 0x6C60F88
	public object get_AppliedRotation() { }

	// RVA: 0x6C60F90
	public object set_AppliedRotation(object value) { }

	// RVA: 0x6C60F98
	public object get_AX() { }

	// RVA: 0x6C60FA0
	public object set_AX(object value) { }

	// RVA: 0x6C60FA8
	public object get_AY() { }

	// RVA: 0x6C60FB0
	public object set_AY(object value) { }

	// RVA: 0x6C60FB8
	public object get_AScaleX() { }

	// RVA: 0x6C60FC0
	public object set_AScaleX(object value) { }

	// RVA: 0x6C60FC8
	public object get_AScaleY() { }

	// RVA: 0x6C60FD0
	public object set_AScaleY(object value) { }

	// RVA: 0x6C60FD8
	public object get_AShearX() { }

	// RVA: 0x6C60FE0
	public object set_AShearX(object value) { }

	// RVA: 0x6C60FE8
	public object get_AShearY() { }

	// RVA: 0x6C60FF0
	public object set_AShearY(object value) { }

	// RVA: 0x6C60FF8
	public object get_A() { }

	// RVA: 0x6C61000
	public object set_A(object value) { }

	// RVA: 0x6C61008
	public object get_B() { }

	// RVA: 0x6C61010
	public object set_B(object value) { }

	// RVA: 0x6C61018
	public object get_C() { }

	// RVA: 0x6C61020
	public object set_C(object value) { }

	// RVA: 0x6C61028
	public object get_D() { }

	// RVA: 0x6C61030
	public object set_D(object value) { }

	// RVA: 0x6C61038
	public object get_WorldX() { }

	// RVA: 0x6C61040
	public object set_WorldX(object value) { }

	// RVA: 0x6C61048
	public object get_WorldY() { }

	// RVA: 0x6C61050
	public object set_WorldY(object value) { }

	// RVA: 0x6C61058
	public object get_WorldRotationX() { }

	// RVA: 0x6C61154
	public object get_WorldRotationY() { }

	// RVA: 0x6C61250
	public object get_WorldScaleX() { }

	// RVA: 0x6C612CC
	public object get_WorldScaleY() { }

	// RVA: 0x6C61348
	public object .ctor(object data, object skeleton, object parent) { }

	// RVA: 0x6C614D4
	public object Update() { }

	// RVA: 0x6C625DC
	public object UpdateWorldTransform() { }

	// RVA: 0x6C614E8
	public object UpdateWorldTransform(object x, object y, object rotation, object scaleX, object scaleY, object shearX, object shearY) { }

	// RVA: 0x6C6149C
	public object SetToSetupPose() { }

	// RVA: 0x6C62728
	public object UpdateAppliedTransform() { }

	// RVA: 0x6C62C04
	public object WorldToLocal(object worldX, object worldY, object localX, object localY) { }

	// RVA: 0x6C5FCBC
	public object LocalToWorld(object localX, object localY, object worldX, object worldY) { }

	// RVA: 0x6C62C50
	public object get_WorldToLocalRotationX() { }

	// RVA: 0x6C62D60
	public object get_WorldToLocalRotationY() { }

	// RVA: 0x6C62E70
	public object WorldToLocalRotation(object worldRotation) { }

	// RVA: 0x6C63058
	public object LocalToWorldRotation(object localRotation) { }

	// RVA: 0x6C63250
	public object RotateWorld(object degrees) { }

	// RVA: 0x6C633C0
	public override object ToString() { }

}

// Namespace: Spine
public class BoneData
{

	// Fields
	internal object index; // 0x8
	internal object name; // 0x10
	internal object parent; // 0x18
	internal object length; // 0x20
	internal object x; // 0x24
	internal object y; // 0x28
	internal object rotation; // 0x2C
	internal object scaleX; // 0x30
	internal object scaleY; // 0x34
	internal object shearX; // 0x38
	internal object shearY; // 0x3C
	internal object transformMode; // 0x40
	internal object skinRequired; // 0x44

	// Properties
	public object Index { get; }
	public object Name { get; }
	public object Parent { get; }
	public object Length { get; set; }
	public object X { get; set; }
	public object Y { get; set; }
	public object Rotation { get; set; }
	public object ScaleX { get; set; }
	public object ScaleY { get; set; }
	public object ShearX { get; set; }
	public object ShearY { get; set; }
	public object TransformMode { get; set; }
	public object SkinRequired { get; set; }

	// Methods

	// RVA: 0x6C633E4
	public object get_Index() { }

	// RVA: 0x6C633EC
	public object get_Name() { }

	// RVA: 0x6C633F4
	public object get_Parent() { }

	// RVA: 0x6C633FC
	public object get_Length() { }

	// RVA: 0x6C63404
	public object set_Length(object value) { }

	// RVA: 0x6C6340C
	public object get_X() { }

	// RVA: 0x6C63414
	public object set_X(object value) { }

	// RVA: 0x6C6341C
	public object get_Y() { }

	// RVA: 0x6C63424
	public object set_Y(object value) { }

	// RVA: 0x6C6342C
	public object get_Rotation() { }

	// RVA: 0x6C63434
	public object set_Rotation(object value) { }

	// RVA: 0x6C6343C
	public object get_ScaleX() { }

	// RVA: 0x6C63444
	public object set_ScaleX(object value) { }

	// RVA: 0x6C6344C
	public object get_ScaleY() { }

	// RVA: 0x6C63454
	public object set_ScaleY(object value) { }

	// RVA: 0x6C6345C
	public object get_ShearX() { }

	// RVA: 0x6C63464
	public object set_ShearX(object value) { }

	// RVA: 0x6C6346C
	public object get_ShearY() { }

	// RVA: 0x6C63474
	public object set_ShearY(object value) { }

	// RVA: 0x6C6347C
	public object get_TransformMode() { }

	// RVA: 0x6C63484
	public object set_TransformMode(object value) { }

	// RVA: 0x6C6348C
	public object get_SkinRequired() { }

	// RVA: 0x6C63494
	public object set_SkinRequired(object value) { }

	// RVA: 0x6C6349C
	public object .ctor(object index, object name, object parent) { }

	// RVA: 0x6C635A4
	public override object ToString() { }

}

// Namespace: Spine
public enum TransformMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object OnlyTranslation;
	public const object NoRotationOrReflection;
	public const object NoScale;
	public const object NoScaleOrReflection;
}

// Namespace: Spine
public abstract class ConstraintData
{

	// Fields
	internal readonly object name; // 0x8
	internal object order; // 0x10
	internal object skinRequired; // 0x14

	// Properties
	public object Name { get; }
	public object Order { get; set; }
	public object SkinRequired { get; set; }

	// Methods

	// RVA: 0x6C635AC
	public object .ctor(object name) { }

	// RVA: 0x6C63638
	public object get_Name() { }

	// RVA: 0x6C63640
	public object get_Order() { }

	// RVA: 0x6C63648
	public object set_Order(object value) { }

	// RVA: 0x6C63650
	public object get_SkinRequired() { }

	// RVA: 0x6C63658
	public object set_SkinRequired(object value) { }

	// RVA: 0x6C63660
	public override object ToString() { }

}

// Namespace: Spine
public class Event
{

	// Fields
	internal readonly object data; // 0x8
	internal readonly object time; // 0x10
	internal object intValue; // 0x14
	internal object floatValue; // 0x18
	internal object stringValue; // 0x20
	internal object volume; // 0x28
	internal object balance; // 0x2C

	// Properties
	public object Data { get; }
	public object Time { get; }
	public object Int { get; set; }
	public object Float { get; set; }
	public object String { get; set; }
	public object Volume { get; set; }
	public object Balance { get; set; }

	// Methods

	// RVA: 0x6C63668
	public object get_Data() { }

	// RVA: 0x6C63670
	public object get_Time() { }

	// RVA: 0x6C63678
	public object get_Int() { }

	// RVA: 0x6C63680
	public object set_Int(object value) { }

	// RVA: 0x6C63688
	public object get_Float() { }

	// RVA: 0x6C63690
	public object set_Float(object value) { }

	// RVA: 0x6C63698
	public object get_String() { }

	// RVA: 0x6C636A0
	public object set_String(object value) { }

	// RVA: 0x6C636A8
	public object get_Volume() { }

	// RVA: 0x6C636B0
	public object set_Volume(object value) { }

	// RVA: 0x6C636B8
	public object get_Balance() { }

	// RVA: 0x6C636C0
	public object set_Balance(object value) { }

	// RVA: 0x6C636C8
	public object .ctor(object time, object data) { }

	// RVA: 0x6C63764
	public override object ToString() { }

}

// Namespace: Spine
public class EventData
{

	// Fields
	internal object name; // 0x8
	private object <Int>k__BackingField; // 0x10
	private object <Float>k__BackingField; // 0x14
	private object <String>k__BackingField; // 0x18
	private object <AudioPath>k__BackingField; // 0x20
	private object <Volume>k__BackingField; // 0x28
	private object <Balance>k__BackingField; // 0x2C

	// Properties
	public object Name { get; }
	public object Int { get; set; }
	public object Float { get; set; }
	public object String { get; set; }
	public object AudioPath { get; set; }
	public object Volume { get; set; }
	public object Balance { get; set; }

	// Methods

	// RVA: 0x6C63788
	public object get_Name() { }

	// RVA: 0x6C63790
	public object get_Int() { }

	// RVA: 0x6C63798
	public object set_Int(object value) { }

	// RVA: 0x6C637A0
	public object get_Float() { }

	// RVA: 0x6C637A8
	public object set_Float(object value) { }

	// RVA: 0x6C637B0
	public object get_String() { }

	// RVA: 0x6C637B8
	public object set_String(object value) { }

	// RVA: 0x6C637C0
	public object get_AudioPath() { }

	// RVA: 0x6C637C8
	public object set_AudioPath(object value) { }

	// RVA: 0x6C637D0
	public object get_Volume() { }

	// RVA: 0x6C637D8
	public object set_Volume(object value) { }

	// RVA: 0x6C637E0
	public object get_Balance() { }

	// RVA: 0x6C637E8
	public object set_Balance(object value) { }

	// RVA: 0x6C637F0
	public object .ctor(object name) { }

	// RVA: 0x6C6387C
	public override object ToString() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object l; // 0x0
	private object next; // 0x0
	private object ver; // 0x0
	private object current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object l) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object VerifyState() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Spine
public class ExposedList<T0>
{

	// Fields
	public object Items; // 0x0
	public object Count; // 0x0
	private const object DefaultCapacity;
	private static readonly object EmptyArray; // 0x0
	private object version; // 0x0

	// Properties
	public object Capacity { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object collection) { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	internal object .ctor(object data, object size) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object GrowIfNeeded(object addedCount) { }

	// RVA: -1
	public object Resize(object newSize) { }

	// RVA: -1
	public object EnsureCapacity(object min) { }

	// RVA: -1
	private object CheckRange(object index, object count) { }

	// RVA: -1
	private object AddCollection(object collection) { }

	// RVA: -1
	private object AddEnumerable(object enumerable) { }

	// RVA: -1
	public object AddRange(object list) { }

	// RVA: -1
	public object AddRange(object collection) { }

	// RVA: -1
	public object BinarySearch(object item) { }

	// RVA: -1
	public object BinarySearch(object item, object comparer) { }

	// RVA: -1
	public object BinarySearch(object index, object count, object item, object comparer) { }

	// RVA: -1
	public object Clear(object clearArray) { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object ConvertAll(object converter) { }

	// RVA: -1
	public object CopyTo(object array) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object CopyTo(object index, object array, object arrayIndex, object count) { }

	// RVA: -1
	public object Exists(object match) { }

	// RVA: -1
	public object Find(object match) { }

	// RVA: -1
	private static object CheckMatch(object match) { }

	// RVA: -1
	public object FindAll(object match) { }

	// RVA: -1
	private object FindAllList(object match) { }

	// RVA: -1
	public object FindIndex(object match) { }

	// RVA: -1
	public object FindIndex(object startIndex, object match) { }

	// RVA: -1
	public object FindIndex(object startIndex, object count, object match) { }

	// RVA: -1
	private object GetIndex(object startIndex, object count, object match) { }

	// RVA: -1
	public object FindLast(object match) { }

	// RVA: -1
	public object FindLastIndex(object match) { }

	// RVA: -1
	public object FindLastIndex(object startIndex, object match) { }

	// RVA: -1
	public object FindLastIndex(object startIndex, object count, object match) { }

	// RVA: -1
	private object GetLastIndex(object startIndex, object count, object match) { }

	// RVA: -1
	public object ForEach(object action) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	public object GetRange(object index, object count) { }

	// RVA: -1
	public object IndexOf(object item) { }

	// RVA: -1
	public object IndexOf(object item, object index) { }

	// RVA: -1
	public object IndexOf(object item, object index, object count) { }

	// RVA: -1
	private object Shift(object start, object delta) { }

	// RVA: -1
	private object CheckIndex(object index) { }

	// RVA: -1
	public object Insert(object index, object item) { }

	// RVA: -1
	private object CheckCollection(object collection) { }

	// RVA: -1
	public object InsertRange(object index, object collection) { }

	// RVA: -1
	private object InsertCollection(object index, object collection) { }

	// RVA: -1
	private object InsertEnumeration(object index, object enumerable) { }

	// RVA: -1
	public object LastIndexOf(object item) { }

	// RVA: -1
	public object LastIndexOf(object item, object index) { }

	// RVA: -1
	public object LastIndexOf(object item, object index, object count) { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	public object RemoveAll(object match) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	public object Pop() { }

	// RVA: -1
	public object RemoveRange(object index, object count) { }

	// RVA: -1
	public object Reverse() { }

	// RVA: -1
	public object Reverse(object index, object count) { }

	// RVA: -1
	public object Sort() { }

	// RVA: -1
	public object Sort(object comparer) { }

	// RVA: -1
	public object Sort(object comparison) { }

	// RVA: -1
	public object Sort(object index, object count, object comparer) { }

	// RVA: -1
	public object ToArray() { }

	// RVA: -1
	public object TrimExcess() { }

	// RVA: -1
	public object TrueForAll(object match) { }

	// RVA: -1
	public object get_Capacity() { }

	// RVA: -1
	public object set_Capacity(object value) { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Spine
public class IkConstraint
{

	// Fields
	internal object data; // 0x8
	internal object bones; // 0x10
	internal object target; // 0x18
	internal object bendDirection; // 0x20
	internal object compress; // 0x24
	internal object stretch; // 0x25
	internal object mix; // 0x28
	internal object softness; // 0x2C
	internal object active; // 0x30

	// Properties
	public object Bones { get; }
	public object Target { get; set; }
	public object Mix { get; set; }
	public object Softness { get; set; }
	public object BendDirection { get; set; }
	public object Compress { get; set; }
	public object Stretch { get; set; }
	public object Active { get; }
	public object Data { get; }

	// Methods

	// RVA: 0x6C63884
	public object .ctor(object data, object skeleton) { }

	// RVA: 0x6C63D04
	public object .ctor(object constraint, object skeleton) { }

	// RVA: 0x6C640EC
	public object Update() { }

	// RVA: 0x6C65078
	public object get_Bones() { }

	// RVA: 0x6C65080
	public object get_Target() { }

	// RVA: 0x6C65088
	public object set_Target(object value) { }

	// RVA: 0x6C65090
	public object get_Mix() { }

	// RVA: 0x6C65098
	public object set_Mix(object value) { }

	// RVA: 0x6C650A0
	public object get_Softness() { }

	// RVA: 0x6C650A8
	public object set_Softness(object value) { }

	// RVA: 0x6C650B0
	public object get_BendDirection() { }

	// RVA: 0x6C650B8
	public object set_BendDirection(object value) { }

	// RVA: 0x6C650C0
	public object get_Compress() { }

	// RVA: 0x6C650C8
	public object set_Compress(object value) { }

	// RVA: 0x6C650D0
	public object get_Stretch() { }

	// RVA: 0x6C650D8
	public object set_Stretch(object value) { }

	// RVA: 0x6C650E0
	public object get_Active() { }

	// RVA: 0x6C650E8
	public object get_Data() { }

	// RVA: 0x6C650F0
	public override object ToString() { }

	// RVA: 0x6C6420C
	public static object Apply(object bone, object targetX, object targetY, object compress, object stretch, object uniform, object alpha) { }

	// RVA: 0x6C64618
	public static object Apply(object parent, object child, object targetX, object targetY, object bendDir, object stretch, object uniform, object softness, object alpha) { }

}

// Namespace: Spine
public class IkConstraintData
{

	// Fields
	internal object bones; // 0x18
	internal object target; // 0x20
	internal object bendDirection; // 0x28
	internal object compress; // 0x2C
	internal object stretch; // 0x2D
	internal object uniform; // 0x2E
	internal object mix; // 0x30
	internal object softness; // 0x34

	// Properties
	public object Bones { get; }
	public object Target { get; set; }
	public object Mix { get; set; }
	public object Softness { get; set; }
	public object BendDirection { get; set; }
	public object Compress { get; set; }
	public object Stretch { get; set; }
	public object Uniform { get; set; }

	// Methods

	// RVA: 0x6C65114
	public object .ctor(object name) { }

	// RVA: 0x6C651B0
	public object get_Bones() { }

	// RVA: 0x6C651B8
	public object get_Target() { }

	// RVA: 0x6C651C0
	public object set_Target(object value) { }

	// RVA: 0x6C651C8
	public object get_Mix() { }

	// RVA: 0x6C651D0
	public object set_Mix(object value) { }

	// RVA: 0x6C651D8
	public object get_Softness() { }

	// RVA: 0x6C651E0
	public object set_Softness(object value) { }

	// RVA: 0x6C651E8
	public object get_BendDirection() { }

	// RVA: 0x6C651F0
	public object set_BendDirection(object value) { }

	// RVA: 0x6C651F8
	public object get_Compress() { }

	// RVA: 0x6C65200
	public object set_Compress(object value) { }

	// RVA: 0x6C65208
	public object get_Stretch() { }

	// RVA: 0x6C65210
	public object set_Stretch(object value) { }

	// RVA: 0x6C65218
	public object get_Uniform() { }

	// RVA: 0x6C65220
	public object set_Uniform(object value) { }

}

// Namespace: Spine
public interface IUpdatable
{

	// Properties
	public abstract object Active { get; }

	// Methods

	// RVA: -1
	public abstract object Update() { }

	// RVA: -1
	public abstract object get_Active() { }

}

// Namespace: Spine
public static class Json
{

	// Methods

	// RVA: 0x6C65228
	public static object Deserialize(object text) { }

}

// Namespace: Spine
public static class MathUtils
{

	// Fields
	public const object PI;
	public const object PI2;
	public const object RadDeg;
	public const object DegRad;
	private static object random; // 0x0

	// Methods

	// RVA: 0x6C626C0
	public static object Sin(object radians) { }

	// RVA: 0x6C62658
	public static object Cos(object radians) { }

	// RVA: 0x6C5FF5C
	public static object SinDeg(object degrees) { }

	// RVA: 0x6C5FEE4
	public static object CosDeg(object degrees) { }

	// RVA: 0x6C5FFD4
	public static object Atan2(object y, object x) { }

	// RVA: 0x6C652E0
	public static object Clamp(object value, object min, object max) { }

	// RVA: 0x6C65300
	public static object RandomTriangle(object min, object max) { }

	// RVA: 0x6C65374
	public static object RandomTriangle(object min, object max, object mode) { }

	// RVA: 0x6C654C8
	private static object .cctor() { }

}

// Namespace: Spine
public abstract class IInterpolation
{

	// Fields
	public static object Pow2; // 0x0
	public static object Pow2Out; // 0x8

	// Methods

	// RVA: -1
	protected abstract object Apply(object a) { }

	// RVA: 0x6C65544
	public object Apply(object start, object end, object a) { }

	// RVA: 0x6C655B4
	protected object .ctor() { }

	// RVA: 0x6C655BC
	private static object .cctor() { }

}

// Namespace: Spine
public class Pow
{

	// Fields
	private object <Power>k__BackingField; // 0x8

	// Properties
	public object Power { get; set; }

	// Methods

	// RVA: 0x6C657D0
	public object get_Power() { }

	// RVA: 0x6C657D8
	public object set_Power(object value) { }

	// RVA: 0x6C656E0
	public object .ctor(object power) { }

	// RVA: 0x6C657E0
	protected override object Apply(object a) { }

}

// Namespace: Spine
public class PowOut
{

	// Methods

	// RVA: 0x6C65758
	public object .ctor(object power) { }

	// RVA: 0x6C658EC
	protected override object Apply(object a) { }

}

// Namespace: Spine
public class PathConstraint
{

	// Fields
	private const object NONE;
	private const object BEFORE;
	private const object AFTER;
	private const object Epsilon;
	internal object data; // 0x8
	internal object bones; // 0x10
	internal object target; // 0x18
	internal object position; // 0x20
	internal object spacing; // 0x24
	internal object mixRotate; // 0x28
	internal object mixX; // 0x2C
	internal object mixY; // 0x30
	internal object active; // 0x34
	internal object spaces; // 0x38
	internal object positions; // 0x40
	internal object world; // 0x48
	internal object curves; // 0x50
	internal object lengths; // 0x58
	internal object segments; // 0x60

	// Properties
	public object Position { get; set; }
	public object Spacing { get; set; }
	public object MixRotate { get; set; }
	public object MixX { get; set; }
	public object MixY { get; set; }
	public object Bones { get; }
	public object Target { get; set; }
	public object Active { get; }
	public object Data { get; }

	// Methods

	// RVA: 0x6C659A8
	public object .ctor(object data, object skeleton) { }

	// RVA: 0x6C65E70
	public object .ctor(object constraint, object skeleton) { }

	// RVA: 0x6C662A8
	public static object ArraysFill(object a, object fromIndex, object toIndex, object val) { }

	// RVA: 0x6C66364
	public object Update() { }

	// RVA: 0x6C67454
	private object ComputeWorldPositions(object path, object spacesCount, object tangents) { }

	// RVA: 0x6C684F0
	private static object AddBeforePosition(object p, object temp, object i, object output, object o) { }

	// RVA: 0x6C68758
	private static object AddAfterPosition(object p, object temp, object i, object output, object o) { }

	// RVA: 0x6C689C0
	private static object AddCurvePosition(object p, object x1, object y1, object cx1, object cy1, object cx2, object cy2, object x2, object y2, object output, object o, object tangents) { }

	// RVA: 0x6C68C2C
	public object get_Position() { }

	// RVA: 0x6C68C34
	public object set_Position(object value) { }

	// RVA: 0x6C68C3C
	public object get_Spacing() { }

	// RVA: 0x6C68C44
	public object set_Spacing(object value) { }

	// RVA: 0x6C68C4C
	public object get_MixRotate() { }

	// RVA: 0x6C68C54
	public object set_MixRotate(object value) { }

	// RVA: 0x6C68C5C
	public object get_MixX() { }

	// RVA: 0x6C68C64
	public object set_MixX(object value) { }

	// RVA: 0x6C68C6C
	public object get_MixY() { }

	// RVA: 0x6C68C74
	public object set_MixY(object value) { }

	// RVA: 0x6C68C7C
	public object get_Bones() { }

	// RVA: 0x6C68C84
	public object get_Target() { }

	// RVA: 0x6C68C8C
	public object set_Target(object value) { }

	// RVA: 0x6C68C94
	public object get_Active() { }

	// RVA: 0x6C68C9C
	public object get_Data() { }

}

// Namespace: Spine
public class PathConstraintData
{

	// Fields
	internal object bones; // 0x18
	internal object target; // 0x20
	internal object positionMode; // 0x28
	internal object spacingMode; // 0x2C
	internal object rotateMode; // 0x30
	internal object offsetRotation; // 0x34
	internal object position; // 0x38
	internal object spacing; // 0x3C
	internal object mixRotate; // 0x40
	internal object mixX; // 0x44
	internal object mixY; // 0x48

	// Properties
	public object Bones { get; }
	public object Target { get; set; }
	public object PositionMode { get; set; }
	public object SpacingMode { get; set; }
	public object RotateMode { get; set; }
	public object OffsetRotation { get; set; }
	public object Position { get; set; }
	public object Spacing { get; set; }
	public object RotateMix { get; set; }
	public object MixX { get; set; }
	public object MixY { get; set; }

	// Methods

	// RVA: 0x6C68CA4
	public object .ctor(object name) { }

	// RVA: 0x6C68D30
	public object get_Bones() { }

	// RVA: 0x6C68D38
	public object get_Target() { }

	// RVA: 0x6C68D40
	public object set_Target(object value) { }

	// RVA: 0x6C68D48
	public object get_PositionMode() { }

	// RVA: 0x6C68D50
	public object set_PositionMode(object value) { }

	// RVA: 0x6C68D58
	public object get_SpacingMode() { }

	// RVA: 0x6C68D60
	public object set_SpacingMode(object value) { }

	// RVA: 0x6C68D68
	public object get_RotateMode() { }

	// RVA: 0x6C68D70
	public object set_RotateMode(object value) { }

	// RVA: 0x6C68D78
	public object get_OffsetRotation() { }

	// RVA: 0x6C68D80
	public object set_OffsetRotation(object value) { }

	// RVA: 0x6C68D88
	public object get_Position() { }

	// RVA: 0x6C68D90
	public object set_Position(object value) { }

	// RVA: 0x6C68D98
	public object get_Spacing() { }

	// RVA: 0x6C68DA0
	public object set_Spacing(object value) { }

	// RVA: 0x6C68DA8
	public object get_RotateMix() { }

	// RVA: 0x6C68DB0
	public object set_RotateMix(object value) { }

	// RVA: 0x6C68DB8
	public object get_MixX() { }

	// RVA: 0x6C68DC0
	public object set_MixX(object value) { }

	// RVA: 0x6C68DC8
	public object get_MixY() { }

	// RVA: 0x6C68DD0
	public object set_MixY(object value) { }

}

// Namespace: Spine
public enum PositionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Fixed;
	public const object Percent;
}

// Namespace: Spine
public enum SpacingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Length;
	public const object Fixed;
	public const object Percent;
	public const object Proportional;
}

// Namespace: Spine
public enum RotateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Tangent;
	public const object Chain;
	public const object ChainScale;
}

// Namespace: Spine
public class Skeleton
{

	// Fields
	internal object data; // 0x8
	internal object bones; // 0x10
	internal object slots; // 0x18
	internal object drawOrder; // 0x20
	internal object ikConstraints; // 0x28
	internal object transformConstraints; // 0x30
	internal object pathConstraints; // 0x38
	internal object updateCache; // 0x40
	internal object skin; // 0x48
	internal object r; // 0x50
	internal object g; // 0x54
	internal object b; // 0x58
	internal object a; // 0x5C
	internal object time; // 0x60
	private object scaleX; // 0x64
	private object scaleY; // 0x68
	internal object x; // 0x6C
	internal object y; // 0x70

	// Properties
	public object Data { get; }
	public object Bones { get; }
	public object UpdateCacheList { get; }
	public object Slots { get; }
	public object DrawOrder { get; }
	public object IkConstraints { get; }
	public object PathConstraints { get; }
	public object TransformConstraints { get; }
	public object Skin { get; set; }
	public object R { get; set; }
	public object G { get; set; }
	public object B { get; set; }
	public object A { get; set; }
	public object Time { get; set; }
	public object X { get; set; }
	public object Y { get; set; }
	public object ScaleX { get; set; }
	public object ScaleY { get; set; }
	public object FlipX { get; set; }
	public object FlipY { get; set; }
	public object RootBone { get; }

	// Methods

	// RVA: 0x6C68DD8
	public object get_Data() { }

	// RVA: 0x6C68DE0
	public object get_Bones() { }

	// RVA: 0x6C68DE8
	public object get_UpdateCacheList() { }

	// RVA: 0x6C68DF0
	public object get_Slots() { }

	// RVA: 0x6C68DF8
	public object get_DrawOrder() { }

	// RVA: 0x6C68E00
	public object get_IkConstraints() { }

	// RVA: 0x6C68E08
	public object get_PathConstraints() { }

	// RVA: 0x6C68E10
	public object get_TransformConstraints() { }

	// RVA: 0x6C68E18
	public object get_Skin() { }

	// RVA: 0x6C68E20
	public object set_Skin(object value) { }

	// RVA: 0x6C68F54
	public object get_R() { }

	// RVA: 0x6C68F5C
	public object set_R(object value) { }

	// RVA: 0x6C68F64
	public object get_G() { }

	// RVA: 0x6C68F6C
	public object set_G(object value) { }

	// RVA: 0x6C68F74
	public object get_B() { }

	// RVA: 0x6C68F7C
	public object set_B(object value) { }

	// RVA: 0x6C68F84
	public object get_A() { }

	// RVA: 0x6C68F8C
	public object set_A(object value) { }

	// RVA: 0x6C68F94
	public object get_Time() { }

	// RVA: 0x6C68F9C
	public object set_Time(object value) { }

	// RVA: 0x6C68FA4
	public object get_X() { }

	// RVA: 0x6C68FAC
	public object set_X(object value) { }

	// RVA: 0x6C68FB4
	public object get_Y() { }

	// RVA: 0x6C68FBC
	public object set_Y(object value) { }

	// RVA: 0x6C68FC4
	public object get_ScaleX() { }

	// RVA: 0x6C68FCC
	public object set_ScaleX(object value) { }

	// RVA: 0x6C625F0
	public object get_ScaleY() { }

	// RVA: 0x6C68FD4
	public object set_ScaleY(object value) { }

	// RVA: 0x6C68FDC
	public object get_FlipX() { }

	// RVA: 0x6C68FEC
	public object set_FlipX(object value) { }

	// RVA: 0x6C6901C
	public object get_FlipY() { }

	// RVA: 0x6C6902C
	public object set_FlipY(object value) { }

	// RVA: 0x6C6905C
	public object get_RootBone() { }

	// RVA: 0x6C690B8
	public object .ctor(object data) { }

	// RVA: 0x6C69DF0
	public object UpdateCache() { }

	// RVA: 0x6C6A214
	private object SortIkConstraint(object constraint) { }

	// RVA: 0x6C6A6FC
	private object SortPathConstraint(object constraint) { }

	// RVA: 0x6C6A444
	private object SortTransformConstraint(object constraint) { }

	// RVA: 0x6C6AB60
	private object SortPathConstraintAttachment(object skin, object slotIndex, object slotBone) { }

	// RVA: 0x6C6AED8
	private object SortPathConstraintAttachment(object attachment, object slotBone) { }

	// RVA: 0x6C6A9F8
	private object SortBone(object bone) { }

	// RVA: 0x6C6AAA4
	private static object SortReset(object bones) { }

	// RVA: 0x6C6B090
	public object UpdateWorldTransform() { }

	// RVA: 0x6C6B260
	public object UpdateWorldTransform(object parent) { }

	// RVA: 0x6C6B6E8
	public object SetToSetupPose() { }

	// RVA: 0x6C6B70C
	public object SetBonesToSetupPose() { }

	// RVA: 0x6C6B950
	public object SetSlotsToSetupPose() { }

	// RVA: 0x6C63B9C
	public object FindBone(object boneName) { }

	// RVA: 0x6C65D48
	public object FindSlot(object slotName) { }

	// RVA: 0x6C6BA14
	public object SetSkin(object skinName) { }

	// RVA: 0x6C68E24
	public object SetSkin(object newSkin) { }

	// RVA: 0x6C6BAC4
	public object GetAttachment(object slotName, object attachmentName) { }

	// RVA: 0x6C6BB1C
	public object GetAttachment(object slotIndex, object attachmentName) { }

	// RVA: 0x6C6BBFC
	public object SetAttachment(object slotName, object attachmentName) { }

	// RVA: 0x6C6BDE0
	public object FindIkConstraint(object constraintName) { }

	// RVA: 0x6C6BF08
	public object FindTransformConstraint(object constraintName) { }

	// RVA: 0x6C6C030
	public object FindPathConstraint(object constraintName) { }

	// RVA: 0x6C6C168
	public object Update(object delta) { }

	// RVA: 0x6C6C178
	public object GetBounds(object x, object y, object width, object height, object vertexBuffer) { }

}

// Namespace: 
internal class Vertices
{

	// Fields
	public object bones; // 0x8
	public object vertices; // 0x10

	// Methods

	// RVA: 0x6C74AE4
	public object .ctor() { }

}

// Namespace: 
internal class SkeletonInput
{

	// Fields
	private object chars; // 0x8
	private object bytesBigEndian; // 0x10
	internal object strings; // 0x18
	private object input; // 0x20

	// Methods

	// RVA: 0x6C6E3AC
	public object .ctor(object input) { }

	// RVA: 0x6C74AEC
	public object Read() { }

	// RVA: 0x6C7442C
	public object ReadByte() { }

	// RVA: 0x6C6F084
	public object ReadSByte() { }

	// RVA: 0x6C6ED6C
	public object ReadBoolean() { }

	// RVA: 0x6C6EBD4
	public object ReadFloat() { }

	// RVA: 0x6C6EF54
	public object ReadInt() { }

	// RVA: 0x6C6E998
	public object ReadLong() { }

	// RVA: 0x6C6EDC8
	public object ReadInt(object optimizePositive) { }

	// RVA: 0x6C6EAA0
	public object ReadString() { }

	// RVA: 0x6C6F01C
	public object ReadStringRef() { }

	// RVA: 0x6C7506C
	public object ReadFully(object buffer, object offset, object length) { }

	// RVA: 0x6C6E42C
	public object GetVersionString() { }

	// RVA: 0x6C7513C
	public object GetVersionStringOld3X() { }

}

// Namespace: Spine
public class SkeletonBinary
{

	// Fields
	public const object BONE_ROTATE;
	public const object BONE_TRANSLATE;
	public const object BONE_TRANSLATEX;
	public const object BONE_TRANSLATEY;
	public const object BONE_SCALE;
	public const object BONE_SCALEX;
	public const object BONE_SCALEY;
	public const object BONE_SHEAR;
	public const object BONE_SHEARX;
	public const object BONE_SHEARY;
	public const object SLOT_ATTACHMENT;
	public const object SLOT_RGBA;
	public const object SLOT_RGB;
	public const object SLOT_RGBA2;
	public const object SLOT_RGB2;
	public const object SLOT_ALPHA;
	public const object PATH_POSITION;
	public const object PATH_SPACING;
	public const object PATH_MIX;
	public const object CURVE_LINEAR;
	public const object CURVE_STEPPED;
	public const object CURVE_BEZIER;
	public static readonly object TransformModeValues; // 0x0

	// Methods

	// RVA: 0x6C6C510
	public object .ctor(object attachmentLoader) { }

	// RVA: 0x6C6C518
	public object .ctor(object atlasArray) { }

	// RVA: 0x6C6C520
	public override object ReadSkeletonData(object path) { }

	// RVA: 0x6C6E2AC
	public static object GetVersionString(object file) { }

	// RVA: 0x6C6C700
	public object ReadSkeletonData(object file) { }

	// RVA: 0x6C6F118
	private object ReadSkin(object input, object skeletonData, object defaultSkin, object nonessential) { }

	// RVA: 0x6C73600
	private object ReadAttachment(object input, object skeletonData, object skin, object slotIndex, object attachmentName, object nonessential) { }

	// RVA: 0x6C74484
	private object ReadVertices(object input, object vertexCount) { }

	// RVA: 0x6C747F4
	private object ReadFloatArray(object input, object n, object scale) { }

	// RVA: 0x6C74944
	private object ReadShortArray(object input) { }

	// RVA: 0x6C6F964
	private object ReadAnimation(object name, object input, object skeletonData) { }

	// RVA: 0x6C74C2C
	private object ReadTimeline(object input, object timeline, object scale) { }

	// RVA: 0x6C74DD0
	private object ReadTimeline(object input, object timeline, object scale) { }

	// RVA: 0x6C74B3C
	private object SetBezier(object input, object timeline, object bezier, object frame, object value, object time1, object time2, object value1, object value2, object scale) { }

	// RVA: 0x6C74FD4
	private static object .cctor() { }

}

// Namespace: Spine
public class SkeletonBounds
{

	// Fields
	private object polygonPool; // 0x8
	private object minX; // 0x10
	private object minY; // 0x14
	private object maxX; // 0x18
	private object maxY; // 0x1C
	private object <BoundingBoxes>k__BackingField; // 0x20
	private object <Polygons>k__BackingField; // 0x28

	// Properties
	public object BoundingBoxes { get; set; }
	public object Polygons { get; set; }
	public object MinX { get; set; }
	public object MinY { get; set; }
	public object MaxX { get; set; }
	public object MaxY { get; set; }
	public object Width { get; }
	public object Height { get; }

	// Methods

	// RVA: 0x6C752B0
	public object get_BoundingBoxes() { }

	// RVA: 0x6C752B8
	private object set_BoundingBoxes(object value) { }

	// RVA: 0x6C752C0
	public object get_Polygons() { }

	// RVA: 0x6C752C8
	private object set_Polygons(object value) { }

	// RVA: 0x6C752D0
	public object get_MinX() { }

	// RVA: 0x6C752D8
	public object set_MinX(object value) { }

	// RVA: 0x6C752E0
	public object get_MinY() { }

	// RVA: 0x6C752E8
	public object set_MinY(object value) { }

	// RVA: 0x6C752F0
	public object get_MaxX() { }

	// RVA: 0x6C752F8
	public object set_MaxX(object value) { }

	// RVA: 0x6C75300
	public object get_MaxY() { }

	// RVA: 0x6C75308
	public object set_MaxY(object value) { }

	// RVA: 0x6C75310
	public object get_Width() { }

	// RVA: 0x6C75320
	public object get_Height() { }

	// RVA: 0x6C75330
	public object .ctor() { }

	// RVA: 0x6C75414
	public object Update(object skeleton, object updateAabb) { }

	// RVA: 0x6C7587C
	private object AabbCompute() { }

	// RVA: 0x6C75A64
	public object AabbContainsPoint(object x, object y) { }

	// RVA: 0x6C75AB0
	public object AabbIntersectsSegment(object x1, object y1, object x2, object y2) { }

	// RVA: 0x6C75B78
	public object AabbIntersectsSkeleton(object bounds) { }

	// RVA: 0x6C75BDC
	public object ContainsPoint(object polygon, object x, object y) { }

	// RVA: 0x6C75CC8
	public object ContainsPoint(object x, object y) { }

	// RVA: 0x6C75DC8
	public object IntersectsSegment(object x1, object y1, object x2, object y2) { }

	// RVA: 0x6C75ECC
	public object IntersectsSegment(object polygon, object x1, object y1, object x2, object y2) { }

	// RVA: 0x6C7603C
	public object GetPolygon(object attachment) { }

}

// Namespace: Spine
public class Polygon
{

	// Fields
	private object <Vertices>k__BackingField; // 0x8
	private object <Count>k__BackingField; // 0x10

	// Properties
	public object Vertices { get; set; }
	public object Count { get; set; }

	// Methods

	// RVA: 0x6C76108
	public object get_Vertices() { }

	// RVA: 0x6C76110
	public object set_Vertices(object value) { }

	// RVA: 0x6C76118
	public object get_Count() { }

	// RVA: 0x6C76120
	public object set_Count(object value) { }

	// RVA: 0x6C75814
	public object .ctor() { }

}

// Namespace: Spine
public class SkeletonClipping
{

	// Fields
	internal readonly object triangulator; // 0x8
	internal readonly object clippingPolygon; // 0x10
	internal readonly object clipOutput; // 0x18
	internal readonly object clippedVertices; // 0x20
	internal readonly object clippedTriangles; // 0x28
	internal readonly object clippedUVs; // 0x30
	internal readonly object scratch; // 0x38
	internal object clipAttachment; // 0x40
	internal object clippingPolygons; // 0x48

	// Properties
	public object ClippedVertices { get; }
	public object ClippedTriangles { get; }
	public object ClippedUVs { get; }
	public object IsClipping { get; }

	// Methods

	// RVA: 0x6C76128
	public object get_ClippedVertices() { }

	// RVA: 0x6C76130
	public object get_ClippedTriangles() { }

	// RVA: 0x6C76138
	public object get_ClippedUVs() { }

	// RVA: 0x6C76140
	public object get_IsClipping() { }

	// RVA: 0x6C76150
	public object ClipStart(object slot, object clip) { }

	// RVA: 0x6C765E0
	public object ClipEnd(object slot) { }

	// RVA: 0x6C76618
	public object ClipEnd() { }

	// RVA: 0x6C766E8
	public object ClipTriangles(object vertices, object verticesLength, object triangles, object trianglesLength, object uvs) { }

	// RVA: 0x6C76FFC
	internal object Clip(object x1, object y1, object x2, object y2, object x3, object y3, object clippingArea, object output) { }

	// RVA: 0x6C7645C
	public static object MakeClockwise(object polygon) { }

	// RVA: 0x6C77670
	public object .ctor() { }

}

// Namespace: Spine
public class SkeletonData
{

	// Fields
	internal object name; // 0x8
	internal object bones; // 0x10
	internal object slots; // 0x18
	internal object skins; // 0x20
	internal object defaultSkin; // 0x28
	internal object events; // 0x30
	internal object animations; // 0x38
	internal object ikConstraints; // 0x40
	internal object transformConstraints; // 0x48
	internal object pathConstraints; // 0x50
	internal object x; // 0x58
	internal object y; // 0x5C
	internal object width; // 0x60
	internal object height; // 0x64
	internal object version; // 0x68
	internal object hash; // 0x70
	internal object fps; // 0x78
	internal object imagesPath; // 0x80
	internal object audioPath; // 0x88

	// Properties
	public object Name { get; set; }
	public object Bones { get; }
	public object Slots { get; }
	public object Skins { get; set; }
	public object DefaultSkin { get; set; }
	public object Events { get; set; }
	public object Animations { get; set; }
	public object IkConstraints { get; set; }
	public object TransformConstraints { get; set; }
	public object PathConstraints { get; set; }
	public object X { get; set; }
	public object Y { get; set; }
	public object Width { get; set; }
	public object Height { get; set; }
	public object Version { get; set; }
	public object Hash { get; set; }
	public object ImagesPath { get; set; }
	public object AudioPath { get; set; }
	public object Fps { get; set; }

	// Methods

	// RVA: 0x6C777F0
	public object get_Name() { }

	// RVA: 0x6C777F8
	public object set_Name(object value) { }

	// RVA: 0x6C77800
	public object get_Bones() { }

	// RVA: 0x6C77808
	public object get_Slots() { }

	// RVA: 0x6C77810
	public object get_Skins() { }

	// RVA: 0x6C77818
	public object set_Skins(object value) { }

	// RVA: 0x6C77820
	public object get_DefaultSkin() { }

	// RVA: 0x6C77828
	public object set_DefaultSkin(object value) { }

	// RVA: 0x6C77830
	public object get_Events() { }

	// RVA: 0x6C77838
	public object set_Events(object value) { }

	// RVA: 0x6C77840
	public object get_Animations() { }

	// RVA: 0x6C77848
	public object set_Animations(object value) { }

	// RVA: 0x6C77850
	public object get_IkConstraints() { }

	// RVA: 0x6C77858
	public object set_IkConstraints(object value) { }

	// RVA: 0x6C77860
	public object get_TransformConstraints() { }

	// RVA: 0x6C77868
	public object set_TransformConstraints(object value) { }

	// RVA: 0x6C77870
	public object get_PathConstraints() { }

	// RVA: 0x6C77878
	public object set_PathConstraints(object value) { }

	// RVA: 0x6C77880
	public object get_X() { }

	// RVA: 0x6C77888
	public object set_X(object value) { }

	// RVA: 0x6C77890
	public object get_Y() { }

	// RVA: 0x6C77898
	public object set_Y(object value) { }

	// RVA: 0x6C778A0
	public object get_Width() { }

	// RVA: 0x6C778A8
	public object set_Width(object value) { }

	// RVA: 0x6C778B0
	public object get_Height() { }

	// RVA: 0x6C778B8
	public object set_Height(object value) { }

	// RVA: 0x6C778C0
	public object get_Version() { }

	// RVA: 0x6C778C8
	public object set_Version(object value) { }

	// RVA: 0x6C778D0
	public object get_Hash() { }

	// RVA: 0x6C778D8
	public object set_Hash(object value) { }

	// RVA: 0x6C778E0
	public object get_ImagesPath() { }

	// RVA: 0x6C778E8
	public object set_ImagesPath(object value) { }

	// RVA: 0x6C778F0
	public object get_AudioPath() { }

	// RVA: 0x6C778F8
	public object set_AudioPath(object value) { }

	// RVA: 0x6C77900
	public object get_Fps() { }

	// RVA: 0x6C77908
	public object set_Fps(object value) { }

	// RVA: 0x6C77910
	public object FindBone(object boneName) { }

	// RVA: 0x6C77A24
	public object FindSlot(object slotName) { }

	// RVA: 0x6C6F780
	public object FindSkin(object skinName) { }

	// RVA: 0x6C77B78
	public object FindEvent(object eventDataName) { }

	// RVA: 0x6C77D9C
	public object FindAnimation(object animationName) { }

	// RVA: 0x6C77EB0
	public object FindIkConstraint(object constraintName) { }

	// RVA: 0x6C77FC4
	public object FindTransformConstraint(object constraintName) { }

	// RVA: 0x6C780D8
	public object FindPathConstraint(object constraintName) { }

	// RVA: 0x6C781FC
	public override object ToString() { }

	// RVA: 0x6C6E740
	public object .ctor() { }

}

// Namespace: Spine
public class SkeletonJson
{

	// Methods

	// RVA: 0x6C78214
	public object .ctor(object attachmentLoader) { }

	// RVA: 0x6C7821C
	public object .ctor(object atlasArray) { }

	// RVA: 0x6C78224
	public override object ReadSkeletonData(object path) { }

	// RVA: 0x6C78430
	public object ReadSkeletonData(object reader) { }

	// RVA: 0x6C7D74C
	private object ReadAttachment(object map, object skin, object slotIndex, object name, object skeletonData) { }

	// RVA: 0x6C857D4
	private object ReadVertices(object map, object attachment, object verticesLength) { }

	// RVA: 0x6C7D638
	private object FindSlotIndex(object skeletonData, object slotName) { }

	// RVA: 0x6C7E4E4
	private object ReadAnimation(object map, object name, object skeletonData) { }

	// RVA: 0x6C86398
	private static object ReadTimeline(object keyMapEnumerator, object timeline, object defaultValue, object scale) { }

	// RVA: 0x6C86688
	private static object ReadTimeline(object keyMapEnumerator, object timeline, object name1, object name2, object defaultValue, object scale) { }

	// RVA: 0x6C860EC
	private static object ReadCurve(object curve, object timeline, object bezier, object frame, object value, object time1, object time2, object value1, object value2, object scale) { }

	// RVA: 0x6C869F0
	private static object SetBezier(object timeline, object frame, object value, object bezier, object time1, object value1, object cx1, object cy1, object cx2, object cy2, object time2, object value2) { }

	// RVA: 0x6C85C64
	private static object GetFloatArray(object map, object name, object scale) { }

	// RVA: 0x6C85EF8
	private static object GetIntArray(object map, object name) { }

	// RVA: 0x6C7D128
	private static object GetFloat(object map, object name, object defaultValue) { }

	// RVA: 0x6C7D538
	private static object GetInt(object map, object name, object defaultValue) { }

	// RVA: 0x6C7D2EC
	private static object GetBoolean(object map, object name, object defaultValue) { }

	// RVA: 0x6C7D218
	private static object GetString(object map, object name, object defaultValue) { }

	// RVA: 0x6C7D3D4
	private static object ToColor(object hexString, object colorIndex, object expectedLength) { }

}

// Namespace: 
protected class LinkedMesh
{

	// Fields
	internal object parent; // 0x8
	internal object skin; // 0x10
	internal object slotIndex; // 0x18
	internal object mesh; // 0x20
	internal object inheritDeform; // 0x28

	// Methods

	// RVA: 0x6C86C68
	public object .ctor(object mesh, object skin, object slotIndex, object parent, object inheritDeform) { }

}

// Namespace: Spine
public abstract class SkeletonLoader
{

	// Fields
	protected readonly object attachmentLoader; // 0x8
	protected object scale; // 0x10
	protected readonly object linkedMeshes; // 0x18

	// Properties
	public object Scale { get; set; }

	// Methods

	// RVA: 0x6C86A20
	public object .ctor(object atlasArray) { }

	// RVA: 0x6C86AE8
	public object .ctor(object attachmentLoader) { }

	// RVA: 0x6C86BE4
	public object get_Scale() { }

	// RVA: 0x6C86BEC
	public object set_Scale(object value) { }

	// RVA: -1
	public abstract object ReadSkeletonData(object path) { }

}

// Namespace: 
public struct SkinEntry
{

	// Fields
	internal readonly object slotIndex; // 0xFFFFFFFFFFFFFFF8
	internal readonly object name; // 0x0
	internal readonly object attachment; // 0x8

	// Properties
	public object SlotIndex { get; }
	public object Name { get; }
	public object Attachment { get; }

	// Methods

	// RVA: 0x6C8711C
	public object .ctor(object slotIndex, object name, object attachment) { }

	// RVA: 0x6C88628
	public object get_SlotIndex() { }

	// RVA: 0x6C88638
	public object get_Name() { }

	// RVA: 0x6C88648
	public object get_Attachment() { }

}

// Namespace: 
private struct SkinKey
{

	// Fields
	internal readonly object slotIndex; // 0xFFFFFFFFFFFFFFF8
	internal readonly object name; // 0x0
	internal readonly object hashCode; // 0x8

	// Methods

	// RVA: 0x6C8700C
	public object .ctor(object slotIndex, object name) { }

}

// Namespace: 
private class SkinKeyComparer
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Methods

	// RVA: 0x6C88708
	private object System.Collections.Generic.IEqualityComparer<Spine.Skin.SkinKey>.Equals(object e1, object e2) { }

	// RVA: 0x6C88734
	private object System.Collections.Generic.IEqualityComparer<Spine.Skin.SkinKey>.GetHashCode(object e) { }

	// RVA: 0x6C8873C
	public object .ctor() { }

	// RVA: 0x6C88744
	private static object .cctor() { }

}

// Namespace: Spine
public class Skin
{

	// Fields
	internal object name; // 0x8
	private object attachments; // 0x10
	internal readonly object bones; // 0x18
	internal readonly object constraints; // 0x20

	// Properties
	public object Name { get; }
	public object Attachments { get; }
	public object Bones { get; }
	public object Constraints { get; }

	// Methods

	// RVA: 0x6C86CC0
	public object get_Name() { }

	// RVA: 0x6C86CC8
	public object get_Attachments() { }

	// RVA: 0x6C86D24
	public object get_Bones() { }

	// RVA: 0x6C86D2C
	public object get_Constraints() { }

	// RVA: 0x6C86D34
	public object .ctor(object name) { }

	// RVA: 0x6C86EEC
	public object SetAttachment(object slotIndex, object name, object attachment) { }

	// RVA: 0x6C87128
	public object AddSkin(object skin) { }

	// RVA: 0x6C87628
	public object CopySkin(object skin) { }

	// RVA: 0x6C87C24
	public object GetAttachment(object slotIndex, object name) { }

	// RVA: 0x6C87CE4
	public object RemoveAttachment(object slotIndex, object name) { }

	// RVA: 0x6C87D8C
	public object GetAttachments(object slotIndex, object attachments) { }

	// RVA: 0x6C88118
	public object Clear() { }

	// RVA: 0x6C881DC
	public override object ToString() { }

	// RVA: 0x6C881E4
	internal object AttachAll(object skeleton, object oldSkin) { }

}

// Namespace: Spine
public class Slot
{

	// Fields
	internal object data; // 0x8
	internal object bone; // 0x10
	internal object r; // 0x18
	internal object g; // 0x1C
	internal object b; // 0x20
	internal object a; // 0x24
	internal object r2; // 0x28
	internal object g2; // 0x2C
	internal object b2; // 0x30
	internal object hasSecondColor; // 0x34
	internal object attachment; // 0x38
	internal object attachmentTime; // 0x40
	internal object deform; // 0x48
	internal object attachmentState; // 0x50

	// Properties
	public object Data { get; }
	public object Bone { get; }
	public object Skeleton { get; }
	public object R { get; set; }
	public object G { get; set; }
	public object B { get; set; }
	public object A { get; set; }
	public object R2 { get; set; }
	public object G2 { get; set; }
	public object B2 { get; set; }
	public object HasSecondColor { get; set; }
	public object Attachment { get; set; }
	public object AttachmentTime { get; set; }
	public object Deform { get; set; }

	// Methods

	// RVA: 0x6C887A4
	public object .ctor(object data, object bone) { }

	// RVA: 0x6C88994
	public object .ctor(object slot, object bone) { }

	// RVA: 0x6C88B38
	public object get_Data() { }

	// RVA: 0x6C88B40
	public object get_Bone() { }

	// RVA: 0x6C88B48
	public object get_Skeleton() { }

	// RVA: 0x6C88B6C
	public object get_R() { }

	// RVA: 0x6C88B74
	public object set_R(object value) { }

	// RVA: 0x6C88B7C
	public object get_G() { }

	// RVA: 0x6C88B84
	public object set_G(object value) { }

	// RVA: 0x6C88B8C
	public object get_B() { }

	// RVA: 0x6C88B94
	public object set_B(object value) { }

	// RVA: 0x6C88B9C
	public object get_A() { }

	// RVA: 0x6C88BA4
	public object set_A(object value) { }

	// RVA: 0x6C88BAC
	public object ClampColor() { }

	// RVA: 0x6C88C74
	public object get_R2() { }

	// RVA: 0x6C88C7C
	public object set_R2(object value) { }

	// RVA: 0x6C88C84
	public object get_G2() { }

	// RVA: 0x6C88C8C
	public object set_G2(object value) { }

	// RVA: 0x6C88C94
	public object get_B2() { }

	// RVA: 0x6C88C9C
	public object set_B2(object value) { }

	// RVA: 0x6C88CA4
	public object get_HasSecondColor() { }

	// RVA: 0x6C88CC8
	public object set_HasSecondColor(object value) { }

	// RVA: 0x6C88CEC
	public object ClampSecondColor() { }

	// RVA: 0x6C88D9C
	public object get_Attachment() { }

	// RVA: 0x6C884B0
	public object set_Attachment(object value) { }

	// RVA: 0x6C88DA4
	public object get_AttachmentTime() { }

	// RVA: 0x6C88DE8
	public object set_AttachmentTime(object value) { }

	// RVA: 0x6C88E2C
	public object get_Deform() { }

	// RVA: 0x6C88E34
	public object set_Deform(object value) { }

	// RVA: 0x6C888E8
	public object SetToSetupPose() { }

	// RVA: 0x6C88EAC
	public override object ToString() { }

}

// Namespace: Spine
public class SlotData
{

	// Fields
	internal object index; // 0x8
	internal object name; // 0x10
	internal object boneData; // 0x18
	internal object r; // 0x20
	internal object g; // 0x24
	internal object b; // 0x28
	internal object a; // 0x2C
	internal object r2; // 0x30
	internal object g2; // 0x34
	internal object b2; // 0x38
	internal object hasSecondColor; // 0x3C
	internal object attachmentName; // 0x40
	internal object blendMode; // 0x48

	// Properties
	public object Index { get; }
	public object Name { get; }
	public object BoneData { get; }
	public object R { get; set; }
	public object G { get; set; }
	public object B { get; set; }
	public object A { get; set; }
	public object R2 { get; set; }
	public object G2 { get; set; }
	public object B2 { get; set; }
	public object HasSecondColor { get; set; }
	public object AttachmentName { get; set; }
	public object BlendMode { get; set; }

	// Methods

	// RVA: 0x6C88ED0
	public object get_Index() { }

	// RVA: 0x6C88ED8
	public object get_Name() { }

	// RVA: 0x6C88EE0
	public object get_BoneData() { }

	// RVA: 0x6C88EE8
	public object get_R() { }

	// RVA: 0x6C88EF0
	public object set_R(object value) { }

	// RVA: 0x6C88EF8
	public object get_G() { }

	// RVA: 0x6C88F00
	public object set_G(object value) { }

	// RVA: 0x6C88F08
	public object get_B() { }

	// RVA: 0x6C88F10
	public object set_B(object value) { }

	// RVA: 0x6C88F18
	public object get_A() { }

	// RVA: 0x6C88F20
	public object set_A(object value) { }

	// RVA: 0x6C88F28
	public object get_R2() { }

	// RVA: 0x6C88F30
	public object set_R2(object value) { }

	// RVA: 0x6C88F38
	public object get_G2() { }

	// RVA: 0x6C88F40
	public object set_G2(object value) { }

	// RVA: 0x6C88F48
	public object get_B2() { }

	// RVA: 0x6C88F50
	public object set_B2(object value) { }

	// RVA: 0x6C88F58
	public object get_HasSecondColor() { }

	// RVA: 0x6C88F60
	public object set_HasSecondColor(object value) { }

	// RVA: 0x6C88F68
	public object get_AttachmentName() { }

	// RVA: 0x6C88F70
	public object set_AttachmentName(object value) { }

	// RVA: 0x6C88F78
	public object get_BlendMode() { }

	// RVA: 0x6C88F80
	public object set_BlendMode(object value) { }

	// RVA: 0x6C88F88
	public object .ctor(object index, object name, object boneData) { }

	// RVA: 0x6C890C4
	public override object ToString() { }

}

// Namespace: Spine
public class TransformConstraint
{

	// Fields
	internal object data; // 0x8
	internal object bones; // 0x10
	internal object target; // 0x18
	internal object mixRotate; // 0x20
	internal object mixX; // 0x24
	internal object mixY; // 0x28
	internal object mixScaleX; // 0x2C
	internal object mixScaleY; // 0x30
	internal object mixShearY; // 0x34
	internal object active; // 0x38

	// Properties
	public object Bones { get; }
	public object Target { get; set; }
	public object MixRotate { get; set; }
	public object MixX { get; set; }
	public object MixY { get; set; }
	public object MixScaleX { get; set; }
	public object MixScaleY { get; set; }
	public object MixShearY { get; set; }
	public object Active { get; }
	public object Data { get; }

	// Methods

	// RVA: 0x6C890CC
	public object .ctor(object data, object skeleton) { }

	// RVA: 0x6C89394
	public object .ctor(object constraint, object skeleton) { }

	// RVA: 0x6C89700
	public object Update() { }

	// RVA: 0x6C8A128
	private object ApplyAbsoluteWorld() { }

	// RVA: 0x6C89BB8
	private object ApplyRelativeWorld() { }

	// RVA: 0x6C89914
	private object ApplyAbsoluteLocal() { }

	// RVA: 0x6C89784
	private object ApplyRelativeLocal() { }

	// RVA: 0x6C8A79C
	public object get_Bones() { }

	// RVA: 0x6C8A7A4
	public object get_Target() { }

	// RVA: 0x6C8A7AC
	public object set_Target(object value) { }

	// RVA: 0x6C8A7B4
	public object get_MixRotate() { }

	// RVA: 0x6C8A7BC
	public object set_MixRotate(object value) { }

	// RVA: 0x6C8A7C4
	public object get_MixX() { }

	// RVA: 0x6C8A7CC
	public object set_MixX(object value) { }

	// RVA: 0x6C8A7D4
	public object get_MixY() { }

	// RVA: 0x6C8A7DC
	public object set_MixY(object value) { }

	// RVA: 0x6C8A7E4
	public object get_MixScaleX() { }

	// RVA: 0x6C8A7EC
	public object set_MixScaleX(object value) { }

	// RVA: 0x6C8A7F4
	public object get_MixScaleY() { }

	// RVA: 0x6C8A7FC
	public object set_MixScaleY(object value) { }

	// RVA: 0x6C8A804
	public object get_MixShearY() { }

	// RVA: 0x6C8A80C
	public object set_MixShearY(object value) { }

	// RVA: 0x6C8A814
	public object get_Active() { }

	// RVA: 0x6C8A81C
	public object get_Data() { }

	// RVA: 0x6C8A824
	public override object ToString() { }

}

// Namespace: Spine
public class TransformConstraintData
{

	// Fields
	internal object bones; // 0x18
	internal object target; // 0x20
	internal object mixRotate; // 0x28
	internal object mixX; // 0x2C
	internal object mixY; // 0x30
	internal object mixScaleX; // 0x34
	internal object mixScaleY; // 0x38
	internal object mixShearY; // 0x3C
	internal object offsetRotation; // 0x40
	internal object offsetX; // 0x44
	internal object offsetY; // 0x48
	internal object offsetScaleX; // 0x4C
	internal object offsetScaleY; // 0x50
	internal object offsetShearY; // 0x54
	internal object relative; // 0x58
	internal object local; // 0x59

	// Properties
	public object Bones { get; }
	public object Target { get; set; }
	public object MixRotate { get; set; }
	public object MixX { get; set; }
	public object MixY { get; set; }
	public object MixScaleX { get; set; }
	public object MixScaleY { get; set; }
	public object MixShearY { get; set; }
	public object OffsetRotation { get; set; }
	public object OffsetX { get; set; }
	public object OffsetY { get; set; }
	public object OffsetScaleX { get; set; }
	public object OffsetScaleY { get; set; }
	public object OffsetShearY { get; set; }
	public object Relative { get; set; }
	public object Local { get; set; }

	// Methods

	// RVA: 0x6C8A848
	public object get_Bones() { }

	// RVA: 0x6C8A850
	public object get_Target() { }

	// RVA: 0x6C8A858
	public object set_Target(object value) { }

	// RVA: 0x6C8A860
	public object get_MixRotate() { }

	// RVA: 0x6C8A868
	public object set_MixRotate(object value) { }

	// RVA: 0x6C8A870
	public object get_MixX() { }

	// RVA: 0x6C8A878
	public object set_MixX(object value) { }

	// RVA: 0x6C8A880
	public object get_MixY() { }

	// RVA: 0x6C8A888
	public object set_MixY(object value) { }

	// RVA: 0x6C8A890
	public object get_MixScaleX() { }

	// RVA: 0x6C8A898
	public object set_MixScaleX(object value) { }

	// RVA: 0x6C8A8A0
	public object get_MixScaleY() { }

	// RVA: 0x6C8A8A8
	public object set_MixScaleY(object value) { }

	// RVA: 0x6C8A8B0
	public object get_MixShearY() { }

	// RVA: 0x6C8A8B8
	public object set_MixShearY(object value) { }

	// RVA: 0x6C8A8C0
	public object get_OffsetRotation() { }

	// RVA: 0x6C8A8C8
	public object set_OffsetRotation(object value) { }

	// RVA: 0x6C8A8D0
	public object get_OffsetX() { }

	// RVA: 0x6C8A8D8
	public object set_OffsetX(object value) { }

	// RVA: 0x6C8A8E0
	public object get_OffsetY() { }

	// RVA: 0x6C8A8E8
	public object set_OffsetY(object value) { }

	// RVA: 0x6C8A8F0
	public object get_OffsetScaleX() { }

	// RVA: 0x6C8A8F8
	public object set_OffsetScaleX(object value) { }

	// RVA: 0x6C8A900
	public object get_OffsetScaleY() { }

	// RVA: 0x6C8A908
	public object set_OffsetScaleY(object value) { }

	// RVA: 0x6C8A910
	public object get_OffsetShearY() { }

	// RVA: 0x6C8A918
	public object set_OffsetShearY(object value) { }

	// RVA: 0x6C8A920
	public object get_Relative() { }

	// RVA: 0x6C8A928
	public object set_Relative(object value) { }

	// RVA: 0x6C8A930
	public object get_Local() { }

	// RVA: 0x6C8A938
	public object set_Local(object value) { }

	// RVA: 0x6C8A940
	public object .ctor(object name) { }

}

// Namespace: Spine
public class Triangulator
{

	// Fields
	private readonly object convexPolygons; // 0x8
	private readonly object convexPolygonsIndices; // 0x10
	private readonly object indicesArray; // 0x18
	private readonly object isConcaveArray; // 0x20
	private readonly object triangles; // 0x28
	private readonly object polygonPool; // 0x30
	private readonly object polygonIndicesPool; // 0x38

	// Methods

	// RVA: 0x6C8A9D0
	public object Triangulate(object verticesArray) { }

	// RVA: 0x6C8B240
	public object Decompose(object verticesArray, object triangles) { }

	// RVA: 0x6C8B0FC
	private static object IsConcave(object index, object vertexCount, object vertices, object indices) { }

	// RVA: 0x6C8B214
	private static object PositiveArea(object p1x, object p1y, object p2x, object p2y, object p3x, object p3y) { }

	// RVA: 0x6C8BEB0
	private static object Winding(object p1x, object p1y, object p2x, object p2y, object p3x, object p3y) { }

	// RVA: 0x6C8BEE4
	public object .ctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=20
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=2426
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=4101
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 6E450D10AB53D5AE239D151548081394FDB98FF27F824B3E88B5E05C168929D1; // 0x0
	internal static readonly object 93E533A4EB4C3578EA7CB6731EE7909DEF3495D7F8527ACD4BCA11DBCF13DAC0; // 0x1005
	internal static readonly object ADCCF6F914B86A7EF3FFAA75A291E94CBA3B3DFBF16E94206A5A932D18E28891; // 0x197F
}

