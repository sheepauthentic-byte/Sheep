// Namespace: 
internal class <Module>
{
}

// Namespace: 
internal sealed class <>f__AnonymousType0<T0, T1, T2>
{

	// Fields
	private readonly object <Type>i__Field; // 0x0
	private readonly object <Value>i__Field; // 0x0
	private readonly object <Index>i__Field; // 0x0

	// Properties
	public object Type { get; }
	public object Value { get; }
	public object Index { get; }

	// Methods

	// RVA: -1
	public object get_Type() { }

	// RVA: -1
	public object get_Value() { }

	// RVA: -1
	public object get_Index() { }

	// RVA: -1
	public object .ctor(object Type, object Value, object Index) { }

	// RVA: -1
	public override object Equals(object value) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public override object ToString() { }

}

// Namespace: 
internal sealed class <>f__AnonymousType1<T0, T1>
{

	// Fields
	private readonly object <type>i__Field; // 0x0
	private readonly object <method>i__Field; // 0x0

	// Properties
	public object method { get; }

	// Methods

	// RVA: -1
	public object get_method() { }

	// RVA: -1
	public object .ctor(object type, object method) { }

	// RVA: -1
	public override object Equals(object value) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public override object ToString() { }

}

// Namespace: XLua
public class LuaFunction
{

	// Methods

	// RVA: 0x76FBA34
	private static object PreventStripping() { }

	// RVA: 0x76FBD40
	public object Action() { }

	// RVA: -1
	public object Action(object a1, object a2, object a3) { }

	// RVA: -1
	public object Func() { }

	// RVA: 0x76FC15C
	public object .ctor(object reference, object luaenv) { }

	// RVA: -1
	public object Action(object a) { }

	// RVA: -1
	public object Func(object a) { }

	// RVA: -1
	public object Action(object a1, object a2) { }

	// RVA: -1
	public object Func(object a1, object a2) { }

	// RVA: 0x76FC1D4
	public object Call(object args, object returnTypes) { }

	// RVA: 0x76FCC80
	public object Call(object args) { }

	// RVA: 0x76FCC88
	internal override object push(object L) { }

	// RVA: 0x76FCC9C
	public override object ToString() { }

}

// Namespace: XLua
public static class CopyByValue
{

	// Methods

	// RVA: 0x76FCD14
	public static object Pack(object buff, object offset, object field) { }

	// RVA: 0x76FCD68
	public static object UnPack(object buff, object offset, object field) { }

	// RVA: 0x76FCE1C
	public static object IsStruct(object type) { }

}

// Namespace: XLua
public abstract class DelegateBridgeBase
{

	// Fields
	private object firstKey; // 0x18
	private object firstValue; // 0x20
	private object bindTo; // 0x28
	protected object errorFuncRef; // 0x30

	// Methods

	// RVA: 0x76FCE74
	public object .ctor(object reference, object luaenv) { }

	// RVA: 0x76FCEC8
	public object TryGetDelegate(object key, object value) { }

	// RVA: 0x76FCF6C
	public object AddDelegate(object key, object value) { }

	// RVA: 0x76FD0CC
	public virtual object GetDelegateByType(object type) { }

}

// Namespace: XLua
public class DelegateBridge
{

	// Fields
	internal static object DelegateBridgeList; // 0x0

	// Properties
	public static object Gen_Flag { get; }

	// Methods

	// RVA: 0x76FD0D4
	public static object get_Gen_Flag() { }

	// RVA: 0x76FBB00
	public object .ctor(object reference, object luaenv) { }

	// RVA: 0x76FD204
	public object PCall(object L, object nArgs, object nResults, object errFunc) { }

	// RVA: 0x76FBB54
	public object Action() { }

	// RVA: -1
	public object Action(object p1) { }

	// RVA: -1
	public object Action(object p1, object p2) { }

	// RVA: -1
	public object Action(object p1, object p2, object p3) { }

	// RVA: -1
	public object Action(object p1, object p2, object p3, object p4) { }

	// RVA: -1
	public object Func() { }

	// RVA: -1
	public object Func(object p1) { }

	// RVA: -1
	public object Func(object p1, object p2) { }

	// RVA: -1
	public object Func(object p1, object p2, object p3) { }

	// RVA: -1
	public object Func(object p1, object p2, object p3, object p4) { }

	// RVA: 0x76FD264
	private static object .cctor() { }

}

// Namespace: XLua
public enum GenFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object No;
	public const object GCOptimize;
}

// Namespace: XLua
public class LuaCallCSharpAttribute
{

	// Fields
	private object flag; // 0x8

	// Methods

	// RVA: 0x76FD2D8
	public object .ctor(object flag) { }

}

// Namespace: XLua
public class CSharpCallLuaAttribute
{

	// Methods

	// RVA: 0x76FD304
	public object .ctor() { }

}

// Namespace: XLua
public class ReflectionUseAttribute
{

	// Methods

	// RVA: 0x76FD30C
	public object .ctor() { }

}

// Namespace: 
internal sealed class TryArrayGet
{

	// Methods

	// RVA: 0x76FE480
	public object .ctor(object object, object method) { }

	// RVA: 0x76FE58C
	public virtual object Invoke(object type, object L, object translator, object obj, object index) { }

}

// Namespace: 
internal sealed class TryArraySet
{

	// Methods

	// RVA: 0x76FE9D0
	public object .ctor(object object, object method) { }

	// RVA: 0x76FEADC
	public virtual object Invoke(object type, object L, object translator, object obj, object array_idx, object obj_idx) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__14_0; // 0x8
	public static object <>9__14_1; // 0x10
	public static object <>9__14_2; // 0x18
	public static object <>9__14_3; // 0x20

	// Methods

	// RVA: 0x76FEAF0
	private static object .cctor() { }

	// RVA: 0x76FEB50
	public object .ctor() { }

	// RVA: 0x76FEB58
	internal object <Init>b__14_0(object assembly) { }

	// RVA: 0x76FEBD8
	internal object <Init>b__14_1(object x) { }

	// RVA: 0x76FEBE4
	internal object <Init>b__14_2(object assembly) { }

	// RVA: 0x76FEC64
	internal object <Init>b__14_3(object x) { }

}

// Namespace: XLua
internal class InternalGlobals
{

	// Fields
	internal static object genTryArrayGetPtr; // 0x0
	internal static object genTryArraySetPtr; // 0x8
	internal static object objectTranslatorPool; // 0x10
	internal static object LUA_REGISTRYINDEX; // 0x18
	internal static object supportOp; // 0x20
	internal static object extensionMethodMap; // 0x28
	internal static object LazyReflectionWrap; // 0x30
	internal static object delegate_birdge_type; // 0x38
	private static object initState; // 0x40

	// Properties
	internal static object Gen_Flag { get; }

	// Methods

	// RVA: 0x76FD198
	internal static object get_Gen_Flag() { }

	// RVA: 0x76FDA30
	internal static object ConvertDelegate(object sourceDelegate, object targetType) { }

	// RVA: 0x76FD314
	internal static object Init() { }

	// RVA: 0x76FDA78
	private static object .cctor() { }

}

// Namespace: XLua
public abstract class LuaBase
{

	// Fields
	protected object disposed; // 0x8
	protected readonly object luaReference; // 0xC
	protected readonly object luaEnv; // 0x10

	// Methods

	// RVA: 0x76FC198
	public object .ctor(object reference, object luaenv) { }

	// RVA: 0x76FEC70
	protected override object Finalize() { }

	// RVA: 0x76FED28
	public object Dispose() { }

	// RVA: 0x76FEDC0
	public virtual object Dispose(object disposeManagedResources) { }

	// RVA: 0x76FF304
	public override object Equals(object o) { }

	// RVA: 0x76FF5FC
	public override object GetHashCode() { }

	// RVA: 0x76FF720
	internal virtual object push(object L) { }

}

// Namespace: 
internal struct GCAction
{

	// Fields
	public object Reference; // 0xFFFFFFFFFFFFFFF8
	public object IsDelegate; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: 
public sealed class CustomLoader
{

	// Methods

	// RVA: 0x770491C
	public object .ctor(object object, object method) { }

	// RVA: 0x77049C4
	public virtual object Invoke(object filepath) { }

}

// Namespace: XLua
public class LuaEnv
{

	// Fields
	public const object CSHARP_NAMESPACE;
	public const object MAIN_SHREAD;
	internal object rawL; // 0x8
	private object _G; // 0x10
	public object translator; // 0x18
	public object errorFuncRef; // 0x20
	internal object luaLock; // 0x28
	private const object LIB_VERSION_EXPECT;
	private static object initers; // 0x0
	private object last_check_point; // 0x30
	private object max_check_per_tick; // 0x34
	private object object_valid_checker; // 0x38
	private object disposed; // 0x40
	private object refQueue; // 0x48
	private object init_xlua; // 0x50
	internal object customLoaders; // 0x58
	internal object buildin_initer; // 0x60

	// Properties
	public object L { get; }
	public object luaEnvLock { get; }
	public object Global { get; }

	// Methods

	// RVA: 0x76FBE64
	public object get_L() { }

	// RVA: 0x76FF734
	public object get_luaEnvLock() { }

	// RVA: 0x76FF73C
	public object .ctor(object delayReflectionMember) { }

	// RVA: 0x7702E6C
	public static object AddIniter(object initer) { }

	// RVA: 0x7702FF0
	public object get_Global() { }

	// RVA: 0x7702FF8
	public object DoString(object chunk, object chunkName, object env) { }

	// RVA: 0x770251C
	public object DoString(object chunk, object chunkName, object env) { }

	// RVA: 0x77022D4
	private object AddSearcher(object searcher, object index) { }

	// RVA: 0x770325C
	private static object ObjectValidCheck(object obj) { }

	// RVA: 0x7703340
	public object Tick() { }

	// RVA: 0x7703820
	public object NewTable() { }

	// RVA: 0x7703DC0
	public object Dispose() { }

	// RVA: 0x7703F7C
	public virtual object Dispose(object dispose) { }

	// RVA: 0x76FBEE0
	public object ThrowExceptionFromError(object oldTop) { }

	// RVA: 0x76FF210
	internal object equeueGCAction(object action) { }

	// RVA: 0x7704670
	public object AddLoader(object loader) { }

	// RVA: 0x77025B0
	public object AddBuildin(object name, object initer) { }

	// RVA: 0x7703E68
	public object FullGc() { }

}

// Namespace: XLua
public class LuaException
{

	// Methods

	// RVA: 0x7704604
	public object .ctor(object message) { }

}

// Namespace: XLua
public class LuaTable
{

	// Properties
	public object Length { get; }

	// Methods

	// RVA: 0x77049D8
	public object .ctor(object reference, object luaenv) { }

	// RVA: -1
	public object Get(object key, object value) { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object Set(object key, object value) { }

	// RVA: -1
	public object GetInPath(object path) { }

	// RVA: -1
	public object ForEach(object action) { }

	// RVA: 0x7704A14
	public object get_Length() { }

	// RVA: -1
	public object Get(object key) { }

	// RVA: -1
	public object Get(object key) { }

	// RVA: 0x7704BA4
	internal override object push(object L) { }

	// RVA: 0x7704BB8
	public override object ToString() { }

}

// Namespace: XLua
public class OverloadMethodWrap
{

	// Fields
	private object translator; // 0x8
	private object targetType; // 0x10
	private object method; // 0x18
	private object checkArray; // 0x20
	private object castArray; // 0x28
	private object inPosArray; // 0x30
	private object outPosArray; // 0x38
	private object isOptionalArray; // 0x40
	private object defaultValueArray; // 0x48
	private object isVoid; // 0x50
	private object luaStackPosStart; // 0x54
	private object targetNeeded; // 0x58
	private object args; // 0x60
	private object refPos; // 0x68
	private object paramsType; // 0x70
	private object <HasDefalutValue>k__BackingField; // 0x78

	// Properties
	public object HasDefalutValue { get; set; }

	// Methods

	// RVA: 0x7704C30
	public object get_HasDefalutValue() { }

	// RVA: 0x7704C38
	private object set_HasDefalutValue(object value) { }

	// RVA: 0x7704C40
	public object .ctor(object translator, object targetType, object method) { }

	// RVA: 0x7704C90
	public object Init(object objCheckers, object objCasters) { }

	// RVA: 0x7706324
	public object Check(object L) { }

	// RVA: 0x77064C8
	public object Call(object L) { }

}

// Namespace: XLua
public class MethodWrap
{

	// Fields
	private object methodName; // 0x8
	protected object overloads; // 0x10
	private object forceCheck; // 0x18

	// Methods

	// RVA: 0x7707100
	public object .ctor(object methodName, object overloads, object forceCheck) { }

	// RVA: 0x77071A8
	public virtual object Call(object L) { }

}

// Namespace: XLua
public class MethodWrap_New
{

	// Fields
	private object type; // 0x20
	private object methodBases; // 0x28
	private object translator; // 0x30
	private object objCheckers; // 0x38
	private object objCasters; // 0x40
	private object isInited; // 0x48

	// Methods

	// RVA: 0x77074E4
	public object .ctor(object translator, object objCheckers, object objCasters, object type, object methodName, object methodBases, object forceCheck) { }

	// RVA: 0x7707608
	private object Init() { }

	// RVA: 0x7707B2C
	public override object Call(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object <>4__this; // 0x8
	public object type; // 0x10

	// Methods

	// RVA: 0x7708080
	public object .ctor() { }

	// RVA: 0x7708E0C
	internal object <GetConstructorWrap>b__0(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_1
{

	// Fields
	public object ctor; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0x7708088
	public object .ctor() { }

	// RVA: 0x7708E70
	internal object <GetConstructorWrap>b__1(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass12_0
{

	// Fields
	public object <>4__this; // 0x8
	public object type; // 0x10
	public object eventName; // 0x18
	public object is_static; // 0x20
	public object eventInfo; // 0x28
	public object start_idx; // 0x30
	public object add; // 0x38
	public object remove; // 0x40

	// Methods

	// RVA: 0x7708E04
	public object .ctor() { }

	// RVA: 0x7708F30
	internal object <GetEventWrap>b__0(object L) { }

}

// Namespace: XLua
public class MethodWrapsCache
{

	// Fields
	private object translator; // 0x8
	private object objCheckers; // 0x10
	private object objCasters; // 0x18
	private object delayReflectionMember; // 0x20
	private object constructorCache; // 0x28
	private object methodsCache; // 0x30
	private object delegateCache; // 0x38

	// Methods

	// RVA: 0x7707B60
	public object .ctor(object translator, object objCheckers, object objCasters, object delayReflectionMember) { }

	// RVA: 0x7707C70
	public object GetConstructorWrap(object type) { }

	// RVA: 0x77086C4
	public object GetDelegateWrap(object type) { }

	// RVA: 0x77089AC
	public object GetEventWrap(object type, object eventName) { }

	// RVA: 0x7708090
	public object _GenMethodWrap(object type, object methodName, object methodBases, object forceCheck) { }

}

// Namespace: XLua
public sealed class ObjectCheck
{

	// Methods

	// RVA: 0x7709E5C
	public object .ctor(object object, object method) { }

	// RVA: 0x7709EF4
	public virtual object Invoke(object L, object idx) { }

}

// Namespace: XLua
public sealed class ObjectCast
{

	// Methods

	// RVA: 0x7709FA4
	public object .ctor(object object, object method) { }

	// RVA: 0x770A03C
	public virtual object Invoke(object L, object idx, object target) { }

}

// Namespace: 
private sealed class <>c__DisplayClass14_0
{

	// Fields
	public object <>4__this; // 0x8
	public object type; // 0x10
	public object fixTypeCheck; // 0x18

	// Methods

	// RVA: 0x770B81C
	public object .ctor() { }

	// RVA: 0x770B92C
	internal object <genChecker>b__0(object L, object idx) { }

	// RVA: 0x770BBD0
	internal object <genChecker>b__1(object L, object idx) { }

	// RVA: 0x770BC60
	internal object <genChecker>b__2(object L, object idx) { }

	// RVA: 0x770BCF0
	internal object <genChecker>b__3(object L, object idx) { }

	// RVA: 0x770BD80
	internal object <genChecker>b__4(object L, object idx) { }

	// RVA: 0x770BDFC
	internal object <genChecker>b__5(object L, object idx) { }

	// RVA: 0x770BE8C
	internal object <genChecker>b__6(object L, object idx) { }

}

// Namespace: 
private sealed class <>c__DisplayClass15_0
{

	// Fields
	public object oc; // 0x8

	// Methods

	// RVA: 0x770B924
	public object .ctor() { }

	// RVA: 0x770BF08
	internal object <genNullableChecker>b__0(object L, object idx) { }

}

// Namespace: XLua
public class ObjectCheckers
{

	// Fields
	private object checkersMap; // 0x8
	private object translator; // 0x10

	// Methods

	// RVA: 0x770A050
	public object .ctor(object translator) { }

	// RVA: 0x770AE44
	private static object objectCheck(object L, object idx) { }

	// RVA: 0x770AE4C
	private object luaTableCheck(object L, object idx) { }

	// RVA: 0x770AFD0
	private object numberCheck(object L, object idx) { }

	// RVA: 0x770AFF8
	private object decimalCheck(object L, object idx) { }

	// RVA: 0x770B0EC
	private object strCheck(object L, object idx) { }

	// RVA: 0x770B140
	private object bytesCheck(object L, object idx) { }

	// RVA: 0x770B25C
	private object boolCheck(object L, object idx) { }

	// RVA: 0x770B284
	private object int64Check(object L, object idx) { }

	// RVA: 0x770B2D8
	private object uint64Check(object L, object idx) { }

	// RVA: 0x770B32C
	private object luaFunctionCheck(object L, object idx) { }

	// RVA: 0x770B464
	private object intptrCheck(object L, object idx) { }

	// RVA: 0x770B48C
	private object genChecker(object type) { }

	// RVA: 0x770B824
	public object genNullableChecker(object oc) { }

	// RVA: 0x7706084
	public object GetChecker(object type) { }

}

// Namespace: 
private sealed class <>c__DisplayClass23_0
{

	// Fields
	public object <>4__this; // 0x8
	public object type; // 0x10
	public object fixTypeGetter; // 0x18

	// Methods

	// RVA: 0x770E644
	public object .ctor() { }

	// RVA: 0x770E764
	internal object <genCaster>b__0(object L, object idx, object target) { }

	// RVA: 0x770E864
	internal object <genCaster>b__1(object L, object idx, object target) { }

	// RVA: 0x770E918
	internal object <genCaster>b__2(object L, object idx, object target) { }

	// RVA: 0x770E9CC
	internal object <genCaster>b__3(object L, object idx, object target) { }

	// RVA: 0x770EBD0
	internal object <genCaster>b__4(object L, object idx, object target) { }

	// RVA: 0x770ED8C
	internal object <genCaster>b__5(object L, object idx, object target) { }

	// RVA: 0x770FB6C
	internal object <genCaster>b__6(object L, object idx, object target) { }

}

// Namespace: 
private sealed class <>c__DisplayClass23_1
{

	// Fields
	public object elementType; // 0x8
	public object elementCaster; // 0x10
	public object CS$<>8__locals1; // 0x18

	// Methods

	// RVA: 0x770E64C
	public object .ctor() { }

	// RVA: 0x77100C0
	internal object <genCaster>b__7(object L, object idx, object target) { }

}

// Namespace: 
private sealed class <>c__DisplayClass23_2
{

	// Fields
	public object keyType; // 0x8
	public object valueType; // 0x10
	public object keyCaster; // 0x18
	public object valueCaster; // 0x20
	public object CS$<>8__locals2; // 0x28

	// Methods

	// RVA: 0x770E654
	public object .ctor() { }

	// RVA: 0x7710958
	internal object <genCaster>b__8(object L, object idx, object target) { }

}

// Namespace: 
private sealed class <>c__DisplayClass24_0
{

	// Fields
	public object oc; // 0x8

	// Methods

	// RVA: 0x770E75C
	public object .ctor() { }

	// RVA: 0x7710DBC
	internal object <genNullableCaster>b__0(object L, object idx, object target) { }

}

// Namespace: XLua
public class ObjectCasters
{

	// Fields
	private object castersMap; // 0x8
	private object translator; // 0x10

	// Methods

	// RVA: 0x770BF84
	public object .ctor(object translator) { }

	// RVA: 0x770CDD8
	private static object charCaster(object L, object idx, object target) { }

	// RVA: 0x770CE54
	private static object sbyteCaster(object L, object idx, object target) { }

	// RVA: 0x770CED0
	private static object byteCaster(object L, object idx, object target) { }

	// RVA: 0x770CF4C
	private static object shortCaster(object L, object idx, object target) { }

	// RVA: 0x770CFC8
	private static object ushortCaster(object L, object idx, object target) { }

	// RVA: 0x770D044
	private static object intCaster(object L, object idx, object target) { }

	// RVA: 0x770D0C0
	private static object uintCaster(object L, object idx, object target) { }

	// RVA: 0x770D13C
	private static object longCaster(object L, object idx, object target) { }

	// RVA: 0x770D1B8
	private static object ulongCaster(object L, object idx, object target) { }

	// RVA: 0x770D234
	private static object getDouble(object L, object idx, object target) { }

	// RVA: 0x770D2B0
	private static object floatCaster(object L, object idx, object target) { }

	// RVA: 0x770D330
	private object decimalCaster(object L, object idx, object target) { }

	// RVA: 0x770D6B8
	private static object getBoolean(object L, object idx, object target) { }

	// RVA: 0x770D734
	private static object getString(object L, object idx, object target) { }

	// RVA: 0x770D73C
	private object getBytes(object L, object idx, object target) { }

	// RVA: 0x770D8E4
	private object getIntptr(object L, object idx, object target) { }

	// RVA: 0x770D95C
	private object getObject(object L, object idx, object target) { }

	// RVA: 0x770DC48
	private object getLuaTable(object L, object idx, object target) { }

	// RVA: 0x770DDC8
	private object getLuaFunction(object L, object idx, object target) { }

	// RVA: 0x770DF48
	private object genCaster(object type) { }

	// RVA: 0x770E65C
	private object genNullableCaster(object oc) { }

	// RVA: 0x77061D4
	public object GetCaster(object type) { }

}

// Namespace: 
private struct Slot
{

	// Fields
	public object next; // 0xFFFFFFFFFFFFFFF8
	public object obj; // 0x0

	// Methods

	// RVA: 0x7711004
	public object .ctor(object next, object obj) { }

}

// Namespace: XLua
public class ObjectPool
{

	// Fields
	private const object LIST_END;
	private const object ALLOCED;
	private object list; // 0x8
	private object freelist; // 0x10
	private object count; // 0x14

	// Methods

	// RVA: 0x7710E40
	private object extend_capacity() { }

	// RVA: 0x7710F1C
	public object Add(object obj) { }

	// RVA: 0x7711010
	public object TryGetValue(object index, object obj) { }

	// RVA: 0x7711084
	public object Get(object index) { }

	// RVA: 0x77110DC
	public object Remove(object index) { }

	// RVA: 0x7711154
	public object Replace(object index, object o) { }

	// RVA: 0x77035B8
	public object Check(object check_pos, object max_check, object checker, object reverse_map) { }

	// RVA: 0x77111B0
	public object .ctor() { }

}

// Namespace: XLua
internal class ReferenceEqualsComparer
{

	// Methods

	// RVA: 0x7711388
	public object Equals(object o1, object o2) { }

	// RVA: 0x7711394
	public object GetHashCode(object obj) { }

	// RVA: 0x77113A0
	public object .ctor() { }

}

// Namespace: XLua
public class MonoPInvokeCallbackAttribute
{

	// Fields
	private object type; // 0x8

	// Methods

	// RVA: 0x77113A8
	public object .ctor(object t) { }

}

// Namespace: XLua
public enum LuaTypes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LUA_TNONE;
	public const object LUA_TNIL;
	public const object LUA_TNUMBER;
	public const object LUA_TSTRING;
	public const object LUA_TBOOLEAN;
	public const object LUA_TTABLE;
	public const object LUA_TFUNCTION;
	public const object LUA_TUSERDATA;
	public const object LUA_TTHREAD;
	public const object LUA_TLIGHTUSERDATA;
}

// Namespace: XLua
public enum LuaGCOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LUA_GCSTOP;
	public const object LUA_GCRESTART;
	public const object LUA_GCCOLLECT;
	public const object LUA_GCCOUNT;
	public const object LUA_GCCOUNTB;
	public const object LUA_GCSTEP;
	public const object LUA_GCSETPAUSE;
	public const object LUA_GCSETSTEPMUL;
}

// Namespace: XLua
public static class LuaIndexes
{

	// Properties
	public static object LUA_REGISTRYINDEX { get; set; }

	// Methods

	// RVA: 0x77026C4
	public static object get_LUA_REGISTRYINDEX() { }

	// RVA: 0x7700E54
	public static object set_LUA_REGISTRYINDEX(object value) { }

}

// Namespace: 
public sealed class PushCSObject
{

	// Methods

	// RVA: 0x7715218
	public object .ctor(object object, object method) { }

	// RVA: 0x77152B0
	public virtual object Invoke(object L, object obj) { }

}

// Namespace: 
public sealed class GetCSObject
{

	// Methods

	// RVA: 0x7715348
	public object .ctor(object object, object method) { }

	// RVA: 0x77153E0
	public virtual object Invoke(object L, object idx) { }

}

// Namespace: 
public sealed class UpdateCSObject
{

	// Methods

	// RVA: 0x7715478
	public object .ctor(object object, object method) { }

	// RVA: 0x7715510
	public virtual object Invoke(object L, object idx, object obj) { }

}

// Namespace: 
public sealed class GetFunc<T0>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object L, object idx, object val) { }

}

// Namespace: 
private sealed class <>c__DisplayClass34_0
{

	// Fields
	public object delegateType; // 0x8
	public object genericMethodInfo; // 0x10

	// Methods

	// RVA: 0x7712F90
	public object .ctor() { }

	// RVA: 0x7715524
	internal object <getCreatorUsingGeneric>b__7(object o) { }

}

// Namespace: 
private sealed class <>c__DisplayClass34_1
{

	// Fields
	public object methodInfo; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0x7712F98
	public object .ctor() { }

	// RVA: 0x7715534
	internal object <getCreatorUsingGeneric>b__8(object o) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__34_1; // 0x8
	public static object <>9__34_2; // 0x10
	public static object <>9__34_3; // 0x18
	public static object <>9__34_4; // 0x20
	public static object <>9__34_0; // 0x28
	public static object <>9__34_5; // 0x30
	public static object <>9__34_6; // 0x38
	public static object <>9__35_0; // 0x40

	// Methods

	// RVA: 0x7715564
	private static object .cctor() { }

	// RVA: 0x77155C4
	public object .ctor() { }

	// RVA: 0x77155CC
	internal object <getCreatorUsingGeneric>b__34_1(object m) { }

	// RVA: 0x771564C
	internal object <getCreatorUsingGeneric>b__34_2(object m) { }

	// RVA: 0x77156B4
	internal object <getCreatorUsingGeneric>b__34_3(object m) { }

	// RVA: 0x7715734
	internal object <getCreatorUsingGeneric>b__34_4(object m) { }

	// RVA: 0x771579C
	internal object <getCreatorUsingGeneric>b__34_0(object x) { }

	// RVA: 0x77157A4
	internal object <getCreatorUsingGeneric>b__34_5(object x) { }

	// RVA: 0x77157AC
	internal object <getCreatorUsingGeneric>b__34_6(object pinfo) { }

	// RVA: 0x77157F8
	internal object <getDelegate>b__35_0(object m) { }

}

// Namespace: 
private sealed class <>c__DisplayClass35_0
{

	// Fields
	public object delegateType; // 0x8

	// Methods

	// RVA: 0x771353C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass35_1
{

	// Fields
	public object foundMethod; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0x7713544
	public object .ctor() { }

	// RVA: 0x771591C
	internal object <getDelegate>b__1(object o) { }

}

// Namespace: 
private sealed class <>c__97<T0>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__97_0; // 0x0
	public static object <>9__97_1; // 0x0
	public static object <>9__97_2; // 0x0
	public static object <>9__97_3; // 0x0
	public static object <>9__97_4; // 0x0
	public static object <>9__97_5; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <tryGetPushFuncByType>b__97_0(object L, object v) { }

	// RVA: -1
	internal object <tryGetPushFuncByType>b__97_1(object L, object v) { }

	// RVA: -1
	internal object <tryGetPushFuncByType>b__97_2(object L, object v) { }

	// RVA: -1
	internal object <tryGetPushFuncByType>b__97_3(object L, object v) { }

	// RVA: -1
	internal object <tryGetPushFuncByType>b__97_4(object L, object v) { }

	// RVA: -1
	internal object <tryGetPushFuncByType>b__97_5(object L, object v) { }

}

// Namespace: 
private sealed class <>c__99<T0>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__99_1; // 0x0
	public static object <>9__99_2; // 0x0
	public static object <>9__99_3; // 0x0
	public static object <>9__99_4; // 0x0
	public static object <>9__99_5; // 0x0
	public static object <>9__99_6; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <tryGetGetFuncByType>b__99_1(object L, object idx) { }

	// RVA: -1
	internal object <tryGetGetFuncByType>b__99_2(object L, object idx) { }

	// RVA: -1
	internal object <tryGetGetFuncByType>b__99_3(object L, object idx) { }

	// RVA: -1
	internal object <tryGetGetFuncByType>b__99_4(object L, object idx) { }

	// RVA: -1
	internal object <tryGetGetFuncByType>b__99_5(object L, object idx) { }

	// RVA: -1
	internal object <tryGetGetFuncByType>b__99_6(object L, object idx) { }

}

// Namespace: 
private sealed class <>c__DisplayClass102_0<T0>
{

	// Fields
	public object get; // 0x0
	public object push; // 0x0
	public object update; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <RegisterPushAndGetAndUpdate>b__0(object L, object idx) { }

	// RVA: -1
	internal object <RegisterPushAndGetAndUpdate>b__1(object L, object obj) { }

	// RVA: -1
	internal object <RegisterPushAndGetAndUpdate>b__2(object L, object idx) { }

	// RVA: -1
	internal object <RegisterPushAndGetAndUpdate>b__3(object L, object idx, object obj) { }

}

// Namespace: XLua
public class ObjectTranslator
{

	// Fields
	internal object methodWrapsCache; // 0x8
	internal object objectCheckers; // 0x10
	public object objectCasters; // 0x18
	internal readonly object objects; // 0x20
	internal readonly object reverseMap; // 0x28
	internal object luaEnv; // 0x30
	internal object metaFunctions; // 0x38
	internal object assemblies; // 0x40
	private object importTypeFunction; // 0x48
	private object loadAssemblyFunction; // 0x50
	private object castFunction; // 0x58
	private readonly object delayWrap; // 0x60
	private readonly object interfaceBridgeCreators; // 0x68
	private readonly object aliasCfg; // 0x70
	private object delayReflectionMember; // 0x78
	public object getterCache; // 0x80
	public object setterCache; // 0x88
	public object reflectionCallback; // 0x90
	private object reflection_wrap_types; // 0x98
	private object loaded_types; // 0xA0
	public object cacheRef; // 0xA8
	private object delegate_birdge_type; // 0xB0
	private object genericAction; // 0xB8
	private object genericFunc; // 0xC0
	private object delegateCreatorCache; // 0xC8
	private object delegate_bridges; // 0xD0
	private object common_array_meta; // 0xD8
	private object common_delegate_meta; // 0xDC
	private object enumerable_pairs_func; // 0xE0
	private object typeIdMap; // 0xE8
	private object typeMap; // 0xF0
	private object privateAccessibleFlags; // 0xF8
	private object enumMap; // 0x100
	private object fix_cs_functions; // 0x108
	private object custom_push_funcs; // 0x110
	private object custom_get_funcs; // 0x118
	private object custom_update_funcs; // 0x120
	private object push_func_with_type; // 0x128
	private object get_func_with_type; // 0x130
	private object decimal_type_id; // 0x138

	// Properties
	public object IsDelayReflectionMember { get; }

	// Methods

	// RVA: 0x77113D4
	public object get_IsDelayReflectionMember() { }

	// RVA: 0x77113DC
	public object DelayWrapLoader(object type, object loader) { }

	// RVA: 0x7711450
	public object AddInterfaceBridgeCreator(object type, object creator) { }

	// RVA: 0x77114C4
	public object TryDelayWrapLoader(object L, object type) { }

	// RVA: 0x7702728
	public object Alias(object type, object alias) { }

	// RVA: 0x7711D44
	private object addAssemblieByName(object assemblies_usorted, object name) { }

	// RVA: 0x7700EC0
	public object .ctor(object luaenv, object L, object delayReflectionMember) { }

	// RVA: 0x77123E0
	private object initCSharpCallLua() { }

	// RVA: 0x77124E8
	private object getCreatorUsingGeneric(object bridge, object delegateType, object delegateMethod) { }

	// RVA: 0x7712FA0
	private object getDelegate(object bridge, object delegateType) { }

	// RVA: 0x770961C
	public object CreateDelegateBridge(object L, object delegateType, object idx) { }

	// RVA: 0x77041F0
	public object AllDelegateBridgeReleased() { }

	// RVA: 0x76FEFDC
	public object ReleaseLuaBase(object L, object reference, object is_delegate) { }

	// RVA: 0x770EA80
	public object CreateInterfaceBridge(object L, object interfaceType, object idx) { }

	// RVA: 0x7702804
	public object CreateArrayMetatable(object L) { }

	// RVA: 0x77029F4
	public object CreateDelegateMetatable(object L) { }

	// RVA: 0x7702C38
	internal object CreateEnumerablePairs(object L) { }

	// RVA: 0x7701B2C
	public object OpenLib(object L) { }

	// RVA: 0x7701928
	internal object createFunctionMetatable(object L) { }

	// RVA: 0x77118F4
	internal object FindType(object className, object isQualifiedName) { }

	// RVA: 0x771358C
	internal object collectObject(object obj_index_to_collect) { }

	// RVA: 0x7713728
	private object addObject(object obj, object is_valuetype, object is_enum) { }

	// RVA: 0x7704504
	public object GetObject(object L, object index) { }

	// RVA: 0x770BB18
	public object GetTypeOf(object L, object idx) { }

	// RVA: -1
	public object Assignable(object L, object index) { }

	// RVA: 0x7710658
	public object Assignable(object L, object index, object type) { }

	// RVA: 0x7703A50
	public object GetObject(object L, object index, object type) { }

	// RVA: -1
	public object Get(object L, object index, object v) { }

	// RVA: -1
	public object PushByType(object L, object v) { }

	// RVA: -1
	public object GetParams(object L, object index) { }

	// RVA: 0x7706D8C
	public object GetParams(object L, object index, object type) { }

	// RVA: -1
	public object GetDelegate(object L, object index) { }

	// RVA: 0x77118D4
	public object GetTypeId(object L, object type) { }

	// RVA: 0x7713DFC
	public object PrivateAccessible(object L, object type) { }

	// RVA: 0x77137EC
	public object getTypeId(object L, object type, object is_first) { }

	// RVA: 0x7713F20
	private object pushPrimitive(object L, object o) { }

	// RVA: 0x76FC4CC
	public object PushAny(object L, object o) { }

	// RVA: 0x7714890
	public object TranslateToEnumToTop(object L, object type, object idx) { }

	// RVA: 0x7714490
	public object Push(object L, object o) { }

	// RVA: 0x77149E0
	public object Push(object L, object o) { }

	// RVA: 0x7714580
	public object Push(object L, object o) { }

	// RVA: 0x7706E9C
	public object Update(object L, object index, object obj) { }

	// RVA: 0x7714A34
	private object getCsObj(object L, object index, object udata) { }

	// RVA: 0x770AF84
	internal object SafeGetCSObj(object L, object index) { }

	// RVA: 0x7706D40
	public object FastGetCSObj(object L, object index) { }

	// RVA: 0x7714D0C
	internal object ReleaseCSObj(object L, object index) { }

	// RVA: 0x7714E34
	internal object GetFixCSFunction(object index) { }

	// RVA: 0x7714EA0
	internal object PushFixCSFunction(object L, object func) { }

	// RVA: 0x76FCAF0
	internal object popValues(object L, object oldTop) { }

	// RVA: 0x76FC898
	internal object popValues(object L, object oldTop, object popTypes) { }

	// RVA: 0x7715028
	private object registerCustomOp(object type, object push, object get, object update) { }

	// RVA: 0x771513C
	public object HasCustomOp(object type) { }

	// RVA: -1
	private object tryGetPushFuncByType(object type, object func) { }

	// RVA: -1
	private object tryGetGetFuncByType(object type, object func) { }

	// RVA: -1
	public object RegisterPushAndGetAndUpdate(object push, object get, object update) { }

	// RVA: 0x7714300
	public object PushDecimal(object L, object val) { }

	// RVA: 0x770B0A0
	public object IsDecimal(object L, object index) { }

	// RVA: 0x770D3F4
	public object Get(object L, object index, object val) { }

	// RVA: -1
	private object <tryGetGetFuncByType>b__99_0(object L, object idx) { }

}

// Namespace: XLua
public class ObjectTranslatorPool
{

	// Fields
	private object translators; // 0x8
	private object lastPtr; // 0x10
	private object lastTranslator; // 0x18

	// Properties
	public static object Instance { get; }

	// Methods

	// RVA: 0x7702128
	public static object get_Instance() { }

	// RVA: 0x76FE010
	public object .ctor() { }

	// RVA: 0x770218C
	public object Add(object L, object translator) { }

	// RVA: 0x771594C
	public object Find(object L) { }

	// RVA: 0x7704394
	public object Remove(object L) { }

}

// Namespace: XLua
public interface RawObject
{

	// Properties
	public abstract object Target { get; }

	// Methods

	// RVA: -1
	public abstract object get_Target() { }

}

// Namespace: XLua
public class StaticLuaCallbacks
{

	// Fields
	internal object GcMeta; // 0x8
	internal object ToStringMeta; // 0x10
	internal object EnumAndMeta; // 0x18
	internal object EnumOrMeta; // 0x20
	internal object StaticCSFunctionWraper; // 0x28
	internal object FixCSFunctionWraper; // 0x30
	internal object DelegateCtor; // 0x38

	// Methods

	// RVA: 0x7712204
	public object .ctor() { }

	// RVA: 0x7715BBC
	public static object EnumAnd(object L) { }

	// RVA: 0x7715F48
	public static object EnumOr(object L) { }

	// RVA: 0x77162D4
	private static object StaticCSFunction(object L) { }

	// RVA: 0x7716550
	private static object FixCSFunction(object L) { }

	// RVA: 0x77167CC
	public static object DelegateCall(object L) { }

	// RVA: 0x7716AB0
	public static object LuaGC(object L) { }

	// RVA: 0x7716C94
	public static object ToString(object L) { }

	// RVA: 0x7716F84
	public static object DelegateCombine(object L) { }

	// RVA: 0x77172F4
	public static object DelegateRemove(object L) { }

	// RVA: 0x771C9FC
	private static object tryPrimitiveArrayGet(object type, object L, object obj, object index) { }

	// RVA: 0x771762C
	public static object ArrayIndexer(object L) { }

	// RVA: 0x770F18C
	public static object TryPrimitiveArraySet(object type, object L, object obj, object array_idx, object obj_idx) { }

	// RVA: 0x7717B98
	public static object ArrayNewIndexer(object L) { }

	// RVA: 0x7718158
	public static object ArrayLength(object L) { }

	// RVA: 0x77183E4
	public static object MetaFuncIndex(object L) { }

	// RVA: 0x77186F0
	internal static object Panic(object L) { }

	// RVA: 0x77187B4
	internal static object Print(object L) { }

	// RVA: 0x7718AA0
	internal static object LoadSocketCore(object L) { }

	// RVA: 0x7718AFC
	internal static object LoadCS(object L) { }

	// RVA: 0x7718C0C
	internal static object LoadBuiltinLib(object L) { }

	// RVA: 0x7718EE4
	internal static object LoadFromResource(object L) { }

	// RVA: 0x7719294
	internal static object LoadFromStreamingAssetsPath(object L) { }

	// RVA: 0x77195E4
	internal static object LoadFromCustomLoaders(object L) { }

	// RVA: 0x7719A84
	public static object LoadAssembly(object L) { }

	// RVA: 0x7719E68
	public static object ImportType(object L) { }

	// RVA: 0x771A150
	public static object ImportGenericType(object L) { }

	// RVA: 0x771A600
	public static object Cast(object L) { }

	// RVA: 0x771D2F4
	private static object getType(object L, object translator, object idx) { }

	// RVA: 0x771A960
	public static object XLuaAccess(object L) { }

	// RVA: 0x771AF2C
	public static object XLuaPrivateAccessible(object L) { }

	// RVA: 0x771B198
	public static object XLuaMetatableOperation(object L) { }

	// RVA: 0x771B5B0
	public static object DelegateConstructor(object L) { }

	// RVA: 0x771B8B4
	public static object ToFunction(object L) { }

	// RVA: 0x771BCA4
	public static object GenericMethodWraper(object L) { }

	// RVA: 0x771C218
	public static object GetGenericMethod(object L) { }

	// RVA: 0x771C878
	public static object ReleaseCsObject(object L) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__12_0; // 0x8

	// Methods

	// RVA: 0x771DD60
	private static object .cctor() { }

	// RVA: 0x771DDC0
	public object .ctor() { }

	// RVA: 0x771DDC8
	internal object <GetFriendlyName>b__12_0(object x) { }

}

// Namespace: XLua
internal static class TypeExtensions
{

	// Methods

	// RVA: 0x771D534
	public static object IsValueType(object type) { }

	// RVA: 0x771D554
	public static object IsEnum(object type) { }

	// RVA: 0x771D5A8
	public static object IsPrimitive(object type) { }

	// RVA: 0x771D5C8
	public static object IsAbstract(object type) { }

	// RVA: 0x771D5E8
	public static object IsSealed(object type) { }

	// RVA: 0x771D608
	public static object IsInterface(object type) { }

	// RVA: 0x771D628
	public static object IsClass(object type) { }

	// RVA: 0x771D648
	public static object BaseType(object type) { }

	// RVA: 0x771D69C
	public static object IsGenericType(object type) { }

	// RVA: 0x771D6F0
	public static object IsGenericTypeDefinition(object type) { }

	// RVA: 0x771D744
	public static object GetFriendlyName(object type) { }

}

// Namespace: XLua
public enum LazyMemberTypes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Method;
	public const object FieldGet;
	public const object FieldSet;
	public const object PropertyGet;
	public const object PropertySet;
	public const object Event;
}

// Namespace: 
private struct MethodKey
{

	// Fields
	public object Name; // 0xFFFFFFFFFFFFFFF8
	public object IsStatic; // 0x0
}

// Namespace: 
private enum MemberState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknonwn;
	public const object NotExist;
	public const object InBaseType;
	public const object Exist;
}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object exclude_generic_definition; // 0x8
	public object <>9__0; // 0x10

	// Methods

	// RVA: 0x771F0F4
	public object .ctor() { }

	// RVA: 0x772B120
	internal object <GetAllTypes>b__0(object type) { }

}

// Namespace: 
private sealed class <>c__DisplayClass3_0
{

	// Fields
	public object field; // 0x8
	public object type; // 0x10

	// Methods

	// RVA: 0x771F23C
	public object .ctor() { }

	// RVA: 0x772B19C
	internal object <genFieldGetter>b__0(object L) { }

	// RVA: 0x772B254
	internal object <genFieldGetter>b__1(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object field; // 0x8
	public object type; // 0x10

	// Methods

	// RVA: 0x771F41C
	public object .ctor() { }

	// RVA: 0x772B57C
	internal object <genFieldSetter>b__0(object L) { }

	// RVA: 0x772B8CC
	internal object <genFieldSetter>b__1(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass5_0
{

	// Fields
	public object type; // 0x8
	public object props; // 0x10
	public object params_type; // 0x18
	public object arg; // 0x20

	// Methods

	// RVA: 0x771F794
	public object .ctor() { }

	// RVA: 0x772BE4C
	internal object <genItemGetter>b__1(object L) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__5_0; // 0x8
	public static object <>9__6_0; // 0x10
	public static object <>9__8_7; // 0x18
	public static object <>9__8_8; // 0x20
	public static object <>9__8_0; // 0x28
	public static object <>9__8_1; // 0x30
	public static object <>9__8_2; // 0x38
	public static object <>9__8_3; // 0x40
	public static object <>9__8_4; // 0x48
	public static object <>9__8_5; // 0x50
	public static object <>9__8_6; // 0x58
	public static object <>9__10_0; // 0x60
	public static object <>9__10_1; // 0x68
	public static object <>9__10_2; // 0x70

	// Methods

	// RVA: 0x772C510
	private static object .cctor() { }

	// RVA: 0x772C570
	public object .ctor() { }

	// RVA: 0x772C578
	internal object <genItemGetter>b__5_0(object prop) { }

	// RVA: 0x772C6D4
	internal object <genItemSetter>b__6_0(object prop) { }

	// RVA: 0x772C830
	internal object <GetExtensionMethodsOf>b__8_7(object t) { }

	// RVA: 0x772C90C
	internal object <GetExtensionMethodsOf>b__8_8(object t) { }

	// RVA: 0x772C9E8
	internal object <GetExtensionMethodsOf>b__8_0(object type) { }

	// RVA: 0x772CA3C
	internal object <GetExtensionMethodsOf>b__8_1(object type, object method) { }

	// RVA: 0x772CAC8
	internal object <GetExtensionMethodsOf>b__8_2(object <>h__TransparentIdentifier0) { }

	// RVA: 0x772CBFC
	internal object <GetExtensionMethodsOf>b__8_3(object <>h__TransparentIdentifier0) { }

	// RVA: 0x772CC84
	internal object <GetExtensionMethodsOf>b__8_4(object <>h__TransparentIdentifier0) { }

	// RVA: 0x772CCD4
	internal object <GetExtensionMethodsOf>b__8_5(object g) { }

	// RVA: 0x772CDB0
	internal object <GetExtensionMethodsOf>b__8_6(object g) { }

	// RVA: 0x772CDB8
	internal object <makeReflectionWrap>b__10_0(object p) { }

	// RVA: 0x772CE04
	internal object <makeReflectionWrap>b__10_1(object q) { }

	// RVA: 0x772CE50
	internal object <makeReflectionWrap>b__10_2(object p, object q) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object type; // 0x8
	public object props; // 0x10
	public object params_type; // 0x18
	public object arg; // 0x20

	// Methods

	// RVA: 0x771FB0C
	public object .ctor() { }

	// RVA: 0x772CE58
	internal object <genItemSetter>b__1(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass7_0
{

	// Fields
	public object type; // 0x8

	// Methods

	// RVA: 0x771FC14
	public object .ctor() { }

	// RVA: 0x772D708
	internal object <genEnumCastFrom>b__0(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass10_0
{

	// Fields
	public object fieldName; // 0x8

	// Methods

	// RVA: 0x77232CC
	public object .ctor() { }

	// RVA: 0x772D898
	internal object <makeReflectionWrap>b__3(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass14_0
{

	// Fields
	public object memberName; // 0x8

	// Methods

	// RVA: 0x7723BD0
	public object .ctor() { }

	// RVA: 0x772D8F4
	internal object <LazyReflectionCall>b__0(object m) { }

}

// Namespace: 
private sealed class <>c__DisplayClass16_0
{

	// Fields
	public object originalFunction; // 0x8

	// Methods

	// RVA: 0x7723ECC
	public object .ctor() { }

	// RVA: 0x772D950
	internal object <GenLuaCSFunctionWarp>b__0(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass17_0
{

	// Fields
	public object originalFunction; // 0x8
	public object isStatic; // 0x10

	// Methods

	// RVA: 0x7723FDC
	public object .ctor() { }

	// RVA: 0x772D9B8
	internal object <GenGetterWarp>b__0(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass18_0
{

	// Fields
	public object originalFunction; // 0x8
	public object isStatic; // 0x10

	// Methods

	// RVA: 0x77240EC
	public object .ctor() { }

	// RVA: 0x772DA58
	internal object <GenSetterWarp>b__0(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass19_0
{

	// Fields
	public object fieldInfo; // 0x8

	// Methods

	// RVA: 0x77241F4
	public object .ctor() { }

	// RVA: 0x772DB00
	internal object <GenLiteralFieldWarp>b__0(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass27_0
{

	// Fields
	public object type; // 0x8
	public object flag; // 0x10
	public object isStatic; // 0x14
	public object isSetter; // 0x15

	// Methods

	// RVA: 0x77262B4
	public object .ctor() { }

	// RVA: 0x772DBB8
	internal object <GenDelayIndexer>b__0(object L) { }

}

// Namespace: 
private sealed class <>c__DisplayClass28_0
{

	// Fields
	public object type; // 0x8

	// Methods

	// RVA: 0x7727A84
	public object .ctor() { }

	// RVA: 0x7730190
	internal object <ReflectionWrap_New2>b__0(object LL) { }

}

// Namespace: 
private sealed class <>c__DisplayClass29_0
{

	// Fields
	public object type; // 0x8

	// Methods

	// RVA: 0x7728E50
	public object .ctor() { }

	// RVA: 0x7730248
	internal object <ReflectionWrap>b__0(object LL) { }

}

// Namespace: XLua
public static class Utils
{

	// Fields
	private static object AOV_FAST_ENUMERATOR_PATCH; // 0x0

	// Methods

	// RVA: 0x771ED50
	public static object LoadField(object L, object idx, object field_name) { }

	// RVA: 0x771EE4C
	public static object GetAllTypes(object exclude_generic_definition) { }

	// RVA: 0x771F0FC
	private static object genFieldGetter(object type, object field) { }

	// RVA: 0x771F2DC
	private static object genFieldSetter(object type, object field) { }

	// RVA: 0x771F424
	private static object genItemGetter(object type, object props) { }

	// RVA: 0x771F79C
	private static object genItemSetter(object type, object props) { }

	// RVA: 0x771FB14
	private static object genEnumCastFrom(object type) { }

	// RVA: 0x771FC1C
	internal static object GetExtensionMethodsOf(object type_to_be_extend) { }

	// RVA: 0x7720CE0
	private static object makeReflectionWrap(object L, object type, object cls_field, object cls_getter, object cls_setter, object obj_field, object obj_getter, object obj_setter, object obj_meta, object item_getter, object item_setter, object access) { }

	// RVA: 0x7723318
	public static object loadUpvalue(object L, object type, object metafunc, object index) { }

	// RVA: 0x77234C4
	public static object MakePrivateAccessible(object L, object type) { }

	// RVA: 0x771DE28
	internal static object LazyReflectionCall(object L) { }

	// RVA: 0x7723DCC
	private static object GenLuaCSFunctionWarp(object originalFunction) { }

	// RVA: 0x7723ED4
	private static object GenGetterWarp(object originalFunction, object isStatic) { }

	// RVA: 0x7723FE4
	private static object GenSetterWarp(object originalFunction, object isStatic) { }

	// RVA: 0x77240F4
	private static object GenLiteralFieldWarp(object fieldInfo) { }

	// RVA: 0x77241FC
	private static object GenMemberWarp(object L, object type, object memberName, object isStatic, object isSetter, object flags) { }

	// RVA: 0x7725BB4
	private static object GenMemberWarpFunctionRecursion(object L, object type, object memberName, object indexsField, object flags, object isStatic, object isSetter) { }

	// RVA: 0x7725F58
	public static object AheadReflectMember(object L, object type, object memberName, object flags, object isStatic, object isSetter) { }

	// RVA: 0x7726190
	private static object GenDelayIndexer(object type, object isStatic, object isSetter, object access) { }

	// RVA: 0x77262BC
	public static object ReflectionWrap_New2(object L, object type, object privateAccessible) { }

	// RVA: 0x7727FE0
	public static object ReflectionWrap(object L, object type, object privateAccessible) { }

	// RVA: 0x7728E58
	public static object BeginObjectRegister(object type, object L, object translator, object meta_count, object method_count, object getter_count, object setter_count, object type_id) { }

	// RVA: 0x77292BC
	private static object abs_idx(object top, object idx) { }

	// RVA: 0x77292CC
	public static object EndObjectRegister(object type, object L, object translator, object csIndexer, object csNewIndexer, object base_type, object arrayIndexer, object arrayNewIndexer) { }

	// RVA: 0x77299E4
	public static object RegisterFunc(object L, object idx, object name, object func) { }

	// RVA: 0x7729B24
	public static object RegisterObject(object L, object translator, object idx, object name, object obj) { }

	// RVA: 0x7729C2C
	public static object BeginClassRegister(object type, object L, object creator, object class_field_count, object static_getter_count, object static_setter_count) { }

	// RVA: 0x7729E9C
	public static object EndClassRegister(object type, object L, object translator) { }

	// RVA: 0x772A3C4
	private static object getPathOfType(object type) { }

	// RVA: 0x77239F4
	public static object LoadCSTable(object L, object type) { }

	// RVA: 0x7727ADC
	public static object SetCSTable(object L, object type, object cls_table) { }

	// RVA: 0x772A78C
	public static object IsParamsMatch(object delegateMethod, object bridgeMethod) { }

	// RVA: 0x772AAF4
	public static object IsSupportedMethod(object method) { }

	// RVA: 0x772ADD8
	private static object getExtendedType(object method) { }

	// RVA: 0x772AF58
	public static object IsStaticPInvokeCSFunction(object csFunction) { }

	// RVA: 0x772B030
	private static object .cctor() { }

}

// Namespace: XLua.TemplateEngine
public enum TokenType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Code;
	public const object Eval;
	public const object Text;
}

// Namespace: XLua.TemplateEngine
public class Chunk
{

	// Fields
	private object <Type>k__BackingField; // 0x8
	private object <Text>k__BackingField; // 0x10

	// Properties
	public object Type { get; set; }
	public object Text { get; set; }

	// Methods

	// RVA: 0x7730300
	public object get_Type() { }

	// RVA: 0x7730308
	private object set_Type(object value) { }

	// RVA: 0x7730310
	public object get_Text() { }

	// RVA: 0x7730318
	private object set_Text(object value) { }

	// RVA: 0x7730320
	public object .ctor(object type, object text) { }

}

// Namespace: XLua.TemplateEngine
internal class TemplateFormatException
{

	// Methods

	// RVA: 0x773035C
	public object .ctor(object message) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__7_0; // 0x8
	public static object <>9__7_1; // 0x10
	public static object <>9__7_2; // 0x18
	public static object <>9__7_3; // 0x20
	public static object <>9__7_4; // 0x28

	// Methods

	// RVA: 0x77312D0
	private static object .cctor() { }

	// RVA: 0x7731330
	public object .ctor() { }

	// RVA: 0x7731338
	internal object <Parse>b__7_0(object p) { }

	// RVA: 0x77313E0
	internal object <Parse>b__7_1(object p) { }

	// RVA: 0x77314BC
	internal object <Parse>b__7_2(object p) { }

	// RVA: 0x7731564
	internal object <Parse>b__7_3(object p) { }

	// RVA: 0x77315B4
	internal object <Parse>b__7_4(object m) { }

}

// Namespace: XLua.TemplateEngine
public class Parser
{

	// Fields
	private static object <RegexString>k__BackingField; // 0x0

	// Properties
	public static object RegexString { get; set; }

	// Methods

	// RVA: 0x77303E4
	public static object get_RegexString() { }

	// RVA: 0x7730460
	private static object set_RegexString(object value) { }

	// RVA: 0x77304EC
	private static object .cctor() { }

	// RVA: 0x77307C8
	private static object EscapeString(object input) { }

	// RVA: 0x773057C
	private static object GetRegexString() { }

	// RVA: 0x7730B14
	public static object Parse(object snippet) { }

}

// Namespace: XLua.TemplateEngine
public class LuaTemplate
{

	// Fields
	private static object templateCompileFunction; // 0x0
	private static object templateExecuteFunction; // 0x8

	// Methods

	// RVA: 0x7731988
	public static object ComposeCode(object chunks) { }

	// RVA: 0x77316A8
	public static object Compile(object L) { }

	// RVA: 0x77318C0
	public static object Execute(object L) { }

	// RVA: 0x7731DB0
	public static object OpenLib(object L) { }

	// RVA: 0x7732060
	private static object .cctor() { }

}

// Namespace: XLua.LuaDLL
public class Lua
{

	// Methods

	// RVA: 0x7732228
	public static extern object luaopen_libtdrlua(object L) { }

	// RVA: 0x7732224
	public static object LoadTdr(object L) { }

	// RVA: 0x773222C
	public static extern object xlua_get_lib_version() { }

	// RVA: 0x7732230
	public static extern object lua_gc(object L, object what, object data) { }

	// RVA: 0x77234A4
	public static extern object lua_getupvalue(object L, object funcindex, object n) { }

	// RVA: 0x77234C0
	public static extern object lua_setupvalue(object L, object funcindex, object n) { }

	// RVA: 0x7732234
	public static extern object lua_pushthread(object L) { }

	// RVA: 0x7730114
	public static object lua_isfunction(object L, object stackPos) { }

	// RVA: 0x772A770
	public static object lua_istable(object L, object stackPos) { }

	// RVA: 0x7723D8C
	public static object luaL_error(object L, object message) { }

	// RVA: 0x7731DAC
	public static extern object lua_setfenv(object L, object stackPos) { }

	// RVA: 0x773227C
	public static extern object luaL_newstate() { }

	// RVA: 0x7732280
	public static extern object lua_close(object L) { }

	// RVA: 0x7732284
	public static extern object luaopen_xlua(object L) { }

	// RVA: 0x7732288
	public static extern object xlua_objlen(object L, object stackPos) { }

	// RVA: 0x77292B8
	public static extern object lua_createtable(object L, object narr, object nrec) { }

	// RVA: 0x77234B0
	public static object lua_newtable(object L) { }

	// RVA: 0x7730098
	public static extern object xlua_getglobal(object L, object name) { }

	// RVA: 0x773201C
	public static extern object xlua_setglobal(object L, object name) { }

	// RVA: 0x773228C
	public static extern object xlua_getloaders(object L) { }

	// RVA: 0x77239F0
	public static extern object lua_settop(object L, object newTop) { }

	// RVA: 0x77234A8
	public static object lua_pop(object L, object amount) { }

	// RVA: 0x77234A0
	public static extern object lua_remove(object L, object index) { }

	// RVA: 0x771EE2C
	public static extern object lua_rawget(object L, object index) { }

	// RVA: 0x77232D4
	public static extern object lua_rawset(object L, object index) { }

	// RVA: 0x7727FDC
	public static extern object lua_setmetatable(object L, object objIndex) { }

	// RVA: 0x7732290
	public static extern object lua_rawequal(object L, object index1, object index2) { }

	// RVA: 0x77234BC
	public static extern object lua_pushvalue(object L, object index) { }

	// RVA: 0x771EDE8
	public static extern object lua_gettop(object L) { }

	// RVA: 0x7730094
	public static extern object lua_type(object L, object index) { }

	// RVA: 0x771EE30
	public static object lua_isnil(object L, object index) { }

	// RVA: 0x7725F3C
	public static object lua_isboolean(object L, object index) { }

	// RVA: 0x7732294
	public static extern object luaL_ref(object L, object registryIndex) { }

	// RVA: 0x7730130
	public static object luaL_ref(object L) { }

	// RVA: 0x77292B4
	public static extern object xlua_rawgeti(object L, object tableIndex, object index) { }

	// RVA: 0x7732298
	public static extern object xlua_rawseti(object L, object tableIndex, object index) { }

	// RVA: 0x773015C
	public static object lua_getref(object L, object reference) { }

	// RVA: 0x773229C
	public static extern object pcall_prepare(object L, object error_func_ref, object func_ref) { }

	// RVA: 0x77322A0
	public static extern object luaL_unref(object L, object registryIndex, object reference) { }

	// RVA: 0x77322A4
	public static object lua_unref(object L, object reference) { }

	// RVA: 0x77322D8
	public static extern object lua_isinteger(object L, object index) { }

	// RVA: 0x7727FB8
	public static extern object lua_pushnil(object L) { }

	// RVA: 0x7727F34
	public static object lua_pushstdcallcfunction(object L, object function, object n) { }

	// RVA: 0x7723BD8
	public static extern object xlua_upvalueindex(object n) { }

	// RVA: 0x772DA54
	public static extern object lua_pcall(object L, object nArgs, object nResults, object errfunc) { }

	// RVA: 0x77322F8
	public static extern object lua_tonumber(object L, object index) { }

	// RVA: 0x7723BDC
	public static extern object xlua_tointeger(object L, object index) { }

	// RVA: 0x77322FC
	public static extern object xlua_touint(object L, object index) { }

	// RVA: 0x7723D70
	public static extern object lua_toboolean(object L, object index) { }

	// RVA: 0x7732300
	public static extern object lua_topointer(object L, object index) { }

	// RVA: 0x7732304
	public static extern object lua_tolstring(object L, object index, object strLen) { }

	// RVA: 0x7723BE0
	public static object lua_tostring(object L, object index) { }

	// RVA: 0x7732308
	public static extern object lua_atpanic(object L, object panicf) { }

	// RVA: 0x7727AD8
	public static extern object lua_pushnumber(object L, object number) { }

	// RVA: 0x7725F38
	public static extern object lua_pushboolean(object L, object value) { }

	// RVA: 0x7732334
	public static extern object xlua_pushinteger(object L, object value) { }

	// RVA: 0x7732338
	public static extern object xlua_pushuint(object L, object value) { }

	// RVA: 0x77300DC
	public static extern object lua_pushstring(object L, object str) { }

	// RVA: 0x773233C
	public static extern object xlua_pushlstring(object L, object str, object size) { }

	// RVA: 0x771EDEC
	public static object xlua_pushasciistring(object L, object str) { }

	// RVA: 0x773234C
	public static object lua_pushstring(object L, object str) { }

	// RVA: 0x7732360
	public static object lua_tobytes(object L, object index) { }

	// RVA: 0x7727A8C
	public static extern object luaL_newmetatable(object L, object meta) { }

	// RVA: 0x772A76C
	public static extern object xlua_pgettable(object L, object idx) { }

	// RVA: 0x7732470
	public static extern object xlua_psettable(object L, object idx) { }

	// RVA: 0x7723994
	public static object luaL_getmetatable(object L, object meta) { }

	// RVA: 0x7732474
	public static extern object xluaL_loadbuffer(object L, object buff, object size, object name) { }

	// RVA: 0x7731CD4
	public static object luaL_loadbuffer(object L, object buff, object name) { }

	// RVA: 0x77324D8
	public static extern object xlua_tocsobj_safe(object L, object obj) { }

	// RVA: 0x77324DC
	public static extern object xlua_tocsobj_fast(object L, object obj) { }

	// RVA: 0x7731D94
	public static object lua_error(object L) { }

	// RVA: 0x77232B0
	public static extern object lua_checkstack(object L, object extra) { }

	// RVA: 0x77324E4
	public static extern object lua_next(object L, object index) { }

	// RVA: 0x7727AD4
	public static extern object lua_pushlightuserdata(object L, object udata) { }

	// RVA: 0x7727AD0
	public static extern object xlua_tag() { }

	// RVA: 0x77324E8
	public static extern object xlua_tryget_cachedud(object L, object key, object cache_ref) { }

	// RVA: 0x77324EC
	public static extern object xlua_pushcsobj(object L, object key, object meta_ref, object need_cache, object cache_ref) { }

	// RVA: 0x7727FBC
	public static extern object gen_obj_indexer(object L) { }

	// RVA: 0x7727FC4
	public static extern object gen_obj_newindexer(object L) { }

	// RVA: 0x7727FCC
	public static extern object gen_cls_indexer(object L) { }

	// RVA: 0x7727FD4
	public static extern object gen_cls_newindexer(object L) { }

	// RVA: 0x77324F0
	public static extern object get_error_func_ref(object L) { }

	// RVA: 0x77324F4
	public static extern object load_error_func(object L, object Ref) { }

	// RVA: 0x77324F8
	public static extern object luaopen_i64lib(object L) { }

	// RVA: 0x77324FC
	public static extern object luaopen_socket_core(object L) { }

	// RVA: 0x7732500
	public static extern object lua_pushint64(object L, object n) { }

	// RVA: 0x7732504
	public static extern object lua_pushuint64(object L, object n) { }

	// RVA: 0x7732508
	public static extern object lua_isint64(object L, object idx) { }

	// RVA: 0x7732524
	public static extern object lua_isuint64(object L, object idx) { }

	// RVA: 0x7732540
	public static extern object lua_toint64(object L, object idx) { }

	// RVA: 0x7732544
	public static extern object lua_touint64(object L, object idx) { }

	// RVA: 0x77322F4
	public static extern object xlua_push_csharp_function(object L, object fn, object n) { }

	// RVA: 0x7732238
	public static extern object xlua_csharp_str_error(object L, object message) { }

	// RVA: 0x77324E0
	public static extern object xlua_csharp_error(object L) { }

	// RVA: 0x7732548
	public static extern object xlua_pack_int8_t(object buff, object offset, object field) { }

	// RVA: 0x7732564
	public static extern object xlua_unpack_int8_t(object buff, object offset, object field) { }

	// RVA: 0x7732580
	public static extern object xlua_pack_int16_t(object buff, object offset, object field) { }

	// RVA: 0x773259C
	public static extern object xlua_unpack_int16_t(object buff, object offset, object field) { }

	// RVA: 0x77325B8
	public static extern object xlua_pack_int32_t(object buff, object offset, object field) { }

	// RVA: 0x77325D4
	public static extern object xlua_unpack_int32_t(object buff, object offset, object field) { }

	// RVA: 0x77325F0
	public static extern object xlua_pack_int64_t(object buff, object offset, object field) { }

	// RVA: 0x773260C
	public static extern object xlua_unpack_int64_t(object buff, object offset, object field) { }

	// RVA: 0x7732628
	public static extern object xlua_pack_float(object buff, object offset, object field) { }

	// RVA: 0x7732644
	public static extern object xlua_unpack_float(object buff, object offset, object field) { }

	// RVA: 0x7732660
	public static extern object xlua_pack_double(object buff, object offset, object field) { }

	// RVA: 0x773267C
	public static extern object xlua_unpack_double(object buff, object offset, object field) { }

	// RVA: 0x7732698
	public static extern object xlua_pushstruct(object L, object size, object meta_ref) { }

	// RVA: 0x773269C
	public static extern object lua_touserdata(object L, object idx) { }

	// RVA: 0x77326A0
	public static extern object xlua_gettypeid(object L, object idx) { }

	// RVA: 0x77326A4
	public static extern object xlua_get_registry_index() { }

	// RVA: 0x77326A8
	public static extern object xlua_pgettable_bypath(object L, object idx, object path) { }

	// RVA: 0x77326FC
	public static extern object xlua_pack_float2(object buff, object offset, object f1, object f2) { }

	// RVA: 0x7732718
	public static extern object xlua_unpack_float2(object buff, object offset, object f1, object f2) { }

	// RVA: 0x7732734
	public static extern object xlua_pack_float3(object buff, object offset, object f1, object f2, object f3) { }

	// RVA: 0x7732750
	public static extern object xlua_unpack_float3(object buff, object offset, object f1, object f2, object f3) { }

	// RVA: 0x773276C
	public static extern object xlua_pack_float4(object buff, object offset, object f1, object f2, object f3, object f4) { }

	// RVA: 0x7732788
	public static extern object xlua_unpack_float4(object buff, object offset, object f1, object f2, object f3, object f4) { }

	// RVA: 0x77327A4
	public static extern object xlua_pack_decimal(object buff, object offset, object dec) { }

	// RVA: 0x77327C0
	public static extern object xlua_unpack_decimal(object buff, object offset, object scale, object sign, object hi32, object lo64) { }

	// RVA: 0x77327DC
	public static object xlua_is_eq_str(object L, object index, object str) { }

	// RVA: 0x773284C
	public static extern object xlua_is_eq_str(object L, object index, object str, object str_len) { }

	// RVA: 0x77328AC
	public static extern object xlua_gl(object L) { }

	// RVA: 0x7727FC0
	public static extern object gen_obj_delay_indexer(object L) { }

	// RVA: 0x7727FC8
	public static extern object gen_obj_delay_newindexer(object L) { }

	// RVA: 0x7727FD0
	public static extern object gen_cls_delay_indexer(object L) { }

	// RVA: 0x7727FD8
	public static extern object gen_cls_delay_newindexer(object L) { }

}

// Namespace: XLua.LuaDLL
public sealed class lua_CSFunction
{

	// Methods

	// RVA: 0x771F244
	public object .ctor(object object, object method) { }

	// RVA: 0x7732934
	public virtual object Invoke(object L) { }

}

