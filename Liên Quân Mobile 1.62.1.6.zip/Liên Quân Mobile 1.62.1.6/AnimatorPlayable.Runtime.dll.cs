// Namespace: 
internal class <Module>
{
}

// Namespace: 
public class RelativePositonForAnimation
{

	// Fields
	public object positon; // 0x18
	private object m_startPosition; // 0x20
	private object m_rectTrans; // 0x28

	// Methods

	// RVA: 0x355A44
	private object Start() { }

	// RVA: 0x355ACC
	private object Update() { }

	// RVA: 0x355B00
	public object .ctor() { }

}

// Namespace: MainThread.AnimatorPlayable
internal class AnimationClipCarrier
{

	// Fields
	public object mAnimClips; // 0x18

	// Methods

	// RVA: 0x355B08
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class AnimationClipEvent
{

	// Fields
	public object mAnimation; // 0x18
	public object mPlayAutomatically; // 0x20

	// Methods

	// RVA: 0x355B10
	private object Awake() { }

	// RVA: 0x355BDC
	private object OnEnable() { }

	// RVA: 0x355C8C
	private object OnDisable() { }

	// RVA: 0x355D3C
	public object PlayAnimation(object clipName) { }

	// RVA: 0x355E10
	public object .ctor() { }

}

// Namespace: 
private class StateMachineLayer
{

	// Fields
	public object LayerIdx; // 0x8
	public object StateMachine; // 0x10
	public object Additive; // 0x18
	public object Weight; // 0x1C
	public object Mask; // 0x20

	// Methods

	// RVA: 0x3569FC
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class AnimatorPlayableBehaviour
{

	// Fields
	private object m_mixer; // 0x8
	private object m_layerList; // 0x18
	private object m_layerDict; // 0x20
	private object m_allStateSet; // 0x28
	public object AllowTransition; // 0x30
	public object AllowManualUpdate; // 0x31
	private object m_playable; // 0x38

	// Properties
	public object BaseStateMachine { get; }
	public object PlayGraphCallBack { set; }
	public object StopGraphCallBack { set; }
	public object playable { get; }
	public object ActiveStateName { get; }
	public object ActiveStateDuration { get; }
	public object ActiveStateSpeed { set; }
	public object IsTransitioning { get; }
	public object IsActiveBlendTree { get; }
	public object CurrentStateTime { get; }

	// Methods

	// RVA: 0x355E20
	public object get_BaseStateMachine() { }

	// RVA: 0x355F34
	public object set_PlayGraphCallBack(object value) { }

	// RVA: 0x355FD0
	public object set_StopGraphCallBack(object value) { }

	// RVA: 0x35606C
	public object get_playable() { }

	// RVA: 0x356078
	public object get_ActiveStateName() { }

	// RVA: 0x35613C
	public object get_ActiveStateDuration() { }

	// RVA: 0x356260
	public object set_ActiveStateSpeed(object value) { }

	// RVA: 0x35644C
	public object get_IsTransitioning() { }

	// RVA: 0x356508
	public object get_IsActiveBlendTree() { }

	// RVA: 0x356624
	public object get_CurrentStateTime() { }

	// RVA: 0x356754
	public object .ctor() { }

	// RVA: 0x356B94
	public object AddLayerStateMachine(object idx, object weight, object additive, object mask) { }

	// RVA: 0x357270
	public object ResetActiveState() { }

	// RVA: 0x355EA8
	private object GetLayer(object idx) { }

	// RVA: 0x357490
	public object ContainState(object szState, object layerIdx) { }

	// RVA: 0x3575F8
	public object GetStateAnimationTime(object szState, object layerIdx) { }

	// RVA: 0x357868
	public object OnPlayableEnable(object szState) { }

	// RVA: 0x357B40
	public object OnPlayableDisable() { }

	// RVA: 0x357E00
	public object ClearAllAnimationWeight() { }

	// RVA: 0x358104
	public override object OnPlayableCreate(object playable) { }

	// RVA: 0x358458
	public override object PrepareFrame(object owner, object data) { }

	// RVA: 0x358648
	public object Pause() { }

	// RVA: 0x3587D0
	public object Resume() { }

	// RVA: 0x358460
	public object UpdatePlayableBehaviour(object forceUpdate) { }

	// RVA: 0x358B3C
	public object AddClip(object szStateName, object animClip, object layerIdx) { }

	// RVA: 0x359498
	public object AddBlendTree(object szStateName, object nodeList, object blendTreeParameter1, object blendTreeParameter2, object blendType, object layerMixable, object layerIdx) { }

	// RVA: 0x359950
	public object AddLayerMixer(object szStateName, object layerIdx) { }

	// RVA: 0x359DB8
	public object SetBoolParam(object szBool, object bValue) { }

	// RVA: 0x359F58
	public object GetBoolParam(object name, object layerIndex) { }

	// RVA: 0x35A140
	public object SetFloatParam(object szFloat, object fValue) { }

	// RVA: 0x35A2E0
	public object GetFloatParam(object name, object layerIndex) { }

	// RVA: 0x35A470
	public object GetIntParam(object name, object layerIndex) { }

	// RVA: 0x35A5F0
	public object SetIntParam(object szInt, object nValue) { }

	// RVA: 0x35A790
	public object SetTriggerParam(object szTrigger) { }

	// RVA: 0x35AA10
	public object RemoveClip(object animClip, object layerIdx) { }

	// RVA: 0x35ACFC
	public object ChangeState(object stateName, object newClip, object newSpeed, object layerIdx) { }

	// RVA: 0x35B194
	public object ChangeTransitionData(object inSrcStateName, object inTarStateName, object inPreTransitionInfo, object layerIdx) { }

	// RVA: 0x35B63C
	public object ChangeTransitionCondition(object inSrcStateName, object inTarStateName, object inConditions, object layerIdx) { }

	// RVA: 0x35BD84
	public object RemoveClip(object szStateName, object layerIdx) { }

	// RVA: 0x35BE38
	public object RemoveState(object szStateName, object layerIdx) { }

	// RVA: 0x35C2F0
	public object SetDefaultState(object szStateName, object layerIdx) { }

	// RVA: 0x35C4CC
	public object Play(object szStateName, object durationTime, object offsetTime, object layerIdx) { }

	// RVA: 0x35C850
	public object DirectorSetParam(object setParamCmd) { }

	// RVA: 0x35CB08
	public object SimulateTimeTransition(object szSimulateState, object fDistTime) { }

	// RVA: 0x35CD74
	public object SimulateStateTransition(object szSimulateState, object fDistTime) { }

	// RVA: 0x35D038
	public override object OnPlayableDestroy(object playable) { }

	// RVA: 0x35D2EC
	public object Clear() { }

	// RVA: 0x35D474
	public object GetDebugInfo() { }

	// RVA: 0x35DC40
	public object ResetBoolParam(object szBoolName, object bValue) { }

	// RVA: 0x35DEB0
	public object ResetFloatParam(object szBoolName, object fValue) { }

	// RVA: 0x35E12C
	public object ResetIntParam(object szBoolName, object nValue) { }

	// RVA: 0x35E39C
	public object ResetTriggerParam(object szTriggerName) { }

	// RVA: 0x35E5F8
	public object ReplaceAnimation(object originClip, object newClip) { }

	// RVA: 0x35E798
	public object ReplaceAnimation(object stateName, object clip, object stateLayerIdx) { }

	// RVA: 0x35E9D0
	public object SetStateLayer(object stateName, object nodeName, object clip, object layerIdx, object weight, object mask, object stateLayerIdx, object additive) { }

	// RVA: 0x35F0D8
	public object ResetGlobalSpeed() { }

	// RVA: 0x35F24C
	public object ResetAllStateValue() { }

}

// Namespace: UnityAnimatorPlayable.M
public class CommandType
{

	// Fields
	public static readonly object PlayCommand; // 0x0
	public static readonly object TranstionCommand; // 0x8

	// Methods

	// RVA: 0x35F4E8
	private static object .cctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public enum eAnimClipPlayStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Playing;
	public const object PlayDone;
	public const object NextPlay;
}

// Namespace: UnityAnimatorPlayable.M
public class TransitionMixer
{

	// Fields
	public object IsOpen; // 0x8
	public object backContinueTime; // 0xC
	public object duration; // 0x10
	public object recordTime; // 0x14
	public object nFromIndex; // 0x18
	public object nToIndex; // 0x1C
	public object eInterruptionType; // 0x20
	public object nAnyStatePriority; // 0x24

	// Methods

	// RVA: 0x35F570
	public object Clear() { }

	// RVA: 0x35F590
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public struct AnimatorPlayableCmd
{

	// Fields
	public object bActive; // 0xFFFFFFFFFFFFFFF8
	public object szType; // 0x0
	public object szParam; // 0x8
	public object nIndex; // 0x10
	public object durationTime; // 0x14
	public object offsetTime; // 0x18
	public object eInterruptionType; // 0x1C
	public object nAnyStatePriority; // 0x20
}

// Namespace: 
public enum BlendType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BLEND_1D;
	public const object BLEND_2D_FREEFORM_CARTESIAN;
}

// Namespace: 
public class Blend2DData
{

	// Fields
	private object m_nodePostions; // 0x8
	private object m_nodePairVectors; // 0x10
	private object m_nodePairVecMagInvs; // 0x18
	private object m_nodeNeighbors; // 0x20
	private object <Weights>k__BackingField; // 0x28
	private object m_tempBlendVectors; // 0x30

	// Properties
	public object Weights { get; set; }

	// Methods

	// RVA: 0x363504
	public object get_Weights() { }

	// RVA: 0x36350C
	private object set_Weights(object value) { }

	// RVA: 0x360918
	public object InitBlendData(object nodePositions) { }

	// RVA: 0x363514
	private object PreCompute() { }

	// RVA: 0x363C38
	private static object calcMatchNeighbors(object clostNeighbors, object blendPosition, object nodePositions, object pairInvMags, object pairVectors, object blendVectors) { }

	// RVA: 0x362894
	public object CalcWeights(object blendPosition) { }

	// RVA: 0x360910
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class AnimatorPlayableBlendTree
{

	// Fields
	private object m_arrBlendTreeNodes; // 0x88
	private object m_mixPlayable; // 0x90
	private object m_graph; // 0xA0
	private object m_blendTreeParameterX; // 0xB0
	private object m_blendTreeParameterY; // 0xB8
	private object m_fthresholdValue; // 0xC0
	private object m_bthresholdInit; // 0xC4
	private object m_curBlendNodeLeft; // 0xC8
	private object m_curBlendNodeRight; // 0xD0
	private object m_nodeLayerMixable; // 0xD8
	private object m_blend2Ddata; // 0xE0
	private object <blendType>k__BackingField; // 0xE8
	private object m_blendValueX; // 0xEC
	private object m_blendValueY; // 0xF0

	// Properties
	public object blendType { get; set; }
	public object blendTreeParameterX { get; }
	public object blendTreeParameterY { get; }

	// Methods

	// RVA: 0x35F69C
	public object get_blendType() { }

	// RVA: 0x35F6A4
	private object set_blendType(object value) { }

	// RVA: 0x35F6AC
	public object .ctor(object graph) { }

	// RVA: 0x35F7DC
	public object get_blendTreeParameterX() { }

	// RVA: 0x35F7E4
	public object get_blendTreeParameterY() { }

	// RVA: 0x35F7EC
	public override object GetPlayable() { }

	// RVA: 0x35F858
	public object InitBlendTree(object nodeList, object blendTreeParameter1, object blendTreeParameter2, object blendType, object layerMixable) { }

	// RVA: 0x360920
	public override object ReplaceAnimation(object originClip, object newClip) { }

	// RVA: 0x360C50
	public override object ReplaceAnimation(object stateName, object clip) { }

	// RVA: 0x361010
	public object SetStateLayer(object nodeName, object clip, object layerIdx, object weight, object mask, object additive) { }

	// RVA: 0x3611AC
	public override object IsBlendTree() { }

	// RVA: 0x3611B4
	public override object IsOnceAnimation() { }

	// RVA: 0x361258
	public override object SimulatePlayEnd(object fTime) { }

	// RVA: 0x3613B4
	public override object PlayablePlay(object fGlobalSpeed, object floatParams, object fOffsetTime) { }

	// RVA: 0x361B60
	public override object PlayableStop() { }

	// RVA: 0x361BB4
	public override object ManualPlayablePause() { }

	// RVA: 0x361C94
	public override object GetDurationTime() { }

	// RVA: 0x361FFC
	public override object GetCurrentStateTime() { }

	// RVA: 0x3620F4
	public override object UpdateFrame(object bInTransition) { }

	// RVA: 0x362390
	public override object SetSpeed(object speedValue) { }

	// RVA: 0x362484
	public override object ResetStateTime() { }

	// RVA: 0x362634
	public override object Clear() { }

	// RVA: 0x361EB4
	private object GetBlendWeight(object fValue, object outLeftValue, object outRightValue, object outLeftBlendNode, object outRightBlendNode) { }

	// RVA: 0x361760
	public object CalcBlendWeight1D() { }

	// RVA: 0x361994
	public object CalcBlendWeight2D() { }

	// RVA: 0x360BA8
	public object ApplyCurrentWeight() { }

	// RVA: 0x362DC0
	protected override object IsPlayTimeEnd(object data, object fSimulateTime) { }

	// RVA: 0x362F7C
	public override object SetFloatParam(object name, object value) { }

	// RVA: 0x3630A0
	public override object SetIntParam(object name, object value) { }

	// RVA: 0x3630A4
	public override object SetBoolParam(object name, object value) { }

	// RVA: 0x3630A8
	public override object GetAnimClipPlayStatus() { }

}

// Namespace: UnityAnimatorPlayable.M
public enum AnimatorPlayableCullingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AlwaysAnimate;
	public const object InvisibleLowUpdate;
	public const object BattleOptimize;
}

// Namespace: UnityAnimatorPlayable.M
public enum AnimatorPlayableVisibilityAlgorithm
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BasedOnRenderers;
	public const object BasedOnPosition;
	public const object BasedOnViewport;
}

// Namespace: 
public sealed class OnAnimRootMotionPlayedCallback
{

	// Methods

	// RVA: 0x368778
	public object .ctor(object object, object method) { }

	// RVA: 0x3689C4
	public virtual object Invoke(object inClip, object inWeight) { }

}

// Namespace: 
public sealed class OnAnimRootMotionStoppedCallback
{

	// Methods

	// RVA: 0x368828
	public object .ctor(object object, object method) { }

	// RVA: 0x368A48
	public virtual object Invoke(object inHandle) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__114_0; // 0x8
	public static object <>9__114_1; // 0x10

	// Methods

	// RVA: 0x368A5C
	private static object .cctor() { }

	// RVA: 0x368ABC
	public object .ctor() { }

	// RVA: 0x368AC4
	internal object <.ctor>b__114_0(object <p0>, object <p1>) { }

	// RVA: 0x368ACC
	internal object <.ctor>b__114_1(object <p0>) { }

}

// Namespace: UnityAnimatorPlayable.M
public class AnimatorPlayableComponent
{

	// Fields
	public static object EnableBattleOptimize; // 0x0
	public static object EnablePlayableTransitionWithBuild; // 0x1
	private object m_animator; // 0x18
	private object m_playableGraph; // 0x20
	private object m_playableBehaviour; // 0x30
	private object m_bIsInited; // 0x38
	private object m_bIsPlayGraph; // 0x39
	public object Controller; // 0x40
	public object m_instantiatedController; // 0x48
	public object DisableStillPlay; // 0x50
	public object oldAnimatorPath; // 0x58
	public object AllowTransition; // 0x60
	public object PlayOnEnable; // 0x61
	public object oldAnimatorControllerCache; // 0x68
	public object DefaultAnimation; // 0x70
	public object CullingModeExtend; // 0x78
	public object VisibilityAlgorithm; // 0x7C
	public object VisibilityBasedOnPositionDistance; // 0x80
	public object OnAnimRootMotionPlayed; // 0x88
	public object OnAnimRootMotionStopped; // 0x90
	private object m_fEnterAnimationTime; // 0x98
	private object m_bIsVisibility; // 0x9C
	private object m_invisibleOptModule; // 0xA0
	private object m_fInvisibleTimeAccum; // 0xA8
	private const object DetermineInvisibleTime;
	private object mLateUpdateImp; // 0xB0
	private object m_cameraCache; // 0xB8
	private object m_transformCache; // 0xC0
	private object m_boneTransformCache; // 0xC8
	private object m_bVisibleCache; // 0xD0
	private object m_fUpdateVisibleTimeStamp; // 0xD4
	private const object UpdateVisibleInterval;
	private const object LowLevelUpdateVisibleInterval;
	private object m_updateVisibleInterval; // 0xD8
	private object m_renderers; // 0xE0
	public object PreAnimationStates; // 0xE8
	public object PreBoolParams; // 0xF0
	public object PreFloatParams; // 0xF8
	public object PreIntParams; // 0x100
	public object PreTriggerParams; // 0x108
	public object OpenDebugLabel; // 0x110
	public object OpenParamInfo; // 0x111
	private object m_output; // 0x118

	// Properties
	public object animator { get; }
	public object Graph { get; }

	// Methods

	// RVA: 0x363EE0
	public object get_animator() { }

	// RVA: 0x363EE8
	public object get_Graph() { }

	// RVA: 0x363EF4
	private object Awake() { }

	// RVA: 0x364010
	public object Init() { }

	// RVA: 0x364744
	private object BuildGraph() { }

	// RVA: 0x36464C
	public object ResetAnimatorCullMode() { }

	// RVA: 0x3664CC
	public object InitDefaultClip(object animClip, object bPlayOnEnable) { }

	// RVA: 0x366758
	public object DefaultPlay() { }

	// RVA: 0x3668EC
	public object ChangeState(object stateName, object animationClip, object speed) { }

	// RVA: 0x366910
	public object ChangeTransitionData(object inSrcStateName, object inTarStateName, object inPreTransitionInfo) { }

	// RVA: 0x366984
	public object ChangeTransitionCondition(object inSrcStateName, object inTarStateName, object inPreTransitionInfo) { }

	// RVA: 0x3669C0
	public object AddTransition(object inSrcStateName, object inPreTransitionInfo) { }

	// RVA: 0x366BA4
	public object RebuildGraph() { }

	// RVA: 0x366E2C
	public object Pause() { }

	// RVA: 0x366E4C
	public object Resume() { }

	// RVA: 0x366E6C
	public object GetBindAnimator() { }

	// RVA: 0x365790
	public object ResetParamsData() { }

	// RVA: 0x366E74
	public object ResetTrigger(object szTrigger) { }

	// RVA: 0x366EBC
	public object ReplaceAnimation(object originClip, object targetClip) { }

	// RVA: 0x366FC8
	public object ReplaceAnimation(object stateName, object clip, object stateLayerIdx) { }

	// RVA: 0x3670A4
	public object SetStateLayer(object stateName, object nodeName, object clip, object layerIdx, object weight, object mask, object stateLayerIdx, object additive) { }

	// RVA: 0x366D34
	private object OnEnable() { }

	// RVA: 0x3670D8
	private object LateUpdate() { }

	// RVA: 0x366808
	public object EnableImpl() { }

	// RVA: 0x366BD8
	private object OnDisable() { }

	// RVA: 0x367168
	public object DisableImpl() { }

	// RVA: 0x365B98
	private object ExecPlay() { }

	// RVA: 0x3671E0
	private object ExecStop() { }

	// RVA: 0x367104
	public object Play(object szStateName, object durationTime, object offsetTime, object layerIdx) { }

	// RVA: 0x366478
	public object AddClip(object szStateName, object animClip, object layerIdx) { }

	// RVA: 0x36721C
	public object AddLayerMixer(object szStateName, object layerIdx) { }

	// RVA: 0x36723C
	public object SetBool(object szBool, object bValue) { }

	// RVA: 0x3672BC
	public object GetBool(object name, object layerIndex) { }

	// RVA: 0x3672DC
	public object GetInteger(object name, object layerIdex) { }

	// RVA: 0x3673A8
	public object SetInteger(object szInt, object nValue) { }

	// RVA: 0x367428
	public object SetFloat(object szFloat, object fValue) { }

	// RVA: 0x3674A8
	public object GetFloat(object name, object layerIndex) { }

	// RVA: 0x3674C8
	public object SetTrigger(object szTrigger) { }

	// RVA: 0x367530
	public object RemoveClip(object szStateName) { }

	// RVA: 0x3675E0
	public object RemoveClip(object animClip) { }

	// RVA: 0x367690
	public object RemoveState(object szStateName) { }

	// RVA: 0x3676B4
	public object SetDefaultState(object szStateName) { }

	// RVA: 0x367764
	public object GetActiveStateName() { }

	// RVA: 0x367784
	public object GetAcitveStateDuration() { }

	// RVA: 0x3677A4
	public object GetCurrentStateTime() { }

	// RVA: 0x3677C4
	public object SetActiveStateSpeed(object fValue) { }

	// RVA: 0x3677E4
	public object SetEnterAnimationTime(object fNormalizedTime) { }

	// RVA: 0x3677EC
	public object ResetActiveState() { }

	// RVA: 0x36780C
	public object ContainState(object szState) { }

	// RVA: 0x367820
	private object LateUpdate_Implementation() { }

	// RVA: 0x367A50
	public object ManualVisible() { }

	// RVA: 0x367B1C
	public object ManualUpdate(object forceUpdate) { }

	// RVA: 0x367878
	private object UpdateVisibilityOptimize() { }

	// RVA: 0x367ABC
	private object ExecBecameVisible() { }

	// RVA: 0x367BC4
	private object ExecBecameInVisible() { }

	// RVA: 0x367B38
	private object UpdateVisibility() { }

	// RVA: 0x367E0C
	private object UpdateVisibilityByRenderers() { }

	// RVA: 0x367C54
	private object UpdateVisibilityByViewport() { }

	// RVA: 0x367C4C
	private object UpdateVisibilityByPosition() { }

	// RVA: 0x367EB4
	public object GetDebugInfo() { }

	// RVA: 0x367ED4
	public object GetAllAnimationsInEditor() { }

	// RVA: 0x367F48
	private object OnDestroy() { }

	// RVA: 0x366BDC
	public object Clear() { }

	// RVA: 0x368024
	public object OnBeforeSerialize() { }

	// RVA: 0x368028
	public object OnAfterDeserialize() { }

	// RVA: 0x365B78
	private object IsLayerMixerNode(object state) { }

	// RVA: 0x36802C
	public object AddState(object state) { }

	// RVA: 0x3684DC
	public object .ctor() { }

	// RVA: 0x3688C0
	private static object .cctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class LayerMixNode
{

	// Fields
	public object m_nodeName; // 0x8
	public object LayerIdx; // 0x10
	public object Clip; // 0x18
	public object WeightParamName; // 0x20
	public object WeightValue; // 0x28
	public object Additive; // 0x2C
	public object Mask; // 0x30

	// Methods

	// RVA: 0x35FE60
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class AnimatorPlayableLayerMixer
{

	// Fields
	private object m_layerMixer; // 0x88
	private object m_layerPlayableList; // 0x98
	private object m_layerNodeList; // 0xA0

	// Methods

	// RVA: 0x368AD0
	private object GetBaseClip() { }

	// RVA: 0x368B6C
	public override object GetPlayable() { }

	// RVA: 0x368BD8
	public override object Init(object szStateName, object graph) { }

	// RVA: 0x368D1C
	public object InitLayerMixed(object graph) { }

	// RVA: 0x35FE68
	public object AddLayerNode(object node) { }

	// RVA: 0x368E28
	public override object ReplaceAnimation(object originClip, object newClip) { }

	// RVA: 0x36913C
	public override object ReplaceAnimation(object stateName, object clip) { }

	// RVA: 0x369534
	public override object IsOnceAnimation() { }

	// RVA: 0x369608
	public override object PlayablePlay(object fGlobalSpeed, object floatParams, object fOffsetTime) { }

	// RVA: 0x369A30
	public override object PlayableStop() { }

	// RVA: 0x369BD4
	public override object ManualPlayablePause() { }

	// RVA: 0x369D40
	public override object UpdateFrame(object bInTransition) { }

	// RVA: 0x369F80
	public override object SetSpeed(object speedValue) { }

	// RVA: 0x36A0E0
	public override object ResetStateTime() { }

	// RVA: 0x36A2A4
	public override object GetDurationTime() { }

	// RVA: 0x36A3D8
	public override object GetCurrentStateTime() { }

	// RVA: 0x36A478
	protected override object IsPlayTimeEnd(object data, object fSimulateTime) { }

	// RVA: 0x36A618
	public override object SimulatePlayEnd(object fTime) { }

	// RVA: 0x36A718
	public override object GetAnimClipPlayStatus() { }

	// RVA: 0x36A9F4
	public override object Clear() { }

	// RVA: 0x35FE5C
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class AnimatorPlayableState
{

	// Fields
	private object m_animClip; // 0x88
	private object m_playable; // 0x90
	private object m_fLastUpdatePlayState; // 0xA0
	private object m_fUpdateIntervalTime; // 0xA4

	// Properties
	public object animationClip { get; }

	// Methods

	// RVA: 0x36AB3C
	public object get_animationClip() { }

	// RVA: 0x36AB44
	public override object GetPlayable() { }

	// RVA: 0x36AB54
	public override object Init(object szStateName, object graph) { }

	// RVA: 0x36068C
	public object InitAnimation(object animClip) { }

	// RVA: 0x36AB58
	public override object IsOnceAnimation() { }

	// RVA: 0x36ABBC
	public override object ReplaceAnimation(object originClip, object newClip) { }

	// RVA: 0x36ADF8
	public override object ReplaceAnimation(object stateName, object clip) { }

	// RVA: 0x36B03C
	public override object PlayablePlay(object fGlobalSpeed, object floatParams, object fOffsetTime) { }

	// RVA: 0x36B2D0
	public override object PlayableStop() { }

	// RVA: 0x36B378
	public override object ManualPlayablePause() { }

	// RVA: 0x36B3CC
	public override object UpdateFrame(object bInTransition) { }

	// RVA: 0x36B660
	public override object SetSpeed(object speedValue) { }

	// RVA: 0x36B6C4
	public override object ResetStateTime() { }

	// RVA: 0x36B770
	public override object GetDurationTime() { }

	// RVA: 0x36B794
	public override object GetCurrentStateTime() { }

	// RVA: 0x36B7E8
	protected override object IsPlayTimeEnd(object data, object fSimulateTime) { }

	// RVA: 0x36B8F0
	public override object SimulatePlayEnd(object fTime) { }

	// RVA: 0x36B99C
	public override object GetAnimClipPlayStatus() { }

	// RVA: 0x36BBB0
	public override object Clear() { }

	// RVA: 0x360688
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class AnimatorPlayableStateMachine
{

	// Fields
	private object m_stateList; // 0x88
	private object m_stateWeightList; // 0x90
	private object m_stateIndexMap; // 0x98
	private object m_animMixer; // 0xA0
	private object m_curActiveState; // 0xB0
	private object m_bStateInited; // 0xB8
	private object m_paused; // 0xB9
	public object AllowTransition; // 0xBA
	public object AllowManualUpdate; // 0xBB
	public object PlayGraphCallBack; // 0xC0
	public object StopGraphCallBack; // 0xC8
	private object m_defaultStateName; // 0xD0
	private object m_fGlobalSpeed; // 0xD8
	private object m_playAnimationCMD; // 0xE0
	private object m_transitionCMD; // 0x110
	private object m_boolParams; // 0x140
	private object m_floatParams; // 0x148
	private object m_intParams; // 0x150
	private object m_triggerParams; // 0x158
	private object m_transitionMixer; // 0x160
	private object m_prevState; // 0x168
	private object m_szPrevStateName; // 0x170

	// Properties
	public object ActiveStateName { get; }
	public object ActiveStateDuration { get; }
	public object ActiveStateSpeed { set; }
	public object IsTransitioning { get; }
	public object IsActiveBlendTree { get; }

	// Methods

	// RVA: 0x36BC98
	public override object GetPlayable() { }

	// RVA: 0x36BD04
	public override object Init(object szStateName, object graph) { }

	// RVA: 0x36BE9C
	public override object IsOnceAnimation() { }

	// RVA: 0x36BEA4
	public override object PlayablePlay(object fGlobalSpeed, object floatParams, object fOffsetTime) { }

	// RVA: 0x36C1BC
	public override object PlayableStop() { }

	// RVA: 0x36C264
	public override object ManualPlayablePause() { }

	// RVA: 0x358938
	public object Resume() { }

	// RVA: 0x36C400
	public override object UpdateFrame(object bInTransition) { }

	// RVA: 0x36C5E4
	public override object GetAnimClipPlayStatus() { }

	// RVA: 0x36C5EC
	public override object SetSpeed(object speedValue) { }

	// RVA: 0x36C650
	public override object ReplaceAnimation(object originClip, object newClip) { }

	// RVA: 0x36C98C
	public override object ReplaceAnimation(object stateName, object clip) { }

	// RVA: 0x35EBB4
	public object SetStateLayer(object stateName, object nodeName, object clip, object layerIdx, object weight, object mask, object additive) { }

	// RVA: 0x36CE58
	public override object Clear() { }

	// RVA: 0x356124
	public object get_ActiveStateName() { }

	// RVA: 0x35620C
	public object get_ActiveStateDuration() { }

	// RVA: 0x356300
	public object set_ActiveStateSpeed(object value) { }

	// RVA: 0x3564E4
	public object get_IsTransitioning() { }

	// RVA: 0x3565D4
	public object get_IsActiveBlendTree() { }

	// RVA: 0x356A04
	public object .ctor() { }

	// RVA: 0x357404
	public object ResetActiveState() { }

	// RVA: 0x35758C
	public object ContainState(object szState) { }

	// RVA: 0x3576AC
	public object GetStateAnimationTime(object szState) { }

	// RVA: 0x3579D8
	public object OnPlayableEnable(object szState) { }

	// RVA: 0x357CA8
	public object OnPlayableDisable() { }

	// RVA: 0x358078
	public object ClearAllAnimationWeight() { }

	// RVA: 0x358AF0
	public object UpdatePlayableBehaviour(object forceUpdate) { }

	// RVA: 0x358DDC
	public object AddClip(object szStateName, object animClip) { }

	// RVA: 0x359754
	public object AddBlendTree(object szStateName, object nodeList, object blendTreeParameter1, object blendTreeParameter2, object blendType, object layerMixable) { }

	// RVA: 0x35BF48
	public object RemoveState(object szStateName) { }

	// RVA: 0x35C3A0
	public object SetDefaultState(object szStateName) { }

	// RVA: 0x359BDC
	public object AddLayerMixer(object szStateName) { }

	// RVA: 0x3680DC
	public object AddGeneralState(object state) { }

	// RVA: 0x36DC6C
	public override object SetBoolParam(object szBool, object bValue) { }

	// RVA: 0x35A08C
	public object GetBoolParam(object szBool) { }

	// RVA: 0x36DD94
	public override object SetFloatParam(object szFloat, object fValue) { }

	// RVA: 0x35A3E0
	public object GetFloatParam(object szFloat) { }

	// RVA: 0x36DFD8
	public override object SetIntParam(object szInt, object nValue) { }

	// RVA: 0x35A538
	public object GetIntParam(object szInt) { }

	// RVA: 0x35A900
	public object SetTriggerParam(object szTrigger) { }

	// RVA: 0x36D260
	private object SendTransitionCmd() { }

	// RVA: 0x35AAC0
	public object RemoveClip(object animClip) { }

	// RVA: 0x35AEB0
	public object ChangeState(object stateName, object newClip, object newSpeed) { }

	// RVA: 0x35B354
	public object ChangeTransitionData(object inSrcStateName, object inTarStateName, object inPreTransitionInfo) { }

	// RVA: 0x35B7FC
	public object ChangeTransitionCondition(object inSrcStateName, object inTarStateName, object inConditions) { }

	// RVA: 0x35BE34
	public object RemoveClip(object szStateName) { }

	// RVA: 0x35C68C
	public object Play(object szStateName, object durationTime, object offsetTime) { }

	// RVA: 0x36C92C
	private object DisconnectGraph(object nIndex) { }

	// RVA: 0x36E24C
	private object PlayGraph() { }

	// RVA: 0x36E268
	private object StopGraph() { }

	// RVA: 0x36BDB4
	private object SetAnimationMixerWeight(object nIndex, object fValue) { }

	// RVA: 0x35C9C0
	public object DirectorSetParam(object setParamCmd) { }

	// RVA: 0x35CBB0
	public object SimulateTimeTransition(object szSimulateState, object fDistTime) { }

	// RVA: 0x36E2E0
	private object SimulateDefualtTransition(object szSimulateState, object fDistTime) { }

	// RVA: 0x35CE24
	public object SimulateStateTransition(object szSimulateState, object fDistTime) { }

	// RVA: 0x36E284
	private object ModifySimulateState(object szSimulateState, object szToState, object simulateState, object nextState) { }

	// RVA: 0x35D1E4
	public object OnPlayableDestroy(object playable) { }

	// RVA: 0x35D504
	public object GetDebugInfo() { }

	// RVA: 0x3566F8
	public object GetCurrentStateTime() { }

	// RVA: 0x36D140
	private object InitParams() { }

	// RVA: 0x36D0D4
	private object InitTransitionMixer() { }

	// RVA: 0x35DDC0
	public object ResetBoolParam(object szBoolName, object bValue) { }

	// RVA: 0x35E030
	public object ResetFloatParam(object szBoolName, object fValue) { }

	// RVA: 0x35E2AC
	public object ResetIntParam(object szBoolName, object nValue) { }

	// RVA: 0x35E50C
	public object ResetTriggerParam(object szTriggerName) { }

	// RVA: 0x35F240
	public object ResetGlobalSpeed() { }

	// RVA: 0x35F3B4
	public object ResetAllStateValue() { }

	// RVA: 0x36E100
	private object PushCommand(object cmd) { }

	// RVA: 0x36D478
	private object UpdateCommand() { }

	// RVA: 0x36D550
	private object UpdateAnimatorState() { }

	// RVA: 0x36D384
	public object ClearTransitionMix() { }

	// RVA: 0x36F134
	private object ClearTransitionWeight() { }

	// RVA: 0x36D898
	private object UpdateTransitionMix() { }

	// RVA: 0x36F268
	private object LerpTransitionStates(object lerpValue, object fromidx, object toIdx) { }

	// RVA: 0x36ECC0
	public object ExecPlayCommand(object cmd) { }

	// RVA: 0x36ECF0
	public object ExecTransitionChange(object cmd) { }

	// RVA: 0x36DAB0
	private object PlayProcess(object cmd) { }

	// RVA: 0x36F448
	private object PlayInstantImpl(object cmd, object nFromIndex, object state) { }

	// RVA: 0x36F5F4
	private object PlayDurationImpl(object cmd, object nFromIndex, object state) { }

	// RVA: 0x36FA78
	private object CheckAllowInteruption(object nNewAnyStatePriority, object fromState) { }

	// RVA: 0x36F3B0
	private object TransitionProcess(object cmd) { }

	// RVA: 0x36EDD4
	private object TransitionProcessImpl(object szToState, object fDurationTime, object fOffsetTime, object interruptionType, object nAnyStatePriority) { }

}

// Namespace: UnityAnimatorPlayable.M
public class StateMachineBehaviourExtend
{

	// Methods

	// RVA: 0x36FB30
	public virtual object ManualStateEnter(object currentState, object playableComp) { }

	// RVA: 0x36FB34
	public virtual object ManualStateExit(object currentState, object playableComp) { }

	// RVA: 0x36FB38
	public virtual object ManualStateUpdate(object currentState, object playableComp, object bLoop, object normalizedTime) { }

	// RVA: 0x36FB3C
	public virtual object CopySMB(object src) { }

	// RVA: 0x36FB40
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class State
{

	// Fields
	public object name; // 0x8
	public object value; // 0x10

	// Methods

	// RVA: 0x36FB48
	public object .ctor(object n, object b) { }

}

// Namespace: 
public enum eValue
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object True;
	public const object False;
}

// Namespace: UnityAnimatorPlayable.M
public class AnimatorStateBehaviour
{

	// Fields
	public object states; // 0x10
	public object states_end; // 0x18

	// Methods

	// RVA: 0x36FB84
	public object OnBeforeSerialize() { }

	// RVA: 0x36FB88
	public object OnAfterDeserialize() { }

	// RVA: 0x36FD90
	public override object CopySMB(object src) { }

	// RVA: 0x3701AC
	public override object OnStateEnter(object animator, object stateInfo, object layerIndex) { }

	// RVA: 0x370588
	public override object OnStateExit(object animator, object stateInfo, object layerIndex) { }

	// RVA: 0x370750
	public override object ManualStateEnter(object currentState, object playableComp) { }

	// RVA: 0x370758
	public override object ManualStateExit(object currentState, object playableComp) { }

	// RVA: 0x3701B4
	private object StateEnterImpl(object animator, object playableComp) { }

	// RVA: 0x370590
	private object StateExitImpl(object animator, object playableComp) { }

	// RVA: 0x370760
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public struct TransitionData
{

	// Fields
	public object transitionConditionArray; // 0xFFFFFFFFFFFFFFF8
	public object szToState; // 0x0
	public object fixedDuration; // 0x8
	public object durationTime; // 0xC
	public object offsetTime; // 0x10
	public object exitTime; // 0x14
	public object bHasExit; // 0x18
	public object eInterruptionSource; // 0x1C
	public object nAnyStatePriority; // 0x20
}

// Namespace: 
protected enum eActiveType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object OnEnter;
	public const object OnExit;
}

// Namespace: UnityAnimatorPlayable.M
public abstract class BaseAnimatorPlayableState
{

	// Fields
	protected object TransitionList; // 0x8
	protected object m_szStateName; // 0x10
	protected object m_defaultNextState; // 0x18
	protected object m_speedParameter; // 0x20
	protected object m_defaultNextTime; // 0x28
	protected object m_defaultNextDuration; // 0x2C
	protected object m_defaultNextOffsetTime; // 0x30
	protected object m_speedValue; // 0x34
	protected object m_initSpeedValue; // 0x38
	protected object m_bActive; // 0x3C
	protected object m_bHasRootMotion; // 0x3D
	protected object m_RootMotionHandle; // 0x40
	protected object m_eActiveChange; // 0x44
	protected object m_nActiveFrameNum; // 0x48
	protected object m_behavioursList; // 0x50
	public object playableComp; // 0x58
	protected object m_bExitTransitionFlag; // 0x60
	protected object m_fExitTransitionTime; // 0x64
	protected object m_szExitTransitionState; // 0x68
	protected object m_triggerPassList; // 0x70
	protected object m_Graph; // 0x78

	// Properties
	public object stateName { get; }
	public object defaultNext { get; }
	public object defaultNextDuration { get; }
	public object defaultNextOffsetTime { get; }
	public object speedParameter { get; }
	public object sourceSpeed { get; }
	public object NeedExitTransitionCheck { get; }
	public object ExitTransitionTime { get; }
	public object ExitTransitionState { get; }

	// Methods

	// RVA: 0x370834
	public object get_stateName() { }

	// RVA: 0x37083C
	public object get_defaultNext() { }

	// RVA: 0x370844
	public object get_defaultNextDuration() { }

	// RVA: 0x37084C
	public object get_defaultNextOffsetTime() { }

	// RVA: 0x370854
	public object get_speedParameter() { }

	// RVA: 0x37085C
	public object get_sourceSpeed() { }

	// RVA: 0x370864
	public object get_NeedExitTransitionCheck() { }

	// RVA: 0x37086C
	public object get_ExitTransitionTime() { }

	// RVA: 0x370874
	public object get_ExitTransitionState() { }

	// RVA: 0x37087C
	public object GetTransitionList() { }

	// RVA: 0x368C14
	public virtual object Init(object szStateName, object graph) { }

	// RVA: 0x365D54
	public object InitTransitionDataList(object preList) { }

	// RVA: 0x36E228
	public object SetDefaultNextData(object inTransitionData) { }

	// RVA: 0x3661D0
	public object InitSpeedParameter(object szParam, object fSpeed) { }

	// RVA: 0x36ECB4
	public object ResetSpeed() { }

	// RVA: 0x366228
	public object InitBehaviours(object playableComponent, object behaviours) { }

	// RVA: 0x36D2E8
	public object SetStateActive(object bActive) { }

	// RVA: 0x36D37C
	public object ClearActiveCallBack() { }

	// RVA: 0x36EC70
	public object SimulateBehaviourEnter() { }

	// RVA: 0x36EC6C
	public object SimulateBehaviourExit() { }

	// RVA: 0x36ED88
	public object TryExecBehaviourCallBack() { }

	// RVA: 0x370884
	protected object OnEnterActive() { }

	// RVA: 0x370974
	protected object OnExitActive() { }

	// RVA: 0x36E470
	public object CheckTransition(object boolParams, object floatParams, object intParams, object triggerParams, object fOutDuration, object fOutOffsetTime, object bOutInterruptionType, object nOutAnyStatePriority, object fSimulateTime) { }

	// RVA: 0x36EED8
	public object CheckOnlyExitTime() { }

	// RVA: 0x36E2D0
	public object SetExitTransitionFlag(object bValue, object fTime, object szState) { }

	// RVA: 0x370AF4
	protected virtual object IsPlayTimeEnd(object data, object fSimulateTime) { }

	// RVA: 0x370AFC
	public virtual object SimulatePlayEnd(object fTime) { }

	// RVA: 0x370B04
	public virtual object IsOnceAnimation() { }

	// RVA: 0x370B0C
	public virtual object IsBlendTree() { }

	// RVA: 0x36238C
	public virtual object UpdateFrame(object bInTransition) { }

	// RVA: 0x370B14
	public virtual object SetSpeed(object speedValue) { }

	// RVA: 0x370B18
	public virtual object ResetStateTime() { }

	// RVA: 0x370B1C
	public virtual object PlayablePlay(object fGlobalSpeed, object floatParams, object fOffsetTime) { }

	// RVA: 0x370B20
	public virtual object PlayableStop() { }

	// RVA: 0x370B24
	public virtual object ManualPlayablePause() { }

	// RVA: 0x370B28
	public virtual object GetDurationTime() { }

	// RVA: 0x370B30
	public virtual object GetCurrentStateTime() { }

	// RVA: 0x370B38
	public virtual object GetAnimClipPlayStatus() { }

	// RVA: 0x3626EC
	public virtual object Clear() { }

	// RVA: 0x370B80
	public virtual object GetPlayable() { }

	// RVA: 0x370BF0
	public virtual object SetFloatParam(object name, object value) { }

	// RVA: 0x370BF4
	public virtual object SetIntParam(object name, object value) { }

	// RVA: 0x370BF8
	public virtual object SetBoolParam(object name, object value) { }

	// RVA: -1
	public abstract object ReplaceAnimation(object originClip, object newClip) { }

	// RVA: -1
	public abstract object ReplaceAnimation(object stateName, object clip) { }

	// RVA: 0x35F6E0
	protected object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public struct SetParamCommand
{

	// Fields
	public object eType; // 0xFFFFFFFFFFFFFFF8
	public object szParam; // 0x0
	public object nFrameNum; // 0x8
	public object fSetTime; // 0xC
	public object bValue; // 0x10
	public object fValue; // 0x14
	public object nValue; // 0x18
}

// Namespace: UnityAnimatorPlayable.M
public class InvisibleOptimizeModule
{

	// Fields
	public const object MaxCmdQueueCount;
	public const object CmdQueueCapacity;
	public const object InsertCmdQueueCapacity;
	private object m_bindBehaviour; // 0x8
	private object m_cmdQueue; // 0x10
	private object m_curSimulateState; // 0x18
	private object m_curSimulateTime; // 0x20
	private object m_simulateInsertQueue; // 0x28
	private object m_bOnSimulateProcess; // 0x30

	// Methods

	// RVA: 0x370CEC
	public object SetBool(object szParam, object bValue) { }

	// RVA: 0x370DE4
	public object SetFloat(object szParam, object fValue) { }

	// RVA: 0x370E20
	public object SetInteger(object szParam, object nValue) { }

	// RVA: 0x370E5C
	public object SetTrigger(object szParam) { }

	// RVA: 0x370D20
	private object SetParamCmd(object cmd) { }

	// RVA: 0x370E94
	public object LateUpdate() { }

	// RVA: 0x3710D0
	public object OnPlayableBehaviourPause(object playableBehaviour) { }

	// RVA: 0x371114
	public object OnPlayableBehaviourReExec(object playableBehaviour) { }

	// RVA: 0x370F00
	private object SimulateParamTransition(object playableBehaviour) { }

	// RVA: 0x371230
	private object StepFrameSimulateState(object playableBehaviour, object nFrameStamp, object nNextFrame, object fTransitionTime, object fSetTime) { }

	// RVA: 0x3712D8
	private object UpdateDirectorSetParams(object playableBehaviour) { }

	// RVA: 0x3713E0
	public object Clear() { }

}

// Namespace: UnityAnimatorPlayable.M
public class LayerMixerBehaviour
{

	// Fields
	public object m_layerNodeList; // 0x10

	// Methods

	// RVA: 0x371460
	public object CopyNodeList(object dst) { }

	// RVA: 0x371724
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public enum ConditionParamType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Bool;
	public const object Float;
	public const object Int;
	public const object Trigger;
}

// Namespace: UnityAnimatorPlayable.M
public enum ConditionMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Bool;
	public const object Greater;
	public const object Less;
	public const object Equals;
	public const object NotEqual;
	public const object Trigger;
}

// Namespace: UnityAnimatorPlayable.M
public enum TransitionInterruptionSource
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Source;
	public const object Destination;
	public const object SourceThenDestination;
	public const object DestinationThenSource;
}

// Namespace: UnityAnimatorPlayable.M
public class PlayableControllerAsset
{

	// Fields
	public object PreLayerDatas; // 0x10
	public object PreAnimationStates; // 0x18
	public object PreBoolParams; // 0x20
	public object PreFloatParams; // 0x28
	public object PreIntParams; // 0x30
	public object PreTriggerParams; // 0x38
	public object EditorStateMachines; // 0x40
	public object EditorNodes; // 0x48

	// Methods

	// RVA: 0x37172C
	public object OnBeforeSerialize() { }

	// RVA: 0x371730
	public object OnAfterDeserialize() { }

	// RVA: 0x371734
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class BlendTreeNode
{

	// Fields
	public object nodeName; // 0x8
	public object animClip; // 0x10
	public object threshold; // 0x18
	public object m_blendPosition2D; // 0x1C
	public object speed; // 0x24
	private object m_portIndex; // 0x28
	private object m_curWeight; // 0x2C
	private object m_transitionFactor; // 0x30
	public object m_playState; // 0x38

	// Methods

	// RVA: 0x371914
	public object .ctor() { }

	// RVA: 0x371924
	public object SetCurWeight(object fValue) { }

	// RVA: 0x37192C
	public object GetCurWeight() { }

}

// Namespace: UnityAnimatorPlayable.M
public class PreTransitionInfo
{

	// Fields
	public object destinationState; // 0x8
	public object transitionConditionArray; // 0x10
	public object fixedDuration; // 0x18
	public object durationTime; // 0x1C
	public object offsetTime; // 0x20
	public object exitTime; // 0x24
	public object hasExitTime; // 0x28
	public object interruptionSource; // 0x2C
	public object anyStatePriority; // 0x30
}

// Namespace: UnityAnimatorPlayable.M
public class PreLayerData
{

	// Fields
	public object LayerIdx; // 0x8
	public object Additive; // 0xC
	public object Weight; // 0x10
	public object Mask; // 0x18

	// Methods

	// RVA: 0x371934
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class PreAnimationState
{

	// Fields
	public object StateName; // 0x8
	public object LayerIndex; // 0x10
	public object Clip; // 0x18
	public object TransitionInfoList; // 0x20
	public object SpeedParameter; // 0x28
	public object ModifySpeedActive; // 0x30
	public object ModifySpeed; // 0x34
	public object IsLayerMixNode; // 0x38
	public object BlendType; // 0x3C
	public object BlendTreeParameter1; // 0x40
	public object BlendTreeParameter2; // 0x48
	public object BlendTreeNodes; // 0x50
	public object m_arrBehaviours; // 0x58
	public object m_layerMixNodes; // 0x60

	// Methods

	// RVA: 0x37193C
	public object .ctor(object szName, object animClip) { }

	// RVA: 0x3719C8
	public object SetParams(object transitionInfoList, object szSpeedParameter, object speedParameterActive, object fSpeed) { }

	// RVA: 0x3719D8
	public object GetBehaviours() { }

	// RVA: 0x3719E0
	public object OnBeforeSerialize() { }

	// RVA: 0x3719E4
	public object OnAfterDeserialize() { }

	// RVA: 0x371B64
	public object AddPreTransition(object inSrcInfo) { }

}

// Namespace: UnityAnimatorPlayable.M
public class TransitionCondition
{

	// Fields
	public object eType; // 0x8
	public object szName; // 0x10
	public object bConditionValue; // 0x18
	public object fConditionValue; // 0x1C
	public object nConditionValue; // 0x20
	public object eMode; // 0x24

	// Methods

	// RVA: 0x371DD4
	public object .ctor() { }

	// RVA: 0x371DDC
	public object .ctor(object copySrc) { }

}

// Namespace: UnityAnimatorPlayable.M
public class EditorStateMachine
{

	// Fields
	public object name; // 0x8
	public object defaultStateName; // 0x10
	public object layerIndex; // 0x18
	public object index; // 0x1C
	public object position; // 0x20
	public object anyStatePosition; // 0x2C
	public object parentStateMachinePosition; // 0x38
	public object parentStateMachineIndex; // 0x44

	// Methods

	// RVA: 0x371E44
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public class EditorNode
{

	// Fields
	public object name; // 0x8
	public object stateMachineIndex; // 0x10
	public object position; // 0x14
	public object typeId; // 0x20

	// Methods

	// RVA: 0x371F24
	public object .ctor() { }

}

// Namespace: UnityAnimatorPlayable.M
public static class Utils
{

	// Methods

	// RVA: 0x371FC0
	public static object Warning(object str, object parameters) { }

	// RVA: 0x37206C
	public static object Error(object str, object parameters) { }

}

