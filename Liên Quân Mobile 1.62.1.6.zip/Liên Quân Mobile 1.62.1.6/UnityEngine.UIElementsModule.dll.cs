// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.Yoga
internal sealed class BaselineFunction
{

	// Methods

	// RVA: 0x74FBAE4
	public object .ctor(object object, object method) { }

	// RVA: 0x74FBBF0
	public virtual object Invoke(object node, object width, object height) { }

}

// Namespace: UnityEngine.Yoga
internal sealed class Logger
{

	// Methods

	// RVA: 0x74FBF90
	public object .ctor(object object, object method) { }

	// RVA: 0x74FC09C
	public virtual object Invoke(object config, object node, object level, object message) { }

}

// Namespace: UnityEngine.Yoga
internal sealed class MeasureFunction
{

	// Methods

	// RVA: 0x74FC494
	public object .ctor(object object, object method) { }

	// RVA: 0x74FC5A0
	public virtual object Invoke(object node, object width, object widthMode, object height, object heightMode) { }

}

// Namespace: UnityEngine.Yoga
internal class MeasureOutput
{

	// Methods

	// RVA: 0x74FC5B4
	public static object Make(object width, object height) { }

}

// Namespace: UnityEngine.Yoga
internal enum YogaAlign
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object FlexStart;
	public const object Center;
	public const object FlexEnd;
	public const object Stretch;
	public const object Baseline;
	public const object SpaceBetween;
	public const object SpaceAround;
}

// Namespace: UnityEngine.Yoga
internal class YogaConfig
{

	// Fields
	internal static readonly object Default; // 0x0
	private object _ygConfig; // 0x8
	private object _logger; // 0x10

	// Properties
	internal object Handle { get; }
	public object UseWebDefaults { get; set; }
	public object PointScaleFactor { set; }

	// Methods

	// RVA: 0x74FC5B8
	private object .ctor(object ygConfig) { }

	// RVA: 0x74FC640
	public object .ctor() { }

	// RVA: 0x74FC6DC
	protected override object Finalize() { }

	// RVA: 0x74FC834
	internal object get_Handle() { }

	// RVA: 0x74FC8A8
	public object get_UseWebDefaults() { }

	// RVA: 0x74FC948
	public object set_UseWebDefaults(object value) { }

	// RVA: 0x74FCA10
	public object set_PointScaleFactor(object value) { }

	// RVA: 0x74FCAD8
	private static object .cctor() { }

}

// Namespace: UnityEngine.Yoga
internal static class YogaConstants
{

	// Methods

	// RVA: 0x74FCBA4
	public static object IsUndefined(object value) { }

}

// Namespace: UnityEngine.Yoga
internal enum YogaDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Inherit;
	public const object LTR;
	public const object RTL;
}

// Namespace: UnityEngine.Yoga
internal enum YogaDisplay
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Flex;
	public const object None;
}

// Namespace: UnityEngine.Yoga
internal enum YogaEdge
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Top;
	public const object Right;
	public const object Bottom;
	public const object Start;
	public const object End;
	public const object Horizontal;
	public const object Vertical;
	public const object All;
}

// Namespace: UnityEngine.Yoga
internal enum YogaFlexDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Column;
	public const object ColumnReverse;
	public const object Row;
	public const object RowReverse;
}

// Namespace: UnityEngine.Yoga
internal enum YogaJustify
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FlexStart;
	public const object Center;
	public const object FlexEnd;
	public const object SpaceBetween;
	public const object SpaceAround;
}

// Namespace: UnityEngine.Yoga
internal enum YogaLogLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Error;
	public const object Warn;
	public const object Info;
	public const object Debug;
	public const object Verbose;
	public const object Fatal;
}

// Namespace: UnityEngine.Yoga
internal enum YogaMeasureMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undefined;
	public const object Exactly;
	public const object AtMost;
}

// Namespace: UnityEngine.Yoga
internal static class Native
{

	// Methods

	// RVA: 0x74FCBBC
	public static object YGNodeNewWithConfig(object config) { }

	// RVA: 0x74FCC0C
	public static object YGNodeFree(object ygNode) { }

	// RVA: 0x74FCC78
	private static object YGNodeFreeInternal(object ygNode) { }

	// RVA: 0x74FCCC8
	public static object YGSetManagedObject(object ygNode, object node) { }

	// RVA: 0x74FCD2C
	public static object YGNodeSetConfig(object ygNode, object config) { }

	// RVA: 0x74FCB64
	public static object YGConfigGetDefault() { }

	// RVA: 0x74FC69C
	public static object YGConfigNew() { }

	// RVA: 0x74FC83C
	public static object YGConfigFree(object config) { }

	// RVA: 0x74FCD90
	private static object YGConfigFreeInternal(object config) { }

	// RVA: 0x74FC9AC
	public static object YGConfigSetUseWebDefaults(object config, object useWebDefaults) { }

	// RVA: 0x74FC8F8
	public static object YGConfigGetUseWebDefaults(object config) { }

	// RVA: 0x74FCA74
	public static object YGConfigSetPointScaleFactor(object config, object pixelsInPoint) { }

	// RVA: 0x74FCDE0
	public static object YGNodeInsertChild(object node, object child, object index) { }

	// RVA: 0x74FCE4C
	public static object YGNodeRemoveChild(object node, object child) { }

	// RVA: 0x74FCEB0
	public static object YGNodeCalculateLayout(object node, object availableWidth, object availableHeight, object parentDirection) { }

	// RVA: 0x74FCF30
	public static object YGNodeMarkDirty(object node) { }

	// RVA: 0x74FCF80
	public static object YGNodeIsDirty(object node) { }

	// RVA: 0x74FCFD0
	public static object YGNodeCopyStyle(object dstNode, object srcNode) { }

	// RVA: 0x74FD034
	public static object YGNodeSetMeasureFunc(object node) { }

	// RVA: 0x74FD084
	public static object YGNodeRemoveMeasureFunc(object node) { }

	// RVA: 0x74FD0D4
	public static object YGNodeMeasureInvoke(object node, object width, object widthMode, object height, object heightMode, object returnValueAddress) { }

	// RVA: 0x74FD218
	public static object YGNodeBaselineInvoke(object node, object width, object height, object returnValueAddress) { }

	// RVA: 0x74FD33C
	public static object YGNodeSetHasNewLayout(object node, object hasNewLayout) { }

	// RVA: 0x74FD3A0
	public static object YGNodeGetHasNewLayout(object node) { }

	// RVA: 0x74FD3F0
	public static object YGNodeStyleGetDirection(object node) { }

	// RVA: 0x74FD440
	public static object YGNodeStyleSetFlexDirection(object node, object flexDirection) { }

	// RVA: 0x74FD4A4
	public static object YGNodeStyleSetJustifyContent(object node, object justifyContent) { }

	// RVA: 0x74FD508
	public static object YGNodeStyleSetAlignContent(object node, object alignContent) { }

	// RVA: 0x74FD56C
	public static object YGNodeStyleSetAlignItems(object node, object alignItems) { }

	// RVA: 0x74FD5D0
	public static object YGNodeStyleSetAlignSelf(object node, object alignSelf) { }

	// RVA: 0x74FD634
	public static object YGNodeStyleSetPositionType(object node, object positionType) { }

	// RVA: 0x74FD698
	public static object YGNodeStyleSetFlexWrap(object node, object flexWrap) { }

	// RVA: 0x74FD6FC
	public static object YGNodeStyleSetOverflow(object node, object flexWrap) { }

	// RVA: 0x74FD760
	public static object YGNodeStyleSetDisplay(object node, object display) { }

	// RVA: 0x74FD7C4
	public static object YGNodeStyleSetFlex(object node, object flex) { }

	// RVA: 0x74FD828
	public static object YGNodeStyleSetFlexGrow(object node, object flexGrow) { }

	// RVA: 0x74FD88C
	public static object YGNodeStyleSetFlexShrink(object node, object flexShrink) { }

	// RVA: 0x74FD8F0
	public static object YGNodeStyleSetFlexBasis(object node, object flexBasis) { }

	// RVA: 0x74FD954
	public static object YGNodeStyleSetFlexBasisPercent(object node, object flexBasis) { }

	// RVA: 0x74FD9B8
	public static object YGNodeStyleSetFlexBasisAuto(object node) { }

	// RVA: 0x74FDA08
	public static object YGNodeStyleSetWidth(object node, object width) { }

	// RVA: 0x74FDA6C
	public static object YGNodeStyleSetWidthPercent(object node, object width) { }

	// RVA: 0x74FDAD0
	public static object YGNodeStyleSetWidthAuto(object node) { }

	// RVA: 0x74FDB20
	public static object YGNodeStyleSetHeight(object node, object height) { }

	// RVA: 0x74FDB84
	public static object YGNodeStyleSetHeightPercent(object node, object height) { }

	// RVA: 0x74FDBE8
	public static object YGNodeStyleSetHeightAuto(object node) { }

	// RVA: 0x74FDC38
	public static object YGNodeStyleSetMinWidth(object node, object minWidth) { }

	// RVA: 0x74FDC9C
	public static object YGNodeStyleSetMinWidthPercent(object node, object minWidth) { }

	// RVA: 0x74FDD00
	public static object YGNodeStyleSetMinHeight(object node, object minHeight) { }

	// RVA: 0x74FDD64
	public static object YGNodeStyleSetMinHeightPercent(object node, object minHeight) { }

	// RVA: 0x74FDDC8
	public static object YGNodeStyleSetMaxWidth(object node, object maxWidth) { }

	// RVA: 0x74FDE2C
	public static object YGNodeStyleSetMaxWidthPercent(object node, object maxWidth) { }

	// RVA: 0x74FDE90
	public static object YGNodeStyleSetMaxHeight(object node, object maxHeight) { }

	// RVA: 0x74FDEF4
	public static object YGNodeStyleSetMaxHeightPercent(object node, object maxHeight) { }

	// RVA: 0x74FDF58
	public static object YGNodeStyleSetPosition(object node, object edge, object position) { }

	// RVA: 0x74FDFD0
	public static object YGNodeStyleSetPositionPercent(object node, object edge, object position) { }

	// RVA: 0x74FE048
	public static object YGNodeStyleSetMargin(object node, object edge, object margin) { }

	// RVA: 0x74FE0C0
	public static object YGNodeStyleSetMarginPercent(object node, object edge, object margin) { }

	// RVA: 0x74FE138
	public static object YGNodeStyleSetMarginAuto(object node, object edge) { }

	// RVA: 0x74FE19C
	public static object YGNodeStyleSetPadding(object node, object edge, object padding) { }

	// RVA: 0x74FE214
	public static object YGNodeStyleSetPaddingPercent(object node, object edge, object padding) { }

	// RVA: 0x74FE28C
	public static object YGNodeStyleSetBorder(object node, object edge, object border) { }

	// RVA: 0x74FE304
	public static object YGNodeLayoutGetLeft(object node) { }

	// RVA: 0x74FE354
	public static object YGNodeLayoutGetTop(object node) { }

	// RVA: 0x74FE3A4
	public static object YGNodeLayoutGetRight(object node) { }

	// RVA: 0x74FE3F4
	public static object YGNodeLayoutGetBottom(object node) { }

	// RVA: 0x74FE444
	public static object YGNodeLayoutGetWidth(object node) { }

	// RVA: 0x74FE494
	public static object YGNodeLayoutGetHeight(object node) { }

	// RVA: 0x74FE4E4
	public static object YGNodeLayoutGetMargin(object node, object edge) { }

	// RVA: 0x74FE548
	public static object YGNodeLayoutGetPadding(object node, object edge) { }

	// RVA: 0x74FE5AC
	public static object YGNodeLayoutGetBorder(object node, object edge) { }

}

// Namespace: UnityEngine.Yoga
internal class YogaNode
{

	// Fields
	internal object _ygNode; // 0x8
	private object _config; // 0x10
	private object _parent; // 0x18
	private object _children; // 0x20
	private object _measureFunction; // 0x28
	private object _baselineFunction; // 0x30
	private object _data; // 0x38

	// Properties
	internal object Config { set; }
	public object IsDirty { get; }
	public object HasNewLayout { get; }
	public object IsMeasureDefined { get; }
	public object IsBaselineDefined { get; }
	public object FlexDirection { set; }
	public object JustifyContent { set; }
	public object Display { set; }
	public object AlignItems { set; }
	public object AlignSelf { set; }
	public object AlignContent { set; }
	public object PositionType { set; }
	public object Wrap { set; }
	public object Flex { set; }
	public object FlexGrow { set; }
	public object FlexShrink { set; }
	public object FlexBasis { set; }
	public object Width { set; }
	public object Height { set; }
	public object MaxWidth { set; }
	public object MaxHeight { set; }
	public object MinWidth { set; }
	public object MinHeight { set; }
	public object LayoutX { get; }
	public object LayoutY { get; }
	public object LayoutRight { get; }
	public object LayoutBottom { get; }
	public object LayoutWidth { get; }
	public object LayoutHeight { get; }
	public object Overflow { set; }
	public object Count { get; }
	public object Left { set; }
	public object Top { set; }
	public object Right { set; }
	public object Bottom { set; }
	public object MarginLeft { set; }
	public object MarginTop { set; }
	public object MarginRight { set; }
	public object MarginBottom { set; }
	public object PaddingLeft { set; }
	public object PaddingTop { set; }
	public object PaddingRight { set; }
	public object PaddingBottom { set; }
	public object BorderLeftWidth { set; }
	public object BorderTopWidth { set; }
	public object BorderRightWidth { set; }
	public object BorderBottomWidth { set; }
	public object LayoutMarginLeft { get; }
	public object LayoutMarginTop { get; }
	public object LayoutMarginRight { get; }
	public object LayoutMarginBottom { get; }
	public object LayoutPaddingLeft { get; }
	public object LayoutPaddingTop { get; }
	public object LayoutPaddingRight { get; }
	public object LayoutPaddingBottom { get; }
	public object LayoutBorderLeft { get; }
	public object LayoutBorderTop { get; }
	public object LayoutBorderRight { get; }
	public object LayoutBorderBottom { get; }

	// Methods

	// RVA: 0x74FE610
	public object .ctor(object config) { }

	// RVA: 0x74FE75C
	protected override object Finalize() { }

	// RVA: 0x74FE828
	internal object set_Config(object value) { }

	// RVA: 0x74FE91C
	public object get_IsDirty() { }

	// RVA: 0x74FE96C
	public virtual object MarkDirty() { }

	// RVA: 0x74FE9BC
	public object get_HasNewLayout() { }

	// RVA: 0x74FEA0C
	public object get_IsMeasureDefined() { }

	// RVA: 0x74FEA1C
	public object get_IsBaselineDefined() { }

	// RVA: 0x74FEA2C
	public object CopyStyle(object srcNode) { }

	// RVA: 0x74FEAA4
	public object set_FlexDirection(object value) { }

	// RVA: 0x74FEB08
	public object set_JustifyContent(object value) { }

	// RVA: 0x74FEB6C
	public object set_Display(object value) { }

	// RVA: 0x74FEBD0
	public object set_AlignItems(object value) { }

	// RVA: 0x74FEC34
	public object set_AlignSelf(object value) { }

	// RVA: 0x74FEC98
	public object set_AlignContent(object value) { }

	// RVA: 0x74FECFC
	public object set_PositionType(object value) { }

	// RVA: 0x74FED60
	public object set_Wrap(object value) { }

	// RVA: 0x74FEDC4
	public object set_Flex(object value) { }

	// RVA: 0x74FEE28
	public object set_FlexGrow(object value) { }

	// RVA: 0x74FEE8C
	public object set_FlexShrink(object value) { }

	// RVA: 0x74FEEF0
	public object set_FlexBasis(object value) { }

	// RVA: 0x74FEFFC
	public object set_Width(object value) { }

	// RVA: 0x74FF0F8
	public object set_Height(object value) { }

	// RVA: 0x74FF1F4
	public object set_MaxWidth(object value) { }

	// RVA: 0x74FF288
	public object set_MaxHeight(object value) { }

	// RVA: 0x74FF31C
	public object set_MinWidth(object value) { }

	// RVA: 0x74FF3B0
	public object set_MinHeight(object value) { }

	// RVA: 0x74FF444
	public object get_LayoutX() { }

	// RVA: 0x74FF494
	public object get_LayoutY() { }

	// RVA: 0x74FF4E4
	public object get_LayoutRight() { }

	// RVA: 0x74FF534
	public object get_LayoutBottom() { }

	// RVA: 0x74FF584
	public object get_LayoutWidth() { }

	// RVA: 0x74FF5D4
	public object get_LayoutHeight() { }

	// RVA: 0x74FF624
	public object set_Overflow(object value) { }

	// RVA: 0x74FF688
	public object get_Count() { }

	// RVA: 0x74FF6E0
	public object MarkLayoutSeen() { }

	// RVA: 0x74FF738
	public object Insert(object index, object node) { }

	// RVA: 0x74FF870
	public object RemoveAt(object index) { }

	// RVA: 0x74FF978
	public object Clear() { }

	// RVA: 0x74FF9E8
	public object SetMeasureFunction(object measureFunction) { }

	// RVA: 0x74FFB04
	public object CalculateLayout(object width, object height) { }

	// RVA: 0x74FD19C
	public static object MeasureInternal(object node, object width, object widthMode, object height, object heightMode) { }

	// RVA: 0x74FD2C8
	public static object BaselineInternal(object node, object width, object height) { }

	// RVA: 0x74FFBB0
	public object GetEnumerator() { }

	// RVA: 0x74FFDA0
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x74FFF90
	public object set_Left(object value) { }

	// RVA: 0x75000B0
	public object set_Top(object value) { }

	// RVA: 0x7500130
	public object set_Right(object value) { }

	// RVA: 0x75001B0
	public object set_Bottom(object value) { }

	// RVA: 0x7500010
	private object SetStylePosition(object edge, object value) { }

	// RVA: 0x7500230
	public object set_MarginLeft(object value) { }

	// RVA: 0x7500404
	public object set_MarginTop(object value) { }

	// RVA: 0x75004E0
	public object set_MarginRight(object value) { }

	// RVA: 0x75005BC
	public object set_MarginBottom(object value) { }

	// RVA: 0x750030C
	private object SetStyleMargin(object edge, object value) { }

	// RVA: 0x7500698
	public object set_PaddingLeft(object value) { }

	// RVA: 0x75007B8
	public object set_PaddingTop(object value) { }

	// RVA: 0x7500838
	public object set_PaddingRight(object value) { }

	// RVA: 0x75008B8
	public object set_PaddingBottom(object value) { }

	// RVA: 0x7500718
	private object SetStylePadding(object edge, object value) { }

	// RVA: 0x7500938
	public object set_BorderLeftWidth(object value) { }

	// RVA: 0x75009A4
	public object set_BorderTopWidth(object value) { }

	// RVA: 0x7500A10
	public object set_BorderRightWidth(object value) { }

	// RVA: 0x7500A7C
	public object set_BorderBottomWidth(object value) { }

	// RVA: 0x7500AE8
	public object get_LayoutMarginLeft() { }

	// RVA: 0x7500B40
	public object get_LayoutMarginTop() { }

	// RVA: 0x7500B98
	public object get_LayoutMarginRight() { }

	// RVA: 0x7500BF0
	public object get_LayoutMarginBottom() { }

	// RVA: 0x7500C48
	public object get_LayoutPaddingLeft() { }

	// RVA: 0x7500CA0
	public object get_LayoutPaddingTop() { }

	// RVA: 0x7500CF8
	public object get_LayoutPaddingRight() { }

	// RVA: 0x7500D50
	public object get_LayoutPaddingBottom() { }

	// RVA: 0x7500DA8
	public object get_LayoutBorderLeft() { }

	// RVA: 0x7500E00
	public object get_LayoutBorderTop() { }

	// RVA: 0x7500E58
	public object get_LayoutBorderRight() { }

	// RVA: 0x7500EB0
	public object get_LayoutBorderBottom() { }

}

// Namespace: UnityEngine.Yoga
internal enum YogaOverflow
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Visible;
	public const object Hidden;
	public const object Scroll;
}

// Namespace: UnityEngine.Yoga
internal enum YogaPositionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Relative;
	public const object Absolute;
}

// Namespace: UnityEngine.Yoga
internal struct YogaSize
{

	// Fields
	public object width; // 0xFFFFFFFFFFFFFFF8
	public object height; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: UnityEngine.Yoga
internal enum YogaUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undefined;
	public const object Point;
	public const object Percent;
	public const object Auto;
}

// Namespace: UnityEngine.Yoga
internal struct YogaValue
{

	// Fields
	private object value; // 0xFFFFFFFFFFFFFFF8
	private object unit; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object Unit { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x74FEFEC
	public object get_Unit() { }

	// RVA: 0x74FEFF4
	public object get_Value() { }

	// RVA: 0x7500F18
	public static object Point(object value) { }

	// RVA: 0x7500F38
	public object Equals(object other) { }

	// RVA: 0x7501028
	public override object Equals(object obj) { }

	// RVA: 0x7501210
	public override object GetHashCode() { }

	// RVA: 0x75012A0
	public static object Auto() { }

	// RVA: 0x75012AC
	public static object Percent(object value) { }

	// RVA: 0x75012CC
	public static object op_Implicit(object pointValue) { }

}

// Namespace: UnityEngine.Yoga
internal enum YogaWrap
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoWrap;
	public const object Wrap;
	public const object WrapReverse;
}

// Namespace: UnityEngine.UIElements
internal static class AlignmentUtils
{

	// Methods

	// RVA: 0x75012EC
	internal static object RoundToPixelGrid(object v, object pixelsPerPoint, object offset) { }

	// RVA: 0x7501308
	internal static object CeilToPixelGrid(object v, object pixelsPerPoint, object offset) { }

}

// Namespace: UnityEngine.UIElements
internal abstract class AtlasBase
{

	// Fields
	internal object textureRegistry; // 0x8

	// Methods

	// RVA: 0x750131C
	public virtual object TryGetAtlas(object ctx, object src, object atlas, object atlasRect) { }

	// RVA: 0x7501394
	public virtual object ReturnAtlas(object ctx, object src, object atlas) { }

	// RVA: 0x7501398
	public virtual object Reset() { }

	// RVA: 0x750139C
	protected virtual object OnAssignedToPanel(object panel) { }

	// RVA: 0x75013A0
	protected virtual object OnRemovedFromPanel(object panel) { }

	// RVA: 0x75013A4
	protected virtual object OnUpdateDynamicTextures(object panel) { }

	// RVA: 0x75013A8
	internal object InvokeAssignedToPanel(object panel) { }

	// RVA: 0x75013F0
	internal object InvokeRemovedFromPanel(object panel) { }

	// RVA: 0x7501438
	internal object InvokeUpdateDynamicTextures(object panel) { }

	// RVA: 0x7501480
	protected static object RepaintTexturedElements(object panel) { }

	// RVA: 0x7501578
	protected object SetDynamicTexture(object id, object texture) { }

	// RVA: 0x75015A0
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public enum DynamicAtlasFilters
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Readability;
	public const object Size;
	public const object Format;
	public const object ColorSpace;
	public const object FilterMode;
}

// Namespace: UnityEngine.UIElements
public sealed class DynamicAtlasCustomFilter
{

	// Methods

	// RVA: 0x750171C
	public object .ctor(object object, object method) { }

	// RVA: 0x75017CC
	public virtual object Invoke(object texture, object filtersToApply) { }

}

// Namespace: 
private class TextureInfo
{

	// Fields
	public object page; // 0x10
	public object counter; // 0x18
	public object alloc; // 0x20
	public object rect; // 0x50
	public static readonly object pool; // 0x0

	// Methods

	// RVA: 0x7502848
	private static object Create() { }

	// RVA: 0x750292C
	private static object Reset(object info) { }

	// RVA: 0x75028D4
	public object .ctor() { }

	// RVA: 0x750295C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class DynamicAtlas
{

	// Fields
	private object m_Database; // 0x10
	private object m_PointPage; // 0x18
	private object m_BilinearPage; // 0x20
	private object m_ColorSpace; // 0x28
	private object m_Panels; // 0x30
	private object m_MinAtlasSize; // 0x38
	private object m_MaxAtlasSize; // 0x3C
	private object m_MaxSubTextureSize; // 0x40
	private object m_ActiveFilters; // 0x44
	private object m_CustomFilter; // 0x48

	// Properties
	internal object isInitialized { get; }
	public object minAtlasSize { set; }
	public object maxAtlasSize { set; }
	public static object defaultFilters { get; }
	public object activeFilters { set; }
	public object maxSubTextureSize { get; set; }
	public object customFilter { set; }

	// Methods

	// RVA: 0x75017E0
	internal object get_isInitialized() { }

	// RVA: 0x7501800
	protected override object OnAssignedToPanel(object panel) { }

	// RVA: 0x7501944
	protected override object OnRemovedFromPanel(object panel) { }

	// RVA: 0x7501A9C
	public override object Reset() { }

	// RVA: 0x7501B60
	private object InitPages() { }

	// RVA: 0x7501A00
	private object DestroyPages() { }

	// RVA: 0x7501C64
	public override object TryGetAtlas(object ve, object src, object atlas, object atlasRect) { }

	// RVA: 0x750209C
	public override object ReturnAtlas(object ve, object src, object atlas) { }

	// RVA: 0x750222C
	protected override object OnUpdateDynamicTextures(object panel) { }

	// RVA: 0x75022D4
	internal static object IsTextureFormatSupported(object format) { }

	// RVA: 0x7502308
	public virtual object IsTextureValid(object texture, object atlasFilterMode) { }

	// RVA: 0x7502518
	public object set_minAtlasSize(object value) { }

	// RVA: 0x750256C
	public object set_maxAtlasSize(object value) { }

	// RVA: 0x75025C0
	public static object get_defaultFilters() { }

	// RVA: 0x75025C8
	public object set_activeFilters(object value) { }

	// RVA: 0x7502510
	public object get_maxSubTextureSize() { }

	// RVA: 0x750261C
	public object set_maxSubTextureSize(object value) { }

	// RVA: 0x7502670
	public object set_customFilter(object value) { }

	// RVA: 0x75026D0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public struct BackgroundPosition
{

	// Fields
	public object keyword; // 0xFFFFFFFFFFFFFFF8
	public object offset; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x7502A90
	public object .ctor(object keyword) { }

	// RVA: 0x7502B18
	public object .ctor(object keyword, object offset) { }

	// RVA: 0x7502B30
	internal static object Initial() { }

	// RVA: 0x7502BB0
	public override object Equals(object obj) { }

	// RVA: 0x7502C98
	public object Equals(object other) { }

	// RVA: 0x7502E20
	public override object GetHashCode() { }

	// RVA: 0x7502EBC
	public static object op_Equality(object style1, object style2) { }

	// RVA: 0x7502F0C
	public static object op_Inequality(object style1, object style2) { }

	// RVA: 0x7502F60
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
internal static class BackgroundPropertyHelper
{

	// Methods

	// RVA: 0x7502B70
	public static object ConvertScaleModeToBackgroundPosition(object scaleMode) { }

	// RVA: 0x750302C
	public static object ConvertScaleModeToBackgroundRepeat(object scaleMode) { }

	// RVA: 0x750303C
	public static object ConvertScaleModeToBackgroundSize(object scaleMode) { }

	// RVA: 0x750318C
	public static object ResolveUnityBackgroundScaleMode(object backgroundPositionX, object backgroundPositionY, object backgroundRepeat, object backgroundSize, object valid) { }

}

// Namespace: UnityEngine.UIElements
public struct BackgroundRepeat
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x7503034
	public object .ctor(object repeatX, object repeatY) { }

	// RVA: 0x75035F4
	internal static object Initial() { }

	// RVA: 0x75035FC
	public override object Equals(object obj) { }

	// RVA: 0x75036B0
	public object Equals(object other) { }

	// RVA: 0x75037B4
	public override object GetHashCode() { }

	// RVA: 0x7503580
	public static object op_Equality(object style1, object style2) { }

	// RVA: 0x7503850
	public static object op_Inequality(object style1, object style2) { }

	// RVA: 0x750385C
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct BackgroundSize
{

	// Fields
	private object m_SizeType; // 0xFFFFFFFFFFFFFFF8
	private object m_X; // 0xFFFFFFFFFFFFFFFC
	private object m_Y; // 0x4

	// Properties
	public object sizeType { get; set; }
	public object x { get; set; }
	public object y { get; set; }

	// Methods

	// RVA: 0x75039AC
	public object get_sizeType() { }

	// RVA: 0x75039BC
	public object set_sizeType(object value) { }

	// RVA: 0x7503A7C
	public object get_x() { }

	// RVA: 0x7503A8C
	public object set_x(object value) { }

	// RVA: 0x7503AA4
	public object get_y() { }

	// RVA: 0x7503AB4
	public object set_y(object value) { }

	// RVA: 0x750317C
	public object .ctor(object sizeX, object sizeY) { }

	// RVA: 0x750311C
	public object .ctor(object sizeType) { }

	// RVA: 0x7503B3C
	internal static object Initial() { }

	// RVA: 0x7503B90
	public override object Equals(object obj) { }

	// RVA: 0x7503C78
	public object Equals(object other) { }

	// RVA: 0x7503D38
	public override object GetHashCode() { }

	// RVA: 0x750358C
	public static object op_Equality(object style1, object style2) { }

	// RVA: 0x7503E0C
	public static object op_Inequality(object style1, object style2) { }

	// RVA: 0x7503E84
	public override object ToString() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7504004
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_PropertyPath; // 0x68

	// Methods

	// RVA: 0x750405C
	public object .ctor() { }

	// RVA: 0x75040F8
	public override object Init(object ve, object bag, object cc) { }

}

// Namespace: UnityEngine.UIElements
public class BindableElement
{

	// Fields
	private object <binding>k__BackingField; // 0x3C0
	private object <bindingPath>k__BackingField; // 0x3C8

	// Properties
	public object binding { get; }
	public object bindingPath { set; }

	// Methods

	// RVA: 0x7503F6C
	public object get_binding() { }

	// RVA: 0x7503F74
	public object set_bindingPath(object value) { }

	// RVA: 0x7503F7C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal interface IBindingRequest
{

	// Methods

	// RVA: -1
	public abstract object Bind(object element) { }

}

// Namespace: UnityEngine.UIElements
internal class VisualTreeBindingsUpdater
{

	// Fields
	private static readonly object s_BindingRequestObjectVEPropertyName; // 0x0
	private static readonly object s_AdditionalBindingObjectVEPropertyName; // 0x4
	private static readonly object s_Description; // 0x8
	private static readonly object s_ProfilerMarker; // 0x10
	private static readonly object s_ProfilerBindingRequestsMarker; // 0x18
	private static object s_MarkerUpdate; // 0x20
	private static object s_MarkerPoll; // 0x28
	private static object <disableBindingsThrottling>k__BackingField; // 0x30
	private readonly object m_ElementsWithBindings; // 0x30
	private readonly object m_ElementsToAdd; // 0x38
	private readonly object m_ElementsToRemove; // 0x40
	private object m_LastUpdateTime; // 0x48
	private object m_ElementsToBind; // 0x50
	private object <temporaryObjectCache>k__BackingField; // 0x58
	private object updatedBindings; // 0x60

	// Properties
	public override object profilerMarker { get; }
	public object temporaryObjectCache { get; }

	// Methods

	// RVA: 0x7504270
	public override object get_profilerMarker() { }

	// RVA: 0x75042EC
	private object GetBindingObjectFromElement(object ve) { }

	// RVA: 0x7504540
	private object StartTracking(object ve) { }

	// RVA: 0x75045E0
	private object StopTracking(object ve) { }

	// RVA: 0x7504680
	public object get_temporaryObjectCache() { }

	// RVA: 0x7504494
	public static object GetAdditionalBinding(object ve) { }

	// RVA: 0x7504688
	private object StartTrackingRecursive(object ve) { }

	// RVA: 0x7504824
	private object StopTrackingRecursive(object ve) { }

	// RVA: 0x75049C8
	public override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x7504B88
	protected override object OnHierarchyChange(object ve, object type) { }

	// RVA: 0x7504BA0
	private static object CurrentTime() { }

	// RVA: 0x7504C10
	public object PerformTrackingOperations() { }

	// RVA: 0x7504F0C
	public override object Update() { }

	// RVA: 0x750563C
	private object UpdateBindings() { }

	// RVA: 0x7505D90
	public object .ctor() { }

	// RVA: 0x7505EE8
	private static object .cctor() { }

}

// Namespace: 
public enum DragDirection
{

	// Fields
	public object value__; // 0x0
	public const object None;
	public const object LowToHigh;
	public const object HighToLow;
	public const object Free;
}

// Namespace: UnityEngine.UIElements
internal class ClampedDragger<T0>
{

	// Fields
	private object dragging; // 0x0
	private object <dragDirection>k__BackingField; // 0x0
	private object <slider>k__BackingField; // 0x0
	private object <startMousePosition>k__BackingField; // 0x0

	// Properties
	public object dragDirection { get; set; }
	private object slider { set; }
	public object startMousePosition { get; set; }
	public object delta { get; }

	// Methods

	// RVA: -1
	public object add_dragging(object value) { }

	// RVA: -1
	public object remove_dragging(object value) { }

	// RVA: -1
	public object get_dragDirection() { }

	// RVA: -1
	public object set_dragDirection(object value) { }

	// RVA: -1
	private object set_slider(object value) { }

	// RVA: -1
	public object get_startMousePosition() { }

	// RVA: -1
	private object set_startMousePosition(object value) { }

	// RVA: -1
	public object get_delta() { }

	// RVA: -1
	public object .ctor(object slider, object clickHandler, object dragHandler) { }

	// RVA: -1
	protected override object ProcessDownEvent(object evt, object localPosition, object pointerId) { }

	// RVA: -1
	protected override object ProcessMoveEvent(object evt, object localPosition) { }

}

// Namespace: UnityEngine.UIElements
public class Clickable
{

	// Fields
	private object clickedWithEventInfo; // 0x28
	private object clicked; // 0x30
	private readonly object m_Delay; // 0x38
	private readonly object m_Interval; // 0x40
	private object <active>k__BackingField; // 0x48
	private object <lastMousePosition>k__BackingField; // 0x4C
	private object m_ActivePointerId; // 0x54
	private object m_AcceptClicksIfDisabled; // 0x58
	private object m_Repeater; // 0x60

	// Properties
	protected object active { get; set; }
	public object lastMousePosition { get; set; }
	internal object acceptClicksIfDisabled { get; set; }
	private object invokePolicy { get; }

	// Methods

	// RVA: 0x7506080
	public object add_clickedWithEventInfo(object value) { }

	// RVA: 0x7506134
	public object remove_clickedWithEventInfo(object value) { }

	// RVA: 0x75061E8
	protected object get_active() { }

	// RVA: 0x75061F0
	protected object set_active(object value) { }

	// RVA: 0x75061F8
	public object get_lastMousePosition() { }

	// RVA: 0x7506200
	private object set_lastMousePosition(object value) { }

	// RVA: 0x7506208
	internal object get_acceptClicksIfDisabled() { }

	// RVA: 0x7506210
	internal object set_acceptClicksIfDisabled(object value) { }

	// RVA: 0x7506288
	private object get_invokePolicy() { }

	// RVA: 0x7506290
	public object .ctor(object handler, object delay, object interval) { }

	// RVA: 0x7506404
	public object .ctor(object handler) { }

	// RVA: 0x75062C8
	public object .ctor(object handler) { }

	// RVA: 0x7506548
	private object OnTimer(object timerState) { }

	// RVA: 0x7506684
	private object IsRepeatable() { }

	// RVA: 0x75067A8
	protected override object RegisterCallbacksOnTarget() { }

	// RVA: 0x7506CF4
	protected override object UnregisterCallbacksFromTarget() { }

	// RVA: 0x750721C
	protected object OnMouseDown(object evt) { }

	// RVA: 0x7507308
	protected object OnMouseMove(object evt) { }

	// RVA: 0x75073B8
	protected object OnMouseUp(object evt) { }

	// RVA: 0x75074B0
	private object OnMouseCaptureOut(object evt) { }

	// RVA: 0x7507560
	private object OnPointerDown(object evt) { }

	// RVA: 0x75076F4
	private object OnPointerMove(object evt) { }

	// RVA: 0x7507878
	private object OnPointerUp(object evt) { }

	// RVA: 0x7507A18
	private object OnPointerCancel(object evt) { }

	// RVA: 0x7507BB4
	private object OnPointerCaptureOut(object evt) { }

	// RVA: 0x75066A8
	private object ContainsPointer(object pointerId) { }

	// RVA: 0x7507B44
	private static object IsNotMouseEvent(object pointerId) { }

	// RVA: 0x750674C
	protected object Invoke(object evt) { }

	// RVA: 0x7507CCC
	internal object SimulateSingleClick(object evt, object delayMs) { }

	// RVA: 0x7507F70
	protected virtual object ProcessDownEvent(object evt, object localPosition, object pointerId) { }

	// RVA: 0x7508430
	protected virtual object ProcessMoveEvent(object evt, object localPosition) { }

	// RVA: 0x75084E4
	protected virtual object ProcessUpEvent(object evt, object localPosition, object pointerId) { }

	// RVA: 0x7508718
	protected virtual object ProcessCancelEvent(object evt, object pointerId) { }

	// RVA: 0x75088D0
	private object <SimulateSingleClick>b__43_0() { }

}

// Namespace: 
private class ButtonClickStatus
{

	// Fields
	public object m_Target; // 0x8
	public object m_PointerDownPosition; // 0x10
	public object m_LastPointerDownTime; // 0x20
	public object m_ClickCount; // 0x28

	// Methods

	// RVA: 0x7509058
	public object Reset() { }

	// RVA: 0x7508D18
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class ClickDetector
{

	// Fields
	private object m_ClickStatus; // 0x8
	private static object <s_DoubleClickTime>k__BackingField; // 0x0

	// Properties
	internal static object s_DoubleClickTime { get; set; }

	// Methods

	// RVA: 0x7508918
	internal static object get_s_DoubleClickTime() { }

	// RVA: 0x7508994
	internal static object set_s_DoubleClickTime(object value) { }

	// RVA: 0x7508A20
	public object .ctor() { }

	// RVA: 0x7508D20
	private object StartClickTracking(object evt) { }

	// RVA: 0x75090C8
	private object SendClickEvent(object evt) { }

	// RVA: 0x75096C8
	private object CancelClickTracking(object evt) { }

	// RVA: 0x7509840
	public object ProcessEvent(object evt) { }

	// RVA: 0x7509544
	private static object ContainsPointer(object element, object position) { }

	// RVA: 0x7509F4C
	internal object Cleanup(object ve) { }

	// RVA: 0x750A140
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseListViewController
{

	// Fields
	private object itemsSourceSizeChanged; // 0x28
	private object itemsAdded; // 0x30
	private object itemsRemoved; // 0x38

	// Properties
	protected object baseListView { get; }

	// Methods

	// RVA: 0x750A190
	public object add_itemsSourceSizeChanged(object value) { }

	// RVA: 0x750A234
	public object remove_itemsSourceSizeChanged(object value) { }

	// RVA: 0x750A2D8
	public object add_itemsAdded(object value) { }

	// RVA: 0x750A38C
	public object remove_itemsAdded(object value) { }

	// RVA: 0x750A440
	public object add_itemsRemoved(object value) { }

	// RVA: 0x750A4F4
	public object remove_itemsRemoved(object value) { }

	// RVA: 0x750A5A8
	protected object get_baseListView() { }

	// RVA: 0x750A630
	internal override object InvokeMakeItem(object reusableItem) { }

	// RVA: 0x750A8BC
	internal object PostInitRegistration(object listItem) { }

	// RVA: 0x750AE88
	internal override object InvokeBindItem(object reusableItem, object index) { }

	// RVA: 0x750B344
	public virtual object NeedsDragHandle(object index) { }

	// RVA: 0x750B404
	public virtual object AddItems(object itemCount) { }

	// RVA: 0x750C1D4
	public virtual object Move(object index, object newIndex) { }

	// RVA: 0x750C724
	public virtual object RemoveItem(object index) { }

	// RVA: 0x750C984
	public virtual object RemoveItems(object indices) { }

	// RVA: 0x750CF70
	internal virtual object RemoveItems(object itemCount) { }

	// RVA: 0x750D210
	public virtual object ClearItems() { }

	// RVA: 0x750C1B8
	protected object RaiseOnSizeChanged() { }

	// RVA: 0x750C19C
	protected object RaiseItemsAdded(object indices) { }

	// RVA: 0x750CCCC
	protected object RaiseItemsRemoved(object indices) { }

	// RVA: 0x750C03C
	private static object AddToArray(object source, object itemCount) { }

	// RVA: 0x750CCE8
	private static object RemoveFromArray(object source, object indicesToRemove) { }

	// RVA: 0x750C3B4
	private object Swap(object lhs, object rhs) { }

	// RVA: 0x750BE64
	private object EnsureItemSourceCanBeResized() { }

	// RVA: 0x750D46C
	protected object .ctor() { }

	// RVA: 0x750D47C
	internal static object <AddItems>g__IsGenericList|15_0(object t) { }

}

// Namespace: 
private sealed class <>c__DisplayClass20_0
{

	// Fields
	public object <>4__this; // 0x8
	public object treeItem; // 0x10

	// Methods

	// RVA: 0x750EB14
	public object .ctor() { }

	// RVA: 0x7512A30
	internal object <PostInitRegistration>b__0() { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseTreeViewController
{

	// Fields
	private object m_TreeItems; // 0x28
	private object m_RootIndices; // 0x30
	private object m_ItemWrappers; // 0x38
	private object m_TreeItemIdsWithItemWrappers; // 0x40
	private object m_WrapperInsertionList; // 0x48
	private static readonly object K_ExpandItemByIndex; // 0x0
	private static readonly object k_CreateWrappers; // 0x8

	// Properties
	protected object baseTreeView { get; }
	public override object itemsSource { get; set; }

	// Methods

	// RVA: 0x750D574
	protected object get_baseTreeView() { }

	// RVA: 0x750D5FC
	public override object get_itemsSource() { }

	// RVA: 0x750D604
	public override object set_itemsSource(object value) { }

	// RVA: 0x750D658
	public object RebuildTree() { }

	// RVA: 0x750DCA4
	public object GetRootItemIds() { }

	// RVA: -1
	public abstract object GetAllItemIds(object rootIds) { }

	// RVA: -1
	public abstract object GetParentId(object id) { }

	// RVA: -1
	public abstract object GetChildrenIds(object id) { }

	// RVA: -1
	public abstract object Move(object id, object newParentId, object childIndex, object rebuildTree) { }

	// RVA: 0x750DCAC
	internal override object InvokeMakeItem(object reusableItem) { }

	// RVA: 0x750E1E0
	internal override object InvokeBindItem(object reusableItem, object index) { }

	// RVA: 0x750E708
	internal override object InvokeDestroyItem(object reusableItem) { }

	// RVA: 0x750DD98
	internal object PostInitRegistration(object treeItem) { }

	// RVA: 0x750EC84
	private object OnItemPointerUp(object evt) { }

	// RVA: 0x750F700
	private object OnToggleValueChanged(object evt) { }

	// RVA: 0x751118C
	public override object GetIndexForId(object id) { }

	// RVA: 0x751129C
	public override object GetIdForIndex(object index) { }

	// RVA: 0x7511410
	public virtual object HasChildren(object id) { }

	// RVA: 0x75114A0
	internal object Exists(object id) { }

	// RVA: 0x750E600
	public object HasChildrenByIndex(object index) { }

	// RVA: 0x750F60C
	public object GetChildrenIdsByIndex(object index) { }

	// RVA: 0x751150C
	public object GetChildIndexForId(object id) { }

	// RVA: 0x7511908
	internal object GetIndentationDepth(object id) { }

	// RVA: 0x750E3B8
	internal object GetIndentationDepthByIndex(object index) { }

	// RVA: 0x75119B8
	internal virtual object CanChangeExpandedState(object id) { }

	// RVA: 0x75119C0
	public object IsExpanded(object id) { }

	// RVA: 0x750E4A8
	public object IsExpandedByIndex(object index) { }

	// RVA: 0x75100EC
	public object ExpandItemByIndex(object index, object expandAllChildren, object refresh) { }

	// RVA: 0x75121A0
	public object ExpandItem(object id, object expandAllChildren, object refresh) { }

	// RVA: 0x750F92C
	public object CollapseItemByIndex(object index, object collapseAllChildren) { }

	// RVA: 0x7512558
	public object CollapseItem(object id, object collapseAllChildren) { }

	// RVA: 0x750DBDC
	internal object RegenerateWrappers() { }

	// RVA: 0x7511AAC
	private object CreateWrappers(object treeViewItemIds, object depth, object wrappers) { }

	// RVA: 0x7511390
	private object IsIndexValid(object index) { }

	// RVA: 0x75127D4
	internal object RaiseItemParentChanged(object id, object newParentId) { }

	// RVA: 0x75127F0
	protected object .ctor() { }

	// RVA: 0x7512960
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class CollectionViewController
{

	// Fields
	private object m_View; // 0x8
	private object m_ItemsSource; // 0x10
	private object itemsSourceChanged; // 0x18
	private object itemIndexChanged; // 0x20

	// Properties
	public virtual object itemsSource { get; set; }
	protected object view { get; }

	// Methods

	// RVA: 0x7512A74
	public object add_itemsSourceChanged(object value) { }

	// RVA: 0x7512B18
	public object remove_itemsSourceChanged(object value) { }

	// RVA: 0x7512BBC
	public object add_itemIndexChanged(object value) { }

	// RVA: 0x7512C70
	public object remove_itemIndexChanged(object value) { }

	// RVA: 0x7512D24
	public virtual object get_itemsSource() { }

	// RVA: 0x7512D2C
	public virtual object set_itemsSource(object value) { }

	// RVA: 0x75127CC
	protected object SetItemsSourceWithoutNotify(object source) { }

	// RVA: 0x7512EA4
	protected object get_view() { }

	// RVA: 0x7512EAC
	public object SetView(object collectionView) { }

	// RVA: 0x7512F6C
	protected virtual object PrepareView() { }

	// RVA: 0x7512F70
	public virtual object Dispose() { }

	// RVA: 0x7512F7C
	public virtual object GetItemsCount() { }

	// RVA: 0x7513068
	internal virtual object GetItemsMinCount() { }

	// RVA: 0x75130A8
	public virtual object GetIndexForId(object id) { }

	// RVA: 0x75130B0
	public virtual object GetIdForIndex(object index) { }

	// RVA: 0x75130B8
	public virtual object GetItemForIndex(object index) { }

	// RVA: 0x7513258
	internal virtual object InvokeMakeItem(object reusableItem) { }

	// RVA: 0x750B210
	internal virtual object InvokeBindItem(object reusableItem, object index) { }

	// RVA: 0x75132DC
	internal virtual object InvokeUnbindItem(object reusableItem, object index) { }

	// RVA: 0x750EAB8
	internal virtual object InvokeDestroyItem(object reusableItem) { }

	// RVA: -1
	protected abstract object MakeItem() { }

	// RVA: -1
	protected abstract object BindItem(object element, object index) { }

	// RVA: -1
	protected abstract object UnbindItem(object element, object index) { }

	// RVA: -1
	protected abstract object DestroyItem(object element) { }

	// RVA: 0x7512E88
	protected object RaiseItemsSourceChanged() { }

	// RVA: 0x750C708
	protected object RaiseItemIndexChanged(object srcIndex, object dstIndex) { }

	// RVA: 0x750D474
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class DefaultMultiColumnTreeViewController<T0>
{

	// Fields
	private object m_TreeDataController; // 0x0

	// Properties
	private object treeDataController { get; }
	public override object itemsSource { get; set; }

	// Methods

	// RVA: -1
	private object get_treeDataController() { }

	// RVA: -1
	public object .ctor(object columns, object sortDescriptions, object sortedColumns) { }

	// RVA: -1
	public override object get_itemsSource() { }

	// RVA: -1
	public override object set_itemsSource(object value) { }

	// RVA: -1
	public object SetRootItems(object items) { }

	// RVA: -1
	public override object GetItemForIndex(object index) { }

	// RVA: -1
	public override object GetParentId(object id) { }

	// RVA: -1
	public override object HasChildren(object id) { }

	// RVA: -1
	public override object GetChildrenIds(object id) { }

	// RVA: -1
	public override object Move(object id, object newParentId, object childIndex, object rebuildTree) { }

	// RVA: -1
	private object IsChildOf(object childId, object id) { }

	// RVA: -1
	public override object GetAllItemIds(object rootIds) { }

}

// Namespace: UnityEngine.UIElements
internal class DefaultTreeViewController<T0>
{

	// Fields
	private object m_TreeDataController; // 0x0

	// Properties
	private object treeDataController { get; }
	public override object itemsSource { get; set; }

	// Methods

	// RVA: -1
	private object get_treeDataController() { }

	// RVA: -1
	public override object get_itemsSource() { }

	// RVA: -1
	public override object set_itemsSource(object value) { }

	// RVA: -1
	public object SetRootItems(object items) { }

	// RVA: -1
	public override object GetItemForIndex(object index) { }

	// RVA: -1
	public override object GetParentId(object id) { }

	// RVA: -1
	public override object HasChildren(object id) { }

	// RVA: -1
	public override object GetChildrenIds(object id) { }

	// RVA: -1
	public override object Move(object id, object newParentId, object childIndex, object rebuildTree) { }

	// RVA: -1
	private object IsChildOf(object childId, object id) { }

	// RVA: -1
	public override object GetAllItemIds(object rootIds) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class ListViewController
{

	// Properties
	protected object listView { get; }

	// Methods

	// RVA: 0x7513348
	protected object get_listView() { }

	// RVA: 0x75133D0
	protected override object MakeItem() { }

	// RVA: 0x751351C
	protected override object BindItem(object element, object index) { }

	// RVA: 0x75137F0
	protected override object UnbindItem(object element, object index) { }

	// RVA: 0x75138B0
	protected override object DestroyItem(object element) { }

	// RVA: 0x7513968
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class MultiColumnListViewController
{

	// Fields
	private object m_ColumnController; // 0x40

	// Properties
	public object columnController { get; }
	internal object header { get; }

	// Methods

	// RVA: 0x7513970
	public object get_columnController() { }

	// RVA: 0x7513978
	internal object get_header() { }

	// RVA: 0x7513990
	public object .ctor(object columns, object sortDescriptions, object sortedColumns) { }

	// RVA: 0x7513A20
	internal override object InvokeMakeItem(object reusableItem) { }

	// RVA: 0x7514020
	protected override object MakeItem() { }

	// RVA: 0x7514044
	protected override object BindItem(object element, object index) { }

	// RVA: 0x75140EC
	protected override object UnbindItem(object element, object index) { }

	// RVA: 0x7514110
	protected override object DestroyItem(object element) { }

	// RVA: 0x7514134
	protected override object PrepareView() { }

	// RVA: 0x7514364
	public override object Dispose() { }

	// RVA: 0x75145C4
	private object UpdateReorderClassList() { }

}

// Namespace: UnityEngine.UIElements
public abstract class MultiColumnTreeViewController
{

	// Fields
	private object m_ColumnController; // 0x50

	// Properties
	public object columnController { get; }
	internal object header { get; }

	// Methods

	// RVA: 0x751476C
	public object get_columnController() { }

	// RVA: 0x7514774
	internal object get_header() { }

	// RVA: 0x751478C
	protected object .ctor(object columns, object sortDescriptions, object sortedColumns) { }

	// RVA: 0x751483C
	internal override object InvokeMakeItem(object reusableItem) { }

	// RVA: 0x7514DC4
	protected override object MakeItem() { }

	// RVA: 0x7514DE8
	protected override object BindItem(object element, object index) { }

	// RVA: 0x7514E90
	protected override object UnbindItem(object element, object index) { }

	// RVA: 0x7514EB4
	protected override object DestroyItem(object element) { }

	// RVA: 0x7514ED8
	protected override object PrepareView() { }

	// RVA: 0x7514F04
	public override object Dispose() { }

}

// Namespace: 
private sealed class <GetAllItemIds>d__13
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object rootIds; // 0x0
	public object <>3__rootIds; // 0x0
	public object <>4__this; // 0x0
	private object <currentIterator>5__1; // 0x0
	private object <hasNext>5__2; // 0x0
	private object <currentItemId>5__3; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Int32>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<System.Int32>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Int32>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <GetItemIds>d__9
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object items; // 0x0
	public object <>3__items; // 0x0
	private object <>s__1; // 0x0
	private object <item>5__2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Int32>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<System.Int32>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<System.Int32>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.UIElements
internal sealed class TreeDataController<T0>
{

	// Fields
	private object m_TreeData; // 0x0
	private object m_IteratorStack; // 0x0

	// Methods

	// RVA: -1
	public object SetRootItems(object rootItems) { }

	// RVA: -1
	public object GetDataForId(object id) { }

	// RVA: -1
	public object GetParentId(object id) { }

	// RVA: -1
	public object HasChildren(object id) { }

	// RVA: -1
	private static object GetItemIds(object items) { }

	// RVA: -1
	public object GetChildrenIds(object id) { }

	// RVA: -1
	public object Move(object id, object newParentId, object childIndex) { }

	// RVA: -1
	public object IsChildOf(object childId, object id) { }

	// RVA: -1
	public object GetAllItemIds(object rootIds) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class TreeViewController
{

	// Properties
	protected object treeView { get; }

	// Methods

	// RVA: 0x7514F48
	protected object get_treeView() { }

	// RVA: 0x7514FD0
	protected override object MakeItem() { }

	// RVA: 0x751511C
	protected override object BindItem(object element, object index) { }

	// RVA: 0x7515358
	protected override object UnbindItem(object element, object index) { }

	// RVA: 0x7515418
	protected override object DestroyItem(object element) { }

	// RVA: 0x75154D0
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal abstract class CollectionVirtualizationController
{

	// Fields
	protected readonly object m_ScrollView; // 0x8

	// Properties
	public abstract object firstVisibleIndex { get; set; }
	public abstract object visibleItemCount { get; }
	public abstract object activeItems { get; }

	// Methods

	// RVA: -1
	public abstract object get_firstVisibleIndex() { }

	// RVA: -1
	protected abstract object set_firstVisibleIndex(object value) { }

	// RVA: -1
	public abstract object get_visibleItemCount() { }

	// RVA: 0x7515550
	protected object .ctor(object scrollView) { }

	// RVA: -1
	public abstract object Refresh(object rebuild) { }

	// RVA: -1
	public abstract object ScrollToItem(object id) { }

	// RVA: -1
	public abstract object Resize(object size) { }

	// RVA: -1
	public abstract object OnScroll(object offset) { }

	// RVA: -1
	public abstract object GetIndexFromPosition(object position) { }

	// RVA: -1
	public abstract object GetExpectedItemHeight(object index) { }

	// RVA: -1
	public abstract object GetExpectedContentHeight() { }

	// RVA: -1
	public abstract object OnFocus(object leafTarget) { }

	// RVA: -1
	public abstract object OnBlur(object willFocus) { }

	// RVA: -1
	public abstract object UpdateBackground() { }

	// RVA: -1
	public abstract object get_activeItems() { }

	// RVA: -1
	internal abstract object StartDragItem(object item) { }

	// RVA: -1
	internal abstract object EndDrag(object dropIndex) { }

}

// Namespace: 
private struct ContentHeightCacheInfo
{

	// Fields
	public readonly object sum; // 0x0
	public readonly object count; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object sum, object count) { }

}

// Namespace: 
private enum VirtualizationChange
{

	// Fields
	public object value__; // 0x0
	public const object None;
	public const object Resize;
	public const object Scroll;
	public const object ForcedScroll;
}

// Namespace: 
private enum ScrollDirection
{

	// Fields
	public object value__; // 0x0
	public const object Idle;
	public const object Up;
	public const object Down;
}

// Namespace: UnityEngine.UIElements
internal class DynamicHeightVirtualizationController<T0>
{

	// Fields
	private object m_HighestCachedIndex; // 0x0
	private readonly object m_ItemHeightCache; // 0x0
	private readonly object m_ContentHeightCache; // 0x0
	private readonly object m_WaitingCache; // 0x0
	private object m_ForcedFirstVisibleItem; // 0x0
	private object m_ForcedLastVisibleItem; // 0x0
	private object m_StickToBottom; // 0x0
	private object m_LastChange; // 0x0
	private object m_ScrollDirection; // 0x0
	private object m_DelayedScrollOffset; // 0x0
	private object m_AccumulatedHeight; // 0x0
	private object m_MinimumItemHeight; // 0x0
	private object m_FillCallback; // 0x0
	private object m_ScrollCallback; // 0x0
	private object m_ScrollResetCallback; // 0x0
	private object m_GeometryChangedCallback; // 0x0
	private object m_ScheduledItem; // 0x0
	private object m_ScrollScheduledItem; // 0x0
	private object m_ScrollResetScheduledItem; // 0x0
	private object m_IndexOutOfBoundsPredicate; // 0x0

	// Properties
	private object defaultExpectedHeight { get; }
	private object contentPadding { get; set; }
	private object contentHeight { get; set; }
	private object anchoredIndex { get; set; }
	private object anchorOffset { get; set; }
	private object viewportMaxOffset { get; }
	protected override object alwaysRebindOnRefresh { get; }

	// Methods

	// RVA: -1
	private object get_defaultExpectedHeight() { }

	// RVA: -1
	private object get_contentPadding() { }

	// RVA: -1
	private object set_contentPadding(object value) { }

	// RVA: -1
	private object get_contentHeight() { }

	// RVA: -1
	private object set_contentHeight(object value) { }

	// RVA: -1
	private object get_anchoredIndex() { }

	// RVA: -1
	private object set_anchoredIndex(object value) { }

	// RVA: -1
	private object get_anchorOffset() { }

	// RVA: -1
	private object set_anchorOffset(object value) { }

	// RVA: -1
	private object get_viewportMaxOffset() { }

	// RVA: -1
	protected override object get_alwaysRebindOnRefresh() { }

	// RVA: -1
	public object .ctor(object collectionView) { }

	// RVA: -1
	public override object Refresh(object rebuild) { }

	// RVA: -1
	public override object ScrollToItem(object index) { }

	// RVA: -1
	public override object Resize(object size) { }

	// RVA: -1
	public override object OnScroll(object scrollOffset) { }

	// RVA: -1
	private object OnScrollUpdate() { }

	// RVA: -1
	private object CycleItems(object firstIndex) { }

	// RVA: -1
	private object NeedsFill() { }

	// RVA: -1
	private object Fill() { }

	// RVA: -1
	private object UpdateScrollViewContainer(object previousHeight, object newHeight) { }

	// RVA: -1
	private object ApplyScrollViewUpdate(object dimensionsOnly) { }

	// RVA: -1
	private object UpdateAnchor() { }

	// RVA: -1
	private object ScheduleFill() { }

	// RVA: -1
	private object ScheduleScroll() { }

	// RVA: -1
	private object ScheduleScrollDirectionReset() { }

	// RVA: -1
	private object ResetScroll() { }

	// RVA: -1
	public override object GetIndexFromPosition(object position) { }

	// RVA: -1
	public override object GetExpectedItemHeight(object index) { }

	// RVA: -1
	private object GetFirstVisibleItem(object offset) { }

	// RVA: -1
	public override object GetExpectedContentHeight() { }

	// RVA: -1
	private object GetContentHeightForIndex(object lastIndex) { }

	// RVA: -1
	private object GetCachedContentHeight(object index) { }

	// RVA: -1
	private object RegisterItemHeight(object index, object height) { }

	// RVA: -1
	private object UnregisterItemHeight(object index) { }

	// RVA: -1
	private object CleanItemHeightCache() { }

	// RVA: -1
	private object OnRecycledItemGeometryChanged(object item) { }

	// RVA: -1
	private object UpdateRegisteredHeight(object item) { }

	// RVA: -1
	internal override object GetOrMakeItemAtIndex(object activeItemIndex, object scrollViewIndex) { }

	// RVA: -1
	internal override object ReleaseItem(object activeItemsIndex) { }

	// RVA: -1
	internal override object StartDragItem(object item) { }

	// RVA: -1
	internal override object EndDrag(object dropIndex) { }

	// RVA: -1
	private object HideItem(object activeItemsIndex) { }

	// RVA: -1
	private object MarkWaitingForLayout(object item) { }

	// RVA: -1
	private object IsIndexOutOfBounds(object i) { }

}

// Namespace: UnityEngine.UIElements
internal class FixedHeightVirtualizationController<T0>
{

	// Properties
	private object resolvedItemHeight { get; }

	// Methods

	// RVA: -1
	private object get_resolvedItemHeight() { }

	// RVA: -1
	protected override object VisibleItemPredicate(object i) { }

	// RVA: -1
	public object .ctor(object collectionView) { }

	// RVA: -1
	public override object GetIndexFromPosition(object position) { }

	// RVA: -1
	public override object GetExpectedItemHeight(object index) { }

	// RVA: -1
	public override object GetExpectedContentHeight() { }

	// RVA: -1
	public override object ScrollToItem(object index) { }

	// RVA: -1
	public override object Resize(object size) { }

	// RVA: -1
	public override object OnScroll(object scrollOffset) { }

	// RVA: -1
	internal override object GetOrMakeItemAtIndex(object activeItemIndex, object scrollViewIndex) { }

	// RVA: -1
	internal override object EndDrag(object dropIndex) { }

}

// Namespace: UnityEngine.UIElements
internal class ReusableCollectionItem
{

	// Fields
	private object <bindableElement>k__BackingField; // 0x8
	private object <animator>k__BackingField; // 0x10
	private object <index>k__BackingField; // 0x18
	private object <id>k__BackingField; // 0x1C
	private object <isDragGhost>k__BackingField; // 0x20
	private object onGeometryChanged; // 0x28
	protected object m_GeometryChangedEventCallback; // 0x30

	// Properties
	public virtual object rootElement { get; }
	public object bindableElement { get; set; }
	public object animator { get; set; }
	public object index { get; set; }
	public object id { get; set; }
	internal object isDragGhost { get; set; }

	// Methods

	// RVA: 0x751557C
	public virtual object get_rootElement() { }

	// RVA: 0x7515584
	public object get_bindableElement() { }

	// RVA: 0x751558C
	protected object set_bindableElement(object value) { }

	// RVA: 0x7515594
	public object get_animator() { }

	// RVA: 0x751559C
	public object set_animator(object value) { }

	// RVA: 0x75155A4
	public object get_index() { }

	// RVA: 0x75155AC
	public object set_index(object value) { }

	// RVA: 0x75155B4
	public object get_id() { }

	// RVA: 0x75155BC
	public object set_id(object value) { }

	// RVA: 0x75155C4
	internal object get_isDragGhost() { }

	// RVA: 0x75155CC
	private object set_isDragGhost(object value) { }

	// RVA: 0x75155D4
	public object add_onGeometryChanged(object value) { }

	// RVA: 0x7515688
	public object remove_onGeometryChanged(object value) { }

	// RVA: 0x751573C
	public object .ctor() { }

	// RVA: 0x75157D0
	public virtual object Init(object item) { }

	// RVA: 0x75157D8
	public virtual object PreAttachElement() { }

	// RVA: 0x75158DC
	public virtual object DetachElement() { }

	// RVA: 0x7515A6C
	public virtual object SetSelected(object selected) { }

	// RVA: 0x7515C24
	public virtual object SetDragGhost(object dragGhost) { }

	// RVA: 0x7515E3C
	protected object OnGeometryChanged(object evt) { }

}

// Namespace: UnityEngine.UIElements
internal class ReusableListViewItem
{

	// Fields
	private object m_Container; // 0x38
	private object m_DragHandle; // 0x40
	private object m_ItemContainer; // 0x48

	// Properties
	public override object rootElement { get; }

	// Methods

	// RVA: 0x7515E5C
	public override object get_rootElement() { }

	// RVA: 0x750A7EC
	public object Init(object item, object usesAnimatedDragger) { }

	// RVA: 0x7515E74
	protected object UpdateHierarchy(object root, object item, object usesAnimatedDragger) { }

	// RVA: 0x750B044
	public object UpdateDragHandle(object needsDragHandle) { }

	// RVA: 0x751615C
	public override object PreAttachElement() { }

	// RVA: 0x7516208
	public override object DetachElement() { }

	// RVA: 0x75162B4
	public override object SetDragGhost(object dragGhost) { }

	// RVA: 0x75163DC
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class ReusableMultiColumnListViewItem
{

	// Properties
	public override object rootElement { get; }

	// Methods

	// RVA: 0x7516470
	public override object get_rootElement() { }

	// RVA: 0x7516478
	public override object Init(object item) { }

	// RVA: 0x7513BB0
	public object Init(object container, object columns, object usesAnimatedDrag) { }

	// RVA: 0x751647C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class ReusableMultiColumnTreeViewItem
{

	// Properties
	public override object rootElement { get; }

	// Methods

	// RVA: 0x7516510
	public override object get_rootElement() { }

	// RVA: 0x7516518
	public override object Init(object item) { }

	// RVA: 0x751495C
	public object Init(object container, object columns) { }

	// RVA: 0x7516B10
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class ReusableTreeViewItem
{

	// Fields
	private object m_Toggle; // 0x38
	private object m_Container; // 0x40
	private object m_IndentElement; // 0x48
	private object m_BindableContainer; // 0x50
	private object m_Checkmark; // 0x58
	private object onPointerUp; // 0x60
	private object onToggleValueChanged; // 0x68
	private object m_Depth; // 0x70
	private object m_IndentWidth; // 0x74
	private object m_PointerUpCallback; // 0x78
	private object m_ToggleValueChangedCallback; // 0x80
	private object m_ToggleGeometryChangedCallback; // 0x88

	// Properties
	public override object rootElement { get; }

	// Methods

	// RVA: 0x7516CA4
	public override object get_rootElement() { }

	// RVA: 0x750EB1C
	public object add_onPointerUp(object value) { }

	// RVA: 0x750E950
	public object remove_onPointerUp(object value) { }

	// RVA: 0x750EBD0
	public object add_onToggleValueChanged(object value) { }

	// RVA: 0x750EA04
	public object remove_onToggleValueChanged(object value) { }

	// RVA: 0x7516B14
	public object .ctor() { }

	// RVA: 0x7516CBC
	public override object Init(object item) { }

	// RVA: 0x751651C
	protected object InitExpandHierarchy(object root, object item) { }

	// RVA: 0x7516D9C
	public override object PreAttachElement() { }

	// RVA: 0x7516FA4
	public override object DetachElement() { }

	// RVA: 0x750E494
	public object Indent(object depth) { }

	// RVA: 0x750E5A8
	public object SetExpandedWithoutNotify(object expanded) { }

	// RVA: 0x750E6F4
	public object SetToggleVisibility(object visible) { }

	// RVA: 0x7517328
	private object OnToggleGeometryChanged(object evt) { }

	// RVA: 0x75171AC
	private object UpdateIndentLayout() { }

	// RVA: 0x7517610
	private object OnPointerUp(object evt) { }

	// RVA: 0x751762C
	private object OnToggleValueChanged(object evt) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__30_0; // 0x0
	public static object <>9__30_1; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.ctor>b__30_0() { }

	// RVA: -1
	internal object <.ctor>b__30_1(object i) { }

}

// Namespace: UnityEngine.UIElements
internal abstract class VerticalVirtualizationController<T0>
{

	// Fields
	private readonly object m_Pool; // 0x0
	protected object m_CollectionView; // 0x0
	protected object m_ActiveItems; // 0x0
	protected object m_DraggedItem; // 0x0
	private object m_LastFocusedElementIndex; // 0x0
	private object m_LastFocusedElementTreeChildIndexes; // 0x0
	protected readonly object m_VisibleItemPredicateDelegate; // 0x0
	protected object m_ScrollInsertionList; // 0x0
	private object m_EmptyRows; // 0x0

	// Properties
	public override object activeItems { get; }
	internal object itemsCount { get; }
	internal object firstVisibleItem { get; }
	internal object lastVisibleItem { get; }
	public override object visibleItemCount { get; }
	protected object serializedData { get; }
	public override object firstVisibleIndex { get; set; }
	protected object lastHeight { get; }
	protected virtual object alwaysRebindOnRefresh { get; }

	// Methods

	// RVA: -1
	public override object get_activeItems() { }

	// RVA: -1
	internal object get_itemsCount() { }

	// RVA: -1
	protected virtual object VisibleItemPredicate(object i) { }

	// RVA: -1
	internal object get_firstVisibleItem() { }

	// RVA: -1
	internal object get_lastVisibleItem() { }

	// RVA: -1
	public override object get_visibleItemCount() { }

	// RVA: -1
	protected object get_serializedData() { }

	// RVA: -1
	public override object get_firstVisibleIndex() { }

	// RVA: -1
	protected override object set_firstVisibleIndex(object value) { }

	// RVA: -1
	protected object get_lastHeight() { }

	// RVA: -1
	protected virtual object get_alwaysRebindOnRefresh() { }

	// RVA: -1
	protected object .ctor(object collectionView) { }

	// RVA: -1
	public override object Refresh(object rebuild) { }

	// RVA: -1
	protected object Setup(object recycledItem, object newIndex) { }

	// RVA: -1
	public override object OnFocus(object leafTarget) { }

	// RVA: -1
	public override object OnBlur(object willFocus) { }

	// RVA: -1
	private object HandleFocus(object recycledItem, object previousIndex) { }

	// RVA: -1
	public override object UpdateBackground() { }

	// RVA: -1
	internal override object StartDragItem(object item) { }

	// RVA: -1
	internal override object EndDrag(object dropIndex) { }

	// RVA: -1
	internal virtual object GetOrMakeItemAtIndex(object activeItemIndex, object scrollViewIndex) { }

	// RVA: -1
	internal virtual object ReleaseItem(object activeItemsIndex) { }

	// RVA: -1
	protected object GetDraggedIndex() { }

}

// Namespace: UnityEngine.UIElements
public abstract class ContextualMenuManager
{

	// Fields
	private object <displayMenuHandledOSX>k__BackingField; // 0x8

	// Properties
	internal object displayMenuHandledOSX { get; set; }

	// Methods

	// RVA: 0x7517648
	internal object get_displayMenuHandledOSX() { }

	// RVA: 0x7517650
	internal object set_displayMenuHandledOSX(object value) { }

	// RVA: -1
	public abstract object DisplayMenuIfEventMatches(object evt, object eventHandler) { }

	// RVA: 0x7517658
	public object DisplayMenu(object triggerEvent, object target) { }

	// RVA: -1
	protected internal abstract object DoDisplayMenu(object menu, object triggerEvent) { }

}

// Namespace: UnityEngine.UIElements
public class ContextualMenuManipulator
{

	// Fields
	private object m_MenuBuilder; // 0x28

	// Methods

	// RVA: 0x7517920
	public object .ctor(object menuBuilder) { }

	// RVA: 0x7517BBC
	protected override object RegisterCallbacksOnTarget() { }

	// RVA: 0x7517ED8
	protected override object UnregisterCallbacksFromTarget() { }

	// RVA: 0x75181F4
	private object OnMouseUpDownEvent(object evt) { }

	// RVA: 0x7518398
	private object OnMouseDownEventOSX(object evt) { }

	// RVA: 0x75184E4
	private object OnMouseUpEventOSX(object evt) { }

	// RVA: 0x7518618
	private object OnKeyUpEvent(object evt) { }

	// RVA: 0x75182B4
	private object DoDisplayMenu(object evt) { }

	// RVA: 0x7518698
	private object OnContextualMenuEvent(object evt) { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseBoolField
{

	// Fields
	protected object m_Label; // 0x428
	protected readonly object m_CheckMark; // 0x430
	internal object m_Clickable; // 0x438
	private object m_OriginalText; // 0x440

	// Properties
	public object text { get; set; }

	// Methods

	// RVA: 0x75186B4
	public object .ctor(object label) { }

	// RVA: 0x75189CC
	private object OnNavigationSubmit(object evt) { }

	// RVA: 0x7518A30
	public object get_text() { }

	// RVA: 0x7518904
	public object set_text(object value) { }

	// RVA: 0x7518A84
	protected virtual object InitLabel() { }

	// RVA: 0x7518B20
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x7518C28
	private object OnClickEvent(object evt) { }

	// RVA: 0x7518FA8
	protected virtual object ToggleValue() { }

	// RVA: 0x7519018
	protected override object UpdateMixedValueContent() { }

}

// Namespace: 
public sealed class WriteDelegate
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object val, object fieldValue) { }

}

// Namespace: 
internal struct FieldDescription
{

	// Fields
	internal readonly object name; // 0x0
	internal readonly object ussName; // 0x0
	internal readonly object read; // 0x0
	internal readonly object write; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object name, object ussName, object read, object write) { }

}

// Namespace: 
private sealed class <>c__DisplayClass24_0
{

	// Fields
	public object desc; // 0x0
	public object field; // 0x0
	public object <>4__this; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.ctor>b__0(object newValue) { }

	// RVA: -1
	internal object <.ctor>b__1(object e) { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseCompositeField<T0, T1, T2>
{

	// Fields
	private object m_Fields; // 0x0
	private object m_ShouldUpdateDisplay; // 0x0
	private object m_ForceUpdateDisplay; // 0x0
	private object m_PropertyIndex; // 0x0
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x0
	public static readonly object inputUssClassName; // 0x0
	public static readonly object spacerUssClassName; // 0x0
	public static readonly object multilineVariantUssClassName; // 0x0
	public static readonly object fieldGroupUssClassName; // 0x0
	public static readonly object fieldUssClassName; // 0x0
	public static readonly object firstFieldVariantUssClassName; // 0x0
	public static readonly object twoLinesVariantUssClassName; // 0x0

	// Methods

	// RVA: -1
	private object GetSpacer() { }

	// RVA: -1
	internal abstract object DescribeFields() { }

	// RVA: -1
	protected object .ctor(object label, object fieldsByLine) { }

	// RVA: -1
	private object UpdateDisplay() { }

	// RVA: -1
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: -1
	internal override object OnViewDataReady() { }

	// RVA: -1
	protected override object UpdateMixedValueContent() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public enum ListViewReorderMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Simple;
	public const object Animated;
}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private readonly object m_ShowFoldoutHeader; // 0xA8
	private readonly object m_HeaderTitle; // 0xB0
	private readonly object m_ShowAddRemoveFooter; // 0xB8
	private readonly object m_ReorderMode; // 0xC0
	private readonly object m_ShowBoundCollectionSize; // 0xC8

	// Methods

	// RVA: 0x751BBF8
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x751BF04
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseListView
{

	// Fields
	private object m_ShowBoundCollectionSize; // 0x4A4
	private object m_ShowFoldoutHeader; // 0x4A5
	private object m_HeaderTitle; // 0x4A8
	private object itemsAdded; // 0x4B0
	private object itemsRemoved; // 0x4B8
	private object m_ListViewLabel; // 0x4C0
	private object m_Foldout; // 0x4C8
	private object m_ArraySizeField; // 0x4D0
	private object m_IsOverMultiEditLimit; // 0x4D8
	private object m_Footer; // 0x4E0
	private object m_AddButton; // 0x4E8
	private object m_RemoveButton; // 0x4F0
	private object m_ItemAddedCallback; // 0x4F8
	private object m_ItemRemovedCallback; // 0x500
	private object m_ItemsSourceSizeChangedCallback; // 0x508
	private object m_ReorderMode; // 0x510
	private object reorderModeChanged; // 0x518
	public static readonly object ussClassName; // 0x0
	public static readonly object itemUssClassName; // 0x8
	public static readonly object emptyLabelUssClassName; // 0x10
	public static readonly object overMaxMultiEditLimitClassName; // 0x18
	public static readonly object reorderableUssClassName; // 0x20
	public static readonly object reorderableItemUssClassName; // 0x28
	public static readonly object reorderableItemContainerUssClassName; // 0x30
	public static readonly object reorderableItemHandleUssClassName; // 0x38
	public static readonly object reorderableItemHandleBarUssClassName; // 0x40
	public static readonly object footerUssClassName; // 0x48
	public static readonly object foldoutHeaderUssClassName; // 0x50
	public static readonly object arraySizeFieldUssClassName; // 0x58
	public static readonly object listViewWithHeaderUssClassName; // 0x60
	public static readonly object listViewWithFooterUssClassName; // 0x68
	public static readonly object scrollViewWithFooterUssClassName; // 0x70
	public static readonly object footerAddButtonName; // 0x78
	public static readonly object footerRemoveButtonName; // 0x80
	private object m_MaxMultiEditStr; // 0x520
	private static readonly object k_EmptyListStr; // 0x88

	// Properties
	public object showBoundCollectionSize { get; set; }
	internal override object sourceIncludesArraySize { get; }
	public object showFoldoutHeader { get; set; }
	public object headerTitle { set; }
	public object showAddRemoveFooter { get; set; }
	internal object footer { get; }
	public object viewController { get; }
	public object reorderMode { get; set; }

	// Methods

	// RVA: 0x751920C
	public object get_showBoundCollectionSize() { }

	// RVA: 0x7519214
	public object set_showBoundCollectionSize(object value) { }

	// RVA: 0x751943C
	internal override object get_sourceIncludesArraySize() { }

	// RVA: 0x7519468
	public object get_showFoldoutHeader() { }

	// RVA: 0x7519470
	public object set_showFoldoutHeader(object value) { }

	// RVA: 0x751922C
	private object SetupArraySizeField() { }

	// RVA: 0x751A08C
	public object set_headerTitle(object value) { }

	// RVA: 0x7519B20
	public object get_showAddRemoveFooter() { }

	// RVA: 0x751A0A4
	public object set_showAddRemoveFooter(object value) { }

	// RVA: 0x7519B30
	private object EnableFooter(object enabled) { }

	// RVA: 0x751A0A8
	private object AddItems(object itemCount) { }

	// RVA: 0x751A1E4
	private object OnArraySizeFieldChanged(object evt) { }

	// RVA: 0x7519F1C
	internal object UpdateArraySizeField() { }

	// RVA: 0x7519768
	internal object UpdateListViewLabel() { }

	// RVA: 0x751A5D8
	private object OnAddClicked() { }

	// RVA: 0x751A9A8
	private object OnRemoveClicked() { }

	// RVA: 0x751AD40
	internal object get_footer() { }

	// RVA: 0x751A15C
	public object get_viewController() { }

	// RVA: 0x751AD48
	internal override object CreateVirtualizationController() { }

	// RVA: 0x751ADA0
	public override object SetViewController(object controller) { }

	// RVA: 0x751B438
	private object OnItemAdded(object indices) { }

	// RVA: 0x751B454
	private object OnItemsRemoved(object indices) { }

	// RVA: 0x751B470
	private object OnItemsSourceSizeChanged() { }

	// RVA: 0x75142C0
	internal object add_reorderModeChanged(object value) { }

	// RVA: 0x7514520
	internal object remove_reorderModeChanged(object value) { }

	// RVA: 0x751B4F4
	public object get_reorderMode() { }

	// RVA: 0x751B4FC
	public object set_reorderMode(object value) { }

	// RVA: 0x751B564
	internal override object CreateDragger() { }

	// RVA: 0x751B608
	internal override object CreateDragAndDropController() { }

	// RVA: 0x751B670
	public object .ctor() { }

	// RVA: 0x751B740
	internal override object PostRefresh() { }

	// RVA: 0x751B770
	private static object .cctor() { }

	// RVA: 0x751BAFC
	private object <OnAddClicked>b__34_0() { }

}

// Namespace: 
private class PopupTextElement
{

	// Methods

	// RVA: -1
	protected internal override object DoMeasure(object desiredWidth, object widthMode, object desiredHeight, object heightMode) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__23_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.ctor>b__23_0(object e) { }

}

// Namespace: UnityEngine.UIElements
public abstract class BasePopupField<T0, T1>
{

	// Fields
	internal object m_Choices; // 0x0
	private object m_TextElement; // 0x0
	private object m_ArrowElement; // 0x0
	internal object m_FormatSelectedValueCallback; // 0x0
	internal object m_FormatListItemCallback; // 0x0
	internal object createMenuCallback; // 0x0
	public static readonly object ussClassName; // 0x0
	public static readonly object textUssClassName; // 0x0
	public static readonly object arrowUssClassName; // 0x0
	public static readonly object labelUssClassName; // 0x0
	public static readonly object inputUssClassName; // 0x0

	// Properties
	protected object textElement { get; }
	public virtual object choices { set; }

	// Methods

	// RVA: -1
	protected object get_textElement() { }

	// RVA: -1
	internal abstract object GetValueToDisplay() { }

	// RVA: -1
	internal abstract object GetListItemToDisplay(object item) { }

	// RVA: -1
	internal abstract object AddMenuItems(object menu) { }

	// RVA: -1
	public virtual object set_choices(object value) { }

	// RVA: -1
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: -1
	internal object .ctor(object label) { }

	// RVA: -1
	private object OnPointerDownEvent(object evt) { }

	// RVA: -1
	private object OnPointerMoveEvent(object evt) { }

	// RVA: -1
	private object ContainsPointer(object pointerId) { }

	// RVA: -1
	private object ProcessPointerDown(object evt) { }

	// RVA: -1
	private object OnNavigationSubmit(object evt) { }

	// RVA: -1
	internal object ShowMenu() { }

	// RVA: -1
	protected override object UpdateMixedValueContent() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public enum SliderDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Horizontal;
	public const object Vertical;
}

// Namespace: 
internal enum SliderKey
{

	// Fields
	public object value__; // 0x0
	public const object None;
	public const object Lowest;
	public const object LowerPage;
	public const object Lower;
	public const object Higher;
	public const object HigherPage;
	public const object Highest;
}

// Namespace: UnityEngine.UIElements
public abstract class BaseSlider<T0>
{

	// Fields
	private object <dragContainer>k__BackingField; // 0x0
	private object <dragElement>k__BackingField; // 0x0
	private object <trackElement>k__BackingField; // 0x0
	private object <dragBorderElement>k__BackingField; // 0x0
	private object <inputTextField>k__BackingField; // 0x0
	private object m_IsEditingTextField; // 0x0
	private object m_LowValue; // 0x0
	private object m_HighValue; // 0x0
	private object m_PageSize; // 0x0
	private object m_ShowInputField; // 0x0
	private object <clamped>k__BackingField; // 0x0
	private object <clampedDragger>k__BackingField; // 0x0
	private object m_DragElementStartPos; // 0x0
	private object m_Direction; // 0x0
	private object m_Inverted; // 0x0
	internal const object kDefaultPageSize;
	internal const object kDefaultShowInputField;
	internal const object kDefaultInverted;
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x0
	public static readonly object inputUssClassName; // 0x0
	public static readonly object horizontalVariantUssClassName; // 0x0
	public static readonly object verticalVariantUssClassName; // 0x0
	public static readonly object dragContainerUssClassName; // 0x0
	public static readonly object trackerUssClassName; // 0x0
	public static readonly object draggerUssClassName; // 0x0
	public static readonly object draggerBorderUssClassName; // 0x0
	public static readonly object textFieldClassName; // 0x0

	// Properties
	internal object dragContainer { get; set; }
	internal object dragElement { get; set; }
	internal object trackElement { get; set; }
	internal object dragBorderElement { get; set; }
	internal object inputTextField { get; set; }
	public object lowValue { get; set; }
	public object highValue { get; set; }
	public virtual object pageSize { get; set; }
	public virtual object showInputField { get; set; }
	internal object clamped { get; set; }
	internal object clampedDragger { get; set; }
	public override object value { get; set; }
	public object direction { get; set; }
	public object inverted { get; set; }

	// Methods

	// RVA: -1
	internal object get_dragContainer() { }

	// RVA: -1
	private object set_dragContainer(object value) { }

	// RVA: -1
	internal object get_dragElement() { }

	// RVA: -1
	private object set_dragElement(object value) { }

	// RVA: -1
	internal object get_trackElement() { }

	// RVA: -1
	private object set_trackElement(object value) { }

	// RVA: -1
	internal object get_dragBorderElement() { }

	// RVA: -1
	private object set_dragBorderElement(object value) { }

	// RVA: -1
	internal object get_inputTextField() { }

	// RVA: -1
	private object set_inputTextField(object value) { }

	// RVA: -1
	public object get_lowValue() { }

	// RVA: -1
	public object set_lowValue(object value) { }

	// RVA: -1
	public object get_highValue() { }

	// RVA: -1
	public object set_highValue(object value) { }

	// RVA: -1
	internal object SetHighValueWithoutNotify(object newHighValue) { }

	// RVA: -1
	public virtual object get_pageSize() { }

	// RVA: -1
	public virtual object set_pageSize(object value) { }

	// RVA: -1
	public virtual object get_showInputField() { }

	// RVA: -1
	public virtual object set_showInputField(object value) { }

	// RVA: -1
	internal object get_clamped() { }

	// RVA: -1
	internal object set_clamped(object value) { }

	// RVA: -1
	internal object get_clampedDragger() { }

	// RVA: -1
	private object set_clampedDragger(object value) { }

	// RVA: -1
	private object Clamp(object value, object lowBound, object highBound) { }

	// RVA: -1
	private object GetClampedValue(object newValue) { }

	// RVA: -1
	public override object get_value() { }

	// RVA: -1
	public override object set_value(object value) { }

	// RVA: -1
	public virtual object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: -1
	private object UnityEngine.UIElements.IValueField<TValueType>.StartDragging() { }

	// RVA: -1
	private object UnityEngine.UIElements.IValueField<TValueType>.StopDragging() { }

	// RVA: -1
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: -1
	public object get_direction() { }

	// RVA: -1
	public object set_direction(object value) { }

	// RVA: -1
	public object get_inverted() { }

	// RVA: -1
	public object set_inverted(object value) { }

	// RVA: -1
	internal object .ctor(object label, object start, object end, object direction, object pageSize) { }

	// RVA: -1
	protected static object GetClosestPowerOfTen(object positiveNumber) { }

	// RVA: -1
	protected static object RoundToMultipleOf(object value, object roundingValue) { }

	// RVA: -1
	private object ClampValue() { }

	// RVA: -1
	internal abstract object SliderLerpUnclamped(object a, object b, object interpolant) { }

	// RVA: -1
	internal abstract object SliderNormalizeValue(object currentValue, object lowerValue, object higherValue) { }

	// RVA: -1
	internal abstract object ParseStringToValue(object stringValue) { }

	// RVA: -1
	internal abstract object ComputeValueFromKey(object sliderKey, object isShift) { }

	// RVA: -1
	private object SliderLerpDirectionalUnclamped(object a, object b, object positionInterpolant) { }

	// RVA: -1
	private object SetSliderValueFromDrag() { }

	// RVA: -1
	private object ComputeValueAndDirectionFromDrag(object sliderLength, object dragElementLength, object dragElementPos) { }

	// RVA: -1
	private object SetSliderValueFromClick() { }

	// RVA: -1
	private object OnKeyDown(object evt) { }

	// RVA: -1
	private object OnNavigationMove(object evt) { }

	// RVA: -1
	internal virtual object ComputeValueAndDirectionFromClick(object sliderLength, object dragElementLength, object dragElementPos, object dragElementLastPos) { }

	// RVA: -1
	public object AdjustDragElement(object factor) { }

	// RVA: -1
	private object UpdateDragElementPosition(object evt) { }

	// RVA: -1
	internal override object OnViewDataReady() { }

	// RVA: -1
	private object SameValues(object a, object b, object epsilon) { }

	// RVA: -1
	private object UpdateDragElementPosition() { }

	// RVA: -1
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: -1
	private object UpdateTextFieldVisibility() { }

	// RVA: -1
	private object UpdateTextFieldValue() { }

	// RVA: -1
	private object OnTextFieldFocusIn(object evt) { }

	// RVA: -1
	private object OnTextFieldFocusOut(object evt) { }

	// RVA: -1
	private object OnInputNavigationMoveEvent(object evt) { }

	// RVA: -1
	private object OnTextFieldValueChange(object evt) { }

	// RVA: -1
	protected override object UpdateMixedValueContent() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private readonly object m_AutoExpand; // 0xA8

	// Methods

	// RVA: 0x751DBA8
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x751E13C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseTreeView
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object itemUssClassName; // 0x8
	public static readonly object itemToggleUssClassName; // 0x10
	public static readonly object itemIndentsContainerUssClassName; // 0x18
	public static readonly object itemIndentUssClassName; // 0x20
	public static readonly object itemContentContainerUssClassName; // 0x28
	private object m_AutoExpand; // 0x4A4
	private object m_ExpandedItemIds; // 0x4A8

	// Properties
	public object itemsSource { get; }
	public object viewController { get; }
	public object autoExpand { get; set; }
	internal object expandedItemIds { get; set; }

	// Methods

	// RVA: 0x751C16C
	public object get_itemsSource() { }

	// RVA: 0x751C20C
	public object get_viewController() { }

	// RVA: 0x751C294
	internal override object CreateVirtualizationController() { }

	// RVA: 0x751C2EC
	public override object SetViewController(object controller) { }

	// RVA: 0x751C590
	private object OnItemIndexChanged(object srcIndex, object dstIndex) { }

	// RVA: 0x751C598
	internal override object CreateDragAndDropController() { }

	// RVA: 0x751C600
	public object get_autoExpand() { }

	// RVA: 0x751C608
	public object set_autoExpand(object value) { }

	// RVA: 0x751C6B0
	internal object get_expandedItemIds() { }

	// RVA: 0x751C6B8
	internal object set_expandedItemIds(object value) { }

	// RVA: 0x751C6C0
	public object .ctor() { }

	// RVA: 0x751C6C8
	public object .ctor(object itemHeight) { }

	// RVA: 0x751C848
	internal override object OnViewDataReady() { }

	// RVA: 0x751C8E0
	internal override object HandleItemNavigation(object moveIn, object altPressed) { }

	// RVA: 0x751D3A0
	public object SetSelectionById(object id) { }

	// RVA: 0x751D428
	public object SetSelectionById(object ids) { }

	// RVA: 0x751D430
	internal object SetSelectionInternalById(object ids, object sendNotification) { }

	// RVA: 0x751D530
	private object GetItemIndex(object id, object expand) { }

	// RVA: 0x751D7CC
	public object IsExpanded(object id) { }

	// RVA: 0x751D860
	public object CollapseItem(object id, object collapseAllChildren) { }

	// RVA: 0x751D908
	public object ExpandItem(object id, object expandAllChildren) { }

	// RVA: 0x751D9A8
	private object OnTreeViewMouseUp(object evt) { }

	// RVA: 0x751CF50
	private object IsExpandedByIndex(object index) { }

	// RVA: 0x751D1C4
	private object CollapseItemByIndex(object index, object collapseAll) { }

	// RVA: 0x751CFE4
	private object ExpandItemByIndex(object index, object expandAll) { }

	// RVA: 0x751DA38
	private static object .cctor() { }

	// RVA: 0x751DBA0
	private object <SetSelectionInternalById>b__47_0(object id) { }

}

// Namespace: UnityEngine.UIElements
public enum AlternatingRowBackground
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ContentOnly;
	public const object All;
}

// Namespace: UnityEngine.UIElements
public enum CollectionVirtualizationMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FixedHeight;
	public const object DynamicHeight;
}

// Namespace: UnityEngine.UIElements
internal class SerializedVirtualizationData
{

	// Fields
	public object scrollOffset; // 0x8
	public object firstVisibleIndex; // 0x10
	public object contentPadding; // 0x14
	public object contentHeight; // 0x18
	public object anchoredItemIndex; // 0x1C
	public object anchorOffset; // 0x20

	// Methods

	// RVA: 0x751E598
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private readonly object m_FixedItemHeight; // 0x70
	private readonly object m_VirtualizationMethod; // 0x78
	private readonly object m_ShowBorder; // 0x80
	private readonly object m_SelectionType; // 0x88
	private readonly object m_ShowAlternatingRowBackgrounds; // 0x90
	private readonly object m_Reorderable; // 0x98
	private readonly object m_HorizontalScrollingEnabled; // 0xA0

	// Methods

	// RVA: 0x751DCD8
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x751E1E0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass163_0
{

	// Fields
	public object id; // 0x8

	// Methods

	// RVA: 0x7520540
	public object .ctor() { }

	// RVA: 0x7526A44
	internal object <GetRootElementForId>b__0(object t) { }

}

// Namespace: 
private struct <>c__DisplayClass183_0
{

	// Fields
	public object <>4__this; // 0xFFFFFFFFFFFFFFF8
	public object shiftKey; // 0x0
}

// Namespace: UnityEngine.UIElements
public abstract class BaseVerticalCollectionView
{

	// Fields
	private static readonly object k_RefreshMarker; // 0x0
	private static readonly object k_RebuildMarker; // 0x8
	private object itemsChosen; // 0x3D0
	private object selectionChanged; // 0x3D8
	private object selectedIndicesChanged; // 0x3E0
	private object itemIndexChanged; // 0x3E8
	private object itemsSourceChanged; // 0x3F0
	private object selectionNotChanged; // 0x3F8
	private object canStartDrag; // 0x400
	private object setupDragAndDrop; // 0x408
	private object dragAndDropUpdate; // 0x410
	private object handleDrop; // 0x418
	private object m_SelectionType; // 0x420
	private static readonly object k_EmptyItems; // 0x10
	private object m_HorizontalScrollingEnabled; // 0x424
	private object m_ShowAlternatingRowBackgrounds; // 0x428
	internal static readonly object s_DefaultItemHeight; // 0x18
	internal object m_FixedItemHeight; // 0x42C
	internal object m_ItemHeightIsInline; // 0x430
	private object m_VirtualizationMethod; // 0x434
	private readonly object m_ScrollView; // 0x438
	private object m_ViewController; // 0x440
	private object m_VirtualizationController; // 0x448
	private object m_NavigationManipulator; // 0x450
	internal object serializedVirtualizationData; // 0x458
	private readonly object m_SelectedIds; // 0x460
	private readonly object m_SelectedIndices; // 0x468
	private readonly object m_SelectedItems; // 0x470
	private object m_LastHeight; // 0x478
	private object m_IsRangeSelectionDirectionUp; // 0x47C
	private object m_Dragger; // 0x480
	internal static object s_ItemHeightProperty; // 0x20
	private object m_ItemIndexChangedCallback; // 0x488
	private object m_ItemsSourceChangedCallback; // 0x490
	public static readonly object ussClassName; // 0x28
	public static readonly object borderUssClassName; // 0x30
	public static readonly object itemUssClassName; // 0x38
	public static readonly object dragHoverBarUssClassName; // 0x40
	public static readonly object dragHoverMarkerUssClassName; // 0x48
	public static readonly object itemDragHoverUssClassName; // 0x50
	public static readonly object itemSelectedVariantUssClassName; // 0x58
	public static readonly object itemAlternativeBackgroundUssClassName; // 0x60
	public static readonly object listScrollViewUssClassName; // 0x68
	internal static readonly object backgroundFillUssClassName; // 0x70
	private object m_TouchDownPosition; // 0x498

	// Properties
	public object itemsSource { get; set; }
	internal virtual object sourceIncludesArraySize { get; }
	public override object contentContainer { get; }
	public object selectionType { get; set; }
	public object selectedIndex { get; set; }
	public object selectedIndices { get; }
	internal object selectedIds { get; }
	internal object activeItems { get; }
	internal object scrollView { get; }
	internal object dragger { get; }
	internal object virtualizationController { get; }
	public object viewController { get; }
	public object showBorder { set; }
	public object reorderable { get; set; }
	public object horizontalScrollingEnabled { set; }
	public object showAlternatingRowBackgrounds { get; set; }
	public object virtualizationMethod { get; set; }
	public object fixedItemHeight { get; set; }
	internal object lastHeight { get; }

	// Methods

	// RVA: 0x751E5A0
	internal object HasCanStartDrag() { }

	// RVA: 0x751E5B0
	internal object RaiseCanStartDrag(object item, object ids) { }

	// RVA: 0x751E678
	internal object RaiseSetupDragAndDrop(object item, object ids, object args) { }

	// RVA: 0x751E760
	internal object RaiseHandleDragAndDrop(object pointerPosition, object dragAndDropArgs) { }

	// RVA: 0x751E7E4
	internal object RaiseDrop(object pointerPosition, object dragAndDropArgs) { }

	// RVA: 0x751E868
	public object get_itemsSource() { }

	// RVA: 0x751E8B8
	public object set_itemsSource(object value) { }

	// RVA: 0x751EA04
	internal virtual object get_sourceIncludesArraySize() { }

	// RVA: 0x751EA0C
	public override object get_contentContainer() { }

	// RVA: 0x751EA14
	public object get_selectionType() { }

	// RVA: 0x751EA1C
	public object set_selectionType(object value) { }

	// RVA: 0x751EC74
	public object get_selectedIndex() { }

	// RVA: 0x751ECF4
	public object set_selectedIndex(object value) { }

	// RVA: 0x751ECF8
	public object get_selectedIndices() { }

	// RVA: 0x751ED00
	internal object get_selectedIds() { }

	// RVA: 0x751ED08
	internal object get_activeItems() { }

	// RVA: 0x751EDBC
	internal object get_scrollView() { }

	// RVA: 0x751EDC4
	internal object get_dragger() { }

	// RVA: 0x751EDCC
	internal object get_virtualizationController() { }

	// RVA: 0x751EE84
	public object get_viewController() { }

	// RVA: 0x751EE8C
	internal object ResolveItemHeight(object height) { }

	// RVA: 0x751EF80
	public object set_showBorder(object value) { }

	// RVA: 0x751F020
	public object get_reorderable() { }

	// RVA: 0x751F148
	public object set_reorderable(object value) { }

	// RVA: 0x751F4C8
	public object set_horizontalScrollingEnabled(object value) { }

	// RVA: 0x751F558
	public object get_showAlternatingRowBackgrounds() { }

	// RVA: 0x751F560
	public object set_showAlternatingRowBackgrounds(object value) { }

	// RVA: 0x751F768
	public object get_virtualizationMethod() { }

	// RVA: 0x751F770
	public object set_virtualizationMethod(object value) { }

	// RVA: 0x751F7CC
	public object get_fixedItemHeight() { }

	// RVA: 0x751F7D4
	public object set_fixedItemHeight(object value) { }

	// RVA: 0x751F8E4
	internal object get_lastHeight() { }

	// RVA: 0x751F8EC
	internal virtual object CreateVirtualizationController() { }

	// RVA: 0x751EE28
	internal object GetOrCreateVirtualizationController() { }

	// RVA: -1
	internal object CreateVirtualizationController() { }

	// RVA: 0x751E978
	internal object GetOrCreateViewController() { }

	// RVA: -1
	protected abstract object CreateViewController() { }

	// RVA: 0x751F944
	public virtual object SetViewController(object controller) { }

	// RVA: 0x751FA3C
	internal virtual object CreateDragger() { }

	// RVA: 0x751FAA4
	internal object InitializeDragAndDropController(object enableReordering) { }

	// RVA: -1
	internal abstract object CreateDragAndDropController() { }

	// RVA: 0x751FC30
	public object .ctor() { }

	// RVA: 0x75202E4
	public object .ctor(object itemsSource, object itemHeight) { }

	// RVA: 0x752039C
	public object GetRootElementForId(object id) { }

	// RVA: 0x7520548
	internal virtual object HasValidDataAndBindings() { }

	// RVA: 0x75205A4
	private object OnItemIndexChanged(object srcIndex, object dstIndex) { }

	// RVA: 0x75205E0
	private object OnItemsSourceChanged() { }

	// RVA: 0x751F578
	public object RefreshItems() { }

	// RVA: 0x751F2DC
	public object Rebuild() { }

	// RVA: 0x75205FC
	private object RefreshSelection() { }

	// RVA: 0x7520A64
	internal virtual object PostRefresh() { }

	// RVA: 0x7520C38
	public object ScrollToItem(object index) { }

	// RVA: 0x7520D04
	public object ScrollToItemById(object id) { }

	// RVA: 0x7520E10
	private object OnScroll(object offset) { }

	// RVA: 0x7520B30
	private object Resize(object size) { }

	// RVA: 0x7520EE4
	private object OnAttachToPanel(object evt) { }

	// RVA: 0x7521310
	private object OnDetachFromPanel(object evt) { }

	// RVA: 0x75216C0
	private object Apply(object op, object shiftKey, object altKey) { }

	// RVA: 0x75227BC
	private object Apply(object op, object sourceEvent) { }

	// RVA: 0x7522AA8
	internal virtual object HandleItemNavigation(object moveIn, object altKey) { }

	// RVA: 0x7522AB0
	private object OnPointerMove(object evt) { }

	// RVA: 0x7523780
	private object OnPointerDown(object evt) { }

	// RVA: 0x7523864
	private object OnPointerCancel(object evt) { }

	// RVA: 0x7523908
	private object OnPointerUp(object evt) { }

	// RVA: 0x7523284
	private object ProcessPointerDown(object evt) { }

	// RVA: 0x7522B50
	private object ProcessPointerUp(object evt) { }

	// RVA: 0x75239EC
	private object DoSelect(object localPosition, object clickCount, object actionKey, object shiftKey) { }

	// RVA: 0x7523FC4
	internal object DoRangeSelection(object rangeSelectionFinalIndex) { }

	// RVA: 0x7523E6C
	private object ProcessSingleClick(object clickedIndex) { }

	// RVA: 0x7521D54
	internal object SelectAll() { }

	// RVA: 0x7523F40
	public object AddToSelection(object index) { }

	// RVA: 0x75246CC
	internal object AddToSelection(object indexes) { }

	// RVA: 0x7524BC0
	private object AddToSelectionWithoutValidation(object index) { }

	// RVA: 0x7523E70
	public object RemoveFromSelection(object index) { }

	// RVA: 0x75252C4
	private object RemoveFromSelectionWithoutValidation(object index) { }

	// RVA: 0x751EBD4
	public object SetSelection(object index) { }

	// RVA: 0x7525824
	public object SetSelection(object indices) { }

	// RVA: 0x7525C28
	public object SetSelectionWithoutNotify(object indices) { }

	// RVA: 0x752582C
	internal object SetSelectionInternal(object indices, object sendNotification) { }

	// RVA: 0x7525C30
	private object MatchesExistingSelection(object indices) { }

	// RVA: 0x7524B38
	private object NotifyOfSelectionChange() { }

	// RVA: 0x751EADC
	public object ClearSelection() { }

	// RVA: 0x7524238
	private object ClearSelectionWithoutValidation() { }

	// RVA: 0x7525EC0
	internal override object OnViewDataReady() { }

	// RVA: 0x7525F00
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: 0x75263C4
	private object OnSizeChanged(object evt) { }

	// RVA: 0x7526534
	private object OnCustomStyleResolved(object e) { }

	// RVA: 0x75266F8
	private object UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize() { }

	// RVA: 0x75266FC
	private object UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize() { }

	// RVA: 0x7526700
	private static object .cctor() { }

	// RVA: 0x7526A38
	private object <.ctor>b__160_0(object v) { }

	// RVA: 0x7522610
	private object <Apply>g__HandleSelectionAndScroll|183_0(object index, object ) { }

}

// Namespace: UnityEngine.UIElements
public interface IBindable
{

	// Properties
	public abstract object binding { get; }
	public abstract object bindingPath { set; }

	// Methods

	// RVA: -1
	public abstract object get_binding() { }

	// RVA: -1
	public abstract object set_bindingPath(object value) { }

}

// Namespace: UnityEngine.UIElements
public interface IBinding
{

	// Methods

	// RVA: -1
	public abstract object PreUpdate() { }

	// RVA: -1
	public abstract object Update() { }

	// RVA: -1
	public abstract object Release() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75274CC
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_CenterXValue; // 0x78
	private object m_CenterYValue; // 0x80
	private object m_CenterZValue; // 0x88
	private object m_ExtentsXValue; // 0x90
	private object m_ExtentsYValue; // 0x98
	private object m_ExtentsZValue; // 0xA0

	// Methods

	// RVA: 0x7527524
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x752787C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class BoundsField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10
	public static readonly object centerFieldUssClassName; // 0x18
	public static readonly object extentsFieldUssClassName; // 0x20
	private object m_CenterField; // 0x438
	private object m_ExtentsField; // 0x440

	// Methods

	// RVA: 0x7526A70
	public object .ctor() { }

	// RVA: 0x7526A78
	public object .ctor(object label) { }

	// RVA: 0x7526FC4
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x7527128
	protected override object UpdateMixedValueContent() { }

	// RVA: 0x75271B4
	private static object .cctor() { }

	// RVA: 0x75272EC
	private object <.ctor>b__10_0(object e) { }

	// RVA: 0x75273DC
	private object <.ctor>b__10_1(object e) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75284B0
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_PositionXValue; // 0x78
	private object m_PositionYValue; // 0x80
	private object m_PositionZValue; // 0x88
	private object m_SizeXValue; // 0x90
	private object m_SizeYValue; // 0x98
	private object m_SizeZValue; // 0xA0

	// Methods

	// RVA: 0x7528508
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x7528858
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class BoundsIntField
{

	// Fields
	private object m_PositionField; // 0x438
	private object m_SizeField; // 0x440
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10
	public static readonly object positionUssClassName; // 0x18
	public static readonly object sizeUssClassName; // 0x20

	// Methods

	// RVA: 0x7527A7C
	public object .ctor() { }

	// RVA: 0x7527A84
	public object .ctor(object label) { }

	// RVA: 0x7527FD0
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x752811C
	protected override object UpdateMixedValueContent() { }

	// RVA: 0x75281A8
	private static object .cctor() { }

	// RVA: 0x75282E0
	private object <.ctor>b__10_0(object e) { }

	// RVA: 0x75283C8
	private object <.ctor>b__10_1(object e) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7528B94
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Box
{

	// Fields
	public static readonly object ussClassName; // 0x0

	// Methods

	// RVA: 0x7528A58
	public object .ctor() { }

	// RVA: 0x7528B28
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7528FA4
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x7528FFC
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Button
{

	// Fields
	public static readonly object ussClassName; // 0x0
	private object m_Clickable; // 0x498
	private static readonly object NonEmptyString; // 0x8

	// Properties
	public object clickable { get; set; }

	// Methods

	// RVA: 0x7528BEC
	public object get_clickable() { }

	// RVA: 0x7528BF4
	public object set_clickable(object value) { }

	// RVA: 0x7528C64
	public object .ctor() { }

	// RVA: 0x7528C6C
	public object .ctor(object clickEvent) { }

	// RVA: 0x7528DFC
	private object OnNavigationSubmit(object evt) { }

	// RVA: 0x7528E48
	protected internal override object DoMeasure(object desiredWidth, object widthMode, object desiredHeight, object heightMode) { }

	// RVA: 0x7528F1C
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752930C
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x7529364
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class ButtonStripField
{

	// Fields
	private object m_Buttons; // 0x428

	// Methods

	// RVA: 0x7529060
	public object .ctor() { }

	// RVA: 0x7529124
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x75291BC
	private object RefreshButtonsState() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7529CE8
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_XValue; // 0x78
	private object m_YValue; // 0x80
	private object m_WValue; // 0x88
	private object m_HValue; // 0x90

	// Methods

	// RVA: 0x7529D40
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x7529FCC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__0_2; // 0x18
	public static object <>9__0_3; // 0x20
	public static object <>9__0_4; // 0x28
	public static object <>9__0_5; // 0x30
	public static object <>9__0_6; // 0x38
	public static object <>9__0_7; // 0x40

	// Methods

	// RVA: 0x752A144
	private static object .cctor() { }

	// RVA: 0x752A1A4
	public object .ctor() { }

	// RVA: 0x752A1AC
	internal object <DescribeFields>b__0_0(object r) { }

	// RVA: 0x752A1B0
	internal object <DescribeFields>b__0_1(object r, object v) { }

	// RVA: 0x752A1B8
	internal object <DescribeFields>b__0_2(object r) { }

	// RVA: 0x752A1C0
	internal object <DescribeFields>b__0_3(object r, object v) { }

	// RVA: 0x752A1C8
	internal object <DescribeFields>b__0_4(object r) { }

	// RVA: 0x752A1D0
	internal object <DescribeFields>b__0_5(object r, object v) { }

	// RVA: 0x752A1D8
	internal object <DescribeFields>b__0_6(object r) { }

	// RVA: 0x752A1E0
	internal object <DescribeFields>b__0_7(object r, object v) { }

}

// Namespace: UnityEngine.UIElements
public class RectField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Methods

	// RVA: 0x75293BC
	internal override object DescribeFields() { }

	// RVA: 0x7529AB8
	public object .ctor() { }

	// RVA: 0x7529AC0
	public object .ctor(object label) { }

	// RVA: 0x7529C18
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752AB14
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_XValue; // 0x78
	private object m_YValue; // 0x80
	private object m_WValue; // 0x88
	private object m_HValue; // 0x90

	// Methods

	// RVA: 0x752AB6C
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x752ADF0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__0_2; // 0x18
	public static object <>9__0_3; // 0x20
	public static object <>9__0_4; // 0x28
	public static object <>9__0_5; // 0x30
	public static object <>9__0_6; // 0x38
	public static object <>9__0_7; // 0x40

	// Methods

	// RVA: 0x752AF68
	private static object .cctor() { }

	// RVA: 0x752AFC8
	public object .ctor() { }

	// RVA: 0x752AFD0
	internal object <DescribeFields>b__0_0(object r) { }

	// RVA: 0x752AFD8
	internal object <DescribeFields>b__0_1(object r, object v) { }

	// RVA: 0x752AFE0
	internal object <DescribeFields>b__0_2(object r) { }

	// RVA: 0x752AFE8
	internal object <DescribeFields>b__0_3(object r, object v) { }

	// RVA: 0x752AFF0
	internal object <DescribeFields>b__0_4(object r) { }

	// RVA: 0x752AFF8
	internal object <DescribeFields>b__0_5(object r, object v) { }

	// RVA: 0x752B000
	internal object <DescribeFields>b__0_6(object r) { }

	// RVA: 0x752B008
	internal object <DescribeFields>b__0_7(object r, object v) { }

}

// Namespace: UnityEngine.UIElements
public class RectIntField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Methods

	// RVA: 0x752A1E8
	internal override object DescribeFields() { }

	// RVA: 0x752A8E4
	public object .ctor() { }

	// RVA: 0x752A8EC
	public object .ctor(object label) { }

	// RVA: 0x752AA44
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752B60C
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_XValue; // 0x78
	private object m_YValue; // 0x80

	// Methods

	// RVA: 0x752B664
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x752B830
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__0_2; // 0x18
	public static object <>9__0_3; // 0x20

	// Methods

	// RVA: 0x752B920
	private static object .cctor() { }

	// RVA: 0x752B980
	public object .ctor() { }

	// RVA: 0x752B988
	internal object <DescribeFields>b__0_0(object r) { }

	// RVA: 0x752B98C
	internal object <DescribeFields>b__0_1(object r, object v) { }

	// RVA: 0x752B994
	internal object <DescribeFields>b__0_2(object r) { }

	// RVA: 0x752B99C
	internal object <DescribeFields>b__0_3(object r, object v) { }

}

// Namespace: UnityEngine.UIElements
public class Vector2Field
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Methods

	// RVA: 0x752B010
	internal override object DescribeFields() { }

	// RVA: 0x752B3F4
	public object .ctor() { }

	// RVA: 0x752B3FC
	public object .ctor(object label) { }

	// RVA: 0x752B53C
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752BFEC
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_XValue; // 0x78
	private object m_YValue; // 0x80
	private object m_ZValue; // 0x88

	// Methods

	// RVA: 0x752C044
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x752C274
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__0_2; // 0x18
	public static object <>9__0_3; // 0x20
	public static object <>9__0_4; // 0x28
	public static object <>9__0_5; // 0x30

	// Methods

	// RVA: 0x752C3A8
	private static object .cctor() { }

	// RVA: 0x752C408
	public object .ctor() { }

	// RVA: 0x752C410
	internal object <DescribeFields>b__0_0(object r) { }

	// RVA: 0x752C414
	internal object <DescribeFields>b__0_1(object r, object v) { }

	// RVA: 0x752C41C
	internal object <DescribeFields>b__0_2(object r) { }

	// RVA: 0x752C424
	internal object <DescribeFields>b__0_3(object r, object v) { }

	// RVA: 0x752C42C
	internal object <DescribeFields>b__0_4(object r) { }

	// RVA: 0x752C434
	internal object <DescribeFields>b__0_5(object r, object v) { }

}

// Namespace: UnityEngine.UIElements
public class Vector3Field
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Methods

	// RVA: 0x752B9A4
	internal override object DescribeFields() { }

	// RVA: 0x752BF14
	public object .ctor() { }

	// RVA: 0x7526E84
	public object .ctor(object label) { }

	// RVA: 0x752BF1C
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752CD50
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_XValue; // 0x78
	private object m_YValue; // 0x80
	private object m_ZValue; // 0x88
	private object m_WValue; // 0x90

	// Methods

	// RVA: 0x752CDA8
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x752D034
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__0_2; // 0x18
	public static object <>9__0_3; // 0x20
	public static object <>9__0_4; // 0x28
	public static object <>9__0_5; // 0x30
	public static object <>9__0_6; // 0x38
	public static object <>9__0_7; // 0x40

	// Methods

	// RVA: 0x752D1AC
	private static object .cctor() { }

	// RVA: 0x752D20C
	public object .ctor() { }

	// RVA: 0x752D214
	internal object <DescribeFields>b__0_0(object r) { }

	// RVA: 0x752D218
	internal object <DescribeFields>b__0_1(object r, object v) { }

	// RVA: 0x752D220
	internal object <DescribeFields>b__0_2(object r) { }

	// RVA: 0x752D228
	internal object <DescribeFields>b__0_3(object r, object v) { }

	// RVA: 0x752D230
	internal object <DescribeFields>b__0_4(object r) { }

	// RVA: 0x752D238
	internal object <DescribeFields>b__0_5(object r, object v) { }

	// RVA: 0x752D240
	internal object <DescribeFields>b__0_6(object r) { }

	// RVA: 0x752D248
	internal object <DescribeFields>b__0_7(object r, object v) { }

}

// Namespace: UnityEngine.UIElements
public class Vector4Field
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Methods

	// RVA: 0x752C43C
	internal override object DescribeFields() { }

	// RVA: 0x752CB38
	public object .ctor() { }

	// RVA: 0x752CB40
	public object .ctor(object label) { }

	// RVA: 0x752CC80
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752D84C
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_XValue; // 0x78
	private object m_YValue; // 0x80

	// Methods

	// RVA: 0x752D8A4
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x752DA68
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__0_2; // 0x18
	public static object <>9__0_3; // 0x20

	// Methods

	// RVA: 0x752DB58
	private static object .cctor() { }

	// RVA: 0x752DBB8
	public object .ctor() { }

	// RVA: 0x752DBC0
	internal object <DescribeFields>b__0_0(object r) { }

	// RVA: 0x752DBC8
	internal object <DescribeFields>b__0_1(object r, object v) { }

	// RVA: 0x752DBD0
	internal object <DescribeFields>b__0_2(object r) { }

	// RVA: 0x752DBD8
	internal object <DescribeFields>b__0_3(object r, object v) { }

}

// Namespace: UnityEngine.UIElements
public class Vector2IntField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Methods

	// RVA: 0x752D250
	internal override object DescribeFields() { }

	// RVA: 0x752D634
	public object .ctor() { }

	// RVA: 0x752D63C
	public object .ctor(object label) { }

	// RVA: 0x752D77C
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752E228
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_XValue; // 0x78
	private object m_YValue; // 0x80
	private object m_ZValue; // 0x88

	// Methods

	// RVA: 0x752E280
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x752E4A0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10
	public static object <>9__0_2; // 0x18
	public static object <>9__0_3; // 0x20
	public static object <>9__0_4; // 0x28
	public static object <>9__0_5; // 0x30

	// Methods

	// RVA: 0x752E5D4
	private static object .cctor() { }

	// RVA: 0x752E634
	public object .ctor() { }

	// RVA: 0x752E63C
	internal object <DescribeFields>b__0_0(object r) { }

	// RVA: 0x752E644
	internal object <DescribeFields>b__0_1(object r, object v) { }

	// RVA: 0x752E64C
	internal object <DescribeFields>b__0_2(object r) { }

	// RVA: 0x752E654
	internal object <DescribeFields>b__0_3(object r, object v) { }

	// RVA: 0x752E65C
	internal object <DescribeFields>b__0_4(object r) { }

	// RVA: 0x752E664
	internal object <DescribeFields>b__0_5(object r, object v) { }

}

// Namespace: UnityEngine.UIElements
public class Vector3IntField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Methods

	// RVA: 0x752DBE0
	internal override object DescribeFields() { }

	// RVA: 0x752E150
	public object .ctor() { }

	// RVA: 0x7527E90
	public object .ctor(object label) { }

	// RVA: 0x752E158
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752ED90
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x752EDE8
	public object .ctor() { }

}

// Namespace: 
private class DoubleInput
{

	// Properties
	private object parentDoubleField { get; }
	protected override object allowedCharacters { get; }

	// Methods

	// RVA: 0x752EE40
	private object get_parentDoubleField() { }

	// RVA: 0x752EB04
	internal object .ctor() { }

	// RVA: 0x752EEC8
	protected override object get_allowedCharacters() { }

	// RVA: 0x752EF44
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x752F1E0
	protected override object ValueToString(object v) { }

	// RVA: 0x752F238
	protected override object StringToValue(object str) { }

}

// Namespace: UnityEngine.UIElements
public class DoubleField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	private object doubleInput { get; }

	// Methods

	// RVA: 0x752E66C
	private object get_doubleInput() { }

	// RVA: 0x752E6F4
	protected override object ValueToString(object v) { }

	// RVA: 0x752E804
	protected override object StringToValue(object str) { }

	// RVA: 0x752E918
	public object .ctor() { }

	// RVA: 0x752E924
	public object .ctor(object label, object maxLength) { }

	// RVA: 0x752EB9C
	internal override object CanTryParse(object textString) { }

	// RVA: 0x752EBC8
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x752ECC0
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x752F3E8
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Index; // 0x78
	private object m_Choices; // 0x80

	// Methods

	// RVA: 0x752F440
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x752F650
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class DropdownField
{

	// Methods

	// RVA: 0x752F2EC
	public object .ctor() { }

	// RVA: 0x752F368
	public object .ctor(object label) { }

}

// Namespace: UnityEngine.UIElements
internal static class EnumFieldHelpers
{

	// Fields
	internal static readonly object type; // 0x0
	internal static readonly object value; // 0x8
	internal static readonly object includeObsoleteValues; // 0x10

	// Methods

	// RVA: 0x752F754
	internal static object ExtractValue(object bag, object cc, object resEnumType, object resEnumValue, object resIncludeObsoleteValues) { }

	// RVA: 0x752FB8C
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75314C4
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Type; // 0x78
	private object m_Value; // 0x80
	private object m_IncludeObsoleteValues; // 0x88

	// Methods

	// RVA: 0x753151C
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x7531814
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__22_0; // 0x8

	// Methods

	// RVA: 0x75318A4
	private static object .cctor() { }

	// RVA: 0x7531904
	public object .ctor() { }

	// RVA: 0x753190C
	internal object <.ctor>b__22_0(object e) { }

}

// Namespace: UnityEngine.UIElements
public class EnumField
{

	// Fields
	private object m_EnumType; // 0x428
	private object m_IncludeObsoleteValues; // 0x430
	private object m_TextElement; // 0x438
	private object m_ArrowElement; // 0x440
	private object m_EnumData; // 0x448
	internal object createMenuCallback; // 0x488
	public static readonly object ussClassName; // 0x0
	public static readonly object textUssClassName; // 0x8
	public static readonly object arrowUssClassName; // 0x10
	public static readonly object labelUssClassName; // 0x18
	public static readonly object inputUssClassName; // 0x20

	// Properties
	internal object includeObsoleteValues { get; }

	// Methods

	// RVA: 0x752FD18
	internal object get_includeObsoleteValues() { }

	// RVA: 0x752FD20
	private object Initialize(object defaultValue) { }

	// RVA: 0x752FEF8
	public object .ctor() { }

	// RVA: 0x752FF04
	public object .ctor(object label, object defaultValue) { }

	// RVA: 0x752FEF0
	public object Init(object defaultValue) { }

	// RVA: 0x753026C
	public object Init(object defaultValue, object includeObsoleteValues) { }

	// RVA: 0x7530408
	internal object PopulateDataFromType(object enumType) { }

	// RVA: 0x75305D4
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x75304A4
	private object UpdateValueLabel(object value) { }

	// RVA: 0x75306CC
	private object OnPointerDownEvent(object evt) { }

	// RVA: 0x753072C
	private object OnPointerMoveEvent(object evt) { }

	// RVA: 0x75307D0
	private object ContainsPointer(object pointerId) { }

	// RVA: -1
	private object ProcessPointerDown(object evt) { }

	// RVA: 0x7530874
	private object OnNavigationSubmit(object evt) { }

	// RVA: 0x75308AC
	private object ShowMenu() { }

	// RVA: 0x75310BC
	private object ChangeValueFromMenu(object menuItem) { }

	// RVA: 0x753117C
	protected override object UpdateMixedValueContent() { }

	// RVA: 0x75312CC
	private static object .cctor() { }

	// RVA: 0x7531404
	private object <ShowMenu>b__33_0(object contentView) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7532098
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75320F0
	public object .ctor() { }

}

// Namespace: 
private class FloatInput
{

	// Properties
	private object parentFloatField { get; }
	protected override object allowedCharacters { get; }

	// Methods

	// RVA: 0x7532148
	private object get_parentFloatField() { }

	// RVA: 0x7531E0C
	internal object .ctor() { }

	// RVA: 0x75321D0
	protected override object get_allowedCharacters() { }

	// RVA: 0x753224C
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x7532518
	protected override object ValueToString(object v) { }

	// RVA: 0x7532570
	protected override object StringToValue(object str) { }

}

// Namespace: UnityEngine.UIElements
public class FloatField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	private object floatInput { get; }

	// Methods

	// RVA: 0x7531974
	private object get_floatInput() { }

	// RVA: 0x75319FC
	protected override object ValueToString(object v) { }

	// RVA: 0x7531B0C
	protected override object StringToValue(object str) { }

	// RVA: 0x7531C20
	public object .ctor() { }

	// RVA: 0x7531C2C
	public object .ctor(object label, object maxLength) { }

	// RVA: 0x7531EA4
	internal override object CanTryParse(object textString) { }

	// RVA: 0x7531ED0
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x7531FC8
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75333AC
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Text; // 0x70
	private object m_Value; // 0x78

	// Methods

	// RVA: 0x7533404
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x7533594
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Foldout
{

	// Fields
	private object m_Toggle; // 0x3D0
	private object m_Container; // 0x3D8
	private object m_Value; // 0x3E0
	public static readonly object ussClassName; // 0x0
	public static readonly object toggleUssClassName; // 0x8
	public static readonly object contentUssClassName; // 0x10
	public static readonly object inputUssClassName; // 0x18
	public static readonly object checkmarkUssClassName; // 0x20
	public static readonly object textUssClassName; // 0x28
	internal static readonly object toggleInspectorUssClassName; // 0x30
	internal static readonly object ussFoldoutDepthClassName; // 0x38
	internal static readonly object ussFoldoutMaxDepth; // 0x40

	// Properties
	public override object contentContainer { get; }
	public object text { set; }
	public object value { get; set; }

	// Methods

	// RVA: 0x7532624
	public override object get_contentContainer() { }

	// RVA: 0x753262C
	public object set_text(object value) { }

	// RVA: 0x75327A4
	public object get_value() { }

	// RVA: 0x75327AC
	public object set_value(object value) { }

	// RVA: 0x75329AC
	public object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x7532B64
	internal override object OnViewDataReady() { }

	// RVA: 0x7532BB0
	public object .ctor() { }

	// RVA: 0x7532F60
	private object OnAttachToPanel(object evt) { }

	// RVA: 0x753314C
	private static object .cctor() { }

	// RVA: 0x7533324
	private object <.ctor>b__26_0(object evt) { }

}

// Namespace: UnityEngine.UIElements
internal interface IGenericMenu
{

	// Methods

	// RVA: -1
	public abstract object AddItem(object itemName, object isChecked, object action) { }

	// RVA: -1
	public abstract object AddItem(object itemName, object isChecked, object action, object data) { }

	// RVA: -1
	public abstract object DropDown(object position, object targetElement, object anchored) { }

}

// Namespace: 
internal class MenuItem
{

	// Fields
	public object name; // 0x8
	public object element; // 0x10
	public object action; // 0x18
	public object actionUserData; // 0x20

	// Methods

	// RVA: 0x7535530
	public object .ctor() { }

}

// Namespace: 
private struct <>c__DisplayClass39_0
{

	// Fields
	public object <>4__this; // 0xFFFFFFFFFFFFFFF8
	public object selectedIndex; // 0x0
}

// Namespace: UnityEngine.UIElements
public class GenericDropdownMenu
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object itemUssClassName; // 0x8
	public static readonly object labelUssClassName; // 0x10
	public static readonly object containerInnerUssClassName; // 0x18
	public static readonly object containerOuterUssClassName; // 0x20
	public static readonly object checkmarkUssClassName; // 0x28
	public static readonly object separatorUssClassName; // 0x30
	private object m_Items; // 0x8
	private object m_MenuContainer; // 0x10
	private object m_OuterContainer; // 0x18
	private object m_ScrollView; // 0x20
	private object m_PanelRootVisualContainer; // 0x28
	private object m_TargetElement; // 0x30
	private object m_DesiredRect; // 0x38
	private object m_NavigationManipulator; // 0x48
	private object <isSingleSelectionDropdown>k__BackingField; // 0x50
	private object <closeOnParentResize>k__BackingField; // 0x51
	private object m_MousePosition; // 0x54

	// Properties
	internal object isSingleSelectionDropdown { get; set; }
	internal object closeOnParentResize { get; set; }
	public object contentContainer { get; }

	// Methods

	// RVA: 0x7533698
	internal object get_isSingleSelectionDropdown() { }

	// RVA: 0x75336A0
	internal object set_isSingleSelectionDropdown(object value) { }

	// RVA: 0x75336A8
	internal object get_closeOnParentResize() { }

	// RVA: 0x75336B0
	internal object set_closeOnParentResize(object value) { }

	// RVA: 0x75336B8
	public object get_contentContainer() { }

	// RVA: 0x7530D4C
	public object .ctor() { }

	// RVA: 0x7533708
	private object OnAttachToPanel(object evt) { }

	// RVA: 0x7533BB4
	private object OnDetachFromPanel(object evt) { }

	// RVA: 0x7533FD8
	private object Hide(object giveFocusBack) { }

	// RVA: 0x7534084
	private object Apply(object op, object sourceEvent) { }

	// RVA: 0x75340D8
	private object Apply(object op) { }

	// RVA: 0x75345B4
	private object OnPointerDown(object evt) { }

	// RVA: 0x75348F0
	private object OnPointerMove(object evt) { }

	// RVA: 0x7534A70
	private object OnPointerUp(object evt) { }

	// RVA: 0x7534C1C
	private object OnFocusOut(object evt) { }

	// RVA: 0x7534E34
	private object OnParentResized(object evt) { }

	// RVA: 0x7534734
	private object UpdateSelection(object target) { }

	// RVA: 0x7534E4C
	private object ChangeSelectedIndex(object newIndex, object previousIndex) { }

	// RVA: 0x7534330
	private object GetSelectedIndex() { }

	// RVA: 0x7534FF4
	public object AddItem(object itemName, object isChecked, object action) { }

	// RVA: 0x7535434
	public object AddItem(object itemName, object isChecked, object action, object data) { }

	// RVA: 0x7535460
	public object AddSeparator(object path) { }

	// RVA: 0x7535024
	private object AddItem(object itemName, object isChecked, object isEnabled, object data) { }

	// RVA: 0x7535538
	public object DropDown(object position, object targetElement, object anchored) { }

	// RVA: 0x7536814
	private object OnTargetElementDetachFromPanel(object evt) { }

	// RVA: 0x7536874
	private object OnContainerGeometryChanged(object evt) { }

	// RVA: 0x75360DC
	private object EnsureVisibilityInParent() { }

	// RVA: 0x7536878
	private static object .cctor() { }

	// RVA: 0x75344D0
	private object <Apply>g__UpdateSelectionDown|39_0(object newIndex, object ) { }

	// RVA: 0x75343FC
	private object <Apply>g__UpdateSelectionUp|39_1(object newIndex, object ) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7536D10
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Text; // 0x70

	// Methods

	// RVA: 0x7536D68
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x7536E98
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class GroupBox
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	private object m_TitleLabel; // 0x3D0

	// Properties
	public object text { set; }

	// Methods

	// RVA: 0x7536A18
	public object set_text(object value) { }

	// RVA: 0x7536B5C
	public object .ctor() { }

	// RVA: 0x7536BE4
	public object .ctor(object text) { }

	// RVA: 0x7536C70
	private object UnityEngine.UIElements.IGroupBox.OnOptionAdded(object option) { }

	// RVA: 0x7536C74
	private object UnityEngine.UIElements.IGroupBox.OnOptionRemoved(object option) { }

	// RVA: 0x7536C78
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7537B68
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x7537BC0
	public object .ctor() { }

}

// Namespace: 
private class Hash128Input
{

	// Properties
	protected object allowedCharacters { get; }

	// Methods

	// RVA: 0x75370E4
	internal object .ctor() { }

	// RVA: 0x7537C18
	protected object get_allowedCharacters() { }

	// RVA: 0x7537C5C
	internal override object AcceptCharacter(object c) { }

	// RVA: 0x7537D20
	protected override object StringToValue(object str) { }

	// RVA: 0x7537770
	internal static object Parse(object str) { }

}

// Namespace: UnityEngine.UIElements
public class Hash128Field
{

	// Fields
	internal object m_UpdateTextFromValue; // 0x448
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	public override object value { get; set; }

	// Methods

	// RVA: 0x7536F30
	public object .ctor() { }

	// RVA: 0x7536F3C
	public object .ctor(object label, object maxLength) { }

	// RVA: 0x7537278
	public override object get_value() { }

	// RVA: 0x75372D0
	public override object set_value(object value) { }

	// RVA: 0x75373D8
	internal override object UpdateValueFromText() { }

	// RVA: 0x7537500
	internal override object UpdateTextFromValue() { }

	// RVA: 0x75375B0
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x75376B8
	protected override object ValueToString(object value) { }

	// RVA: 0x75376E0
	protected override object StringToValue(object str) { }

	// RVA: 0x7537800
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: 0x7537A98
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public enum HelpBoxMessageType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Info;
	public const object Warning;
	public const object Error;
}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75383A4
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Text; // 0x68
	private object m_MessageType; // 0x70

	// Methods

	// RVA: 0x75383FC
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75385D4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class HelpBox
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object iconUssClassName; // 0x10
	public static readonly object iconInfoUssClassName; // 0x18
	public static readonly object iconwarningUssClassName; // 0x20
	public static readonly object iconErrorUssClassName; // 0x28
	private object m_HelpBoxMessageType; // 0x3C0
	private object m_Icon; // 0x3C8
	private object m_IconClass; // 0x3D0
	private object m_Label; // 0x3D8

	// Properties
	public object text { set; }
	public object messageType { set; }

	// Methods

	// RVA: 0x7537DB0
	public object set_text(object value) { }

	// RVA: 0x7537E08
	public object set_messageType(object value) { }

	// RVA: 0x7537FA8
	public object .ctor() { }

	// RVA: 0x753800C
	public object .ctor(object text, object messageType) { }

	// RVA: 0x7538174
	private object GetIconClass(object messageType) { }

	// RVA: 0x7537E20
	private object UpdateIcon(object messageType) { }

	// RVA: 0x7538240
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x753A298
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x753A2F0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Image
{

	// Fields
	private object m_ScaleMode; // 0x3C0
	private object m_Image; // 0x3C8
	private object m_Sprite; // 0x3D0
	private object m_VectorImage; // 0x3D8
	private object m_UV; // 0x3E0
	private object m_TintColor; // 0x3F0
	internal object m_ImageIsInline; // 0x400
	private object m_ScaleModeIsInline; // 0x401
	private object m_TintColorIsInline; // 0x402
	public static readonly object ussClassName; // 0x0
	private static object s_ImageProperty; // 0x8
	private static object s_SpriteProperty; // 0x10
	private static object s_VectorImageProperty; // 0x18
	private static object s_ScaleModeProperty; // 0x20
	private static object s_TintColorProperty; // 0x28

	// Properties
	public object image { get; set; }
	public object sprite { get; set; }
	public object vectorImage { get; set; }
	public object sourceRect { get; }
	public object uv { get; set; }
	public object scaleMode { get; }
	public object tintColor { get; }

	// Methods

	// RVA: 0x75386E8
	public object get_image() { }

	// RVA: 0x75386F0
	public object set_image(object value) { }

	// RVA: 0x75387F8
	public object get_sprite() { }

	// RVA: 0x7538800
	public object set_sprite(object value) { }

	// RVA: 0x7538908
	public object get_vectorImage() { }

	// RVA: 0x7538910
	public object set_vectorImage(object value) { }

	// RVA: 0x7538A18
	public object get_sourceRect() { }

	// RVA: 0x7538C18
	public object get_uv() { }

	// RVA: 0x7538C2C
	public object set_uv(object value) { }

	// RVA: 0x7538C68
	public object get_scaleMode() { }

	// RVA: 0x7538C70
	public object get_tintColor() { }

	// RVA: 0x7538C84
	public object .ctor() { }

	// RVA: 0x7538E4C
	private object GetTextureDisplaySize(object texture) { }

	// RVA: 0x7538F94
	private object GetTextureDisplaySize(object sprite) { }

	// RVA: 0x75390F4
	protected internal override object DoMeasure(object desiredWidth, object widthMode, object desiredHeight, object heightMode) { }

	// RVA: 0x75393AC
	private object OnGenerateVisualContent(object mgc) { }

	// RVA: 0x75399C8
	private object OnCustomStyleResolved(object e) { }

	// RVA: 0x7539A08
	private object ReadCustomProperties(object customStyleProvider) { }

	// RVA: -1
	private object SetProperty(object src, object dst, object alt0, object alt1) { }

	// RVA: 0x7539FE4
	private object ClearProperty() { }

	// RVA: 0x753A028
	private object SetScaleMode(object mode) { }

	// RVA: 0x753A048
	private object SetTintColor(object color) { }

	// RVA: 0x7538A1C
	private object GetSourceRect() { }

	// RVA: 0x753A0B8
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public interface INotifyValueChanged<T0>
{

	// Properties
	public abstract object value { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_value() { }

	// RVA: -1
	public abstract object set_value(object value) { }

	// RVA: -1
	public abstract object SetValueWithoutNotify(object newValue) { }

}

// Namespace: UnityEngine.UIElements
public static class INotifyValueChangedExtensions
{

	// Methods

	// RVA: -1
	public static object RegisterValueChangedCallback(object control, object callback) { }

	// RVA: -1
	public static object UnregisterValueChangedCallback(object control, object callback) { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Label; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public override object Init(object ve, object bag, object cc) { }

	// RVA: -1
	internal static object ParseChoiceList(object choicesFromBag) { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseField<T0>
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x0
	public static readonly object inputUssClassName; // 0x0
	public static readonly object noLabelVariantUssClassName; // 0x0
	public static readonly object labelDraggerVariantUssClassName; // 0x0
	public static readonly object mixedValueLabelUssClassName; // 0x0
	public static readonly object alignedFieldUssClassName; // 0x0
	private static readonly object inspectorFieldUssClassName; // 0x0
	protected internal static readonly object mixedValueString; // 0x0
	protected internal static readonly object serializedPropertyCopyName; // 0x0
	private static object s_LabelWidthRatioProperty; // 0x0
	private static object s_LabelExtraPaddingProperty; // 0x0
	private static object s_LabelBaseMinWidthProperty; // 0x0
	private static object s_LabelExtraContextWidthProperty; // 0x0
	private object m_LabelWidthRatio; // 0x0
	private object m_LabelExtraPadding; // 0x0
	private object m_LabelBaseMinWidth; // 0x0
	private object m_LabelExtraContextWidth; // 0x0
	private object m_VisualInput; // 0x0
	private object m_Value; // 0x0
	private object onValidateValue; // 0x0
	private object <labelElement>k__BackingField; // 0x0
	private object m_ShowMixedValue; // 0x0
	private object m_MixedValueLabel; // 0x0
	private object m_SkipValidation; // 0x0
	private object m_CachedContextWidthElement; // 0x0
	private object m_CachedInspectorElement; // 0x0

	// Properties
	internal object visualInput { get; set; }
	protected object rawValue { get; set; }
	public virtual object value { get; set; }
	public object labelElement { get; set; }
	public object label { get; set; }
	public object showMixedValue { get; set; }
	protected object mixedValueLabel { get; }

	// Methods

	// RVA: -1
	internal object get_visualInput() { }

	// RVA: -1
	internal object set_visualInput(object value) { }

	// RVA: -1
	protected object get_rawValue() { }

	// RVA: -1
	protected object set_rawValue(object value) { }

	// RVA: -1
	internal object add_onValidateValue(object value) { }

	// RVA: -1
	internal object remove_onValidateValue(object value) { }

	// RVA: -1
	public virtual object get_value() { }

	// RVA: -1
	public virtual object set_value(object value) { }

	// RVA: -1
	public object get_labelElement() { }

	// RVA: -1
	private object set_labelElement(object value) { }

	// RVA: -1
	public object get_label() { }

	// RVA: -1
	public object set_label(object value) { }

	// RVA: -1
	public object get_showMixedValue() { }

	// RVA: -1
	public object set_showMixedValue(object value) { }

	// RVA: -1
	protected object get_mixedValueLabel() { }

	// RVA: -1
	internal object .ctor(object label) { }

	// RVA: -1
	protected object .ctor(object label, object visualInput) { }

	// RVA: -1
	private object OnAttachToPanel(object e) { }

	// RVA: -1
	private object OnDetachFromPanel(object e) { }

	// RVA: -1
	private object OnCustomStyleResolved(object evt) { }

	// RVA: -1
	private object OnInspectorFieldGeometryChanged(object e) { }

	// RVA: -1
	private object AlignLabel() { }

	// RVA: -1
	internal object ValidatedValue(object value) { }

	// RVA: -1
	protected virtual object UpdateMixedValueContent() { }

	// RVA: -1
	public virtual object SetValueWithoutNotify(object newValue) { }

	// RVA: -1
	internal override object OnViewDataReady() { }

	// RVA: -1
	internal override object GetTooltipRect() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public class BaseFieldTraits<T0, T1>
{

	// Fields
	private object m_Value; // 0x0

	// Methods

	// RVA: -1
	public override object Init(object ve, object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class KeyboardTextEditorEventHandler
{

	// Fields
	private readonly object m_ImguiEvent; // 0x18
	internal object m_Changed; // 0x20

	// Methods

	// RVA: 0x753A2F8
	public object .ctor(object textElement, object editingUtilities) { }

	// RVA: 0x753A454
	public override object ExecuteDefaultActionAtTarget(object evt) { }

	// RVA: 0x753A740
	private object OnFocus(object _) { }

	// RVA: 0x753A84C
	private object OnBlur(object _) { }

	// RVA: 0x753A858
	private object OnKeyDown(object evt) { }

	// RVA: 0x753B83C
	private object UpdateLabel() { }

	// RVA: 0x753B194
	private object OnValidateCommandEvent(object evt) { }

	// RVA: 0x753B42C
	private object OnExecuteCommandEvent(object evt) { }

	// RVA: -1
	private object OnNavigationEvent(object evt) { }

}

// Namespace: UnityEngine.UIElements
internal class TextEditorEventHandler
{

	// Fields
	protected object textElement; // 0x8
	protected object editingUtilities; // 0x10

	// Methods

	// RVA: 0x75A79C8
	protected object .ctor(object textElement, object editingUtilities) { }

	// RVA: 0x75A7A00
	public virtual object ExecuteDefaultActionAtTarget(object evt) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75A8848
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private static readonly object k_Value; // 0x0
	private object m_Multiline; // 0xC0

	// Methods

	// RVA: 0x75A88A0
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75A8B1C
	public object .ctor() { }

	// RVA: 0x75A8BC8
	private static object .cctor() { }

}

// Namespace: 
private class TextInput
{

	// Properties
	public object multiline { set; }
	public override object isPasswordField { set; }

	// Methods

	// RVA: 0x75A7B34
	public object set_multiline(object value) { }

	// RVA: 0x75A8CD0
	public override object set_isPasswordField(object value) { }

	// RVA: 0x75A8D4C
	protected override object StringToValue(object str) { }

	// RVA: 0x75A80F4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class TextField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	private object textInput { get; }
	public object multiline { set; }
	public override object value { get; set; }

	// Methods

	// RVA: 0x75A7A04
	private object get_textInput() { }

	// RVA: 0x75A7A8C
	public object set_multiline(object value) { }

	// RVA: 0x75A7DF0
	public object .ctor() { }

	// RVA: 0x75A7E08
	public object .ctor(object label) { }

	// RVA: 0x75A7E1C
	public object .ctor(object label, object maxLength, object multiline, object isPasswordField, object maskChar) { }

	// RVA: 0x75A8198
	public override object get_value() { }

	// RVA: 0x75A81F0
	public override object set_value(object value) { }

	// RVA: 0x75A8338
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x75A84FC
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: 0x75A86A8
	internal override object OnViewDataReady() { }

	// RVA: 0x75A8768
	protected override object ValueToString(object value) { }

	// RVA: 0x75A8770
	protected override object StringToValue(object str) { }

	// RVA: 0x75A8778
	private static object .cctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_MaxLength; // 0x0
	private object m_Password; // 0x0
	private object m_MaskCharacter; // 0x0
	private object m_IsReadOnly; // 0x0
	private object m_IsDelayed; // 0x0
	private object m_HideMobileInput; // 0x0
	private object m_KeyboardType; // 0x0
	private object m_AutoCorrection; // 0x0

	// Methods

	// RVA: -1
	public override object Init(object ve, object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
protected internal abstract class TextInputBase
{

	// Fields
	private object <textElement>k__BackingField; // 0x0
	internal object scrollView; // 0x0
	internal object multilineContainer; // 0x0
	public static readonly object innerComponentsModifierName; // 0x0
	public static readonly object innerTextElementUssClassName; // 0x0
	internal static readonly object innerTextElementWithScrollViewUssClassName; // 0x0
	public static readonly object horizontalVariantInnerTextElementUssClassName; // 0x0
	public static readonly object verticalVariantInnerTextElementUssClassName; // 0x0
	public static readonly object verticalHorizontalVariantInnerTextElementUssClassName; // 0x0
	public static readonly object innerScrollviewUssClassName; // 0x0
	public static readonly object innerViewportUssClassName; // 0x0
	public static readonly object innerContentContainerUssClassName; // 0x0
	private object <isDragging>k__BackingField; // 0x0
	internal object scrollOffset; // 0x0
	private object m_ScrollViewWasClamped; // 0x0
	private object lastCursorPos; // 0x0
	private object m_VerticalScrollerVisibility; // 0x0

	// Properties
	internal object textElement { get; set; }
	public object textSelection { get; }
	public object textEdition { get; }
	internal object originalText { get; }
	public object isReadOnly { get; }
	public object maxLength { set; }
	public object maskChar { set; }
	public virtual object isPasswordField { get; set; }
	internal object isDragging { set; }
	public object text { get; set; }

	// Methods

	// RVA: -1
	internal object get_textElement() { }

	// RVA: -1
	private object set_textElement(object value) { }

	// RVA: -1
	public object get_textSelection() { }

	// RVA: -1
	public object get_textEdition() { }

	// RVA: -1
	public object SelectAll() { }

	// RVA: -1
	internal object SelectNone() { }

	// RVA: -1
	internal object get_originalText() { }

	// RVA: -1
	protected virtual object StringToValue(object str) { }

	// RVA: -1
	internal object UpdateValueFromText() { }

	// RVA: -1
	internal object UpdateTextFromValue() { }

	// RVA: -1
	internal object MoveFocusToCompositeRoot() { }

	// RVA: -1
	public object get_isReadOnly() { }

	// RVA: -1
	public object set_maxLength(object value) { }

	// RVA: -1
	public object set_maskChar(object value) { }

	// RVA: -1
	public virtual object get_isPasswordField() { }

	// RVA: -1
	public virtual object set_isPasswordField(object value) { }

	// RVA: -1
	internal object set_isDragging(object value) { }

	// RVA: -1
	public object get_text() { }

	// RVA: -1
	public object set_text(object value) { }

	// RVA: -1
	internal object .ctor() { }

	// RVA: -1
	private object MakeSureScrollViewDoesNotLeakEvents(object evt) { }

	// RVA: -1
	internal object SetSingleLine() { }

	// RVA: -1
	internal object SetMultiline() { }

	// RVA: -1
	private object ScrollViewOnGeometryChangedEvent(object e) { }

	// RVA: -1
	private object TextElementOnGeometryChangedEvent(object e) { }

	// RVA: -1
	internal object OnInputCustomStyleResolved(object e) { }

	// RVA: -1
	internal virtual object AcceptCharacter(object c) { }

	// RVA: -1
	internal object UpdateScrollOffset(object isBackspace) { }

	// RVA: -1
	internal object UpdateScrollOffset(object isBackspace, object widthChanged) { }

	// RVA: -1
	private object GetScrollOffset(object xOffset, object yOffset, object contentViewportWidth, object isBackspace, object widthChanged) { }

	// RVA: -1
	internal object SetScrollViewMode() { }

	// RVA: -1
	private object SetMultilineContainerStyle() { }

	// RVA: -1
	private object RemoveSingleLineComponents() { }

	// RVA: -1
	private object RemoveMultilineComponents() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class TextInputBaseField<T0>
{

	// Fields
	private static object s_SelectionColorProperty; // 0x0
	private static object s_CursorColorProperty; // 0x0
	private object m_VisualInputTabIndex; // 0x0
	private object m_TextInputBase; // 0x0
	internal const object kMaxLengthNone;
	internal const object kMaskCharDefault;
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x0
	public static readonly object inputUssClassName; // 0x0
	internal static readonly object multilineContainerClassName; // 0x0
	public static readonly object singleLineInputUssClassName; // 0x0
	public static readonly object multilineInputUssClassName; // 0x0
	internal static readonly object multilineInputWithScrollViewUssClassName; // 0x0
	public static readonly object textInputUssName; // 0x0
	private object onIsReadOnlyChanged; // 0x0

	// Properties
	protected internal object textInputBase { get; }
	public object text { get; set; }
	public object isReadOnly { get; set; }
	public object isPasswordField { set; }
	public object autoCorrection { set; }
	public object hideMobileInput { set; }
	public object keyboardType { set; }
	public object textEdition { get; }
	public object maxLength { set; }
	public object isDelayed { get; set; }
	public object maskChar { set; }

	// Methods

	// RVA: -1
	protected internal object get_textInputBase() { }

	// RVA: -1
	public object get_text() { }

	// RVA: -1
	protected object set_text(object value) { }

	// RVA: -1
	protected object add_onIsReadOnlyChanged(object value) { }

	// RVA: -1
	protected object remove_onIsReadOnlyChanged(object value) { }

	// RVA: -1
	public object get_isReadOnly() { }

	// RVA: -1
	public object set_isReadOnly(object value) { }

	// RVA: -1
	public object set_isPasswordField(object value) { }

	// RVA: -1
	public object set_autoCorrection(object value) { }

	// RVA: -1
	public object set_hideMobileInput(object value) { }

	// RVA: -1
	public object set_keyboardType(object value) { }

	// RVA: -1
	public object get_textEdition() { }

	// RVA: -1
	public object set_maxLength(object value) { }

	// RVA: -1
	public object get_isDelayed() { }

	// RVA: -1
	public object set_isDelayed(object value) { }

	// RVA: -1
	public object set_maskChar(object value) { }

	// RVA: -1
	protected abstract object ValueToString(object value) { }

	// RVA: -1
	protected abstract object StringToValue(object str) { }

	// RVA: -1
	protected object .ctor(object label, object maxLength, object maskChar, object textInputBase) { }

	// RVA: -1
	private object OnFieldCustomStyleResolved(object e) { }

	// RVA: -1
	protected override object ExecuteDefaultActionAtTarget(object evt) { }

	// RVA: -1
	protected override object UpdateMixedValueContent() { }

	// RVA: -1
	internal virtual object UpdateValueFromText() { }

	// RVA: -1
	internal virtual object UpdateTextFromValue() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class TouchScreenTextEditorEventHandler
{

	// Fields
	private object m_TouchKeyboardPoller; // 0x18
	private object m_TouchKeyboardAllowsInPlaceEditing; // 0x20
	private object m_IsClicking; // 0x21

	// Methods

	// RVA: 0x75A8D54
	public object .ctor(object textElement, object editingUtilities) { }

	// RVA: 0x75A8D94
	private object PollTouchScreenKeyboard() { }

	// RVA: 0x75A9040
	private object DoPollTouchScreenKeyboard() { }

	// RVA: 0x75A9B24
	private object UpdateStringPositionFromKeyboard() { }

	// RVA: 0x75A99F0
	private object CloseTouchScreenKeyboard() { }

	// RVA: 0x75A9E94
	private object OpenTouchScreenKeyboard() { }

	// RVA: 0x75AA564
	public override object ExecuteDefaultActionAtTarget(object evt) { }

	// RVA: 0x75AA7BC
	private object OnPointerDownEvent() { }

	// RVA: 0x75AAA50
	private object OnPointerUpEvent(object evt) { }

	// RVA: 0x75AAA78
	private object OnFocusInEvent() { }

	// RVA: 0x75AACA8
	private object OnFocusOutEvent(object evt) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75ABC20
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75ABC78
	public object .ctor() { }

}

// Namespace: 
private class IntegerInput
{

	// Properties
	private object parentIntegerField { get; }
	protected override object allowedCharacters { get; }

	// Methods

	// RVA: 0x75ABCD0
	private object get_parentIntegerField() { }

	// RVA: 0x75AB994
	internal object .ctor() { }

	// RVA: 0x75ABD58
	protected override object get_allowedCharacters() { }

	// RVA: 0x75ABDD4
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75AC150
	protected override object ValueToString(object v) { }

	// RVA: 0x75AC1A8
	protected override object StringToValue(object str) { }

}

// Namespace: UnityEngine.UIElements
public class IntegerField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	private object integerInput { get; }

	// Methods

	// RVA: 0x75AB4FC
	private object get_integerInput() { }

	// RVA: 0x75AB584
	protected override object ValueToString(object v) { }

	// RVA: 0x75AB694
	protected override object StringToValue(object str) { }

	// RVA: 0x75AB7A8
	public object .ctor() { }

	// RVA: 0x75AB7B4
	public object .ctor(object label, object maxLength) { }

	// RVA: 0x75ABA2C
	internal override object CanTryParse(object textString) { }

	// RVA: 0x75ABA58
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75ABB50
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75AC428
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75AC480
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Label
{

	// Fields
	public static readonly object ussClassName; // 0x0

	// Methods

	// RVA: 0x75AC25C
	public object .ctor() { }

	// RVA: 0x75AC2BC
	public object .ctor(object text) { }

	// RVA: 0x75AC3BC
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75AC5C0
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75AC618
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class ListView
{

	// Fields
	private object m_MakeItem; // 0x528
	private object m_BindItem; // 0x530
	private object <unbindItem>k__BackingField; // 0x538
	private object <destroyItem>k__BackingField; // 0x540

	// Properties
	public object makeItem { get; }
	public object bindItem { get; }
	public object unbindItem { get; }
	public object destroyItem { get; }

	// Methods

	// RVA: 0x75AC488
	public object get_makeItem() { }

	// RVA: 0x75AC490
	public object get_bindItem() { }

	// RVA: 0x75AC498
	public object get_unbindItem() { }

	// RVA: 0x75AC4A0
	public object get_destroyItem() { }

	// RVA: 0x75AC4A8
	internal override object HasValidDataAndBindings() { }

	// RVA: 0x75AC4EC
	protected override object CreateViewController() { }

	// RVA: 0x75AC544
	public object .ctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75ACD44
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75ACD9C
	public object .ctor() { }

}

// Namespace: 
private class LongInput
{

	// Properties
	private object parentLongField { get; }
	protected override object allowedCharacters { get; }

	// Methods

	// RVA: 0x75ACDF4
	private object get_parentLongField() { }

	// RVA: 0x75ACAB8
	internal object .ctor() { }

	// RVA: 0x75ACE7C
	protected override object get_allowedCharacters() { }

	// RVA: 0x75ACEF8
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75AD2AC
	private object ClampMinMaxLongValue(object niceDelta, object value) { }

	// RVA: 0x75AD34C
	protected override object ValueToString(object v) { }

	// RVA: 0x75AD3A4
	protected override object StringToValue(object str) { }

}

// Namespace: UnityEngine.UIElements
public class LongField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	private object longInput { get; }

	// Methods

	// RVA: 0x75AC620
	private object get_longInput() { }

	// RVA: 0x75AC6A8
	protected override object ValueToString(object v) { }

	// RVA: 0x75AC7B8
	protected override object StringToValue(object str) { }

	// RVA: 0x75AC8CC
	public object .ctor() { }

	// RVA: 0x75AC8D8
	public object .ctor(object label, object maxLength) { }

	// RVA: 0x75ACB50
	internal override object CanTryParse(object textString) { }

	// RVA: 0x75ACB7C
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75ACC74
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75B0CA8
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_MinValue; // 0x78
	private object m_MaxValue; // 0x80
	private object m_LowLimit; // 0x88
	private object m_HighLimit; // 0x90

	// Methods

	// RVA: 0x75B0D00
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75B0F84
	public object .ctor() { }

}

// Namespace: 
private enum DragState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoThumb;
	public const object MinThumb;
	public const object MiddleThumb;
	public const object MaxThumb;
}

// Namespace: UnityEngine.UIElements
public class MinMaxSlider
{

	// Fields
	private object <dragElement>k__BackingField; // 0x428
	private object <dragMinThumb>k__BackingField; // 0x430
	private object <dragMaxThumb>k__BackingField; // 0x438
	private object <clampedDragger>k__BackingField; // 0x440
	private object m_DragElementStartPos; // 0x448
	private object m_ValueStartPos; // 0x450
	private object m_DragMinThumbRect; // 0x458
	private object m_DragMaxThumbRect; // 0x468
	private object m_DragState; // 0x478
	private object m_MinLimit; // 0x47C
	private object m_MaxLimit; // 0x480
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10
	public static readonly object trackerUssClassName; // 0x18
	public static readonly object draggerUssClassName; // 0x20
	public static readonly object minThumbUssClassName; // 0x28
	public static readonly object maxThumbUssClassName; // 0x30

	// Properties
	internal object dragElement { get; set; }
	internal object dragMinThumb { get; set; }
	internal object dragMaxThumb { get; set; }
	internal object clampedDragger { get; set; }
	public object minValue { get; set; }
	public object maxValue { get; set; }
	public override object value { get; set; }
	public object lowLimit { get; set; }
	public object highLimit { get; set; }

	// Methods

	// RVA: 0x75AD458
	internal object get_dragElement() { }

	// RVA: 0x75AD460
	private object set_dragElement(object value) { }

	// RVA: 0x75AD468
	internal object get_dragMinThumb() { }

	// RVA: 0x75AD470
	private object set_dragMinThumb(object value) { }

	// RVA: 0x75AD478
	internal object get_dragMaxThumb() { }

	// RVA: 0x75AD480
	private object set_dragMaxThumb(object value) { }

	// RVA: 0x75AD488
	internal object get_clampedDragger() { }

	// RVA: 0x75AD490
	private object set_clampedDragger(object value) { }

	// RVA: 0x75AD498
	public object get_minValue() { }

	// RVA: 0x75AD4DC
	public object set_minValue(object value) { }

	// RVA: 0x75AD5C8
	public object get_maxValue() { }

	// RVA: 0x75AD614
	public object set_maxValue(object value) { }

	// RVA: 0x75AD6C8
	public override object get_value() { }

	// RVA: 0x75AD720
	public override object set_value(object value) { }

	// RVA: 0x75AD7B4
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x75AF41C
	public object get_lowLimit() { }

	// RVA: 0x75AF424
	public object set_lowLimit(object value) { }

	// RVA: 0x75AF5C0
	public object get_highLimit() { }

	// RVA: 0x75AF5C8
	public object set_highLimit(object value) { }

	// RVA: 0x75AF764
	public object .ctor() { }

	// RVA: 0x75AF784
	public object .ctor(object label, object minValue, object maxValue, object minLimit, object maxLimit) { }

	// RVA: 0x75AD590
	private object ClampValues(object valueToClamp) { }

	// RVA: 0x75AFE88
	private object UpdateDragElementPosition(object evt) { }

	// RVA: 0x75AD84C
	private object UpdateDragElementPosition() { }

	// RVA: 0x75AFEE0
	internal object SliderLerpUnclamped(object a, object b, object interpolant) { }

	// RVA: 0x75AFED0
	internal object SliderNormalizeValue(object currentValue, object lowerValue, object higherValue) { }

	// RVA: 0x75AFEF0
	private object ComputeValueFromPosition(object positionToConvert) { }

	// RVA: 0x75B0104
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: 0x75B0268
	private object SetSliderValueFromDrag() { }

	// RVA: 0x75B056C
	private object SetSliderValueFromClick() { }

	// RVA: 0x75B09F0
	private object ComputeValueDragStateNoThumb(object lowLimitPosition, object highLimitPosition, object dragElementPos) { }

	// RVA: 0x75B0308
	private object ComputeValueFromDraggingThumb(object dragElementStartPos, object dragElementEndPos) { }

	// RVA: 0x75B0B04
	protected override object UpdateMixedValueContent() { }

	// RVA: 0x75B0B08
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal enum ColumnDataType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Name;
	public const object Title;
	public const object Icon;
	public const object Visibility;
	public const object Width;
	public const object MaxWidth;
	public const object MinWidth;
	public const object Stretchable;
	public const object Sortable;
	public const object Optional;
	public const object Resizable;
	public const object HeaderTemplate;
	public const object CellTemplate;
}

// Namespace: 
internal class UxmlObjectFactory<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass15_0
{

	// Fields
	public object asset; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <Init>b__0() { }

}

// Namespace: 
private sealed class <>c__DisplayClass15_1
{

	// Fields
	public object asset; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <Init>b__1() { }

}

// Namespace: 
internal class UxmlObjectTraits<T0>
{

	// Fields
	private object m_Name; // 0x0
	private object m_Text; // 0x0
	private object m_Visible; // 0x0
	private object m_Width; // 0x0
	private object m_MinWidth; // 0x0
	private object m_MaxWidth; // 0x0
	private object m_Stretch; // 0x0
	private object m_Sortable; // 0x0
	private object m_Optional; // 0x0
	private object m_Resizable; // 0x0
	private object m_HeaderTemplateId; // 0x0
	private object m_CellTemplateId; // 0x0

	// Methods

	// RVA: -1
	private static object ParseLength(object str, object defaultValue) { }

	// RVA: -1
	public override object Init(object obj, object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Column
{

	// Fields
	private static readonly object k_InvalidTemplateError; // 0x0
	private object m_Name; // 0x8
	private object m_Title; // 0x10
	private object m_Icon; // 0x18
	private object m_Visible; // 0x38
	private object m_Width; // 0x3C
	private object m_MinWidth; // 0x44
	private object m_MaxWidth; // 0x4C
	private object m_DesiredWidth; // 0x54
	private object m_Stretchable; // 0x58
	private object m_Sortable; // 0x59
	private object m_Optional; // 0x5A
	private object m_Resizable; // 0x5B
	private object m_MakeHeader; // 0x60
	private object m_BindHeader; // 0x68
	private object m_UnbindHeader; // 0x70
	private object m_DestroyHeader; // 0x78
	private object m_MakeCell; // 0x80
	private object m_BindCell; // 0x88
	private object m_UnbindCellItem; // 0x90
	private object <destroyCell>k__BackingField; // 0x98
	private object <collection>k__BackingField; // 0xA0
	private object changed; // 0xA8
	private object resized; // 0xB0

	// Properties
	public object name { get; set; }
	public object title { get; set; }
	public object icon { get; }
	internal object index { get; }
	internal object displayIndex { get; }
	internal object visibleIndex { get; }
	public object visible { get; set; }
	public object width { get; set; }
	public object minWidth { get; set; }
	public object maxWidth { get; set; }
	internal object desiredWidth { get; set; }
	public object sortable { get; set; }
	public object stretchable { get; set; }
	public object optional { get; set; }
	public object resizable { get; set; }
	public object makeHeader { get; set; }
	public object bindHeader { get; }
	public object unbindHeader { get; }
	public object destroyHeader { get; }
	public object makeCell { get; set; }
	public object bindCell { get; }
	public object unbindCell { get; }
	public object destroyCell { get; }
	public object collection { get; set; }

	// Methods

	// RVA: 0x75B1124
	public object get_name() { }

	// RVA: 0x75B112C
	public object set_name(object value) { }

	// RVA: 0x75B11AC
	public object get_title() { }

	// RVA: 0x75B11B4
	public object set_title(object value) { }

	// RVA: 0x75B1210
	public object get_icon() { }

	// RVA: 0x75B1220
	internal object get_index() { }

	// RVA: 0x75B1310
	internal object get_displayIndex() { }

	// RVA: 0x75B14B4
	internal object get_visibleIndex() { }

	// RVA: 0x75B158C
	public object get_visible() { }

	// RVA: 0x75B1594
	public object set_visible(object value) { }

	// RVA: 0x75B15CC
	public object get_width() { }

	// RVA: 0x75B15D4
	public object set_width(object value) { }

	// RVA: 0x75B1684
	public object get_minWidth() { }

	// RVA: 0x75B168C
	public object set_minWidth(object value) { }

	// RVA: 0x75B16E8
	public object get_maxWidth() { }

	// RVA: 0x75B16F0
	public object set_maxWidth(object value) { }

	// RVA: 0x75B174C
	internal object get_desiredWidth() { }

	// RVA: 0x75B1654
	internal object set_desiredWidth(object value) { }

	// RVA: 0x75B1754
	public object get_sortable() { }

	// RVA: 0x75B175C
	public object set_sortable(object value) { }

	// RVA: 0x75B1794
	public object get_stretchable() { }

	// RVA: 0x75B179C
	public object set_stretchable(object value) { }

	// RVA: 0x75B17D4
	public object get_optional() { }

	// RVA: 0x75B17DC
	public object set_optional(object value) { }

	// RVA: 0x75B1814
	public object get_resizable() { }

	// RVA: 0x75B181C
	public object set_resizable(object value) { }

	// RVA: 0x75B1854
	public object get_makeHeader() { }

	// RVA: 0x75B185C
	public object set_makeHeader(object value) { }

	// RVA: 0x75B18B8
	public object get_bindHeader() { }

	// RVA: 0x75B18C0
	public object get_unbindHeader() { }

	// RVA: 0x75B18C8
	public object get_destroyHeader() { }

	// RVA: 0x75B18D0
	public object get_makeCell() { }

	// RVA: 0x75B18D8
	public object set_makeCell(object value) { }

	// RVA: 0x75B1934
	public object get_bindCell() { }

	// RVA: 0x75B193C
	public object get_unbindCell() { }

	// RVA: 0x75B1944
	public object get_destroyCell() { }

	// RVA: 0x75B194C
	public object get_collection() { }

	// RVA: 0x75B1954
	internal object set_collection(object value) { }

	// RVA: 0x75B195C
	internal object add_changed(object value) { }

	// RVA: 0x75B1A10
	internal object remove_changed(object value) { }

	// RVA: 0x75B1AC4
	internal object add_resized(object value) { }

	// RVA: 0x75B1B78
	internal object remove_resized(object value) { }

	// RVA: 0x75B1188
	private object NotifyChange(object type) { }

	// RVA: 0x75B1C2C
	public object .ctor() { }

	// RVA: 0x75B1CA0
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__41_0; // 0x8
	public static object <>9__41_1; // 0x10
	public static object <>9__42_0; // 0x18
	public static object <>9__42_2; // 0x20
	public static object <>9__42_4; // 0x28
	public static object <>9__42_6; // 0x30

	// Methods

	// RVA: 0x75B60B8
	private static object .cctor() { }

	// RVA: 0x75B6118
	public object .ctor() { }

	// RVA: 0x75B6120
	internal object <DoLayout>b__41_0(object c1, object c2) { }

	// RVA: 0x75B6170
	internal object <DoLayout>b__41_1(object c1, object c2) { }

	// RVA: 0x75B61C0
	internal object <StretchResizeColumns>b__42_0(object c1, object c2) { }

	// RVA: 0x75B6210
	internal object <StretchResizeColumns>b__42_2(object c1, object c2) { }

	// RVA: 0x75B6260
	internal object <StretchResizeColumns>b__42_4(object c1, object c2) { }

	// RVA: 0x75B62B0
	internal object <StretchResizeColumns>b__42_6(object c1, object c2) { }

}

// Namespace: 
private sealed class <>c__DisplayClass42_0
{

	// Fields
	public object totalStretchableWidth; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x75B54CC
	public object .ctor() { }

	// RVA: 0x75B6300
	internal object <StretchResizeColumns>b__1(object c) { }

}

// Namespace: 
private sealed class <>c__DisplayClass42_1
{

	// Fields
	public object totalFixedWidth; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x75B54D4
	public object .ctor() { }

	// RVA: 0x75B6348
	internal object <StretchResizeColumns>b__3(object c) { }

}

// Namespace: 
private sealed class <>c__DisplayClass42_2
{

	// Fields
	public object totalStretchableWidth; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x75B54DC
	public object .ctor() { }

	// RVA: 0x75B6390
	internal object <StretchResizeColumns>b__5(object c) { }

}

// Namespace: 
private sealed class <>c__DisplayClass42_3
{

	// Fields
	public object totalFixedWidth; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x75B54E4
	public object .ctor() { }

	// RVA: 0x75B63D8
	internal object <StretchResizeColumns>b__7(object c) { }

}

// Namespace: UnityEngine.UIElements
internal class ColumnLayout
{

	// Fields
	private object m_StretchableColumns; // 0x8
	private object m_FixedColumns; // 0x10
	private object m_Columns; // 0x18
	private object m_ColumnsWidth; // 0x20
	private object m_ColumnsWidthDirty; // 0x24
	private object m_MaxColumnsWidth; // 0x28
	private object m_MinColumnsWidth; // 0x2C
	private object m_IsDirty; // 0x30
	private object m_PreviousWidth; // 0x34
	private object m_DragResizeInPreviewMode; // 0x38
	private object m_DragResizing; // 0x39
	private object m_DragStartPos; // 0x3C
	private object m_DragLastPos; // 0x40
	private object m_DragInitialColumnWidth; // 0x44
	private object m_DragStretchableColumns; // 0x48
	private object m_DragFixedColumns; // 0x50
	private object m_PreviewDesiredWidths; // 0x58
	private object layoutRequested; // 0x60

	// Properties
	public object columns { get; }
	public object columnsWidth { get; }
	public object minColumnsWidth { get; }
	public object maxColumnsWidth { get; }
	public object hasStretchableColumns { get; }

	// Methods

	// RVA: 0x75B1D0C
	public object get_columns() { }

	// RVA: 0x75B1D14
	public object get_columnsWidth() { }

	// RVA: 0x75B20AC
	public object get_minColumnsWidth() { }

	// RVA: 0x75B20B4
	public object get_maxColumnsWidth() { }

	// RVA: 0x75B20BC
	public object get_hasStretchableColumns() { }

	// RVA: 0x75B2118
	public object add_layoutRequested(object value) { }

	// RVA: 0x75B21BC
	public object remove_layoutRequested(object value) { }

	// RVA: 0x75B2260
	public object .ctor(object columns) { }

	// RVA: 0x75B2BFC
	public object Dirty() { }

	// RVA: 0x75B26D0
	private object OnColumnAdded(object column, object index) { }

	// RVA: 0x75B2D04
	private object OnColumnRemoved(object column) { }

	// RVA: 0x75B2F34
	private object OnColumnReordered(object column, object from, object to) { }

	// RVA: 0x75B2F84
	private object RequiresLayoutUpdate(object type) { }

	// RVA: 0x75B2F9C
	private object OnColumnChanged(object column, object type) { }

	// RVA: 0x75B3010
	private object OnColumnResized(object column) { }

	// RVA: 0x75B301C
	private static object IsClamped(object value, object min, object max) { }

	// RVA: 0x75B302C
	public object DoLayout(object width) { }

	// RVA: 0x75B4320
	public object StretchResizeColumns(object stretchableColumns, object fixedColumns, object delta, object resizeToFit) { }

	// RVA: 0x75B54EC
	public object ResizeToFit(object width) { }

	// RVA: 0x75B5360
	private object ResizeColumn(object column, object width, object setDesiredWidthOnly) { }

	// RVA: 0x75B55DC
	internal object BeginDragResize(object column, object pos, object previewMode) { }

	// RVA: 0x75B5ABC
	public object GetDesiredPosition(object column) { }

	// RVA: 0x75B420C
	public object GetDesiredWidth(object c) { }

	// RVA: 0x75B5C58
	public object DragResize(object column, object pos) { }

	// RVA: 0x75B5E44
	internal object EndDragResize(object column, object cancelled) { }

	// RVA: 0x75B3C10
	private object UpdateCache() { }

	// RVA: 0x75B2C4C
	private object ClearCache() { }

}

// Namespace: UnityEngine.UIElements
internal enum ColumnsDataType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PrimaryColumn;
	public const object StretchMode;
	public const object Reorderable;
	public const object Resizable;
	public const object ResizePreview;
}

// Namespace: 
public enum StretchMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Grow;
	public const object GrowAndFill;
}

// Namespace: 
internal class UxmlObjectFactory<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
internal class UxmlObjectTraits<T0>
{

	// Fields
	private readonly object m_PrimaryColumnName; // 0x0
	private readonly object m_StretchMode; // 0x0
	private readonly object m_Reorderable; // 0x0
	private readonly object m_Resizable; // 0x0
	private readonly object m_ResizePreview; // 0x0
	private readonly object m_Columns; // 0x0

	// Methods

	// RVA: -1
	public override object Init(object obj, object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__74_0; // 0x8

	// Methods

	// RVA: 0x75B880C
	private static object .cctor() { }

	// RVA: 0x75B886C
	public object .ctor() { }

	// RVA: 0x75B8874
	internal object <UpdateVisibleColumns>b__74_0(object c) { }

}

// Namespace: UnityEngine.UIElements
public class Columns
{

	// Fields
	private object m_Columns; // 0x8
	private object m_DisplayColumns; // 0x10
	private object m_VisibleColumns; // 0x18
	private object m_VisibleColumnsDirty; // 0x20
	private object m_StretchMode; // 0x24
	private object m_Reorderable; // 0x28
	private object m_Resizable; // 0x29
	private object m_ResizePreview; // 0x2A
	private object m_PrimaryColumnName; // 0x30
	private object changed; // 0x38
	private object columnAdded; // 0x40
	private object columnRemoved; // 0x48
	private object columnChanged; // 0x50
	private object columnResized; // 0x58
	private object columnReordered; // 0x60

	// Properties
	public object primaryColumnName { get; set; }
	public object reorderable { get; set; }
	public object resizable { get; set; }
	public object resizePreview { get; set; }
	internal object displayList { get; }
	internal object visibleList { get; }
	public object stretchMode { get; set; }
	public object Count { get; }
	public object IsReadOnly { get; }
	public object Item { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x75B6420
	public object get_primaryColumnName() { }

	// RVA: 0x75B6428
	public object set_primaryColumnName(object value) { }

	// RVA: 0x75B649C
	public object get_reorderable() { }

	// RVA: 0x75B64A4
	public object set_reorderable(object value) { }

	// RVA: 0x75B64D4
	public object get_resizable() { }

	// RVA: 0x75B64DC
	public object set_resizable(object value) { }

	// RVA: 0x75B650C
	public object get_resizePreview() { }

	// RVA: 0x75B6514
	public object set_resizePreview(object value) { }

	// RVA: 0x75B1420
	internal object get_displayList() { }

	// RVA: 0x75B1568
	internal object get_visibleList() { }

	// RVA: 0x75B68A4
	internal object add_changed(object value) { }

	// RVA: 0x75B6958
	internal object remove_changed(object value) { }

	// RVA: 0x75B6A0C
	public object get_stretchMode() { }

	// RVA: 0x75B6A14
	public object set_stretchMode(object value) { }

	// RVA: 0x75B29E0
	internal object add_columnAdded(object value) { }

	// RVA: 0x75B6A44
	internal object remove_columnAdded(object value) { }

	// RVA: 0x75B2A94
	internal object add_columnRemoved(object value) { }

	// RVA: 0x75B6AF8
	internal object remove_columnRemoved(object value) { }

	// RVA: 0x75B6BAC
	internal object add_columnChanged(object value) { }

	// RVA: 0x75B6C60
	internal object remove_columnChanged(object value) { }

	// RVA: 0x75B6D14
	internal object add_columnResized(object value) { }

	// RVA: 0x75B6DC8
	internal object remove_columnResized(object value) { }

	// RVA: 0x75B2B48
	internal object add_columnReordered(object value) { }

	// RVA: 0x75B6E7C
	internal object remove_columnReordered(object value) { }

	// RVA: 0x75B6F30
	public object IsPrimary(object column) { }

	// RVA: 0x75B412C
	public object GetEnumerator() { }

	// RVA: 0x75B703C
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x75B7040
	public object Add(object item) { }

	// RVA: 0x75B74F4
	public object Clear() { }

	// RVA: 0x75B7A64
	public object Contains(object item) { }

	// RVA: 0x75B7B3C
	public object Contains(object name) { }

	// RVA: 0x75B7ED0
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x75B771C
	public object Remove(object column) { }

	// RVA: 0x75B7FB8
	private object OnColumnChanged(object column, object type) { }

	// RVA: 0x75B80F8
	private object OnColumnResized(object column) { }

	// RVA: 0x75B2900
	public object get_Count() { }

	// RVA: 0x75B8114
	public object get_IsReadOnly() { }

	// RVA: 0x75B1238
	public object IndexOf(object column) { }

	// RVA: 0x75B7128
	public object Insert(object index, object column) { }

	// RVA: 0x75B25FC
	public object get_Item(object index) { }

	// RVA: 0x75B81F8
	public object get_Item(object name) { }

	// RVA: 0x75B858C
	public object ReorderDisplay(object from, object to) { }

	// RVA: 0x75B6544
	private object InitOrderColumns() { }

	// RVA: 0x75B8080
	private object DirtyVisibleColumns() { }

	// RVA: 0x75B65D4
	private object UpdateVisibleColumns() { }

	// RVA: 0x75B6480
	private object NotifyChange(object type) { }

	// RVA: 0x75B8778
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class MultiColumnController
{

	// Fields
	private static readonly object k_BoundColumnVePropertyName; // 0x0
	internal static readonly object bindableElementPropertyName; // 0x4
	internal static readonly object baseUssClassName; // 0x8
	private static readonly object k_HeaderContainerViewDataKey; // 0x10
	public static readonly object headerContainerUssClassName; // 0x18
	public static readonly object rowContainerUssClassName; // 0x20
	public static readonly object cellUssClassName; // 0x28
	public static readonly object cellLabelUssClassName; // 0x30
	private static readonly object k_HeaderViewDataKey; // 0x38
	private object columnSortingChanged; // 0x8
	private object headerContextMenuPopulateEvent; // 0x10
	private object m_View; // 0x18
	private object m_HeaderContainer; // 0x20
	private object m_MultiColumnHeader; // 0x28

	// Properties
	internal object header { get; }

	// Methods

	// RVA: 0x75B8894
	public object add_columnSortingChanged(object value) { }

	// RVA: 0x75B8938
	public object remove_columnSortingChanged(object value) { }

	// RVA: 0x75B89DC
	public object add_headerContextMenuPopulateEvent(object value) { }

	// RVA: 0x75B8A90
	public object remove_headerContextMenuPopulateEvent(object value) { }

	// RVA: 0x75B8B44
	internal object get_header() { }

	// RVA: 0x75B8B4C
	public object .ctor(object columns, object sortDescriptions, object sortedColumns) { }

	// RVA: -1
	private static object BindCellItem(object ve, object rowIndex, object column, object item) { }

	// RVA: 0x75B91CC
	private static object UnbindCellItem(object ve, object rowIndex, object column) { }

	// RVA: 0x75B920C
	private static object DefaultMakeCellItem() { }

	// RVA: -1
	private static object DefaultBindCellItem(object ve, object column, object item) { }

	// RVA: 0x75B92EC
	public object MakeItem() { }

	// RVA: -1
	public object BindItem(object element, object index, object item) { }

	// RVA: 0x75B9804
	public object UnbindItem(object element, object index) { }

	// RVA: 0x75B9CC4
	public object DestroyItem(object element) { }

	// RVA: 0x75BA140
	public object PrepareView(object collectionView) { }

	// RVA: 0x75BA5D8
	public object Dispose() { }

	// RVA: 0x75BAEE0
	private object OnHorizontalScrollerValueChanged(object v) { }

	// RVA: 0x75BAF04
	private object OnViewportGeometryChanged(object evt) { }

	// RVA: 0x75BB500
	private object OnColumnContainerGeometryChanged(object evt) { }

	// RVA: 0x75BB294
	private object UpdateContentContainer(object collectionView) { }

	// RVA: 0x75BB508
	private object OnColumnSortingChanged() { }

	// RVA: 0x75BB524
	private object OnContextMenuPopulateEvent(object evt, object column) { }

	// RVA: 0x75BB540
	private object OnColumnResized(object index, object width) { }

	// RVA: 0x75BB9CC
	private object OnColumnAdded(object column, object index) { }

	// RVA: 0x75BB9F0
	private object OnColumnRemoved(object column) { }

	// RVA: 0x75BBA14
	private object OnColumnReordered(object column, object from, object to) { }

	// RVA: 0x75BBA38
	private object OnColumnsChanged(object column, object type) { }

	// RVA: 0x75BBA68
	private object OnColumnChanged(object type) { }

	// RVA: 0x75BBA94
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75BCB5C
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private readonly object m_SortingEnabled; // 0xD0
	private readonly object m_Columns; // 0xD8
	private readonly object m_SortColumnDescriptions; // 0xE0

	// Methods

	// RVA: 0x75BCBB4
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75BCDF8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class MultiColumnListView
{

	// Fields
	private object m_Columns; // 0x528
	private object m_SortingEnabled; // 0x530
	private object m_SortColumnDescriptions; // 0x538
	private object m_SortedColumns; // 0x540
	private object columnSortingChanged; // 0x548
	private object headerContextMenuPopulateEvent; // 0x550

	// Properties
	public object viewController { get; }
	public object columns { get; set; }
	public object sortColumnDescriptions { get; set; }
	public object sortingEnabled { set; }

	// Methods

	// RVA: 0x75BBC50
	public object get_viewController() { }

	// RVA: 0x75BBCE4
	public object get_columns() { }

	// RVA: 0x75BBCEC
	private object set_columns(object value) { }

	// RVA: 0x75BBD54
	public object get_sortColumnDescriptions() { }

	// RVA: 0x75BBD5C
	private object set_sortColumnDescriptions(object value) { }

	// RVA: 0x75BBF34
	public object set_sortingEnabled(object value) { }

	// RVA: 0x75BC068
	public object .ctor() { }

	// RVA: 0x75BC144
	public object .ctor(object columns) { }

	// RVA: 0x75BC3E4
	protected override object CreateViewController() { }

	// RVA: 0x75BC460
	public override object SetViewController(object controller) { }

	// RVA: 0x75BCACC
	internal override object CreateVirtualizationController() { }

	// RVA: 0x75BCB24
	private object RaiseColumnSortingChanged() { }

	// RVA: 0x75BCB40
	private object RaiseHeaderContextMenuPopulate(object evt, object column) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75BDC14
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private readonly object m_SortingEnabled; // 0xB0
	private readonly object m_Columns; // 0xB8
	private readonly object m_SortColumnDescriptions; // 0xC0

	// Methods

	// RVA: 0x75BDC6C
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75BDEB0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class MultiColumnTreeView
{

	// Fields
	private object m_Columns; // 0x4B0
	private object m_SortingEnabled; // 0x4B8
	private object m_SortColumnDescriptions; // 0x4C0
	private object m_SortedColumns; // 0x4C8
	private object columnSortingChanged; // 0x4D0
	private object headerContextMenuPopulateEvent; // 0x4D8

	// Properties
	public object viewController { get; }
	public object columns { get; set; }
	public object sortColumnDescriptions { get; set; }
	public object sortingEnabled { set; }

	// Methods

	// RVA: 0x75BCF18
	public object get_viewController() { }

	// RVA: 0x75BCFAC
	public object get_columns() { }

	// RVA: 0x75BCFB4
	private object set_columns(object value) { }

	// RVA: 0x75BD01C
	public object get_sortColumnDescriptions() { }

	// RVA: 0x75BD024
	private object set_sortColumnDescriptions(object value) { }

	// RVA: 0x75BD050
	public object set_sortingEnabled(object value) { }

	// RVA: 0x75BD184
	public object .ctor() { }

	// RVA: 0x75BD260
	public object .ctor(object columns) { }

	// RVA: 0x75BD480
	protected override object CreateViewController() { }

	// RVA: 0x75BD518
	public override object SetViewController(object controller) { }

	// RVA: 0x75BDB84
	internal override object CreateVirtualizationController() { }

	// RVA: 0x75BDBDC
	private object RaiseColumnSortingChanged() { }

	// RVA: 0x75BDBF8
	private object RaiseHeaderContextMenuPopulate(object evt, object column) { }

}

// Namespace: UnityEngine.UIElements
public enum SortDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Ascending;
	public const object Descending;
}

// Namespace: 
internal class UxmlObjectFactory<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
internal class UxmlObjectTraits<T0>
{

	// Fields
	private readonly object m_ColumnName; // 0x0
	private readonly object m_ColumnIndex; // 0x0
	private readonly object m_SortDescription; // 0x0

	// Methods

	// RVA: -1
	public override object Init(object obj, object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class SortColumnDescription
{

	// Fields
	private object m_ColumnIndex; // 0x8
	private object m_ColumnName; // 0x10
	private object m_SortDirection; // 0x18
	private object <column>k__BackingField; // 0x20
	private object changed; // 0x28

	// Properties
	public object columnName { get; set; }
	public object columnIndex { get; set; }
	public object column { get; set; }
	public object direction { get; set; }

	// Methods

	// RVA: 0x75BDFD0
	public object get_columnName() { }

	// RVA: 0x75BDFD8
	public object set_columnName(object value) { }

	// RVA: 0x75BE030
	public object get_columnIndex() { }

	// RVA: 0x75BE038
	public object set_columnIndex(object value) { }

	// RVA: 0x75BE06C
	public object get_column() { }

	// RVA: 0x75BE074
	internal object set_column(object value) { }

	// RVA: 0x75BE07C
	public object get_direction() { }

	// RVA: 0x75BE084
	public object set_direction(object value) { }

	// RVA: 0x75BE0B8
	internal object add_changed(object value) { }

	// RVA: 0x75BE16C
	internal object remove_changed(object value) { }

	// RVA: 0x75BE220
	public object .ctor() { }

	// RVA: 0x75BE230
	public object .ctor(object columnIndex, object direction) { }

	// RVA: 0x75BE2D0
	public object .ctor(object columnName, object direction) { }

}

// Namespace: 
internal class UxmlObjectFactory<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
internal class UxmlObjectTraits<T0>
{

	// Fields
	private readonly object m_SortColumnDescriptions; // 0x0

	// Methods

	// RVA: -1
	public override object Init(object obj, object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class SortColumnDescriptions
{

	// Fields
	private readonly object m_Descriptions; // 0x8
	private object changed; // 0x10

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }

	// Methods

	// RVA: 0x75BE378
	internal object add_changed(object value) { }

	// RVA: 0x75BE41C
	internal object remove_changed(object value) { }

	// RVA: 0x75BE4C0
	public object GetEnumerator() { }

	// RVA: 0x75BE5A0
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x75BE5A4
	public object Add(object item) { }

	// RVA: 0x75BBD88
	public object Clear() { }

	// RVA: 0x75BEB20
	public object Contains(object item) { }

	// RVA: 0x75BEBF8
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x75BE8E8
	public object Remove(object desc) { }

	// RVA: 0x75BECE0
	private object OnDescriptionChanged(object desc) { }

	// RVA: 0x75BECFC
	public object get_Count() { }

	// RVA: 0x75BEDDC
	public object get_IsReadOnly() { }

	// RVA: 0x75BE68C
	public object Insert(object index, object desc) { }

	// RVA: 0x75BC364
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass26_0
{

	// Fields
	public object item; // 0x0
	public object <>4__this; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <AddMenuItems>b__0() { }

}

// Namespace: UnityEngine.UIElements
public class PopupField<T0>
{

	// Fields
	private object m_Index; // 0x0
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x0
	public static readonly object inputUssClassName; // 0x0

	// Properties
	public override object value { get; set; }
	public object index { set; }

	// Methods

	// RVA: -1
	internal override object GetValueToDisplay() { }

	// RVA: -1
	internal override object GetListItemToDisplay(object value) { }

	// RVA: -1
	public override object get_value() { }

	// RVA: -1
	public override object set_value(object value) { }

	// RVA: -1
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: -1
	public object set_index(object value) { }

	// RVA: -1
	public object .ctor(object label) { }

	// RVA: -1
	internal override object AddMenuItems(object menu) { }

	// RVA: -1
	private object ChangeValueFromMenu(object menuItem) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75BF09C
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75BF0F4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class PopupWindow
{

	// Fields
	private object m_ContentContainer; // 0x498
	public static readonly object ussClassName; // 0x0
	public static readonly object contentUssClassName; // 0x8

	// Properties
	public override object contentContainer { get; }

	// Methods

	// RVA: 0x75BEEC0
	public object .ctor() { }

	// RVA: 0x75BEFFC
	public override object get_contentContainer() { }

	// RVA: 0x75BF004
	private static object .cctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_LowValue; // 0x70
	private object m_HighValue; // 0x78
	private object m_Value; // 0x80
	private object m_Title; // 0x88

	// Methods

	// RVA: 0x75BFBEC
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75BFEA8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class AbstractProgressBar
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object containerUssClassName; // 0x8
	public static readonly object titleUssClassName; // 0x10
	public static readonly object titleContainerUssClassName; // 0x18
	public static readonly object progressUssClassName; // 0x20
	public static readonly object backgroundUssClassName; // 0x28
	private readonly object m_Background; // 0x3D0
	private readonly object m_Progress; // 0x3D8
	private readonly object m_Title; // 0x3E0
	private object m_LowValue; // 0x3E8
	private object m_HighValue; // 0x3EC
	private object m_Value; // 0x3F0

	// Properties
	public object title { set; }
	public object lowValue { get; set; }
	public object highValue { get; set; }
	public virtual object value { get; set; }

	// Methods

	// RVA: 0x75BF0FC
	public object set_title(object value) { }

	// RVA: 0x75BF154
	public object get_lowValue() { }

	// RVA: 0x75BF15C
	public object set_lowValue(object value) { }

	// RVA: 0x75BF330
	public object get_highValue() { }

	// RVA: 0x75BF338
	public object set_highValue(object value) { }

	// RVA: 0x75BF344
	public object .ctor() { }

	// RVA: 0x75BF678
	private object OnGeometryChanged(object e) { }

	// RVA: 0x75BF6C0
	public virtual object get_value() { }

	// RVA: 0x75BF6C8
	public virtual object set_value(object value) { }

	// RVA: 0x75BF9A0
	public object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x75BF168
	private object SetProgress(object p) { }

	// RVA: 0x75BF9EC
	private object CalculateProgressWidth(object width) { }

	// RVA: 0x75BFA84
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75C00EC
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class ProgressBar
{

	// Methods

	// RVA: 0x75C006C
	public object .ctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75C0B94
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Text; // 0x80

	// Methods

	// RVA: 0x75C0BEC
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75C0D34
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class RadioButton
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10
	public static readonly object checkmarkBackgroundUssClassName; // 0x18
	public static readonly object checkmarkUssClassName; // 0x20
	public static readonly object textUssClassName; // 0x28
	private object m_CheckmarkBackground; // 0x448

	// Properties
	public override object value { get; set; }

	// Methods

	// RVA: 0x75C0144
	public override object get_value() { }

	// RVA: 0x75C019C
	public override object set_value(object value) { }

	// RVA: 0x75C03BC
	public object .ctor() { }

	// RVA: 0x75C03C4
	public object .ctor(object label) { }

	// RVA: 0x75C0698
	private object OnOptionAttachToPanel(object evt) { }

	// RVA: 0x75C073C
	private object OnOptionDetachFromPanel(object evt) { }

	// RVA: 0x75C07E0
	protected override object InitLabel() { }

	// RVA: 0x75C0870
	protected override object ToggleValue() { }

	// RVA: 0x75C08EC
	private object UnityEngine.UIElements.IGroupBoxOption.SetSelected(object selected) { }

	// RVA: 0x75C0938
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x75C0280
	private object UpdateCheckmark() { }

	// RVA: 0x75C0960
	protected override object UpdateMixedValueContent() { }

	// RVA: 0x75C0A2C
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75C2028
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Choices; // 0x80

	// Methods

	// RVA: 0x75C2080
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75C21E0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class RadioButtonGroup
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object containerUssClassName; // 0x8
	private object m_RadioButtons; // 0x428
	private object m_RadioButtonValueChangedCallback; // 0x430
	private object m_RadioButtonContainer; // 0x438

	// Properties
	public object choices { set; }

	// Methods

	// RVA: 0x75C0DE0
	public object set_choices(object value) { }

	// RVA: 0x75C16C8
	public object .ctor() { }

	// RVA: 0x75C16D4
	public object .ctor(object label, object radioButtonChoices) { }

	// RVA: 0x75C1958
	private object RadioButtonValueChangedCallback(object evt) { }

	// RVA: 0x75C1A90
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: 0x75C1428
	private object UpdateRadioButtons() { }

	// RVA: 0x75C1B34
	private object UnityEngine.UIElements.IGroupBox.OnOptionAdded(object option) { }

	// RVA: 0x75C1DD0
	private object UnityEngine.UIElements.IGroupBox.OnOptionRemoved(object option) { }

	// RVA: 0x75C1F90
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75C250C
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Delay; // 0x88
	private object m_Interval; // 0x90

	// Methods

	// RVA: 0x75C2564
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75C2750
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class RepeatButton
{

	// Fields
	private object m_Clickable; // 0x498
	public static readonly object ussClassName; // 0x0

	// Methods

	// RVA: 0x75C228C
	public object .ctor() { }

	// RVA: 0x75C235C
	public object .ctor(object clickEvent, object delay, object interval) { }

	// RVA: 0x75C2400
	public object SetAction(object clickEvent, object delay, object interval) { }

	// RVA: 0x75C24A0
	private static object .cctor() { }

}

// Namespace: 
private class ScrollerSlider
{

	// Methods

	// RVA: 0x75C31B4
	public object .ctor(object start, object end, object direction, object pageSize) { }

	// RVA: 0x75C3824
	internal override object SliderNormalizeValue(object currentValue, object lowerValue, object higherValue) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75C3854
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_LowValue; // 0x68
	private object m_HighValue; // 0x70
	private object m_Direction; // 0x78
	private object m_Value; // 0x80

	// Methods

	// RVA: 0x75C38AC
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75C3B88
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Scroller
{

	// Fields
	private object valueChanged; // 0x3C0
	private object <slider>k__BackingField; // 0x3C8
	private object <lowButton>k__BackingField; // 0x3D0
	private object <highButton>k__BackingField; // 0x3D8
	internal const object kDefaultPageSize;
	public static readonly object ussClassName; // 0x0
	public static readonly object horizontalVariantUssClassName; // 0x8
	public static readonly object verticalVariantUssClassName; // 0x10
	public static readonly object sliderUssClassName; // 0x18
	public static readonly object lowButtonUssClassName; // 0x20
	public static readonly object highButtonUssClassName; // 0x28

	// Properties
	public object slider { get; set; }
	public object lowButton { get; set; }
	public object highButton { get; set; }
	public object value { get; set; }
	public object lowValue { get; set; }
	public object highValue { get; set; }
	public object direction { set; }

	// Methods

	// RVA: 0x75BA524
	public object add_valueChanged(object value) { }

	// RVA: 0x75BAE2C
	public object remove_valueChanged(object value) { }

	// RVA: 0x75C282C
	public object get_slider() { }

	// RVA: 0x75C2834
	private object set_slider(object value) { }

	// RVA: 0x75C283C
	public object get_lowButton() { }

	// RVA: 0x75C2844
	private object set_lowButton(object value) { }

	// RVA: 0x75C284C
	public object get_highButton() { }

	// RVA: 0x75C2854
	private object set_highButton(object value) { }

	// RVA: 0x75C285C
	public object get_value() { }

	// RVA: 0x75C28AC
	public object set_value(object value) { }

	// RVA: 0x75C290C
	public object get_lowValue() { }

	// RVA: 0x75C2968
	public object set_lowValue(object value) { }

	// RVA: 0x75C29D4
	public object get_highValue() { }

	// RVA: 0x75C2A30
	public object set_highValue(object value) { }

	// RVA: 0x75C2A9C
	public object set_direction(object value) { }

	// RVA: 0x75C2D24
	public object .ctor() { }

	// RVA: 0x75C2D38
	public object .ctor(object lowValue, object highValue, object valueChanged, object direction) { }

	// RVA: 0x75C3248
	public object Adjust(object factor) { }

	// RVA: 0x75C32CC
	private object OnSliderValueChange(object evt) { }

	// RVA: 0x75C33C4
	public object ScrollPageUp() { }

	// RVA: 0x75C3540
	public object ScrollPageDown() { }

	// RVA: 0x75C33CC
	public object ScrollPageUp(object factor) { }

	// RVA: 0x75C3548
	public object ScrollPageDown(object factor) { }

	// RVA: 0x75C36BC
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public enum ScrollViewMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Vertical;
	public const object Horizontal;
	public const object VerticalAndHorizontal;
}

// Namespace: UnityEngine.UIElements
public enum ScrollerVisibility
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object AlwaysVisible;
	public const object Hidden;
}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75CB0F0
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_ScrollViewMode; // 0x68
	private object m_NestedInteractionKind; // 0x70
	private object m_ShowHorizontal; // 0x78
	private object m_ShowVertical; // 0x80
	private object m_HorizontalScrollerVisibility; // 0x88
	private object m_VerticalScrollerVisibility; // 0x90
	private object m_HorizontalPageSize; // 0x98
	private object m_VerticalPageSize; // 0xA0
	private object m_MouseWheelScrollSize; // 0xA8
	private object m_TouchScrollBehavior; // 0xB0
	private object m_ScrollDecelerationRate; // 0xB8
	private object m_Elasticity; // 0xC0

	// Methods

	// RVA: 0x75CB148
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75CB690
	public object .ctor() { }

}

// Namespace: 
public enum TouchScrollBehavior
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unrestricted;
	public const object Elastic;
	public const object Clamped;
}

// Namespace: 
public enum NestedInteractionKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object StopScrolling;
	public const object ForwardScrolling;
}

// Namespace: 
internal enum TouchScrollingResult
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Apply;
	public const object Forward;
	public const object Block;
}

// Namespace: UnityEngine.UIElements
public class ScrollView
{

	// Fields
	private const object k_MaxLocalLayoutPassCount;
	private object m_FirstLayoutPass; // 0x3C0
	private object m_HorizontalScrollerVisibility; // 0x3C4
	private object m_VerticalScrollerVisibility; // 0x3C8
	private const object k_SizeThreshold;
	private object m_AttachedRootVisualContainer; // 0x3D0
	private object m_SingleLineHeight; // 0x3D8
	private const object k_SingleLineHeightPropertyName;
	private const object k_ScrollPageOverlapFactor;
	internal const object k_UnsetPageSizeValue;
	internal const object k_MouseWheelScrollSizeDefaultValue;
	internal const object k_MouseWheelScrollSizeUnset;
	internal object m_MouseWheelScrollSizeIsInline; // 0x3DC
	private object m_HorizontalPageSize; // 0x3E0
	private object m_VerticalPageSize; // 0x3E4
	private object m_MouseWheelScrollSize; // 0x3E8
	private static readonly object k_DefaultScrollDecelerationRate; // 0x0
	private object m_ScrollDecelerationRate; // 0x3EC
	private static readonly object k_DefaultElasticity; // 0x4
	private object m_Elasticity; // 0x3F0
	private object m_TouchScrollBehavior; // 0x3F4
	private object m_NestedInteractionKind; // 0x3F8
	private readonly object <contentViewport>k__BackingField; // 0x400
	private readonly object <horizontalScroller>k__BackingField; // 0x408
	private readonly object <verticalScroller>k__BackingField; // 0x410
	private object m_ContentContainer; // 0x418
	private object m_ContentAndVerticalScrollContainer; // 0x420
	public static readonly object ussClassName; // 0x8
	public static readonly object viewportUssClassName; // 0x10
	public static readonly object horizontalVariantViewportUssClassName; // 0x18
	public static readonly object verticalVariantViewportUssClassName; // 0x20
	public static readonly object verticalHorizontalVariantViewportUssClassName; // 0x28
	public static readonly object contentAndVerticalScrollUssClassName; // 0x30
	public static readonly object contentUssClassName; // 0x38
	public static readonly object horizontalVariantContentUssClassName; // 0x40
	public static readonly object verticalVariantContentUssClassName; // 0x48
	public static readonly object verticalHorizontalVariantContentUssClassName; // 0x50
	public static readonly object hScrollerUssClassName; // 0x58
	public static readonly object vScrollerUssClassName; // 0x60
	public static readonly object horizontalVariantUssClassName; // 0x68
	public static readonly object verticalVariantUssClassName; // 0x70
	public static readonly object verticalHorizontalVariantUssClassName; // 0x78
	public static readonly object scrollVariantUssClassName; // 0x80
	private object m_Mode; // 0x428
	private object m_ScheduledLayoutPassResetItem; // 0x430
	private object m_ScrollingPointerId; // 0x438
	private const object k_VelocityLerpTimeFactor;
	internal const object ScrollThresholdSquared;
	private object m_StartPosition; // 0x43C
	private object m_PointerStartPosition; // 0x444
	private object m_Velocity; // 0x44C
	private object m_SpringBackVelocity; // 0x454
	private object m_LowBounds; // 0x45C
	private object m_HighBounds; // 0x464
	private object m_LastVelocityLerpTime; // 0x46C
	private object m_StartedMoving; // 0x470
	private object m_TouchStoppedVelocity; // 0x471
	private object m_CapturedTarget; // 0x478
	private object m_CapturedTargetPointerMoveCallback; // 0x480
	private object m_CapturedTargetPointerUpCallback; // 0x488
	private object m_PostPointerUpAnimation; // 0x490

	// Properties
	public object horizontalScrollerVisibility { get; set; }
	public object verticalScrollerVisibility { get; set; }
	public object showHorizontal { set; }
	public object showVertical { set; }
	internal object needsHorizontal { get; }
	internal object needsVertical { get; }
	internal object isVerticalScrollDisplayed { get; }
	internal object isHorizontalScrollDisplayed { get; }
	public object scrollOffset { get; set; }
	public object horizontalPageSize { set; }
	public object verticalPageSize { set; }
	public object mouseWheelScrollSize { get; set; }
	internal object scrollableWidth { get; }
	internal object scrollableHeight { get; }
	private object hasInertia { get; }
	public object scrollDecelerationRate { get; set; }
	public object elasticity { get; set; }
	public object touchScrollBehavior { get; set; }
	public object nestedInteractionKind { get; set; }
	public object contentViewport { get; }
	public object horizontalScroller { get; }
	public object verticalScroller { get; }
	public override object contentContainer { get; }
	public object mode { get; set; }

	// Methods

	// RVA: 0x75C3DE8
	public object get_horizontalScrollerVisibility() { }

	// RVA: 0x75C3DF0
	public object set_horizontalScrollerVisibility(object value) { }

	// RVA: 0x75C46BC
	public object get_verticalScrollerVisibility() { }

	// RVA: 0x75C46C4
	public object set_verticalScrollerVisibility(object value) { }

	// RVA: 0x75C4700
	public object set_showHorizontal(object value) { }

	// RVA: 0x75C4720
	public object set_showVertical(object value) { }

	// RVA: 0x75C3E2C
	internal object get_needsHorizontal() { }

	// RVA: 0x75C3F0C
	internal object get_needsVertical() { }

	// RVA: 0x75C4850
	internal object get_isVerticalScrollDisplayed() { }

	// RVA: 0x75C4948
	internal object get_isHorizontalScrollDisplayed() { }

	// RVA: 0x75C4A40
	public object get_scrollOffset() { }

	// RVA: 0x75C4AF8
	public object set_scrollOffset(object value) { }

	// RVA: 0x75C4F5C
	public object set_horizontalPageSize(object value) { }

	// RVA: 0x75C5250
	public object set_verticalPageSize(object value) { }

	// RVA: 0x75C5544
	public object get_mouseWheelScrollSize() { }

	// RVA: 0x75C554C
	public object set_mouseWheelScrollSize(object value) { }

	// RVA: 0x75C4740
	internal object get_scrollableWidth() { }

	// RVA: 0x75C47C8
	internal object get_scrollableHeight() { }

	// RVA: 0x75C560C
	private object get_hasInertia() { }

	// RVA: 0x75C561C
	public object get_scrollDecelerationRate() { }

	// RVA: 0x75C5624
	public object set_scrollDecelerationRate(object value) { }

	// RVA: 0x75C5638
	public object get_elasticity() { }

	// RVA: 0x75C5640
	public object set_elasticity(object value) { }

	// RVA: 0x75C5654
	public object get_touchScrollBehavior() { }

	// RVA: 0x75C565C
	public object set_touchScrollBehavior(object value) { }

	// RVA: 0x75C5774
	public object get_nestedInteractionKind() { }

	// RVA: 0x75C577C
	public object set_nestedInteractionKind(object value) { }

	// RVA: 0x75C5784
	private object OnHorizontalScrollDragElementChanged(object evt) { }

	// RVA: 0x75C57CC
	private object OnVerticalScrollDragElementChanged(object evt) { }

	// RVA: 0x75C4F64
	private object UpdateHorizontalSliderPageSize() { }

	// RVA: 0x75C5258
	private object UpdateVerticalSliderPageSize() { }

	// RVA: 0x75C4C34
	internal object UpdateContentViewTransform() { }

	// RVA: 0x75C5814
	public object ScrollTo(object child) { }

	// RVA: 0x75C5DE0
	private object GetXDeltaOffset(object child) { }

	// RVA: 0x75C5B24
	private object GetYDeltaOffset(object child) { }

	// RVA: 0x75C609C
	private object GetDeltaDistance(object viewMin, object viewMax, object childBoundaryMin, object childBoundaryMax) { }

	// RVA: 0x75C60EC
	public object get_contentViewport() { }

	// RVA: 0x75C60F4
	public object get_horizontalScroller() { }

	// RVA: 0x75C60FC
	public object get_verticalScroller() { }

	// RVA: 0x75C6104
	public override object get_contentContainer() { }

	// RVA: 0x75C610C
	public object .ctor() { }

	// RVA: 0x75C6114
	public object .ctor(object scrollViewMode) { }

	// RVA: 0x75C7164
	public object get_mode() { }

	// RVA: 0x75C716C
	public object set_mode(object value) { }

	// RVA: 0x75C6D1C
	private object SetScrollViewMode(object mode) { }

	// RVA: 0x75C7180
	private object OnAttachToPanel(object evt) { }

	// RVA: 0x75C7814
	private object OnDetachFromPanel(object evt) { }

	// RVA: 0x75C7DA4
	private object OnPointerCapture(object evt) { }

	// RVA: 0x75C7EC4
	private object OnPointerCaptureOut(object evt) { }

	// RVA: 0x75C8110
	private object OnGeometryChanged(object evt) { }

	// RVA: 0x75C8204
	private object ScheduleResetLayoutPass() { }

	// RVA: 0x75C7D98
	private object ResetLayoutPass() { }

	// RVA: 0x75C846C
	private static object ComputeElasticOffset(object deltaPointer, object initialScrollOffset, object lowLimit, object hardLowLimit, object highLimit, object hardHighLimit) { }

	// RVA: 0x75C857C
	private object ComputeInitialSpringBackVelocity() { }

	// RVA: 0x75C86A0
	private object SpringBack() { }

	// RVA: 0x75C8830
	internal object ApplyScrollInertia() { }

	// RVA: 0x75C8A04
	private object PostPointerUpAnimation() { }

	// RVA: 0x75C8BA4
	private object OnPointerDown(object evt) { }

	// RVA: 0x75C9194
	private object OnPointerMove(object evt) { }

	// RVA: 0x75C9AC0
	private object OnPointerCancel(object evt) { }

	// RVA: 0x75C9B34
	private object OnPointerUp(object evt) { }

	// RVA: 0x75C8E98
	internal object InitTouchScrolling(object position) { }

	// RVA: 0x75C9400
	internal object ComputeTouchScrolling(object position) { }

	// RVA: 0x75C9C14
	private object ApplyTouchScrolling(object newScrollOffset) { }

	// RVA: 0x75C7FA4
	private object ReleaseScrolling(object pointerId, object target) { }

	// RVA: 0x75C9E58
	private object ExecuteElasticSpringAnimation() { }

	// RVA: 0x75CA0CC
	private object AdjustScrollers() { }

	// RVA: 0x75C3FEC
	internal object UpdateScrollers(object displayHorizontal, object displayVertical) { }

	// RVA: 0x75CA33C
	private object OnScrollersGeometryChanged(object evt) { }

	// RVA: 0x75CA4D8
	private object OnScrollWheel(object evt) { }

	// RVA: 0x75CAD98
	private object OnRootCustomStyleResolved(object evt) { }

	// RVA: 0x75C76EC
	private object ReadSingleLineHeight() { }

	// RVA: 0x75CAD9C
	private static object .cctor() { }

	// RVA: 0x75CB078
	private object <.ctor>b__115_0(object value) { }

	// RVA: 0x75CB0B4
	private object <.ctor>b__115_1(object value) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75CC5C8
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_LowValue; // 0x80
	private object m_HighValue; // 0x88
	private object m_PageSize; // 0x90
	private object m_ShowInputField; // 0x98
	private object m_Direction; // 0xA0
	private object m_Inverted; // 0xA8

	// Methods

	// RVA: 0x75CC620
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75CC9F4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Slider
{

	// Fields
	internal const object kDefaultHighValue;
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Methods

	// RVA: 0x75CBB60
	public object .ctor() { }

	// RVA: 0x75CBCE4
	public object .ctor(object start, object end, object direction, object pageSize) { }

	// RVA: 0x75CBB78
	public object .ctor(object label, object start, object end, object direction, object pageSize) { }

	// RVA: 0x75CBCF0
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75CBE50
	internal override object SliderLerpUnclamped(object a, object b, object interpolant) { }

	// RVA: 0x75CC198
	internal override object SliderNormalizeValue(object currentValue, object lowerValue, object higherValue) { }

	// RVA: 0x75CC1A8
	internal override object ParseStringToValue(object stringValue) { }

	// RVA: 0x75CC288
	internal override object ComputeValueFromKey(object sliderKey, object isShift) { }

	// RVA: 0x75CC4F8
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75CDB90
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_LowValue; // 0x80
	private object m_HighValue; // 0x88
	private object m_PageSize; // 0x90
	private object m_ShowInputField; // 0x98
	private object m_Direction; // 0xA0
	private object m_Inverted; // 0xA8

	// Methods

	// RVA: 0x75CDBE8
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75CDFC4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class SliderInt
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	public override object pageSize { get; set; }

	// Methods

	// RVA: 0x75CCC6C
	public object .ctor() { }

	// RVA: 0x75CCC84
	public object .ctor(object label, object start, object end, object direction, object pageSize) { }

	// RVA: 0x75CCDF0
	public override object get_pageSize() { }

	// RVA: 0x75CCE48
	public override object set_pageSize(object value) { }

	// RVA: 0x75CCF98
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75CD1B8
	internal override object SliderLerpUnclamped(object a, object b, object interpolant) { }

	// RVA: 0x75CD2DC
	internal override object SliderNormalizeValue(object currentValue, object lowerValue, object higherValue) { }

	// RVA: 0x75CD2F8
	internal override object ParseStringToValue(object stringValue) { }

	// RVA: 0x75CD330
	internal override object ComputeValueAndDirectionFromClick(object sliderLength, object dragElementLength, object dragElementPos, object dragElementLastPos) { }

	// RVA: 0x75CD754
	internal override object ComputeValueFromKey(object sliderKey, object isShift) { }

	// RVA: 0x75CDAC0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public enum DeltaSpeed
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Fast;
	public const object Normal;
	public const object Slow;
}

// Namespace: UnityEngine.UIElements
public interface IValueField<T0>
{

	// Properties
	public abstract object value { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_value() { }

	// RVA: -1
	public abstract object set_value(object value) { }

	// RVA: -1
	public abstract object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: -1
	public abstract object StartDragging() { }

	// RVA: -1
	public abstract object StopDragging() { }

}

// Namespace: 
protected abstract class TextValueInput
{

	// Fields
	private object <formatString>k__BackingField; // 0x0

	// Properties
	private object textValueFieldParent { get; }
	protected abstract object allowedCharacters { get; }
	public object formatString { get; set; }

	// Methods

	// RVA: -1
	private object get_textValueFieldParent() { }

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	internal override object AcceptCharacter(object c) { }

	// RVA: -1
	protected abstract object get_allowedCharacters() { }

	// RVA: -1
	public object get_formatString() { }

	// RVA: -1
	public object set_formatString(object value) { }

	// RVA: -1
	public abstract object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: -1
	public object StartDragging() { }

	// RVA: -1
	public object StopDragging() { }

	// RVA: -1
	protected abstract object ValueToString(object value) { }

	// RVA: -1
	protected override object StringToValue(object str) { }

}

// Namespace: UnityEngine.UIElements
public abstract class TextValueField<T0>
{

	// Fields
	private object m_Dragger; // 0x0
	internal object m_UpdateTextFromValue; // 0x0
	private object m_ForceUpdateDisplay; // 0x0

	// Properties
	private object textValueInput { get; }
	public object formatString { get; }
	public override object value { get; set; }

	// Methods

	// RVA: -1
	private object get_textValueInput() { }

	// RVA: -1
	public object get_formatString() { }

	// RVA: -1
	protected object .ctor(object label, object maxLength, object textValueInput) { }

	// RVA: -1
	public abstract object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: -1
	public object StartDragging() { }

	// RVA: -1
	public object StopDragging() { }

	// RVA: -1
	public override object get_value() { }

	// RVA: -1
	public override object set_value(object value) { }

	// RVA: -1
	internal override object UpdateValueFromText() { }

	// RVA: -1
	internal override object UpdateTextFromValue() { }

	// RVA: -1
	private object OnIsReadOnlyChanged(object newValue) { }

	// RVA: -1
	internal virtual object CanTryParse(object textString) { }

	// RVA: -1
	protected object AddLabelDragger() { }

	// RVA: -1
	private object EnableLabelDragger(object enable) { }

	// RVA: -1
	public override object SetValueWithoutNotify(object newValue) { }

	// RVA: -1
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: -1
	internal override object OnViewDataReady() { }

}

// Namespace: UnityEngine.UIElements
public class TextValueFieldTraits<T0, T1>
{

	// Fields
	private object m_IsReadOnly; // 0x0
	private object m_IsDelayed; // 0x0

	// Methods

	// RVA: -1
	public override object Init(object ve, object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75CE7BC
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Text; // 0x80

	// Methods

	// RVA: 0x75CE814
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75CE95C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class Toggle
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10
	public static readonly object noTextVariantUssClassName; // 0x18
	public static readonly object checkmarkUssClassName; // 0x20
	public static readonly object textUssClassName; // 0x28
	public static readonly object mixedValuesUssClassName; // 0x30

	// Methods

	// RVA: 0x75CE23C
	public object .ctor() { }

	// RVA: 0x75CE244
	public object .ctor(object label) { }

	// RVA: 0x75CE368
	protected override object InitLabel() { }

	// RVA: 0x75CE3F8
	protected override object UpdateMixedValueContent() { }

	// RVA: 0x75CE61C
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75CEC58
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75CECB0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class TreeView
{

	// Fields
	private object m_MakeItem; // 0x4B0
	private object m_BindItem; // 0x4B8
	private object <unbindItem>k__BackingField; // 0x4C0
	private object <destroyItem>k__BackingField; // 0x4C8

	// Properties
	public object makeItem { get; set; }
	public object bindItem { get; set; }
	public object unbindItem { get; }
	public object destroyItem { get; }

	// Methods

	// RVA: 0x75CEA08
	public object get_makeItem() { }

	// RVA: 0x75CEA10
	public object set_makeItem(object value) { }

	// RVA: 0x75CEA5C
	public object get_bindItem() { }

	// RVA: 0x75CEA64
	public object set_bindItem(object value) { }

	// RVA: 0x75CEAB0
	public object get_unbindItem() { }

	// RVA: 0x75CEAB8
	public object get_destroyItem() { }

	// RVA: 0x75CEAC0
	internal override object HasValidDataAndBindings() { }

	// RVA: 0x75CEB04
	protected override object CreateViewController() { }

	// RVA: 0x75CEB78
	public object .ctor() { }

	// RVA: 0x75CEB84
	public object .ctor(object makeItem, object bindItem) { }

}

// Namespace: UnityEngine.UIElements
internal struct TreeData<T0>
{

	// Fields
	private readonly object m_RootItemIds; // 0x0
	private readonly object m_Tree; // 0x0
	private readonly object m_ParentIds; // 0x0
	private readonly object m_ChildrenIds; // 0x0

	// Properties
	public object rootItemIds { get; }

	// Methods

	// RVA: -1
	public object get_rootItemIds() { }

	// RVA: -1
	public object .ctor(object rootItems) { }

	// RVA: -1
	public object GetDataForId(object id) { }

	// RVA: -1
	public object GetParentId(object id) { }

	// RVA: -1
	public object Move(object id, object newParentId, object childIndex) { }

	// RVA: -1
	public object HasAncestor(object childId, object ancestorId) { }

	// RVA: -1
	private object AddItemToParent(object item, object parentId, object childIndex) { }

	// RVA: -1
	private object RemoveFromParent(object id, object parentId) { }

	// RVA: -1
	private object UpdateParentTree(object current) { }

	// RVA: -1
	private object RefreshTree(object rootItems) { }

	// RVA: -1
	private object BuildTree(object items, object isRoot) { }

}

// Namespace: UnityEngine.UIElements
internal struct TreeItem
{

	// Fields
	private readonly object <id>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private readonly object <parentId>k__BackingField; // 0xFFFFFFFFFFFFFFFC
	private readonly object <childrenIds>k__BackingField; // 0x0

	// Properties
	public object id { get; }
	public object parentId { get; }
	public object childrenIds { get; }
	public object hasChildren { get; }

	// Methods

	// RVA: 0x75CECF4
	public object get_id() { }

	// RVA: 0x75CED04
	public object get_parentId() { }

	// RVA: 0x75CED14
	public object get_childrenIds() { }

	// RVA: 0x75CED24
	public object get_hasChildren() { }

	// RVA: 0x75CEDDC
	public object .ctor(object id, object parentId, object childrenIds) { }

}

// Namespace: UnityEngine.UIElements
internal struct TreeViewItemWrapper
{

	// Fields
	public readonly object item; // 0xFFFFFFFFFFFFFFF8
	public readonly object depth; // 0x8

	// Properties
	public object id { get; }
	public object childrenIds { get; }
	public object hasChildren { get; }

	// Methods

	// RVA: 0x75CEE30
	public object get_id() { }

	// RVA: 0x75CEE40
	public object get_childrenIds() { }

	// RVA: 0x75CEE50
	public object get_hasChildren() { }

	// RVA: 0x75CEF08
	public object .ctor(object item, object depth) { }

}

// Namespace: UnityEngine.UIElements
public struct TreeViewItemData<T0>
{

	// Fields
	private readonly object <id>k__BackingField; // 0x0
	private readonly object m_Data; // 0x0
	private readonly object m_Children; // 0x0

	// Properties
	public object id { get; }
	public object data { get; }
	public object children { get; }
	public object hasChildren { get; }

	// Methods

	// RVA: -1
	public object get_id() { }

	// RVA: -1
	public object get_data() { }

	// RVA: -1
	public object get_children() { }

	// RVA: -1
	public object get_hasChildren() { }

	// RVA: -1
	internal object InsertChild(object child, object index) { }

	// RVA: -1
	internal object RemoveChild(object childId) { }

	// RVA: -1
	internal object GetChildIndex(object itemId) { }

	// RVA: -1
	internal object ReplaceChild(object newChild) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75D23E8
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_FixedPaneIndex; // 0x68
	private object m_FixedPaneInitialDimension; // 0x70
	private object m_Orientation; // 0x78

	// Methods

	// RVA: 0x75D2440
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x75D2624
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class TwoPaneSplitView
{

	// Fields
	private static readonly object s_UssClassName; // 0x0
	private static readonly object s_ContentContainerClassName; // 0x8
	private static readonly object s_HandleDragLineClassName; // 0x10
	private static readonly object s_HandleDragLineVerticalClassName; // 0x18
	private static readonly object s_HandleDragLineHorizontalClassName; // 0x20
	private static readonly object s_HandleDragLineAnchorClassName; // 0x28
	private static readonly object s_HandleDragLineAnchorVerticalClassName; // 0x30
	private static readonly object s_HandleDragLineAnchorHorizontalClassName; // 0x38
	private static readonly object s_VerticalClassName; // 0x40
	private static readonly object s_HorizontalClassName; // 0x48
	private object m_LeftPane; // 0x3C0
	private object m_RightPane; // 0x3C8
	private object m_FixedPane; // 0x3D0
	private object m_FlexedPane; // 0x3D8
	private object m_FixedPaneDimension; // 0x3E0
	private object m_DragLine; // 0x3E8
	private object m_DragLineAnchor; // 0x3F0
	private object m_CollapseMode; // 0x3F8
	private object m_Content; // 0x400
	private object m_Orientation; // 0x408
	private object m_FixedPaneIndex; // 0x40C
	private object m_FixedPaneInitialDimension; // 0x410
	internal object m_Resizer; // 0x418

	// Properties
	public object fixedPane { get; }
	public object flexedPane { get; }
	public object fixedPaneIndex { get; }
	public object orientation { get; }
	internal object fixedPaneDimension { get; set; }
	public override object contentContainer { get; }

	// Methods

	// RVA: 0x75CEF20
	public object get_fixedPane() { }

	// RVA: 0x75CEF28
	public object get_flexedPane() { }

	// RVA: 0x75CEF30
	public object get_fixedPaneIndex() { }

	// RVA: 0x75CEF38
	public object get_orientation() { }

	// RVA: 0x75CEF40
	internal object get_fixedPaneDimension() { }

	// RVA: 0x75CEF7C
	internal object set_fixedPaneDimension(object value) { }

	// RVA: 0x75CEF98
	public object .ctor() { }

	// RVA: 0x75CF214
	internal object Init(object fixedPaneIndex, object fixedPaneInitialDimension, object orientation) { }

	// RVA: 0x75D0DF0
	private object OnPostDisplaySetup(object evt) { }

	// RVA: 0x75CF5AC
	private object PostDisplaySetup() { }

	// RVA: 0x75D103C
	private object OnSizeChange(object evt) { }

	// RVA: 0x75D1048
	private object UpdateLayout(object updateFixedPane, object updateDragLine) { }

	// RVA: 0x75D2200
	public override object get_contentContainer() { }

	// RVA: 0x75D2208
	internal override object OnViewDataReady() { }

	// RVA: 0x75D1E78
	private object SetDragLineOffset(object offset) { }

	// RVA: 0x75D203C
	private object SetFixedPaneDimension(object dimension) { }

	// RVA: 0x75D2250
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public enum TwoPaneSplitViewOrientation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Horizontal;
	public const object Vertical;
}

// Namespace: UnityEngine.UIElements
internal class TwoPaneSplitViewResizer
{

	// Fields
	private object m_Start; // 0x28
	protected object m_Active; // 0x34
	private object m_SplitView; // 0x38
	private object m_Direction; // 0x40

	// Properties
	private object orientation { get; }
	private object fixedPane { get; }
	private object flexedPane { get; }
	private object fixedPaneMinDimension { get; }
	private object fixedPaneMargins { get; }
	private object flexedPaneMinDimension { get; }
	private object flexedPaneMargin { get; }

	// Methods

	// RVA: 0x75D2794
	private object get_orientation() { }

	// RVA: 0x75D27B8
	private object get_fixedPane() { }

	// RVA: 0x75D27DC
	private object get_flexedPane() { }

	// RVA: 0x75D2800
	private object get_fixedPaneMinDimension() { }

	// RVA: 0x75D29B4
	private object get_fixedPaneMargins() { }

	// RVA: 0x75D2CE8
	private object get_flexedPaneMinDimension() { }

	// RVA: 0x75D2E9C
	private object get_flexedPaneMargin() { }

	// RVA: 0x75D0F00
	public object .ctor(object splitView, object dir) { }

	// RVA: 0x75D31D0
	protected override object RegisterCallbacksOnTarget() { }

	// RVA: 0x75D33B0
	protected override object UnregisterCallbacksFromTarget() { }

	// RVA: 0x75D3590
	public object ApplyDelta(object delta) { }

	// RVA: 0x75D3EEC
	protected object OnPointerDown(object e) { }

	// RVA: 0x75D3FE0
	protected object OnPointerMove(object e) { }

	// RVA: 0x75D40C8
	protected object OnPointerUp(object e) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75D48B4
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75D490C
	public object .ctor() { }

}

// Namespace: 
private class UnsignedIntegerInput
{

	// Properties
	private object parentUnsignedIntegerField { get; }
	protected override object allowedCharacters { get; }

	// Methods

	// RVA: 0x75D4964
	private object get_parentUnsignedIntegerField() { }

	// RVA: 0x75D4628
	internal object .ctor() { }

	// RVA: 0x75D49EC
	protected override object get_allowedCharacters() { }

	// RVA: 0x75D4A68
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75D4DE4
	protected override object ValueToString(object v) { }

	// RVA: 0x75D4E3C
	protected override object StringToValue(object str) { }

}

// Namespace: UnityEngine.UIElements
public class UnsignedIntegerField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	private object integerInput { get; }

	// Methods

	// RVA: 0x75D4190
	private object get_integerInput() { }

	// RVA: 0x75D4218
	protected override object ValueToString(object v) { }

	// RVA: 0x75D4328
	protected override object StringToValue(object str) { }

	// RVA: 0x75D443C
	public object .ctor() { }

	// RVA: 0x75D4448
	public object .ctor(object label, object maxLength) { }

	// RVA: 0x75D46C0
	internal override object CanTryParse(object textString) { }

	// RVA: 0x75D46EC
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75D47E4
	private static object .cctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x75D5614
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x75D566C
	public object .ctor() { }

}

// Namespace: 
private class UnsignedLongInput
{

	// Properties
	private object parentUnsignedLongField { get; }
	protected override object allowedCharacters { get; }

	// Methods

	// RVA: 0x75D56C4
	private object get_parentUnsignedLongField() { }

	// RVA: 0x75D5388
	internal object .ctor() { }

	// RVA: 0x75D574C
	protected override object get_allowedCharacters() { }

	// RVA: 0x75D57C8
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75D5B5C
	private object ClampToMinMaxULongValue(object niceDelta, object value) { }

	// RVA: 0x75D5BDC
	protected override object ValueToString(object v) { }

	// RVA: 0x75D5C34
	protected override object StringToValue(object str) { }

}

// Namespace: UnityEngine.UIElements
public class UnsignedLongField
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object labelUssClassName; // 0x8
	public static readonly object inputUssClassName; // 0x10

	// Properties
	private object unsignedLongInput { get; }

	// Methods

	// RVA: 0x75D4EF0
	private object get_unsignedLongInput() { }

	// RVA: 0x75D4F78
	protected override object ValueToString(object v) { }

	// RVA: 0x75D5088
	protected override object StringToValue(object str) { }

	// RVA: 0x75D519C
	public object .ctor() { }

	// RVA: 0x75D51A8
	public object .ctor(object label, object maxLength) { }

	// RVA: 0x75D5420
	internal override object CanTryParse(object textString) { }

	// RVA: 0x75D544C
	public override object ApplyInputDeviceDelta(object delta, object speed, object startValue) { }

	// RVA: 0x75D5544
	private static object .cctor() { }

}

// Namespace: 
public struct <m_Counters>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.UIElements
internal struct CountingBloomFilter
{

	// Fields
	private object m_Counters; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x75D5CE8
	private object AdjustSlot(object index, object increment) { }

	// RVA: 0x75D5D44
	private object Hash1(object hash) { }

	// RVA: 0x75D5D54
	private object Hash2(object hash) { }

	// RVA: 0x75D5D64
	private object IsSlotEmpty(object index) { }

	// RVA: 0x75D5D88
	public object InsertHash(object hash) { }

	// RVA: 0x75D5E1C
	public object RemoveHash(object hash) { }

	// RVA: 0x75D5E78
	public object ContainsHash(object hash) { }

}

// Namespace: UnityEngine.UIElements
internal class AncestorFilter
{

	// Fields
	private object m_CountingBloomFilter; // 0x8
	private object m_HashStack; // 0x4008

	// Methods

	// RVA: 0x75D5ECC
	public object .ctor() { }

	// RVA: 0x75D5F50
	private object AddHash(object hash) { }

	// RVA: 0x75D6014
	public object IsCandidate(object complexSel) { }

	// RVA: 0x75D60C8
	public object PushElement(object element) { }

	// RVA: 0x75D64F8
	public object PopElement() { }

}

// Namespace: UnityEngine.UIElements
public struct Cursor
{

	// Fields
	private object <texture>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <hotspot>k__BackingField; // 0x0
	private object <defaultCursorId>k__BackingField; // 0x8

	// Properties
	public object texture { get; set; }
	public object hotspot { get; set; }
	internal object defaultCursorId { get; set; }

	// Methods

	// RVA: 0x75D6654
	public object get_texture() { }

	// RVA: 0x75D6664
	public object set_texture(object value) { }

	// RVA: 0x75D6674
	public object get_hotspot() { }

	// RVA: 0x75D6684
	public object set_hotspot(object value) { }

	// RVA: 0x75D6694
	internal object get_defaultCursorId() { }

	// RVA: 0x75D66A4
	internal object set_defaultCursorId(object value) { }

	// RVA: 0x75D66B4
	public override object Equals(object obj) { }

	// RVA: 0x75D682C
	public object Equals(object other) { }

	// RVA: 0x75D6A14
	public override object GetHashCode() { }

	// RVA: 0x75D6B60
	public static object op_Equality(object style1, object style2) { }

	// RVA: 0x75D6C54
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
internal interface ICursorManager
{

	// Methods

	// RVA: -1
	public abstract object SetCursor(object cursor) { }

	// RVA: -1
	public abstract object ResetCursor() { }

}

// Namespace: UnityEngine.UIElements
internal class CursorManager
{

	// Fields
	private object <isCursorOverriden>k__BackingField; // 0x8

	// Properties
	public object isCursorOverriden { get; set; }

	// Methods

	// RVA: 0x75D6D7C
	public object get_isCursorOverriden() { }

	// RVA: 0x75D6D84
	private object set_isCursorOverriden(object value) { }

	// RVA: 0x75D6D8C
	public object SetCursor(object cursor) { }

	// RVA: 0x75D6EF4
	public object ResetCursor() { }

	// RVA: 0x75D6F6C
	public object .ctor() { }

}

// Namespace: 
public enum UpdateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Always;
	public const object IgnoreIfAppNotFocused;
}

// Namespace: 
internal struct FocusBasedEventSequenceContext
{

	// Fields
	private object es; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x75D95BC
	public object .ctor(object es) { }

	// RVA: 0x75DA580
	public object Dispose() { }

}

// Namespace: 
internal interface IInput
{

	// Properties
	public abstract object touchCount { get; }
	public abstract object mousePresent { get; }
	public abstract object mousePosition { get; }
	public abstract object mouseButtonCount { get; }
	public abstract object anyKey { get; }
	public abstract object unscaledTime { get; }
	public abstract object doubleClickTime { get; }

	// Methods

	// RVA: -1
	public abstract object GetButtonDown(object button) { }

	// RVA: -1
	public abstract object GetAxisRaw(object axis) { }

	// RVA: -1
	public abstract object ClearLastPenContactEvent() { }

	// RVA: -1
	public abstract object GetLastPenContactEvent() { }

	// RVA: -1
	public abstract object get_touchCount() { }

	// RVA: -1
	public abstract object GetTouch(object index) { }

	// RVA: -1
	public abstract object get_mousePresent() { }

	// RVA: -1
	public abstract object GetMouseButtonDown(object button) { }

	// RVA: -1
	public abstract object GetMouseButtonUp(object button) { }

	// RVA: -1
	public abstract object get_mousePosition() { }

	// RVA: -1
	public abstract object get_mouseButtonCount() { }

	// RVA: -1
	public abstract object get_anyKey() { }

	// RVA: -1
	public abstract object get_unscaledTime() { }

	// RVA: -1
	public abstract object get_doubleClickTime() { }

}

// Namespace: 
private class Input
{

	// Properties
	public object touchCount { get; }
	public object mousePresent { get; }
	public object mousePosition { get; }
	public object mouseButtonCount { get; }
	public object anyKey { get; }
	public object unscaledTime { get; }
	public object doubleClickTime { get; }

	// Methods

	// RVA: 0x75DA5C8
	public object GetButtonDown(object button) { }

	// RVA: 0x75DA5D4
	public object GetAxisRaw(object axis) { }

	// RVA: 0x75DA5E0
	public object ClearLastPenContactEvent() { }

	// RVA: 0x75DA5E8
	public object GetLastPenContactEvent() { }

	// RVA: 0x75DA5F0
	public object get_touchCount() { }

	// RVA: 0x75DA5F8
	public object GetTouch(object index) { }

	// RVA: 0x75DA604
	public object get_mousePresent() { }

	// RVA: 0x75DA60C
	public object GetMouseButtonDown(object button) { }

	// RVA: 0x75DA618
	public object GetMouseButtonUp(object button) { }

	// RVA: 0x75DA624
	public object get_mousePosition() { }

	// RVA: 0x75DA62C
	public object get_mouseButtonCount() { }

	// RVA: 0x75DA634
	public object get_anyKey() { }

	// RVA: 0x75DA63C
	public object get_unscaledTime() { }

	// RVA: 0x75DA644
	public object get_doubleClickTime() { }

	// RVA: 0x75D71F8
	public object .ctor() { }

}

// Namespace: 
private class NoInput
{

	// Properties
	public object touchCount { get; }
	public object mousePresent { get; }
	public object mousePosition { get; }
	public object mouseButtonCount { get; }
	public object anyKey { get; }
	public object unscaledTime { get; }
	public object doubleClickTime { get; }

	// Methods

	// RVA: 0x75DA670
	public object GetButtonDown(object button) { }

	// RVA: 0x75DA678
	public object GetAxisRaw(object axis) { }

	// RVA: 0x75DA680
	public object get_touchCount() { }

	// RVA: 0x75DA688
	public object GetTouch(object index) { }

	// RVA: 0x75DA69C
	public object ClearLastPenContactEvent() { }

	// RVA: 0x75DA6A0
	public object GetLastPenContactEvent() { }

	// RVA: 0x75DA6B0
	public object get_mousePresent() { }

	// RVA: 0x75DA6B8
	public object GetMouseButtonDown(object button) { }

	// RVA: 0x75DA6C0
	public object GetMouseButtonUp(object button) { }

	// RVA: 0x75DA6C8
	public object get_mousePosition() { }

	// RVA: 0x75DA6D8
	public object get_mouseButtonCount() { }

	// RVA: 0x75DA6E0
	public object get_anyKey() { }

	// RVA: 0x75DA6E8
	public object get_unscaledTime() { }

	// RVA: 0x75DA6F0
	public object get_doubleClickTime() { }

	// RVA: 0x75D7200
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__30_0; // 0x8
	public static object <>9__30_1; // 0x10
	public static object <>9__30_2; // 0x18
	public static object <>9__36_0; // 0x20
	public static object <>9__36_1; // 0x28
	public static object <>9__36_2; // 0x30
	public static object <>9__37_0; // 0x38
	public static object <>9__37_1; // 0x40
	public static object <>9__37_2; // 0x48
	public static object <>9__44_0; // 0x50
	public static object <>9__45_0; // 0x58
	public static object <>9__51_0; // 0x60

	// Methods

	// RVA: 0x75DA6FC
	private static object .cctor() { }

	// RVA: 0x75DA75C
	public object .ctor() { }

	// RVA: 0x75DA764
	internal object <SendIMGUIEvents>b__30_0(object self) { }

	// RVA: 0x75DA7E8
	internal object <SendIMGUIEvents>b__30_1(object panelPosition, object _, object t) { }

	// RVA: 0x75DA888
	internal object <SendIMGUIEvents>b__30_2(object panelPosition, object panelDelta, object evt) { }

	// RVA: 0x75DA93C
	internal object <ProcessMouseEvents>b__36_0(object panelPosition, object panelDelta, object self) { }

	// RVA: 0x75DA9E4
	internal object <ProcessMouseEvents>b__36_1(object panelPosition, object panelDelta, object t) { }

	// RVA: 0x75DA9F8
	internal object <ProcessMouseEvents>b__36_2(object panelPosition, object panelDelta, object t) { }

	// RVA: 0x75DAA0C
	internal object <SendInputEvents>b__37_0(object self) { }

	// RVA: 0x75DAB78
	internal object <SendInputEvents>b__37_1(object self) { }

	// RVA: 0x75DACA0
	internal object <SendInputEvents>b__37_2(object self) { }

	// RVA: 0x75DADC8
	internal object <ProcessTouchEvents>b__44_0(object panelPosition, object panelDelta, object _touch) { }

	// RVA: 0x75DAEB0
	internal object <ProcessPenEvents>b__45_0(object panelPosition, object panelDelta, object _pen) { }

	// RVA: 0x75DB008
	internal object <ProcessTabEvent>b__51_0(object t) { }

	// RVA: 0x75DB144
	internal object <.cctor>b__56_0() { }

}

// Namespace: UnityEngine.UIElements
internal class DefaultEventSystem
{

	// Fields
	internal static object IsEditorRemoteConnected; // 0x0
	private object m_Input; // 0x8
	private readonly object m_HorizontalAxis; // 0x10
	private readonly object m_VerticalAxis; // 0x18
	private readonly object m_SubmitButton; // 0x20
	private readonly object m_CancelButton; // 0x28
	private readonly object m_InputActionsPerSecond; // 0x30
	private readonly object m_RepeatDelay; // 0x34
	private object m_SendingTouchEvents; // 0x38
	private object m_SendingPenEvent; // 0x39
	private object m_Event; // 0x40
	private object m_FocusedPanel; // 0x48
	private object m_PreviousFocusedPanel; // 0x50
	private object m_PreviousFocusedElement; // 0x58
	private object m_CurrentModifiers; // 0x60
	private object m_LastMousePressButton; // 0x64
	private object m_NextMousePressTime; // 0x68
	private object m_LastMouseClickCount; // 0x6C
	private object m_LastMousePosition; // 0x70
	private object m_MouseProcessedAtLeastOnce; // 0x78
	private object m_ConsecutiveMoveCount; // 0x7C
	private object m_LastMoveVector; // 0x80
	private object m_PrevActionTime; // 0x88

	// Properties
	private object isAppFocused { get; }
	internal object input { get; }
	public object focusedPanel { get; set; }

	// Methods

	// RVA: 0x75D6F74
	private object get_isAppFocused() { }

	// RVA: 0x75D6FE4
	internal object get_input() { }

	// RVA: 0x75D7020
	private object GetDefaultInput() { }

	// RVA: 0x75D7208
	private object ShouldIgnoreEventsOnAppNotFocused() { }

	// RVA: 0x75D722C
	public object get_focusedPanel() { }

	// RVA: 0x75D7234
	public object set_focusedPanel(object value) { }

	// RVA: 0x75D7288
	public object Update(object updateMode) { }

	// RVA: 0x75D885C
	internal object FocusBasedEventSequence() { }

	// RVA: 0x75D88F4
	private object SendIMGUIEvents() { }

	// RVA: 0x75D7CB0
	private object ProcessMouseEvents() { }

	// RVA: 0x75D913C
	private object SendInputEvents() { }

	// RVA: -1
	internal object SendFocusBasedEvent(object evtFactory, object arg) { }

	// RVA: -1
	private object SendPositionBasedEvent(object mousePosition, object delta, object pointerId, object targetDisplay, object evtFactory, object arg, object deselectIfNoTarget) { }

	// RVA: 0x75D9C28
	private object UpdateFocusedPanel(object runtimePanel) { }

	// RVA: 0x75D9CF0
	private static object MakeTouchEvent(object touch, object modifiers) { }

	// RVA: 0x75D9E70
	private static object MakePenEvent(object pen, object modifiers) { }

	// RVA: 0x75D77A0
	private object ProcessTouchEvents() { }

	// RVA: 0x75D7468
	private object ProcessPenEvents() { }

	// RVA: 0x75D9F3C
	private object GetRawMoveVector() { }

	// RVA: 0x75D97F8
	private object ShouldSendMoveFromInput() { }

	// RVA: 0x75D9650
	private object ProcessTabEvent(object e, object modifiers) { }

	// RVA: 0x75DA2B4
	public object .ctor() { }

	// RVA: 0x75DA3E8
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class DisposeHelper
{

	// Methods

	// RVA: 0x75DB14C
	public static object NotifyDisposedUsed(object disposable) { }

}

// Namespace: UnityEngine.UIElements
internal abstract class BaseReorderableDragAndDropController
{

	// Fields
	protected readonly object m_View; // 0x8
	protected object m_SortedSelectedIds; // 0x10
	private object <enableReordering>k__BackingField; // 0x18

	// Properties
	public virtual object enableReordering { get; set; }

	// Methods

	// RVA: 0x75DB268
	public object GetSortedSelectedIds() { }

	// RVA: 0x75DB270
	protected object .ctor(object view) { }

	// RVA: 0x75DB30C
	public virtual object get_enableReordering() { }

	// RVA: 0x75DB314
	public virtual object set_enableReordering(object value) { }

	// RVA: 0x75DB31C
	public virtual object CanStartDrag(object itemIds) { }

	// RVA: 0x75DB360
	public virtual object SetupDragAndDrop(object itemIds, object skipText) { }

	// RVA: 0x75DBDC8
	protected virtual object CompareId(object id1, object id2) { }

	// RVA: -1
	public abstract object HandleDragAndDrop(object args) { }

	// RVA: -1
	public abstract object OnDrop(object args) { }

	// RVA: 0x75DBDF4
	public virtual object DragCleanup() { }

	// RVA: 0x75DBDF8
	public virtual object HandleAutoExpand(object item, object pointerPosition) { }

}

// Namespace: UnityEngine.UIElements
internal static class DragAndDropUtility
{

	// Fields
	private static object s_MakeDragAndDropClientFunc; // 0x0
	private static object s_DragAndDropEditor; // 0x8
	private static object s_DragAndDropPlayMode; // 0x10

	// Methods

	// RVA: 0x75DBDFC
	internal static object GetDragAndDrop(object panel) { }

}

// Namespace: UnityEngine.UIElements
internal class DefaultDragAndDropClient
{

	// Fields
	private readonly object m_GenericData; // 0x8
	private object m_DraggedInfoLabel; // 0x10
	private object m_VisualMode; // 0x18
	private object m_UnityObjectReferences; // 0x20

	// Properties
	public override object source { get; }
	public object data { get; }

	// Methods

	// RVA: 0x75DC094
	public override object get_source() { }

	// RVA: 0x75DC108
	public override object GetGenericData(object key) { }

	// RVA: 0x75DC1C4
	public object StartDrag(object args, object pointerPosition) { }

	// RVA: 0x75DC9F4
	public object UpdateDrag(object pointerPosition) { }

	// RVA: 0x75DCBEC
	public object AcceptDrag() { }

	// RVA: 0x75DCBF0
	public object SetVisualMode(object mode) { }

	// RVA: 0x75DCBF8
	public object DragCleanup() { }

	// RVA: 0x75DCC64
	public object get_data() { }

	// RVA: 0x75DC028
	public object .ctor() { }

}

// Namespace: 
internal enum DragState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object CanStartDrag;
	public const object Dragging;
}

// Namespace: UnityEngine.UIElements
internal abstract class DragEventsProcessor
{

	// Fields
	private object m_IsRegistered; // 0x8
	private object m_DragState; // 0xC
	private object m_Start; // 0x10
	protected readonly object m_Target; // 0x20

	// Properties
	protected virtual object supportsDragEvents { get; }
	private object useDragEvents { get; }
	protected object dragAndDrop { get; }
	internal virtual object isEditorContext { get; }

	// Methods

	// RVA: 0x75DCC70
	protected virtual object get_supportsDragEvents() { }

	// RVA: 0x75DCC78
	private object get_useDragEvents() { }

	// RVA: 0x75DCCE8
	protected object get_dragAndDrop() { }

	// RVA: 0x75DCD14
	internal virtual object get_isEditorContext() { }

	// RVA: 0x75DCEA4
	internal object .ctor(object target) { }

	// RVA: 0x75DD34C
	private object RegisterCallbacksFromTarget(object evt) { }

	// RVA: 0x75DCFF8
	private object RegisterCallbacksFromTarget() { }

	// RVA: 0x75DD350
	private object UnregisterCallbacksFromTarget(object evt) { }

	// RVA: 0x75DD358
	internal object UnregisterCallbacksFromTarget(object unregisterPanelEvents) { }

	// RVA: -1
	protected abstract object CanStartDrag(object pointerPosition) { }

	// RVA: -1
	protected internal abstract object StartDrag(object pointerPosition) { }

	// RVA: -1
	protected internal abstract object UpdateDrag(object pointerPosition) { }

	// RVA: -1
	protected internal abstract object OnDrop(object pointerPosition) { }

	// RVA: -1
	protected abstract object ClearDragAndDropUI(object dragCancelled) { }

	// RVA: 0x75DD7B4
	private object OnPointerDownEvent(object evt) { }

	// RVA: 0x75DD8F4
	internal object OnPointerUpEvent(object evt) { }

	// RVA: 0x75DDCCC
	private object OnPointerLeaveEvent(object evt) { }

	// RVA: 0x75DDD10
	private object OnPointerCancelEvent(object evt) { }

	// RVA: 0x75DDEE0
	private object OnPointerCapturedOut(object evt) { }

	// RVA: 0x75DE080
	private object OnPointerMoveEvent(object evt) { }

	// RVA: 0x75DDB90
	private object GetDropTarget(object position) { }

}

// Namespace: UnityEngine.UIElements
internal interface ICollectionDragAndDropController
{
}

// Namespace: UnityEngine.UIElements
internal interface IDragAndDrop
{

	// Properties
	public abstract object data { get; }

	// Methods

	// RVA: -1
	public abstract object StartDrag(object args, object pointerPosition) { }

	// RVA: -1
	public abstract object UpdateDrag(object pointerPosition) { }

	// RVA: -1
	public abstract object AcceptDrag() { }

	// RVA: -1
	public abstract object DragCleanup() { }

	// RVA: -1
	public abstract object SetVisualMode(object visualMode) { }

	// RVA: -1
	public abstract object get_data() { }

}

// Namespace: UnityEngine.UIElements
internal abstract class DragAndDropData
{

	// Properties
	public abstract object source { get; }

	// Methods

	// RVA: -1
	public abstract object GetGenericData(object key) { }

	// RVA: -1
	public abstract object get_source() { }

	// RVA: 0x75DCC68
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal interface IListDragAndDropArgs
{

	// Properties
	public abstract object insertAtIndex { get; }
	public abstract object parentId { get; }
	public abstract object childIndex { get; }
	public abstract object dragAndDropData { get; }
	public abstract object dragAndDropPosition { get; }

	// Methods

	// RVA: -1
	public abstract object get_insertAtIndex() { }

	// RVA: -1
	public abstract object get_parentId() { }

	// RVA: -1
	public abstract object get_childIndex() { }

	// RVA: -1
	public abstract object get_dragAndDropData() { }

	// RVA: -1
	public abstract object get_dragAndDropPosition() { }

}

// Namespace: UnityEngine.UIElements
internal struct DragAndDropArgs
{

	// Fields
	private object <target>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <insertAtIndex>k__BackingField; // 0x0
	private object <parentId>k__BackingField; // 0x4
	private object <childIndex>k__BackingField; // 0x8
	private object <dragAndDropPosition>k__BackingField; // 0xC
	private object <dragAndDropData>k__BackingField; // 0x10

	// Properties
	public object target { set; }
	public object insertAtIndex { get; set; }
	public object parentId { get; set; }
	public object childIndex { get; set; }
	public object dragAndDropPosition { get; set; }
	public object dragAndDropData { get; set; }

	// Methods

	// RVA: 0x75DE4D8
	public object set_target(object value) { }

	// RVA: 0x75DE4E8
	public object get_insertAtIndex() { }

	// RVA: 0x75DE4F8
	public object set_insertAtIndex(object value) { }

	// RVA: 0x75DE508
	public object get_parentId() { }

	// RVA: 0x75DE518
	public object set_parentId(object value) { }

	// RVA: 0x75DE528
	public object get_childIndex() { }

	// RVA: 0x75DE538
	public object set_childIndex(object value) { }

	// RVA: 0x75DE548
	public object get_dragAndDropPosition() { }

	// RVA: 0x75DE558
	public object set_dragAndDropPosition(object value) { }

	// RVA: 0x75DE568
	public object get_dragAndDropData() { }

	// RVA: 0x75DE578
	public object set_dragAndDropData(object value) { }

}

// Namespace: UnityEngine.UIElements
internal enum DragAndDropPosition
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OverItem;
	public const object BetweenItems;
	public const object OutsideItems;
}

// Namespace: UnityEngine.UIElements
internal interface IDragAndDropController<T0>
{

	// Methods

	// RVA: -1
	public abstract object CanStartDrag(object itemIds) { }

	// RVA: -1
	public abstract object SetupDragAndDrop(object itemIds, object skipText) { }

	// RVA: -1
	public abstract object HandleDragAndDrop(object args) { }

	// RVA: -1
	public abstract object OnDrop(object args) { }

	// RVA: -1
	public virtual object DragCleanup() { }

	// RVA: -1
	public virtual object HandleAutoExpand(object item, object pointerPosition) { }

	// RVA: -1
	public virtual object GetSortedSelectedIds() { }

}

// Namespace: UnityEngine.UIElements
internal enum DragVisualMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Copy;
	public const object Move;
	public const object Rejected;
}

// Namespace: UnityEngine.UIElements
internal struct CanStartDragArgs
{

	// Fields
	public readonly object draggedElement; // 0xFFFFFFFFFFFFFFF8
	public readonly object id; // 0x0
	public readonly object selectedIds; // 0x8

	// Methods

	// RVA: 0x75DE5C4
	internal object .ctor(object draggedElement, object id, object selectedIds) { }

}

// Namespace: UnityEngine.UIElements
internal struct SetupDragAndDropArgs
{

	// Fields
	public readonly object draggedElement; // 0xFFFFFFFFFFFFFFF8
	public readonly object selectedIds; // 0x0
	public readonly object startDragArgs; // 0x8

	// Methods

	// RVA: 0x75DE620
	internal object .ctor(object draggedElement, object selectedIds, object startDragArgs) { }

}

// Namespace: UnityEngine.UIElements
internal struct HandleDragAndDropArgs
{

	// Fields
	private readonly object m_DragAndDropArgs; // 0xFFFFFFFFFFFFFFF8
	private readonly object <position>k__BackingField; // 0x18

	// Methods

	// RVA: 0x75DE688
	internal object .ctor(object position, object dragAndDropArgs) { }

}

// Namespace: UnityEngine.UIElements
internal struct StartDragArgs
{

	// Fields
	private readonly object <title>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private readonly object <visualMode>k__BackingField; // 0x0
	private object <genericData>k__BackingField; // 0x8
	private object <unityObjectReferences>k__BackingField; // 0x10

	// Properties
	public object title { get; }
	public object visualMode { get; }
	internal object genericData { get; set; }
	internal object unityObjectReferences { get; set; }

	// Methods

	// RVA: 0x75DBDB8
	public object .ctor(object title, object visualMode) { }

	// RVA: 0x75DE700
	public object get_title() { }

	// RVA: 0x75DE710
	public object get_visualMode() { }

	// RVA: 0x75DE720
	internal object get_genericData() { }

	// RVA: 0x75DE730
	private object set_genericData(object value) { }

	// RVA: 0x75DE740
	internal object get_unityObjectReferences() { }

	// RVA: 0x75DE750
	private object set_unityObjectReferences(object value) { }

	// RVA: 0x75DE760
	public object SetGenericData(object key, object data) { }

}

// Namespace: UnityEngine.UIElements
internal interface IReorderable
{

	// Properties
	public abstract object enableReordering { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_enableReordering() { }

	// RVA: -1
	public abstract object set_enableReordering(object value) { }

}

// Namespace: 
internal struct DragPosition
{

	// Fields
	public object insertAtIndex; // 0xFFFFFFFFFFFFFFF8
	public object parentId; // 0xFFFFFFFFFFFFFFFC
	public object childIndex; // 0x0
	public object recycledItem; // 0x8
	public object dropPosition; // 0x10

	// Methods

	// RVA: 0x75E19A4
	public object Equals(object other) { }

	// RVA: 0x75E464C
	public override object Equals(object obj) { }

	// RVA: 0x75E4750
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal class ListViewDragger
{

	// Fields
	private object m_LastDragPosition; // 0x28
	private object m_DragHoverBar; // 0x48
	private object m_DragHoverItemMarker; // 0x50
	private object m_DragHoverSiblingMarker; // 0x58
	private object m_LeftIndentation; // 0x60
	private object m_SiblingBottom; // 0x64
	private object <dragAndDropController>k__BackingField; // 0x68

	// Properties
	protected object targetView { get; }
	protected object targetScrollView { get; }
	public object dragAndDropController { get; set; }

	// Methods

	// RVA: 0x75DE8C0
	protected object get_targetView() { }

	// RVA: 0x75DE948
	protected object get_targetScrollView() { }

	// RVA: 0x75DE9D0
	public object get_dragAndDropController() { }

	// RVA: 0x75DE9D8
	public object set_dragAndDropController(object value) { }

	// RVA: 0x75DE9E0
	public object .ctor(object listView) { }

	// RVA: 0x75DE9EC
	protected override object CanStartDrag(object pointerPosition) { }

	// RVA: 0x75DF42C
	protected internal override object StartDrag(object pointerPosition) { }

	// RVA: 0x75DFAAC
	protected internal override object UpdateDrag(object pointerPosition) { }

	// RVA: 0x75DFD18
	private object GetVisualMode(object pointerPosition, object dragPosition) { }

	// RVA: 0x75E149C
	protected internal override object OnDrop(object pointerPosition) { }

	// RVA: 0x75DFF50
	internal object HandleDragAndScroll(object pointerPosition) { }

	// RVA: 0x75E037C
	private object HandleAutoExpansion(object pointerPosition) { }

	// RVA: 0x75E0498
	private object ApplyDragAndDropUI(object dragPosition) { }

	// RVA: 0x75E271C
	protected virtual object TryGetDragPosition(object pointerPosition, object dragPosition) { }

	// RVA: 0x75E2D5C
	private object HandleTreePosition(object pointerPosition, object dragPosition) { }

	// RVA: 0x75E2F04
	private object HandleSiblingInsertionAtAvailableDepthsAndChangeTargetIfNeeded(object dragPosition, object pointerPosition) { }

	// RVA: 0x75E3604
	private object GetPreviousAndNextItemsIgnoringDraggedItems(object insertAtIndex, object previousItemId, object nextItemId) { }

	// RVA: 0x75E12A8
	protected object MakeDragAndDropArgs(object dragPosition) { }

	// RVA: 0x75E3A74
	private object GetHoverBarTopPosition(object item) { }

	// RVA: 0x75E26F4
	private object PlaceHoverBarAtElement(object item) { }

	// RVA: 0x75E1A20
	private object PlaceHoverBarAt(object top, object indentationPadding, object siblingBottom) { }

	// RVA: 0x75E3BA4
	protected override object ClearDragAndDropUI(object dragCancelled) { }

	// RVA: 0x75DEFB8
	protected object GetRecycledItem(object pointerPosition) { }

	// RVA: 0x75E4414
	private object <ApplyDragAndDropUI>g__GeometryChangedCallback|27_0(object e) { }

}

// Namespace: UnityEngine.UIElements
internal static class ListViewDraggerExtension
{

	// Methods

	// RVA: 0x75DB9F8
	public static object GetRecycledItemFromId(object listView, object id) { }

	// RVA: 0x75E2334
	public static object GetRecycledItemFromIndex(object listView, object index) { }

}

// Namespace: UnityEngine.UIElements
internal class ListViewDraggerAnimated
{

	// Fields
	private object m_DragStartIndex; // 0x70
	private object m_CurrentIndex; // 0x74
	private object m_SelectionHeight; // 0x78
	private object m_LocalOffsetOnStart; // 0x7C
	private object m_CurrentPointerPosition; // 0x80
	private object m_Item; // 0x90
	private object m_OffsetItem; // 0x98
	private object <isDragging>k__BackingField; // 0xA0

	// Properties
	public object isDragging { get; set; }
	public object draggedItem { get; }
	protected override object supportsDragEvents { get; }

	// Methods

	// RVA: 0x75E4870
	public object get_isDragging() { }

	// RVA: 0x75E4878
	private object set_isDragging(object value) { }

	// RVA: 0x75E4880
	public object get_draggedItem() { }

	// RVA: 0x75E4888
	protected override object get_supportsDragEvents() { }

	// RVA: 0x75E4890
	public object .ctor(object listView) { }

	// RVA: 0x75E489C
	protected internal override object StartDrag(object pointerPosition) { }

	// RVA: 0x75E5A10
	protected internal override object UpdateDrag(object pointerPosition) { }

	// RVA: 0x75E554C
	private object Animate(object element, object paddingTop) { }

	// RVA: 0x75E6848
	protected internal override object OnDrop(object pointerPosition) { }

	// RVA: 0x75E6EAC
	protected override object ClearDragAndDropUI(object dragCancelled) { }

	// RVA: 0x75E6EB0
	protected override object TryGetDragPosition(object pointerPosition, object dragPosition) { }

}

// Namespace: UnityEngine.UIElements
internal class ListViewReorderableDragAndDropController
{

	// Fields
	protected readonly object m_ListView; // 0x20

	// Methods

	// RVA: 0x75E6ED0
	public object .ctor(object view) { }

	// RVA: 0x75E6F70
	public override object HandleDragAndDrop(object args) { }

	// RVA: 0x75E7170
	public override object OnDrop(object args) { }

}

// Namespace: 
protected class DropData
{

	// Fields
	public object expandedIdsBeforeDrag; // 0x8
	public object draggedIds; // 0x10
	public object lastItemId; // 0x18
	public object expandItemBeginTimerMs; // 0x1C
	public object expandItemBeginPosition; // 0x20

	// Methods

	// RVA: 0x75E76D8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class TreeViewReorderableDragAndDropController
{

	// Fields
	protected object m_DropData; // 0x20
	protected readonly object m_TreeView; // 0x28
	private object m_ExpandDropItemScheduledItem; // 0x30
	private object m_ExpandDropItemCallback; // 0x38

	// Methods

	// RVA: 0x75E75A0
	public object .ctor(object view) { }

	// RVA: 0x75E76E8
	protected override object CompareId(object id1, object id2) { }

	// RVA: 0x75E7F3C
	public override object SetupDragAndDrop(object itemIds, object skipText) { }

	// RVA: 0x75E7FE4
	public override object HandleDragAndDrop(object args) { }

	// RVA: 0x75E8150
	public override object OnDrop(object args) { }

	// RVA: 0x75E8B90
	public override object DragCleanup() { }

	// RVA: 0x75E8D08
	private object RestoreExpanded(object ids) { }

	// RVA: 0x75E9114
	public override object HandleAutoExpand(object item, object pointerPosition) { }

	// RVA: 0x75E9280
	private object DelayExpandDropItem() { }

	// RVA: 0x75E9554
	private object ExpandDropItem() { }

}

// Namespace: UnityEngine.UIElements
public class DropdownMenuEventInfo
{

	// Fields
	private readonly object <modifiers>k__BackingField; // 0x8
	private readonly object <mousePosition>k__BackingField; // 0xC
	private readonly object <localMousePosition>k__BackingField; // 0x14
	private readonly object <character>k__BackingField; // 0x1C
	private readonly object <keyCode>k__BackingField; // 0x20

	// Methods

	// RVA: 0x75E97E0
	public object .ctor(object e) { }

}

// Namespace: UnityEngine.UIElements
public abstract class DropdownMenuItem
{

	// Methods

	// RVA: 0x75E9BA4
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class DropdownMenuSeparator
{

	// Fields
	private readonly object <subMenuPath>k__BackingField; // 0x8

	// Methods

	// RVA: 0x75E9BAC
	public object .ctor(object subMenuPath) { }

}

// Namespace: 
public enum Status
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Normal;
	public const object Disabled;
	public const object Checked;
	public const object Hidden;
}

// Namespace: UnityEngine.UIElements
public class DropdownMenuAction
{

	// Fields
	private readonly object <name>k__BackingField; // 0x8
	private object <status>k__BackingField; // 0x10
	private object <eventInfo>k__BackingField; // 0x18
	private object <userData>k__BackingField; // 0x20
	private readonly object actionCallback; // 0x28
	private readonly object actionStatusCallback; // 0x30

	// Properties
	private object status { set; }
	private object eventInfo { set; }
	private object userData { set; }

	// Methods

	// RVA: 0x75E9BD8
	private object set_status(object value) { }

	// RVA: 0x75E9BE0
	private object set_eventInfo(object value) { }

	// RVA: 0x75E9BE8
	private object set_userData(object value) { }

	// RVA: 0x75E9BF0
	public static object AlwaysEnabled(object a) { }

	// RVA: 0x75E9BF8
	public static object AlwaysDisabled(object a) { }

	// RVA: 0x75E9C00
	public object .ctor(object actionName, object actionCallback, object actionStatusCallback, object userData) { }

	// RVA: 0x75E9C50
	public object UpdateActionStatus(object eventInfo) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object status; // 0x8

	// Methods

	// RVA: 0x75E9F54
	public object .ctor() { }

	// RVA: 0x75EA620
	internal object <AppendAction>b__0(object e) { }

}

// Namespace: UnityEngine.UIElements
public class DropdownMenu
{

	// Fields
	private object m_MenuItems; // 0x8
	private object m_DropdownMenuEventInfo; // 0x10

	// Methods

	// RVA: 0x75E9CA4
	public object MenuItems() { }

	// RVA: 0x75E9CAC
	public object AppendAction(object actionName, object action, object actionStatusCallback, object userData) { }

	// RVA: 0x75E9E24
	public object AppendAction(object actionName, object action, object status) { }

	// RVA: 0x75E9F5C
	public object AppendSeparator(object subMenuPath) { }

	// RVA: 0x75EA144
	public object InsertSeparator(object subMenuPath, object atIndex) { }

	// RVA: 0x75EA298
	public object PrepareForDisplay(object e) { }

	// RVA: 0x75EA5A0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal static class DropdownUtility
{

	// Fields
	internal static object MakeDropdownFunc; // 0x0

	// Methods

	// RVA: 0x75EA628
	internal static object CreateDropdown() { }

}

// Namespace: UnityEngine.UIElements
internal enum DispatchMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Queued;
	public const object Immediate;
}

// Namespace: UnityEngine.UIElements
public struct EventDispatcherGate
{

	// Fields
	private readonly object m_Dispatcher; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x75EA6F8
	public object .ctor(object d) { }

	// RVA: 0x75EA7C8
	public object Dispose() { }

	// RVA: 0x75EA810
	public object Equals(object other) { }

	// RVA: 0x75EA828
	public override object Equals(object obj) { }

	// RVA: 0x75EA968
	public override object GetHashCode() { }

}

// Namespace: 
private struct EventRecord
{

	// Fields
	public object m_Event; // 0xFFFFFFFFFFFFFFF8
	public object m_Panel; // 0x0
}

// Namespace: 
private struct DispatchContext
{

	// Fields
	public object m_GateCount; // 0xFFFFFFFFFFFFFFF8
	public object m_Queue; // 0x0
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75ECABC
	private static object .cctor() { }

	// RVA: 0x75ECB1C
	public object .ctor() { }

	// RVA: 0x75ECB24
	internal object <.cctor>b__31_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class EventDispatcher
{

	// Fields
	internal object m_ClickDetector; // 0x8
	private object m_DispatchingStrategies; // 0x10
	private static readonly object k_EventQueuePool; // 0x0
	private object m_Queue; // 0x18
	private readonly object <pointerState>k__BackingField; // 0x20
	private object m_GateCount; // 0x28
	private object m_DispatchContexts; // 0x30
	private static readonly object s_EditorStrategies; // 0x8
	private object m_Immediate; // 0x38
	private object <processingEvents>k__BackingField; // 0x39

	// Properties
	internal object pointerState { get; }
	private object dispatchImmediately { get; }
	private object processingEvents { set; }

	// Methods

	// RVA: 0x75EAA08
	internal object get_pointerState() { }

	// RVA: 0x75EAA10
	internal static object CreateForRuntime(object strategies) { }

	// RVA: 0x75EAA74
	private object .ctor(object strategies) { }

	// RVA: 0x75EAC44
	private object get_dispatchImmediately() { }

	// RVA: 0x75EAC64
	private object set_processingEvents(object value) { }

	// RVA: 0x75EAC6C
	internal object Dispatch(object evt, object panel, object dispatchMode) { }

	// RVA: 0x75EB4E8
	internal object CloseGate() { }

	// RVA: 0x75EB4F8
	internal object OpenGate() { }

	// RVA: 0x75EB5BC
	private object ProcessEventQueue() { }

	// RVA: 0x75EAF4C
	private object ProcessEvent(object evt, object panel) { }

	// RVA: 0x75EBAE0
	private object ApplyDispatchingStrategies(object evt, object panel, object imguiEventIsInitiallyUsed) { }

	// RVA: 0x75EC5C4
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal interface IPointerCaptureEventInternal
{

	// Properties
	public abstract object pointerId { get; }

	// Methods

	// RVA: -1
	public abstract object get_pointerId() { }

}

// Namespace: UnityEngine.UIElements
public abstract class PointerCaptureEventBase<T0>
{

	// Fields
	private object <relatedTarget>k__BackingField; // 0x0
	private object <pointerId>k__BackingField; // 0x0

	// Properties
	private object relatedTarget { set; }
	public object pointerId { get; set; }

	// Methods

	// RVA: -1
	private object set_relatedTarget(object value) { }

	// RVA: -1
	public object get_pointerId() { }

	// RVA: -1
	private object set_pointerId(object value) { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object GetPooled(object target, object relatedTarget, object pointerId) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75ECCE0
	private static object .cctor() { }

	// RVA: 0x75ECD40
	public object .ctor() { }

	// RVA: 0x75ECD48
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class PointerCaptureOutEvent
{

	// Methods

	// RVA: 0x75ECB98
	private static object .cctor() { }

	// RVA: 0x75ECC88
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75ECF1C
	private static object .cctor() { }

	// RVA: 0x75ECF7C
	public object .ctor() { }

	// RVA: 0x75ECF84
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class PointerCaptureEvent
{

	// Methods

	// RVA: 0x75ECDD4
	private static object .cctor() { }

	// RVA: 0x75ECEC4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class MouseCaptureEventBase<T0>
{

	// Methods

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75ED158
	private static object .cctor() { }

	// RVA: 0x75ED1B8
	public object .ctor() { }

	// RVA: 0x75ED1C0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseCaptureOutEvent
{

	// Methods

	// RVA: 0x75ED010
	private static object .cctor() { }

	// RVA: 0x75ED100
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75ED394
	private static object .cctor() { }

	// RVA: 0x75ED3F4
	public object .ctor() { }

	// RVA: 0x75ED3FC
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseCaptureEvent
{

	// Methods

	// RVA: 0x75ED24C
	private static object .cctor() { }

	// RVA: 0x75ED33C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class ChangeEvent<T0>
{

	// Fields
	private object <previousValue>k__BackingField; // 0x0
	private object <newValue>k__BackingField; // 0x0

	// Properties
	public object previousValue { get; set; }
	public object newValue { get; set; }

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object get_previousValue() { }

	// RVA: -1
	protected object set_previousValue(object value) { }

	// RVA: -1
	public object get_newValue() { }

	// RVA: -1
	protected object set_newValue(object value) { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object GetPooled(object previousValue, object newValue) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class CommandEventDispatchingStrategy
{

	// Methods

	// RVA: 0x75ED488
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75ED4E8
	public object DispatchEvent(object evt, object panel) { }

	// RVA: 0x75ECA2C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public interface ICommandEvent
{
}

// Namespace: UnityEngine.UIElements
public abstract class CommandEventBase<T0>
{

	// Fields
	private object m_CommandName; // 0x0

	// Properties
	public object commandName { get; set; }

	// Methods

	// RVA: -1
	public object get_commandName() { }

	// RVA: -1
	protected object set_commandName(object value) { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object GetPooled(object systemEvent) { }

	// RVA: -1
	public static object GetPooled(object commandName) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75EE244
	private static object .cctor() { }

	// RVA: 0x75EE2A4
	public object .ctor() { }

	// RVA: 0x75EE2AC
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class ValidateCommandEvent
{

	// Methods

	// RVA: 0x75EE0FC
	private static object .cctor() { }

	// RVA: 0x75EE1EC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75EE480
	private static object .cctor() { }

	// RVA: 0x75EE4E0
	public object .ctor() { }

	// RVA: 0x75EE4E8
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class ExecuteCommandEvent
{

	// Methods

	// RVA: 0x75EE338
	private static object .cctor() { }

	// RVA: 0x75EE428
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class DefaultDispatchingStrategy
{

	// Methods

	// RVA: 0x75EE574
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75EE5F8
	public object DispatchEvent(object evt, object panel) { }

	// RVA: 0x75ECA3C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class ElementUnderPointer
{

	// Fields
	private object m_PendingTopElementUnderPointer; // 0x8
	private object m_TopElementUnderPointer; // 0x10
	private object m_TriggerPointerEvent; // 0x18
	private object m_TriggerMouseEvent; // 0x20
	private object m_PickingPointerPositions; // 0x28
	private object m_IsPickingPointerTemporaries; // 0x30

	// Methods

	// RVA: 0x75EE870
	internal object GetTopElementUnderPointer(object pointerId, object pickPosition, object isTemporary) { }

	// RVA: 0x75EE908
	internal object GetTopElementUnderPointer(object pointerId) { }

	// RVA: 0x75EE944
	internal object SetElementUnderPointer(object newElementUnderPointer, object pointerId, object pointerPos) { }

	// RVA: 0x75EEB18
	private object GetEventPointerPosition(object triggerEvent) { }

	// RVA: 0x75EED4C
	internal object SetTemporaryElementUnderPointer(object newElementUnderPointer, object pointerId, object triggerEvent) { }

	// RVA: 0x75EF040
	internal object SetElementUnderPointer(object newElementUnderPointer, object pointerId, object triggerEvent) { }

	// RVA: 0x75EED54
	private object SetElementUnderPointer(object newElementUnderPointer, object pointerId, object triggerEvent, object temporary) { }

	// RVA: 0x75EF048
	internal object CommitElementUnderPointers(object dispatcher, object contextType) { }

	// RVA: 0x75F07C4
	public object .ctor() { }

}

// Namespace: 
internal enum EventPropagation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Bubbles;
	public const object TricklesDown;
	public const object Cancellable;
	public const object SkipDisabledElements;
	public const object IgnoreCompositeRoots;
}

// Namespace: 
private enum LifeCycleStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object PropagationStopped;
	public const object ImmediatePropagationStopped;
	public const object DefaultPrevented;
	public const object Dispatching;
	public const object Pooled;
	public const object IMGUIEventIsValid;
	public const object StopDispatch;
	public const object PropagateToIMGUI;
	public const object Dispatched;
	public const object Processed;
	public const object ProcessedByFocusController;
}

// Namespace: UnityEngine.UIElements
public abstract class EventBase
{

	// Fields
	private static object s_LastTypeId; // 0x0
	private readonly object <eventCategory>k__BackingField; // 0x8
	private static object s_NextEventId; // 0x8
	private object <timestamp>k__BackingField; // 0x10
	private object <eventId>k__BackingField; // 0x18
	private object <triggerEventId>k__BackingField; // 0x20
	private object <propagation>k__BackingField; // 0x28
	private object <path>k__BackingField; // 0x30
	private object <lifeCycleStatus>k__BackingField; // 0x38
	private object <leafTarget>k__BackingField; // 0x40
	private object m_Target; // 0x48
	private readonly object <skipElements>k__BackingField; // 0x50
	private object <propagationPhase>k__BackingField; // 0x58
	private object m_CurrentTarget; // 0x60
	private object m_ImguiEvent; // 0x68
	private object <originalMousePosition>k__BackingField; // 0x70

	// Properties
	public virtual object eventTypeId { get; }
	internal object eventCategory { get; }
	public object timestamp { get; set; }
	internal object eventId { get; set; }
	private object triggerEventId { set; }
	internal object propagation { get; set; }
	internal object path { get; set; }
	private object lifeCycleStatus { get; set; }
	public object bubbles { get; }
	public object tricklesDown { get; }
	internal object bubblesOrTricklesDown { get; }
	internal object skipDisabledElements { get; set; }
	internal object ignoreCompositeRoots { get; set; }
	internal object leafTarget { get; set; }
	public object target { get; set; }
	internal object skipElements { get; }
	public object isPropagationStopped { get; set; }
	public object isImmediatePropagationStopped { get; set; }
	public object isDefaultPrevented { get; set; }
	public object propagationPhase { get; set; }
	public virtual object currentTarget { get; set; }
	public object dispatch { get; set; }
	private object dispatched { get; set; }
	internal object processed { get; set; }
	internal object processedByFocusController { get; set; }
	internal object stopDispatch { get; set; }
	internal object propagateToIMGUI { get; set; }
	private object imguiEventIsValid { get; set; }
	public object imguiEvent { get; set; }
	public object originalMousePosition { get; set; }
	protected object pooled { get; set; }

	// Methods

	// RVA: 0x75F092C
	protected static object RegisterEventType() { }

	// RVA: 0x75F0980
	public virtual object get_eventTypeId() { }

	// RVA: 0x75F0988
	internal object get_eventCategory() { }

	// RVA: 0x75F0990
	public object get_timestamp() { }

	// RVA: 0x75F0998
	private object set_timestamp(object value) { }

	// RVA: 0x75F09A0
	internal object get_eventId() { }

	// RVA: 0x75F09A8
	private object set_eventId(object value) { }

	// RVA: 0x75F09B0
	private object set_triggerEventId(object value) { }

	// RVA: 0x75F09B8
	internal object SetTriggerEventId(object id) { }

	// RVA: 0x75F09C0
	internal object get_propagation() { }

	// RVA: 0x75F09C8
	internal object set_propagation(object value) { }

	// RVA: 0x75F09D0
	internal object get_path() { }

	// RVA: 0x75F09D8
	internal object set_path(object value) { }

	// RVA: 0x75F09E0
	private object get_lifeCycleStatus() { }

	// RVA: 0x75F09E8
	private object set_lifeCycleStatus(object value) { }

	// RVA: 0x75F09F0
	protected virtual object PreDispatch() { }

	// RVA: 0x75F09F4
	protected internal virtual object PreDispatch(object panel) { }

	// RVA: 0x75F0A34
	protected virtual object PostDispatch() { }

	// RVA: 0x75F0A38
	protected internal virtual object PostDispatch(object panel) { }

	// RVA: 0x75F0AA4
	public object get_bubbles() { }

	// RVA: 0x75F0AB0
	public object get_tricklesDown() { }

	// RVA: 0x75EBE38
	internal object get_bubblesOrTricklesDown() { }

	// RVA: 0x75F0ABC
	internal object get_skipDisabledElements() { }

	// RVA: 0x75F0AC8
	internal object set_skipDisabledElements(object value) { }

	// RVA: 0x75F0AE8
	internal object get_ignoreCompositeRoots() { }

	// RVA: 0x75F0AF4
	internal object set_ignoreCompositeRoots(object value) { }

	// RVA: 0x75F0B14
	internal object get_leafTarget() { }

	// RVA: 0x75F0B1C
	private object set_leafTarget(object value) { }

	// RVA: 0x75EC57C
	public object get_target() { }

	// RVA: 0x75EC334
	public object set_target(object value) { }

	// RVA: 0x75F0B24
	internal object get_skipElements() { }

	// RVA: 0x75ED9F0
	internal object Skip(object h) { }

	// RVA: 0x75EBAD4
	public object get_isPropagationStopped() { }

	// RVA: 0x75F0B2C
	private object set_isPropagationStopped(object value) { }

	// RVA: 0x75EDA5C
	public object StopPropagation() { }

	// RVA: 0x75F0B40
	public object get_isImmediatePropagationStopped() { }

	// RVA: 0x75F0B4C
	private object set_isImmediatePropagationStopped(object value) { }

	// RVA: 0x75F0B6C
	public object StopImmediatePropagation() { }

	// RVA: 0x75F0B7C
	public object get_isDefaultPrevented() { }

	// RVA: 0x75F0B88
	private object set_isDefaultPrevented(object value) { }

	// RVA: 0x75EDA6C
	public object PreventDefault() { }

	// RVA: 0x75F0BA8
	public object get_propagationPhase() { }

	// RVA: 0x75F0BB0
	internal object set_propagationPhase(object value) { }

	// RVA: 0x75F0BB8
	public virtual object get_currentTarget() { }

	// RVA: 0x75F0BC0
	internal virtual object set_currentTarget(object value) { }

	// RVA: 0x75F0CF4
	public object get_dispatch() { }

	// RVA: 0x75F0D00
	internal object set_dispatch(object value) { }

	// RVA: 0x75EAEA0
	internal object MarkReceivedByDispatcher() { }

	// RVA: 0x75F0D40
	private object get_dispatched() { }

	// RVA: 0x75F0D20
	private object set_dispatched(object value) { }

	// RVA: 0x75F0D4C
	internal object get_processed() { }

	// RVA: 0x75F0A84
	private object set_processed(object value) { }

	// RVA: 0x75F0D58
	internal object get_processedByFocusController() { }

	// RVA: 0x75F0D64
	internal object set_processedByFocusController(object value) { }

	// RVA: 0x75EBAC8
	internal object get_stopDispatch() { }

	// RVA: 0x75EE0DC
	internal object set_stopDispatch(object value) { }

	// RVA: 0x75EDA84
	internal object get_propagateToIMGUI() { }

	// RVA: 0x75EE0BC
	internal object set_propagateToIMGUI(object value) { }

	// RVA: 0x75F0D84
	private object get_imguiEventIsValid() { }

	// RVA: 0x75F0D90
	private object set_imguiEventIsValid(object value) { }

	// RVA: 0x75EAF34
	public object get_imguiEvent() { }

	// RVA: 0x75F0DB0
	protected object set_imguiEvent(object value) { }

	// RVA: 0x75F0E88
	public object get_originalMousePosition() { }

	// RVA: 0x75F0E90
	private object set_originalMousePosition(object value) { }

	// RVA: 0x75F0E98
	protected virtual object Init() { }

	// RVA: 0x75F0E9C
	private object LocalInit() { }

	// RVA: 0x75F114C
	internal object .ctor(object category) { }

	// RVA: 0x75F11E8
	protected object get_pooled() { }

	// RVA: 0x75F112C
	protected object set_pooled(object value) { }

	// RVA: -1
	internal abstract object Acquire() { }

	// RVA: -1
	public abstract object Dispose() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__15_0() { }

}

// Namespace: UnityEngine.UIElements
public abstract class EventBase<T0>
{

	// Fields
	private static readonly object s_TypeId; // 0x0
	private static readonly object s_Pool; // 0x0
	private object m_RefCount; // 0x0
	internal static readonly object EventCategory; // 0x0

	// Properties
	public override object eventTypeId { get; }

	// Methods

	// RVA: -1
	internal static object SetCreateFunction(object createMethod) { }

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	public static object TypeId() { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	public static object GetPooled() { }

	// RVA: -1
	internal static object GetPooled(object e) { }

	// RVA: -1
	private static object ReleasePooled(object evt) { }

	// RVA: -1
	internal override object Acquire() { }

	// RVA: -1
	public sealed override object Dispose() { }

	// RVA: -1
	public override object get_eventTypeId() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public sealed class EventCallback<T0>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object evt) { }

}

// Namespace: UnityEngine.UIElements
internal abstract class EventCallbackFunctorBase
{

	// Fields
	private readonly object <phase>k__BackingField; // 0x8
	private readonly object <invokePolicy>k__BackingField; // 0xC

	// Properties
	public object phase { get; }
	public object invokePolicy { get; }

	// Methods

	// RVA: 0x75F11F4
	public object get_phase() { }

	// RVA: 0x75F11FC
	public object get_invokePolicy() { }

	// RVA: 0x75F1204
	protected object .ctor(object phase, object invokePolicy) { }

	// RVA: -1
	public abstract object Invoke(object evt, object propagationPhase) { }

	// RVA: -1
	public abstract object IsEquivalentTo(object eventTypeId, object callback, object phase) { }

	// RVA: 0x75F123C
	protected object PhaseMatches(object propagationPhase) { }

}

// Namespace: UnityEngine.UIElements
internal class EventCallbackFunctor<T0>
{

	// Fields
	private readonly object m_Callback; // 0x0
	private readonly object m_EventTypeId; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object callback, object phase, object invokePolicy) { }

	// RVA: -1
	public override object Invoke(object evt, object propagationPhase) { }

	// RVA: -1
	public override object IsEquivalentTo(object eventTypeId, object callback, object phase) { }

}

// Namespace: UnityEngine.UIElements
public enum TrickleDown
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoTrickleDown;
	public const object TrickleDown;
}

// Namespace: UnityEngine.UIElements
internal enum CallbackPhase
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TargetAndBubbleUp;
	public const object TrickleDownAndTarget;
}

// Namespace: UnityEngine.UIElements
internal enum InvokePolicy
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object IncludeDisabled;
}

// Namespace: UnityEngine.UIElements
internal class EventCallbackListPool
{

	// Fields
	private readonly object m_Stack; // 0x8

	// Methods

	// RVA: 0x75F1278
	public object Get(object initializer) { }

	// RVA: 0x75F1714
	public object Release(object element) { }

	// RVA: 0x75F1858
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class EventCallbackList
{

	// Fields
	private object m_List; // 0x8
	private object <trickleDownCallbackCount>k__BackingField; // 0x10
	private object <bubbleUpCallbackCount>k__BackingField; // 0x14

	// Properties
	public object trickleDownCallbackCount { get; set; }
	public object bubbleUpCallbackCount { get; set; }
	public object Count { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x75F18D8
	public object get_trickleDownCallbackCount() { }

	// RVA: 0x75F18E0
	private object set_trickleDownCallbackCount(object value) { }

	// RVA: 0x75F18E8
	public object get_bubbleUpCallbackCount() { }

	// RVA: 0x75F18F0
	private object set_bubbleUpCallbackCount(object value) { }

	// RVA: 0x75F14D4
	public object .ctor() { }

	// RVA: 0x75F1434
	public object .ctor(object source) { }

	// RVA: 0x75F18F8
	public object Contains(object eventTypeId, object callback, object phase) { }

	// RVA: 0x75F1914
	public object Find(object eventTypeId, object callback, object phase) { }

	// RVA: 0x75F1A48
	public object Remove(object eventTypeId, object callback, object phase) { }

	// RVA: 0x75F1BAC
	public object Add(object item) { }

	// RVA: 0x75F1558
	public object AddRange(object list) { }

	// RVA: 0x75F1D48
	public object get_Count() { }

	// RVA: 0x75F1D9C
	public object get_Item(object i) { }

	// RVA: 0x75F17E0
	public object Clear() { }

}

// Namespace: UnityEngine.UIElements
internal class EventCallbackRegistry
{

	// Fields
	private static readonly object s_ListPool; // 0x0
	private object m_Callbacks; // 0x8
	private object m_TemporaryCallbacks; // 0x10
	private object m_IsInvoking; // 0x18

	// Methods

	// RVA: 0x75F1E08
	private static object GetCallbackList(object initializer) { }

	// RVA: 0x75F1E9C
	private static object ReleaseCallbackList(object toRelease) { }

	// RVA: 0x75F1F30
	public object .ctor() { }

	// RVA: 0x75F1F58
	private object GetCallbackListForWriting() { }

	// RVA: 0x75F2190
	private object GetCallbackListForReading() { }

	// RVA: 0x75F21AC
	private object UnregisterCallback(object eventTypeId, object callback, object useTrickleDown) { }

	// RVA: -1
	public object RegisterCallback(object callback, object useTrickleDown, object invokePolicy) { }

	// RVA: -1
	public object UnregisterCallback(object callback, object useTrickleDown) { }

	// RVA: 0x75F2218
	public object InvokeCallbacks(object evt, object propagationPhase) { }

	// RVA: 0x75F25F8
	public object HasTrickleDownHandlers() { }

	// RVA: 0x75F2618
	public object HasBubbleHandlers() { }

	// RVA: 0x75F2638
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal struct EventDebuggerLogCall
{

	// Methods

	// RVA: 0x75F2714
	public object .ctor(object callback, object evt) { }

	// RVA: 0x75F271C
	public object Dispose() { }

}

// Namespace: UnityEngine.UIElements
internal struct EventDebuggerLogIMGUICall
{

	// Methods

	// RVA: 0x75F2724
	public object .ctor(object evt) { }

	// RVA: 0x75F272C
	public object Dispose() { }

}

// Namespace: UnityEngine.UIElements
internal struct EventDebuggerLogExecuteDefaultAction
{

	// Methods

	// RVA: 0x75F2734
	public object .ctor(object evt) { }

	// RVA: 0x75F273C
	public object Dispose() { }

}

// Namespace: UnityEngine.UIElements
internal class EventDebugger
{

	// Methods

	// RVA: 0x75EC330
	public static object LogPropagationPaths(object evt, object paths) { }

}

// Namespace: UnityEngine.UIElements
public interface IEventHandler
{

	// Methods

	// RVA: -1
	public abstract object SendEvent(object e) { }

	// RVA: -1
	public abstract object HandleEvent(object evt) { }

}

// Namespace: UnityEngine.UIElements
public abstract class CallbackEventHandler
{

	// Fields
	internal object isIMGUIContainer; // 0x8
	private object m_CallbackRegistry; // 0x10
	internal const object ExecuteDefaultActionName;
	internal const object ExecuteDefaultActionAtTargetName;

	// Methods

	// RVA: -1
	public object RegisterCallback(object callback, object useTrickleDown) { }

	// RVA: -1
	private object AddEventCategories() { }

	// RVA: -1
	internal object RegisterCallback(object callback, object invokePolicy, object useTrickleDown) { }

	// RVA: -1
	public object UnregisterCallback(object callback, object useTrickleDown) { }

	// RVA: -1
	public abstract object SendEvent(object e) { }

	// RVA: -1
	internal abstract object SendEvent(object e, object dispatchMode) { }

	// RVA: 0x75F2744
	internal object HandleEventAtTargetPhase(object evt) { }

	// RVA: 0x75F284C
	internal object HandleEventAtTargetAndDefaultPhase(object evt) { }

	// RVA: 0x75F2804
	internal object HandleEventAtCurrentTargetAndPhase(object evt) { }

	// RVA: 0x75F28AC
	private object UnityEngine.UIElements.IEventHandler.HandleEvent(object evt) { }

	// RVA: 0x75F28F4
	public virtual object HandleEvent(object evt) { }

	// RVA: 0x75F2BD4
	public object HasTrickleDownHandlers() { }

	// RVA: 0x75F2BFC
	public object HasBubbleUpHandlers() { }

	// RVA: 0x75F2C24
	protected virtual object ExecuteDefaultActionAtTarget(object evt) { }

	// RVA: 0x75F2C28
	protected virtual object ExecuteDefaultAction(object evt) { }

	// RVA: 0x75F2C2C
	internal virtual object ExecuteDefaultActionDisabledAtTarget(object evt) { }

	// RVA: 0x75F2C30
	internal virtual object ExecuteDefaultActionDisabled(object evt) { }

	// RVA: 0x75F2C34
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class FocusEventBase<T0>
{

	// Fields
	private object <relatedTarget>k__BackingField; // 0x0
	private object <direction>k__BackingField; // 0x0
	private object <focusController>k__BackingField; // 0x0
	private object <IsFocusDelegated>k__BackingField; // 0x0

	// Properties
	public object relatedTarget { get; set; }
	public object direction { get; set; }
	protected object focusController { get; set; }
	internal object IsFocusDelegated { get; set; }

	// Methods

	// RVA: -1
	public object get_relatedTarget() { }

	// RVA: -1
	private object set_relatedTarget(object value) { }

	// RVA: -1
	public object get_direction() { }

	// RVA: -1
	private object set_direction(object value) { }

	// RVA: -1
	protected object get_focusController() { }

	// RVA: -1
	private object set_focusController(object value) { }

	// RVA: -1
	internal object get_IsFocusDelegated() { }

	// RVA: -1
	private object set_IsFocusDelegated(object value) { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object GetPooled(object target, object relatedTarget, object direction, object focusController, object bIsFocusDelegated) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F2DFC
	private static object .cctor() { }

	// RVA: 0x75F2E5C
	public object .ctor() { }

	// RVA: 0x75F2E64
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class FocusOutEvent
{

	// Methods

	// RVA: 0x75F2C40
	private static object .cctor() { }

	// RVA: 0x75F2D30
	protected override object Init() { }

	// RVA: 0x75F2D90
	private object LocalInit() { }

	// RVA: 0x75F2D9C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F3184
	private static object .cctor() { }

	// RVA: 0x75F31E4
	public object .ctor() { }

	// RVA: 0x75F31EC
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class BlurEvent
{

	// Methods

	// RVA: 0x75F2EF8
	private static object .cctor() { }

	// RVA: 0x75F2FE8
	protected internal override object PreDispatch(object panel) { }

	// RVA: 0x75F312C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F3434
	private static object .cctor() { }

	// RVA: 0x75F3494
	public object .ctor() { }

	// RVA: 0x75F349C
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class FocusInEvent
{

	// Methods

	// RVA: 0x75F3278
	private static object .cctor() { }

	// RVA: 0x75F3368
	protected override object Init() { }

	// RVA: 0x75F33C8
	private object LocalInit() { }

	// RVA: 0x75F33D4
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F3768
	private static object .cctor() { }

	// RVA: 0x75F37C8
	public object .ctor() { }

	// RVA: 0x75F37D0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class FocusEvent
{

	// Methods

	// RVA: 0x75F3530
	private static object .cctor() { }

	// RVA: 0x75F3620
	protected internal override object PreDispatch(object panel) { }

	// RVA: 0x75F3710
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public enum PropagationPhase
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object TrickleDown;
	public const object AtTarget;
	public const object DefaultActionAtTarget;
	public const object BubbleUp;
	public const object DefaultAction;
}

// Namespace: UnityEngine.UIElements
internal interface IEventDispatchingStrategy
{

	// Methods

	// RVA: -1
	public abstract object CanDispatchEvent(object evt) { }

	// RVA: -1
	public abstract object DispatchEvent(object evt, object panel) { }

}

// Namespace: UnityEngine.UIElements
internal static class EventDispatchUtilities
{

	// Methods

	// RVA: 0x75EDF68
	public static object PropagateEvent(object evt) { }

	// RVA: 0x75F385C
	private static object HandleEventAcrossPropagationPath(object evt) { }

	// RVA: 0x75EDA90
	internal static object PropagateToIMGUIContainer(object root, object evt) { }

	// RVA: 0x75EC34C
	public static object ExecuteDefaultAction(object evt) { }

}

// Namespace: UnityEngine.UIElements
internal class IMGUIEventDispatchingStrategy
{

	// Methods

	// RVA: 0x75F4340
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75F43C4
	public object DispatchEvent(object evt, object panel) { }

	// RVA: 0x75ECA34
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F475C
	private static object .cctor() { }

	// RVA: 0x75F47BC
	public object .ctor() { }

	// RVA: 0x75F47C4
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class InputEvent
{

	// Fields
	private object <previousData>k__BackingField; // 0x80
	private object <newData>k__BackingField; // 0x88

	// Properties
	protected object previousData { set; }
	protected object newData { set; }

	// Methods

	// RVA: 0x75F44B0
	private static object .cctor() { }

	// RVA: 0x75F45A0
	protected object set_previousData(object value) { }

	// RVA: 0x75F45A8
	protected object set_newData(object value) { }

	// RVA: 0x75F45B0
	protected override object Init() { }

	// RVA: 0x75F4614
	private object LocalInit() { }

	// RVA: 0x75F4624
	public static object GetPooled(object previousData, object newData) { }

	// RVA: 0x75F46D4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class KeyboardEventDispatchingStrategy
{

	// Methods

	// RVA: 0x75F4880
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75F48E0
	public object DispatchEvent(object evt, object panel) { }

	// RVA: 0x75ECA0C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public interface IKeyboardEvent
{

	// Properties
	public abstract object modifiers { get; }
	public abstract object character { get; }
	public abstract object keyCode { get; }

	// Methods

	// RVA: -1
	public abstract object get_modifiers() { }

	// RVA: -1
	public abstract object get_character() { }

	// RVA: -1
	public abstract object get_keyCode() { }

}

// Namespace: UnityEngine.UIElements
public abstract class KeyboardEventBase<T0>
{

	// Fields
	private object <modifiers>k__BackingField; // 0x0
	private object <character>k__BackingField; // 0x0
	private object <keyCode>k__BackingField; // 0x0

	// Properties
	public object modifiers { get; set; }
	public object character { get; set; }
	public object keyCode { get; set; }
	public object shiftKey { get; }
	public object ctrlKey { get; }
	public object commandKey { get; }
	public object altKey { get; }
	internal object functionKey { get; }
	public object actionKey { get; }

	// Methods

	// RVA: -1
	public object get_modifiers() { }

	// RVA: -1
	protected object set_modifiers(object value) { }

	// RVA: -1
	public object get_character() { }

	// RVA: -1
	protected object set_character(object value) { }

	// RVA: -1
	public object get_keyCode() { }

	// RVA: -1
	protected object set_keyCode(object value) { }

	// RVA: -1
	public object get_shiftKey() { }

	// RVA: -1
	public object get_ctrlKey() { }

	// RVA: -1
	public object get_commandKey() { }

	// RVA: -1
	public object get_altKey() { }

	// RVA: -1
	internal object get_functionKey() { }

	// RVA: -1
	public object get_actionKey() { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object GetPooled(object c, object keyCode, object modifiers) { }

	// RVA: -1
	public static object GetPooled(object systemEvent) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F5B2C
	private static object .cctor() { }

	// RVA: 0x75F5B8C
	public object .ctor() { }

	// RVA: 0x75F5B94
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class KeyDownEvent
{

	// Methods

	// RVA: 0x75F4C48
	private static object .cctor() { }

	// RVA: 0x75F4D38
	internal object GetEquivalentImguiEvent(object outImguiEvent) { }

	// RVA: 0x75F4E1C
	protected internal override object PostDispatch(object panel) { }

	// RVA: 0x75F4F74
	private object SendEquivalentNavigationEventIfAny(object panel) { }

	// RVA: 0x75F5AD4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal static class KeyboardEventExtensions
{

	// Methods

	// RVA: 0x75F56D8
	internal static object ShouldSendNavigationMoveEvent(object e) { }

	// RVA: 0x75F5C20
	internal static object ShouldSendNavigationMoveEventRuntime(object e) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F5DC8
	private static object .cctor() { }

	// RVA: 0x75F5E28
	public object .ctor() { }

	// RVA: 0x75F5E30
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class KeyUpEvent
{

	// Methods

	// RVA: 0x75F5C80
	private static object .cctor() { }

	// RVA: 0x75F5D70
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F6234
	private static object .cctor() { }

	// RVA: 0x75F6294
	public object .ctor() { }

	// RVA: 0x75F629C
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class GeometryChangedEvent
{

	// Fields
	private object <oldRect>k__BackingField; // 0x7C
	private object <newRect>k__BackingField; // 0x8C
	private object <layoutPass>k__BackingField; // 0x9C

	// Properties
	public object oldRect { get; set; }
	public object newRect { get; set; }
	internal object layoutPass { get; set; }

	// Methods

	// RVA: 0x75F5EBC
	private static object .cctor() { }

	// RVA: 0x75F5FAC
	public static object GetPooled(object oldRect, object newRect) { }

	// RVA: 0x75F6098
	protected override object Init() { }

	// RVA: 0x75F6114
	private object LocalInit() { }

	// RVA: 0x75F6154
	public object get_oldRect() { }

	// RVA: 0x75F6160
	private object set_oldRect(object value) { }

	// RVA: 0x75F616C
	public object get_newRect() { }

	// RVA: 0x75F6178
	private object set_newRect(object value) { }

	// RVA: 0x75F6184
	internal object get_layoutPass() { }

	// RVA: 0x75F618C
	internal object set_layoutPass(object value) { }

	// RVA: 0x75F6194
	public object .ctor() { }

}

// Namespace: 
private enum EventBehavior
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object IsCapturable;
	public const object IsSentExclusivelyToCapturingElement;
}

// Namespace: UnityEngine.UIElements
internal class MouseCaptureDispatchingStrategy
{

	// Methods

	// RVA: 0x75F62F0
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75F6398
	public object DispatchEvent(object evt, object panel) { }

	// RVA: 0x75ECA04
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class MouseEventDispatchingStrategy
{

	// Methods

	// RVA: 0x75F6BEC
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75F6C4C
	public object DispatchEvent(object evt, object iPanel) { }

	// RVA: 0x75F6E7C
	private static object SendEventToTarget(object evt, object panel) { }

	// RVA: 0x75F6EBC
	private static object SendEventToRegularTarget(object evt, object panel) { }

	// RVA: 0x75F6FC0
	private static object SendEventToIMGUIContainer(object evt, object panel) { }

	// RVA: 0x75F6D90
	private static object SetBestTargetForEvent(object evt, object panel) { }

	// RVA: 0x75F7350
	private static object UpdateElementUnderMouse(object evt, object panel, object elementUnderMouse) { }

	// RVA: 0x75F72F0
	private static object IsDone(object evt) { }

	// RVA: 0x75ECA1C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public interface IMouseEvent
{

	// Properties
	public abstract object modifiers { get; }
	public abstract object mousePosition { get; }
	public abstract object localMousePosition { get; }
	public abstract object mouseDelta { get; }
	public abstract object clickCount { get; }
	public abstract object button { get; }
	public abstract object pressedButtons { get; }
	public abstract object shiftKey { get; }
	public abstract object ctrlKey { get; }
	public abstract object commandKey { get; }
	public abstract object altKey { get; }

	// Methods

	// RVA: -1
	public abstract object get_modifiers() { }

	// RVA: -1
	public abstract object get_mousePosition() { }

	// RVA: -1
	public abstract object get_localMousePosition() { }

	// RVA: -1
	public abstract object get_mouseDelta() { }

	// RVA: -1
	public abstract object get_clickCount() { }

	// RVA: -1
	public abstract object get_button() { }

	// RVA: -1
	public abstract object get_pressedButtons() { }

	// RVA: -1
	public abstract object get_shiftKey() { }

	// RVA: -1
	public abstract object get_ctrlKey() { }

	// RVA: -1
	public abstract object get_commandKey() { }

	// RVA: -1
	public abstract object get_altKey() { }

}

// Namespace: UnityEngine.UIElements
internal interface IMouseEventInternal
{

	// Properties
	public abstract object triggeredByOS { get; set; }
	public abstract object recomputeTopElementUnderMouse { get; set; }
	public abstract object sourcePointerEvent { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_triggeredByOS() { }

	// RVA: -1
	public abstract object set_triggeredByOS(object value) { }

	// RVA: -1
	public abstract object get_recomputeTopElementUnderMouse() { }

	// RVA: -1
	public abstract object set_recomputeTopElementUnderMouse(object value) { }

	// RVA: -1
	public abstract object get_sourcePointerEvent() { }

	// RVA: -1
	public abstract object set_sourcePointerEvent(object value) { }

}

// Namespace: UnityEngine.UIElements
public abstract class MouseEventBase<T0>
{

	// Fields
	private object <modifiers>k__BackingField; // 0x0
	private object <mousePosition>k__BackingField; // 0x0
	private object <localMousePosition>k__BackingField; // 0x0
	private object <mouseDelta>k__BackingField; // 0x0
	private object <clickCount>k__BackingField; // 0x0
	private object <button>k__BackingField; // 0x0
	private object <pressedButtons>k__BackingField; // 0x0
	private object <UnityEngine.UIElements.IMouseEventInternal.triggeredByOS>k__BackingField; // 0x0
	private object <UnityEngine.UIElements.IMouseEventInternal.recomputeTopElementUnderMouse>k__BackingField; // 0x0
	private object <UnityEngine.UIElements.IMouseEventInternal.sourcePointerEvent>k__BackingField; // 0x0

	// Properties
	public object modifiers { get; set; }
	public object mousePosition { get; set; }
	public object localMousePosition { get; set; }
	public object mouseDelta { get; set; }
	public object clickCount { get; set; }
	public object button { get; set; }
	public object pressedButtons { get; set; }
	public object shiftKey { get; }
	public object ctrlKey { get; }
	public object commandKey { get; }
	public object altKey { get; }
	private object UnityEngine.UIElements.IMouseEventInternal.triggeredByOS { get; set; }
	private object UnityEngine.UIElements.IMouseEventInternal.recomputeTopElementUnderMouse { get; set; }
	private object UnityEngine.UIElements.IMouseEventInternal.sourcePointerEvent { get; set; }
	public override object currentTarget { get; set; }

	// Methods

	// RVA: -1
	public object get_modifiers() { }

	// RVA: -1
	protected object set_modifiers(object value) { }

	// RVA: -1
	public object get_mousePosition() { }

	// RVA: -1
	protected object set_mousePosition(object value) { }

	// RVA: -1
	public object get_localMousePosition() { }

	// RVA: -1
	internal object set_localMousePosition(object value) { }

	// RVA: -1
	public object get_mouseDelta() { }

	// RVA: -1
	protected object set_mouseDelta(object value) { }

	// RVA: -1
	public object get_clickCount() { }

	// RVA: -1
	protected object set_clickCount(object value) { }

	// RVA: -1
	public object get_button() { }

	// RVA: -1
	protected object set_button(object value) { }

	// RVA: -1
	public object get_pressedButtons() { }

	// RVA: -1
	protected object set_pressedButtons(object value) { }

	// RVA: -1
	public object get_shiftKey() { }

	// RVA: -1
	public object get_ctrlKey() { }

	// RVA: -1
	public object get_commandKey() { }

	// RVA: -1
	public object get_altKey() { }

	// RVA: -1
	private object UnityEngine.UIElements.IMouseEventInternal.get_triggeredByOS() { }

	// RVA: -1
	private object UnityEngine.UIElements.IMouseEventInternal.set_triggeredByOS(object value) { }

	// RVA: -1
	private object UnityEngine.UIElements.IMouseEventInternal.get_recomputeTopElementUnderMouse() { }

	// RVA: -1
	private object UnityEngine.UIElements.IMouseEventInternal.set_recomputeTopElementUnderMouse(object value) { }

	// RVA: -1
	private object UnityEngine.UIElements.IMouseEventInternal.get_sourcePointerEvent() { }

	// RVA: -1
	private object UnityEngine.UIElements.IMouseEventInternal.set_sourcePointerEvent(object value) { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public override object get_currentTarget() { }

	// RVA: -1
	internal override object set_currentTarget(object value) { }

	// RVA: -1
	protected internal override object PreDispatch(object panel) { }

	// RVA: -1
	protected internal override object PostDispatch(object panel) { }

	// RVA: -1
	public static object GetPooled(object systemEvent) { }

	// RVA: -1
	internal static object GetPooled(object triggerEvent, object mousePosition, object recomputeTopElementUnderMouse) { }

	// RVA: -1
	public static object GetPooled(object triggerEvent) { }

	// RVA: -1
	protected static object GetPooled(object pointerEvent) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F7C74
	private static object .cctor() { }

	// RVA: 0x75F7CD4
	public object .ctor() { }

	// RVA: 0x75F7CDC
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseDownEvent
{

	// Methods

	// RVA: 0x75F76FC
	private static object .cctor() { }

	// RVA: 0x75F77EC
	protected override object Init() { }

	// RVA: 0x75F784C
	private object LocalInit() { }

	// RVA: 0x75F7858
	public object .ctor() { }

	// RVA: 0x75F78B8
	private static object MakeFromPointerEvent(object pointerEvent) { }

	// RVA: 0x75F7B74
	internal static object GetPooled(object pointerEvent) { }

	// RVA: 0x75F7BF4
	internal static object GetPooled(object pointerEvent) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F8368
	private static object .cctor() { }

	// RVA: 0x75F83C8
	public object .ctor() { }

	// RVA: 0x75F83D0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseUpEvent
{

	// Methods

	// RVA: 0x75F7D70
	private static object .cctor() { }

	// RVA: 0x75F7E60
	protected override object Init() { }

	// RVA: 0x75F7EC0
	private object LocalInit() { }

	// RVA: 0x75F7ECC
	public object .ctor() { }

	// RVA: 0x75F7F2C
	private static object MakeFromPointerEvent(object pointerEvent) { }

	// RVA: 0x75F81E8
	internal static object GetPooled(object pointerEvent) { }

	// RVA: 0x75F8268
	internal static object GetPooled(object pointerEvent) { }

	// RVA: 0x75F82E8
	internal static object GetPooled(object pointerEvent) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F8678
	private static object .cctor() { }

	// RVA: 0x75F86D8
	public object .ctor() { }

	// RVA: 0x75F86E0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseMoveEvent
{

	// Methods

	// RVA: 0x75F8464
	private static object .cctor() { }

	// RVA: 0x75F8554
	protected override object Init() { }

	// RVA: 0x75F85B4
	private object LocalInit() { }

	// RVA: 0x75F85C0
	public object .ctor() { }

	// RVA: 0x75F8620
	internal static object GetPooled(object pointerEvent) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F88BC
	private static object .cctor() { }

	// RVA: 0x75F891C
	public object .ctor() { }

	// RVA: 0x75F8924
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class ContextClickEvent
{

	// Methods

	// RVA: 0x75F8774
	private static object .cctor() { }

	// RVA: 0x75F8864
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F8E80
	private static object .cctor() { }

	// RVA: 0x75F8EE0
	public object .ctor() { }

	// RVA: 0x75F8EE8
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class WheelEvent
{

	// Fields
	private object <delta>k__BackingField; // 0xB0

	// Properties
	public object delta { get; set; }

	// Methods

	// RVA: 0x75F89B0
	private static object .cctor() { }

	// RVA: 0x75F8AA0
	public object get_delta() { }

	// RVA: 0x75F8AAC
	private object set_delta(object value) { }

	// RVA: 0x75F8AB8
	public static object GetPooled(object systemEvent) { }

	// RVA: 0x75F8B48
	internal static object GetPooled(object delta, object mousePosition, object modifiers) { }

	// RVA: 0x75F8C44
	internal static object GetPooled(object delta, object pointerEvent) { }

	// RVA: 0x75F8CD4
	protected override object Init() { }

	// RVA: 0x75F8D74
	private object LocalInit() { }

	// RVA: 0x75F8DE0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F9178
	private static object .cctor() { }

	// RVA: 0x75F91D8
	public object .ctor() { }

	// RVA: 0x75F91E0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseEnterEvent
{

	// Methods

	// RVA: 0x75F8FBC
	private static object .cctor() { }

	// RVA: 0x75F90AC
	protected override object Init() { }

	// RVA: 0x75F910C
	private object LocalInit() { }

	// RVA: 0x75F9118
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F9430
	private static object .cctor() { }

	// RVA: 0x75F9490
	public object .ctor() { }

	// RVA: 0x75F9498
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseLeaveEvent
{

	// Methods

	// RVA: 0x75F9274
	private static object .cctor() { }

	// RVA: 0x75F9364
	protected override object Init() { }

	// RVA: 0x75F93C4
	private object LocalInit() { }

	// RVA: 0x75F93D0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75F9878
	private static object .cctor() { }

	// RVA: 0x75F98D8
	public object .ctor() { }

	// RVA: 0x75F98E0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseEnterWindowEvent
{

	// Methods

	// RVA: 0x75F952C
	private static object .cctor() { }

	// RVA: 0x75F961C
	protected override object Init() { }

	// RVA: 0x75F967C
	private object LocalInit() { }

	// RVA: 0x75F9688
	public object .ctor() { }

	// RVA: 0x75F96E8
	protected internal override object PostDispatch(object panel) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FA0A4
	private static object .cctor() { }

	// RVA: 0x75FA104
	public object .ctor() { }

	// RVA: 0x75FA10C
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseLeaveWindowEvent
{

	// Methods

	// RVA: 0x75F9974
	private static object .cctor() { }

	// RVA: 0x75F9A64
	protected override object Init() { }

	// RVA: 0x75F9B60
	private object LocalInit() { }

	// RVA: 0x75F9C28
	public object .ctor() { }

	// RVA: 0x75F9D24
	public static object GetPooled(object systemEvent) { }

	// RVA: 0x75F9F14
	protected internal override object PostDispatch(object panel) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FA2A8
	private static object .cctor() { }

	// RVA: 0x75FA308
	public object .ctor() { }

	// RVA: 0x75FA310
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseOverEvent
{

	// Methods

	// RVA: 0x75FA160
	private static object .cctor() { }

	// RVA: 0x75FA250
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FA4E4
	private static object .cctor() { }

	// RVA: 0x75FA544
	public object .ctor() { }

	// RVA: 0x75FA54C
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class MouseOutEvent
{

	// Methods

	// RVA: 0x75FA39C
	private static object .cctor() { }

	// RVA: 0x75FA48C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FB290
	private static object .cctor() { }

	// RVA: 0x75FB2F0
	public object .ctor() { }

	// RVA: 0x75FB2F8
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class ContextualMenuPopulateEvent
{

	// Fields
	private object <menu>k__BackingField; // 0xB0
	private object <triggerEvent>k__BackingField; // 0xB8
	private object m_ContextualMenuManager; // 0xC0

	// Properties
	public object menu { get; set; }
	public object triggerEvent { get; set; }

	// Methods

	// RVA: 0x75FA5D8
	private static object .cctor() { }

	// RVA: 0x75FA6C8
	public object get_menu() { }

	// RVA: 0x75FA6D0
	private object set_menu(object value) { }

	// RVA: 0x75FA6D8
	public object get_triggerEvent() { }

	// RVA: 0x75FA6E0
	private object set_triggerEvent(object value) { }

	// RVA: 0x75FA6E8
	public static object GetPooled(object triggerEvent, object menu, object target, object menuManager) { }

	// RVA: 0x75FB038
	protected override object Init() { }

	// RVA: 0x75FB0CC
	private object LocalInit() { }

	// RVA: 0x75FB124
	public object .ctor() { }

	// RVA: 0x75FB1B8
	protected internal override object PostDispatch(object panel) { }

}

// Namespace: UnityEngine.UIElements
internal static class MouseEventsHelper
{

	// Methods

	// RVA: -1
	internal static object SendEnterLeave(object previousTopElementUnderMouse, object currentTopElementUnderMouse, object triggerEvent, object mousePosition) { }

	// RVA: 0x75F0430
	internal static object SendMouseOverMouseOut(object previousTopElementUnderMouse, object currentTopElementUnderMouse, object triggerEvent, object mousePosition) { }

}

// Namespace: UnityEngine.UIElements
internal static class PointerEventsHelper
{

	// Methods

	// RVA: -1
	internal static object SendEnterLeave(object previousTopElementUnderPointer, object currentTopElementUnderPointer, object triggerEvent, object position, object pointerId) { }

	// RVA: 0x75F0098
	internal static object SendOverOut(object previousTopElementUnderPointer, object currentTopElementUnderPointer, object triggerEvent, object position, object pointerId) { }

}

// Namespace: UnityEngine.UIElements
internal class NavigationEventDispatchingStrategy
{

	// Methods

	// RVA: 0x75FB3C0
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75FB420
	public object DispatchEvent(object evt, object panel) { }

	// RVA: 0x75ECA24
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public interface INavigationEvent
{

	// Properties
	public abstract object shiftKey { get; }
	public abstract object altKey { get; }

	// Methods

	// RVA: -1
	public abstract object get_shiftKey() { }

	// RVA: -1
	public abstract object get_altKey() { }

}

// Namespace: UnityEngine.UIElements
internal enum NavigationDeviceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Keyboard;
	public const object NonKeyboard;
}

// Namespace: UnityEngine.UIElements
public abstract class NavigationEventBase<T0>
{

	// Fields
	private object <modifiers>k__BackingField; // 0x0
	private object <deviceType>k__BackingField; // 0x0

	// Properties
	public object modifiers { get; set; }
	public object shiftKey { get; }
	public object altKey { get; }
	internal object deviceType { get; set; }

	// Methods

	// RVA: -1
	public object get_modifiers() { }

	// RVA: -1
	protected object set_modifiers(object value) { }

	// RVA: -1
	public object get_shiftKey() { }

	// RVA: -1
	public object get_altKey() { }

	// RVA: -1
	internal object get_deviceType() { }

	// RVA: -1
	private object set_deviceType(object value) { }

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object GetPooled(object modifiers) { }

	// RVA: -1
	internal static object GetPooled(object deviceType, object modifiers) { }

}

// Namespace: 
public enum Direction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Left;
	public const object Up;
	public const object Right;
	public const object Down;
	public const object Next;
	public const object Previous;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FBA8C
	private static object .cctor() { }

	// RVA: 0x75FBAEC
	public object .ctor() { }

	// RVA: 0x75FBAF4
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class NavigationMoveEvent
{

	// Fields
	private object <direction>k__BackingField; // 0x84
	private object <move>k__BackingField; // 0x88

	// Properties
	public object direction { get; set; }
	private object move { set; }

	// Methods

	// RVA: 0x75FB5F4
	private static object .cctor() { }

	// RVA: 0x75FB6E4
	internal static object DetermineMoveDirection(object x, object y, object deadZone) { }

	// RVA: 0x75FB734
	public object get_direction() { }

	// RVA: 0x75FB73C
	private object set_direction(object value) { }

	// RVA: 0x75FB744
	private object set_move(object value) { }

	// RVA: 0x75FB74C
	public static object GetPooled(object moveVector, object modifiers) { }

	// RVA: 0x75F59C4
	internal static object GetPooled(object moveVector, object deviceType, object modifiers) { }

	// RVA: 0x75FB84C
	public static object GetPooled(object direction, object modifiers) { }

	// RVA: 0x75F57D0
	internal static object GetPooled(object direction, object deviceType, object modifiers) { }

	// RVA: 0x75FB904
	protected override object Init() { }

	// RVA: 0x75FB9F8
	public object .ctor() { }

	// RVA: 0x75FB998
	private object LocalInit() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FBD04
	private static object .cctor() { }

	// RVA: 0x75FBD64
	public object .ctor() { }

	// RVA: 0x75FBD6C
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class NavigationCancelEvent
{

	// Methods

	// RVA: 0x75FBBBC
	private static object .cctor() { }

	// RVA: 0x75FBCAC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FBF40
	private static object .cctor() { }

	// RVA: 0x75FBFA0
	public object .ctor() { }

	// RVA: 0x75FBFA8
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class NavigationSubmitEvent
{

	// Methods

	// RVA: 0x75FBDF8
	private static object .cctor() { }

	// RVA: 0x75FBEE8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class PanelChangedEventBase<T0>
{

	// Fields
	private object <originPanel>k__BackingField; // 0x0
	private object <destinationPanel>k__BackingField; // 0x0

	// Properties
	public object originPanel { get; set; }
	public object destinationPanel { get; set; }

	// Methods

	// RVA: -1
	public object get_originPanel() { }

	// RVA: -1
	private object set_originPanel(object value) { }

	// RVA: -1
	public object get_destinationPanel() { }

	// RVA: -1
	private object set_destinationPanel(object value) { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object GetPooled(object originPanel, object destinationPanel) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FC17C
	private static object .cctor() { }

	// RVA: 0x75FC1DC
	public object .ctor() { }

	// RVA: 0x75FC1E4
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class AttachToPanelEvent
{

	// Methods

	// RVA: 0x75FC034
	private static object .cctor() { }

	// RVA: 0x75FC124
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FC3B8
	private static object .cctor() { }

	// RVA: 0x75FC418
	public object .ctor() { }

	// RVA: 0x75FC420
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class DetachFromPanelEvent
{

	// Methods

	// RVA: 0x75FC270
	private static object .cctor() { }

	// RVA: 0x75FC360
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class PointerCaptureDispatchingStrategy
{

	// Methods

	// RVA: 0x75FC4AC
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75FC50C
	public object DispatchEvent(object evt, object panel) { }

	// RVA: 0x75EC9FC
	public object .ctor() { }

}

// Namespace: 
internal enum LocationFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object OutsidePanel;
}

// Namespace: 
private struct PointerLocation
{

	// Fields
	private object <Position>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <Panel>k__BackingField; // 0x0
	private object <Flags>k__BackingField; // 0x8

	// Properties
	internal object Position { get; set; }
	internal object Panel { get; set; }
	internal object Flags { get; set; }

	// Methods

	// RVA: 0x75FD478
	internal object get_Position() { }

	// RVA: 0x75FD488
	private object set_Position(object value) { }

	// RVA: 0x75FD498
	internal object get_Panel() { }

	// RVA: 0x75FD4A8
	private object set_Panel(object value) { }

	// RVA: 0x75FD4B8
	internal object get_Flags() { }

	// RVA: 0x75FD4C8
	private object set_Flags(object value) { }

	// RVA: 0x75FCCE8
	internal object SetLocation(object position, object panel) { }

}

// Namespace: UnityEngine.UIElements
internal static class PointerDeviceState
{

	// Fields
	private static object s_PlayerPointerLocations; // 0x0
	private static object s_PressedButtons; // 0x8
	private static readonly object s_PlayerPanelWithSoftPointerCapture; // 0x10

	// Methods

	// RVA: 0x75FCAB8
	internal static object RemovePanelData(object panel) { }

	// RVA: 0x75FCE14
	public static object SavePointerPosition(object pointerId, object position, object panel, object contextType) { }

	// RVA: 0x75F7A8C
	public static object PressButton(object pointerId, object buttonId) { }

	// RVA: 0x75F8100
	public static object ReleaseButton(object pointerId, object buttonId) { }

	// RVA: 0x75F9E6C
	public static object ReleaseAllButtons(object pointerId) { }

	// RVA: 0x75EFFEC
	public static object GetPointerPosition(object pointerId, object contextType) { }

	// RVA: 0x75FCEE0
	public static object GetPanel(object pointerId, object contextType) { }

	// RVA: 0x75FCF8C
	private static object HasFlagFast(object flagSet, object flag) { }

	// RVA: 0x75FCF98
	public static object HasLocationFlag(object pointerId, object contextType, object flag) { }

	// RVA: 0x75FD050
	public static object GetPressedButtons(object pointerId) { }

	// RVA: 0x75FD0F8
	internal static object HasAdditionalPressedButtons(object pointerId, object exceptButtonId) { }

	// RVA: 0x75FD1B4
	internal static object SetPlayerPanelWithSoftPointerCapture(object pointerId, object panel) { }

	// RVA: 0x75FD284
	internal static object GetPlayerPanelWithSoftPointerCapture(object pointerId) { }

	// RVA: 0x75FD32C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class PointerEventDispatchingStrategy
{

	// Methods

	// RVA: 0x75FD4E0
	public object CanDispatchEvent(object evt) { }

	// RVA: 0x75FD540
	public virtual object DispatchEvent(object evt, object panel) { }

	// RVA: 0x75FD930
	private static object SendEventToTarget(object evt, object panel) { }

	// RVA: 0x75FD604
	private static object SetBestTargetForEvent(object evt, object panel) { }

	// RVA: 0x75FD9E8
	private static object UpdateElementUnderPointer(object evt, object panel, object elementUnderPointer) { }

	// RVA: 0x75ECA14
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public static class PointerType
{

	// Fields
	public static readonly object mouse; // 0x0
	public static readonly object touch; // 0x8
	public static readonly object pen; // 0x10
	public static readonly object unknown; // 0x18

	// Methods

	// RVA: 0x75FDD30
	internal static object GetPointerType(object pointerId) { }

	// RVA: 0x75FDE78
	internal static object IsDirectManipulationDevice(object pointerType) { }

	// RVA: 0x75FDF38
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public static class PointerId
{

	// Fields
	public static readonly object maxPointers; // 0x0
	public static readonly object invalidPointerId; // 0x4
	public static readonly object mousePointerId; // 0x8
	public static readonly object touchPointerIdBase; // 0xC
	public static readonly object touchPointerCount; // 0x10
	public static readonly object penPointerIdBase; // 0x14
	public static readonly object penPointerCount; // 0x18
	internal static readonly object hoveringPointers; // 0x20

	// Methods

	// RVA: 0x75FDFFC
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public interface IPointerEvent
{

	// Properties
	public abstract object pointerId { get; }
	public abstract object pointerType { get; }
	public abstract object isPrimary { get; }
	public abstract object button { get; }
	public abstract object pressedButtons { get; }
	public abstract object position { get; }
	public abstract object localPosition { get; }
	public abstract object deltaPosition { get; }
	public abstract object deltaTime { get; }
	public abstract object clickCount { get; }
	public abstract object pressure { get; }
	public abstract object tangentialPressure { get; }
	public abstract object altitudeAngle { get; }
	public abstract object azimuthAngle { get; }
	public abstract object twist { get; }
	public abstract object tilt { get; }
	public abstract object penStatus { get; }
	public abstract object radius { get; }
	public abstract object radiusVariance { get; }
	public abstract object modifiers { get; }
	public abstract object shiftKey { get; }
	public abstract object ctrlKey { get; }
	public abstract object commandKey { get; }
	public abstract object altKey { get; }
	public abstract object actionKey { get; }

	// Methods

	// RVA: -1
	public abstract object get_pointerId() { }

	// RVA: -1
	public abstract object get_pointerType() { }

	// RVA: -1
	public abstract object get_isPrimary() { }

	// RVA: -1
	public abstract object get_button() { }

	// RVA: -1
	public abstract object get_pressedButtons() { }

	// RVA: -1
	public abstract object get_position() { }

	// RVA: -1
	public abstract object get_localPosition() { }

	// RVA: -1
	public abstract object get_deltaPosition() { }

	// RVA: -1
	public abstract object get_deltaTime() { }

	// RVA: -1
	public abstract object get_clickCount() { }

	// RVA: -1
	public abstract object get_pressure() { }

	// RVA: -1
	public abstract object get_tangentialPressure() { }

	// RVA: -1
	public abstract object get_altitudeAngle() { }

	// RVA: -1
	public abstract object get_azimuthAngle() { }

	// RVA: -1
	public abstract object get_twist() { }

	// RVA: -1
	public abstract object get_tilt() { }

	// RVA: -1
	public abstract object get_penStatus() { }

	// RVA: -1
	public abstract object get_radius() { }

	// RVA: -1
	public abstract object get_radiusVariance() { }

	// RVA: -1
	public abstract object get_modifiers() { }

	// RVA: -1
	public abstract object get_shiftKey() { }

	// RVA: -1
	public abstract object get_ctrlKey() { }

	// RVA: -1
	public abstract object get_commandKey() { }

	// RVA: -1
	public abstract object get_altKey() { }

	// RVA: -1
	public abstract object get_actionKey() { }

}

// Namespace: UnityEngine.UIElements
internal interface IPointerEventInternal
{

	// Properties
	public abstract object triggeredByOS { get; set; }
	public abstract object recomputeTopElementUnderPointer { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_triggeredByOS() { }

	// RVA: -1
	public abstract object set_triggeredByOS(object value) { }

	// RVA: -1
	public abstract object get_recomputeTopElementUnderPointer() { }

	// RVA: -1
	public abstract object set_recomputeTopElementUnderPointer(object value) { }

}

// Namespace: UnityEngine.UIElements
internal static class PointerEventHelper
{

	// Methods

	// RVA: 0x75FE0BC
	public static object GetPooled(object eventType, object mousePosition, object delta, object button, object clickCount, object modifiers) { }

}

// Namespace: UnityEngine.UIElements
public abstract class PointerEventBase<T0>
{

	// Fields
	private const object k_DefaultButtonPressure;
	private object m_AltitudeNeedsConversion; // 0x0
	private object m_AzimuthNeedsConversion; // 0x0
	private object m_AltitudeAngle; // 0x0
	private object m_AzimuthAngle; // 0x0
	private object m_TiltNeeded; // 0x0
	private object m_Tilt; // 0x0
	private object <pointerId>k__BackingField; // 0x0
	private object <pointerType>k__BackingField; // 0x0
	private object <isPrimary>k__BackingField; // 0x0
	private object <button>k__BackingField; // 0x0
	private object <pressedButtons>k__BackingField; // 0x0
	private object <position>k__BackingField; // 0x0
	private object <localPosition>k__BackingField; // 0x0
	private object <deltaPosition>k__BackingField; // 0x0
	private object <deltaTime>k__BackingField; // 0x0
	private object <clickCount>k__BackingField; // 0x0
	private object <pressure>k__BackingField; // 0x0
	private object <tangentialPressure>k__BackingField; // 0x0
	private object <twist>k__BackingField; // 0x0
	private object <penStatus>k__BackingField; // 0x0
	private object <radius>k__BackingField; // 0x0
	private object <radiusVariance>k__BackingField; // 0x0
	private object <modifiers>k__BackingField; // 0x0
	private object <UnityEngine.UIElements.IPointerEventInternal.triggeredByOS>k__BackingField; // 0x0
	private object <UnityEngine.UIElements.IPointerEventInternal.recomputeTopElementUnderPointer>k__BackingField; // 0x0

	// Properties
	public object pointerId { get; set; }
	public object pointerType { get; set; }
	public object isPrimary { get; set; }
	public object button { get; set; }
	public object pressedButtons { get; set; }
	public object position { get; set; }
	public object localPosition { get; set; }
	public object deltaPosition { get; set; }
	public object deltaTime { get; set; }
	public object clickCount { get; set; }
	public object pressure { get; set; }
	public object tangentialPressure { get; set; }
	public object altitudeAngle { get; set; }
	public object azimuthAngle { get; set; }
	public object twist { get; set; }
	public object tilt { get; set; }
	public object penStatus { get; set; }
	public object radius { get; set; }
	public object radiusVariance { get; set; }
	public object modifiers { get; set; }
	public object shiftKey { get; }
	public object ctrlKey { get; }
	public object commandKey { get; }
	public object altKey { get; }
	public object actionKey { get; }
	private object UnityEngine.UIElements.IPointerEventInternal.triggeredByOS { get; set; }
	private object UnityEngine.UIElements.IPointerEventInternal.recomputeTopElementUnderPointer { get; set; }
	public override object currentTarget { get; set; }

	// Methods

	// RVA: -1
	public object get_pointerId() { }

	// RVA: -1
	protected object set_pointerId(object value) { }

	// RVA: -1
	public object get_pointerType() { }

	// RVA: -1
	protected object set_pointerType(object value) { }

	// RVA: -1
	public object get_isPrimary() { }

	// RVA: -1
	protected object set_isPrimary(object value) { }

	// RVA: -1
	public object get_button() { }

	// RVA: -1
	protected object set_button(object value) { }

	// RVA: -1
	public object get_pressedButtons() { }

	// RVA: -1
	protected object set_pressedButtons(object value) { }

	// RVA: -1
	public object get_position() { }

	// RVA: -1
	protected object set_position(object value) { }

	// RVA: -1
	public object get_localPosition() { }

	// RVA: -1
	protected object set_localPosition(object value) { }

	// RVA: -1
	public object get_deltaPosition() { }

	// RVA: -1
	protected object set_deltaPosition(object value) { }

	// RVA: -1
	public object get_deltaTime() { }

	// RVA: -1
	protected object set_deltaTime(object value) { }

	// RVA: -1
	public object get_clickCount() { }

	// RVA: -1
	protected object set_clickCount(object value) { }

	// RVA: -1
	public object get_pressure() { }

	// RVA: -1
	protected object set_pressure(object value) { }

	// RVA: -1
	public object get_tangentialPressure() { }

	// RVA: -1
	protected object set_tangentialPressure(object value) { }

	// RVA: -1
	public object get_altitudeAngle() { }

	// RVA: -1
	protected object set_altitudeAngle(object value) { }

	// RVA: -1
	public object get_azimuthAngle() { }

	// RVA: -1
	protected object set_azimuthAngle(object value) { }

	// RVA: -1
	public object get_twist() { }

	// RVA: -1
	protected object set_twist(object value) { }

	// RVA: -1
	public object get_tilt() { }

	// RVA: -1
	protected object set_tilt(object value) { }

	// RVA: -1
	public object get_penStatus() { }

	// RVA: -1
	protected object set_penStatus(object value) { }

	// RVA: -1
	public object get_radius() { }

	// RVA: -1
	protected object set_radius(object value) { }

	// RVA: -1
	public object get_radiusVariance() { }

	// RVA: -1
	protected object set_radiusVariance(object value) { }

	// RVA: -1
	public object get_modifiers() { }

	// RVA: -1
	protected object set_modifiers(object value) { }

	// RVA: -1
	public object get_shiftKey() { }

	// RVA: -1
	public object get_ctrlKey() { }

	// RVA: -1
	public object get_commandKey() { }

	// RVA: -1
	public object get_altKey() { }

	// RVA: -1
	public object get_actionKey() { }

	// RVA: -1
	private object UnityEngine.UIElements.IPointerEventInternal.get_triggeredByOS() { }

	// RVA: -1
	private object UnityEngine.UIElements.IPointerEventInternal.set_triggeredByOS(object value) { }

	// RVA: -1
	private object UnityEngine.UIElements.IPointerEventInternal.get_recomputeTopElementUnderPointer() { }

	// RVA: -1
	private object UnityEngine.UIElements.IPointerEventInternal.set_recomputeTopElementUnderPointer(object value) { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public override object get_currentTarget() { }

	// RVA: -1
	internal override object set_currentTarget(object value) { }

	// RVA: -1
	private static object IsMouse(object systemEvent) { }

	// RVA: -1
	private static object IsTouch(object systemEvent) { }

	// RVA: -1
	private static object TiltToAzimuth(object tilt) { }

	// RVA: -1
	private static object AzimuthAndAlitutudeToTilt(object altitude, object azimuth) { }

	// RVA: -1
	private static object TiltToAltitude(object tilt) { }

	// RVA: -1
	public static object GetPooled(object systemEvent) { }

	// RVA: -1
	internal static object GetPooled(object eventType, object mousePosition, object delta, object button, object clickCount, object modifiers) { }

	// RVA: -1
	public static object GetPooled(object touch, object modifiers) { }

	// RVA: -1
	public static object GetPooled(object pen, object modifiers) { }

	// RVA: -1
	internal static object GetPooled(object triggerEvent, object position, object pointerId) { }

	// RVA: -1
	public static object GetPooled(object triggerEvent) { }

	// RVA: -1
	protected internal override object PreDispatch(object panel) { }

	// RVA: -1
	protected internal override object PostDispatch(object panel) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FE958
	private static object .cctor() { }

	// RVA: 0x75FE9B8
	public object .ctor() { }

	// RVA: 0x75FE9C0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerDownEvent
{

	// Methods

	// RVA: 0x75FE374
	private static object .cctor() { }

	// RVA: 0x75FE464
	protected override object Init() { }

	// RVA: 0x75FE4C0
	private object LocalInit() { }

	// RVA: 0x75FE600
	public object .ctor() { }

	// RVA: 0x75FE65C
	protected internal override object PostDispatch(object panel) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FF4E0
	private static object .cctor() { }

	// RVA: 0x75FF540
	public object .ctor() { }

	// RVA: 0x75FF548
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerMoveEvent
{

	// Fields
	private object <isHandledByDraggable>k__BackingField; // 0xFE

	// Properties
	internal object isHandledByDraggable { get; set; }

	// Methods

	// RVA: 0x75FEA54
	private static object .cctor() { }

	// RVA: 0x75FEB44
	internal object get_isHandledByDraggable() { }

	// RVA: 0x75FEB4C
	internal object set_isHandledByDraggable(object value) { }

	// RVA: 0x75FEB54
	protected override object Init() { }

	// RVA: 0x75FEBB0
	private object LocalInit() { }

	// RVA: 0x75FECF8
	public object .ctor() { }

	// RVA: 0x75FED54
	protected internal override object PostDispatch(object panel) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75FF8C4
	private static object .cctor() { }

	// RVA: 0x75FF924
	public object .ctor() { }

	// RVA: 0x75FF92C
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerStationaryEvent
{

	// Methods

	// RVA: 0x75FF5DC
	private static object .cctor() { }

	// RVA: 0x75FF6CC
	protected override object Init() { }

	// RVA: 0x75FF728
	private object LocalInit() { }

	// RVA: 0x75FF868
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x760011C
	private static object .cctor() { }

	// RVA: 0x760017C
	public object .ctor() { }

	// RVA: 0x7600184
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerUpEvent
{

	// Methods

	// RVA: 0x75FF9C0
	private static object .cctor() { }

	// RVA: 0x75FFAB0
	protected override object Init() { }

	// RVA: 0x75FFB0C
	private object LocalInit() { }

	// RVA: 0x75FFC4C
	public object .ctor() { }

	// RVA: 0x75FFCA8
	protected internal override object PostDispatch(object panel) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7600978
	private static object .cctor() { }

	// RVA: 0x76009D8
	public object .ctor() { }

	// RVA: 0x76009E0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerCancelEvent
{

	// Methods

	// RVA: 0x7600218
	private static object .cctor() { }

	// RVA: 0x7600308
	protected override object Init() { }

	// RVA: 0x7600364
	private object LocalInit() { }

	// RVA: 0x76004A4
	public object .ctor() { }

	// RVA: 0x7600500
	protected internal override object PostDispatch(object panel) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7600CB0
	private static object .cctor() { }

	// RVA: 0x7600D10
	public object .ctor() { }

	// RVA: 0x7600D18
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class ClickEvent
{

	// Methods

	// RVA: 0x7600A74
	private static object .cctor() { }

	// RVA: 0x7600B64
	protected override object Init() { }

	// RVA: 0x7600BC4
	private object LocalInit() { }

	// RVA: 0x7600BD0
	public object .ctor() { }

	// RVA: 0x7600C30
	internal static object GetPooled(object pointerEvent, object clickCount) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7600F68
	private static object .cctor() { }

	// RVA: 0x7600FC8
	public object .ctor() { }

	// RVA: 0x7600FD0
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerEnterEvent
{

	// Methods

	// RVA: 0x7600DAC
	private static object .cctor() { }

	// RVA: 0x7600E9C
	protected override object Init() { }

	// RVA: 0x7600EFC
	private object LocalInit() { }

	// RVA: 0x7600F08
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7601220
	private static object .cctor() { }

	// RVA: 0x7601280
	public object .ctor() { }

	// RVA: 0x7601288
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerLeaveEvent
{

	// Methods

	// RVA: 0x7601064
	private static object .cctor() { }

	// RVA: 0x7601154
	protected override object Init() { }

	// RVA: 0x76011B4
	private object LocalInit() { }

	// RVA: 0x76011C0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7601464
	private static object .cctor() { }

	// RVA: 0x76014C4
	public object .ctor() { }

	// RVA: 0x76014CC
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerOverEvent
{

	// Methods

	// RVA: 0x760131C
	private static object .cctor() { }

	// RVA: 0x760140C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x76016A0
	private static object .cctor() { }

	// RVA: 0x7601700
	public object .ctor() { }

	// RVA: 0x7601708
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class PointerOutEvent
{

	// Methods

	// RVA: 0x7601558
	private static object .cctor() { }

	// RVA: 0x7601648
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7601968
	private static object .cctor() { }

	// RVA: 0x76019C8
	public object .ctor() { }

	// RVA: 0x76019D0
	internal object <.cctor>b__12_0() { }

}

// Namespace: UnityEngine.UIElements
internal class PropagationPaths
{

	// Fields
	private static readonly object s_Pool; // 0x0
	public readonly object trickleDownPath; // 0x8
	public readonly object targetElements; // 0x10
	public readonly object bubbleUpPath; // 0x18
	private const object k_DefaultPropagationDepth;
	private const object k_DefaultTargetCount;

	// Methods

	// RVA: 0x7601794
	public object .ctor() { }

	// RVA: 0x75EBE48
	public static object Build(object elem, object evt) { }

	// RVA: 0x75F0FEC
	public object Release() { }

	// RVA: 0x7601854
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7601C44
	private static object .cctor() { }

	// RVA: 0x7601CA4
	public object .ctor() { }

	// RVA: 0x7601CAC
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class CustomStyleResolvedEvent
{

	// Properties
	public object customStyle { get; }

	// Methods

	// RVA: 0x7601A24
	private static object .cctor() { }

	// RVA: 0x7601B14
	public object get_customStyle() { }

	// RVA: 0x7601BA0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7602024
	private static object .cctor() { }

	// RVA: 0x7602084
	public object .ctor() { }

	// RVA: 0x760208C
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class TooltipEvent
{

	// Fields
	private object <tooltip>k__BackingField; // 0x80
	private object <rect>k__BackingField; // 0x88

	// Properties
	public object tooltip { set; }
	public object rect { set; }

	// Methods

	// RVA: 0x7601D5C
	private static object .cctor() { }

	// RVA: 0x7601E4C
	public object set_tooltip(object value) { }

	// RVA: 0x7601E54
	public object set_rect(object value) { }

	// RVA: 0x7601E60
	protected override object Init() { }

	// RVA: 0x7601EFC
	private object LocalInit() { }

	// RVA: 0x7601F64
	public object .ctor() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object m_Enumerator; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x7602254
	internal object .ctor(object enumerator) { }

	// RVA: 0x7602664
	public object MoveNext() { }

	// RVA: 0x7602710
	public object get_Current() { }

	// RVA: 0x7602790
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x76028A0
	public object Reset() { }

	// RVA: 0x76028A8
	public object Dispose() { }

}

// Namespace: UnityEngine.UIElements
public struct StylePropertyNameCollection
{

	// Fields
	internal object propertiesList; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x76021BC
	internal object .ctor(object list) { }

	// RVA: 0x76021CC
	public object GetEnumerator() { }

	// RVA: 0x76022E8
	private object System.Collections.Generic.IEnumerable<UnityEngine.UIElements.StylePropertyName>.GetEnumerator() { }

	// RVA: 0x7602480
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.UIElements
public abstract class TransitionEventBase<T0>
{

	// Fields
	private readonly object <stylePropertyNames>k__BackingField; // 0x0
	private object <elapsedTime>k__BackingField; // 0x0

	// Properties
	public object stylePropertyNames { get; }
	protected object elapsedTime { set; }

	// Methods

	// RVA: -1
	public object get_stylePropertyNames() { }

	// RVA: -1
	protected object set_elapsedTime(object value) { }

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	protected override object Init() { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object GetPooled(object stylePropertyName, object elapsedTime) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7602A9C
	private static object .cctor() { }

	// RVA: 0x7602AFC
	public object .ctor() { }

	// RVA: 0x7602B04
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class TransitionRunEvent
{

	// Methods

	// RVA: 0x7602954
	private static object .cctor() { }

	// RVA: 0x7602A44
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7602CD8
	private static object .cctor() { }

	// RVA: 0x7602D38
	public object .ctor() { }

	// RVA: 0x7602D40
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class TransitionStartEvent
{

	// Methods

	// RVA: 0x7602B90
	private static object .cctor() { }

	// RVA: 0x7602C80
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7602F14
	private static object .cctor() { }

	// RVA: 0x7602F74
	public object .ctor() { }

	// RVA: 0x7602F7C
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class TransitionEndEvent
{

	// Methods

	// RVA: 0x7602DCC
	private static object .cctor() { }

	// RVA: 0x7602EBC
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7603150
	private static object .cctor() { }

	// RVA: 0x76031B0
	public object .ctor() { }

	// RVA: 0x76031B8
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public sealed class TransitionCancelEvent
{

	// Methods

	// RVA: 0x7603008
	private static object .cctor() { }

	// RVA: 0x76030F8
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x76034DC
	private static object .cctor() { }

	// RVA: 0x760353C
	public object .ctor() { }

	// RVA: 0x7603544
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements
public class IMGUIEvent
{

	// Methods

	// RVA: 0x7603244
	private static object .cctor() { }

	// RVA: 0x7603334
	public static object GetPooled(object systemEvent) { }

	// RVA: 0x76033EC
	protected override object Init() { }

	// RVA: 0x760344C
	private object LocalInit() { }

	// RVA: 0x7603458
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseFieldMouseDragger
{

	// Methods

	// RVA: 0x76035FC
	public object SetDragZone(object dragElement) { }

	// RVA: -1
	public abstract object SetDragZone(object dragElement, object hotZone) { }

	// RVA: 0x7603654
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class FieldMouseDragger<T0>
{

	// Fields
	private readonly object m_DrivenField; // 0x0
	private object m_DragElement; // 0x0
	private object m_DragHotZone; // 0x0
	private object <dragging>k__BackingField; // 0x0
	private object <startValue>k__BackingField; // 0x0

	// Properties
	public object dragging { get; set; }
	public object startValue { get; set; }

	// Methods

	// RVA: -1
	public object .ctor(object drivenField) { }

	// RVA: -1
	public object get_dragging() { }

	// RVA: -1
	public object set_dragging(object value) { }

	// RVA: -1
	public object get_startValue() { }

	// RVA: -1
	public object set_startValue(object value) { }

	// RVA: -1
	public sealed override object SetDragZone(object dragElement, object hotZone) { }

	// RVA: -1
	private object CanStartDrag(object button, object localPosition) { }

	// RVA: -1
	private object UpdateValueOnPointerDown(object evt) { }

	// RVA: -1
	private object ProcessDownEvent(object evt) { }

	// RVA: -1
	private object UpdateValueOnPointerMove(object evt) { }

	// RVA: -1
	private object ProcessMoveEvent(object shiftKey, object altKey, object deltaPosition) { }

	// RVA: -1
	private object UpdateValueOnPointerUp(object evt) { }

	// RVA: -1
	private object ProcessUpEvent(object evt, object pointerId) { }

	// RVA: -1
	private object UpdateValueOnKeyDown(object evt) { }

}

// Namespace: UnityEngine.UIElements
public abstract class Focusable
{

	// Fields
	private object <focusable>k__BackingField; // 0x18
	private object <tabIndex>k__BackingField; // 0x1C
	private object m_DelegatesFocus; // 0x20
	private object m_ExcludeFromFocusRing; // 0x21

	// Properties
	public abstract object focusController { get; }
	public object focusable { get; set; }
	public object tabIndex { get; set; }
	public object delegatesFocus { get; set; }
	internal object excludeFromFocusRing { get; set; }
	public virtual object canGrabFocus { get; }

	// Methods

	// RVA: 0x760365C
	protected object .ctor() { }

	// RVA: -1
	public abstract object get_focusController() { }

	// RVA: 0x7603690
	public object get_focusable() { }

	// RVA: 0x7603698
	public object set_focusable(object value) { }

	// RVA: 0x76036A0
	public object get_tabIndex() { }

	// RVA: 0x76036A8
	public object set_tabIndex(object value) { }

	// RVA: 0x76036B0
	public object get_delegatesFocus() { }

	// RVA: 0x76036B8
	public object set_delegatesFocus(object value) { }

	// RVA: 0x76036C0
	internal object get_excludeFromFocusRing() { }

	// RVA: 0x76036C8
	internal object set_excludeFromFocusRing(object value) { }

	// RVA: 0x76037B8
	public virtual object get_canGrabFocus() { }

	// RVA: 0x76037C0
	public virtual object Focus() { }

	// RVA: 0x7603CEC
	public virtual object Blur() { }

	// RVA: 0x7603F8C
	internal object BlurImmediately() { }

	// RVA: 0x7603B6C
	private object GetFocusDelegate() { }

	// RVA: 0x7603FEC
	private static object GetFirstFocusableChild(object ve) { }

	// RVA: 0x7604180
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: 0x7604260
	internal override object ExecuteDefaultActionDisabled(object evt) { }

	// RVA: 0x76041F0
	private object ProcessEvent(object evt) { }

}

// Namespace: UnityEngine.UIElements
public class FocusChangeDirection
{

	// Fields
	private static readonly object <unspecified>k__BackingField; // 0x0
	private static readonly object <none>k__BackingField; // 0x8
	private static readonly object <lastValue>k__BackingField; // 0x10
	private readonly object m_Value; // 0x8

	// Properties
	public static object unspecified { get; }
	public static object none { get; }
	protected static object lastValue { get; }

	// Methods

	// RVA: 0x7604588
	public static object get_unspecified() { }

	// RVA: 0x7604604
	public static object get_none() { }

	// RVA: 0x7604680
	protected static object get_lastValue() { }

	// RVA: 0x76046FC
	protected object .ctor(object value) { }

	// RVA: 0x7604728
	public static object op_Implicit(object fcd) { }

	// RVA: 0x7604734
	private object System.IDisposable.Dispose() { }

	// RVA: 0x7604774
	protected virtual object Dispose() { }

	// RVA: 0x7604778
	internal virtual object ApplyTo(object focusController, object f) { }

	// RVA: 0x7604A84
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public interface IFocusRing
{

	// Methods

	// RVA: -1
	public abstract object GetFocusChangeDirection(object currentFocusable, object e) { }

	// RVA: -1
	public abstract object GetNextFocusable(object currentFocusable, object direction) { }

}

// Namespace: 
private struct FocusedElement
{

	// Fields
	public object m_SubTreeRoot; // 0xFFFFFFFFFFFFFFF8
	public object m_FocusedElement; // 0x0
}

// Namespace: UnityEngine.UIElements
public class FocusController
{

	// Fields
	private readonly object <focusRing>k__BackingField; // 0x8
	private object m_SelectedTextElement; // 0x10
	private object m_FocusedElements; // 0x18
	private object m_LastFocusedElement; // 0x20
	internal object m_LastPendingFocusedElement; // 0x28
	private object m_PendingFocusCount; // 0x30
	private object <imguiKeyboardControl>k__BackingField; // 0x34

	// Properties
	private object focusRing { get; }
	internal object selectedTextElement { set; }
	public object focusedElement { get; }
	internal object imguiKeyboardControl { get; set; }

	// Methods

	// RVA: 0x7604B68
	public object .ctor(object focusRing) { }

	// RVA: 0x7604C04
	private object get_focusRing() { }

	// RVA: 0x7604C0C
	internal object set_selectedTextElement(object value) { }

	// RVA: 0x7604D08
	public object get_focusedElement() { }

	// RVA: 0x760502C
	internal object IsFocused(object f) { }

	// RVA: 0x7604D64
	internal object GetRetargetedFocusedElement(object retargetAgainst) { }

	// RVA: 0x75ED914
	internal object GetLeafFocusedElement() { }

	// RVA: 0x7604FC0
	private object IsLocalElement(object f) { }

	// RVA: 0x760521C
	internal object IsPendingFocus(object f) { }

	// RVA: 0x7605308
	internal object SetFocusToLastFocusedElement() { }

	// RVA: 0x76053AC
	internal object BlurLastFocusedElement() { }

	// RVA: 0x7605458
	internal object DoFocusChange(object f) { }

	// RVA: 0x75F3110
	internal object ProcessPendingFocusChange(object f) { }

	// RVA: 0x7605650
	internal object FocusNextInDirection(object direction) { }

	// RVA: 0x760579C
	private object AboutToReleaseFocus(object focusable, object willGiveFocusTo, object direction, object dispatchMode) { }

	// RVA: 0x7605964
	private object ReleaseFocus(object focusable, object willGiveFocusTo, object direction, object dispatchMode) { }

	// RVA: 0x7605B2C
	private object AboutToGrabFocus(object focusable, object willTakeFocusFrom, object direction, object dispatchMode) { }

	// RVA: 0x7605CF4
	private object GrabFocus(object focusable, object willTakeFocusFrom, object direction, object bIsFocusDelegated, object dispatchMode) { }

	// RVA: 0x7603D4C
	internal object Blur(object focusable, object bIsFocusDelegated, object dispatchMode) { }

	// RVA: 0x7603C08
	internal object SwitchFocus(object newFocusedElement, object bIsFocusDelegated, object dispatchMode) { }

	// RVA: 0x76047AC
	internal object SwitchFocus(object newFocusedElement, object direction, object bIsFocusDelegated, object dispatchMode) { }

	// RVA: 0x76042D0
	internal object SwitchFocusOnEvent(object e) { }

	// RVA: 0x7605EC0
	internal object ReevaluateFocus() { }

	// RVA: 0x7605FC4
	internal object GetFocusableParentForPointerEvent(object target, object effectiveTarget) { }

	// RVA: 0x76060E4
	internal object get_imguiKeyboardControl() { }

	// RVA: 0x76060EC
	internal object set_imguiKeyboardControl(object value) { }

	// RVA: 0x76060F4
	internal object SyncIMGUIFocus(object imguiKeyboardControlID, object imguiContainerHavingKeyboardControl, object forceSwitch) { }

}

// Namespace: UnityEngine.UIElements
public class DynamicAtlasSettings
{

	// Fields
	private object m_MinAtlasSize; // 0x8
	private object m_MaxAtlasSize; // 0xC
	private object m_MaxSubTextureSize; // 0x10
	private object m_ActiveFilters; // 0x14
	private object m_CustomFilter; // 0x18

	// Properties
	public object minAtlasSize { get; set; }
	public object maxAtlasSize { get; set; }
	public object maxSubTextureSize { get; set; }
	public object activeFilters { get; set; }
	public static object defaultFilters { get; }
	public object customFilter { get; set; }
	public static object defaults { get; }

	// Methods

	// RVA: 0x7606340
	public object get_minAtlasSize() { }

	// RVA: 0x7606348
	public object set_minAtlasSize(object value) { }

	// RVA: 0x7606350
	public object get_maxAtlasSize() { }

	// RVA: 0x7606358
	public object set_maxAtlasSize(object value) { }

	// RVA: 0x7606360
	public object get_maxSubTextureSize() { }

	// RVA: 0x7606368
	public object set_maxSubTextureSize(object value) { }

	// RVA: 0x7606370
	public object get_activeFilters() { }

	// RVA: 0x7606378
	public object set_activeFilters(object value) { }

	// RVA: 0x7606380
	public static object get_defaultFilters() { }

	// RVA: 0x7606388
	public object get_customFilter() { }

	// RVA: 0x7606390
	public object set_customFilter(object value) { }

	// RVA: 0x7606398
	public static object get_defaults() { }

	// RVA: 0x7606424
	public object .ctor() { }

}

// Namespace: 
public class ChangeDirection
{

	// Methods

	// RVA: 0x7607548
	public object .ctor(object i) { }

}

// Namespace: 
private struct FocusableHierarchyTraversal
{

	// Fields
	public object currentFocusable; // 0xFFFFFFFFFFFFFFF8
	public object validRect; // 0x0
	public object firstPass; // 0x10
	public object direction; // 0x18

	// Methods

	// RVA: 0x76075F4
	private object ValidateHierarchyTraversal(object v) { }

	// RVA: 0x76076F0
	private object ValidateElement(object v) { }

	// RVA: 0x7607820
	private object Order(object a, object b) { }

	// RVA: 0x7607CF4
	private object StrictOrder(object a, object b) { }

	// RVA: 0x76079A8
	private object StrictOrder(object ra, object rb) { }

	// RVA: 0x7607BE4
	private object TieBreaker(object ra, object rb) { }

	// RVA: 0x7606F98
	public object GetBestOverall(object candidate, object bestSoFar) { }

}

// Namespace: UnityEngine.UIElements
internal class NavigateFocusRing
{

	// Fields
	public static readonly object Left; // 0x0
	public static readonly object Right; // 0x8
	public static readonly object Up; // 0x10
	public static readonly object Down; // 0x18
	public static readonly object Next; // 0x20
	public static readonly object Previous; // 0x28
	private readonly object m_Root; // 0x8
	private readonly object m_Ring; // 0x10

	// Properties
	private object focusController { get; }

	// Methods

	// RVA: 0x760642C
	private object get_focusController() { }

	// RVA: 0x760647C
	public object .ctor(object root) { }

	// RVA: 0x76064FC
	public object GetFocusChangeDirection(object currentFocusable, object e) { }

	// RVA: 0x76069A8
	public virtual object GetNextFocusable(object currentFocusable, object direction) { }

	// RVA: 0x7606B60
	private object GetNextFocusable2D(object currentFocusable, object direction) { }

	// RVA: 0x7607104
	private static object IsActive(object v) { }

	// RVA: 0x7607228
	private static object IsNavigable(object focusable) { }

	// RVA: 0x76072B0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public enum PanelScaleMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ConstantPixelSize;
	public const object ConstantPhysicalSize;
	public const object ScaleWithScreenSize;
}

// Namespace: UnityEngine.UIElements
public enum PanelScreenMatchMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MatchWidthOrHeight;
	public const object Shrink;
	public const object Expand;
}

// Namespace: 
private class RuntimePanelAccess
{

	// Fields
	private readonly object m_Settings; // 0x8
	private object m_RuntimePanel; // 0x10

	// Properties
	internal object isInitialized { get; }
	internal object panel { get; }

	// Methods

	// RVA: 0x7608824
	internal object .ctor(object settings) { }

	// RVA: 0x7608D1C
	internal object get_isInitialized() { }

	// RVA: 0x760846C
	internal object get_panel() { }

	// RVA: 0x7608C0C
	internal object DisposePanel() { }

	// RVA: 0x7608194
	internal object SetTargetTexture() { }

	// RVA: 0x7608348
	internal object SetSortingPriority() { }

	// RVA: 0x76083D4
	internal object SetTargetDisplay() { }

	// RVA: 0x760A240
	private object CreateRelatedRuntimePanel() { }

	// RVA: 0x760A35C
	private object DisposeRelatedPanel() { }

	// RVA: 0x760A1B0
	internal object MarkPotentiallyEmpty() { }

}

// Namespace: UnityEngine.UIElements
public class PanelSettings
{

	// Fields
	private const object k_DefaultSortingOrder;
	private const object k_DefaultScaleValue;
	internal const object k_DefaultStyleSheetPath;
	private object themeUss; // 0x10
	private object m_TargetTexture; // 0x18
	private object m_ScaleMode; // 0x20
	private object m_ReferenceSpritePixelsPerUnit; // 0x24
	private object m_Scale; // 0x28
	private const object DefaultDpi;
	private object m_ReferenceDpi; // 0x2C
	private object m_FallbackDpi; // 0x30
	private object m_ReferenceResolution; // 0x34
	private object m_ScreenMatchMode; // 0x3C
	private object m_Match; // 0x40
	private object m_SortingOrder; // 0x44
	private object m_TargetDisplay; // 0x48
	private object m_ClearDepthStencil; // 0x4C
	private object m_ClearColor; // 0x4D
	private object m_ColorClearValue; // 0x50
	private object m_PanelAccess; // 0x60
	internal object m_AttachedUIDocumentsList; // 0x68
	private object m_DynamicAtlasSettings; // 0x70
	private object m_AtlasBlitShader; // 0x78
	private object m_RuntimeShader; // 0x80
	private object m_RuntimeWorldShader; // 0x88
	public object textSettings; // 0x90
	private object m_TargetRect; // 0x98
	private object m_ResolvedScale; // 0xA8
	private object m_OldThemeUss; // 0xB0
	private object <ScreenDPI>k__BackingField; // 0xB8
	private object m_AssignedScreenToPanel; // 0xC0

	// Properties
	public object themeStyleSheet { get; set; }
	public object targetTexture { get; set; }
	public object scaleMode { get; set; }
	public object referenceSpritePixelsPerUnit { get; set; }
	public object scale { get; set; }
	public object referenceDpi { get; set; }
	public object fallbackDpi { get; set; }
	public object referenceResolution { get; set; }
	public object screenMatchMode { get; set; }
	public object match { get; set; }
	public object sortingOrder { get; set; }
	public object targetDisplay { get; set; }
	public object clearDepthStencil { get; set; }
	public object depthClearValue { get; }
	public object clearColor { get; set; }
	public object colorClearValue { get; set; }
	internal object panel { get; }
	internal object visualTree { get; }
	public object dynamicAtlasSettings { get; set; }
	private object ScreenDPI { get; set; }

	// Methods

	// RVA: 0x7607F44
	public object get_themeStyleSheet() { }

	// RVA: 0x7607F4C
	public object set_themeStyleSheet(object value) { }

	// RVA: 0x7608140
	public object get_targetTexture() { }

	// RVA: 0x7608148
	public object set_targetTexture(object value) { }

	// RVA: 0x76081C4
	public object get_scaleMode() { }

	// RVA: 0x76081CC
	public object set_scaleMode(object value) { }

	// RVA: 0x76081D4
	public object get_referenceSpritePixelsPerUnit() { }

	// RVA: 0x76081DC
	public object set_referenceSpritePixelsPerUnit(object value) { }

	// RVA: 0x76081E4
	public object get_scale() { }

	// RVA: 0x76081EC
	public object set_scale(object value) { }

	// RVA: 0x76081F4
	public object get_referenceDpi() { }

	// RVA: 0x76081FC
	public object set_referenceDpi(object value) { }

	// RVA: 0x7608230
	public object get_fallbackDpi() { }

	// RVA: 0x7608238
	public object set_fallbackDpi(object value) { }

	// RVA: 0x760826C
	public object get_referenceResolution() { }

	// RVA: 0x7608274
	public object set_referenceResolution(object value) { }

	// RVA: 0x760827C
	public object get_screenMatchMode() { }

	// RVA: 0x7608284
	public object set_screenMatchMode(object value) { }

	// RVA: 0x760828C
	public object get_match() { }

	// RVA: 0x7608294
	public object set_match(object value) { }

	// RVA: 0x760829C
	public object get_sortingOrder() { }

	// RVA: 0x76082A4
	public object set_sortingOrder(object value) { }

	// RVA: 0x76082F8
	internal object ApplySortingOrder() { }

	// RVA: 0x7608380
	public object get_targetDisplay() { }

	// RVA: 0x7608388
	public object set_targetDisplay(object value) { }

	// RVA: 0x7608404
	public object get_clearDepthStencil() { }

	// RVA: 0x760840C
	public object set_clearDepthStencil(object value) { }

	// RVA: 0x7608414
	public object get_depthClearValue() { }

	// RVA: 0x7608424
	public object get_clearColor() { }

	// RVA: 0x760842C
	public object set_clearColor(object value) { }

	// RVA: 0x7608434
	public object get_colorClearValue() { }

	// RVA: 0x7608440
	public object set_colorClearValue(object value) { }

	// RVA: 0x760844C
	internal object get_panel() { }

	// RVA: 0x7608694
	internal object get_visualTree() { }

	// RVA: 0x7608700
	public object get_dynamicAtlasSettings() { }

	// RVA: 0x7608708
	public object set_dynamicAtlasSettings(object value) { }

	// RVA: 0x7608710
	private object .ctor() { }

	// RVA: 0x7608850
	private object Reset() { }

	// RVA: 0x7608854
	private object OnEnable() { }

	// RVA: 0x7608B84
	private object OnDisable() { }

	// RVA: 0x7608C84
	internal object DisposePanel() { }

	// RVA: 0x7608D0C
	private object get_ScreenDPI() { }

	// RVA: 0x7608D14
	private object set_ScreenDPI(object value) { }

	// RVA: 0x7608984
	internal object UpdateScreenDPI() { }

	// RVA: 0x7607F58
	private object ApplyThemeStyleSheet(object root) { }

	// RVA: 0x76089AC
	private object InitializeShaders() { }

	// RVA: 0x7608D2C
	internal object ApplyPanelSettings() { }

	// RVA: 0x76098E4
	public object SetScreenToPanelSpaceFunction(object screentoPanelSpaceFunction) { }

	// RVA: 0x76097EC
	internal object ResolveScale(object targetRect, object screenDpi) { }

	// RVA: 0x7609688
	internal object GetDisplayRect() { }

	// RVA: 0x7609934
	internal object AttachAndInsertUIDocumentToVisualTree(object uiDocument) { }

	// RVA: 0x760A02C
	internal object DetachUIDocument(object uiDocument) { }

}

// Namespace: UnityEngine.UIElements
internal static class RuntimeEventDispatcher
{

	// Methods

	// RVA: 0x760A3EC
	public static object Create() { }

}

// Namespace: UnityEngine.UIElements
internal class RuntimePanel
{

	// Fields
	internal static readonly object s_EventDispatcher; // 0x0
	private readonly object m_PanelSettings; // 0x1E0

	// Properties
	public object panelSettings { get; }

	// Methods

	// RVA: 0x760A964
	public object get_panelSettings() { }

	// RVA: 0x760A96C
	public static object Create(object ownerObject) { }

	// RVA: 0x760A9D0
	private object .ctor(object ownerObject) { }

	// RVA: 0x760ACF8
	public override object Update() { }

	// RVA: 0x760ADC8
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class UIDocumentList
{

	// Fields
	internal object m_AttachedUIDocuments; // 0x8

	// Methods

	// RVA: 0x7609B68
	internal object RemoveFromListAndFromVisualTree(object uiDocument) { }

	// RVA: 0x7609C0C
	internal object AddToListAndToVisualTree(object uiDocument, object visualTree, object firstInsertIndex) { }

	// RVA: 0x7609AE8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public sealed class UIDocument
{

	// Fields
	internal const object k_RootStyleClassName;
	internal const object k_VisualElementNameSuffix;
	private const object k_DefaultSortingOrder;
	private static object s_CurrentUIDocumentCounter; // 0x0
	internal readonly object m_UIDocumentCreationIndex; // 0x18
	private object m_PanelSettings; // 0x20
	private object m_PreviousPanelSettings; // 0x28
	private object m_ParentUI; // 0x30
	private object m_ChildrenContent; // 0x38
	private object m_ChildrenContentCopy; // 0x40
	private object sourceAsset; // 0x48
	private object m_RootVisualElement; // 0x50
	private object m_FirstChildInsertIndex; // 0x58
	private object m_SortingOrder; // 0x5C

	// Properties
	public object panelSettings { get; set; }
	public object parentUI { get; set; }
	public object visualTreeAsset { get; set; }
	public object rootVisualElement { get; }
	internal object firstChildInserIndex { get; }
	public object sortingOrder { get; set; }

	// Methods

	// RVA: 0x760AE58
	public object get_panelSettings() { }

	// RVA: 0x760AE60
	public object set_panelSettings(object value) { }

	// RVA: 0x760B1F0
	public object get_parentUI() { }

	// RVA: 0x760B1F8
	private object set_parentUI(object value) { }

	// RVA: 0x760B200
	public object get_visualTreeAsset() { }

	// RVA: 0x760B208
	public object set_visualTreeAsset(object value) { }

	// RVA: 0x760B6E4
	public object get_rootVisualElement() { }

	// RVA: 0x760B6EC
	internal object get_firstChildInserIndex() { }

	// RVA: 0x760B6F4
	public object get_sortingOrder() { }

	// RVA: 0x760B6FC
	public object set_sortingOrder(object value) { }

	// RVA: 0x760B714
	internal object ApplySortingOrder() { }

	// RVA: 0x760B840
	private object .ctor() { }

	// RVA: 0x760B8BC
	private object Awake() { }

	// RVA: 0x760B990
	private object OnEnable() { }

	// RVA: 0x760B8C0
	private object SetupFromHierarchy() { }

	// RVA: 0x760BAC0
	private object FindUIDocumentParent() { }

	// RVA: 0x760BBC0
	internal object Reset() { }

	// RVA: 0x760BD54
	private object AddChildAndInsertContentToVisualTree(object child) { }

	// RVA: 0x760BAAC
	private object RemoveChild(object child) { }

	// RVA: 0x760B210
	private object RecreateUI() { }

	// RVA: 0x760BF30
	private object SetupRootClassList() { }

	// RVA: 0x760B718
	private object AddRootVisualElementToTree() { }

	// RVA: 0x760BDFC
	private object RemoveFromHierarchy() { }

	// RVA: 0x760BFDC
	private object OnDisable() { }

	// RVA: 0x760C008
	private object OnTransformChildrenChanged() { }

	// RVA: 0x760C384
	private object OnTransformParentChanged() { }

	// RVA: 0x760C218
	internal object ReactToHierarchyChanged() { }

}

// Namespace: UnityEngine.UIElements
internal static class GroupBoxUtility
{

	// Fields
	private static object s_GroupManagers; // 0x0
	private static object s_GroupOptionManagerCache; // 0x8
	private static readonly object k_GenericGroupBoxType; // 0x10

	// Methods

	// RVA: -1
	public static object RegisterGroupBoxOption(object option) { }

	// RVA: -1
	public static object UnregisterGroupBoxOption(object option) { }

	// RVA: -1
	public static object OnOptionSelected(object selectedOption) { }

	// RVA: 0x760C388
	private static object FindOrCreateGroupManager(object groupBox) { }

	// RVA: 0x760CB64
	private static object OnGroupBoxDetachedFromPanel(object evt) { }

	// RVA: 0x760CC5C
	private static object OnPanelDestroyed(object panel) { }

	// RVA: 0x760CE98
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal interface IGroupBoxOption
{

	// Methods

	// RVA: -1
	public abstract object SetSelected(object selected) { }

}

// Namespace: UnityEngine.UIElements
internal interface IGroupBox
{

	// Methods

	// RVA: -1
	public abstract object OnOptionAdded(object option) { }

	// RVA: -1
	public abstract object OnOptionRemoved(object option) { }

}

// Namespace: UnityEngine.UIElements
internal interface IGroupBox<T0>
{
}

// Namespace: UnityEngine.UIElements
internal interface IGroupManager
{

	// Methods

	// RVA: -1
	public abstract object Init(object groupBox) { }

	// RVA: -1
	public abstract object OnOptionSelectionChanged(object selectedOption) { }

	// RVA: -1
	public abstract object RegisterOption(object option) { }

	// RVA: -1
	public abstract object UnregisterOption(object option) { }

}

// Namespace: UnityEngine.UIElements
internal class DefaultGroupManager
{

	// Fields
	private object m_GroupOptions; // 0x8
	private object m_SelectedOption; // 0x10
	private object m_GroupBox; // 0x18

	// Methods

	// RVA: 0x760CFD4
	public object Init(object groupBox) { }

	// RVA: 0x760CFDC
	public object OnOptionSelectionChanged(object selectedOption) { }

	// RVA: 0x760D21C
	public object RegisterOption(object option) { }

	// RVA: 0x760D400
	public object UnregisterOption(object option) { }

	// RVA: 0x760CA30
	public object .ctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7612008
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Methods

	// RVA: 0x7612060
	public object .ctor() { }

}

// Namespace: 
private struct GUIGlobals
{

	// Fields
	public object matrix; // 0xFFFFFFFFFFFFFFF8
	public object color; // 0x38
	public object contentColor; // 0x48
	public object backgroundColor; // 0x58
	public object enabled; // 0x68
	public object changed; // 0x69
	public object displayIndex; // 0x6C
}

// Namespace: UnityEngine.UIElements
public class IMGUIContainer
{

	// Fields
	private object m_OnGUIHandler; // 0x3C0
	private object m_ObjectGUIState; // 0x3C8
	internal object useOwnerObjectGUIState; // 0x3D0
	private object <lastWorldClip>k__BackingField; // 0x3D4
	private object m_CullingEnabled; // 0x3E4
	private object m_IsFocusDelegated; // 0x3E5
	private object m_RefreshCachedLayout; // 0x3E6
	private object m_Cache; // 0x3E8
	private object m_CachedClippingRect; // 0x3F0
	private object m_CachedTransform; // 0x400
	private object <contextType>k__BackingField; // 0x440
	private object lostFocus; // 0x444
	private object receivedFocus; // 0x445
	private object focusChangeDirection; // 0x448
	private object hasFocusableControls; // 0x450
	private object newKeyboardFocusControlID; // 0x454
	private object <focusOnlyIfHasFocusableControls>k__BackingField; // 0x458
	public static readonly object ussClassName; // 0x0
	internal static readonly object ussFoldoutChildDepthClassName; // 0x8
	internal static readonly object ussFoldoutChildDepthClassNames; // 0x10
	private object m_GUIGlobals; // 0x45C
	private static readonly object k_OnGUIMarker; // 0x18
	private static readonly object k_ImmediateCallbackMarker; // 0x20
	private static object s_DefaultMeasureEvent; // 0x28
	private static object s_MeasureEvent; // 0x30
	private static object s_CurrentEvent; // 0x38

	// Properties
	public object onGUIHandler { get; set; }
	internal object guiState { get; }
	internal object lastWorldClip { get; set; }
	public object cullingEnabled { get; }
	private object cache { get; }
	private object layoutMeasuredWidth { get; }
	private object layoutMeasuredHeight { get; }
	public object contextType { get; set; }
	internal object focusOnlyIfHasFocusableControls { get; }
	public override object canGrabFocus { get; }

	// Methods

	// RVA: 0x760D50C
	public object get_onGUIHandler() { }

	// RVA: 0x760D514
	public object set_onGUIHandler(object value) { }

	// RVA: 0x760D570
	internal object get_guiState() { }

	// RVA: 0x760D650
	internal object get_lastWorldClip() { }

	// RVA: 0x760D664
	internal object set_lastWorldClip(object value) { }

	// RVA: 0x760D678
	public object get_cullingEnabled() { }

	// RVA: 0x760D680
	private object get_cache() { }

	// RVA: 0x760D700
	private object get_layoutMeasuredWidth() { }

	// RVA: 0x760D794
	private object get_layoutMeasuredHeight() { }

	// RVA: 0x760D828
	public object get_contextType() { }

	// RVA: 0x760D830
	public object set_contextType(object value) { }

	// RVA: 0x760D838
	internal object get_focusOnlyIfHasFocusableControls() { }

	// RVA: 0x760D840
	public override object get_canGrabFocus() { }

	// RVA: 0x760D868
	private static object .cctor() { }

	// RVA: 0x760DD00
	public object .ctor() { }

	// RVA: 0x760DD08
	public object .ctor(object onGUIHandler) { }

	// RVA: 0x760DFB4
	private object OnGenerateVisualContent(object mgc) { }

	// RVA: 0x760E148
	private object SaveGlobals() { }

	// RVA: 0x760E25C
	private object RestoreGlobals() { }

	// RVA: 0x760E380
	private object DoOnGUI(object evt, object parentTransform, object clippingRect, object isComputingLayout, object layoutSize, object onGUIHandler, object canAffectFocus) { }

	// RVA: 0x760FA94
	public object MarkDirtyLayout() { }

	// RVA: 0x760FAA8
	internal object ProcessEvent(object evt) { }

	// RVA: 0x7610008
	private object DoIMGUIRepaint() { }

	// RVA: 0x760FCD8
	internal object SendEventToIMGUI(object evt, object canAffectFocus, object verifyBounds) { }

	// RVA: 0x7610754
	private object SendEventToIMGUIRaw(object evt, object canAffectFocus, object verifyBounds) { }

	// RVA: 0x7610938
	private object VerifyBounds(object evt) { }

	// RVA: 0x7610AF0
	private object IsContainerCapturingTheMouse() { }

	// RVA: 0x7610C78
	private object IsLocalEvent(object evt) { }

	// RVA: 0x7610F54
	private object IsEventInsideLocalWindow(object evt) { }

	// RVA: 0x761113C
	private static object IsDockAreaMouseUp(object evt) { }

	// RVA: 0x76109EC
	private object HandleIMGUIEvent(object e, object canAffectFocus) { }

	// RVA: 0x761136C
	internal object HandleIMGUIEvent(object e, object onGUIHandler, object canAffectFocus) { }

	// RVA: 0x7610348
	private object HandleIMGUIEvent(object e, object worldTransform, object clippingRect, object onGUIHandler, object canAffectFocus) { }

	// RVA: 0x76116C0
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: 0x7611A64
	private object SetFoldoutDepthClass() { }

	// RVA: 0x7611C1C
	protected internal override object DoMeasure(object desiredWidth, object widthMode, object desiredHeight, object heightMode) { }

	// RVA: 0x7611330
	private object GetCurrentClipRect() { }

	// RVA: 0x7611438
	private static object GetCurrentTransformAndClip(object container, object evt, object transform, object clipRect) { }

	// RVA: 0x7611F48
	public object Dispose() { }

	// RVA: 0x7611FE4
	protected virtual object Dispose(object disposeManaged) { }

	// RVA: 0x7611FFC
	private object <DoOnGUI>b__56_0() { }

}

// Namespace: UnityEngine.UIElements
internal class ImmediateModeException
{

	// Methods

	// RVA: 0x761217C
	public object .ctor(object inner) { }

}

// Namespace: UnityEngine.UIElements
public enum SelectionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Single;
	public const object Multiple;
}

// Namespace: UnityEngine.UIElements
internal interface ISerializableJsonDictionary
{

	// Methods

	// RVA: -1
	public abstract object Set(object key, object value) { }

	// RVA: -1
	public abstract object Get(object key) { }

	// RVA: -1
	public abstract object Overwrite(object obj, object key) { }

	// RVA: -1
	public abstract object ContainsKey(object key) { }

}

// Namespace: UnityEngine.UIElements
public interface ITransform
{

	// Properties
	public abstract object position { get; set; }
	public abstract object scale { get; }

	// Methods

	// RVA: -1
	public abstract object get_position() { }

	// RVA: -1
	public abstract object set_position(object value) { }

	// RVA: -1
	public abstract object get_scale() { }

}

// Namespace: UnityEngine.UIElements
public enum KeyboardNavigationOperation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object SelectAll;
	public const object Cancel;
	public const object Submit;
	public const object Previous;
	public const object Next;
	public const object MoveRight;
	public const object MoveLeft;
	public const object PageUp;
	public const object PageDown;
	public const object Begin;
	public const object End;
}

// Namespace: 
private struct <>c__DisplayClass4_0
{

	// Fields
	public object evt; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.UIElements
public class KeyboardNavigationManipulator
{

	// Fields
	private readonly object m_Action; // 0x10

	// Methods

	// RVA: 0x7612200
	public object .ctor(object action) { }

	// RVA: 0x7612234
	protected override object RegisterCallbacksOnTarget() { }

	// RVA: 0x7612478
	protected override object UnregisterCallbacksFromTarget() { }

	// RVA: 0x76126B4
	internal object OnKeyDown(object evt) { }

	// RVA: 0x7612848
	private object OnNavigationCancel(object evt) { }

	// RVA: 0x761286C
	private object OnNavigationSubmit(object evt) { }

	// RVA: 0x7612890
	private object OnNavigationMove(object evt) { }

	// RVA: 0x761282C
	private object Invoke(object operation, object evt) { }

	// RVA: 0x7612718
	internal static object <OnKeyDown>g__GetOperation|4_0(object ) { }

}

// Namespace: UnityEngine.UIElements
public struct ManipulatorActivationFilter
{

	// Fields
	private object <button>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <modifiers>k__BackingField; // 0xFFFFFFFFFFFFFFFC
	private object <clickCount>k__BackingField; // 0x0

	// Properties
	public object button { get; set; }
	public object modifiers { get; set; }
	public object clickCount { get; }

	// Methods

	// RVA: 0x761294C
	public object get_button() { }

	// RVA: 0x761295C
	public object set_button(object value) { }

	// RVA: 0x761296C
	public object get_modifiers() { }

	// RVA: 0x761297C
	public object set_modifiers(object value) { }

	// RVA: 0x761298C
	public object get_clickCount() { }

	// RVA: 0x761299C
	public override object Equals(object obj) { }

	// RVA: 0x7612A60
	public object Equals(object other) { }

	// RVA: 0x7612B8C
	public override object GetHashCode() { }

	// RVA: 0x7612CA4
	public object Matches(object e) { }

	// RVA: 0x7612E74
	private object HasModifiers(object e) { }

	// RVA: 0x761316C
	public object Matches(object e) { }

	// RVA: 0x761333C
	private object HasModifiers(object e) { }

	// RVA: 0x7613118
	private object MatchModifiers(object alt, object ctrl, object shift, object command) { }

}

// Namespace: UnityEngine.UIElements
public interface IManipulator
{

	// Properties
	public abstract object target { set; }

	// Methods

	// RVA: -1
	public abstract object set_target(object value) { }

}

// Namespace: UnityEngine.UIElements
public abstract class Manipulator
{

	// Fields
	private object m_Target; // 0x8

	// Properties
	public object target { get; set; }

	// Methods

	// RVA: -1
	protected abstract object RegisterCallbacksOnTarget() { }

	// RVA: -1
	protected abstract object UnregisterCallbacksFromTarget() { }

	// RVA: 0x7612470
	public object get_target() { }

	// RVA: 0x7613634
	public object set_target(object value) { }

	// RVA: 0x761222C
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public enum MouseButton
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LeftMouse;
	public const object RightMouse;
	public const object MiddleMouse;
}

// Namespace: UnityEngine.UIElements
public static class MouseCaptureController
{

	// Methods

	// RVA: 0x76115AC
	public static object HasMouseCapture(object handler) { }

	// RVA: 0x7613710
	public static object CaptureMouse(object handler) { }

	// RVA: 0x7613938
	public static object ReleaseMouse(object handler) { }

}

// Namespace: UnityEngine.UIElements
public abstract class MouseManipulator
{

	// Fields
	private object <activators>k__BackingField; // 0x10
	private object m_currentActivator; // 0x18

	// Properties
	public object activators { get; set; }

	// Methods

	// RVA: 0x7613ABC
	public object get_activators() { }

	// RVA: 0x7613AC4
	private object set_activators(object value) { }

	// RVA: 0x7613ACC
	protected object .ctor() { }

	// RVA: 0x7613B50
	protected object CanStartManipulation(object e) { }

	// RVA: 0x7613D28
	protected object CanStopManipulation(object e) { }

}

// Namespace: UnityEngine.UIElements
internal struct MeshWriteDataInterface
{

	// Fields
	public object vertices; // 0xFFFFFFFFFFFFFFF8
	public object indices; // 0x0
	public object vertexCount; // 0x8
	public object indexCount; // 0xC
}

// Namespace: UnityEngine.UIElements
internal static class UIPainter2D
{

	// Methods

	// RVA: 0x7613E10
	public static object Create(object maxArcRadius) { }

	// RVA: 0x7613E64
	public static object Destroy(object handle) { }

	// RVA: 0x7613EB4
	public static object Reset(object handle) { }

}

// Namespace: 
public struct NativeColorPage
{

	// Fields
	public object isValid; // 0xFFFFFFFFFFFFFFF8
	public object pageAndID; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: 
public struct NativeBorderParams
{

	// Fields
	public object rect; // 0xFFFFFFFFFFFFFFF8
	public object leftColor; // 0x8
	public object topColor; // 0x18
	public object rightColor; // 0x28
	public object bottomColor; // 0x38
	public object leftWidth; // 0x48
	public object topWidth; // 0x4C
	public object rightWidth; // 0x50
	public object bottomWidth; // 0x54
	public object topLeftRadius; // 0x58
	public object topRightRadius; // 0x60
	public object bottomRightRadius; // 0x68
	public object bottomLeftRadius; // 0x70
	internal object leftColorPage; // 0x78
	internal object topColorPage; // 0x80
	internal object rightColorPage; // 0x88
	internal object bottomColorPage; // 0x90
}

// Namespace: 
public struct NativeRectParams
{

	// Fields
	public object rect; // 0xFFFFFFFFFFFFFFF8
	public object subRect; // 0x8
	public object uv; // 0x18
	public object uvRegion; // 0x28
	public object color; // 0x38
	public object scaleMode; // 0x48
	public object topLeftRadius; // 0x4C
	public object topRightRadius; // 0x54
	public object bottomRightRadius; // 0x5C
	public object bottomLeftRadius; // 0x64
	public object contentSize; // 0x6C
	public object textureSize; // 0x74
	public object texturePixelsPerPoint; // 0x7C
	public object leftSlice; // 0x80
	public object topSlice; // 0x84
	public object rightSlice; // 0x88
	public object bottomSlice; // 0x8C
	public object sliceScale; // 0x90
	public object colorPage; // 0x94
}

// Namespace: UnityEngine.UIElements
internal static class MeshBuilderNative
{

	// Methods

	// RVA: 0x7613F04
	public static object MakeBorder(object borderParams, object posZ) { }

	// RVA: 0x7614004
	public static object MakeSolidRect(object rectParams, object posZ) { }

	// RVA: 0x7614104
	public static object MakeTexturedRect(object rectParams, object posZ) { }

	// RVA: 0x7614204
	public static object MakeVectorGraphicsStretchBackground(object svgVertices, object svgIndices, object svgWidth, object svgHeight, object targetRect, object sourceUV, object scaleMode, object tint, object colorPage, object settingIndexOffset, object finalVertexCount, object finalIndexCount) { }

	// RVA: 0x76143B8
	public static object MakeVectorGraphics9SliceBackground(object svgVertices, object svgIndices, object svgWidth, object svgHeight, object targetRect, object sliceLTRB, object tint, object colorPage, object settingIndexOffset) { }

	// RVA: 0x7613F8C
	private static object MakeBorder_Injected(object borderParams, object posZ, object ret) { }

	// RVA: 0x761408C
	private static object MakeSolidRect_Injected(object rectParams, object posZ, object ret) { }

	// RVA: 0x761418C
	private static object MakeTexturedRect_Injected(object rectParams, object posZ, object ret) { }

	// RVA: 0x76142EC
	private static object MakeVectorGraphicsStretchBackground_Injected(object svgVertices, object svgIndices, object svgWidth, object svgHeight, object targetRect, object sourceUV, object scaleMode, object tint, object colorPage, object settingIndexOffset, object finalVertexCount, object finalIndexCount, object ret) { }

	// RVA: 0x7614480
	private static object MakeVectorGraphics9SliceBackground_Injected(object svgVertices, object svgIndices, object svgWidth, object svgHeight, object targetRect, object sliceLTRB, object tint, object colorPage, object settingIndexOffset, object ret) { }

}

// Namespace: UnityEngine.UIElements
internal static class UIElementsRuntimeUtilityNative
{

	// Fields
	internal static object RepaintOverlayPanelsCallback; // 0x0
	internal static object UpdateRuntimePanelsCallback; // 0x8
	internal static object RepaintOffscreenPanelsCallback; // 0x10

	// Methods

	// RVA: 0x7614534
	public static object RepaintOverlayPanels() { }

	// RVA: 0x761459C
	public static object UpdateRuntimePanels() { }

	// RVA: 0x7614604
	public static object RepaintOffscreenPanels() { }

	// RVA: 0x761466C
	public static object RegisterPlayerloopCallback() { }

	// RVA: 0x76146AC
	public static object UnregisterPlayerloopCallback() { }

	// RVA: 0x76146EC
	public static object VisualElementCreation() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__6_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.ctor>b__6_0() { }

}

// Namespace: UnityEngine.UIElements
internal class ObjectPool<T0>
{

	// Fields
	private readonly object m_Stack; // 0x0
	private object m_MaxSize; // 0x0
	internal object CreateFunc; // 0x0

	// Properties
	public object maxSize { get; set; }

	// Methods

	// RVA: -1
	public object get_maxSize() { }

	// RVA: -1
	public object set_maxSize(object value) { }

	// RVA: -1
	public object .ctor(object CreateFunc, object maxSize) { }

	// RVA: -1
	public object Size() { }

	// RVA: -1
	public object Get() { }

	// RVA: -1
	public object Release(object element) { }

}

// Namespace: UnityEngine.UIElements
public enum ContextType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Player;
	public const object Editor;
}

// Namespace: UnityEngine.UIElements
internal enum VersionChangeType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Bindings;
	public const object ViewData;
	public const object Hierarchy;
	public const object Layout;
	public const object StyleSheet;
	public const object Styles;
	public const object Overflow;
	public const object BorderRadius;
	public const object BorderWidth;
	public const object Transform;
	public const object Size;
	public const object Repaint;
	public const object Opacity;
	public const object Color;
	public const object RenderHints;
	public const object TransitionProperty;
	public const object EventCallbackCategories;
}

// Namespace: UnityEngine.UIElements
public enum UsageHints
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object DynamicTransform;
	public const object GroupTransform;
	public const object MaskContainer;
	public const object DynamicColor;
}

// Namespace: UnityEngine.UIElements
internal enum RenderHints
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object GroupTransform;
	public const object BoneTransform;
	public const object ClipWithScissors;
	public const object MaskContainer;
	public const object DynamicColor;
	public const object DirtyOffset;
	public const object DirtyGroupTransform;
	public const object DirtyBoneTransform;
	public const object DirtyClipWithScissors;
	public const object DirtyMaskContainer;
	public const object DirtyAll;
}

// Namespace: UnityEngine.UIElements
internal struct PanelClearSettings
{

	// Fields
	public object clearDepthStencil; // 0xFFFFFFFFFFFFFFF8
	public object clearColor; // 0xFFFFFFFFFFFFFFF9
	public object color; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: UnityEngine.UIElements
internal class RepaintData
{

	// Fields
	private object <currentOffset>k__BackingField; // 0x8
	private object <mousePosition>k__BackingField; // 0x48
	private object <currentWorldClip>k__BackingField; // 0x50
	private object <repaintEvent>k__BackingField; // 0x60

	// Properties
	public object currentOffset { get; }
	public object currentWorldClip { get; }
	public object repaintEvent { get; set; }

	// Methods

	// RVA: 0x7614770
	public object get_currentOffset() { }

	// RVA: 0x761478C
	public object get_currentWorldClip() { }

	// RVA: 0x7614798
	public object get_repaintEvent() { }

	// RVA: 0x76147A0
	public object set_repaintEvent(object value) { }

	// RVA: 0x76147A8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal sealed class HierarchyEvent
{

	// Methods

	// RVA: 0x7614B24
	public object .ctor(object object, object method) { }

	// RVA: 0x7614C30
	public virtual object Invoke(object ve, object changeType) { }

}

// Namespace: UnityEngine.UIElements
public interface IPanel
{

	// Properties
	public abstract object visualTree { get; }
	public abstract object dispatcher { get; }
	public abstract object contextType { get; }
	public abstract object focusController { get; }

	// Methods

	// RVA: -1
	public abstract object get_visualTree() { }

	// RVA: -1
	public abstract object get_dispatcher() { }

	// RVA: -1
	public abstract object get_contextType() { }

	// RVA: -1
	public abstract object get_focusController() { }

	// RVA: -1
	public abstract object Pick(object point) { }

}

// Namespace: UnityEngine.UIElements
internal abstract class BaseVisualElementPanel
{

	// Fields
	private object panelDisposed; // 0x8
	private object m_UIElementsBridge; // 0x10
	private object m_Scale; // 0x18
	internal object yogaConfig; // 0x20
	private object m_PixelsPerPoint; // 0x28
	private object <referenceSpritePixelsPerUnit>k__BackingField; // 0x2C
	private object <clearSettings>k__BackingField; // 0x30
	private object <duringLayoutPhase>k__BackingField; // 0x44
	private object <repaintData>k__BackingField; // 0x48
	private object <cursorManager>k__BackingField; // 0x50
	private object <contextualMenuManager>k__BackingField; // 0x58
	private object <disposed>k__BackingField; // 0x60
	internal object m_TopElementUnderPointers; // 0x68
	private object standardShaderChanged; // 0x70
	private object standardWorldSpaceShaderChanged; // 0x78
	private object atlasChanged; // 0x80
	private object updateMaterial; // 0x88
	private object hierarchyChanged; // 0x90
	private object beforeUpdate; // 0x98

	// Properties
	public abstract object IMGUIEventInterests { get; set; }
	public abstract object ownerObject { get; set; }
	public abstract object saveViewData { get; }
	public abstract object getViewDataDictionary { get; }
	public abstract object IMGUIContainersCount { get; set; }
	public abstract object focusController { get; set; }
	public abstract object rootIMGUIContainer { get; }
	internal object uiElementsBridge { get; }
	internal object scale { get; set; }
	internal object pixelsPerPoint { set; }
	public object scaledPixelsPerPoint { get; }
	public object referenceSpritePixelsPerUnit { get; set; }
	internal object clearSettings { get; set; }
	internal object duringLayoutPhase { get; set; }
	internal abstract object version { get; }
	internal abstract object hierarchyVersion { get; }
	internal virtual object repaintData { get; set; }
	internal virtual object cursorManager { get; set; }
	public object contextualMenuManager { get; set; }
	public abstract object visualTree { get; }
	public abstract object dispatcher { get; set; }
	internal abstract object scheduler { get; }
	internal abstract object styleAnimationSystem { get; set; }
	public abstract object contextType { get; set; }
	internal object disposed { get; set; }
	internal abstract object standardShader { get; }
	internal virtual object standardWorldSpaceShader { get; }
	public abstract object atlas { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_IMGUIEventInterests() { }

	// RVA: -1
	public abstract object set_IMGUIEventInterests(object value) { }

	// RVA: -1
	public abstract object get_ownerObject() { }

	// RVA: -1
	protected abstract object set_ownerObject(object value) { }

	// RVA: -1
	public abstract object get_saveViewData() { }

	// RVA: -1
	public abstract object get_getViewDataDictionary() { }

	// RVA: -1
	public abstract object get_IMGUIContainersCount() { }

	// RVA: -1
	public abstract object set_IMGUIContainersCount(object value) { }

	// RVA: -1
	public abstract object get_focusController() { }

	// RVA: -1
	public abstract object set_focusController(object value) { }

	// RVA: -1
	public abstract object get_rootIMGUIContainer() { }

	// RVA: 0x760CAB0
	internal object add_panelDisposed(object value) { }

	// RVA: 0x760CDE4
	internal object remove_panelDisposed(object value) { }

	// RVA: 0x7614C44
	internal object get_uiElementsBridge() { }

	// RVA: 0x7614CA4
	protected object .ctor() { }

	// RVA: 0x7614DE8
	public object Dispose() { }

	// RVA: 0x7614E84
	protected virtual object Dispose(object disposing) { }

	// RVA: -1
	public abstract object Repaint(object e) { }

	// RVA: -1
	public abstract object ValidateFocus() { }

	// RVA: -1
	public abstract object ValidateLayout() { }

	// RVA: -1
	public abstract object UpdateAnimations() { }

	// RVA: -1
	public abstract object UpdateBindings() { }

	// RVA: -1
	public abstract object ApplyStyles() { }

	// RVA: 0x761502C
	internal object get_scale() { }

	// RVA: 0x7615034
	internal object set_scale(object value) { }

	// RVA: 0x76151AC
	internal object set_pixelsPerPoint(object value) { }

	// RVA: 0x761519C
	public object get_scaledPixelsPerPoint() { }

	// RVA: 0x7615314
	public object get_referenceSpritePixelsPerUnit() { }

	// RVA: 0x761531C
	public object set_referenceSpritePixelsPerUnit(object value) { }

	// RVA: 0x7615324
	internal object get_clearSettings() { }

	// RVA: 0x7615338
	internal object set_clearSettings(object value) { }

	// RVA: 0x761534C
	internal object get_duringLayoutPhase() { }

	// RVA: 0x7615354
	internal object set_duringLayoutPhase(object value) { }

	// RVA: -1
	internal abstract object get_version() { }

	// RVA: -1
	internal abstract object get_hierarchyVersion() { }

	// RVA: -1
	internal abstract object OnVersionChanged(object ele, object changeTypeFlag) { }

	// RVA: 0x761535C
	internal virtual object get_repaintData() { }

	// RVA: 0x7615364
	internal virtual object set_repaintData(object value) { }

	// RVA: 0x761536C
	internal virtual object get_cursorManager() { }

	// RVA: 0x7615374
	internal virtual object set_cursorManager(object value) { }

	// RVA: 0x761537C
	public object get_contextualMenuManager() { }

	// RVA: 0x7615384
	internal object set_contextualMenuManager(object value) { }

	// RVA: -1
	public abstract object get_visualTree() { }

	// RVA: -1
	public abstract object get_dispatcher() { }

	// RVA: -1
	public abstract object set_dispatcher(object value) { }

	// RVA: 0x761538C
	internal object SendEvent(object e, object dispatchMode) { }

	// RVA: -1
	internal abstract object get_scheduler() { }

	// RVA: -1
	internal abstract object get_styleAnimationSystem() { }

	// RVA: -1
	internal abstract object set_styleAnimationSystem(object value) { }

	// RVA: -1
	public abstract object get_contextType() { }

	// RVA: -1
	protected abstract object set_contextType(object value) { }

	// RVA: -1
	public abstract object Pick(object point) { }

	// RVA: -1
	public abstract object PickAll(object point, object picked) { }

	// RVA: 0x7615484
	internal object get_disposed() { }

	// RVA: 0x761548C
	private object set_disposed(object value) { }

	// RVA: -1
	internal abstract object GetUpdater(object phase) { }

	// RVA: 0x7615494
	internal object GetTopElementUnderPointer(object pointerId) { }

	// RVA: 0x76154B8
	internal object RecomputeTopElementUnderPointer(object pointerId, object pointerPos, object triggerEvent) { }

	// RVA: 0x761566C
	internal object ClearCachedElementUnderPointer(object pointerId, object triggerEvent) { }

	// RVA: 0x761569C
	internal object CommitElementUnderPointers() { }

	// RVA: -1
	internal abstract object get_standardShader() { }

	// RVA: 0x7615738
	internal virtual object get_standardWorldSpaceShader() { }

	// RVA: 0x7615740
	internal object add_standardShaderChanged(object value) { }

	// RVA: 0x76157E4
	internal object remove_standardShaderChanged(object value) { }

	// RVA: 0x7615888
	internal object add_standardWorldSpaceShaderChanged(object value) { }

	// RVA: 0x761592C
	internal object remove_standardWorldSpaceShaderChanged(object value) { }

	// RVA: 0x76159D0
	internal object add_atlasChanged(object value) { }

	// RVA: 0x7615A74
	internal object remove_atlasChanged(object value) { }

	// RVA: 0x7615B18
	protected object InvokeAtlasChanged() { }

	// RVA: -1
	public abstract object get_atlas() { }

	// RVA: -1
	public abstract object set_atlas(object value) { }

	// RVA: 0x7615B34
	internal object InvokeUpdateMaterial(object mat) { }

	// RVA: 0x7615B50
	internal object add_hierarchyChanged(object value) { }

	// RVA: 0x7615BF4
	internal object remove_hierarchyChanged(object value) { }

	// RVA: 0x7615C98
	internal object InvokeHierarchyChanged(object ve, object changeType) { }

	// RVA: 0x7615CB4
	internal object InvokeBeforeUpdate() { }

	// RVA: 0x7615CD4
	internal object UpdateElementUnderPointers() { }

	// RVA: 0x7615FF4
	private object UnityEngine.UIElements.IGroupBox.OnOptionAdded(object option) { }

	// RVA: 0x7615FF8
	private object UnityEngine.UIElements.IGroupBox.OnOptionRemoved(object option) { }

	// RVA: 0x7615FFC
	public virtual object Update() { }

}

// Namespace: UnityEngine.UIElements
internal sealed class LoadResourceFunction
{

	// Methods

	// RVA: 0x7616258
	public object .ctor(object object, object method) { }

	// RVA: 0x7616308
	public virtual object Invoke(object pathName, object type, object dpiScaling) { }

}

// Namespace: UnityEngine.UIElements
internal sealed class TimeMsFunction
{

	// Methods

	// RVA: 0x7616384
	public object .ctor(object object, object method) { }

	// RVA: 0x7616418
	public virtual object Invoke() { }

}

// Namespace: UnityEngine.UIElements
internal sealed class GetViewDataDictionary
{

	// Methods

	// RVA: 0x761648C
	public object .ctor(object object, object method) { }

	// RVA: 0x7616520
	public virtual object Invoke() { }

}

// Namespace: UnityEngine.UIElements
internal sealed class SavePersistentViewData
{

	// Methods

	// RVA: 0x761658C
	public object .ctor(object object, object method) { }

	// RVA: 0x7616620
	public virtual object Invoke() { }

}

// Namespace: UnityEngine.UIElements
internal class Panel
{

	// Fields
	private object m_RootContainer; // 0xA0
	private object m_VisualTreeUpdater; // 0xA8
	private object m_StylePropertyAnimationSystem; // 0xB0
	private object m_PanelName; // 0xB8
	private object m_Version; // 0xC0
	private object m_RepaintVersion; // 0xC4
	private object m_HierarchyVersion; // 0xC8
	private object m_MarkerBeforeUpdate; // 0xD0
	private object m_MarkerUpdate; // 0xD8
	private object m_MarkerLayout; // 0xE0
	private object m_MarkerBindings; // 0xE8
	private object m_MarkerAnimations; // 0xF0
	private static object s_MarkerPickAll; // 0x0
	private object <dispatcher>k__BackingField; // 0xF8
	private object m_Scheduler; // 0x100
	private object <ownerObject>k__BackingField; // 0x108
	private object <contextType>k__BackingField; // 0x110
	private object <saveViewData>k__BackingField; // 0x118
	private object <getViewDataDictionary>k__BackingField; // 0x120
	private object <focusController>k__BackingField; // 0x128
	private object <IMGUIEventInterests>k__BackingField; // 0x130
	private static object <loadResourceFunc>k__BackingField; // 0x8
	private object m_JustReceivedFocus; // 0x133
	private static object <TimeSinceStartup>k__BackingField; // 0x10
	private object <IMGUIContainersCount>k__BackingField; // 0x134
	private object <rootIMGUIContainer>k__BackingField; // 0x138
	private object m_StandardShader; // 0x140
	private object m_Atlas; // 0x148
	private object m_ValidatingLayout; // 0x150
	private static object beforeAnyRepaint; // 0x18

	// Properties
	public sealed override object visualTree { get; }
	public sealed override object dispatcher { get; set; }
	public object timerEventScheduler { get; }
	internal override object scheduler { get; }
	internal override object styleAnimationSystem { get; set; }
	public override object ownerObject { get; set; }
	public override object contextType { get; set; }
	public override object saveViewData { get; }
	public override object getViewDataDictionary { get; }
	public sealed override object focusController { get; set; }
	public override object IMGUIEventInterests { get; set; }
	private static object loadResourceFunc { get; }
	internal object name { get; set; }
	private static object TimeSinceStartup { get; }
	public override object IMGUIContainersCount { get; set; }
	public override object rootIMGUIContainer { get; }
	internal override object version { get; }
	internal override object hierarchyVersion { get; }
	internal override object standardShader { get; }
	public override object atlas { get; set; }

	// Methods

	// RVA: 0x7616634
	public sealed override object get_visualTree() { }

	// RVA: 0x761663C
	public sealed override object get_dispatcher() { }

	// RVA: 0x7616644
	public sealed override object set_dispatcher(object value) { }

	// RVA: 0x761664C
	public object get_timerEventScheduler() { }

	// RVA: 0x76166C8
	internal override object get_scheduler() { }

	// RVA: 0x7616744
	internal override object get_styleAnimationSystem() { }

	// RVA: 0x761674C
	internal override object set_styleAnimationSystem(object value) { }

	// RVA: 0x761682C
	public override object get_ownerObject() { }

	// RVA: 0x7616834
	protected override object set_ownerObject(object value) { }

	// RVA: 0x761683C
	public override object get_contextType() { }

	// RVA: 0x7616844
	protected override object set_contextType(object value) { }

	// RVA: 0x761684C
	public override object get_saveViewData() { }

	// RVA: 0x7616854
	public override object get_getViewDataDictionary() { }

	// RVA: 0x761685C
	public sealed override object get_focusController() { }

	// RVA: 0x7616864
	public sealed override object set_focusController(object value) { }

	// RVA: 0x761686C
	public override object get_IMGUIEventInterests() { }

	// RVA: 0x761687C
	public override object set_IMGUIEventInterests(object value) { }

	// RVA: 0x761688C
	private static object get_loadResourceFunc() { }

	// RVA: 0x7616908
	internal static object LoadResource(object pathName, object type, object dpiScaling) { }

	// RVA: 0x7616A90
	internal object Focus() { }

	// RVA: 0x7616A9C
	internal object Blur() { }

	// RVA: 0x7616AF8
	public override object ValidateFocus() { }

	// RVA: 0x7616B5C
	internal object get_name() { }

	// RVA: 0x7616B64
	internal object set_name(object value) { }

	// RVA: 0x7616B6C
	private object CreateMarkers() { }

	// RVA: 0x7616DC4
	private static object get_TimeSinceStartup() { }

	// RVA: 0x7616E40
	public override object get_IMGUIContainersCount() { }

	// RVA: 0x7616E48
	public override object set_IMGUIContainersCount(object value) { }

	// RVA: 0x7616E50
	public override object get_rootIMGUIContainer() { }

	// RVA: 0x7616E58
	internal override object get_version() { }

	// RVA: 0x7616E60
	internal override object get_hierarchyVersion() { }

	// RVA: 0x7616E68
	internal override object get_standardShader() { }

	// RVA: 0x7616E70
	public override object get_atlas() { }

	// RVA: 0x7616E78
	public override object set_atlas(object value) { }

	// RVA: 0x7616EF0
	public object .ctor(object ownerObject, object contextType, object dispatcher) { }

	// RVA: 0x76173C0
	protected override object Dispose(object disposing) { }

	// RVA: 0x7617448
	public static object TimeSinceStartupMs() { }

	// RVA: 0x7617558
	internal static object DefaultTimeSinceStartupMs() { }

	// RVA: 0x7617594
	private static object PickAll(object root, object point, object picked, object includeIgnoredElement) { }

	// RVA: 0x7617658
	private static object PerformPick(object root, object point, object picked, object includeIgnoredElement) { }

	// RVA: 0x76179D0
	public override object PickAll(object point, object picked) { }

	// RVA: 0x7617B5C
	public override object Pick(object point) { }

	// RVA: 0x7617F6C
	public override object ValidateLayout() { }

	// RVA: 0x7618020
	public override object UpdateAnimations() { }

	// RVA: 0x7618070
	public override object UpdateBindings() { }

	// RVA: 0x76180C0
	public override object ApplyStyles() { }

	// RVA: 0x76180E8
	private object UpdateForRepaint() { }

	// RVA: 0x76181A0
	public override object Repaint(object e) { }

	// RVA: 0x7618494
	internal override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x76184EC
	internal override object GetUpdater(object phase) { }

	// RVA: 0x7618510
	private static object .cctor() { }

	// RVA: 0x7617EA8
	internal static object <Pick>g__PixelOf|101_0(object p) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7619C44
	private static object .cctor() { }

	// RVA: 0x7619CA4
	public object .ctor() { }

	// RVA: 0x7619CAC
	internal object <.cctor>b__47_0(object p) { }

}

// Namespace: UnityEngine.UIElements
internal abstract class BaseRuntimePanel
{

	// Fields
	private object m_SelectableGameObject; // 0x158
	private static object s_CurrentRuntimePanelCounter; // 0x0
	internal readonly object m_RuntimePanelCreationIndex; // 0x160
	private object m_SortingPriority; // 0x164
	internal object resolvedSortingIndex; // 0x168
	private object destroyed; // 0x170
	private object m_StandardWorldSpaceShader; // 0x178
	private object m_DrawToCameras; // 0x180
	internal object targetTexture; // 0x188
	internal object panelToWorld; // 0x190
	private object <targetDisplay>k__BackingField; // 0x1D0
	internal static readonly object DefaultScreenToPanelSpace; // 0x8
	private object m_ScreenToPanelSpace; // 0x1D8

	// Properties
	public object selectableGameObject { get; set; }
	public object sortingPriority { get; set; }
	internal override object standardWorldSpaceShader { get; }
	internal object drawToCameras { get; set; }
	internal object targetDisplay { get; set; }
	internal object screenRenderingWidth { get; }
	internal object screenRenderingHeight { get; }
	public object screenToPanelSpace { get; set; }

	// Methods

	// RVA: 0x7618590
	public object get_selectableGameObject() { }

	// RVA: 0x7618598
	public object set_selectableGameObject(object value) { }

	// RVA: 0x76189E4
	public object get_sortingPriority() { }

	// RVA: 0x76189EC
	public object set_sortingPriority(object value) { }

	// RVA: 0x7618B28
	public object add_destroyed(object value) { }

	// RVA: 0x7618BCC
	public object remove_destroyed(object value) { }

	// RVA: 0x7618C70
	protected object .ctor(object ownerObject, object dispatcher) { }

	// RVA: 0x7618DA4
	protected override object Dispose(object disposing) { }

	// RVA: 0x7618E58
	internal override object get_standardWorldSpaceShader() { }

	// RVA: 0x7618E60
	internal object get_drawToCameras() { }

	// RVA: 0x7618E68
	internal object set_drawToCameras(object value) { }

	// RVA: 0x7619014
	internal object get_targetDisplay() { }

	// RVA: 0x761901C
	internal object set_targetDisplay(object value) { }

	// RVA: 0x7619024
	internal object get_screenRenderingWidth() { }

	// RVA: 0x7619190
	internal object get_screenRenderingHeight() { }

	// RVA: 0x7619218
	internal static object getScreenRenderingHeight(object display) { }

	// RVA: 0x76190AC
	internal static object getScreenRenderingWidth(object display) { }

	// RVA: 0x76192FC
	public override object Repaint(object e) { }

	// RVA: 0x7619638
	public object get_screenToPanelSpace() { }

	// RVA: 0x7619640
	public object set_screenToPanelSpace(object value) { }

	// RVA: 0x76196DC
	internal object ScreenToPanel(object screen) { }

	// RVA: 0x7619728
	internal object ScreenToPanel(object screenPosition, object screenDelta, object panelPosition, object panelDelta, object allowOutside) { }

	// RVA: 0x761865C
	private object AssignPanelToComponents(object panel) { }

	// RVA: 0x7619968
	internal object PointerLeavesPanel(object pointerId, object position) { }

	// RVA: 0x7619ABC
	internal object PointerEntersPanel(object pointerId, object position) { }

	// RVA: 0x7619B70
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal interface IRuntimePanelComponent
{

	// Properties
	public abstract object panel { set; }

	// Methods

	// RVA: -1
	public abstract object set_panel(object value) { }

}

// Namespace: UnityEngine.UIElements
public static class PointerCaptureHelper
{

	// Methods

	// RVA: 0x7619CB0
	private static object GetStateFor(object handler) { }

	// RVA: 0x76136B4
	public static object HasPointerCapture(object handler, object pointerId) { }

	// RVA: 0x76137FC
	public static object CapturePointer(object handler, object pointerId) { }

	// RVA: 0x7613A50
	public static object ReleasePointer(object handler, object pointerId) { }

	// RVA: 0x7619FD4
	public static object GetCapturingElement(object panel, object pointerId) { }

	// RVA: 0x761A110
	public static object ReleasePointer(object panel, object pointerId) { }

	// RVA: 0x761A274
	internal static object ActivateCompatibilityMouseEvents(object panel, object pointerId) { }

	// RVA: 0x761A3E0
	internal static object PreventCompatibilityMouseEvents(object panel, object pointerId) { }

	// RVA: 0x761A544
	internal static object ShouldSendCompatibilityMouseEvents(object panel, object evt) { }

	// RVA: 0x7613838
	internal static object ProcessPointerCapture(object panel, object pointerId) { }

}

// Namespace: UnityEngine.UIElements
internal class PointerDispatchState
{

	// Fields
	private object m_PendingPointerCapture; // 0x8
	private object m_PointerCapture; // 0x10
	private object m_ShouldSendCompatibilityMouseEvents; // 0x18

	// Methods

	// RVA: 0x761B2AC
	public object .ctor() { }

	// RVA: 0x761B388
	internal object Reset() { }

	// RVA: 0x76112F4
	public object GetCapturingElement(object pointerId) { }

	// RVA: 0x7619E08
	public object HasPointerCapture(object handler, object pointerId) { }

	// RVA: 0x7619E4C
	public object CapturePointer(object handler, object pointerId) { }

	// RVA: 0x761A238
	public object ReleasePointer(object pointerId) { }

	// RVA: 0x7619F84
	public object ReleasePointer(object handler, object pointerId) { }

	// RVA: 0x761A860
	public object ProcessPointerCapture(object pointerId) { }

	// RVA: 0x761A3A0
	public object ActivateCompatibilityMouseEvents(object pointerId) { }

	// RVA: 0x761A508
	public object PreventCompatibilityMouseEvents(object pointerId) { }

	// RVA: 0x761A6AC
	public object ShouldSendCompatibilityMouseEvents(object evt) { }

}

// Namespace: UnityEngine.UIElements
public abstract class PointerManipulator
{

	// Fields
	private object m_CurrentPointerId; // 0x24

	// Methods

	// RVA: 0x761B42C
	protected object CanStartManipulation(object e) { }

	// RVA: 0x761B658
	protected object CanStopManipulation(object e) { }

	// RVA: 0x761B73C
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal static class ProjectionUtils
{

	// Methods

	// RVA: 0x761B7C0
	public static object Ortho(object left, object right, object bottom, object top, object near, object far) { }

}

// Namespace: UnityEngine.UIElements
internal struct SafeHandleAccess
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x761B830
	public object .ctor(object ptr) { }

	// RVA: 0x761B840
	public object IsNull() { }

	// RVA: 0x761B860
	public static object op_Implicit(object a) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x761CD38
	private static object .cctor() { }

	// RVA: 0x761CD98
	public object .ctor() { }

	// RVA: 0x761CDA0
	internal object <.cctor>b__21_0() { }

}

// Namespace: 
private class Row
{

	// Fields
	private static object s_Pool; // 0x0
	private object <offsetX>k__BackingField; // 0x8
	private object <offsetY>k__BackingField; // 0xC
	private object <width>k__BackingField; // 0x10
	private object <height>k__BackingField; // 0x14
	public object Cursor; // 0x18

	// Properties
	public object offsetX { get; set; }
	public object offsetY { get; set; }
	public object width { get; set; }
	private object height { set; }

	// Methods

	// RVA: 0x761CBE4
	public object get_offsetX() { }

	// RVA: 0x761CBEC
	private object set_offsetX(object value) { }

	// RVA: 0x761CBF4
	public object get_offsetY() { }

	// RVA: 0x761CBFC
	private object set_offsetY(object value) { }

	// RVA: 0x761CC04
	public object get_width() { }

	// RVA: 0x761CC0C
	private object set_width(object value) { }

	// RVA: 0x761CC14
	private object set_height(object value) { }

	// RVA: 0x761C9B4
	public static object Acquire(object offsetX, object offsetY, object width, object height) { }

	// RVA: 0x761BB7C
	public object Release() { }

	// RVA: 0x761CC1C
	public object .ctor() { }

	// RVA: 0x761CC24
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x761CF14
	private static object .cctor() { }

	// RVA: 0x761CF74
	public object .ctor() { }

	// RVA: 0x761CF7C
	internal object <.cctor>b__9_0() { }

}

// Namespace: 
private class AreaNode
{

	// Fields
	private static object s_Pool; // 0x0
	public object rect; // 0x8
	public object previous; // 0x18
	public object next; // 0x20

	// Methods

	// RVA: 0x761BFEC
	public static object Acquire(object rect) { }

	// RVA: 0x761BC38
	public object Release() { }

	// RVA: 0x761CA90
	public object RemoveFromChain() { }

	// RVA: 0x761CAAC
	public object AddAfter(object previous) { }

	// RVA: 0x761CDF8
	public object .ctor() { }

	// RVA: 0x761CE00
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class UIRAtlasAllocator
{

	// Fields
	private readonly object <maxAtlasSize>k__BackingField; // 0x8
	private readonly object <maxImageWidth>k__BackingField; // 0xC
	private readonly object <maxImageHeight>k__BackingField; // 0x10
	private object <virtualWidth>k__BackingField; // 0x14
	private object <virtualHeight>k__BackingField; // 0x18
	private object <physicalWidth>k__BackingField; // 0x1C
	private object <physicalHeight>k__BackingField; // 0x20
	private object m_FirstUnpartitionedArea; // 0x28
	private object m_OpenRows; // 0x30
	private object m_1SidePadding; // 0x38
	private object m_2SidePadding; // 0x3C
	private static object s_MarkerTryAllocate; // 0x0
	private object <disposed>k__BackingField; // 0x40

	// Properties
	public object maxAtlasSize { get; }
	public object maxImageWidth { get; }
	public object maxImageHeight { get; }
	public object virtualWidth { get; set; }
	public object virtualHeight { get; set; }
	public object physicalWidth { get; set; }
	public object physicalHeight { get; set; }
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x761B8C4
	public object get_maxAtlasSize() { }

	// RVA: 0x761B8CC
	public object get_maxImageWidth() { }

	// RVA: 0x761B8D4
	public object get_maxImageHeight() { }

	// RVA: 0x761B8DC
	public object get_virtualWidth() { }

	// RVA: 0x761B8E4
	private object set_virtualWidth(object value) { }

	// RVA: 0x761B8EC
	public object get_virtualHeight() { }

	// RVA: 0x761B8F4
	private object set_virtualHeight(object value) { }

	// RVA: 0x761B8FC
	public object get_physicalWidth() { }

	// RVA: 0x761B904
	private object set_physicalWidth(object value) { }

	// RVA: 0x761B90C
	public object get_physicalHeight() { }

	// RVA: 0x761B914
	private object set_physicalHeight(object value) { }

	// RVA: 0x761B91C
	protected object get_disposed() { }

	// RVA: 0x761B924
	private object set_disposed(object value) { }

	// RVA: 0x761B92C
	public object Dispose() { }

	// RVA: 0x761B9C4
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x761BCE4
	private static object GetLog2OfNextPower(object n) { }

	// RVA: 0x761BE54
	public object .ctor(object initialAtlasSize, object maxAtlasSize, object sidePadding) { }

	// RVA: 0x761C2C8
	public object TryAllocate(object width, object height, object location) { }

	// RVA: 0x761C6FC
	private object TryPartitionArea(object areaNode, object rowIndex, object rowHeight, object minWidth) { }

	// RVA: 0x761C0B4
	private object BuildAreas() { }

	// RVA: 0x761CB64
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class DynamicAtlasPage
{

	// Fields
	private object <textureId>k__BackingField; // 0x8
	private object <atlas>k__BackingField; // 0x10
	private readonly object <format>k__BackingField; // 0x18
	private readonly object <filterMode>k__BackingField; // 0x1C
	private readonly object <minSize>k__BackingField; // 0x20
	private readonly object <maxSize>k__BackingField; // 0x28
	private readonly object m_1Padding; // 0x30
	private readonly object m_2Padding; // 0x34
	private object m_Allocator; // 0x38
	private object m_Blitter; // 0x40
	private object m_CurrentSize; // 0x48
	private static object s_TextureCounter; // 0x0
	private object <disposed>k__BackingField; // 0x50

	// Properties
	public object textureId { get; set; }
	public object atlas { get; set; }
	public object format { get; }
	public object filterMode { get; }
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x761CFD4
	public object get_textureId() { }

	// RVA: 0x761CFDC
	private object set_textureId(object value) { }

	// RVA: 0x761CFE4
	public object get_atlas() { }

	// RVA: 0x761CFEC
	private object set_atlas(object value) { }

	// RVA: 0x761CFF4
	public object get_format() { }

	// RVA: 0x761CFFC
	public object get_filterMode() { }

	// RVA: 0x761D004
	public object .ctor(object format, object filterMode, object minSize, object maxSize) { }

	// RVA: 0x761D188
	protected object get_disposed() { }

	// RVA: 0x761D190
	private object set_disposed(object value) { }

	// RVA: 0x761D198
	public object Dispose() { }

	// RVA: 0x761D230
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x761D48C
	public object TryAdd(object image, object alloc, object rect) { }

	// RVA: 0x761D7C8
	public object Update(object image, object rect) { }

	// RVA: 0x761D954
	public object Remove(object alloc) { }

	// RVA: 0x761DA4C
	public object Commit() { }

	// RVA: 0x761DAA4
	private object UpdateAtlasTexture() { }

	// RVA: 0x761DF48
	private object CreateAtlasTexture() { }

}

// Namespace: UnityEngine.UIElements
internal class UIRLayoutUpdater
{

	// Fields
	private static readonly object s_Description; // 0x0
	private static readonly object s_ProfilerMarker; // 0x8
	private object changeEventsList; // 0x18

	// Properties
	public override object profilerMarker { get; }

	// Methods

	// RVA: 0x761E084
	public override object get_profilerMarker() { }

	// RVA: 0x761E100
	public override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x761E174
	public override object Update() { }

	// RVA: 0x761E51C
	private object UpdateSubTree(object ve, object isDisplayed, object changeEvents) { }

	// RVA: 0x761EDF8
	private object DispatchChangeEvents(object changeEvents, object currentLayoutPass) { }

	// RVA: 0x761F188
	public object .ctor() { }

	// RVA: 0x761F208
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public struct Vertex
{

	// Fields
	public static readonly object nearZ; // 0x0
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object tint; // 0x4
	public object uv; // 0x8
	internal object xformClipPages; // 0x10
	internal object ids; // 0x14
	internal object flags; // 0x18
	internal object opacityColorPages; // 0x1C
	internal object settingIndex; // 0x20
	internal object circle; // 0x24
	internal object textureId; // 0x34
}

// Namespace: UnityEngine.UIElements
public class MeshWriteData
{

	// Fields
	internal object m_Vertices; // 0x8
	internal object m_Indices; // 0x18
	internal object m_UVRegion; // 0x28
	internal object currentIndex; // 0x38
	internal object currentVertex; // 0x3C

	// Properties
	public object vertexCount { get; }
	public object indexCount { get; }
	public object uvRegion { get; }

	// Methods

	// RVA: 0x761F294
	internal object .ctor() { }

	// RVA: 0x761F29C
	public object get_vertexCount() { }

	// RVA: 0x761F2F0
	public object get_indexCount() { }

	// RVA: 0x761F344
	public object get_uvRegion() { }

	// RVA: 0x761F350
	public object SetNextVertex(object vertex) { }

	// RVA: 0x761F3D4
	public object SetNextIndex(object index) { }

	// RVA: 0x761F43C
	public object SetAllVertices(object vertices) { }

	// RVA: 0x761F510
	public object SetAllIndices(object indices) { }

	// RVA: 0x761F5E4
	internal object Reset(object vertices, object indices) { }

	// RVA: 0x761F600
	internal object Reset(object vertices, object indices, object uvRegion) { }

}

// Namespace: UnityEngine.UIElements
internal struct ColorPage
{

	// Fields
	public object isValid; // 0xFFFFFFFFFFFFFFF8
	public object pageAndID; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x761F64C
	public static object Init(object renderChain, object alloc) { }

	// RVA: 0x761F748
	public object ToNativeColorPage() { }

}

// Namespace: 
public struct BorderParams
{

	// Fields
	public object rect; // 0xFFFFFFFFFFFFFFF8
	public object playmodeTintColor; // 0x8
	public object leftColor; // 0x18
	public object topColor; // 0x28
	public object rightColor; // 0x38
	public object bottomColor; // 0x48
	public object leftWidth; // 0x58
	public object topWidth; // 0x5C
	public object rightWidth; // 0x60
	public object bottomWidth; // 0x64
	public object topLeftRadius; // 0x68
	public object topRightRadius; // 0x70
	public object bottomRightRadius; // 0x78
	public object bottomLeftRadius; // 0x80
	public object material; // 0x88
	internal object leftColorPage; // 0x90
	internal object topColorPage; // 0x98
	internal object rightColorPage; // 0xA0
	internal object bottomColorPage; // 0xA8

	// Methods

	// RVA: 0x7620290
	internal object ToNativeParams() { }

}

// Namespace: 
public struct RectangleParams
{

	// Fields
	public object rect; // 0xFFFFFFFFFFFFFFF8
	public object uv; // 0x8
	public object color; // 0x18
	public object subRect; // 0x28
	public object backgroundPositionX; // 0x38
	public object backgroundPositionY; // 0x44
	public object backgroundRepeat; // 0x50
	public object backgroundSize; // 0x58
	public object texture; // 0x70
	public object sprite; // 0x78
	public object vectorImage; // 0x80
	public object material; // 0x88
	public object scaleMode; // 0x90
	public object playmodeTintColor; // 0x94
	public object topLeftRadius; // 0xA4
	public object topRightRadius; // 0xAC
	public object bottomRightRadius; // 0xB4
	public object bottomLeftRadius; // 0xBC
	public object contentSize; // 0xC4
	public object textureSize; // 0xCC
	public object leftSlice; // 0xD4
	public object topSlice; // 0xD8
	public object rightSlice; // 0xDC
	public object bottomSlice; // 0xE0
	public object sliceScale; // 0xE4
	internal object spriteGeomRect; // 0xE8
	internal object colorPage; // 0xF8
	internal object meshFlags; // 0x100

	// Methods

	// RVA: 0x76203C0
	private static object AdjustUVsForScaleMode(object rect, object uv, object texture, object scaleMode, object rectOut, object uvOut) { }

	// RVA: 0x762059C
	private static object AdjustSpriteUVsForScaleMode(object containerRect, object srcRect, object spriteGeomRect, object sprite, object scaleMode, object rectOut, object uvOut) { }

	// RVA: 0x76208E0
	internal static object RectIntersection(object a, object b) { }

	// RVA: 0x76209BC
	private static object ComputeGeomRect(object sprite) { }

	// RVA: 0x7620A80
	private static object ComputeUVRect(object sprite) { }

	// RVA: 0x7620B44
	private static object ApplyPackingRotation(object uv, object rotation) { }

	// RVA: 0x7620B9C
	public static object MakeTextured(object rect, object uv, object texture, object scaleMode, object panelContext) { }

	// RVA: 0x7620DD0
	public static object MakeSprite(object containerRect, object subRect, object sprite, object scaleMode, object panelContext, object hasRadius, object slices, object useForRepeat) { }

	// RVA: 0x76218D8
	public static object MakeVectorTextured(object rect, object uv, object vectorImage, object scaleMode, object panelContext) { }

	// RVA: 0x7621A3C
	internal object HasRadius(object epsilon) { }

	// RVA: 0x7621B24
	internal object HasSlices(object epsilon) { }

	// RVA: 0x7621BBC
	internal object ToNativeParams(object uvRegion) { }

}

// Namespace: UnityEngine.UIElements
internal static class MeshGenerationContextUtils
{

	// Methods

	// RVA: 0x761F768
	public static object Rectangle(object mgc, object rectParams) { }

	// RVA: 0x761F884
	public static object Text(object mgc, object te) { }

	// RVA: 0x761F988
	private static object ConvertBorderRadiusPercentToPoints(object borderRectSize, object length) { }

	// RVA: 0x761F9C4
	public static object GetVisualElementRadii(object ve, object topLeft, object bottomLeft, object topRight, object bottomRight) { }

	// RVA: 0x761FC98
	public static object AdjustBackgroundSizeForBorders(object visualElement, object rect) { }

}

// Namespace: 
internal enum MeshFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object UVisDisplacement;
	public const object SkipDynamicAtlas;
}

// Namespace: UnityEngine.UIElements
public class MeshGenerationContext
{

	// Fields
	private object m_Painter2D; // 0x8
	private static readonly object s_AllocateMarker; // 0x0
	private static readonly object s_DrawVectorImageMarker; // 0x8
	internal object painter; // 0x10

	// Properties
	public object painter2D { get; }
	internal object hasPainter2D { get; }

	// Methods

	// RVA: 0x7621CAC
	public object get_painter2D() { }

	// RVA: 0x7621E00
	internal object get_hasPainter2D() { }

	// RVA: 0x7621E10
	internal object .ctor(object painter) { }

	// RVA: 0x7621E3C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public class Painter2D
{

	// Fields
	private object m_Ctx; // 0x8
	internal object m_DetachedAllocator; // 0x10
	internal object m_Handle; // 0x18
	private object m_Disposed; // 0x20
	private static object <isPainterActive>k__BackingField; // 0x0
	private static object s_MaxArcRadius; // 0x4
	private static readonly object s_StrokeMarker; // 0x8
	private static readonly object s_FillMarker; // 0x10

	// Properties
	internal static object isPainterActive { set; }
	private static object maxArcRadius { get; }

	// Methods

	// RVA: 0x7621D28
	internal object .ctor(object ctx) { }

	// RVA: 0x7622030
	internal object Reset() { }

	// RVA: 0x76220C8
	public object Dispose() { }

	// RVA: 0x7622168
	private object Dispose(object disposing) { }

	// RVA: 0x762223C
	internal static object set_isPainterActive(object value) { }

	// RVA: 0x7621EF4
	private static object get_maxArcRadius() { }

	// RVA: 0x76222C8
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class UIRRepaintUpdater
{

	// Fields
	private object attachedPanel; // 0x18
	internal object renderChain; // 0x20
	private static readonly object s_Description; // 0x0
	private static readonly object s_ProfilerMarker; // 0x8
	private object <drawStats>k__BackingField; // 0x28
	private object <breakBatches>k__BackingField; // 0x29
	private object <disposed>k__BackingField; // 0x2A

	// Properties
	public override object profilerMarker { get; }
	public object drawStats { get; }
	public object breakBatches { get; }
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x7622390
	public object .ctor() { }

	// RVA: 0x7622424
	public override object get_profilerMarker() { }

	// RVA: 0x76224A0
	public object get_drawStats() { }

	// RVA: 0x76224A8
	public object get_breakBatches() { }

	// RVA: 0x76224B0
	public override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x76225E4
	public override object Update() { }

	// RVA: 0x7622820
	protected virtual object CreateRenderChain() { }

	// RVA: 0x762289C
	private static object .cctor() { }

	// RVA: 0x76229A0
	private static object OnGraphicsResourcesRecreate(object recreate) { }

	// RVA: 0x7622C8C
	private object OnPanelChanged(object obj) { }

	// RVA: 0x7623060
	private object AttachToPanel() { }

	// RVA: 0x7622CB0
	private object DetachFromPanel() { }

	// RVA: 0x76226D0
	private object InitRenderChain() { }

	// RVA: 0x7618F94
	internal object DestroyRenderChain() { }

	// RVA: 0x76238AC
	private object OnPanelAtlasChanged() { }

	// RVA: 0x762392C
	private object OnPanelHierarchyChanged(object ve, object changeType) { }

	// RVA: 0x7623400
	private object OnPanelStandardShaderChanged() { }

	// RVA: 0x76235F8
	private object OnPanelStandardWorldSpaceShaderChanged() { }

	// RVA: 0x76237F0
	private object ResetAllElementsDataRecursive(object ve) { }

	// RVA: 0x7623964
	protected object get_disposed() { }

	// RVA: 0x762396C
	private object set_disposed(object value) { }

	// RVA: 0x7623974
	protected override object Dispose(object disposing) { }

}

// Namespace: UnityEngine.UIElements
internal struct TextureId
{

	// Fields
	private readonly object m_Index; // 0xFFFFFFFFFFFFFFF8
	public static readonly object invalid; // 0x0

	// Properties
	public object index { get; }

	// Methods

	// RVA: 0x7643264
	public object .ctor(object index) { }

	// RVA: 0x764327C
	public object get_index() { }

	// RVA: 0x7643294
	public object ConvertToGpu() { }

	// RVA: 0x7643364
	public override object Equals(object obj) { }

	// RVA: 0x76434DC
	public override object GetHashCode() { }

	// RVA: 0x76434F0
	public static object op_Equality(object left, object right) { }

	// RVA: 0x76434FC
	public static object op_Inequality(object left, object right) { }

	// RVA: 0x7643588
	private static object .cctor() { }

}

// Namespace: 
private struct TextureInfo
{

	// Fields
	public object texture; // 0xFFFFFFFFFFFFFFF8
	public object dynamic; // 0x0
	public object refCount; // 0x4
}

// Namespace: UnityEngine.UIElements
internal class TextureRegistry
{

	// Fields
	private object m_Textures; // 0x8
	private object m_TextureToId; // 0x10
	private object m_FreeIds; // 0x18
	internal const object maxTextures;
	private static readonly object <instance>k__BackingField; // 0x0

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: 0x76435D4
	public static object get_instance() { }

	// RVA: 0x7643650
	public object GetTexture(object id) { }

	// RVA: 0x7643868
	public object AllocAndAcquireDynamic() { }

	// RVA: 0x7643BA8
	public object UpdateDynamic(object id, object texture) { }

	// RVA: 0x7643874
	private object AllocAndAcquire(object texture, object dynamic) { }

	// RVA: 0x7643E74
	public object Acquire(object tex) { }

	// RVA: 0x7644014
	public object Release(object id) { }

	// RVA: 0x764431C
	public object .ctor() { }

	// RVA: 0x7644434
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal static class UIRUtility
{

	// Fields
	public static readonly object k_DefaultShaderName; // 0x0
	public static readonly object k_DefaultWorldSpaceShaderName; // 0x8

	// Methods

	// RVA: 0x76444CC
	public static object ShapeWindingIsClockwise(object maskDepth, object stencilRef) { }

	// RVA: 0x764454C
	public static object IsRoundRect(object ve) { }

	// RVA: 0x76447E0
	public static object IsVectorImageBackground(object ve) { }

	// RVA: 0x7644880
	public static object IsElementSelfHidden(object ve) { }

	// RVA: 0x7644958
	public static object Destroy(object obj) { }

	// RVA: 0x7644AAC
	public static object GetPrevPow2(object n) { }

	// RVA: 0x7644AEC
	public static object GetNextPow2(object n) { }

	// RVA: 0x7644B08
	public static object GetNextPow2Exp(object n) { }

	// RVA: 0x7644B38
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public struct TimerState
{

	// Fields
	private object <start>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <now>k__BackingField; // 0x0

	// Properties
	public object start { get; set; }
	public object now { get; set; }
	public object deltaTime { get; }

	// Methods

	// RVA: 0x7644BB4
	public object get_start() { }

	// RVA: 0x7644BC4
	public object set_start(object value) { }

	// RVA: 0x7644BD4
	public object get_now() { }

	// RVA: 0x7644BE4
	public object set_now(object value) { }

	// RVA: 0x7644BF4
	public object get_deltaTime() { }

	// RVA: 0x7644C0C
	public override object Equals(object obj) { }

	// RVA: 0x7644CC0
	public object Equals(object other) { }

	// RVA: 0x7644DBC
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal interface IScheduler
{

	// Methods

	// RVA: -1
	public abstract object Unschedule(object item) { }

	// RVA: -1
	public abstract object Schedule(object item) { }

	// RVA: -1
	public abstract object UpdateScheduledEvents() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x76451AC
	private static object .cctor() { }

	// RVA: 0x764520C
	public object .ctor() { }

	// RVA: 0x7645214
	internal object <.cctor>b__25_0() { }

	// RVA: 0x764521C
	internal object <.cctor>b__25_1() { }

}

// Namespace: UnityEngine.UIElements
internal abstract class ScheduledItem
{

	// Fields
	public object timerUpdateStopCondition; // 0x8
	public static readonly object OnceCondition; // 0x0
	public static readonly object ForeverCondition; // 0x8
	private object <startMs>k__BackingField; // 0x10
	private object <delayMs>k__BackingField; // 0x18
	private object <intervalMs>k__BackingField; // 0x20
	private object <endTimeMs>k__BackingField; // 0x28

	// Properties
	public object startMs { get; set; }
	public object delayMs { get; set; }
	public object intervalMs { get; set; }
	public object endTimeMs { get; }

	// Methods

	// RVA: 0x7644EDC
	public object get_startMs() { }

	// RVA: 0x7644EE4
	public object set_startMs(object value) { }

	// RVA: 0x7644EEC
	public object get_delayMs() { }

	// RVA: 0x7644EF4
	public object set_delayMs(object value) { }

	// RVA: 0x7644EFC
	public object get_intervalMs() { }

	// RVA: 0x7644F04
	public object set_intervalMs(object value) { }

	// RVA: 0x7644F0C
	public object get_endTimeMs() { }

	// RVA: 0x7644F14
	public object .ctor() { }

	// RVA: 0x7645000
	protected object ResetStartTime() { }

	// RVA: -1
	public abstract object PerformTimerUpdate(object state) { }

	// RVA: 0x7645068
	internal virtual object OnItemUnscheduled() { }

	// RVA: 0x764506C
	public virtual object ShouldUnschedule() { }

	// RVA: 0x764508C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class TimerEventScheduler
{

	// Fields
	private readonly object m_ScheduledItems; // 0x8
	private object m_TransactionMode; // 0x10
	private readonly object m_ScheduleTransactions; // 0x18
	private readonly object m_UnscheduleTransactions; // 0x20
	internal object disableThrottling; // 0x28
	private object m_LastUpdatedIndex; // 0x2C

	// Methods

	// RVA: 0x7645224
	public object Schedule(object item) { }

	// RVA: 0x76454DC
	private object RemovedScheduledItemAt(object index) { }

	// RVA: 0x764556C
	public object Unschedule(object item) { }

	// RVA: 0x764574C
	private object PrivateUnSchedule(object sItem) { }

	// RVA: 0x7645870
	public object UpdateScheduledEvents() { }

	// RVA: 0x7645E4C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal struct Spacing
{

	// Fields
	public object left; // 0xFFFFFFFFFFFFFFF8
	public object top; // 0xFFFFFFFFFFFFFFFC
	public object right; // 0x0
	public object bottom; // 0x4

	// Properties
	public object horizontal { get; }
	public object vertical { get; }

	// Methods

	// RVA: 0x7645F38
	public object get_horizontal() { }

	// RVA: 0x7645F58
	public object get_vertical() { }

	// RVA: 0x7645F78
	public object .ctor(object left, object top, object right, object bottom) { }

	// RVA: 0x7645F90
	public static object op_Subtraction(object r, object a) { }

}

// Namespace: UnityEngine.UIElements
public enum AngleUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Degree;
	public const object Gradian;
	public const object Radian;
	public const object Turn;
}

// Namespace: 
private enum Unit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Degree;
	public const object Gradian;
	public const object Radian;
	public const object Turn;
	public const object None;
}

// Namespace: UnityEngine.UIElements
public struct Angle
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Unit; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object value { get; }

	// Methods

	// RVA: 0x7645FC0
	internal static object None() { }

	// RVA: 0x7645FD4
	public object get_value() { }

	// RVA: 0x7645FE4
	public object .ctor(object value, object unit) { }

	// RVA: 0x7645FC8
	private object .ctor(object value, object unit) { }

	// RVA: 0x7646008
	public object ToDegrees() { }

	// RVA: 0x7646120
	public static object op_Implicit(object value) { }

	// RVA: 0x7646128
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7646148
	public object Equals(object other) { }

	// RVA: 0x7646190
	public override object Equals(object obj) { }

	// RVA: 0x7646310
	public override object GetHashCode() { }

	// RVA: 0x764637C
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct Background
{

	// Fields
	private object m_Texture; // 0xFFFFFFFFFFFFFFF8
	private object m_Sprite; // 0x0
	private object m_RenderTexture; // 0x8
	private object m_VectorImage; // 0x10

	// Properties
	public object texture { get; set; }
	public object sprite { get; set; }
	public object renderTexture { get; set; }
	public object vectorImage { get; set; }

	// Methods

	// RVA: 0x76465FC
	public object get_texture() { }

	// RVA: 0x764660C
	public object set_texture(object value) { }

	// RVA: 0x7646774
	public object get_sprite() { }

	// RVA: 0x7646784
	public object set_sprite(object value) { }

	// RVA: 0x76468EC
	public object get_renderTexture() { }

	// RVA: 0x76468FC
	public object set_renderTexture(object value) { }

	// RVA: 0x7644878
	public object get_vectorImage() { }

	// RVA: 0x7646A6C
	public object set_vectorImage(object value) { }

	// RVA: 0x7646BD4
	public static object FromTexture2D(object t) { }

	// RVA: 0x7646CA4
	public static object FromRenderTexture(object rt) { }

	// RVA: 0x7646D64
	public static object FromSprite(object s) { }

	// RVA: 0x7646E24
	public static object FromVectorImage(object vi) { }

	// RVA: 0x7646EF0
	internal static object FromObject(object obj) { }

	// RVA: 0x76472D8
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7647448
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7647480
	public object Equals(object other) { }

	// RVA: 0x76474EC
	public override object Equals(object obj) { }

	// RVA: 0x7647668
	public override object GetHashCode() { }

	// RVA: 0x7647784
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
internal struct ComputedStyle
{

	// Fields
	public object inheritedData; // 0xFFFFFFFFFFFFFFF8
	public object layoutData; // 0x0
	public object rareData; // 0x8
	public object transformData; // 0x10
	public object transitionData; // 0x18
	public object visualData; // 0x20
	public object yogaNode; // 0x28
	public object customProperties; // 0x30
	public object matchingRulesHash; // 0x38
	public object dpiScaling; // 0x40
	public object computedTransitions; // 0x48

	// Properties
	public object customPropertiesCount { get; }
	public object hasTransition { get; }
	public object alignContent { get; }
	public object alignItems { get; }
	public object alignSelf { get; }
	public object backgroundColor { get; }
	public object backgroundImage { get; }
	public object backgroundPositionX { get; }
	public object backgroundPositionY { get; }
	public object backgroundRepeat { get; }
	public object backgroundSize { get; }
	public object borderBottomColor { get; }
	public object borderBottomLeftRadius { get; }
	public object borderBottomRightRadius { get; }
	public object borderBottomWidth { get; }
	public object borderLeftColor { get; }
	public object borderLeftWidth { get; }
	public object borderRightColor { get; }
	public object borderRightWidth { get; }
	public object borderTopColor { get; }
	public object borderTopLeftRadius { get; }
	public object borderTopRightRadius { get; }
	public object borderTopWidth { get; }
	public object bottom { get; }
	public object color { get; }
	public object cursor { get; }
	public object display { get; }
	public object flexBasis { get; }
	public object flexDirection { get; }
	public object flexGrow { get; }
	public object flexShrink { get; }
	public object flexWrap { get; }
	public object fontSize { get; }
	public object height { get; }
	public object justifyContent { get; }
	public object left { get; }
	public object letterSpacing { get; }
	public object marginBottom { get; }
	public object marginLeft { get; }
	public object marginRight { get; }
	public object marginTop { get; }
	public object maxHeight { get; }
	public object maxWidth { get; }
	public object minHeight { get; }
	public object minWidth { get; }
	public object opacity { get; }
	public object overflow { get; }
	public object paddingBottom { get; }
	public object paddingLeft { get; }
	public object paddingRight { get; }
	public object paddingTop { get; }
	public object position { get; }
	public object right { get; }
	public object rotate { get; }
	public object scale { get; }
	public object textOverflow { get; }
	public object textShadow { get; }
	public object top { get; }
	public object transformOrigin { get; }
	public object transitionDelay { get; }
	public object transitionDuration { get; }
	public object transitionProperty { get; }
	public object transitionTimingFunction { get; }
	public object translate { get; }
	public object unityBackgroundImageTintColor { get; }
	public object unityFont { get; }
	public object unityFontDefinition { get; }
	public object unityFontStyleAndWeight { get; }
	public object unityOverflowClipBox { get; }
	public object unityParagraphSpacing { get; }
	public object unitySliceBottom { get; }
	public object unitySliceLeft { get; }
	public object unitySliceRight { get; }
	public object unitySliceScale { get; }
	public object unitySliceTop { get; }
	public object unityTextAlign { get; }
	public object unityTextOutlineColor { get; }
	public object unityTextOutlineWidth { get; }
	public object unityTextOverflowPosition { get; }
	public object visibility { get; }
	public object whiteSpace { get; }
	public object width { get; }
	public object wordSpacing { get; }

	// Methods

	// RVA: 0x76239E8
	public object get_customPropertiesCount() { }

	// RVA: 0x7623AA0
	public object get_hasTransition() { }

	// RVA: 0x7623AE0
	public object FinalizeApply(object parentStyle) { }

	// RVA: 0x7623CF8
	public object SyncWithLayout(object targetNode) { }

	// RVA: 0x762527C
	private object ApplyGlobalKeyword(object reader, object parentStyle) { }

	// RVA: 0x7625460
	private object ApplyGlobalKeyword(object id, object keyword, object parentStyle) { }

	// RVA: 0x76277B0
	private object RemoveCustomStyleProperty(object reader) { }

	// RVA: 0x7627890
	private object ApplyCustomStyleProperty(object reader) { }

	// RVA: 0x76279A8
	private object ApplyAllPropertyInitial() { }

	// RVA: 0x7627BCC
	private object ResetComputedTransitions() { }

	// RVA: 0x7627BDC
	public static object StartAnimationInlineTranslate(object element, object computedStyle, object translate, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76250A8
	public object get_alignContent() { }

	// RVA: 0x7625104
	public object get_alignItems() { }

	// RVA: 0x7624E80
	public object get_alignSelf() { }

	// RVA: 0x7628034
	public object get_backgroundColor() { }

	// RVA: 0x76280F4
	public object get_backgroundImage() { }

	// RVA: 0x76281BC
	public object get_backgroundPositionX() { }

	// RVA: 0x7628284
	public object get_backgroundPositionY() { }

	// RVA: 0x762834C
	public object get_backgroundRepeat() { }

	// RVA: 0x7628404
	public object get_backgroundSize() { }

	// RVA: 0x76284DC
	public object get_borderBottomColor() { }

	// RVA: 0x762859C
	public object get_borderBottomLeftRadius() { }

	// RVA: 0x7628654
	public object get_borderBottomRightRadius() { }

	// RVA: 0x7624CB4
	public object get_borderBottomWidth() { }

	// RVA: 0x7628768
	public object get_borderLeftColor() { }

	// RVA: 0x7624BA0
	public object get_borderLeftWidth() { }

	// RVA: 0x7628884
	public object get_borderRightColor() { }

	// RVA: 0x7624C58
	public object get_borderRightWidth() { }

	// RVA: 0x76289A0
	public object get_borderTopColor() { }

	// RVA: 0x7628A60
	public object get_borderTopLeftRadius() { }

	// RVA: 0x7628B18
	public object get_borderTopRightRadius() { }

	// RVA: 0x7624BFC
	public object get_borderTopWidth() { }

	// RVA: 0x7624864
	public object get_bottom() { }

	// RVA: 0x7628C88
	public object get_color() { }

	// RVA: 0x7628D4C
	public object get_cursor() { }

	// RVA: 0x7625218
	public object get_display() { }

	// RVA: 0x76246F4
	public object get_flexBasis() { }

	// RVA: 0x762504C
	public object get_flexDirection() { }

	// RVA: 0x762463C
	public object get_flexGrow() { }

	// RVA: 0x7624698
	public object get_flexShrink() { }

	// RVA: 0x76251BC
	public object get_flexWrap() { }

	// RVA: 0x7623C98
	public object get_fontSize() { }

	// RVA: 0x7624D6C
	public object get_height() { }

	// RVA: 0x7625160
	public object get_justifyContent() { }

	// RVA: 0x7624750
	public object get_left() { }

	// RVA: 0x76291BC
	public object get_letterSpacing() { }

	// RVA: 0x76249D4
	public object get_marginBottom() { }

	// RVA: 0x76248C0
	public object get_marginLeft() { }

	// RVA: 0x7624978
	public object get_marginRight() { }

	// RVA: 0x762491C
	public object get_marginTop() { }

	// RVA: 0x7624F38
	public object get_maxHeight() { }

	// RVA: 0x7624EDC
	public object get_maxWidth() { }

	// RVA: 0x7624FF0
	public object get_minHeight() { }

	// RVA: 0x7624F94
	public object get_minWidth() { }

	// RVA: 0x7629558
	public object get_opacity() { }

	// RVA: 0x7624E24
	public object get_overflow() { }

	// RVA: 0x7624B44
	public object get_paddingBottom() { }

	// RVA: 0x7624A30
	public object get_paddingLeft() { }

	// RVA: 0x7624AE8
	public object get_paddingRight() { }

	// RVA: 0x7624A8C
	public object get_paddingTop() { }

	// RVA: 0x7624DC8
	public object get_position() { }

	// RVA: 0x7624808
	public object get_right() { }

	// RVA: 0x7629894
	public object get_rotate() { }

	// RVA: 0x762996C
	public object get_scale() { }

	// RVA: 0x7629A2C
	public object get_textOverflow() { }

	// RVA: 0x7629AE4
	public object get_textShadow() { }

	// RVA: 0x76247AC
	public object get_top() { }

	// RVA: 0x7629C1C
	public object get_transformOrigin() { }

	// RVA: 0x7629CF4
	public object get_transitionDelay() { }

	// RVA: 0x7629DAC
	public object get_transitionDuration() { }

	// RVA: 0x7629E64
	public object get_transitionProperty() { }

	// RVA: 0x7629F1C
	public object get_transitionTimingFunction() { }

	// RVA: 0x7629FD4
	public object get_translate() { }

	// RVA: 0x762A0AC
	public object get_unityBackgroundImageTintColor() { }

	// RVA: 0x762A16C
	public object get_unityFont() { }

	// RVA: 0x762A228
	public object get_unityFontDefinition() { }

	// RVA: 0x762A2EC
	public object get_unityFontStyleAndWeight() { }

	// RVA: 0x762A3A8
	public object get_unityOverflowClipBox() { }

	// RVA: 0x762A460
	public object get_unityParagraphSpacing() { }

	// RVA: 0x762A51C
	public object get_unitySliceBottom() { }

	// RVA: 0x762A5D4
	public object get_unitySliceLeft() { }

	// RVA: 0x762A68C
	public object get_unitySliceRight() { }

	// RVA: 0x762A744
	public object get_unitySliceScale() { }

	// RVA: 0x762A7FC
	public object get_unitySliceTop() { }

	// RVA: 0x762A8B4
	public object get_unityTextAlign() { }

	// RVA: 0x762A970
	public object get_unityTextOutlineColor() { }

	// RVA: 0x762AA34
	public object get_unityTextOutlineWidth() { }

	// RVA: 0x762AAF0
	public object get_unityTextOverflowPosition() { }

	// RVA: 0x762ABA8
	public object get_visibility() { }

	// RVA: 0x762AC64
	public object get_whiteSpace() { }

	// RVA: 0x7624D10
	public object get_width() { }

	// RVA: 0x762AD7C
	public object get_wordSpacing() { }

	// RVA: 0x762AE38
	public static object Create(object parentStyle) { }

	// RVA: 0x762AFB4
	public static object CreateInitial() { }

	// RVA: 0x762B0DC
	public object Acquire() { }

	// RVA: 0x762B218
	public object Release() { }

	// RVA: 0x7627A14
	public object CopyFrom(object other) { }

	// RVA: 0x762B32C
	public object ApplyProperties(object reader, object parentStyle) { }

	// RVA: 0x762C810
	public object ApplyStyleValue(object sv, object parentStyle) { }

	// RVA: 0x762DA60
	public object ApplyStyleValueManaged(object sv, object parentStyle) { }

	// RVA: 0x762DEDC
	public object ApplyStyleCursor(object cursor) { }

	// RVA: 0x762DFC8
	public object ApplyStyleTextShadow(object st) { }

	// RVA: 0x762E0C0
	public object ApplyFromComputedStyle(object id, object other) { }

	// RVA: 0x762FA6C
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7630490
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x76308FC
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x76312B8
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x76314E8
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7631690
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7631824
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7631B6C
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7631D44
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7631F28
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x76320DC
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x763227C
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7632410
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x76325A4
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7632730
	public object ApplyPropertyAnimation(object ve, object id, object newValue) { }

	// RVA: 0x7632890
	public static object StartAnimation(object element, object id, object oldStyle, object newStyle, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76378A8
	public static object StartAnimationAllProperty(object element, object oldStyle, object newStyle, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x763CCE8
	public static object StartAnimationInline(object element, object id, object computedStyle, object sv, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76407FC
	public object ApplyStyleTransformOrigin(object st) { }

	// RVA: 0x76408E8
	public object ApplyStyleTranslate(object translateValue) { }

	// RVA: 0x76409D4
	public object ApplyStyleRotate(object rotateValue) { }

	// RVA: 0x7640AC0
	public object ApplyStyleScale(object scaleValue) { }

	// RVA: 0x7640B98
	public object ApplyStyleBackgroundSize(object backgroundSizeValue) { }

	// RVA: 0x7625374
	public object ApplyInitialValue(object reader) { }

	// RVA: 0x7625490
	public object ApplyInitialValue(object id) { }

	// RVA: 0x7625428
	public object ApplyUnsetValue(object reader, object parentStyle) { }

	// RVA: 0x7640C94
	public object ApplyUnsetValue(object id, object parentStyle) { }

	// RVA: 0x764129C
	public static object CompareChanges(object x, object y) { }

}

// Namespace: UnityEngine.UIElements
internal struct ComputedTransitionProperty
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object durationMs; // 0xFFFFFFFFFFFFFFFC
	public object delayMs; // 0x0
	public object easingCurve; // 0x8
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__12_0; // 0x8
	public static object <>9__12_1; // 0x10
	public static object <>9__12_2; // 0x18
	public static object <>9__12_3; // 0x20
	public static object <>9__12_4; // 0x28
	public static object <>9__12_5; // 0x30
	public static object <>9__12_6; // 0x38
	public static object <>9__12_7; // 0x40
	public static object <>9__12_8; // 0x48
	public static object <>9__12_9; // 0x50
	public static object <>9__12_10; // 0x58
	public static object <>9__12_11; // 0x60
	public static object <>9__12_12; // 0x68
	public static object <>9__12_13; // 0x70
	public static object <>9__12_14; // 0x78
	public static object <>9__12_15; // 0x80
	public static object <>9__12_16; // 0x88
	public static object <>9__12_17; // 0x90
	public static object <>9__12_18; // 0x98
	public static object <>9__12_19; // 0xA0
	public static object <>9__12_20; // 0xA8
	public static object <>9__12_21; // 0xB0
	public static object <>9__12_22; // 0xB8

	// Methods

	// RVA: 0x7649338
	private static object .cctor() { }

	// RVA: 0x7649398
	public object .ctor() { }

	// RVA: 0x76493A0
	internal object <ConvertTransitionFunction>b__12_0(object t) { }

	// RVA: 0x76493DC
	internal object <ConvertTransitionFunction>b__12_1(object t) { }

	// RVA: 0x76493E4
	internal object <ConvertTransitionFunction>b__12_2(object t) { }

	// RVA: 0x76493EC
	internal object <ConvertTransitionFunction>b__12_3(object t) { }

	// RVA: 0x76493F4
	internal object <ConvertTransitionFunction>b__12_4(object t) { }

	// RVA: 0x76493FC
	internal object <ConvertTransitionFunction>b__12_5(object t) { }

	// RVA: 0x7649404
	internal object <ConvertTransitionFunction>b__12_6(object t) { }

	// RVA: 0x764940C
	internal object <ConvertTransitionFunction>b__12_7(object t) { }

	// RVA: 0x7649414
	internal object <ConvertTransitionFunction>b__12_8(object t) { }

	// RVA: 0x764941C
	internal object <ConvertTransitionFunction>b__12_9(object t) { }

	// RVA: 0x7649424
	internal object <ConvertTransitionFunction>b__12_10(object t) { }

	// RVA: 0x764942C
	internal object <ConvertTransitionFunction>b__12_11(object t) { }

	// RVA: 0x7649434
	internal object <ConvertTransitionFunction>b__12_12(object t) { }

	// RVA: 0x764943C
	internal object <ConvertTransitionFunction>b__12_13(object t) { }

	// RVA: 0x7649444
	internal object <ConvertTransitionFunction>b__12_14(object t) { }

	// RVA: 0x764944C
	internal object <ConvertTransitionFunction>b__12_15(object t) { }

	// RVA: 0x7649454
	internal object <ConvertTransitionFunction>b__12_16(object t) { }

	// RVA: 0x764945C
	internal object <ConvertTransitionFunction>b__12_17(object t) { }

	// RVA: 0x7649464
	internal object <ConvertTransitionFunction>b__12_18(object t) { }

	// RVA: 0x764946C
	internal object <ConvertTransitionFunction>b__12_19(object t) { }

	// RVA: 0x7649474
	internal object <ConvertTransitionFunction>b__12_20(object t) { }

	// RVA: 0x764947C
	internal object <ConvertTransitionFunction>b__12_21(object t) { }

	// RVA: 0x7649484
	internal object <ConvertTransitionFunction>b__12_22(object t) { }

}

// Namespace: UnityEngine.UIElements
internal static class ComputedTransitionUtils
{

	// Fields
	private static object s_ComputedTransitionsBuffer; // 0x0

	// Methods

	// RVA: 0x7647A24
	internal static object UpdateComputedTransitions(object computedStyle) { }

	// RVA: 0x7647CE4
	internal static object HasTransitionProperty(object computedStyle, object id) { }

	// RVA: 0x7647DDC
	internal static object GetTransitionProperty(object computedStyle, object id, object result) { }

	// RVA: 0x7647AB8
	private static object GetOrComputeTransitionPropertyData(object computedStyle) { }

	// RVA: 0x7647F40
	private static object GetTransitionHashCode(object cs) { }

	// RVA: 0x76487B0
	internal static object SameTransitionProperty(object x, object y) { }

	// RVA: 0x7648910
	private static object SameTransitionProperty(object a, object b) { }

	// RVA: 0x7648A3C
	private static object SameTransitionProperty(object a, object b) { }

	// RVA: 0x76483AC
	private static object ComputeTransitionPropertyData(object computedStyle, object outData) { }

	// RVA: -1
	private static object GetWrappingTransitionData(object list, object i, object defaultValue) { }

	// RVA: 0x7648B4C
	private static object ConvertTransitionTime(object time) { }

	// RVA: 0x7648C78
	private static object ConvertTransitionFunction(object mode) { }

	// RVA: 0x76492A8
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public struct CustomStyleProperty<T0>
{

	// Fields
	private object <name>k__BackingField; // 0x0

	// Properties
	public object name { get; set; }

	// Methods

	// RVA: -1
	public object get_name() { }

	// RVA: -1
	private object set_name(object value) { }

	// RVA: -1
	public object .ctor(object propertyName) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
public interface ICustomStyle
{

	// Methods

	// RVA: -1
	public abstract object TryGetValue(object property, object value) { }

	// RVA: -1
	public abstract object TryGetValue(object property, object value) { }

	// RVA: -1
	public abstract object TryGetValue(object property, object value) { }

	// RVA: -1
	public abstract object TryGetValue(object property, object value) { }

	// RVA: -1
	public abstract object TryGetValue(object property, object value) { }

	// RVA: -1
	public abstract object TryGetValue(object property, object value) { }

	// RVA: -1
	public abstract object TryGetValue(object property, object value) { }

}

// Namespace: UnityEngine.UIElements
public enum EasingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Ease;
	public const object EaseIn;
	public const object EaseOut;
	public const object EaseInOut;
	public const object Linear;
	public const object EaseInSine;
	public const object EaseOutSine;
	public const object EaseInOutSine;
	public const object EaseInCubic;
	public const object EaseOutCubic;
	public const object EaseInOutCubic;
	public const object EaseInCirc;
	public const object EaseOutCirc;
	public const object EaseInOutCirc;
	public const object EaseInElastic;
	public const object EaseOutElastic;
	public const object EaseInOutElastic;
	public const object EaseInBack;
	public const object EaseOutBack;
	public const object EaseInOutBack;
	public const object EaseInBounce;
	public const object EaseOutBounce;
	public const object EaseInOutBounce;
}

// Namespace: UnityEngine.UIElements
public struct EasingFunction
{

	// Fields
	private object m_Mode; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object mode { get; }

	// Methods

	// RVA: 0x764948C
	public object get_mode() { }

	// RVA: 0x764949C
	public object .ctor(object mode) { }

	// RVA: 0x7648C74
	public static object op_Implicit(object easingMode) { }

	// RVA: 0x76494AC
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x76494B8
	public object Equals(object other) { }

	// RVA: 0x76494D8
	public override object Equals(object obj) { }

	// RVA: 0x7649620
	public override object ToString() { }

	// RVA: 0x7648768
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
public struct FontDefinition
{

	// Fields
	private object m_Font; // 0xFFFFFFFFFFFFFFF8
	private object m_FontAsset; // 0x0

	// Properties
	public object font { get; }
	public object fontAsset { get; }

	// Methods

	// RVA: 0x764975C
	public object get_font() { }

	// RVA: 0x764976C
	public object get_fontAsset() { }

	// RVA: 0x764977C
	public static object FromFont(object f) { }

	// RVA: 0x7649784
	public static object FromSDFFont(object f) { }

	// RVA: 0x7649790
	internal static object FromObject(object obj) { }

	// RVA: 0x76498EC
	internal object IsEmpty() { }

	// RVA: 0x7649A7C
	public override object ToString() { }

	// RVA: 0x7649BB4
	public object Equals(object other) { }

	// RVA: 0x7649C44
	public override object Equals(object obj) { }

	// RVA: 0x7649DAC
	public override object GetHashCode() { }

	// RVA: 0x7649F30
	public static object op_Equality(object left, object right) { }

	// RVA: 0x7649F78
	public static object op_Inequality(object left, object right) { }

}

// Namespace: 
internal struct InlineRule
{

	// Fields
	public object sheet; // 0xFFFFFFFFFFFFFFF8
	public object rule; // 0x0
	public object propertyIds; // 0x8
}

// Namespace: UnityEngine.UIElements
internal class InlineStyleAccess
{

	// Fields
	private static object s_StylePropertyReader; // 0x0
	private object m_ValuesManaged; // 0x10
	private object <ve>k__BackingField; // 0x18
	private object m_HasInlineCursor; // 0x20
	private object m_InlineCursor; // 0x28
	private object m_HasInlineTextShadow; // 0x48
	private object m_InlineTextShadow; // 0x4C
	private object m_HasInlineTransformOrigin; // 0x6C
	private object m_InlineTransformOrigin; // 0x70
	private object m_HasInlineTranslate; // 0x88
	private object m_InlineTranslateOperation; // 0x8C
	private object m_HasInlineRotate; // 0xA8
	private object m_InlineRotateOperation; // 0xAC
	private object m_HasInlineScale; // 0xC8
	private object m_InlineScale; // 0xCC
	private object m_HasInlineBackgroundSize; // 0xE0
	public object m_InlineBackgroundSize; // 0xE4
	private object m_InlineRule; // 0x100

	// Properties
	private object UnityEngine.UIElements.IStyle.backgroundColor { set; }
	private object UnityEngine.UIElements.IStyle.borderBottomColor { set; }
	private object UnityEngine.UIElements.IStyle.borderBottomLeftRadius { set; }
	private object UnityEngine.UIElements.IStyle.borderBottomRightRadius { set; }
	private object UnityEngine.UIElements.IStyle.borderBottomWidth { set; }
	private object UnityEngine.UIElements.IStyle.borderLeftColor { set; }
	private object UnityEngine.UIElements.IStyle.borderLeftWidth { set; }
	private object UnityEngine.UIElements.IStyle.borderRightColor { set; }
	private object UnityEngine.UIElements.IStyle.borderRightWidth { set; }
	private object UnityEngine.UIElements.IStyle.borderTopColor { set; }
	private object UnityEngine.UIElements.IStyle.borderTopLeftRadius { set; }
	private object UnityEngine.UIElements.IStyle.borderTopRightRadius { set; }
	private object UnityEngine.UIElements.IStyle.borderTopWidth { set; }
	private object UnityEngine.UIElements.IStyle.bottom { set; }
	private object UnityEngine.UIElements.IStyle.color { set; }
	private object UnityEngine.UIElements.IStyle.display { get; set; }
	private object UnityEngine.UIElements.IStyle.flexBasis { set; }
	private object UnityEngine.UIElements.IStyle.flexDirection { set; }
	private object UnityEngine.UIElements.IStyle.flexGrow { set; }
	private object UnityEngine.UIElements.IStyle.flexShrink { set; }
	private object UnityEngine.UIElements.IStyle.fontSize { set; }
	private object UnityEngine.UIElements.IStyle.height { set; }
	private object UnityEngine.UIElements.IStyle.left { set; }
	private object UnityEngine.UIElements.IStyle.marginBottom { set; }
	private object UnityEngine.UIElements.IStyle.marginLeft { set; }
	private object UnityEngine.UIElements.IStyle.marginRight { set; }
	private object UnityEngine.UIElements.IStyle.marginTop { set; }
	private object UnityEngine.UIElements.IStyle.maxHeight { set; }
	private object UnityEngine.UIElements.IStyle.maxWidth { set; }
	private object UnityEngine.UIElements.IStyle.minWidth { set; }
	private object UnityEngine.UIElements.IStyle.opacity { set; }
	private object UnityEngine.UIElements.IStyle.overflow { set; }
	private object UnityEngine.UIElements.IStyle.paddingBottom { set; }
	private object UnityEngine.UIElements.IStyle.paddingLeft { set; }
	private object UnityEngine.UIElements.IStyle.paddingRight { set; }
	private object UnityEngine.UIElements.IStyle.paddingTop { get; set; }
	private object UnityEngine.UIElements.IStyle.position { set; }
	private object UnityEngine.UIElements.IStyle.right { set; }
	private object UnityEngine.UIElements.IStyle.top { set; }
	private object UnityEngine.UIElements.IStyle.unityBackgroundImageTintColor { set; }
	private object UnityEngine.UIElements.IStyle.unityFont { set; }
	private object UnityEngine.UIElements.IStyle.unityFontDefinition { set; }
	private object UnityEngine.UIElements.IStyle.visibility { set; }
	private object UnityEngine.UIElements.IStyle.width { get; set; }
	private object ve { get; set; }
	private object UnityEngine.UIElements.IStyle.cursor { get; }
	private object UnityEngine.UIElements.IStyle.textShadow { get; }
	private object UnityEngine.UIElements.IStyle.backgroundSize { get; }
	private object UnityEngine.UIElements.IStyle.transformOrigin { get; }
	private object UnityEngine.UIElements.IStyle.translate { get; set; }
	private object UnityEngine.UIElements.IStyle.rotate { get; }
	private object UnityEngine.UIElements.IStyle.scale { get; }

	// Methods

	// RVA: 0x7649FCC
	private object UnityEngine.UIElements.IStyle.set_backgroundColor(object value) { }

	// RVA: 0x764A290
	private object UnityEngine.UIElements.IStyle.set_borderBottomColor(object value) { }

	// RVA: 0x764A324
	private object UnityEngine.UIElements.IStyle.set_borderBottomLeftRadius(object value) { }

	// RVA: 0x764A54C
	private object UnityEngine.UIElements.IStyle.set_borderBottomRightRadius(object value) { }

	// RVA: 0x764A5D8
	private object UnityEngine.UIElements.IStyle.set_borderBottomWidth(object value) { }

	// RVA: 0x764A828
	private object UnityEngine.UIElements.IStyle.set_borderLeftColor(object value) { }

	// RVA: 0x764A8BC
	private object UnityEngine.UIElements.IStyle.set_borderLeftWidth(object value) { }

	// RVA: 0x764A98C
	private object UnityEngine.UIElements.IStyle.set_borderRightColor(object value) { }

	// RVA: 0x764AA20
	private object UnityEngine.UIElements.IStyle.set_borderRightWidth(object value) { }

	// RVA: 0x764AAF0
	private object UnityEngine.UIElements.IStyle.set_borderTopColor(object value) { }

	// RVA: 0x764AB84
	private object UnityEngine.UIElements.IStyle.set_borderTopLeftRadius(object value) { }

	// RVA: 0x764AC10
	private object UnityEngine.UIElements.IStyle.set_borderTopRightRadius(object value) { }

	// RVA: 0x764AC9C
	private object UnityEngine.UIElements.IStyle.set_borderTopWidth(object value) { }

	// RVA: 0x764AD6C
	private object UnityEngine.UIElements.IStyle.set_bottom(object value) { }

	// RVA: 0x764AE50
	private object UnityEngine.UIElements.IStyle.set_color(object value) { }

	// RVA: 0x764AEE0
	private object UnityEngine.UIElements.IStyle.get_display() { }

	// RVA: 0x764AF88
	private object UnityEngine.UIElements.IStyle.set_display(object value) { }

	// RVA: 0x764B090
	private object UnityEngine.UIElements.IStyle.set_flexBasis(object value) { }

	// RVA: 0x764B174
	private object UnityEngine.UIElements.IStyle.set_flexDirection(object value) { }

	// RVA: 0x764B27C
	private object UnityEngine.UIElements.IStyle.set_flexGrow(object value) { }

	// RVA: 0x764B34C
	private object UnityEngine.UIElements.IStyle.set_flexShrink(object value) { }

	// RVA: 0x764B41C
	private object UnityEngine.UIElements.IStyle.set_fontSize(object value) { }

	// RVA: 0x764B4A4
	private object UnityEngine.UIElements.IStyle.set_height(object value) { }

	// RVA: 0x764B588
	private object UnityEngine.UIElements.IStyle.set_left(object value) { }

	// RVA: 0x764B66C
	private object UnityEngine.UIElements.IStyle.set_marginBottom(object value) { }

	// RVA: 0x764B750
	private object UnityEngine.UIElements.IStyle.set_marginLeft(object value) { }

	// RVA: 0x764B834
	private object UnityEngine.UIElements.IStyle.set_marginRight(object value) { }

	// RVA: 0x764B918
	private object UnityEngine.UIElements.IStyle.set_marginTop(object value) { }

	// RVA: 0x764B9FC
	private object UnityEngine.UIElements.IStyle.set_maxHeight(object value) { }

	// RVA: 0x764BAE0
	private object UnityEngine.UIElements.IStyle.set_maxWidth(object value) { }

	// RVA: 0x764BBC4
	private object UnityEngine.UIElements.IStyle.set_minWidth(object value) { }

	// RVA: 0x764BCA8
	private object UnityEngine.UIElements.IStyle.set_opacity(object value) { }

	// RVA: 0x764BD2C
	private object UnityEngine.UIElements.IStyle.set_overflow(object value) { }

	// RVA: 0x764BEA8
	private object UnityEngine.UIElements.IStyle.set_paddingBottom(object value) { }

	// RVA: 0x764BF8C
	private object UnityEngine.UIElements.IStyle.set_paddingLeft(object value) { }

	// RVA: 0x764C070
	private object UnityEngine.UIElements.IStyle.set_paddingRight(object value) { }

	// RVA: 0x764C154
	private object UnityEngine.UIElements.IStyle.get_paddingTop() { }

	// RVA: 0x764C178
	private object UnityEngine.UIElements.IStyle.set_paddingTop(object value) { }

	// RVA: 0x764C25C
	private object UnityEngine.UIElements.IStyle.set_position(object value) { }

	// RVA: 0x764C364
	private object UnityEngine.UIElements.IStyle.set_right(object value) { }

	// RVA: 0x764C448
	private object UnityEngine.UIElements.IStyle.set_top(object value) { }

	// RVA: 0x764C52C
	private object UnityEngine.UIElements.IStyle.set_unityBackgroundImageTintColor(object value) { }

	// RVA: 0x764C5C0
	private object UnityEngine.UIElements.IStyle.set_unityFont(object value) { }

	// RVA: 0x764C8D4
	private object UnityEngine.UIElements.IStyle.set_unityFontDefinition(object value) { }

	// RVA: 0x764CCDC
	private object UnityEngine.UIElements.IStyle.set_visibility(object value) { }

	// RVA: 0x764CDA0
	private object UnityEngine.UIElements.IStyle.get_width() { }

	// RVA: 0x764CDC4
	private object UnityEngine.UIElements.IStyle.set_width(object value) { }

	// RVA: 0x764CEA8
	private object get_ve() { }

	// RVA: 0x764CEB0
	private object set_ve(object value) { }

	// RVA: 0x764CEB8
	public object .ctor(object ve) { }

	// RVA: 0x764CEE4
	protected override object Finalize() { }

	// RVA: 0x764D044
	public object SetInlineRule(object sheet, object rule) { }

	// RVA: 0x764E030
	public object IsValueSet(object id) { }

	// RVA: 0x764D108
	public object ApplyInlineStyles(object computedStyle) { }

	// RVA: 0x764E444
	private object UnityEngine.UIElements.IStyle.get_cursor() { }

	// RVA: 0x764E4D8
	private object UnityEngine.UIElements.IStyle.get_textShadow() { }

	// RVA: 0x764E56C
	private object UnityEngine.UIElements.IStyle.get_backgroundSize() { }

	// RVA: 0x764E5FC
	private object UnityEngine.UIElements.IStyle.get_transformOrigin() { }

	// RVA: 0x764E68C
	private object UnityEngine.UIElements.IStyle.get_translate() { }

	// RVA: 0x764E728
	private object UnityEngine.UIElements.IStyle.set_translate(object value) { }

	// RVA: 0x764E944
	private object UnityEngine.UIElements.IStyle.get_rotate() { }

	// RVA: 0x764E9E0
	private object UnityEngine.UIElements.IStyle.get_scale() { }

	// RVA: 0x764A3AC
	private object SetStyleValue(object id, object inlineValue) { }

	// RVA: 0x764A6A8
	private object SetStyleValue(object id, object inlineValue) { }

	// RVA: 0x764A05C
	private object SetStyleValue(object id, object inlineValue) { }

	// RVA: -1
	private object SetStyleValue(object id, object inlineValue) { }

	// RVA: 0x764C968
	private object SetStyleValue(object id, object inlineValue) { }

	// RVA: 0x764C648
	private object SetStyleValue(object id, object inlineValue) { }

	// RVA: 0x764E7B4
	private object SetInlineTranslate(object inlineValue) { }

	// RVA: 0x764EF24
	private object ApplyStyleTranslate(object translate) { }

	// RVA: 0x764EB8C
	private object ApplyStyleValue(object value) { }

	// RVA: 0x764EA70
	private object RemoveInlineStyle(object id) { }

	// RVA: 0x764F1E0
	private object ApplyFromComputedStyle(object id, object newStyle) { }

	// RVA: 0x764E4B8
	public object TryGetInlineCursor(object value) { }

	// RVA: 0x764E54C
	public object TryGetInlineTextShadow(object value) { }

	// RVA: 0x764E668
	public object TryGetInlineTransformOrigin(object value) { }

	// RVA: 0x764E6FC
	public object TryGetInlineTranslate(object value) { }

	// RVA: 0x764E9B4
	public object TryGetInlineRotate(object value) { }

	// RVA: 0x764EA4C
	public object TryGetInlineScale(object value) { }

	// RVA: 0x764E5D8
	public object TryGetInlineBackgroundSize(object value) { }

	// RVA: 0x764F4D0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public interface IResolvedStyle
{

	// Properties
	public abstract object backgroundColor { get; }
	public abstract object borderBottomColor { get; }
	public abstract object borderBottomLeftRadius { get; }
	public abstract object borderBottomRightRadius { get; }
	public abstract object borderBottomWidth { get; }
	public abstract object borderLeftColor { get; }
	public abstract object borderLeftWidth { get; }
	public abstract object borderRightColor { get; }
	public abstract object borderRightWidth { get; }
	public abstract object borderTopColor { get; }
	public abstract object borderTopLeftRadius { get; }
	public abstract object borderTopRightRadius { get; }
	public abstract object borderTopWidth { get; }
	public abstract object bottom { get; }
	public abstract object color { get; }
	public abstract object display { get; }
	public abstract object flexDirection { get; }
	public abstract object flexGrow { get; }
	public abstract object flexShrink { get; }
	public abstract object height { get; }
	public abstract object left { get; }
	public abstract object marginBottom { get; }
	public abstract object marginLeft { get; }
	public abstract object marginRight { get; }
	public abstract object marginTop { get; }
	public abstract object minHeight { get; }
	public abstract object minWidth { get; }
	public abstract object opacity { get; }
	public abstract object paddingBottom { get; }
	public abstract object paddingLeft { get; }
	public abstract object paddingRight { get; }
	public abstract object paddingTop { get; }
	public abstract object right { get; }
	public abstract object scale { get; }
	public abstract object top { get; }
	public abstract object transformOrigin { get; }
	public abstract object translate { get; }
	public abstract object unityBackgroundImageTintColor { get; }
	public abstract object unitySliceLeft { get; }
	public abstract object unitySliceRight { get; }
	public abstract object unitySliceScale { get; }
	public abstract object unityTextOutlineColor { get; }
	public abstract object unityTextOutlineWidth { get; }
	public abstract object visibility { get; }
	public abstract object width { get; }

	// Methods

	// RVA: -1
	public abstract object get_backgroundColor() { }

	// RVA: -1
	public abstract object get_borderBottomColor() { }

	// RVA: -1
	public abstract object get_borderBottomLeftRadius() { }

	// RVA: -1
	public abstract object get_borderBottomRightRadius() { }

	// RVA: -1
	public abstract object get_borderBottomWidth() { }

	// RVA: -1
	public abstract object get_borderLeftColor() { }

	// RVA: -1
	public abstract object get_borderLeftWidth() { }

	// RVA: -1
	public abstract object get_borderRightColor() { }

	// RVA: -1
	public abstract object get_borderRightWidth() { }

	// RVA: -1
	public abstract object get_borderTopColor() { }

	// RVA: -1
	public abstract object get_borderTopLeftRadius() { }

	// RVA: -1
	public abstract object get_borderTopRightRadius() { }

	// RVA: -1
	public abstract object get_borderTopWidth() { }

	// RVA: -1
	public abstract object get_bottom() { }

	// RVA: -1
	public abstract object get_color() { }

	// RVA: -1
	public abstract object get_display() { }

	// RVA: -1
	public abstract object get_flexDirection() { }

	// RVA: -1
	public abstract object get_flexGrow() { }

	// RVA: -1
	public abstract object get_flexShrink() { }

	// RVA: -1
	public abstract object get_height() { }

	// RVA: -1
	public abstract object get_left() { }

	// RVA: -1
	public abstract object get_marginBottom() { }

	// RVA: -1
	public abstract object get_marginLeft() { }

	// RVA: -1
	public abstract object get_marginRight() { }

	// RVA: -1
	public abstract object get_marginTop() { }

	// RVA: -1
	public abstract object get_minHeight() { }

	// RVA: -1
	public abstract object get_minWidth() { }

	// RVA: -1
	public abstract object get_opacity() { }

	// RVA: -1
	public abstract object get_paddingBottom() { }

	// RVA: -1
	public abstract object get_paddingLeft() { }

	// RVA: -1
	public abstract object get_paddingRight() { }

	// RVA: -1
	public abstract object get_paddingTop() { }

	// RVA: -1
	public abstract object get_right() { }

	// RVA: -1
	public abstract object get_scale() { }

	// RVA: -1
	public abstract object get_top() { }

	// RVA: -1
	public abstract object get_transformOrigin() { }

	// RVA: -1
	public abstract object get_translate() { }

	// RVA: -1
	public abstract object get_unityBackgroundImageTintColor() { }

	// RVA: -1
	public abstract object get_unitySliceLeft() { }

	// RVA: -1
	public abstract object get_unitySliceRight() { }

	// RVA: -1
	public abstract object get_unitySliceScale() { }

	// RVA: -1
	public abstract object get_unityTextOutlineColor() { }

	// RVA: -1
	public abstract object get_unityTextOutlineWidth() { }

	// RVA: -1
	public abstract object get_visibility() { }

	// RVA: -1
	public abstract object get_width() { }

}

// Namespace: UnityEngine.UIElements
public interface IStyle
{

	// Properties
	public abstract object backgroundColor { set; }
	public abstract object backgroundSize { get; }
	public abstract object borderBottomColor { set; }
	public abstract object borderBottomLeftRadius { set; }
	public abstract object borderBottomRightRadius { set; }
	public abstract object borderBottomWidth { set; }
	public abstract object borderLeftColor { set; }
	public abstract object borderLeftWidth { set; }
	public abstract object borderRightColor { set; }
	public abstract object borderRightWidth { set; }
	public abstract object borderTopColor { set; }
	public abstract object borderTopLeftRadius { set; }
	public abstract object borderTopRightRadius { set; }
	public abstract object borderTopWidth { set; }
	public abstract object bottom { set; }
	public abstract object color { set; }
	public abstract object cursor { get; }
	public abstract object display { get; set; }
	public abstract object flexBasis { set; }
	public abstract object flexDirection { set; }
	public abstract object flexGrow { set; }
	public abstract object flexShrink { set; }
	public abstract object fontSize { set; }
	public abstract object height { set; }
	public abstract object left { set; }
	public abstract object marginBottom { set; }
	public abstract object marginLeft { set; }
	public abstract object marginRight { set; }
	public abstract object marginTop { set; }
	public abstract object maxHeight { set; }
	public abstract object maxWidth { set; }
	public abstract object minWidth { set; }
	public abstract object opacity { set; }
	public abstract object overflow { set; }
	public abstract object paddingBottom { set; }
	public abstract object paddingLeft { set; }
	public abstract object paddingRight { set; }
	public abstract object paddingTop { get; set; }
	public abstract object position { set; }
	public abstract object right { set; }
	public abstract object rotate { get; }
	public abstract object scale { get; }
	public abstract object textShadow { get; }
	public abstract object top { set; }
	public abstract object transformOrigin { get; }
	public abstract object translate { get; set; }
	public abstract object unityBackgroundImageTintColor { set; }
	public abstract object unityFont { set; }
	public abstract object unityFontDefinition { set; }
	public abstract object visibility { set; }
	public abstract object width { get; set; }

	// Methods

	// RVA: -1
	public abstract object set_backgroundColor(object value) { }

	// RVA: -1
	public abstract object get_backgroundSize() { }

	// RVA: -1
	public abstract object set_borderBottomColor(object value) { }

	// RVA: -1
	public abstract object set_borderBottomLeftRadius(object value) { }

	// RVA: -1
	public abstract object set_borderBottomRightRadius(object value) { }

	// RVA: -1
	public abstract object set_borderBottomWidth(object value) { }

	// RVA: -1
	public abstract object set_borderLeftColor(object value) { }

	// RVA: -1
	public abstract object set_borderLeftWidth(object value) { }

	// RVA: -1
	public abstract object set_borderRightColor(object value) { }

	// RVA: -1
	public abstract object set_borderRightWidth(object value) { }

	// RVA: -1
	public abstract object set_borderTopColor(object value) { }

	// RVA: -1
	public abstract object set_borderTopLeftRadius(object value) { }

	// RVA: -1
	public abstract object set_borderTopRightRadius(object value) { }

	// RVA: -1
	public abstract object set_borderTopWidth(object value) { }

	// RVA: -1
	public abstract object set_bottom(object value) { }

	// RVA: -1
	public abstract object set_color(object value) { }

	// RVA: -1
	public abstract object get_cursor() { }

	// RVA: -1
	public abstract object get_display() { }

	// RVA: -1
	public abstract object set_display(object value) { }

	// RVA: -1
	public abstract object set_flexBasis(object value) { }

	// RVA: -1
	public abstract object set_flexDirection(object value) { }

	// RVA: -1
	public abstract object set_flexGrow(object value) { }

	// RVA: -1
	public abstract object set_flexShrink(object value) { }

	// RVA: -1
	public abstract object set_fontSize(object value) { }

	// RVA: -1
	public abstract object set_height(object value) { }

	// RVA: -1
	public abstract object set_left(object value) { }

	// RVA: -1
	public abstract object set_marginBottom(object value) { }

	// RVA: -1
	public abstract object set_marginLeft(object value) { }

	// RVA: -1
	public abstract object set_marginRight(object value) { }

	// RVA: -1
	public abstract object set_marginTop(object value) { }

	// RVA: -1
	public abstract object set_maxHeight(object value) { }

	// RVA: -1
	public abstract object set_maxWidth(object value) { }

	// RVA: -1
	public abstract object set_minWidth(object value) { }

	// RVA: -1
	public abstract object set_opacity(object value) { }

	// RVA: -1
	public abstract object set_overflow(object value) { }

	// RVA: -1
	public abstract object set_paddingBottom(object value) { }

	// RVA: -1
	public abstract object set_paddingLeft(object value) { }

	// RVA: -1
	public abstract object set_paddingRight(object value) { }

	// RVA: -1
	public abstract object get_paddingTop() { }

	// RVA: -1
	public abstract object set_paddingTop(object value) { }

	// RVA: -1
	public abstract object set_position(object value) { }

	// RVA: -1
	public abstract object set_right(object value) { }

	// RVA: -1
	public abstract object get_rotate() { }

	// RVA: -1
	public abstract object get_scale() { }

	// RVA: -1
	public abstract object get_textShadow() { }

	// RVA: -1
	public abstract object set_top(object value) { }

	// RVA: -1
	public abstract object get_transformOrigin() { }

	// RVA: -1
	public abstract object get_translate() { }

	// RVA: -1
	public abstract object set_translate(object value) { }

	// RVA: -1
	public abstract object set_unityBackgroundImageTintColor(object value) { }

	// RVA: -1
	public abstract object set_unityFont(object value) { }

	// RVA: -1
	public abstract object set_unityFontDefinition(object value) { }

	// RVA: -1
	public abstract object set_visibility(object value) { }

	// RVA: -1
	public abstract object get_width() { }

	// RVA: -1
	public abstract object set_width(object value) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7662230
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	protected object m_Name; // 0x10
	private object m_ViewDataKey; // 0x18
	protected object m_PickingMode; // 0x20
	private object m_Tooltip; // 0x28
	private object m_UsageHints; // 0x30
	private object <focusIndex>k__BackingField; // 0x38
	private object m_TabIndex; // 0x40
	private object <focusable>k__BackingField; // 0x48
	private object m_Class; // 0x50
	private object m_ContentContainer; // 0x58
	private object m_Style; // 0x60

	// Properties
	protected object focusIndex { get; }
	protected object focusable { get; }

	// Methods

	// RVA: 0x7662288
	protected object get_focusIndex() { }

	// RVA: 0x7662290
	protected object get_focusable() { }

	// RVA: 0x7662298
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x76625DC
	public object .ctor() { }

}

// Namespace: 
public enum MeasureMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undefined;
	public const object Exactly;
	public const object AtMost;
}

// Namespace: 
internal enum RenderTargetMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NoColorConversion;
	public const object LinearToGamma;
	public const object GammaToLinear;
}

// Namespace: 
public struct Hierarchy
{

	// Fields
	private const object k_InvalidHierarchyChangeMsg;
	private readonly object m_Owner; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object parent { get; }
	internal object children { get; }
	public object childCount { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x7662B14
	public object get_parent() { }

	// RVA: 0x7662B5C
	internal object get_children() { }

	// RVA: 0x7662BA4
	internal object .ctor(object element) { }

	// RVA: 0x7662BB4
	public object Add(object child) { }

	// RVA: 0x7662CE8
	public object Insert(object index, object child) { }

	// RVA: 0x76633C0
	public object Remove(object child) { }

	// RVA: 0x76634D8
	public object RemoveAt(object index) { }

	// RVA: 0x76639C4
	public object Clear() { }

	// RVA: 0x7663DB4
	internal object BringToFront(object child) { }

	// RVA: 0x7663FEC
	internal object SendToBack(object child) { }

	// RVA: 0x76640E0
	internal object PlaceBehind(object child, object over) { }

	// RVA: 0x7663EDC
	private object MoveChildElement(object child, object currentIndex, object nextIndex) { }

	// RVA: 0x7662C80
	public object get_childCount() { }

	// RVA: 0x7664290
	public object get_Item(object key) { }

	// RVA: 0x7664390
	public object IndexOf(object element) { }

	// RVA: 0x7664490
	public object ElementAt(object index) { }

	// RVA: 0x7664590
	public object Children() { }

	// RVA: 0x766334C
	private object SetParent(object value) { }

	// RVA: 0x76630F4
	private object PutChildAtIndex(object child, object index) { }

	// RVA: 0x76637D8
	private object RemoveChildAtIndex(object index) { }

	// RVA: 0x766388C
	private object ReleaseChildList() { }

	// RVA: 0x766465C
	public object Equals(object other) { }

	// RVA: 0x7664688
	public override object Equals(object obj) { }

	// RVA: 0x76647D0
	public override object GetHashCode() { }

	// RVA: 0x766466C
	public static object op_Equality(object x, object y) { }

}

// Namespace: 
private abstract class BaseVisualElementScheduledItem
{

	// Fields
	private object <element>k__BackingField; // 0x30
	public object isScheduled; // 0x38
	private object m_Activator; // 0x40

	// Properties
	public object element { get; set; }

	// Methods

	// RVA: 0x7664870
	public object get_element() { }

	// RVA: 0x7664878
	private object set_element(object value) { }

	// RVA: 0x7664880
	protected object .ctor(object handler) { }

	// RVA: 0x7664924
	public object StartingIn(object delayMs) { }

	// RVA: 0x766492C
	public object Every(object intervalMs) { }

	// RVA: 0x7664A14
	internal override object OnItemUnscheduled() { }

	// RVA: 0x7664A6C
	public object Resume() { }

	// RVA: 0x7664A94
	public object Pause() { }

	// RVA: 0x7664ABC
	public object ExecuteLater(object delayMs) { }

	// RVA: 0x7664B14
	public object OnPanelActivate() { }

	// RVA: 0x7664C64
	public object OnPanelDeactivate() { }

	// RVA: 0x7664DA4
	public object CanBeActivated() { }

}

// Namespace: 
private abstract class VisualElementScheduledItem<T0>
{

	// Fields
	public object updateEvent; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object handler, object upEvent) { }

}

// Namespace: 
private class TimerStateScheduledItem
{

	// Methods

	// RVA: 0x7664E14
	public object .ctor(object handler, object updateEvent) { }

	// RVA: 0x7664E84
	public override object PerformTimerUpdate(object state) { }

}

// Namespace: 
private class SimpleScheduledItem
{

	// Methods

	// RVA: 0x7664EC0
	public object .ctor(object handler, object updateEvent) { }

	// RVA: 0x7664F30
	public override object PerformTimerUpdate(object state) { }

}

// Namespace: 
internal class CustomStyleAccess
{

	// Fields
	private object m_CustomProperties; // 0x8
	private object m_DpiScaling; // 0x10

	// Methods

	// RVA: 0x7664F6C
	public object SetContext(object customProperties, object dpiScaling) { }

	// RVA: 0x7664F78
	public object TryGetValue(object property, object value) { }

	// RVA: 0x7665258
	public object TryGetValue(object property, object value) { }

	// RVA: 0x76653B8
	public object TryGetValue(object property, object value) { }

	// RVA: 0x7665760
	public object TryGetValue(object property, object value) { }

	// RVA: 0x766586C
	public object TryGetValue(object property, object value) { }

	// RVA: 0x7665978
	public object TryGetValue(object property, object value) { }

	// RVA: 0x7665A84
	public object TryGetValue(object property, object value) { }

	// RVA: 0x7665090
	private object TryGetValue(object propertyName, object valueType, object customProp) { }

	// RVA: 0x766566C
	private static object LogCustomPropertyWarning(object propertyName, object valueType, object customProp) { }

	// RVA: 0x7665B60
	public object .ctor() { }

}

// Namespace: 
internal class TypeData
{

	// Fields
	private readonly object <type>k__BackingField; // 0x8
	private object m_FullTypeName; // 0x10
	private object m_TypeName; // 0x18
	private object m_TypeNamespace; // 0x20

	// Properties
	public object type { get; }
	public object fullTypeName { get; }
	public object typeName { get; }
	public object typeNamespace { get; }

	// Methods

	// RVA: 0x7665B68
	public object get_type() { }

	// RVA: 0x7665B70
	public object .ctor(object type) { }

	// RVA: 0x7665BE4
	public object get_fullTypeName() { }

	// RVA: 0x7665C60
	public object get_typeName() { }

	// RVA: 0x7665D6C
	public object get_typeNamespace() { }

}

// Namespace: 
private sealed class <>c__DisplayClass492_0
{

	// Fields
	public object <>4__this; // 0x8
	public object to; // 0x10

	// Methods

	// RVA: 0x7665DE8
	public object .ctor() { }

	// RVA: 0x7665DF0
	internal object <UnityEngine.UIElements.Experimental.ITransitionAnimations.Start>b__0(object e) { }

}

// Namespace: UnityEngine.UIElements
public class VisualElement
{

	// Fields
	private object <UnityEngine.UIElements.IStylePropertyAnimations.runningAnimationCount>k__BackingField; // 0x24
	private object <UnityEngine.UIElements.IStylePropertyAnimations.completedAnimationCount>k__BackingField; // 0x28
	private static object s_NextId; // 0x0
	private static object s_EmptyClassList; // 0x8
	internal static readonly object userDataPropertyKey; // 0x10
	public static readonly object disabledUssClassName; // 0x18
	private object m_Name; // 0x30
	private object m_ClassList; // 0x38
	private object m_PropertyBag; // 0x40
	internal object m_Flags; // 0x48
	private object m_ViewDataKey; // 0x50
	private object m_RenderHints; // 0x58
	internal object lastLayout; // 0x5C
	internal object lastPseudoPadding; // 0x6C
	internal object renderChainData; // 0x80
	private object m_Layout; // 0x1C8
	private object m_BoundingBox; // 0x1D8
	private const object worldBoundingBoxDirtyDependencies;
	private object m_WorldBoundingBox; // 0x1E8
	private const object worldTransformInverseDirtyDependencies;
	private object m_WorldTransformCache; // 0x1F8
	private object m_WorldTransformInverseCache; // 0x238
	private object m_WorldClip; // 0x278
	private object m_WorldClipMinusGroup; // 0x288
	private object m_WorldClipIsInfinite; // 0x298
	internal static readonly object s_InfiniteRect; // 0x20
	internal object triggerPseudoMask; // 0x29C
	internal object dependencyPseudoMask; // 0x2A0
	private object m_PseudoStates; // 0x2A4
	private object <containedPointerIds>k__BackingField; // 0x2A8
	private object <pickingMode>k__BackingField; // 0x2AC
	private object <yogaNode>k__BackingField; // 0x2B0
	internal object m_Style; // 0x2B8
	internal object variableContext; // 0x310
	internal object inheritedStylesHash; // 0x318
	internal readonly object controlid; // 0x31C
	internal object imguiContainerDescendantCount; // 0x320
	private object <enabledSelf>k__BackingField; // 0x324
	private object m_LanguageDirection; // 0x328
	private object m_LocalLanguageDirection; // 0x32C
	private object <generateVisualContent>k__BackingField; // 0x330
	private static readonly object k_GenerateVisualContentMarker; // 0x30
	private object m_SubRenderTargetMode; // 0x338
	private static object s_runtimeMaterial; // 0x38
	private object m_defaultMaterial; // 0x340
	private object m_RunningAnimations; // 0x348
	private static object s_NextParentVersion; // 0x40
	private object m_NextParentCachedVersion; // 0x350
	private object m_NextParentRequiredVersion; // 0x354
	private object m_CachedNextParentWithEventCallback; // 0x358
	private object m_EventCallbackCategories; // 0x360
	private object m_CachedEventCallbackParentCategories; // 0x364
	private readonly object m_DefaultActionEventCategories; // 0x368
	private readonly object m_DefaultActionAtTargetEventCategories; // 0x36C
	internal const object k_RootVisualContainerName;
	private object <hierarchy>k__BackingField; // 0x370
	private object <isRootVisualContainer>k__BackingField; // 0x378
	private object <cacheAsBitmap>k__BackingField; // 0x379
	private object m_PhysicalParent; // 0x380
	private object m_LogicalParent; // 0x388
	private static readonly object s_EmptyList; // 0x48
	private object m_Children; // 0x390
	private object <elementPanel>k__BackingField; // 0x398
	private object m_VisualTreeAssetSource; // 0x3A0
	internal static object s_CustomStyleAccess; // 0x50
	internal object inlineStyleAccess; // 0x3A8
	internal object styleSheetList; // 0x3B0
	private static readonly object s_InternalStyleSheetPath; // 0x58
	internal static readonly object tooltipPropertyKey; // 0x60
	private static readonly object s_TypeData; // 0x68
	private object m_TypeData; // 0x3B8

	// Properties
	public object resolvedStyle { get; }
	private object UnityEngine.UIElements.IResolvedStyle.backgroundColor { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderBottomColor { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderBottomLeftRadius { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderBottomRightRadius { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderBottomWidth { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderLeftColor { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderLeftWidth { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderRightColor { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderRightWidth { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderTopColor { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderTopLeftRadius { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderTopRightRadius { get; }
	private object UnityEngine.UIElements.IResolvedStyle.borderTopWidth { get; }
	private object UnityEngine.UIElements.IResolvedStyle.bottom { get; }
	private object UnityEngine.UIElements.IResolvedStyle.color { get; }
	private object UnityEngine.UIElements.IResolvedStyle.display { get; }
	private object UnityEngine.UIElements.IResolvedStyle.flexDirection { get; }
	private object UnityEngine.UIElements.IResolvedStyle.flexGrow { get; }
	private object UnityEngine.UIElements.IResolvedStyle.flexShrink { get; }
	private object UnityEngine.UIElements.IResolvedStyle.height { get; }
	private object UnityEngine.UIElements.IResolvedStyle.left { get; }
	private object UnityEngine.UIElements.IResolvedStyle.marginBottom { get; }
	private object UnityEngine.UIElements.IResolvedStyle.marginLeft { get; }
	private object UnityEngine.UIElements.IResolvedStyle.marginRight { get; }
	private object UnityEngine.UIElements.IResolvedStyle.marginTop { get; }
	private object UnityEngine.UIElements.IResolvedStyle.minHeight { get; }
	private object UnityEngine.UIElements.IResolvedStyle.minWidth { get; }
	private object UnityEngine.UIElements.IResolvedStyle.opacity { get; }
	private object UnityEngine.UIElements.IResolvedStyle.paddingBottom { get; }
	private object UnityEngine.UIElements.IResolvedStyle.paddingLeft { get; }
	private object UnityEngine.UIElements.IResolvedStyle.paddingRight { get; }
	private object UnityEngine.UIElements.IResolvedStyle.paddingTop { get; }
	private object UnityEngine.UIElements.IResolvedStyle.right { get; }
	private object UnityEngine.UIElements.IResolvedStyle.scale { get; }
	private object UnityEngine.UIElements.IResolvedStyle.top { get; }
	private object UnityEngine.UIElements.IResolvedStyle.transformOrigin { get; }
	private object UnityEngine.UIElements.IResolvedStyle.translate { get; }
	private object UnityEngine.UIElements.IResolvedStyle.unityBackgroundImageTintColor { get; }
	private object UnityEngine.UIElements.IResolvedStyle.unitySliceLeft { get; }
	private object UnityEngine.UIElements.IResolvedStyle.unitySliceRight { get; }
	private object UnityEngine.UIElements.IResolvedStyle.unitySliceScale { get; }
	private object UnityEngine.UIElements.IResolvedStyle.unityTextOutlineColor { get; }
	private object UnityEngine.UIElements.IResolvedStyle.unityTextOutlineWidth { get; }
	private object UnityEngine.UIElements.IResolvedStyle.visibility { get; }
	private object UnityEngine.UIElements.IResolvedStyle.width { get; }
	internal object hasRunningAnimations { get; }
	internal object hasCompletedAnimations { get; }
	private object UnityEngine.UIElements.IStylePropertyAnimations.runningAnimationCount { get; set; }
	private object UnityEngine.UIElements.IStylePropertyAnimations.completedAnimationCount { get; set; }
	internal object styleAnimation { get; }
	internal object isCompositeRoot { get; set; }
	internal object isHierarchyDisplayed { get; set; }
	public object viewDataKey { get; set; }
	internal object enableViewDataPersistence { get; set; }
	public object userData { get; set; }
	public override object canGrabFocus { get; }
	public override object focusController { get; }
	public object usageHints { get; set; }
	internal object renderHints { get; set; }
	public object transform { get; }
	private object UnityEngine.UIElements.ITransform.position { get; set; }
	private object UnityEngine.UIElements.ITransform.scale { get; }
	internal object isLayoutManual { get; set; }
	internal object scaledPixelsPerPoint { get; }
	public object layout { get; set; }
	public object contentRect { get; }
	protected object paddingRect { get; }
	internal object isBoundingBoxDirty { get; set; }
	internal object isWorldBoundingBoxDirty { set; }
	internal object isWorldBoundingBoxOrDependenciesDirty { get; }
	internal object boundingBox { get; }
	internal object worldBoundingBox { get; }
	private object boundingBoxInParentSpace { get; }
	public object worldBound { get; }
	public object localBound { get; }
	internal object rect { get; }
	internal object isWorldTransformDirty { get; set; }
	internal object isWorldTransformInverseDirty { set; }
	internal object isWorldTransformInverseOrDependenciesDirty { get; }
	public object worldTransform { get; }
	internal object worldTransformRef { get; }
	internal object worldTransformInverse { get; }
	internal object isWorldClipDirty { get; set; }
	internal object worldClip { get; }
	internal object worldClipMinusGroup { get; }
	internal object worldClipIsInfinite { get; }
	internal object pseudoStates { get; set; }
	internal object containedPointerIds { get; set; }
	public object pickingMode { get; set; }
	public object name { get; set; }
	internal object classList { get; }
	internal object fullTypeName { get; }
	internal object typeName { get; }
	internal object yogaNode { get; set; }
	internal object computedStyle { get; }
	internal object hasInlineStyle { get; }
	internal object styleInitialized { get; set; }
	private object isParentEnabledInHierarchy { get; }
	public object enabledInHierarchy { get; }
	public object enabledSelf { get; set; }
	public object languageDirection { get; }
	internal object localLanguageDirection { get; set; }
	public object visible { get; set; }
	public object generateVisualContent { get; set; }
	internal object requireMeasureFunction { get; set; }
	internal object subRenderTargetMode { get; }
	internal object defaultMaterial { get; }
	internal object nextParentWithEventCallback { get; }
	internal object eventCallbackCategories { get; set; }
	internal object eventCallbackParentCategories { get; }
	internal object isEventCallbackParentCategoriesDirty { get; set; }
	public object experimental { get; }
	private object UnityEngine.UIElements.IExperimentalFeatures.animation { get; }
	public object hierarchy { get; set; }
	internal object isRootVisualContainer { get; set; }
	internal object disableClipping { get; set; }
	public object parent { get; }
	internal object elementPanel { get; set; }
	public object panel { get; }
	public virtual object contentContainer { get; }
	internal object visualTreeAssetSource { set; }
	public object Item { get; }
	public object childCount { get; }
	private object positionWithLayout { get; }
	internal object hasDefaultRotationAndScale { get; }
	public object schedule { get; }
	public object style { get; }
	public object customStyle { get; }
	public object styleSheets { get; }
	public object tooltip { get; set; }
	private object typeData { get; }

	// Methods

	// RVA: 0x76447DC
	public object get_resolvedStyle() { }

	// RVA: 0x764F588
	private object UnityEngine.UIElements.IResolvedStyle.get_backgroundColor() { }

	// RVA: 0x764F594
	private object UnityEngine.UIElements.IResolvedStyle.get_borderBottomColor() { }

	// RVA: 0x764F5A0
	private object UnityEngine.UIElements.IResolvedStyle.get_borderBottomLeftRadius() { }

	// RVA: 0x764F5C0
	private object UnityEngine.UIElements.IResolvedStyle.get_borderBottomRightRadius() { }

	// RVA: 0x764F5E0
	private object UnityEngine.UIElements.IResolvedStyle.get_borderBottomWidth() { }

	// RVA: 0x764F604
	private object UnityEngine.UIElements.IResolvedStyle.get_borderLeftColor() { }

	// RVA: 0x764F610
	private object UnityEngine.UIElements.IResolvedStyle.get_borderLeftWidth() { }

	// RVA: 0x764F634
	private object UnityEngine.UIElements.IResolvedStyle.get_borderRightColor() { }

	// RVA: 0x764F640
	private object UnityEngine.UIElements.IResolvedStyle.get_borderRightWidth() { }

	// RVA: 0x764F664
	private object UnityEngine.UIElements.IResolvedStyle.get_borderTopColor() { }

	// RVA: 0x764F670
	private object UnityEngine.UIElements.IResolvedStyle.get_borderTopLeftRadius() { }

	// RVA: 0x764F690
	private object UnityEngine.UIElements.IResolvedStyle.get_borderTopRightRadius() { }

	// RVA: 0x764F6B0
	private object UnityEngine.UIElements.IResolvedStyle.get_borderTopWidth() { }

	// RVA: 0x764F6D4
	private object UnityEngine.UIElements.IResolvedStyle.get_bottom() { }

	// RVA: 0x764F6F8
	private object UnityEngine.UIElements.IResolvedStyle.get_color() { }

	// RVA: 0x764F704
	private object UnityEngine.UIElements.IResolvedStyle.get_display() { }

	// RVA: 0x764F710
	private object UnityEngine.UIElements.IResolvedStyle.get_flexDirection() { }

	// RVA: 0x764F71C
	private object UnityEngine.UIElements.IResolvedStyle.get_flexGrow() { }

	// RVA: 0x764F728
	private object UnityEngine.UIElements.IResolvedStyle.get_flexShrink() { }

	// RVA: 0x764F734
	private object UnityEngine.UIElements.IResolvedStyle.get_height() { }

	// RVA: 0x764F758
	private object UnityEngine.UIElements.IResolvedStyle.get_left() { }

	// RVA: 0x764F77C
	private object UnityEngine.UIElements.IResolvedStyle.get_marginBottom() { }

	// RVA: 0x764F7A0
	private object UnityEngine.UIElements.IResolvedStyle.get_marginLeft() { }

	// RVA: 0x764F7C4
	private object UnityEngine.UIElements.IResolvedStyle.get_marginRight() { }

	// RVA: 0x764F7E8
	private object UnityEngine.UIElements.IResolvedStyle.get_marginTop() { }

	// RVA: 0x764F80C
	private object UnityEngine.UIElements.IResolvedStyle.get_minHeight() { }

	// RVA: 0x764FA4C
	private object UnityEngine.UIElements.IResolvedStyle.get_minWidth() { }

	// RVA: 0x764FA80
	private object UnityEngine.UIElements.IResolvedStyle.get_opacity() { }

	// RVA: 0x764FA8C
	private object UnityEngine.UIElements.IResolvedStyle.get_paddingBottom() { }

	// RVA: 0x764FAB0
	private object UnityEngine.UIElements.IResolvedStyle.get_paddingLeft() { }

	// RVA: 0x764FAD4
	private object UnityEngine.UIElements.IResolvedStyle.get_paddingRight() { }

	// RVA: 0x764FAF8
	private object UnityEngine.UIElements.IResolvedStyle.get_paddingTop() { }

	// RVA: 0x764FB1C
	private object UnityEngine.UIElements.IResolvedStyle.get_right() { }

	// RVA: 0x764FB40
	private object UnityEngine.UIElements.IResolvedStyle.get_scale() { }

	// RVA: 0x764FB4C
	private object UnityEngine.UIElements.IResolvedStyle.get_top() { }

	// RVA: 0x764FB70
	private object UnityEngine.UIElements.IResolvedStyle.get_transformOrigin() { }

	// RVA: 0x764FF0C
	private object UnityEngine.UIElements.IResolvedStyle.get_translate() { }

	// RVA: 0x7650120
	private object UnityEngine.UIElements.IResolvedStyle.get_unityBackgroundImageTintColor() { }

	// RVA: 0x765012C
	private object UnityEngine.UIElements.IResolvedStyle.get_unitySliceLeft() { }

	// RVA: 0x7650138
	private object UnityEngine.UIElements.IResolvedStyle.get_unitySliceRight() { }

	// RVA: 0x7650144
	private object UnityEngine.UIElements.IResolvedStyle.get_unitySliceScale() { }

	// RVA: 0x7650150
	private object UnityEngine.UIElements.IResolvedStyle.get_unityTextOutlineColor() { }

	// RVA: 0x765015C
	private object UnityEngine.UIElements.IResolvedStyle.get_unityTextOutlineWidth() { }

	// RVA: 0x7650168
	private object UnityEngine.UIElements.IResolvedStyle.get_visibility() { }

	// RVA: 0x7650174
	private object UnityEngine.UIElements.IResolvedStyle.get_width() { }

	// RVA: 0x7650198
	internal object get_hasRunningAnimations() { }

	// RVA: 0x7650270
	internal object get_hasCompletedAnimations() { }

	// RVA: 0x7650348
	private object UnityEngine.UIElements.IStylePropertyAnimations.get_runningAnimationCount() { }

	// RVA: 0x7650350
	private object UnityEngine.UIElements.IStylePropertyAnimations.set_runningAnimationCount(object value) { }

	// RVA: 0x7650358
	private object UnityEngine.UIElements.IStylePropertyAnimations.get_completedAnimationCount() { }

	// RVA: 0x7650360
	private object UnityEngine.UIElements.IStylePropertyAnimations.set_completedAnimationCount(object value) { }

	// RVA: 0x7650368
	private object GetStylePropertyAnimationSystem() { }

	// RVA: 0x764F1DC
	internal object get_styleAnimation() { }

	// RVA: 0x76503BC
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7650504
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7650660
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76507BC
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7650950
	private object UnityEngine.UIElements.IStylePropertyAnimations.StartEnum(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7650AAC
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7650C2C
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7650DA0
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7650EFC
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x765109C
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7651210
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76513B0
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7651550
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76516F0
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7651860
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76519BC
	private object UnityEngine.UIElements.IStylePropertyAnimations.Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7651B5C
	private object UnityEngine.UIElements.IStylePropertyAnimations.CancelAnimation(object id) { }

	// RVA: 0x7651C78
	private object UnityEngine.UIElements.IStylePropertyAnimations.CancelAllAnimations() { }

	// RVA: 0x7651D98
	private object UnityEngine.UIElements.IStylePropertyAnimations.UpdateAnimation(object id) { }

	// RVA: 0x7651EAC
	private object UnityEngine.UIElements.IStylePropertyAnimations.GetAllAnimations(object outPropertyIds) { }

	// RVA: 0x7651FEC
	internal object TryConvertLengthUnits(object id, object from, object to, object subPropertyIndex) { }

	// RVA: 0x76526C8
	internal object TryConvertTransformOriginUnits(object from, object to) { }

	// RVA: 0x7652748
	internal object TryConvertTranslateUnits(object from, object to) { }

	// RVA: 0x76527C8
	internal object TryConvertBackgroundSizeUnits(object from, object to) { }

	// RVA: 0x76522AC
	private object GetParentSizeForLengthConversion(object id, object subPropertyIndex) { }

	// RVA: 0x76528A0
	internal object get_isCompositeRoot() { }

	// RVA: 0x76528AC
	internal object set_isCompositeRoot(object value) { }

	// RVA: 0x7652A84
	internal object get_isHierarchyDisplayed() { }

	// RVA: 0x7652A90
	internal object set_isHierarchyDisplayed(object value) { }

	// RVA: 0x7652AB0
	public object get_viewDataKey() { }

	// RVA: 0x7652AB8
	public object set_viewDataKey(object value) { }

	// RVA: 0x7652B3C
	internal object get_enableViewDataPersistence() { }

	// RVA: 0x7652B48
	private object set_enableViewDataPersistence(object value) { }

	// RVA: 0x7652B68
	public object get_userData() { }

	// RVA: 0x7652D04
	public object set_userData(object value) { }

	// RVA: 0x7653134
	public override object get_canGrabFocus() { }

	// RVA: 0x76533C4
	public override object get_focusController() { }

	// RVA: 0x76534B8
	public object get_usageHints() { }

	// RVA: 0x76534D8
	public object set_usageHints(object value) { }

	// RVA: 0x76534D0
	internal object get_renderHints() { }

	// RVA: 0x76536BC
	internal object set_renderHints(object value) { }

	// RVA: 0x7653738
	internal object MarkRenderHintsClean() { }

	// RVA: 0x7653748
	public object get_transform() { }

	// RVA: 0x765374C
	private object UnityEngine.UIElements.ITransform.get_position() { }

	// RVA: 0x765382C
	private object UnityEngine.UIElements.ITransform.set_position(object value) { }

	// RVA: 0x7653A00
	private object UnityEngine.UIElements.ITransform.get_scale() { }

	// RVA: 0x7653AE0
	internal object get_isLayoutManual() { }

	// RVA: 0x7653AEC
	private object set_isLayoutManual(object value) { }

	// RVA: 0x7653B0C
	internal object get_scaledPixelsPerPoint() { }

	// RVA: 0x7653B20
	public object get_layout() { }

	// RVA: 0x7653BE4
	internal object set_layout(object value) { }

	// RVA: 0x7654590
	internal object ClearManualLayout() { }

	// RVA: 0x7654CA8
	public object get_contentRect() { }

	// RVA: 0x7654F28
	protected object get_paddingRect() { }

	// RVA: 0x76551C4
	internal object get_isBoundingBoxDirty() { }

	// RVA: 0x76551D0
	internal object set_isBoundingBoxDirty(object value) { }

	// RVA: 0x76551F0
	internal object set_isWorldBoundingBoxDirty(object value) { }

	// RVA: 0x7655210
	internal object get_isWorldBoundingBoxOrDependenciesDirty() { }

	// RVA: 0x7655224
	internal object get_boundingBox() { }

	// RVA: 0x76554E8
	internal object get_worldBoundingBox() { }

	// RVA: 0x765567C
	private object get_boundingBoxInParentSpace() { }

	// RVA: 0x765526C
	internal object UpdateBoundingBox() { }

	// RVA: 0x7655538
	internal object UpdateWorldBoundingBox() { }

	// RVA: 0x76558D4
	public object get_worldBound() { }

	// RVA: 0x76559C4
	public object get_localBound() { }

	// RVA: 0x76551A8
	internal object get_rect() { }

	// RVA: 0x7655A0C
	internal object get_isWorldTransformDirty() { }

	// RVA: 0x7655A18
	internal object set_isWorldTransformDirty(object value) { }

	// RVA: 0x7655A2C
	internal object set_isWorldTransformInverseDirty(object value) { }

	// RVA: 0x7655A4C
	internal object get_isWorldTransformInverseOrDependenciesDirty() { }

	// RVA: 0x7655A5C
	public object get_worldTransform() { }

	// RVA: 0x76558A4
	internal object get_worldTransformRef() { }

	// RVA: 0x7655DB4
	internal object get_worldTransformInverse() { }

	// RVA: 0x7655AA0
	internal object UpdateWorldTransform() { }

	// RVA: 0x7655E24
	internal object UpdateWorldTransformInverse() { }

	// RVA: 0x7656264
	internal object get_isWorldClipDirty() { }

	// RVA: 0x7656270
	internal object set_isWorldClipDirty(object value) { }

	// RVA: 0x7656290
	internal object get_worldClip() { }

	// RVA: 0x7656638
	internal object get_worldClipMinusGroup() { }

	// RVA: 0x7656680
	internal object get_worldClipIsInfinite() { }

	// RVA: 0x76566BC
	internal object EnsureWorldTransformAndClipUpToDate() { }

	// RVA: 0x76562D8
	private object UpdateWorldClip() { }

	// RVA: 0x7656DF0
	private object CombineClipRects(object rect, object parentRect) { }

	// RVA: 0x7656714
	private object SubstractBorderPadding(object worldRect) { }

	// RVA: 0x7656E40
	internal static object ComputeAAAlignedBound(object position, object mat) { }

	// RVA: 0x7656F60
	internal object get_pseudoStates() { }

	// RVA: 0x7656F68
	internal object set_pseudoStates(object value) { }

	// RVA: 0x7657018
	internal object get_containedPointerIds() { }

	// RVA: 0x7657020
	private object set_containedPointerIds(object value) { }

	// RVA: 0x7657028
	private object UpdateHoverPseudoState() { }

	// RVA: 0x7657244
	private static object IsPartOfCapturedChain(object self, object capturingElement) { }

	// RVA: 0x76573A8
	public object get_pickingMode() { }

	// RVA: 0x76573B0
	public object set_pickingMode(object value) { }

	// RVA: 0x76573B8
	public object get_name() { }

	// RVA: 0x76573C0
	public object set_name(object value) { }

	// RVA: 0x7657434
	internal object get_classList() { }

	// RVA: 0x7657520
	internal object get_fullTypeName() { }

	// RVA: 0x76576A0
	internal object get_typeName() { }

	// RVA: 0x76576C8
	internal object get_yogaNode() { }

	// RVA: 0x76576D0
	private object set_yogaNode(object value) { }

	// RVA: 0x7644870
	internal object get_computedStyle() { }

	// RVA: 0x76576D8
	internal object get_hasInlineStyle() { }

	// RVA: 0x764F1D0
	internal object get_styleInitialized() { }

	// RVA: 0x76576E8
	internal object set_styleInitialized(object value) { }

	// RVA: 0x7657708
	private object ChangeIMGUIContainerCount(object delta) { }

	// RVA: 0x7657754
	public object .ctor() { }

	// RVA: 0x7657AE4
	protected override object ExecuteDefaultAction(object evt) { }

	// RVA: 0x76588E8
	internal virtual object GetTooltipRect() { }

	// RVA: 0x76587D0
	private object SetTooltip(object e) { }

	// RVA: 0x7658A10
	public sealed override object Focus() { }

	// RVA: 0x7658AEC
	internal object SetPanel(object p) { }

	// RVA: 0x76596C8
	private object WillChangePanel(object destinationPanel) { }

	// RVA: 0x76599B4
	private object HasChangedPanel(object prevPanel) { }

	// RVA: 0x765A0C0
	public sealed override object SendEvent(object e) { }

	// RVA: 0x765A0D8
	internal sealed override object SendEvent(object e, object dispatchMode) { }

	// RVA: 0x764A224
	internal object IncrementVersion(object changeType) { }

	// RVA: 0x765A0EC
	internal object InvokeHierarchyChanged(object changeType) { }

	// RVA: 0x765A108
	private object SetEnabledFromHierarchyPrivate(object state) { }

	// RVA: 0x765A5FC
	private object get_isParentEnabledInHierarchy() { }

	// RVA: 0x76533B4
	public object get_enabledInHierarchy() { }

	// RVA: 0x765AAD8
	public object get_enabledSelf() { }

	// RVA: 0x765AAE0
	private object set_enabledSelf(object value) { }

	// RVA: 0x7657ACC
	public object SetEnabled(object value) { }

	// RVA: 0x765AAE8
	private object PropagateEnabledToChildren(object value) { }

	// RVA: 0x765ABC4
	public object get_languageDirection() { }

	// RVA: 0x765ABCC
	internal object get_localLanguageDirection() { }

	// RVA: 0x765ABD4
	internal object set_localLanguageDirection(object value) { }

	// RVA: 0x76532DC
	public object get_visible() { }

	// RVA: 0x765AD1C
	public object set_visible(object value) { }

	// RVA: 0x765AE80
	public object MarkDirtyRepaint() { }

	// RVA: 0x765AEDC
	public object get_generateVisualContent() { }

	// RVA: 0x765AEE4
	public object set_generateVisualContent(object value) { }

	// RVA: 0x765AEEC
	internal object InvokeGenerateVisualContent(object mgc) { }

	// RVA: 0x765B0F4
	internal object GetFullHierarchicalViewDataKey(object key) { }

	// RVA: 0x765B1A0
	internal object GetFullHierarchicalViewDataKey() { }

	// RVA: -1
	internal object GetOrCreateViewData(object existing, object key) { }

	// RVA: 0x765B23C
	internal object OverwriteFromViewData(object obj, object key) { }

	// RVA: 0x765B63C
	internal object SaveViewData() { }

	// RVA: 0x765B70C
	internal object IsViewDataPersitenceSupportedOnChildren(object existingState) { }

	// RVA: 0x765B7D4
	internal object OnViewDataReady(object enablePersistence) { }

	// RVA: 0x765B834
	internal virtual object OnViewDataReady() { }

	// RVA: 0x765B838
	public virtual object ContainsPoint(object localPoint) { }

	// RVA: 0x765B888
	internal object get_requireMeasureFunction() { }

	// RVA: 0x765B894
	internal object set_requireMeasureFunction(object value) { }

	// RVA: 0x765B9D0
	private object AssignMeasureFunction() { }

	// RVA: 0x765BA6C
	private object RemoveMeasureFunction() { }

	// RVA: 0x765BA94
	protected internal virtual object DoMeasure(object desiredWidth, object widthMode, object desiredHeight, object heightMode) { }

	// RVA: 0x765BAA4
	internal object Measure(object node, object width, object widthMode, object height, object heightMode) { }

	// RVA: 0x765BC00
	private object FinalizeLayout() { }

	// RVA: 0x765BC64
	internal object SetInlineRule(object sheet, object rule) { }

	// RVA: 0x765BD90
	internal object SetComputedStyle(object newStyle) { }

	// RVA: 0x765C0AC
	public override object ToString() { }

	// RVA: 0x765C254
	internal object GetClassesForIteration() { }

	// RVA: 0x765A7F4
	public object AddToClassList(object className) { }

	// RVA: 0x765A67C
	public object RemoveFromClassList(object className) { }

	// RVA: 0x765AACC
	public object EnableInClassList(object className, object enable) { }

	// RVA: 0x765C25C
	public object ClassListContains(object cls) { }

	// RVA: 0x765C328
	internal object GetProperty(object key) { }

	// RVA: 0x765C51C
	internal object SetProperty(object key, object value) { }

	// RVA: 0x765C5A0
	internal object HasProperty(object key) { }

	// RVA: 0x7652BEC
	private object TryGetPropertyInternal(object key, object value) { }

	// RVA: 0x765C3B4
	private static object CheckUserKeyArgument(object key) { }

	// RVA: 0x7652D78
	private object SetPropertyInternal(object key, object value) { }

	// RVA: 0x7658214
	private object UpdateCursorStyle(object eventType) { }

	// RVA: 0x765C624
	internal object get_subRenderTargetMode() { }

	// RVA: 0x765C62C
	internal object get_defaultMaterial() { }

	// RVA: 0x765C634
	private object GetAnimationSystem() { }

	// RVA: 0x765C6FC
	internal object RegisterAnimation(object anim) { }

	// RVA: 0x765C900
	internal object UnregisterAnimation(object anim) { }

	// RVA: 0x7659E48
	private object UnregisterRunningAnimations() { }

	// RVA: 0x7659FD0
	private object RegisterRunningAnimations() { }

	// RVA: -1
	private static object StartAnimation(object anim, object fromValueGetter, object to, object durationMs, object onValueChanged) { }

	// RVA: 0x765CA08
	private static object AssignStyleValues(object ve, object src) { }

	// RVA: 0x765E208
	private object ReadCurrentValues(object ve, object targetValuesToRead) { }

	// RVA: 0x765F428
	private object UnityEngine.UIElements.Experimental.ITransitionAnimations.Start(object to, object durationMs) { }

	// RVA: 0x765F514
	private object Start(object fromValueGetter, object to, object durationMs) { }

	// RVA: 0x765F694
	private object DirtyNextParentWithEventCallback() { }

	// RVA: 0x76529BC
	private object SetAsNextParentWithEventCallback() { }

	// RVA: 0x765F718
	internal object GetCachedNextParentWithEventCallback(object nextParent) { }

	// RVA: 0x765F740
	internal object get_nextParentWithEventCallback() { }

	// RVA: 0x765F890
	private object PropagateCachedNextParentWithEventCallback(object nextParent, object stopParent) { }

	// RVA: 0x765F914
	internal object get_eventCallbackCategories() { }

	// RVA: 0x765F91C
	internal object set_eventCallbackCategories(object value) { }

	// RVA: 0x765FA44
	internal object get_eventCallbackParentCategories() { }

	// RVA: 0x765FA90
	internal object get_isEventCallbackParentCategoriesDirty() { }

	// RVA: 0x765FBA4
	internal object set_isEventCallbackParentCategoriesDirty(object value) { }

	// RVA: 0x765FA9C
	private object UpdateCallbackParentCategories() { }

	// RVA: 0x765FBC4
	internal object HasEventCallbacks(object eventCategory) { }

	// RVA: 0x765FBD4
	internal object HasParentEventCallbacksOrDefaultActions(object eventCategory) { }

	// RVA: 0x7659E28
	internal object HasEventCallbacksOrDefaultActions(object eventCategory) { }

	// RVA: 0x765FC48
	internal object HasParentEventCallbacksOrDefaultActionAtTarget(object eventCategory) { }

	// RVA: 0x765FCB4
	internal object HasEventCallbacksOrDefaultActionAtTarget(object eventCategory) { }

	// RVA: 0x765FCCC
	internal object HasDefaultAction(object eventCategory) { }

	// RVA: 0x765FCDC
	public object get_experimental() { }

	// RVA: 0x765FCE0
	private object UnityEngine.UIElements.IExperimentalFeatures.get_animation() { }

	// RVA: 0x765FCE4
	public object get_hierarchy() { }

	// RVA: 0x765FCEC
	private object set_hierarchy(object value) { }

	// RVA: 0x765FCF4
	internal object get_isRootVisualContainer() { }

	// RVA: 0x765FCFC
	internal object set_isRootVisualContainer(object value) { }

	// RVA: 0x765FD04
	internal object get_disableClipping() { }

	// RVA: 0x765FD10
	internal object set_disableClipping(object value) { }

	// RVA: 0x765586C
	internal object ShouldClip() { }

	// RVA: 0x76532D4
	public object get_parent() { }

	// RVA: 0x765FD30
	internal object get_elementPanel() { }

	// RVA: 0x765FD38
	private object set_elementPanel(object value) { }

	// RVA: 0x76534B0
	public object get_panel() { }

	// RVA: 0x765FD40
	public virtual object get_contentContainer() { }

	// RVA: 0x765FD44
	internal object set_visualTreeAssetSource(object value) { }

	// RVA: 0x765FD4C
	public object Add(object child) { }

	// RVA: 0x765FE1C
	public object Insert(object index, object element) { }

	// RVA: 0x765FEE0
	public object Clear() { }

	// RVA: 0x765FF84
	public object ElementAt(object index) { }

	// RVA: 0x765FF88
	public object get_Item(object key) { }

	// RVA: 0x7660038
	public object get_childCount() { }

	// RVA: 0x76600DC
	public object IndexOf(object element) { }

	// RVA: 0x76601A0
	internal object ElementAtTreePath(object childIndexes) { }

	// RVA: 0x766035C
	internal object FindElementInTree(object element, object outChildIndexes) { }

	// RVA: 0x76604CC
	public object Children() { }

	// RVA: 0x76605E4
	public object BringToFront() { }

	// RVA: 0x766065C
	public object SendToBack() { }

	// RVA: 0x76606D4
	public object PlaceBehind(object sibling) { }

	// RVA: 0x7660824
	public object RemoveFromHierarchy() { }

	// RVA: -1
	public object GetFirstOfType() { }

	// RVA: -1
	public object GetFirstAncestorOfType() { }

	// RVA: 0x766089C
	internal object GetFirstAncestorWhere(object predicate) { }

	// RVA: 0x7657338
	public object Contains(object child) { }

	// RVA: 0x76595CC
	private object GatherAllChildren(object elements) { }

	// RVA: 0x7660924
	public object FindCommonAncestor(object other) { }

	// RVA: 0x7660AF0
	internal object GetRoot() { }

	// RVA: 0x7660BE0
	internal object GetRootVisualContainer() { }

	// RVA: 0x7660C30
	internal object GetNextElementDepthFirst() { }

	// RVA: 0x7660D64
	internal object GetPreviousElementDepthFirst() { }

	// RVA: 0x7660E94
	internal object RetargetElement(object retargetAgainst) { }

	// RVA: 0x7655E88
	private object get_positionWithLayout() { }

	// RVA: 0x7655EDC
	internal object GetPivotedMatrixWithLayout(object result) { }

	// RVA: 0x7660F70
	internal object get_hasDefaultRotationAndScale() { }

	// RVA: 0x7661064
	internal static object Min(object a, object b, object c, object d) { }

	// RVA: 0x7661080
	internal static object Max(object a, object b, object c, object d) { }

	// RVA: 0x766109C
	private object TransformAlignedRectToParentSpace(object rect) { }

	// RVA: 0x766122C
	internal static object CalculateConservativeRect(object matrix, object rect) { }

	// RVA: 0x76614A4
	internal static object TransformAlignedRect(object matrix, object rect) { }

	// RVA: 0x7661450
	internal static object OrderMinMaxRect(object rect) { }

	// RVA: 0x766153C
	internal static object MultiplyMatrix44Point2(object lhs, object point) { }

	// RVA: 0x7661560
	internal static object MultiplyVector2(object lhs, object vector) { }

	// RVA: 0x76560A8
	internal static object MultiplyMatrix34(object lhs, object rhs, object res) { }

	// RVA: 0x766157C
	private static object TranslateMatrix34(object lhs, object rhs, object res) { }

	// RVA: 0x766166C
	private static object TranslateMatrix34InPlace(object lhs, object rhs) { }

	// RVA: 0x76616C8
	public object get_schedule() { }

	// RVA: 0x76616CC
	private object UnityEngine.UIElements.IVisualElementScheduler.Execute(object timerUpdateEvent) { }

	// RVA: 0x7661794
	private object UnityEngine.UIElements.IVisualElementScheduler.Execute(object updateEvent) { }

	// RVA: 0x764E3C4
	public object get_style() { }

	// RVA: 0x766185C
	public object get_customStyle() { }

	// RVA: 0x7661908
	public object get_styleSheets() { }

	// RVA: 0x7661938
	internal object AddStyleSheetPath(object sheetPath) { }

	// RVA: 0x764F840
	private object ResolveLengthValue(object length, object isRow) { }

	// RVA: 0x764FF10
	private object ResolveTranslate() { }

	// RVA: 0x764FB74
	private object ResolveTransformOrigin() { }

	// RVA: 0x7660F00
	private object ResolveRotation() { }

	// RVA: 0x7660F44
	private object ResolveScale() { }

	// RVA: 0x76588EC
	public object get_tooltip() { }

	// RVA: 0x7661BC8
	public object set_tooltip(object value) { }

	// RVA: 0x7661DC8
	internal static object GetOrCreateTypeData(object t) { }

	// RVA: 0x7657548
	private object get_typeData() { }

	// RVA: 0x7661F14
	private static object .cctor() { }

	// RVA: 0x76621AC
	private object <AssignMeasureFunction>b__432_0(object node, object f, object mode, object f1, object heightMode) { }

}

// Namespace: UnityEngine.UIElements
internal interface IStyleDataGroup<T0>
{

	// Methods

	// RVA: -1
	public abstract object Copy() { }

	// RVA: -1
	public abstract object CopyFrom(object other) { }

}

// Namespace: UnityEngine.UIElements
internal struct InheritedData
{

	// Fields
	public object color; // 0xFFFFFFFFFFFFFFF8
	public object fontSize; // 0x8
	public object letterSpacing; // 0x10
	public object textShadow; // 0x18
	public object unityFont; // 0x38
	public object unityFontDefinition; // 0x40
	public object unityFontStyleAndWeight; // 0x50
	public object unityParagraphSpacing; // 0x54
	public object unityTextAlign; // 0x5C
	public object unityTextOutlineColor; // 0x60
	public object unityTextOutlineWidth; // 0x70
	public object visibility; // 0x74
	public object whiteSpace; // 0x78
	public object wordSpacing; // 0x7C

	// Methods

	// RVA: 0x7665E58
	public object Copy() { }

	// RVA: 0x7665EC0
	public object CopyFrom(object other) { }

	// RVA: 0x7665ED4
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7666160
	public object Equals(object other) { }

	// RVA: 0x7666268
	public override object Equals(object obj) { }

	// RVA: 0x7666470
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal struct LayoutData
{

	// Fields
	public object alignContent; // 0xFFFFFFFFFFFFFFF8
	public object alignItems; // 0xFFFFFFFFFFFFFFFC
	public object alignSelf; // 0x0
	public object borderBottomWidth; // 0x4
	public object borderLeftWidth; // 0x8
	public object borderRightWidth; // 0xC
	public object borderTopWidth; // 0x10
	public object bottom; // 0x14
	public object display; // 0x1C
	public object flexBasis; // 0x20
	public object flexDirection; // 0x28
	public object flexGrow; // 0x2C
	public object flexShrink; // 0x30
	public object flexWrap; // 0x34
	public object height; // 0x38
	public object justifyContent; // 0x40
	public object left; // 0x44
	public object marginBottom; // 0x4C
	public object marginLeft; // 0x54
	public object marginRight; // 0x5C
	public object marginTop; // 0x64
	public object maxHeight; // 0x6C
	public object maxWidth; // 0x74
	public object minHeight; // 0x7C
	public object minWidth; // 0x84
	public object paddingBottom; // 0x8C
	public object paddingLeft; // 0x94
	public object paddingRight; // 0x9C
	public object paddingTop; // 0xA4
	public object position; // 0xAC
	public object right; // 0xB0
	public object top; // 0xB8
	public object width; // 0xC0

	// Methods

	// RVA: 0x7666748
	public object Copy() { }

	// RVA: 0x76667D8
	public object CopyFrom(object other) { }

	// RVA: 0x76667EC
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7666BD0
	public object Equals(object other) { }

	// RVA: 0x7666D20
	public override object Equals(object obj) { }

	// RVA: 0x7666F70
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal struct RareData
{

	// Fields
	public object cursor; // 0xFFFFFFFFFFFFFFF8
	public object textOverflow; // 0x10
	public object unityBackgroundImageTintColor; // 0x14
	public object unityOverflowClipBox; // 0x24
	public object unitySliceBottom; // 0x28
	public object unitySliceLeft; // 0x2C
	public object unitySliceRight; // 0x30
	public object unitySliceScale; // 0x34
	public object unitySliceTop; // 0x38
	public object unityTextOverflowPosition; // 0x3C

	// Methods

	// RVA: 0x76672F8
	public object Copy() { }

	// RVA: 0x7667338
	public object CopyFrom(object other) { }

	// RVA: 0x766734C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7667498
	public object Equals(object other) { }

	// RVA: 0x76676E8
	public override object Equals(object obj) { }

	// RVA: 0x7667888
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal struct TransformData
{

	// Fields
	public object rotate; // 0xFFFFFFFFFFFFFFF8
	public object scale; // 0x10
	public object transformOrigin; // 0x20
	public object translate; // 0x34

	// Methods

	// RVA: 0x7667B78
	public object Copy() { }

	// RVA: 0x7667BC8
	public object CopyFrom(object other) { }

	// RVA: 0x7667BDC
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7667F9C
	public object Equals(object other) { }

	// RVA: 0x766806C
	public override object Equals(object obj) { }

	// RVA: 0x766824C
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal struct TransitionData
{

	// Fields
	public object transitionDelay; // 0xFFFFFFFFFFFFFFF8
	public object transitionDuration; // 0x0
	public object transitionProperty; // 0x8
	public object transitionTimingFunction; // 0x10

	// Methods

	// RVA: 0x7668600
	public object Copy() { }

	// RVA: 0x766874C
	public object CopyFrom(object other) { }

	// RVA: 0x76688FC
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7668958
	public object Equals(object other) { }

	// RVA: 0x76689D0
	public override object Equals(object obj) { }

	// RVA: 0x7668BB0
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal struct VisualData
{

	// Fields
	public object backgroundColor; // 0xFFFFFFFFFFFFFFF8
	public object backgroundImage; // 0x8
	public object backgroundPositionX; // 0x28
	public object backgroundPositionY; // 0x34
	public object backgroundRepeat; // 0x40
	public object backgroundSize; // 0x48
	public object borderBottomColor; // 0x5C
	public object borderBottomLeftRadius; // 0x6C
	public object borderBottomRightRadius; // 0x74
	public object borderLeftColor; // 0x7C
	public object borderRightColor; // 0x8C
	public object borderTopColor; // 0x9C
	public object borderTopLeftRadius; // 0xAC
	public object borderTopRightRadius; // 0xB4
	public object opacity; // 0xBC
	public object overflow; // 0xC0

	// Methods

	// RVA: 0x7668D28
	public object Copy() { }

	// RVA: 0x7668DB8
	public object CopyFrom(object other) { }

	// RVA: 0x7668DCC
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x76690D8
	public object Equals(object other) { }

	// RVA: 0x7669228
	public override object Equals(object obj) { }

	// RVA: 0x7669478
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal class StyleValueCollection
{

	// Fields
	internal object m_Values; // 0x8

	// Methods

	// RVA: 0x7669778
	public object GetStyleLength(object id) { }

	// RVA: 0x76699D8
	public object GetStyleFloat(object id) { }

	// RVA: 0x7669A54
	public object GetStyleInt(object id) { }

	// RVA: 0x76697F4
	public object TryGetStyleValue(object id, object value) { }

	// RVA: 0x7669AE8
	public object SetStyleValue(object value) { }

	// RVA: 0x7669D50
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public enum LengthUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Pixel;
	public const object Percent;
}

// Namespace: 
private enum Unit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Pixel;
	public const object Percent;
	public const object Auto;
	public const object None;
}

// Namespace: UnityEngine.UIElements
public struct Length
{

	// Fields
	internal const object k_MaxValue;
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Unit; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object value { get; set; }
	public object unit { get; }

	// Methods

	// RVA: 0x7669DD0
	public static object Percent(object value) { }

	// RVA: 0x7669E18
	public static object Auto() { }

	// RVA: 0x7669E44
	public static object None() { }

	// RVA: 0x7669E4C
	public object get_value() { }

	// RVA: 0x7669E5C
	public object set_value(object value) { }

	// RVA: 0x7669E9C
	public object get_unit() { }

	// RVA: 0x7669EAC
	public object IsAuto() { }

	// RVA: 0x7669ECC
	public object IsNone() { }

	// RVA: 0x7669EEC
	public object .ctor(object value) { }

	// RVA: 0x7669DF4
	public object .ctor(object value, object unit) { }

	// RVA: 0x7669E20
	private object .ctor(object value, object unit) { }

	// RVA: 0x7669F7C
	public static object op_Implicit(object value) { }

	// RVA: 0x7666140
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7669F9C
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7669FBC
	public object Equals(object other) { }

	// RVA: 0x766A004
	public override object Equals(object obj) { }

	// RVA: 0x766670C
	public override object GetHashCode() { }

	// RVA: 0x766A1BC
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct Rotate
{

	// Fields
	private object m_Angle; // 0xFFFFFFFFFFFFFFF8
	private object m_Axis; // 0x0
	private object m_IsNone; // 0xC

	// Properties
	public object angle { get; set; }

	// Methods

	// RVA: 0x766A3E0
	public object .ctor(object angle) { }

	// RVA: 0x766A4B8
	internal static object Initial() { }

	// RVA: 0x766A534
	public static object None() { }

	// RVA: 0x766A5BC
	public object get_angle() { }

	// RVA: 0x766A5CC
	public object set_angle(object value) { }

	// RVA: 0x7667DCC
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766A5DC
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x766A684
	public object Equals(object other) { }

	// RVA: 0x766A7DC
	public override object Equals(object obj) { }

	// RVA: 0x7668388
	public override object GetHashCode() { }

	// RVA: 0x766A920
	public override object ToString() { }

	// RVA: 0x766AA20
	internal object ToQuaternion() { }

}

// Namespace: UnityEngine.UIElements
public struct Scale
{

	// Fields
	private object m_Scale; // 0xFFFFFFFFFFFFFFF8
	private object m_IsNone; // 0x4

	// Properties
	public object value { get; }

	// Methods

	// RVA: 0x766AA84
	public object .ctor(object scale) { }

	// RVA: 0x766ABAC
	internal static object Initial() { }

	// RVA: 0x766AC14
	public static object None() { }

	// RVA: 0x766AC84
	public object get_value() { }

	// RVA: 0x7667E60
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766AC9C
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x766ACF4
	public object Equals(object other) { }

	// RVA: 0x766ADA4
	public override object Equals(object obj) { }

	// RVA: 0x7668460
	public override object GetHashCode() { }

	// RVA: 0x766AFC4
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleBackgroundSize
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0xC

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766AFE8
	public object get_value() { }

	// RVA: 0x766B088
	public object get_keyword() { }

	// RVA: 0x766B098
	public object .ctor(object keyword) { }

	// RVA: 0x766B0A4
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766B0E4
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766B144
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766B150
	public object Equals(object other) { }

	// RVA: 0x766B210
	public override object Equals(object obj) { }

	// RVA: 0x766B3E8
	public override object GetHashCode() { }

	// RVA: 0x766B454
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleColor
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0x8

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766B56C
	public object get_value() { }

	// RVA: 0x766B5BC
	public object get_keyword() { }

	// RVA: 0x766B5CC
	public object .ctor(object v) { }

	// RVA: 0x766B5DC
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766B60C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766B668
	public static object op_Implicit(object v) { }

	// RVA: 0x766B678
	public object Equals(object other) { }

	// RVA: 0x766B730
	public override object Equals(object obj) { }

	// RVA: 0x766B81C
	public override object GetHashCode() { }

	// RVA: 0x766B94C
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleCursor
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0x10

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766BAA0
	public object get_value() { }

	// RVA: 0x766BB38
	public object get_keyword() { }

	// RVA: 0x766BB48
	public object .ctor(object keyword) { }

	// RVA: 0x766BB58
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766BBA0
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766BC00
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766BC10
	public object Equals(object other) { }

	// RVA: 0x766BCD0
	public override object Equals(object obj) { }

	// RVA: 0x766BEB0
	public override object GetHashCode() { }

	// RVA: 0x766BF1C
	public override object ToString() { }

}

// Namespace: 
private class RefCounted
{

	// Fields
	private static object m_NextId; // 0x0
	private object m_RefCount; // 0x0
	private readonly object m_Id; // 0x0
	public object value; // 0x0

	// Properties
	public object refCount { get; }

	// Methods

	// RVA: -1
	public object get_refCount() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object Acquire() { }

	// RVA: -1
	public object Release() { }

	// RVA: -1
	public object Copy() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal struct StyleDataRef<T0>
{

	// Fields
	private object m_Ref; // 0x0

	// Methods

	// RVA: -1
	public object Acquire() { }

	// RVA: -1
	public object Release() { }

	// RVA: -1
	public object CopyFrom(object other) { }

	// RVA: -1
	public object Read() { }

	// RVA: -1
	public object Write() { }

	// RVA: -1
	public static object Create() { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public object ReferenceEquals(object other) { }

}

// Namespace: UnityEngine.UIElements
public struct StyleEnum<T0>
{

	// Fields
	private object m_Value; // 0x0
	private object m_Keyword; // 0x0

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: -1
	public object get_value() { }

	// RVA: -1
	public object get_keyword() { }

	// RVA: -1
	public object .ctor(object v) { }

	// RVA: -1
	public object .ctor(object keyword) { }

	// RVA: -1
	internal object .ctor(object v, object keyword) { }

	// RVA: -1
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: -1
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: -1
	public static object op_Implicit(object keyword) { }

	// RVA: -1
	public static object op_Implicit(object v) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleFloat
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766C028
	public object get_value() { }

	// RVA: 0x766C058
	public object get_keyword() { }

	// RVA: 0x766C068
	public object .ctor(object v) { }

	// RVA: 0x766C080
	public object .ctor(object keyword) { }

	// RVA: 0x7669A40
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766C09C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7669A4C
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766C0BC
	public static object op_Implicit(object v) { }

	// RVA: 0x766C0C4
	public object Equals(object other) { }

	// RVA: 0x766C10C
	public override object Equals(object obj) { }

	// RVA: 0x766C27C
	public override object GetHashCode() { }

	// RVA: 0x766C2E8
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleFont
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0x0

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766C42C
	public object get_value() { }

	// RVA: 0x766C45C
	public object get_keyword() { }

	// RVA: 0x766C46C
	public object .ctor(object v) { }

	// RVA: 0x766C478
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766C49C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766C538
	public static object op_Implicit(object v) { }

	// RVA: 0x766C540
	public object Equals(object other) { }

	// RVA: 0x766C678
	public override object Equals(object obj) { }

	// RVA: 0x766C77C
	public override object GetHashCode() { }

	// RVA: 0x766C880
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleFontDefinition
{

	// Fields
	private object m_Keyword; // 0xFFFFFFFFFFFFFFF8
	private object m_Value; // 0x0

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766C9C4
	public object get_value() { }

	// RVA: 0x766C9FC
	public object get_keyword() { }

	// RVA: 0x766CA0C
	public object .ctor(object f) { }

	// RVA: 0x766CA18
	internal object .ctor(object f, object keyword) { }

	// RVA: 0x766CA3C
	public static object op_Implicit(object f) { }

	// RVA: 0x766CA48
	public object Equals(object other) { }

	// RVA: 0x766CA9C
	public override object Equals(object obj) { }

	// RVA: 0x766CBFC
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleInt
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766CC60
	public object get_value() { }

	// RVA: 0x766CC90
	public object get_keyword() { }

	// RVA: 0x766CCA0
	public object .ctor(object keyword) { }

	// RVA: 0x7669AD8
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766CCB8
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7669AE0
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766CCC4
	public object Equals(object other) { }

	// RVA: 0x766CCE4
	public override object Equals(object obj) { }

	// RVA: 0x766CE2C
	public override object GetHashCode() { }

	// RVA: 0x766CE54
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleLength
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0x0

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766CF5C
	public object get_value() { }

	// RVA: 0x766CFB0
	public object get_keyword() { }

	// RVA: 0x766CFC0
	public object .ctor(object v) { }

	// RVA: 0x766D010
	public object .ctor(object v) { }

	// RVA: 0x766D050
	public object .ctor(object keyword) { }

	// RVA: 0x76699AC
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766D088
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x76699CC
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766D0BC
	public static object op_Implicit(object v) { }

	// RVA: 0x766D0E0
	public static object op_Implicit(object v) { }

	// RVA: 0x766D0F4
	public object Equals(object other) { }

	// RVA: 0x766D16C
	public override object Equals(object obj) { }

	// RVA: 0x766D30C
	public override object GetHashCode() { }

	// RVA: 0x766D388
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleRotate
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0x10

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766D504
	public object get_value() { }

	// RVA: 0x766D668
	public object get_keyword() { }

	// RVA: 0x766D678
	public object .ctor(object keyword) { }

	// RVA: 0x766D688
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766D6D0
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766D794
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766D7A4
	public object Equals(object other) { }

	// RVA: 0x766D924
	public override object Equals(object obj) { }

	// RVA: 0x766DA68
	public override object GetHashCode() { }

	// RVA: 0x766DACC
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleScale
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0x8

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766DC38
	public object get_value() { }

	// RVA: 0x766DD84
	public object get_keyword() { }

	// RVA: 0x766DD94
	public object .ctor(object keyword) { }

	// RVA: 0x766DDA0
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766DDC4
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766DE2C
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766DE38
	public object Equals(object other) { }

	// RVA: 0x766DF08
	public override object Equals(object obj) { }

	// RVA: 0x766E0E8
	public override object GetHashCode() { }

	// RVA: 0x766E1BC
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleTranslate
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0x10

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766E334
	public object get_value() { }

	// RVA: 0x766E448
	public object get_keyword() { }

	// RVA: 0x766E458
	public object .ctor(object v) { }

	// RVA: 0x766E4B0
	public object .ctor(object keyword) { }

	// RVA: 0x766E478
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766E4F0
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766E574
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766E584
	public static object op_Implicit(object v) { }

	// RVA: 0x766E59C
	public object Equals(object other) { }

	// RVA: 0x766E6A4
	public override object Equals(object obj) { }

	// RVA: 0x766E7DC
	public override object GetHashCode() { }

	// RVA: 0x766E8F8
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleTextShadow
{

	// Fields
	private object m_Keyword; // 0xFFFFFFFFFFFFFFF8
	private object m_Value; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766EA10
	public object get_value() { }

	// RVA: 0x766EAC0
	public object get_keyword() { }

	// RVA: 0x766EAD0
	public object .ctor(object keyword) { }

	// RVA: 0x766EAE8
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766EB4C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766EBAC
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766EBC4
	public object Equals(object other) { }

	// RVA: 0x766EC84
	public override object Equals(object obj) { }

	// RVA: 0x766EE64
	public override object GetHashCode() { }

	// RVA: 0x766EF00
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct StyleTransformOrigin
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Keyword; // 0xC

	// Properties
	public object value { get; }
	public object keyword { get; }

	// Methods

	// RVA: 0x766F00C
	public object get_value() { }

	// RVA: 0x766F134
	public object get_keyword() { }

	// RVA: 0x766F144
	public object .ctor(object keyword) { }

	// RVA: 0x766F150
	internal object .ctor(object v, object keyword) { }

	// RVA: 0x766F190
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766F208
	public static object op_Implicit(object keyword) { }

	// RVA: 0x766F214
	public object Equals(object other) { }

	// RVA: 0x766F304
	public override object Equals(object obj) { }

	// RVA: 0x766F53C
	public override object GetHashCode() { }

	// RVA: 0x766F658
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
internal interface IStyleValue<T0>
{

	// Properties
	public abstract object value { get; }
	public abstract object keyword { get; }

	// Methods

	// RVA: -1
	public abstract object get_value() { }

	// RVA: -1
	public abstract object get_keyword() { }

}

// Namespace: UnityEngine.UIElements
public enum StyleKeyword
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undefined;
	public const object Null;
	public const object Auto;
	public const object None;
	public const object Initial;
}

// Namespace: UnityEngine.UIElements
internal static class StyleValueExtensions
{

	// Methods

	// RVA: -1
	internal static object DebugString(object styleValue) { }

	// RVA: 0x766F770
	internal static object ToYogaValue(object length) { }

	// RVA: 0x766F8D4
	internal static object ToLength(object keyword) { }

	// RVA: 0x766F9F4
	internal static object ToRotate(object keyword) { }

	// RVA: 0x766FB6C
	internal static object ToScale(object keyword) { }

	// RVA: 0x766FCCC
	internal static object ToTranslate(object keyword) { }

	// RVA: 0x766FE1C
	internal static object ToLength(object styleLength) { }

	// RVA: -1
	internal static object CopyFrom(object list, object other) { }

}

// Namespace: UnityEngine.UIElements
public enum TimeUnit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Second;
	public const object Millisecond;
}

// Namespace: UnityEngine.UIElements
public struct TimeValue
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Unit; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object value { get; }
	public object unit { get; }

	// Methods

	// RVA: 0x766FE3C
	public object get_value() { }

	// RVA: 0x766FE4C
	public object get_unit() { }

	// RVA: 0x766FE5C
	public object .ctor(object value) { }

	// RVA: 0x766FE68
	public object .ctor(object value, object unit) { }

	// RVA: 0x766FE8C
	public static object op_Implicit(object value) { }

	// RVA: 0x766FE94
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x766FEB4
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x766FED4
	public object Equals(object other) { }

	// RVA: 0x766FF1C
	public override object Equals(object obj) { }

	// RVA: 0x767009C
	public override object GetHashCode() { }

	// RVA: 0x7670108
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct TransformOrigin
{

	// Fields
	private object m_X; // 0xFFFFFFFFFFFFFFF8
	private object m_Y; // 0x0
	private object m_Z; // 0x8

	// Properties
	public object x { get; set; }
	public object y { get; set; }
	public object z { get; }

	// Methods

	// RVA: 0x7670258
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x766F094
	public static object Initial() { }

	// RVA: 0x7670270
	public object get_x() { }

	// RVA: 0x7670280
	public object set_x(object value) { }

	// RVA: 0x7670290
	public object get_y() { }

	// RVA: 0x76702A0
	public object set_y(object value) { }

	// RVA: 0x76702B0
	public object get_z() { }

	// RVA: 0x7667EB8
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x76702C0
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7670328
	public object Equals(object other) { }

	// RVA: 0x76703F8
	public override object Equals(object obj) { }

	// RVA: 0x76684BC
	public override object GetHashCode() { }

	// RVA: 0x767065C
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public struct Translate
{

	// Fields
	private object m_X; // 0xFFFFFFFFFFFFFFF8
	private object m_Y; // 0x0
	private object m_Z; // 0x8
	private object m_isNone; // 0xC

	// Properties
	public object x { get; set; }
	public object y { get; set; }
	public object z { get; }

	// Methods

	// RVA: 0x76707E0
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x766E424
	public static object None() { }

	// RVA: 0x7670800
	public object get_x() { }

	// RVA: 0x7670810
	public object set_x(object value) { }

	// RVA: 0x7670820
	public object get_y() { }

	// RVA: 0x7670830
	public object set_y(object value) { }

	// RVA: 0x7670840
	public object get_z() { }

	// RVA: 0x7667F24
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7670850
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x76708C8
	public object Equals(object other) { }

	// RVA: 0x76709C0
	public override object Equals(object obj) { }

	// RVA: 0x766853C
	public override object GetHashCode() { }

	// RVA: 0x7670C84
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
public enum Position
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Relative;
	public const object Absolute;
}

// Namespace: UnityEngine.UIElements
public enum Overflow
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Visible;
	public const object Hidden;
}

// Namespace: UnityEngine.UIElements
internal enum OverflowInternal
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Visible;
	public const object Hidden;
	public const object Scroll;
}

// Namespace: UnityEngine.UIElements
public enum OverflowClipBox
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PaddingBox;
	public const object ContentBox;
}

// Namespace: UnityEngine.UIElements
public enum FlexDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Column;
	public const object ColumnReverse;
	public const object Row;
	public const object RowReverse;
}

// Namespace: UnityEngine.UIElements
public enum Wrap
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoWrap;
	public const object Wrap;
	public const object WrapReverse;
}

// Namespace: UnityEngine.UIElements
public enum Align
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object FlexStart;
	public const object Center;
	public const object FlexEnd;
	public const object Stretch;
}

// Namespace: UnityEngine.UIElements
public enum Justify
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FlexStart;
	public const object Center;
	public const object FlexEnd;
	public const object SpaceBetween;
	public const object SpaceAround;
}

// Namespace: UnityEngine.UIElements
public enum TextOverflowPosition
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object End;
	public const object Start;
	public const object Middle;
}

// Namespace: UnityEngine.UIElements
public enum TextOverflow
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Clip;
	public const object Ellipsis;
}

// Namespace: UnityEngine.UIElements
public enum TransformOriginOffset
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Left;
	public const object Right;
	public const object Top;
	public const object Bottom;
	public const object Center;
}

// Namespace: UnityEngine.UIElements
public enum Visibility
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Visible;
	public const object Hidden;
}

// Namespace: UnityEngine.UIElements
public enum WhiteSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object NoWrap;
}

// Namespace: UnityEngine.UIElements
public enum DisplayStyle
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Flex;
	public const object None;
}

// Namespace: UnityEngine.UIElements
public enum BackgroundPositionKeyword
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Center;
	public const object Top;
	public const object Bottom;
	public const object Left;
	public const object Right;
}

// Namespace: UnityEngine.UIElements
public enum Repeat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoRepeat;
	public const object Space;
	public const object Round;
	public const object Repeat;
}

// Namespace: UnityEngine.UIElements
public enum BackgroundSizeType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Length;
	public const object Cover;
	public const object Contain;
}

// Namespace: UnityEngine.UIElements
internal interface IStylePainter
{

	// Methods

	// RVA: -1
	public abstract object DrawText(object te) { }

	// RVA: -1
	public abstract object DrawRectangle(object rectParams) { }

	// RVA: -1
	public abstract object DrawImmediate(object callback, object cullingEnabled) { }

}

// Namespace: UnityEngine.UIElements
internal interface IStylePropertyAnimations
{

	// Properties
	public abstract object runningAnimationCount { get; set; }
	public abstract object completedAnimationCount { get; set; }

	// Methods

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartEnum(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object Start(object id, object from, object to, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object UpdateAnimation(object id) { }

	// RVA: -1
	public abstract object GetAllAnimations(object outPropertyIds) { }

	// RVA: -1
	public abstract object CancelAnimation(object id) { }

	// RVA: -1
	public abstract object CancelAllAnimations() { }

	// RVA: -1
	public abstract object get_runningAnimationCount() { }

	// RVA: -1
	public abstract object set_runningAnimationCount(object value) { }

	// RVA: -1
	public abstract object get_completedAnimationCount() { }

	// RVA: -1
	public abstract object set_completedAnimationCount(object value) { }

}

// Namespace: UnityEngine.UIElements
internal interface IStylePropertyAnimationSystem
{

	// Methods

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: -1
	public abstract object CancelAllAnimations() { }

	// RVA: -1
	public abstract object CancelAllAnimations(object owner) { }

	// RVA: -1
	public abstract object CancelAnimation(object owner, object id) { }

	// RVA: -1
	public abstract object UpdateAnimation(object owner, object id) { }

	// RVA: -1
	public abstract object GetAllAnimations(object owner, object propertyIds) { }

	// RVA: -1
	public abstract object Update() { }

}

// Namespace: 
private enum TransitionState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Running;
	public const object Started;
	public const object Ended;
	public const object Canceled;
}

// Namespace: 
private struct AnimationDataSet<T0, T1>
{

	// Fields
	public object elements; // 0x0
	public object properties; // 0x0
	public object timing; // 0x0
	public object style; // 0x0
	public object count; // 0x0
	private object indices; // 0x0

	// Properties
	private object capacity { get; set; }

	// Methods

	// RVA: -1
	private object get_capacity() { }

	// RVA: -1
	private object set_capacity(object value) { }

	// RVA: -1
	private object LocalInit() { }

	// RVA: -1
	public static object Create() { }

	// RVA: -1
	public object IndexOf(object ve, object prop, object index) { }

	// RVA: -1
	public object Add(object owner, object prop, object timingData, object styleData) { }

	// RVA: -1
	public object Remove(object cancelledIndex) { }

	// RVA: -1
	public object Replace(object index, object timingData, object styleData) { }

	// RVA: -1
	public object RemoveAll(object ve) { }

	// RVA: -1
	public object RemoveAll() { }

	// RVA: -1
	public object GetActivePropertiesForElement(object ve, object outProperties) { }

}

// Namespace: 
private class EqualityComparer
{

	// Methods

	// RVA: 0x7672708
	public object Equals(object x, object y) { }

	// RVA: 0x7672718
	public object GetHashCode(object obj) { }

	// RVA: 0x7672700
	public object .ctor() { }

}

// Namespace: 
private struct ElementPropertyPair
{

	// Fields
	public static readonly object Comparer; // 0x0
	public readonly object element; // 0xFFFFFFFFFFFFFFF8
	public readonly object property; // 0x0

	// Methods

	// RVA: 0x767266C
	public object .ctor(object element, object property) { }

	// RVA: 0x7672684
	private static object .cctor() { }

}

// Namespace: 
private abstract class Values
{

	// Methods

	// RVA: -1
	public abstract object CancelAllAnimations() { }

	// RVA: -1
	public abstract object CancelAllAnimations(object ve) { }

	// RVA: -1
	public abstract object CancelAnimation(object ve, object id) { }

	// RVA: -1
	public abstract object UpdateAnimation(object ve, object id) { }

	// RVA: -1
	public abstract object GetAllAnimations(object ve, object outPropertyIds) { }

	// RVA: -1
	public abstract object Update(object currentTimeMs) { }

	// RVA: -1
	protected abstract object UpdateValues() { }

	// RVA: -1
	protected abstract object UpdateComputedStyle() { }

	// RVA: -1
	protected abstract object UpdateComputedStyle(object i) { }

	// RVA: 0x7672778
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__11_0() { }

}

// Namespace: 
private class TransitionEventsFrameState
{

	// Fields
	private static readonly object k_EventQueuePool; // 0x0
	public readonly object elementPropertyStateDelta; // 0x0
	public readonly object elementPropertyQueuedEvents; // 0x0
	public object panel; // 0x0
	private object m_ChangesCount; // 0x0

	// Methods

	// RVA: -1
	public static object GetPooledQueue() { }

	// RVA: -1
	public object RegisterChange() { }

	// RVA: -1
	public object UnregisterChange() { }

	// RVA: -1
	public object StateChanged() { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
public struct TimingData
{

	// Fields
	public object startTimeMs; // 0x0
	public object durationMs; // 0x0
	public object easingCurve; // 0x0
	public object easedProgress; // 0x0
	public object reversingShorteningFactor; // 0x0
	public object isStarted; // 0x0
	public object delayMs; // 0x0
}

// Namespace: 
public struct StyleData
{

	// Fields
	public object startValue; // 0x0
	public object endValue; // 0x0
	public object reversingAdjustedStartValue; // 0x0
	public object currentValue; // 0x0
}

// Namespace: 
public struct EmptyData
{

	// Fields
	public static object Default; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
private abstract class Values<T0>
{

	// Fields
	private object m_CurrentTimeMs; // 0x0
	private object m_CurrentFrameEventsState; // 0x0
	private object m_NextFrameEventsState; // 0x0
	public object running; // 0x0
	public object completed; // 0x0

	// Properties
	public object isEmpty { get; }
	public abstract object SameFunc { get; }

	// Methods

	// RVA: -1
	public object get_isEmpty() { }

	// RVA: -1
	public abstract object get_SameFunc() { }

	// RVA: -1
	protected virtual object ConvertUnits(object owner, object prop, object a, object b) { }

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	private object SwapFrameStates() { }

	// RVA: -1
	private object QueueEvent(object evt, object epp) { }

	// RVA: -1
	private object ClearEventQueue(object epp) { }

	// RVA: -1
	private object QueueTransitionRunEvent(object ve, object runningIndex) { }

	// RVA: -1
	private object QueueTransitionStartEvent(object ve, object runningIndex) { }

	// RVA: -1
	private object QueueTransitionEndEvent(object ve, object runningIndex) { }

	// RVA: -1
	private object QueueTransitionCancelEvent(object ve, object runningIndex, object panelElapsedMs) { }

	// RVA: -1
	private object SendTransitionCancelEvent(object ve, object runningIndex, object panelElapsedMs) { }

	// RVA: -1
	public sealed override object CancelAllAnimations() { }

	// RVA: -1
	public sealed override object CancelAllAnimations(object ve) { }

	// RVA: -1
	public sealed override object CancelAnimation(object ve, object id) { }

	// RVA: -1
	public sealed override object UpdateAnimation(object ve, object id) { }

	// RVA: -1
	public sealed override object GetAllAnimations(object ve, object outPropertyIds) { }

	// RVA: -1
	private object ComputeReversingShorteningFactor(object oldIndex) { }

	// RVA: -1
	private object ComputeReversingDuration(object newTransitionDurationMs, object newReversingShorteningFactor) { }

	// RVA: -1
	private object ComputeReversingDelay(object delayMs, object newReversingShorteningFactor) { }

	// RVA: -1
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve, object currentTimeMs) { }

	// RVA: -1
	private object ForceComputedStyleEndValue(object runningIndex) { }

	// RVA: -1
	public sealed override object Update(object currentTimeMs) { }

	// RVA: -1
	private object ProcessEventQueue() { }

	// RVA: -1
	private object UpdateProgress(object currentTimeMs) { }

}

// Namespace: 
private class ValuesFloat
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x7672780
	public override object get_SameFunc() { }

	// RVA: 0x7672788
	private static object IsSame(object a, object b) { }

	// RVA: 0x7672820
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x7672830
	protected sealed override object UpdateValues() { }

	// RVA: 0x76728C8
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x76729D0
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7672ABC
	public object .ctor() { }

}

// Namespace: 
private class ValuesInt
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x7672B60
	public override object get_SameFunc() { }

	// RVA: 0x7672B68
	private static object IsSame(object a, object b) { }

	// RVA: 0x7672B74
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x7672C98
	protected sealed override object UpdateValues() { }

	// RVA: 0x7672D48
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7672E50
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7672F3C
	public object .ctor() { }

}

// Namespace: 
private class ValuesLength
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x7672FE0
	public override object get_SameFunc() { }

	// RVA: 0x7672FE8
	private static object IsSame(object a, object b) { }

	// RVA: 0x7673094
	protected sealed override object ConvertUnits(object owner, object prop, object a, object b) { }

	// RVA: 0x76730C8
	internal static object Lerp(object a, object b, object t) { }

	// RVA: 0x7673104
	protected sealed override object UpdateValues() { }

	// RVA: 0x76731CC
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x76732D4
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x76733C0
	public object .ctor() { }

}

// Namespace: 
private class ValuesColor
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x7673464
	public override object get_SameFunc() { }

	// RVA: 0x767346C
	private static object IsSame(object c, object d) { }

	// RVA: 0x76735F0
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x7673628
	protected sealed override object UpdateValues() { }

	// RVA: 0x76736C0
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x76737D0
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x76738C0
	public object .ctor() { }

}

// Namespace: 
private abstract class ValuesDiscrete<T0>
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x0

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: -1
	public override object get_SameFunc() { }

	// RVA: -1
	private static object IsSame(object a, object b) { }

	// RVA: -1
	private static object Lerp(object a, object b, object t) { }

	// RVA: -1
	protected sealed override object UpdateValues() { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private class ValuesBackground
{

	// Methods

	// RVA: 0x7673964
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7673A84
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7673B8C
	public object .ctor() { }

}

// Namespace: 
private class ValuesFontDefinition
{

	// Methods

	// RVA: 0x7673BE4
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7673CF0
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7673DDC
	public object .ctor() { }

}

// Namespace: 
private class ValuesFont
{

	// Methods

	// RVA: 0x7673E34
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7673F3C
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7674028
	public object .ctor() { }

}

// Namespace: 
private class ValuesTextShadow
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x7674080
	public override object get_SameFunc() { }

	// RVA: 0x7674088
	private static object IsSame(object a, object b) { }

	// RVA: 0x76740D0
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x7674118
	protected sealed override object UpdateValues() { }

	// RVA: 0x7674228
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x767435C
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7674478
	public object .ctor() { }

}

// Namespace: 
private class ValuesScale
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x767451C
	public override object get_SameFunc() { }

	// RVA: 0x7674524
	private static object IsSame(object a, object b) { }

	// RVA: 0x767457C
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7674688
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7674774
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x76747E4
	protected sealed override object UpdateValues() { }

	// RVA: 0x76748D8
	public object .ctor() { }

}

// Namespace: 
private class ValuesRotate
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x767497C
	public override object get_SameFunc() { }

	// RVA: 0x7674984
	private static object IsSame(object a, object b) { }

	// RVA: 0x7674A30
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7674B5C
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7674C70
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x7674D38
	protected sealed override object UpdateValues() { }

	// RVA: 0x7674E8C
	public object .ctor() { }

}

// Namespace: 
private class ValuesTranslate
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x7674F30
	public override object get_SameFunc() { }

	// RVA: 0x7674F38
	private static object IsSame(object a, object b) { }

	// RVA: 0x7674FB4
	protected sealed override object ConvertUnits(object owner, object prop, object a, object b) { }

	// RVA: 0x7674FE0
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x767510C
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7675220
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x76752A0
	protected sealed override object UpdateValues() { }

	// RVA: 0x76753AC
	public object .ctor() { }

}

// Namespace: 
private class ValuesTransformOrigin
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x7675450
	public override object get_SameFunc() { }

	// RVA: 0x7675458
	private static object IsSame(object a, object b) { }

	// RVA: 0x76754C0
	protected sealed override object ConvertUnits(object owner, object prop, object a, object b) { }

	// RVA: 0x76754EC
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7675618
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x767572C
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x76757A8
	protected sealed override object UpdateValues() { }

	// RVA: 0x76758A8
	public object .ctor() { }

}

// Namespace: 
private class ValuesBackgroundPosition
{

	// Methods

	// RVA: 0x767594C
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7675A70
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7675B64
	public object .ctor() { }

}

// Namespace: 
private class ValuesBackgroundRepeat
{

	// Methods

	// RVA: 0x7675BBC
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7675CC4
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x7675DB0
	public object .ctor() { }

}

// Namespace: 
private class ValuesBackgroundSize
{

	// Fields
	private readonly object <SameFunc>k__BackingField; // 0x80

	// Properties
	public override object SameFunc { get; }

	// Methods

	// RVA: 0x7675E08
	public override object get_SameFunc() { }

	// RVA: 0x7675E10
	private static object IsSame(object a, object b) { }

	// RVA: 0x7675E58
	protected sealed override object ConvertUnits(object owner, object prop, object a, object b) { }

	// RVA: 0x7675E84
	protected sealed override object UpdateComputedStyle() { }

	// RVA: 0x7675FB0
	protected sealed override object UpdateComputedStyle(object i) { }

	// RVA: 0x76760C4
	private static object Lerp(object a, object b, object t) { }

	// RVA: 0x76761B8
	protected sealed override object UpdateValues() { }

	// RVA: 0x7676380
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class StylePropertyAnimationSystem
{

	// Fields
	private object m_CurrentTimeMs; // 0x8
	private object m_Floats; // 0x10
	private object m_Ints; // 0x18
	private object m_Lengths; // 0x20
	private object m_Colors; // 0x28
	private object m_Backgrounds; // 0x30
	private object m_FontDefinitions; // 0x38
	private object m_Fonts; // 0x40
	private object m_TextShadows; // 0x48
	private object m_Scale; // 0x50
	private object m_Rotate; // 0x58
	private object m_Translate; // 0x60
	private object m_TransformOrigin; // 0x68
	private object m_BackgroundPosition; // 0x70
	private object m_BackgroundRepeat; // 0x78
	private object m_BackgroundSize; // 0x80
	private readonly object m_AllValues; // 0x88
	private readonly object m_PropertyToValues; // 0x90

	// Methods

	// RVA: 0x7670E08
	public object .ctor() { }

	// RVA: -1
	private object GetOrCreate(object values) { }

	// RVA: -1
	private object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve, object values) { }

	// RVA: 0x7670F10
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7670FE4
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76710BC
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671194
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x76712B0
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671398
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671488
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671560
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671658
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671748
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671840
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671938
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671A30
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671B20
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671BF8
	public object StartTransition(object owner, object prop, object startValue, object endValue, object durationMs, object delayMs, object easingCurve) { }

	// RVA: 0x7671CF0
	public object CancelAllAnimations() { }

	// RVA: 0x7671EA0
	public object CancelAllAnimations(object owner) { }

	// RVA: 0x76721C4
	public object CancelAnimation(object owner, object id) { }

	// RVA: 0x767228C
	public object UpdateAnimation(object owner, object id) { }

	// RVA: 0x7672354
	public object GetAllAnimations(object owner, object propertyIds) { }

	// RVA: -1
	private object UpdateTracking(object values) { }

	// RVA: 0x76724DC
	private object CurrentTimeMs() { }

	// RVA: 0x76724E4
	public object Update() { }

}

// Namespace: UnityEngine.UIElements
public struct StylePropertyName
{

	// Fields
	private readonly object <id>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private readonly object <name>k__BackingField; // 0x0

	// Properties
	internal object id { get; }
	private object name { get; }

	// Methods

	// RVA: 0x76764B4
	internal object get_id() { }

	// RVA: 0x76764C4
	private object get_name() { }

	// RVA: 0x76764D4
	internal static object StylePropertyIdFromString(object name) { }

	// RVA: 0x76765A4
	internal object .ctor(object stylePropertyId) { }

	// RVA: 0x767676C
	public object .ctor(object name) { }

	// RVA: 0x7676858
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x7676864
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x7676870
	public static object op_Implicit(object name) { }

	// RVA: 0x7676948
	public override object GetHashCode() { }

	// RVA: 0x7676958
	public override object Equals(object other) { }

	// RVA: 0x76769FC
	public object Equals(object other) { }

	// RVA: 0x7676AC0
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements
internal enum Salt
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TagNameSalt;
	public const object IdSalt;
	public const object ClassSalt;
}

// Namespace: 
public struct <hashes>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.UIElements
internal struct Hashes
{

	// Fields
	public const object kSize;
	public object hashes; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
private struct PseudoStateData
{

	// Fields
	public readonly object state; // 0xFFFFFFFFFFFFFFF8
	public readonly object negate; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x76770F4
	public object .ctor(object state, object negate) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__24_0; // 0x8
	public static object <>9__27_0; // 0x10

	// Methods

	// RVA: 0x767798C
	private static object .cctor() { }

	// RVA: 0x76779EC
	public object .ctor() { }

	// RVA: 0x76779F4
	internal object <ToString>b__24_0(object x) { }

	// RVA: 0x7677A40
	internal object <CalculateHashes>b__27_0(object p) { }

}

// Namespace: UnityEngine.UIElements
internal class StyleComplexSelector
{

	// Fields
	public object ancestorHashes; // 0x8
	private object m_Specificity; // 0x18
	private object <rule>k__BackingField; // 0x20
	private object m_isSimple; // 0x28
	private object m_Selectors; // 0x30
	internal object ruleIndex; // 0x38
	internal object nextInTable; // 0x40
	internal object orderInStyleSheet; // 0x48
	private static object s_PseudoStates; // 0x0
	private static object m_HashList; // 0x8

	// Properties
	public object specificity { get; }
	public object rule { get; set; }
	public object isSimple { get; }
	public object selectors { get; set; }

	// Methods

	// RVA: 0x7676AD0
	public object get_specificity() { }

	// RVA: 0x7676AD8
	public object get_rule() { }

	// RVA: 0x7676AE0
	internal object set_rule(object value) { }

	// RVA: 0x7676AE8
	public object get_isSimple() { }

	// RVA: 0x7676AF0
	public object get_selectors() { }

	// RVA: 0x7676AF8
	internal object set_selectors(object value) { }

	// RVA: 0x7676B28
	public object OnBeforeSerialize() { }

	// RVA: 0x7676B2C
	public virtual object OnAfterDeserialize() { }

	// RVA: 0x7676B5C
	internal object CachePseudoStateMasks() { }

	// RVA: 0x7677118
	public override object ToString() { }

	// RVA: 0x767728C
	private static object StyleSelectorPartCompare(object x, object y) { }

	// RVA: 0x76772DC
	internal object CalculateHashes() { }

	// RVA: 0x76778BC
	public object .ctor() { }

	// RVA: 0x76778C4
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class StyleProperty
{

	// Fields
	private object m_Name; // 0x8
	private object m_Line; // 0x10
	private object m_Values; // 0x18
	internal object isCustomProperty; // 0x20
	internal object requireVariableResolve; // 0x21

	// Properties
	public object name { get; }
	public object values { get; }

	// Methods

	// RVA: 0x7677A58
	public object get_name() { }

	// RVA: 0x7677A60
	public object get_values() { }

	// RVA: 0x7677A68
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class StyleRule
{

	// Fields
	private object m_Properties; // 0x8
	internal object line; // 0x10
	internal object customPropertiesCount; // 0x14

	// Properties
	public object properties { get; }

	// Methods

	// RVA: 0x7677A70
	public object get_properties() { }

	// RVA: 0x7677A78
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__10_0; // 0x8

	// Methods

	// RVA: 0x7677BF4
	private static object .cctor() { }

	// RVA: 0x7677C54
	public object .ctor() { }

	// RVA: 0x7677C5C
	internal object <ToString>b__10_0(object p) { }

}

// Namespace: UnityEngine.UIElements
internal class StyleSelector
{

	// Fields
	private object m_Parts; // 0x8
	private object m_PreviousRelationship; // 0x10
	internal object pseudoStateMask; // 0x14
	internal object negatedPseudoStateMask; // 0x18

	// Properties
	public object parts { get; set; }
	public object previousRelationship { get; set; }

	// Methods

	// RVA: 0x7677100
	public object get_parts() { }

	// RVA: 0x7677A80
	internal object set_parts(object value) { }

	// RVA: 0x7677A88
	public object get_previousRelationship() { }

	// RVA: 0x7677A90
	internal object set_previousRelationship(object value) { }

	// RVA: 0x7677A98
	public override object ToString() { }

	// RVA: 0x7677BE4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal struct StyleSelectorPart
{

	// Fields
	private object m_Value; // 0xFFFFFFFFFFFFFFF8
	private object m_Type; // 0x0
	internal object tempData; // 0x8

	// Properties
	public object value { get; }
	public object type { get; set; }

	// Methods

	// RVA: 0x7677110
	public object get_value() { }

	// RVA: 0x7677108
	public object get_type() { }

	// RVA: 0x7677F28
	internal object set_type(object value) { }

	// RVA: 0x7677C64
	public override object ToString() { }

	// RVA: 0x7677F40
	public static object CreateClass(object className) { }

	// RVA: 0x7677F58
	public static object CreateId(object Id) { }

	// RVA: 0x7677F70
	public static object CreatePredicate(object predicate) { }

}

// Namespace: UnityEngine.UIElements
internal enum StyleSelectorRelationship
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Child;
	public const object Descendent;
}

// Namespace: UnityEngine.UIElements
internal enum StyleSelectorType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Wildcard;
	public const object Type;
	public const object Class;
	public const object PseudoClass;
	public const object RecursivePseudoClass;
	public const object ID;
	public const object Predicate;
}

// Namespace: 
internal struct ImportStruct
{

	// Fields
	public object styleSheet; // 0xFFFFFFFFFFFFFFF8
	public object mediaQueries; // 0x0
}

// Namespace: UnityEngine.UIElements
public class StyleSheet
{

	// Fields
	private object m_ImportedWithErrors; // 0x10
	private object m_ImportedWithWarnings; // 0x11
	private object m_Rules; // 0x18
	private object m_ComplexSelectors; // 0x20
	internal object floats; // 0x28
	internal object dimensions; // 0x30
	internal object colors; // 0x38
	internal object strings; // 0x40
	internal object assets; // 0x48
	internal object imports; // 0x50
	private object m_FlattenedImportedStyleSheets; // 0x58
	private object m_ContentHash; // 0x60
	internal object scalableImages; // 0x68
	internal object orderedNameSelectors; // 0x70
	internal object orderedTypeSelectors; // 0x78
	internal object orderedClassSelectors; // 0x80
	private object m_IsDefaultStyleSheet; // 0x88
	private static object kCustomPropertyMarker; // 0x0

	// Properties
	public object importedWithErrors { get; set; }
	public object importedWithWarnings { get; set; }
	internal object rules { get; set; }
	internal object complexSelectors { get; set; }
	internal object flattenedRecursiveImports { get; }
	public object contentHash { get; set; }
	internal object isDefaultStyleSheet { get; set; }

	// Methods

	// RVA: 0x7677F88
	public object get_importedWithErrors() { }

	// RVA: 0x7677F90
	internal object set_importedWithErrors(object value) { }

	// RVA: 0x7677F98
	public object get_importedWithWarnings() { }

	// RVA: 0x7677FA0
	internal object set_importedWithWarnings(object value) { }

	// RVA: 0x7677FA8
	internal object get_rules() { }

	// RVA: 0x7677FB0
	internal object set_rules(object value) { }

	// RVA: 0x767867C
	internal object get_complexSelectors() { }

	// RVA: 0x7678684
	internal object set_complexSelectors(object value) { }

	// RVA: 0x767868C
	internal object get_flattenedRecursiveImports() { }

	// RVA: 0x7678694
	public object get_contentHash() { }

	// RVA: 0x767869C
	public object set_contentHash(object value) { }

	// RVA: 0x76786A4
	internal object get_isDefaultStyleSheet() { }

	// RVA: 0x76786AC
	internal object set_isDefaultStyleSheet(object value) { }

	// RVA: -1
	private static object TryCheckAccess(object list, object type, object handle, object value) { }

	// RVA: -1
	private static object CheckAccess(object list, object type, object handle) { }

	// RVA: 0x7678838
	internal virtual object OnEnable() { }

	// RVA: 0x767883C
	internal object FlattenImportedStyleSheetsRecursive() { }

	// RVA: 0x76788BC
	private object FlattenImportedStyleSheetsRecursive(object sheet) { }

	// RVA: 0x7677FB8
	private object SetupReferences() { }

	// RVA: 0x7678B88
	internal object ReadKeyword(object handle) { }

	// RVA: 0x7678B90
	internal object ReadFloat(object handle) { }

	// RVA: 0x7665148
	internal object TryReadFloat(object handle, object value) { }

	// RVA: 0x7678C6C
	internal object ReadDimension(object handle) { }

	// RVA: 0x7678D64
	internal object TryReadDimension(object handle, object value) { }

	// RVA: 0x7678E94
	internal object ReadColor(object handle) { }

	// RVA: 0x76655D4
	internal object TryReadColor(object handle, object value) { }

	// RVA: 0x7678F1C
	internal object ReadString(object handle) { }

	// RVA: 0x7678FA4
	internal object TryReadString(object handle, object value) { }

	// RVA: 0x767903C
	internal object ReadEnum(object handle) { }

	// RVA: 0x76790C4
	internal object TryReadEnum(object handle, object value) { }

	// RVA: 0x767915C
	internal object ReadVariable(object handle) { }

	// RVA: 0x76791E4
	internal object TryReadVariable(object handle, object value) { }

	// RVA: 0x767927C
	internal object ReadResourcePath(object handle) { }

	// RVA: 0x7679304
	internal object TryReadResourcePath(object handle, object value) { }

	// RVA: 0x767939C
	internal object ReadAssetReference(object handle) { }

	// RVA: 0x7679424
	internal object ReadMissingAssetReferenceUrl(object handle) { }

	// RVA: 0x76794AC
	internal object TryReadAssetReference(object handle, object value) { }

	// RVA: 0x7679544
	internal object ReadFunction(object handle) { }

	// RVA: 0x767954C
	internal object ReadFunctionName(object handle) { }

	// RVA: 0x7679834
	internal object ReadScalableImage(object handle) { }

	// RVA: 0x7678AA0
	private static object CustomStartsWith(object originalString, object pattern) { }

	// RVA: 0x76798BC
	public object .ctor() { }

	// RVA: 0x76798C4
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal enum StyleValueFunction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Var;
	public const object Env;
	public const object LinearGradient;
}

// Namespace: UnityEngine.UIElements
internal static class StyleValueFunctionExtension
{

	// Methods

	// RVA: 0x7679738
	public static object ToUssString(object svf) { }

}

// Namespace: UnityEngine.UIElements
internal struct StyleValueHandle
{

	// Fields
	private object m_ValueType; // 0xFFFFFFFFFFFFFFF8
	internal object valueIndex; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object valueType { get; set; }

	// Methods

	// RVA: 0x76655CC
	public object get_valueType() { }

	// RVA: 0x7679974
	internal object set_valueType(object value) { }

}

// Namespace: UnityEngine.UIElements
internal enum StyleValueKeyword
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Inherit;
	public const object Initial;
	public const object Auto;
	public const object Unset;
	public const object True;
	public const object False;
	public const object None;
}

// Namespace: UnityEngine.UIElements
internal static class StyleValueKeywordExtension
{

	// Methods

	// RVA: 0x7679984
	public static object ToUssString(object svk) { }

}

// Namespace: UnityEngine.UIElements
internal enum StyleValueType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Invalid;
	public const object Keyword;
	public const object Float;
	public const object Dimension;
	public const object Color;
	public const object ResourcePath;
	public const object AssetReference;
	public const object Enum;
	public const object Variable;
	public const object String;
	public const object Function;
	public const object CommaSeparator;
	public const object ScalableImage;
	public const object MissingAssetReference;
}

// Namespace: UnityEngine.UIElements
internal struct StyleVariable
{

	// Fields
	public readonly object name; // 0xFFFFFFFFFFFFFFF8
	public readonly object sheet; // 0x0
	public readonly object handles; // 0x8

	// Methods

	// RVA: 0x7679AE8
	public object .ctor(object name, object sheet, object handles) { }

	// RVA: 0x7679B00
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
internal class StyleVariableContext
{

	// Fields
	public static readonly object none; // 0x0
	private object m_VariableHash; // 0x8
	private object m_Variables; // 0x10
	private object m_SortedHash; // 0x18

	// Methods

	// RVA: 0x7679BF0
	public object Add(object sv) { }

	// RVA: 0x7679E30
	public object AddInitialRange(object other) { }

	// RVA: 0x7679F70
	public object Clear() { }

	// RVA: 0x767A024
	public object .ctor() { }

	// RVA: 0x767A0F4
	public object .ctor(object other) { }

	// RVA: 0x767A1F4
	public object TryFindVariable(object name, object v) { }

	// RVA: 0x767A304
	public object GetVariableHash() { }

	// RVA: 0x767A30C
	private static object .cctor() { }

}

// Namespace: 
private enum Result
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Valid;
	public const object Invalid;
	public const object NotFound;
}

// Namespace: 
private struct ResolveContext
{

	// Fields
	public object sheet; // 0xFFFFFFFFFFFFFFF8
	public object handles; // 0x0
}

// Namespace: UnityEngine.UIElements
internal class StyleVariableResolver
{

	// Fields
	internal const object kMaxResolves;
	private static object s_SyntaxParser; // 0x0
	private object m_Matcher; // 0x8
	private object m_ResolvedValues; // 0x10
	private object m_ResolvedVarStack; // 0x18
	private object m_Property; // 0x20
	private object m_ContextStack; // 0x28
	private object m_CurrentContext; // 0x30
	private object <variableContext>k__BackingField; // 0x40

	// Properties
	private object currentSheet { get; }
	private object currentHandles { get; }
	public object resolvedValues { get; }
	public object variableContext { get; set; }

	// Methods

	// RVA: 0x767A368
	private object get_currentSheet() { }

	// RVA: 0x767A370
	private object get_currentHandles() { }

	// RVA: 0x767A378
	public object get_resolvedValues() { }

	// RVA: 0x767A380
	public object get_variableContext() { }

	// RVA: 0x767A388
	public object set_variableContext(object value) { }

	// RVA: 0x767A390
	public object Init(object property, object sheet, object handles) { }

	// RVA: 0x767A4A0
	private object PushContext(object sheet, object handles) { }

	// RVA: 0x767A518
	private object PopContext() { }

	// RVA: 0x767A5AC
	public object AddValue(object handle) { }

	// RVA: 0x767A6E0
	public object ResolveVarFunction(object index) { }

	// RVA: 0x767A8F0
	private object ResolveVarFunction(object index, object argc, object varName) { }

	// RVA: 0x767B17C
	public object ValidateResolvedValues() { }

	// RVA: 0x767AA94
	private object ResolveVariable(object variableName) { }

	// RVA: 0x767AE74
	private object ResolveFallback(object index) { }

	// RVA: 0x767A7C0
	private static object ParseVarFunction(object sheet, object handles, object index, object argCount, object variableName) { }

	// RVA: 0x767B33C
	public object .ctor() { }

	// RVA: 0x767B480
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public class ThemeStyleSheet
{

	// Methods

	// RVA: 0x767B538
	internal override object OnEnable() { }

	// RVA: 0x767B568
	public object .ctor() { }

}

// Namespace: 
public class UxmlFactory
{

	// Properties
	public override object uxmlName { get; }
	public override object uxmlQualifiedName { get; }

	// Methods

	// RVA: 0x767B674
	public override object get_uxmlName() { }

	// RVA: 0x767B6B8
	public override object get_uxmlQualifiedName() { }

	// RVA: 0x767B760
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Template; // 0x70

	// Methods

	// RVA: 0x767B7B8
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x767C860
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class TemplateContainer
{

	// Fields
	private object <templateId>k__BackingField; // 0x3D0
	private object m_ContentContainer; // 0x3D8
	private object m_TemplateSource; // 0x3E0

	// Properties
	public object templateId { get; set; }
	internal object templateSource { set; }
	public override object contentContainer { get; }

	// Methods

	// RVA: 0x767B5F0
	public object get_templateId() { }

	// RVA: 0x767B5F8
	private object set_templateId(object value) { }

	// RVA: 0x767B600
	internal object set_templateSource(object value) { }

	// RVA: 0x767B608
	public object .ctor() { }

	// RVA: 0x767B634
	public object .ctor(object templateId) { }

	// RVA: 0x767B664
	public override object get_contentContainer() { }

	// RVA: 0x767B66C
	internal object SetContentContainer(object content) { }

}

// Namespace: UnityEngine.UIElements
public class PanelTextSettings
{

	// Fields
	private static object s_DefaultPanelTextSettings; // 0x0
	internal static object EditorGUIUtilityLoad; // 0x8
	internal static object GetCurrentLanguage; // 0x10
	internal static readonly object s_DefaultEditorPanelTextSettingPath; // 0x18

	// Properties
	internal static object defaultPanelTextSettings { get; }

	// Methods

	// RVA: 0x767CA44
	internal static object get_defaultPanelTextSettings() { }

	// RVA: 0x767CC10
	internal static object UpdateLocalizationFontAsset() { }

	// RVA: 0x767D264
	internal object GetCachedFontAsset(object font) { }

	// RVA: 0x767D26C
	public object .ctor() { }

	// RVA: 0x767D274
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class TextEditingManipulator
{

	// Fields
	private object m_TextElement; // 0x8
	internal object editingEventHandler; // 0x10
	internal object editingUtilities; // 0x18
	private object m_TouchScreenTextFieldInitialized; // 0x20
	private object m_HardwareKeyboardPoller; // 0x28

	// Properties
	private object touchScreenTextFieldChanged { get; }

	// Methods

	// RVA: 0x767D2E0
	private object get_touchScreenTextFieldChanged() { }

	// RVA: 0x767D390
	public object .ctor(object textElement) { }

	// RVA: 0x767D53C
	private object InitTextEditorEventHandler() { }

	// RVA: 0x767D618
	internal object ExecuteDefaultActionAtTarget(object evt) { }

	// RVA: 0x767D7E4
	private object OnFocusInEvent(object _) { }

	// RVA: 0x767DC0C
	private object OnFocusOutEvent(object _) { }

	// RVA: 0x767DCEC
	private object <OnFocusInEvent>b__10_0() { }

}

// Namespace: UnityEngine.UIElements
internal class TextSelectingManipulator
{

	// Fields
	internal object m_SelectingUtilities; // 0x8
	private object selectAllOnMouseUp; // 0x10
	private object m_TextElement; // 0x18
	private object m_ClickStartPosition; // 0x20
	private object m_Dragged; // 0x28
	private object m_IsClicking; // 0x29
	private const object k_DragThresholdSqr;
	private object m_ConsecutiveMouseDownCount; // 0x2C
	private object m_LastMouseDownTimeStamp; // 0x30
	private readonly object m_ImguiEvent; // 0x38

	// Properties
	internal object isClicking { get; set; }
	internal object cursorIndex { get; set; }
	internal object selectIndex { get; set; }

	// Methods

	// RVA: 0x767DDF0
	internal object get_isClicking() { }

	// RVA: 0x767DDF8
	internal object set_isClicking(object value) { }

	// RVA: 0x767DE0C
	public object .ctor(object textElement) { }

	// RVA: 0x767E08C
	internal object get_cursorIndex() { }

	// RVA: 0x767E0A4
	internal object set_cursorIndex(object value) { }

	// RVA: 0x767E0C8
	internal object get_selectIndex() { }

	// RVA: 0x767E0E0
	internal object set_selectIndex(object value) { }

	// RVA: 0x767E104
	private object OnRevealCursor() { }

	// RVA: 0x767E12C
	private object OnSelectIndexChange() { }

	// RVA: 0x767E344
	private object OnCursorIndexChange() { }

	// RVA: 0x767E538
	internal object RevealCursor() { }

	// RVA: 0x767E320
	internal object HasSelection() { }

	// RVA: 0x767E55C
	internal object HasFocus() { }

	// RVA: 0x767E64C
	internal object ExecuteDefaultActionAtTarget(object evt) { }

	// RVA: 0x767E898
	private object OnFocusEvent(object evt) { }

	// RVA: 0x767EBBC
	private object OnBlurEvent(object evt) { }

	// RVA: 0x767F124
	private object OnKeyDown(object evt) { }

	// RVA: 0x767EC94
	private object OnPointerDownEvent(object evt) { }

	// RVA: 0x767F200
	private object OnPointerMoveEvent(object evt) { }

	// RVA: 0x767F4C8
	private object OnPointerUpEvent(object evt) { }

	// RVA: 0x767F5A4
	private object OnValidateCommandEvent(object evt) { }

	// RVA: 0x767F790
	private object OnExecuteCommandEvent(object evt) { }

	// RVA: 0x767F938
	private object MoveDistanceQualifiesForDrag(object start, object current) { }

}

// Namespace: UnityEngine.UIElements
internal class UITKTextHandle
{

	// Fields
	private object <MeasuredSizes>k__BackingField; // 0x2C
	private object <RoundedSizes>k__BackingField; // 0x34
	private object m_TextElement; // 0x40
	internal object isOverridingCursor; // 0x48
	internal object currentLinkIDHash; // 0x4C
	internal object hasLinkTag; // 0x50
	internal object hasATag; // 0x51
	internal static readonly object k_MinPadding; // 0x0

	// Properties
	public object MeasuredSizes { get; set; }
	public object RoundedSizes { get; set; }

	// Methods

	// RVA: 0x767F95C
	public object .ctor(object te) { }

	// RVA: 0x767F9DC
	public object get_MeasuredSizes() { }

	// RVA: 0x767F9E4
	public object set_MeasuredSizes(object value) { }

	// RVA: 0x767F9EC
	public object get_RoundedSizes() { }

	// RVA: 0x767F9F4
	public object set_RoundedSizes(object value) { }

	// RVA: 0x767F9FC
	public object ComputeTextWidth(object textToMeasure, object wordWrap, object width, object height) { }

	// RVA: 0x767FE7C
	public object ComputeTextHeight(object textToMeasure, object width, object height) { }

	// RVA: 0x767FF2C
	public object Update() { }

	// RVA: 0x7680B40
	private object ATagOnPointerUp(object pue) { }

	// RVA: 0x7680D10
	private object ATagOnPointerOver(object _) { }

	// RVA: 0x7680D18
	private object ATagOnPointerMove(object pme) { }

	// RVA: 0x7681078
	private object ATagOnPointerOut(object _) { }

	// RVA: 0x7681080
	internal object LinkTagOnPointerDown(object pde) { }

	// RVA: 0x76813AC
	internal object LinkTagOnPointerUp(object pue) { }

	// RVA: 0x76816D8
	internal object LinkTagOnPointerMove(object pme) { }

	// RVA: 0x7681D34
	private object LinkTagOnPointerOut(object poe) { }

	// RVA: 0x76806A8
	private object HandleLinkTag() { }

	// RVA: 0x7680054
	private object HandleATag() { }

	// RVA: 0x7681F5C
	private object GetTextOverflowMode() { }

	// RVA: 0x767FABC
	internal object ConvertUssToTextGenerationSettings(object tgs) { }

	// RVA: 0x7682028
	internal object TextLibraryCanElide() { }

	// RVA: 0x768234C
	internal object GetTextEffectPadding(object fontAsset) { }

	// RVA: 0x76826E0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal static class TextUtilities
{

	// Methods

	// RVA: 0x7682730
	internal static object MeasureVisualElementTextSize(object te, object textToMeasure, object width, object widthMode, object height, object heightMode) { }

	// RVA: 0x7682150
	internal static object GetFontAsset(object ve) { }

	// RVA: 0x76829B0
	internal static object IsFontAssigned(object ve) { }

	// RVA: 0x7682064
	internal static object GetTextSettingsFrom(object ve) { }

	// RVA: 0x7682610
	internal static object ConvertPixelUnitsToTextCoreRelativeUnits(object ve, object fontAsset) { }

	// RVA: 0x7682A98
	internal static object GetTextCoreSettingsForElement(object ve) { }

}

// Namespace: 
public class UxmlFactory
{

	// Methods

	// RVA: 0x7688218
	public object .ctor() { }

}

// Namespace: 
public class UxmlTraits
{

	// Fields
	private object m_Text; // 0x70
	private object m_EnableRichText; // 0x78
	private object m_DisplayTooltipWhenElided; // 0x80

	// Methods

	// RVA: 0x7688270
	public override object Init(object ve, object bag, object cc) { }

	// RVA: 0x76884AC
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class TextElement
{

	// Fields
	public static readonly object ussClassName; // 0x0
	private object <uitkTextHandle>k__BackingField; // 0x3D0
	private object m_Text; // 0x3D8
	private object m_EnableRichText; // 0x3E0
	private object m_ParseEscapeSequences; // 0x3E1
	private object m_DisplayTooltipWhenElided; // 0x3E2
	private object <isElided>k__BackingField; // 0x3E3
	internal static readonly object k_EllipsisText; // 0x8
	internal object elidedText; // 0x3E8
	private object m_WasElided; // 0x3F0
	internal object editingManipulator; // 0x3F8
	private object m_Multiline; // 0x400
	internal object m_TouchScreenKeyboard; // 0x408
	internal object m_KeyboardType; // 0x410
	private object m_HideMobileInput; // 0x414
	private object m_IsReadOnly; // 0x415
	private object m_MaxLength; // 0x418
	private object <UnityEngine.UIElements.ITextEdition.isDelayed>k__BackingField; // 0x41C
	private object <UnityEngine.UIElements.ITextEdition.AcceptCharacter>k__BackingField; // 0x420
	private object <UnityEngine.UIElements.ITextEdition.UpdateScrollOffset>k__BackingField; // 0x428
	private object <UnityEngine.UIElements.ITextEdition.UpdateValueFromText>k__BackingField; // 0x430
	private object <UnityEngine.UIElements.ITextEdition.UpdateTextFromValue>k__BackingField; // 0x438
	private object <UnityEngine.UIElements.ITextEdition.MoveFocusToCompositeRoot>k__BackingField; // 0x440
	private object m_RenderedText; // 0x448
	private object m_OriginalText; // 0x450
	private object m_MaskChar; // 0x458
	private object m_IsPassword; // 0x45A
	private object m_AutoCorrection; // 0x45B
	private object m_SelectingManipulator; // 0x460
	private object m_IsSelectable; // 0x468
	private object <UnityEngine.UIElements.ITextSelection.doubleClickSelectsWord>k__BackingField; // 0x469
	private object <UnityEngine.UIElements.ITextSelection.tripleClickSelectsLine>k__BackingField; // 0x46A
	private object <UnityEngine.UIElements.ITextSelection.selectAllOnFocus>k__BackingField; // 0x46B
	private object <UnityEngine.UIElements.ITextSelection.selectAllOnMouseUp>k__BackingField; // 0x46C
	private object m_SelectionColor; // 0x470
	private object m_CursorColor; // 0x480
	private object m_CursorWidth; // 0x490

	// Properties
	internal object uitkTextHandle { get; set; }
	public virtual object text { get; set; }
	public object enableRichText { get; set; }
	public object displayTooltipWhenElided { get; set; }
	public object isElided { get; set; }
	internal object hasFocus { get; }
	private object UnityEngine.UIElements.INotifyValueChanged<System.String>.value { get; set; }
	internal object edition { get; }
	private object UnityEngine.UIElements.ITextEdition.multiline { get; set; }
	private object UnityEngine.UIElements.ITextEdition.keyboardType { get; set; }
	private object UnityEngine.UIElements.ITextEdition.hideMobileInput { get; set; }
	private object UnityEngine.UIElements.ITextEdition.isReadOnly { get; set; }
	private object UnityEngine.UIElements.ITextEdition.maxLength { get; set; }
	private object UnityEngine.UIElements.ITextEdition.isDelayed { get; set; }
	private object UnityEngine.UIElements.ITextEdition.AcceptCharacter { get; set; }
	private object UnityEngine.UIElements.ITextEdition.UpdateScrollOffset { get; set; }
	private object UnityEngine.UIElements.ITextEdition.UpdateValueFromText { get; set; }
	private object UnityEngine.UIElements.ITextEdition.UpdateTextFromValue { get; set; }
	private object UnityEngine.UIElements.ITextEdition.MoveFocusToCompositeRoot { get; set; }
	private object UnityEngine.UIElements.ITextEdition.maskChar { set; }
	private object effectiveMaskChar { get; }
	private object UnityEngine.UIElements.ITextEdition.isPassword { get; set; }
	private object UnityEngine.UIElements.ITextEdition.autoCorrection { get; set; }
	internal object renderedText { get; set; }
	internal object originalText { get; }
	public object selection { get; }
	private object UnityEngine.UIElements.ITextSelection.isSelectable { get; set; }
	private object UnityEngine.UIElements.ITextSelection.cursorIndex { get; set; }
	private object UnityEngine.UIElements.ITextSelection.selectIndex { get; set; }
	private object UnityEngine.UIElements.ITextSelection.doubleClickSelectsWord { get; }
	private object UnityEngine.UIElements.ITextSelection.tripleClickSelectsLine { get; }
	private object UnityEngine.UIElements.ITextSelection.selectAllOnFocus { get; set; }
	private object UnityEngine.UIElements.ITextSelection.selectAllOnMouseUp { get; set; }
	private object UnityEngine.UIElements.ITextSelection.cursorPosition { get; }
	private object UnityEngine.UIElements.ITextSelection.lineHeightAtCursorPosition { get; }
	private object UnityEngine.UIElements.ITextSelection.selectionColor { get; set; }
	private object UnityEngine.UIElements.ITextSelection.cursorColor { get; set; }
	private object UnityEngine.UIElements.ITextSelection.cursorWidth { get; }
	internal object selectingManipulator { get; }

	// Methods

	// RVA: 0x7682F04
	public object .ctor() { }

	// RVA: 0x7683170
	internal object get_uitkTextHandle() { }

	// RVA: 0x7683178
	internal object set_uitkTextHandle(object value) { }

	// RVA: 0x7683180
	private object OnGeometryChanged(object e) { }

	// RVA: 0x768331C
	public virtual object get_text() { }

	// RVA: 0x76833E8
	public virtual object set_text(object value) { }

	// RVA: 0x76834AC
	public object get_enableRichText() { }

	// RVA: 0x76834B4
	public object set_enableRichText(object value) { }

	// RVA: 0x76834D0
	public object get_displayTooltipWhenElided() { }

	// RVA: 0x76834D8
	public object set_displayTooltipWhenElided(object value) { }

	// RVA: 0x7683514
	public object get_isElided() { }

	// RVA: 0x768351C
	private object set_isElided(object value) { }

	// RVA: 0x7683524
	internal object OnGenerateVisualContent(object mgc) { }

	// RVA: 0x7684C48
	internal object ElideText(object drawText, object ellipsisText, object width, object textOverflowPosition) { }

	// RVA: 0x7683A08
	private object UpdateTooltip() { }

	// RVA: 0x7683184
	private object UpdateVisibleText() { }

	// RVA: 0x76839A8
	private object ShouldElide() { }

	// RVA: 0x767E5DC
	internal object get_hasFocus() { }

	// RVA: 0x7685168
	public object MeasureTextSize(object textToMeasure, object width, object widthMode, object height, object heightMode) { }

	// RVA: 0x768516C
	protected internal override object DoMeasure(object desiredWidth, object widthMode, object desiredHeight, object heightMode) { }

	// RVA: 0x76851C4
	private object UnityEngine.UIElements.INotifyValueChanged<System.String>.get_value() { }

	// RVA: 0x7685230
	private object UnityEngine.UIElements.INotifyValueChanged<System.String>.set_value(object value) { }

	// RVA: 0x7685574
	private object UnityEngine.UIElements.INotifyValueChanged<System.String>.SetValueWithoutNotify(object newValue) { }

	// RVA: 0x767D7E0
	internal object get_edition() { }

	// RVA: 0x7685758
	private object UnityEngine.UIElements.ITextEdition.get_multiline() { }

	// RVA: 0x7685760
	private object UnityEngine.UIElements.ITextEdition.set_multiline(object value) { }

	// RVA: 0x7685874
	private object UnityEngine.UIElements.ITextEdition.get_keyboardType() { }

	// RVA: 0x768587C
	private object UnityEngine.UIElements.ITextEdition.set_keyboardType(object value) { }

	// RVA: 0x7685884
	private object UnityEngine.UIElements.ITextEdition.get_hideMobileInput() { }

	// RVA: 0x7685950
	private object UnityEngine.UIElements.ITextEdition.set_hideMobileInput(object value) { }

	// RVA: 0x7685A18
	private object UnityEngine.UIElements.ITextEdition.get_isReadOnly() { }

	// RVA: 0x7685A44
	private object UnityEngine.UIElements.ITextEdition.set_isReadOnly(object value) { }

	// RVA: 0x7685AF8
	private object ProcessMenuCommand(object command) { }

	// RVA: 0x7685CA0
	private object Cut(object a) { }

	// RVA: 0x7685CF8
	private object Copy(object a) { }

	// RVA: 0x7685D50
	private object Paste(object a) { }

	// RVA: 0x7685DA8
	private object BuildContextualMenu(object evt) { }

	// RVA: 0x7686188
	private object CutActionStatus(object a) { }

	// RVA: 0x7686320
	private object CopyActionStatus(object a) { }

	// RVA: 0x76864C8
	private object PasteActionStatus(object a) { }

	// RVA: 0x768653C
	protected override object ExecuteDefaultActionAtTarget(object evt) { }

	// RVA: 0x7686A0C
	private object UnityEngine.UIElements.ITextEdition.get_maxLength() { }

	// RVA: 0x7686A14
	private object UnityEngine.UIElements.ITextEdition.set_maxLength(object value) { }

	// RVA: 0x7686B38
	private object UnityEngine.UIElements.ITextEdition.get_isDelayed() { }

	// RVA: 0x7686B40
	private object UnityEngine.UIElements.ITextEdition.set_isDelayed(object value) { }

	// RVA: 0x7686B48
	private object UnityEngine.UIElements.ITextEdition.ResetValueAndText() { }

	// RVA: 0x7686B94
	private object UnityEngine.UIElements.ITextEdition.SaveValueAndText() { }

	// RVA: 0x7686BDC
	private object UnityEngine.UIElements.ITextEdition.RestoreValueAndText() { }

	// RVA: 0x7686C28
	private object UnityEngine.UIElements.ITextEdition.get_AcceptCharacter() { }

	// RVA: 0x7686C30
	private object UnityEngine.UIElements.ITextEdition.set_AcceptCharacter(object value) { }

	// RVA: 0x7686C38
	private object UnityEngine.UIElements.ITextEdition.get_UpdateScrollOffset() { }

	// RVA: 0x7686C40
	private object UnityEngine.UIElements.ITextEdition.set_UpdateScrollOffset(object value) { }

	// RVA: 0x7686C48
	private object UnityEngine.UIElements.ITextEdition.get_UpdateValueFromText() { }

	// RVA: 0x7686C50
	private object UnityEngine.UIElements.ITextEdition.set_UpdateValueFromText(object value) { }

	// RVA: 0x7686C58
	private object UnityEngine.UIElements.ITextEdition.get_UpdateTextFromValue() { }

	// RVA: 0x7686C60
	private object UnityEngine.UIElements.ITextEdition.set_UpdateTextFromValue(object value) { }

	// RVA: 0x7686C68
	private object UnityEngine.UIElements.ITextEdition.get_MoveFocusToCompositeRoot() { }

	// RVA: 0x7686C70
	private object UnityEngine.UIElements.ITextEdition.set_MoveFocusToCompositeRoot(object value) { }

	// RVA: 0x7686C78
	private object UnityEngine.UIElements.ITextEdition.UpdateText(object value) { }

	// RVA: 0x7686F98
	private object UnityEngine.UIElements.ITextEdition.CullString(object s) { }

	// RVA: 0x76870B4
	private object UnityEngine.UIElements.ITextEdition.set_maskChar(object value) { }

	// RVA: 0x76871B4
	private object get_effectiveMaskChar() { }

	// RVA: 0x768729C
	private object UnityEngine.UIElements.ITextEdition.get_isPassword() { }

	// RVA: 0x76872A4
	private object UnityEngine.UIElements.ITextEdition.set_isPassword(object value) { }

	// RVA: 0x76872C4
	private object UnityEngine.UIElements.ITextEdition.get_autoCorrection() { }

	// RVA: 0x76872CC
	private object UnityEngine.UIElements.ITextEdition.set_autoCorrection(object value) { }

	// RVA: 0x7682508
	internal object get_renderedText() { }

	// RVA: 0x76856F4
	internal object set_renderedText(object value) { }

	// RVA: 0x76872D4
	internal object get_originalText() { }

	// RVA: 0x767F934
	public object get_selection() { }

	// RVA: 0x76872DC
	private object UnityEngine.UIElements.ITextSelection.get_isSelectable() { }

	// RVA: 0x76872FC
	private object UnityEngine.UIElements.ITextSelection.set_isSelectable(object value) { }

	// RVA: 0x7687314
	private object UnityEngine.UIElements.ITextSelection.get_cursorIndex() { }

	// RVA: 0x768746C
	private object UnityEngine.UIElements.ITextSelection.set_cursorIndex(object value) { }

	// RVA: 0x76875C4
	private object UnityEngine.UIElements.ITextSelection.get_selectIndex() { }

	// RVA: 0x768771C
	private object UnityEngine.UIElements.ITextSelection.set_selectIndex(object value) { }

	// RVA: 0x7687874
	private object UnityEngine.UIElements.ITextSelection.SelectAll() { }

	// RVA: 0x76879D0
	private object UnityEngine.UIElements.ITextSelection.SelectNone() { }

	// RVA: 0x7687B2C
	private object UnityEngine.UIElements.ITextSelection.HasSelection() { }

	// RVA: 0x7687C7C
	private object UnityEngine.UIElements.ITextSelection.get_doubleClickSelectsWord() { }

	// RVA: 0x7687C84
	private object UnityEngine.UIElements.ITextSelection.get_tripleClickSelectsLine() { }

	// RVA: 0x7687C8C
	private object UnityEngine.UIElements.ITextSelection.get_selectAllOnFocus() { }

	// RVA: 0x7687C94
	private object UnityEngine.UIElements.ITextSelection.set_selectAllOnFocus(object value) { }

	// RVA: 0x7687C9C
	private object UnityEngine.UIElements.ITextSelection.get_selectAllOnMouseUp() { }

	// RVA: 0x7687CA4
	private object UnityEngine.UIElements.ITextSelection.set_selectAllOnMouseUp(object value) { }

	// RVA: 0x7687CAC
	private object UnityEngine.UIElements.ITextSelection.get_cursorPosition() { }

	// RVA: 0x7687DC8
	private object UnityEngine.UIElements.ITextSelection.get_lineHeightAtCursorPosition() { }

	// RVA: 0x7687EB4
	private object UnityEngine.UIElements.ITextSelection.get_selectionColor() { }

	// RVA: 0x7687EC8
	private object UnityEngine.UIElements.ITextSelection.set_selectionColor(object value) { }

	// RVA: 0x7687F34
	private object UnityEngine.UIElements.ITextSelection.get_cursorColor() { }

	// RVA: 0x7687F48
	private object UnityEngine.UIElements.ITextSelection.set_cursorColor(object value) { }

	// RVA: 0x7687FB4
	private object UnityEngine.UIElements.ITextSelection.get_cursorWidth() { }

	// RVA: 0x767D4C0
	internal object get_selectingManipulator() { }

	// RVA: 0x7683AA8
	private object DrawHighlighting(object mgc) { }

	// RVA: 0x76847D0
	internal object DrawCaret(object mgc) { }

	// RVA: 0x7687FBC
	private object GetLastCharacterAt(object lineIndex) { }

	// RVA: 0x7688190
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public interface ITextEdition
{

	// Properties
	internal abstract object multiline { get; set; }
	public abstract object isReadOnly { get; set; }
	public abstract object maxLength { get; set; }
	public abstract object isDelayed { get; set; }
	internal abstract object AcceptCharacter { get; set; }
	internal abstract object UpdateScrollOffset { get; set; }
	internal abstract object UpdateValueFromText { get; set; }
	internal abstract object UpdateTextFromValue { get; set; }
	internal abstract object MoveFocusToCompositeRoot { get; set; }
	public abstract object maskChar { set; }
	public abstract object isPassword { get; set; }
	public virtual object autoCorrection { get; set; }
	public virtual object hideMobileInput { get; set; }
	public virtual object keyboardType { get; set; }

	// Methods

	// RVA: -1
	internal abstract object get_multiline() { }

	// RVA: -1
	internal abstract object set_multiline(object value) { }

	// RVA: -1
	public abstract object get_isReadOnly() { }

	// RVA: -1
	public abstract object set_isReadOnly(object value) { }

	// RVA: -1
	public abstract object get_maxLength() { }

	// RVA: -1
	public abstract object set_maxLength(object value) { }

	// RVA: -1
	public abstract object get_isDelayed() { }

	// RVA: -1
	public abstract object set_isDelayed(object value) { }

	// RVA: -1
	internal abstract object ResetValueAndText() { }

	// RVA: -1
	internal abstract object SaveValueAndText() { }

	// RVA: -1
	internal abstract object RestoreValueAndText() { }

	// RVA: -1
	internal abstract object get_AcceptCharacter() { }

	// RVA: -1
	internal abstract object set_AcceptCharacter(object value) { }

	// RVA: -1
	internal abstract object get_UpdateScrollOffset() { }

	// RVA: -1
	internal abstract object set_UpdateScrollOffset(object value) { }

	// RVA: -1
	internal abstract object get_UpdateValueFromText() { }

	// RVA: -1
	internal abstract object set_UpdateValueFromText(object value) { }

	// RVA: -1
	internal abstract object get_UpdateTextFromValue() { }

	// RVA: -1
	internal abstract object set_UpdateTextFromValue(object value) { }

	// RVA: -1
	internal abstract object get_MoveFocusToCompositeRoot() { }

	// RVA: -1
	internal abstract object set_MoveFocusToCompositeRoot(object value) { }

	// RVA: -1
	internal abstract object UpdateText(object value) { }

	// RVA: -1
	internal abstract object CullString(object s) { }

	// RVA: -1
	public abstract object set_maskChar(object value) { }

	// RVA: -1
	public abstract object get_isPassword() { }

	// RVA: -1
	public abstract object set_isPassword(object value) { }

	// RVA: 0x76887BC
	public virtual object get_autoCorrection() { }

	// RVA: 0x76888B8
	public virtual object set_autoCorrection(object value) { }

	// RVA: 0x76889C0
	public virtual object get_hideMobileInput() { }

	// RVA: 0x7688ABC
	public virtual object set_hideMobileInput(object value) { }

	// RVA: 0x7688BC4
	public virtual object get_keyboardType() { }

	// RVA: 0x7688CC0
	public virtual object set_keyboardType(object value) { }

}

// Namespace: UnityEngine.UIElements
public interface ITextSelection
{

	// Properties
	public abstract object isSelectable { get; set; }
	public abstract object cursorColor { get; set; }
	public abstract object cursorIndex { get; set; }
	public abstract object doubleClickSelectsWord { get; }
	public abstract object selectIndex { get; set; }
	public abstract object selectionColor { get; set; }
	public abstract object tripleClickSelectsLine { get; }
	internal abstract object selectAllOnFocus { get; set; }
	internal abstract object selectAllOnMouseUp { get; set; }
	public abstract object cursorPosition { get; }
	internal abstract object lineHeightAtCursorPosition { get; }
	internal abstract object cursorWidth { get; }

	// Methods

	// RVA: -1
	public abstract object get_isSelectable() { }

	// RVA: -1
	public abstract object set_isSelectable(object value) { }

	// RVA: -1
	public abstract object get_cursorColor() { }

	// RVA: -1
	public abstract object set_cursorColor(object value) { }

	// RVA: -1
	public abstract object get_cursorIndex() { }

	// RVA: -1
	public abstract object set_cursorIndex(object value) { }

	// RVA: -1
	public abstract object get_doubleClickSelectsWord() { }

	// RVA: -1
	public abstract object get_selectIndex() { }

	// RVA: -1
	public abstract object set_selectIndex(object value) { }

	// RVA: -1
	public abstract object get_selectionColor() { }

	// RVA: -1
	public abstract object set_selectionColor(object value) { }

	// RVA: -1
	public abstract object get_tripleClickSelectsLine() { }

	// RVA: -1
	public abstract object HasSelection() { }

	// RVA: -1
	public abstract object SelectAll() { }

	// RVA: -1
	public abstract object SelectNone() { }

	// RVA: -1
	internal abstract object get_selectAllOnFocus() { }

	// RVA: -1
	internal abstract object set_selectAllOnFocus(object value) { }

	// RVA: -1
	internal abstract object get_selectAllOnMouseUp() { }

	// RVA: -1
	internal abstract object set_selectAllOnMouseUp(object value) { }

	// RVA: -1
	public abstract object get_cursorPosition() { }

	// RVA: -1
	internal abstract object get_lineHeightAtCursorPosition() { }

	// RVA: -1
	internal abstract object get_cursorWidth() { }

}

// Namespace: UnityEngine.UIElements
public struct TextShadow
{

	// Fields
	public object offset; // 0xFFFFFFFFFFFFFFF8
	public object blurRadius; // 0x0
	public object color; // 0x4

	// Methods

	// RVA: 0x7688DC8
	public override object Equals(object obj) { }

	// RVA: 0x7688ED4
	public object Equals(object other) { }

	// RVA: 0x7688FE4
	public override object GetHashCode() { }

	// RVA: 0x7689188
	public static object op_Equality(object style1, object style2) { }

	// RVA: 0x768920C
	public static object op_Inequality(object style1, object style2) { }

	// RVA: 0x768928C
	public override object ToString() { }

	// RVA: 0x7689388
	internal static object LerpUnclamped(object a, object b, object t) { }

}

// Namespace: UnityEngine.UIElements
internal abstract class UIElementsBridge
{

	// Methods

	// RVA: -1
	public abstract object SetWantsMouseJumping(object value) { }

	// RVA: 0x76893D8
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class RuntimeUIElementsBridge
{

	// Methods

	// RVA: 0x76893E0
	public override object SetWantsMouseJumping(object value) { }

	// RVA: 0x76893E4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal static class UIElementsPackageUtility
{

	// Fields
	private static object <IsUIEPackageLoaded>k__BackingField; // 0x0
	private static object <EditorResourcesBasePath>k__BackingField; // 0x8

	// Properties
	internal static object IsUIEPackageLoaded { get; set; }
	internal static object EditorResourcesBasePath { get; set; }

	// Methods

	// RVA: 0x76893EC
	internal static object get_IsUIEPackageLoaded() { }

	// RVA: 0x7689468
	private static object set_IsUIEPackageLoaded(object value) { }

	// RVA: 0x76894F4
	internal static object get_EditorResourcesBasePath() { }

	// RVA: 0x7689570
	private static object set_EditorResourcesBasePath(object value) { }

	// RVA: 0x76895FC
	private static object .cctor() { }

	// RVA: 0x7689600
	internal static object Refresh() { }

}

// Namespace: 
public sealed class CreateRuntimePanelDelegate
{

	// Methods

	// RVA: 0x768D1C0
	public object .ctor(object object, object method) { }

	// RVA: 0x768D2DC
	public virtual object Invoke(object ownerObject) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__48_0; // 0x8

	// Methods

	// RVA: 0x768D2F0
	private static object .cctor() { }

	// RVA: 0x768D350
	public object .ctor() { }

	// RVA: 0x768D358
	internal object <.cctor>b__9_0() { }

	// RVA: 0x768D35C
	internal object <.cctor>b__9_1(object displayIndex, object sortOrder) { }

	// RVA: 0x768D3E8
	internal object <SortPanels>b__48_0(object a, object b) { }

}

// Namespace: UnityEngine.UIElements
internal static class UIElementsRuntimeUtility
{

	// Fields
	private static object onCreatePanel; // 0x0
	private static object s_RegisteredPlayerloopCallback; // 0x8
	private static object s_SortedRuntimePanels; // 0x10
	private static object s_PanelOrderingDirty; // 0x18
	internal static object s_ResolvedSortingIndexMax; // 0x1C
	internal static readonly object s_RepaintProfilerMarkerName; // 0x20
	private static readonly object s_RepaintProfilerMarker; // 0x28
	private static object currentOverlayIndex; // 0x30
	private static object <activeEventSystem>k__BackingField; // 0x38
	private static object s_DefaultEventSystem; // 0x40
	private static object s_PotentiallyEmptyPanelSettings; // 0x48

	// Properties
	internal static object activeEventSystem { get; set; }
	internal static object useDefaultEventSystem { get; }
	internal static object defaultEventSystem { get; }

	// Methods

	// RVA: 0x7689748
	public static object add_onCreatePanel(object value) { }

	// RVA: 0x7689858
	public static object remove_onCreatePanel(object value) { }

	// RVA: 0x7689968
	private static object .cctor() { }

	// RVA: 0x7689CDC
	public static object CreateEvent(object systemEvent) { }

	// RVA: 0x768A130
	public static object FindOrCreateRuntimePanel(object ownerObject, object createDelegate) { }

	// RVA: 0x768A8E0
	public static object DisposeRuntimePanel(object ownerObject) { }

	// RVA: 0x768A684
	private static object RegisterCachedPanelInternal(object instanceID, object panel) { }

	// RVA: 0x768A448
	private static object RemoveCachedPanelInternal(object instanceID) { }

	// RVA: 0x768AF9C
	public static object RepaintOffscreenPanels() { }

	// RVA: 0x768B36C
	public static object RepaintOverlayPanel(object panel) { }

	// RVA: 0x768B54C
	internal static object BeginRenderOverlays(object displayIndex) { }

	// RVA: 0x768B5C8
	internal static object RenderOverlaysBeforePriority(object displayIndex, object maxPriority) { }

	// RVA: 0x768B874
	internal static object EndRenderOverlays(object displayIndex) { }

	// RVA: 0x768B8F0
	internal static object get_activeEventSystem() { }

	// RVA: 0x768B96C
	private static object set_activeEventSystem(object value) { }

	// RVA: 0x768B9F8
	internal static object get_useDefaultEventSystem() { }

	// RVA: 0x768BB0C
	public static object RegisterEventSystem(object eventSystem) { }

	// RVA: 0x768BE10
	public static object UnregisterEventSystem(object eventSystem) { }

	// RVA: 0x768BFC0
	internal static object get_defaultEventSystem() { }

	// RVA: 0x768C0A4
	public static object UpdateRuntimePanels() { }

	// RVA: 0x768C644
	internal static object MarkPotentiallyEmpty(object settings) { }

	// RVA: 0x768C414
	internal static object RemoveUnusedPanels() { }

	// RVA: 0x768AB04
	public static object RegisterPlayerloopCallback() { }

	// RVA: 0x768AF48
	public static object UnregisterPlayerloopCallback() { }

	// RVA: 0x768C828
	internal static object SetPanelOrderingDirty() { }

	// RVA: 0x768B290
	internal static object GetSortedPlayerPanels() { }

	// RVA: 0x768C8AC
	private static object SortPanels() { }

	// RVA: 0x768CBBC
	internal static object MultiDisplayBottomLeftToPanelPosition(object position, object targetDisplay) { }

	// RVA: 0x768CC48
	internal static object MultiDisplayToLocalScreenPosition(object position, object targetDisplay) { }

	// RVA: 0x768CDB4
	internal static object ScreenBottomLeftToPanelPosition(object position, object targetDisplay) { }

	// RVA: 0x768CECC
	internal static object ScreenBottomLeftToPanelDelta(object delta) { }

}

// Namespace: UnityEngine.UIElements
internal interface IUIElementsUtility
{

	// Methods

	// RVA: -1
	public abstract object TakeCapture() { }

	// RVA: -1
	public abstract object ReleaseCapture() { }

	// RVA: -1
	public abstract object ProcessEvent(object instanceID, object nativeEventPtr, object eventHandled) { }

	// RVA: -1
	public abstract object CleanupRoots() { }

	// RVA: -1
	public abstract object EndContainerGUIFromException(object exception) { }

	// RVA: -1
	public abstract object MakeCurrentIMGUIContainerDirty() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x768E850
	private static object .cctor() { }

	// RVA: 0x768E8B0
	public object .ctor() { }

	// RVA: 0x768E8B8
	internal object <.cctor>b__1_0() { }

	// RVA: 0x768E920
	internal object <.cctor>b__1_1() { }

	// RVA: 0x768E988
	internal object <.cctor>b__1_2(object i, object ptr) { }

	// RVA: 0x768EA14
	internal object <.cctor>b__1_3() { }

	// RVA: 0x768EA7C
	internal object <.cctor>b__1_4(object exception) { }

	// RVA: 0x768EAFC
	internal object <.cctor>b__1_5() { }

}

// Namespace: UnityEngine.UIElements
internal static class UIEventRegistration
{

	// Fields
	private static object s_Utilities; // 0x0

	// Methods

	// RVA: 0x768D57C
	private static object .cctor() { }

	// RVA: 0x768DA2C
	internal static object RegisterUIElementSystem(object utility) { }

	// RVA: 0x768DADC
	private static object TakeCapture() { }

	// RVA: 0x768DD38
	private static object ReleaseCapture() { }

	// RVA: 0x768DF58
	private static object EndContainerGUIFromException(object exception) { }

	// RVA: 0x768E1B0
	private static object ProcessEvent(object instanceID, object nativeEventPtr) { }

	// RVA: 0x768E410
	private static object CleanupRoots() { }

	// RVA: 0x768E630
	internal static object MakeCurrentIMGUIContainerDirty() { }

}

// Namespace: UnityEngine.UIElements
internal class UIElementsUtility
{

	// Fields
	private static object s_ContainerStack; // 0x0
	private static object s_UIElementsCache; // 0x8
	private static object s_EventInstance; // 0x10
	internal static object editorPlayModeTintColor; // 0x18
	internal static object singleLineHeight; // 0x28
	private static object s_Instance; // 0x30
	internal static object s_PanelsIterationList; // 0x38
	internal static readonly object s_RepaintProfilerMarkerName; // 0x40
	internal static readonly object s_EventProfilerMarkerName; // 0x48
	private static readonly object s_RepaintProfilerMarker; // 0x50
	private static readonly object s_EventProfilerMarker; // 0x58

	// Methods

	// RVA: 0x768EB64
	private object .ctor() { }

	// RVA: 0x768EC74
	private object UnityEngine.UIElements.IUIElementsUtility.MakeCurrentIMGUIContainerDirty() { }

	// RVA: 0x768ED78
	private object UnityEngine.UIElements.IUIElementsUtility.TakeCapture() { }

	// RVA: 0x768EE6C
	private object UnityEngine.UIElements.IUIElementsUtility.ReleaseCapture() { }

	// RVA: 0x768EE74
	private object UnityEngine.UIElements.IUIElementsUtility.ProcessEvent(object instanceID, object nativeEventPtr, object eventHandled) { }

	// RVA: 0x768F6F4
	private object UnityEngine.UIElements.IUIElementsUtility.CleanupRoots() { }

	// RVA: 0x768F758
	private object UnityEngine.UIElements.IUIElementsUtility.EndContainerGUIFromException(object exception) { }

	// RVA: 0x768AA50
	public static object RegisterCachedPanel(object instanceID, object panel) { }

	// RVA: 0x768ABA4
	public static object RemoveCachedPanel(object instanceID) { }

	// RVA: 0x768A394
	public static object TryGetPanel(object instanceID, object panel) { }

	// RVA: 0x768F848
	internal static object BeginContainerGUI(object cache, object evt, object container) { }

	// RVA: 0x768FAD0
	internal static object EndContainerGUI(object evt, object layoutSize) { }

	// RVA: 0x768FD50
	internal static object CreateEvent(object systemEvent) { }

	// RVA: 0x7689D78
	internal static object CreateEvent(object systemEvent, object eventType) { }

	// RVA: 0x768EFC8
	private static object DoDispatch(object panel) { }

	// RVA: 0x768AC50
	internal static object GetAllPanels(object panels, object contextType) { }

	// RVA: 0x768FDEC
	internal static object GetPanelsIterator() { }

	// RVA: 0x768FECC
	internal static object PixelsPerUnitScaleForElement(object ve, object sprite) { }

	// RVA: 0x768FFD4
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal struct RuleMatcher
{

	// Fields
	public object sheet; // 0xFFFFFFFFFFFFFFF8
	public object complexSelector; // 0x0

	// Methods

	// RVA: 0x769021C
	public override object ToString() { }

}

// Namespace: 
internal interface IVisualPredicateWrapper
{

	// Methods

	// RVA: -1
	public abstract object Predicate(object e) { }

}

// Namespace: 
internal class IsOfType<T0>
{

	// Fields
	public static object s_Instance; // 0x0

	// Methods

	// RVA: -1
	public object Predicate(object e) { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__5_0; // 0x8

	// Methods

	// RVA: 0x7690578
	private static object .cctor() { }

	// RVA: 0x76905D8
	public object .ctor() { }

	// RVA: 0x76905E0
	internal object <TraverseRecursive>b__5_0(object e, object i) { }

}

// Namespace: 
internal abstract class UQueryMatcher
{

	// Fields
	internal object m_Matchers; // 0x8

	// Methods

	// RVA: 0x76902B4
	protected object .ctor() { }

	// RVA: 0x76902BC
	public override object Traverse(object element) { }

	// RVA: 0x76902C4
	protected virtual object OnRuleMatchedElement(object matcher, object element) { }

	// RVA: 0x76902CC
	private static object NoProcessResult(object e, object i) { }

	// RVA: 0x76902D0
	public override object TraverseRecursive(object element, object depth) { }

	// RVA: 0x769052C
	public virtual object Run(object root, object matchers) { }

}

// Namespace: 
internal abstract class SingleQueryMatcher
{

	// Fields
	private object <match>k__BackingField; // 0x10

	// Properties
	public object match { get; set; }

	// Methods

	// RVA: 0x76905E4
	public object get_match() { }

	// RVA: 0x76905EC
	public object set_match(object value) { }

	// RVA: 0x76905F4
	public override object Run(object root, object matchers) { }

	// RVA: 0x7690644
	public object IsInUse() { }

	// RVA: -1
	public abstract object CreateNew() { }

	// RVA: 0x7690654
	protected object .ctor() { }

}

// Namespace: 
internal class FirstQueryMatcher
{

	// Fields
	public static readonly object Instance; // 0x0

	// Methods

	// RVA: 0x769065C
	protected override object OnRuleMatchedElement(object matcher, object element) { }

	// RVA: 0x7690678
	public override object CreateNew() { }

	// RVA: 0x76906D0
	public object .ctor() { }

	// RVA: 0x76906D8
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public static class UQuery
{
}

// Namespace: 
private class ListQueryMatcher<T0>
{

	// Fields
	private object <matches>k__BackingField; // 0x0

	// Properties
	public object matches { get; set; }

	// Methods

	// RVA: -1
	public object get_matches() { }

	// RVA: -1
	public object set_matches(object value) { }

	// RVA: -1
	protected override object OnRuleMatchedElement(object matcher, object element) { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private class ActionQueryMatcher
{

	// Fields
	private object <callBack>k__BackingField; // 0x0

	// Properties
	internal object callBack { get; }

	// Methods

	// RVA: -1
	internal object get_callBack() { }

	// RVA: -1
	protected override object OnRuleMatchedElement(object matcher, object element) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object iterationList; // 0x0
	private object currentIndex; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object queryState) { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: UnityEngine.UIElements
public struct UQueryState<T0>
{

	// Fields
	private static object s_Action; // 0x0
	private readonly object m_Element; // 0x0
	internal readonly object m_Matchers; // 0x0
	private static readonly object s_List; // 0x0
	private static readonly object s_EnumerationList; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor(object element, object matchers) { }

	// RVA: -1
	public object RebuildOn(object element) { }

	// RVA: -1
	private object Single(object matcher) { }

	// RVA: -1
	public object First() { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public struct UQueryBuilder<T0>
{

	// Fields
	private object m_StyleSelectors; // 0x0
	private object m_Parts; // 0x0
	private object m_Element; // 0x0
	private object m_Matchers; // 0x0
	private object m_Relationship; // 0x0
	private object pseudoStatesMask; // 0x0
	private object negatedPseudoStatesMask; // 0x0

	// Properties
	private object styleSelectors { get; }
	private object parts { get; }

	// Methods

	// RVA: -1
	private object get_styleSelectors() { }

	// RVA: -1
	private object get_parts() { }

	// RVA: -1
	public object .ctor(object visualElement) { }

	// RVA: -1
	public object Class(object classname) { }

	// RVA: -1
	public object Name(object id) { }

	// RVA: -1
	internal object SingleBaseType() { }

	// RVA: -1
	private object AddClass(object c) { }

	// RVA: -1
	private object AddName(object id) { }

	// RVA: -1
	private object AddPseudoStatesRuleIfNecessasy() { }

	// RVA: -1
	private object FinishSelector() { }

	// RVA: -1
	private object CurrentSelectorEmpty() { }

	// RVA: -1
	private object FinishCurrentSelector() { }

	// RVA: -1
	public object Build() { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public override object GetHashCode() { }

}

// Namespace: UnityEngine.UIElements
public static class UQueryExtensions
{

	// Fields
	private static object SingleElementEmptyQuery; // 0x0
	private static object SingleElementNameQuery; // 0x10
	private static object SingleElementClassQuery; // 0x20
	private static object SingleElementNameAndClassQuery; // 0x30
	private static object SingleElementTypeQuery; // 0x40
	private static object SingleElementTypeAndNameQuery; // 0x50
	private static object SingleElementTypeAndClassQuery; // 0x60
	private static object SingleElementTypeAndNameAndClassQuery; // 0x70

	// Methods

	// RVA: -1
	public static object Q(object e, object name, object className) { }

	// RVA: 0x7690738
	public static object Q(object e, object name, object className) { }

	// RVA: 0x7690C94
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public interface IUxmlAttributes
{

	// Methods

	// RVA: -1
	public abstract object TryGetAttributeValue(object attributeName, object value) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlRootElementFactory
{

	// Properties
	public override object uxmlName { get; }
	public override object uxmlQualifiedName { get; }

	// Methods

	// RVA: 0x7691174
	public override object get_uxmlName() { }

	// RVA: 0x76911B8
	public override object get_uxmlQualifiedName() { }

	// RVA: 0x7691260
	public override object Create(object bag, object cc) { }

	// RVA: 0x7691268
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlRootElementTraits
{

	// Fields
	protected object m_Name; // 0x10
	private object m_Class; // 0x18

	// Methods

	// RVA: 0x76912C0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlStyleFactory
{

	// Properties
	public override object uxmlName { get; }
	public override object uxmlQualifiedName { get; }

	// Methods

	// RVA: 0x76914B8
	public override object get_uxmlName() { }

	// RVA: 0x76914FC
	public override object get_uxmlQualifiedName() { }

	// RVA: 0x76915A4
	public override object Create(object bag, object cc) { }

	// RVA: 0x76915AC
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlStyleTraits
{

	// Fields
	private object m_Name; // 0x10
	private object m_Path; // 0x18
	private object m_Src; // 0x20

	// Methods

	// RVA: 0x7691604
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlTemplateFactory
{

	// Properties
	public override object uxmlName { get; }
	public override object uxmlQualifiedName { get; }

	// Methods

	// RVA: 0x7691868
	public override object get_uxmlName() { }

	// RVA: 0x76918AC
	public override object get_uxmlQualifiedName() { }

	// RVA: 0x7691954
	public override object Create(object bag, object cc) { }

	// RVA: 0x769195C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlTemplateTraits
{

	// Fields
	private object m_Name; // 0x10
	private object m_Path; // 0x18
	private object m_Src; // 0x20

	// Methods

	// RVA: 0x76919B4
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlAttributeOverridesFactory
{

	// Properties
	public override object uxmlName { get; }
	public override object uxmlQualifiedName { get; }

	// Methods

	// RVA: 0x7691C20
	public override object get_uxmlName() { }

	// RVA: 0x7691C64
	public override object get_uxmlQualifiedName() { }

	// RVA: 0x7691D0C
	public override object Create(object bag, object cc) { }

	// RVA: 0x7691D14
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlAttributeOverridesTraits
{

	// Fields
	private object m_ElementName; // 0x10

	// Methods

	// RVA: 0x7691D6C
	public object .ctor() { }

}

// Namespace: 
public struct AttributeOverride
{

	// Fields
	public object m_ElementName; // 0xFFFFFFFFFFFFFFF8
	public object m_AttributeName; // 0x0
	public object m_Value; // 0x8
}

// Namespace: UnityEngine.UIElements
internal class TemplateAsset
{

	// Fields
	private object m_TemplateAlias; // 0x60
	private object m_AttributeOverrides; // 0x68
	private object m_SlotUsages; // 0x70

	// Properties
	public object attributeOverrides { get; }
	internal object slotUsages { get; }

	// Methods

	// RVA: 0x767BFD0
	public object get_attributeOverrides() { }

	// RVA: 0x7691EA0
	internal object get_slotUsages() { }

}

// Namespace: 
public enum Use
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Optional;
	public const object Prohibited;
	public const object Required;
}

// Namespace: UnityEngine.UIElements
public abstract class UxmlAttributeDescription
{

	// Fields
	private object <name>k__BackingField; // 0x8
	private object m_ObsoleteNames; // 0x10
	private object <type>k__BackingField; // 0x18
	private object <typeNamespace>k__BackingField; // 0x20
	private object <use>k__BackingField; // 0x28
	private object <restriction>k__BackingField; // 0x30

	// Properties
	public object name { get; set; }
	public object obsoleteNames { set; }
	protected object type { set; }
	protected object typeNamespace { set; }
	public object use { set; }
	public object restriction { set; }

	// Methods

	// RVA: 0x7691F84
	protected object .ctor() { }

	// RVA: 0x7691FB4
	public object get_name() { }

	// RVA: 0x7691FBC
	public object set_name(object value) { }

	// RVA: 0x7691FC4
	public object set_obsoleteNames(object value) { }

	// RVA: 0x7692024
	protected object set_type(object value) { }

	// RVA: 0x769202C
	protected object set_typeNamespace(object value) { }

	// RVA: 0x7692034
	public object set_use(object value) { }

	// RVA: 0x769203C
	public object set_restriction(object value) { }

	// RVA: 0x7692044
	internal object TryGetValueFromBagAsString(object bag, object cc, object value) { }

	// RVA: -1
	protected object TryGetValueFromBag(object bag, object cc, object converterFunc, object defaultValue, object value) { }

	// RVA: -1
	protected object GetValueFromBag(object bag, object cc, object converterFunc, object defaultValue) { }

}

// Namespace: UnityEngine.UIElements
public abstract class TypedUxmlAttributeDescription<T0>
{

	// Fields
	private object <defaultValue>k__BackingField; // 0x0

	// Properties
	public object defaultValue { get; set; }

	// Methods

	// RVA: -1
	public abstract object GetValueFromBag(object bag, object cc) { }

	// RVA: -1
	public object get_defaultValue() { }

	// RVA: -1
	public object set_defaultValue(object value) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8
	public static object <>9__4_0; // 0x10

	// Methods

	// RVA: 0x76929B0
	private static object .cctor() { }

	// RVA: 0x7692A10
	public object .ctor() { }

	// RVA: 0x7692A18
	internal object <GetValueFromBag>b__3_0(object s, object t) { }

	// RVA: 0x7692A20
	internal object <TryGetValueFromBag>b__4_0(object s, object t) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlStringAttributeDescription
{

	// Methods

	// RVA: 0x767C988
	public object .ctor() { }

	// RVA: 0x76926B0
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: 0x7692828
	public object TryGetValueFromBag(object bag, object cc, object value) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8

	// Methods

	// RVA: 0x7692CE4
	private static object .cctor() { }

	// RVA: 0x7692D44
	public object .ctor() { }

	// RVA: 0x7692D4C
	internal object <GetValueFromBag>b__3_0(object s, object f) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlFloatAttributeDescription
{

	// Methods

	// RVA: 0x7692A28
	public object .ctor() { }

	// RVA: 0x7692ACC
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: 0x7692C44
	private static object ConvertValueToFloat(object v, object defaultValue) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8

	// Methods

	// RVA: 0x76930A8
	private static object .cctor() { }

	// RVA: 0x7693108
	public object .ctor() { }

	// RVA: 0x7693110
	internal object <GetValueFromBag>b__3_0(object s, object d) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlDoubleAttributeDescription
{

	// Methods

	// RVA: 0x7692DEC
	public object .ctor() { }

	// RVA: 0x7692E90
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: 0x7693008
	private static object ConvertValueToDouble(object v, object defaultValue) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8
	public static object <>9__4_0; // 0x10

	// Methods

	// RVA: 0x769359C
	private static object .cctor() { }

	// RVA: 0x76935FC
	public object .ctor() { }

	// RVA: 0x7693604
	internal object <GetValueFromBag>b__3_0(object s, object i) { }

	// RVA: 0x7693650
	internal object <TryGetValueFromBag>b__4_0(object s, object i) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlIntAttributeDescription
{

	// Methods

	// RVA: 0x76931B0
	public object .ctor() { }

	// RVA: 0x7693254
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: 0x76933CC
	public object TryGetValueFromBag(object bag, object cc, object value) { }

	// RVA: 0x7693554
	private static object ConvertValueToInt(object v, object defaultValue) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8

	// Methods

	// RVA: 0x7693900
	private static object .cctor() { }

	// RVA: 0x7693960
	public object .ctor() { }

	// RVA: 0x7693968
	internal object <GetValueFromBag>b__3_0(object s, object i) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlUnsignedIntAttributeDescription
{

	// Methods

	// RVA: 0x769369C
	public object .ctor() { }

	// RVA: 0x7693740
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: 0x76938B8
	private static object ConvertValueToUInt(object v, object defaultValue) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8

	// Methods

	// RVA: 0x7693C18
	private static object .cctor() { }

	// RVA: 0x7693C78
	public object .ctor() { }

	// RVA: 0x7693C80
	internal object <GetValueFromBag>b__3_0(object s, object l) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlUnsignedLongAttributeDescription
{

	// Methods

	// RVA: 0x76939B4
	public object .ctor() { }

	// RVA: 0x7693A58
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: 0x7693BD0
	private static object ConvertValueToUlong(object v, object defaultValue) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8

	// Methods

	// RVA: 0x7693F30
	private static object .cctor() { }

	// RVA: 0x7693F90
	public object .ctor() { }

	// RVA: 0x7693F98
	internal object <GetValueFromBag>b__3_0(object s, object l) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlLongAttributeDescription
{

	// Methods

	// RVA: 0x7693CCC
	public object .ctor() { }

	// RVA: 0x7693D70
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: 0x7693EE8
	private static object ConvertValueToLong(object v, object defaultValue) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8
	public static object <>9__4_0; // 0x10

	// Methods

	// RVA: 0x7694388
	private static object .cctor() { }

	// RVA: 0x76943E8
	public object .ctor() { }

	// RVA: 0x76943F0
	internal object <GetValueFromBag>b__3_0(object s, object b) { }

	// RVA: 0x7694494
	internal object <TryGetValueFromBag>b__4_0(object s, object b) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlBoolAttributeDescription
{

	// Methods

	// RVA: 0x7688718
	public object .ctor() { }

	// RVA: 0x7693FE4
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: 0x769415C
	public object TryGetValueFromBag(object bag, object cc, object value) { }

	// RVA: 0x76942E4
	private static object ConvertValueToBool(object v, object defaultValue) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlTypeAttributeDescription<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: -1
	private object ConvertValueToType(object v, object defaultValue) { }

	// RVA: -1
	private object <GetValueFromBag>b__3_0(object s, object type1) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x0
	public static object <>9__4_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <GetValueFromBag>b__3_0(object s, object convertible) { }

	// RVA: -1
	internal object <TryGetValueFromBag>b__4_0(object s, object convertible) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlEnumAttributeDescription<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: -1
	public object TryGetValueFromBag(object bag, object cc, object value) { }

	// RVA: -1
	private static object ConvertValueToEnum(object v, object defaultValue) { }

	// RVA: -1
	private static object GetEnumNameErrorMessage(object v, object enumType) { }

	// RVA: -1
	private static object GetEnumRangeErrorMessage(object v, object enumType) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8

	// Methods

	// RVA: 0x7694754
	private static object .cctor() { }

	// RVA: 0x76947B4
	public object .ctor() { }

	// RVA: 0x76947BC
	internal object <GetValueFromBag>b__3_0(object s, object i) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlHash128AttributeDescription
{

	// Methods

	// RVA: 0x7694538
	public object .ctor() { }

	// RVA: 0x76945DC
	public override object GetValueFromBag(object bag, object cc) { }

}

// Namespace: UnityEngine.UIElements
internal class UxmlObjectAttributeDescription<T0>
{

	// Fields
	private object <defaultValue>k__BackingField; // 0x0

	// Properties
	public object defaultValue { get; }

	// Methods

	// RVA: -1
	public object get_defaultValue() { }

	// RVA: -1
	public virtual object GetValueFromBag(object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class UxmlObjectListAttributeDescription<T0>
{

	// Methods

	// RVA: -1
	public override object GetValueFromBag(object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseUxmlTraits
{

	// Fields
	private object <canHaveAnyAttribute>k__BackingField; // 0x8

	// Properties
	protected object canHaveAnyAttribute { set; }

	// Methods

	// RVA: 0x76947C8
	protected object .ctor() { }

	// RVA: 0x76947F4
	protected object set_canHaveAnyAttribute(object value) { }

}

// Namespace: UnityEngine.UIElements
public abstract class UxmlTraits
{

	// Methods

	// RVA: 0x76947FC
	public virtual object Init(object ve, object bag, object cc) { }

	// RVA: 0x769148C
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal abstract class UxmlObjectTraits<T0>
{

	// Methods

	// RVA: -1
	public virtual object Init(object obj, object bag, object cc) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public interface IBaseUxmlFactory
{

	// Properties
	public abstract object uxmlQualifiedName { get; }
	public abstract object uxmlType { get; }

	// Methods

	// RVA: -1
	public abstract object get_uxmlQualifiedName() { }

	// RVA: -1
	public abstract object get_uxmlType() { }

	// RVA: -1
	public abstract object AcceptsAttributeBag(object bag, object cc) { }

}

// Namespace: UnityEngine.UIElements
public interface IUxmlFactory
{

	// Methods

	// RVA: -1
	public abstract object Create(object bag, object cc) { }

}

// Namespace: UnityEngine.UIElements
internal interface IBaseUxmlObjectFactory
{
}

// Namespace: UnityEngine.UIElements
internal interface IUxmlObjectFactory<T0>
{

	// Methods

	// RVA: -1
	public abstract object CreateObject(object bag, object cc) { }

}

// Namespace: UnityEngine.UIElements
public abstract class BaseUxmlFactory<T0, T1>
{

	// Fields
	internal object m_Traits; // 0x0

	// Properties
	public virtual object uxmlName { get; }
	public virtual object uxmlNamespace { get; }
	public virtual object uxmlQualifiedName { get; }
	public virtual object uxmlType { get; }

	// Methods

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	public virtual object get_uxmlName() { }

	// RVA: -1
	public virtual object get_uxmlNamespace() { }

	// RVA: -1
	public virtual object get_uxmlQualifiedName() { }

	// RVA: -1
	public virtual object get_uxmlType() { }

	// RVA: -1
	public virtual object AcceptsAttributeBag(object bag, object cc) { }

}

// Namespace: UnityEngine.UIElements
public class UxmlFactory<T0, T1>
{

	// Methods

	// RVA: -1
	public virtual object Create(object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class UxmlObjectFactory<T0, T1>
{

	// Methods

	// RVA: -1
	public virtual object CreateObject(object bag, object cc) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlFactory<T0>
{

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class UxmlAsset
{

	// Fields
	private object m_FullTypeName; // 0x8
	private object m_Id; // 0x10
	private object m_OrderInDocument; // 0x14
	private object m_ParentId; // 0x18
	protected object m_Properties; // 0x20

	// Properties
	public object fullTypeName { get; }
	public object id { get; }
	public object orderInDocument { get; }
	public object parentId { get; }

	// Methods

	// RVA: 0x7694800
	public object get_fullTypeName() { }

	// RVA: 0x7694808
	public object get_id() { }

	// RVA: 0x7694810
	public object get_orderInDocument() { }

	// RVA: 0x7694818
	public object get_parentId() { }

	// RVA: 0x7694820
	public object TryGetAttributeValue(object propertyName, object value) { }

	// RVA: 0x7694910
	public object SetAttribute(object name, object value) { }

	// RVA: 0x7694914
	private object SetOrAddProperty(object propertyName, object propertyValue) { }

}

// Namespace: UnityEngine.UIElements
internal sealed class UxmlObjectAsset
{
}

// Namespace: UnityEngine.UIElements
internal class UxmlObjectFactoryRegistry
{

	// Fields
	private static object s_Factories; // 0x0

	// Properties
	internal static object factories { get; }

	// Methods

	// RVA: 0x7694C14
	internal static object get_factories() { }

	// RVA: 0x7695304
	protected static object RegisterFactory(object factory) { }

	// RVA: 0x7695938
	internal static object TryGetFactories(object fullTypeName, object factoryList) { }

	// RVA: 0x7694CDC
	private static object RegisterEngineFactories() { }

	// RVA: 0x7694F08
	private static object RegisterUserFactories() { }

}

// Namespace: UnityEngine.UIElements
public abstract class UxmlTypeRestriction
{

	// Methods

	// RVA: 0x76959A8
	public virtual object Equals(object other) { }

	// RVA: 0x76959B4
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class UxmlEnumeration
{

	// Fields
	private object m_Values; // 0x8

	// Properties
	public object values { get; set; }

	// Methods

	// RVA: 0x76959BC
	public object get_values() { }

	// RVA: 0x76959C4
	public object set_values(object value) { }

	// RVA: 0x7695A24
	public override object Equals(object other) { }

	// RVA: 0x7695B88
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class VisualElementAsset
{

	// Fields
	private object m_Name; // 0x28
	private object m_RuleIndex; // 0x30
	private object m_Text; // 0x38
	private object m_PickingMode; // 0x40
	private object m_Classes; // 0x48
	private object m_StylesheetPaths; // 0x50
	private object m_Stylesheets; // 0x58

	// Properties
	public object ruleIndex { get; }
	public object classes { get; }
	public object stylesheetPaths { get; }
	public object hasStylesheetPaths { get; }
	public object stylesheets { get; }
	public object hasStylesheets { get; }

	// Methods

	// RVA: 0x7695C08
	public object get_ruleIndex() { }

	// RVA: 0x7695C10
	public object get_classes() { }

	// RVA: 0x7695C18
	public object get_stylesheetPaths() { }

	// RVA: 0x7695CA8
	public object get_hasStylesheetPaths() { }

	// RVA: 0x7695CB8
	public object get_stylesheets() { }

	// RVA: 0x7695D48
	public object get_hasStylesheets() { }

	// RVA: 0x7695D58
	public object OnBeforeSerialize() { }

	// RVA: 0x7695D5C
	public object OnAfterDeserialize() { }

}

// Namespace: UnityEngine.UIElements
internal class VisualElementFactoryRegistry
{

	// Fields
	private static object s_Factories; // 0x0
	private static object s_MovedTypesFactories; // 0x8

	// Properties
	internal static object factories { get; }

	// Methods

	// RVA: 0x7695F24
	private static object GetMovedUIControlTypeName(object type, object attr) { }

	// RVA: 0x76960C8
	internal static object get_factories() { }

	// RVA: 0x76977BC
	protected static object RegisterFactory(object factory) { }

	// RVA: 0x7697F84
	internal static object TryGetValue(object fullTypeName, object factoryList) { }

	// RVA: 0x76961D4
	private static object RegisterEngineFactories() { }

	// RVA: 0x76973C0
	internal static object RegisterUserFactories() { }

}

// Namespace: 
internal struct UsingEntry
{

	// Fields
	internal static readonly object comparer; // 0x0
	public object alias; // 0xFFFFFFFFFFFFFFF8
	public object path; // 0x0
	public object asset; // 0x8

	// Methods

	// RVA: 0x753BE5C
	public object .ctor(object alias, object path) { }

	// RVA: 0x753BE74
	private static object .cctor() { }

}

// Namespace: 
private class UsingEntryComparer
{

	// Methods

	// RVA: 0x753BEF8
	public object Compare(object x, object y) { }

	// RVA: 0x753BEF0
	public object .ctor() { }

}

// Namespace: 
internal struct SlotDefinition
{

	// Fields
	public object name; // 0xFFFFFFFFFFFFFFF8
	public object insertionPointId; // 0x0
}

// Namespace: 
internal struct SlotUsageEntry
{

	// Fields
	public object slotName; // 0xFFFFFFFFFFFFFFF8
	public object assetId; // 0x0
}

// Namespace: 
internal struct UxmlObjectEntry
{

	// Fields
	public object parentId; // 0xFFFFFFFFFFFFFFF8
	public object uxmlObjectAssets; // 0x0

	// Methods

	// RVA: 0x753C074
	public object .ctor(object parentId, object uxmlObjectAssets) { }

}

// Namespace: 
private struct AssetEntry
{

	// Fields
	public object path; // 0xFFFFFFFFFFFFFFF8
	public object typeFullName; // 0x0
	public object asset; // 0x8
	private object m_CachedType; // 0x10

	// Properties
	public object type { get; }

	// Methods

	// RVA: 0x753C0C8
	public object get_type() { }

	// RVA: 0x753C228
	public object .ctor(object path, object type, object asset) { }

}

// Namespace: 
private sealed class <>c__DisplayClass61_0
{

	// Fields
	public object childVea; // 0x8

	// Methods

	// RVA: 0x753C308
	public object .ctor() { }

	// RVA: 0x753C310
	internal object <CloneSetupRecursively>b__0(object u) { }

}

// Namespace: 
private struct <>c__DisplayClass65_0
{

	// Fields
	public object asset; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
private sealed class <get_stylesheets>d__23
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	public object <>4__this; // 0x20
	private object <sent>5__1; // 0x28
	private object <>s__2; // 0x30
	private object <vea>5__3; // 0x48
	private object <>s__4; // 0x50
	private object <stylesheet>5__5; // 0x68
	private object <>s__6; // 0x70
	private object <stylesheetPath>5__7; // 0x88
	private object <stylesheet>5__8; // 0x90

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.UIElements.StyleSheet>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x753C33C
	public object .ctor(object <>1__state) { }

	// RVA: 0x753C374
	private object System.IDisposable.Dispose() { }

	// RVA: 0x753C598
	private object MoveNext() { }

	// RVA: 0x753CD8C
	private object <>m__Finally1() { }

	// RVA: 0x753CCD4
	private object <>m__Finally2() { }

	// RVA: 0x753CD30
	private object <>m__Finally3() { }

	// RVA: 0x753CE1C
	private object System.Collections.Generic.IEnumerator<UnityEngine.UIElements.StyleSheet>.get_Current() { }

	// RVA: 0x753CE24
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x753CE64
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x753CE6C
	private object System.Collections.Generic.IEnumerable<UnityEngine.UIElements.StyleSheet>.GetEnumerator() { }

	// RVA: 0x753CF18
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <get_templateDependencies>d__19
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	public object <>4__this; // 0x20
	private object <sent>5__1; // 0x28
	private object <>s__2; // 0x30
	private object <entry>5__3; // 0x58
	private object <vta>5__4; // 0x70

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.UIElements.VisualTreeAsset>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x753CFC4
	public object .ctor(object <>1__state) { }

	// RVA: 0x753CFFC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x753D080
	private object MoveNext() { }

	// RVA: 0x753D5E4
	private object <>m__Finally1() { }

	// RVA: 0x753D674
	private object System.Collections.Generic.IEnumerator<UnityEngine.UIElements.VisualTreeAsset>.get_Current() { }

	// RVA: 0x753D67C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x753D6BC
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x753D6C4
	private object System.Collections.Generic.IEnumerable<UnityEngine.UIElements.VisualTreeAsset>.GetEnumerator() { }

	// RVA: 0x753D770
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: UnityEngine.UIElements
public class VisualTreeAsset
{

	// Fields
	internal static object LinkedVEAInTemplatePropertyName; // 0x0
	private object m_ImportedWithErrors; // 0x10
	private object m_ImportedWithWarnings; // 0x11
	private static readonly object s_TemporarySlotInsertionPoints; // 0x8
	private object m_Usings; // 0x18
	internal object inlineSheet; // 0x20
	private object m_VisualElementAssets; // 0x28
	private object m_TemplateAssets; // 0x30
	private object m_UxmlObjectEntries; // 0x38
	private object m_UxmlObjectIds; // 0x40
	private object m_AssetEntries; // 0x48
	private object m_Slots; // 0x50
	private object m_ContentContainerId; // 0x58
	private object m_ContentHash; // 0x5C

	// Properties
	public object importedWithErrors { get; set; }
	public object importedWithWarnings { get; set; }
	public object templateDependencies { get; }
	public object stylesheets { get; }
	internal object visualElementAssets { get; set; }
	internal object templateAssets { get; set; }
	internal object uxmlObjectEntries { get; }
	internal object uxmlObjectIds { get; }
	internal object slots { get; set; }
	internal object contentContainerId { get; set; }
	public object contentHash { get; set; }

	// Methods

	// RVA: 0x769804C
	public object get_importedWithErrors() { }

	// RVA: 0x7698054
	internal object set_importedWithErrors(object value) { }

	// RVA: 0x769805C
	public object get_importedWithWarnings() { }

	// RVA: 0x7698064
	internal object set_importedWithWarnings(object value) { }

	// RVA: 0x769806C
	internal object GetNextChildSerialNumber() { }

	// RVA: 0x76980EC
	public object get_templateDependencies() { }

	// RVA: 0x7698168
	public object get_stylesheets() { }

	// RVA: 0x76981E4
	internal object get_visualElementAssets() { }

	// RVA: 0x76981EC
	internal object set_visualElementAssets(object value) { }

	// RVA: 0x76981F4
	internal object get_templateAssets() { }

	// RVA: 0x76981FC
	internal object set_templateAssets(object value) { }

	// RVA: 0x7698204
	internal object get_uxmlObjectEntries() { }

	// RVA: 0x769820C
	internal object get_uxmlObjectIds() { }

	// RVA: 0x7698214
	internal object RegisterUxmlObject(object uxmlObjectAsset) { }

	// RVA: -1
	internal object GetUxmlObjects(object asset, object cc) { }

	// RVA: 0x7698814
	internal object AssetEntryExists(object path, object type) { }

	// RVA: 0x7698A34
	internal object RegisterAssetEntry(object path, object type, object asset) { }

	// RVA: -1
	internal object GetAsset(object path) { }

	// RVA: 0x76986A4
	internal object GetUxmlObjectEntry(object id) { }

	// RVA: 0x7698C28
	private object GetUxmlObjectFactory(object uxmlObjectAsset) { }

	// RVA: 0x7699020
	internal object get_slots() { }

	// RVA: 0x7699028
	internal object set_slots(object value) { }

	// RVA: 0x7699030
	internal object get_contentContainerId() { }

	// RVA: 0x7699038
	internal object set_contentContainerId(object value) { }

	// RVA: 0x7699040
	public object Instantiate() { }

	// RVA: 0x769924C
	public object Instantiate(object bindingPath) { }

	// RVA: 0x7699280
	public object CloneTree() { }

	// RVA: 0x7699284
	public object CloneTree(object bindingPath) { }

	// RVA: 0x76992B8
	public object CloneTree(object target) { }

	// RVA: 0x76992E4
	public object CloneTree(object target, object firstElementIndex, object elementAddedCount) { }

	// RVA: 0x767C060
	internal object CloneTree(object target, object slotInsertionPoints, object attributeOverrides) { }

	// RVA: 0x7699988
	private object CloneSetupRecursively(object root, object idToChildren, object context) { }

	// RVA: 0x769AD60
	private static object CompareForOrder(object a, object b) { }

	// RVA: 0x769AC9C
	internal object TryGetSlotInsertionPoint(object insertionPointId, object slotName) { }

	// RVA: 0x767BCC4
	internal object ResolveTemplate(object templateName) { }

	// RVA: 0x769A630
	internal static object Create(object asset, object ctx) { }

	// RVA: 0x769956C
	private static object AssignClassListFromAssetToElement(object asset, object element) { }

	// RVA: 0x7699604
	private static object AssignStyleSheetFromAssetToElement(object asset, object element) { }

	// RVA: 0x769AF1C
	public object get_contentHash() { }

	// RVA: 0x769AF24
	public object set_contentHash(object value) { }

	// RVA: 0x769AF2C
	public object .ctor() { }

	// RVA: 0x769AF34
	private static object .cctor() { }

	// RVA: 0x769ADB0
	internal static object <Create>g__CreateError|65_0(object ) { }

}

// Namespace: UnityEngine.UIElements
public struct CreationContext
{

	// Fields
	public static readonly object Default; // 0x0
	private object <target>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private object <visualTreeAsset>k__BackingField; // 0x0
	private object <slotInsertionPoints>k__BackingField; // 0x8
	private object <attributeOverrides>k__BackingField; // 0x10

	// Properties
	public object target { get; set; }
	public object visualTreeAsset { get; set; }
	public object slotInsertionPoints { get; set; }
	internal object attributeOverrides { get; set; }

	// Methods

	// RVA: 0x753D858
	public object get_target() { }

	// RVA: 0x753D868
	private object set_target(object value) { }

	// RVA: 0x753D878
	public object get_visualTreeAsset() { }

	// RVA: 0x753D888
	private object set_visualTreeAsset(object value) { }

	// RVA: 0x753D898
	public object get_slotInsertionPoints() { }

	// RVA: 0x753D8A8
	private object set_slotInsertionPoints(object value) { }

	// RVA: 0x753D8B8
	internal object get_attributeOverrides() { }

	// RVA: 0x753D8C8
	private object set_attributeOverrides(object value) { }

	// RVA: 0x753D8D8
	internal object .ctor(object slotInsertionPoints, object vta, object target) { }

	// RVA: 0x753D9A8
	internal object .ctor(object slotInsertionPoints, object attributeOverrides, object vta, object target) { }

	// RVA: 0x753DB80
	public override object Equals(object obj) { }

	// RVA: 0x753DC4C
	public object Equals(object other) { }

	// RVA: 0x753DF30
	public override object GetHashCode() { }

	// RVA: 0x753E0FC
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal enum GradientType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Linear;
	public const object Radial;
}

// Namespace: UnityEngine.UIElements
internal enum AddressMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Wrap;
	public const object Clamp;
	public const object Mirror;
}

// Namespace: UnityEngine.UIElements
internal struct VectorImageVertex
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object tint; // 0x4
	public object uv; // 0x8
	public object settingIndex; // 0x10
	public object flags; // 0x14
	public object circle; // 0x18
}

// Namespace: UnityEngine.UIElements
internal struct GradientSettings
{

	// Fields
	public object gradientType; // 0xFFFFFFFFFFFFFFF8
	public object addressMode; // 0xFFFFFFFFFFFFFFFC
	public object radialFocus; // 0x0
	public object location; // 0x8
}

// Namespace: UnityEngine.UIElements
public class VectorImage
{

	// Fields
	internal object version; // 0x10
	internal object atlas; // 0x18
	internal object vertices; // 0x20
	internal object indices; // 0x28
	internal object settings; // 0x30
	internal object size; // 0x38

	// Properties
	public object width { get; }
	public object height { get; }

	// Methods

	// RVA: 0x753E14C
	public object get_width() { }

	// RVA: 0x753E154
	public object get_height() { }

	// RVA: 0x753E15C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal enum PseudoStates
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Active;
	public const object Hover;
	public const object Checked;
	public const object Disabled;
	public const object Focus;
	public const object Root;
}

// Namespace: UnityEngine.UIElements
internal enum VisualElementFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WorldTransformDirty;
	public const object WorldTransformInverseDirty;
	public const object WorldClipDirty;
	public const object BoundingBoxDirty;
	public const object WorldBoundingBoxDirty;
	public const object EventCallbackParentCategoriesDirty;
	public const object LayoutManual;
	public const object CompositeRoot;
	public const object RequireMeasureFunction;
	public const object EnableViewDataPersistence;
	public const object DisableClipping;
	public const object NeedsAttachToPanelEvent;
	public const object HierarchyDisplayed;
	public const object StyleInitialized;
	public const object Init;
}

// Namespace: UnityEngine.UIElements
public enum PickingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Position;
	public const object Ignore;
}

// Namespace: UnityEngine.UIElements
public enum LanguageDirection
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Inherit;
	public const object LTR;
	public const object RTL;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x753E5B0
	private static object .cctor() { }

	// RVA: 0x753E610
	public object .ctor() { }

	// RVA: 0x753E618
	internal object <.cctor>b__4_0() { }

}

// Namespace: UnityEngine.UIElements
internal static class VisualElementListPool
{

	// Fields
	private static object pool; // 0x0

	// Methods

	// RVA: 0x753E1D4
	public static object Copy(object elements) { }

	// RVA: 0x753E2B8
	public static object Get(object initialCapacity) { }

	// RVA: 0x753E3D0
	public static object Release(object elements) { }

	// RVA: 0x753E49C
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__4_0() { }

}

// Namespace: UnityEngine.UIElements
internal class ObjectListPool<T0>
{

	// Fields
	private static object pool; // 0x0

	// Methods

	// RVA: -1
	public static object Get() { }

	// RVA: -1
	public static object Release(object elements) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
public static class VisualElementExtensions
{

	// Methods

	// RVA: 0x753E68C
	public static object StretchToParentSize(object elem) { }

	// RVA: 0x753EA28
	public static object AddManipulator(object ele, object manipulator) { }

	// RVA: 0x753EAFC
	public static object RemoveManipulator(object ele, object manipulator) { }

	// RVA: 0x753EBCC
	public static object WorldToLocal(object ele, object p) { }

	// RVA: 0x753ECB0
	public static object LocalToWorld(object ele, object p) { }

	// RVA: 0x753ED94
	public static object WorldToLocal(object ele, object r) { }

	// RVA: 0x753EE84
	public static object ChangeCoordinatesTo(object src, object dest, object point) { }

}

// Namespace: 
private struct DefaultEventInterests
{

	// Fields
	public object DefaultActionCategories; // 0xFFFFFFFFFFFFFFF8
	public object DefaultActionAtTargetCategories; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: UnityEngine.UIElements
internal static class EventInterestReflectionUtils
{

	// Fields
	private static readonly object s_DefaultEventInterests; // 0x0
	private static readonly object s_EventCategories; // 0x8

	// Methods

	// RVA: 0x753EEA8
	internal static object GetDefaultEventInterests(object elementType, object defaultActionCategories, object defaultActionAtTargetCategories) { }

	// RVA: 0x753F144
	private static object ComputeDefaultEventInterests(object elementType, object methodName) { }

	// RVA: 0x753F3A4
	internal static object GetEventCategory(object eventType) { }

	// RVA: 0x753F624
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal enum EventCategory
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Pointer;
	public const object PointerMove;
	public const object EnterLeave;
	public const object EnterLeaveWindow;
	public const object Keyboard;
	public const object Geometry;
	public const object Style;
	public const object ChangeValue;
	public const object Bind;
	public const object Focus;
	public const object ChangePanel;
	public const object StyleTransition;
	public const object Navigation;
	public const object Command;
	public const object Tooltip;
	public const object IMGUI;
	public const object Reserved;
}

// Namespace: UnityEngine.UIElements
internal enum EventCategoryFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object All;
	public const object TriggeredByOS;
	public const object TargetOnly;
}

// Namespace: UnityEngine.UIElements
public enum EventInterestOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Inherit;
	public const object AllEventTypes;
}

// Namespace: UnityEngine.UIElements
public class EventInterestAttribute
{

	// Fields
	internal object eventTypes; // 0x8
	internal object categoryFlags; // 0x10

	// Methods

	// RVA: 0x753F704
	public object .ctor(object eventTypes) { }

	// RVA: 0x753F734
	public object .ctor(object interests) { }

}

// Namespace: UnityEngine.UIElements
internal class EventCategoryAttribute
{

	// Fields
	internal object category; // 0x8

	// Methods

	// RVA: 0x753F764
	public object .ctor(object category) { }

}

// Namespace: UnityEngine.UIElements
public interface IExperimentalFeatures
{

	// Properties
	public abstract object animation { get; }

	// Methods

	// RVA: -1
	public abstract object get_animation() { }

}

// Namespace: UnityEngine.UIElements
public class VisualElementFocusChangeDirection
{

	// Fields
	private static readonly object s_Left; // 0x0
	private static readonly object s_Right; // 0x8

	// Properties
	public static object left { get; }
	public static object right { get; }

	// Methods

	// RVA: 0x753F790
	public static object get_left() { }

	// RVA: 0x753F80C
	public static object get_right() { }

	// RVA: 0x753F888
	protected object .ctor(object value) { }

	// RVA: 0x753F8F4
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x753FEAC
	private static object .cctor() { }

	// RVA: 0x753FF0C
	public object .ctor() { }

	// RVA: 0x753FF14
	internal object <.cctor>b__9_0() { }

}

// Namespace: UnityEngine.UIElements
internal class VisualElementFocusChangeTarget
{

	// Fields
	private static readonly object Pool; // 0x0
	private object <target>k__BackingField; // 0x10

	// Properties
	public object target { get; set; }

	// Methods

	// RVA: 0x753FAD0
	public static object GetPooled(object target) { }

	// RVA: 0x753FB90
	protected override object Dispose() { }

	// RVA: 0x753FC44
	internal override object ApplyTo(object focusController, object f) { }

	// RVA: 0x753FCB4
	public object .ctor() { }

	// RVA: 0x753FD88
	public object get_target() { }

	// RVA: 0x753FD90
	private object set_target(object value) { }

	// RVA: 0x753FD98
	private static object .cctor() { }

}

// Namespace: 
public enum DefaultFocusOrder
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ChildOrder;
	public const object PositionXY;
	public const object PositionYX;
}

// Namespace: 
private class FocusRingRecord
{

	// Fields
	public object m_AutoIndex; // 0x8
	public object m_Focusable; // 0x10
	public object m_IsSlot; // 0x18
	public object m_ScopeNavigationOrder; // 0x20

	// Methods

	// RVA: 0x7540E64
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
public class VisualElementFocusRing
{

	// Fields
	private readonly object root; // 0x8
	private object <defaultFocusOrder>k__BackingField; // 0x10
	private object m_FocusRing; // 0x18

	// Properties
	private object focusController { get; }
	public object defaultFocusOrder { get; set; }

	// Methods

	// RVA: 0x753FF68
	public object .ctor(object root, object dfo) { }

	// RVA: 0x7540004
	private object get_focusController() { }

	// RVA: 0x7540054
	public object get_defaultFocusOrder() { }

	// RVA: 0x754005C
	public object set_defaultFocusOrder(object value) { }

	// RVA: 0x7540064
	private object FocusRingAutoIndexSort(object a, object b) { }

	// RVA: 0x7540434
	private object FocusRingSort(object a, object b) { }

	// RVA: 0x75405E4
	private object DoUpdate() { }

	// RVA: 0x75406E0
	private object BuildRingForScopeRecursive(object ve, object scopeIndex, object scopeList) { }

	// RVA: 0x7540B0C
	private object SortAndFlattenScopeLists(object rootScopeList) { }

	// RVA: 0x7540EAC
	private object GetFocusableInternalIndex(object f) { }

	// RVA: 0x7540F6C
	public object GetFocusChangeDirection(object currentFocusable, object e) { }

	// RVA: 0x7541414
	public object GetNextFocusable(object currentFocusable, object direction) { }

	// RVA: 0x7541A98
	internal static object GetNextFocusableInTree(object currentFocusable) { }

	// RVA: 0x7541B70
	internal static object GetPreviousFocusableInTree(object currentFocusable) { }

}

// Namespace: UnityEngine.UIElements
public interface IVisualElementScheduledItem
{

	// Methods

	// RVA: -1
	public abstract object Resume() { }

	// RVA: -1
	public abstract object Pause() { }

	// RVA: -1
	public abstract object ExecuteLater(object delayMs) { }

	// RVA: -1
	public abstract object StartingIn(object delayMs) { }

	// RVA: -1
	public abstract object Every(object intervalMs) { }

}

// Namespace: UnityEngine.UIElements
public interface IVisualElementScheduler
{

	// Methods

	// RVA: -1
	public abstract object Execute(object timerUpdateEvent) { }

	// RVA: -1
	public abstract object Execute(object updateEvent) { }

}

// Namespace: UnityEngine.UIElements
internal interface IVisualElementPanelActivatable
{

	// Properties
	public abstract object element { get; }

	// Methods

	// RVA: -1
	public abstract object get_element() { }

	// RVA: -1
	public abstract object CanBeActivated() { }

	// RVA: -1
	public abstract object OnPanelActivate() { }

	// RVA: -1
	public abstract object OnPanelDeactivate() { }

}

// Namespace: UnityEngine.UIElements
internal class VisualElementPanelActivator
{

	// Fields
	private object m_Activatable; // 0x8
	private object <isActive>k__BackingField; // 0x10
	private object <isDetaching>k__BackingField; // 0x11
	private object m_OnAttachToPanelCallback; // 0x18
	private object m_OnDetachFromPanelCallback; // 0x20

	// Properties
	public object isActive { get; set; }
	public object isDetaching { get; set; }

	// Methods

	// RVA: 0x7541CA0
	public object get_isActive() { }

	// RVA: 0x7541CA8
	private object set_isActive(object value) { }

	// RVA: 0x7541CB0
	public object get_isDetaching() { }

	// RVA: 0x7541CB8
	private object set_isDetaching(object value) { }

	// RVA: 0x7541CC0
	public object .ctor(object activatable) { }

	// RVA: 0x7541DAC
	public object SetActive(object action) { }

	// RVA: 0x754215C
	public object SendActivation() { }

	// RVA: 0x75422E0
	public object SendDeactivation() { }

	// RVA: 0x7542464
	private object OnEnter(object evt) { }

	// RVA: 0x7542478
	private object OnLeave(object evt) { }

}

// Namespace: UnityEngine.UIElements
public struct VisualElementStyleSheetSet
{

	// Fields
	private readonly object m_Element; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x7542530
	internal object .ctor(object element) { }

	// RVA: 0x7542540
	public object Add(object styleSheet) { }

	// RVA: 0x75427D8
	public object Remove(object styleSheet) { }

	// RVA: 0x754294C
	public object Equals(object other) { }

	// RVA: 0x7542964
	public override object Equals(object obj) { }

	// RVA: 0x7542AA4
	public override object GetHashCode() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__5_0; // 0x8

	// Methods

	// RVA: 0x7542FF4
	private static object .cctor() { }

	// RVA: 0x7543054
	public object .ctor() { }

	// RVA: 0x754305C
	internal object <AssignInspectorStyleIfNecessary>b__5_0(object i) { }

}

// Namespace: UnityEngine.UIElements
internal static class VisualElementUtils
{

	// Fields
	private static readonly object s_usedNames; // 0x0
	private static readonly object s_FoldoutType; // 0x8
	private static readonly object s_InspectorElementUssClassName; // 0x10

	// Methods

	// RVA: 0x7542B44
	public static object GetUniqueName(object nameBase) { }

	// RVA: 0x7542C88
	internal static object GetFoldoutDepth(object element) { }

	// RVA: 0x7542DC0
	internal static object AssignInspectorStyleIfNecessary(object element, object classNameToEnable) { }

	// RVA: 0x7542EF0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class VisualElementAnimationSystem
{

	// Fields
	private object m_Animations; // 0x18
	private object m_IterationList; // 0x20
	private object m_HasNewAnimations; // 0x28
	private object m_IterationListDirty; // 0x29
	private static readonly object s_Description; // 0x0
	private static readonly object s_ProfilerMarker; // 0x8
	private static readonly object s_StylePropertyAnimationDescription; // 0x10
	private static readonly object s_StylePropertyAnimationProfilerMarker; // 0x18
	private object lastUpdate; // 0x30

	// Properties
	public override object profilerMarker { get; }
	private static object stylePropertyAnimationProfilerMarker { get; }

	// Methods

	// RVA: 0x75430EC
	public override object get_profilerMarker() { }

	// RVA: 0x7543168
	private static object get_stylePropertyAnimationProfilerMarker() { }

	// RVA: 0x75431E4
	public object UnregisterAnimation(object anim) { }

	// RVA: 0x754325C
	public object UnregisterAnimations(object anims) { }

	// RVA: 0x7543418
	public object RegisterAnimation(object anim) { }

	// RVA: 0x7543490
	public object RegisterAnimations(object anims) { }

	// RVA: 0x754360C
	public override object Update() { }

	// RVA: 0x7543ACC
	public override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x7543AD0
	public object .ctor() { }

	// RVA: 0x7543BA4
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class VisualTreeHierarchyFlagsUpdater
{

	// Fields
	private object m_Version; // 0x18
	private object m_LastVersion; // 0x1C
	private static readonly object s_Description; // 0x0
	private static readonly object s_ProfilerMarker; // 0x8

	// Properties
	public override object profilerMarker { get; }

	// Methods

	// RVA: 0x7543C6C
	public override object get_profilerMarker() { }

	// RVA: 0x7543CE8
	public override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x7543DD8
	private static object DirtyHierarchy(object ve, object mustDirtyFlags) { }

	// RVA: 0x7543EEC
	private static object DirtyBoundingBoxHierarchy(object ve) { }

	// RVA: 0x7543FA4
	public override object Update() { }

	// RVA: 0x7544048
	public object .ctor() { }

	// RVA: 0x7544054
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal enum HierarchyChangeType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object Remove;
	public const object Move;
}

// Namespace: 
private enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Waiting;
	public const object TrackingAddOrMove;
	public const object TrackingRemove;
}

// Namespace: UnityEngine.UIElements
internal abstract class BaseVisualTreeHierarchyTrackerUpdater
{

	// Fields
	private object m_State; // 0x18
	private object m_CurrentChangeElement; // 0x20
	private object m_CurrentChangeParent; // 0x28

	// Methods

	// RVA: -1
	protected abstract object OnHierarchyChange(object ve, object type) { }

	// RVA: 0x75440E0
	public override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x7544524
	public override object Update() { }

	// RVA: 0x7544260
	private object ProcessNewChange(object ve) { }

	// RVA: 0x75443A0
	private object ProcessAddOrMove(object ve) { }

	// RVA: 0x7544314
	private object ProcessRemove(object ve) { }

	// RVA: 0x75445DC
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal static class StyleCache
{

	// Fields
	private static object s_ComputedStyleCache; // 0x0
	private static object s_StyleVariableContextCache; // 0x8
	private static object s_ComputedTransitionsCache; // 0x10

	// Methods

	// RVA: 0x75445E8
	public static object TryGetValue(object hash, object data) { }

	// RVA: 0x754469C
	public static object SetValue(object hash, object data) { }

	// RVA: 0x754477C
	public static object TryGetValue(object hash, object data) { }

	// RVA: 0x7544830
	public static object SetValue(object hash, object data) { }

	// RVA: 0x75448E4
	public static object TryGetValue(object hash, object data) { }

	// RVA: 0x7544998
	public static object SetValue(object hash, object data) { }

	// RVA: 0x7544A4C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class VisualTreeStyleUpdater
{

	// Fields
	private object m_ApplyStyleUpdateList; // 0x18
	private object m_TransitionPropertyUpdateList; // 0x20
	private object m_IsApplyingStyles; // 0x28
	private object m_Version; // 0x2C
	private object m_LastVersion; // 0x30
	private object m_StyleContextHierarchyTraversal; // 0x38
	private static readonly object s_Description; // 0x0
	private static readonly object s_ProfilerMarker; // 0x8
	private object <disposed>k__BackingField; // 0x40

	// Properties
	public override object profilerMarker { get; }
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x7544B7C
	public override object get_profilerMarker() { }

	// RVA: 0x7544BF8
	public override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x7544DDC
	public override object Update() { }

	// RVA: 0x754571C
	protected object get_disposed() { }

	// RVA: 0x7545724
	private object set_disposed(object value) { }

	// RVA: 0x754572C
	protected override object Dispose(object disposing) { }

	// RVA: 0x75451AC
	private object ApplyStyles() { }

	// RVA: 0x75457D0
	public object .ctor() { }

	// RVA: 0x7545AA0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements
internal class StyleMatchingContext
{

	// Fields
	private object m_StyleSheetStack; // 0x8
	public object variableContext; // 0x10
	public object currentElement; // 0x18
	public object processResult; // 0x20
	public object ancestorFilter; // 0x28

	// Properties
	public object styleSheetCount { get; }

	// Methods

	// RVA: 0x7545B2C
	public object get_styleSheetCount() { }

	// RVA: 0x7545B80
	public object .ctor(object processResult) { }

	// RVA: 0x7545C7C
	public object AddStyleSheet(object sheet) { }

	// RVA: 0x7545E08
	public object RemoveStyleSheetRange(object index, object count) { }

	// RVA: 0x7545E7C
	public object GetStyleSheetAt(object index) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__24_0; // 0x8

	// Methods

	// RVA: 0x7547C30
	private static object .cctor() { }

	// RVA: 0x7547C90
	public object .ctor() { }

	// RVA: 0x7547C98
	internal object <ProcessMatchedRules>b__24_0(object a, object b) { }

}

// Namespace: UnityEngine.UIElements
internal class VisualTreeStyleUpdaterTraversal
{

	// Fields
	private object m_ProcessVarContext; // 0x8
	private object m_UpdateList; // 0x10
	private object m_ParentList; // 0x18
	private object m_TempMatchResults; // 0x20
	private object <currentPixelsPerPoint>k__BackingField; // 0x28
	private object m_StyleMatchingContext; // 0x30
	private object m_StylePropertyReader; // 0x38
	private readonly object m_AnimatedProperties; // 0x40

	// Properties
	private object currentPixelsPerPoint { get; set; }

	// Methods

	// RVA: 0x7545EE8
	private object get_currentPixelsPerPoint() { }

	// RVA: 0x7545EF0
	private object set_currentPixelsPerPoint(object value) { }

	// RVA: 0x75457C8
	public object PrepareTraversal(object pixelsPerPoint) { }

	// RVA: 0x7544D50
	public object AddChangedElement(object ve, object versionChangeType) { }

	// RVA: 0x7545314
	public object Clear() { }

	// RVA: 0x7545EF8
	private object PropagateToChildren(object ve) { }

	// RVA: 0x7545FEC
	private object PropagateToParents(object ve) { }

	// RVA: 0x75460B0
	private static object OnProcessMatchResult(object current, object info) { }

	// RVA: 0x75460E8
	public override object TraverseRecursive(object element, object depth) { }

	// RVA: 0x7547650
	private object ProcessTransitions(object element, object oldStyle, object newStyle) { }

	// RVA: 0x7547774
	private object ForceUpdateTransitions(object element) { }

	// RVA: 0x75453DC
	internal object CancelAnimationsWithNoTransitionProperty(object element, object newStyle) { }

	// RVA: 0x7546A70
	protected object ShouldSkipElement(object element) { }

	// RVA: 0x7546B1C
	private object ProcessMatchedRules(object element, object matchingSelectors) { }

	// RVA: 0x7547B08
	private object ProcessMatchedVariables(object sheet, object rule) { }

	// RVA: 0x75458A0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal enum VisualTreeUpdatePhase
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ViewData;
	public const object Bindings;
	public const object Animation;
	public const object Styles;
	public const object Layout;
	public const object TransformClip;
	public const object Repaint;
	public const object Count;
}

// Namespace: 
private class UpdaterArray
{

	// Fields
	private object m_VisualTreeUpdaters; // 0x8

	// Properties
	public object Item { get; set; }
	public object Item { get; }

	// Methods

	// RVA: 0x7547D98
	public object .ctor() { }

	// RVA: 0x75484AC
	public object set_Item(object phase, object value) { }

	// RVA: 0x75482F0
	public object get_Item(object phase) { }

	// RVA: 0x754807C
	public object get_Item(object index) { }

}

// Namespace: UnityEngine.UIElements
internal sealed class VisualTreeUpdater
{

	// Fields
	private object m_Panel; // 0x8
	private object m_UpdaterArray; // 0x10

	// Methods

	// RVA: 0x7547CE0
	public object .ctor(object panel) { }

	// RVA: 0x7547F48
	public object Dispose() { }

	// RVA: 0x75480B8
	public object UpdateVisualTreePhase(object phase) { }

	// RVA: 0x754832C
	public object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: -1
	public object SetUpdater(object phase) { }

	// RVA: 0x7548468
	public object GetUpdater(object phase) { }

	// RVA: 0x7547E00
	private object SetDefaultUpdaters() { }

}

// Namespace: UnityEngine.UIElements
internal interface IVisualTreeUpdater
{

	// Properties
	public abstract object panel { set; }
	public abstract object profilerMarker { get; }

	// Methods

	// RVA: -1
	public abstract object set_panel(object value) { }

	// RVA: -1
	public abstract object get_profilerMarker() { }

	// RVA: -1
	public abstract object Update() { }

	// RVA: -1
	public abstract object OnVersionChanged(object ve, object versionChangeType) { }

}

// Namespace: UnityEngine.UIElements
internal abstract class BaseVisualTreeUpdater
{

	// Fields
	private object panelChanged; // 0x8
	private object m_Panel; // 0x10

	// Properties
	public object panel { get; set; }
	public object visualTree { get; }
	public abstract object profilerMarker { get; }

	// Methods

	// RVA: 0x7548524
	public object add_panelChanged(object value) { }

	// RVA: 0x75485D8
	public object remove_panelChanged(object value) { }

	// RVA: 0x7543AC4
	public object get_panel() { }

	// RVA: 0x754868C
	public object set_panel(object value) { }

	// RVA: 0x7545778
	public object get_visualTree() { }

	// RVA: -1
	public abstract object get_profilerMarker() { }

	// RVA: 0x75486AC
	public object Dispose() { }

	// RVA: 0x7548744
	protected virtual object Dispose(object disposing) { }

	// RVA: -1
	public abstract object Update() { }

	// RVA: -1
	public abstract object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x7543B9C
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements
internal class VisualTreeViewDataUpdater
{

	// Fields
	private object m_UpdateList; // 0x18
	private object m_ParentList; // 0x20
	private object m_Version; // 0x28
	private object m_LastVersion; // 0x2C
	private static readonly object s_Description; // 0x0
	private static readonly object s_ProfilerMarker; // 0x8

	// Properties
	public override object profilerMarker { get; }

	// Methods

	// RVA: 0x7548748
	public override object get_profilerMarker() { }

	// RVA: 0x75487C4
	public override object OnVersionChanged(object ve, object versionChangeType) { }

	// RVA: 0x7548924
	public override object Update() { }

	// RVA: 0x7548C68
	private object ValidateViewDataOnSubTree(object ve, object enablePersistence) { }

	// RVA: 0x7548860
	private object PropagateToParents(object ve) { }

	// RVA: 0x7548DFC
	public object .ctor() { }

	// RVA: 0x7548E94
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal struct GfxUpdateBufferRange
{

	// Fields
	public object offsetFromWriteStart; // 0xFFFFFFFFFFFFFFF8
	public object size; // 0xFFFFFFFFFFFFFFFC
	public object source; // 0x0
}

// Namespace: UnityEngine.UIElements.UIR
internal struct DrawBufferRange
{

	// Fields
	public object firstIndex; // 0xFFFFFFFFFFFFFFF8
	public object indexCount; // 0xFFFFFFFFFFFFFFFC
	public object minIndexVal; // 0x0
	public object vertsReferenced; // 0x4
}

// Namespace: 
internal enum GPUBufferType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Vertex;
	public const object Index;
}

// Namespace: 
public class GPUBuffer<T0>
{

	// Fields
	private object buffer; // 0x0
	private object elemCount; // 0x0
	private object elemStride; // 0x0

	// Properties
	public object ElementStride { get; }
	internal object BufferPointer { get; }

	// Methods

	// RVA: -1
	public object .ctor(object elementCount, object type) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object UpdateRanges(object ranges, object rangesMin, object rangesMax) { }

	// RVA: -1
	public object get_ElementStride() { }

	// RVA: -1
	internal object get_BufferPointer() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class Utility
{

	// Fields
	private static object GraphicsResourcesRecreate; // 0x0
	private static object EngineUpdate; // 0x8
	private static object FlushPendingResources; // 0x10
	private static object RegisterIntermediateRenderers; // 0x18
	private static object RenderNodeAdd; // 0x20
	private static object RenderNodeExecute; // 0x28
	private static object RenderNodeCleanup; // 0x30
	private static object s_MarkerRaiseEngineUpdate; // 0x38

	// Methods

	// RVA: -1
	public static object SetVectorArray(object props, object name, object vector4s) { }

	// RVA: 0x7548F20
	public static object add_GraphicsResourcesRecreate(object value) { }

	// RVA: 0x7549030
	public static object remove_GraphicsResourcesRecreate(object value) { }

	// RVA: 0x7549140
	public static object add_EngineUpdate(object value) { }

	// RVA: 0x7549230
	public static object remove_EngineUpdate(object value) { }

	// RVA: 0x7549320
	public static object add_FlushPendingResources(object value) { }

	// RVA: 0x7549410
	public static object remove_FlushPendingResources(object value) { }

	// RVA: 0x7549500
	public static object add_RegisterIntermediateRenderers(object value) { }

	// RVA: 0x7549614
	public static object remove_RegisterIntermediateRenderers(object value) { }

	// RVA: 0x7549728
	public static object add_RenderNodeExecute(object value) { }

	// RVA: 0x754983C
	public static object remove_RenderNodeExecute(object value) { }

	// RVA: 0x7549950
	internal static object RaiseGraphicsResourcesRecreate(object recreate) { }

	// RVA: 0x75499F4
	internal static object RaiseEngineUpdate() { }

	// RVA: 0x7549AD4
	internal static object RaiseFlushPendingResources() { }

	// RVA: 0x7549B64
	internal static object RaiseRegisterIntermediateRenderers(object camera) { }

	// RVA: 0x7549C08
	internal static object RaiseRenderNodeAdd(object userData) { }

	// RVA: 0x7549CAC
	internal static object RaiseRenderNodeExecute(object userData) { }

	// RVA: 0x7549D50
	internal static object RaiseRenderNodeCleanup(object userData) { }

	// RVA: 0x7549DF4
	private static object AllocateBuffer(object elementCount, object elementStride, object vertexBuffer) { }

	// RVA: 0x7549E60
	private static object FreeBuffer(object buffer) { }

	// RVA: 0x7549EB0
	private static object UpdateBufferRanges(object buffer, object ranges, object rangeCount, object writeRangeStart, object writeRangeEnd) { }

	// RVA: 0x7549F38
	private static object SetVectorArray(object props, object name, object vector4s, object count) { }

	// RVA: 0x7549FB8
	public static object GetVertexDeclaration(object vertexAttributes) { }

	// RVA: 0x754A008
	public static object RegisterIntermediateRenderer(object camera, object material, object transform, object aabb, object renderLayer, object shadowCasting, object receiveShadows, object sameDistanceSortPriority, object sceneCullingMask, object rendererCallbackFlags, object userData, object userDataSize) { }

	// RVA: 0x754A1C8
	public static object DrawRanges(object ib, object vertexStreams, object streamCount, object ranges, object rangeCount, object vertexDecl) { }

	// RVA: 0x754A264
	public static object SetPropertyBlock(object props) { }

	// RVA: 0x754A2B4
	public static object SetScissorRect(object scissorRect) { }

	// RVA: 0x754A3B8
	public static object DisableScissor() { }

	// RVA: 0x754A3F8
	public static object CreateStencilState(object stencilState) { }

	// RVA: 0x754A500
	public static object SetStencilState(object stencilState, object stencilRef) { }

	// RVA: 0x754A564
	public static object HasMappedBufferRange() { }

	// RVA: 0x754A5A4
	public static object InsertCPUFence() { }

	// RVA: 0x754A5E4
	public static object CPUFencePassed(object fence) { }

	// RVA: 0x754A634
	public static object WaitForCPUFencePassed(object fence) { }

	// RVA: 0x754A684
	public static object SyncRenderThread() { }

	// RVA: 0x754A6C4
	public static object GetActiveViewport() { }

	// RVA: 0x754A7BC
	public static object ProfileDrawChainBegin() { }

	// RVA: 0x754A7FC
	public static object ProfileDrawChainEnd() { }

	// RVA: 0x754A83C
	public static object NotifyOfUIREvents(object subscribe) { }

	// RVA: 0x754A88C
	public static object GetUnityProjectionMatrix() { }

	// RVA: 0x754A9AC
	private static object .cctor() { }

	// RVA: 0x754A10C
	private static object RegisterIntermediateRenderer_Injected(object camera, object material, object transform, object aabb, object renderLayer, object shadowCasting, object receiveShadows, object sameDistanceSortPriority, object sceneCullingMask, object rendererCallbackFlags, object userData, object userDataSize) { }

	// RVA: 0x754A368
	private static object SetScissorRect_Injected(object scissorRect) { }

	// RVA: 0x754A4B0
	private static object CreateStencilState_Injected(object stencilState) { }

	// RVA: 0x754A76C
	private static object GetActiveViewport_Injected(object ret) { }

	// RVA: 0x754A95C
	private static object GetUnityProjectionMatrix_Injected(object ret) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal static class JobProcessor
{

	// Methods

	// RVA: 0x754AA2C
	internal static object ScheduleNudgeJobs(object buffer, object jobCount) { }

	// RVA: 0x754AB04
	internal static object ScheduleConvertMeshJobs(object buffer, object jobCount) { }

	// RVA: 0x754ABDC
	internal static object ScheduleCopyClosingMeshJobs(object buffer, object jobCount) { }

	// RVA: 0x754AA98
	private static object ScheduleNudgeJobs_Injected(object buffer, object jobCount, object ret) { }

	// RVA: 0x754AB70
	private static object ScheduleConvertMeshJobs_Injected(object buffer, object jobCount, object ret) { }

	// RVA: 0x754AC48
	private static object ScheduleCopyClosingMeshJobs_Injected(object buffer, object jobCount, object ret) { }

}

// Namespace: 
public class Area
{

	// Fields
	public object rect; // 0x8
	public object allocator; // 0x18

	// Methods

	// RVA: 0x754C270
	public object .ctor(object rect) { }

}

// Namespace: 
public class Row
{

	// Fields
	public object rect; // 0x10
	public object area; // 0x20
	public object allocator; // 0x28
	public object alloc; // 0x30
	public object next; // 0x48
	public static readonly object pool; // 0x0

	// Methods

	// RVA: 0x754C2F8
	private static object Create() { }

	// RVA: 0x754C3DC
	private static object Reset(object row) { }

	// RVA: 0x754C384
	public object .ctor() { }

	// RVA: 0x754C404
	private static object .cctor() { }

}

// Namespace: 
public struct Alloc2D
{

	// Fields
	public object rect; // 0xFFFFFFFFFFFFFFF8
	public object row; // 0x8
	public object alloc; // 0x10

	// Methods

	// RVA: 0x754BBD8
	public object .ctor(object row, object alloc, object width, object height) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class Allocator2D
{

	// Fields
	private readonly object m_MinSize; // 0x8
	private readonly object m_MaxSize; // 0x10
	private readonly object m_MaxAllocSize; // 0x18
	private readonly object m_RowHeightBias; // 0x20
	private readonly object m_Rows; // 0x28
	private readonly object m_Areas; // 0x30

	// Methods

	// RVA: 0x754ACB4
	public object .ctor(object minSize, object maxSize, object rowHeightBias) { }

	// RVA: 0x754B51C
	public object TryAllocate(object width, object height, object alloc2D) { }

	// RVA: 0x754BDA8
	public object Free(object alloc2D) { }

	// RVA: 0x754AF7C
	private static object BuildAreas(object areas, object minSize, object maxSize) { }

	// RVA: 0x754B364
	private static object ComputeMaxAllocSize(object areas, object rowHeightBias) { }

	// RVA: 0x754B490
	private static object BuildRowArray(object maxRowHeight, object rowHeightBias) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class DetachedAllocator
{

	// Fields
	private object m_VertsPool; // 0x8
	private object m_IndexPool; // 0x10
	private object m_MeshWriteDataPool; // 0x18
	private object m_MeshWriteDataCount; // 0x20
	private object m_Disposed; // 0x24

	// Methods

	// RVA: 0x754C5A8
	public object Dispose() { }

	// RVA: 0x754C6C4
	protected object Dispose(object disposing) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal struct Transform3x4
{

	// Fields
	public object v0; // 0xFFFFFFFFFFFFFFF8
	public object v1; // 0x8
	public object v2; // 0x18
}

// Namespace: UnityEngine.UIElements.UIR
internal class MeshHandle
{

	// Fields
	internal object allocVerts; // 0x10
	internal object allocIndices; // 0x28
	internal object triangleCount; // 0x40
	internal object allocPage; // 0x48
	internal object allocTime; // 0x50
	internal object updateAllocID; // 0x54

	// Methods

	// RVA: 0x754C774
	public object .ctor() { }

}

// Namespace: 
internal struct AllocToUpdate
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object allocTime; // 0xFFFFFFFFFFFFFFFC
	public object meshHandle; // 0x0
	public object permAllocVerts; // 0x8
	public object permAllocIndices; // 0x20
	public object permPage; // 0x38
	public object copyBackIndices; // 0x40
}

// Namespace: 
private struct AllocToFree
{

	// Fields
	public object alloc; // 0xFFFFFFFFFFFFFFF8
	public object page; // 0x10
	public object vertices; // 0x18
}

// Namespace: 
private struct DeviceToFree
{

	// Fields
	public object handle; // 0xFFFFFFFFFFFFFFF8
	public object page; // 0x0

	// Methods

	// RVA: 0x754E5A0
	public object Dispose() { }

}

// Namespace: 
private struct EvaluationState
{

	// Fields
	public object stateMatProps; // 0xFFFFFFFFFFFFFFF8
	public object defaultMat; // 0x0
	public object curState; // 0x8
	public object curPage; // 0x20
	public object mustApplyMaterial; // 0x28
	public object mustApplyCommonBlock; // 0x29
	public object mustApplyStateBlock; // 0x2A
	public object mustApplyStencil; // 0x2B
}

// Namespace: 
internal struct DrawStatistics
{

	// Fields
	public object currentFrameIndex; // 0xFFFFFFFFFFFFFFF8
	public object totalIndices; // 0xFFFFFFFFFFFFFFFC
	public object commandCount; // 0x0
	public object drawCommandCount; // 0x4
	public object materialSetCount; // 0x8
	public object drawRangeCount; // 0xC
	public object drawRangeCallCount; // 0x10
	public object immediateDraws; // 0x14
	public object stencilRefChanges; // 0x18
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__50_0; // 0x8
	public static object <>9__50_1; // 0x10

	// Methods

	// RVA: 0x7553D50
	private static object .cctor() { }

	// RVA: 0x7553DB0
	public object .ctor() { }

	// RVA: 0x7553DB8
	internal object <.ctor>b__50_0() { }

	// RVA: 0x7553E44
	internal object <.ctor>b__50_1(object mh) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class UIRenderDevice
{

	// Fields
	private readonly object m_MockDevice; // 0x8
	private object m_DefaultStencilState; // 0x10
	private object m_VertexDecl; // 0x18
	private object m_FirstPage; // 0x20
	private object m_NextPageVertexCount; // 0x28
	private object m_LargeMeshVertexCount; // 0x2C
	private object m_IndexToVertexCountRatio; // 0x30
	private object m_DeferredFrees; // 0x38
	private object m_Updates; // 0x40
	private object m_Fences; // 0x48
	private object m_StandardMatProps; // 0x50
	private object m_FrameIndex; // 0x58
	private object m_NextUpdateID; // 0x5C
	private object m_DrawStats; // 0x60
	private readonly object m_MeshHandles; // 0x88
	private readonly object m_DrawParams; // 0x90
	private readonly object m_TextureSlotManager; // 0x98
	private static object m_DeviceFreeQueue; // 0x0
	private static object m_ActiveDeviceCount; // 0x8
	private static object m_SubscribedToNotifications; // 0xC
	private static object m_SynchronousFree; // 0xD
	private static readonly object s_GradientSettingsTexID; // 0x10
	private static readonly object s_ShaderInfoTexID; // 0x14
	private static readonly object s_TransformsPropID; // 0x18
	private static readonly object s_ClipRectsPropID; // 0x1C
	private static object s_MarkerAllocate; // 0x20
	private static object s_MarkerFree; // 0x28
	private static object s_MarkerAdvanceFrame; // 0x30
	private static object s_MarkerFence; // 0x38
	private static object s_MarkerBeforeDraw; // 0x40
	private static object s_VertexTexturingIsAvailable; // 0x48
	private static object s_ShaderModelIs35; // 0x4A
	private readonly object <maxVerticesPerPage>k__BackingField; // 0xA0
	private object <breakBatches>k__BackingField; // 0xA4
	private static object s_DefaultShaderInfoTexFloat; // 0x50
	private static object s_DefaultShaderInfoTexARGB8; // 0x58
	private object <disposed>k__BackingField; // 0xA5

	// Properties
	internal object maxVerticesPerPage { get; }
	internal object breakBatches { get; set; }
	internal static object defaultShaderInfoTexFloat { get; }
	internal static object defaultShaderInfoTexARGB8 { get; }
	internal static object vertexTexturingIsAvailable { get; }
	internal static object shaderModelIs35 { get; }
	private object fullyCreated { get; }
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x754C7CC
	internal object get_maxVerticesPerPage() { }

	// RVA: 0x754C7D4
	internal object get_breakBatches() { }

	// RVA: 0x754C7DC
	internal object set_breakBatches(object value) { }

	// RVA: 0x754C7E4
	private static object .cctor() { }

	// RVA: 0x754CAFC
	public object .ctor(object initialVertexCapacity, object initialIndexCapacity) { }

	// RVA: 0x754CB04
	protected object .ctor(object initialVertexCapacity, object initialIndexCapacity, object mockDevice) { }

	// RVA: 0x754D1F8
	internal static object get_defaultShaderInfoTexFloat() { }

	// RVA: 0x754D668
	internal static object get_defaultShaderInfoTexARGB8() { }

	// RVA: 0x754D9F0
	internal static object get_vertexTexturingIsAvailable() { }

	// RVA: 0x754DC04
	internal static object get_shaderModelIs35() { }

	// RVA: 0x754DE18
	private object InitVertexDeclaration() { }

	// RVA: 0x754E0F4
	private object CompleteCreation() { }

	// RVA: 0x754E328
	private object get_fullyCreated() { }

	// RVA: 0x754E338
	protected object get_disposed() { }

	// RVA: 0x754E340
	private object set_disposed(object value) { }

	// RVA: 0x754E348
	public object Dispose() { }

	// RVA: 0x754E3E0
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x754EB60
	public object Allocate(object vertexCount, object indexCount, object vertexData, object indexData, object indexOffset) { }

	// RVA: 0x754F400
	public object Update(object mesh, object vertexCount, object vertexData) { }

	// RVA: 0x754FE7C
	public object Update(object mesh, object vertexCount, object indexCount, object vertexData, object indexData, object indexOffset) { }

	// RVA: 0x7550064
	private object UpdateCopyBackIndices(object mesh, object copyBackIndices) { }

	// RVA: 0x75501D8
	internal object ActiveUpdatesForMeshHandle(object mesh) { }

	// RVA: 0x755026C
	private object TryAllocFromPage(object page, object vertexCount, object indexCount, object va, object ia, object shortLived) { }

	// RVA: 0x754EC40
	private object Allocate(object meshHandle, object vertexCount, object indexCount, object vertexData, object indexData, object shortLived) { }

	// RVA: 0x754F624
	private object UpdateAfterGPUUsedData(object mesh, object vertexCount, object indexCount, object vertexData, object indexData, object indexOffset, object allocToUpdate, object copyBackIndices) { }

	// RVA: 0x7550638
	public object Free(object mesh) { }

	// RVA: 0x755104C
	public object OnFrameRenderingBegin() { }

	// RVA: -1
	internal static object PtrToSlice(object p, object count) { }

	// RVA: 0x7551DC8
	private object ApplyDrawCommandState(object cmd, object textureSlot, object newMat, object newMatDiffers, object st) { }

	// RVA: 0x7551FE0
	private object ApplyBatchState(object st, object allowMaterialChange) { }

	// RVA: 0x7552208
	public object EvaluateChain(object head, object initialMat, object defaultMat, object gradientSettings, object shaderInfo, object pixelsPerPoint, object transforms, object clipRects, object stateMatProps, object allowMaterialChange, object immediateException) { }

	// RVA: 0x7553424
	private object UpdateFenceValue() { }

	// RVA: 0x7553170
	private object KickRanges(object ranges, object rangesReady, object rangesStart, object rangesCount, object curPage) { }

	// RVA: -1
	private object DrawRanges(object ib, object vb, object ranges) { }

	// RVA: 0x755352C
	private object WaitOnCpuFence(object fence) { }

	// RVA: 0x7551184
	public object AdvanceFrame() { }

	// RVA: 0x75536F0
	private object PruneUnusedPages() { }

	// RVA: 0x75537FC
	internal static object PrepareForGfxDeviceRecreate() { }

	// RVA: 0x75539F0
	internal static object WrapUpGfxDeviceRecreate() { }

	// RVA: 0x7553A54
	internal static object FlushAllPendingDeviceDisposes() { }

	// RVA: 0x7553B24
	internal object GatherDrawStatistics() { }

	// RVA: 0x754E5DC
	private static object ProcessDeviceFreeQueue() { }

	// RVA: 0x7553B38
	private static object OnEngineUpdateGlobal() { }

	// RVA: 0x7553BA0
	private static object OnFlushPendingResources() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal struct Alloc
{

	// Fields
	public object start; // 0xFFFFFFFFFFFFFFF8
	public object size; // 0xFFFFFFFFFFFFFFFC
	internal object handle; // 0x0
	internal object shortLived; // 0x8
}

// Namespace: 
private class BlockPool
{

	// Methods

	// RVA: 0x7554360
	private static object CreateBlock() { }

	// RVA: 0x7554444
	private static object ResetBlock(object block) { }

	// RVA: 0x7553FD0
	public object .ctor() { }

}

// Namespace: 
private class Block
{

	// Fields
	public object start; // 0x10
	public object end; // 0x14
	public object prev; // 0x18
	public object next; // 0x20
	public object prevAvailable; // 0x28
	public object nextAvailable; // 0x30
	public object allocated; // 0x38

	// Properties
	public object size { get; }

	// Methods

	// RVA: 0x7554114
	public object get_size() { }

	// RVA: 0x75543EC
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class BestFitAllocator
{

	// Fields
	private readonly object <totalSize>k__BackingField; // 0x8
	private object m_FirstBlock; // 0x10
	private object m_FirstAvailableBlock; // 0x18
	private object m_BlockPool; // 0x20
	private object m_HighWatermark; // 0x28

	// Properties
	public object totalSize { get; }
	public object highWatermark { get; }

	// Methods

	// RVA: 0x754BCEC
	public object .ctor(object size) { }

	// RVA: 0x75540C8
	public object get_totalSize() { }

	// RVA: 0x754C268
	public object get_highWatermark() { }

	// RVA: 0x754BA30
	public object Allocate(object size) { }

	// RVA: 0x754BFF4
	public object Free(object alloc) { }

	// RVA: 0x7554224
	private object CoalesceBlockWithPrevious(object block) { }

	// RVA: 0x75540D0
	private object BestFitFindAvailableBlock(object size) { }

	// RVA: 0x7554120
	private object SplitBlock(object block, object size) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class GPUBufferAllocator
{

	// Fields
	private object m_Low; // 0x8
	private object m_High; // 0x10

	// Properties
	public object isEmpty { get; }

	// Methods

	// RVA: 0x7554448
	public object .ctor(object maxSize) { }

	// RVA: 0x7550424
	public object Allocate(object size, object shortLived) { }

	// RVA: 0x75505C4
	public object Free(object alloc) { }

	// RVA: 0x7554524
	public object get_isEmpty() { }

	// RVA: 0x75544D4
	private object HighLowCollide() { }

}

// Namespace: 
public class DataSet<T0>
{

	// Fields
	private object <disposed>k__BackingField; // 0x0
	public object gpuData; // 0x0
	public object cpuData; // 0x0
	public object updateRanges; // 0x0
	public object allocator; // 0x0
	private readonly object m_UpdateRangePoolSize; // 0x0
	private object m_ElemStride; // 0x0
	private object m_UpdateRangeMin; // 0x0
	private object m_UpdateRangeMax; // 0x0
	private object m_UpdateRangesEnqueued; // 0x0
	private object m_UpdateRangesBatchStart; // 0x0
	private object m_UpdateRangesSaturated; // 0x0

	// Properties
	protected object disposed { get; set; }

	// Methods

	// RVA: -1
	public object .ctor(object bufferType, object totalCount, object maxQueuedFrameCount, object updateRangePoolSize, object mockBuffer) { }

	// RVA: -1
	protected object get_disposed() { }

	// RVA: -1
	private object set_disposed(object value) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object Dispose(object disposing) { }

	// RVA: -1
	public object RegisterUpdate(object start, object size) { }

	// RVA: -1
	private object HasMappedBufferRange() { }

	// RVA: -1
	public object SendUpdates() { }

	// RVA: -1
	public object SendFullRange() { }

	// RVA: -1
	public object SendPartialRanges() { }

	// RVA: -1
	private object ResetUpdateState() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class Page
{

	// Fields
	private object <disposed>k__BackingField; // 0x8
	public object vertices; // 0x10
	public object indices; // 0x18
	public object next; // 0x20
	public object framesEmpty; // 0x28

	// Properties
	protected object disposed { get; set; }
	public object isEmpty { get; }

	// Methods

	// RVA: 0x7554604
	public object .ctor(object vertexMaxCount, object indexMaxCount, object maxQueuedFrameCount, object mockPage) { }

	// RVA: 0x7554750
	protected object get_disposed() { }

	// RVA: 0x7554758
	private object set_disposed(object value) { }

	// RVA: 0x7554760
	public object Dispose() { }

	// RVA: 0x75547F8
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x75548A8
	public object get_isEmpty() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal enum VertexFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IsSolid;
	public const object IsText;
	public const object IsTextured;
	public const object IsDynamic;
	public const object IsSvgGradients;
	public const object LastType;
	public const object IsGraphViewEdge;
}

// Namespace: UnityEngine.UIElements.UIR
internal struct State
{

	// Fields
	public object material; // 0xFFFFFFFFFFFFFFF8
	public object texture; // 0x0
	public object stencilRef; // 0x4
	public object sdfScale; // 0x8
}

// Namespace: UnityEngine.UIElements.UIR
internal enum CommandType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Draw;
	public const object ImmediateCull;
	public const object Immediate;
	public const object PushView;
	public const object PopView;
	public const object PushScissor;
	public const object PopScissor;
	public const object PushRenderTexture;
	public const object PopRenderTexture;
	public const object BlitToPreviousRT;
	public const object PushDefaultMaterial;
	public const object PopDefaultMaterial;
}

// Namespace: UnityEngine.UIElements.UIR
internal class DrawParams
{

	// Fields
	internal static readonly object k_UnlimitedRect; // 0x0
	internal static readonly object k_FullNormalizedRect; // 0x10
	internal readonly object view; // 0x8
	internal readonly object scissor; // 0x10
	internal readonly object renderTexture; // 0x18
	internal readonly object defaultMaterial; // 0x20

	// Methods

	// RVA: 0x755496C
	public object Reset() { }

	// RVA: 0x7554B74
	public object .ctor() { }

	// RVA: 0x7554CDC
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class RenderChainCommand
{

	// Fields
	internal object owner; // 0x10
	internal object prev; // 0x18
	internal object next; // 0x20
	internal object closing; // 0x28
	internal object type; // 0x2C
	internal object state; // 0x30
	internal object mesh; // 0x48
	internal object indexOffset; // 0x50
	internal object indexCount; // 0x54
	internal object callback; // 0x58
	private static readonly object k_ID_MainTex; // 0x0
	private static object s_ImmediateOverheadMarker; // 0x8

	// Methods

	// RVA: 0x7554D38
	internal object Reset() { }

	// RVA: 0x7554D5C
	internal object ExecuteNonDrawMesh(object drawParams, object pixelsPerPoint, object immediateException) { }

	// RVA: 0x7556300
	private object Blit(object source, object destination, object depth) { }

	// RVA: 0x75561EC
	private static object CombineScissorRects(object r0, object r1) { }

	// RVA: 0x7555D74
	private static object RectPointsToPixelsAndFlipYAxis(object rect, object pixelsPerPoint) { }

	// RVA: 0x755648C
	public object .ctor() { }

	// RVA: 0x75564E4
	private static object .cctor() { }

}

// Namespace: 
private struct RawTexture
{

	// Fields
	public object rgba; // 0xFFFFFFFFFFFFFFF8
	public object width; // 0x0
	public object height; // 0x4

	// Methods

	// RVA: 0x7556E5C
	public object WriteRawInt2Packed(object v0, object v1, object destX, object destY) { }

	// RVA: 0x7556D98
	public object WriteRawFloat4Packed(object f0, object f1, object f2, object f3, object destX, object destY) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class GradientSettingsAtlas
{

	// Fields
	private static object s_MarkerWrite; // 0x0
	private static object s_MarkerCommit; // 0x8
	private readonly object m_Length; // 0x8
	private readonly object m_ElemWidth; // 0xC
	private object m_Allocator; // 0x10
	private object m_Atlas; // 0x18
	private object m_RawAtlas; // 0x20
	private static object s_TextureCounter; // 0x10
	private object <disposed>k__BackingField; // 0x30
	private object <MustCommit>k__BackingField; // 0x31

	// Properties
	internal object length { get; }
	protected object disposed { get; set; }
	public object atlas { get; }
	public object MustCommit { get; set; }

	// Methods

	// RVA: 0x7556590
	internal object get_length() { }

	// RVA: 0x7556598
	protected object get_disposed() { }

	// RVA: 0x75565A0
	private object set_disposed(object value) { }

	// RVA: 0x75565A8
	public object Dispose() { }

	// RVA: 0x7556640
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x75566DC
	public object .ctor(object length) { }

	// RVA: 0x7556710
	public object Reset() { }

	// RVA: 0x75567DC
	public object get_atlas() { }

	// RVA: 0x75567E4
	public object Add(object count) { }

	// RVA: 0x75568D8
	public object Write(object alloc, object settings, object remap) { }

	// RVA: 0x7556EE8
	public object get_MustCommit() { }

	// RVA: 0x7556EF0
	private object set_MustCommit(object value) { }

	// RVA: 0x7556EF8
	public object Commit() { }

	// RVA: 0x7556FE8
	private object PrepareAtlas() { }

	// RVA: 0x755718C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class JobManager
{

	// Fields
	private object m_NudgeJobs; // 0x8
	private object m_ConvertMeshJobs; // 0x10
	private object m_CopyClosingMeshJobs; // 0x18
	private object m_JobMerger; // 0x20
	private object <disposed>k__BackingField; // 0x28

	// Properties
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x755745C
	public object Add(object job) { }

	// RVA: 0x75574C8
	public object Add(object job) { }

	// RVA: 0x7557534
	public object Add(object job) { }

	// RVA: 0x75575A0
	public object CompleteNudgeJobs() { }

	// RVA: 0x7557A20
	public object CompleteConvertMeshJobs() { }

	// RVA: 0x7557D74
	public object CompleteClosingMeshJobs() { }

	// RVA: 0x75580C8
	protected object get_disposed() { }

	// RVA: 0x75580D0
	private object set_disposed(object value) { }

	// RVA: 0x75580D8
	public object Dispose() { }

	// RVA: 0x7558178
	protected object Dispose(object disposing) { }

	// RVA: 0x75583FC
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal struct NudgeJobData
{

	// Fields
	public object src; // 0xFFFFFFFFFFFFFFF8
	public object dst; // 0x0
	public object count; // 0x8
	public object closingSrc; // 0x10
	public object closingDst; // 0x18
	public object closingCount; // 0x20
	public object transform; // 0x24
	public object vertsBeforeUVDisplacement; // 0x64
	public object vertsAfterUVDisplacement; // 0x68
}

// Namespace: UnityEngine.UIElements.UIR
internal struct ConvertMeshJobData
{

	// Fields
	public object vertSrc; // 0xFFFFFFFFFFFFFFF8
	public object vertDst; // 0x0
	public object vertCount; // 0x8
	public object transform; // 0xC
	public object transformUVs; // 0x4C
	public object xformClipPages; // 0x50
	public object ids; // 0x54
	public object addFlags; // 0x58
	public object opacityPage; // 0x5C
	public object textCoreSettingsPage; // 0x60
	public object isText; // 0x64
	public object textureId; // 0x68
	public object indexSrc; // 0x70
	public object indexDst; // 0x78
	public object indexCount; // 0x80
	public object indexOffset; // 0x84
	public object flipIndices; // 0x88
}

// Namespace: UnityEngine.UIElements.UIR
internal struct CopyClosingMeshJobData
{

	// Fields
	public object vertSrc; // 0xFFFFFFFFFFFFFFF8
	public object vertDst; // 0x0
	public object vertCount; // 0x8
	public object indexSrc; // 0x10
	public object indexDst; // 0x18
	public object indexCount; // 0x20
	public object indexOffset; // 0x24
}

// Namespace: UnityEngine.UIElements.UIR
internal class JobMerger
{

	// Fields
	private object m_Jobs; // 0x8
	private object m_JobCount; // 0x18
	private object <disposed>k__BackingField; // 0x1C

	// Properties
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x755854C
	public object .ctor(object capacity) { }

	// RVA: 0x75578B4
	public object Add(object job) { }

	// RVA: 0x755797C
	public object MergeAndReset() { }

	// RVA: 0x7558608
	protected object get_disposed() { }

	// RVA: 0x7558610
	private object set_disposed(object value) { }

	// RVA: 0x7558320
	public object Dispose() { }

	// RVA: 0x7558618
	protected object Dispose(object disposing) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class LinkedPoolItem<T0>
{

	// Fields
	internal object poolNext; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class LinkedPool<T0>
{

	// Fields
	private readonly object m_CreateFunc; // 0x0
	private readonly object m_ResetAction; // 0x0
	private readonly object m_Limit; // 0x0
	private object m_PoolFirst; // 0x0
	private object <Count>k__BackingField; // 0x0

	// Properties
	public object Count { get; set; }

	// Methods

	// RVA: -1
	public object .ctor(object createFunc, object resetAction, object limit) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	private object set_Count(object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Get() { }

	// RVA: -1
	public object Return(object item) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class BasicNode<T0>
{

	// Fields
	public object next; // 0x0
	public object data; // 0x0

	// Methods

	// RVA: -1
	public object AppendTo(object first) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class BasicNodePool<T0>
{

	// Methods

	// RVA: -1
	private static object Reset(object node) { }

	// RVA: -1
	private static object Create() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
internal sealed class Allocator
{

	// Methods

	// RVA: 0x75590D4
	public object .ctor(object object, object method) { }

	// RVA: 0x755916C
	public virtual object Invoke(object vertexCount, object indexCount, object allocatorData) { }

}

// Namespace: 
internal struct AllocMeshData
{

	// Fields
	internal object alloc; // 0xFFFFFFFFFFFFFFF8
	internal object texture; // 0x0
	internal object svgTexture; // 0x8
	internal object material; // 0x10
	internal object flags; // 0x18
	internal object colorAlloc; // 0x1C

	// Methods

	// RVA: 0x7558E64
	internal object Allocate(object vertexCount, object indexCount) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal static class MeshBuilder
{

	// Fields
	private static object s_VectorGraphics9Slice; // 0x0
	private static object s_VectorGraphicsSplitTriangle; // 0x8
	private static object s_VectorGraphicsScaleTriangle; // 0x10
	private static object s_VectorGraphicsStretch; // 0x18
	internal static readonly object s_MaxTextMeshVertices; // 0x20

	// Methods

	// RVA: 0x75586A0
	private static object ConvertTextVertexToUIRVertex(object info, object index, object offset, object flags, object isDynamicColor) { }

	// RVA: 0x75587B4
	private static object LimitTextVertices(object vertexCount, object logTruncation) { }

	// RVA: 0x7558920
	internal static object MakeText(object meshInfo, object offset, object meshAlloc, object flags, object isDynamicColor) { }

	// RVA: 0x7558E94
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class NativePagedList<T0>
{

	// Fields
	private readonly object k_PoolCapacity; // 0x0
	private object m_Pages; // 0x0
	private object m_CurrentPage; // 0x0
	private object m_CurrentPageCount; // 0x0
	private object m_Enumerator; // 0x0
	private object <disposed>k__BackingField; // 0x0

	// Properties
	protected object disposed { get; set; }

	// Methods

	// RVA: -1
	public object .ctor(object poolCapacity) { }

	// RVA: -1
	public object Add(object data) { }

	// RVA: -1
	public object GetPages() { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	protected object get_disposed() { }

	// RVA: -1
	private object set_disposed(object value) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	protected object Dispose(object disposing) { }

}

// Namespace: 
private struct OpacityIdUpdateJob
{

	// Fields
	public object oldVerts; // 0xFFFFFFFFFFFFFFF8
	public object newVerts; // 0x8
	public object opacityData; // 0x18

	// Methods

	// RVA: 0x75594D0
	public object Execute(object i) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class OpacityIdAccelerator
{

	// Fields
	private object m_Jobs; // 0x8
	private object m_NextJobIndex; // 0x18
	private object <disposed>k__BackingField; // 0x1C

	// Properties
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x7559180
	public object CreateJob(object oldVerts, object newVerts, object opacityData, object vertexCount) { }

	// RVA: 0x7559280
	public object CompleteJobs() { }

	// RVA: 0x755931C
	protected object get_disposed() { }

	// RVA: 0x7559324
	private object set_disposed(object value) { }

	// RVA: 0x755932C
	public object Dispose() { }

	// RVA: 0x75593C4
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x755944C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal struct ChainBuilderStats
{

	// Fields
	public object elementsAdded; // 0xFFFFFFFFFFFFFFF8
	public object elementsRemoved; // 0xFFFFFFFFFFFFFFFC
	public object recursiveClipUpdates; // 0x0
	public object recursiveClipUpdatesExpanded; // 0x4
	public object nonRecursiveClipUpdates; // 0x8
	public object recursiveTransformUpdates; // 0xC
	public object recursiveTransformUpdatesExpanded; // 0x10
	public object recursiveOpacityUpdates; // 0x14
	public object recursiveOpacityUpdatesExpanded; // 0x18
	public object opacityIdUpdates; // 0x1C
	public object colorUpdates; // 0x20
	public object colorUpdatesExpanded; // 0x24
	public object recursiveVisualUpdates; // 0x28
	public object recursiveVisualUpdatesExpanded; // 0x2C
	public object nonRecursiveVisualUpdates; // 0x30
	public object dirtyProcessed; // 0x34
	public object nudgeTransformed; // 0x38
	public object boneTransformed; // 0x3C
	public object skipTransformed; // 0x40
	public object visualUpdateTransformed; // 0x44
	public object updatedMeshAllocations; // 0x48
	public object newMeshAllocations; // 0x4C
	public object groupTransformElementsChanged; // 0x50
	public object immedateRenderersActive; // 0x54
}

// Namespace: 
private struct DepthOrderedDirtyTracking
{

	// Fields
	public object heads; // 0xFFFFFFFFFFFFFFF8
	public object tails; // 0x0
	public object minDepths; // 0x8
	public object maxDepths; // 0x10
	public object dirtyID; // 0x18

	// Methods

	// RVA: 0x755E1C8
	public object EnsureFits(object maxDepth) { }

	// RVA: 0x755D9B8
	public object RegisterDirty(object ve, object dirtyTypes, object dirtyTypeClass) { }

	// RVA: 0x755BEFC
	public object ClearDirty(object ve, object dirtyTypesInverse) { }

	// RVA: 0x755A428
	public object Reset() { }

}

// Namespace: 
private struct RenderChainStaticIndexAllocator
{

	// Fields
	private static object renderChains; // 0x0

	// Methods

	// RVA: 0x755A7BC
	public static object AllocateIndex(object renderChain) { }

	// RVA: 0x755AE60
	public static object FreeIndex(object index) { }

	// RVA: 0x755E8C0
	public static object AccessIndex(object index) { }

	// RVA: 0x755F6C0
	private static object .cctor() { }

}

// Namespace: 
private struct RenderNodeData
{

	// Fields
	public object standardMaterial; // 0xFFFFFFFFFFFFFFF8
	public object initialMaterial; // 0x0
	public object matPropBlock; // 0x8
	public object firstCommand; // 0x10
	public object device; // 0x18
	public object vectorAtlas; // 0x20
	public object shaderInfoAtlas; // 0x28
	public object dpiScale; // 0x30
	public object transformConstants; // 0x38
	public object clipRectConstants; // 0x48
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__34_0; // 0x8
	public static object <>9__34_1; // 0x10

	// Methods

	// RVA: 0x755F790
	private static object .cctor() { }

	// RVA: 0x755F7F0
	public object .ctor() { }

	// RVA: 0x755F7F8
	internal object <.ctor>b__34_0() { }

	// RVA: 0x755F884
	internal object <.ctor>b__34_1(object cmd) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class RenderChain
{

	// Fields
	private object m_FirstCommand; // 0x8
	private object m_DirtyTracker; // 0x10
	private object m_CommandPool; // 0x38
	private object m_TexturePool; // 0x40
	private object m_RenderNodesData; // 0x48
	private object m_DefaultShader; // 0x50
	private object m_DefaultWorldSpaceShader; // 0x58
	private object m_DefaultMat; // 0x60
	private object m_DefaultWorldSpaceMat; // 0x68
	private object m_BlockDirtyRegistration; // 0x70
	private object m_StaticIndex; // 0x74
	private object m_ActiveRenderNodes; // 0x78
	private object m_CustomMaterialCommands; // 0x7C
	private object m_Stats; // 0x80
	private object m_StatsElementsAdded; // 0xE0
	private object m_StatsElementsRemoved; // 0xE4
	private object m_TextureRegistry; // 0xE8
	private object <opacityIdAccelerator>k__BackingField; // 0xF0
	private static object s_MarkerProcess; // 0x0
	private static object s_MarkerClipProcessing; // 0x8
	private static object s_MarkerOpacityProcessing; // 0x10
	private static object s_MarkerColorsProcessing; // 0x18
	private static object s_MarkerTransformProcessing; // 0x20
	private static object s_MarkerVisualsProcessing; // 0x28
	private static object s_MarkerTextRegen; // 0x30
	private object <disposed>k__BackingField; // 0xF8
	internal static object OnPreRender; // 0x38
	private object <panel>k__BackingField; // 0x100
	private object <device>k__BackingField; // 0x108
	private object <atlas>k__BackingField; // 0x110
	private object <vectorImageManager>k__BackingField; // 0x118
	private object <vertsPool>k__BackingField; // 0x120
	private object <indicesPool>k__BackingField; // 0x128
	private object <jobManager>k__BackingField; // 0x130
	internal object shaderInfoAllocator; // 0x138
	private object <painter>k__BackingField; // 0x208
	private object <drawStats>k__BackingField; // 0x210
	private object <drawInCameras>k__BackingField; // 0x211

	// Properties
	public object opacityIdAccelerator { get; set; }
	protected object disposed { get; set; }
	internal object panel { get; set; }
	internal object device { get; set; }
	internal object atlas { get; set; }
	internal object vectorImageManager { get; set; }
	internal object vertsPool { get; set; }
	internal object indicesPool { get; set; }
	internal object jobManager { get; set; }
	internal object painter { get; set; }
	internal object drawStats { get; set; }
	internal object drawInCameras { get; set; }
	internal object defaultShader { set; }
	internal object defaultWorldSpaceShader { set; }

	// Methods

	// RVA: 0x75595B4
	public object get_opacityIdAccelerator() { }

	// RVA: 0x75595BC
	private object set_opacityIdAccelerator(object value) { }

	// RVA: 0x75595C4
	private static object .cctor() { }

	// RVA: 0x755986C
	public object .ctor(object panel) { }

	// RVA: 0x7559E9C
	private object Constructor(object panelObj, object deviceObj, object atlas, object vectorImageMan) { }

	// RVA: 0x755A9D4
	private object Destructor() { }

	// RVA: 0x755B400
	protected object get_disposed() { }

	// RVA: 0x755B408
	private object set_disposed(object value) { }

	// RVA: 0x755B410
	public object Dispose() { }

	// RVA: 0x755B4B4
	protected object Dispose(object disposing) { }

	// RVA: 0x755B4EC
	public object ProcessChanges() { }

	// RVA: 0x755C174
	public object Render() { }

	// RVA: 0x755D234
	public object UIEOnChildAdded(object ve) { }

	// RVA: 0x755D62C
	public object UIEOnChildrenReordered(object ve) { }

	// RVA: 0x755D7FC
	public object UIEOnChildRemoving(object ve) { }

	// RVA: 0x755D910
	public object UIEOnRenderHintsChanged(object ve) { }

	// RVA: 0x755D428
	public object UIEOnClippingChanged(object ve, object hierarchical) { }

	// RVA: 0x755D4D4
	public object UIEOnOpacityChanged(object ve, object hierarchical) { }

	// RVA: 0x755DC14
	public object UIEOnColorChanged(object ve) { }

	// RVA: 0x755DCB4
	public object UIEOnTransformOrSizeChanged(object ve, object transformChanged, object clipRectSizeChanged) { }

	// RVA: 0x755D580
	public object UIEOnVisualsChanged(object ve, object hierarchical) { }

	// RVA: 0x755DD60
	public object UIEOnOpacityIdChanged(object ve) { }

	// RVA: 0x755DE00
	internal object get_panel() { }

	// RVA: 0x755DE08
	private object set_panel(object value) { }

	// RVA: 0x755DE10
	internal object get_device() { }

	// RVA: 0x755DE18
	private object set_device(object value) { }

	// RVA: 0x755DE20
	internal object get_atlas() { }

	// RVA: 0x755DE28
	private object set_atlas(object value) { }

	// RVA: 0x755DE30
	internal object get_vectorImageManager() { }

	// RVA: 0x755DE38
	private object set_vectorImageManager(object value) { }

	// RVA: 0x755DE40
	internal object get_vertsPool() { }

	// RVA: 0x755DE48
	private object set_vertsPool(object value) { }

	// RVA: 0x755DE50
	internal object get_indicesPool() { }

	// RVA: 0x755DE58
	private object set_indicesPool(object value) { }

	// RVA: 0x755DE60
	internal object get_jobManager() { }

	// RVA: 0x755DE68
	private object set_jobManager(object value) { }

	// RVA: 0x755DE70
	internal object get_painter() { }

	// RVA: 0x755DE78
	private object set_painter(object value) { }

	// RVA: 0x755DE80
	internal object get_drawStats() { }

	// RVA: 0x755DE88
	internal object set_drawStats(object value) { }

	// RVA: 0x755DE90
	internal object get_drawInCameras() { }

	// RVA: 0x755DE98
	private object set_drawInCameras(object value) { }

	// RVA: 0x755DEA0
	internal object set_defaultShader(object value) { }

	// RVA: 0x755DF88
	internal object set_defaultWorldSpaceShader(object value) { }

	// RVA: 0x755C524
	internal object GetStandardMaterial() { }

	// RVA: 0x755E070
	internal object GetStandardWorldSpaceMaterial() { }

	// RVA: 0x755E1C0
	internal object EnsureFitsDepth(object depth) { }

	// RVA: 0x755E3CC
	internal object ChildWillBeRemoved(object ve) { }

	// RVA: 0x755E4A4
	internal object AllocCommand() { }

	// RVA: 0x755E534
	internal object FreeCommand(object cmd) { }

	// RVA: 0x755E630
	internal object OnRenderCommandAdded(object command) { }

	// RVA: 0x755E704
	internal object OnRenderCommandsRemoved(object firstCommand, object lastCommand) { }

	// RVA: 0x755E74C
	private static object AccessRenderNodeData(object obj) { }

	// RVA: 0x755E96C
	private static object OnRenderNodeExecute(object obj) { }

	// RVA: 0x755EA24
	private static object OnRegisterIntermediateRenderers(object camera) { }

	// RVA: 0x755EF10
	private static object OnRegisterIntermediateRendererMat(object rtp, object renderChain, object rnd, object camera, object sameDistanceSortPriority) { }

	// RVA: 0x755F3A8
	internal object RepaintTexturedElements() { }

	// RVA: 0x755F4AC
	public object AppendTexture(object ve, object src, object id, object isAtlas) { }

	// RVA: 0x755AF30
	public object ResetTextures(object ve) { }

	// RVA: 0x755C818
	private object DrawStats() { }

	// RVA: 0x755AF10
	private static object GetFirstElementInPanel(object ve) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal enum RenderDataDirtyTypes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Transform;
	public const object ClipRectSize;
	public const object Clipping;
	public const object ClippingHierarchy;
	public const object Visuals;
	public const object VisualsHierarchy;
	public const object VisualsOpacityId;
	public const object Opacity;
	public const object OpacityHierarchy;
	public const object Color;
	public const object AllVisuals;
}

// Namespace: UnityEngine.UIElements.UIR
internal enum RenderDataDirtyTypeClasses
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Clipping;
	public const object Opacity;
	public const object Color;
	public const object TransformSize;
	public const object Visuals;
	public const object Count;
}

// Namespace: UnityEngine.UIElements.UIR
internal enum RenderDataFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IsIgnoringDynamicColorHint;
}

// Namespace: UnityEngine.UIElements.UIR
internal struct RenderChainVEData
{

	// Fields
	internal object prev; // 0xFFFFFFFFFFFFFFF8
	internal object next; // 0x0
	internal object groupTransformAncestor; // 0x8
	internal object boneTransformAncestor; // 0x10
	internal object prevDirty; // 0x18
	internal object nextDirty; // 0x20
	internal object flags; // 0x28
	internal object hierarchyDepth; // 0x2C
	internal object dirtiedValues; // 0x30
	internal object dirtyID; // 0x34
	internal object firstCommand; // 0x38
	internal object lastCommand; // 0x40
	internal object firstClosingCommand; // 0x48
	internal object lastClosingCommand; // 0x50
	internal object isInChain; // 0x58
	internal object isHierarchyHidden; // 0x59
	internal object localFlipsWinding; // 0x5A
	internal object localTransformScaleZero; // 0x5B
	internal object worldFlipsWinding; // 0x5C
	internal object clipMethod; // 0x60
	internal object childrenStencilRef; // 0x64
	internal object childrenMaskDepth; // 0x68
	internal object disableNudging; // 0x6C
	internal object data; // 0x70
	internal object closingData; // 0x78
	internal object verticesSpace; // 0x80
	internal object displacementUVStart; // 0xC0
	internal object displacementUVEnd; // 0xC4
	internal object transformID; // 0xC8
	internal object clipRectID; // 0xD0
	internal object opacityID; // 0xD8
	internal object textCoreSettingsID; // 0xE0
	internal object colorID; // 0xE8
	internal object backgroundColorID; // 0xF0
	internal object borderLeftColorID; // 0xF8
	internal object borderTopColorID; // 0x100
	internal object borderRightColorID; // 0x108
	internal object borderBottomColorID; // 0x110
	internal object tintColorID; // 0x118
	internal object compositeOpacity; // 0x120
	internal object backgroundColor; // 0x124
	internal object textures; // 0x138

	// Properties
	internal object lastClosingOrLastCommand { get; }
	public object isIgnoringDynamicColorHint { get; }

	// Methods

	// RVA: 0x755F8C4
	internal object get_lastClosingOrLastCommand() { }

	// RVA: 0x755F8F4
	internal static object AllocatesID(object alloc) { }

	// RVA: 0x755F97C
	internal static object InheritsID(object alloc) { }

	// RVA: 0x755F9F0
	public object get_isIgnoringDynamicColorHint() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal struct TextureEntry
{

	// Fields
	public object source; // 0xFFFFFFFFFFFFFFF8
	public object actual; // 0x0
	public object replaced; // 0x4
}

// Namespace: UnityEngine.UIElements.UIR
internal abstract class BaseShaderInfoStorage
{

	// Fields
	protected static object s_TextureCounter; // 0x0
	internal static object s_MarkerCopyTexture; // 0x8
	internal static object s_MarkerGetTextureData; // 0x10
	internal static object s_MarkerUpdateTexture; // 0x18
	private object <disposed>k__BackingField; // 0x8

	// Properties
	public abstract object texture { get; }
	protected object disposed { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_texture() { }

	// RVA: -1
	public abstract object AllocateRect(object width, object height, object uvs) { }

	// RVA: -1
	public abstract object SetTexel(object x, object y, object color) { }

	// RVA: -1
	public abstract object UpdateTexture() { }

	// RVA: 0x755FA44
	protected object get_disposed() { }

	// RVA: 0x755FA4C
	private object set_disposed(object value) { }

	// RVA: 0x755FA54
	public object Dispose() { }

	// RVA: 0x755FAEC
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x755FB00
	protected object .ctor() { }

	// RVA: 0x755FB08
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class ShaderInfoStorage<T0>
{

	// Fields
	private readonly object m_InitialSize; // 0x0
	private readonly object m_MaxSize; // 0x0
	private readonly object m_Format; // 0x0
	private readonly object m_Convert; // 0x0
	private object m_Allocator; // 0x0
	private object m_Texture; // 0x0
	private object m_Texels; // 0x0

	// Properties
	public override object texture { get; }

	// Methods

	// RVA: -1
	public object .ctor(object format, object convert, object initialSize, object maxSize) { }

	// RVA: -1
	protected override object Dispose(object disposing) { }

	// RVA: -1
	public override object get_texture() { }

	// RVA: -1
	public override object AllocateRect(object width, object height, object uvs) { }

	// RVA: -1
	public override object SetTexel(object x, object y, object color) { }

	// RVA: -1
	public override object UpdateTexture() { }

	// RVA: -1
	private object CreateOrExpandTexture() { }

	// RVA: -1
	private static object CpuBlit(object src, object srcWidth, object srcHeight, object dst, object dstWidth, object dstHeight) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x755FD68
	private static object .cctor() { }

	// RVA: 0x755FDC8
	public object .ctor() { }

	// RVA: 0x755FDD0
	internal object <.cctor>b__2_0(object c) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class ShaderInfoStorageRGBA32
{

	// Fields
	private static readonly object s_Convert; // 0x0

	// Methods

	// RVA: 0x755FC00
	public object .ctor(object initialSize, object maxSize) { }

	// RVA: 0x755FCA0
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x755FF40
	private static object .cctor() { }

	// RVA: 0x755FFA0
	public object .ctor() { }

	// RVA: 0x755FFA8
	internal object <.cctor>b__2_0(object c) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class ShaderInfoStorageRGBAFloat
{

	// Fields
	private static readonly object s_Convert; // 0x0

	// Methods

	// RVA: 0x755FDD8
	public object .ctor(object initialSize, object maxSize) { }

	// RVA: 0x755FE78
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal static class Shaders
{

	// Fields
	public static readonly object k_AtlasBlit; // 0x0
	public static readonly object k_Editor; // 0x8
	public static readonly object k_Runtime; // 0x10
	public static readonly object k_RuntimeWorld; // 0x18
	public static readonly object k_GraphView; // 0x20
	public static readonly object k_ColorConversionBlit; // 0x28

	// Methods

	// RVA: 0x755FFAC
	private static object .cctor() { }

}

// Namespace: 
private struct Page
{

	// Fields
	public object array; // 0x0
	public object used; // 0x0
}

// Namespace: UnityEngine.UIElements.UIR
internal class TempAllocator<T0>
{

	// Fields
	private readonly object m_ExcessMinCapacity; // 0x0
	private readonly object m_ExcessMaxCapacity; // 0x0
	private object m_Pool; // 0x0
	private object m_Excess; // 0x0
	private object m_NextExcessSize; // 0x0
	private object <disposed>k__BackingField; // 0x0

	// Properties
	protected object disposed { get; set; }

	// Methods

	// RVA: -1
	public object .ctor(object poolCapacity, object excessMinCapacity, object excessMaxCapacity) { }

	// RVA: -1
	protected object get_disposed() { }

	// RVA: -1
	private object set_disposed(object value) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	protected object Dispose(object disposing) { }

	// RVA: -1
	public object Alloc(object count) { }

	// RVA: -1
	public object Reset() { }

	// RVA: -1
	private object ReleaseExcess() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal struct TextCoreSettings
{

	// Fields
	public object faceColor; // 0xFFFFFFFFFFFFFFF8
	public object outlineColor; // 0x8
	public object outlineWidth; // 0x18
	public object underlayColor; // 0x1C
	public object underlayOffset; // 0x2C
	public object underlaySoftness; // 0x34

	// Methods

	// RVA: 0x75601F4
	public override object Equals(object obj) { }

	// RVA: 0x75602B0
	public object Equals(object other) { }

	// RVA: 0x75604A4
	public override object GetHashCode() { }

}

// Namespace: 
private struct BlitInfo
{

	// Fields
	public object src; // 0xFFFFFFFFFFFFFFF8
	public object srcRect; // 0x0
	public object dstPos; // 0x10
	public object border; // 0x18
	public object tint; // 0x1C
}

// Namespace: UnityEngine.UIElements.UIR
internal class TextureBlitter
{

	// Fields
	private static readonly object k_TextureIds; // 0x0
	private static object s_CommitSampler; // 0x8
	private object m_SingleBlit; // 0x8
	private object m_BlitMaterial; // 0x10
	private object m_Properties; // 0x18
	private object m_Viewport; // 0x20
	private object m_PrevRT; // 0x30
	private object m_PendingBlits; // 0x38
	private object <disposed>k__BackingField; // 0x40

	// Properties
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x756063C
	protected object get_disposed() { }

	// RVA: 0x7560644
	private object set_disposed(object value) { }

	// RVA: 0x756064C
	public object Dispose() { }

	// RVA: 0x75606E4
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x7560784
	private static object .cctor() { }

	// RVA: 0x75608C0
	public object .ctor(object capacity) { }

	// RVA: 0x7560978
	public object QueueBlit(object src, object srcRect, object dstPos, object addBorder, object tint) { }

	// RVA: 0x7560B48
	public object BlitOneNow(object dst, object src, object srcRect, object dstPos, object addBorder, object tint) { }

	// RVA: 0x75615D0
	public object Commit(object dst) { }

	// RVA: 0x7560C44
	private object BeginBlit(object dst) { }

	// RVA: 0x7560EC8
	private object DoBlit(object blitInfos, object startIndex) { }

	// RVA: 0x7561548
	private object EndBlit() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class TextureSlotManager
{

	// Fields
	internal static readonly object k_SlotCount; // 0x0
	internal static readonly object k_SlotSize; // 0x4
	internal static readonly object slotIds; // 0x8
	internal static readonly object textureTableId; // 0x10
	private object m_Textures; // 0x8
	private object m_Tickets; // 0x10
	private object m_CurrentTicket; // 0x18
	private object m_FirstUsedTicket; // 0x1C
	private object m_GpuTextures; // 0x20
	private object <FreeSlots>k__BackingField; // 0x28
	internal object textureRegistry; // 0x30

	// Properties
	public object FreeSlots { get; set; }

	// Methods

	// RVA: 0x75617F8
	private static object .cctor() { }

	// RVA: 0x75619A0
	public object .ctor() { }

	// RVA: 0x7561B4C
	public object Reset() { }

	// RVA: 0x7561E04
	public object StartNewBatch() { }

	// RVA: 0x7561E7C
	public object IndexOf(object id) { }

	// RVA: 0x7561F94
	public object MarkUsed(object slotIndex) { }

	// RVA: 0x7561FF8
	public object get_FreeSlots() { }

	// RVA: 0x7562000
	private object set_FreeSlots(object value) { }

	// RVA: 0x7562008
	public object FindOldestSlot() { }

	// RVA: 0x7562168
	public object Bind(object id, object sdfScale, object slot, object mat) { }

	// RVA: 0x7561C84
	public object SetGpuData(object slotIndex, object id, object textureWidth, object textureHeight, object sdfScale) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10

	// Methods

	// RVA: 0x7562588
	private static object .cctor() { }

	// RVA: 0x75625E8
	public object .ctor() { }

	// RVA: 0x75625F0
	internal object <.ctor>b__0_0() { }

	// RVA: 0x75626D4
	internal object <.ctor>b__0_1(object vectorImageInfo) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class VectorImageRenderInfoPool
{

	// Methods

	// RVA: 0x75623C8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class VectorImageRenderInfo
{

	// Fields
	public object useCount; // 0x10
	public object firstGradientRemap; // 0x18
	public object gradientSettingsAlloc; // 0x20

	// Methods

	// RVA: 0x7562700
	public object Reset() { }

	// RVA: 0x756267C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__0_0; // 0x8
	public static object <>9__0_1; // 0x10

	// Methods

	// RVA: 0x75628D4
	private static object .cctor() { }

	// RVA: 0x7562934
	public object .ctor() { }

	// RVA: 0x756293C
	internal object <.ctor>b__0_0() { }

	// RVA: 0x7562A20
	internal object <.ctor>b__0_1(object gradientRemap) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class GradientRemapPool
{

	// Methods

	// RVA: 0x7562714
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class GradientRemap
{

	// Fields
	public object origIndex; // 0x10
	public object destIndex; // 0x14
	public object location; // 0x18
	public object next; // 0x28
	public object atlas; // 0x30

	// Methods

	// RVA: 0x7562AA4
	public object Reset() { }

	// RVA: 0x75629C8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal class VectorImageManager
{

	// Fields
	public static object instances; // 0x0
	private static object s_MarkerRegister; // 0x8
	private static object s_MarkerUnregister; // 0x10
	private readonly object m_Atlas; // 0x8
	private object m_Registered; // 0x10
	private object m_RenderInfoPool; // 0x18
	private object m_GradientRemapPool; // 0x20
	private object m_GradientSettingsAtlas; // 0x28
	private object m_LoggedExhaustedSettingsAtlas; // 0x30
	private object <disposed>k__BackingField; // 0x31

	// Properties
	public object atlas { get; }
	protected object disposed { get; set; }

	// Methods

	// RVA: 0x755C674
	public object get_atlas() { }

	// RVA: 0x7559C4C
	public object .ctor(object atlas) { }

	// RVA: 0x7562B18
	protected object get_disposed() { }

	// RVA: 0x7562B20
	private object set_disposed(object value) { }

	// RVA: 0x755B24C
	public object Dispose() { }

	// RVA: 0x7562B28
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x755C0F4
	public object Commit() { }

	// RVA: 0x7562CE8
	public object AddUser(object vi, object context) { }

	// RVA: 0x7562E40
	private object Register(object vi, object context) { }

	// RVA: 0x75633D0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR
internal enum OwnedState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Inherited;
	public const object Owned;
}

// Namespace: UnityEngine.UIElements.UIR
internal struct BMPAlloc
{

	// Fields
	public static readonly object Invalid; // 0x0
	public object page; // 0xFFFFFFFFFFFFFFF8
	public object pageLine; // 0xFFFFFFFFFFFFFFFC
	public object bitIndex; // 0xFFFFFFFFFFFFFFFE
	public object ownedState; // 0xFFFFFFFFFFFFFFFF

	// Methods

	// RVA: 0x75634DC
	public object Equals(object other) { }

	// RVA: 0x755F96C
	public object IsValid() { }

	// RVA: 0x756355C
	public override object ToString() { }

	// RVA: 0x7563658
	private static object .cctor() { }

}

// Namespace: 
private struct Page
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFA
	public object freeSlots; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: UnityEngine.UIElements.UIR
internal struct BitmapAllocator32
{

	// Fields
	private object m_PageHeight; // 0xFFFFFFFFFFFFFFF8
	private object m_Pages; // 0x0
	private object m_AllocMap; // 0x8
	private object m_EntryWidth; // 0x10
	private object m_EntryHeight; // 0x14

	// Properties
	public object entryWidth { get; }
	public object entryHeight { get; }

	// Methods

	// RVA: 0x75636E4
	public object Construct(object pageHeight, object entryWidth, object entryHeight) { }

	// RVA: 0x7563808
	public object ForceFirstAlloc(object firstPageX, object firstPageY) { }

	// RVA: 0x7563B24
	public object Allocate(object storage) { }

	// RVA: 0x756425C
	public object Free(object alloc) { }

	// RVA: 0x75643CC
	public object get_entryWidth() { }

	// RVA: 0x75643DC
	public object get_entryHeight() { }

	// RVA: 0x75643EC
	internal object GetAllocPageAtlasLocation(object page, object x, object y) { }

	// RVA: 0x75641EC
	private static object CountTrailingZeroes(object val) { }

}

// Namespace: UnityEngine.UIElements.UIR
internal struct UIRVEShaderInfoAllocator
{

	// Fields
	private object m_Storage; // 0xFFFFFFFFFFFFFFF8
	private object m_TransformAllocator; // 0x0
	private object m_ClipRectAllocator; // 0x20
	private object m_OpacityAllocator; // 0x40
	private object m_ColorAllocator; // 0x60
	private object m_TextSettingsAllocator; // 0x80
	private object m_StorageReallyCreated; // 0xA0
	private object m_VertexTexturingEnabled; // 0xA1
	private object m_Transforms; // 0xA8
	private object m_ClipRects; // 0xB8
	internal static readonly object identityTransformTexel; // 0x0
	internal static readonly object infiniteClipRectTexel; // 0xFFFFFFFFFFFFFFF8
	internal static readonly object fullOpacityTexel; // 0x0
	internal static readonly object clearColorTexel; // 0x8
	internal static readonly object defaultTextCoreSettingsTexel; // 0x10
	internal static readonly object identityTransformValue; // 0x18
	internal static readonly object identityTransformRow0Value; // 0x58
	internal static readonly object identityTransformRow1Value; // 0x68
	internal static readonly object identityTransformRow2Value; // 0x78
	internal static readonly object infiniteClipRectValue; // 0x88
	internal static readonly object fullOpacityValue; // 0x98
	internal static readonly object clearColorValue; // 0xA8
	internal static readonly object defaultTextCoreSettingsValue; // 0xB8
	public static readonly object identityTransform; // 0xF8
	public static readonly object infiniteClipRect; // 0x100
	public static readonly object fullOpacity; // 0x108
	public static readonly object clearColor; // 0x110
	public static readonly object defaultTextCoreSettings; // 0x118

	// Properties
	private static object pageWidth { get; }
	private static object pageHeight { get; }
	public object transformConstants { get; }
	public object clipRectConstants { get; }
	public object atlas { get; }

	// Methods

	// RVA: 0x7564540
	private static object get_pageWidth() { }

	// RVA: 0x7564548
	private static object get_pageHeight() { }

	// RVA: 0x7564550
	private static object AllocToTexelCoord(object allocator, object alloc) { }

	// RVA: 0x75645E0
	private static object AllocToConstantBufferIndex(object alloc) { }

	// RVA: 0x756464C
	private static object AtlasRectMatchesPage(object allocator, object defAlloc, object atlasRect) { }

	// RVA: 0x755C770
	public object get_transformConstants() { }

	// RVA: 0x755C7C4
	public object get_clipRectConstants() { }

	// RVA: 0x755C68C
	public object get_atlas() { }

	// RVA: 0x755A520
	public object Construct() { }

	// RVA: 0x756491C
	private object ReallyCreateStorage() { }

	// RVA: 0x755B2E4
	public object Dispose() { }

	// RVA: 0x755C128
	public object IssuePendingStorageChanges() { }

	// RVA: 0x7565DF8
	public object AllocTransform() { }

	// RVA: 0x7565F8C
	public object AllocClipRect() { }

	// RVA: 0x7566120
	public object AllocOpacity() { }

	// RVA: 0x7566230
	public object AllocColor() { }

	// RVA: 0x7566340
	public object AllocTextCoreSettings(object settings) { }

	// RVA: 0x7564EE8
	public object SetTransformValue(object alloc, object xform) { }

	// RVA: 0x75652D4
	public object SetClipRectValue(object alloc, object clipRect) { }

	// RVA: 0x7565534
	public object SetOpacityValue(object alloc, object opacity) { }

	// RVA: 0x75656EC
	public object SetColorValue(object alloc, object color, object isEditorContext) { }

	// RVA: 0x7565914
	public object SetTextCoreSettingValue(object alloc, object settings, object isEditorContext) { }

	// RVA: 0x75664D0
	public object FreeTransform(object alloc) { }

	// RVA: 0x7566650
	public object FreeClipRect(object alloc) { }

	// RVA: 0x75667D0
	public object FreeOpacity(object alloc) { }

	// RVA: 0x7566950
	public object FreeColor(object alloc) { }

	// RVA: 0x7566AD0
	public object FreeTextCoreSettings(object alloc) { }

	// RVA: 0x7566C50
	public object TransformAllocToVertexData(object alloc) { }

	// RVA: 0x7566DBC
	public object ClipRectAllocToVertexData(object alloc) { }

	// RVA: 0x7566F28
	public object OpacityAllocToVertexData(object alloc) { }

	// RVA: 0x7567060
	public object ColorAllocToVertexData(object alloc) { }

	// RVA: 0x7567198
	public object TextCoreSettingsToVertexData(object alloc) { }

	// RVA: 0x75672D0
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR.Implementation
internal static class CommandGenerator
{

	// Fields
	private static readonly object k_GenerateEntries; // 0x0
	private static readonly object k_ConvertEntriesToCommandsMarker; // 0x8
	private static readonly object k_GenerateClosingCommandsMarker; // 0x10
	private static readonly object k_NudgeVerticesMarker; // 0x18
	private static readonly object k_UpdateOpacityIdMarker; // 0x20
	private static readonly object k_ComputeTransformMatrixMarker; // 0x28
	private static object s_blitMaterial_LinearToGamma; // 0x30
	private static object s_blitMaterial_GammaToLinear; // 0x38
	private static object s_blitMaterial_NoChange; // 0x40
	private static object s_blitShader; // 0x48

	// Methods

	// RVA: 0x7567484
	private static object GetVerticesTransformInfo(object ve, object transform) { }

	// RVA: 0x7567658
	internal static object ComputeTransformMatrix(object ve, object ancestor, object result) { }

	// RVA: 0x7567874
	private static object IsParentOrAncestorOf(object ve, object child) { }

	// RVA: 0x7567914
	public static object PaintElement(object renderChain, object ve, object stats) { }

	// RVA: 0x7569350
	private static object InvokeGenerateVisualContent(object ve, object ctx) { }

	// RVA: 0x756A3E0
	private static object CreateBlitShader(object colorConversion) { }

	// RVA: 0x7569F98
	private static object GetBlitMaterial(object mode) { }

	// RVA: 0x756A64C
	public static object ClosePaintElement(object ve, object closingInfo, object renderChain, object stats) { }

	// RVA: 0x75694A0
	private static object UpdateOrAllocate(object data, object vertexCount, object indexCount, object device, object verts, object indices, object indexOffset, object stats) { }

	// RVA: 0x756A8D4
	public static object UpdateOpacityId(object ve, object renderChain) { }

	// RVA: 0x756A9E8
	private static object DoUpdateOpacityId(object ve, object renderChain, object mesh) { }

	// RVA: 0x756AB54
	public static object NudgeVerticesToNewSpace(object ve, object renderChain, object device) { }

	// RVA: 0x756AF64
	private static object PrepareNudgeVertices(object ve, object device, object mesh, object src, object dst, object count) { }

	// RVA: 0x7569864
	private static object InjectMeshDrawCommand(object renderChain, object ve, object cmdPrev, object cmdNext, object mesh, object indexCount, object indexOffset, object material, object texture, object stencilRef) { }

	// RVA: 0x756A2A0
	private static object InjectClosingMeshDrawCommand(object renderChain, object ve, object cmdPrev, object cmdNext, object mesh, object indexCount, object indexOffset, object material, object texture, object stencilRef) { }

	// RVA: 0x75695B4
	private static object FindCommandInsertionPoint(object ve, object prev, object next) { }

	// RVA: 0x7569B78
	private static object FindClosingCommandInsertionPoint(object ve, object prev, object next) { }

	// RVA: 0x75699A0
	private static object InjectCommandInBetween(object renderChain, object cmd, object prev, object next) { }

	// RVA: 0x7569DBC
	private static object InjectClosingCommandInBetween(object renderChain, object cmd, object prev, object next) { }

	// RVA: 0x7568FF0
	public static object ResetCommands(object renderChain, object ve) { }

	// RVA: 0x756B0AC
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.UIR.Implementation
internal enum ClipMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undetermined;
	public const object NotClipped;
	public const object Scissor;
	public const object ShaderDiscard;
	public const object Stencil;
}

// Namespace: UnityEngine.UIElements.UIR.Implementation
internal static class RenderEvents
{

	// Fields
	private static readonly object VisibilityTreshold; // 0x0

	// Methods

	// RVA: 0x756B254
	internal static object ProcessOnClippingChanged(object renderChain, object ve, object dirtyID, object stats) { }

	// RVA: 0x756B98C
	internal static object ProcessOnOpacityChanged(object renderChain, object ve, object dirtyID, object stats) { }

	// RVA: 0x756BF78
	internal static object ProcessOnColorChanged(object renderChain, object ve, object dirtyID, object stats) { }

	// RVA: 0x756C298
	internal static object ProcessOnTransformOrSizeChanged(object renderChain, object ve, object dirtyID, object stats) { }

	// RVA: 0x756C7F4
	internal static object ProcessOnVisualsChanged(object renderChain, object ve, object dirtyID, object stats) { }

	// RVA: 0x756CF2C
	private static object GetTransformIDTransformInfo(object ve) { }

	// RVA: 0x756D08C
	private static object GetClipRectIDClipInfo(object ve) { }

	// RVA: 0x756D25C
	internal static object DepthFirstOnChildAdded(object renderChain, object parent, object ve, object index, object resetState) { }

	// RVA: 0x756EE04
	internal static object DepthFirstOnChildRemoving(object renderChain, object ve) { }

	// RVA: 0x756B35C
	private static object DepthFirstOnClippingChanged(object renderChain, object parent, object ve, object dirtyID, object hierarchical, object isRootOfChange, object isPendingHierarchicalRepaint, object inheritedClipRectIDChanged, object inheritedMaskingChanged, object device, object stats) { }

	// RVA: 0x756BAA8
	private static object DepthFirstOnOpacityChanged(object renderChain, object parentCompositeOpacity, object ve, object dirtyID, object hierarchical, object stats, object isDoingFullVertexRegeneration) { }

	// RVA: 0x756C004
	private static object OnColorChanged(object renderChain, object ve, object dirtyID, object stats) { }

	// RVA: 0x756C374
	private static object DepthFirstOnTransformOrSizeChanged(object renderChain, object parent, object ve, object dirtyID, object device, object isAncestorOfChangeSkinned, object transformChanged, object stats) { }

	// RVA: 0x756CA40
	private static object DepthFirstOnVisualsChanged(object renderChain, object ve, object dirtyID, object parentHierarchyHidden, object hierarchical, object stats) { }

	// RVA: 0x756F5F0
	private static object UpdateTextCoreSettings(object renderChain, object ve) { }

	// RVA: 0x756C944
	private static object IsElementHierarchyHidden(object ve) { }

	// RVA: 0x756DA7C
	private static object GetLastDeepestChild(object ve) { }

	// RVA: 0x756F4A4
	private static object DetermineSelfClipMethod(object renderChain, object ve) { }

	// RVA: 0x756D8E8
	private static object UpdateLocalFlipsWinding(object ve) { }

	// RVA: 0x756FC2C
	private static object UpdateWorldFlipsWinding(object ve) { }

	// RVA: 0x756FA4C
	private static object UpdateZeroScaling(object ve) { }

	// RVA: 0x756DB18
	private static object NeedsTransformID(object ve) { }

	// RVA: 0x756DB70
	internal static object NeedsColorID(object ve) { }

	// RVA: 0x756FC94
	internal static object NeedsTextCoreSettings(object ve) { }

	// RVA: 0x756DB9C
	private static object InitColorIDs(object renderChain, object ve) { }

	// RVA: 0x756E470
	private static object SetColorValues(object renderChain, object ve) { }

	// RVA: 0x756FD54
	private static object .cctor() { }

}

// Namespace: 
internal struct Entry
{

	// Fields
	public object vertices; // 0xFFFFFFFFFFFFFFF8
	public object indices; // 0x8
	public object material; // 0x18
	public object fontTexSDFScale; // 0x20
	public object texture; // 0x24
	public object customCommand; // 0x28
	public object clipRectID; // 0x30
	public object addFlags; // 0x38
	public object uvIsDisplacement; // 0x3C
	public object isTextEntry; // 0x3D
	public object isClipRegisterEntry; // 0x3E
	public object stencilRef; // 0x40
	public object maskDepth; // 0x44
}

// Namespace: 
internal struct ClosingInfo
{

	// Fields
	public object needsClosing; // 0xFFFFFFFFFFFFFFF8
	public object popViewMatrix; // 0xFFFFFFFFFFFFFFF9
	public object popScissorClip; // 0xFFFFFFFFFFFFFFFA
	public object blitAndPopRenderTexture; // 0xFFFFFFFFFFFFFFFB
	public object PopDefaultMaterial; // 0xFFFFFFFFFFFFFFFC
	public object clipUnregisterDrawCommand; // 0x0
	public object clipperRegisterVertices; // 0x8
	public object clipperRegisterIndices; // 0x18
	public object clipperRegisterIndexOffset; // 0x28
	public object maskStencilRef; // 0x2C
}

// Namespace: 
private struct RepeatRectUV
{

	// Fields
	public object rect; // 0xFFFFFFFFFFFFFFF8
	public object uv; // 0x8
}

// Namespace: UnityEngine.UIElements.UIR.Implementation
internal class UIRStylePainter
{

	// Fields
	private object m_Owner; // 0x8
	private object m_Entries; // 0x10
	private object m_Atlas; // 0x18
	private object m_VectorImageManager; // 0x20
	private object m_CurrentEntry; // 0x28
	private object m_ClosingInfo; // 0x78
	private object m_MaskDepth; // 0xB0
	private object m_StencilRef; // 0xB4
	private object m_ClipRectID; // 0xB8
	private object m_SVGBackgroundEntryIndex; // 0xC0
	private object m_VertsPool; // 0xC8
	private object m_IndicesPool; // 0xD0
	private object m_MeshWriteDataPool; // 0xD8
	private object m_NextMeshWriteDataPoolItem; // 0xE0
	private object m_RepeatRectUVList; // 0xE8
	private object m_AllocRawVertsIndicesDelegate; // 0xF0
	private object m_AllocThroughDrawMeshDelegate; // 0xF8
	private readonly object <meshGenerationContext>k__BackingField; // 0x100
	private object <currentElement>k__BackingField; // 0x108
	private object <totalVertices>k__BackingField; // 0x110
	private object <totalIndices>k__BackingField; // 0x114
	private object m_TextInfo; // 0x118

	// Properties
	public object meshGenerationContext { get; }
	public object currentElement { get; set; }
	public object entries { get; }
	public object closingInfo { get; }
	public object totalVertices { get; set; }
	public object totalIndices { get; set; }
	public object visualElement { get; }

	// Methods

	// RVA: 0x756FDA8
	private object GetPooledMeshWriteData() { }

	// RVA: 0x756FF2C
	private object AllocRawVertsIndices(object vertexCount, object indexCount, object allocatorData) { }

	// RVA: 0x757000C
	private object AllocThroughDrawMesh(object vertexCount, object indexCount, object allocatorData) { }

	// RVA: 0x75705DC
	public object .ctor(object renderChain) { }

	// RVA: 0x7570918
	public object get_meshGenerationContext() { }

	// RVA: 0x7570920
	public object get_currentElement() { }

	// RVA: 0x7570928
	private object set_currentElement(object value) { }

	// RVA: 0x7570930
	public object get_entries() { }

	// RVA: 0x7570938
	public object get_closingInfo() { }

	// RVA: 0x7570958
	public object get_totalVertices() { }

	// RVA: 0x7570960
	private object set_totalVertices(object value) { }

	// RVA: 0x7570968
	public object get_totalIndices() { }

	// RVA: 0x7570970
	private object set_totalIndices(object value) { }

	// RVA: 0x7570978
	public object Begin(object ve) { }

	// RVA: 0x7570FB0
	public object LandClipUnregisterMeshDrawCommand(object cmd) { }

	// RVA: 0x7571024
	public object LandClipRegisterMesh(object vertices, object indices, object indexOffset) { }

	// RVA: 0x7570020
	public object DrawMesh(object vertexCount, object indexCount, object texture, object material, object flags) { }

	// RVA: 0x75710C0
	internal object TryAtlasTexture(object texture, object flags, object outUVRegion, object outIsAtlas, object outTextureId, object outAddFlags) { }

	// RVA: 0x75712F8
	internal object BuildEntryFromNativeMesh(object meshData, object texture, object textureId, object isAtlas, object material, object flags, object uvRegion, object addFlags) { }

	// RVA: 0x75717F4
	internal object BuildGradientEntryFromNativeMesh(object meshData, object svgTextureId) { }

	// RVA: 0x7571C4C
	public object BuildRawEntryFromNativeMesh(object meshData) { }

	// RVA: 0x7571E38
	public object DrawText(object te) { }

	// RVA: 0x7571EF4
	private object DrawTextInfo(object textInfo, object offset, object useHints) { }

	// RVA: 0x7572668
	public object DrawRectangle(object rectParams) { }

	// RVA: 0x757311C
	public object DrawBorder(object borderParams) { }

	// RVA: 0x75731C0
	public object DrawImmediate(object callback, object cullingEnabled) { }

	// RVA: 0x7573374
	public object get_visualElement() { }

	// RVA: 0x757337C
	public object DrawVisualElementBackground() { }

	// RVA: 0x757484C
	private object DrawRectangleRepeat(object rectParams, object totalRect) { }

	// RVA: 0x7576210
	private object StampRectangleWithSubRect(object rectParams, object targetRect, object targetUV) { }

	// RVA: 0x7576464
	public object DrawVisualElementBorder() { }

	// RVA: 0x75771E8
	public object ApplyVisualElementClipping() { }

	// RVA: 0x7578428
	private object AdjustSpriteWinding(object vertices, object indices) { }

	// RVA: 0x7572D68
	public object DrawSprite(object rectParams) { }

	// RVA: 0x757290C
	public object DrawVectorImage(object rectParams) { }

	// RVA: 0x7578764
	private object MakeVectorGraphics(object rectParams, object isUsingGradients, object svgTexture, object settingIndexOffset, object finalVertexCount, object finalIndexCount) { }

	// RVA: 0x7578B90
	internal object Reset() { }

	// RVA: 0x7578C28
	private object ValidateMeshWriteData() { }

	// RVA: 0x7577890
	private object GenerateStencilClipEntryForRoundedRectBackground() { }

	// RVA: 0x7577490
	private object GenerateStencilClipEntryForSVGBackground() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal abstract class HierarchyTraversal
{

	// Methods

	// RVA: 0x7579100
	public virtual object Traverse(object element) { }

	// RVA: -1
	public abstract object TraverseRecursive(object element, object depth) { }

	// RVA: 0x757914C
	protected object Recurse(object element, object depth) { }

	// RVA: 0x7579248
	protected object .ctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal static class InitialStyle
{

	// Fields
	private static object s_InitialStyle; // 0x0

	// Properties
	public static object alignContent { get; }
	public static object alignItems { get; }
	public static object alignSelf { get; }
	public static object backgroundColor { get; }
	public static object backgroundImage { get; }
	public static object backgroundPositionX { get; }
	public static object backgroundPositionY { get; }
	public static object backgroundRepeat { get; }
	public static object backgroundSize { get; }
	public static object borderBottomColor { get; }
	public static object borderBottomLeftRadius { get; }
	public static object borderBottomRightRadius { get; }
	public static object borderBottomWidth { get; }
	public static object borderLeftColor { get; }
	public static object borderLeftWidth { get; }
	public static object borderRightColor { get; }
	public static object borderRightWidth { get; }
	public static object borderTopColor { get; }
	public static object borderTopLeftRadius { get; }
	public static object borderTopRightRadius { get; }
	public static object borderTopWidth { get; }
	public static object bottom { get; }
	public static object color { get; }
	public static object cursor { get; }
	public static object display { get; }
	public static object flexBasis { get; }
	public static object flexDirection { get; }
	public static object flexGrow { get; }
	public static object flexShrink { get; }
	public static object flexWrap { get; }
	public static object fontSize { get; }
	public static object height { get; }
	public static object justifyContent { get; }
	public static object left { get; }
	public static object letterSpacing { get; }
	public static object marginBottom { get; }
	public static object marginLeft { get; }
	public static object marginRight { get; }
	public static object marginTop { get; }
	public static object maxHeight { get; }
	public static object maxWidth { get; }
	public static object minHeight { get; }
	public static object minWidth { get; }
	public static object opacity { get; }
	public static object overflow { get; }
	public static object paddingBottom { get; }
	public static object paddingLeft { get; }
	public static object paddingRight { get; }
	public static object paddingTop { get; }
	public static object position { get; }
	public static object right { get; }
	public static object rotate { get; }
	public static object scale { get; }
	public static object textOverflow { get; }
	public static object textShadow { get; }
	public static object top { get; }
	public static object transformOrigin { get; }
	public static object transitionDelay { get; }
	public static object transitionDuration { get; }
	public static object transitionProperty { get; }
	public static object transitionTimingFunction { get; }
	public static object translate { get; }
	public static object unityBackgroundImageTintColor { get; }
	public static object unityFont { get; }
	public static object unityFontDefinition { get; }
	public static object unityFontStyleAndWeight { get; }
	public static object unityOverflowClipBox { get; }
	public static object unityParagraphSpacing { get; }
	public static object unitySliceBottom { get; }
	public static object unitySliceLeft { get; }
	public static object unitySliceRight { get; }
	public static object unitySliceScale { get; }
	public static object unitySliceTop { get; }
	public static object unityTextAlign { get; }
	public static object unityTextOutlineColor { get; }
	public static object unityTextOutlineWidth { get; }
	public static object unityTextOverflowPosition { get; }
	public static object visibility { get; }
	public static object whiteSpace { get; }
	public static object width { get; }
	public static object wordSpacing { get; }

	// Methods

	// RVA: 0x7579250
	public static object Get() { }

	// RVA: 0x75792C4
	public static object Acquire() { }

	// RVA: 0x7579370
	private static object .cctor() { }

	// RVA: 0x757A2CC
	public static object get_alignContent() { }

	// RVA: 0x757A348
	public static object get_alignItems() { }

	// RVA: 0x757A3C4
	public static object get_alignSelf() { }

	// RVA: 0x757A440
	public static object get_backgroundColor() { }

	// RVA: 0x757A4C0
	public static object get_backgroundImage() { }

	// RVA: 0x757A54C
	public static object get_backgroundPositionX() { }

	// RVA: 0x757A5D0
	public static object get_backgroundPositionY() { }

	// RVA: 0x757A654
	public static object get_backgroundRepeat() { }

	// RVA: 0x757A6D0
	public static object get_backgroundSize() { }

	// RVA: 0x757A764
	public static object get_borderBottomColor() { }

	// RVA: 0x757A7E4
	public static object get_borderBottomLeftRadius() { }

	// RVA: 0x757A860
	public static object get_borderBottomRightRadius() { }

	// RVA: 0x757A8DC
	public static object get_borderBottomWidth() { }

	// RVA: 0x757A958
	public static object get_borderLeftColor() { }

	// RVA: 0x757A9D8
	public static object get_borderLeftWidth() { }

	// RVA: 0x757AA54
	public static object get_borderRightColor() { }

	// RVA: 0x757AAD4
	public static object get_borderRightWidth() { }

	// RVA: 0x757AB50
	public static object get_borderTopColor() { }

	// RVA: 0x757ABD0
	public static object get_borderTopLeftRadius() { }

	// RVA: 0x757AC4C
	public static object get_borderTopRightRadius() { }

	// RVA: 0x757ACC8
	public static object get_borderTopWidth() { }

	// RVA: 0x757AD44
	public static object get_bottom() { }

	// RVA: 0x757ADC0
	public static object get_color() { }

	// RVA: 0x757AE3C
	public static object get_cursor() { }

	// RVA: 0x757AED0
	public static object get_display() { }

	// RVA: 0x757AF4C
	public static object get_flexBasis() { }

	// RVA: 0x757AFC8
	public static object get_flexDirection() { }

	// RVA: 0x757B044
	public static object get_flexGrow() { }

	// RVA: 0x757B0C0
	public static object get_flexShrink() { }

	// RVA: 0x757B13C
	public static object get_flexWrap() { }

	// RVA: 0x757B1B8
	public static object get_fontSize() { }

	// RVA: 0x757B230
	public static object get_height() { }

	// RVA: 0x757B2AC
	public static object get_justifyContent() { }

	// RVA: 0x757B328
	public static object get_left() { }

	// RVA: 0x757B3A4
	public static object get_letterSpacing() { }

	// RVA: 0x757B41C
	public static object get_marginBottom() { }

	// RVA: 0x757B498
	public static object get_marginLeft() { }

	// RVA: 0x757B514
	public static object get_marginRight() { }

	// RVA: 0x757B590
	public static object get_marginTop() { }

	// RVA: 0x757B60C
	public static object get_maxHeight() { }

	// RVA: 0x757B688
	public static object get_maxWidth() { }

	// RVA: 0x757B704
	public static object get_minHeight() { }

	// RVA: 0x757B780
	public static object get_minWidth() { }

	// RVA: 0x757B7FC
	public static object get_opacity() { }

	// RVA: 0x757B878
	public static object get_overflow() { }

	// RVA: 0x757B8F4
	public static object get_paddingBottom() { }

	// RVA: 0x757B970
	public static object get_paddingLeft() { }

	// RVA: 0x757B9EC
	public static object get_paddingRight() { }

	// RVA: 0x757BA68
	public static object get_paddingTop() { }

	// RVA: 0x757BAE4
	public static object get_position() { }

	// RVA: 0x757BB60
	public static object get_right() { }

	// RVA: 0x757BBDC
	public static object get_rotate() { }

	// RVA: 0x757BC70
	public static object get_scale() { }

	// RVA: 0x757BCF0
	public static object get_textOverflow() { }

	// RVA: 0x757BD6C
	public static object get_textShadow() { }

	// RVA: 0x757BDFC
	public static object get_top() { }

	// RVA: 0x757BE78
	public static object get_transformOrigin() { }

	// RVA: 0x757BF0C
	public static object get_transitionDelay() { }

	// RVA: 0x757BF88
	public static object get_transitionDuration() { }

	// RVA: 0x757C004
	public static object get_transitionProperty() { }

	// RVA: 0x757C080
	public static object get_transitionTimingFunction() { }

	// RVA: 0x757C0FC
	public static object get_translate() { }

	// RVA: 0x757C190
	public static object get_unityBackgroundImageTintColor() { }

	// RVA: 0x757C210
	public static object get_unityFont() { }

	// RVA: 0x757C288
	public static object get_unityFontDefinition() { }

	// RVA: 0x757C304
	public static object get_unityFontStyleAndWeight() { }

	// RVA: 0x757C37C
	public static object get_unityOverflowClipBox() { }

	// RVA: 0x757C3F8
	public static object get_unityParagraphSpacing() { }

	// RVA: 0x757C470
	public static object get_unitySliceBottom() { }

	// RVA: 0x757C4EC
	public static object get_unitySliceLeft() { }

	// RVA: 0x757C568
	public static object get_unitySliceRight() { }

	// RVA: 0x757C5E4
	public static object get_unitySliceScale() { }

	// RVA: 0x757C660
	public static object get_unitySliceTop() { }

	// RVA: 0x757C6DC
	public static object get_unityTextAlign() { }

	// RVA: 0x757C754
	public static object get_unityTextOutlineColor() { }

	// RVA: 0x757C7D0
	public static object get_unityTextOutlineWidth() { }

	// RVA: 0x757C848
	public static object get_unityTextOverflowPosition() { }

	// RVA: 0x757C8C4
	public static object get_visibility() { }

	// RVA: 0x757C93C
	public static object get_whiteSpace() { }

	// RVA: 0x757C9B4
	public static object get_width() { }

	// RVA: 0x757CA30
	public static object get_wordSpacing() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal static class ShorthandApplicator
{

	// Fields
	private static object s_TransitionDelayList; // 0x0
	private static object s_TransitionDurationList; // 0x8
	private static object s_TransitionPropertyList; // 0x10
	private static object s_TransitionTimingFunctionList; // 0x18

	// Methods

	// RVA: 0x757CAA8
	public static object ApplyBackgroundPosition(object reader, object computedStyle) { }

	// RVA: 0x757D310
	public static object ApplyBorderColor(object reader, object computedStyle) { }

	// RVA: 0x757D59C
	public static object ApplyBorderRadius(object reader, object computedStyle) { }

	// RVA: 0x757D7DC
	public static object ApplyBorderWidth(object reader, object computedStyle) { }

	// RVA: 0x757D9E8
	public static object ApplyFlex(object reader, object computedStyle) { }

	// RVA: 0x757DE7C
	public static object ApplyMargin(object reader, object computedStyle) { }

	// RVA: 0x757E110
	public static object ApplyPadding(object reader, object computedStyle) { }

	// RVA: 0x757E1FC
	public static object ApplyTransition(object reader, object computedStyle) { }

	// RVA: 0x757ED3C
	public static object ApplyUnityBackgroundScaleMode(object reader, object computedStyle) { }

	// RVA: 0x757EF58
	public static object ApplyUnityTextOutline(object reader, object computedStyle) { }

	// RVA: 0x757DAB8
	private static object CompileFlexShorthand(object reader, object grow, object shrink, object basis) { }

	// RVA: 0x757D688
	private static object CompileBorderRadius(object reader, object top, object right, object bottom, object left) { }

	// RVA: 0x757CB7C
	private static object CompileBackgroundPosition(object reader, object backgroundPositionX, object backgroundPositionY) { }

	// RVA: 0x757EEA4
	public static object CompileUnityBackgroundScaleMode(object reader, object backgroundPositionX, object backgroundPositionY, object backgroundRepeat, object backgroundSize) { }

	// RVA: 0x757DF68
	private static object CompileBoxArea(object reader, object top, object right, object bottom, object left) { }

	// RVA: 0x757D924
	private static object CompileBoxArea(object reader, object top, object right, object bottom, object left) { }

	// RVA: 0x757D404
	private static object CompileBoxArea(object reader, object top, object right, object bottom, object left) { }

	// RVA: 0x757F014
	private static object CompileTextOutline(object reader, object outlineColor, object outlineWidth) { }

	// RVA: 0x757E350
	private static object CompileTransition(object reader, object outDelay, object outDuration, object outProperty, object outTimingFunction) { }

	// RVA: 0x7580C14
	private static object .cctor() { }

	// RVA: 0x757F6F4
	internal static object <CompileBackgroundPosition>g__SwapKeyword|16_0(object a, object b) { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal static class StylePropertyCache
{

	// Fields
	internal static readonly object s_PropertySyntaxCache; // 0x0
	internal static readonly object s_NonTerminalValues; // 0x8

	// Methods

	// RVA: 0x7580D64
	public static object TryGetSyntax(object name, object syntax) { }

	// RVA: 0x7580E18
	public static object TryGetNonTerminalValue(object name, object syntax) { }

	// RVA: 0x7580ECC
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal enum StyleEnumType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Align;
	public const object BackgroundPositionKeyword;
	public const object BackgroundSizeType;
	public const object DisplayStyle;
	public const object EasingMode;
	public const object FlexDirection;
	public const object FontStyle;
	public const object Justify;
	public const object Overflow;
	public const object OverflowClipBox;
	public const object OverflowInternal;
	public const object Position;
	public const object Repeat;
	public const object RepeatXY;
	public const object ScaleMode;
	public const object TextAnchor;
	public const object TextOverflow;
	public const object TextOverflowPosition;
	public const object TransformOriginOffset;
	public const object Visibility;
	public const object WhiteSpace;
	public const object Wrap;
}

// Namespace: UnityEngine.UIElements.StyleSheets
internal enum StylePropertyId
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Custom;
	public const object AlignContent;
	public const object AlignItems;
	public const object AlignSelf;
	public const object All;
	public const object BackgroundColor;
	public const object BackgroundImage;
	public const object BackgroundPosition;
	public const object BackgroundPositionX;
	public const object BackgroundPositionY;
	public const object BackgroundRepeat;
	public const object BackgroundSize;
	public const object BorderBottomColor;
	public const object BorderBottomLeftRadius;
	public const object BorderBottomRightRadius;
	public const object BorderBottomWidth;
	public const object BorderColor;
	public const object BorderLeftColor;
	public const object BorderLeftWidth;
	public const object BorderRadius;
	public const object BorderRightColor;
	public const object BorderRightWidth;
	public const object BorderTopColor;
	public const object BorderTopLeftRadius;
	public const object BorderTopRightRadius;
	public const object BorderTopWidth;
	public const object BorderWidth;
	public const object Bottom;
	public const object Color;
	public const object Cursor;
	public const object Display;
	public const object Flex;
	public const object FlexBasis;
	public const object FlexDirection;
	public const object FlexGrow;
	public const object FlexShrink;
	public const object FlexWrap;
	public const object FontSize;
	public const object Height;
	public const object JustifyContent;
	public const object Left;
	public const object LetterSpacing;
	public const object Margin;
	public const object MarginBottom;
	public const object MarginLeft;
	public const object MarginRight;
	public const object MarginTop;
	public const object MaxHeight;
	public const object MaxWidth;
	public const object MinHeight;
	public const object MinWidth;
	public const object Opacity;
	public const object Overflow;
	public const object Padding;
	public const object PaddingBottom;
	public const object PaddingLeft;
	public const object PaddingRight;
	public const object PaddingTop;
	public const object Position;
	public const object Right;
	public const object Rotate;
	public const object Scale;
	public const object TextOverflow;
	public const object TextShadow;
	public const object Top;
	public const object TransformOrigin;
	public const object Transition;
	public const object TransitionDelay;
	public const object TransitionDuration;
	public const object TransitionProperty;
	public const object TransitionTimingFunction;
	public const object Translate;
	public const object UnityBackgroundImageTintColor;
	public const object UnityBackgroundScaleMode;
	public const object UnityFont;
	public const object UnityFontDefinition;
	public const object UnityFontStyleAndWeight;
	public const object UnityOverflowClipBox;
	public const object UnityParagraphSpacing;
	public const object UnitySliceBottom;
	public const object UnitySliceLeft;
	public const object UnitySliceRight;
	public const object UnitySliceScale;
	public const object UnitySliceTop;
	public const object UnityTextAlign;
	public const object UnityTextOutline;
	public const object UnityTextOutlineColor;
	public const object UnityTextOutlineWidth;
	public const object UnityTextOverflowPosition;
	public const object Visibility;
	public const object WhiteSpace;
	public const object Width;
	public const object WordSpacing;
}

// Namespace: UnityEngine.UIElements.StyleSheets
internal static class StylePropertyUtil
{

	// Fields
	internal static readonly object s_NameToId; // 0x0
	internal static readonly object s_IdToName; // 0x8
	internal static readonly object s_AnimatableProperties; // 0x10
	internal static readonly object s_AnimatableWithUsageHintProperties; // 0x18

	// Methods

	// RVA: 0x757F970
	public static object TryGetEnumIntValue(object enumType, object value, object intValue) { }

	// RVA: 0x7582318
	public static object IsMatchingShorthand(object shorthand, object id) { }

	// RVA: 0x7582554
	public static object IsAnimatable(object id) { }

	// RVA: 0x7582600
	private static object .cctor() { }

}

// Namespace: 
public enum Unit
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unitless;
	public const object Pixel;
	public const object Percent;
	public const object Second;
	public const object Millisecond;
	public const object Degree;
	public const object Gradian;
	public const object Radian;
	public const object Turn;
}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct Dimension
{

	// Fields
	public object unit; // 0xFFFFFFFFFFFFFFF8
	public object value; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x75847E0
	public object .ctor(object value, object unit) { }

	// RVA: 0x757F6B8
	public object ToLength() { }

	// RVA: 0x7584834
	public object ToTime() { }

	// RVA: 0x75848AC
	public object ToAngle() { }

	// RVA: 0x7584980
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x75849A0
	public object Equals(object other) { }

	// RVA: 0x75849E8
	public override object Equals(object obj) { }

	// RVA: 0x7584B68
	public override object GetHashCode() { }

	// RVA: 0x7584C04
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct ScalableImage
{

	// Fields
	public object normalImage; // 0xFFFFFFFFFFFFFFF8
	public object highResolutionImage; // 0x0

	// Methods

	// RVA: 0x7584DA4
	public override object ToString() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct StylePropertyValue
{

	// Fields
	public object sheet; // 0xFFFFFFFFFFFFFFF8
	public object handle; // 0x0
}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct ImageSource
{

	// Fields
	public object texture; // 0xFFFFFFFFFFFFFFF8
	public object sprite; // 0x0
	public object vectorImage; // 0x8
	public object renderTexture; // 0x10

	// Methods

	// RVA: 0x7584F94
	public object IsNull() { }

}

// Namespace: 
internal sealed class GetCursorIdFunction
{

	// Methods

	// RVA: 0x7589F40
	public object .ctor(object object, object method) { }

	// RVA: 0x758A04C
	public virtual object Invoke(object sheet, object handle) { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal class StylePropertyReader
{

	// Fields
	internal static object getCursorIdFunc; // 0x0
	private object m_Values; // 0x8
	private object m_ValueCount; // 0x10
	private object m_Resolver; // 0x18
	private object m_Sheet; // 0x20
	private object m_Properties; // 0x28
	private object m_PropertyIds; // 0x30
	private object m_CurrentValueIndex; // 0x38
	private object m_CurrentPropertyIndex; // 0x3C
	private object <property>k__BackingField; // 0x40
	private object <propertyId>k__BackingField; // 0x48
	private object <valueCount>k__BackingField; // 0x4C
	private object <dpiScaling>k__BackingField; // 0x50

	// Properties
	public object property { get; set; }
	public object propertyId { get; set; }
	public object valueCount { get; set; }
	public object dpiScaling { get; set; }

	// Methods

	// RVA: 0x75850E8
	public object get_property() { }

	// RVA: 0x75850F0
	private object set_property(object value) { }

	// RVA: 0x75850F8
	public object get_propertyId() { }

	// RVA: 0x7585100
	private object set_propertyId(object value) { }

	// RVA: 0x7585108
	public object get_valueCount() { }

	// RVA: 0x7585110
	private object set_valueCount(object value) { }

	// RVA: 0x7585118
	public object get_dpiScaling() { }

	// RVA: 0x7585120
	private object set_dpiScaling(object value) { }

	// RVA: 0x7585128
	public object SetContext(object sheet, object selector, object varContext, object dpiScaling) { }

	// RVA: 0x7585AA4
	public object SetInlineContext(object sheet, object properties, object propertyIds, object dpiScaling) { }

	// RVA: 0x7585AB4
	public object MoveNextProperty() { }

	// RVA: 0x757F508
	public object GetValue(object index) { }

	// RVA: 0x757F2B0
	public object GetValueType(object index) { }

	// RVA: 0x757F170
	public object IsValueType(object index, object type) { }

	// RVA: 0x757F20C
	public object IsKeyword(object index, object keyword) { }

	// RVA: 0x757F8F8
	public object ReadAsString(object index) { }

	// RVA: 0x757F340
	public object ReadLength(object index) { }

	// RVA: 0x757F840
	public object ReadTimeValue(object index) { }

	// RVA: 0x7585BCC
	public object ReadTranslate(object index) { }

	// RVA: 0x7585FF4
	public object ReadTransformOrigin(object index) { }

	// RVA: 0x7586314
	public object ReadRotate(object index) { }

	// RVA: 0x7586590
	public object ReadScale(object index) { }

	// RVA: 0x757F480
	public object ReadFloat(object index) { }

	// RVA: 0x75868E8
	public object ReadInt(object index) { }

	// RVA: 0x757F708
	public object ReadColor(object index) { }

	// RVA: 0x757F578
	public object ReadEnum(object enumType, object index) { }

	// RVA: 0x7586AA4
	public object ReadFontDefinition(object index) { }

	// RVA: 0x758706C
	public object ReadFont(object index) { }

	// RVA: 0x7587420
	public object ReadBackground(object index) { }

	// RVA: 0x7587F70
	public object ReadCursor(object index) { }

	// RVA: 0x758835C
	public object ReadTextShadow(object index) { }

	// RVA: 0x75887FC
	public object ReadBackgroundPositionX(object index) { }

	// RVA: 0x7588900
	public object ReadBackgroundPositionY(object index) { }

	// RVA: 0x7588818
	private object ReadBackgroundPosition(object index, object keyword) { }

	// RVA: 0x7588AB0
	public object ReadBackgroundRepeat(object index) { }

	// RVA: 0x7588CD8
	public object ReadBackgroundSize(object index) { }

	// RVA: 0x758902C
	public object ReadListEasingFunction(object list, object index) { }

	// RVA: 0x7589298
	public object ReadListTimeValue(object list, object index) { }

	// RVA: 0x75894D4
	public object ReadListStylePropertyName(object list, object index) { }

	// RVA: 0x7585420
	private object LoadProperties() { }

	// RVA: 0x7585AF0
	private object SetCurrentProperty() { }

	// RVA: 0x7586154
	public static object ReadTransformOrigin(object valCount, object val1, object val2, object zVvalue) { }

	// RVA: 0x7589708
	private static object ReadTransformOriginEnum(object value, object isVertical, object isHorizontal) { }

	// RVA: 0x7585D2C
	public static object ReadTranslate(object valCount, object val1, object val2, object val3) { }

	// RVA: 0x75866C4
	public static object ReadScale(object valCount, object val1, object val2, object val3) { }

	// RVA: 0x758646C
	public static object ReadRotate(object valCount, object val1, object val2, object val3, object val4) { }

	// RVA: 0x7589A24
	private static object TryReadEnum(object enumType, object value, object intValue) { }

	// RVA: 0x7589890
	private static object ReadEnum(object enumType, object value) { }

	// RVA: 0x7589994
	public static object ReadAngle(object value) { }

	// RVA: 0x758891C
	public static object ReadBackgroundPosition(object valCount, object val1, object val2, object keyword) { }

	// RVA: 0x7588C20
	public static object ReadBackgroundRepeat(object valCount, object val1, object val2) { }

	// RVA: 0x7588DDC
	public static object ReadBackgroundSize(object valCount, object val1, object val2) { }

	// RVA: 0x7587700
	internal static object TryGetImageSourceFromValue(object propertyValue, object dpiScaling, object source) { }

	// RVA: 0x7589B2C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct MatchResultInfo
{

	// Fields
	public readonly object success; // 0xFFFFFFFFFFFFFFF8
	public readonly object triggerPseudoMask; // 0xFFFFFFFFFFFFFFFC
	public readonly object dependencyPseudoMask; // 0x0

	// Methods

	// RVA: 0x758A094
	public object .ctor(object success, object triggerPseudoMask, object dependencyPseudoMask) { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct SelectorMatchRecord
{

	// Fields
	public object sheet; // 0xFFFFFFFFFFFFFFF8
	public object styleSheetIndexInStack; // 0x0
	public object complexSelector; // 0x8

	// Methods

	// RVA: 0x758A0E8
	public object .ctor(object sheet, object styleSheetIndexInStack) { }

	// RVA: 0x758A110
	public static object Compare(object a, object b) { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal static class StyleSelectorHelper
{

	// Methods

	// RVA: 0x758A260
	public static object MatchesSelector(object element, object selector) { }

	// RVA: 0x758A5C0
	public static object MatchRightToLeft(object element, object complexSelector, object processResult) { }

	// RVA: 0x758A864
	private static object FastLookup(object table, object matchedSelectors, object context, object input, object record) { }

	// RVA: 0x758AB6C
	public static object FindMatches(object context, object matchedSelectors, object parentSheetIndex) { }

}

// Namespace: 
private struct SheetHandleKey
{

	// Fields
	public readonly object sheetInstanceID; // 0xFFFFFFFFFFFFFFF8
	public readonly object index; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x758B108
	public object .ctor(object sheet, object index) { }

}

// Namespace: 
private class SheetHandleKeyComparer
{

	// Methods

	// RVA: 0x758B4A4
	public object Equals(object x, object y) { }

	// RVA: 0x758B4B0
	public object GetHashCode(object key) { }

	// RVA: 0x758B45C
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal static class StyleSheetCache
{

	// Fields
	private static object s_Comparer; // 0x0
	private static object s_RulePropertyIdsCache; // 0x8

	// Methods

	// RVA: 0x758520C
	internal static object GetPropertyIds(object sheet, object ruleIndex) { }

	// RVA: 0x758B280
	internal static object GetPropertyIds(object rule) { }

	// RVA: 0x758B148
	private static object GetPropertyId(object rule, object index) { }

	// RVA: 0x758B38C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal static class StyleSheetColor
{

	// Fields
	private static object s_NameToColor; // 0x0

	// Methods

	// RVA: 0x758698C
	public static object TryGetColor(object name, object color) { }

	// RVA: 0x758B4F8
	private static object HexToColor32(object color) { }

	// RVA: 0x758B50C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal static class StyleSheetExtensions
{

	// Methods

	// RVA: 0x758CF6C
	public static object ReadAsString(object sheet, object handle) { }

	// RVA: 0x758D408
	public static object IsVarFunction(object handle) { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct StyleValue
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object keyword; // 0xFFFFFFFFFFFFFFFC
	public object number; // 0x0
	public object length; // 0x0
	public object color; // 0x0
	public object resource; // 0x0
	public object position; // 0x0
	public object repeat; // 0x0
}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct StyleValueManaged
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object keyword; // 0xFFFFFFFFFFFFFFFC
	public object value; // 0x0
}

// Namespace: UnityEngine.UIElements.StyleSheets
internal enum MatchResultErrorCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Syntax;
	public const object EmptyValue;
	public const object ExpectedEndOfValue;
}

// Namespace: UnityEngine.UIElements.StyleSheets
internal struct MatchResult
{

	// Fields
	public object errorCode; // 0xFFFFFFFFFFFFFFF8
	public object errorValue; // 0x0

	// Properties
	public object success { get; }

	// Methods

	// RVA: 0x758D630
	public object get_success() { }

}

// Namespace: 
private struct MatchContext
{

	// Fields
	public object valueIndex; // 0xFFFFFFFFFFFFFFF8
	public object matchedVariableCount; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: UnityEngine.UIElements.StyleSheets
internal abstract class BaseStyleMatcher
{

	// Fields
	protected static readonly object s_CustomIdentRegex; // 0x0
	private object m_ContextStack; // 0x8
	private object m_CurrentContext; // 0x10

	// Properties
	public abstract object valueCount { get; }
	public abstract object isCurrentVariable { get; }
	public abstract object isCurrentComma { get; }
	public object hasCurrent { get; }
	public object currentIndex { get; set; }
	public object matchedVariableCount { get; set; }

	// Methods

	// RVA: -1
	protected abstract object MatchKeyword(object keyword) { }

	// RVA: -1
	protected abstract object MatchNumber() { }

	// RVA: -1
	protected abstract object MatchInteger() { }

	// RVA: -1
	protected abstract object MatchLength() { }

	// RVA: -1
	protected abstract object MatchPercentage() { }

	// RVA: -1
	protected abstract object MatchColor() { }

	// RVA: -1
	protected abstract object MatchResource() { }

	// RVA: -1
	protected abstract object MatchUrl() { }

	// RVA: -1
	protected abstract object MatchTime() { }

	// RVA: -1
	protected abstract object MatchAngle() { }

	// RVA: -1
	protected abstract object MatchCustomIdent() { }

	// RVA: -1
	public abstract object get_valueCount() { }

	// RVA: -1
	public abstract object get_isCurrentVariable() { }

	// RVA: -1
	public abstract object get_isCurrentComma() { }

	// RVA: 0x758D650
	public object get_hasCurrent() { }

	// RVA: 0x758D6A4
	public object get_currentIndex() { }

	// RVA: 0x758D6AC
	public object set_currentIndex(object value) { }

	// RVA: 0x758D6B4
	public object get_matchedVariableCount() { }

	// RVA: 0x758D6BC
	public object set_matchedVariableCount(object value) { }

	// RVA: 0x758D6C4
	protected object Initialize() { }

	// RVA: 0x758D724
	public object MoveNext() { }

	// RVA: 0x758D784
	public object SaveContext() { }

	// RVA: 0x758D7E4
	public object RestoreContext() { }

	// RVA: 0x758D848
	public object DropContext() { }

	// RVA: 0x758D8A4
	protected object Match(object exp) { }

	// RVA: 0x758D96C
	private object MatchExpression(object exp) { }

	// RVA: 0x758DB0C
	private object MatchExpressionWithMultiplier(object exp) { }

	// RVA: 0x758E0F8
	private object MatchGroup(object exp) { }

	// RVA: 0x758DCB8
	private object MatchCombinator(object exp) { }

	// RVA: 0x758E1D0
	private object MatchOr(object exp) { }

	// RVA: 0x758E35C
	private object MatchOrOr(object exp) { }

	// RVA: 0x758E378
	private object MatchAndAnd(object exp) { }

	// RVA: 0x758E448
	private object MatchMany(object exp) { }

	// RVA: 0x758E7E4
	private object MatchManyByOrder(object exp, object matchOrder) { }

	// RVA: 0x758E3C8
	private object MatchJuxtaposition(object exp) { }

	// RVA: 0x758DE9C
	private object MatchDataType(object exp) { }

	// RVA: 0x758E9BC
	protected object .ctor() { }

	// RVA: 0x758EA3C
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets
internal class StylePropertyValueMatcher
{

	// Fields
	private object m_Values; // 0x18

	// Properties
	private object current { get; }
	public override object valueCount { get; }
	public override object isCurrentVariable { get; }
	public override object isCurrentComma { get; }

	// Methods

	// RVA: 0x758EAD4
	private object get_current() { }

	// RVA: 0x758EB80
	public override object get_valueCount() { }

	// RVA: 0x758EBD4
	public override object get_isCurrentVariable() { }

	// RVA: 0x758EBDC
	public override object get_isCurrentComma() { }

	// RVA: 0x758ECAC
	public object Match(object exp, object values) { }

	// RVA: 0x758F084
	protected override object MatchKeyword(object keyword) { }

	// RVA: 0x758F1F0
	protected override object MatchNumber() { }

	// RVA: 0x758F2B8
	protected override object MatchInteger() { }

	// RVA: 0x758F380
	protected override object MatchLength() { }

	// RVA: 0x758F53C
	protected override object MatchPercentage() { }

	// RVA: 0x758F6F8
	protected override object MatchColor() { }

	// RVA: 0x758F8AC
	protected override object MatchResource() { }

	// RVA: 0x758F974
	protected override object MatchUrl() { }

	// RVA: 0x758FA40
	protected override object MatchTime() { }

	// RVA: 0x758FB48
	protected override object MatchCustomIdent() { }

	// RVA: 0x758FCF4
	protected override object MatchAngle() { }

	// RVA: 0x758FEB8
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal class Expression
{

	// Fields
	public object type; // 0x8
	public object multiplier; // 0xC
	public object dataType; // 0x18
	public object combinator; // 0x1C
	public object subExpressions; // 0x20
	public object keyword; // 0x28

	// Methods

	// RVA: 0x758FF70
	public object .ctor(object type) { }

}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal enum ExpressionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Data;
	public const object Keyword;
	public const object Combinator;
}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal enum DataType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Number;
	public const object Integer;
	public const object Length;
	public const object Percentage;
	public const object Color;
	public const object Resource;
	public const object Url;
	public const object Time;
	public const object Angle;
	public const object CustomIdent;
}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal enum ExpressionCombinator
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Or;
	public const object OrOr;
	public const object AndAnd;
	public const object Juxtaposition;
	public const object Group;
}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal enum ExpressionMultiplierType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object ZeroOrMore;
	public const object OneOrMore;
	public const object ZeroOrOne;
	public const object Ranges;
	public const object OneOrMoreComma;
	public const object GroupAtLeastOne;
}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal struct ExpressionMultiplier
{

	// Fields
	public const object Infinity;
	private object m_Type; // 0xFFFFFFFFFFFFFFF8
	public object min; // 0xFFFFFFFFFFFFFFFC
	public object max; // 0x0

	// Properties
	public object type { get; set; }

	// Methods

	// RVA: 0x758D964
	public object get_type() { }

	// RVA: 0x7590030
	public object set_type(object value) { }

	// RVA: 0x758FFB8
	public object .ctor(object type) { }

	// RVA: 0x7590098
	private object SetType(object value) { }

}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal class StyleSyntaxParser
{

	// Fields
	private object m_ProcessExpressionList; // 0x8
	private object m_ExpressionStack; // 0x10
	private object m_CombinatorStack; // 0x18
	private object m_ParsedExpressionCache; // 0x20

	// Methods

	// RVA: 0x7590240
	public object Parse(object syntax) { }

	// RVA: 0x75919E4
	private object ParseExpression(object tokenizer) { }

	// RVA: 0x7592564
	private object ProcessCombinatorStack() { }

	// RVA: 0x7591E58
	private object ParseTerm(object tokenizer) { }

	// RVA: 0x7592330
	private object ParseCombinatorType(object tokenizer) { }

	// RVA: 0x7592040
	private object ParseGroup(object tokenizer) { }

	// RVA: 0x7592994
	private object ParseDataType(object tokenizer) { }

	// RVA: 0x7593308
	private object ParseNonTerminalValue(object syntax) { }

	// RVA: 0x7593484
	private object ParseProperty(object tokenizer) { }

	// RVA: 0x7593048
	private object ParseMultiplier(object tokenizer, object multiplier) { }

	// RVA: 0x7593818
	private object ParseRanges(object tokenizer, object min, object max) { }

	// RVA: 0x7593254
	private static object EatSpace(object tokenizer) { }

	// RVA: 0x7592980
	private static object IsExpressionEnd(object token) { }

	// RVA: 0x7593240
	private static object IsCombinator(object token) { }

	// RVA: 0x7593800
	private static object IsMultiplier(object token) { }

	// RVA: 0x75939A0
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal enum StyleSyntaxTokenType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object String;
	public const object Number;
	public const object Space;
	public const object SingleBar;
	public const object DoubleBar;
	public const object DoubleAmpersand;
	public const object Comma;
	public const object SingleQuote;
	public const object Asterisk;
	public const object Plus;
	public const object QuestionMark;
	public const object HashMark;
	public const object ExclamationPoint;
	public const object OpenBracket;
	public const object CloseBracket;
	public const object OpenBrace;
	public const object CloseBrace;
	public const object LessThan;
	public const object GreaterThan;
	public const object End;
}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal struct StyleSyntaxToken
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object text; // 0x0
	public object number; // 0x8

	// Methods

	// RVA: 0x7593BA0
	public object .ctor(object t) { }

	// RVA: 0x7593BC0
	public object .ctor(object type, object text) { }

	// RVA: 0x7593BE0
	public object .ctor(object type, object number) { }

}

// Namespace: UnityEngine.UIElements.StyleSheets.Syntax
internal class StyleSyntaxTokenizer
{

	// Fields
	private object m_Tokens; // 0x8
	private object m_CurrentTokenIndex; // 0x10

	// Properties
	public object current { get; }

	// Methods

	// RVA: 0x7591D98
	public object get_current() { }

	// RVA: 0x7592E70
	public object MoveNext() { }

	// RVA: 0x759317C
	public object PeekNext() { }

	// RVA: 0x75904EC
	public object Tokenize(object syntax) { }

	// RVA: 0x7593C6C
	private static object IsNextCharacter(object s, object index, object c) { }

	// RVA: 0x7593D90
	private static object IsNextLetterOrDash(object s, object index) { }

	// RVA: 0x7593CC8
	private static object IsNextNumber(object s, object index) { }

	// RVA: 0x7593C00
	private static object GlobCharacter(object s, object index, object c) { }

	// RVA: 0x7590464
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public static class Easing
{

	// Methods

	// RVA: 0x7593E84
	public static object Linear(object t) { }

	// RVA: 0x7593E88
	public static object InSine(object t) { }

	// RVA: 0x7593EBC
	public static object OutSine(object t) { }

	// RVA: 0x7593ED0
	public static object InOutSine(object t) { }

	// RVA: 0x7593F0C
	public static object InQuad(object t) { }

	// RVA: 0x7593F14
	public static object OutQuad(object t) { }

	// RVA: 0x7593F24
	public static object InOutQuad(object t) { }

	// RVA: 0x7593F64
	public static object InCubic(object t) { }

	// RVA: 0x7593F74
	public static object OutCubic(object t) { }

	// RVA: 0x7593FD8
	public static object InOutCubic(object t) { }

	// RVA: 0x7593F6C
	public static object InPower(object t, object power) { }

	// RVA: 0x7593F9C
	public static object OutPower(object t, object power) { }

	// RVA: 0x7594030
	public static object InOutPower(object t, object power) { }

	// RVA: 0x75940A4
	public static object InBounce(object t) { }

	// RVA: 0x75941A4
	public static object OutBounce(object t) { }

	// RVA: 0x759427C
	public static object InOutBounce(object t) { }

	// RVA: 0x75944C0
	public static object InElastic(object t) { }

	// RVA: 0x759454C
	public static object OutElastic(object t) { }

	// RVA: 0x75945E0
	public static object InOutElastic(object t) { }

	// RVA: 0x7594714
	public static object InBack(object t) { }

	// RVA: 0x7594740
	public static object OutBack(object t) { }

	// RVA: 0x7594778
	public static object InOutBack(object t) { }

	// RVA: 0x7594800
	public static object InCirc(object t) { }

	// RVA: 0x7594820
	public static object OutCirc(object t) { }

	// RVA: 0x759483C
	public static object InOutCirc(object t) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7594AD0
	private static object .cctor() { }

	// RVA: 0x7594B30
	public object .ctor() { }

	// RVA: 0x7594B38
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public class PointerOverLinkTagEvent
{

	// Fields
	private object <linkID>k__BackingField; // 0x100
	private object <linkText>k__BackingField; // 0x108

	// Properties
	private object linkID { set; }
	private object linkText { set; }

	// Methods

	// RVA: 0x7594884
	private static object .cctor() { }

	// RVA: 0x7594974
	private object set_linkID(object value) { }

	// RVA: 0x759497C
	private object set_linkText(object value) { }

	// RVA: 0x7594984
	protected override object Init() { }

	// RVA: 0x75949E4
	private object LocalInit() { }

	// RVA: 0x75949F0
	public static object GetPooled(object evt, object linkID, object linkText) { }

	// RVA: 0x7594A70
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7594E18
	private static object .cctor() { }

	// RVA: 0x7594E78
	public object .ctor() { }

	// RVA: 0x7594E80
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public class PointerMoveLinkTagEvent
{

	// Fields
	private object <linkID>k__BackingField; // 0x100
	private object <linkText>k__BackingField; // 0x108

	// Properties
	private object linkID { set; }
	private object linkText { set; }

	// Methods

	// RVA: 0x7594BCC
	private static object .cctor() { }

	// RVA: 0x7594CBC
	private object set_linkID(object value) { }

	// RVA: 0x7594CC4
	private object set_linkText(object value) { }

	// RVA: 0x7594CCC
	protected override object Init() { }

	// RVA: 0x7594D2C
	private object LocalInit() { }

	// RVA: 0x7594D38
	public static object GetPooled(object evt, object linkID, object linkText) { }

	// RVA: 0x7594DB8
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7595128
	private static object .cctor() { }

	// RVA: 0x7595188
	public object .ctor() { }

	// RVA: 0x7595190
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public class PointerOutLinkTagEvent
{

	// Methods

	// RVA: 0x7594F14
	private static object .cctor() { }

	// RVA: 0x7595004
	protected override object Init() { }

	// RVA: 0x7595064
	private object LocalInit() { }

	// RVA: 0x7595070
	public static object GetPooled(object evt, object linkID) { }

	// RVA: 0x75950C8
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x7595470
	private static object .cctor() { }

	// RVA: 0x75954D0
	public object .ctor() { }

	// RVA: 0x75954D8
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public sealed class PointerDownLinkTagEvent
{

	// Fields
	private object <linkID>k__BackingField; // 0x100
	private object <linkText>k__BackingField; // 0x108

	// Properties
	private object linkID { set; }
	private object linkText { set; }

	// Methods

	// RVA: 0x7595224
	private static object .cctor() { }

	// RVA: 0x7595314
	private object set_linkID(object value) { }

	// RVA: 0x759531C
	private object set_linkText(object value) { }

	// RVA: 0x7595324
	protected override object Init() { }

	// RVA: 0x7595384
	private object LocalInit() { }

	// RVA: 0x7595390
	public static object GetPooled(object evt, object linkID, object linkText) { }

	// RVA: 0x7595410
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x75957B8
	private static object .cctor() { }

	// RVA: 0x7595818
	public object .ctor() { }

	// RVA: 0x7595820
	internal object <.cctor>b__0_0() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public class PointerUpLinkTagEvent
{

	// Fields
	private object <linkID>k__BackingField; // 0x100
	private object <linkText>k__BackingField; // 0x108

	// Properties
	private object linkID { set; }
	private object linkText { set; }

	// Methods

	// RVA: 0x759556C
	private static object .cctor() { }

	// RVA: 0x759565C
	private object set_linkID(object value) { }

	// RVA: 0x7595664
	private object set_linkText(object value) { }

	// RVA: 0x759566C
	protected override object Init() { }

	// RVA: 0x75956CC
	private object LocalInit() { }

	// RVA: 0x75956D8
	public static object GetPooled(object evt, object linkID, object linkText) { }

	// RVA: 0x7595758
	public object .ctor() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public struct StyleValues
{

	// Fields
	internal object m_StyleValues; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object top { set; }
	public object left { set; }
	public object width { set; }
	public object height { set; }
	public object right { set; }
	public object bottom { set; }
	public object color { set; }
	public object backgroundColor { set; }
	public object unityBackgroundImageTintColor { set; }
	public object borderColor { set; }
	public object marginLeft { set; }
	public object marginTop { set; }
	public object marginRight { set; }
	public object marginBottom { set; }
	public object paddingLeft { set; }
	public object paddingTop { get; set; }
	public object paddingRight { set; }
	public object paddingBottom { set; }
	public object borderLeftWidth { set; }
	public object borderRightWidth { set; }
	public object borderTopWidth { set; }
	public object borderBottomWidth { set; }
	public object borderTopLeftRadius { set; }
	public object borderTopRightRadius { set; }
	public object borderBottomLeftRadius { set; }
	public object borderBottomRightRadius { set; }
	public object opacity { set; }
	public object flexGrow { set; }
	public object flexShrink { set; }

	// Methods

	// RVA: 0x75958F0
	public object set_top(object value) { }

	// RVA: 0x7595BDC
	public object set_left(object value) { }

	// RVA: 0x7595DCC
	public object set_width(object value) { }

	// RVA: 0x7595FBC
	public object set_height(object value) { }

	// RVA: 0x75961AC
	public object set_right(object value) { }

	// RVA: 0x759639C
	public object set_bottom(object value) { }

	// RVA: 0x759658C
	public object set_color(object value) { }

	// RVA: 0x7596854
	public object set_backgroundColor(object value) { }

	// RVA: 0x7596A2C
	public object set_unityBackgroundImageTintColor(object value) { }

	// RVA: 0x7596C04
	public object set_borderColor(object value) { }

	// RVA: 0x7596DDC
	public object set_marginLeft(object value) { }

	// RVA: 0x7596FCC
	public object set_marginTop(object value) { }

	// RVA: 0x75971BC
	public object set_marginRight(object value) { }

	// RVA: 0x75973AC
	public object set_marginBottom(object value) { }

	// RVA: 0x759759C
	public object set_paddingLeft(object value) { }

	// RVA: 0x759778C
	public object get_paddingTop() { }

	// RVA: 0x75978B0
	public object set_paddingTop(object value) { }

	// RVA: 0x7597AA0
	public object set_paddingRight(object value) { }

	// RVA: 0x7597C90
	public object set_paddingBottom(object value) { }

	// RVA: 0x7597E80
	public object set_borderLeftWidth(object value) { }

	// RVA: 0x7598070
	public object set_borderRightWidth(object value) { }

	// RVA: 0x7598260
	public object set_borderTopWidth(object value) { }

	// RVA: 0x7598450
	public object set_borderBottomWidth(object value) { }

	// RVA: 0x7598640
	public object set_borderTopLeftRadius(object value) { }

	// RVA: 0x7598830
	public object set_borderTopRightRadius(object value) { }

	// RVA: 0x7598A20
	public object set_borderBottomLeftRadius(object value) { }

	// RVA: 0x7598C10
	public object set_borderBottomRightRadius(object value) { }

	// RVA: 0x7598E00
	public object set_opacity(object value) { }

	// RVA: 0x7598FF0
	public object set_flexGrow(object value) { }

	// RVA: 0x75991E0
	public object set_flexShrink(object value) { }

	// RVA: 0x75959E8
	internal object SetValue(object id, object value) { }

	// RVA: 0x7596678
	internal object SetValue(object id, object value) { }

	// RVA: 0x759782C
	internal object Values() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public interface ITransitionAnimations
{

	// Methods

	// RVA: -1
	public abstract object Start(object to, object durationMs) { }

}

// Namespace: UnityEngine.UIElements.Experimental
internal static class Lerp
{

	// Methods

	// RVA: 0x7599638
	public static object Interpolate(object start, object end, object ratio) { }

	// RVA: 0x7599648
	public static object Interpolate(object start, object end, object ratio) { }

	// RVA: 0x7599680
	internal static object Interpolate(object start, object end, object ratio) { }

}

// Namespace: UnityEngine.UIElements.Experimental
internal interface IValueAnimationUpdate
{

	// Methods

	// RVA: -1
	public abstract object Tick(object currentTimeMs) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__67_0() { }

}

// Namespace: UnityEngine.UIElements.Experimental
public sealed class ValueAnimation<T0>
{

	// Fields
	private object m_StartTimeMs; // 0x0
	private object m_DurationMs; // 0x0
	private object <easingCurve>k__BackingField; // 0x0
	private object <isRunning>k__BackingField; // 0x0
	private object <onAnimationCompleted>k__BackingField; // 0x0
	private object <autoRecycle>k__BackingField; // 0x0
	private object <recycled>k__BackingField; // 0x0
	private static object sObjectPool; // 0x0
	private object <owner>k__BackingField; // 0x0
	private object <valueUpdated>k__BackingField; // 0x0
	private object <initialValue>k__BackingField; // 0x0
	private object <interpolator>k__BackingField; // 0x0
	private object _from; // 0x0
	private object fromValueSet; // 0x0
	private object <to>k__BackingField; // 0x0

	// Properties
	public object durationMs { get; set; }
	public object easingCurve { get; set; }
	public object isRunning { get; set; }
	public object onAnimationCompleted { get; set; }
	public object autoRecycle { get; set; }
	private object recycled { get; set; }
	private object owner { get; set; }
	public object valueUpdated { get; set; }
	public object initialValue { get; set; }
	public object interpolator { get; set; }
	public object from { get; set; }
	public object to { get; set; }

	// Methods

	// RVA: -1
	public object get_durationMs() { }

	// RVA: -1
	public object set_durationMs(object value) { }

	// RVA: -1
	public object get_easingCurve() { }

	// RVA: -1
	public object set_easingCurve(object value) { }

	// RVA: -1
	public object get_isRunning() { }

	// RVA: -1
	private object set_isRunning(object value) { }

	// RVA: -1
	public object get_onAnimationCompleted() { }

	// RVA: -1
	public object set_onAnimationCompleted(object value) { }

	// RVA: -1
	public object get_autoRecycle() { }

	// RVA: -1
	public object set_autoRecycle(object value) { }

	// RVA: -1
	private object get_recycled() { }

	// RVA: -1
	private object set_recycled(object value) { }

	// RVA: -1
	private object get_owner() { }

	// RVA: -1
	private object set_owner(object value) { }

	// RVA: -1
	public object get_valueUpdated() { }

	// RVA: -1
	public object set_valueUpdated(object value) { }

	// RVA: -1
	public object get_initialValue() { }

	// RVA: -1
	public object set_initialValue(object value) { }

	// RVA: -1
	public object get_interpolator() { }

	// RVA: -1
	public object set_interpolator(object value) { }

	// RVA: -1
	public object get_from() { }

	// RVA: -1
	public object set_from(object value) { }

	// RVA: -1
	public object get_to() { }

	// RVA: -1
	public object set_to(object value) { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object Start() { }

	// RVA: -1
	public object Stop() { }

	// RVA: -1
	public object Recycle() { }

	// RVA: -1
	private object UnityEngine.UIElements.Experimental.IValueAnimationUpdate.Tick(object currentTimeMs) { }

	// RVA: -1
	private object SetDefaultValues() { }

	// RVA: -1
	private object Unregister() { }

	// RVA: -1
	private object Register() { }

	// RVA: -1
	internal object SetOwner(object e) { }

	// RVA: -1
	private object CheckNotRecycled() { }

	// RVA: -1
	public static object Create(object e, object interpolator) { }

	// RVA: -1
	public object KeepAlive() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class MultiColumnHeaderColumnMovePreview
{

	// Fields
	public static readonly object ussClassName; // 0x0

	// Methods

	// RVA: 0x7599BD0
	public object .ctor() { }

	// RVA: 0x7599CAC
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class MultiColumnHeaderColumnMoveLocationPreview
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object visualUssClassName; // 0x8

	// Methods

	// RVA: 0x7599D50
	public object .ctor() { }

	// RVA: 0x7599E78
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class ColumnMover
{

	// Fields
	private object m_StartPos; // 0x28
	private object m_LastPos; // 0x2C
	private object m_Active; // 0x30
	private object m_Moving; // 0x31
	private object m_Cancelled; // 0x32
	private object m_Header; // 0x38
	private object m_PreviewElement; // 0x40
	private object m_LocationPreviewElement; // 0x48
	private object m_ColumnToMove; // 0x50
	private object m_ColumnToMovePos; // 0x58
	private object m_ColumnToMoveWidth; // 0x5C
	private object m_DestinationColumn; // 0x60
	private object m_MoveBeforeDestination; // 0x68
	private object <columnLayout>k__BackingField; // 0x70
	private object activeChanged; // 0x78
	private object movingChanged; // 0x80

	// Properties
	public object columnLayout { get; set; }
	public object active { get; set; }
	public object moving { get; set; }

	// Methods

	// RVA: 0x7599F48
	public object get_columnLayout() { }

	// RVA: 0x7599F50
	public object set_columnLayout(object value) { }

	// RVA: 0x7599F58
	public object get_active() { }

	// RVA: 0x7599F60
	public object set_active(object value) { }

	// RVA: 0x7599F94
	public object get_moving() { }

	// RVA: 0x7599F9C
	public object set_moving(object value) { }

	// RVA: 0x7599FD0
	public object add_activeChanged(object value) { }

	// RVA: 0x759A084
	public object remove_activeChanged(object value) { }

	// RVA: 0x759A138
	public object add_movingChanged(object value) { }

	// RVA: 0x759A1EC
	public object remove_movingChanged(object value) { }

	// RVA: 0x759A2A0
	public object .ctor() { }

	// RVA: 0x759A3D4
	protected override object RegisterCallbacksOnTarget() { }

	// RVA: 0x759A988
	protected override object UnregisterCallbacksFromTarget() { }

	// RVA: 0x759AF3C
	protected object OnMouseDown(object evt) { }

	// RVA: 0x759B25C
	protected object OnMouseMove(object evt) { }

	// RVA: 0x759B42C
	protected object OnMouseUp(object evt) { }

	// RVA: 0x759B634
	private object OnMouseCaptureOut(object evt) { }

	// RVA: 0x759B834
	private object OnPointerDown(object evt) { }

	// RVA: 0x759B990
	private object OnPointerMove(object evt) { }

	// RVA: 0x759BAE0
	private object OnPointerUp(object evt) { }

	// RVA: 0x759BC44
	private object OnPointerCancel(object evt) { }

	// RVA: 0x759BDC0
	private object OnPointerCaptureOut(object evt) { }

	// RVA: 0x759BD50
	private static object IsNotMouseEvent(object pointerId) { }

	// RVA: 0x759B6C4
	protected object ProcessCancelEvent(object evt, object pointerId) { }

	// RVA: 0x759C028
	private object OnKeyDown(object e) { }

	// RVA: 0x759B008
	private object ProcessDownEvent(object evt, object localPosition, object pointerId) { }

	// RVA: 0x759B2E0
	private object ProcessMoveEvent(object e, object localPosition) { }

	// RVA: 0x759B4EC
	private object ProcessUpEvent(object evt, object localPosition, object pointerId) { }

	// RVA: 0x759C108
	private object BeginDragMove(object pos) { }

	// RVA: 0x759C634
	internal object DragMove(object pos) { }

	// RVA: 0x759CA30
	private object UpdatePreviewPosition() { }

	// RVA: 0x759C63C
	private object UpdateMoveLocation() { }

	// RVA: 0x759BEB8
	private object EndDragMove(object cancelled) { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class MultiColumnHeaderColumnResizePreview
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object visualUssClassName; // 0x8

	// Methods

	// RVA: 0x759CD50
	public object .ctor() { }

	// RVA: 0x759CE78
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class ColumnResizer
{

	// Fields
	private object m_Start; // 0x28
	protected object m_Active; // 0x30
	private object m_Resizing; // 0x31
	private object m_Header; // 0x38
	private object m_Column; // 0x40
	private object m_PreviewElement; // 0x48
	private object <columnLayout>k__BackingField; // 0x50
	private object <preview>k__BackingField; // 0x58

	// Properties
	public object columnLayout { get; set; }
	public object preview { get; set; }

	// Methods

	// RVA: 0x759CF48
	public object get_columnLayout() { }

	// RVA: 0x759CF50
	public object set_columnLayout(object value) { }

	// RVA: 0x759CF58
	public object get_preview() { }

	// RVA: 0x759CF60
	public object set_preview(object value) { }

	// RVA: 0x759CF68
	public object .ctor(object column) { }

	// RVA: 0x759D09C
	protected override object RegisterCallbacksOnTarget() { }

	// RVA: 0x759D308
	protected override object UnregisterCallbacksFromTarget() { }

	// RVA: 0x759D574
	private object OnKeyDown(object e) { }

	// RVA: 0x759D684
	private object OnPointerDown(object e) { }

	// RVA: 0x759D9A8
	private object OnPointerMove(object e) { }

	// RVA: 0x759DB78
	private object OnPointerUp(object e) { }

	// RVA: 0x759D94C
	private object BeginDragResize(object pos) { }

	// RVA: 0x759DB28
	private object DragResize(object pos) { }

	// RVA: 0x759DD10
	private object UpdatePreviewPosition() { }

	// RVA: 0x759D620
	private object EndDragResize(object pos, object cancelled) { }

}

// Namespace: 
private struct ColumnState
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object name; // 0x0
	public object actualWidth; // 0x8
	public object width; // 0xC
	public object visible; // 0x10
}

// Namespace: 
private class ViewState
{

	// Fields
	private object m_HasPersistedData; // 0x8
	private object m_SortDescriptions; // 0x10
	private object m_OrderedColumnStates; // 0x18

	// Methods

	// RVA: 0x75A4560
	internal object Save(object header) { }

	// RVA: 0x75A4178
	internal object Apply(object header) { }

	// RVA: 0x75A5598
	public object OnBeforeSerialize() { }

	// RVA: 0x75A55A4
	public object OnAfterDeserialize() { }

	// RVA: 0x75A55B0
	public object .ctor() { }

}

// Namespace: 
internal class ColumnData
{

	// Fields
	private object <control>k__BackingField; // 0x8
	private object <resizeHandle>k__BackingField; // 0x10

	// Properties
	public object control { get; set; }
	public object resizeHandle { get; set; }

	// Methods

	// RVA: 0x75A5738
	public object get_control() { }

	// RVA: 0x75A5740
	public object set_control(object value) { }

	// RVA: 0x75A5748
	public object get_resizeHandle() { }

	// RVA: 0x75A5750
	public object set_resizeHandle(object value) { }

	// RVA: 0x75A1688
	public object .ctor() { }

}

// Namespace: 
private struct SortedColumnState
{

	// Fields
	public object columnDesc; // 0xFFFFFFFFFFFFFFF8
	public object direction; // 0x0

	// Methods

	// RVA: 0x75A0134
	public object .ctor(object desc, object dir) { }

}

// Namespace: 
private sealed class <>c__DisplayClass59_0
{

	// Fields
	public object column; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0x75A2700
	public object .ctor() { }

	// RVA: 0x75A57A0
	internal object <OnContextualMenuManipulator>b__1(object a) { }

	// RVA: 0x75A57D0
	internal object <OnContextualMenuManipulator>b__2(object a) { }

}

// Namespace: 
private sealed class <>c__DisplayClass65_0
{

	// Fields
	public object column; // 0x8

	// Methods

	// RVA: 0x75A32BC
	public object .ctor() { }

	// RVA: 0x75A58A0
	internal object <UpdateSortColumnDescriptionsOnClick>b__0(object d) { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class MultiColumnCollectionHeader
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object columnContainerUssClassName; // 0x8
	public static readonly object handleContainerUssClassName; // 0x10
	public static readonly object reorderableUssClassName; // 0x18
	private object m_SortingEnabled; // 0x3C0
	private object m_SortedColumns; // 0x3C8
	private object m_OldSortedColumnStates; // 0x3D0
	private object m_SortingUpdatesTemporarilyDisabled; // 0x3D8
	private object m_ViewState; // 0x3E0
	private object m_ApplyingViewState; // 0x3E8
	private object m_DoLayoutScheduled; // 0x3E9
	private readonly object <columnDataMap>k__BackingField; // 0x3F0
	private readonly object <columnLayout>k__BackingField; // 0x3F8
	private readonly object <columnContainer>k__BackingField; // 0x400
	private readonly object <resizeHandleContainer>k__BackingField; // 0x408
	private readonly object <sortDescriptions>k__BackingField; // 0x410
	private readonly object <columns>k__BackingField; // 0x418
	private object columnResized; // 0x420
	private object columnSortingChanged; // 0x428
	private object contextMenuPopulateEvent; // 0x430

	// Properties
	public object columnDataMap { get; }
	public object columnLayout { get; }
	public object columnContainer { get; }
	public object resizeHandleContainer { get; }
	public object sortedColumns { get; }
	public object sortDescriptions { get; }
	public object columns { get; }
	public object sortingEnabled { get; set; }

	// Methods

	// RVA: 0x759DE6C
	public object get_columnDataMap() { }

	// RVA: 0x759DE74
	public object get_columnLayout() { }

	// RVA: 0x759DE7C
	public object get_columnContainer() { }

	// RVA: 0x759DE84
	public object get_resizeHandleContainer() { }

	// RVA: 0x759DE8C
	public object get_sortedColumns() { }

	// RVA: 0x759DE94
	public object get_sortDescriptions() { }

	// RVA: 0x759DE9C
	public object get_columns() { }

	// RVA: 0x759DEA4
	public object get_sortingEnabled() { }

	// RVA: 0x759DEAC
	public object set_sortingEnabled(object value) { }

	// RVA: 0x759EEB4
	public object add_columnResized(object value) { }

	// RVA: 0x759EF68
	public object remove_columnResized(object value) { }

	// RVA: 0x759F01C
	public object add_columnSortingChanged(object value) { }

	// RVA: 0x759F0C0
	public object remove_columnSortingChanged(object value) { }

	// RVA: 0x759F164
	public object add_contextMenuPopulateEvent(object value) { }

	// RVA: 0x759F218
	public object remove_contextMenuPopulateEvent(object value) { }

	// RVA: 0x759F2CC
	public object .ctor(object columns, object sortDescriptions, object sortedColumns) { }

	// RVA: 0x759FFB4
	private object ScheduleDoLayout() { }

	// RVA: 0x75A00F4
	private object ResizeToFit() { }

	// RVA: 0x759E674
	private object UpdateSortedColumns() { }

	// RVA: 0x75A0240
	private object UpdateColumnControls() { }

	// RVA: 0x75A0C18
	private object OnColumnAdded(object column, object index) { }

	// RVA: 0x759FBA4
	private object OnColumnAdded(object column) { }

	// RVA: 0x75A1690
	private object OnColumnRemoved(object column) { }

	// RVA: 0x75A19F8
	private object OnColumnChanged(object column, object type) { }

	// RVA: 0x75A1A98
	private object OnColumnReordered(object column, object from, object to) { }

	// RVA: 0x75A1CC4
	private object OnColumnResized(object column) { }

	// RVA: 0x75A1D04
	private object OnContextualMenuManipulator(object evt) { }

	// RVA: 0x75A2708
	private object OnMoveManipulatorActivated(object mover) { }

	// RVA: 0x75A2830
	private object OnGeometryChanged(object e) { }

	// RVA: 0x75A28E4
	private object DoLayout() { }

	// RVA: 0x75A2930
	private object OnColumnControlGeometryChanged(object evt) { }

	// RVA: 0x75A2D44
	private object OnColumnClicked(object evt) { }

	// RVA: 0x75A2FD0
	private object UpdateSortColumnDescriptionsOnClick(object column, object modifiers) { }

	// RVA: 0x75A32C4
	public object ScrollHorizontally(object horizontalOffset) { }

	// RVA: 0x75A2C00
	private object RaiseColumnResized(object columnIndex) { }

	// RVA: 0x75A0200
	private object RaiseColumnSortingChanged() { }

	// RVA: 0x75A34FC
	private object ApplyColumnSorting() { }

	// RVA: 0x759DEE4
	private object UpdateSortingStatus() { }

	// RVA: 0x75A4088
	internal override object OnViewDataReady() { }

	// RVA: 0x75A01C0
	private object SaveViewState() { }

	// RVA: 0x75A4DFC
	public object Dispose() { }

	// RVA: 0x75A5418
	private static object .cctor() { }

	// RVA: 0x75A5518
	private object <OnContextualMenuManipulator>b__59_0(object a) { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class MultiColumnHeaderColumnSortIndicator
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object arrowUssClassName; // 0x8
	public static readonly object indexLabelUssClassName; // 0x10
	private object m_IndexLabel; // 0x3C0

	// Properties
	public object sortOrderLabel { set; }

	// Methods

	// RVA: 0x75A5960
	public object set_sortOrderLabel(object value) { }

	// RVA: 0x75A59B8
	public object .ctor() { }

	// RVA: 0x75A5B54
	private static object .cctor() { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class MultiColumnHeaderColumnIcon
{

	// Fields
	public static readonly object ussClassName; // 0x0
	private object <isImageInline>k__BackingField; // 0x403

	// Properties
	public object isImageInline { get; set; }

	// Methods

	// RVA: 0x75A5C5C
	public object get_isImageInline() { }

	// RVA: 0x75A5C64
	public object set_isImageInline(object value) { }

	// RVA: 0x75A5C6C
	public object .ctor() { }

	// RVA: 0x75A5D80
	public object UpdateClassList() { }

	// RVA: 0x75A5F5C
	private static object .cctor() { }

	// RVA: 0x75A6000
	private object <.ctor>b__5_0(object evt) { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class MultiColumnHeaderColumn
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object sortableUssClassName; // 0x8
	public static readonly object sortedAscendingUssClassName; // 0x10
	public static readonly object sortedDescendingUssClassName; // 0x18
	public static readonly object movingUssClassName; // 0x20
	public static readonly object contentContainerUssClassName; // 0x28
	public static readonly object contentUssClassName; // 0x30
	public static readonly object defaultContentUssClassName; // 0x38
	public static readonly object hasIconUssClassName; // 0x40
	public static readonly object hasTitleUssClassName; // 0x48
	public static readonly object titleUssClassName; // 0x50
	public static readonly object iconElementName; // 0x58
	public static readonly object titleElementName; // 0x60
	private static readonly object s_BoundVEPropertyName; // 0x68
	private static readonly object s_BindingCallbackVEPropertyName; // 0x70
	private static readonly object s_UnbindingCallbackVEPropertyName; // 0x78
	private static readonly object s_DestroyCallbackVEPropertyName; // 0x80
	private object m_ContentContainer; // 0x3C0
	private object m_Content; // 0x3C8
	private object m_SortIndicatorContainer; // 0x3D0
	private object m_ScheduledHeaderTemplateUpdate; // 0x3D8
	private object <clickable>k__BackingField; // 0x3E0
	private object <mover>k__BackingField; // 0x3E8
	private object <column>k__BackingField; // 0x3F0

	// Properties
	public object clickable { get; set; }
	public object mover { get; set; }
	public object sortOrderLabel { set; }
	public object column { get; set; }
	public object content { get; set; }
	private object isContentBound { get; set; }

	// Methods

	// RVA: 0x75A6004
	public object get_clickable() { }

	// RVA: 0x75A600C
	private object set_clickable(object value) { }

	// RVA: 0x75A6014
	public object get_mover() { }

	// RVA: 0x75A601C
	private object set_mover(object value) { }

	// RVA: 0x75A4028
	public object set_sortOrderLabel(object value) { }

	// RVA: 0x75A6024
	public object get_column() { }

	// RVA: 0x75A602C
	public object set_column(object value) { }

	// RVA: 0x75A6034
	public object get_content() { }

	// RVA: 0x75A603C
	public object set_content(object value) { }

	// RVA: 0x75A6234
	private object get_isContentBound() { }

	// RVA: 0x75A630C
	private object set_isContentBound(object value) { }

	// RVA: 0x75A0C1C
	public object .ctor(object column) { }

	// RVA: 0x75A674C
	private object InitManipulators() { }

	// RVA: 0x75A6B1C
	private object UpdateDataFromColumn() { }

	// RVA: 0x75A6C54
	private object BindHeaderContent() { }

	// RVA: 0x75A6B64
	private object UnbindHeaderContent() { }

	// RVA: 0x75A6128
	private object DestroyHeaderContent() { }

	// RVA: 0x75A6D44
	private object CreateDefaultHeaderContent() { }

	// RVA: 0x75A6EE0
	private object DefaultBindHeaderContent(object ve) { }

	// RVA: 0x75A63CC
	private object UpdateHeaderTemplate() { }

	// RVA: 0x75A65FC
	private object UpdateGeometryFromColumn() { }

	// RVA: 0x75A72F4
	private static object .cctor() { }

	// RVA: 0x75A7628
	private object <.ctor>b__45_0(object c, object role) { }

	// RVA: 0x75A783C
	private object <.ctor>b__45_1(object c) { }

	// RVA: 0x75A7840
	private object <InitManipulators>b__46_0(object mv) { }

}

// Namespace: UnityEngine.UIElements.Internal
internal class MultiColumnHeaderColumnResizeHandle
{

	// Fields
	public static readonly object ussClassName; // 0x0
	public static readonly object dragAreaUssClassName; // 0x8
	private readonly object <dragArea>k__BackingField; // 0x3C0

	// Properties
	public object dragArea { get; }

	// Methods

	// RVA: 0x75A78F0
	public object get_dragArea() { }

	// RVA: 0x75A1560
	public object .ctor() { }

	// RVA: 0x75A78F8
	private static object .cctor() { }

}

