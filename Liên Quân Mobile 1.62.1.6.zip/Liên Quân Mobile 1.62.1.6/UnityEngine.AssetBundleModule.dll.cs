// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public class AssetBundle
{

	// Methods

	// RVA: 0x7345F48
	private object .ctor() { }

	// RVA: 0x7345FD0
	internal static object LoadFromFileAsync_Internal(object path, object crc, object offset) { }

	// RVA: 0x734603C
	public static object LoadFromFileAsync(object path) { }

	// RVA: 0x734609C
	internal static object LoadFromFile_Internal(object path, object crc, object offset) { }

	// RVA: 0x7346108
	public static object LoadFromFile(object path) { }

	// RVA: -1
	public object LoadAsset(object name) { }

	// RVA: 0x7346168
	public object LoadAssetByHash(object hash) { }

	// RVA: -1
	public object LoadAssetByHash(object hash) { }

	// RVA: 0x7346200
	public object LoadAssetByHash(object hash, object type) { }

	// RVA: 0x73463F4
	public object LoadAsset(object name, object type) { }

	// RVA: 0x7346388
	private object LoadAssetByHash_Internal(object hash, object type) { }

	// RVA: 0x7346554
	private object LoadAsset_Internal(object name, object type) { }

	// RVA: 0x73465C0
	public object LoadAssetAsync(object name, object type) { }

	// RVA: 0x734678C
	public object LoadAssetByHashAsync(object hash) { }

	// RVA: 0x7346824
	public object LoadAssetByHashAsync(object hash, object type) { }

	// RVA: 0x7346A18
	public object LoadAllAssets() { }

	// RVA: 0x7346AA0
	public object LoadAllAssets(object type) { }

	// RVA: 0x73469AC
	private object LoadAssetAsyncByHash_Internal(object hash, object type) { }

	// RVA: 0x7346720
	private object LoadAssetAsync_Internal(object name, object type) { }

	// RVA: 0x7346C2C
	public object Unload(object unloadAllLoadedObjects) { }

	// RVA: 0x7346BC0
	internal object LoadAssetWithSubAssets_Internal(object name, object type) { }

}

// Namespace: UnityEngine
public class AssetBundleCreateRequest
{

	// Properties
	public object assetBundle { get; }

	// Methods

	// RVA: 0x7346D2C
	public object get_assetBundle() { }

	// RVA: 0x7346D7C
	public object .ctor() { }

}

// Namespace: UnityEngine
public class AssetBundleRecompressOperation
{
}

// Namespace: UnityEngine
public class AssetBundleRequest
{

	// Properties
	public object asset { get; }

	// Methods

	// RVA: 0x7346E5C
	protected override object GetResult() { }

	// RVA: 0x7346EAC
	public object get_asset() { }

	// RVA: 0x7346EEC
	public object .ctor() { }

}

// Namespace: UnityEngine
public class AssetBundleUnloadOperation
{
}

