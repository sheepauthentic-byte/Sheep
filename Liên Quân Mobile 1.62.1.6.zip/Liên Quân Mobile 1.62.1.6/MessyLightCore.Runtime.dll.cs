// Namespace: 
internal class <Module>
{
}

// Namespace: MessyLight
public struct Int3
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
}

// Namespace: MessyLight
public struct uint2
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: MessyLight
public struct uint3
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0

	// Methods

	// RVA: 0x3943CC4
	public object .ctor(object px, object py, object pz) { }

}

// Namespace: MessyLight
public struct uint4
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public object w; // 0x4
}

// Namespace: MessyLight
public struct float2
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x3943CDC
	public object .ctor(object px, object py) { }

}

// Namespace: MessyLight
public struct float3
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0

	// Methods

	// RVA: 0x3943CEC
	public object .ctor(object vec3) { }

}

// Namespace: MessyLight
public struct float4
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public object w; // 0x4
}

// Namespace: MessyLight
public static class Packing
{

	// Methods

	// RVA: 0x3943D04
	public static object PackR16G14ToUINT(object xy) { }

	// RVA: 0x3943D38
	public static object SafePackColor32ToUInt(object col) { }

	// RVA: 0x3943D70
	public static object AsFloat(object val) { }

}

// Namespace: MessyLight
public class DynamicBakingDebugUI
{

	// Fields
	private object mDynamicProps; // 0x18
	private object mSelectedIndex; // 0x20
	public object slider; // 0x28

	// Methods

	// RVA: 0x3943D90
	private object Start() { }

	// RVA: 0x3943F64
	public object CheckoutIndex() { }

	// RVA: 0x394404C
	public object ApplyIntensity(object val) { }

	// RVA: 0x39440EC
	public object .ctor() { }

}

// Namespace: MessyLight
public class PackedReceivers
{

	// Fields
	public object LightmapReceiverOffsets; // 0x10
	public object LightmapReceivers; // 0x18
	public object VLMReceiverOffsets; // 0x20
	public object VLMReceivers; // 0x28

	// Methods

	// RVA: 0x394416C
	public object .ctor() { }

}

// Namespace: MessyLight
public struct Receiver
{

	// Fields
	public object location; // 0xFFFFFFFFFFFFFFF8
	public object illumination; // 0x8
}

// Namespace: MessyLight
public struct AHDReceiver
{

	// Fields
	public object location; // 0xFFFFFFFFFFFFFFF8
	public object irradiance; // 0x8
	public object directionAndWeight; // 0x18
}

// Namespace: MessyLight
public class Receivers
{

	// Fields
	public object mLightmapReceivers; // 0x10
	public object mLightmapAHDReceivers; // 0x18
	public object mLightmapReceiverOffsets; // 0x20
	public object mVLMReceivers; // 0x28
	public object mVLMReceiverOffsets; // 0x30

	// Methods

	// RVA: 0x3944240
	public object .ctor() { }

}

// Namespace: MessyLight
public class GIPropertyOverrider
{

	// Fields
	public object applyToChildren; // 0x18
	public object mode; // 0x1C
	public object representation; // 0x20
	public object seamStitching; // 0x24
	public object overrideTileSize; // 0x25
	public object tileWidth; // 0x28
	public object tileHeight; // 0x2C
	public object isDynamicLight; // 0x30
	public object groupLights; // 0x38
	public object dynamicLuminanceRatio; // 0x40
	public object dynamicLightIntensity; // 0x44
	public object smoothFactor; // 0x48

	// Methods

	// RVA: 0x3944380
	private object Update() { }

	// RVA: 0x3944384
	public object .ctor() { }

}

// Namespace: MessyLight
public class LightPropertyOverrider
{

	// Fields
	public object directLighting; // 0x18
	public object indirectLighting; // 0x19
	public object visibilityTest; // 0x1A

	// Methods

	// RVA: 0x394442C
	public object GetLightmapBakeType() { }

	// RVA: 0x3944450
	public object .ctor() { }

}

// Namespace: MessyLight
public class TextureData
{

	// Fields
	public object pixels; // 0x8
	public object width; // 0x10
	public object height; // 0x14
	public object depth; // 0x18
	public object wrapMode; // 0x1C

	// Methods

	// RVA: 0x3944468
	public object .ctor(object texture3D) { }

	// RVA: 0x3944520
	public object .ctor(object other) { }

	// RVA: 0x39445F8
	public object GetPixel(object x, object y, object z) { }

	// RVA: 0x3944654
	public object SetPixel(object x, object y, object z, object col) { }

	// RVA: 0x3944694
	public object GetSampledPosition(object uvw) { }

	// RVA: 0x3944A50
	public object Sample(object uvw) { }

	// RVA: 0x39459B0
	private object Clamp(object x, object left, object right) { }

	// RVA: 0x39459C4
	private object RepeatInt(object x, object width) { }

	// RVA: 0x39449DC
	private object TextureWrap(object x, object max) { }

}

