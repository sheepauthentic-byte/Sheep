// Namespace: 
internal class <Module>
{
}

// Namespace: 
internal static class SR
{

	// Methods

	// RVA: 0x6D8AD24
	internal static object GetString(object name) { }

	// RVA: 0x6D8AD28
	internal static object Format(object resourceFormat, object p1) { }

	// RVA: 0x6D8AD9C
	internal static object Format(object resourceFormat, object p1, object p2) { }

	// RVA: 0x6D8AE20
	internal static object Format(object resourceFormat, object p1, object p2, object p3) { }

}

// Namespace: System.Data
public enum AcceptRejectRule
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Cascade;
}

// Namespace: System.Data
internal enum AggregateType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Sum;
	public const object Mean;
	public const object Min;
	public const object Max;
	public const object First;
	public const object Count;
	public const object Var;
	public const object StDev;
}

// Namespace: System.Data
public class InternalDataCollectionBase
{

	// Fields
	internal static readonly object s_refreshEventArgs; // 0x0

	// Properties
	public virtual object Count { get; }
	public object IsSynchronized { get; }
	public object SyncRoot { get; }
	protected virtual object List { get; }

	// Methods

	// RVA: 0x6D8AEAC
	public virtual object get_Count() { }

	// RVA: 0x6D8AF2C
	public virtual object CopyTo(object ar, object index) { }

	// RVA: 0x6D8AFC4
	public virtual object GetEnumerator() { }

	// RVA: 0x6D8B044
	public object get_IsSynchronized() { }

	// RVA: 0x6D8B04C
	internal object NamesEqual(object s1, object s2, object fCaseSensitive, object locale) { }

	// RVA: 0x6D8B164
	public object get_SyncRoot() { }

	// RVA: 0x6D8B168
	protected virtual object get_List() { }

	// RVA: 0x6D8B170
	public object .ctor() { }

	// RVA: 0x6D8B178
	private static object .cctor() { }

}

// Namespace: System.Data
internal sealed class ColumnTypeConverter
{

	// Fields
	private static readonly object s_types; // 0x0
	private object _values; // 0x8

	// Methods

	// RVA: 0x6D8B1FC
	public object .ctor() { }

	// RVA: 0x6D8B204
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x6D8B2D0
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x6D8B8EC
	public override object CanConvertFrom(object context, object sourceType) { }

	// RVA: 0x6D8B9B8
	public override object ConvertFrom(object context, object culture, object value) { }

	// RVA: 0x6D8BC3C
	public override object GetStandardValues(object context) { }

	// RVA: 0x6D8BD88
	public override object GetStandardValuesExclusive(object context) { }

	// RVA: 0x6D8BD90
	public override object GetStandardValuesSupported(object context) { }

	// RVA: 0x6D8BD98
	private static object .cctor() { }

}

// Namespace: System.Data
internal class DataCommonEventSource
{

	// Fields
	internal static readonly object Log; // 0x0
	private static object s_nextScopeId; // 0x8

	// Methods

	// RVA: 0x6D8C8B8
	internal object Trace(object message) { }

	// RVA: -1
	internal object Trace(object format, object arg0) { }

	// RVA: -1
	internal object Trace(object format, object arg0, object arg1) { }

	// RVA: -1
	internal object Trace(object format, object arg0, object arg1, object arg2) { }

	// RVA: -1
	internal object Trace(object format, object arg0, object arg1, object arg2, object arg3) { }

	// RVA: -1
	internal object Trace(object format, object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: -1
	internal object Trace(object format, object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6) { }

	// RVA: 0x6D8C8C8
	internal object EnterScope(object message) { }

	// RVA: -1
	internal object EnterScope(object format, object arg1) { }

	// RVA: -1
	internal object EnterScope(object format, object arg1, object arg2) { }

	// RVA: -1
	internal object EnterScope(object format, object arg1, object arg2, object arg3) { }

	// RVA: -1
	internal object EnterScope(object format, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x6D8C9B4
	internal object ExitScope(object scopeId) { }

	// RVA: 0x6D8C9C4
	public object .ctor() { }

	// RVA: 0x6D8C9CC
	private static object .cctor() { }

}

// Namespace: System.Data
public abstract class Constraint
{

	// Fields
	private object _schemaName; // 0x8
	private object _inCollection; // 0x10
	private object _dataSet; // 0x18
	internal object _name; // 0x20
	internal object _extendedProperties; // 0x28

	// Properties
	public virtual object ConstraintName { get; set; }
	internal object SchemaName { get; set; }
	internal virtual object InCollection { get; set; }
	public abstract object Table { get; }
	public object ExtendedProperties { get; }
	protected virtual object _DataSet { get; }

	// Methods

	// RVA: 0x6D8CA2C
	public virtual object get_ConstraintName() { }

	// RVA: 0x6D8CA34
	public virtual object set_ConstraintName(object value) { }

	// RVA: 0x6D8D0F0
	internal object get_SchemaName() { }

	// RVA: 0x6D8D14C
	internal object set_SchemaName(object value) { }

	// RVA: 0x6D8D180
	internal virtual object get_InCollection() { }

	// RVA: 0x6D8D188
	internal virtual object set_InCollection(object value) { }

	// RVA: -1
	public abstract object get_Table() { }

	// RVA: 0x6D8D1FC
	public object get_ExtendedProperties() { }

	// RVA: -1
	internal abstract object ContainsColumn(object column) { }

	// RVA: -1
	internal abstract object CanEnableConstraint() { }

	// RVA: -1
	internal abstract object Clone(object destination) { }

	// RVA: -1
	internal abstract object Clone(object destination, object ignoreNSforTableLookup) { }

	// RVA: 0x6D8D278
	internal object CheckConstraint() { }

	// RVA: -1
	internal abstract object CheckCanAddToCollection(object constraint) { }

	// RVA: -1
	internal abstract object CanBeRemovedFromCollection(object constraint, object fThrowException) { }

	// RVA: -1
	internal abstract object CheckConstraint(object row, object action) { }

	// RVA: -1
	internal abstract object CheckState() { }

	// RVA: 0x6D8D404
	protected object CheckStateForProperty() { }

	// RVA: 0x6D8D640
	protected virtual object get__DataSet() { }

	// RVA: -1
	internal abstract object IsConstraintViolated() { }

	// RVA: 0x6D8D648
	public override object ToString() { }

	// RVA: 0x6D8D688
	protected object .ctor() { }

}

// Namespace: System.Data
public sealed class ConstraintCollection
{

	// Fields
	private readonly object _table; // 0x8
	private readonly object _list; // 0x10
	private object _defaultNameIndex; // 0x18
	private object _onCollectionChanged; // 0x20
	private object _delayLoadingConstraints; // 0x28
	private object _fLoadForeignKeyConstraintsOnly; // 0x30

	// Properties
	protected override object List { get; }
	public object Item { get; }
	internal object Table { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x6D8D6F4
	internal object .ctor(object table) { }

	// RVA: 0x6D8D7A0
	protected override object get_List() { }

	// RVA: 0x6D8D7A8
	public object get_Item(object index) { }

	// RVA: 0x6D8DA54
	internal object get_Table() { }

	// RVA: 0x6D8DA5C
	public object get_Item(object name) { }

	// RVA: 0x6D8DEC8
	public object Add(object constraint) { }

	// RVA: 0x6D8DED0
	internal object Add(object constraint, object addUniqueWhenAddingForeign) { }

	// RVA: 0x6D8F0E8
	public object Add(object name, object columns, object primaryKey) { }

	// RVA: 0x6D8EB04
	private object AddUniqueConstraint(object constraint) { }

	// RVA: 0x6D8EE60
	private object AddForeignKeyConstraint(object constraint) { }

	// RVA: 0x6D8E890
	private object AutoGenerated(object constraint) { }

	// RVA: 0x6D8F03C
	private object ArrayAdd(object constraint) { }

	// RVA: 0x6D8F34C
	private object ArrayRemove(object constraint) { }

	// RVA: 0x6D8EE30
	internal object AssignName() { }

	// RVA: 0x6D8EF00
	private object BaseAdd(object constraint) { }

	// RVA: 0x6D8F4A0
	private object BaseGroupSwitch(object oldArray, object oldLength, object newArray, object newLength) { }

	// RVA: 0x6D8F764
	private object BaseRemove(object constraint) { }

	// RVA: 0x6D8FBFC
	internal object CanRemove(object constraint, object fThrowException) { }

	// RVA: 0x6D8FC64
	public object Clear() { }

	// RVA: 0x6D90258
	public object Contains(object name) { }

	// RVA: 0x6D90274
	internal object Contains(object name, object caseSensitive) { }

	// RVA: 0x6D8E514
	internal object FindConstraint(object constraint) { }

	// RVA: 0x6D8EC24
	internal object FindKeyConstraint(object columns) { }

	// RVA: 0x6D90480
	internal object FindKeyConstraint(object column) { }

	// RVA: 0x6D90638
	internal object FindForeignKeyConstraint(object parentColumns, object childColumns) { }

	// RVA: 0x6D903D8
	private static object CompareArrays(object a1, object a2) { }

	// RVA: 0x6D8DB9C
	internal object InternalIndexOf(object constraintName) { }

	// RVA: 0x6D8F3D4
	private object MakeName(object index) { }

	// RVA: 0x6D8F0C4
	private object OnCollectionChanged(object ccevent) { }

	// RVA: 0x6D8CD9C
	internal object RegisterName(object name) { }

	// RVA: 0x6D909DC
	public object Remove(object constraint) { }

	// RVA: 0x6D8D064
	internal object UnregisterName(object name) { }

}

// Namespace: System.Data
internal sealed class ConstraintConverter
{

	// Methods

	// RVA: 0x6D90BBC
	public object .ctor() { }

	// RVA: 0x6D90BC4
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x6D90C90
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

}

// Namespace: System.Data
internal class ConstraintEnumerator
{

	// Fields
	private object _tables; // 0x8
	private object _constraints; // 0x10
	private object _currentObject; // 0x18

	// Properties
	protected object CurrentObject { get; }

	// Methods

	// RVA: 0x6D9173C
	public object .ctor(object dataSet) { }

	// RVA: 0x6D917C0
	public object GetNext() { }

	// RVA: 0x6D91BE0
	public object GetConstraint() { }

	// RVA: 0x6D91BE8
	protected virtual object IsValidCandidate(object constraint) { }

	// RVA: 0x6D91BF0
	protected object get_CurrentObject() { }

}

// Namespace: System.Data
internal class ForeignKeyConstraintEnumerator
{

	// Methods

	// RVA: 0x6D91BF8
	public object .ctor(object dataSet) { }

	// RVA: 0x6D91C7C
	protected override object IsValidCandidate(object constraint) { }

	// RVA: 0x6D91D00
	public object GetForeignKeyConstraint() { }

}

// Namespace: System.Data
internal sealed class ChildForeignKeyConstraintEnumerator
{

	// Fields
	private readonly object _table; // 0x20

	// Methods

	// RVA: 0x6D91D7C
	public object .ctor(object dataSet, object inTable) { }

	// RVA: 0x6D91E0C
	protected override object IsValidCandidate(object constraint) { }

}

// Namespace: System.Data
internal sealed class ParentForeignKeyConstraintEnumerator
{

	// Fields
	private readonly object _table; // 0x20

	// Methods

	// RVA: 0x6D91ECC
	public object .ctor(object dataSet, object inTable) { }

	// RVA: 0x6D91F5C
	protected override object IsValidCandidate(object constraint) { }

}

// Namespace: System.Data
public class DataColumn
{

	// Fields
	private object _allowNull; // 0x18
	private object _caption; // 0x20
	private object _columnName; // 0x28
	private object _dataType; // 0x30
	private object _storageType; // 0x38
	internal object _defaultValue; // 0x40
	private object _dateTimeMode; // 0x48
	private object _expression; // 0x50
	private object _maxLength; // 0x58
	private object _ordinal; // 0x5C
	private object _readOnly; // 0x60
	internal object _sortIndex; // 0x68
	internal object _table; // 0x70
	private object _unique; // 0x78
	internal object _columnMapping; // 0x7C
	internal object _hashCode; // 0x80
	internal object _errors; // 0x84
	private object _isSqlType; // 0x88
	private object _implementsINullable; // 0x89
	private object _implementsIChangeTracking; // 0x8A
	private object _implementsIRevertibleChangeTracking; // 0x8B
	private object _implementsIXMLSerializable; // 0x8C
	private object _defaultValueIsNull; // 0x8D
	internal object _dependentColumns; // 0x90
	internal object _extendedProperties; // 0x98
	private object _storage; // 0xA0
	private object _autoInc; // 0xA8
	internal object _columnUri; // 0xB0
	private object _columnPrefix; // 0xB8
	internal object _encodedColumnName; // 0xC0
	internal object _simpleType; // 0xC8
	private static object s_objectTypeCount; // 0x0
	private readonly object _objectID; // 0xD0
	private object <XmlDataType>k__BackingField; // 0xD8
	private object PropertyChanging; // 0xE0

	// Properties
	public object AllowDBNull { get; set; }
	public object AutoIncrement { get; set; }
	internal object AutoIncrementCurrent { get; set; }
	internal object AutoInc { get; }
	public object AutoIncrementSeed { get; set; }
	public object AutoIncrementStep { get; set; }
	public object Caption { get; set; }
	public object ColumnName { get; set; }
	internal object EncodedColumnName { get; }
	internal object FormatProvider { get; }
	internal object Locale { get; }
	internal object ObjectID { get; }
	public object Prefix { get; set; }
	internal object Computed { get; }
	internal object DataExpression { get; }
	public object DataType { get; set; }
	public object DateTimeMode { get; set; }
	public object DefaultValue { get; set; }
	internal object DefaultValueIsNull { get; }
	public object Expression { get; set; }
	public object ExtendedProperties { get; }
	internal object HasData { get; }
	internal object ImplementsINullable { get; }
	internal object ImplementsIChangeTracking { get; }
	internal object ImplementsIRevertibleChangeTracking { get; }
	internal object IsValueType { get; }
	internal object IsSqlType { get; }
	public object MaxLength { get; set; }
	public object Namespace { get; set; }
	public object Ordinal { get; }
	public object ReadOnly { get; set; }
	private object SortIndex { get; }
	public object Table { get; }
	internal object Item { get; set; }
	public object Unique { get; set; }
	internal object XmlDataType { get; set; }
	internal object SimpleType { get; set; }
	public virtual object ColumnMapping { get; set; }
	internal object IsCustomType { get; }
	internal object ImplementsIXMLSerializable { get; }

	// Methods

	// RVA: 0x6D92020
	public object .ctor() { }

	// RVA: 0x6D92414
	public object .ctor(object columnName, object dataType) { }

	// RVA: 0x6D920B4
	public object .ctor(object columnName, object dataType, object expr, object type) { }

	// RVA: 0x6D92504
	private object UpdateColumnType(object type, object typeCode) { }

	// RVA: 0x6D93048
	public object get_AllowDBNull() { }

	// RVA: 0x6D93050
	public object set_AllowDBNull(object value) { }

	// RVA: 0x6D93728
	public object get_AutoIncrement() { }

	// RVA: 0x6D9373C
	public object set_AutoIncrement(object value) { }

	// RVA: 0x6D94A14
	internal object get_AutoIncrementCurrent() { }

	// RVA: 0x6D94AF8
	internal object set_AutoIncrementCurrent(object value) { }

	// RVA: 0x6D948B0
	internal object get_AutoInc() { }

	// RVA: 0x6D94AA8
	public object get_AutoIncrementSeed() { }

	// RVA: 0x6D94E04
	public object set_AutoIncrementSeed(object value) { }

	// RVA: 0x6D94F68
	public object get_AutoIncrementStep() { }

	// RVA: 0x6D94FB8
	public object set_AutoIncrementStep(object value) { }

	// RVA: 0x6D9511C
	public object get_Caption() { }

	// RVA: 0x6D95138
	public object set_Caption(object value) { }

	// RVA: 0x6D952B8
	public object get_ColumnName() { }

	// RVA: 0x6D952C0
	public object set_ColumnName(object value) { }

	// RVA: 0x6D95D24
	internal object get_EncodedColumnName() { }

	// RVA: 0x6D94D00
	internal object get_FormatProvider() { }

	// RVA: 0x6D95238
	internal object get_Locale() { }

	// RVA: 0x6D95DA8
	internal object get_ObjectID() { }

	// RVA: 0x6D95DB0
	public object get_Prefix() { }

	// RVA: 0x6D95DB8
	public object set_Prefix(object value) { }

	// RVA: 0x6D96068
	internal object GetColumnValueAsString(object row, object version) { }

	// RVA: 0x6D96278
	internal object get_Computed() { }

	// RVA: 0x6D96288
	internal object get_DataExpression() { }

	// RVA: 0x6D96290
	public object get_DataType() { }

	// RVA: 0x6D93E38
	public object set_DataType(object value) { }

	// RVA: 0x6D97030
	public object get_DateTimeMode() { }

	// RVA: 0x6D97038
	public object set_DateTimeMode(object value) { }

	// RVA: 0x6D966A0
	public object get_DefaultValue() { }

	// RVA: 0x6D96878
	public object set_DefaultValue(object value) { }

	// RVA: 0x6D975D0
	internal object get_DefaultValueIsNull() { }

	// RVA: 0x6D975D8
	public object get_Expression() { }

	// RVA: 0x6D92634
	public object set_Expression(object value) { }

	// RVA: 0x6D97EA4
	public object get_ExtendedProperties() { }

	// RVA: 0x6D93D18
	internal object get_HasData() { }

	// RVA: 0x6D97F20
	internal object get_ImplementsINullable() { }

	// RVA: 0x6D97F28
	internal object get_ImplementsIChangeTracking() { }

	// RVA: 0x6D97F30
	internal object get_ImplementsIRevertibleChangeTracking() { }

	// RVA: 0x6D97F38
	internal object get_IsValueType() { }

	// RVA: 0x6D97F5C
	internal object get_IsSqlType() { }

	// RVA: 0x6D97F64
	private object SetMaxLengthSimpleType() { }

	// RVA: 0x6D98028
	public object get_MaxLength() { }

	// RVA: 0x6D98030
	public object set_MaxLength(object value) { }

	// RVA: 0x6D98B3C
	public object get_Namespace() { }

	// RVA: 0x6D98BC4
	public object set_Namespace(object value) { }

	// RVA: 0x6D98F20
	public object get_Ordinal() { }

	// RVA: 0x6D98F28
	internal object SetOrdinalInternal(object ordinal) { }

	// RVA: 0x6D990BC
	public object get_ReadOnly() { }

	// RVA: 0x6D9780C
	public object set_ReadOnly(object value) { }

	// RVA: 0x6D99160
	private object get_SortIndex() { }

	// RVA: 0x6D99258
	public object get_Table() { }

	// RVA: 0x6D99260
	internal object SetTable(object table) { }

	// RVA: 0x6D99364
	private object GetDataRow(object index) { }

	// RVA: 0x6D96160
	internal object get_Item(object record) { }

	// RVA: 0x6D993A0
	internal object set_Item(object record, object value) { }

	// RVA: 0x6D97CD0
	internal object InitializeRecord(object record) { }

	// RVA: 0x6D997C8
	internal object SetValue(object record, object value) { }

	// RVA: 0x6D99934
	internal object FreeRecord(object record) { }

	// RVA: 0x6D99998
	public object get_Unique() { }

	// RVA: 0x6D999A0
	public object set_Unique(object value) { }

	// RVA: 0x6D9A028
	internal object InternalUnique(object value) { }

	// RVA: 0x6D9A030
	internal object get_XmlDataType() { }

	// RVA: 0x6D9A038
	internal object set_XmlDataType(object value) { }

	// RVA: 0x6D9A040
	internal object get_SimpleType() { }

	// RVA: 0x6D924B4
	internal object set_SimpleType(object value) { }

	// RVA: 0x6D9A048
	public virtual object get_ColumnMapping() { }

	// RVA: 0x6D9A050
	public virtual object set_ColumnMapping(object value) { }

	// RVA: 0x6D9A5E8
	internal object CheckColumnConstraint(object row, object action) { }

	// RVA: 0x6D985AC
	internal object CheckMaxLength() { }

	// RVA: 0x6D9A6F8
	internal object CheckMaxLength(object dr) { }

	// RVA: 0x6D931F8
	protected internal object CheckNotAllowNull() { }

	// RVA: 0x6D9A648
	internal object CheckNullable(object row) { }

	// RVA: 0x6D99FC8
	protected object CheckUnique() { }

	// RVA: 0x6D9AC50
	internal object Compare(object record1, object record2) { }

	// RVA: 0x6D9ACB4
	internal object CompareValueTo(object record1, object value, object checkType) { }

	// RVA: 0x6D9AF48
	internal object CompareValueTo(object record1, object value) { }

	// RVA: 0x6D9AFAC
	internal object ConvertValue(object value) { }

	// RVA: 0x6D9B000
	internal object Copy(object srcRecordNo, object dstRecordNo) { }

	// RVA: 0x6D9B064
	internal object Clone() { }

	// RVA: 0x6D9B870
	internal object GetAggregateValue(object records, object kind) { }

	// RVA: 0x6D9A7AC
	private object GetStringLength(object record) { }

	// RVA: 0x6D9B96C
	internal object Init(object record) { }

	// RVA: 0x6D93A38
	internal static object IsAutoIncrementType(object dataType) { }

	// RVA: 0x6D9BA5C
	internal object get_IsCustomType() { }

	// RVA: 0x6D9BAE8
	internal object IsValueCustomTypeInstance(object value) { }

	// RVA: 0x6D9BBD8
	internal object get_ImplementsIXMLSerializable() { }

	// RVA: 0x6D963B8
	internal object IsInRelation() { }

	// RVA: 0x6D9BCA8
	internal object IsMaxLengthViolated() { }

	// RVA: 0x6D9C430
	internal object IsNotAllowDBNullViolated() { }

	// RVA: 0x6D9C710
	protected virtual object OnPropertyChanging(object pcevent) { }

	// RVA: 0x6D95C34
	protected internal object RaisePropertyChanging(object name) { }

	// RVA: 0x6D9C734
	private object InsureStorage() { }

	// RVA: 0x6D9C7D0
	internal object SetCapacity(object capacity) { }

	// RVA: 0x6D9C894
	internal object OnSetDataSet() { }

	// RVA: 0x6D9C898
	public override object ToString() { }

	// RVA: 0x6D9C95C
	internal object ConvertXmlToObject(object s) { }

	// RVA: 0x6D9CA20
	internal object ConvertXmlToObject(object xmlReader, object xmlAttrib) { }

	// RVA: 0x6D961B4
	internal object ConvertObjectToXml(object value) { }

	// RVA: 0x6D9CAF4
	internal object ConvertObjectToXml(object value, object xmlWriter, object xmlAttrib) { }

	// RVA: 0x6D9CBD0
	internal object GetEmptyColumnStore(object recordCount) { }

	// RVA: 0x6D9CC70
	internal object CopyValueIntoStore(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6D9CC94
	internal object SetStorage(object store, object nullbits) { }

	// RVA: 0x6D9CD44
	internal object AddDependentColumn(object expressionColumn) { }

	// RVA: 0x6D9CEA4
	internal object RemoveDependentColumn(object expressionColumn) { }

	// RVA: 0x6D97B30
	internal object HandleDependentColumnList(object oldExpression, object newExpression) { }

}

// Namespace: System.Data
internal abstract class AutoIncrementValue
{

	// Fields
	private object <Auto>k__BackingField; // 0x8

	// Properties
	internal object Auto { get; set; }
	internal abstract object Current { get; set; }
	internal abstract object Seed { get; set; }
	internal abstract object Step { get; set; }
	internal abstract object DataType { get; }

	// Methods

	// RVA: 0x6D9CF5C
	internal object get_Auto() { }

	// RVA: 0x6D9CF64
	internal object set_Auto(object value) { }

	// RVA: -1
	internal abstract object get_Current() { }

	// RVA: -1
	internal abstract object set_Current(object value) { }

	// RVA: -1
	internal abstract object get_Seed() { }

	// RVA: -1
	internal abstract object set_Seed(object value) { }

	// RVA: -1
	internal abstract object get_Step() { }

	// RVA: -1
	internal abstract object set_Step(object value) { }

	// RVA: -1
	internal abstract object get_DataType() { }

	// RVA: -1
	internal abstract object SetCurrent(object value, object formatProvider) { }

	// RVA: -1
	internal abstract object SetCurrentAndIncrement(object value) { }

	// RVA: -1
	internal abstract object MoveAfter() { }

	// RVA: 0x6D9B68C
	internal object Clone() { }

	// RVA: 0x6D9CF6C
	protected object .ctor() { }

}

// Namespace: System.Data
internal sealed class AutoIncrementInt64
{

	// Fields
	private object _current; // 0x10
	private object _seed; // 0x18
	private object _step; // 0x20

	// Properties
	internal override object Current { get; set; }
	internal override object DataType { get; }
	internal override object Seed { get; set; }
	internal override object Step { get; set; }

	// Methods

	// RVA: 0x6D9CF74
	internal override object get_Current() { }

	// RVA: 0x6D9CFDC
	internal override object set_Current(object value) { }

	// RVA: 0x6D9D068
	internal override object get_DataType() { }

	// RVA: 0x6D9D108
	internal override object get_Seed() { }

	// RVA: 0x6D9D110
	internal override object set_Seed(object value) { }

	// RVA: 0x6D9D2BC
	internal override object get_Step() { }

	// RVA: 0x6D9D2C4
	internal override object set_Step(object value) { }

	// RVA: 0x6D9D3F4
	internal override object MoveAfter() { }

	// RVA: 0x6D9D408
	internal override object SetCurrent(object value, object formatProvider) { }

	// RVA: 0x6D9D488
	internal override object SetCurrentAndIncrement(object value) { }

	// RVA: 0x6D9D1AC
	private object BoundaryCheck(object value) { }

	// RVA: 0x6D94D80
	public object .ctor() { }

}

// Namespace: System.Data
internal sealed class AutoIncrementBigInteger
{

	// Fields
	private object _current; // 0x10
	private object _seed; // 0x20
	private object _step; // 0x28

	// Properties
	internal override object Current { get; set; }
	internal override object DataType { get; }
	internal override object Seed { get; set; }
	internal override object Step { get; set; }

	// Methods

	// RVA: 0x6D9D5FC
	internal override object get_Current() { }

	// RVA: 0x6D9D664
	internal override object set_Current(object value) { }

	// RVA: 0x6D9D6F0
	internal override object get_DataType() { }

	// RVA: 0x6D9D790
	internal override object get_Seed() { }

	// RVA: 0x6D9D798
	internal override object set_Seed(object value) { }

	// RVA: 0x6D9DA28
	internal override object get_Step() { }

	// RVA: 0x6D9DA94
	internal override object set_Step(object value) { }

	// RVA: 0x6D9DC70
	internal override object MoveAfter() { }

	// RVA: 0x6D9DCF8
	internal override object SetCurrent(object value, object formatProvider) { }

	// RVA: 0x6D9DD28
	internal override object SetCurrentAndIncrement(object value) { }

	// RVA: 0x6D9D8AC
	private object BoundaryCheck(object value) { }

	// RVA: 0x6D94D90
	public object .ctor() { }

}

// Namespace: System.Data
public class DataColumnChangeEventArgs
{

	// Fields
	private object _column; // 0x8
	private readonly object <Row>k__BackingField; // 0x10
	private object <ProposedValue>k__BackingField; // 0x18

	// Properties
	public object ProposedValue { get; set; }

	// Methods

	// RVA: 0x6D9DDFC
	internal object .ctor(object row) { }

	// RVA: 0x6D9DE6C
	public object .ctor(object row, object column, object value) { }

	// RVA: 0x6D9DEF0
	public object get_ProposedValue() { }

	// RVA: 0x6D9DEF8
	public object set_ProposedValue(object value) { }

	// RVA: 0x6D9DF00
	internal object InitializeColumnChangeEvent(object column, object value) { }

}

// Namespace: System.Data
public sealed class DataColumnChangeEventHandler
{

	// Methods

	// RVA: 0x6D9E210
	public object .ctor(object object, object method) { }

	// RVA: 0x6D9E31C
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Data
public sealed class DataColumnCollection
{

	// Fields
	private readonly object _table; // 0x8
	private readonly object _list; // 0x10
	private object _defaultNameIndex; // 0x18
	private object _delayedAddRangeColumns; // 0x20
	private readonly object _columnFromName; // 0x28
	private object _fInClear; // 0x30
	private object _columnsImplementingIChangeTracking; // 0x38
	private object _nColumnsImplementingIChangeTracking; // 0x40
	private object _nColumnsImplementingIRevertibleChangeTracking; // 0x44
	private object CollectionChanged; // 0x48
	private object CollectionChanging; // 0x50
	private object ColumnPropertyChanged; // 0x58

	// Properties
	protected override object List { get; }
	internal object ColumnsImplementingIChangeTracking { get; }
	internal object ColumnsImplementingIChangeTrackingCount { get; }
	internal object ColumnsImplementingIRevertibleChangeTrackingCount { get; }
	public object Item { get; }
	public object Item { get; }
	internal object Item { get; }

	// Methods

	// RVA: 0x6D9E330
	internal object .ctor(object table) { }

	// RVA: 0x6D9E4E4
	protected override object get_List() { }

	// RVA: 0x6D9E4EC
	internal object get_ColumnsImplementingIChangeTracking() { }

	// RVA: 0x6D9E4F4
	internal object get_ColumnsImplementingIChangeTrackingCount() { }

	// RVA: 0x6D9E4FC
	internal object get_ColumnsImplementingIRevertibleChangeTrackingCount() { }

	// RVA: 0x6D9E504
	public object get_Item(object index) { }

	// RVA: 0x6D9E794
	public object get_Item(object name) { }

	// RVA: 0x6D9EAC4
	internal object get_Item(object name, object ns) { }

	// RVA: 0x6D9EBE0
	public object Add(object column) { }

	// RVA: 0x6D9EBEC
	internal object AddAt(object index, object column) { }

	// RVA: 0x6D9F5D4
	public object add_CollectionChanged(object value) { }

	// RVA: 0x6D9F678
	public object remove_CollectionChanged(object value) { }

	// RVA: 0x6D9F71C
	internal object add_ColumnPropertyChanged(object value) { }

	// RVA: 0x6D9F7C0
	internal object remove_ColumnPropertyChanged(object value) { }

	// RVA: 0x6D9F3EC
	private object ArrayAdd(object column) { }

	// RVA: 0x6D9F32C
	private object ArrayAdd(object index, object column) { }

	// RVA: 0x6D9F8C0
	private object ArrayRemove(object column) { }

	// RVA: 0x6D9FBD4
	internal object AssignName() { }

	// RVA: 0x6D9EFE0
	private object BaseAdd(object column) { }

	// RVA: 0x6D9FF64
	private object BaseGroupSwitch(object oldArray, object oldLength, object newArray, object newLength) { }

	// RVA: 0x6DA020C
	private object BaseRemove(object column) { }

	// RVA: 0x6DA0360
	internal object CanRemove(object column, object fThrowException) { }

	// RVA: 0x6D9F864
	private object CheckIChangeTracking(object column) { }

	// RVA: 0x6DA1294
	public object Clear() { }

	// RVA: 0x6DA161C
	public object Contains(object name) { }

	// RVA: 0x6DA16D8
	internal object Contains(object name, object caseSensitive) { }

	// RVA: 0x6DA1784
	public object IndexOf(object columnName) { }

	// RVA: 0x6D9E920
	internal object IndexOfCaseInsensitive(object name) { }

	// RVA: 0x6D9FC78
	private object MakeName(object index) { }

	// RVA: 0x6D9F4F8
	private object OnCollectionChanged(object ccevent) { }

	// RVA: 0x6D9EFBC
	private object OnCollectionChanging(object ccevent) { }

	// RVA: 0x6D95CC0
	internal object OnColumnPropertyChanged(object ccevent) { }

	// RVA: 0x6D95880
	internal object RegisterColumnName(object name, object column) { }

	// RVA: 0x6DA1C2C
	internal object CanRegisterName(object name) { }

	// RVA: 0x6DA1CA0
	public object Remove(object column) { }

	// RVA: 0x6D95AF4
	internal object UnregisterName(object name) { }

	// RVA: 0x6DA11B4
	private object AddColumnsImplementingIChangeTrackingList(object dataColumn) { }

	// RVA: 0x6D9FA7C
	private object RemoveColumnsImplementingIChangeTrackingList(object dataColumn) { }

}

// Namespace: System.Data
internal sealed class DataColumnPropertyDescriptor
{

	// Fields
	private readonly object <Column>k__BackingField; // 0x80

	// Properties
	public override object Attributes { get; }
	internal object Column { get; }
	public override object ComponentType { get; }
	public override object IsReadOnly { get; }
	public override object PropertyType { get; }

	// Methods

	// RVA: 0x6DA1DD8
	internal object .ctor(object dataColumn) { }

	// RVA: 0x6DA1E1C
	public override object get_Attributes() { }

	// RVA: 0x6DA2034
	internal object get_Column() { }

	// RVA: 0x6DA203C
	public override object get_ComponentType() { }

	// RVA: 0x6DA20DC
	public override object get_IsReadOnly() { }

	// RVA: 0x6DA2100
	public override object get_PropertyType() { }

	// RVA: 0x6DA2124
	public override object Equals(object other) { }

	// RVA: 0x6DA21AC
	public override object GetHashCode() { }

	// RVA: 0x6DA21F8
	public override object GetValue(object component) { }

	// RVA: 0x6DA2298
	public override object SetValue(object component, object value) { }

	// RVA: 0x6DA23A0
	public override object ShouldSerializeValue(object component) { }

}

// Namespace: 
internal struct ColumnError
{

	// Fields
	internal object _column; // 0xFFFFFFFFFFFFFFF8
	internal object _error; // 0x0
}

// Namespace: System.Data
internal sealed class DataError
{

	// Fields
	private object _rowError; // 0x8
	private object _count; // 0x10
	private object _errorList; // 0x18

	// Properties
	internal object Text { get; set; }
	internal object HasErrors { get; }

	// Methods

	// RVA: 0x6DA23A8
	internal object .ctor() { }

	// RVA: 0x6DA2410
	internal object .ctor(object rowError) { }

	// RVA: 0x6DA2544
	internal object get_Text() { }

	// RVA: 0x6DA254C
	internal object set_Text(object value) { }

	// RVA: 0x6DA25C8
	internal object get_HasErrors() { }

	// RVA: 0x6DA2604
	internal object SetColumnError(object column, object error) { }

	// RVA: 0x6DA29B8
	internal object GetColumnError(object column) { }

	// RVA: 0x6DA26FC
	internal object Clear(object column) { }

	// RVA: 0x6DA2A60
	internal object Clear() { }

	// RVA: 0x6DA2B18
	internal object GetColumnsInError() { }

	// RVA: 0x6DA24C8
	private object SetText(object errorText) { }

	// RVA: 0x6DA2828
	internal object IndexOf(object column) { }

}

// Namespace: System.Data
public class DataException
{

	// Methods

	// RVA: 0x6DA2C64
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA2C6C
	public object .ctor() { }

	// RVA: 0x6DA2CD4
	public object .ctor(object s) { }

	// RVA: 0x6DA2D04
	public object .ctor(object s, object innerException) { }

}

// Namespace: System.Data
public class ConstraintException
{

	// Methods

	// RVA: 0x6DA2D0C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA2D14
	public object .ctor() { }

	// RVA: 0x6DA2D7C
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class DeletedRowInaccessibleException
{

	// Methods

	// RVA: 0x6DA2DAC
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA2DB4
	public object .ctor() { }

	// RVA: 0x6DA2E1C
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class DuplicateNameException
{

	// Methods

	// RVA: 0x6DA2E4C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA2E54
	public object .ctor() { }

	// RVA: 0x6DA2EBC
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class InRowChangingEventException
{

	// Methods

	// RVA: 0x6DA2EEC
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA2EF4
	public object .ctor() { }

	// RVA: 0x6DA2F5C
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class InvalidConstraintException
{

	// Methods

	// RVA: 0x6DA2F8C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA2F94
	public object .ctor() { }

	// RVA: 0x6DA2FFC
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class NoNullAllowedException
{

	// Methods

	// RVA: 0x6DA302C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA3034
	public object .ctor() { }

	// RVA: 0x6DA309C
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class ReadOnlyException
{

	// Methods

	// RVA: 0x6DA30CC
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA30D4
	public object .ctor() { }

	// RVA: 0x6DA313C
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class RowNotInTableException
{

	// Methods

	// RVA: 0x6DA316C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA3174
	public object .ctor() { }

	// RVA: 0x6DA31DC
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class VersionNotFoundException
{

	// Methods

	// RVA: 0x6DA320C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DA3214
	public object .ctor() { }

	// RVA: 0x6DA327C
	public object .ctor(object s) { }

}

// Namespace: System.Data
internal static class ExceptionBuilder
{

	// Methods

	// RVA: 0x6DA32AC
	private static object TraceException(object trace, object e) { }

	// RVA: 0x6DA335C
	internal static object TraceExceptionAsReturnValue(object e) { }

	// RVA: 0x6D97918
	internal static object TraceExceptionForCapture(object e) { }

	// RVA: 0x6D97D38
	internal static object TraceExceptionWithoutRethrow(object e) { }

	// RVA: 0x6DA3454
	internal static object _Argument(object error) { }

	// RVA: 0x6DA34BC
	internal static object _Argument(object error, object innerException) { }

	// RVA: 0x6DA352C
	private static object _ArgumentNull(object paramName, object msg) { }

	// RVA: 0x6DA359C
	internal static object _ArgumentOutOfRange(object paramName, object msg) { }

	// RVA: 0x6DA360C
	private static object _IndexOutOfRange(object error) { }

	// RVA: 0x6DA3674
	private static object _InvalidOperation(object error) { }

	// RVA: 0x6DA36DC
	private static object _InvalidEnumArgumentException(object error) { }

	// RVA: -1
	private static object _InvalidEnumArgumentException(object value) { }

	// RVA: 0x6DA3744
	private static object ThrowDataException(object error, object innerException) { }

	// RVA: 0x6DA379C
	private static object _Data(object error) { }

	// RVA: 0x6DA3810
	private static object _Constraint(object error) { }

	// RVA: 0x6DA3884
	private static object _InvalidConstraint(object error) { }

	// RVA: 0x6DA38F8
	private static object _DeletedRowInaccessible(object error) { }

	// RVA: 0x6DA396C
	private static object _DuplicateName(object error) { }

	// RVA: 0x6DA39E0
	private static object _InRowChangingEvent(object error) { }

	// RVA: 0x6DA3A54
	private static object _NoNullAllowed(object error) { }

	// RVA: 0x6DA3AC8
	private static object _ReadOnly(object error) { }

	// RVA: 0x6DA3B3C
	private static object _RowNotInTable(object error) { }

	// RVA: 0x6DA3BB0
	private static object _VersionNotFound(object error) { }

	// RVA: 0x6D8E400
	public static object ArgumentNull(object paramName) { }

	// RVA: 0x6DA3C24
	public static object ArgumentOutOfRange(object paramName) { }

	// RVA: 0x6D8D530
	public static object BadObjectPropertyAccess(object error) { }

	// RVA: 0x6D8DDB8
	public static object CaseInsensitiveNameConflict(object name) { }

	// RVA: 0x6DA3D38
	public static object NamespaceNameConflict(object name) { }

	// RVA: 0x6DA3E48
	public static object InvalidOffsetLength() { }

	// RVA: 0x6DA3ED8
	public static object ColumnNotInTheTable(object column, object table) { }

	// RVA: 0x6DA3FF8
	public static object ColumnNotInAnyTable() { }

	// RVA: 0x6D9E668
	public static object ColumnOutOfRange(object index) { }

	// RVA: 0x6DA4088
	public static object ColumnOutOfRange(object column) { }

	// RVA: 0x6D9FD44
	public static object CannotAddColumn1(object column) { }

	// RVA: 0x6D9FE54
	public static object CannotAddColumn2(object column) { }

	// RVA: 0x6D9A448
	public static object CannotAddColumn3() { }

	// RVA: 0x6D9A4D8
	public static object CannotAddColumn4(object column) { }

	// RVA: 0x6DA18D8
	public static object CannotAddDuplicate(object column) { }

	// RVA: 0x6DA1B10
	public static object CannotAddDuplicate2(object table) { }

	// RVA: 0x6DA19F4
	public static object CannotAddDuplicate3(object table) { }

	// RVA: 0x6DA0D04
	public static object CannotRemoveColumn() { }

	// RVA: 0x6DA0D94
	public static object CannotRemovePrimaryKey() { }

	// RVA: 0x6DA0E24
	public static object CannotRemoveChildKey(object relation) { }

	// RVA: 0x6DA0F34
	public static object CannotRemoveConstraint(object constraint, object table) { }

	// RVA: 0x6DA1054
	public static object CannotRemoveExpression(object column, object expression) { }

	// RVA: 0x6D8EA74
	public static object AddPrimaryKeyConstraint() { }

	// RVA: 0x6D8CD0C
	public static object NoConstraintName() { }

	// RVA: 0x6D8D2E8
	public static object ConstraintViolation(object constraint) { }

	// RVA: 0x6DA4198
	public static object KeysToString(object keys) { }

	// RVA: 0x6DA42C0
	public static object UniqueConstraintViolationText(object columns, object values) { }

	// RVA: 0x6DA44E0
	public static object ConstraintViolation(object columns, object values) { }

	// RVA: 0x6D8D928
	public static object ConstraintOutOfRange(object index) { }

	// RVA: 0x6D8E774
	public static object DuplicateConstraint(object constraint) { }

	// RVA: 0x6D908C0
	public static object DuplicateConstraintName(object constraint) { }

	// RVA: 0x6DA4558
	public static object NeededForForeignKeyConstraint(object key, object fk) { }

	// RVA: 0x6D8F22C
	public static object UniqueConstraintViolation() { }

	// RVA: 0x6D8F19C
	public static object ConstraintForeignTable() { }

	// RVA: 0x6D8F2BC
	public static object ConstraintParentValues() { }

	// RVA: 0x6DA46C0
	public static object ConstraintAddFailed(object table) { }

	// RVA: 0x6D8FB6C
	public static object ConstraintRemoveFailed() { }

	// RVA: 0x6DA47C8
	public static object FailedCascadeDelete(object constraint) { }

	// RVA: 0x6DA48E4
	public static object FailedCascadeUpdate(object constraint) { }

	// RVA: 0x6DA4A00
	public static object FailedClearParentTable(object table, object constraint, object childTable) { }

	// RVA: 0x6DA4B34
	public static object ForeignKeyViolation(object constraint, object keys) { }

	// RVA: 0x6DA4C44
	public static object RemoveParentRow(object constraint) { }

	// RVA: 0x6D9C36C
	public static object MaxLengthViolationText(object columnName) { }

	// RVA: 0x6D9C64C
	public static object NotAllowDBNullViolationText(object columnName) { }

	// RVA: 0x6D8E964
	public static object CantAddConstraintToMultipleNestedTable(object tableName) { }

	// RVA: 0x6D93918
	public static object AutoIncrementAndExpression() { }

	// RVA: 0x6D939A8
	public static object AutoIncrementAndDefaultValue() { }

	// RVA: 0x6D9D364
	public static object AutoIncrementSeed() { }

	// RVA: 0x6D96298
	public static object CantChangeDataType() { }

	// RVA: 0x6D96328
	public static object NullDataType() { }

	// RVA: 0x6D957F0
	public static object ColumnNameRequired() { }

	// RVA: 0x6D973B8
	public static object DefaultValueAndAutoIncrement() { }

	// RVA: 0x6D96C7C
	public static object DefaultValueDataType(object column, object defaultType, object columnType, object inner) { }

	// RVA: 0x6D97448
	public static object DefaultValueColumnDataType(object column, object defaultType, object columnType, object inner) { }

	// RVA: 0x6D97638
	public static object ExpressionAndUnique() { }

	// RVA: 0x6D97A10
	public static object ExpressionAndReadOnly() { }

	// RVA: 0x6D976C8
	public static object ExpressionAndConstraint(object column, object constraint) { }

	// RVA: 0x6DA4D70
	public static object ExpressionInConstraint(object column) { }

	// RVA: 0x6D97AA0
	public static object ExpressionCircular() { }

	// RVA: 0x6D9AB34
	public static object NonUniqueValues(object column) { }

	// RVA: 0x6D9A8FC
	public static object NullKeyValues(object column) { }

	// RVA: 0x6D9AA18
	public static object NullValues(object column) { }

	// RVA: 0x6D990C4
	public static object ReadOnlyAndExpression() { }

	// RVA: 0x6DA4E6C
	public static object ReadOnly(object column) { }

	// RVA: 0x6D99F38
	public static object UniqueAndExpression() { }

	// RVA: 0x6D995EC
	public static object SetFailed(object value, object column, object type, object innerException) { }

	// RVA: 0x6DA4F88
	public static object CannotSetToNull(object column) { }

	// RVA: 0x6D9A800
	public static object LongerThanMaxLength(object column) { }

	// RVA: 0x6D989EC
	public static object CannotSetMaxLength(object column, object value) { }

	// RVA: 0x6D983B4
	public static object CannotSetMaxLength2(object column) { }

	// RVA: 0x6D96F10
	public static object CannotSetSimpleContentType(object columnName, object type) { }

	// RVA: 0x6D9A328
	public static object CannotSetSimpleContent(object columnName, object type) { }

	// RVA: 0x6D98E10
	public static object CannotChangeNamespace(object columnName) { }

	// RVA: 0x6D984B0
	public static object HasToBeStringType(object column) { }

	// RVA: 0x6D93D28
	public static object AutoIncrementCannotSetIfHasData(object typeName) { }

	// RVA: 0x6DA5084
	public static object INullableUDTwithoutStaticNull(object typeName) { }

	// RVA: 0x6DA5194
	public static object IComparableNotImplemented(object typeName) { }

	// RVA: 0x6DA52B0
	public static object UDTImplementsIChangeTrackingButnotIRevertible(object typeName) { }

	// RVA: 0x6DA53C0
	public static object InvalidDataColumnMapping(object type) { }

	// RVA: 0x6D97168
	public static object CannotSetDateTimeModeForNonDateTimeColumns() { }

	// RVA: 0x6D97360
	public static object InvalidDateTimeMode(object mode) { }

	// RVA: 0x6D971F8
	public static object CantChangeDateTimeMode(object oldValue, object newValue) { }

	// RVA: 0x6D92420
	public static object ColumnTypeNotSupported() { }

	// RVA: 0x6DA54E4
	public static object SetFailed(object name) { }

	// RVA: 0x6DA5600
	public static object CanNotUse() { }

	// RVA: 0x6DA569C
	public static object SetIListObject() { }

	// RVA: 0x6DA572C
	public static object AddNewNotAllowNull() { }

	// RVA: 0x6DA57C8
	public static object NotOpen() { }

	// RVA: 0x6DA5864
	public static object CreateChildView() { }

	// RVA: 0x6DA58F4
	public static object CanNotDelete() { }

	// RVA: 0x6DA5990
	public static object GetElementIndex(object index) { }

	// RVA: 0x6DA5ABC
	public static object AddExternalObject() { }

	// RVA: 0x6DA5B4C
	public static object CanNotClear() { }

	// RVA: 0x6DA5BDC
	public static object InsertExternalObject() { }

	// RVA: 0x6DA5C6C
	public static object RemoveExternalObject() { }

	// RVA: 0x6DA5CFC
	public static object KeyTableMismatch() { }

	// RVA: 0x6DA5D98
	public static object KeyNoColumns() { }

	// RVA: 0x6DA5E34
	public static object KeyTooManyColumns(object cols) { }

	// RVA: 0x6DA5F6C
	public static object KeyDuplicateColumns(object columnName) { }

	// RVA: 0x6DA6088
	public static object RelationDataSetMismatch() { }

	// RVA: 0x6D96604
	public static object ColumnsTypeMismatch() { }

	// RVA: 0x6DA6124
	public static object KeyLengthMismatch() { }

	// RVA: 0x6DA61B4
	public static object KeyLengthZero() { }

	// RVA: 0x6DA6244
	public static object ForeignRelation() { }

	// RVA: 0x6DA62D4
	public static object KeyColumnsIdentical() { }

	// RVA: 0x6DA6370
	public static object RelationForeignTable(object t1, object t2) { }

	// RVA: 0x6DA649C
	public static object GetParentRowTableMismatch(object t1, object t2) { }

	// RVA: 0x6DA65C8
	public static object SetParentRowTableMismatch(object t1, object t2) { }

	// RVA: 0x6DA66F4
	public static object RelationForeignRow() { }

	// RVA: 0x6DA6784
	public static object RelationNestedReadOnly() { }

	// RVA: 0x6DA6814
	public static object TableCantBeNestedInTwoTables(object tableName) { }

	// RVA: 0x6DA6924
	public static object LoopInNestedRelations(object tableName) { }

	// RVA: 0x6DA6A34
	public static object RelationDoesNotExist() { }

	// RVA: 0x6DA6AC4
	public static object ParentOrChildColumnsDoNotHaveDataSet() { }

	// RVA: 0x6DA6B60
	public static object InValidNestedRelation(object childTableName) { }

	// RVA: 0x6DA6C70
	public static object InvalidParentNamespaceinNestedRelation(object childTableName) { }

	// RVA: 0x6DA6D80
	public static object RowNotInTheDataSet() { }

	// RVA: 0x6DA6E10
	public static object RowNotInTheTable() { }

	// RVA: 0x6DA6EAC
	public static object EditInRowChanging() { }

	// RVA: 0x6DA6F48
	public static object EndEditInRowChanging() { }

	// RVA: 0x6DA6FE4
	public static object BeginEditInRowChanging() { }

	// RVA: 0x6DA7080
	public static object CancelEditInRowChanging() { }

	// RVA: 0x6DA711C
	public static object DeleteInRowDeleting() { }

	// RVA: 0x6DA71B8
	public static object ValueArrayLength() { }

	// RVA: 0x6DA7248
	public static object NoCurrentData() { }

	// RVA: 0x6DA72E4
	public static object NoOriginalData() { }

	// RVA: 0x6DA7380
	public static object NoProposedData() { }

	// RVA: 0x6DA741C
	public static object RowRemovedFromTheTable() { }

	// RVA: 0x6DA74B8
	public static object DeletedRowInaccessible() { }

	// RVA: 0x6DA7554
	public static object RowAlreadyDeleted() { }

	// RVA: 0x6DA75F0
	public static object RowEmpty() { }

	// RVA: 0x6DA7680
	public static object InvalidRowVersion() { }

	// RVA: 0x6DA771C
	public static object RowOutOfRange(object index) { }

	// RVA: 0x6DA7848
	public static object RowInsertTwice(object index, object tableName) { }

	// RVA: 0x6DA7984
	public static object RowInsertMissing(object tableName) { }

	// RVA: 0x6DA7A94
	public static object RowAlreadyRemoved() { }

	// RVA: 0x6DA7B30
	public static object MultipleParents() { }

	// RVA: 0x6DA7BCC
	public static object InvalidRowState(object state) { }

	// RVA: 0x6DA7C24
	public static object InvalidRowBitPattern() { }

	// RVA: 0x6DA7CB4
	internal static object SetDataSetNameToEmpty() { }

	// RVA: 0x6DA7D44
	internal static object SetDataSetNameConflicting(object name) { }

	// RVA: 0x6DA7E54
	public static object DataSetUnsupportedSchema(object ns) { }

	// RVA: 0x6DA7F64
	public static object MergeMissingDefinition(object obj) { }

	// RVA: 0x6DA8074
	public static object TablesInDifferentSets() { }

	// RVA: 0x6DA8104
	public static object RelationAlreadyExists() { }

	// RVA: 0x6DA8194
	public static object RowAlreadyInOtherCollection() { }

	// RVA: 0x6DA8224
	public static object RowAlreadyInTheCollection() { }

	// RVA: 0x6DA82B4
	public static object RecordStateRange() { }

	// RVA: 0x6DA8344
	public static object IndexKeyLength(object length, object keyLength) { }

	// RVA: 0x6DA84E8
	public static object RemovePrimaryKey(object table) { }

	// RVA: 0x6DA8628
	public static object RelationAlreadyInOtherDataSet() { }

	// RVA: 0x6DA86B8
	public static object RelationAlreadyInTheDataSet() { }

	// RVA: 0x6DA8748
	public static object RelationNotInTheDataSet(object relation) { }

	// RVA: 0x6DA8858
	public static object RelationOutOfRange(object index) { }

	// RVA: 0x6DA8978
	public static object DuplicateRelation(object relation) { }

	// RVA: 0x6DA8A94
	public static object RelationTableNull() { }

	// RVA: 0x6DA8B24
	public static object RelationDataSetNull() { }

	// RVA: 0x6DA8BB4
	public static object RelationTableWasRemoved() { }

	// RVA: 0x6DA8C44
	public static object ParentTableMismatch() { }

	// RVA: 0x6DA8CD4
	public static object ChildTableMismatch() { }

	// RVA: 0x6DA8D64
	public static object EnforceConstraint() { }

	// RVA: 0x6DA8E00
	public static object CaseLocaleMismatch() { }

	// RVA: 0x6DA8E90
	public static object CannotChangeCaseLocale() { }

	// RVA: 0x6DA8F24
	public static object CannotChangeCaseLocale(object innerException) { }

	// RVA: 0x6DA8FBC
	public static object InvalidRemotingFormat(object mode) { }

	// RVA: 0x6DA9014
	public static object TableForeignPrimaryKey() { }

	// RVA: 0x6DA90A4
	public static object TableCannotAddToSimpleContent() { }

	// RVA: 0x6DA9134
	public static object NoTableName() { }

	// RVA: 0x6DA91C4
	public static object MultipleTextOnlyColumns() { }

	// RVA: 0x6DA9254
	public static object InvalidSortString(object sort) { }

	// RVA: 0x6DA9364
	public static object DuplicateTableName(object table) { }

	// RVA: 0x6DA9480
	public static object DuplicateTableName2(object table, object ns) { }

	// RVA: 0x6DA95AC
	public static object SelfnestedDatasetConflictingName(object table) { }

	// RVA: 0x6DA96C8
	public static object DatasetConflictingName(object table) { }

	// RVA: 0x6DA97E4
	public static object TableAlreadyInOtherDataSet() { }

	// RVA: 0x6DA9874
	public static object TableAlreadyInTheDataSet() { }

	// RVA: 0x6DA9904
	public static object TableOutOfRange(object index) { }

	// RVA: 0x6DA9A30
	public static object TableNotInTheDataSet(object table) { }

	// RVA: 0x6DA9B40
	public static object TableInRelation() { }

	// RVA: 0x6DA9BD0
	public static object TableInConstraint(object table, object constraint) { }

	// RVA: 0x6DA9D14
	public static object CanNotSerializeDataTableHierarchy() { }

	// RVA: 0x6DA9DA4
	public static object CanNotRemoteDataTable() { }

	// RVA: 0x6DA9E34
	public static object CanNotSetRemotingFormat() { }

	// RVA: 0x6DA9EC4
	public static object CanNotSerializeDataTableWithEmptyName() { }

	// RVA: 0x6DA9F54
	public static object TableNotFound(object tableName) { }

	// RVA: 0x6DAA064
	public static object AggregateException(object aggregateType, object type) { }

	// RVA: 0x6DAA1E8
	public static object InvalidStorageType(object typecode) { }

	// RVA: 0x6DAA324
	public static object RangeArgument(object min, object max) { }

	// RVA: 0x6DAA478
	public static object NullRange() { }

	// RVA: 0x6DAA514
	public static object NegativeMinimumCapacity() { }

	// RVA: 0x6DAA5A4
	public static object ProblematicChars(object charValue) { }

	// RVA: 0x6DAA718
	public static object StorageSetFailed() { }

	// RVA: 0x6DAA7A8
	public static object SimpleTypeNotSupported() { }

	// RVA: 0x6DAA844
	public static object MissingAttribute(object attribute) { }

	// RVA: 0x6DAA8A0
	public static object MissingAttribute(object element, object attribute) { }

	// RVA: 0x6DAA9CC
	public static object InvalidAttributeValue(object name, object value) { }

	// RVA: 0x6DAAAF8
	public static object AttributeValues(object name, object value1, object value2) { }

	// RVA: 0x6DAAC2C
	public static object ElementTypeNotFound(object name) { }

	// RVA: 0x6DAAD48
	public static object RelationParentNameMissing(object rel) { }

	// RVA: 0x6DAAE64
	public static object RelationChildNameMissing(object rel) { }

	// RVA: 0x6DAAF80
	public static object RelationTableKeyMissing(object rel) { }

	// RVA: 0x6DAB09C
	public static object RelationChildKeyMissing(object rel) { }

	// RVA: 0x6DAB1B8
	public static object UndefinedDatatype(object name) { }

	// RVA: 0x6DAB2D4
	public static object DatatypeNotDefined() { }

	// RVA: 0x6DAB370
	public static object MismatchKeyLength() { }

	// RVA: 0x6DAB40C
	public static object InvalidField(object name) { }

	// RVA: 0x6DAB528
	public static object InvalidSelector(object name) { }

	// RVA: 0x6DAB644
	public static object CircularComplexType(object name) { }

	// RVA: 0x6DAB760
	public static object CannotInstantiateAbstract(object name) { }

	// RVA: 0x6DAB87C
	public static object InvalidKey(object name) { }

	// RVA: 0x6DAB998
	public static object DiffgramMissingTable(object name) { }

	// RVA: 0x6DABAB4
	public static object DiffgramMissingSQL() { }

	// RVA: 0x6DABB50
	public static object DuplicateConstraintRead(object str) { }

	// RVA: 0x6DABC6C
	public static object ColumnTypeConflict(object name) { }

	// RVA: 0x6DABD88
	public static object CannotConvert(object name, object type) { }

	// RVA: 0x6DABEB4
	public static object MissingRefer(object name) { }

	// RVA: 0x6D95F4C
	public static object InvalidPrefix(object name) { }

	// RVA: 0x6DABFE8
	public static object CanNotDeserializeObjectType() { }

	// RVA: 0x6DAC078
	public static object IsDataSetAttributeMissingInSchema() { }

	// RVA: 0x6DAC114
	public static object TooManyIsDataSetAtributeInSchema() { }

	// RVA: 0x6DAC1B0
	public static object NestedCircular(object name) { }

	// RVA: 0x6DAC2CC
	public static object MultipleParentRows(object tableQName) { }

	// RVA: 0x6DAC3E8
	public static object PolymorphismNotSupported(object typeName) { }

	// RVA: 0x6DAC4F8
	public static object DataTableInferenceNotSupported() { }

	// RVA: 0x6DAC588
	internal static object ThrowMultipleTargetConverter(object innerException) { }

	// RVA: 0x6DAC624
	public static object DuplicateDeclaration(object name) { }

	// RVA: 0x6DAC740
	public static object FoundEntity() { }

	// RVA: 0x6DAC7DC
	public static object MergeFailed(object name) { }

	// RVA: 0x6DAC850
	public static object ConvertFailed(object type1, object type2) { }

	// RVA: 0x6DAC9CC
	internal static object InvalidDuplicateNamedSimpleTypeDelaration(object stName, object errorStr) { }

	// RVA: 0x6DACAEC
	internal static object InternalRBTreeError(object internalError) { }

	// RVA: 0x6DACC08
	public static object EnumeratorModified() { }

}

// Namespace: System.Data
internal struct DataKey
{

	// Fields
	private readonly object _columns; // 0xFFFFFFFFFFFFFFF8

	// Properties
	internal object ColumnsReference { get; }
	internal object HasValue { get; }
	internal object Table { get; }

	// Methods

	// RVA: 0x6DACCD4
	internal object .ctor(object columns, object copyColumns) { }

	// RVA: 0x6DACFA0
	internal object get_ColumnsReference() { }

	// RVA: 0x6DACFB0
	internal object get_HasValue() { }

	// RVA: 0x6D916F4
	internal object get_Table() { }

	// RVA: 0x6DACEDC
	internal object CheckState() { }

	// RVA: 0x6DAD020
	internal object ColumnsEqual(object key) { }

	// RVA: 0x6DAD028
	internal static object ColumnsEqual(object column1, object column2) { }

	// RVA: 0x6D9BC04
	internal object ContainsColumn(object column) { }

	// RVA: 0x6DAD1DC
	public override object GetHashCode() { }

	// RVA: 0x6DAD2BC
	public override object Equals(object value) { }

	// RVA: 0x6DAD42C
	internal object Equals(object value) { }

	// RVA: 0x6DAD64C
	internal object GetColumnNames() { }

	// RVA: 0x6DAD740
	internal object GetIndexDesc() { }

	// RVA: 0x6DAD860
	internal object GetKeyValues(object record) { }

	// RVA: 0x6DAD9F8
	internal object GetSortIndex() { }

	// RVA: 0x6DADA00
	internal object GetSortIndex(object recordStates) { }

	// RVA: 0x6DADA90
	internal object RecordsEqual(object record1, object record2) { }

	// RVA: 0x6DADC20
	internal object ToArray() { }

}

// Namespace: System.Data
public class DataRelation
{

	// Fields
	private object _dataSet; // 0x8
	internal object _extendedProperties; // 0x10
	internal object _relationName; // 0x18
	private object _childKey; // 0x20
	private object _parentKey; // 0x28
	private object _parentKeyConstraint; // 0x30
	private object _childKeyConstraint; // 0x38
	internal object _parentColumnNames; // 0x40
	internal object _childColumnNames; // 0x48
	internal object _parentTableName; // 0x50
	internal object _childTableName; // 0x58
	internal object _parentTableNamespace; // 0x60
	internal object _childTableNamespace; // 0x68
	internal object _nested; // 0x70
	internal object _createConstraints; // 0x71
	private object _checkMultipleNested; // 0x72
	private static object s_objectTypeCount; // 0x0
	private readonly object _objectID; // 0x74
	private object PropertyChanging; // 0x78

	// Properties
	public virtual object ChildColumns { get; }
	internal object ChildColumnsReference { get; }
	internal object ChildKey { get; }
	public virtual object ChildTable { get; }
	public virtual object DataSet { get; }
	internal object ParentColumnNames { get; }
	internal object ChildColumnNames { get; }
	public virtual object ParentColumns { get; }
	internal object ParentColumnsReference { get; }
	internal object ParentKey { get; }
	public virtual object ParentTable { get; }
	public virtual object RelationName { get; }
	public virtual object Nested { get; set; }
	public virtual object ParentKeyConstraint { get; }
	public virtual object ChildKeyConstraint { get; }
	public object ExtendedProperties { get; }
	internal object CheckMultipleNested { get; set; }
	internal object ObjectID { get; }

	// Methods

	// RVA: 0x6DADD30
	public object .ctor(object relationName, object parentColumn, object childColumn, object createConstraints) { }

	// RVA: 0x6DAE29C
	public object .ctor(object relationName, object parentColumns, object childColumns) { }

	// RVA: 0x6DAE364
	public object .ctor(object relationName, object parentColumns, object childColumns, object createConstraints) { }

	// RVA: 0x6DAE430
	public object .ctor(object relationName, object parentTableName, object childTableName, object parentColumnNames, object childColumnNames, object nested) { }

	// RVA: 0x6DAE508
	public object .ctor(object relationName, object parentTableName, object parentTableNamespace, object childTableName, object childTableNamespace, object parentColumnNames, object childColumnNames, object nested) { }

	// RVA: 0x6DAE5FC
	public virtual object get_ChildColumns() { }

	// RVA: 0x6DAE724
	internal object get_ChildColumnsReference() { }

	// RVA: 0x6D9BBE0
	internal object get_ChildKey() { }

	// RVA: 0x6DAE748
	public virtual object get_ChildTable() { }

	// RVA: 0x6DAE7A0
	public virtual object get_DataSet() { }

	// RVA: 0x6DAE7C4
	internal object get_ParentColumnNames() { }

	// RVA: 0x6DAE7CC
	internal object get_ChildColumnNames() { }

	// RVA: 0x6DAE7D4
	private static object IsKeyNull(object values) { }

	// RVA: 0x6DAE898
	internal static object GetChildRows(object parentKey, object childKey, object parentRow, object version) { }

	// RVA: 0x6DAEA04
	internal static object GetParentRows(object parentKey, object childKey, object childRow, object version) { }

	// RVA: 0x6DAEB6C
	internal static object GetParentRow(object parentKey, object childKey, object childRow, object version) { }

	// RVA: 0x6DAEDA8
	internal object SetDataSet(object dataSet) { }

	// RVA: 0x6DAEDBC
	public virtual object get_ParentColumns() { }

	// RVA: 0x6DAEDE0
	internal object get_ParentColumnsReference() { }

	// RVA: 0x6D9BC84
	internal object get_ParentKey() { }

	// RVA: 0x6DAEDE8
	public virtual object get_ParentTable() { }

	// RVA: 0x6DAEE40
	public virtual object get_RelationName() { }

	// RVA: 0x6DAEE64
	internal object CheckNamespaceValidityForNestedRelations(object ns) { }

	// RVA: 0x6DAF2C4
	internal object CheckNestedRelations() { }

	// RVA: 0x6DAF908
	public virtual object get_Nested() { }

	// RVA: 0x6DAF92C
	public virtual object set_Nested(object value) { }

	// RVA: 0x6DB1620
	public virtual object get_ParentKeyConstraint() { }

	// RVA: 0x6DB1644
	internal object SetParentKeyConstraint(object value) { }

	// RVA: 0x6DB164C
	public virtual object get_ChildKeyConstraint() { }

	// RVA: 0x6DB1670
	public object get_ExtendedProperties() { }

	// RVA: 0x6DB16EC
	internal object get_CheckMultipleNested() { }

	// RVA: 0x6DB16F4
	internal object set_CheckMultipleNested(object value) { }

	// RVA: 0x6DB16FC
	internal object SetChildKeyConstraint(object value) { }

	// RVA: 0x6DB1704
	internal object CheckState() { }

	// RVA: 0x6DAE620
	protected object CheckStateForProperty() { }

	// RVA: 0x6DADF5C
	private object Create(object relationName, object parentColumns, object childColumns, object createConstraints) { }

	// RVA: 0x6DB1A7C
	internal object Clone(object destination) { }

	// RVA: 0x6DB241C
	protected internal object OnPropertyChanging(object pcevent) { }

	// RVA: 0x6DB15B0
	protected internal object RaisePropertyChanging(object name) { }

	// RVA: 0x6DB2510
	public override object ToString() { }

	// RVA: 0x6DB0FD8
	internal object ValidateMultipleNestedRelations() { }

	// RVA: 0x6DB2550
	private object IsAutoGenerated(object col) { }

	// RVA: 0x6DB277C
	internal object get_ObjectID() { }

}

// Namespace: 
internal sealed class DataTableRelationCollection
{

	// Fields
	private readonly object _table; // 0x30
	private readonly object _relations; // 0x38
	private readonly object _fParentCollection; // 0x40
	private object RelationPropertyChanged; // 0x48

	// Properties
	protected override object List { get; }
	public override object Item { get; }
	public override object Item { get; }

	// Methods

	// RVA: 0x6DD3BCC
	internal object .ctor(object table, object fParentCollection) { }

	// RVA: 0x6DD3CE4
	protected override object get_List() { }

	// RVA: 0x6DD3CEC
	private object EnsureDataSet() { }

	// RVA: 0x6DD3D44
	protected override object GetDataSet() { }

	// RVA: 0x6DD3D98
	public override object get_Item(object index) { }

	// RVA: 0x6DD3EE8
	public override object get_Item(object name) { }

	// RVA: 0x6DD402C
	internal object add_RelationPropertyChanged(object value) { }

	// RVA: 0x6DD40D0
	internal object remove_RelationPropertyChanged(object value) { }

	// RVA: 0x6DD4174
	private object AddCache(object relation) { }

	// RVA: 0x6DD420C
	protected override object AddCore(object relation) { }

	// RVA: 0x6DD43B4
	private object RemoveCache(object relation) { }

	// RVA: 0x6DD450C
	protected override object RemoveCore(object relation) { }

}

// Namespace: 
internal sealed class DataSetRelationCollection
{

	// Fields
	private readonly object _dataSet; // 0x30
	private readonly object _relations; // 0x38
	private object _delayLoadingRelations; // 0x40

	// Properties
	protected override object List { get; }
	public override object Item { get; }
	public override object Item { get; }

	// Methods

	// RVA: 0x6DD4644
	internal object .ctor(object dataSet) { }

	// RVA: 0x6DD4754
	protected override object get_List() { }

	// RVA: 0x6DD475C
	public override object Clear() { }

	// RVA: 0x6DD47A8
	protected override object GetDataSet() { }

	// RVA: 0x6DD47B0
	public override object get_Item(object index) { }

	// RVA: 0x6DD4900
	public override object get_Item(object name) { }

	// RVA: 0x6DD4A44
	protected override object AddCore(object relation) { }

	// RVA: 0x6DD5274
	protected override object RemoveCore(object relation) { }

}

// Namespace: System.Data
public abstract class DataRelationCollection
{

	// Fields
	private object _inTransition; // 0x8
	private object _defaultNameIndex; // 0x10
	private object _onCollectionChangedDelegate; // 0x18
	private object _onCollectionChangingDelegate; // 0x20
	private static object s_objectTypeCount; // 0x0
	private readonly object _objectID; // 0x28

	// Properties
	internal object ObjectID { get; }
	public abstract object Item { get; }
	public abstract object Item { get; }

	// Methods

	// RVA: 0x6DD20C0
	internal object get_ObjectID() { }

	// RVA: -1
	public abstract object get_Item(object index) { }

	// RVA: -1
	public abstract object get_Item(object name) { }

	// RVA: 0x6DD20C8
	public object Add(object relation) { }

	// RVA: 0x6DD2388
	protected virtual object AddCore(object relation) { }

	// RVA: 0x6DD2764
	public object add_CollectionChanged(object value) { }

	// RVA: 0x6DD2890
	public object remove_CollectionChanged(object value) { }

	// RVA: 0x6DD29BC
	internal object AssignName() { }

	// RVA: 0x6DD2AB8
	public virtual object Clear() { }

	// RVA: 0x6DD2DB4
	public virtual object Contains(object name) { }

	// RVA: 0x6DD2DD0
	internal object InternalIndexOf(object name) { }

	// RVA: -1
	protected abstract object GetDataSet() { }

	// RVA: 0x6DD29EC
	private object MakeName(object index) { }

	// RVA: 0x6DD301C
	protected virtual object OnCollectionChanged(object ccevent) { }

	// RVA: 0x6DD3110
	protected virtual object OnCollectionChanging(object ccevent) { }

	// RVA: 0x6DD3204
	internal object RegisterName(object name) { }

	// RVA: 0x6DD3464
	public object Remove(object relation) { }

	// RVA: 0x6DD3674
	public object RemoveAt(object index) { }

	// RVA: 0x6DD3710
	protected virtual object RemoveCore(object relation) { }

	// RVA: 0x6DD3994
	internal object UnregisterName(object name) { }

	// RVA: 0x6DD3B20
	protected object .ctor() { }

}

// Namespace: System.Data
internal sealed class DataRelationPropertyDescriptor
{

	// Fields
	private readonly object <Relation>k__BackingField; // 0x80

	// Properties
	internal object Relation { get; }
	public override object ComponentType { get; }
	public override object IsReadOnly { get; }
	public override object PropertyType { get; }

	// Methods

	// RVA: 0x6DD568C
	internal object .ctor(object dataRelation) { }

	// RVA: 0x6DD56F8
	internal object get_Relation() { }

	// RVA: 0x6DD5700
	public override object get_ComponentType() { }

	// RVA: 0x6DD57A0
	public override object get_IsReadOnly() { }

	// RVA: 0x6DD57A8
	public override object get_PropertyType() { }

	// RVA: 0x6DD5848
	public override object Equals(object other) { }

	// RVA: 0x6DD58D0
	public override object GetHashCode() { }

	// RVA: 0x6DD591C
	public override object GetValue(object component) { }

	// RVA: 0x6DD59C4
	public override object SetValue(object component, object value) { }

	// RVA: 0x6DD59C8
	public override object ShouldSerializeValue(object component) { }

}

// Namespace: System.Data
public class DataRow
{

	// Fields
	private readonly object _table; // 0x8
	private readonly object _columns; // 0x10
	internal object _oldRecord; // 0x18
	internal object _newRecord; // 0x1C
	internal object _tempRecord; // 0x20
	internal object _rowID; // 0x28
	internal object _action; // 0x30
	internal object _inChangingEvent; // 0x34
	internal object _inDeletingEvent; // 0x35
	internal object _inCascade; // 0x36
	private object _lastChangedColumn; // 0x38
	private object _countColumnChange; // 0x40
	private object _error; // 0x48
	private object _rbTreeNodeId; // 0x50
	private static object s_objectTypeCount; // 0x0
	internal readonly object _objectID; // 0x54

	// Properties
	internal object LastChangedColumn { get; set; }
	internal object HasPropertyChanged { get; }
	internal object RBTreeNodeId { get; set; }
	public object RowError { get; set; }
	internal object rowID { get; set; }
	public object RowState { get; }
	public object Table { get; }
	public object Item { set; }
	public object Item { get; set; }
	public object Item { get; }
	public object ItemArray { set; }
	public object HasErrors { get; }

	// Methods

	// RVA: 0x6DD59D0
	protected internal object .ctor(object builder) { }

	// RVA: 0x6DD5A88
	internal object get_LastChangedColumn() { }

	// RVA: 0x6DD5AA4
	internal object set_LastChangedColumn(object value) { }

	// RVA: 0x6DD5AB8
	internal object get_HasPropertyChanged() { }

	// RVA: 0x6DD5AC8
	internal object get_RBTreeNodeId() { }

	// RVA: 0x6DD5AD0
	internal object set_RBTreeNodeId(object value) { }

	// RVA: 0x6DD5BA4
	public object get_RowError() { }

	// RVA: 0x6DD5C0C
	public object set_RowError(object value) { }

	// RVA: 0x6DD5DB8
	private object RowErrorChanged() { }

	// RVA: 0x6DD5E2C
	internal object get_rowID() { }

	// RVA: 0x6DD5E34
	internal object set_rowID(object value) { }

	// RVA: 0x6DD5E50
	public object get_RowState() { }

	// RVA: 0x6DD6118
	public object get_Table() { }

	// RVA: 0x6DD6120
	internal object CheckForLoops(object rel) { }

	// RVA: 0x6DD6230
	internal object GetNestedParentCount() { }

	// RVA: 0x6DD6318
	public object set_Item(object columnName, object value) { }

	// RVA: 0x6DD6088
	public object get_Item(object column) { }

	// RVA: 0x6DD6430
	public object set_Item(object column, object value) { }

	// RVA: 0x6DD6BA8
	public object get_Item(object column, object version) { }

	// RVA: 0x6DD6D4C
	public object set_ItemArray(object value) { }

	// RVA: 0x6DD7200
	public object AcceptChanges() { }

	// RVA: 0x6DD75F0
	public object BeginEdit() { }

	// RVA: 0x6DD6904
	private object BeginEditInternal() { }

	// RVA: 0x6DD6A40
	public object CancelEdit() { }

	// RVA: 0x6DD67F8
	private object CheckColumn(object column) { }

	// RVA: 0x6DD75F4
	internal object CheckInTable() { }

	// RVA: 0x6DD7634
	public object Delete() { }

	// RVA: 0x6DD6AB4
	public object EndEdit() { }

	// RVA: 0x6DD76B0
	public object SetColumnError(object columnIndex, object error) { }

	// RVA: 0x6DD772C
	public object SetColumnError(object column, object error) { }

	// RVA: 0x6DD7A18
	public object GetColumnError(object column) { }

	// RVA: 0x6DD7B20
	public object ClearErrors() { }

	// RVA: 0x6DD7BA4
	internal object ClearError(object column) { }

	// RVA: 0x6DD7C28
	public object get_HasErrors() { }

	// RVA: 0x6DD7C3C
	public object GetColumnsInError() { }

	// RVA: 0x6DD7D50
	public object GetChildRows(object relation) { }

	// RVA: 0x6DD7D58
	public object GetChildRows(object relation, object version) { }

	// RVA: 0x6DD63B0
	internal object GetDataColumn(object columnName) { }

	// RVA: 0x6DD6228
	public object GetParentRow(object relation) { }

	// RVA: 0x6DD7EDC
	public object GetParentRow(object relation, object version) { }

	// RVA: 0x6DD8048
	internal object GetNestedParentRow(object version) { }

	// RVA: 0x6DD8128
	public object GetParentRows(object relation) { }

	// RVA: 0x6DD8130
	public object GetParentRows(object relation, object version) { }

	// RVA: 0x6DD82B4
	internal object GetColumnValues(object columns) { }

	// RVA: 0x6DD8354
	internal object GetColumnValues(object columns, object version) { }

	// RVA: 0x6DD83E8
	internal object GetKeyValues(object key) { }

	// RVA: 0x6DD83B4
	internal object GetKeyValues(object key, object version) { }

	// RVA: 0x6DD846C
	internal object GetCurrentRecordNo() { }

	// RVA: 0x6DD689C
	internal object GetDefaultRecord() { }

	// RVA: 0x6DD84AC
	internal object GetOriginalRecordNo() { }

	// RVA: 0x6DD6A00
	private object GetProposedRecordNo() { }

	// RVA: 0x6DD6C00
	internal object GetRecordFromVersion(object version) { }

	// RVA: 0x6DD84EC
	internal object GetDefaultRowVersion(object viewState) { }

	// RVA: 0x6DD8518
	internal object GetRecordState(object record) { }

	// RVA: 0x6DD856C
	internal object HasKeyChanged(object key) { }

	// RVA: 0x6DD85C0
	internal object HasKeyChanged(object key, object version1, object version2) { }

	// RVA: 0x6DD8724
	public object HasVersion(object version) { }

	// RVA: 0x6DD87C0
	internal object HaveValuesChanged(object columns) { }

	// RVA: 0x6DD8890
	internal object HaveValuesChanged(object columns, object version1, object version2) { }

	// RVA: 0x6DD893C
	public object RejectChanges() { }

	// RVA: 0x6DD5E44
	internal object ResetLastChangedColumn() { }

	// RVA: 0x6DD9048
	internal object SetKeyValues(object key, object keyValues) { }

	// RVA: 0x6DD91C0
	internal object SetNestedParentRow(object parentRow, object setNonNested) { }

	// RVA: 0x6DD96B4
	internal object SetParentRowToDBNull() { }

	// RVA: 0x6DD9A18
	internal object SetParentRowToDBNull(object relation) { }

	// RVA: 0x6DD9BC8
	internal object CopyValuesIntoStore(object storeList, object nullbitList, object storeIndex) { }

}

// Namespace: System.Data
public sealed class DataRowBuilder
{

	// Fields
	internal readonly object _table; // 0x8
	internal object _record; // 0x10

	// Methods

	// RVA: 0x6DDA264
	internal object .ctor(object table, object record) { }

}

// Namespace: System.Data
public enum DataRowAction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Nothing;
	public const object Delete;
	public const object Change;
	public const object Rollback;
	public const object Commit;
	public const object Add;
	public const object ChangeOriginal;
	public const object ChangeCurrentAndOriginal;
}

// Namespace: System.Data
public class DataRowChangeEventArgs
{

	// Fields
	private readonly object <Row>k__BackingField; // 0x8
	private readonly object <Action>k__BackingField; // 0x10

	// Methods

	// RVA: 0x6DDA2A0
	public object .ctor(object row, object action) { }

}

// Namespace: System.Data
public sealed class DataRowChangeEventHandler
{

	// Methods

	// RVA: 0x6DDA624
	public object .ctor(object object, object method) { }

	// RVA: 0x6DDA730
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: 
private sealed class DataRowTree
{

	// Methods

	// RVA: 0x6DDA818
	internal object .ctor() { }

	// RVA: 0x6DDB0C8
	protected override object CompareNode(object record1, object record2) { }

	// RVA: 0x6DDB0FC
	protected override object CompareSateliteTreeNode(object record1, object record2) { }

}

// Namespace: System.Data
public sealed class DataRowCollection
{

	// Fields
	private readonly object _table; // 0x8
	private readonly object _list; // 0x10
	internal object _nullInList; // 0x18

	// Properties
	public override object Count { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x6DDA744
	internal object .ctor(object table) { }

	// RVA: 0x6DDA874
	public override object get_Count() { }

	// RVA: 0x6DDA8D0
	public object get_Item(object index) { }

	// RVA: 0x6DDA93C
	public object Add(object row) { }

	// RVA: 0x6DDA964
	internal object DiffInsertAt(object row, object pos) { }

	// RVA: 0x6DDAC20
	public object IndexOf(object row) { }

	// RVA: 0x6DDACD0
	internal object AddWithColumnEvents(object values) { }

	// RVA: 0x6DDAD5C
	internal object ArrayAdd(object row) { }

	// RVA: 0x6DDADE4
	internal object ArrayInsert(object row, object pos) { }

	// RVA: 0x6DDAE74
	internal object ArrayClear() { }

	// RVA: 0x6DDAED0
	internal object ArrayRemove(object row) { }

	// RVA: 0x6DDAF84
	public override object CopyTo(object ar, object index) { }

	// RVA: 0x6DDAFF8
	public object CopyTo(object array, object index) { }

	// RVA: 0x6DDB06C
	public override object GetEnumerator() { }

}

// Namespace: System.Data
internal sealed class DataRowCreatedEventHandler
{

	// Methods

	// RVA: 0x6DDB434
	public object .ctor(object object, object method) { }

	// RVA: 0x6DDB540
	public virtual object Invoke(object sender, object r) { }

}

// Namespace: System.Data
internal sealed class DataSetClearEventhandler
{

	// Methods

	// RVA: 0x6DDB858
	public object .ctor(object object, object method) { }

	// RVA: 0x6DDB964
	public virtual object Invoke(object sender, object table) { }

}

// Namespace: System.Data
public enum DataRowState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Detached;
	public const object Unchanged;
	public const object Added;
	public const object Deleted;
	public const object Modified;
}

// Namespace: System.Data
public enum DataRowVersion
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Original;
	public const object Current;
	public const object Proposed;
	public const object Default;
}

// Namespace: System.Data
public class DataRowView
{

	// Fields
	private readonly object _dataView; // 0x8
	private readonly object _row; // 0x10
	private object _delayBeginEdit; // 0x18
	private static readonly object s_zeroPropertyDescriptorCollection; // 0x0
	private object PropertyChanged; // 0x20

	// Properties
	public object DataView { get; }
	private object RowVersionDefault { get; }
	public object Row { get; }
	public object IsNew { get; }

	// Methods

	// RVA: 0x6DDB978
	internal object .ctor(object dataView, object row) { }

	// RVA: 0x6DDB9B0
	public override object Equals(object other) { }

	// RVA: 0x6DDB9BC
	public override object GetHashCode() { }

	// RVA: 0x6DDBA08
	public object get_DataView() { }

	// RVA: 0x6DDBA10
	private object get_RowVersionDefault() { }

	// RVA: 0x6DDBA80
	internal object GetRecord() { }

	// RVA: 0x6DDBAE4
	internal object HasRecord() { }

	// RVA: 0x6DDBB5C
	internal object GetColumnValue(object column) { }

	// RVA: 0x6DDBC04
	internal object SetColumnValue(object column, object value) { }

	// RVA: 0x6DDBCE0
	public object CreateChildView(object relation, object followParent) { }

	// RVA: 0x6DD59BC
	public object CreateChildView(object relation) { }

	// RVA: 0x6DDC190
	public object get_Row() { }

	// RVA: 0x6DDC198
	public object EndEdit() { }

	// RVA: 0x6DDC20C
	public object get_IsNew() { }

	// RVA: 0x6DDC4DC
	internal object RaisePropertyChangedEvent(object propName) { }

	// RVA: 0x6DDC570
	private object System.ComponentModel.ICustomTypeDescriptor.GetAttributes() { }

	// RVA: 0x6DDC5CC
	private object System.ComponentModel.ICustomTypeDescriptor.GetClassName() { }

	// RVA: 0x6DDC5D4
	private object System.ComponentModel.ICustomTypeDescriptor.GetComponentName() { }

	// RVA: 0x6DDC5DC
	private object System.ComponentModel.ICustomTypeDescriptor.GetConverter() { }

	// RVA: 0x6DDC5E4
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultEvent() { }

	// RVA: 0x6DDC5EC
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultProperty() { }

	// RVA: 0x6DDC5F4
	private object System.ComponentModel.ICustomTypeDescriptor.GetEditor(object editorBaseType) { }

	// RVA: 0x6DDC5FC
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents() { }

	// RVA: 0x6DDC658
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents(object attributes) { }

	// RVA: 0x6DDC6B4
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties() { }

	// RVA: 0x6DDC774
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties(object attributes) { }

	// RVA: 0x6DDC82C
	private object System.ComponentModel.ICustomTypeDescriptor.GetPropertyOwner(object pd) { }

	// RVA: 0x6DDC830
	private static object .cctor() { }

}

// Namespace: System.Data
public enum SerializationFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Xml;
	public const object Binary;
}

// Namespace: System.Data
public class DataSet
{

	// Fields
	private object _defaultViewManager; // 0x18
	private readonly object _tableCollection; // 0x20
	private readonly object _relationCollection; // 0x28
	internal object _extendedProperties; // 0x30
	private object _dataSetName; // 0x38
	private object _datasetPrefix; // 0x40
	internal object _namespaceURI; // 0x48
	private object _enforceConstraints; // 0x50
	private object _caseSensitive; // 0x51
	private object _culture; // 0x58
	private object _cultureUserSet; // 0x60
	internal object _fInReadXml; // 0x61
	internal object _fInLoadDiffgram; // 0x62
	internal object _fTopLevelTable; // 0x63
	internal object _fInitInProgress; // 0x64
	internal object _fEnableCascading; // 0x65
	internal object _fIsSchemaLoading; // 0x66
	internal object _mainTableName; // 0x68
	private object _remotingFormat; // 0x70
	private object _defaultViewManagerLock; // 0x78
	private static object s_objectTypeCount; // 0x0
	private readonly object _objectID; // 0x80
	private static object s_schemaTypeForWSDL; // 0x8
	internal object _useDataSetSchemaOnly; // 0x84
	internal object _udtIsWrapped; // 0x85
	private object PropertyChanging; // 0x88
	private object MergeFailed; // 0x90
	private object DataRowCreated; // 0x98
	private object ClearFunctionCalled; // 0xA0

	// Properties
	public object RemotingFormat { get; set; }
	public virtual object SchemaSerializationMode { get; }
	public object CaseSensitive { get; set; }
	public object EnforceConstraints { get; set; }
	public object DataSetName { get; set; }
	public object Namespace { get; set; }
	public object Prefix { get; set; }
	public object ExtendedProperties { get; }
	public object Locale { get; set; }
	public override object Site { get; }
	public object Relations { get; }
	public object Tables { get; }
	internal object MainTableName { get; set; }
	internal object ObjectID { get; }

	// Methods

	// RVA: 0x6DDC8B0
	public object .ctor() { }

	// RVA: 0x6DDCCA0
	public object .ctor(object dataSetName) { }

	// RVA: 0x6DDCEAC
	public object get_RemotingFormat() { }

	// RVA: 0x6DDCEB4
	public object set_RemotingFormat(object value) { }

	// RVA: 0x6DDD100
	public virtual object get_SchemaSerializationMode() { }

	// RVA: 0x6DDD108
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DDD110
	protected object .ctor(object info, object context, object ConstructSchema) { }

	// RVA: 0x6DDD3AC
	public virtual object GetObjectData(object info, object context) { }

	// RVA: 0x6DDDB64
	protected virtual object InitializeDerivedDataSet() { }

	// RVA: 0x6DDD3B4
	private object SerializeDataSet(object info, object context, object remotingFormat) { }

	// RVA: 0x6DDD358
	internal object DeserializeDataSet(object info, object context, object remotingFormat, object schemaSerializationMode) { }

	// RVA: 0x6DDEC60
	private object DeserializeDataSetSchema(object info, object context, object remotingFormat, object schemaSerializationMode) { }

	// RVA: 0x6DDF1E8
	private object DeserializeDataSetData(object info, object context, object remotingFormat) { }

	// RVA: 0x6DDDB68
	private object SerializeDataSetProperties(object info, object context) { }

	// RVA: 0x6DDF400
	private object DeserializeDataSetProperties(object info, object context) { }

	// RVA: 0x6DDDD50
	private object SerializeRelations(object info, object context) { }

	// RVA: 0x6DDF9C4
	private object DeserializeRelations(object info, object context) { }

	// RVA: 0x6DE1200
	internal object FailedEnableConstraints() { }

	// RVA: 0x6DE13C4
	public object get_CaseSensitive() { }

	// RVA: 0x6DE13CC
	public object set_CaseSensitive(object value) { }

	// RVA: 0x6DE1C74
	public object get_EnforceConstraints() { }

	// RVA: 0x6DE1238
	public object set_EnforceConstraints(object value) { }

	// RVA: 0x6DE251C
	internal object RestoreEnforceConstraints(object value) { }

	// RVA: 0x6DE1C7C
	internal object EnableConstraints() { }

	// RVA: 0x6DE2524
	public object get_DataSetName() { }

	// RVA: 0x6DDCCCC
	public object set_DataSetName(object value) { }

	// RVA: 0x6DE26FC
	public object get_Namespace() { }

	// RVA: 0x6DE2704
	public object set_Namespace(object value) { }

	// RVA: 0x6DE2EFC
	public object get_Prefix() { }

	// RVA: 0x6DE2F04
	public object set_Prefix(object value) { }

	// RVA: 0x6DE1050
	public object get_ExtendedProperties() { }

	// RVA: 0x6DE30B8
	public object get_Locale() { }

	// RVA: 0x6DE30C0
	public object set_Locale(object value) { }

	// RVA: 0x6DE3290
	internal object SetLocaleValue(object value, object userSet) { }

	// RVA: 0x6DE46F0
	internal object ShouldSerializeLocale() { }

	// RVA: 0x6DE46F8
	public override object get_Site() { }

	// RVA: 0x6DE4700
	public object get_Relations() { }

	// RVA: 0x6DE4708
	public object get_Tables() { }

	// RVA: 0x6DE4710
	public object Clear() { }

	// RVA: 0x6DE4980
	public virtual object Clone() { }

	// RVA: 0x6DDE834
	internal object EstimatedXmlStringSize() { }

	// RVA: 0x6DE5D40
	internal object GetRemotingDiffGram(object table) { }

	// RVA: 0x6DDE624
	internal object GetXmlSchemaForRemoting(object table) { }

	// RVA: 0x6DE5EAC
	public object ReadXmlSchema(object reader) { }

	// RVA: 0x6DE03E0
	internal object ReadXmlSchema(object reader, object denyResolving) { }

	// RVA: 0x6DE63DC
	internal object MoveToElement(object reader, object depth) { }

	// RVA: 0x6DE6A9C
	private static object MoveToElement(object reader) { }

	// RVA: 0x6DE6518
	internal object ReadEndElement(object reader) { }

	// RVA: 0x6DE6078
	internal object ReadXSDSchema(object reader, object denyResolving) { }

	// RVA: 0x6DE5EB4
	internal object ReadXDRSchema(object reader) { }

	// RVA: 0x6DE6B7C
	private object WriteXmlSchema(object writer, object schemaFormat, object multipleTargetConverter) { }

	// RVA: 0x6DE6DF0
	public object ReadXml(object reader) { }

	// RVA: 0x6DE6DF8
	internal object ReadXml(object reader, object denyResolving) { }

	// RVA: 0x6DE6654
	internal object InferSchema(object xdoc, object excludedNamespaces, object mode) { }

	// RVA: 0x6DE9DF8
	private object IsEmpty() { }

	// RVA: 0x6DE85C0
	private object ReadXmlDiffgram(object reader) { }

	// RVA: 0x6DE1048
	public object ReadXml(object reader, object mode) { }

	// RVA: 0x6DEA318
	internal object ReadXml(object reader, object mode, object denyResolving) { }

	// RVA: 0x6DDEA24
	public object WriteXml(object writer, object mode) { }

	// RVA: 0x6DEA18C
	public object Merge(object dataSet) { }

	// RVA: 0x6DEB608
	public object Merge(object dataSet, object preserveChanges, object missingSchemaAction) { }

	// RVA: 0x6DEB888
	protected virtual object OnPropertyChanging(object pcevent) { }

	// RVA: 0x6DEB8AC
	internal object OnMergeFailed(object mfevent) { }

	// RVA: 0x6DEB914
	internal object RaiseMergeFailed(object table, object conflict, object missingSchemaAction) { }

	// RVA: 0x6DEBA14
	internal object OnDataRowCreated(object row) { }

	// RVA: 0x6DE495C
	internal object OnClearFunctionCalled(object table) { }

	// RVA: 0x6DEBA38
	protected internal virtual object OnRemoveTable(object table) { }

	// RVA: 0x6DEBA3C
	internal object OnRemovedTable(object table) { }

	// RVA: 0x6DEBA6C
	protected virtual object OnRemoveRelation(object relation) { }

	// RVA: 0x6DD5640
	internal object OnRemoveRelationHack(object relation) { }

	// RVA: 0x6DE266C
	protected internal object RaisePropertyChanging(object name) { }

	// RVA: 0x6DEBA70
	internal object TopLevelTables() { }

	// RVA: 0x6DEBA78
	internal object TopLevelTables(object forSchema) { }

	// RVA: 0x6DEBFA4
	public virtual object Reset() { }

	// RVA: 0x6DE174C
	internal object ValidateCaseConstraint() { }

	// RVA: 0x6DE3AEC
	internal object ValidateLocaleConstraint() { }

	// RVA: 0x6DEC6C0
	protected virtual object ReadXmlSerializable(object reader) { }

	// RVA: 0x6DECA68
	public static object GetDataSetSchema(object schemaSet) { }

	// RVA: 0x6DECD34
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6DECF30
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6DED210
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6DED248
	internal object get_MainTableName() { }

	// RVA: 0x6DED250
	internal object set_MainTableName(object value) { }

	// RVA: 0x6DED258
	internal object get_ObjectID() { }

}

// Namespace: System.Data
public enum DataSetDateTime
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Local;
	public const object Unspecified;
	public const object UnspecifiedLocal;
	public const object Utc;
}

// Namespace: 
internal struct RowDiffIdUsageSection
{

	// Fields
	private object _targetTable; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x6DED29C
	internal object Prepare(object table) { }

}

// Namespace: 
internal struct DSRowDiffIdUsageSection
{

	// Fields
	private object _targetDS; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x6DE8508
	internal object Prepare(object ds) { }

}

// Namespace: System.Data
public class DataTable
{

	// Fields
	private object _dataSet; // 0x18
	private object _defaultView; // 0x20
	internal object _nextRowID; // 0x28
	internal readonly object _rowCollection; // 0x30
	internal readonly object _columnCollection; // 0x38
	private readonly object _constraintCollection; // 0x40
	private object _elementColumnCount; // 0x48
	internal object _parentRelationsCollection; // 0x50
	internal object _childRelationsCollection; // 0x58
	internal readonly object _recordManager; // 0x60
	internal readonly object _indexes; // 0x68
	private object _shadowIndexes; // 0x70
	private object _shadowCount; // 0x78
	internal object _extendedProperties; // 0x80
	private object _tableName; // 0x88
	internal object _tableNamespace; // 0x90
	private object _tablePrefix; // 0x98
	internal object _displayExpression; // 0xA0
	internal object _fNestedInDataset; // 0xA8
	private object _culture; // 0xB0
	private object _cultureUserSet; // 0xB8
	private object _compareInfo; // 0xC0
	private object _compareFlags; // 0xC8
	private object _formatProvider; // 0xD0
	private object _hashCodeProvider; // 0xD8
	private object _caseSensitive; // 0xE0
	private object _caseSensitiveUserSet; // 0xE1
	internal object _encodedTableName; // 0xE8
	internal object _xmlText; // 0xF0
	internal object _colUnique; // 0xF8
	internal object _minOccurs; // 0x100
	internal object _maxOccurs; // 0x110
	internal object _repeatableElement; // 0x120
	private object _typeName; // 0x128
	internal object _primaryKey; // 0x130
	internal object _primaryIndex; // 0x138
	private object _delayedSetPrimaryKey; // 0x140
	private object _loadIndex; // 0x148
	private object _loadIndexwithOriginalAdded; // 0x150
	private object _loadIndexwithCurrentDeleted; // 0x158
	private object _suspendIndexEvents; // 0x160
	private object _inDataLoad; // 0x164
	private object _schemaLoading; // 0x165
	private object _enforceConstraints; // 0x166
	internal object _suspendEnforceConstraints; // 0x167
	protected internal object fInitInProgress; // 0x168
	private object _inLoad; // 0x169
	internal object _fInLoadDiffgram; // 0x16A
	private object _isTypedDataTable; // 0x16B
	private object _emptyDataRowArray; // 0x170
	private object _propertyDescriptorCollectionCache; // 0x178
	private object _nestedParentRelations; // 0x180
	internal object _dependentColumns; // 0x188
	private object _mergingData; // 0x190
	private object _onRowChangedDelegate; // 0x198
	private object _onRowChangingDelegate; // 0x1A0
	private object _onRowDeletingDelegate; // 0x1A8
	private object _onRowDeletedDelegate; // 0x1B0
	private object _onColumnChangedDelegate; // 0x1B8
	private object _onColumnChangingDelegate; // 0x1C0
	private object _onTableClearingDelegate; // 0x1C8
	private object _onTableClearedDelegate; // 0x1D0
	private object _onTableNewRowDelegate; // 0x1D8
	private object _onPropertyChangingDelegate; // 0x1E0
	private readonly object _rowBuilder; // 0x1E8
	internal readonly object _delayedViews; // 0x1F0
	private readonly object _dataViewListeners; // 0x1F8
	internal object _rowDiffId; // 0x200
	internal readonly object _indexesLock; // 0x208
	internal object _ukColumnPositionForInference; // 0x210
	private object _remotingFormat; // 0x214
	private static object s_objectTypeCount; // 0x0
	private readonly object _objectID; // 0x218

	// Properties
	public object CaseSensitive { get; set; }
	internal object AreIndexEventsSuspended { get; }
	private object IsTypedDataTable { get; }
	internal object SelfNested { get; }
	internal object LiveIndexes { get; }
	public object RemotingFormat { get; set; }
	internal object UKColumnPositionForInference { get; set; }
	public object ChildRelations { get; }
	public object Columns { get; }
	private object CompareInfo { get; }
	public object Constraints { get; }
	public object DataSet { get; }
	internal object DisplayExpressionInternal { get; }
	internal object EnforceConstraints { get; set; }
	internal object SuspendEnforceConstraints { get; set; }
	public object ExtendedProperties { get; }
	internal object FormatProvider { get; }
	public object Locale { get; set; }
	public object MinimumCapacity { get; set; }
	internal object RecordCapacity { get; }
	internal object ElementColumnCount { get; set; }
	public object ParentRelations { get; }
	internal object MergingData { get; set; }
	internal object NestedParentRelations { get; }
	internal object SchemaLoading { get; }
	internal object NestedParentsCount { get; }
	public object PrimaryKey { get; set; }
	public object Rows { get; }
	public object TableName { get; set; }
	internal object EncodedTableName { get; }
	public object Namespace { get; set; }
	public object Prefix { get; set; }
	internal object XmlText { get; set; }
	internal object MaxOccurs { get; set; }
	internal object MinOccurs { get; set; }
	public override object Site { get; }
	internal object NeedColumnChangeEvents { get; }
	internal object TypeName { get; set; }
	internal object RowDiffId { get; }
	internal object ObjectID { get; }

	// Methods

	// RVA: 0x6DB2784
	public object .ctor() { }

	// RVA: 0x6DB2D14
	public object .ctor(object tableName) { }

	// RVA: 0x6DB2D8C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6DB3354
	public virtual object GetObjectData(object info, object context) { }

	// RVA: 0x6DB3450
	private object SerializeDataTable(object info, object context, object isSingleTable, object remotingFormat) { }

	// RVA: 0x6DB2F64
	internal object DeserializeDataTable(object info, object context, object isSingleTable, object remotingFormat) { }

	// RVA: 0x6DB383C
	internal object SerializeTableSchema(object info, object context, object isSingleTable) { }

	// RVA: 0x6DB5148
	internal object DeserializeTableSchema(object info, object context, object isSingleTable) { }

	// RVA: 0x6DB8894
	internal object SerializeConstraints(object info, object context, object serIndex, object allConstraints) { }

	// RVA: 0x6DB9DEC
	internal object DeserializeConstraints(object info, object context, object serIndex, object allConstraints) { }

	// RVA: 0x6DBADBC
	internal object SerializeExpressionColumns(object info, object context, object serIndex) { }

	// RVA: 0x6DBAFDC
	internal object DeserializeExpressionColumns(object info, object context, object serIndex) { }

	// RVA: 0x6DB48F0
	internal object SerializeTableData(object info, object context, object serIndex) { }

	// RVA: 0x6DB60A8
	internal object DeserializeTableData(object info, object context, object serIndex) { }

	// RVA: 0x6DBB5B0
	private object ConvertToRowState(object bitStates, object bitIndex) { }

	// RVA: 0x6DBB1FC
	internal object GetRowAndColumnErrors(object rowIndex, object rowErrors, object colErrors) { }

	// RVA: 0x6DBB698
	private object ConvertToRowError(object rowIndex, object rowErrors, object colErrors) { }

	// RVA: 0x6DBBA74
	public object get_CaseSensitive() { }

	// RVA: 0x6DBBA7C
	public object set_CaseSensitive(object value) { }

	// RVA: 0x6DBBB1C
	internal object get_AreIndexEventsSuspended() { }

	// RVA: 0x6DBBB2C
	internal object RestoreIndexEvents(object forceReset) { }

	// RVA: 0x6DBBFA0
	internal object SuspendIndexEvents() { }

	// RVA: 0x6DBC078
	private object get_IsTypedDataTable() { }

	// RVA: 0x6DB9368
	internal object SetCaseSensitiveValue(object isCaseSensitive, object userSet, object resetIndexes) { }

	// RVA: 0x6DBC148
	internal object ShouldSerializeCaseSensitive() { }

	// RVA: 0x6DBC150
	internal object get_SelfNested() { }

	// RVA: 0x6DBC5E8
	internal object get_LiveIndexes() { }

	// RVA: 0x6DBC6C8
	public object get_RemotingFormat() { }

	// RVA: 0x6DBC6D0
	public object set_RemotingFormat(object value) { }

	// RVA: 0x6DBC73C
	internal object get_UKColumnPositionForInference() { }

	// RVA: 0x6DBC744
	internal object set_UKColumnPositionForInference(object value) { }

	// RVA: 0x6DBC74C
	public object get_ChildRelations() { }

	// RVA: 0x6DBC7D0
	public object get_Columns() { }

	// RVA: 0x6DBC7D8
	private object get_CompareInfo() { }

	// RVA: 0x6DBC848
	public object get_Constraints() { }

	// RVA: 0x6DBC850
	private object ResetConstraints() { }

	// RVA: 0x6DBC874
	public object get_DataSet() { }

	// RVA: 0x6DBC87C
	internal object SetDataSet(object dataSet) { }

	// RVA: 0x6DBC950
	internal object get_DisplayExpressionInternal() { }

	// RVA: 0x6DBC9B8
	internal object get_EnforceConstraints() { }

	// RVA: 0x6DBC9E8
	internal object set_EnforceConstraints(object value) { }

	// RVA: 0x6DBD0F8
	internal object get_SuspendEnforceConstraints() { }

	// RVA: 0x6DBD100
	internal object set_SuspendEnforceConstraints(object value) { }

	// RVA: 0x6DBCA34
	internal object EnableConstraints() { }

	// RVA: 0x6DB8288
	public object get_ExtendedProperties() { }

	// RVA: 0x6DBD108
	internal object get_FormatProvider() { }

	// RVA: 0x6DBD1C8
	public object get_Locale() { }

	// RVA: 0x6DBD1D0
	public object set_Locale(object value) { }

	// RVA: 0x6DB9700
	internal object SetLocaleValue(object culture, object userSet, object resetIndexes) { }

	// RVA: 0x6DBD92C
	internal object ShouldSerializeLocale() { }

	// RVA: 0x6DBD934
	public object get_MinimumCapacity() { }

	// RVA: 0x6DB9DB8
	public object set_MinimumCapacity(object value) { }

	// RVA: 0x6DBD958
	internal object get_RecordCapacity() { }

	// RVA: 0x6DBD97C
	internal object get_ElementColumnCount() { }

	// RVA: 0x6DBD984
	internal object set_ElementColumnCount(object value) { }

	// RVA: 0x6DBC564
	public object get_ParentRelations() { }

	// RVA: 0x6DBD9CC
	internal object get_MergingData() { }

	// RVA: 0x6DBD9D4
	internal object set_MergingData(object value) { }

	// RVA: 0x6DBD9DC
	internal object get_NestedParentRelations() { }

	// RVA: 0x6DBD9E4
	internal object get_SchemaLoading() { }

	// RVA: 0x6DBD9EC
	internal object CacheNestedParent() { }

	// RVA: 0x6DBDA10
	private object FindNestedParentRelations() { }

	// RVA: 0x6DBE000
	internal object get_NestedParentsCount() { }

	// RVA: 0x6DBE3CC
	public object get_PrimaryKey() { }

	// RVA: 0x6DBE4EC
	public object set_PrimaryKey(object value) { }

	// RVA: 0x6DBEA1C
	public object get_Rows() { }

	// RVA: 0x6DBEA24
	public object get_TableName() { }

	// RVA: 0x6DBEA2C
	public object set_TableName(object value) { }

	// RVA: 0x6DBF2AC
	internal object get_EncodedTableName() { }

	// RVA: 0x6DBF330
	private object GetInheritedNamespace(object visitedTables) { }

	// RVA: 0x6DB50C0
	public object get_Namespace() { }

	// RVA: 0x6DB7E84
	public object set_Namespace(object value) { }

	// RVA: 0x6DC08B4
	internal object IsNamespaceInherited() { }

	// RVA: 0x6DBF6A8
	internal object CheckCascadingNamespaceConflict(object realNamespace) { }

	// RVA: 0x6DBFBD4
	internal object CheckNamespaceValidityForNestedRelations(object realNamespace) { }

	// RVA: 0x6DC08C4
	internal object CheckNamespaceValidityForNestedParentRelations(object ns, object parentTable) { }

	// RVA: 0x6DC00F8
	internal object DoRaiseNamespaceChange() { }

	// RVA: 0x6DC0DC0
	public object get_Prefix() { }

	// RVA: 0x6DC0DC8
	public object set_Prefix(object value) { }

	// RVA: 0x6DC0F60
	internal object get_XmlText() { }

	// RVA: 0x6DC0F68
	internal object set_XmlText(object value) { }

	// RVA: 0x6DC103C
	internal object get_MaxOccurs() { }

	// RVA: 0x6DC1048
	internal object set_MaxOccurs(object value) { }

	// RVA: 0x6DC1050
	internal object get_MinOccurs() { }

	// RVA: 0x6DC105C
	internal object set_MinOccurs(object value) { }

	// RVA: 0x6DC1064
	internal object SetKeyValues(object key, object keyValues, object record) { }

	// RVA: 0x6DC1120
	internal object FindByIndex(object ndx, object key) { }

	// RVA: 0x6DC11C8
	internal object FindMergeTarget(object row, object key, object ndx) { }

	// RVA: 0x6DC125C
	private object SetMergeRecords(object row, object newRecord, object oldRecord, object action) { }

	// RVA: 0x6DC16F4
	internal object MergeRow(object row, object targetRow, object preserveChanges, object idxSearch) { }

	// RVA: 0x6DC2458
	protected virtual object CreateInstance() { }

	// RVA: 0x6DC24EC
	public virtual object Clone() { }

	// RVA: 0x6DC24F4
	internal object Clone(object cloneDS) { }

	// RVA: 0x6DC27CC
	private object IncrementalCloneTo(object sourceTable, object targetTable) { }

	// RVA: 0x6DC2BA4
	private object CloneHierarchy(object sourceTable, object ds, object visitedMap) { }

	// RVA: 0x6DB6D14
	private object CloneTo(object clone, object cloneDS, object skipExpressionColumns) { }

	// RVA: 0x6DC3200
	public override object get_Site() { }

	// RVA: 0x6DC3208
	internal object AddRow(object row, object proposedID) { }

	// RVA: 0x6DC3218
	internal object InsertRow(object row, object proposedID, object pos) { }

	// RVA: 0x6DC3224
	internal object InsertRow(object row, object proposedID, object pos, object fireEvent) { }

	// RVA: 0x6DC42B0
	internal object CheckNotModifying(object row) { }

	// RVA: 0x6DC42E4
	public object Clear() { }

	// RVA: 0x6DC42EC
	internal object Clear(object clearAll) { }

	// RVA: 0x6DC4E24
	internal object CascadeAll(object row, object action) { }

	// RVA: 0x6DC4F0C
	internal object CommitRow(object row) { }

	// RVA: 0x6DC5220
	internal object Compare(object s1, object s2) { }

	// RVA: 0x6DC5228
	internal object Compare(object s1, object s2, object comparer) { }

	// RVA: 0x6DC5404
	internal object IndexOf(object s1, object s2) { }

	// RVA: 0x6DC54BC
	internal object IsSuffix(object s1, object s2) { }

	// RVA: 0x6DC5574
	internal object DeleteRow(object row) { }

	// RVA: 0x6DC561C
	internal object FormatSortString(object indexDesc) { }

	// RVA: 0x6DC5790
	internal object FreeRecord(object record) { }

	// RVA: 0x6DC57B4
	internal object GetIndex(object sort, object recordStates, object rowFilter) { }

	// RVA: 0x6DC5C54
	internal object GetIndex(object indexDesc, object recordStates, object rowFilter) { }

	// RVA: 0x6DC5EC0
	internal object GetListeners() { }

	// RVA: 0x6DBD804
	internal object GetSpecialHashCode(object name) { }

	// RVA: 0x6DC1F00
	internal object InsertRow(object row, object proposedID) { }

	// RVA: 0x6DC7000
	internal object NewRecord() { }

	// RVA: 0x6DC7150
	internal object NewUninitializedRecord() { }

	// RVA: 0x6DC7008
	internal object NewRecord(object sourceRecord) { }

	// RVA: 0x6DBB530
	internal object NewEmptyRow() { }

	// RVA: 0x6DC7174
	private object NewUninitializedRow() { }

	// RVA: 0x6DC7274
	public object NewRow() { }

	// RVA: 0x6DC73C4
	internal object CreateEmptyRow() { }

	// RVA: 0x6DC731C
	private object NewRowCreated(object row) { }

	// RVA: 0x6DC71B4
	internal object NewRow(object record) { }

	// RVA: 0x6DC7850
	protected virtual object NewRowFromBuilder(object builder) { }

	// RVA: 0x6DC78B8
	protected virtual object GetRowType() { }

	// RVA: 0x6DC7958
	protected internal object NewRowArray(object size) { }

	// RVA: 0x6DC7BA8
	internal object get_NeedColumnChangeEvents() { }

	// RVA: 0x6DC7C00
	protected internal virtual object OnColumnChanging(object e) { }

	// RVA: 0x6DC7CF4
	protected internal virtual object OnColumnChanged(object e) { }

	// RVA: 0x6DC7DE8
	protected virtual object OnPropertyChanging(object pcevent) { }

	// RVA: 0x6DC7EDC
	internal object OnRemoveColumnInternal(object column) { }

	// RVA: 0x6DC7F28
	protected virtual object OnRemoveColumn(object column) { }

	// RVA: 0x6DC515C
	private object OnRowChanged(object args, object eRow, object eAction) { }

	// RVA: 0x6DC5098
	private object OnRowChanging(object args, object eRow, object eAction) { }

	// RVA: 0x6DC7F2C
	protected virtual object OnRowChanged(object e) { }

	// RVA: 0x6DC8020
	protected virtual object OnRowChanging(object e) { }

	// RVA: 0x6DC8114
	protected virtual object OnRowDeleting(object e) { }

	// RVA: 0x6DC8208
	protected virtual object OnRowDeleted(object e) { }

	// RVA: 0x6DC82FC
	protected virtual object OnTableCleared(object e) { }

	// RVA: 0x6DC83F0
	protected virtual object OnTableClearing(object e) { }

	// RVA: 0x6DC84E4
	protected virtual object OnTableNewRow(object e) { }

	// RVA: 0x6DC57F4
	internal object ParseSortString(object sortString) { }

	// RVA: 0x6DBF1AC
	internal object RaisePropertyChanging(object name) { }

	// RVA: 0x6DC85D8
	internal object RecordChanged(object record) { }

	// RVA: 0x6DC8798
	internal object RecordChanged(object oldIndex, object newIndex) { }

	// RVA: 0x6DC614C
	internal object RecordStateChanged(object record, object oldState, object newState) { }

	// RVA: 0x6DC6324
	internal object RecordStateChanged(object record1, object oldState1, object newState1, object record2, object oldState2, object newState2) { }

	// RVA: 0x6DC8A68
	internal object RemoveRecordFromIndexes(object row, object version) { }

	// RVA: 0x6DC8CB8
	internal object InsertRecordToIndexes(object row, object version) { }

	// RVA: 0x6DC8F14
	internal object SilentlySetValue(object dr, object dc, object version, object newValue) { }

	// RVA: 0x6DC9C64
	internal object RemoveRow(object row, object check) { }

	// RVA: 0x6DC9E44
	public virtual object Reset() { }

	// RVA: 0x6DB6D0C
	internal object ResetIndexes() { }

	// RVA: 0x6DCA1BC
	internal object ResetInternalIndexes(object column) { }

	// RVA: 0x6DCA410
	internal object RollbackRow(object row) { }

	// RVA: 0x6DC6CF0
	private object RaiseRowChanged(object args, object eRow, object eAction) { }

	// RVA: 0x6DCA4C4
	private object RaiseRowChanging(object args, object eRow, object eAction) { }

	// RVA: 0x6DC5EC8
	private object RaiseRowChanging(object args, object eRow, object eAction, object fireEvent) { }

	// RVA: 0x6DC1388
	internal object SetNewRecord(object row, object proposedRecord, object action, object isInMerge, object fireEvent, object suppressEnsurePropertyChanged) { }

	// RVA: 0x6DC364C
	private object SetNewRecordWorker(object row, object proposedRecord, object action, object isInMerge, object suppressEnsurePropertyChanged, object position, object fireEvent, object deferredException) { }

	// RVA: 0x6DC13E4
	internal object SetOldRecord(object row, object proposedRecord) { }

	// RVA: 0x6DCA93C
	private object RestoreShadowIndexes() { }

	// RVA: 0x6DBBF24
	private object SetShadowIndexes() { }

	// RVA: 0x6DCA958
	internal object ShadowIndexCopy() { }

	// RVA: 0x6DCA9FC
	public override object ToString() { }

	// RVA: 0x6DCA4A4
	internal object UpdatingCurrent(object row, object action) { }

	// RVA: 0x6DCAAC8
	internal object AddUniqueKey(object position) { }

	// RVA: 0x6DCADEC
	internal object AddUniqueKey() { }

	// RVA: 0x6DCADF4
	internal object AddForeignKey(object parentKey) { }

	// RVA: 0x6DCAEBC
	internal object UpdatePropertyDescriptorCollectionCache() { }

	// RVA: 0x6DCAEC4
	internal object GetPropertyDescriptorCollection(object attributes) { }

	// RVA: 0x6DB81C0
	internal object get_TypeName() { }

	// RVA: 0x6DCB2FC
	internal object set_TypeName(object value) { }

	// RVA: 0x6DCB304
	public object Merge(object table) { }

	// RVA: 0x6DCB310
	public object Merge(object table, object preserveChanges, object missingSchemaAction) { }

	// RVA: 0x6DCB600
	public object WriteXml(object writer, object mode, object writeHierarchy) { }

	// RVA: 0x6DCBA68
	private object CheckForClosureOnExpressions(object dt, object writeHierarchy) { }

	// RVA: 0x6DB8304
	private object CheckForClosureOnExpressionTables(object tableList) { }

	// RVA: 0x6DCC144
	public object WriteXmlSchema(object writer, object writeHierarchy) { }

	// RVA: 0x6DCC524
	private object RestoreConstraint(object originalEnforceConstraint) { }

	// RVA: 0x6DCC578
	private object IsEmptyXml(object reader) { }

	// RVA: 0x6DCC890
	internal object ReadXml(object reader, object mode, object denyResolving) { }

	// RVA: 0x6DCEA7C
	internal object ReadEndElement(object reader) { }

	// RVA: 0x6DCEBB8
	internal object ReadXDRSchema(object reader) { }

	// RVA: 0x6DD05AC
	internal object MoveToElement(object reader, object depth) { }

	// RVA: 0x6DCDD5C
	private object ReadXmlDiffgram(object reader) { }

	// RVA: 0x6DD06E8
	internal object ReadXSDSchema(object reader, object denyResolving) { }

	// RVA: 0x6DCEC50
	internal object ReadXmlSchema(object reader, object denyResolving) { }

	// RVA: 0x6DCBBCC
	private object CreateTableList(object currentTable, object tableList) { }

	// RVA: 0x6DD08D0
	private object CreateRelationList(object tableList, object relationList) { }

	// RVA: 0x6DD0F48
	public static object GetDataTableSchema(object schemaSet) { }

	// RVA: 0x6DD11E4
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6DD1228
	protected virtual object GetSchema() { }

	// RVA: 0x6DD1424
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6DD1658
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6DD1690
	protected virtual object ReadXmlSerializable(object reader) { }

	// RVA: 0x6DD169C
	internal object get_RowDiffId() { }

	// RVA: 0x6DD1718
	internal object get_ObjectID() { }

	// RVA: 0x6DD1720
	internal object AddDependentColumn(object expressionColumn) { }

	// RVA: 0x6DD18C0
	internal object RemoveDependentColumn(object expressionColumn) { }

	// RVA: 0x6DD1968
	internal object EvaluateExpressions() { }

	// RVA: 0x6DC6644
	internal object EvaluateExpressions(object row, object action, object cachedRows) { }

	// RVA: 0x6DD1DC4
	internal object EvaluateExpressions(object column) { }

	// RVA: 0x6DC4CB4
	internal object EvaluateDependentExpressions(object column) { }

	// RVA: 0x6DC90E0
	internal object EvaluateDependentExpressions(object columns, object row, object version, object cachedRows) { }

}

// Namespace: System.Data
public sealed class DataTableClearEventArgs
{

	// Fields
	private readonly object <Table>k__BackingField; // 0x8

	// Methods

	// RVA: 0x6DED328
	public object .ctor(object dataTable) { }

}

// Namespace: System.Data
public sealed class DataTableClearEventHandler
{

	// Methods

	// RVA: 0x6DED69C
	public object .ctor(object object, object method) { }

	// RVA: 0x6DED7A8
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Data
public sealed class DataTableCollection
{

	// Fields
	private readonly object _dataSet; // 0x8
	private readonly object _list; // 0x10
	private object _defaultNameIndex; // 0x18
	private object _delayedAddRangeTables; // 0x20
	private object _onCollectionChangedDelegate; // 0x28
	private object _onCollectionChangingDelegate; // 0x30
	private static object s_objectTypeCount; // 0x0
	private readonly object _objectID; // 0x38

	// Properties
	protected override object List { get; }
	internal object ObjectID { get; }
	public object Item { get; }
	public object Item { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x6DDCB20
	internal object .ctor(object dataSet) { }

	// RVA: 0x6DED7BC
	protected override object get_List() { }

	// RVA: 0x6DED7C4
	internal object get_ObjectID() { }

	// RVA: 0x6DDCF98
	public object get_Item(object index) { }

	// RVA: 0x6DED7CC
	public object get_Item(object name) { }

	// RVA: 0x6DE252C
	public object get_Item(object name, object tableNamespace) { }

	// RVA: 0x6DEDD78
	internal object GetTable(object name, object ns) { }

	// RVA: 0x6DEDF04
	internal object GetTableSmart(object name, object ns) { }

	// RVA: 0x6DDF6E4
	public object Add(object table) { }

	// RVA: 0x6DEE308
	private object ArrayAdd(object table) { }

	// RVA: 0x6DEE454
	internal object AssignName() { }

	// RVA: 0x6DEE18C
	private object BaseAdd(object table) { }

	// RVA: 0x6DEE894
	private object BaseGroupSwitch(object oldArray, object oldLength, object newArray, object newLength) { }

	// RVA: 0x6DEEAE8
	private object BaseRemove(object table) { }

	// RVA: 0x6DEEBD0
	internal object CanRemove(object table, object fThrowException) { }

	// RVA: 0x6DEC2EC
	public object Clear() { }

	// RVA: 0x6DEE580
	public object Contains(object name) { }

	// RVA: 0x6DE2D04
	internal object Contains(object name, object tableNamespace, object checkProperty, object caseSensitive) { }

	// RVA: 0x6DEF29C
	internal object Contains(object name, object caseSensitive) { }

	// RVA: 0x6DE10CC
	public object IndexOf(object table) { }

	// RVA: 0x6DEF448
	public object IndexOf(object tableName) { }

	// RVA: 0x6DEF464
	internal object IndexOf(object tableName, object tableNamespace, object chekforNull) { }

	// RVA: 0x6DEF4D0
	internal object ReplaceFromInference(object tableList) { }

	// RVA: 0x6DED900
	internal object InternalIndexOf(object tableName) { }

	// RVA: 0x6DEDB78
	internal object InternalIndexOf(object tableName, object tableNamespace) { }

	// RVA: 0x6DEE4B4
	private object MakeName(object index) { }

	// RVA: 0x6DEE360
	private object OnCollectionChanged(object ccevent) { }

	// RVA: 0x6DEE098
	private object OnCollectionChanging(object ccevent) { }

	// RVA: 0x6DEE59C
	internal object RegisterName(object name, object tbNamespace) { }

	// RVA: 0x6DEF570
	public object Remove(object table) { }

	// RVA: 0x6DEF160
	internal object UnregisterName(object name) { }

}

// Namespace: System.Data
public sealed class DataTableNewRowEventArgs
{

	// Fields
	private readonly object <Row>k__BackingField; // 0x8

	// Methods

	// RVA: 0x6DEF768
	public object .ctor(object dataRow) { }

}

// Namespace: System.Data
public sealed class DataTableNewRowEventHandler
{

	// Methods

	// RVA: 0x6DEFADC
	public object .ctor(object object, object method) { }

	// RVA: 0x6DEFBE8
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Data
internal sealed class DataTableTypeConverter
{

	// Methods

	// RVA: 0x6DEFBFC
	public object .ctor() { }

	// RVA: 0x6DEFCB0
	public override object GetPropertiesSupported(object context) { }

}

// Namespace: 
private sealed class DataRowReferenceComparer
{

	// Fields
	internal static readonly object s_default; // 0x0

	// Methods

	// RVA: 0x6DF38C0
	private object .ctor() { }

	// RVA: 0x6DF38C8
	public object Equals(object x, object y) { }

	// RVA: 0x6DF38D4
	public object GetHashCode(object obj) { }

	// RVA: 0x6DF38F4
	private static object .cctor() { }

}

// Namespace: System.Data
public class DataView
{

	// Fields
	private object _dataViewManager; // 0x18
	private object _table; // 0x20
	private object _locked; // 0x28
	private object _index; // 0x30
	private object _findIndexes; // 0x38
	private object _sort; // 0x40
	private object _comparison; // 0x48
	private object _rowFilter; // 0x50
	private object _recordStates; // 0x58
	private object _shouldOpen; // 0x5C
	private object _open; // 0x5D
	private object _allowNew; // 0x5E
	private object _allowEdit; // 0x5F
	private object _allowDelete; // 0x60
	private object _applyDefaultSort; // 0x61
	internal object _addNewRow; // 0x68
	private object _addNewMoved; // 0x70
	private object _onListChanged; // 0x78
	internal static object s_resetEventArgs; // 0x0
	private object _delayedRecordStates; // 0x80
	private object _fEndInitInProgress; // 0x84
	private object _rowViewCache; // 0x88
	private readonly object _rowViewBuffer; // 0x90
	private object _dvListener; // 0x98
	private static object s_objectTypeCount; // 0x8
	private readonly object _objectID; // 0xA0

	// Properties
	public object AllowDelete { get; }
	public object AllowNew { get; }
	public object Count { get; }
	private object CountFromIndex { get; }
	public object DataViewManager { get; }
	protected object IsOpen { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	public object RowStateFilter { get; }
	public object Sort { get; }
	internal object SortComparison { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	public object Table { get; }
	private object System.Collections.IList.Item { get; set; }
	public object Item { get; }
	private object System.Collections.IList.IsReadOnly { get; }
	private object System.Collections.IList.IsFixedSize { get; }
	internal object ObjectID { get; }

	// Methods

	// RVA: 0x6DEFCB8
	internal object .ctor(object table, object locked) { }

	// RVA: 0x6DF036C
	public object get_AllowDelete() { }

	// RVA: 0x6DF0374
	public object get_AllowNew() { }

	// RVA: 0x6DF037C
	public object get_Count() { }

	// RVA: 0x6DF03D8
	private object get_CountFromIndex() { }

	// RVA: 0x6DF03F4
	public object get_DataViewManager() { }

	// RVA: 0x6DF03FC
	protected object get_IsOpen() { }

	// RVA: 0x6DF0404
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x6DF040C
	public object get_RowStateFilter() { }

	// RVA: 0x6DF0414
	public object get_Sort() { }

	// RVA: 0x6DF0484
	internal object get_SortComparison() { }

	// RVA: 0x6DF048C
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: 0x6DF0490
	public object get_Table() { }

	// RVA: 0x6DF0498
	private object System.Collections.IList.get_Item(object recordIndex) { }

	// RVA: 0x6DF0578
	private object System.Collections.IList.set_Item(object recordIndex, object value) { }

	// RVA: 0x6DF0508
	public object get_Item(object recordIndex) { }

	// RVA: 0x6DF0714
	public virtual object AddNew() { }

	// RVA: 0x6DF0AB4
	private object CheckOpen() { }

	// RVA: 0x6DF0C38
	protected object Close() { }

	// RVA: 0x6DF0CEC
	public object CopyTo(object array, object index) { }

	// RVA: 0x6DF0EF4
	private object CopyTo(object array, object index) { }

	// RVA: 0x6DF10CC
	public object Delete(object index) { }

	// RVA: 0x6DF10F4
	internal object Delete(object row) { }

	// RVA: 0x6DF1334
	protected override object Dispose(object disposing) { }

	// RVA: 0x6DDC23C
	internal object FinishAddNew(object success) { }

	// RVA: 0x6DF13B0
	public object GetEnumerator() { }

	// RVA: 0x6DF1484
	private object System.Collections.IList.get_IsReadOnly() { }

	// RVA: 0x6DF148C
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: 0x6DF1494
	private object System.Collections.IList.Add(object value) { }

	// RVA: 0x6DF1548
	private object System.Collections.IList.Clear() { }

	// RVA: 0x6DF1578
	private object System.Collections.IList.Contains(object value) { }

	// RVA: 0x6DF1614
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: 0x6DF0AF0
	internal object IndexOf(object rowview) { }

	// RVA: 0x6DF16B0
	private object IndexOfDataRowView(object rowview) { }

	// RVA: 0x6DF1740
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: 0x6DF1770
	private object System.Collections.IList.Remove(object value) { }

	// RVA: 0x6DF18BC
	private object System.Collections.IList.RemoveAt(object index) { }

	// RVA: 0x6DF18E4
	internal virtual object GetFilter() { }

	// RVA: 0x6DF18EC
	private object GetRecord(object recordIndex) { }

	// RVA: 0x6DF05A8
	internal object GetRow(object index) { }

	// RVA: 0x6DF0E64
	private object GetRowView(object record) { }

	// RVA: 0x6DF06A8
	private object GetRowView(object dr) { }

	// RVA: 0x6DF1A28
	protected virtual object IndexListChanged(object sender, object e) { }

	// RVA: 0x6DF1B00
	internal object IndexListChangedInternal(object e) { }

	// RVA: 0x6DF1BFC
	internal object MaintainDataView(object changedType, object row, object trackAddRemove) { }

	// RVA: 0x6DF21F8
	protected virtual object OnListChanged(object e) { }

	// RVA: 0x6DF2608
	protected object Reset() { }

	// RVA: 0x6DF1F24
	internal object ResetRowViewCache() { }

	// RVA: 0x6DDBF0C
	internal object SetDataViewManager(object dataViewManager) { }

	// RVA: 0x6DF263C
	internal virtual object SetIndex(object newSort, object newRowStates, object newRowFilter) { }

	// RVA: 0x6DF2644
	internal object SetIndex2(object newSort, object newRowStates, object newRowFilter, object fireEvent) { }

	// RVA: 0x6DF0C9C
	protected object UpdateIndex() { }

	// RVA: 0x6DF2D30
	protected virtual object UpdateIndex(object force) { }

	// RVA: 0x6DF28C8
	internal object UpdateIndex(object force, object fireEvent) { }

	// RVA: 0x6DF2F40
	internal object ChildRelationCollectionChanged(object sender, object e) { }

	// RVA: 0x6DF3238
	internal object ParentRelationCollectionChanged(object sender, object e) { }

	// RVA: 0x6DF3530
	protected virtual object ColumnCollectionChanged(object sender, object e) { }

	// RVA: 0x6DF37D8
	internal object ColumnCollectionChangedInternal(object sender, object e) { }

	// RVA: 0x6DF3834
	internal object get_ObjectID() { }

	// RVA: 0x6DF383C
	private static object .cctor() { }

}

// Namespace: System.Data
internal sealed class DataViewListener
{

	// Fields
	private readonly object _dvWeak; // 0x8
	private object _table; // 0x10
	private object _index; // 0x18
	internal readonly object _objectID; // 0x20

	// Methods

	// RVA: 0x6DEFFCC
	internal object .ctor(object dv) { }

	// RVA: 0x6DF3954
	private object ChildRelationCollectionChanged(object sender, object e) { }

	// RVA: 0x6DF3A58
	private object ParentRelationCollectionChanged(object sender, object e) { }

	// RVA: 0x6DF3B38
	private object ColumnCollectionChanged(object sender, object e) { }

	// RVA: 0x6DF3C48
	internal object MaintainDataView(object changedType, object row, object trackAddRemove) { }

	// RVA: 0x6DF3D44
	internal object IndexListChanged(object e) { }

	// RVA: 0x6DF005C
	internal object RegisterMetaDataEvents(object table) { }

	// RVA: 0x6DF0CE4
	internal object UnregisterMetaDataEvents() { }

	// RVA: 0x6DF4110
	private object UnregisterMetaDataEvents(object updateListeners) { }

	// RVA: 0x6DF2E48
	internal object RegisterListChangedEvent(object index) { }

	// RVA: 0x6DF2D38
	internal object UnregisterListChangedEvent() { }

	// RVA: 0x6DF3A34
	private object CleanUp(object updateListeners) { }

	// RVA: 0x6DF3E24
	private object RegisterListener(object table) { }

}

// Namespace: System.Data
public class DataViewManager
{

	// Fields
	private object _dataViewSettingsCollection; // 0x18
	internal object _nViews; // 0x20
	private static object s_notSupported; // 0x0

	// Properties
	public object DataViewSettings { get; }

	// Methods

	// RVA: 0x6DF44EC
	public object get_DataViewSettings() { }

	// RVA: 0x6DF44F4
	private static object .cctor() { }

}

// Namespace: System.Data
public enum DataViewRowState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Unchanged;
	public const object Added;
	public const object Deleted;
	public const object ModifiedCurrent;
	public const object ModifiedOriginal;
	public const object OriginalRows;
	public const object CurrentRows;
}

// Namespace: System.Data
public class DataViewSetting
{

	// Fields
	private object _dataViewManager; // 0x8
	private object _table; // 0x10
	private object _sort; // 0x18
	private object _rowFilter; // 0x20
	private object _rowStateFilter; // 0x28
	private object _applyDefaultSort; // 0x2C

	// Properties
	public object ApplyDefaultSort { get; }
	public object RowFilter { get; }
	public object RowStateFilter { get; }
	public object Sort { get; }

	// Methods

	// RVA: 0x6DF4570
	internal object .ctor() { }

	// RVA: 0x6DF45E0
	public object get_ApplyDefaultSort() { }

	// RVA: 0x6DF45E8
	internal object SetDataViewManager(object dataViewManager) { }

	// RVA: 0x6DF45FC
	internal object SetDataTable(object table) { }

	// RVA: 0x6DF4610
	public object get_RowFilter() { }

	// RVA: 0x6DF4618
	public object get_RowStateFilter() { }

	// RVA: 0x6DF4620
	public object get_Sort() { }

}

// Namespace: System.Data
public class DataViewSettingCollection
{

	// Fields
	private readonly object _dataViewManager; // 0x8
	private readonly object _list; // 0x10

	// Properties
	public virtual object Item { get; set; }

	// Methods

	// RVA: 0x6DF4628
	public virtual object get_Item(object table) { }

	// RVA: 0x6DF47D0
	public virtual object set_Item(object table, object value) { }

	// RVA: 0x6DF48A0
	internal object Remove(object table) { }

}

// Namespace: System.Data
internal sealed class DefaultValueTypeConverter
{

	// Methods

	// RVA: 0x6DF48F8
	public object .ctor() { }

	// RVA: 0x6DF4900
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

	// RVA: 0x6DF4AEC
	public override object ConvertFrom(object context, object culture, object value) { }

}

// Namespace: System.Data
internal enum Aggregate
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Sum;
	public const object Avg;
	public const object Min;
	public const object Max;
	public const object Count;
	public const object StDev;
	public const object Var;
}

// Namespace: System.Data
internal sealed class AggregateNode
{

	// Fields
	private readonly object _type; // 0x10
	private readonly object _aggregate; // 0x14
	private readonly object _local; // 0x18
	private readonly object _relationName; // 0x20
	private readonly object _columnName; // 0x28
	private object _childTable; // 0x30
	private object _column; // 0x38
	private object _relation; // 0x40

	// Methods

	// RVA: 0x6DF4C98
	internal object .ctor(object table, object aggregateType, object columnName) { }

	// RVA: 0x6DF4CA4
	internal object .ctor(object table, object aggregateType, object columnName, object local, object relationName) { }

	// RVA: 0x6DF4E60
	internal override object Bind(object table, object list) { }

	// RVA: 0x6DF53F0
	internal static object Bind(object relation, object list) { }

	// RVA: 0x6DF56B0
	internal override object Eval() { }

	// RVA: 0x6DF56F8
	internal override object Eval(object row, object version) { }

	// RVA: 0x6DF5B78
	internal override object Eval(object records) { }

	// RVA: 0x6DF5CB0
	internal override object IsConstant() { }

	// RVA: 0x6DF5CB8
	internal override object IsTableConstant() { }

	// RVA: 0x6DF5CC0
	internal override object HasLocalAggregate() { }

	// RVA: 0x6DF5CC8
	internal override object HasRemoteAggregate() { }

	// RVA: 0x6DF5CD8
	internal override object DependsOn(object column) { }

	// RVA: 0x6DF5DF4
	internal override object Optimize() { }

}

// Namespace: 
private enum DataTypePrecedence
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SqlDateTime;
	public const object DateTimeOffset;
	public const object DateTime;
	public const object TimeSpan;
	public const object SqlDouble;
	public const object Double;
	public const object SqlSingle;
	public const object Single;
	public const object SqlDecimal;
	public const object Decimal;
	public const object SqlMoney;
	public const object UInt64;
	public const object SqlInt64;
	public const object Int64;
	public const object UInt32;
	public const object SqlInt32;
	public const object Int32;
	public const object UInt16;
	public const object SqlInt16;
	public const object Int16;
	public const object Byte;
	public const object SqlByte;
	public const object SByte;
	public const object Error;
	public const object SqlBoolean;
	public const object Boolean;
	public const object SqlGuid;
	public const object SqlString;
	public const object String;
	public const object SqlXml;
	public const object SqlChars;
	public const object Char;
	public const object SqlBytes;
	public const object SqlBinary;
}

// Namespace: System.Data
internal class BinaryNode
{

	// Fields
	internal object _op; // 0x10
	internal object _left; // 0x18
	internal object _right; // 0x20

	// Methods

	// RVA: 0x6DF5DF8
	internal object .ctor(object table, object op, object left, object right) { }

	// RVA: 0x6DF5E48
	internal override object Bind(object table, object list) { }

	// RVA: 0x6DF5EF4
	internal override object Eval() { }

	// RVA: 0x6DF5F3C
	internal override object Eval(object row, object version) { }

	// RVA: 0x6DFB71C
	internal override object Eval(object recordNos) { }

	// RVA: 0x6DFB734
	internal override object IsConstant() { }

	// RVA: 0x6DFB7CC
	internal override object IsTableConstant() { }

	// RVA: 0x6DFB864
	internal override object HasLocalAggregate() { }

	// RVA: 0x6DFB900
	internal override object HasRemoteAggregate() { }

	// RVA: 0x6DFB99C
	internal override object DependsOn(object column) { }

	// RVA: 0x6DFBA58
	internal override object Optimize() { }

	// RVA: 0x6DFC154
	internal object SetTypeMismatchError(object op, object left, object right) { }

	// RVA: 0x6DFC308
	private static object Eval(object expr, object row, object version, object recordNos) { }

	// RVA: 0x6DFC3C4
	internal object BinaryCompare(object vLeft, object vRight, object resultType, object op) { }

	// RVA: 0x6DFC3CC
	internal object BinaryCompare(object vLeft, object vRight, object resultType, object op, object comparer) { }

	// RVA: 0x6DF5F54
	private object EvalBinaryOp(object op, object left, object right, object row, object version, object recordNos) { }

	// RVA: 0x6DFEAD4
	private object GetPrecedence(object storageType) { }

	// RVA: 0x6DFEAF8
	private static object GetPrecedenceType(object code) { }

	// RVA: 0x6DFEB1C
	private object IsMixed(object left, object right) { }

	// RVA: 0x6DFEBD8
	private object IsMixedSql(object left, object right) { }

	// RVA: 0x6DFE3A0
	internal object ResultType(object left, object right, object lc, object rc, object op) { }

	// RVA: 0x6DFDCE4
	internal object ResultSqlType(object left, object right, object lc, object rc, object op) { }

	// RVA: 0x6DFEE78
	private object SqlResultType(object typeCode) { }

}

// Namespace: System.Data
internal sealed class LikeNode
{

	// Fields
	private object _kind; // 0x28
	private object _pattern; // 0x30

	// Methods

	// RVA: 0x6DFEEC8
	internal object .ctor(object table, object op, object left, object right) { }

	// RVA: 0x6DFEF18
	internal override object Eval(object row, object version) { }

	// RVA: 0x6DFF60C
	internal object AnalyzePattern(object pat) { }

}

// Namespace: System.Data
internal sealed class ConstNode
{

	// Fields
	internal readonly object _val; // 0x10

	// Methods

	// RVA: 0x6DFFCFC
	internal object .ctor(object table, object type, object constant) { }

	// RVA: 0x6DFBDE0
	internal object .ctor(object table, object type, object constant, object fParseQuotes) { }

	// RVA: 0x6E00730
	internal override object Bind(object table, object list) { }

	// RVA: 0x6E00738
	internal override object Eval() { }

	// RVA: 0x6E00740
	internal override object Eval(object row, object version) { }

	// RVA: 0x6E00780
	internal override object Eval(object recordNos) { }

	// RVA: 0x6E007C0
	internal override object IsConstant() { }

	// RVA: 0x6E007C8
	internal override object IsTableConstant() { }

	// RVA: 0x6E007D0
	internal override object HasLocalAggregate() { }

	// RVA: 0x6E007D8
	internal override object HasRemoteAggregate() { }

	// RVA: 0x6E007E0
	internal override object Optimize() { }

	// RVA: 0x6E0027C
	private object SmallestDecimal(object constant) { }

	// RVA: 0x6DFFD04
	private object SmallestNumeric(object constant) { }

}

// Namespace: System.Data
internal sealed class DataExpression
{

	// Fields
	internal object _originalExpression; // 0x8
	private object _parsed; // 0x10
	private object _bound; // 0x11
	private object _expr; // 0x18
	private object _table; // 0x20
	private readonly object _storageType; // 0x28
	private readonly object _dataType; // 0x30
	private object _dependency; // 0x38

	// Properties
	internal object Expression { get; }
	internal object HasValue { get; }

	// Methods

	// RVA: 0x6E007E4
	internal object .ctor(object table, object expression) { }

	// RVA: 0x6E007EC
	internal object .ctor(object table, object expression, object type) { }

	// RVA: 0x6E01E28
	internal object get_Expression() { }

	// RVA: 0x6E01E84
	internal object get_HasValue() { }

	// RVA: 0x6E01CE4
	internal object Bind(object table) { }

	// RVA: 0x6DF5D98
	internal object DependsOn(object column) { }

	// RVA: 0x6E01E94
	internal object Evaluate() { }

	// RVA: 0x6E01EA0
	internal object Evaluate(object row, object version) { }

	// RVA: 0x6E02224
	public object Invoke(object row, object version) { }

	// RVA: 0x6E02438
	internal object GetDependency() { }

	// RVA: 0x6E02440
	internal object IsTableAggregate() { }

	// RVA: 0x6E02490
	internal static object IsUnknown(object value) { }

	// RVA: 0x6E02518
	internal object HasLocalAggregate() { }

	// RVA: 0x6E02568
	internal object HasRemoteAggregate() { }

	// RVA: 0x6DFD9DC
	internal static object ToBoolean(object value) { }

}

// Namespace: System.Data
internal abstract class ExpressionNode
{

	// Fields
	private object _table; // 0x8

	// Properties
	internal object FormatProvider { get; }
	internal virtual object IsSqlColumn { get; }
	protected object table { get; }

	// Methods

	// RVA: 0x6DF4D84
	protected object .ctor(object table) { }

	// RVA: 0x6DFD95C
	internal object get_FormatProvider() { }

	// RVA: 0x6E025B8
	internal virtual object get_IsSqlColumn() { }

	// RVA: 0x6E025C0
	protected object get_table() { }

	// RVA: 0x6E025C8
	protected object BindTable(object table) { }

	// RVA: -1
	internal abstract object Bind(object table, object list) { }

	// RVA: -1
	internal abstract object Eval() { }

	// RVA: -1
	internal abstract object Eval(object row, object version) { }

	// RVA: -1
	internal abstract object Eval(object recordNos) { }

	// RVA: -1
	internal abstract object IsConstant() { }

	// RVA: -1
	internal abstract object IsTableConstant() { }

	// RVA: -1
	internal abstract object HasLocalAggregate() { }

	// RVA: -1
	internal abstract object HasRemoteAggregate() { }

	// RVA: -1
	internal abstract object Optimize() { }

	// RVA: 0x6E025D0
	internal virtual object DependsOn(object column) { }

	// RVA: 0x6DFECEC
	internal static object IsInteger(object type) { }

	// RVA: 0x6DFE858
	internal static object IsIntegerSql(object type) { }

	// RVA: 0x6DFEB98
	internal static object IsSigned(object type) { }

	// RVA: 0x6DFEC54
	internal static object IsSignedSql(object type) { }

	// RVA: 0x6DFEBC8
	internal static object IsUnsigned(object type) { }

	// RVA: 0x6DFEC70
	internal static object IsUnsignedSql(object type) { }

	// RVA: 0x6DFECDC
	internal static object IsNumeric(object type) { }

	// RVA: 0x6DFEEA8
	internal static object IsNumericSql(object type) { }

	// RVA: 0x6E025D8
	internal static object IsFloat(object type) { }

	// RVA: 0x6E025E8
	internal static object IsFloatSql(object type) { }

}

// Namespace: System.Data
internal enum ValueType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object Null;
	public const object Bool;
	public const object Numeric;
	public const object Str;
	public const object Float;
	public const object Decimal;
	public const object Object;
	public const object Date;
}

// Namespace: System.Data
internal enum Nodes
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Noop;
	public const object Unop;
	public const object UnopSpec;
	public const object Binop;
	public const object BinopSpec;
	public const object Zop;
	public const object Call;
	public const object Const;
	public const object Name;
	public const object Paren;
	public const object Conv;
}

// Namespace: 
private struct ReservedWords
{

	// Fields
	internal readonly object _word; // 0xFFFFFFFFFFFFFFF8
	internal readonly object _token; // 0x0
	internal readonly object _op; // 0x4

	// Methods

	// RVA: 0x6E0573C
	internal object .ctor(object word, object token, object op) { }

}

// Namespace: System.Data
internal sealed class ExpressionParser
{

	// Fields
	private static readonly object s_reservedwords; // 0x0
	private object _escape; // 0x8
	private object _decimalSeparator; // 0xA
	private object _listSeparator; // 0xC
	private object _exponentL; // 0xE
	private object _exponentU; // 0x10
	internal object _text; // 0x18
	internal object _pos; // 0x20
	internal object _start; // 0x24
	internal object _token; // 0x28
	internal object _op; // 0x2C
	internal object _ops; // 0x30
	internal object _topOperator; // 0x38
	internal object _topNode; // 0x3C
	private readonly object _table; // 0x40
	internal object _nodeStack; // 0x48
	internal object _prevOperand; // 0x50
	internal object _expression; // 0x58

	// Methods

	// RVA: 0x6E00A80
	internal object .ctor(object table) { }

	// RVA: 0x6E00B30
	internal object LoadExpression(object data) { }

	// RVA: 0x6E02604
	internal object StartScan() { }

	// RVA: 0x6E00C98
	internal object Parse() { }

	// RVA: 0x6E03A8C
	private object ParseAggregateArgument(object aggregate) { }

	// RVA: 0x6E03988
	private object NodePop() { }

	// RVA: 0x6E03898
	private object NodePeek() { }

	// RVA: 0x6E03690
	private object NodePush(object node) { }

	// RVA: 0x6E02E74
	private object BuildExpression(object pri) { }

	// RVA: 0x6E03510
	internal object CheckToken(object token) { }

	// RVA: 0x6E026E8
	internal object Scan() { }

	// RVA: 0x6E04DC8
	private object ScanNumeric() { }

	// RVA: 0x6E05200
	private object ScanName() { }

	// RVA: 0x6E04C3C
	private object ScanName(object chEnd, object esc, object charsToEscape) { }

	// RVA: 0x6E04A90
	private object ScanDate() { }

	// RVA: 0x6E04F04
	private object ScanBinaryConstant() { }

	// RVA: 0x6E04F18
	private object ScanReserved() { }

	// RVA: 0x6E04B54
	private object ScanString(object escape) { }

	// RVA: 0x6E03260
	internal object ScanToken(object token) { }

	// RVA: 0x6E04A18
	private object ScanWhite() { }

	// RVA: 0x6E054A4
	private object IsWhiteSpace(object ch) { }

	// RVA: 0x6E051BC
	private object IsAlphaNumeric(object ch) { }

	// RVA: 0x6E04F08
	private object IsDigit(object ch) { }

	// RVA: 0x6E053D4
	private object IsAlpha(object ch) { }

	// RVA: 0x6E054B4
	private static object .cctor() { }

}

// Namespace: System.Data
internal enum Tokens
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Name;
	public const object Numeric;
	public const object Decimal;
	public const object Float;
	public const object BinaryConst;
	public const object StringConst;
	public const object Date;
	public const object ListSeparator;
	public const object LeftParen;
	public const object RightParen;
	public const object ZeroOp;
	public const object UnaryOp;
	public const object BinaryOp;
	public const object Child;
	public const object Parent;
	public const object Dot;
	public const object Unknown;
	public const object EOS;
}

// Namespace: System.Data
internal sealed class OperatorInfo
{

	// Fields
	internal object _type; // 0x8
	internal object _op; // 0xC
	internal object _priority; // 0x10

	// Methods

	// RVA: 0x6E026A8
	internal object .ctor(object type, object op, object pri) { }

}

// Namespace: System.Data
public class InvalidExpressionException
{

	// Methods

	// RVA: 0x6E057EC
	protected object .ctor(object info, object context) { }

	// RVA: 0x6E057F4
	public object .ctor() { }

	// RVA: 0x6E057FC
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class EvaluateException
{

	// Methods

	// RVA: 0x6E05804
	protected object .ctor(object info, object context) { }

	// RVA: 0x6E0580C
	public object .ctor() { }

	// RVA: 0x6E05814
	public object .ctor(object s) { }

}

// Namespace: System.Data
public class SyntaxErrorException
{

	// Methods

	// RVA: 0x6E0581C
	protected object .ctor(object info, object context) { }

	// RVA: 0x6E05824
	public object .ctor() { }

	// RVA: 0x6E0582C
	public object .ctor(object s) { }

}

// Namespace: System.Data
internal sealed class ExprException
{

	// Methods

	// RVA: 0x6E05834
	private static object _Overflow(object error) { }

	// RVA: 0x6E058A8
	private static object _Expr(object error) { }

	// RVA: 0x6E0591C
	private static object _Syntax(object error) { }

	// RVA: 0x6E05990
	private static object _Eval(object error) { }

	// RVA: 0x6E05A04
	private static object _Eval(object error, object innerException) { }

	// RVA: 0x6E02340
	public static object InvokeArgument() { }

	// RVA: 0x6E05A78
	public static object NYI(object moreinfo) { }

	// RVA: 0x6E02D84
	public static object MissingOperand(object before) { }

	// RVA: 0x6E031B0
	public static object MissingOperator(object token) { }

	// RVA: 0x6E05B28
	public static object TypeMismatch(object expr) { }

	// RVA: 0x6E05BD8
	public static object FunctionArgumentOutOfRange(object arg, object func) { }

	// RVA: 0x6E0480C
	public static object ExpressionTooComplex() { }

	// RVA: 0x6DF5340
	public static object UnboundName(object name) { }

	// RVA: 0x6E053F4
	public static object InvalidString(object str) { }

	// RVA: 0x6DF4DB0
	public static object UndefinedFunction(object name) { }

	// RVA: 0x6E038EC
	public static object SyntaxError() { }

	// RVA: 0x6E05C44
	public static object FunctionArgumentCount(object name) { }

	// RVA: 0x6E03114
	public static object MissingRightParen() { }

	// RVA: 0x6E04674
	public static object UnknownToken(object token, object position) { }

	// RVA: 0x6E048A8
	public static object UnknownToken(object tokExpected, object tokCurr, object position) { }

	// RVA: 0x6E05CF4
	public static object DatatypeConvertion(object type1, object type2) { }

	// RVA: 0x6E02100
	public static object DatavalueConvertion(object value, object type, object innerException) { }

	// RVA: 0x6E05E18
	public static object InvalidName(object name) { }

	// RVA: 0x6E05324
	public static object InvalidDate(object date) { }

	// RVA: 0x6E05EC8
	public static object NonConstantArgument() { }

	// RVA: 0x6DFFC4C
	public static object InvalidPattern(object pat) { }

	// RVA: 0x6DFE878
	public static object InWithoutParentheses() { }

	// RVA: 0x6E05F64
	public static object InWithoutList() { }

	// RVA: 0x6DFBD44
	public static object InvalidIsSyntax() { }

	// RVA: 0x6DFE9F0
	public static object Overflow(object type) { }

	// RVA: 0x6E06000
	public static object ArgumentType(object function, object arg, object type) { }

	// RVA: 0x6E0613C
	public static object ArgumentTypeInteger(object function, object arg) { }

	// RVA: 0x6DFC18C
	public static object TypeMismatchInBinop(object op, object type1, object type2) { }

	// RVA: 0x6DFECFC
	public static object AmbiguousBinop(object op, object type1, object type2) { }

	// RVA: 0x6DFE914
	public static object UnsupportedOperator(object op) { }

	// RVA: 0x6E05274
	public static object InvalidNameBracketing(object name) { }

	// RVA: 0x6E04398
	public static object MissingOperandBefore(object op) { }

	// RVA: 0x6E03E70
	public static object TooManyRightParentheses() { }

	// RVA: 0x6DF5288
	public static object UnresolvedRelation(object name, object expr) { }

	// RVA: 0x6E06238
	internal static object BindFailure(object relationName) { }

	// RVA: 0x6E04770
	public static object AggregateArgument() { }

	// RVA: 0x6DF51D8
	public static object AggregateUnbound(object expr) { }

	// RVA: 0x6DF5ADC
	public static object EvalNoContext() { }

	// RVA: 0x6E062E8
	public static object ExpressionUnbound(object expr) { }

	// RVA: 0x6DF5C00
	public static object ComputeNotAggregate(object expr) { }

	// RVA: 0x6E02388
	public static object FilterConvertion(object expr) { }

	// RVA: 0x6E03558
	public static object LookupArgument() { }

	// RVA: 0x6E06398
	public static object InvalidType(object typeName) { }

	// RVA: 0x6E06448
	public static object InvalidHoursArgument() { }

	// RVA: 0x6E064E4
	public static object InvalidMinutesArgument() { }

	// RVA: 0x6E06580
	public static object InvalidTimeZoneRange() { }

	// RVA: 0x6E0661C
	public static object MismatchKindandTimeSpan() { }

	// RVA: 0x6E00C08
	public static object UnsupportedDataType(object type) { }

}

// Namespace: System.Data
internal sealed class FunctionNode
{

	// Fields
	internal readonly object _name; // 0x10
	internal readonly object _info; // 0x18
	internal object _argumentCount; // 0x1C
	internal object _arguments; // 0x20
	private static readonly object s_funcs; // 0x0

	// Properties
	internal object Aggregate { get; }
	internal object IsAggregate { get; }

	// Methods

	// RVA: 0x6E03738
	internal object .ctor(object table, object name) { }

	// RVA: 0x6E03F0C
	internal object AddArgument(object argument) { }

	// RVA: 0x6E066B8
	internal override object Bind(object table, object list) { }

	// RVA: 0x6E06A90
	internal override object Eval() { }

	// RVA: 0x6E06AD8
	internal override object Eval(object row, object version) { }

	// RVA: 0x6E093B8
	internal override object Eval(object recordNos) { }

	// RVA: 0x6E093F0
	internal override object IsConstant() { }

	// RVA: 0x6E094C4
	internal override object IsTableConstant() { }

	// RVA: 0x6E09580
	internal override object HasLocalAggregate() { }

	// RVA: 0x6E0963C
	internal override object HasRemoteAggregate() { }

	// RVA: 0x6E096F8
	internal override object DependsOn(object column) { }

	// RVA: 0x6E097C0
	internal override object Optimize() { }

	// RVA: 0x6E0778C
	private object GetDataType(object node) { }

	// RVA: 0x6E07A48
	private object EvalFunction(object id, object argumentValues, object row, object version) { }

	// RVA: 0x6E039D0
	internal object get_Aggregate() { }

	// RVA: 0x6E09A0C
	internal object get_IsAggregate() { }

	// RVA: 0x6E04134
	internal object Check() { }

	// RVA: 0x6E09D74
	private static object .cctor() { }

}

// Namespace: System.Data
internal enum FunctionId
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object none;
	public const object Ascii;
	public const object Char;
	public const object Charindex;
	public const object Difference;
	public const object Len;
	public const object Lower;
	public const object LTrim;
	public const object Patindex;
	public const object Replicate;
	public const object Reverse;
	public const object Right;
	public const object RTrim;
	public const object Soundex;
	public const object Space;
	public const object Str;
	public const object Stuff;
	public const object Substring;
	public const object Upper;
	public const object IsNull;
	public const object Iif;
	public const object Convert;
	public const object cInt;
	public const object cBool;
	public const object cDate;
	public const object cDbl;
	public const object cStr;
	public const object Abs;
	public const object Acos;
	public const object In;
	public const object Trim;
	public const object Sum;
	public const object Avg;
	public const object Min;
	public const object Max;
	public const object Count;
	public const object StDev;
	public const object Var;
	public const object DateTimeOffset;
}

// Namespace: System.Data
internal sealed class Function
{

	// Fields
	internal readonly object _name; // 0x8
	internal readonly object _id; // 0x10
	internal readonly object _result; // 0x18
	internal readonly object _isValidateArguments; // 0x20
	internal readonly object _isVariantArgumentList; // 0x21
	internal readonly object _argumentCount; // 0x24
	internal readonly object _parameters; // 0x28
	internal static object s_functionName; // 0x0

	// Methods

	// RVA: 0x6E0A608
	internal object .ctor(object name, object id, object result, object IsValidateArguments, object IsVariantArgumentList, object argumentCount, object a1, object a2, object a3) { }

	// RVA: 0x6E0A864
	private static object .cctor() { }

}

// Namespace: System.Data
internal interface IFilter
{

	// Methods

	// RVA: -1
	public abstract object Invoke(object row, object version) { }

}

// Namespace: System.Data
internal sealed class LookupNode
{

	// Fields
	private readonly object _relationName; // 0x10
	private readonly object _columnName; // 0x18
	private object _column; // 0x20
	private object _relation; // 0x28

	// Methods

	// RVA: 0x6E035F4
	internal object .ctor(object table, object columnName, object relationName) { }

	// RVA: 0x6E0AE60
	internal override object Bind(object table, object list) { }

	// RVA: 0x6E0B1A4
	internal override object Eval() { }

	// RVA: 0x6E0B1D0
	internal override object Eval(object row, object version) { }

	// RVA: 0x6E0B2F4
	internal override object Eval(object recordNos) { }

	// RVA: 0x6E0B32C
	internal override object IsConstant() { }

	// RVA: 0x6E0B334
	internal override object IsTableConstant() { }

	// RVA: 0x6E0B33C
	internal override object HasLocalAggregate() { }

	// RVA: 0x6E0B344
	internal override object HasRemoteAggregate() { }

	// RVA: 0x6E0B34C
	internal override object DependsOn(object column) { }

	// RVA: 0x6E0B35C
	internal override object Optimize() { }

}

// Namespace: System.Data
internal sealed class NameNode
{

	// Fields
	internal object _name; // 0x10
	internal object _found; // 0x18
	internal object _column; // 0x20

	// Properties
	internal override object IsSqlColumn { get; }

	// Methods

	// RVA: 0x6E03634
	internal object .ctor(object table, object text, object start, object pos) { }

	// RVA: 0x6E0463C
	internal object .ctor(object table, object name) { }

	// RVA: 0x6E0B360
	internal override object get_IsSqlColumn() { }

	// RVA: 0x6E0B384
	internal override object Bind(object table, object list) { }

	// RVA: 0x6E0B640
	internal override object Eval() { }

	// RVA: 0x6E0B66C
	internal override object Eval(object row, object version) { }

	// RVA: 0x6E0B74C
	internal override object Eval(object records) { }

	// RVA: 0x6E0B784
	internal override object IsConstant() { }

	// RVA: 0x6E0B78C
	internal override object IsTableConstant() { }

	// RVA: 0x6E0B81C
	internal override object HasLocalAggregate() { }

	// RVA: 0x6E0B8AC
	internal override object HasRemoteAggregate() { }

	// RVA: 0x6E0B93C
	internal override object DependsOn(object column) { }

	// RVA: 0x6E0B9FC
	internal override object Optimize() { }

	// RVA: 0x6E032B8
	internal static object ParseName(object text, object start, object pos) { }

}

// Namespace: System.Data
internal sealed class Operators
{

	// Fields
	private static readonly object s_priority; // 0x0
	private static readonly object s_looks; // 0x8

	// Methods

	// RVA: 0x6DFECC0
	internal static object IsArithmetical(object op) { }

	// RVA: 0x6DFECA0
	internal static object IsLogical(object op) { }

	// RVA: 0x6DFEC90
	internal static object IsRelational(object op) { }

	// RVA: 0x6E0454C
	internal static object Priority(object op) { }

	// RVA: 0x6E04448
	internal static object ToString(object op) { }

	// RVA: 0x6E0BA00
	private static object .cctor() { }

}

// Namespace: System.Data
internal sealed class UnaryNode
{

	// Fields
	internal readonly object _op; // 0x10
	internal object _right; // 0x18

	// Methods

	// RVA: 0x6E0C040
	internal object .ctor(object table, object op, object right) { }

	// RVA: 0x6E0C07C
	internal override object Bind(object table, object list) { }

	// RVA: 0x6E0C0E4
	internal override object Eval() { }

	// RVA: 0x6E0C12C
	internal override object Eval(object row, object version) { }

	// RVA: 0x6E0C8D4
	internal override object Eval(object recordNos) { }

	// RVA: 0x6E0C1B0
	private object EvalUnaryOp(object op, object vl) { }

	// RVA: 0x6E0C928
	internal override object IsConstant() { }

	// RVA: 0x6E0C974
	internal override object IsTableConstant() { }

	// RVA: 0x6E0C9C0
	internal override object HasLocalAggregate() { }

	// RVA: 0x6E0CA0C
	internal override object HasRemoteAggregate() { }

	// RVA: 0x6E0CA58
	internal override object DependsOn(object column) { }

	// RVA: 0x6E0CAB0
	internal override object Optimize() { }

}

// Namespace: System.Data
internal sealed class ZeroOpNode
{

	// Fields
	internal readonly object _op; // 0x10

	// Methods

	// RVA: 0x6E0CBB8
	internal object .ctor(object op) { }

	// RVA: 0x6E0CBE8
	internal override object Bind(object table, object list) { }

	// RVA: 0x6E0CBEC
	internal override object Eval() { }

	// RVA: 0x6E0CCE8
	internal override object Eval(object row, object version) { }

	// RVA: 0x6E0CD28
	internal override object Eval(object recordNos) { }

	// RVA: 0x6E0CD68
	internal override object IsConstant() { }

	// RVA: 0x6E0CD70
	internal override object IsTableConstant() { }

	// RVA: 0x6E0CD78
	internal override object HasLocalAggregate() { }

	// RVA: 0x6E0CD80
	internal override object HasRemoteAggregate() { }

	// RVA: 0x6E0CD88
	internal override object Optimize() { }

}

// Namespace: System.Data
public class ForeignKeyConstraint
{

	// Fields
	internal object _deleteRule; // 0x30
	internal object _updateRule; // 0x34
	internal object _acceptRejectRule; // 0x38
	private object _childKey; // 0x40
	private object _parentKey; // 0x48
	internal object _constraintName; // 0x50
	internal object _parentColumnNames; // 0x58
	internal object _childColumnNames; // 0x60
	internal object _parentTableName; // 0x68

	// Properties
	internal object ChildKey { get; }
	public virtual object Columns { get; }
	public override object Table { get; }
	internal object ParentColumnNames { get; }
	internal object ChildColumnNames { get; }
	public virtual object AcceptRejectRule { get; set; }
	public virtual object DeleteRule { get; set; }
	public virtual object RelatedColumns { get; }
	internal object RelatedColumnsReference { get; }
	internal object ParentKey { get; }
	public virtual object RelatedTable { get; }
	public virtual object UpdateRule { get; set; }

	// Methods

	// RVA: 0x6E0CD8C
	public object .ctor(object parentColumns, object childColumns) { }

	// RVA: 0x6E0CDD8
	public object .ctor(object constraintName, object parentColumns, object childColumns) { }

	// RVA: 0x6E0CFF4
	public object .ctor(object constraintName, object parentTableName, object parentColumnNames, object childColumnNames, object acceptRejectRule, object deleteRule, object updateRule) { }

	// RVA: 0x6E0D064
	internal object get_ChildKey() { }

	// RVA: 0x6E0D08C
	public virtual object get_Columns() { }

	// RVA: 0x6E0D0B8
	public override object get_Table() { }

	// RVA: 0x6E0D0E4
	internal object get_ParentColumnNames() { }

	// RVA: 0x6E0D0F0
	internal object get_ChildColumnNames() { }

	// RVA: 0x6E0D0FC
	internal override object CheckCanAddToCollection(object constraints) { }

	// RVA: 0x6E0D30C
	internal override object CanBeRemovedFromCollection(object constraints, object fThrowException) { }

	// RVA: 0x6E0D314
	internal object IsKeyNull(object values) { }

	// RVA: 0x6E0D3D8
	internal override object IsConstraintViolated() { }

	// RVA: 0x6E0DB48
	internal override object CanEnableConstraint() { }

	// RVA: 0x6E0DE58
	internal object CascadeCommit(object row) { }

	// RVA: 0x6E0E068
	internal object CascadeDelete(object row) { }

	// RVA: 0x6E0E7B4
	internal object CascadeRollback(object row) { }

	// RVA: 0x6E0EA5C
	internal object CascadeUpdate(object row) { }

	// RVA: 0x6E0F098
	internal object CheckCanClearParentTable(object table) { }

	// RVA: 0x6E0F1F8
	internal object CheckCanRemoveParentRow(object row) { }

	// RVA: 0x6E0F310
	internal object CheckCascade(object row, object action) { }

	// RVA: 0x6E0F494
	internal override object CheckConstraint(object childRow, object action) { }

	// RVA: 0x6E0F860
	private object NonVirtualCheckState() { }

	// RVA: 0x6E0FB6C
	internal override object CheckState() { }

	// RVA: 0x6E0FB70
	public virtual object get_AcceptRejectRule() { }

	// RVA: 0x6E0FB98
	public virtual object set_AcceptRejectRule(object value) { }

	// RVA: 0x6E0FBF0
	internal override object ContainsColumn(object column) { }

	// RVA: 0x6E0FC3C
	internal override object Clone(object destination) { }

	// RVA: 0x6E0FC88
	internal override object Clone(object destination, object ignorNSforTableLookup) { }

	// RVA: 0x6E107E8
	internal object Clone(object destination) { }

	// RVA: 0x6E0CE28
	private object Create(object relationName, object parentColumns, object childColumns) { }

	// RVA: 0x6E11098
	public virtual object get_DeleteRule() { }

	// RVA: 0x6E110C0
	public virtual object set_DeleteRule(object value) { }

	// RVA: 0x6E11118
	public override object Equals(object key) { }

	// RVA: 0x6E11234
	public override object GetHashCode() { }

	// RVA: 0x6E1123C
	public virtual object get_RelatedColumns() { }

	// RVA: 0x6E107C0
	internal object get_RelatedColumnsReference() { }

	// RVA: 0x6E0F2E8
	internal object get_ParentKey() { }

	// RVA: 0x6E11268
	internal object FindParentRelation() { }

	// RVA: 0x6E113D4
	public virtual object get_RelatedTable() { }

	// RVA: 0x6E11400
	public virtual object get_UpdateRule() { }

	// RVA: 0x6E11428
	public virtual object set_UpdateRule(object value) { }

}

// Namespace: System.Data
public enum MappingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Element;
	public const object Attribute;
	public const object SimpleContent;
	public const object Hidden;
}

// Namespace: System.Data
public class MergeFailedEventArgs
{

	// Fields
	private readonly object <Table>k__BackingField; // 0x8
	private readonly object <Conflict>k__BackingField; // 0x10

	// Properties
	public object Conflict { get; }

	// Methods

	// RVA: 0x6E11480
	public object .ctor(object table, object conflict) { }

	// RVA: 0x6E114FC
	public object get_Conflict() { }

}

// Namespace: System.Data
public sealed class MergeFailedEventHandler
{

	// Methods

	// RVA: 0x6E11808
	public object .ctor(object object, object method) { }

	// RVA: 0x6E11914
	public virtual object Invoke(object sender, object e) { }

}

// Namespace: System.Data
internal sealed class Merger
{

	// Fields
	private object _dataSet; // 0x8
	private object _dataTable; // 0x10
	private object _preserveChanges; // 0x18
	private object _missingSchemaAction; // 0x1C
	private object _isStandAlonetable; // 0x20
	private object _IgnoreNSforTableLookup; // 0x21

	// Methods

	// RVA: 0x6E11928
	internal object .ctor(object dataSet, object preserveChanges, object missingSchemaAction) { }

	// RVA: 0x6E11974
	internal object .ctor(object dataTable, object preserveChanges, object missingSchemaAction) { }

	// RVA: 0x6E119C8
	internal object MergeDataSet(object source) { }

	// RVA: 0x6E13EC8
	internal object MergeTable(object src) { }

	// RVA: 0x6E141E0
	private object MergeTable(object src, object dst) { }

	// RVA: 0x6E149BC
	private object MergeSchema(object table) { }

	// RVA: 0x6E12D7C
	private object MergeTableData(object src) { }

	// RVA: 0x6E12E3C
	private object MergeConstraints(object source) { }

	// RVA: 0x6E15388
	private object MergeConstraints(object table) { }

	// RVA: 0x6E12EF0
	private object MergeRelation(object relation) { }

	// RVA: 0x6E13B60
	private object MergeExtendedProperties(object src, object dst) { }

	// RVA: 0x6E147C4
	private object GetSrcKey(object src, object dst) { }

}

// Namespace: System.Data
public enum MissingSchemaAction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object Ignore;
	public const object Error;
	public const object AddWithKey;
}

// Namespace: System.Data
internal sealed class PrimaryKeyTypeConverter
{

	// Methods

	// RVA: 0x6E157FC
	public object .ctor() { }

	// RVA: 0x6E158B0
	public override object GetPropertiesSupported(object context) { }

	// RVA: 0x6E158B8
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x6E15984
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

}

// Namespace: System.Data
public class PropertyCollection
{

	// Methods

	// RVA: 0x6E15C08
	public object .ctor() { }

	// RVA: 0x6E15C10
	protected object .ctor(object info, object context) { }

	// RVA: 0x6E15C18
	public override object Clone() { }

}

// Namespace: System.Data
internal struct Range
{

	// Fields
	private object _min; // 0xFFFFFFFFFFFFFFF8
	private object _max; // 0xFFFFFFFFFFFFFFFC
	private object _isNotNull; // 0x0

	// Properties
	public object Count { get; }
	public object IsNull { get; }
	public object Min { get; }

	// Methods

	// RVA: 0x6E15FE8
	public object .ctor(object min, object max) { }

	// RVA: 0x6E0E6A8
	public object get_Count() { }

	// RVA: 0x6E0E058
	public object get_IsNull() { }

	// RVA: 0x6E0E6C8
	public object get_Min() { }

	// RVA: 0x6E160B8
	internal object CheckNull() { }

}

// Namespace: System.Data
internal enum RBTreeError
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object InvalidPageSize;
	public const object PagePositionInSlotInUse;
	public const object NoFreeSlots;
	public const object InvalidStateinInsert;
	public const object InvalidNextSizeInDelete;
	public const object InvalidStateinDelete;
	public const object InvalidNodeSizeinDelete;
	public const object InvalidStateinEndDelete;
	public const object CannotRotateInvalidsuccessorNodeinDelete;
	public const object IndexOutOFRangeinGetNodeByIndex;
	public const object RBDeleteFixup;
	public const object UnsupportedAccessMethod1;
	public const object UnsupportedAccessMethod2;
	public const object UnsupportedAccessMethodInNonNillRootSubtree;
	public const object AttachedNodeWithZerorbTreeNodeId;
	public const object CompareNodeInDataRowTree;
	public const object CompareSateliteTreeNodeInDataRowTree;
	public const object NestedSatelliteTreeEnumerator;
}

// Namespace: System.Data
internal enum TreeAccessMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object KEY_SEARCH_AND_INDEX;
	public const object INDEX_ONLY;
}

// Namespace: 
private enum NodeColor
{

	// Fields
	public object value__; // 0x0
	public const object red;
	public const object black;
}

// Namespace: 
private struct Node
{

	// Fields
	internal object _selfId; // 0x0
	internal object _leftId; // 0x0
	internal object _rightId; // 0x0
	internal object _parentId; // 0x0
	internal object _nextId; // 0x0
	internal object _subTreeSize; // 0x0
	internal object _keyOfNode; // 0x0
	internal object _nodeColor; // 0x0
}

// Namespace: 
private struct NodePath
{

	// Fields
	internal readonly object _nodeID; // 0x0
	internal readonly object _mainTreeNodeID; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor(object nodeID, object mainTreeNodeID) { }

}

// Namespace: 
private sealed class TreePage
{

	// Fields
	internal readonly object _slots; // 0x0
	internal readonly object _slotMap; // 0x0
	private object _inUseCount; // 0x0
	private object _pageId; // 0x0
	private object _nextFreeSlotLine; // 0x0

	// Properties
	internal object InUseCount { get; set; }
	internal object PageId { get; set; }

	// Methods

	// RVA: -1
	internal object .ctor(object size) { }

	// RVA: -1
	internal object AllocSlot(object tree) { }

	// RVA: -1
	internal object get_InUseCount() { }

	// RVA: -1
	internal object set_InUseCount(object value) { }

	// RVA: -1
	internal object get_PageId() { }

	// RVA: -1
	internal object set_PageId(object value) { }

}

// Namespace: 
internal struct RBTreeEnumerator
{

	// Fields
	private readonly object _tree; // 0x0
	private readonly object _version; // 0x0
	private object _index; // 0x0
	private object _mainTreeNodeId; // 0x0
	private object _current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object tree) { }

	// RVA: -1
	internal object .ctor(object tree, object position) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: System.Data
internal abstract class RBTree<T0>
{

	// Fields
	private object _pageTable; // 0x0
	private object _pageTableMap; // 0x0
	private object _inUsePageCount; // 0x0
	private object _nextFreePageLine; // 0x0
	public object root; // 0x0
	private object _version; // 0x0
	private object _inUseNodeCount; // 0x0
	private object _inUseSatelliteTreeCount; // 0x0
	private readonly object _accessMethod; // 0x0

	// Properties
	public object Count { get; }
	public object HasDuplicates { get; }
	public object Item { get; }

	// Methods

	// RVA: -1
	protected abstract object CompareNode(object record1, object record2) { }

	// RVA: -1
	protected abstract object CompareSateliteTreeNode(object record1, object record2) { }

	// RVA: -1
	protected object .ctor(object accessMethod) { }

	// RVA: -1
	private object InitTree() { }

	// RVA: -1
	private object FreePage(object page) { }

	// RVA: -1
	private object AllocPage(object size) { }

	// RVA: -1
	private object MarkPageFull(object page) { }

	// RVA: -1
	private object MarkPageFree(object page) { }

	// RVA: -1
	private static object GetIntValueFromBitMap(object bitMap) { }

	// RVA: -1
	private object FreeNode(object nodeId) { }

	// RVA: -1
	private object GetIndexOfPageWithFreeSlot(object allocatedPage) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_HasDuplicates() { }

	// RVA: -1
	private object GetNewNode(object key) { }

	// RVA: -1
	private object Successor(object x_id) { }

	// RVA: -1
	private object Successor(object nodeId, object mainTreeNodeId) { }

	// RVA: -1
	private object Minimum(object x_id) { }

	// RVA: -1
	private object LeftRotate(object root_id, object x_id, object mainTreeNode) { }

	// RVA: -1
	private object RightRotate(object root_id, object x_id, object mainTreeNode) { }

	// RVA: -1
	private object RBInsert(object root_id, object x_id, object mainTreeNodeID, object position, object append) { }

	// RVA: -1
	public object UpdateNodeKey(object currentKey, object newKey) { }

	// RVA: -1
	public object DeleteByIndex(object i) { }

	// RVA: -1
	public object RBDelete(object z_id) { }

	// RVA: -1
	private object RBDeleteX(object root_id, object z_id, object mainTreeNodeID) { }

	// RVA: -1
	private object RBDeleteFixup(object root_id, object x_id, object px_id, object mainTreeNodeID) { }

	// RVA: -1
	private object SearchSubTree(object root_id, object key) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	private object GetNodeByKey(object key) { }

	// RVA: -1
	public object GetIndexByKey(object key) { }

	// RVA: -1
	public object GetIndexByNode(object node) { }

	// RVA: -1
	private object GetIndexByNodePath(object path) { }

	// RVA: -1
	private object ComputeIndexByNode(object nodeId) { }

	// RVA: -1
	private object ComputeIndexWithSatelliteByNode(object nodeId) { }

	// RVA: -1
	private object GetNodeByIndex(object userIndex) { }

	// RVA: -1
	private object ComputeNodeByIndex(object index, object satelliteRootId) { }

	// RVA: -1
	private object ComputeNodeByIndex(object x_id, object index) { }

	// RVA: -1
	public object Insert(object item) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	public object IndexOf(object nodeId, object item) { }

	// RVA: -1
	public object Insert(object position, object item) { }

	// RVA: -1
	public object InsertAt(object position, object item, object append) { }

	// RVA: -1
	public object RemoveAt(object position) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object CopyTo(object array, object index) { }

	// RVA: -1
	public object CopyTo(object array, object index) { }

	// RVA: -1
	private object SetRight(object nodeId, object rightNodeId) { }

	// RVA: -1
	private object SetLeft(object nodeId, object leftNodeId) { }

	// RVA: -1
	private object SetParent(object nodeId, object parentNodeId) { }

	// RVA: -1
	private object SetColor(object nodeId, object color) { }

	// RVA: -1
	private object SetKey(object nodeId, object key) { }

	// RVA: -1
	private object SetNext(object nodeId, object nextNodeId) { }

	// RVA: -1
	private object SetSubTreeSize(object nodeId, object size) { }

	// RVA: -1
	private object IncreaseSize(object nodeId) { }

	// RVA: -1
	private object RecomputeSize(object nodeId) { }

	// RVA: -1
	private object DecreaseSize(object nodeId) { }

	// RVA: -1
	public object Right(object nodeId) { }

	// RVA: -1
	public object Left(object nodeId) { }

	// RVA: -1
	public object Parent(object nodeId) { }

	// RVA: -1
	private object color(object nodeId) { }

	// RVA: -1
	public object Next(object nodeId) { }

	// RVA: -1
	public object SubTreeSize(object nodeId) { }

	// RVA: -1
	public object Key(object nodeId) { }

}

// Namespace: System.Data
internal sealed class RecordManager
{

	// Fields
	private readonly object _table; // 0x8
	private object _lastFreeRecord; // 0x10
	private object _minimumCapacity; // 0x14
	private object _recordCapacity; // 0x18
	private readonly object _freeRecordList; // 0x20
	private object _rows; // 0x28

	// Properties
	internal object LastFreeRecord { get; }
	internal object MinimumCapacity { get; set; }
	internal object RecordCapacity { get; set; }
	internal object Item { get; set; }

	// Methods

	// RVA: 0x6E16170
	internal object .ctor(object table) { }

	// RVA: 0x6E16240
	private object GrowRecordCapacity() { }

	// RVA: 0x6E16484
	internal object get_LastFreeRecord() { }

	// RVA: 0x6E1648C
	internal object get_MinimumCapacity() { }

	// RVA: 0x6E16494
	internal object set_MinimumCapacity(object value) { }

	// RVA: 0x6E164DC
	internal object get_RecordCapacity() { }

	// RVA: 0x6E16398
	internal object set_RecordCapacity(object value) { }

	// RVA: 0x6E16350
	internal static object NewCapacity(object capacity) { }

	// RVA: 0x6E16364
	private object NormalizedMinimumCapacity(object capacity) { }

	// RVA: 0x6E164E4
	internal object NewRecordBase() { }

	// RVA: 0x6E165D0
	internal object FreeRecord(object record) { }

	// RVA: 0x6E16874
	internal object Clear(object clearAll) { }

	// RVA: 0x6E16B78
	internal object get_Item(object record) { }

	// RVA: 0x6E167FC
	internal object set_Item(object record, object value) { }

	// RVA: 0x6E16BB4
	internal object ImportRecord(object src, object record) { }

	// RVA: 0x6E16BBC
	internal object CopyRecord(object src, object record, object copy) { }

	// RVA: 0x6E17080
	internal object SetRowCache(object newRows) { }

}

// Namespace: System.Data
internal sealed class RelatedView
{

	// Fields
	private readonly object _parentKey; // 0xA8
	private readonly object _childKey; // 0xB8
	private readonly object _parentRowView; // 0xC0
	private readonly object _filterValues; // 0xC8

	// Methods

	// RVA: 0x6E170AC
	public object .ctor(object columns, object values) { }

	// RVA: 0x6E171E8
	public object .ctor(object parentRowView, object parentKey, object childKeyColumns) { }

	// RVA: 0x6E1730C
	private object GetParentValues() { }

	// RVA: 0x6E173D4
	public object Invoke(object row, object version) { }

	// RVA: 0x6E175B0
	internal override object GetFilter() { }

	// RVA: 0x6E175B4
	public override object AddNew() { }

	// RVA: 0x6E1762C
	internal override object SetIndex(object newSort, object newRowStates, object newRowFilter) { }

}

// Namespace: System.Data
internal sealed class RelationshipConverter
{

	// Methods

	// RVA: 0x6E1765C
	public object .ctor() { }

	// RVA: 0x6E17664
	public override object CanConvertTo(object context, object destinationType) { }

	// RVA: 0x6E17730
	public override object ConvertTo(object context, object culture, object value, object destinationType) { }

}

// Namespace: System.Data
public enum Rule
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Cascade;
	public const object SetNull;
	public const object SetDefault;
}

// Namespace: System.Data
public enum SchemaSerializationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IncludeSchema;
	public const object ExcludeSchema;
}

// Namespace: System.Data
internal struct IndexField
{

	// Fields
	public readonly object Column; // 0xFFFFFFFFFFFFFFF8
	public readonly object IsDescending; // 0x0

	// Methods

	// RVA: 0x6E18340
	internal object .ctor(object column, object isDescending) { }

	// RVA: 0x6E18358
	public static object op_Equality(object if1, object if2) { }

	// RVA: 0x6E1836C
	public override object Equals(object obj) { }

	// RVA: 0x6E184CC
	public override object GetHashCode() { }

}

// Namespace: 
private sealed class IndexTree
{

	// Fields
	private readonly object _index; // 0x38

	// Methods

	// RVA: 0x6E1BB30
	internal object .ctor(object index) { }

	// RVA: 0x6E1C770
	protected override object CompareNode(object record1, object record2) { }

	// RVA: 0x6E1C790
	protected override object CompareSateliteTreeNode(object record1, object record2) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__22_0; // 0x8
	public static object <>9__85_0; // 0x10

	// Methods

	// RVA: 0x6E1C7B0
	private static object .cctor() { }

	// RVA: 0x6E1C810
	public object .ctor() { }

	// RVA: 0x6E1C818
	internal object <.ctor>b__22_0(object listener) { }

	// RVA: 0x6E1C824
	internal object <OnListChanged>b__85_0(object listener, object args, object arg2, object arg3) { }

}

// Namespace: 
private sealed class <>c__DisplayClass86_0
{

	// Fields
	public object changedType; // 0x8

	// Methods

	// RVA: 0x6E1BD34
	public object .ctor() { }

	// RVA: 0x6E1C84C
	internal object <MaintainDataView>b__0(object listener, object type, object row, object track) { }

}

// Namespace: System.Data
internal sealed class Index
{

	// Fields
	private readonly object _table; // 0x8
	internal readonly object _indexFields; // 0x10
	private readonly object _comparison; // 0x18
	private readonly object _recordStates; // 0x20
	private object _rowFilter; // 0x28
	private object _records; // 0x30
	private object _recordCount; // 0x38
	private object _refCount; // 0x3C
	private object _listeners; // 0x40
	private object _suspendEvents; // 0x48
	private readonly object _isSharable; // 0x49
	private readonly object _hasRemoteAggregate; // 0x4A
	private static object s_objectTypeCount; // 0x0
	private readonly object _objectID; // 0x4C

	// Properties
	internal object HasRemoteAggregate { get; }
	internal object ObjectID { get; }
	public object RecordStates { get; }
	public object RowFilter { get; }
	public object HasDuplicates { get; }
	public object RecordCount { get; }
	public object RefCount { get; }
	private object DoListChanged { get; }
	internal object Table { get; }

	// Methods

	// RVA: 0x6E1861C
	public object .ctor(object table, object indexFields, object recordStates, object rowFilter) { }

	// RVA: 0x6E18920
	public object .ctor(object table, object comparison, object recordStates, object rowFilter) { }

	// RVA: 0x6E1898C
	private static object GetAllFields(object columns) { }

	// RVA: 0x6E1862C
	private object .ctor(object table, object indexFields, object comparison, object recordStates, object rowFilter) { }

	// RVA: 0x6E18F14
	public object Equal(object indexDesc, object recordStates, object rowFilter) { }

	// RVA: 0x6E18FD8
	internal object get_HasRemoteAggregate() { }

	// RVA: 0x6E18FE0
	internal object get_ObjectID() { }

	// RVA: 0x6E18FE8
	public object get_RecordStates() { }

	// RVA: 0x6E18FF0
	public object get_RowFilter() { }

	// RVA: 0x6E19094
	public object GetRecord(object recordIndex) { }

	// RVA: 0x6E19100
	public object get_HasDuplicates() { }

	// RVA: 0x6E1915C
	public object get_RecordCount() { }

	// RVA: 0x6E19164
	private object AcceptRecord(object record) { }

	// RVA: 0x6E1922C
	private object AcceptRecord(object record, object filter) { }

	// RVA: 0x6E19438
	internal object ListChangedAdd(object listener) { }

	// RVA: 0x6E194A4
	internal object ListChangedRemove(object listener) { }

	// RVA: 0x6E19510
	public object get_RefCount() { }

	// RVA: 0x6E19518
	public object AddRef() { }

	// RVA: 0x6E19838
	public object RemoveRef() { }

	// RVA: 0x6E19A7C
	private object ApplyChangeAction(object record, object action, object changeRecord) { }

	// RVA: 0x6E1A0CC
	public object CheckUnique() { }

	// RVA: 0x6E1A130
	private object CompareRecords(object record1, object record2) { }

	// RVA: 0x6E1A358
	private object CompareDataRows(object record1, object record2) { }

	// RVA: 0x6E1A3DC
	private object CompareDuplicateRecords(object record1, object record2) { }

	// RVA: 0x6E1A5D8
	private object CompareRecordToKey(object record1, object vals) { }

	// RVA: 0x6E1A6E8
	public object DeleteRecordFromIndex(object recordIndex) { }

	// RVA: 0x6E1A058
	private object DeleteRecord(object recordIndex) { }

	// RVA: 0x6E1A6F0
	private object DeleteRecord(object recordIndex, object fireEvent) { }

	// RVA: 0x6E1AAD4
	public object GetEnumerator(object startIndex) { }

	// RVA: 0x6E1A060
	public object GetIndex(object record) { }

	// RVA: 0x6E19E74
	private object GetIndex(object record, object changeRecord) { }

	// RVA: 0x6E0D770
	public object GetUniqueKeyValues() { }

	// RVA: 0x6E1AE94
	private object FindNodeByKey(object originalKey) { }

	// RVA: 0x6E1B150
	private object FindNodeByKeys(object originalKey) { }

	// RVA: 0x6E1B424
	private object FindNodeByKeyRecord(object record) { }

	// RVA: 0x6E1B554
	private object GetRangeFromNode(object nodeId) { }

	// RVA: 0x6E1B6B0
	public object FindRecords(object key) { }

	// RVA: 0x6E0D930
	public object FindRecords(object key) { }

	// RVA: 0x6E1B6E0
	internal object FireResetEvent() { }

	// RVA: 0x6E1BAB8
	private object GetChangeAction(object oldState, object newState) { }

	// RVA: 0x6E1BAD4
	private static object GetReplaceAction(object oldState) { }

	// RVA: 0x6E0E708
	public object GetRow(object i) { }

	// RVA: 0x6E1BAF4
	public object GetRows(object values) { }

	// RVA: 0x6E0D960
	public object GetRows(object range) { }

	// RVA: 0x6E18A7C
	private object InitRecords(object filter) { }

	// RVA: 0x6E1BB94
	public object InsertRecordToIndex(object record) { }

	// RVA: 0x6E19B60
	private object InsertRecord(object record, object fireEvent) { }

	// RVA: 0x6E1BBD8
	public object IsKeyInIndex(object key) { }

	// RVA: 0x6E0D914
	public object IsKeyInIndex(object key) { }

	// RVA: 0x6E1BBF4
	public object IsKeyRecordInIndex(object record) { }

	// RVA: 0x6E1B85C
	private object get_DoListChanged() { }

	// RVA: 0x6E1BC10
	private object OnListChanged(object changedType, object newIndex, object oldIndex) { }

	// RVA: 0x6E1A9C4
	private object OnListChanged(object changedType, object index) { }

	// RVA: 0x6E1B8F8
	private object OnListChanged(object e) { }

	// RVA: 0x6E1A850
	private object MaintainDataView(object changedType, object record, object trackAddRemove) { }

	// RVA: 0x6E1BD3C
	public object Reset() { }

	// RVA: 0x6E1BEA4
	public object RecordChanged(object record) { }

	// RVA: 0x6E1C044
	public object RecordChanged(object oldIndex, object newIndex) { }

	// RVA: 0x6E1C1C4
	public object RecordStateChanged(object record, object oldState, object newState) { }

	// RVA: 0x6E1C2E8
	public object RecordStateChanged(object oldRecord, object oldOldState, object oldNewState, object newRecord, object newOldState, object newNewState) { }

	// RVA: 0x6E1C768
	internal object get_Table() { }

	// RVA: 0x6E1ABCC
	private object GetUniqueKeyValues(object list, object curNodeId) { }

	// RVA: -1
	internal static object IndexOfReference(object list, object item) { }

}

// Namespace: 
internal sealed class Action<T0, T1, T2, T3>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4) { }

}

// Namespace: 
internal sealed class Func<T0, T1>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1) { }

}

// Namespace: System.Data
internal sealed class Listeners<T0>
{

	// Fields
	private readonly object _listeners; // 0x0
	private readonly object _filter; // 0x0
	private readonly object _objectID; // 0x0
	private object _listenerReaderCount; // 0x0

	// Properties
	internal object HasListeners { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object ObjectID, object notifyFilter) { }

	// RVA: -1
	internal object get_HasListeners() { }

	// RVA: -1
	internal object Add(object listener) { }

	// RVA: -1
	internal object IndexOfReference(object listener) { }

	// RVA: -1
	internal object Remove(object listener) { }

	// RVA: -1
	internal object Notify(object arg1, object arg2, object arg3, object action) { }

	// RVA: -1
	private object RemoveNullListeners(object nullIndex) { }

}

// Namespace: System.Data
internal sealed class SimpleType
{

	// Fields
	private object _baseType; // 0x8
	private object _baseSimpleType; // 0x10
	private object _xmlBaseType; // 0x18
	private object _name; // 0x20
	private object _length; // 0x28
	private object _minLength; // 0x2C
	private object _maxLength; // 0x30
	private object _pattern; // 0x38
	private object _ns; // 0x40
	private object _maxExclusive; // 0x48
	private object _maxInclusive; // 0x50
	private object _minExclusive; // 0x58
	private object _minInclusive; // 0x60
	internal object _enumeration; // 0x68

	// Properties
	internal object BaseType { get; }
	internal object XmlBaseType { get; }
	internal object Name { get; }
	internal object Namespace { get; }
	internal object Length { get; }
	internal object MaxLength { get; set; }
	internal object BaseSimpleType { get; }
	public object SimpleTypeQualifiedName { get; }

	// Methods

	// RVA: 0x6E1C880
	internal object .ctor(object baseType) { }

	// RVA: 0x6E1C910
	internal object .ctor(object node) { }

	// RVA: 0x6E1D3AC
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object info, object context) { }

	// RVA: 0x6E1CA58
	internal object LoadTypeValues(object node) { }

	// RVA: 0x6E1D588
	internal object IsPlainString() { }

	// RVA: 0x6E1D840
	internal object get_BaseType() { }

	// RVA: 0x6E1D848
	internal object get_XmlBaseType() { }

	// RVA: 0x6E1D850
	internal object get_Name() { }

	// RVA: 0x6E1D858
	internal object get_Namespace() { }

	// RVA: 0x6E1D860
	internal object get_Length() { }

	// RVA: 0x6E1D868
	internal object get_MaxLength() { }

	// RVA: 0x6E1D870
	internal object set_MaxLength(object value) { }

	// RVA: 0x6E1D878
	internal object get_BaseSimpleType() { }

	// RVA: 0x6E1D880
	public object get_SimpleTypeQualifiedName() { }

	// RVA: 0x6E1D8FC
	internal object QualifiedName(object name) { }

	// RVA: 0x6E1D984
	internal object ToNode(object dc, object prefixes, object inRemoting) { }

	// RVA: 0x6E1E09C
	internal static object CreateEnumeratedType(object values) { }

	// RVA: 0x6E1E184
	internal static object CreateByteArrayType(object encoding) { }

	// RVA: 0x6E1E25C
	internal static object CreateLimitedStringType(object length) { }

	// RVA: 0x6E1E344
	internal static object CreateSimpleType(object typeCode, object type) { }

	// RVA: 0x6E1E4AC
	internal object HasConflictingDefinition(object otherSimpleType) { }

	// RVA: 0x6E1E600
	internal object CanHaveMaxLength() { }

	// RVA: 0x6E1E670
	internal object ConvertToAnnonymousSimpleType() { }

}

// Namespace: System.Data
public class UniqueConstraint
{

	// Fields
	private object _key; // 0x30
	private object _constraintIndex; // 0x38
	internal object _bPrimaryKey; // 0x40
	internal object _constraintName; // 0x48
	internal object _columnNames; // 0x50

	// Properties
	internal object ColumnNames { get; }
	internal object ConstraintIndex { get; }
	public virtual object Columns { get; }
	internal object ColumnsReference { get; }
	public object IsPrimaryKey { get; }
	internal override object InCollection { set; }
	internal object Key { get; }
	public override object Table { get; }

	// Methods

	// RVA: 0x6E1E6F0
	public object .ctor(object column) { }

	// RVA: 0x6E1E8CC
	public object .ctor(object name, object columns) { }

	// RVA: 0x6E1E90C
	public object .ctor(object columns) { }

	// RVA: 0x6E1E940
	public object .ctor(object name, object columnNames, object isPrimaryKey) { }

	// RVA: 0x6E1E980
	public object .ctor(object name, object columns, object isPrimaryKey) { }

	// RVA: 0x6E1E9C8
	internal object get_ColumnNames() { }

	// RVA: 0x6E1E9D4
	internal object get_ConstraintIndex() { }

	// RVA: 0x6E1E9DC
	internal object ConstraintIndexClear() { }

	// RVA: 0x6E1EA08
	internal object ConstraintIndexInitialize() { }

	// RVA: 0x6E1EA58
	internal override object CheckState() { }

	// RVA: 0x6E1EA64
	private object NonVirtualCheckState() { }

	// RVA: 0x6E1EA70
	internal override object CheckCanAddToCollection(object constraints) { }

	// RVA: 0x6E1EA74
	internal override object CanBeRemovedFromCollection(object constraints, object fThrowException) { }

	// RVA: 0x6E1EC84
	internal override object CanEnableConstraint() { }

	// RVA: 0x6E1ED40
	internal override object IsConstraintViolated() { }

	// RVA: 0x6E1F024
	internal override object CheckConstraint(object row, object action) { }

	// RVA: 0x6E1F174
	internal override object ContainsColumn(object column) { }

	// RVA: 0x6E1F180
	internal override object Clone(object destination) { }

	// RVA: 0x6E1F1CC
	internal override object Clone(object destination, object ignorNSforTableLookup) { }

	// RVA: 0x6E1F960
	internal object Clone(object table) { }

	// RVA: 0x6E1FFB4
	public virtual object get_Columns() { }

	// RVA: 0x6E1F16C
	internal object get_ColumnsReference() { }

	// RVA: 0x6E1FFC0
	public object get_IsPrimaryKey() { }

	// RVA: 0x6E1E7AC
	private object Create(object constraintName, object columns) { }

	// RVA: 0x6E20044
	public override object Equals(object key2) { }

	// RVA: 0x6E200FC
	public override object GetHashCode() { }

	// RVA: 0x6E20104
	internal override object set_InCollection(object value) { }

	// RVA: 0x6E20164
	internal object get_Key() { }

	// RVA: 0x6E2016C
	public override object get_Table() { }

}

// Namespace: 
private sealed class NameType
{

	// Fields
	public object name; // 0x8
	public object type; // 0x10

	// Methods

	// RVA: 0x6E24C58
	public object .ctor(object n, object t) { }

	// RVA: 0x6E24C90
	public object CompareTo(object obj) { }

}

// Namespace: System.Data
internal sealed class XDRSchema
{

	// Fields
	internal object _schemaName; // 0x8
	internal object _schemaUri; // 0x10
	internal object _schemaRoot; // 0x18
	internal object _ds; // 0x20
	private static readonly object s_colonArray; // 0x0
	private static object s_mapNameTypeXdr; // 0x8
	private static object s_enumerationNameType; // 0x10

	// Methods

	// RVA: 0x6E201B0
	internal object .ctor(object ds, object fInline) { }

	// RVA: 0x6E20228
	internal object LoadSchema(object schemaRoot, object ds) { }

	// RVA: 0x6E207C8
	internal object FindTypeNode(object node) { }

	// RVA: 0x6E20EC4
	internal object IsTextOnlyContent(object node) { }

	// RVA: 0x6E2112C
	internal object IsXDRField(object node, object typeNode) { }

	// RVA: 0x6E205C0
	internal object HandleTable(object node) { }

	// RVA: 0x6E21F24
	private static object FindNameType(object name) { }

	// RVA: 0x6E22038
	private object ParseDataType(object dt, object dtValues) { }

	// RVA: 0x6E221B8
	internal object GetInstanceName(object node) { }

	// RVA: 0x6E22430
	internal object HandleColumn(object node, object table) { }

	// RVA: 0x6E213FC
	internal object GetMinMax(object elNode, object minOccurs, object maxOccurs) { }

	// RVA: 0x6E23194
	internal object GetMinMax(object elNode, object isAttribute, object minOccurs, object maxOccurs) { }

	// RVA: 0x6E23AFC
	internal object HandleTypeNode(object typeNode, object table, object tableChildren) { }

	// RVA: 0x6E216B4
	internal object InstantiateTable(object dataSet, object node, object typeNode) { }

	// RVA: 0x6E2140C
	internal object InstantiateSimpleTable(object dataSet, object node) { }

	// RVA: 0x6E23E78
	private static object .cctor() { }

}

// Namespace: System.Data
internal sealed class XMLDiffLoader
{

	// Fields
	private object _tables; // 0x8
	private object _dataSet; // 0x10
	private object _dataTable; // 0x18

	// Methods

	// RVA: 0x6E24D10
	internal object LoadDiffGram(object ds, object dataTextReader) { }

	// RVA: 0x6E258F4
	private object CreateTablesHierarchy(object dt) { }

	// RVA: 0x6E25D74
	internal object LoadDiffGram(object dt, object dataTextReader) { }

	// RVA: 0x6E24F00
	internal object ProcessDiffs(object ds, object ssync) { }

	// RVA: 0x6E25FD8
	internal object ProcessDiffs(object tableList, object ssync) { }

	// RVA: 0x6E25350
	internal object ProcessErrors(object ds, object ssync) { }

	// RVA: 0x6E26448
	internal object ProcessErrors(object dt, object ssync) { }

	// RVA: 0x6E27F34
	private object GetTable(object tableName, object ns) { }

	// RVA: 0x6E26BC8
	private object ReadOldRowData(object ds, object table, object pos, object row) { }

	// RVA: 0x6E26B14
	internal object SkipWhitespaces(object reader) { }

	// RVA: 0x6E281BC
	public object .ctor() { }

}

// Namespace: System.Data
internal class XMLSchema
{

	// Methods

	// RVA: 0x6E281C4
	internal static object GetConverter(object type) { }

	// RVA: 0x6E23528
	internal static object SetProperties(object instance, object attrs) { }

	// RVA: 0x6E20508
	internal static object FEqualIdentity(object node, object name, object ns) { }

	// RVA: 0x6E2824C
	internal static object GetBooleanAttribute(object element, object attrName, object attrNS, object defVal) { }

	// RVA: 0x6E23024
	internal static object GenUniqueColumnName(object proposedName, object table) { }

	// RVA: 0x6E20220
	public object .ctor() { }

}

// Namespace: System.Data
internal sealed class ConstraintTable
{

	// Fields
	public object table; // 0x8
	public object constraint; // 0x10

	// Methods

	// RVA: 0x6E283F4
	public object .ctor(object t, object c) { }

}

// Namespace: 
private sealed class NameType
{

	// Fields
	public readonly object name; // 0x8
	public readonly object type; // 0x10

	// Methods

	// RVA: 0x6E3B920
	public object .ctor(object n, object t) { }

	// RVA: 0x6E3B958
	public object CompareTo(object obj) { }

}

// Namespace: System.Data
internal sealed class XSDSchema
{

	// Fields
	private object _schemaSet; // 0x8
	private object _dsElement; // 0x10
	private object _ds; // 0x18
	private object _schemaName; // 0x20
	private object _columnExpressions; // 0x28
	private object _constraintNodes; // 0x30
	private object _refTables; // 0x38
	private object _complexTypes; // 0x40
	private object _annotations; // 0x48
	private object _elements; // 0x50
	private object _attributes; // 0x58
	private object _elementsTable; // 0x60
	private object _attributeGroups; // 0x68
	private object _schemaTypes; // 0x70
	private object _expressions; // 0x78
	private object _tableDictionary; // 0x80
	private object _udSimpleTypes; // 0x88
	private object _existingSimpleTypeMap; // 0x90
	private object _fromInference; // 0x98
	private static readonly object s_mapNameTypeXsd; // 0x0

	// Properties
	internal object FromInference { get; set; }

	// Methods

	// RVA: 0x6E2842C
	internal object get_FromInference() { }

	// RVA: 0x6E28434
	internal object set_FromInference(object value) { }

	// RVA: 0x6E2843C
	private object CollectElementsAnnotations(object schema) { }

	// RVA: 0x6E284E4
	private object CollectElementsAnnotations(object schema, object schemaList) { }

	// RVA: 0x6E1D7B8
	internal static object QualifiedName(object name) { }

	// RVA: 0x6E29064
	internal static object SetProperties(object instance, object attrs) { }

	// RVA: 0x6E29710
	private static object SetExtProperties(object instance, object attrs) { }

	// RVA: 0x6E29BF0
	private object HandleColumnExpression(object instance, object attrs) { }

	// RVA: 0x6E1D3EC
	internal static object GetMsdataAttribute(object node, object ln) { }

	// RVA: 0x6E29E98
	private static object SetExtProperties(object instance, object attrs) { }

	// RVA: 0x6E2A1F0
	internal object HandleRefTableProperties(object RefTables, object element) { }

	// RVA: 0x6E2A424
	internal object HandleRelation(object node, object fNested) { }

	// RVA: 0x6E2AFB0
	private object HasAttributes(object attributes) { }

	// RVA: 0x6E2B238
	private object IsDatasetParticle(object pt) { }

	// RVA: 0x6E2BD04
	private object DatasetElementCount(object elements) { }

	// RVA: 0x6E2C0F4
	private object FindDatasetElement(object elements) { }

	// RVA: 0x6E2C78C
	public object LoadSchema(object schemaSet, object dt) { }

	// RVA: 0x6E2C7B4
	public object LoadSchema(object schemaSet, object ds) { }

	// RVA: 0x6E30750
	private object HandleRelations(object ann, object fNested) { }

	// RVA: 0x6E2B7EC
	internal object GetParticleItems(object pt) { }

	// RVA: 0x6E30AF0
	internal object HandleParticle(object pt, object table, object tableChildren, object isBase) { }

	// RVA: 0x6E326E8
	internal object HandleAttributes(object attributes, object table, object isBase) { }

	// RVA: 0x6E33714
	private object HandleAttributeGroup(object attributeGroup, object table, object isBase) { }

	// RVA: 0x6E33B38
	internal object HandleComplexType(object ct, object table, object tableChildren, object isNillable) { }

	// RVA: 0x6E2C628
	internal object GetParticle(object ct) { }

	// RVA: 0x6E3599C
	internal object FindField(object table, object field) { }

	// RVA: 0x6E35B80
	internal object BuildKey(object keyNode, object table) { }

	// RVA: 0x6E2BF44
	internal object GetBooleanAttribute(object element, object attrName, object defVal) { }

	// RVA: 0x6E2EC3C
	internal object GetStringAttribute(object element, object attrName, object defVal) { }

	// RVA: 0x6E35F3C
	internal static object TranslateAcceptRejectRule(object strRule) { }

	// RVA: 0x6E35FD8
	internal static object TranslateRule(object strRule) { }

	// RVA: 0x6E360F4
	internal object HandleKeyref(object keyref) { }

	// RVA: 0x6E36E70
	internal object HandleConstraint(object keyNode) { }

	// RVA: 0x6E37428
	internal object InstantiateSimpleTable(object node) { }

	// RVA: 0x6E2A310
	internal object GetInstanceName(object node) { }

	// RVA: 0x6E381A0
	internal object InstantiateTable(object node, object typeNode, object isRef) { }

	// RVA: 0x6E39D20
	public static object XsdtoClr(object xsdTypeName) { }

	// RVA: 0x6E39E48
	private static object FindNameType(object name) { }

	// RVA: 0x6E39F5C
	private object ParseDataType(object dt) { }

	// RVA: 0x6E3A174
	internal static object IsXsdType(object name) { }

	// RVA: 0x6E2ECE8
	internal object FindTypeNode(object node) { }

	// RVA: 0x6E34C50
	internal object HandleSimpleTypeSimpleContentColumn(object typeNode, object strType, object table, object isBase, object attrs, object isNillable) { }

	// RVA: 0x6E3427C
	internal object HandleSimpleContentColumn(object strType, object table, object isBase, object attrs, object isNillable) { }

	// RVA: 0x6E32A14
	internal object HandleAttributeColumn(object attrib, object table, object isBase) { }

	// RVA: 0x6E31618
	internal object HandleElementColumn(object elem, object table, object isBase) { }

	// RVA: 0x6E2F26C
	internal object HandleDataSet(object node, object isNewDataSet) { }

	// RVA: 0x6E3A1F0
	private object AddTablesToList(object tableList, object dt) { }

	// RVA: 0x6E37CF4
	private object GetPrefix(object ns) { }

	// RVA: 0x6E3A460
	private object GetNamespaceFromPrefix(object prefix) { }

	// RVA: 0x6E39B60
	private object GetTableNamespace(object key) { }

	// RVA: 0x6E36D08
	private object GetTableName(object key) { }

	// RVA: 0x6E2BA40
	internal object IsTable(object node) { }

	// RVA: 0x6E2F0AC
	internal object HandleTable(object node) { }

	// RVA: 0x6E3A914
	public object .ctor() { }

	// RVA: 0x6E3A91C
	private static object .cctor() { }

}

// Namespace: System.Data
internal sealed class XmlIgnoreNamespaceReader
{

	// Fields
	private object _namespacesToIgnore; // 0x28

	// Methods

	// RVA: 0x6E3B9D8
	internal object .ctor(object xdoc, object namespacesToIgnore) { }

	// RVA: 0x6E3BA74
	public override object MoveToFirstAttribute() { }

	// RVA: 0x6E3BBD8
	public override object MoveToNextAttribute() { }

}

// Namespace: System.Data
internal sealed class XmlDataLoader
{

	// Fields
	private object _dataSet; // 0x8
	private object _nodeToSchemaMap; // 0x10
	private object _nodeToRowMap; // 0x18
	private object _childRowsStack; // 0x20
	private object _htableExcludedNS; // 0x28
	private object _fIsXdr; // 0x30
	internal object _isDiffgram; // 0x31
	private object _topMostNode; // 0x38
	private object _ignoreSchema; // 0x40
	private object _dataTable; // 0x48
	private object _isTableLevel; // 0x50
	private object _fromInference; // 0x51
	private object _dataReader; // 0x58
	private object _XSD_XMLNS_NS; // 0x60
	private object _XDR_SCHEMA; // 0x68
	private object _XDRNS; // 0x70
	private object _SQL_SYNC; // 0x78
	private object _UPDGNS; // 0x80
	private object _XSD_SCHEMA; // 0x88
	private object _XSDNS; // 0x90
	private object _DFFNS; // 0x98
	private object _MSDNS; // 0xA0
	private object _DIFFID; // 0xA8
	private object _HASCHANGES; // 0xB0
	private object _ROWORDER; // 0xB8

	// Properties
	internal object FromInference { get; set; }

	// Methods

	// RVA: 0x6E3BD4C
	internal object .ctor(object dataset, object IsXdr, object ignoreSchema) { }

	// RVA: 0x6E3BDDC
	internal object .ctor(object dataset, object IsXdr, object topNode, object ignoreSchema) { }

	// RVA: 0x6E3BEAC
	internal object .ctor(object datatable, object IsXdr, object ignoreSchema) { }

	// RVA: 0x6E3BF48
	internal object .ctor(object datatable, object IsXdr, object topNode, object ignoreSchema) { }

	// RVA: 0x6E3C024
	internal object get_FromInference() { }

	// RVA: 0x6E3C02C
	internal object set_FromInference(object value) { }

	// RVA: 0x6E3C034
	private object AttachRows(object parentRow, object parentElement) { }

	// RVA: 0x6E3C34C
	private object CountNonNSAttributes(object node) { }

	// RVA: 0x6E3C63C
	private object GetValueForTextOnlyColums(object n) { }

	// RVA: 0x6E3CA5C
	private object GetInitialTextFromNodes(object n) { }

	// RVA: 0x6E3CEC0
	private object GetTextOnlyColumn(object row) { }

	// RVA: 0x6E3C288
	internal object GetRowFromElement(object e) { }

	// RVA: 0x6E3CFFC
	internal object FColumnElement(object e) { }

	// RVA: 0x6E3C570
	private object FExcludedNamespace(object ns) { }

	// RVA: 0x6E3D160
	private object FIgnoreNamespace(object node) { }

	// RVA: 0x6E3D6BC
	private object FIgnoreNamespace(object node) { }

	// RVA: 0x6E3CA00
	internal object IsTextLikeNode(object n) { }

	// RVA: 0x6E3CFA4
	internal object IsTextOnly(object c) { }

	// RVA: 0x6E3D788
	internal object LoadData(object xdoc) { }

	// RVA: 0x6E3DD44
	private object LoadRowData(object row, object rowElement) { }

	// RVA: 0x6E3ECB8
	private object LoadRows(object parentRow, object parentElement) { }

	// RVA: 0x6E3F16C
	private object SetRowValueFromXmlText(object row, object col, object xmlText) { }

	// RVA: 0x6E3F228
	private object InitNameTable() { }

	// RVA: 0x6E3F5E8
	internal object LoadData(object reader) { }

	// RVA: 0x6E3FBB8
	private object LoadTopMostTable(object table) { }

	// RVA: 0x6E40CF8
	private object LoadTable(object table, object isNested) { }

	// RVA: 0x6E421D0
	private object LoadColumn(object column, object foundColumns) { }

	// RVA: 0x6E40930
	private object ProcessXsdSchema() { }

}

// Namespace: System.Data
public enum XmlReadMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object ReadSchema;
	public const object IgnoreSchema;
	public const object InferSchema;
	public const object DiffGram;
	public const object Fragment;
	public const object InferTypedSchema;
}

// Namespace: 
private sealed class XmlNodeIdentety
{

	// Fields
	public object LocalName; // 0x8
	public object NamespaceURI; // 0x10

	// Methods

	// RVA: 0x6E459FC
	public object .ctor(object localName, object namespaceURI) { }

	// RVA: 0x6E46B20
	public override object GetHashCode() { }

	// RVA: 0x6E46B6C
	public override object Equals(object obj) { }

}

// Namespace: 
internal sealed class XmlNodeIdHashtable
{

	// Fields
	private object _id; // 0x48

	// Properties
	public object Item { get; }
	public object Item { get; }
	public object Item { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x6E4621C
	public object .ctor(object capacity) { }

	// RVA: 0x6E46818
	public object get_Item(object node) { }

	// RVA: 0x6E46A44
	public object get_Item(object dataReader) { }

	// RVA: 0x6E46998
	public object get_Item(object table) { }

	// RVA: 0x6E468FC
	public object get_Item(object name) { }

}

// Namespace: 
private sealed class TableSchemaInfo
{

	// Fields
	public object TableSchema; // 0x8
	public object ColumnsSchemaMap; // 0x10

	// Methods

	// RVA: 0x6E458C4
	public object .ctor(object tableSchema) { }

}

// Namespace: System.Data
internal sealed class XmlToDatasetMap
{

	// Fields
	private object _tableSchemaMap; // 0x8
	private object _lastTableSchemaInfo; // 0x10

	// Methods

	// RVA: 0x6E3DB60
	public object .ctor(object dataSet, object nameTable) { }

	// RVA: 0x6E3FB38
	public object .ctor(object nameTable, object dataSet) { }

	// RVA: 0x6E3DB20
	public object .ctor(object dataTable, object nameTable) { }

	// RVA: 0x6E3FB78
	public object .ctor(object nameTable, object dataTable) { }

	// RVA: 0x6E3F1CC
	internal static object IsMappedColumn(object c) { }

	// RVA: 0x6E45728
	private object AddTableSchema(object table, object nameTable) { }

	// RVA: 0x6E45A34
	private object AddTableSchema(object nameTable, object table) { }

	// RVA: 0x6E45C3C
	private object AddColumnSchema(object col, object nameTable, object columns) { }

	// RVA: 0x6E45FCC
	private object AddColumnSchema(object nameTable, object col, object columns) { }

	// RVA: 0x6E4300C
	private object BuildIdentityMap(object dataSet, object nameTable) { }

	// RVA: 0x6E43784
	private object BuildIdentityMap(object nameTable, object dataSet) { }

	// RVA: 0x6E44574
	private object BuildIdentityMap(object dataTable, object nameTable) { }

	// RVA: 0x6E449C0
	private object BuildIdentityMap(object nameTable, object dataTable) { }

	// RVA: 0x6E462BC
	private object GetSelfAndDescendants(object dt) { }

	// RVA: 0x6E3D290
	public object GetColumnSchema(object node, object fIgnoreNamespace) { }

	// RVA: 0x6E41F60
	public object GetColumnSchema(object table, object dataReader, object fIgnoreNamespace) { }

	// RVA: 0x6E3DBA0
	public object GetSchemaForNode(object node, object fIgnoreNamespace) { }

	// RVA: 0x6E407C4
	public object GetTableForNode(object node, object fIgnoreNamespace) { }

	// RVA: 0x6E45DE0
	private object HandleSpecialColumn(object col, object nameTable, object columns) { }

}

// Namespace: System.Data
public enum XmlWriteMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WriteSchema;
	public const object IgnoreSchema;
	public const object DiffGram;
}

// Namespace: System.Data
internal enum SchemaFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Public;
	public const object Remoting;
	public const object WebService;
	public const object RemotingSkipSchema;
	public const object WebServiceSkipSchema;
}

// Namespace: System.Data
internal sealed class XmlTreeGen
{

	// Fields
	private object _constraintNames; // 0x8
	private object _namespaces; // 0x10
	private object _autogenerated; // 0x18
	private object _prefixes; // 0x20
	private object _ds; // 0x28
	private object _tables; // 0x30
	private object _relations; // 0x38
	private object _dc; // 0x40
	private object _sRoot; // 0x48
	private object _prefixCount; // 0x50
	private object _schFormat; // 0x54
	private object _filePath; // 0x58
	private object _fileName; // 0x60
	private object _fileExt; // 0x68
	private object _dsElement; // 0x70
	private object _constraintSeparator; // 0x78
	private object _targetConverter; // 0x80

	// Methods

	// RVA: 0x6E46C1C
	internal object .ctor(object format) { }

	// RVA: 0x6E46CB4
	internal static object AddExtendedProperties(object props, object node) { }

	// RVA: 0x6E46CBC
	internal static object AddExtendedProperties(object props, object node, object type) { }

	// RVA: 0x6E47494
	internal object AddXdoProperties(object instance, object root, object xd) { }

	// RVA: 0x6E47674
	internal object AddXdoProperty(object pd, object instance, object root, object xd) { }

	// RVA: 0x6E4804C
	internal static object XmlDataTypeName(object type) { }

	// RVA: 0x6E490C4
	private object GenerateConstraintNames(object table, object fromTable) { }

	// RVA: 0x6E4970C
	private object GenerateConstraintNames(object tables) { }

	// RVA: 0x6E49820
	private object GenerateConstraintNames(object ds) { }

	// RVA: 0x6E49B7C
	private static object _PropsNotEmpty(object props) { }

	// RVA: 0x6E49BD0
	private object HaveExtendedProperties(object ds) { }

	// RVA: 0x6E49EB4
	internal object WriteSchemaRoot(object xd, object rootSchema, object targetNamespace) { }

	// RVA: 0x6E4A20C
	internal static object ValidateColumnMapping(object columnType) { }

	// RVA: 0x6E4A2BC
	internal object SetupAutoGenerated(object ds) { }

	// RVA: 0x6E4B3E0
	internal object SetupAutoGenerated(object dt) { }

	// RVA: 0x6E4A614
	internal object SetupAutoGenerated(object dt) { }

	// RVA: 0x6E4BCA0
	private object CreateTablesHierarchy(object dt) { }

	// RVA: 0x6E4C120
	private object CreateRelations(object dt) { }

	// RVA: 0x6E4C550
	private object CreateToplevelTables() { }

	// RVA: 0x6E4CA78
	internal object SchemaTree(object xd, object xmlWriter, object ds, object dt, object writeHierarchy) { }

	// RVA: 0x6E51578
	internal object SchemaTree(object xd, object dt) { }

	// RVA: 0x6E501F8
	internal object FillDataSetElement(object xd, object ds, object dt) { }

	// RVA: 0x6E55DD8
	internal object SetPath(object xw) { }

	// RVA: 0x6E5602C
	internal object Save(object ds, object xw) { }

	// RVA: 0x6E5604C
	internal object Save(object dt, object xw) { }

	// RVA: 0x6E56040
	internal object Save(object ds, object dt, object xw) { }

	// RVA: 0x6E5614C
	internal object Save(object ds, object dt, object xw, object writeHierarchy) { }

	// RVA: 0x6E56154
	internal object Save(object ds, object dt, object xw, object writeHierarchy, object multipleTargetConverter) { }

	// RVA: 0x6E50D00
	internal object HandleRelation(object rel, object dc) { }

	// RVA: 0x6E562C4
	private static object FindSimpleType(object schema, object name) { }

	// RVA: 0x6E56424
	internal object GetSchema(object NamespaceURI) { }

	// RVA: 0x6E56798
	internal object HandleColumnType(object col, object dc, object root, object schema) { }

	// RVA: 0x6E56E6C
	internal object AddColumnProperties(object col, object root) { }

	// RVA: 0x6E57674
	private object FindTargetNamespace(object table) { }

	// RVA: 0x6E577F0
	internal object HandleColumn(object col, object dc, object schema, object fWriteOrdinal) { }

	// RVA: 0x6E589F8
	internal static object TranslateAcceptRejectRule(object rule) { }

	// RVA: 0x6E58A80
	internal static object TranslateRule(object rule) { }

	// RVA: 0x6E50C00
	internal object AppendChildWithoutRef(object node, object Namespace, object el, object refString) { }

	// RVA: 0x6E587DC
	internal object FindTypeNode(object node, object strType) { }

	// RVA: 0x6E50BF8
	internal object HandleTable(object table, object dc, object schema) { }

	// RVA: 0x6E58B38
	private object HasMixedColumns(object table) { }

	// RVA: 0x6E4B4F0
	internal static object AutoGenerated(object col) { }

	// RVA: 0x6E58FAC
	internal static object AutoGenerated(object rel) { }

	// RVA: 0x6E4BB5C
	internal static object AutoGenerated(object unique) { }

	// RVA: 0x6E4BB50
	private object AutoGenerated(object fk) { }

	// RVA: 0x6E59120
	internal static object AutoGenerated(object fk, object checkRelation) { }

	// RVA: 0x6E59318
	private object IsAutoGenerated(object o) { }

	// RVA: 0x6E51BFC
	internal object HandleTable(object table, object dc, object schema, object genNested) { }

	// RVA: 0x6E48E74
	private object SetMSDataAttribute(object root, object type) { }

}

// Namespace: System.Data
internal sealed class NewDiffgramGen
{

	// Fields
	internal object _doc; // 0x8
	internal object _ds; // 0x10
	internal object _dt; // 0x18
	internal object _xmlw; // 0x20
	private object _fBefore; // 0x28
	private object _fErrors; // 0x29
	internal object _rowsOrder; // 0x30
	private object _tables; // 0x38
	private object _writeHierarchy; // 0x40

	// Methods

	// RVA: 0x6E59414
	internal object .ctor(object ds) { }

	// RVA: 0x6E598B8
	internal object .ctor(object dt, object writeHierarchy) { }

	// RVA: 0x6E599C8
	private object CreateTableHierarchy(object dt) { }

	// RVA: 0x6E59594
	private object DoAssignments(object tables) { }

	// RVA: 0x6E59E48
	private object EmptyData() { }

	// RVA: 0x6E59FBC
	internal object Save(object xmlw) { }

	// RVA: 0x6E59FC4
	internal object Save(object xmlw, object table) { }

	// RVA: 0x6E5A5E0
	private object GenerateTable(object table) { }

	// RVA: 0x6E5A698
	private object GenerateTableErrors(object table) { }

	// RVA: 0x6E5AE7C
	private object GenerateRow(object row) { }

	// RVA: 0x6E5B6F0
	private object GenerateColumn(object row, object col, object version) { }

	// RVA: 0x6E59398
	internal static object QualifiedName(object prefix, object name) { }

}

// Namespace: System.Data
internal sealed class XmlDataTreeWriter
{

	// Fields
	private object _xmlw; // 0x8
	private object _ds; // 0x10
	private object _dt; // 0x18
	private object _dTables; // 0x20
	private object _topLevelTables; // 0x28
	private object _fFromTable; // 0x30
	private object _isDiffgram; // 0x31
	private object _rowsOrder; // 0x38
	private object _writeHierarchy; // 0x40

	// Methods

	// RVA: 0x6E5C2EC
	internal object .ctor(object ds) { }

	// RVA: 0x6E5C6D0
	internal object .ctor(object dt, object writeHierarchy) { }

	// RVA: 0x6E5CD3C
	private object CreateToplevelTables() { }

	// RVA: 0x6E5C8BC
	private object CreateTablesHierarchy(object dt) { }

	// RVA: 0x6E5D264
	internal static object RowHasErrors(object row) { }

	// RVA: 0x6E5D3B8
	internal object SaveDiffgramData(object xw, object rowsOrder) { }

	// RVA: 0x6E5FA1C
	internal object Save(object xw, object writeSchema) { }

	// RVA: 0x6E605E4
	private object GetNestedChildRelations(object row) { }

	// RVA: 0x6E5DCA8
	internal object XmlDataRowWriter(object row, object encodedTableName) { }

	// RVA: 0x6E609E8
	internal static object PreserveSpace(object value) { }

}

// Namespace: System.Data
internal sealed class DataTextWriter
{

	// Fields
	private object _xmltextWriter; // 0x10

	// Properties
	internal object BaseStream { get; }
	public override object WriteState { get; }

	// Methods

	// RVA: 0x6E5DC40
	internal static object CreateWriter(object xw) { }

	// RVA: 0x6E60AEC
	private object .ctor(object w) { }

	// RVA: 0x6E60B18
	internal object get_BaseStream() { }

	// RVA: 0x6E60BA4
	public override object WriteStartDocument() { }

	// RVA: 0x6E60BF0
	public override object WriteStartDocument(object standalone) { }

	// RVA: 0x6E60C44
	public override object WriteEndDocument() { }

	// RVA: 0x6E60C90
	public override object WriteDocType(object name, object pubid, object sysid, object subset) { }

	// RVA: 0x6E60D0C
	public override object WriteStartElement(object prefix, object localName, object ns) { }

	// RVA: 0x6E60D78
	public override object WriteEndElement() { }

	// RVA: 0x6E60DC4
	public override object WriteFullEndElement() { }

	// RVA: 0x6E60E10
	public override object WriteStartAttribute(object prefix, object localName, object ns) { }

	// RVA: 0x6E60E7C
	public override object WriteEndAttribute() { }

	// RVA: 0x6E60ECC
	public override object WriteCData(object text) { }

	// RVA: 0x6E60F24
	public override object WriteComment(object text) { }

	// RVA: 0x6E60F7C
	public override object WriteProcessingInstruction(object name, object text) { }

	// RVA: 0x6E60FE4
	public override object WriteEntityRef(object name) { }

	// RVA: 0x6E6103C
	public override object WriteCharEntity(object ch) { }

	// RVA: 0x6E61094
	public override object WriteWhitespace(object ws) { }

	// RVA: 0x6E610EC
	public override object WriteString(object text) { }

	// RVA: 0x6E61144
	public override object WriteSurrogateCharEntity(object lowChar, object highChar) { }

	// RVA: 0x6E611AC
	public override object WriteChars(object buffer, object index, object count) { }

	// RVA: 0x6E6121C
	public override object WriteRaw(object buffer, object index, object count) { }

	// RVA: 0x6E6128C
	public override object WriteRaw(object data) { }

	// RVA: 0x6E612E4
	public override object WriteBase64(object buffer, object index, object count) { }

	// RVA: 0x6E61354
	public override object WriteBinHex(object buffer, object index, object count) { }

	// RVA: 0x6E613C4
	public override object get_WriteState() { }

	// RVA: 0x6E61414
	public override object Close() { }

	// RVA: 0x6E61464
	public override object Flush() { }

	// RVA: 0x6E614B4
	public override object LookupPrefix(object ns) { }

}

// Namespace: System.Data
internal sealed class DataTextReader
{

	// Fields
	private object _xmlreader; // 0x8

	// Properties
	public override object Settings { get; }
	public override object NodeType { get; }
	public override object Name { get; }
	public override object LocalName { get; }
	public override object NamespaceURI { get; }
	public override object Prefix { get; }
	public override object Value { get; }
	public override object Depth { get; }
	public override object BaseURI { get; }
	public override object IsEmptyElement { get; }
	public override object IsDefault { get; }
	public override object QuoteChar { get; }
	public override object XmlSpace { get; }
	public override object XmlLang { get; }
	public override object AttributeCount { get; }
	public override object EOF { get; }
	public override object ReadState { get; }
	public override object NameTable { get; }
	public override object CanResolveEntity { get; }
	public override object CanReadValueChunk { get; }

	// Methods

	// RVA: 0x6E6150C
	internal static object CreateReader(object xr) { }

	// RVA: 0x6E615B0
	private object .ctor(object input) { }

	// RVA: 0x6E61620
	public override object get_Settings() { }

	// RVA: 0x6E6166C
	public override object get_NodeType() { }

	// RVA: 0x6E616B8
	public override object get_Name() { }

	// RVA: 0x6E61704
	public override object get_LocalName() { }

	// RVA: 0x6E61750
	public override object get_NamespaceURI() { }

	// RVA: 0x6E6179C
	public override object get_Prefix() { }

	// RVA: 0x6E617E8
	public override object get_Value() { }

	// RVA: 0x6E61834
	public override object get_Depth() { }

	// RVA: 0x6E61880
	public override object get_BaseURI() { }

	// RVA: 0x6E618D0
	public override object get_IsEmptyElement() { }

	// RVA: 0x6E61920
	public override object get_IsDefault() { }

	// RVA: 0x6E61970
	public override object get_QuoteChar() { }

	// RVA: 0x6E619C0
	public override object get_XmlSpace() { }

	// RVA: 0x6E61A10
	public override object get_XmlLang() { }

	// RVA: 0x6E61A60
	public override object get_AttributeCount() { }

	// RVA: 0x6E61AB0
	public override object GetAttribute(object name) { }

	// RVA: 0x6E61B08
	public override object GetAttribute(object localName, object namespaceURI) { }

	// RVA: 0x6E61B70
	public override object GetAttribute(object i) { }

	// RVA: 0x6E61BC8
	public override object MoveToAttribute(object name) { }

	// RVA: 0x6E61C20
	public override object MoveToAttribute(object i) { }

	// RVA: 0x6E61C78
	public override object MoveToFirstAttribute() { }

	// RVA: 0x6E61CC8
	public override object MoveToNextAttribute() { }

	// RVA: 0x6E61D18
	public override object MoveToElement() { }

	// RVA: 0x6E61D68
	public override object ReadAttributeValue() { }

	// RVA: 0x6E61DB8
	public override object Read() { }

	// RVA: 0x6E61E08
	public override object get_EOF() { }

	// RVA: 0x6E61E58
	public override object Close() { }

	// RVA: 0x6E61EA8
	public override object get_ReadState() { }

	// RVA: 0x6E61EF8
	public override object Skip() { }

	// RVA: 0x6E61F48
	public override object get_NameTable() { }

	// RVA: 0x6E61F98
	public override object LookupNamespace(object prefix) { }

	// RVA: 0x6E61FF0
	public override object get_CanResolveEntity() { }

	// RVA: 0x6E62040
	public override object ResolveEntity() { }

	// RVA: 0x6E62090
	public override object get_CanReadValueChunk() { }

	// RVA: 0x6E620E0
	public override object ReadString() { }

}

// Namespace: System.Data.SqlTypes
internal static class SQLResource
{

	// Properties
	internal static object NullString { get; }
	internal static object ArithOverflowMessage { get; }
	internal static object DivideByZeroMessage { get; }
	internal static object NullValueMessage { get; }
	internal static object TruncationMessage { get; }
	internal static object DateTimeOverflowMessage { get; }
	internal static object ConcatDiffCollationMessage { get; }
	internal static object CompareDiffCollationMessage { get; }
	internal static object ConversionOverflowMessage { get; }
	internal static object TimeZoneSpecifiedMessage { get; }
	internal static object InvalidPrecScaleMessage { get; }
	internal static object FormatMessage { get; }

	// Methods

	// RVA: 0x6E62130
	internal static object get_NullString() { }

	// RVA: 0x6E62174
	internal static object get_ArithOverflowMessage() { }

	// RVA: 0x6E621B8
	internal static object get_DivideByZeroMessage() { }

	// RVA: 0x6E621FC
	internal static object get_NullValueMessage() { }

	// RVA: 0x6E62240
	internal static object get_TruncationMessage() { }

	// RVA: 0x6E62284
	internal static object get_DateTimeOverflowMessage() { }

	// RVA: 0x6E622C8
	internal static object get_ConcatDiffCollationMessage() { }

	// RVA: 0x6E6230C
	internal static object get_CompareDiffCollationMessage() { }

	// RVA: 0x6E62350
	internal static object get_ConversionOverflowMessage() { }

	// RVA: 0x6E62394
	internal static object get_TimeZoneSpecifiedMessage() { }

	// RVA: 0x6E623D8
	internal static object get_InvalidPrecScaleMessage() { }

	// RVA: 0x6E6241C
	internal static object get_FormatMessage() { }

	// RVA: 0x6E62460
	internal static object InvalidOpStreamClosed(object method) { }

	// RVA: 0x6E624B8
	internal static object InvalidOpStreamNonWritable(object method) { }

	// RVA: 0x6E62510
	internal static object InvalidOpStreamNonReadable(object method) { }

	// RVA: 0x6E62568
	internal static object InvalidOpStreamNonSeekable(object method) { }

}

// Namespace: System.Data.SqlTypes
public interface INullable
{

	// Properties
	public abstract object IsNull { get; }

	// Methods

	// RVA: -1
	public abstract object get_IsNull() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlBinary
{

	// Fields
	private object _value; // 0xFFFFFFFFFFFFFFF8
	public static readonly object Null; // 0x0

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E62684
	private object .ctor(object fNull) { }

	// RVA: 0x6E62694
	public object .ctor(object value) { }

	// RVA: 0x6E627A4
	public object get_IsNull() { }

	// RVA: 0x6E627C4
	public object get_Value() { }

	// RVA: 0x6E628C4
	public static object op_Implicit(object x) { }

	// RVA: 0x6E62948
	public override object ToString() { }

	// RVA: 0x6E62A90
	private static object PerformCompareByte(object x, object y) { }

	// RVA: 0x6E62BC0
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E62CF0
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E62E0C
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E62F28
	public object CompareTo(object value) { }

	// RVA: 0x6E63068
	public object CompareTo(object value) { }

	// RVA: 0x6E63304
	public override object Equals(object value) { }

	// RVA: 0x6E63514
	internal static object HashByteArray(object rgbValue, object length) { }

	// RVA: 0x6E63584
	public override object GetHashCode() { }

	// RVA: 0x6E636D0
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E636E0
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E63978
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E63AF0
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E63B80
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlBoolean
{

	// Fields
	private object m_value; // 0xFFFFFFFFFFFFFFF8
	public static readonly object True; // 0x0
	public static readonly object False; // 0xFFFFFFFFFFFFFFF1
	public static readonly object Null; // 0xFFFFFFFFFFFFFFF2
	public static readonly object Zero; // 0xFFFFFFFFFFFFFFF3
	public static readonly object One; // 0xFFFFFFFFFFFFFFF4

	// Properties
	public object IsNull { get; }
	public object Value { get; }
	public object IsTrue { get; }
	public object IsFalse { get; }
	public object ByteValue { get; }

	// Methods

	// RVA: 0x6E62CDC
	public object .ctor(object value) { }

	// RVA: 0x6E63BE0
	public object .ctor(object value) { }

	// RVA: 0x6E63C50
	private object .ctor(object value, object fNull) { }

	// RVA: 0x6E63CF8
	public object get_IsNull() { }

	// RVA: 0x6E634B0
	public object get_Value() { }

	// RVA: 0x6E63D74
	public object get_IsTrue() { }

	// RVA: 0x6E63D94
	public object get_IsFalse() { }

	// RVA: 0x6E63DB4
	public static object op_Implicit(object x) { }

	// RVA: 0x6E63294
	public static object op_True(object x) { }

	// RVA: 0x6E63DC4
	public static object op_BitwiseAnd(object x, object y) { }

	// RVA: 0x6E63EC0
	public static object op_BitwiseOr(object x, object y) { }

	// RVA: 0x6E63FA4
	public object get_ByteValue() { }

	// RVA: 0x6E64060
	public override object ToString() { }

	// RVA: 0x6E641B8
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E642A0
	public static object And(object x, object y) { }

	// RVA: 0x6E643DC
	public static object Or(object x, object y) { }

	// RVA: 0x6E64530
	public object CompareTo(object value) { }

	// RVA: 0x6E64670
	public object CompareTo(object value) { }

	// RVA: 0x6E647E0
	public override object Equals(object value) { }

	// RVA: 0x6E64988
	public override object GetHashCode() { }

	// RVA: 0x6E64AB8
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E64AC8
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E64C70
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E64DDC
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E64E6C
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlByte
{

	// Fields
	private object m_fNotNull; // 0xFFFFFFFFFFFFFFF8
	private object m_value; // 0xFFFFFFFFFFFFFFF9
	private static readonly object s_iBitNotByteMax; // 0x0
	public static readonly object Null; // 0xFFFFFFFFFFFFFFF4
	public static readonly object Zero; // 0xFFFFFFFFFFFFFFF6
	public static readonly object MinValue; // 0xFFFFFFFFFFFFFFF8
	public static readonly object MaxValue; // 0xFFFFFFFFFFFFFFFA

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E64F94
	private object .ctor(object fNull) { }

	// RVA: 0x6E64FA4
	public object .ctor(object value) { }

	// RVA: 0x6E64FC4
	public object get_IsNull() { }

	// RVA: 0x6E64FE4
	public object get_Value() { }

	// RVA: 0x6E65088
	public static object op_Implicit(object x) { }

	// RVA: 0x6E65094
	public override object ToString() { }

	// RVA: 0x6E65214
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E65364
	public static object op_Subtraction(object x, object y) { }

	// RVA: 0x6E654AC
	public static object op_Multiply(object x, object y) { }

	// RVA: 0x6E655FC
	public static object op_Division(object x, object y) { }

	// RVA: 0x6E65738
	public static object op_Explicit(object x) { }

	// RVA: 0x6E6592C
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E65A38
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E65B44
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E65C50
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E65CDC
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E65D68
	public object ToSqlDouble() { }

	// RVA: 0x6E65FF0
	public object ToSqlInt64() { }

	// RVA: 0x6E66220
	public object CompareTo(object value) { }

	// RVA: 0x6E66360
	public object CompareTo(object value) { }

	// RVA: 0x6E665A0
	public override object Equals(object value) { }

	// RVA: 0x6E66768
	public override object GetHashCode() { }

	// RVA: 0x6E66868
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E66878
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E66A1C
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E66B98
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E66C28
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
internal enum SqlBytesCharsState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Null;
	public const object Buffer;
	public const object Stream;
}

// Namespace: System.Data.SqlTypes
public sealed class SqlBytes
{

	// Fields
	internal object _rgbBuf; // 0x8
	private object _lCurLen; // 0x10
	internal object _stream; // 0x18
	private object _state; // 0x20
	private object _rgbWorkBuf; // 0x28

	// Properties
	public object IsNull { get; }
	public object Buffer { get; }
	public object Length { get; }
	public object Value { get; }
	public static object Null { get; }

	// Methods

	// RVA: 0x6E66CA4
	public object .ctor() { }

	// RVA: 0x6E66CE4
	public object .ctor(object buffer) { }

	// RVA: 0x6E66D4C
	public object .ctor(object value) { }

	// RVA: 0x6E66E38
	public object get_IsNull() { }

	// RVA: 0x6E66E48
	public object get_Buffer() { }

	// RVA: 0x6E67074
	public object get_Length() { }

	// RVA: 0x6E67114
	public object get_Value() { }

	// RVA: 0x6E66CD4
	public object SetNull() { }

	// RVA: 0x6E66E8C
	private object CopyStreamToBuffer() { }

	// RVA: 0x6E66E7C
	internal object FStream() { }

	// RVA: 0x6E673E4
	private object SetBuffer(object buffer) { }

	// RVA: 0x6E6741C
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E67424
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object r) { }

	// RVA: 0x6E676E4
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E67844
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E678D4
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object info, object context) { }

	// RVA: 0x6E67914
	public static object get_Null() { }

}

// Namespace: System.Data.SqlTypes
public sealed class SqlChars
{

	// Fields
	internal object _rgchBuf; // 0x8
	private object _lCurLen; // 0x10
	internal object _stream; // 0x18
	private object _state; // 0x20
	private object _rgchWorkBuf; // 0x28

	// Properties
	public object IsNull { get; }
	public object Buffer { get; }
	public object Length { get; }
	public object Value { get; }
	public static object Null { get; }

	// Methods

	// RVA: 0x6E67980
	public object .ctor() { }

	// RVA: 0x6E679C0
	public object .ctor(object buffer) { }

	// RVA: 0x6E67A28
	public object .ctor(object value) { }

	// RVA: 0x6E67B44
	public object get_IsNull() { }

	// RVA: 0x6E67B54
	public object get_Buffer() { }

	// RVA: 0x6E67D74
	public object get_Length() { }

	// RVA: 0x6E67E14
	public object get_Value() { }

	// RVA: 0x6E679B0
	public object SetNull() { }

	// RVA: 0x6E67B88
	internal object FStream() { }

	// RVA: 0x6E67B98
	private object CopyStreamToBuffer() { }

	// RVA: 0x6E680D8
	private object SetBuffer(object buffer) { }

	// RVA: 0x6E68110
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E68118
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object r) { }

	// RVA: 0x6E682BC
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E683F8
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E68488
	private object System.Runtime.Serialization.ISerializable.GetObjectData(object info, object context) { }

	// RVA: 0x6E684C8
	public static object get_Null() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlDateTime
{

	// Fields
	private object m_fNotNull; // 0xFFFFFFFFFFFFFFF8
	private object m_day; // 0xFFFFFFFFFFFFFFFC
	private object m_time; // 0x0
	private static readonly object s_SQLTicksPerMillisecond; // 0x0
	public static readonly object SQLTicksPerSecond; // 0xFFFFFFFFFFFFFFF8
	public static readonly object SQLTicksPerMinute; // 0xFFFFFFFFFFFFFFFC
	public static readonly object SQLTicksPerHour; // 0x0
	private static readonly object s_SQLTicksPerDay; // 0x4
	private static readonly object s_ticksPerSecond; // 0x8
	private static readonly object s_SQLBaseDate; // 0x10
	private static readonly object s_SQLBaseDateTicks; // 0x18
	private static readonly object s_minYear; // 0x20
	private static readonly object s_maxYear; // 0x24
	private static readonly object s_minDay; // 0x28
	private static readonly object s_maxDay; // 0x2C
	private static readonly object s_minTime; // 0x30
	private static readonly object s_maxTime; // 0x34
	private static readonly object s_dayBase; // 0x38
	private static readonly object s_daysToMonth365; // 0x40
	private static readonly object s_daysToMonth366; // 0x48
	private static readonly object s_minDateTime; // 0x50
	private static readonly object s_maxDateTime; // 0x58
	private static readonly object s_minTimeSpan; // 0x60
	private static readonly object s_maxTimeSpan; // 0x68
	private static readonly object s_ISO8601_DateTimeFormat; // 0x70
	private static readonly object s_dateTimeFormats; // 0x78
	public static readonly object MinValue; // 0x80
	public static readonly object MaxValue; // 0x8C
	public static readonly object Null; // 0x98

	// Properties
	public object IsNull { get; }
	public object Value { get; }
	public object DayTicks { get; }
	public object TimeTicks { get; }

	// Methods

	// RVA: 0x6E68568
	private object .ctor(object fNull) { }

	// RVA: 0x6E68580
	public object .ctor(object value) { }

	// RVA: 0x6E68788
	public object .ctor(object dayTicks, object timeTicks) { }

	// RVA: 0x6E688E0
	public object get_IsNull() { }

	// RVA: 0x6E68900
	private static object ToTimeSpan(object value) { }

	// RVA: 0x6E689AC
	private static object ToDateTime(object value) { }

	// RVA: 0x6E68B08
	private static object FromTimeSpan(object value) { }

	// RVA: 0x6E685F0
	private static object FromDateTime(object value) { }

	// RVA: 0x6E68D70
	public object get_Value() { }

	// RVA: 0x6E68E30
	public object get_DayTicks() { }

	// RVA: 0x6E68ED4
	public object get_TimeTicks() { }

	// RVA: 0x6E68F78
	public static object op_Implicit(object value) { }

	// RVA: 0x6E68FE0
	public override object ToString() { }

	// RVA: 0x6E69104
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E69210
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E69340
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E69470
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E694F0
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E69570
	public object CompareTo(object value) { }

	// RVA: 0x6E696BC
	public object CompareTo(object value) { }

	// RVA: 0x6E69930
	public override object Equals(object value) { }

	// RVA: 0x6E69B10
	public override object GetHashCode() { }

	// RVA: 0x6E69C18
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E69C28
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E69EA8
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E6A050
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E6A0E0
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlDecimal
{

	// Fields
	internal object _bStatus; // 0xFFFFFFFFFFFFFFF8
	internal object _bLen; // 0xFFFFFFFFFFFFFFF9
	internal object _bPrec; // 0xFFFFFFFFFFFFFFFA
	internal object _bScale; // 0xFFFFFFFFFFFFFFFB
	internal object _data1; // 0xFFFFFFFFFFFFFFFC
	internal object _data2; // 0x0
	internal object _data3; // 0x4
	internal object _data4; // 0x8
	private static readonly object s_NUMERIC_MAX_PRECISION; // 0x0
	public static readonly object MaxPrecision; // 0xFFFFFFFFFFFFFFF1
	public static readonly object MaxScale; // 0xFFFFFFFFFFFFFFF2
	private static readonly object s_bNullMask; // 0xFFFFFFFFFFFFFFF3
	private static readonly object s_bIsNull; // 0xFFFFFFFFFFFFFFF4
	private static readonly object s_bNotNull; // 0xFFFFFFFFFFFFFFF5
	private static readonly object s_bReverseNullMask; // 0xFFFFFFFFFFFFFFF6
	private static readonly object s_bSignMask; // 0xFFFFFFFFFFFFFFF7
	private static readonly object s_bPositive; // 0xFFFFFFFFFFFFFFF8
	private static readonly object s_bNegative; // 0xFFFFFFFFFFFFFFF9
	private static readonly object s_bReverseSignMask; // 0xFFFFFFFFFFFFFFFA
	private static readonly object s_uiZero; // 0xFFFFFFFFFFFFFFFC
	private static readonly object s_cNumeMax; // 0x0
	private static readonly object s_lInt32Base; // 0x8
	private static readonly object s_ulInt32Base; // 0x10
	private static readonly object s_ulInt32BaseForMod; // 0x18
	internal static readonly object s_llMax; // 0x20
	private static readonly object s_ulBase10; // 0x28
	private static readonly object s_DUINT_BASE; // 0x30
	private static readonly object s_DUINT_BASE2; // 0x38
	private static readonly object s_DUINT_BASE3; // 0x40
	private static readonly object s_DMAX_NUME; // 0x48
	private static readonly object s_DBL_DIG; // 0x50
	private static readonly object s_cNumeDivScaleMin; // 0x54
	private static readonly object s_rgulShiftBase; // 0x58
	private static readonly object s_decimalHelpersLo; // 0x60
	private static readonly object s_decimalHelpersMid; // 0x68
	private static readonly object s_decimalHelpersHi; // 0x70
	private static readonly object s_decimalHelpersHiHi; // 0x78
	private static readonly object s_rgCLenFromPrec; // 0x80
	private static readonly object s_ulT1; // 0x88
	private static readonly object s_ulT2; // 0x8C
	private static readonly object s_ulT3; // 0x90
	private static readonly object s_ulT4; // 0x94
	private static readonly object s_ulT5; // 0x98
	private static readonly object s_ulT6; // 0x9C
	private static readonly object s_ulT7; // 0xA0
	private static readonly object s_ulT8; // 0xA4
	private static readonly object s_ulT9; // 0xA8
	private static readonly object s_dwlT10; // 0xB0
	private static readonly object s_dwlT11; // 0xB8
	private static readonly object s_dwlT12; // 0xC0
	private static readonly object s_dwlT13; // 0xC8
	private static readonly object s_dwlT14; // 0xD0
	private static readonly object s_dwlT15; // 0xD8
	private static readonly object s_dwlT16; // 0xE0
	private static readonly object s_dwlT17; // 0xE8
	private static readonly object s_dwlT18; // 0xF0
	private static readonly object s_dwlT19; // 0xF8
	public static readonly object Null; // 0x100
	public static readonly object MinValue; // 0x114
	public static readonly object MaxValue; // 0x128

	// Properties
	public object IsNull { get; }
	public object Value { get; }
	public object IsPositive { get; }
	public object Scale { get; }
	public object Data { get; }

	// Methods

	// RVA: 0x6E6A4E4
	private object CalculatePrecision() { }

	// RVA: 0x6E6A770
	private object VerifyPrecision(object precision) { }

	// RVA: 0x6E6AA54
	private object .ctor(object fNull) { }

	// RVA: 0x6E6AB3C
	public object .ctor(object value) { }

	// RVA: 0x6E6AD44
	public object .ctor(object value) { }

	// RVA: 0x6E6B068
	public object .ctor(object value) { }

	// RVA: 0x6E6B56C
	private object .ctor(object rglData, object bLen, object bPrec, object bScale, object fPositive) { }

	// RVA: 0x6E6B8E0
	public object get_IsNull() { }

	// RVA: 0x6E6B9D8
	public object get_Value() { }

	// RVA: 0x6E6BCC8
	public object get_IsPositive() { }

	// RVA: 0x6E6B864
	private object SetPositive() { }

	// RVA: 0x6E6BE90
	private object SetSignBit(object fPositive) { }

	// RVA: 0x6E6BFE0
	public object get_Scale() { }

	// RVA: 0x6E6C10C
	public object get_Data() { }

	// RVA: 0x6E6C2A8
	public override object ToString() { }

	// RVA: 0x6E6C96C
	public static object Parse(object s) { }

	// RVA: 0x6E6D51C
	public object ToDouble() { }

	// RVA: 0x6E6BA58
	private object ToDecimal() { }

	// RVA: 0x6E6D704
	public static object op_Implicit(object x) { }

	// RVA: 0x6E6D71C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E6D794
	public static object op_UnaryNegation(object x) { }

	// RVA: 0x6E6DA34
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E6E7F4
	public static object op_Subtraction(object x, object y) { }

	// RVA: 0x6E6E8A4
	public static object op_Multiply(object x, object y) { }

	// RVA: 0x6E6F598
	public static object op_Division(object x, object y) { }

	// RVA: 0x6E7064C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7076C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E708F0
	public static object op_Implicit(object x) { }

	// RVA: 0x6E70AB0
	public static object op_Implicit(object x) { }

	// RVA: 0x6E70BE0
	public static object op_Implicit(object x) { }

	// RVA: 0x6E705A0
	private static object ZeroToMaxLen(object rgulData, object cUI4sCur) { }

	// RVA: 0x6E6B844
	private object FZero() { }

	// RVA: 0x6E6E78C
	private object FGt10_38() { }

	// RVA: 0x6E70EAC
	private object FGt10_38(object rglData) { }

	// RVA: 0x6E6AE48
	private static object BGetPrecUI4(object value) { }

	// RVA: 0x6E6B158
	private static object BGetPrecUI8(object dwlVal) { }

	// RVA: 0x6E6D2D0
	private object AddULong(object ulAdd) { }

	// RVA: 0x6E6D030
	private object MultByULong(object uiMultiplier) { }

	// RVA: 0x6E71038
	private object DivByULong(object iDivisor) { }

	// RVA: 0x6E6E1E0
	internal object AdjustScale(object digits, object fRound) { }

	// RVA: 0x6E6E5F0
	private object LAbsCmp(object snumOp) { }

	// RVA: 0x6E71270
	private static object MpMove(object rgulS, object ciulS, object rgulD, object ciulD) { }

	// RVA: 0x6E712F0
	private static object MpSet(object rgulD, object ciulD, object iulN) { }

	// RVA: 0x6E71328
	private static object MpNormalize(object rgulU, object ciulU) { }

	// RVA: 0x6E7138C
	private static object MpMul1(object piulD, object ciulD, object iulX) { }

	// RVA: 0x6E6C810
	private static object MpDiv1(object rgulU, object ciulU, object iulD, object iulR) { }

	// RVA: 0x6E7149C
	internal static object DWL(object lo, object hi) { }

	// RVA: 0x6E71490
	private static object HI(object x) { }

	// RVA: 0x6E71498
	private static object LO(object x) { }

	// RVA: 0x6E6FB38
	private static object MpDiv(object rgulU, object ciulU, object rgulD, object ciulD, object rgulQ, object ciulQ, object rgulR, object ciulR) { }

	// RVA: 0x6E714A8
	private object CompareNm(object snumOp) { }

	// RVA: 0x6E6B764
	private static object CheckValidPrecScale(object bPrec, object bScale) { }

	// RVA: 0x6E71788
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E71990
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E71B98
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E71DA0
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E71E34
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E71EC8
	public object ToSqlDouble() { }

	// RVA: 0x6E72160
	public object ToSqlInt64() { }

	// RVA: 0x6E724C4
	public object ToSqlMoney() { }

	// RVA: 0x6E6C958
	private static object ChFromDigit(object uiDigit) { }

	// RVA: 0x6E70FC4
	private object StoreFromWorkingArray(object rguiData) { }

	// RVA: 0x6E6CFAC
	private object SetToZero() { }

	// RVA: 0x6E72864
	public object CompareTo(object value) { }

	// RVA: 0x6E729A4
	public object CompareTo(object value) { }

	// RVA: 0x6E72D74
	public override object Equals(object value) { }

	// RVA: 0x6E7311C
	public override object GetHashCode() { }

	// RVA: 0x6E732D8
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E732E8
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E734D0
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E736A0
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E73730
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlDouble
{

	// Fields
	private object m_fNotNull; // 0xFFFFFFFFFFFFFFF8
	private object m_value; // 0x0
	public static readonly object Null; // 0x0
	public static readonly object Zero; // 0x0
	public static readonly object MinValue; // 0x10
	public static readonly object MaxValue; // 0x20

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E73AE8
	private object .ctor(object fNull) { }

	// RVA: 0x6E73B00
	public object .ctor(object value) { }

	// RVA: 0x6E73BD8
	public object get_IsNull() { }

	// RVA: 0x6E73BF8
	public object get_Value() { }

	// RVA: 0x6E73C9C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E73D04
	public override object ToString() { }

	// RVA: 0x6E73E84
	public static object op_UnaryNegation(object x) { }

	// RVA: 0x6E73F90
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E74138
	public static object op_Subtraction(object x, object y) { }

	// RVA: 0x6E742E0
	public static object op_Multiply(object x, object y) { }

	// RVA: 0x6E74488
	public static object op_Division(object x, object y) { }

	// RVA: 0x6E65DF0
	public static object op_Implicit(object x) { }

	// RVA: 0x6E74664
	public static object op_Implicit(object x) { }

	// RVA: 0x6E747D0
	public static object op_Implicit(object x) { }

	// RVA: 0x6E74914
	public static object op_Implicit(object x) { }

	// RVA: 0x6E74A7C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E74BC4
	public static object op_Implicit(object x) { }

	// RVA: 0x6E71F44
	public static object op_Implicit(object x) { }

	// RVA: 0x6E74E9C
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E74FA4
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E750AC
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E751B4
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E75234
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E752B4
	public object ToSqlSingle() { }

	// RVA: 0x6E7538C
	public object CompareTo(object value) { }

	// RVA: 0x6E754D4
	public object CompareTo(object value) { }

	// RVA: 0x6E75738
	public override object Equals(object value) { }

	// RVA: 0x6E75910
	public override object GetHashCode() { }

	// RVA: 0x6E75A0C
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E75A1C
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E75BC0
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E75D48
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E75DD8
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlGuid
{

	// Fields
	private static readonly object s_sizeOfGuid; // 0x0
	private static readonly object s_rgiGuidOrder; // 0xFFFFFFFFFFFFFFF8
	private object m_value; // 0xFFFFFFFFFFFFFFF8
	public static readonly object Null; // 0x0

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E75F30
	private object .ctor(object fNull) { }

	// RVA: 0x6E75F40
	public object .ctor(object g) { }

	// RVA: 0x6E75FB0
	public object get_IsNull() { }

	// RVA: 0x6E75FD0
	public object get_Value() { }

	// RVA: 0x6E760A0
	public static object op_Implicit(object x) { }

	// RVA: 0x6E760C8
	public override object ToString() { }

	// RVA: 0x6E76288
	private static object Compare(object x, object y) { }

	// RVA: 0x6E76458
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E76568
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E76678
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E76788
	public object CompareTo(object value) { }

	// RVA: 0x6E768C8
	public object CompareTo(object value) { }

	// RVA: 0x6E76AFC
	public override object Equals(object value) { }

	// RVA: 0x6E76CB0
	public override object GetHashCode() { }

	// RVA: 0x6E76E30
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E76E40
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E76FDC
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E77174
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E77204
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlInt16
{

	// Fields
	private object m_fNotNull; // 0xFFFFFFFFFFFFFFF8
	private object m_value; // 0xFFFFFFFFFFFFFFFA
	private static readonly object s_MASKI2; // 0x0
	public static readonly object Null; // 0xFFFFFFFFFFFFFFF4
	public static readonly object Zero; // 0xFFFFFFFFFFFFFFF8
	public static readonly object MinValue; // 0xFFFFFFFFFFFFFFFC
	public static readonly object MaxValue; // 0x0

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E772E0
	private object .ctor(object fNull) { }

	// RVA: 0x6E772F8
	public object .ctor(object value) { }

	// RVA: 0x6E7088C
	public object get_IsNull() { }

	// RVA: 0x6E7089C
	public object get_Value() { }

	// RVA: 0x6E77378
	public static object op_Implicit(object x) { }

	// RVA: 0x6E77384
	public override object ToString() { }

	// RVA: 0x6E77504
	public static object op_UnaryNegation(object x) { }

	// RVA: 0x6E775D8
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E77728
	public static object op_Subtraction(object x, object y) { }

	// RVA: 0x6E77878
	public static object op_Multiply(object x, object y) { }

	// RVA: 0x6E77A0C
	public static object op_Division(object x, object y) { }

	// RVA: 0x6E77BBC
	public static object op_Implicit(object x) { }

	// RVA: 0x6E77CE4
	public static object op_Explicit(object x) { }

	// RVA: 0x6E77E58
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E77F60
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E78068
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E78170
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E781FC
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E78288
	public object ToSqlDouble() { }

	// RVA: 0x6E78398
	public object ToSqlInt64() { }

	// RVA: 0x6E785C8
	public object CompareTo(object value) { }

	// RVA: 0x6E78708
	public object CompareTo(object value) { }

	// RVA: 0x6E7894C
	public override object Equals(object value) { }

	// RVA: 0x6E78B0C
	public override object GetHashCode() { }

	// RVA: 0x6E78C0C
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E78C1C
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E78DC0
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E78F3C
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E78FCC
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlInt32
{

	// Fields
	private object m_fNotNull; // 0xFFFFFFFFFFFFFFF8
	private object m_value; // 0xFFFFFFFFFFFFFFFC
	private static readonly object s_iIntMin; // 0x0
	private static readonly object s_lBitNotIntMax; // 0xFFFFFFFFFFFFFFF8
	public static readonly object Null; // 0x0
	public static readonly object Zero; // 0x8
	public static readonly object MinValue; // 0x10
	public static readonly object MaxValue; // 0x18

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E79078
	private object .ctor(object fNull) { }

	// RVA: 0x6E79090
	public object .ctor(object value) { }

	// RVA: 0x6E709F0
	public object get_IsNull() { }

	// RVA: 0x6E70A00
	public object get_Value() { }

	// RVA: 0x6E790C8
	public static object op_Implicit(object x) { }

	// RVA: 0x6E790D4
	public override object ToString() { }

	// RVA: 0x6E79254
	public static object op_UnaryNegation(object x) { }

	// RVA: 0x6E79324
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E794A4
	public static object op_Subtraction(object x, object y) { }

	// RVA: 0x6E79618
	public static object op_Multiply(object x, object y) { }

	// RVA: 0x6E797AC
	public static object op_Division(object x, object y) { }

	// RVA: 0x6E79960
	public static object op_Implicit(object x) { }

	// RVA: 0x6E79A88
	public static object op_Implicit(object x) { }

	// RVA: 0x6E79BB0
	public static object op_Explicit(object x) { }

	// RVA: 0x6E79498
	private static object SameSignInt(object x, object y) { }

	// RVA: 0x6E79D24
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E79E30
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E79F3C
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E7A048
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E7A0D4
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E7A160
	public object ToSqlDouble() { }

	// RVA: 0x6E7A270
	public object ToSqlInt64() { }

	// RVA: 0x6E7A468
	public object CompareTo(object value) { }

	// RVA: 0x6E7A5A8
	public object CompareTo(object value) { }

	// RVA: 0x6E7A7E4
	public override object Equals(object value) { }

	// RVA: 0x6E7A9A4
	public override object GetHashCode() { }

	// RVA: 0x6E7AB24
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E7AB34
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E7ACD8
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E7AE54
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E7AEE4
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlInt64
{

	// Fields
	private object m_fNotNull; // 0xFFFFFFFFFFFFFFF8
	private object m_value; // 0x0
	private static readonly object s_lLowIntMask; // 0x0
	private static readonly object s_lHighIntMask; // 0xFFFFFFFFFFFFFFF8
	public static readonly object Null; // 0x0
	public static readonly object Zero; // 0x10
	public static readonly object MinValue; // 0x20
	public static readonly object MaxValue; // 0x30

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E7AF98
	private object .ctor(object fNull) { }

	// RVA: 0x6E7AFB0
	public object .ctor(object value) { }

	// RVA: 0x6E658C8
	public object get_IsNull() { }

	// RVA: 0x6E658D8
	public object get_Value() { }

	// RVA: 0x6E7B030
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7B03C
	public override object ToString() { }

	// RVA: 0x6E7B1BC
	public static object op_UnaryNegation(object x) { }

	// RVA: 0x6E7B284
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E7B418
	public static object op_Subtraction(object x, object y) { }

	// RVA: 0x6E7B59C
	public static object op_Multiply(object x, object y) { }

	// RVA: 0x6E7B73C
	public static object op_Division(object x, object y) { }

	// RVA: 0x6E7B8C4
	public static object op_Modulus(object x, object y) { }

	// RVA: 0x6E66078
	public static object op_Implicit(object x) { }

	// RVA: 0x6E78420
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7A2F8
	public static object op_Implicit(object x) { }

	// RVA: 0x6E721DC
	public static object op_Explicit(object x) { }

	// RVA: 0x6E7B408
	private static object SameSignLong(object x, object y) { }

	// RVA: 0x6E7BA50
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E7BB50
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E7BC50
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E7BD50
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E7BDD0
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E7BE50
	public object ToSqlByte() { }

	// RVA: 0x6E7BF70
	public object ToSqlDouble() { }

	// RVA: 0x6E7C090
	public object ToSqlInt16() { }

	// RVA: 0x6E7C1B0
	public object ToSqlInt32() { }

	// RVA: 0x6E7C2D0
	public object ToSqlDecimal() { }

	// RVA: 0x6E7C3B0
	public object CompareTo(object value) { }

	// RVA: 0x6E7C4F8
	public object CompareTo(object value) { }

	// RVA: 0x6E7C75C
	public override object Equals(object value) { }

	// RVA: 0x6E7C934
	public override object GetHashCode() { }

	// RVA: 0x6E7CA34
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E7CA44
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E7CBE8
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E7CD64
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E7CDF4
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlMoney
{

	// Fields
	private object _fNotNull; // 0xFFFFFFFFFFFFFFF8
	private object _value; // 0x0
	internal static readonly object s_iMoneyScale; // 0x0
	private static readonly object s_lTickBase; // 0xFFFFFFFFFFFFFFF8
	private static readonly object s_dTickBase; // 0x0
	private static readonly object s_minLong; // 0x8
	private static readonly object s_maxLong; // 0x10
	public static readonly object Null; // 0x18
	public static readonly object Zero; // 0x28
	public static readonly object MinValue; // 0x38
	public static readonly object MaxValue; // 0x48

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E7CEC4
	private object .ctor(object fNull) { }

	// RVA: 0x6E7CEDC
	internal object .ctor(object value, object ignored) { }

	// RVA: 0x6E7CEFC
	public object .ctor(object value) { }

	// RVA: 0x6E7CFFC
	public object .ctor(object value) { }

	// RVA: 0x6E7D120
	public object .ctor(object value) { }

	// RVA: 0x6E70CEC
	public object get_IsNull() { }

	// RVA: 0x6E7D2B8
	public object get_Value() { }

	// RVA: 0x6E70CFC
	public object ToDecimal() { }

	// RVA: 0x6E74DC0
	public object ToDouble() { }

	// RVA: 0x6E7D44C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7D47C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7D4E8
	public override object ToString() { }

	// RVA: 0x6E7D648
	public static object op_UnaryNegation(object x) { }

	// RVA: 0x6E7D774
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E7D94C
	public static object op_Subtraction(object x, object y) { }

	// RVA: 0x6E7DB24
	public static object op_Multiply(object x, object y) { }

	// RVA: 0x6E7DC94
	public static object op_Division(object x, object y) { }

	// RVA: 0x6E7DE04
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7DF6C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7E0D8
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7E234
	public static object op_Implicit(object x) { }

	// RVA: 0x6E72540
	public static object op_Explicit(object x) { }

	// RVA: 0x6E7E360
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E7E460
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E7E560
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E7E660
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E7E6E0
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E7E760
	public object ToSqlDouble() { }

	// RVA: 0x6E7E880
	public object ToSqlDecimal() { }

	// RVA: 0x6E7E960
	public object CompareTo(object value) { }

	// RVA: 0x6E7EAA8
	public object CompareTo(object value) { }

	// RVA: 0x6E7ED0C
	public override object Equals(object value) { }

	// RVA: 0x6E7EEE4
	public override object GetHashCode() { }

	// RVA: 0x6E7F00C
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E7F01C
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E7F210
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E7F3D0
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E7F460
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public struct SqlSingle
{

	// Fields
	private object _fNotNull; // 0xFFFFFFFFFFFFFFF8
	private object _value; // 0xFFFFFFFFFFFFFFFC
	public static readonly object Null; // 0x0
	public static readonly object Zero; // 0xFFFFFFFFFFFFFFF8
	public static readonly object MinValue; // 0x0
	public static readonly object MaxValue; // 0x8

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E7F578
	private object .ctor(object fNull) { }

	// RVA: 0x6E7F590
	public object .ctor(object value) { }

	// RVA: 0x6E7F678
	public object .ctor(object value) { }

	// RVA: 0x6E7F774
	public object get_IsNull() { }

	// RVA: 0x6E7F794
	public object get_Value() { }

	// RVA: 0x6E7F874
	public static object op_Implicit(object x) { }

	// RVA: 0x6E7F8E8
	public override object ToString() { }

	// RVA: 0x6E7FA18
	public static object op_UnaryNegation(object x) { }

	// RVA: 0x6E7FB34
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E7FCE0
	public static object op_Subtraction(object x, object y) { }

	// RVA: 0x6E7FE8C
	public static object op_Multiply(object x, object y) { }

	// RVA: 0x6E80038
	public static object op_Division(object x, object y) { }

	// RVA: 0x6E8021C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E8031C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E8041C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E8051C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E8061C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E80714
	public static object op_Implicit(object x) { }

	// RVA: 0x6E80818
	public static object op_Explicit(object x) { }

	// RVA: 0x6E80910
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E80A30
	public static object op_LessThan(object x, object y) { }

	// RVA: 0x6E80B50
	public static object op_GreaterThan(object x, object y) { }

	// RVA: 0x6E80C70
	public static object LessThan(object x, object y) { }

	// RVA: 0x6E80CFC
	public static object GreaterThan(object x, object y) { }

	// RVA: 0x6E80D88
	public object ToSqlDouble() { }

	// RVA: 0x6E80EA8
	public object CompareTo(object value) { }

	// RVA: 0x6E80FE4
	public object CompareTo(object value) { }

	// RVA: 0x6E81314
	public override object Equals(object value) { }

	// RVA: 0x6E814A0
	public override object GetHashCode() { }

	// RVA: 0x6E8159C
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E815AC
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E81750
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E818D8
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E81968
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
public enum SqlCompareOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object IgnoreCase;
	public const object IgnoreNonSpace;
	public const object IgnoreKanaType;
	public const object IgnoreWidth;
	public const object BinarySort;
	public const object BinarySort2;
}

// Namespace: System.Data.SqlTypes
public struct SqlString
{

	// Fields
	private object m_value; // 0xFFFFFFFFFFFFFFF8
	private object m_cmpInfo; // 0x0
	private object m_lcid; // 0x8
	private object m_flag; // 0xC
	private object m_fNotNull; // 0x10
	public static readonly object Null; // 0x0
	internal static readonly object s_unicodeEncoding; // 0x10
	public static readonly object IgnoreCase; // 0x18
	public static readonly object IgnoreWidth; // 0x1C
	public static readonly object IgnoreNonSpace; // 0x20
	public static readonly object IgnoreKanaType; // 0x24
	public static readonly object BinarySort; // 0x28
	public static readonly object BinarySort2; // 0x2C
	private static readonly object s_iDefaultFlag; // 0x30
	private static readonly object s_iValidCompareOptionMask; // 0x34
	internal static readonly object s_iValidSqlCompareOptionMask; // 0x38
	internal static readonly object s_lcidUSEnglish; // 0x3C
	private static readonly object s_lcidBinary; // 0x40

	// Properties
	public object IsNull { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6E81A24
	private object .ctor(object fNull) { }

	// RVA: 0x6E81A44
	public object .ctor(object data, object lcid, object compareOptions) { }

	// RVA: 0x6E81C38
	public object .ctor(object data) { }

	// RVA: 0x6E81DA8
	private object .ctor(object lcid, object compareOptions, object data, object cmpInfo) { }

	// RVA: 0x6E81EE8
	public object get_IsNull() { }

	// RVA: 0x6E81F08
	public object get_Value() { }

	// RVA: 0x6E81FBC
	private object SetCompareInfo() { }

	// RVA: 0x6E8207C
	public static object op_Implicit(object x) { }

	// RVA: 0x6E82090
	public override object ToString() { }

	// RVA: 0x6E821B0
	public static object op_Addition(object x, object y) { }

	// RVA: 0x6E823B4
	private static object StringCompare(object x, object y) { }

	// RVA: 0x6E82B1C
	private static object Compare(object x, object y, object ecExpectedResult) { }

	// RVA: 0x6E82CC8
	public static object op_Equality(object x, object y) { }

	// RVA: 0x6E81AD4
	private static object ValidateSqlCompareOptions(object compareOptions) { }

	// RVA: 0x6E82A50
	public static object CompareOptionsFromSqlCompareOptions(object compareOptions) { }

	// RVA: 0x6E82DE4
	private object FBinarySort() { }

	// RVA: 0x6E8261C
	private static object CompareBinary(object x, object y) { }

	// RVA: 0x6E82878
	private static object CompareBinary2(object x, object y) { }

	// RVA: 0x6E82F14
	public object CompareTo(object value) { }

	// RVA: 0x6E83048
	public object CompareTo(object value) { }

	// RVA: 0x6E831A4
	public override object Equals(object value) { }

	// RVA: 0x6E833A4
	public override object GetHashCode() { }

	// RVA: 0x6E83710
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E83720
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object reader) { }

	// RVA: 0x6E83894
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E839DC
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E83A6C
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
internal enum EComparison
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LT;
	public const object LE;
	public const object EQ;
	public const object GE;
	public const object GT;
	public const object NE;
}

// Namespace: System.Data.SqlTypes
public class SqlTypeException
{

	// Methods

	// RVA: 0x6E83B24
	public object .ctor() { }

	// RVA: 0x6E82380
	public object .ctor(object message) { }

	// RVA: 0x6E83B90
	public object .ctor(object message, object e) { }

	// RVA: 0x6E83BC0
	protected object .ctor(object si, object sc) { }

	// RVA: 0x6E83C14
	private static object SqlTypeExceptionSerialization(object si, object sc) { }

}

// Namespace: System.Data.SqlTypes
public sealed class SqlNullValueException
{

	// Methods

	// RVA: 0x6E7F7E4
	public object .ctor() { }

	// RVA: 0x6E83D34
	public object .ctor(object message) { }

	// RVA: 0x6E83D04
	public object .ctor(object message, object e) { }

	// RVA: 0x6E83D68
	private object .ctor(object si, object sc) { }

	// RVA: 0x6E83DCC
	private static object SqlNullValueExceptionSerialization(object si, object sc) { }

}

// Namespace: System.Data.SqlTypes
public sealed class SqlTruncateException
{

	// Methods

	// RVA: 0x6E83EBC
	public object .ctor() { }

	// RVA: 0x6E83F30
	public object .ctor(object message) { }

	// RVA: 0x6E83F00
	public object .ctor(object message, object e) { }

	// RVA: 0x6E83F64
	private object .ctor(object si, object sc) { }

	// RVA: 0x6E83FC8
	private static object SqlTruncateExceptionSerialization(object si, object sc) { }

}

// Namespace: System.Data.SqlTypes
internal abstract class SqlStreamChars
{

	// Properties
	public abstract object Length { get; }
	public abstract object Position { get; }

	// Methods

	// RVA: -1
	public abstract object get_Length() { }

	// RVA: -1
	public abstract object get_Position() { }

	// RVA: -1
	public abstract object Read(object buffer, object offset, object count) { }

	// RVA: -1
	public abstract object Seek(object offset, object origin) { }

}

// Namespace: System.Data.SqlTypes
public sealed class SqlXml
{

	// Fields
	private static readonly object s_sqlReaderDelegate; // 0x0
	private static readonly object s_defaultXmlReaderSettings; // 0x8
	private static readonly object s_defaultXmlReaderSettingsCloseInput; // 0x10
	private static object s_createSqlReaderMethodInfo; // 0x18
	private object _createSqlReaderMethodInfo; // 0x8
	private object _fNotNull; // 0x10
	private object _stream; // 0x18
	private object _firstCreateReader; // 0x20

	// Properties
	private static object CreateSqlReaderMethodInfo { get; }
	public object IsNull { get; }

	// Methods

	// RVA: 0x6E840B8
	public object .ctor() { }

	// RVA: 0x6E84100
	public object CreateReader() { }

	// RVA: 0x6E844C8
	internal static object CreateSqlXmlReader(object stream, object closeInput, object throwTargetInvocationExceptions) { }

	// RVA: 0x6E84980
	private static object CreateSqlReaderDelegate() { }

	// RVA: 0x6E84360
	private static object get_CreateSqlReaderMethodInfo() { }

	// RVA: 0x6E842DC
	public object get_IsNull() { }

	// RVA: 0x6E840EC
	private object SetNull() { }

	// RVA: 0x6E84AC8
	private object System.Xml.Serialization.IXmlSerializable.GetSchema() { }

	// RVA: 0x6E84AD0
	private object System.Xml.Serialization.IXmlSerializable.ReadXml(object r) { }

	// RVA: 0x6E84D80
	private object System.Xml.Serialization.IXmlSerializable.WriteXml(object writer) { }

	// RVA: 0x6E84F88
	public static object GetXsdType(object schemaSet) { }

	// RVA: 0x6E85018
	private static object .cctor() { }

}

// Namespace: System.Data.SqlTypes
internal sealed class SqlXmlStreamWrapper
{

	// Fields
	private object _stream; // 0x20
	private object _lPosition; // 0x28
	private object _isClosed; // 0x30

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x6E842EC
	internal object .ctor(object stream) { }

	// RVA: 0x6E85114
	public override object get_CanRead() { }

	// RVA: 0x6E8525C
	public override object get_CanSeek() { }

	// RVA: 0x6E852C4
	public override object get_CanWrite() { }

	// RVA: 0x6E8532C
	public override object get_Length() { }

	// RVA: 0x6E8551C
	public override object get_Position() { }

	// RVA: 0x6E855D0
	public override object set_Position(object value) { }

	// RVA: 0x6E85714
	public override object Seek(object offset, object origin) { }

	// RVA: 0x6E85A74
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x6E85DC4
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x6E86114
	public override object ReadByte() { }

	// RVA: 0x6E86368
	public override object WriteByte(object value) { }

	// RVA: 0x6E86530
	public override object SetLength(object value) { }

	// RVA: 0x6E86634
	public override object Flush() { }

	// RVA: 0x6E86684
	protected override object Dispose(object disposing) { }

	// RVA: 0x6E8547C
	private object ThrowIfStreamCannotSeek(object method) { }

	// RVA: 0x6E85D24
	private object ThrowIfStreamCannotRead(object method) { }

	// RVA: 0x6E86074
	private object ThrowIfStreamCannotWrite(object method) { }

	// RVA: 0x6E85410
	private object ThrowIfStreamClosed(object method) { }

	// RVA: 0x6E8517C
	private object IsStreamClosed() { }

}

// Namespace: System.Data.Common
internal static class ADP
{

	// Fields
	private static readonly object s_stackOverflowType; // 0x0
	private static readonly object s_outOfMemoryType; // 0x8
	private static readonly object s_threadAbortType; // 0x10
	private static readonly object s_nullReferenceType; // 0x18
	private static readonly object s_accessViolationType; // 0x20
	private static readonly object s_securityType; // 0x28
	internal static readonly object StrEmpty; // 0x30
	internal static readonly object AzureSqlServerEndpoints; // 0x38
	internal static readonly object PtrZero; // 0x40
	internal static readonly object PtrSize; // 0x48

	// Methods

	// RVA: 0x6E86694
	private static object TraceException(object trace, object e) { }

	// RVA: 0x6E86744
	internal static object TraceExceptionAsReturnValue(object e) { }

	// RVA: 0x6E86868
	internal static object TraceExceptionWithoutRethrow(object e) { }

	// RVA: 0x6E8698C
	internal static object Argument(object error) { }

	// RVA: 0x6E82D50
	internal static object ArgumentOutOfRange(object parameterName) { }

	// RVA: 0x6E86A20
	internal static object ArgumentOutOfRange(object message, object parameterName) { }

	// RVA: 0x6E86AC4
	internal static object InvalidOperation(object error) { }

	// RVA: 0x6E86B58
	internal static object NotSupported(object error) { }

	// RVA: 0x6E84698
	internal static object IsCatchableExceptionType(object e) { }

	// RVA: 0x6E86BEC
	internal static object IsCatchableOrSecurityExceptionType(object e) { }

	// RVA: 0x6E86E68
	internal static object InvalidEnumerationValue(object type, object value) { }

	// RVA: 0x6E8595C
	internal static object InvalidSeekOrigin(object parameterName) { }

	// RVA: 0x6E87024
	internal static object InvalidAcceptRejectRule(object value) { }

	// RVA: 0x6E8711C
	internal static object InvalidMissingSchemaAction(object value) { }

	// RVA: 0x6E87214
	internal static object InvalidRule(object value) { }

	// RVA: 0x6E8118C
	internal static object WrongType(object got, object expected) { }

	// RVA: 0x6E8730C
	private static object .cctor() { }

}

// Namespace: System.Data.Common
internal sealed class BigIntegerStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E875FC
	internal object .ctor(object column) { }

	// RVA: 0x6E87870
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E878A8
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E87AAC
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E87C68
	internal static object ConvertToBigInteger(object value, object formatProvider) { }

	// RVA: 0x6E8845C
	internal static object ConvertFromBigInteger(object value, object type, object formatProvider) { }

	// RVA: 0x6E88BF4
	public override object ConvertValue(object value) { }

	// RVA: 0x6E88CDC
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E88DC0
	public override object Get(object record) { }

	// RVA: 0x6E88F14
	public override object Set(object record, object value) { }

	// RVA: 0x6E890BC
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E89268
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E8934C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E89448
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E8949C
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E895DC
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class BooleanStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E89694
	internal object .ctor(object column) { }

	// RVA: 0x6E897FC
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E89BE8
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E89CF8
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E89E70
	public override object ConvertValue(object value) { }

	// RVA: 0x6E89FF0
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E8A088
	public override object Get(object record) { }

	// RVA: 0x6E8A160
	public override object Set(object record, object value) { }

	// RVA: 0x6E8A340
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E8A460
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E8A4F4
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E8A5B0
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E8A604
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E8A73C
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class ByteStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8A7F4
	internal object .ctor(object column) { }

	// RVA: 0x6E8A95C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E8B1E0
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E8B2B4
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E8B418
	public override object ConvertValue(object value) { }

	// RVA: 0x6E8B598
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E8B630
	public override object Get(object record) { }

	// RVA: 0x6E8B704
	public override object Set(object record, object value) { }

	// RVA: 0x6E8B8E4
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E8BA04
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E8BA98
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E8BB54
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E8BBA8
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E8BCE0
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class CharStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8BD98
	internal object .ctor(object column) { }

	// RVA: 0x6E8BF00
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E8C2E0
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E8C3F4
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E8C56C
	public override object ConvertValue(object value) { }

	// RVA: 0x6E8C6EC
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E8C784
	public override object Get(object record) { }

	// RVA: 0x6E8C858
	public override object Set(object record, object value) { }

	// RVA: 0x6E8CA88
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E8CBA8
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E8CC3C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E8CCF8
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E8CD4C
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E8CE84
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal enum StorageType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Empty;
	public const object Object;
	public const object DBNull;
	public const object Boolean;
	public const object Char;
	public const object SByte;
	public const object Byte;
	public const object Int16;
	public const object UInt16;
	public const object Int32;
	public const object UInt32;
	public const object Int64;
	public const object UInt64;
	public const object Single;
	public const object Double;
	public const object Decimal;
	public const object DateTime;
	public const object TimeSpan;
	public const object String;
	public const object Guid;
	public const object ByteArray;
	public const object CharArray;
	public const object Type;
	public const object DateTimeOffset;
	public const object BigInteger;
	public const object Uri;
	public const object SqlBinary;
	public const object SqlBoolean;
	public const object SqlByte;
	public const object SqlBytes;
	public const object SqlChars;
	public const object SqlDateTime;
	public const object SqlDecimal;
	public const object SqlDouble;
	public const object SqlGuid;
	public const object SqlInt16;
	public const object SqlInt32;
	public const object SqlInt64;
	public const object SqlMoney;
	public const object SqlSingle;
	public const object SqlString;
}

// Namespace: System.Data.Common
internal abstract class DataStorage
{

	// Fields
	private static readonly object s_storageClassType; // 0x0
	internal readonly object _column; // 0x8
	internal readonly object _table; // 0x10
	internal readonly object _dataType; // 0x18
	internal readonly object _storageTypeCode; // 0x20
	private object _dbNullBits; // 0x28
	private readonly object _defaultValue; // 0x30
	internal readonly object _nullValue; // 0x38
	internal readonly object _isCloneable; // 0x40
	internal readonly object _isCustomDefinedType; // 0x41
	internal readonly object _isStringType; // 0x42
	internal readonly object _isValueType; // 0x43
	private static readonly object s_inspectTypeForInterfaces; // 0x8
	private static readonly object s_typeImplementsInterface; // 0x10

	// Properties
	internal object DateTimeMode { get; }
	internal object FormatProvider { get; }

	// Methods

	// RVA: 0x6E877D0
	protected object .ctor(object column, object type, object defaultValue, object storageType) { }

	// RVA: 0x6E8D07C
	protected object .ctor(object column, object type, object defaultValue, object nullValue, object storageType) { }

	// RVA: 0x6E8CF3C
	protected object .ctor(object column, object type, object defaultValue, object nullValue, object isICloneable, object storageType) { }

	// RVA: 0x6E8D0EC
	internal object get_DateTimeMode() { }

	// RVA: 0x6E88CB8
	internal object get_FormatProvider() { }

	// RVA: 0x6E89BD4
	public virtual object Aggregate(object recordNos, object kind) { }

	// RVA: 0x6E8D110
	public object AggregateCount(object recordNos) { }

	// RVA: 0x6E87A2C
	protected object CompareBits(object recordNo1, object recordNo2) { }

	// RVA: -1
	public abstract object Compare(object recordNo1, object recordNo2) { }

	// RVA: -1
	public abstract object CompareValueTo(object recordNo1, object value) { }

	// RVA: 0x6E8D1E8
	public virtual object ConvertValue(object value) { }

	// RVA: 0x6E88D74
	protected object CopyBits(object srcRecordNo, object dstRecordNo) { }

	// RVA: -1
	public abstract object Copy(object recordNo1, object recordNo2) { }

	// RVA: -1
	public abstract object Get(object recordNo) { }

	// RVA: 0x6E88EC8
	protected object GetBits(object recordNo) { }

	// RVA: 0x6E8D1F0
	public virtual object GetStringLength(object record) { }

	// RVA: 0x6E87C38
	protected object HasValue(object recordNo) { }

	// RVA: 0x6E8D1F8
	public virtual object IsNull(object recordNo) { }

	// RVA: -1
	public abstract object Set(object recordNo, object value) { }

	// RVA: 0x6E89098
	protected object SetNullBit(object recordNo, object flag) { }

	// RVA: 0x6E891DC
	public virtual object SetCapacity(object capacity) { }

	// RVA: -1
	public abstract object ConvertXmlToObject(object s) { }

	// RVA: 0x6E8D21C
	public virtual object ConvertXmlToObject(object xmlReader, object xmlAttrib) { }

	// RVA: -1
	public abstract object ConvertObjectToXml(object value) { }

	// RVA: 0x6E8D29C
	public virtual object ConvertObjectToXml(object value, object xmlWriter, object xmlAttrib) { }

	// RVA: 0x6E8D334
	public static object CreateStorage(object column, object dataType, object typeCode) { }

	// RVA: 0x6E8EAE4
	internal static object GetStorageType(object dataType) { }

	// RVA: 0x6E8EC2C
	internal static object GetTypeStorage(object storageType) { }

	// RVA: 0x6E8ECD4
	internal static object IsTypeCustomType(object type) { }

	// RVA: 0x6E8D088
	internal static object IsTypeCustomType(object typeCode) { }

	// RVA: 0x6E8ED50
	internal static object IsSqlType(object storageType) { }

	// RVA: 0x6E8ED5C
	public static object IsSqlType(object dataType) { }

	// RVA: 0x6E8D0A4
	private static object DetermineIfValueType(object typeCode, object dataType) { }

	// RVA: 0x6E8EE84
	internal static object ImplementsInterfaces(object typeCode, object dataType, object sqlType, object nullable, object xmlSerializable, object changeTracking, object revertibleChangeTracking) { }

	// RVA: 0x6E8F00C
	private static object InspectTypeForInterfaces(object dataType) { }

	// RVA: 0x6E8F28C
	internal static object ImplementsINullableValue(object typeCode, object dataType) { }

	// RVA: 0x6E8F39C
	public static object IsObjectNull(object value) { }

	// RVA: 0x6E8F460
	public static object IsObjectSqlNull(object value) { }

	// RVA: 0x6E8F554
	internal object GetEmptyStorageInternal(object recordCount) { }

	// RVA: 0x6E8F5A0
	internal object CopyValueInternal(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E8F614
	internal object SetStorageInternal(object store, object nullbits) { }

	// RVA: -1
	protected abstract object GetEmptyStorage(object recordCount) { }

	// RVA: -1
	protected abstract object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: -1
	protected abstract object SetStorage(object store, object nullbits) { }

	// RVA: 0x6E8F670
	protected object SetNullStorage(object nullbits) { }

	// RVA: 0x6E8F678
	internal static object GetType(object value) { }

	// RVA: 0x6E8F95C
	internal static object GetQualifiedName(object type) { }

	// RVA: 0x6E8FA0C
	private static object .cctor() { }

}

// Namespace: System.Data.Common
internal sealed class DateTimeOffsetStorage
{

	// Fields
	private static readonly object s_defaultValue; // 0x0
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8E94C
	internal object .ctor(object column) { }

	// RVA: 0x6E9074C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E90CE4
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E90F34
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E9110C
	public override object ConvertValue(object value) { }

	// RVA: 0x6E911D0
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E91268
	public override object Get(object record) { }

	// RVA: 0x6E913B8
	public override object Set(object record, object value) { }

	// RVA: 0x6E91518
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E91638
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E916CC
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E9178C
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E917E0
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E91920
	protected override object SetStorage(object store, object nullbits) { }

	// RVA: 0x6E919D8
	private static object .cctor() { }

}

// Namespace: System.Data.Common
internal sealed class DateTimeStorage
{

	// Fields
	private static readonly object s_defaultValue; // 0x0
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8E7B4
	internal object .ctor(object column) { }

	// RVA: 0x6E91A54
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E91FBC
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E921C8
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E92398
	public override object ConvertValue(object value) { }

	// RVA: 0x6E92518
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E925B0
	public override object Get(object record) { }

	// RVA: 0x6E92700
	public override object Set(object record, object value) { }

	// RVA: 0x6E92B2C
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E92C4C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E92D1C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E92E2C
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E92E80
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E93040
	protected override object SetStorage(object store, object nullbits) { }

	// RVA: 0x6E93298
	private static object .cctor() { }

}

// Namespace: System.Data.Common
internal sealed class DecimalStorage
{

	// Fields
	private static readonly object s_defaultValue; // 0x0
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8E5F8
	internal object .ctor(object column) { }

	// RVA: 0x6E93314
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E93E60
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E94068
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E94218
	public override object ConvertValue(object value) { }

	// RVA: 0x6E943B8
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E94450
	public override object Get(object record) { }

	// RVA: 0x6E9453C
	public override object Set(object record, object value) { }

	// RVA: 0x6E9473C
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E9485C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E9491C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E949DC
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E94A30
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E94B70
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class DoubleStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8E490
	internal object .ctor(object column) { }

	// RVA: 0x6E94C28
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E95408
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E954E8
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E95650
	public override object ConvertValue(object value) { }

	// RVA: 0x6E957D0
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E95868
	public override object Get(object record) { }

	// RVA: 0x6E95940
	public override object Set(object record, object value) { }

	// RVA: 0x6E95B20
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E95C40
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E95CD4
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E95D90
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E95DE4
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E95F24
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class Int16Storage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8E058
	internal object .ctor(object column) { }

	// RVA: 0x6E95FDC
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E9691C
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E969E4
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E96B28
	public override object ConvertValue(object value) { }

	// RVA: 0x6E96CA8
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E96D40
	public override object Get(object record) { }

	// RVA: 0x6E96E14
	public override object Set(object record, object value) { }

	// RVA: 0x6E96FF4
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E97114
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E971A8
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E97264
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E972B8
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E973E8
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class Int32Storage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8E1C0
	internal object .ctor(object column) { }

	// RVA: 0x6E974A0
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E97DD4
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E97EB8
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E97FFC
	public override object ConvertValue(object value) { }

	// RVA: 0x6E9817C
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E98214
	public override object Get(object record) { }

	// RVA: 0x6E982E8
	public override object Set(object record, object value) { }

	// RVA: 0x6E984C8
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E985E8
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E9867C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E98738
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E9878C
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E988BC
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class Int64Storage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8E328
	internal object .ctor(object column) { }

	// RVA: 0x6E98974
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E9923C
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E99320
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6E99464
	public override object ConvertValue(object value) { }

	// RVA: 0x6E995E4
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E9967C
	public override object Get(object record) { }

	// RVA: 0x6E99750
	public override object Set(object record, object value) { }

	// RVA: 0x6E99930
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E99A50
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E99AE4
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E99BA0
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E99BF4
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E99D24
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: 
private enum Families
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DATETIME;
	public const object NUMBER;
	public const object STRING;
	public const object BOOLEAN;
	public const object ARRAY;
}

// Namespace: 
private class TempAssemblyComparer
{

	// Fields
	internal static readonly object s_default; // 0x0

	// Methods

	// RVA: 0x6E9F648
	private object .ctor() { }

	// RVA: 0x6E9F650
	public object Equals(object x, object y) { }

	// RVA: 0x6E9F7B8
	public object GetHashCode(object obj) { }

	// RVA: 0x6E9F8A0
	private static object .cctor() { }

}

// Namespace: System.Data.Common
internal sealed class ObjectStorage
{

	// Fields
	private static readonly object s_defaultValue; // 0x0
	private object _values; // 0x48
	private readonly object _implementsIXmlSerializable; // 0x50
	private static readonly object s_tempAssemblyCacheLock; // 0x8
	private static object s_tempAssemblyCache; // 0x10
	private static readonly object s_serializerFactory; // 0x18

	// Methods

	// RVA: 0x6E8DCD4
	internal object .ctor(object column, object type) { }

	// RVA: 0x6E99DDC
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6E99E14
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6E9A56C
	public override object CompareValueTo(object recordNo1, object value) { }

	// RVA: 0x6E9A7C4
	private object CompareTo(object valueNo1, object valueNo2) { }

	// RVA: 0x6E9A018
	private object CompareWithFamilies(object valueNo1, object valueNo2) { }

	// RVA: 0x6E9AAB4
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6E9AB38
	public override object Get(object recordNo) { }

	// RVA: 0x6E9A96C
	private object GetFamily(object dataType) { }

	// RVA: 0x6E9AB8C
	public override object IsNull(object record) { }

	// RVA: 0x6E9ABD0
	public override object Set(object recordNo, object value) { }

	// RVA: 0x6E9B4AC
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6E9B568
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6E9BBFC
	public override object ConvertXmlToObject(object xmlReader, object xmlAttrib) { }

	// RVA: 0x6E9E8FC
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6E9EEFC
	public override object ConvertObjectToXml(object value, object xmlWriter, object xmlAttrib) { }

	// RVA: 0x6E9F098
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6E9F0EC
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6E9F350
	protected override object SetStorage(object store, object nullbits) { }

	// RVA: 0x6E8F7BC
	internal static object VerifyIDynamicMetaObjectProvider(object type) { }

	// RVA: 0x6E9BB50
	internal static object GetXmlSerializer(object type) { }

	// RVA: 0x6E9E27C
	internal static object GetXmlSerializer(object type, object attribute) { }

	// RVA: 0x6E9F58C
	private static object .cctor() { }

}

// Namespace: System.Data.Common
internal sealed class SByteStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6E8DEF0
	public object .ctor(object column) { }

	// RVA: 0x6E9F900
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EA01A4
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA02A0
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EA0404
	public override object ConvertValue(object value) { }

	// RVA: 0x6EA0584
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA061C
	public override object Get(object record) { }

	// RVA: 0x6EA0708
	public override object Set(object record, object value) { }

	// RVA: 0x6EA08E8
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EA0A08
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EA0A9C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EA0B58
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EA0BAC
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EA0CE4
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal static class SqlConvert
{

	// Methods

	// RVA: 0x6EA0D9C
	public static object ConvertToSqlByte(object value) { }

	// RVA: 0x6EA0FDC
	public static object ConvertToSqlInt16(object value) { }

	// RVA: 0x6EA12FC
	public static object ConvertToSqlInt32(object value) { }

	// RVA: 0x6EA1768
	public static object ConvertToSqlInt64(object value) { }

	// RVA: 0x6EA1D1C
	public static object ConvertToSqlDouble(object value) { }

	// RVA: 0x6EA2490
	public static object ConvertToSqlDecimal(object value) { }

	// RVA: 0x6EA2B84
	public static object ConvertToSqlSingle(object value) { }

	// RVA: 0x6EA3288
	public static object ConvertToSqlMoney(object value) { }

	// RVA: 0x6EA3924
	public static object ConvertToSqlDateTime(object value) { }

	// RVA: 0x6EA3B68
	public static object ConvertToSqlBoolean(object value) { }

	// RVA: 0x6EA3D8C
	public static object ConvertToSqlGuid(object value) { }

	// RVA: 0x6EA3FD4
	public static object ConvertToSqlBinary(object value) { }

	// RVA: 0x6EA4210
	public static object ConvertToSqlString(object value) { }

	// RVA: 0x6EA443C
	public static object ConvertToSqlChars(object value) { }

	// RVA: 0x6EA45B4
	public static object ConvertToSqlBytes(object value) { }

	// RVA: 0x6EA472C
	public static object ConvertStringToDateTimeOffset(object value, object formatProvider) { }

	// RVA: 0x6EA4798
	public static object ChangeTypeForDefaultValue(object value, object type, object formatProvider) { }

	// RVA: 0x6EA4990
	public static object ChangeType2(object value, object stype, object type, object formatProvider) { }

	// RVA: 0x6E9C474
	public static object ChangeTypeForXML(object value, object type) { }

}

// Namespace: System.Data.Common
internal sealed class SqlBinaryStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EA5A0C
	public object .ctor(object column) { }

	// RVA: 0x6EA5B44
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EA5DD0
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA5E78
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EA5F48
	public override object ConvertValue(object value) { }

	// RVA: 0x6EA5FD8
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA6020
	public override object Get(object record) { }

	// RVA: 0x6EA60B4
	public override object IsNull(object record) { }

	// RVA: 0x6EA6144
	public override object Set(object record, object value) { }

	// RVA: 0x6EA6198
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EA6254
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EA6544
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EA67FC
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EA6850
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EA6988
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlByteStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EA6A34
	public object .ctor(object column) { }

	// RVA: 0x6EA6B6C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EA7AE0
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA7B88
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EA7C58
	public override object ConvertValue(object value) { }

	// RVA: 0x6EA7CE8
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA7D30
	public override object Get(object record) { }

	// RVA: 0x6EA7DC4
	public override object IsNull(object record) { }

	// RVA: 0x6EA7E54
	public override object Set(object record, object value) { }

	// RVA: 0x6EA7EA8
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EA7F64
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EA8254
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EA850C
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EA8560
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EA8698
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlBytesStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EA8744
	public object .ctor(object column) { }

	// RVA: 0x6EA882C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EA8A90
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA8A98
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EA8AA0
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA8AE8
	public override object Get(object record) { }

	// RVA: 0x6EA8B24
	public override object IsNull(object record) { }

	// RVA: 0x6EA8B74
	public override object Set(object record, object value) { }

	// RVA: 0x6EA8C84
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EA8D40
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EA9054
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EA930C
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EA9360
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EA9498
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlCharsStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EA9544
	public object .ctor(object column) { }

	// RVA: 0x6EA962C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EA9890
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA9898
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EA98A0
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EA98E8
	public override object Get(object record) { }

	// RVA: 0x6EA9924
	public override object IsNull(object record) { }

	// RVA: 0x6EA9974
	public override object Set(object record, object value) { }

	// RVA: 0x6EA9A84
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EA9B40
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EA9E60
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EAA118
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EAA16C
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EAA2A4
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlDateTimeStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EAA350
	public object .ctor(object column) { }

	// RVA: 0x6EAA498
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EAAB38
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EAABFC
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EAACD4
	public override object ConvertValue(object value) { }

	// RVA: 0x6EAAD68
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EAADC4
	public override object Get(object record) { }

	// RVA: 0x6EAAE64
	public override object IsNull(object record) { }

	// RVA: 0x6EAAEF8
	public override object Set(object record, object value) { }

	// RVA: 0x6EAAF54
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EAB010
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EAB30C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EAB5C4
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EAB618
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EAB768
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlDecimalStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EAB814
	public object .ctor(object column) { }

	// RVA: 0x6EAB95C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EAC9D0
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EACAAC
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EACB9C
	public override object ConvertValue(object value) { }

	// RVA: 0x6EACC3C
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EACC98
	public override object Get(object record) { }

	// RVA: 0x6EACD40
	public override object IsNull(object record) { }

	// RVA: 0x6EACDD4
	public override object Set(object record, object value) { }

	// RVA: 0x6EACE44
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EACF00
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EAD1FC
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EAD4B4
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EAD508
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EAD668
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlDoubleStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EAD714
	public object .ctor(object column) { }

	// RVA: 0x6EAD84C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EAE6B0
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EAE768
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EAE838
	public override object ConvertValue(object value) { }

	// RVA: 0x6EAE8C8
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EAE910
	public override object Get(object record) { }

	// RVA: 0x6EAE9A4
	public override object IsNull(object record) { }

	// RVA: 0x6EAEA34
	public override object Set(object record, object value) { }

	// RVA: 0x6EAEA88
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EAEB44
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EAEE34
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EAF0EC
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EAF140
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EAF288
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlGuidStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EAF334
	public object .ctor(object column) { }

	// RVA: 0x6EAF46C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EAF6F8
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EAF7A0
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EAF870
	public override object ConvertValue(object value) { }

	// RVA: 0x6EAF900
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EAF948
	public override object Get(object record) { }

	// RVA: 0x6EAF9DC
	public override object IsNull(object record) { }

	// RVA: 0x6EAFA6C
	public override object Set(object record, object value) { }

	// RVA: 0x6EAFAC0
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EAFB7C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EAFE6C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EB0124
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EB0178
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EB02B0
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlInt16Storage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EB035C
	public object .ctor(object column) { }

	// RVA: 0x6EB0494
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EB1408
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB14B0
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EB1580
	public override object ConvertValue(object value) { }

	// RVA: 0x6EB1610
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB1658
	public override object Get(object record) { }

	// RVA: 0x6EB16EC
	public override object IsNull(object record) { }

	// RVA: 0x6EB177C
	public override object Set(object record, object value) { }

	// RVA: 0x6EB17D0
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EB188C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EB1B7C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EB1E34
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EB1E88
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EB1FC0
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlInt32Storage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EB206C
	public object .ctor(object column) { }

	// RVA: 0x6EB21A4
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EB30F4
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB319C
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EB326C
	public override object ConvertValue(object value) { }

	// RVA: 0x6EB32FC
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB3344
	public override object Get(object record) { }

	// RVA: 0x6EB33D8
	public override object IsNull(object record) { }

	// RVA: 0x6EB3468
	public override object Set(object record, object value) { }

	// RVA: 0x6EB34BC
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EB3578
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EB3868
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EB3B20
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EB3B74
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EB3CAC
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlInt64Storage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EB3D58
	public object .ctor(object column) { }

	// RVA: 0x6EB3E90
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EB4E70
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB4F28
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EB4FF8
	public override object ConvertValue(object value) { }

	// RVA: 0x6EB5088
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB50D0
	public override object Get(object record) { }

	// RVA: 0x6EB5164
	public override object IsNull(object record) { }

	// RVA: 0x6EB51F4
	public override object Set(object record, object value) { }

	// RVA: 0x6EB5248
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EB5304
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EB55F4
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EB58AC
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EB5900
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EB5A48
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlMoneyStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EB5AF4
	public object .ctor(object column) { }

	// RVA: 0x6EB5C2C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EB6C64
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB6D1C
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EB6DEC
	public override object ConvertValue(object value) { }

	// RVA: 0x6EB6E7C
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB6EC4
	public override object Get(object record) { }

	// RVA: 0x6EB6F58
	public override object IsNull(object record) { }

	// RVA: 0x6EB6FE8
	public override object Set(object record, object value) { }

	// RVA: 0x6EB703C
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EB70F8
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EB73E8
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EB76A0
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EB76F4
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EB783C
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlSingleStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EB78E8
	public object .ctor(object column) { }

	// RVA: 0x6EB7A20
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EB893C
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB89E4
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EB8AB4
	public override object ConvertValue(object value) { }

	// RVA: 0x6EB8B44
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB8B8C
	public override object Get(object record) { }

	// RVA: 0x6EB8C20
	public override object IsNull(object record) { }

	// RVA: 0x6EB8CB0
	public override object Set(object record, object value) { }

	// RVA: 0x6EB8D04
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EB8DC0
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EB90B0
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EB9368
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EB93BC
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EB94F4
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlStringStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EB95A0
	public object .ctor(object column) { }

	// RVA: 0x6EB96E4
	public override object Aggregate(object recordNos, object kind) { }

	// RVA: 0x6EB9BD4
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB9C54
	public object Compare(object valueNo1, object valueNo2) { }

	// RVA: 0x6EB9E18
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EB9EFC
	public override object ConvertValue(object value) { }

	// RVA: 0x6EB9F94
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EB9FEC
	public override object Get(object record) { }

	// RVA: 0x6EBA08C
	public override object GetStringLength(object record) { }

	// RVA: 0x6EBA194
	public override object IsNull(object record) { }

	// RVA: 0x6EBA228
	public override object Set(object record, object value) { }

	// RVA: 0x6EBA294
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EBA350
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EBA644
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EBA8FC
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EBA950
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EBAAA8
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SqlBooleanStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EBAB54
	public object .ctor(object column) { }

	// RVA: 0x6EBAC8C
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EBB188
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EBB230
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EBB300
	public override object ConvertValue(object value) { }

	// RVA: 0x6EBB390
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EBB3D8
	public override object Get(object record) { }

	// RVA: 0x6EBB46C
	public override object IsNull(object record) { }

	// RVA: 0x6EBB4FC
	public override object Set(object record, object value) { }

	// RVA: 0x6EBB550
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EBB60C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EBB8FC
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EBBBB4
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EBBC08
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EBBD40
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class SingleStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EBBDEC
	public object .ctor(object column) { }

	// RVA: 0x6EBBEEC
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EBC6EC
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EBC784
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EBC8EC
	public override object ConvertValue(object value) { }

	// RVA: 0x6EBCA60
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EBCACC
	public override object Get(object record) { }

	// RVA: 0x6EBCB8C
	public override object Set(object record, object value) { }

	// RVA: 0x6EBCD54
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EBCE1C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EBCEB0
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EBCF6C
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EBCFC0
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EBD100
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object type; // 0x8

	// Methods

	// RVA: 0x6EBD58C
	public object .ctor() { }

	// RVA: 0x6EBECCC
	internal object <GetStaticNullForUdtType>b__0(object t) { }

}

// Namespace: System.Data.Common
internal sealed class SqlUdtStorage
{

	// Fields
	private object _values; // 0x48
	private readonly object _implementsIXmlSerializable; // 0x50
	private readonly object _implementsIComparable; // 0x51
	private static readonly object s_typeToNull; // 0x0

	// Methods

	// RVA: 0x6EBD1B8
	public object .ctor(object column, object type) { }

	// RVA: 0x6EBD364
	private object .ctor(object column, object type, object nullValue) { }

	// RVA: 0x6EBD23C
	internal static object GetStaticNullForUdtType(object type) { }

	// RVA: 0x6EBD594
	public override object IsNull(object record) { }

	// RVA: 0x6EBD6E0
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EBD718
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EBD798
	public override object CompareValueTo(object recordNo1, object value) { }

	// RVA: 0x6EBDAB4
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EBDB48
	public override object Get(object recordNo) { }

	// RVA: 0x6EBDB84
	public override object Set(object recordNo, object value) { }

	// RVA: 0x6EBDD74
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EBDE3C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EBE194
	public override object ConvertXmlToObject(object xmlReader, object xmlAttrib) { }

	// RVA: 0x6EBE4E8
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EBE83C
	public override object ConvertObjectToXml(object value, object xmlWriter, object xmlAttrib) { }

	// RVA: 0x6EBE9CC
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EBEA20
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EBEB90
	protected override object SetStorage(object store, object nullbits) { }

	// RVA: 0x6EBEC3C
	private static object .cctor() { }

}

// Namespace: System.Data.Common
internal sealed class StringStorage
{

	// Fields
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EBEE74
	public object .ctor(object column) { }

	// RVA: 0x6EBEF60
	public override object Aggregate(object recordNos, object kind) { }

	// RVA: 0x6EBF2F8
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EBF38C
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EBF484
	public override object ConvertValue(object value) { }

	// RVA: 0x6EBF4E4
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EBF52C
	public override object Get(object recordNo) { }

	// RVA: 0x6EBF580
	public override object GetStringLength(object record) { }

	// RVA: 0x6EBF5D0
	public override object IsNull(object record) { }

	// RVA: 0x6EBF614
	public override object Set(object record, object value) { }

	// RVA: 0x6EBF6E0
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EBF79C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EBF7A4
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EBF808
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EBF85C
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EBF994
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class TimeSpanStorage
{

	// Fields
	private static readonly object s_defaultValue; // 0x0
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EBFA40
	public object .ctor(object column) { }

	// RVA: 0x6EBFB70
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EC088C
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EC0A60
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EC0C64
	private static object ConvertToTimeSpan(object value) { }

	// RVA: 0x6EC0E9C
	public override object ConvertValue(object value) { }

	// RVA: 0x6EC0F64
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EC0FD0
	public override object Get(object record) { }

	// RVA: 0x6EC110C
	public override object Set(object record, object value) { }

	// RVA: 0x6EC1200
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EC12C8
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EC135C
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EC1418
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EC146C
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EC15A4
	protected override object SetStorage(object store, object nullbits) { }

	// RVA: 0x6EC165C
	private static object .cctor() { }

}

// Namespace: System.Data.Common
internal sealed class UInt16Storage
{

	// Fields
	private static readonly object s_defaultValue; // 0x0
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EC16D8
	public object .ctor(object column) { }

	// RVA: 0x6EC1800
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EC20C8
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EC219C
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EC22EC
	public override object ConvertValue(object value) { }

	// RVA: 0x6EC2460
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EC24CC
	public override object Get(object record) { }

	// RVA: 0x6EC25BC
	public override object Set(object record, object value) { }

	// RVA: 0x6EC27A4
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EC286C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EC2900
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EC29BC
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EC2A10
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EC2B30
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class UInt32Storage
{

	// Fields
	private static readonly object s_defaultValue; // 0x0
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EC2BE8
	public object .ctor(object column) { }

	// RVA: 0x6EC2D10
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EC35DC
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EC36CC
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EC381C
	public override object ConvertValue(object value) { }

	// RVA: 0x6EC3990
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EC39FC
	public override object Get(object record) { }

	// RVA: 0x6EC3AEC
	public override object Set(object record, object value) { }

	// RVA: 0x6EC3CD4
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EC3D9C
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EC3E30
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EC3EEC
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EC3F40
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EC4060
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: System.Data.Common
internal sealed class UInt64Storage
{

	// Fields
	private static readonly object s_defaultValue; // 0x0
	private object _values; // 0x48

	// Methods

	// RVA: 0x6EC4118
	public object .ctor(object column) { }

	// RVA: 0x6EC4240
	public override object Aggregate(object records, object kind) { }

	// RVA: 0x6EC4AE8
	public override object Compare(object recordNo1, object recordNo2) { }

	// RVA: 0x6EC4BFC
	public override object CompareValueTo(object recordNo, object value) { }

	// RVA: 0x6EC4D4C
	public override object ConvertValue(object value) { }

	// RVA: 0x6EC4EC0
	public override object Copy(object recordNo1, object recordNo2) { }

	// RVA: 0x6EC4F2C
	public override object Get(object record) { }

	// RVA: 0x6EC501C
	public override object Set(object record, object value) { }

	// RVA: 0x6EC5204
	public override object SetCapacity(object capacity) { }

	// RVA: 0x6EC52CC
	public override object ConvertXmlToObject(object s) { }

	// RVA: 0x6EC5360
	public override object ConvertObjectToXml(object value) { }

	// RVA: 0x6EC541C
	protected override object GetEmptyStorage(object recordCount) { }

	// RVA: 0x6EC5470
	protected override object CopyValue(object record, object store, object nullbits, object storeIndex) { }

	// RVA: 0x6EC5590
	protected override object SetStorage(object store, object nullbits) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=36
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=38
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=52
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=64
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=152
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=176
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 39A47A6A540EB845B37C85CE8C346359A0DB937D4AAF7A74A6C207205E0BC61E; // 0x0
	internal static readonly object 540CD885F06B2760118EA5544E069ACE0C5D184B85D9D104417C14F1E536376D; // 0x98
	internal static readonly object 5857EE4CE98BFABBD62B385C1098507DD0052FF3951043AAD6A1DABD495F18AA; // 0xBE
	internal static readonly object 8D4DC488705859D6A837A660BDBA9E88D1BD229BC39DB97734072D04BD513ECD; // 0xF2
	internal static readonly object BA1E68F004F9EFDE72987E33682A8A5C579C4A609FBECE4F6EDBB844431D9226; // 0x116
	internal static readonly object C44E90B8C219817ECD3C403823D4770C0F744358EBF32A4282B3CE0338D4602E; // 0x1AE
	internal static readonly object D44900CF81FC3D53E7F8D2FCB6EF3B50B39ED1A857628FA737F5B4B7E0382939; // 0x246
	internal static readonly object E29424929B12EB1FDF4FD2E4911E09644CB58261C6033211F88022DDED785AE6; // 0x2DE
	internal static readonly object F327BBE8D18E0318C5295B25F9A8BA9B3AFE1F44C3C244BB3921AFEB578F1591; // 0x38E
	internal static readonly object FADB218011E7702BB9575D0C32A685DA10B5C72EB809BD9A955DB1C76E4D8315; // 0x3CE
}

