// Namespace: 
internal class <Module>
{
}

// Namespace: 
internal static class SR
{

	// Methods

	// RVA: 0x6CC5B90
	internal static object GetString(object name) { }

	// RVA: 0x6CC5B94
	internal static object Format(object resourceFormat, object args) { }

	// RVA: 0x6CC5C20
	internal static object Format(object resourceFormat, object p1) { }

	// RVA: 0x6CC5C94
	internal static object Format(object resourceFormat, object p1, object p2) { }

	// RVA: 0x6CC5D18
	internal static object Format(object resourceFormat, object p1, object p2, object p3) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13, object arg14) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13, object arg14, object arg15) { }

}

// Namespace: System
public sealed class Action<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13, object arg14, object arg15, object arg16) { }

}

// Namespace: System
public sealed class Func<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9) { }

}

// Namespace: System
public sealed class Func<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10) { }

}

// Namespace: System
public sealed class Func<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11) { }

}

// Namespace: System
public sealed class Func<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12) { }

}

// Namespace: System
public sealed class Func<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13) { }

}

// Namespace: System
public sealed class Func<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13, object arg14) { }

}

// Namespace: System
public sealed class Func<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13, object arg14, object arg15) { }

}

// Namespace: System
public sealed class Func<T0, T1, T2, T3, T4, T5, T6, T7, T8, T9, T10, T11, T12, T13, T14, T15, T16>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13, object arg14, object arg15, object arg16) { }

}

// Namespace: System.Security.Cryptography
public sealed class IncrementalHash
{

	// Fields
	private readonly object _algorithmName; // 0x8
	private object _hash; // 0x10
	private object _disposed; // 0x18
	private object _resetPending; // 0x19

	// Methods

	// RVA: 0x6CC5DA4
	private object .ctor(object name, object hash) { }

	// RVA: 0x6CC5DDC
	public object AppendData(object data, object offset, object count) { }

	// RVA: 0x6CC6070
	public object GetHashAndReset() { }

	// RVA: 0x6CC62A4
	public object Dispose() { }

	// RVA: 0x6CC62DC
	public static object CreateHMAC(object hashAlgorithm, object key) { }

	// RVA: 0x6CC6410
	private static object GetHMAC(object hashAlgorithm, object key) { }

}

// Namespace: System.Security.Cryptography
public sealed class AesManaged
{

	// Fields
	private object m_rijndael; // 0x40

	// Properties
	public override object FeedbackSize { get; }
	public override object IV { get; set; }
	public override object Key { get; set; }
	public override object KeySize { get; set; }
	public override object Mode { get; set; }
	public override object Padding { get; set; }

	// Methods

	// RVA: 0x6CC6644
	public object .ctor() { }

	// RVA: 0x6CC6850
	public override object get_FeedbackSize() { }

	// RVA: 0x6CC689C
	public override object get_IV() { }

	// RVA: 0x6CC68E8
	public override object set_IV(object value) { }

	// RVA: 0x6CC693C
	public override object get_Key() { }

	// RVA: 0x6CC6988
	public override object set_Key(object value) { }

	// RVA: 0x6CC69DC
	public override object get_KeySize() { }

	// RVA: 0x6CC6A2C
	public override object set_KeySize(object value) { }

	// RVA: 0x6CC6A84
	public override object get_Mode() { }

	// RVA: 0x6CC6AD4
	public override object set_Mode(object value) { }

	// RVA: 0x6CC6B80
	public override object get_Padding() { }

	// RVA: 0x6CC6BD0
	public override object set_Padding(object value) { }

	// RVA: 0x6CC6C28
	public override object CreateDecryptor() { }

	// RVA: 0x6CC6C78
	public override object CreateDecryptor(object key, object iv) { }

	// RVA: 0x6CC6DE4
	public override object CreateEncryptor() { }

	// RVA: 0x6CC6E34
	public override object CreateEncryptor(object key, object iv) { }

	// RVA: 0x6CC6FA0
	protected override object Dispose(object disposing) { }

	// RVA: 0x6CC7170
	public override object GenerateIV() { }

	// RVA: 0x6CC71C0
	public override object GenerateKey() { }

}

// Namespace: System.Security.Cryptography
public sealed class AesCryptoServiceProvider
{

	// Properties
	public override object IV { get; set; }
	public override object Key { get; set; }
	public override object KeySize { get; set; }
	public override object FeedbackSize { get; }
	public override object Mode { get; set; }
	public override object Padding { get; set; }

	// Methods

	// RVA: 0x6CC7210
	public object .ctor() { }

	// RVA: 0x6CC7280
	public override object GenerateIV() { }

	// RVA: 0x6CC72B0
	public override object GenerateKey() { }

	// RVA: 0x6CC72E0
	public override object CreateDecryptor(object key, object iv) { }

	// RVA: 0x6CC7C14
	public override object CreateEncryptor(object key, object iv) { }

	// RVA: 0x6CC7D30
	public override object get_IV() { }

	// RVA: 0x6CC7D38
	public override object set_IV(object value) { }

	// RVA: 0x6CC7D40
	public override object get_Key() { }

	// RVA: 0x6CC7D48
	public override object set_Key(object value) { }

	// RVA: 0x6CC7D50
	public override object get_KeySize() { }

	// RVA: 0x6CC7D58
	public override object set_KeySize(object value) { }

	// RVA: 0x6CC7D60
	public override object get_FeedbackSize() { }

	// RVA: 0x6CC7D68
	public override object get_Mode() { }

	// RVA: 0x6CC7D70
	public override object set_Mode(object value) { }

	// RVA: 0x6CC7DD4
	public override object get_Padding() { }

	// RVA: 0x6CC7DDC
	public override object set_Padding(object value) { }

	// RVA: 0x6CC7DE4
	public override object CreateDecryptor() { }

	// RVA: 0x6CC7E84
	public override object CreateEncryptor() { }

	// RVA: 0x6CC7F24
	protected override object Dispose(object disposing) { }

}

// Namespace: System.Security.Cryptography
internal class AesTransform
{

	// Fields
	private object expandedKey; // 0x50
	private object Nk; // 0x58
	private object Nr; // 0x5C
	private static readonly object Rcon; // 0x0
	private static readonly object SBox; // 0x8
	private static readonly object iSBox; // 0x10
	private static readonly object T0; // 0x18
	private static readonly object T1; // 0x20
	private static readonly object T2; // 0x28
	private static readonly object T3; // 0x30
	private static readonly object iT0; // 0x38
	private static readonly object iT1; // 0x40
	private static readonly object iT2; // 0x48
	private static readonly object iT3; // 0x50

	// Methods

	// RVA: 0x6CC73FC
	public object .ctor(object algo, object encryption, object key, object iv) { }

	// RVA: 0x6CC8018
	protected override object ECB(object input, object output) { }

	// RVA: 0x6CC7F2C
	private object SubByte(object a) { }

	// RVA: 0x6CC8030
	private object Encrypt128(object indata, object outdata, object ekey) { }

	// RVA: 0x6CC9D3C
	private object Decrypt128(object indata, object outdata, object ekey) { }

	// RVA: 0x6CCBA54
	private static object .cctor() { }

}

// Namespace: System.Security.Cryptography.X509Certificates
public static class RSACertificateExtensions
{

	// Methods

	// RVA: 0x6CCBD70
	public static object GetRSAPublicKey(object certificate) { }

}

// Namespace: System.Linq
internal static class Error
{

	// Methods

	// RVA: 0x6CCBE68
	internal static object ArgumentNull(object s) { }

	// RVA: 0x6CCBED0
	internal static object ArgumentOutOfRange(object s) { }

	// RVA: 0x6CCBF38
	internal static object MoreThanOneElement() { }

	// RVA: 0x6CCBFB0
	internal static object MoreThanOneMatch() { }

	// RVA: 0x6CCC028
	internal static object NoElements() { }

	// RVA: 0x6CCC0A0
	internal static object NoMatch() { }

	// RVA: 0x6CCC118
	internal static object NotSupported() { }

}

// Namespace: 
private abstract class Iterator<T0>
{

	// Fields
	private object threadId; // 0x0
	internal object state; // 0x0
	internal object current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public abstract object Clone() { }

	// RVA: -1
	public virtual object Dispose() { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	public abstract object MoveNext() { }

	// RVA: -1
	public abstract object Select(object selector) { }

	// RVA: -1
	public abstract object Where(object predicate) { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: 
private class WhereEnumerableIterator<T0>
{

	// Fields
	private object source; // 0x0
	private object predicate; // 0x0
	private object enumerator; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object source, object predicate) { }

	// RVA: -1
	public override object Clone() { }

	// RVA: -1
	public override object Dispose() { }

	// RVA: -1
	public override object MoveNext() { }

	// RVA: -1
	public override object Select(object selector) { }

	// RVA: -1
	public override object Where(object predicate) { }

}

// Namespace: 
private class WhereArrayIterator<T0>
{

	// Fields
	private object source; // 0x0
	private object predicate; // 0x0
	private object index; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object source, object predicate) { }

	// RVA: -1
	public override object Clone() { }

	// RVA: -1
	public override object MoveNext() { }

	// RVA: -1
	public override object Select(object selector) { }

	// RVA: -1
	public override object Where(object predicate) { }

}

// Namespace: 
private class WhereListIterator<T0>
{

	// Fields
	private object source; // 0x0
	private object predicate; // 0x0
	private object enumerator; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object source, object predicate) { }

	// RVA: -1
	public override object Clone() { }

	// RVA: -1
	public override object MoveNext() { }

	// RVA: -1
	public override object Select(object selector) { }

	// RVA: -1
	public override object Where(object predicate) { }

}

// Namespace: 
private class WhereSelectEnumerableIterator<T0, T1>
{

	// Fields
	private object source; // 0x0
	private object predicate; // 0x0
	private object selector; // 0x0
	private object enumerator; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object source, object predicate, object selector) { }

	// RVA: -1
	public override object Clone() { }

	// RVA: -1
	public override object Dispose() { }

	// RVA: -1
	public override object MoveNext() { }

	// RVA: -1
	public override object Select(object selector) { }

	// RVA: -1
	public override object Where(object predicate) { }

}

// Namespace: 
private class WhereSelectArrayIterator<T0, T1>
{

	// Fields
	private object source; // 0x0
	private object predicate; // 0x0
	private object selector; // 0x0
	private object index; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object source, object predicate, object selector) { }

	// RVA: -1
	public override object Clone() { }

	// RVA: -1
	public override object MoveNext() { }

	// RVA: -1
	public override object Select(object selector) { }

	// RVA: -1
	public override object Where(object predicate) { }

}

// Namespace: 
private class WhereSelectListIterator<T0, T1>
{

	// Fields
	private object source; // 0x0
	private object predicate; // 0x0
	private object selector; // 0x0
	private object enumerator; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object source, object predicate, object selector) { }

	// RVA: -1
	public override object Clone() { }

	// RVA: -1
	public override object MoveNext() { }

	// RVA: -1
	public override object Select(object selector) { }

	// RVA: -1
	public override object Where(object predicate) { }

}

// Namespace: 
private sealed class <SelectIterator>d__5<T0, T1>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object source; // 0x0
	public object <>3__source; // 0x0
	private object selector; // 0x0
	public object <>3__selector; // 0x0
	private object <index>5__2; // 0x0
	private object <>7__wrap2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0<T0>
{

	// Fields
	public object predicate1; // 0x0
	public object predicate2; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CombinePredicates>b__0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass7_0<T0, T1, T2>
{

	// Fields
	public object selector2; // 0x0
	public object selector1; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CombineSelectors>b__0(object x) { }

}

// Namespace: 
private sealed class <SelectManyIterator>d__17<T0, T1>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object source; // 0x0
	public object <>3__source; // 0x0
	private object selector; // 0x0
	public object <>3__selector; // 0x0
	private object <>7__wrap1; // 0x0
	private object <>7__wrap2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object <>m__Finally2() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <SelectManyIterator>d__23<T0, T1, T2>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object source; // 0x0
	public object <>3__source; // 0x0
	private object collectionSelector; // 0x0
	public object <>3__collectionSelector; // 0x0
	private object resultSelector; // 0x0
	public object <>3__resultSelector; // 0x0
	private object <>7__wrap1; // 0x0
	private object <element>5__3; // 0x0
	private object <>7__wrap3; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object <>m__Finally2() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <TakeIterator>d__25<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object count; // 0x0
	public object <>3__count; // 0x0
	private object source; // 0x0
	public object <>3__source; // 0x0
	private object <>7__wrap1; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <SkipIterator>d__31<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object source; // 0x0
	public object <>3__source; // 0x0
	private object count; // 0x0
	public object <>3__count; // 0x0
	private object <e>5__2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <JoinIterator>d__38<T0, T1, T2, T3>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object inner; // 0x0
	public object <>3__inner; // 0x0
	private object innerKeySelector; // 0x0
	public object <>3__innerKeySelector; // 0x0
	private object comparer; // 0x0
	public object <>3__comparer; // 0x0
	private object outer; // 0x0
	public object <>3__outer; // 0x0
	private object outerKeySelector; // 0x0
	public object <>3__outerKeySelector; // 0x0
	private object resultSelector; // 0x0
	public object <>3__resultSelector; // 0x0
	private object <lookup>5__2; // 0x0
	private object <>7__wrap2; // 0x0
	private object <item>5__4; // 0x0
	private object <g>5__5; // 0x0
	private object <i>5__6; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <ConcatIterator>d__59<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object first; // 0x0
	public object <>3__first; // 0x0
	private object second; // 0x0
	public object <>3__second; // 0x0
	private object <>7__wrap1; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object <>m__Finally2() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <DistinctIterator>d__68<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object comparer; // 0x0
	public object <>3__comparer; // 0x0
	private object source; // 0x0
	public object <>3__source; // 0x0
	private object <set>5__2; // 0x0
	private object <>7__wrap2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <UnionIterator>d__71<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object comparer; // 0x0
	public object <>3__comparer; // 0x0
	private object first; // 0x0
	public object <>3__first; // 0x0
	private object second; // 0x0
	public object <>3__second; // 0x0
	private object <set>5__2; // 0x0
	private object <>7__wrap2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object <>m__Finally2() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <ReverseIterator>d__79<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object source; // 0x0
	public object <>3__source; // 0x0
	private object <buffer>5__2; // 0x0
	private object <i>5__3; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TSource>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TSource>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TSource>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <CastIterator>d__99<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object source; // 0x0
	public object <>3__source; // 0x0
	private object <>7__wrap1; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <RangeIterator>d__115
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x10
	private object start; // 0x14
	public object <>3__start; // 0x18
	private object count; // 0x1C
	public object <>3__count; // 0x20
	private object <i>5__2; // 0x24

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Int32>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6CCC2BC
	public object .ctor(object <>1__state) { }

	// RVA: 0x6CCD4EC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6CCD4F0
	private object MoveNext() { }

	// RVA: 0x6CCD558
	private object System.Collections.Generic.IEnumerator<System.Int32>.get_Current() { }

	// RVA: 0x6CCD560
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6CCD5A0
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x6CCD608
	private object System.Collections.Generic.IEnumerable<System.Int32>.GetEnumerator() { }

	// RVA: 0x6CCD6B4
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <RepeatIterator>d__117<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object element; // 0x0
	public object <>3__element; // 0x0
	private object count; // 0x0
	public object <>3__count; // 0x0
	private object <i>5__2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TResult>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TResult>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<TResult>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Linq
public static class Enumerable
{

	// Methods

	// RVA: -1
	public static object Where(object source, object predicate) { }

	// RVA: -1
	public static object Select(object source, object selector) { }

	// RVA: -1
	public static object Select(object source, object selector) { }

	// RVA: -1
	private static object SelectIterator(object source, object selector) { }

	// RVA: -1
	private static object CombinePredicates(object predicate1, object predicate2) { }

	// RVA: -1
	private static object CombineSelectors(object selector1, object selector2) { }

	// RVA: -1
	public static object SelectMany(object source, object selector) { }

	// RVA: -1
	private static object SelectManyIterator(object source, object selector) { }

	// RVA: -1
	public static object SelectMany(object source, object collectionSelector, object resultSelector) { }

	// RVA: -1
	private static object SelectManyIterator(object source, object collectionSelector, object resultSelector) { }

	// RVA: -1
	public static object Take(object source, object count) { }

	// RVA: -1
	private static object TakeIterator(object source, object count) { }

	// RVA: -1
	public static object Skip(object source, object count) { }

	// RVA: -1
	private static object SkipIterator(object source, object count) { }

	// RVA: -1
	public static object Join(object outer, object inner, object outerKeySelector, object innerKeySelector, object resultSelector) { }

	// RVA: -1
	private static object JoinIterator(object outer, object inner, object outerKeySelector, object innerKeySelector, object resultSelector, object comparer) { }

	// RVA: -1
	public static object OrderBy(object source, object keySelector) { }

	// RVA: -1
	public static object OrderByDescending(object source, object keySelector) { }

	// RVA: -1
	public static object ThenBy(object source, object keySelector) { }

	// RVA: -1
	public static object ThenByDescending(object source, object keySelector) { }

	// RVA: -1
	public static object GroupBy(object source, object keySelector) { }

	// RVA: -1
	public static object GroupBy(object source, object keySelector, object elementSelector) { }

	// RVA: -1
	public static object Concat(object first, object second) { }

	// RVA: -1
	private static object ConcatIterator(object first, object second) { }

	// RVA: -1
	public static object Distinct(object source) { }

	// RVA: -1
	private static object DistinctIterator(object source, object comparer) { }

	// RVA: -1
	public static object Union(object first, object second) { }

	// RVA: -1
	private static object UnionIterator(object first, object second, object comparer) { }

	// RVA: -1
	public static object Reverse(object source) { }

	// RVA: -1
	private static object ReverseIterator(object source) { }

	// RVA: -1
	public static object SequenceEqual(object first, object second) { }

	// RVA: -1
	public static object SequenceEqual(object first, object second, object comparer) { }

	// RVA: -1
	public static object ToArray(object source) { }

	// RVA: -1
	public static object ToList(object source) { }

	// RVA: -1
	public static object ToDictionary(object source, object keySelector, object elementSelector) { }

	// RVA: -1
	public static object ToDictionary(object source, object keySelector, object elementSelector, object comparer) { }

	// RVA: -1
	public static object Cast(object source) { }

	// RVA: -1
	private static object CastIterator(object source) { }

	// RVA: -1
	public static object First(object source) { }

	// RVA: -1
	public static object First(object source, object predicate) { }

	// RVA: -1
	public static object FirstOrDefault(object source) { }

	// RVA: -1
	public static object FirstOrDefault(object source, object predicate) { }

	// RVA: -1
	public static object Last(object source) { }

	// RVA: -1
	public static object LastOrDefault(object source, object predicate) { }

	// RVA: -1
	public static object Single(object source) { }

	// RVA: -1
	public static object Single(object source, object predicate) { }

	// RVA: -1
	public static object SingleOrDefault(object source) { }

	// RVA: -1
	public static object SingleOrDefault(object source, object predicate) { }

	// RVA: -1
	public static object ElementAt(object source, object index) { }

	// RVA: 0x6CCC170
	public static object Range(object start, object count) { }

	// RVA: 0x6CCC238
	private static object RangeIterator(object start, object count) { }

	// RVA: -1
	public static object Repeat(object element, object count) { }

	// RVA: -1
	private static object RepeatIterator(object element, object count) { }

	// RVA: -1
	public static object Empty() { }

	// RVA: -1
	public static object Any(object source) { }

	// RVA: -1
	public static object Any(object source, object predicate) { }

	// RVA: -1
	public static object All(object source, object predicate) { }

	// RVA: -1
	public static object Count(object source) { }

	// RVA: -1
	public static object Count(object source, object predicate) { }

	// RVA: -1
	public static object Contains(object source, object value) { }

	// RVA: -1
	public static object Contains(object source, object value, object comparer) { }

	// RVA: -1
	public static object Aggregate(object source, object func) { }

	// RVA: -1
	public static object Aggregate(object source, object seed, object func) { }

	// RVA: 0x6CCC2F4
	public static object Sum(object source) { }

	// RVA: 0x6CCC678
	public static object Min(object source) { }

	// RVA: 0x6CCC9F8
	public static object Max(object source) { }

	// RVA: 0x6CCCD78
	public static object Max(object source) { }

	// RVA: 0x6CCD120
	public static object Average(object source) { }

}

// Namespace: System.Linq
internal class EmptyEnumerable<T0>
{

	// Fields
	public static readonly object Instance; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__1_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <get_Instance>b__1_0(object x) { }

}

// Namespace: System.Linq
internal class IdentityFunction<T0>
{

	// Properties
	public static object Instance { get; }

	// Methods

	// RVA: -1
	public static object get_Instance() { }

}

// Namespace: System.Linq
public interface IOrderedEnumerable<T0>
{

	// Methods

	// RVA: -1
	public abstract object CreateOrderedEnumerable(object keySelector, object comparer, object descending) { }

}

// Namespace: System.Linq
public interface IGrouping<T0, T1>
{

	// Properties
	public abstract object Key { get; }

	// Methods

	// RVA: -1
	public abstract object get_Key() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__7
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	public object <>4__this; // 0x0
	private object <i>5__2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TElement>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TElement>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
internal class Grouping
{

	// Fields
	internal object key; // 0x0
	internal object hashCode; // 0x0
	internal object elements; // 0x0
	internal object count; // 0x0
	internal object hashNext; // 0x0
	internal object next; // 0x0

	// Properties
	public object Key { get; }
	private object System.Collections.Generic.ICollection<TElement>.Count { get; }
	private object System.Collections.Generic.ICollection<TElement>.IsReadOnly { get; }
	private object System.Collections.Generic.IList<TElement>.Item { get; set; }

	// Methods

	// RVA: -1
	internal object Add(object element) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object get_Key() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TElement>.get_Count() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TElement>.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TElement>.Add(object item) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TElement>.Clear() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TElement>.Contains(object item) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TElement>.CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<TElement>.Remove(object item) { }

	// RVA: -1
	private object System.Collections.Generic.IList<TElement>.IndexOf(object item) { }

	// RVA: -1
	private object System.Collections.Generic.IList<TElement>.Insert(object index, object item) { }

	// RVA: -1
	private object System.Collections.Generic.IList<TElement>.RemoveAt(object index) { }

	// RVA: -1
	private object System.Collections.Generic.IList<TElement>.get_Item(object index) { }

	// RVA: -1
	private object System.Collections.Generic.IList<TElement>.set_Item(object index, object value) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__12
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	public object <>4__this; // 0x0
	private object <g>5__2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Linq.IGrouping<TKey,TElement>>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<System.Linq.IGrouping<TKey,TElement>>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Linq
public class Lookup<T0, T1>
{

	// Fields
	private object comparer; // 0x0
	private object groupings; // 0x0
	private object lastGrouping; // 0x0
	private object count; // 0x0

	// Methods

	// RVA: -1
	internal static object Create(object source, object keySelector, object elementSelector, object comparer) { }

	// RVA: -1
	internal static object CreateForJoin(object source, object keySelector, object comparer) { }

	// RVA: -1
	private object .ctor(object comparer) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	internal object InternalGetHashCode(object key) { }

	// RVA: -1
	internal object GetGrouping(object key, object create) { }

	// RVA: -1
	private object Resize() { }

}

// Namespace: 
internal struct Slot
{

	// Fields
	internal object hashCode; // 0x0
	internal object value; // 0x0
	internal object next; // 0x0
}

// Namespace: System.Linq
internal class Set<T0>
{

	// Fields
	private object buckets; // 0x0
	private object slots; // 0x0
	private object count; // 0x0
	private object freeList; // 0x0
	private object comparer; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	public object Add(object value) { }

	// RVA: -1
	private object Find(object value, object add) { }

	// RVA: -1
	private object Resize() { }

	// RVA: -1
	internal object InternalGetHashCode(object value) { }

}

// Namespace: System.Linq
internal class GroupedEnumerable<T0, T1, T2>
{

	// Fields
	private object source; // 0x0
	private object keySelector; // 0x0
	private object elementSelector; // 0x0
	private object comparer; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object source, object keySelector, object elementSelector, object comparer) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__1
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	public object <>4__this; // 0x0
	private object <buffer>5__2; // 0x0
	private object <map>5__3; // 0x0
	private object <i>5__4; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<TElement>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<TElement>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Linq
internal abstract class OrderedEnumerable<T0>
{

	// Fields
	internal object source; // 0x0

	// Methods

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	internal abstract object GetEnumerableSorter(object next) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Linq.IOrderedEnumerable<TElement>.CreateOrderedEnumerable(object keySelector, object comparer, object descending) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: System.Linq
internal class OrderedEnumerable<T0, T1>
{

	// Fields
	internal object parent; // 0x0
	internal object keySelector; // 0x0
	internal object comparer; // 0x0
	internal object descending; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor(object source, object keySelector, object comparer, object descending) { }

	// RVA: -1
	internal override object GetEnumerableSorter(object next) { }

}

// Namespace: System.Linq
internal abstract class EnumerableSorter<T0>
{

	// Methods

	// RVA: -1
	internal abstract object ComputeKeys(object elements, object count) { }

	// RVA: -1
	internal abstract object CompareKeys(object index1, object index2) { }

	// RVA: -1
	internal object Sort(object elements, object count) { }

	// RVA: -1
	private object QuickSort(object map, object left, object right) { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: System.Linq
internal class EnumerableSorter<T0, T1>
{

	// Fields
	internal object keySelector; // 0x0
	internal object comparer; // 0x0
	internal object descending; // 0x0
	internal object next; // 0x0
	internal object keys; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor(object keySelector, object comparer, object descending, object next) { }

	// RVA: -1
	internal override object ComputeKeys(object elements, object count) { }

	// RVA: -1
	internal override object CompareKeys(object index1, object index2) { }

}

// Namespace: System.Linq
internal struct Buffer<T0>
{

	// Fields
	internal object items; // 0x0
	internal object count; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor(object source) { }

	// RVA: -1
	internal object ToArray() { }

}

// Namespace: System.Linq.Expressions
internal static class CachedReflectionInfo
{

	// Fields
	private static object s_CallSiteOps_SetNotMatched; // 0x0
	private static object s_CallSiteOps_CreateMatchmaker; // 0x8
	private static object s_CallSiteOps_GetMatch; // 0x10
	private static object s_CallSiteOps_ClearMatch; // 0x18
	private static object s_CallSiteOps_UpdateRules; // 0x20
	private static object s_CallSiteOps_GetRules; // 0x28
	private static object s_CallSiteOps_GetRuleCache; // 0x30
	private static object s_CallSiteOps_GetCachedRules; // 0x38
	private static object s_CallSiteOps_AddRule; // 0x40
	private static object s_CallSiteOps_MoveRule; // 0x48
	private static object s_CallSiteOps_Bind; // 0x50
	private static object s_String_op_Equality_String_String; // 0x58
	private static object s_Math_Pow_Double_Double; // 0x60

	// Properties
	public static object CallSiteOps_SetNotMatched { get; }
	public static object CallSiteOps_CreateMatchmaker { get; }
	public static object CallSiteOps_GetMatch { get; }
	public static object CallSiteOps_ClearMatch { get; }
	public static object CallSiteOps_UpdateRules { get; }
	public static object CallSiteOps_GetRules { get; }
	public static object CallSiteOps_GetRuleCache { get; }
	public static object CallSiteOps_GetCachedRules { get; }
	public static object CallSiteOps_AddRule { get; }
	public static object CallSiteOps_MoveRule { get; }
	public static object CallSiteOps_Bind { get; }
	public static object String_op_Equality_String_String { get; }
	public static object Math_Pow_Double_Double { get; }

	// Methods

	// RVA: 0x6CCD760
	public static object get_CallSiteOps_SetNotMatched() { }

	// RVA: 0x6CCD840
	public static object get_CallSiteOps_CreateMatchmaker() { }

	// RVA: 0x6CCD920
	public static object get_CallSiteOps_GetMatch() { }

	// RVA: 0x6CCDA00
	public static object get_CallSiteOps_ClearMatch() { }

	// RVA: 0x6CCDAE0
	public static object get_CallSiteOps_UpdateRules() { }

	// RVA: 0x6CCDBC0
	public static object get_CallSiteOps_GetRules() { }

	// RVA: 0x6CCDCA0
	public static object get_CallSiteOps_GetRuleCache() { }

	// RVA: 0x6CCDD80
	public static object get_CallSiteOps_GetCachedRules() { }

	// RVA: 0x6CCDE60
	public static object get_CallSiteOps_AddRule() { }

	// RVA: 0x6CCDF40
	public static object get_CallSiteOps_MoveRule() { }

	// RVA: 0x6CCE020
	public static object get_CallSiteOps_Bind() { }

	// RVA: 0x6CCE100
	public static object get_String_op_Equality_String_String() { }

	// RVA: 0x6CCE2B4
	public static object get_Math_Pow_Double_Double() { }

}

// Namespace: System.Linq.Expressions
public class BinaryExpression
{

	// Fields
	private readonly object <Right>k__BackingField; // 0x8
	private readonly object <Left>k__BackingField; // 0x10

	// Properties
	public override object CanReduce { get; }
	public object Right { get; }
	public object Left { get; }
	public object Method { get; }
	public object Conversion { get; }
	public object IsLifted { get; }
	public object IsLiftedToNull { get; }
	internal object IsLiftedLogical { get; }
	internal object IsReferenceComparison { get; }

	// Methods

	// RVA: 0x6CCE47C
	internal object .ctor(object left, object right) { }

	// RVA: 0x6CCE500
	public override object get_CanReduce() { }

	// RVA: 0x6CCE550
	private static object IsOpAssignment(object op) { }

	// RVA: 0x6CCE560
	public object get_Right() { }

	// RVA: 0x6CCE568
	public object get_Left() { }

	// RVA: 0x6CCE570
	public object get_Method() { }

	// RVA: 0x6CCE5B0
	internal virtual object GetMethod() { }

	// RVA: 0x6CCE5B8
	public object Update(object left, object conversion, object right) { }

	// RVA: 0x6CCF964
	public override object Reduce() { }

	// RVA: 0x6CD089C
	private static object GetBinaryOpFromAssignmentOp(object op) { }

	// RVA: 0x6CD06CC
	private object ReduceVariable() { }

	// RVA: 0x6CCFA2C
	private object ReduceMember() { }

	// RVA: 0x6CD0034
	private object ReduceIndex() { }

	// RVA: 0x6CCE810
	public object get_Conversion() { }

	// RVA: 0x6CD12D8
	internal virtual object GetConversion() { }

	// RVA: 0x6CD12E0
	public object get_IsLifted() { }

	// RVA: 0x6CCEDE0
	public object get_IsLiftedToNull() { }

	// RVA: 0x6CD1550
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CD15A4
	internal object get_IsLiftedLogical() { }

	// RVA: 0x6CCE850
	internal object get_IsReferenceComparison() { }

	// RVA: 0x6CD17CC
	internal object ReduceUserdefinedLifted() { }

}

// Namespace: System.Linq.Expressions
internal sealed class LogicalBinaryExpression
{

	// Fields
	private readonly object <NodeType>k__BackingField; // 0x18

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }

	// Methods

	// RVA: 0x6CD2FC8
	internal object .ctor(object nodeType, object left, object right) { }

	// RVA: 0x6CD304C
	public sealed override object get_Type() { }

	// RVA: 0x6CD30EC
	public sealed override object get_NodeType() { }

}

// Namespace: System.Linq.Expressions
internal class AssignBinaryExpression
{

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }

	// Methods

	// RVA: 0x6CD30F4
	internal object .ctor(object left, object right) { }

	// RVA: 0x6CD3170
	public sealed override object get_Type() { }

	// RVA: 0x6CD31BC
	public sealed override object get_NodeType() { }

}

// Namespace: System.Linq.Expressions
internal sealed class CoalesceConversionBinaryExpression
{

	// Fields
	private readonly object _conversion; // 0x18

	// Properties
	public sealed override object NodeType { get; }
	public sealed override object Type { get; }

	// Methods

	// RVA: 0x6CD31C4
	internal object .ctor(object left, object right, object conversion) { }

	// RVA: 0x6CD3248
	internal override object GetConversion() { }

	// RVA: 0x6CD3250
	public sealed override object get_NodeType() { }

	// RVA: 0x6CD3258
	public sealed override object get_Type() { }

}

// Namespace: System.Linq.Expressions
internal sealed class OpAssignMethodConversionBinaryExpression
{

	// Fields
	private readonly object _conversion; // 0x30

	// Methods

	// RVA: 0x6CD32A4
	internal object .ctor(object nodeType, object left, object right, object type, object method, object conversion) { }

	// RVA: 0x6CD33E4
	internal override object GetConversion() { }

}

// Namespace: System.Linq.Expressions
internal class SimpleBinaryExpression
{

	// Fields
	private readonly object <NodeType>k__BackingField; // 0x18
	private readonly object <Type>k__BackingField; // 0x20

	// Properties
	public sealed override object NodeType { get; }
	public sealed override object Type { get; }

	// Methods

	// RVA: 0x6CD33EC
	internal object .ctor(object nodeType, object left, object right, object type) { }

	// RVA: 0x6CD3480
	public sealed override object get_NodeType() { }

	// RVA: 0x6CD3488
	public sealed override object get_Type() { }

}

// Namespace: System.Linq.Expressions
internal class MethodBinaryExpression
{

	// Fields
	private readonly object _method; // 0x28

	// Methods

	// RVA: 0x6CD334C
	internal object .ctor(object nodeType, object left, object right, object type, object method) { }

	// RVA: 0x6CD3490
	internal override object GetMethod() { }

}

// Namespace: 
internal class BinaryExpressionProxy
{
}

// Namespace: 
internal class BlockExpressionProxy
{
}

// Namespace: 
internal class CatchBlockProxy
{
}

// Namespace: 
internal class ConditionalExpressionProxy
{
}

// Namespace: 
internal class ConstantExpressionProxy
{
}

// Namespace: 
internal class DebugInfoExpressionProxy
{
}

// Namespace: 
internal class DefaultExpressionProxy
{
}

// Namespace: 
internal class GotoExpressionProxy
{
}

// Namespace: 
internal class IndexExpressionProxy
{
}

// Namespace: 
internal class InvocationExpressionProxy
{
}

// Namespace: 
internal class LabelExpressionProxy
{
}

// Namespace: 
internal class LambdaExpressionProxy
{
}

// Namespace: 
internal class ListInitExpressionProxy
{
}

// Namespace: 
internal class LoopExpressionProxy
{
}

// Namespace: 
internal class MemberExpressionProxy
{
}

// Namespace: 
internal class MemberInitExpressionProxy
{
}

// Namespace: 
internal class MethodCallExpressionProxy
{
}

// Namespace: 
internal class NewArrayExpressionProxy
{
}

// Namespace: 
internal class NewExpressionProxy
{
}

// Namespace: 
internal class ParameterExpressionProxy
{
}

// Namespace: 
internal class RuntimeVariablesExpressionProxy
{
}

// Namespace: 
internal class SwitchCaseProxy
{
}

// Namespace: 
internal class SwitchExpressionProxy
{
}

// Namespace: 
internal class TryExpressionProxy
{
}

// Namespace: 
internal class TypeBinaryExpressionProxy
{
}

// Namespace: 
internal class UnaryExpressionProxy
{
}

// Namespace: 
private class ExtensionInfo
{

	// Fields
	internal readonly object NodeType; // 0x8
	internal readonly object Type; // 0x10
}

// Namespace: System.Linq.Expressions
public abstract class Expression
{

	// Fields
	private static readonly object s_lambdaDelegateCache; // 0x0
	private static object s_lambdaFactories; // 0x8
	private static object s_legacyCtorSupportTable; // 0x10

	// Properties
	public virtual object NodeType { get; }
	public virtual object Type { get; }
	public virtual object CanReduce { get; }

	// Methods

	// RVA: 0x6CD0B08
	public static object Assign(object left, object right) { }

	// RVA: 0x6CD3774
	private static object GetUserDefinedBinaryOperator(object binaryType, object name, object left, object right, object liftToNull) { }

	// RVA: 0x6CD3E94
	private static object GetMethodBasedBinaryOperator(object binaryType, object left, object right, object method, object liftToNull) { }

	// RVA: 0x6CD4A98
	private static object GetMethodBasedAssignOperator(object binaryType, object left, object right, object method, object conversion, object liftToNull) { }

	// RVA: 0x6CD514C
	private static object GetUserDefinedBinaryOperatorOrThrow(object binaryType, object name, object left, object right, object liftToNull) { }

	// RVA: 0x6CD5420
	private static object GetUserDefinedAssignOperatorOrThrow(object binaryType, object name, object left, object right, object conversion, object liftToNull) { }

	// RVA: 0x6CD3C40
	private static object GetUserDefinedBinaryOperator(object binaryType, object leftType, object rightType, object name) { }

	// RVA: 0x6CD5780
	private static object IsLiftingConditionalLogicalOperator(object left, object right, object method, object binaryType) { }

	// RVA: 0x6CD48A4
	internal static object ParameterIsAssignable(object pi, object argType) { }

	// RVA: 0x6CD4990
	private static object ValidateParamswithOperandsOrThrow(object paramType, object operandType, object exprType, object name) { }

	// RVA: 0x6CD4704
	private static object ValidateOperator(object method) { }

	// RVA: 0x6CD588C
	private static object ValidateMethodInfo(object method, object paramName) { }

	// RVA: 0x6CD5938
	private static object IsNullComparison(object left, object right) { }

	// RVA: 0x6CD5BB4
	private static object IsNullConstant(object e) { }

	// RVA: 0x6CD5C44
	private static object ValidateUserDefinedConditionalLogicOperator(object nodeType, object left, object right, object method) { }

	// RVA: 0x6CD65D0
	private static object VerifyOpTrueFalse(object nodeType, object left, object opTrue, object paramName) { }

	// RVA: 0x6CD6460
	private static object IsValidLiftedConditionalLogicalOperator(object left, object right, object pms) { }

	// RVA: 0x6CD08E8
	public static object MakeBinary(object binaryType, object left, object right, object liftToNull, object method) { }

	// RVA: 0x6CCEE90
	public static object MakeBinary(object binaryType, object left, object right, object liftToNull, object method, object conversion) { }

	// RVA: 0x6CDE224
	public static object Equal(object left, object right) { }

	// RVA: 0x6CDA124
	public static object Equal(object left, object right, object liftToNull, object method) { }

	// RVA: 0x6CCE9C0
	public static object ReferenceEqual(object left, object right) { }

	// RVA: 0x6CDE8A8
	public static object NotEqual(object left, object right) { }

	// RVA: 0x6CDA258
	public static object NotEqual(object left, object right, object liftToNull, object method) { }

	// RVA: 0x6CCEBD0
	public static object ReferenceNotEqual(object left, object right) { }

	// RVA: 0x6CDE294
	private static object GetEqualityComparisonOperator(object binaryType, object opName, object left, object right, object liftToNull) { }

	// RVA: 0x6CD9EBC
	public static object GreaterThan(object left, object right, object liftToNull, object method) { }

	// RVA: 0x6CD9C54
	public static object LessThan(object left, object right, object liftToNull, object method) { }

	// RVA: 0x6CD9FF0
	public static object GreaterThanOrEqual(object left, object right, object liftToNull, object method) { }

	// RVA: 0x6CD9D88
	public static object LessThanOrEqual(object left, object right, object liftToNull, object method) { }

	// RVA: 0x6CDE918
	private static object GetComparisonOperator(object binaryType, object opName, object left, object right, object liftToNull) { }

	// RVA: 0x6CDEC3C
	public static object AndAlso(object left, object right) { }

	// RVA: 0x6CD87B0
	public static object AndAlso(object left, object right, object method) { }

	// RVA: 0x6CD92B8
	public static object OrElse(object left, object right, object method) { }

	// RVA: 0x6CDA68C
	public static object Coalesce(object left, object right, object conversion) { }

	// RVA: 0x6CDECA8
	private static object ValidateCoalesceArgTypes(object left, object right) { }

	// RVA: 0x6CD67D8
	public static object Add(object left, object right, object method) { }

	// RVA: 0x6CDB518
	public static object AddAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD4DF8
	private static object ValidateOpAssignConversionLambda(object conversion, object left, object method, object nodeType) { }

	// RVA: 0x6CDD804
	public static object AddAssignChecked(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD6AD4
	public static object AddChecked(object left, object right, object method) { }

	// RVA: 0x6CD6DD4
	public static object Subtract(object left, object right, object method) { }

	// RVA: 0x6CDD4A4
	public static object SubtractAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CDDB64
	public static object SubtractAssignChecked(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD70D4
	public static object SubtractChecked(object left, object right, object method) { }

	// RVA: 0x6CD79D4
	public static object Divide(object left, object right, object method) { }

	// RVA: 0x6CDBBD8
	public static object DivideAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD7CD4
	public static object Modulo(object left, object right, object method) { }

	// RVA: 0x6CDC5B4
	public static object ModuloAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD73D4
	public static object Multiply(object left, object right, object method) { }

	// RVA: 0x6CDC914
	public static object MultiplyAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CDDEC4
	public static object MultiplyAssignChecked(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD76D4
	public static object MultiplyChecked(object left, object right, object method) { }

	// RVA: 0x6CDEEA8
	private static object IsSimpleShift(object left, object right) { }

	// RVA: 0x6CDEFB8
	private static object GetResultTypeOfShift(object left, object right) { }

	// RVA: 0x6CDB25C
	public static object LeftShift(object left, object right, object method) { }

	// RVA: 0x6CDC298
	public static object LeftShiftAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CDAFA0
	public static object RightShift(object left, object right, object method) { }

	// RVA: 0x6CDD188
	public static object RightShiftAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD84B0
	public static object And(object left, object right, object method) { }

	// RVA: 0x6CDB878
	public static object AndAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD8FB8
	public static object Or(object left, object right, object method) { }

	// RVA: 0x6CDCC74
	public static object OrAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CDA38C
	public static object ExclusiveOr(object left, object right, object method) { }

	// RVA: 0x6CDBF38
	public static object ExclusiveOrAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CD7FD4
	public static object Power(object left, object right, object method) { }

	// RVA: 0x6CDCFD4
	public static object PowerAssign(object left, object right, object method, object conversion) { }

	// RVA: 0x6CDAD04
	public static object ArrayIndex(object array, object index) { }

	// RVA: 0x6CDF178
	public static object Block(object arg0, object arg1) { }

	// RVA: 0x6CDF238
	public static object Block(object arg0, object arg1, object arg2) { }

	// RVA: 0x6CDF32C
	public static object Block(object arg0, object arg1, object arg2, object arg3) { }

	// RVA: 0x6CDF454
	public static object Block(object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x6CDF5A8
	public static object Block(object expressions) { }

	// RVA: 0x6CDF67C
	public static object Block(object type, object expressions) { }

	// RVA: 0x6CDF7AC
	public static object Block(object type, object expressions) { }

	// RVA: 0x6CDFAE0
	public static object Block(object variables, object expressions) { }

	// RVA: 0x6CDFB6C
	public static object Block(object type, object variables, object expressions) { }

	// RVA: 0x6CD1004
	public static object Block(object variables, object expressions) { }

	// RVA: 0x6CDF874
	public static object Block(object type, object variables, object expressions) { }

	// RVA: 0x6CE07D8
	private static object BlockCore(object type, object variables, object expressions) { }

	// RVA: 0x6CE0BD4
	internal static object ValidateVariables(object varList, object collectionName) { }

	// RVA: 0x6CDFD94
	private static object GetOptimizedBlockExpression(object expressions) { }

	// RVA: 0x6CE0DE8
	public static object MakeCatchBlock(object type, object variable, object body, object filter) { }

	// RVA: 0x6CD2D5C
	public static object Condition(object test, object ifTrue, object ifFalse) { }

	// RVA: 0x6CE10A4
	public static object Condition(object test, object ifTrue, object ifFalse, object type) { }

	// RVA: 0x6CE1388
	public static object IfThen(object test, object ifTrue) { }

	// RVA: 0x6CE151C
	public static object Constant(object value) { }

	// RVA: 0x6CD2AC4
	public static object Constant(object value, object type) { }

	// RVA: 0x6CE146C
	public static object Empty() { }

	// RVA: 0x6CE1584
	public static object Default(object type) { }

	// RVA: 0x6CCE4F8
	protected object .ctor() { }

	// RVA: 0x6CE1644
	public virtual object get_NodeType() { }

	// RVA: 0x6CE1778
	public virtual object get_Type() { }

	// RVA: 0x6CE18AC
	public virtual object get_CanReduce() { }

	// RVA: 0x6CE18B4
	public virtual object Reduce() { }

	// RVA: 0x6CE1920
	protected internal virtual object VisitChildren(object visitor) { }

	// RVA: 0x6CE1B28
	protected internal virtual object Accept(object visitor) { }

	// RVA: 0x6CE19CC
	public object ReduceAndCheck() { }

	// RVA: 0x6CE1B7C
	public override object ToString() { }

	// RVA: 0x6CDFBE4
	private static object RequiresCanRead(object items, object paramName) { }

	// RVA: 0x6CD3498
	private static object RequiresCanWrite(object expression, object paramName) { }

	// RVA: 0x6CE1B84
	public static object Break(object target) { }

	// RVA: 0x6CE1D3C
	public static object Return(object target) { }

	// RVA: 0x6CE1DF4
	public static object Return(object target, object value) { }

	// RVA: 0x6CE1EB8
	public static object Goto(object target, object type) { }

	// RVA: 0x6CE1F28
	public static object Goto(object target, object value) { }

	// RVA: 0x6CE1C3C
	public static object MakeGoto(object kind, object target, object value, object type) { }

	// RVA: 0x6CE1FEC
	private static object ValidateGoto(object target, object value, object targetParameter, object valueParameter, object type) { }

	// RVA: 0x6CE21DC
	private static object ValidateGotoType(object expectedType, object value, object paramName) { }

	// RVA: 0x6CD11A0
	public static object MakeIndex(object instance, object indexer, object arguments) { }

	// RVA: 0x6CE29A0
	public static object ArrayAccess(object array, object indexes) { }

	// RVA: 0x6CE2458
	public static object ArrayAccess(object array, object indexes) { }

	// RVA: 0x6CE23A4
	public static object Property(object instance, object indexer, object arguments) { }

	// RVA: 0x6CE2A2C
	private static object MakeIndexProperty(object instance, object indexer, object paramName, object argList) { }

	// RVA: 0x6CE2AF4
	private static object ValidateIndexedProperty(object instance, object indexer, object paramName, object argList) { }

	// RVA: 0x6CE31D0
	private static object ValidateAccessor(object instance, object method, object indexes, object arguments, object paramName) { }

	// RVA: 0x6CE34B8
	private static object ValidateAccessorArgumentTypes(object method, object indexes, object arguments, object paramName) { }

	// RVA: 0x6CE3994
	internal static object Invoke(object expression) { }

	// RVA: 0x6CD097C
	internal static object Invoke(object expression, object arg0) { }

	// RVA: 0x6CE3D6C
	internal static object Invoke(object expression, object arg0, object arg1) { }

	// RVA: 0x6CE3F48
	internal static object Invoke(object expression, object arg0, object arg1, object arg2) { }

	// RVA: 0x6CE417C
	internal static object Invoke(object expression, object arg0, object arg1, object arg2, object arg3) { }

	// RVA: 0x6CE4400
	internal static object Invoke(object expression, object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x6CE46E4
	public static object Invoke(object expression, object arguments) { }

	// RVA: 0x6CE4770
	public static object Invoke(object expression, object arguments) { }

	// RVA: 0x6CE3AB4
	internal static object GetInvokeMethod(object expression) { }

	// RVA: 0x6CE527C
	public static object Label(object target) { }

	// RVA: 0x6CE5304
	public static object Label(object target, object defaultValue) { }

	// RVA: 0x6CE53EC
	public static object Label() { }

	// RVA: 0x6CE55B0
	public static object Label(object name) { }

	// RVA: 0x6CE56A8
	public static object Label(object type) { }

	// RVA: 0x6CE54E0
	public static object Label(object type, object name) { }

	// RVA: 0x6CE5730
	internal static object CreateLambda(object delegateType, object body, object name, object tailCall, object parameters) { }

	// RVA: -1
	public static object Lambda(object body, object parameters) { }

	// RVA: -1
	public static object Lambda(object body, object parameters) { }

	// RVA: -1
	public static object Lambda(object body, object tailCall, object parameters) { }

	// RVA: -1
	public static object Lambda(object body, object name, object tailCall, object parameters) { }

	// RVA: 0x6CE5C74
	public static object Lambda(object delegateType, object body, object parameters) { }

	// RVA: 0x6CE5CF4
	public static object Lambda(object delegateType, object body, object name, object tailCall, object parameters) { }

	// RVA: 0x6CE5DDC
	private static object ValidateLambdaArgs(object delegateType, object body, object parameters, object paramName) { }

	// RVA: 0x6CE6620
	public static object Loop(object body, object break, object continue) { }

	// RVA: 0x6CE6758
	public static object Field(object expression, object field) { }

	// RVA: 0x6CE6948
	public static object Field(object expression, object fieldName) { }

	// RVA: 0x6CD2190
	public static object Property(object expression, object propertyName) { }

	// RVA: 0x6CE6B50
	public static object Property(object expression, object property) { }

	// RVA: 0x6CD0E1C
	public static object MakeMemberAccess(object expression, object member) { }

	// RVA: 0x6CE6E78
	internal static object Call(object method) { }

	// RVA: 0x6CD2570
	public static object Call(object method, object arg0) { }

	// RVA: 0x6CD27B0
	public static object Call(object method, object arg0, object arg1) { }

	// RVA: 0x6CE70D4
	public static object Call(object method, object arg0, object arg1, object arg2) { }

	// RVA: 0x6CE73E4
	public static object Call(object method, object arg0, object arg1, object arg2, object arg3) { }

	// RVA: 0x6CE7764
	public static object Call(object method, object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x6CE7B54
	public static object Call(object method, object arguments) { }

	// RVA: 0x6CE7C90
	public static object Call(object method, object arguments) { }

	// RVA: 0x6CE8824
	public static object Call(object instance, object method) { }

	// RVA: 0x6CE7C18
	public static object Call(object instance, object method, object arguments) { }

	// RVA: 0x6CE89C4
	internal static object Call(object instance, object method, object arg0) { }

	// RVA: 0x6CE8BD0
	public static object Call(object instance, object method, object arg0, object arg1) { }

	// RVA: 0x6CE8E48
	public static object Call(object instance, object method, object arg0, object arg1, object arg2) { }

	// RVA: 0x6CD235C
	public static object Call(object instance, object methodName, object typeArguments, object arguments) { }

	// RVA: 0x6CE7CFC
	public static object Call(object instance, object method, object arguments) { }

	// RVA: 0x6CE703C
	private static object ValidateMethodAndGetParameters(object instance, object method) { }

	// RVA: 0x6CE942C
	private static object ValidateStaticOrInstanceMethod(object instance, object method) { }

	// RVA: 0x6CE33D8
	private static object ValidateCallInstanceType(object instanceType, object method) { }

	// RVA: 0x6CE5274
	private static object ValidateArgumentTypes(object method, object nodeKind, object arguments, object methodParamName) { }

	// RVA: 0x6CE3D50
	private static object GetParametersForValidation(object method, object nodeKind) { }

	// RVA: 0x6CE3D58
	private static object ValidateArgumentCount(object method, object nodeKind, object count, object pis) { }

	// RVA: 0x6CE3D60
	private static object ValidateOneArgument(object method, object nodeKind, object arg, object pi, object methodParamName, object argumentParamName) { }

	// RVA: 0x6CE239C
	private static object TryQuote(object parameterType, object argument) { }

	// RVA: 0x6CE912C
	private static object FindMethod(object type, object methodName, object typeArgs, object args, object flags) { }

	// RVA: 0x6CE967C
	private static object IsCompatible(object m, object arguments) { }

	// RVA: 0x6CE9554
	private static object ApplyTypeArgs(object m, object typeArgs) { }

	// RVA: 0x6CE99CC
	public static object NewArrayInit(object type, object initializers) { }

	// RVA: 0x6CE9A58
	public static object NewArrayInit(object type, object initializers) { }

	// RVA: 0x6CE9F00
	public static object NewArrayBounds(object type, object bounds) { }

	// RVA: 0x6CEA218
	public static object Parameter(object type) { }

	// RVA: 0x6CD20A8
	public static object Parameter(object type, object name) { }

	// RVA: 0x6CD0DA0
	public static object Variable(object type, object name) { }

	// RVA: 0x6CEA2A0
	private static object Validate(object type, object allowByRef) { }

	// RVA: 0x6CEA3D0
	public static object TryFinally(object body, object finally) { }

	// RVA: 0x6CEA444
	public static object MakeTry(object type, object body, object finally, object fault, object handlers) { }

	// RVA: 0x6CEA6B0
	private static object ValidateTryAndCatchHaveSameType(object type, object tryBody, object handlers) { }

	// RVA: 0x6CEB1DC
	public static object TypeIs(object expression, object type) { }

	// RVA: 0x6CEB2F0
	public static object TypeEqual(object expression, object type) { }

	// RVA: 0x6CEB404
	public static object MakeUnary(object unaryType, object operand, object type, object method) { }

	// RVA: 0x6CEDA8C
	private static object GetUserDefinedUnaryOperatorOrThrow(object unaryType, object name, object operand) { }

	// RVA: 0x6CEDC88
	private static object GetUserDefinedUnaryOperator(object unaryType, object name, object operand) { }

	// RVA: 0x6CEE01C
	private static object GetMethodBasedUnaryOperator(object unaryType, object operand, object method) { }

	// RVA: 0x6CEE544
	private static object GetUserDefinedCoercionOrThrow(object coercionType, object expression, object convertToType) { }

	// RVA: 0x6CEE628
	private static object GetUserDefinedCoercion(object coercionType, object expression, object convertToType) { }

	// RVA: 0x6CEE738
	private static object GetMethodBasedCoercionOperator(object unaryType, object operand, object convertToType, object method) { }

	// RVA: 0x6CEB9D8
	public static object Negate(object expression, object method) { }

	// RVA: 0x6CED134
	public static object UnaryPlus(object expression, object method) { }

	// RVA: 0x6CEBC08
	public static object NegateChecked(object expression, object method) { }

	// RVA: 0x6CEEC24
	public static object Not(object expression) { }

	// RVA: 0x6CEBE38
	public static object Not(object expression, object method) { }

	// RVA: 0x6CEC054
	public static object IsFalse(object expression, object method) { }

	// RVA: 0x6CEC228
	public static object IsTrue(object expression, object method) { }

	// RVA: 0x6CEC3FC
	public static object OnesComplement(object expression, object method) { }

	// RVA: 0x6CECE8C
	public static object TypeAs(object expression, object type) { }

	// RVA: 0x6CED308
	public static object Unbox(object expression, object type) { }

	// RVA: 0x6CD2A58
	public static object Convert(object expression, object type) { }

	// RVA: 0x6CEC80C
	public static object Convert(object expression, object type, object method) { }

	// RVA: 0x6CECA7C
	public static object ConvertChecked(object expression, object type, object method) { }

	// RVA: 0x6CEC5D0
	public static object ArrayLength(object array) { }

	// RVA: 0x6CED000
	public static object Quote(object expression) { }

	// RVA: 0x6CECD04
	public static object Throw(object value, object type) { }

	// RVA: 0x6CED534
	public static object Increment(object expression, object method) { }

	// RVA: 0x6CED708
	public static object Decrement(object expression, object method) { }

	// RVA: 0x6CEECAC
	public static object PreIncrementAssign(object expression) { }

	// RVA: 0x6CED8DC
	public static object PreIncrementAssign(object expression, object method) { }

	// RVA: 0x6CED9B4
	public static object PreDecrementAssign(object expression, object method) { }

	// RVA: 0x6CED948
	public static object PostIncrementAssign(object expression, object method) { }

	// RVA: 0x6CEDA20
	public static object PostDecrementAssign(object expression, object method) { }

	// RVA: 0x6CEED14
	private static object MakeOpAssignUnary(object kind, object expression, object method) { }

	// RVA: 0x6CEF03C
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions
public class BlockExpression
{

	// Properties
	public object Expressions { get; }
	public object Variables { get; }
	public sealed override object NodeType { get; }
	public override object Type { get; }
	internal virtual object ExpressionCount { get; }

	// Methods

	// RVA: 0x6CEF0D0
	public object get_Expressions() { }

	// RVA: 0x6CEF110
	public object get_Variables() { }

	// RVA: 0x6CEF154
	internal object .ctor() { }

	// RVA: 0x6CEF1DC
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CEF230
	public sealed override object get_NodeType() { }

	// RVA: 0x6CEF238
	public override object get_Type() { }

	// RVA: 0x6CEF2DC
	internal virtual object GetExpression(object index) { }

	// RVA: 0x6CEF30C
	internal virtual object get_ExpressionCount() { }

	// RVA: 0x6CEF33C
	internal virtual object GetOrMakeExpressions() { }

	// RVA: 0x6CEF36C
	internal virtual object GetOrMakeVariables() { }

	// RVA: 0x6CEF3E8
	internal virtual object Rewrite(object variables, object args) { }

	// RVA: 0x6CEF418
	internal static object ReturnReadOnlyExpressions(object provider, object collection) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Block2
{

	// Fields
	private object _arg0; // 0x8
	private readonly object _arg1; // 0x10

	// Properties
	internal override object ExpressionCount { get; }

	// Methods

	// RVA: 0x6CEF59C
	internal object .ctor(object arg0, object arg1) { }

	// RVA: 0x6CEF618
	internal override object GetExpression(object index) { }

	// RVA: 0x6CEF724
	internal override object get_ExpressionCount() { }

	// RVA: 0x6CEF72C
	internal override object GetOrMakeExpressions() { }

	// RVA: 0x6CEF734
	internal override object Rewrite(object variables, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Block3
{

	// Fields
	private object _arg0; // 0x8
	private readonly object _arg1; // 0x10
	private readonly object _arg2; // 0x18

	// Properties
	internal override object ExpressionCount { get; }

	// Methods

	// RVA: 0x6CEF808
	internal object .ctor(object arg0, object arg1, object arg2) { }

	// RVA: 0x6CEF88C
	internal override object GetExpression(object index) { }

	// RVA: 0x6CEF94C
	internal override object get_ExpressionCount() { }

	// RVA: 0x6CEF954
	internal override object GetOrMakeExpressions() { }

	// RVA: 0x6CEF95C
	internal override object Rewrite(object variables, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Block4
{

	// Fields
	private object _arg0; // 0x8
	private readonly object _arg1; // 0x10
	private readonly object _arg2; // 0x18
	private readonly object _arg3; // 0x20

	// Properties
	internal override object ExpressionCount { get; }

	// Methods

	// RVA: 0x6CEFA40
	internal object .ctor(object arg0, object arg1, object arg2, object arg3) { }

	// RVA: 0x6CEFAD0
	internal override object GetExpression(object index) { }

	// RVA: 0x6CEFBB4
	internal override object get_ExpressionCount() { }

	// RVA: 0x6CEFBBC
	internal override object GetOrMakeExpressions() { }

	// RVA: 0x6CEFBC4
	internal override object Rewrite(object variables, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Block5
{

	// Fields
	private object _arg0; // 0x8
	private readonly object _arg1; // 0x10
	private readonly object _arg2; // 0x18
	private readonly object _arg3; // 0x20
	private readonly object _arg4; // 0x28

	// Properties
	internal override object ExpressionCount { get; }

	// Methods

	// RVA: 0x6CEFCB8
	internal object .ctor(object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x6CEFD50
	internal override object GetExpression(object index) { }

	// RVA: 0x6CEFE50
	internal override object get_ExpressionCount() { }

	// RVA: 0x6CEFE58
	internal override object GetOrMakeExpressions() { }

	// RVA: 0x6CEFE60
	internal override object Rewrite(object variables, object args) { }

}

// Namespace: System.Linq.Expressions
internal class BlockN
{

	// Fields
	private object _expressions; // 0x8

	// Properties
	internal override object ExpressionCount { get; }

	// Methods

	// RVA: 0x6CEFF64
	internal object .ctor(object expressions) { }

	// RVA: 0x6CEFFD4
	internal override object GetExpression(object index) { }

	// RVA: 0x6CF00A8
	internal override object get_ExpressionCount() { }

	// RVA: 0x6CF0188
	internal override object GetOrMakeExpressions() { }

	// RVA: 0x6CF01DC
	internal override object Rewrite(object variables, object args) { }

}

// Namespace: System.Linq.Expressions
internal class ScopeExpression
{

	// Fields
	private object _variables; // 0x8

	// Properties
	protected object VariablesList { get; }

	// Methods

	// RVA: 0x6CF0280
	internal object .ctor(object variables) { }

	// RVA: 0x6CF02F0
	internal override object GetOrMakeVariables() { }

	// RVA: 0x6CF0344
	protected object get_VariablesList() { }

	// RVA: 0x6CF034C
	internal object ReuseOrValidateVariables(object variables) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Scope1
{

	// Fields
	private object _body; // 0x10

	// Properties
	internal override object ExpressionCount { get; }

	// Methods

	// RVA: 0x6CF03E4
	internal object .ctor(object variables, object body) { }

	// RVA: 0x6CF0460
	private object .ctor(object variables, object body) { }

	// RVA: 0x6CF04DC
	internal override object GetExpression(object index) { }

	// RVA: 0x6CF0564
	internal override object get_ExpressionCount() { }

	// RVA: 0x6CF056C
	internal override object GetOrMakeExpressions() { }

	// RVA: 0x6CF0574
	internal override object Rewrite(object variables, object args) { }

}

// Namespace: System.Linq.Expressions
internal class ScopeN
{

	// Fields
	private object _body; // 0x10

	// Properties
	protected object Body { get; }
	internal override object ExpressionCount { get; }

	// Methods

	// RVA: 0x6CF0730
	internal object .ctor(object variables, object body) { }

	// RVA: 0x6CF07AC
	protected object get_Body() { }

	// RVA: 0x6CF07B4
	internal override object GetExpression(object index) { }

	// RVA: 0x6CF0888
	internal override object get_ExpressionCount() { }

	// RVA: 0x6CF0968
	internal override object GetOrMakeExpressions() { }

	// RVA: 0x6CF09BC
	internal override object Rewrite(object variables, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class ScopeWithType
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x18

	// Properties
	public sealed override object Type { get; }

	// Methods

	// RVA: 0x6CF0B68
	internal object .ctor(object variables, object expressions, object type) { }

	// RVA: 0x6CF0BEC
	public sealed override object get_Type() { }

	// RVA: 0x6CF0BF4
	internal override object Rewrite(object variables, object args) { }

}

// Namespace: 
private sealed class <GetEnumerator>d__18
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <i>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Linq.Expressions.Expression>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6CF1364
	public object .ctor(object <>1__state) { }

	// RVA: 0x6CF13FC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6CF1400
	private object MoveNext() { }

	// RVA: 0x6CF153C
	private object System.Collections.Generic.IEnumerator<System.Linq.Expressions.Expression>.get_Current() { }

	// RVA: 0x6CF1544
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6CF1584
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Linq.Expressions
internal class BlockExpressionList
{

	// Fields
	private readonly object _block; // 0x8
	private readonly object _arg0; // 0x10

	// Properties
	public object Item { get; set; }
	public object Count { get; }
	public object IsReadOnly { get; }

	// Methods

	// RVA: 0x6CEF564
	internal object .ctor(object provider, object arg0) { }

	// RVA: 0x6CF0DF4
	public object IndexOf(object item) { }

	// RVA: 0x6CF0EDC
	public object Insert(object index, object item) { }

	// RVA: 0x6CF0F0C
	public object RemoveAt(object index) { }

	// RVA: 0x6CF0F3C
	public object get_Item(object index) { }

	// RVA: 0x6CF0FA4
	public object set_Item(object index, object value) { }

	// RVA: 0x6CF0FD4
	public object Add(object item) { }

	// RVA: 0x6CF1004
	public object Clear() { }

	// RVA: 0x6CF1034
	public object Contains(object item) { }

	// RVA: 0x6CF1050
	public object CopyTo(object array, object index) { }

	// RVA: 0x6CF124C
	public object get_Count() { }

	// RVA: 0x6CF1298
	public object get_IsReadOnly() { }

	// RVA: 0x6CF12C8
	public object Remove(object item) { }

	// RVA: 0x6CF12F8
	public object GetEnumerator() { }

	// RVA: 0x6CF1390
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Linq.Expressions
public sealed class CatchBlock
{

	// Fields
	private readonly object <Variable>k__BackingField; // 0x8
	private readonly object <Test>k__BackingField; // 0x10
	private readonly object <Body>k__BackingField; // 0x18
	private readonly object <Filter>k__BackingField; // 0x20

	// Properties
	public object Variable { get; }
	public object Test { get; }
	public object Body { get; }
	public object Filter { get; }

	// Methods

	// RVA: 0x6CF158C
	internal object .ctor(object test, object variable, object body, object filter) { }

	// RVA: 0x6CF15D8
	public object get_Variable() { }

	// RVA: 0x6CF15E0
	public object get_Test() { }

	// RVA: 0x6CF15E8
	public object get_Body() { }

	// RVA: 0x6CF15F0
	public object get_Filter() { }

	// RVA: 0x6CF15F8
	public override object ToString() { }

	// RVA: 0x6CF16EC
	public object Update(object variable, object filter, object body) { }

}

// Namespace: System.Linq.Expressions
internal static class ArrayBuilderExtensions
{

	// Methods

	// RVA: -1
	public static object ToReadOnly(object builder) { }

}

// Namespace: System.Linq.Expressions
internal enum AnalyzeTypeIsResult
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object KnownFalse;
	public const object KnownTrue;
	public const object KnownAssignable;
	public const object Unknown;
}

// Namespace: System.Linq.Expressions
internal static class ConstantCheck
{

	// Methods

	// RVA: 0x6CF17B0
	internal static object AnalyzeTypeIs(object typeIs) { }

	// RVA: 0x6CF17D4
	private static object AnalyzeTypeIs(object operand, object testType) { }

}

// Namespace: System.Linq.Expressions
public class ConditionalExpression
{

	// Fields
	private readonly object <Test>k__BackingField; // 0x8
	private readonly object <IfTrue>k__BackingField; // 0x10

	// Properties
	public sealed override object NodeType { get; }
	public override object Type { get; }
	public object Test { get; }
	public object IfTrue { get; }
	public object IfFalse { get; }

	// Methods

	// RVA: 0x6CF1A68
	internal object .ctor(object test, object ifTrue) { }

	// RVA: 0x6CF1AE4
	internal static object Make(object test, object ifTrue, object ifFalse, object type) { }

	// RVA: 0x6CF1F40
	public sealed override object get_NodeType() { }

	// RVA: 0x6CF1F48
	public override object get_Type() { }

	// RVA: 0x6CF1F94
	public object get_Test() { }

	// RVA: 0x6CF1F9C
	public object get_IfTrue() { }

	// RVA: 0x6CF1FA4
	public object get_IfFalse() { }

	// RVA: 0x6CF1FE4
	internal virtual object GetFalse() { }

	// RVA: 0x6CF2060
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CF20B4
	public object Update(object test, object ifTrue, object ifFalse) { }

}

// Namespace: System.Linq.Expressions
internal class FullConditionalExpression
{

	// Fields
	private readonly object _false; // 0x18

	// Methods

	// RVA: 0x6CF1EBC
	internal object .ctor(object test, object ifTrue, object ifFalse) { }

	// RVA: 0x6CF21BC
	internal override object GetFalse() { }

}

// Namespace: System.Linq.Expressions
internal sealed class FullConditionalExpressionWithType
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x20

	// Properties
	public sealed override object Type { get; }

	// Methods

	// RVA: 0x6CF1E2C
	internal object .ctor(object test, object ifTrue, object ifFalse, object type) { }

	// RVA: 0x6CF21C4
	public sealed override object get_Type() { }

}

// Namespace: System.Linq.Expressions
public class ConstantExpression
{

	// Fields
	private readonly object <Value>k__BackingField; // 0x8

	// Properties
	public override object Type { get; }
	public sealed override object NodeType { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x6CF21CC
	internal object .ctor(object value) { }

	// RVA: 0x6CF223C
	public override object get_Type() { }

	// RVA: 0x6CF22DC
	public sealed override object get_NodeType() { }

	// RVA: 0x6CF22E4
	public object get_Value() { }

	// RVA: 0x6CF22EC
	protected internal override object Accept(object visitor) { }

}

// Namespace: System.Linq.Expressions
internal class TypedConstantExpression
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x10

	// Properties
	public sealed override object Type { get; }

	// Methods

	// RVA: 0x6CF2340
	internal object .ctor(object value, object type) { }

	// RVA: 0x6CF23BC
	public sealed override object get_Type() { }

}

// Namespace: System.Linq.Expressions
public class DebugInfoExpression
{

	// Fields
	private readonly object <Document>k__BackingField; // 0x8

	// Properties
	public virtual object StartLine { get; }
	public virtual object EndLine { get; }
	public object Document { get; }
	public virtual object IsClear { get; }

	// Methods

	// RVA: 0x6CF23C4
	public virtual object get_StartLine() { }

	// RVA: 0x6CF23F4
	public virtual object get_EndLine() { }

	// RVA: 0x6CF2424
	public object get_Document() { }

	// RVA: 0x6CF242C
	public virtual object get_IsClear() { }

}

// Namespace: System.Linq.Expressions
public sealed class DefaultExpression
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x8

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }

	// Methods

	// RVA: 0x6CF245C
	internal object .ctor(object type) { }

	// RVA: 0x6CF24CC
	public sealed override object get_Type() { }

	// RVA: 0x6CF24D4
	public sealed override object get_NodeType() { }

	// RVA: 0x6CF24DC
	protected internal override object Accept(object visitor) { }

}

// Namespace: System.Linq.Expressions
public sealed class ElementInit
{

	// Fields
	private readonly object <AddMethod>k__BackingField; // 0x8
	private readonly object <Arguments>k__BackingField; // 0x10

	// Properties
	public object AddMethod { get; }
	public object Arguments { get; }
	public object ArgumentCount { get; }

	// Methods

	// RVA: 0x6CF2530
	public object get_AddMethod() { }

	// RVA: 0x6CF2538
	public object get_Arguments() { }

	// RVA: 0x6CF2540
	public object GetArgument(object index) { }

	// RVA: 0x6CF25AC
	public object get_ArgumentCount() { }

}

// Namespace: System.Linq.Expressions
internal static class Error
{

	// Methods

	// RVA: 0x6CF2608
	internal static object ReducibleMustOverrideReduce() { }

	// RVA: 0x6CF26DC
	internal static object InvalidMetaObjectCreated(object p0) { }

	// RVA: 0x6CF27D8
	internal static object AmbiguousMatchInExpandoObject(object p0) { }

	// RVA: 0x6CF28D4
	internal static object SameKeyExistsInExpando(object key) { }

	// RVA: 0x6CF29F0
	internal static object KeyDoesNotExistInExpando(object p0) { }

	// RVA: 0x6CF2AEC
	internal static object CollectionModifiedWhileEnumerating() { }

	// RVA: 0x6CF2BC0
	internal static object CollectionReadOnly() { }

	// RVA: 0x6CF2C94
	internal static object MustReduceToDifferent() { }

	// RVA: 0x6CF2D68
	internal static object BinderNotCompatibleWithCallSite(object p0, object p1, object p2) { }

	// RVA: 0x6CF2E94
	internal static object DynamicBindingNeedsRestrictions(object p0, object p1) { }

	// RVA: 0x6CF2FA8
	internal static object DynamicObjectResultNotAssignable(object p0, object p1, object p2, object p3) { }

	// RVA: 0x6CF318C
	internal static object DynamicBinderResultNotAssignable(object p0, object p1, object p2) { }

	// RVA: 0x6CF32B8
	internal static object BindingCannotBeNull() { }

	// RVA: 0x6CF338C
	internal static object ReducedNotCompatible() { }

	// RVA: 0x6CF3460
	internal static object SetterHasNoParams(object paramName) { }

	// RVA: 0x6CF353C
	internal static object PropertyCannotHaveRefType(object paramName) { }

	// RVA: 0x6CF3618
	internal static object IndexesOfSetGetMustMatch(object paramName) { }

	// RVA: 0x6CF36F4
	internal static object TypeParameterIsNotDelegate(object p0) { }

	// RVA: 0x6CF37F0
	internal static object FirstArgumentMustBeCallSite() { }

	// RVA: 0x6CF38C4
	internal static object AccessorsCannotHaveVarArgs(object paramName) { }

	// RVA: 0x6CF39A0
	private static object AccessorsCannotHaveByRefArgs(object paramName) { }

	// RVA: 0x6CF3A7C
	internal static object AccessorsCannotHaveByRefArgs(object paramName, object index) { }

	// RVA: 0x6CF3C24
	internal static object TypeMustBeDerivedFromSystemDelegate() { }

	// RVA: 0x6CF3CF8
	internal static object NoOrInvalidRuleProduced() { }

	// RVA: 0x6CF3DCC
	internal static object BoundsCannotBeLessThanOne(object paramName) { }

	// RVA: 0x6CF3EA8
	internal static object TypeMustNotBeByRef(object paramName) { }

	// RVA: 0x6CF3F84
	internal static object TypeMustNotBePointer(object paramName) { }

	// RVA: 0x6CF4060
	internal static object SetterMustBeVoid(object paramName) { }

	// RVA: 0x6CF413C
	internal static object PropertyTypeMustMatchGetter(object paramName) { }

	// RVA: 0x6CF4218
	internal static object PropertyTypeMustMatchSetter(object paramName) { }

	// RVA: 0x6CF42F4
	internal static object BothAccessorsMustBeStatic(object paramName) { }

	// RVA: 0x6CF43D0
	internal static object OnlyStaticFieldsHaveNullInstance(object paramName) { }

	// RVA: 0x6CF44AC
	internal static object OnlyStaticPropertiesHaveNullInstance(object paramName) { }

	// RVA: 0x6CF4588
	internal static object OnlyStaticMethodsHaveNullInstance() { }

	// RVA: 0x6CF465C
	internal static object PropertyTypeCannotBeVoid(object paramName) { }

	// RVA: 0x6CF4738
	internal static object InvalidUnboxType(object paramName) { }

	// RVA: 0x6CF4814
	internal static object ExpressionMustBeWriteable(object paramName) { }

	// RVA: 0x6CF48F0
	internal static object ArgumentMustNotHaveValueType(object paramName) { }

	// RVA: 0x6CF49CC
	internal static object MustBeReducible() { }

	// RVA: 0x6CF4AA0
	internal static object LabelMustBeVoidOrHaveExpression(object paramName) { }

	// RVA: 0x6CF4B7C
	internal static object LabelTypeMustBeVoid(object paramName) { }

	// RVA: 0x6CF4C58
	internal static object QuotedExpressionMustBeLambda(object paramName) { }

	// RVA: 0x6CF4D34
	internal static object VariableMustNotBeByRef(object p0, object p1, object paramName) { }

	// RVA: 0x6CF4E50
	internal static object VariableMustNotBeByRef(object p0, object p1, object paramName, object index) { }

	// RVA: 0x6CF4F80
	private static object DuplicateVariable(object p0, object paramName) { }

	// RVA: 0x6CF508C
	internal static object DuplicateVariable(object p0, object paramName, object index) { }

	// RVA: 0x6CF51B4
	internal static object FaultCannotHaveCatchOrFinally(object paramName) { }

	// RVA: 0x6CF5290
	internal static object TryMustHaveCatchFinallyOrFault() { }

	// RVA: 0x6CF5364
	internal static object BodyOfCatchMustHaveSameTypeAsBodyOfTry() { }

	// RVA: 0x6CF5438
	internal static object ExtensionNodeMustOverrideProperty(object p0) { }

	// RVA: 0x6CF5534
	internal static object UserDefinedOperatorMustBeStatic(object p0, object paramName) { }

	// RVA: 0x6CF5640
	internal static object UserDefinedOperatorMustNotBeVoid(object p0, object paramName) { }

	// RVA: 0x6CF574C
	internal static object CoercionOperatorNotDefined(object p0, object p1) { }

	// RVA: 0x6CF5860
	internal static object UnaryOperatorNotDefined(object p0, object p1) { }

	// RVA: 0x6CF5974
	internal static object BinaryOperatorNotDefined(object p0, object p1, object p2) { }

	// RVA: 0x6CF5AA0
	internal static object ReferenceEqualityNotDefined(object p0, object p1) { }

	// RVA: 0x6CF5BB4
	internal static object OperandTypesDoNotMatchParameters(object p0, object p1) { }

	// RVA: 0x6CF5CC8
	internal static object OverloadOperatorTypeDoesNotMatchConversionType(object p0, object p1) { }

	// RVA: 0x6CF5DDC
	internal static object ConversionIsNotSupportedForArithmeticTypes() { }

	// RVA: 0x6CF5EB0
	internal static object ArgumentMustBeArray(object paramName) { }

	// RVA: 0x6CF5F8C
	internal static object ArgumentMustBeBoolean(object paramName) { }

	// RVA: 0x6CF6068
	private static object ArgumentMustBeInteger(object paramName) { }

	// RVA: 0x6CF6144
	internal static object ArgumentMustBeInteger(object paramName, object index) { }

	// RVA: 0x6CF6250
	internal static object ArgumentMustBeArrayIndexType(object paramName) { }

	// RVA: 0x6CF632C
	internal static object ArgumentMustBeSingleDimensionalArrayType(object paramName) { }

	// RVA: 0x6CF6408
	internal static object ArgumentTypesMustMatch() { }

	// RVA: 0x6CF64DC
	internal static object CannotAutoInitializeValueTypeMemberThroughProperty(object p0) { }

	// RVA: 0x6CF65D8
	internal static object IncorrectTypeForTypeAs(object p0, object paramName) { }

	// RVA: 0x6CF66E4
	internal static object CoalesceUsedOnNonNullType() { }

	// RVA: 0x6CF67B8
	internal static object ExpressionTypeCannotInitializeArrayType(object p0, object p1) { }

	// RVA: 0x6CF68CC
	internal static object ExpressionTypeDoesNotMatchReturn(object p0, object p1) { }

	// RVA: 0x6CF69E0
	internal static object ExpressionTypeDoesNotMatchAssignment(object p0, object p1) { }

	// RVA: 0x6CF6AF4
	internal static object ExpressionTypeDoesNotMatchLabel(object p0, object p1) { }

	// RVA: 0x6CF6C08
	internal static object ExpressionTypeNotInvocable(object p0, object paramName) { }

	// RVA: 0x6CF6D14
	internal static object InstanceFieldNotDefinedForType(object p0, object p1) { }

	// RVA: 0x6CF6E28
	internal static object FieldInfoNotDefinedForType(object p0, object p1, object p2) { }

	// RVA: 0x6CF6F54
	internal static object IncorrectNumberOfIndexes() { }

	// RVA: 0x6CF7028
	internal static object IncorrectNumberOfLambdaDeclarationParameters() { }

	// RVA: 0x6CF70FC
	internal static object LambdaTypeMustBeDerivedFromSystemDelegate(object paramName) { }

	// RVA: 0x6CF71D8
	internal static object MemberNotFieldOrProperty(object p0, object paramName) { }

	// RVA: 0x6CF72E4
	internal static object MethodContainsGenericParameters(object p0, object paramName) { }

	// RVA: 0x6CF73F0
	internal static object MethodIsGeneric(object p0, object paramName) { }

	// RVA: 0x6CF74FC
	internal static object PropertyDoesNotHaveAccessor(object p0, object paramName) { }

	// RVA: 0x6CF7608
	internal static object ParameterExpressionNotValidAsDelegate(object p0, object p1) { }

	// RVA: 0x6CF771C
	internal static object PropertyNotDefinedForType(object p0, object p1, object paramName) { }

	// RVA: 0x6CF7838
	internal static object InstancePropertyNotDefinedForType(object p0, object p1, object paramName) { }

	// RVA: 0x6CF7954
	internal static object InstanceAndMethodTypeMismatch(object p0, object p1, object p2) { }

	// RVA: 0x6CF7A80
	internal static object UnhandledBinary(object p0, object paramName) { }

	// RVA: 0x6CF7B8C
	internal static object UnhandledUnary(object p0, object paramName) { }

	// RVA: 0x6CF7C98
	internal static object UserDefinedOpMustHaveConsistentTypes(object p0, object p1) { }

	// RVA: 0x6CF7DAC
	internal static object UserDefinedOpMustHaveValidReturnType(object p0, object p1) { }

	// RVA: 0x6CF7EC0
	internal static object LogicalOperatorMustHaveBooleanOperators(object p0, object p1) { }

	// RVA: 0x6CF7FD4
	internal static object MethodWithArgsDoesNotExistOnType(object p0, object p1) { }

	// RVA: 0x6CF80E8
	internal static object GenericMethodWithArgsDoesNotExistOnType(object p0, object p1) { }

	// RVA: 0x6CF81FC
	internal static object MethodWithMoreThanOneMatch(object p0, object p1) { }

	// RVA: 0x6CF8310
	internal static object ArgumentCannotBeOfTypeVoid(object paramName) { }

	// RVA: 0x6CF83EC
	internal static object OutOfRange(object paramName, object p1) { }

	// RVA: 0x6CF8504
	internal static object LabelTargetAlreadyDefined(object p0) { }

	// RVA: 0x6CF8600
	internal static object LabelTargetUndefined(object p0) { }

	// RVA: 0x6CF86FC
	internal static object ControlCannotLeaveFinally() { }

	// RVA: 0x6CF87D0
	internal static object ControlCannotLeaveFilterTest() { }

	// RVA: 0x6CF88A4
	internal static object AmbiguousJump(object p0) { }

	// RVA: 0x6CF89A0
	internal static object ControlCannotEnterTry() { }

	// RVA: 0x6CF8A74
	internal static object ControlCannotEnterExpression() { }

	// RVA: 0x6CF8B48
	internal static object NonLocalJumpWithValue(object p0) { }

	// RVA: 0x6CF8C44
	internal static object InvalidLvalue(object p0) { }

	// RVA: 0x6CF8D70
	internal static object RethrowRequiresCatch() { }

	// RVA: 0x6CF8E44
	internal static object MustRewriteToSameNode(object p0, object p1, object p2) { }

	// RVA: 0x6CF8F70
	internal static object MustRewriteChildToSameType(object p0, object p1, object p2) { }

	// RVA: 0x6CF909C
	internal static object MustRewriteWithoutMethod(object p0, object p1) { }

	// RVA: 0x6CEF6BC
	internal static object ArgumentOutOfRange(object paramName) { }

	// RVA: 0x6CF91B0
	internal static object NotSupported() { }

	// RVA: 0x6CF9208
	internal static object NonAbstractConstructorRequired() { }

	// RVA: 0x6CF92DC
	internal static object InvalidProgram() { }

	// RVA: 0x6CF9334
	internal static object EnumerationIsDone() { }

	// RVA: 0x6CF9408
	private static object TypeContainsGenericParameters(object p0, object paramName) { }

	// RVA: 0x6CF9514
	internal static object TypeContainsGenericParameters(object p0, object paramName, object index) { }

	// RVA: 0x6CF963C
	internal static object TypeIsGeneric(object p0, object paramName) { }

	// RVA: 0x6CF9748
	internal static object TypeIsGeneric(object p0, object paramName, object index) { }

	// RVA: 0x6CF9870
	internal static object IncorrectNumberOfConstructorArguments() { }

	// RVA: 0x6CF9944
	internal static object ExpressionTypeDoesNotMatchMethodParameter(object p0, object p1, object p2, object paramName) { }

	// RVA: 0x6CF9A80
	internal static object ExpressionTypeDoesNotMatchMethodParameter(object p0, object p1, object p2, object paramName, object index) { }

	// RVA: 0x6CF9BC0
	internal static object ExpressionTypeDoesNotMatchParameter(object p0, object p1, object paramName) { }

	// RVA: 0x6CF9CDC
	internal static object ExpressionTypeDoesNotMatchParameter(object p0, object p1, object paramName, object index) { }

	// RVA: 0x6CF9E0C
	internal static object IncorrectNumberOfLambdaArguments() { }

	// RVA: 0x6CF9EE0
	internal static object IncorrectNumberOfMethodCallArguments(object p0, object paramName) { }

	// RVA: 0x6CF9FEC
	internal static object ExpressionTypeDoesNotMatchConstructorParameter(object p0, object p1, object paramName) { }

	// RVA: 0x6CFA108
	internal static object ExpressionTypeDoesNotMatchConstructorParameter(object p0, object p1, object paramName, object index) { }

	// RVA: 0x6CFA238
	internal static object ExpressionMustBeReadable(object paramName) { }

	// RVA: 0x6CFA314
	internal static object ExpressionMustBeReadable(object paramName, object index) { }

	// RVA: 0x6CFA420
	internal static object InvalidArgumentValue(object paramName) { }

	// RVA: 0x6CFA4FC
	internal static object InvalidNullValue(object type, object paramName) { }

	// RVA: 0x6CFA608
	internal static object InvalidTypeException(object value, object type, object paramName) { }

	// RVA: 0x6CF3B88
	private static object GetParamName(object paramName, object index) { }

}

// Namespace: System.Linq.Expressions
internal sealed class ExpressionStringBuilder
{

	// Fields
	private readonly object _out; // 0x8
	private object _ids; // 0x10

	// Methods

	// RVA: 0x6CFA768
	private object .ctor() { }

	// RVA: 0x6CFA7E0
	public override object ToString() { }

	// RVA: 0x6CFA82C
	private object GetLabelId(object label) { }

	// RVA: 0x6CFA96C
	private object GetParamId(object p) { }

	// RVA: 0x6CFA830
	private object GetId(object o) { }

	// RVA: 0x6CFA970
	private object Out(object s) { }

	// RVA: 0x6CFA994
	private object Out(object c) { }

	// RVA: 0x6CFA9B8
	internal static object ExpressionToString(object node) { }

	// RVA: 0x6CF15FC
	internal static object CatchBlockToString(object node) { }

	// RVA: -1
	private object VisitExpressions(object open, object expressions, object close) { }

	// RVA: -1
	private object VisitExpressions(object open, object expressions, object close, object seperator) { }

	// RVA: 0x6CFAAA4
	protected internal override object VisitBinary(object node) { }

	// RVA: 0x6CFB1B0
	protected internal override object VisitParameter(object node) { }

	// RVA: -1
	protected internal override object VisitLambda(object node) { }

	// RVA: 0x6CFB310
	protected internal override object VisitConditional(object node) { }

	// RVA: 0x6CFB480
	protected internal override object VisitConstant(object node) { }

	// RVA: 0x6CFB664
	private object OutMember(object instance, object member) { }

	// RVA: 0x6CFB7B0
	protected internal override object VisitMember(object node) { }

	// RVA: 0x6CFB860
	protected internal override object VisitInvocation(object node) { }

	// RVA: 0x6CFB9EC
	protected internal override object VisitMethodCall(object node) { }

	// RVA: 0x6CFBD3C
	protected internal override object VisitNewArray(object node) { }

	// RVA: 0x6CFBED0
	protected internal override object VisitTypeBinary(object node) { }

	// RVA: 0x6CFC03C
	protected internal override object VisitUnary(object node) { }

	// RVA: 0x6CFC5B0
	protected internal override object VisitBlock(object node) { }

	// RVA: 0x6CFC97C
	protected internal override object VisitDefault(object node) { }

	// RVA: 0x6CFCA7C
	protected internal override object VisitLabel(object node) { }

	// RVA: 0x6CFCBF0
	protected internal override object VisitGoto(object node) { }

	// RVA: 0x6CFCD74
	protected internal override object VisitLoop(object node) { }

	// RVA: 0x6CFCDE8
	protected override object VisitCatchBlock(object node) { }

	// RVA: 0x6CFCF3C
	protected internal override object VisitTry(object node) { }

	// RVA: 0x6CFCFB0
	protected internal override object VisitIndex(object node) { }

	// RVA: 0x6CFD3F4
	protected internal override object VisitExtension(object node) { }

	// RVA: 0x6CFCB14
	private object DumpLabel(object target) { }

	// RVA: 0x6CFB068
	private static object IsBool(object node) { }

}

// Namespace: System.Linq.Expressions
public enum ExpressionType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Add;
	public const object AddChecked;
	public const object And;
	public const object AndAlso;
	public const object ArrayLength;
	public const object ArrayIndex;
	public const object Call;
	public const object Coalesce;
	public const object Conditional;
	public const object Constant;
	public const object Convert;
	public const object ConvertChecked;
	public const object Divide;
	public const object Equal;
	public const object ExclusiveOr;
	public const object GreaterThan;
	public const object GreaterThanOrEqual;
	public const object Invoke;
	public const object Lambda;
	public const object LeftShift;
	public const object LessThan;
	public const object LessThanOrEqual;
	public const object ListInit;
	public const object MemberAccess;
	public const object MemberInit;
	public const object Modulo;
	public const object Multiply;
	public const object MultiplyChecked;
	public const object Negate;
	public const object UnaryPlus;
	public const object NegateChecked;
	public const object New;
	public const object NewArrayInit;
	public const object NewArrayBounds;
	public const object Not;
	public const object NotEqual;
	public const object Or;
	public const object OrElse;
	public const object Parameter;
	public const object Power;
	public const object Quote;
	public const object RightShift;
	public const object Subtract;
	public const object SubtractChecked;
	public const object TypeAs;
	public const object TypeIs;
	public const object Assign;
	public const object Block;
	public const object DebugInfo;
	public const object Decrement;
	public const object Dynamic;
	public const object Default;
	public const object Extension;
	public const object Goto;
	public const object Increment;
	public const object Index;
	public const object Label;
	public const object RuntimeVariables;
	public const object Loop;
	public const object Switch;
	public const object Throw;
	public const object Try;
	public const object Unbox;
	public const object AddAssign;
	public const object AndAssign;
	public const object DivideAssign;
	public const object ExclusiveOrAssign;
	public const object LeftShiftAssign;
	public const object ModuloAssign;
	public const object MultiplyAssign;
	public const object OrAssign;
	public const object PowerAssign;
	public const object RightShiftAssign;
	public const object SubtractAssign;
	public const object AddAssignChecked;
	public const object MultiplyAssignChecked;
	public const object SubtractAssignChecked;
	public const object PreIncrementAssign;
	public const object PreDecrementAssign;
	public const object PostIncrementAssign;
	public const object PostDecrementAssign;
	public const object TypeEqual;
	public const object OnesComplement;
	public const object IsTrue;
	public const object IsFalse;
}

// Namespace: System.Linq.Expressions
public abstract class ExpressionVisitor
{

	// Methods

	// RVA: 0x6CFA7D8
	protected object .ctor() { }

	// RVA: 0x6CFD69C
	public virtual object Visit(object node) { }

	// RVA: 0x6CFD6EC
	public object Visit(object nodes) { }

	// RVA: 0x6CFD970
	private object VisitArguments(object nodes) { }

	// RVA: 0x6CFD978
	private object VisitParameters(object nodes, object callerName) { }

	// RVA: -1
	public static object Visit(object nodes, object elementVisitor) { }

	// RVA: -1
	public object VisitAndConvert(object node, object callerName) { }

	// RVA: -1
	public object VisitAndConvert(object nodes, object callerName) { }

	// RVA: 0x6CFD980
	protected internal virtual object VisitBinary(object node) { }

	// RVA: 0x6CFDCAC
	protected internal virtual object VisitBlock(object node) { }

	// RVA: 0x6CFDDF4
	protected internal virtual object VisitConditional(object node) { }

	// RVA: 0x6CFDEF4
	protected internal virtual object VisitConstant(object node) { }

	// RVA: 0x6CFDEFC
	protected internal virtual object VisitDefault(object node) { }

	// RVA: 0x6CFDF04
	protected internal virtual object VisitExtension(object node) { }

	// RVA: 0x6CFDF58
	protected internal virtual object VisitGoto(object node) { }

	// RVA: 0x6CFE180
	protected internal virtual object VisitInvocation(object node) { }

	// RVA: 0x6CFE24C
	protected virtual object VisitLabelTarget(object node) { }

	// RVA: 0x6CFE254
	protected internal virtual object VisitLabel(object node) { }

	// RVA: -1
	protected internal virtual object VisitLambda(object node) { }

	// RVA: 0x6CFE3FC
	protected internal virtual object VisitLoop(object node) { }

	// RVA: 0x6CFE614
	protected internal virtual object VisitMember(object node) { }

	// RVA: 0x6CFE7C0
	protected internal virtual object VisitIndex(object node) { }

	// RVA: 0x6CFE974
	protected internal virtual object VisitMethodCall(object node) { }

	// RVA: 0x6CFEA84
	protected internal virtual object VisitNewArray(object node) { }

	// RVA: 0x6CFECC8
	protected internal virtual object VisitParameter(object node) { }

	// RVA: 0x6CFECD0
	protected virtual object VisitCatchBlock(object node) { }

	// RVA: 0x6CFEE50
	protected internal virtual object VisitTry(object node) { }

	// RVA: 0x6CFF0CC
	protected internal virtual object VisitTypeBinary(object node) { }

	// RVA: 0x6CFF220
	protected internal virtual object VisitUnary(object node) { }

	// RVA: 0x6CFF390
	private static object ValidateUnary(object before, object after) { }

	// RVA: 0x6CFDA9C
	private static object ValidateBinary(object before, object after) { }

	// RVA: 0x6CFF4FC
	private static object ValidateChildType(object before, object after, object methodName) { }

}

// Namespace: System.Linq.Expressions
public enum GotoExpressionKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Goto;
	public const object Return;
	public const object Break;
	public const object Continue;
}

// Namespace: System.Linq.Expressions
public sealed class GotoExpression
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x8
	private readonly object <Value>k__BackingField; // 0x10
	private readonly object <Target>k__BackingField; // 0x18
	private readonly object <Kind>k__BackingField; // 0x20

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }
	public object Value { get; }
	public object Target { get; }
	public object Kind { get; }

	// Methods

	// RVA: 0x6CFF5E0
	internal object .ctor(object kind, object target, object value, object type) { }

	// RVA: 0x6CFF674
	public sealed override object get_Type() { }

	// RVA: 0x6CFF67C
	public sealed override object get_NodeType() { }

	// RVA: 0x6CFF684
	public object get_Value() { }

	// RVA: 0x6CFF68C
	public object get_Target() { }

	// RVA: 0x6CFF694
	public object get_Kind() { }

	// RVA: 0x6CFF69C
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFE0A4
	public object Update(object target, object value) { }

}

// Namespace: System.Linq.Expressions
public interface IArgumentProvider
{

	// Properties
	public abstract object ArgumentCount { get; }

	// Methods

	// RVA: -1
	public abstract object GetArgument(object index) { }

	// RVA: -1
	public abstract object get_ArgumentCount() { }

}

// Namespace: System.Linq.Expressions
internal interface IParameterProvider
{

	// Properties
	public abstract object ParameterCount { get; }

	// Methods

	// RVA: -1
	public abstract object GetParameter(object index) { }

	// RVA: -1
	public abstract object get_ParameterCount() { }

}

// Namespace: System.Linq.Expressions
public sealed class IndexExpression
{

	// Fields
	private object _arguments; // 0x8
	private readonly object <Object>k__BackingField; // 0x10
	private readonly object <Indexer>k__BackingField; // 0x18

	// Properties
	public sealed override object NodeType { get; }
	public sealed override object Type { get; }
	public object Object { get; }
	public object Indexer { get; }
	public object ArgumentCount { get; }

	// Methods

	// RVA: 0x6CFF6F0
	internal object .ctor(object instance, object indexer, object arguments) { }

	// RVA: 0x6CFF784
	public sealed override object get_NodeType() { }

	// RVA: 0x6CFF78C
	public sealed override object get_Type() { }

	// RVA: 0x6CFF874
	public object get_Object() { }

	// RVA: 0x6CFF87C
	public object get_Indexer() { }

	// RVA: 0x6CFD320
	public object GetArgument(object index) { }

	// RVA: 0x6CFD240
	public object get_ArgumentCount() { }

	// RVA: 0x6CFF884
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFE8D4
	internal object Rewrite(object instance, object arguments) { }

}

// Namespace: System.Linq.Expressions
public class InvocationExpression
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x8
	private readonly object <Expression>k__BackingField; // 0x10

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }
	public object Expression { get; }
	public virtual object ArgumentCount { get; }

	// Methods

	// RVA: 0x6CFF8DC
	internal object .ctor(object expression, object returnType) { }

	// RVA: 0x6CFF958
	public sealed override object get_Type() { }

	// RVA: 0x6CFF960
	public sealed override object get_NodeType() { }

	// RVA: 0x6CFF968
	public object get_Expression() { }

	// RVA: 0x6CFF970
	public virtual object GetArgument(object index) { }

	// RVA: 0x6CFF9A0
	public virtual object get_ArgumentCount() { }

	// RVA: 0x6CFF9D0
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFFA24
	internal virtual object Rewrite(object lambda, object arguments) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InvocationExpressionN
{

	// Fields
	private object _arguments; // 0x18

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6CFFA54
	public object .ctor(object lambda, object arguments, object returnType) { }

	// RVA: 0x6CFFAD8
	public override object GetArgument(object index) { }

	// RVA: 0x6CFFBAC
	public override object get_ArgumentCount() { }

	// RVA: 0x6CFFC8C
	internal override object Rewrite(object lambda, object arguments) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InvocationExpression0
{

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6CFFD20
	public object .ctor(object lambda, object returnType) { }

	// RVA: 0x6CFFD9C
	public override object GetArgument(object index) { }

	// RVA: 0x6CFFDF0
	public override object get_ArgumentCount() { }

	// RVA: 0x6CFFDF8
	internal override object Rewrite(object lambda, object arguments) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InvocationExpression1
{

	// Fields
	private object _arg0; // 0x18

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6CFFE80
	public object .ctor(object lambda, object returnType, object arg0) { }

	// RVA: 0x6CFFF04
	public override object GetArgument(object index) { }

	// RVA: 0x6CFFFA8
	public override object get_ArgumentCount() { }

	// RVA: 0x6CFFFB0
	internal override object Rewrite(object lambda, object arguments) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InvocationExpression2
{

	// Fields
	private object _arg0; // 0x18
	private readonly object _arg1; // 0x20

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D00068
	public object .ctor(object lambda, object returnType, object arg0, object arg1) { }

	// RVA: 0x6D000F8
	public override object GetArgument(object index) { }

	// RVA: 0x6D001B8
	public override object get_ArgumentCount() { }

	// RVA: 0x6D001C0
	internal override object Rewrite(object lambda, object arguments) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InvocationExpression3
{

	// Fields
	private object _arg0; // 0x18
	private readonly object _arg1; // 0x20
	private readonly object _arg2; // 0x28

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D002A8
	public object .ctor(object lambda, object returnType, object arg0, object arg1, object arg2) { }

	// RVA: 0x6D00340
	public override object GetArgument(object index) { }

	// RVA: 0x6D0041C
	public override object get_ArgumentCount() { }

	// RVA: 0x6D00424
	internal override object Rewrite(object lambda, object arguments) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InvocationExpression4
{

	// Fields
	private object _arg0; // 0x18
	private readonly object _arg1; // 0x20
	private readonly object _arg2; // 0x28
	private readonly object _arg3; // 0x30

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D00538
	public object .ctor(object lambda, object returnType, object arg0, object arg1, object arg2, object arg3) { }

	// RVA: 0x6D005DC
	public override object GetArgument(object index) { }

	// RVA: 0x6D006DC
	public override object get_ArgumentCount() { }

	// RVA: 0x6D006E4
	internal override object Rewrite(object lambda, object arguments) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InvocationExpression5
{

	// Fields
	private object _arg0; // 0x18
	private readonly object _arg1; // 0x20
	private readonly object _arg2; // 0x28
	private readonly object _arg3; // 0x30
	private readonly object _arg4; // 0x38

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D00810
	public object .ctor(object lambda, object returnType, object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x6D008BC
	public override object GetArgument(object index) { }

	// RVA: 0x6D009D8
	public override object get_ArgumentCount() { }

	// RVA: 0x6D009E0
	internal override object Rewrite(object lambda, object arguments) { }

}

// Namespace: System.Linq.Expressions
public sealed class LabelExpression
{

	// Fields
	private readonly object <Target>k__BackingField; // 0x8
	private readonly object <DefaultValue>k__BackingField; // 0x10

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }
	public object Target { get; }
	public object DefaultValue { get; }

	// Methods

	// RVA: 0x6D00B18
	internal object .ctor(object label, object defaultValue) { }

	// RVA: 0x6D00B94
	public sealed override object get_Type() { }

	// RVA: 0x6D00BB8
	public sealed override object get_NodeType() { }

	// RVA: 0x6D00BC0
	public object get_Target() { }

	// RVA: 0x6D00BC8
	public object get_DefaultValue() { }

	// RVA: 0x6D00BD0
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFE360
	public object Update(object target, object defaultValue) { }

}

// Namespace: System.Linq.Expressions
public sealed class LabelTarget
{

	// Fields
	private readonly object <Name>k__BackingField; // 0x8
	private readonly object <Type>k__BackingField; // 0x10

	// Properties
	public object Name { get; }
	public object Type { get; }

	// Methods

	// RVA: 0x6D00C28
	internal object .ctor(object type, object name) { }

	// RVA: 0x6D00C60
	public object get_Name() { }

	// RVA: 0x6D00C68
	public object get_Type() { }

	// RVA: 0x6D00C70
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions
public abstract class LambdaExpression
{

	// Fields
	private readonly object _body; // 0x8

	// Properties
	public sealed override object Type { get; }
	internal abstract object TypeCore { get; }
	internal abstract object PublicType { get; }
	public sealed override object NodeType { get; }
	public object Name { get; }
	internal virtual object NameCore { get; }
	public object Body { get; }
	public object ReturnType { get; }
	public object TailCall { get; }
	internal virtual object TailCallCore { get; }
	private object System.Linq.Expressions.IParameterProvider.ParameterCount { get; }
	internal virtual object ParameterCount { get; }

	// Methods

	// RVA: 0x6D00CD4
	internal object .ctor(object body) { }

	// RVA: 0x6D00D44
	public sealed override object get_Type() { }

	// RVA: -1
	internal abstract object get_TypeCore() { }

	// RVA: -1
	internal abstract object get_PublicType() { }

	// RVA: 0x6D00D84
	public sealed override object get_NodeType() { }

	// RVA: 0x6D00D8C
	public object get_Name() { }

	// RVA: 0x6D00DD0
	internal virtual object get_NameCore() { }

	// RVA: 0x6D00DD8
	public object get_Body() { }

	// RVA: 0x6D00DE0
	public object get_ReturnType() { }

	// RVA: 0x6D00EA8
	public object get_TailCall() { }

	// RVA: 0x6D00EEC
	internal virtual object get_TailCallCore() { }

	// RVA: 0x6D00EF4
	private object System.Linq.Expressions.IParameterProvider.GetParameter(object index) { }

	// RVA: 0x6D00F40
	internal virtual object GetParameter(object index) { }

	// RVA: 0x6D00F70
	private object System.Linq.Expressions.IParameterProvider.get_ParameterCount() { }

	// RVA: 0x6D00FB4
	internal virtual object get_ParameterCount() { }

	// RVA: 0x6D00FE4
	public object Compile() { }

	// RVA: 0x6D00FEC
	public object Compile(object preferInterpretation) { }

}

// Namespace: System.Linq.Expressions
public class Expression<T0>
{

	// Properties
	internal sealed override object TypeCore { get; }
	internal override object PublicType { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object body) { }

	// RVA: -1
	internal sealed override object get_TypeCore() { }

	// RVA: -1
	internal override object get_PublicType() { }

	// RVA: -1
	public object Compile() { }

	// RVA: -1
	public object Compile(object preferInterpretation) { }

	// RVA: -1
	internal virtual object Rewrite(object body, object parameters) { }

	// RVA: -1
	protected internal override object Accept(object visitor) { }

}

// Namespace: System.Linq.Expressions
internal static class ExpressionCreator<T0>
{

	// Methods

	// RVA: -1
	public static object CreateExpressionFunc(object body, object name, object tailCall, object parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Expression0<T0>
{

	// Properties
	internal override object ParameterCount { get; }

	// Methods

	// RVA: -1
	public object .ctor(object body) { }

	// RVA: -1
	internal override object get_ParameterCount() { }

	// RVA: -1
	internal override object GetParameter(object index) { }

	// RVA: -1
	internal override object Rewrite(object body, object parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Expression1<T0>
{

	// Fields
	private object _par0; // 0x0

	// Properties
	internal override object ParameterCount { get; }

	// Methods

	// RVA: -1
	public object .ctor(object body, object par0) { }

	// RVA: -1
	internal override object get_ParameterCount() { }

	// RVA: -1
	internal override object GetParameter(object index) { }

	// RVA: -1
	internal override object Rewrite(object body, object parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Expression2<T0>
{

	// Fields
	private object _par0; // 0x0
	private readonly object _par1; // 0x0

	// Properties
	internal override object ParameterCount { get; }

	// Methods

	// RVA: -1
	public object .ctor(object body, object par0, object par1) { }

	// RVA: -1
	internal override object get_ParameterCount() { }

	// RVA: -1
	internal override object GetParameter(object index) { }

	// RVA: -1
	internal override object Rewrite(object body, object parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class Expression3<T0>
{

	// Fields
	private object _par0; // 0x0
	private readonly object _par1; // 0x0
	private readonly object _par2; // 0x0

	// Properties
	internal override object ParameterCount { get; }

	// Methods

	// RVA: -1
	public object .ctor(object body, object par0, object par1, object par2) { }

	// RVA: -1
	internal override object get_ParameterCount() { }

	// RVA: -1
	internal override object GetParameter(object index) { }

	// RVA: -1
	internal override object Rewrite(object body, object parameters) { }

}

// Namespace: System.Linq.Expressions
internal class ExpressionN<T0>
{

	// Fields
	private object _parameters; // 0x0

	// Properties
	internal override object ParameterCount { get; }

	// Methods

	// RVA: -1
	public object .ctor(object body, object parameters) { }

	// RVA: -1
	internal override object get_ParameterCount() { }

	// RVA: -1
	internal override object GetParameter(object index) { }

	// RVA: -1
	internal override object Rewrite(object body, object parameters) { }

}

// Namespace: System.Linq.Expressions
internal sealed class FullExpression<T0>
{

	// Fields
	private readonly object <NameCore>k__BackingField; // 0x0
	private readonly object <TailCallCore>k__BackingField; // 0x0

	// Properties
	internal override object NameCore { get; }
	internal override object TailCallCore { get; }

	// Methods

	// RVA: -1
	public object .ctor(object body, object name, object tailCall, object parameters) { }

	// RVA: -1
	internal override object get_NameCore() { }

	// RVA: -1
	internal override object get_TailCallCore() { }

}

// Namespace: System.Linq.Expressions
public sealed class ListInitExpression
{

	// Fields
	private readonly object <NewExpression>k__BackingField; // 0x8
	private readonly object <Initializers>k__BackingField; // 0x10

	// Properties
	public object NewExpression { get; }
	public object Initializers { get; }

	// Methods

	// RVA: 0x6D01080
	public object get_NewExpression() { }

	// RVA: 0x6D01088
	public object get_Initializers() { }

}

// Namespace: System.Linq.Expressions
public sealed class LoopExpression
{

	// Fields
	private readonly object <Body>k__BackingField; // 0x8
	private readonly object <BreakLabel>k__BackingField; // 0x10
	private readonly object <ContinueLabel>k__BackingField; // 0x18

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }
	public object Body { get; }
	public object BreakLabel { get; }
	public object ContinueLabel { get; }

	// Methods

	// RVA: 0x6D01090
	internal object .ctor(object body, object break, object continue) { }

	// RVA: 0x6D01114
	public sealed override object get_Type() { }

	// RVA: 0x6D011B4
	public sealed override object get_NodeType() { }

	// RVA: 0x6D011BC
	public object get_Body() { }

	// RVA: 0x6D011C4
	public object get_BreakLabel() { }

	// RVA: 0x6D011CC
	public object get_ContinueLabel() { }

	// RVA: 0x6D011D4
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFE558
	public object Update(object breakLabel, object continueLabel, object body) { }

}

// Namespace: System.Linq.Expressions
public sealed class MemberAssignment
{

	// Fields
	private readonly object _expression; // 0x18

	// Properties
	public object Expression { get; }

	// Methods

	// RVA: 0x6D0122C
	public object get_Expression() { }

}

// Namespace: System.Linq.Expressions
public enum MemberBindingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Assignment;
	public const object MemberBinding;
	public const object ListBinding;
}

// Namespace: System.Linq.Expressions
public abstract class MemberBinding
{

	// Fields
	private readonly object <BindingType>k__BackingField; // 0x8
	private readonly object <Member>k__BackingField; // 0x10

	// Properties
	public object BindingType { get; }
	public object Member { get; }

	// Methods

	// RVA: 0x6D01234
	public object get_BindingType() { }

	// RVA: 0x6D0123C
	public object get_Member() { }

}

// Namespace: System.Linq.Expressions
public class MemberExpression
{

	// Fields
	private readonly object <Expression>k__BackingField; // 0x8

	// Properties
	public object Member { get; }
	public object Expression { get; }
	public sealed override object NodeType { get; }

	// Methods

	// RVA: 0x6CFB820
	public object get_Member() { }

	// RVA: 0x6D01244
	public object get_Expression() { }

	// RVA: 0x6D0124C
	internal object .ctor(object expression) { }

	// RVA: 0x6D012BC
	internal static object Make(object expression, object property) { }

	// RVA: 0x6D013E8
	internal static object Make(object expression, object field) { }

	// RVA: 0x6D01514
	public sealed override object get_NodeType() { }

	// RVA: 0x6D0151C
	internal virtual object GetMember() { }

	// RVA: 0x6D0154C
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFE70C
	public object Update(object expression) { }

}

// Namespace: System.Linq.Expressions
internal sealed class FieldExpression
{

	// Fields
	private readonly object _field; // 0x10

	// Properties
	public sealed override object Type { get; }

	// Methods

	// RVA: 0x6D01498
	public object .ctor(object expression, object member) { }

	// RVA: 0x6D015A4
	internal override object GetMember() { }

	// RVA: 0x6D015AC
	public sealed override object get_Type() { }

}

// Namespace: System.Linq.Expressions
internal sealed class PropertyExpression
{

	// Fields
	private readonly object _property; // 0x10

	// Properties
	public sealed override object Type { get; }

	// Methods

	// RVA: 0x6D0136C
	public object .ctor(object expression, object member) { }

	// RVA: 0x6D015FC
	internal override object GetMember() { }

	// RVA: 0x6D01604
	public sealed override object get_Type() { }

}

// Namespace: System.Linq.Expressions
public sealed class MemberInitExpression
{

	// Fields
	private readonly object <NewExpression>k__BackingField; // 0x8
	private readonly object <Bindings>k__BackingField; // 0x10

	// Properties
	public object NewExpression { get; }
	public object Bindings { get; }

	// Methods

	// RVA: 0x6D01654
	public object get_NewExpression() { }

	// RVA: 0x6D0165C
	public object get_Bindings() { }

}

// Namespace: System.Linq.Expressions
public sealed class MemberListBinding
{

	// Fields
	private readonly object <Initializers>k__BackingField; // 0x18

	// Properties
	public object Initializers { get; }

	// Methods

	// RVA: 0x6D01664
	public object get_Initializers() { }

}

// Namespace: System.Linq.Expressions
public sealed class MemberMemberBinding
{

	// Fields
	private readonly object <Bindings>k__BackingField; // 0x18

	// Properties
	public object Bindings { get; }

	// Methods

	// RVA: 0x6D0166C
	public object get_Bindings() { }

}

// Namespace: System.Linq.Expressions
public class MethodCallExpression
{

	// Fields
	private readonly object <Method>k__BackingField; // 0x8

	// Properties
	public sealed override object NodeType { get; }
	public sealed override object Type { get; }
	public object Method { get; }
	public object Object { get; }
	public virtual object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D01674
	internal object .ctor(object method) { }

	// RVA: 0x6D016E4
	internal virtual object GetInstance() { }

	// RVA: 0x6D016EC
	public sealed override object get_NodeType() { }

	// RVA: 0x6D016F4
	public sealed override object get_Type() { }

	// RVA: 0x6D01744
	public object get_Method() { }

	// RVA: 0x6CFBCFC
	public object get_Object() { }

	// RVA: 0x6D0174C
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6D017A4
	internal virtual object Rewrite(object instance, object args) { }

	// RVA: 0x6D017D4
	public virtual object GetArgument(object index) { }

	// RVA: 0x6D01804
	public virtual object get_ArgumentCount() { }

}

// Namespace: System.Linq.Expressions
internal class InstanceMethodCallExpression
{

	// Fields
	private readonly object _instance; // 0x10

	// Methods

	// RVA: 0x6D01834
	public object .ctor(object method, object instance) { }

	// RVA: 0x6D018B0
	internal override object GetInstance() { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpressionN
{

	// Fields
	private object _arguments; // 0x10

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D018B8
	public object .ctor(object method, object args) { }

	// RVA: 0x6D01934
	public override object GetArgument(object index) { }

	// RVA: 0x6D01A08
	public override object get_ArgumentCount() { }

	// RVA: 0x6D01AE8
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpressionN
{

	// Fields
	private object _arguments; // 0x18

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D01B80
	public object .ctor(object method, object instance, object args) { }

	// RVA: 0x6D01C04
	public override object GetArgument(object index) { }

	// RVA: 0x6D01CD8
	public override object get_ArgumentCount() { }

	// RVA: 0x6D01DB8
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression0
{

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D01E58
	public object .ctor(object method) { }

	// RVA: 0x6D01EC8
	public override object GetArgument(object index) { }

	// RVA: 0x6D01F1C
	public override object get_ArgumentCount() { }

	// RVA: 0x6D01F24
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression1
{

	// Fields
	private object _arg0; // 0x10

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D01FB4
	public object .ctor(object method, object arg0) { }

	// RVA: 0x6D02030
	public override object GetArgument(object index) { }

	// RVA: 0x6D020D4
	public override object get_ArgumentCount() { }

	// RVA: 0x6D020DC
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression2
{

	// Fields
	private object _arg0; // 0x10
	private readonly object _arg1; // 0x18

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D02218
	public object .ctor(object method, object arg0, object arg1) { }

	// RVA: 0x6D0229C
	public override object GetArgument(object index) { }

	// RVA: 0x6D0235C
	public override object get_ArgumentCount() { }

	// RVA: 0x6D02364
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression3
{

	// Fields
	private object _arg0; // 0x10
	private readonly object _arg1; // 0x18
	private readonly object _arg2; // 0x20

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D02548
	public object .ctor(object method, object arg0, object arg1, object arg2) { }

	// RVA: 0x6D025D8
	public override object GetArgument(object index) { }

	// RVA: 0x6D026B4
	public override object get_ArgumentCount() { }

	// RVA: 0x6D026BC
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression4
{

	// Fields
	private object _arg0; // 0x10
	private readonly object _arg1; // 0x18
	private readonly object _arg2; // 0x20
	private readonly object _arg3; // 0x28

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D02918
	public object .ctor(object method, object arg0, object arg1, object arg2, object arg3) { }

	// RVA: 0x6D029B0
	public override object GetArgument(object index) { }

	// RVA: 0x6D02AB0
	public override object get_ArgumentCount() { }

	// RVA: 0x6D02AB8
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class MethodCallExpression5
{

	// Fields
	private object _arg0; // 0x10
	private readonly object _arg1; // 0x18
	private readonly object _arg2; // 0x20
	private readonly object _arg3; // 0x28
	private readonly object _arg4; // 0x30

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D02D9C
	public object .ctor(object method, object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: 0x6D02E40
	public override object GetArgument(object index) { }

	// RVA: 0x6D02F5C
	public override object get_ArgumentCount() { }

	// RVA: 0x6D02F64
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpression0
{

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D032D4
	public object .ctor(object method, object instance) { }

	// RVA: 0x6D03350
	public override object GetArgument(object index) { }

	// RVA: 0x6D033A4
	public override object get_ArgumentCount() { }

	// RVA: 0x6D033AC
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpression1
{

	// Fields
	private object _arg0; // 0x18

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D0341C
	public object .ctor(object method, object instance, object arg0) { }

	// RVA: 0x6D034A0
	public override object GetArgument(object index) { }

	// RVA: 0x6D03544
	public override object get_ArgumentCount() { }

	// RVA: 0x6D0354C
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpression2
{

	// Fields
	private object _arg0; // 0x18
	private readonly object _arg1; // 0x20

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D03690
	public object .ctor(object method, object instance, object arg0, object arg1) { }

	// RVA: 0x6D03720
	public override object GetArgument(object index) { }

	// RVA: 0x6D037E0
	public override object get_ArgumentCount() { }

	// RVA: 0x6D037E8
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
internal sealed class InstanceMethodCallExpression3
{

	// Fields
	private object _arg0; // 0x18
	private readonly object _arg1; // 0x20
	private readonly object _arg2; // 0x28

	// Properties
	public override object ArgumentCount { get; }

	// Methods

	// RVA: 0x6D039CC
	public object .ctor(object method, object instance, object arg0, object arg1, object arg2) { }

	// RVA: 0x6D03A64
	public override object GetArgument(object index) { }

	// RVA: 0x6D03B40
	public override object get_ArgumentCount() { }

	// RVA: 0x6D03B48
	internal override object Rewrite(object instance, object args) { }

}

// Namespace: System.Linq.Expressions
public class NewArrayExpression
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x8
	private readonly object <Expressions>k__BackingField; // 0x10

	// Properties
	public sealed override object Type { get; }
	public object Expressions { get; }

	// Methods

	// RVA: 0x6D03DB0
	internal object .ctor(object type, object expressions) { }

	// RVA: 0x6D03E2C
	internal static object Make(object nodeType, object type, object expressions) { }

	// RVA: 0x6D04038
	public sealed override object get_Type() { }

	// RVA: 0x6D04040
	public object get_Expressions() { }

	// RVA: 0x6D04048
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFEAC0
	public object Update(object expressions) { }

}

// Namespace: System.Linq.Expressions
internal sealed class NewArrayInitExpression
{

	// Properties
	public sealed override object NodeType { get; }

	// Methods

	// RVA: 0x6D03F40
	internal object .ctor(object type, object expressions) { }

	// RVA: 0x6D040A0
	public sealed override object get_NodeType() { }

}

// Namespace: System.Linq.Expressions
internal sealed class NewArrayBoundsExpression
{

	// Properties
	public sealed override object NodeType { get; }

	// Methods

	// RVA: 0x6D03FBC
	internal object .ctor(object type, object expressions) { }

	// RVA: 0x6D040A8
	public sealed override object get_NodeType() { }

}

// Namespace: System.Linq.Expressions
public class NewExpression
{

	// Fields
	private object _arguments; // 0x8
	private readonly object <Constructor>k__BackingField; // 0x10

	// Properties
	public object Constructor { get; }

	// Methods

	// RVA: 0x6D040B0
	public object get_Constructor() { }

	// RVA: 0x6D040B8
	public object GetArgument(object index) { }

}

// Namespace: System.Linq.Expressions
public class ParameterExpression
{

	// Fields
	private readonly object <Name>k__BackingField; // 0x8

	// Properties
	public override object Type { get; }
	public sealed override object NodeType { get; }
	public object Name { get; }
	public object IsByRef { get; }

	// Methods

	// RVA: 0x6D0418C
	internal object .ctor(object name) { }

	// RVA: 0x6D041FC
	internal static object Make(object type, object name, object isByRef) { }

	// RVA: 0x6D04B58
	public override object get_Type() { }

	// RVA: 0x6D04BF8
	public sealed override object get_NodeType() { }

	// RVA: 0x6D04C00
	public object get_Name() { }

	// RVA: 0x6CFB2D0
	public object get_IsByRef() { }

	// RVA: 0x6D04C08
	internal virtual object GetIsByRef() { }

	// RVA: 0x6D04C10
	protected internal override object Accept(object visitor) { }

}

// Namespace: System.Linq.Expressions
internal sealed class ByRefParameterExpression
{

	// Methods

	// RVA: 0x6D04A60
	internal object .ctor(object type, object name) { }

	// RVA: 0x6D04C68
	internal override object GetIsByRef() { }

}

// Namespace: System.Linq.Expressions
internal class TypedParameterExpression
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x10

	// Properties
	public sealed override object Type { get; }

	// Methods

	// RVA: 0x6D04ADC
	internal object .ctor(object type, object name) { }

	// RVA: 0x6D04C70
	public sealed override object get_Type() { }

}

// Namespace: System.Linq.Expressions
internal sealed class PrimitiveParameterExpression<T0>
{

	// Properties
	public sealed override object Type { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object name) { }

	// RVA: -1
	public sealed override object get_Type() { }

}

// Namespace: System.Linq.Expressions
public sealed class RuntimeVariablesExpression
{

	// Fields
	private readonly object <Variables>k__BackingField; // 0x8

	// Properties
	public object Variables { get; }

	// Methods

	// RVA: 0x6D04C78
	public object get_Variables() { }

}

// Namespace: 
private sealed class <>c__3<T0, T1>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <RunOnEmptyStack>b__3_0(object s) { }

}

// Namespace: System.Linq.Expressions
internal sealed class StackGuard
{

	// Fields
	private object _executionStackCount; // 0x8

	// Methods

	// RVA: 0x6D04C80
	public object TryEnterOnCurrentStack() { }

	// RVA: -1
	public object RunOnEmptyStack(object action, object arg1, object arg2) { }

	// RVA: -1
	private object RunOnEmptyStackCore(object action, object state) { }

	// RVA: 0x6D04CE8
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions
internal static class Strings
{

	// Properties
	internal static object ReducibleMustOverrideReduce { get; }
	internal static object MustReduceToDifferent { get; }
	internal static object ReducedNotCompatible { get; }
	internal static object SetterHasNoParams { get; }
	internal static object PropertyCannotHaveRefType { get; }
	internal static object IndexesOfSetGetMustMatch { get; }
	internal static object AccessorsCannotHaveVarArgs { get; }
	internal static object AccessorsCannotHaveByRefArgs { get; }
	internal static object BoundsCannotBeLessThanOne { get; }
	internal static object TypeMustNotBeByRef { get; }
	internal static object TypeMustNotBePointer { get; }
	internal static object SetterMustBeVoid { get; }
	internal static object PropertyTypeMustMatchGetter { get; }
	internal static object PropertyTypeMustMatchSetter { get; }
	internal static object BothAccessorsMustBeStatic { get; }
	internal static object OnlyStaticFieldsHaveNullInstance { get; }
	internal static object OnlyStaticPropertiesHaveNullInstance { get; }
	internal static object OnlyStaticMethodsHaveNullInstance { get; }
	internal static object PropertyTypeCannotBeVoid { get; }
	internal static object InvalidUnboxType { get; }
	internal static object ExpressionMustBeWriteable { get; }
	internal static object ArgumentMustNotHaveValueType { get; }
	internal static object MustBeReducible { get; }
	internal static object LabelMustBeVoidOrHaveExpression { get; }
	internal static object LabelTypeMustBeVoid { get; }
	internal static object QuotedExpressionMustBeLambda { get; }
	internal static object CollectionModifiedWhileEnumerating { get; }
	internal static object CollectionReadOnly { get; }
	internal static object BindingCannotBeNull { get; }
	internal static object NoOrInvalidRuleProduced { get; }
	internal static object TypeMustBeDerivedFromSystemDelegate { get; }
	internal static object FirstArgumentMustBeCallSite { get; }
	internal static object FaultCannotHaveCatchOrFinally { get; }
	internal static object TryMustHaveCatchFinallyOrFault { get; }
	internal static object BodyOfCatchMustHaveSameTypeAsBodyOfTry { get; }
	internal static object ConversionIsNotSupportedForArithmeticTypes { get; }
	internal static object ArgumentMustBeArray { get; }
	internal static object ArgumentMustBeBoolean { get; }
	internal static object ArgumentMustBeInteger { get; }
	internal static object ArgumentMustBeArrayIndexType { get; }
	internal static object ArgumentMustBeSingleDimensionalArrayType { get; }
	internal static object ArgumentTypesMustMatch { get; }
	internal static object CoalesceUsedOnNonNullType { get; }
	internal static object IncorrectNumberOfIndexes { get; }
	internal static object IncorrectNumberOfLambdaDeclarationParameters { get; }
	internal static object LambdaTypeMustBeDerivedFromSystemDelegate { get; }
	internal static object ArgumentCannotBeOfTypeVoid { get; }
	internal static object ControlCannotLeaveFinally { get; }
	internal static object ControlCannotLeaveFilterTest { get; }
	internal static object ControlCannotEnterTry { get; }
	internal static object ControlCannotEnterExpression { get; }
	internal static object RethrowRequiresCatch { get; }
	internal static object NonAbstractConstructorRequired { get; }
	internal static object ExpressionMustBeReadable { get; }
	internal static object EnumerationIsDone { get; }
	internal static object InvalidArgumentValue { get; }
	internal static object IncorrectNumberOfLambdaArguments { get; }
	internal static object IncorrectNumberOfConstructorArguments { get; }

	// Methods

	// RVA: 0x6CF2698
	internal static object get_ReducibleMustOverrideReduce() { }

	// RVA: 0x6CF2D24
	internal static object get_MustReduceToDifferent() { }

	// RVA: 0x6CF341C
	internal static object get_ReducedNotCompatible() { }

	// RVA: 0x6CF34F8
	internal static object get_SetterHasNoParams() { }

	// RVA: 0x6CF35D4
	internal static object get_PropertyCannotHaveRefType() { }

	// RVA: 0x6CF36B0
	internal static object get_IndexesOfSetGetMustMatch() { }

	// RVA: 0x6CF395C
	internal static object get_AccessorsCannotHaveVarArgs() { }

	// RVA: 0x6CF3A38
	internal static object get_AccessorsCannotHaveByRefArgs() { }

	// RVA: 0x6CF3E64
	internal static object get_BoundsCannotBeLessThanOne() { }

	// RVA: 0x6CF3F40
	internal static object get_TypeMustNotBeByRef() { }

	// RVA: 0x6CF401C
	internal static object get_TypeMustNotBePointer() { }

	// RVA: 0x6CF40F8
	internal static object get_SetterMustBeVoid() { }

	// RVA: 0x6CF41D4
	internal static object get_PropertyTypeMustMatchGetter() { }

	// RVA: 0x6CF42B0
	internal static object get_PropertyTypeMustMatchSetter() { }

	// RVA: 0x6CF438C
	internal static object get_BothAccessorsMustBeStatic() { }

	// RVA: 0x6CF4468
	internal static object get_OnlyStaticFieldsHaveNullInstance() { }

	// RVA: 0x6CF4544
	internal static object get_OnlyStaticPropertiesHaveNullInstance() { }

	// RVA: 0x6CF4618
	internal static object get_OnlyStaticMethodsHaveNullInstance() { }

	// RVA: 0x6CF46F4
	internal static object get_PropertyTypeCannotBeVoid() { }

	// RVA: 0x6CF47D0
	internal static object get_InvalidUnboxType() { }

	// RVA: 0x6CF48AC
	internal static object get_ExpressionMustBeWriteable() { }

	// RVA: 0x6CF4988
	internal static object get_ArgumentMustNotHaveValueType() { }

	// RVA: 0x6CF4A5C
	internal static object get_MustBeReducible() { }

	// RVA: 0x6CF4B38
	internal static object get_LabelMustBeVoidOrHaveExpression() { }

	// RVA: 0x6CF4C14
	internal static object get_LabelTypeMustBeVoid() { }

	// RVA: 0x6CF4CF0
	internal static object get_QuotedExpressionMustBeLambda() { }

	// RVA: 0x6CF2B7C
	internal static object get_CollectionModifiedWhileEnumerating() { }

	// RVA: 0x6CF4DF0
	internal static object VariableMustNotBeByRef(object p0, object p1) { }

	// RVA: 0x6CF2C50
	internal static object get_CollectionReadOnly() { }

	// RVA: 0x6CF287C
	internal static object AmbiguousMatchInExpandoObject(object p0) { }

	// RVA: 0x6CF2998
	internal static object SameKeyExistsInExpando(object p0) { }

	// RVA: 0x6CF2A94
	internal static object KeyDoesNotExistInExpando(object p0) { }

	// RVA: 0x6CF2780
	internal static object InvalidMetaObjectCreated(object p0) { }

	// RVA: 0x6CF2E24
	internal static object BinderNotCompatibleWithCallSite(object p0, object p1, object p2) { }

	// RVA: 0x6CF2F48
	internal static object DynamicBindingNeedsRestrictions(object p0, object p1) { }

	// RVA: 0x6CF3040
	internal static object DynamicObjectResultNotAssignable(object p0, object p1, object p2, object p3) { }

	// RVA: 0x6CF3248
	internal static object DynamicBinderResultNotAssignable(object p0, object p1, object p2) { }

	// RVA: 0x6CF3348
	internal static object get_BindingCannotBeNull() { }

	// RVA: 0x6CF5034
	internal static object DuplicateVariable(object p0) { }

	// RVA: 0x6CF3798
	internal static object TypeParameterIsNotDelegate(object p0) { }

	// RVA: 0x6CF3D88
	internal static object get_NoOrInvalidRuleProduced() { }

	// RVA: 0x6CF3CB4
	internal static object get_TypeMustBeDerivedFromSystemDelegate() { }

	// RVA: 0x6CF3880
	internal static object get_FirstArgumentMustBeCallSite() { }

	// RVA: 0x6CF524C
	internal static object get_FaultCannotHaveCatchOrFinally() { }

	// RVA: 0x6CF5320
	internal static object get_TryMustHaveCatchFinallyOrFault() { }

	// RVA: 0x6CF53F4
	internal static object get_BodyOfCatchMustHaveSameTypeAsBodyOfTry() { }

	// RVA: 0x6CF54DC
	internal static object ExtensionNodeMustOverrideProperty(object p0) { }

	// RVA: 0x6CF55E8
	internal static object UserDefinedOperatorMustBeStatic(object p0) { }

	// RVA: 0x6CF56F4
	internal static object UserDefinedOperatorMustNotBeVoid(object p0) { }

	// RVA: 0x6CF5800
	internal static object CoercionOperatorNotDefined(object p0, object p1) { }

	// RVA: 0x6CF5914
	internal static object UnaryOperatorNotDefined(object p0, object p1) { }

	// RVA: 0x6CF5A30
	internal static object BinaryOperatorNotDefined(object p0, object p1, object p2) { }

	// RVA: 0x6CF5B54
	internal static object ReferenceEqualityNotDefined(object p0, object p1) { }

	// RVA: 0x6CF5C68
	internal static object OperandTypesDoNotMatchParameters(object p0, object p1) { }

	// RVA: 0x6CF5D7C
	internal static object OverloadOperatorTypeDoesNotMatchConversionType(object p0, object p1) { }

	// RVA: 0x6CF5E6C
	internal static object get_ConversionIsNotSupportedForArithmeticTypes() { }

	// RVA: 0x6CF5F48
	internal static object get_ArgumentMustBeArray() { }

	// RVA: 0x6CF6024
	internal static object get_ArgumentMustBeBoolean() { }

	// RVA: 0x6CF6100
	internal static object get_ArgumentMustBeInteger() { }

	// RVA: 0x6CF62E8
	internal static object get_ArgumentMustBeArrayIndexType() { }

	// RVA: 0x6CF63C4
	internal static object get_ArgumentMustBeSingleDimensionalArrayType() { }

	// RVA: 0x6CF6498
	internal static object get_ArgumentTypesMustMatch() { }

	// RVA: 0x6CF6580
	internal static object CannotAutoInitializeValueTypeMemberThroughProperty(object p0) { }

	// RVA: 0x6CF668C
	internal static object IncorrectTypeForTypeAs(object p0) { }

	// RVA: 0x6CF6774
	internal static object get_CoalesceUsedOnNonNullType() { }

	// RVA: 0x6CF686C
	internal static object ExpressionTypeCannotInitializeArrayType(object p0, object p1) { }

	// RVA: 0x6CF6980
	internal static object ExpressionTypeDoesNotMatchReturn(object p0, object p1) { }

	// RVA: 0x6CF6A94
	internal static object ExpressionTypeDoesNotMatchAssignment(object p0, object p1) { }

	// RVA: 0x6CF6BA8
	internal static object ExpressionTypeDoesNotMatchLabel(object p0, object p1) { }

	// RVA: 0x6CF6CBC
	internal static object ExpressionTypeNotInvocable(object p0) { }

	// RVA: 0x6CF6DC8
	internal static object InstanceFieldNotDefinedForType(object p0, object p1) { }

	// RVA: 0x6CF6EE4
	internal static object FieldInfoNotDefinedForType(object p0, object p1, object p2) { }

	// RVA: 0x6CF6FE4
	internal static object get_IncorrectNumberOfIndexes() { }

	// RVA: 0x6CF70B8
	internal static object get_IncorrectNumberOfLambdaDeclarationParameters() { }

	// RVA: 0x6CF7194
	internal static object get_LambdaTypeMustBeDerivedFromSystemDelegate() { }

	// RVA: 0x6CF728C
	internal static object MemberNotFieldOrProperty(object p0) { }

	// RVA: 0x6CF7398
	internal static object MethodContainsGenericParameters(object p0) { }

	// RVA: 0x6CF74A4
	internal static object MethodIsGeneric(object p0) { }

	// RVA: 0x6CF75B0
	internal static object PropertyDoesNotHaveAccessor(object p0) { }

	// RVA: 0x6CF76BC
	internal static object ParameterExpressionNotValidAsDelegate(object p0, object p1) { }

	// RVA: 0x6CF77D8
	internal static object PropertyNotDefinedForType(object p0, object p1) { }

	// RVA: 0x6CF78F4
	internal static object InstancePropertyNotDefinedForType(object p0, object p1) { }

	// RVA: 0x6CF7A10
	internal static object InstanceAndMethodTypeMismatch(object p0, object p1, object p2) { }

	// RVA: 0x6CF7B34
	internal static object UnhandledBinary(object p0) { }

	// RVA: 0x6CF7C40
	internal static object UnhandledUnary(object p0) { }

	// RVA: 0x6CF7D4C
	internal static object UserDefinedOpMustHaveConsistentTypes(object p0, object p1) { }

	// RVA: 0x6CF7E60
	internal static object UserDefinedOpMustHaveValidReturnType(object p0, object p1) { }

	// RVA: 0x6CF7F74
	internal static object LogicalOperatorMustHaveBooleanOperators(object p0, object p1) { }

	// RVA: 0x6CF8088
	internal static object MethodWithArgsDoesNotExistOnType(object p0, object p1) { }

	// RVA: 0x6CF819C
	internal static object GenericMethodWithArgsDoesNotExistOnType(object p0, object p1) { }

	// RVA: 0x6CF82B0
	internal static object MethodWithMoreThanOneMatch(object p0, object p1) { }

	// RVA: 0x6CF83A8
	internal static object get_ArgumentCannotBeOfTypeVoid() { }

	// RVA: 0x6CF84A4
	internal static object OutOfRange(object p0, object p1) { }

	// RVA: 0x6CF85A8
	internal static object LabelTargetAlreadyDefined(object p0) { }

	// RVA: 0x6CF86A4
	internal static object LabelTargetUndefined(object p0) { }

	// RVA: 0x6CF878C
	internal static object get_ControlCannotLeaveFinally() { }

	// RVA: 0x6CF8860
	internal static object get_ControlCannotLeaveFilterTest() { }

	// RVA: 0x6CF8948
	internal static object AmbiguousJump(object p0) { }

	// RVA: 0x6CF8A30
	internal static object get_ControlCannotEnterTry() { }

	// RVA: 0x6CF8B04
	internal static object get_ControlCannotEnterExpression() { }

	// RVA: 0x6CF8BEC
	internal static object NonLocalJumpWithValue(object p0) { }

	// RVA: 0x6CF8D18
	internal static object InvalidLvalue(object p0) { }

	// RVA: 0x6CF8E00
	internal static object get_RethrowRequiresCatch() { }

	// RVA: 0x6CF8F00
	internal static object MustRewriteToSameNode(object p0, object p1, object p2) { }

	// RVA: 0x6CF902C
	internal static object MustRewriteChildToSameType(object p0, object p1, object p2) { }

	// RVA: 0x6CF9150
	internal static object MustRewriteWithoutMethod(object p0, object p1) { }

	// RVA: 0x6CF9298
	internal static object get_NonAbstractConstructorRequired() { }

	// RVA: 0x6CFA2D0
	internal static object get_ExpressionMustBeReadable() { }

	// RVA: 0x6CFA0A8
	internal static object ExpressionTypeDoesNotMatchConstructorParameter(object p0, object p1) { }

	// RVA: 0x6CF93C4
	internal static object get_EnumerationIsDone() { }

	// RVA: 0x6CF94BC
	internal static object TypeContainsGenericParameters(object p0) { }

	// RVA: 0x6CF96F0
	internal static object TypeIsGeneric(object p0) { }

	// RVA: 0x6CFA4B8
	internal static object get_InvalidArgumentValue() { }

	// RVA: 0x6CFA5B0
	internal static object InvalidNullValue(object p0) { }

	// RVA: 0x6CFA708
	internal static object InvalidObjectType(object p0, object p1) { }

	// RVA: 0x6CF9A10
	internal static object ExpressionTypeDoesNotMatchMethodParameter(object p0, object p1, object p2) { }

	// RVA: 0x6CF9C7C
	internal static object ExpressionTypeDoesNotMatchParameter(object p0, object p1) { }

	// RVA: 0x6CF9F94
	internal static object IncorrectNumberOfMethodCallArguments(object p0) { }

	// RVA: 0x6CF9E9C
	internal static object get_IncorrectNumberOfLambdaArguments() { }

	// RVA: 0x6CF9900
	internal static object get_IncorrectNumberOfConstructorArguments() { }

}

// Namespace: System.Linq.Expressions
public sealed class SwitchCase
{

	// Fields
	private readonly object <TestValues>k__BackingField; // 0x8
	private readonly object <Body>k__BackingField; // 0x10

	// Properties
	public object TestValues { get; }
	public object Body { get; }

	// Methods

	// RVA: 0x6D04CF0
	public object get_TestValues() { }

	// RVA: 0x6D04CF8
	public object get_Body() { }

}

// Namespace: System.Linq.Expressions
public sealed class SwitchExpression
{

	// Fields
	private readonly object <SwitchValue>k__BackingField; // 0x8
	private readonly object <Cases>k__BackingField; // 0x10
	private readonly object <DefaultBody>k__BackingField; // 0x18
	private readonly object <Comparison>k__BackingField; // 0x20

	// Properties
	public object SwitchValue { get; }
	public object Cases { get; }
	public object DefaultBody { get; }
	public object Comparison { get; }

	// Methods

	// RVA: 0x6D04D00
	public object get_SwitchValue() { }

	// RVA: 0x6D04D08
	public object get_Cases() { }

	// RVA: 0x6D04D10
	public object get_DefaultBody() { }

	// RVA: 0x6D04D18
	public object get_Comparison() { }

}

// Namespace: System.Linq.Expressions
public class SymbolDocumentInfo
{

	// Fields
	private readonly object <FileName>k__BackingField; // 0x8
	internal static readonly object DocumentType_Text; // 0x0

	// Properties
	public object FileName { get; }

	// Methods

	// RVA: 0x6D04D20
	public object get_FileName() { }

	// RVA: 0x6D04D28
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions
public sealed class TryExpression
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x8
	private readonly object <Body>k__BackingField; // 0x10
	private readonly object <Handlers>k__BackingField; // 0x18
	private readonly object <Finally>k__BackingField; // 0x20
	private readonly object <Fault>k__BackingField; // 0x28

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }
	public object Body { get; }
	public object Handlers { get; }
	public object Finally { get; }
	public object Fault { get; }

	// Methods

	// RVA: 0x6D04DBC
	internal object .ctor(object type, object body, object finally, object fault, object handlers) { }

	// RVA: 0x6D04E54
	public sealed override object get_Type() { }

	// RVA: 0x6D04E5C
	public sealed override object get_NodeType() { }

	// RVA: 0x6D04E64
	public object get_Body() { }

	// RVA: 0x6D04E6C
	public object get_Handlers() { }

	// RVA: 0x6D04E74
	public object get_Finally() { }

	// RVA: 0x6D04E7C
	public object get_Fault() { }

	// RVA: 0x6D04E84
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFEFBC
	public object Update(object body, object handlers, object finally, object fault) { }

}

// Namespace: System.Linq.Expressions
public sealed class TypeBinaryExpression
{

	// Fields
	private readonly object <NodeType>k__BackingField; // 0x8
	private readonly object <Expression>k__BackingField; // 0x10
	private readonly object <TypeOperand>k__BackingField; // 0x18

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }
	public object Expression { get; }
	public object TypeOperand { get; }

	// Methods

	// RVA: 0x6D04EDC
	internal object .ctor(object expression, object typeOperand, object nodeType) { }

	// RVA: 0x6D04F60
	public sealed override object get_Type() { }

	// RVA: 0x6D05000
	public sealed override object get_NodeType() { }

	// RVA: 0x6D05008
	public object get_Expression() { }

	// RVA: 0x6D05010
	public object get_TypeOperand() { }

	// RVA: 0x6D05018
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6CFF13C
	public object Update(object expression) { }

}

// Namespace: System.Linq.Expressions
public sealed class UnaryExpression
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x8
	private readonly object <NodeType>k__BackingField; // 0x10
	private readonly object <Operand>k__BackingField; // 0x18
	private readonly object <Method>k__BackingField; // 0x20

	// Properties
	public sealed override object Type { get; }
	public sealed override object NodeType { get; }
	public object Operand { get; }
	public object Method { get; }
	public object IsLifted { get; }
	public object IsLiftedToNull { get; }
	public override object CanReduce { get; }
	private object IsPrefix { get; }

	// Methods

	// RVA: 0x6D05070
	internal object .ctor(object nodeType, object expression, object type, object method) { }

	// RVA: 0x6D05104
	public sealed override object get_Type() { }

	// RVA: 0x6D0510C
	public sealed override object get_NodeType() { }

	// RVA: 0x6D05114
	public object get_Operand() { }

	// RVA: 0x6D0511C
	public object get_Method() { }

	// RVA: 0x6D05124
	public object get_IsLifted() { }

	// RVA: 0x6D053FC
	public object get_IsLiftedToNull() { }

	// RVA: 0x6D054AC
	protected internal override object Accept(object visitor) { }

	// RVA: 0x6D05504
	public override object get_CanReduce() { }

	// RVA: 0x6D05554
	public override object Reduce() { }

	// RVA: 0x6D066A0
	private object get_IsPrefix() { }

	// RVA: 0x6D06724
	private object FunctionalOp(object operand) { }

	// RVA: 0x6D06378
	private object ReduceVariable() { }

	// RVA: 0x6D05DD8
	private object ReduceMember() { }

	// RVA: 0x6D05614
	private object ReduceIndex() { }

	// RVA: 0x6CFF29C
	public object Update(object operand) { }

}

// Namespace: System.Linq.Expressions
internal static class Utils
{

	// Fields
	public static readonly object BoxedFalse; // 0x0
	public static readonly object BoxedTrue; // 0x8
	public static readonly object BoxedIntM1; // 0x10
	public static readonly object BoxedInt0; // 0x18
	public static readonly object BoxedInt1; // 0x20
	public static readonly object BoxedInt2; // 0x28
	public static readonly object BoxedInt3; // 0x30
	public static readonly object BoxedDefaultSByte; // 0x38
	public static readonly object BoxedDefaultChar; // 0x40
	public static readonly object BoxedDefaultInt16; // 0x48
	public static readonly object BoxedDefaultInt64; // 0x50
	public static readonly object BoxedDefaultByte; // 0x58
	public static readonly object BoxedDefaultUInt16; // 0x60
	public static readonly object BoxedDefaultUInt32; // 0x68
	public static readonly object BoxedDefaultUInt64; // 0x70
	public static readonly object BoxedDefaultSingle; // 0x78
	public static readonly object BoxedDefaultDouble; // 0x80
	public static readonly object BoxedDefaultDecimal; // 0x88
	public static readonly object BoxedDefaultDateTime; // 0x90
	private static readonly object s_true; // 0x98
	private static readonly object s_false; // 0xA0
	private static readonly object s_m1; // 0xA8
	private static readonly object s_0; // 0xB0
	private static readonly object s_1; // 0xB8
	private static readonly object s_2; // 0xC0
	private static readonly object s_3; // 0xC8
	public static readonly object Empty; // 0xD0
	public static readonly object Null; // 0xD8

	// Methods

	// RVA: 0x6D06888
	public static object Constant(object value) { }

	// RVA: 0x6D06900
	public static object Constant(object value) { }

	// RVA: 0x6D06B48
	private static object .cctor() { }

}

// Namespace: 
private sealed class AddInt16
{

	// Methods

	// RVA: 0x6D0752C
	public override object Run(object frame) { }

	// RVA: 0x6D074EC
	public object .ctor() { }

}

// Namespace: 
private sealed class AddInt32
{

	// Methods

	// RVA: 0x6D07690
	public override object Run(object frame) { }

	// RVA: 0x6D074F4
	public object .ctor() { }

}

// Namespace: 
private sealed class AddInt64
{

	// Methods

	// RVA: 0x6D077E4
	public override object Run(object frame) { }

	// RVA: 0x6D074FC
	public object .ctor() { }

}

// Namespace: 
private sealed class AddUInt16
{

	// Methods

	// RVA: 0x6D07948
	public override object Run(object frame) { }

	// RVA: 0x6D07504
	public object .ctor() { }

}

// Namespace: 
private sealed class AddUInt32
{

	// Methods

	// RVA: 0x6D07AAC
	public override object Run(object frame) { }

	// RVA: 0x6D0750C
	public object .ctor() { }

}

// Namespace: 
private sealed class AddUInt64
{

	// Methods

	// RVA: 0x6D07C10
	public override object Run(object frame) { }

	// RVA: 0x6D07514
	public object .ctor() { }

}

// Namespace: 
private sealed class AddSingle
{

	// Methods

	// RVA: 0x6D07D74
	public override object Run(object frame) { }

	// RVA: 0x6D0751C
	public object .ctor() { }

}

// Namespace: 
private sealed class AddDouble
{

	// Methods

	// RVA: 0x6D07EE0
	public override object Run(object frame) { }

	// RVA: 0x6D07524
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class AddInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28
	private static object s_Single; // 0x30
	private static object s_Double; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0702C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D07034
	public override object get_ProducedStack() { }

	// RVA: 0x6D0703C
	public override object get_InstructionName() { }

	// RVA: 0x6D07080
	private object .ctor() { }

	// RVA: 0x6D07088
	public static object Create(object type) { }

}

// Namespace: 
private sealed class AddOvfInt16
{

	// Methods

	// RVA: 0x6D0844C
	public override object Run(object frame) { }

	// RVA: 0x6D0841C
	public object .ctor() { }

}

// Namespace: 
private sealed class AddOvfInt32
{

	// Methods

	// RVA: 0x6D086B4
	public override object Run(object frame) { }

	// RVA: 0x6D08424
	public object .ctor() { }

}

// Namespace: 
private sealed class AddOvfInt64
{

	// Methods

	// RVA: 0x6D088E8
	public override object Run(object frame) { }

	// RVA: 0x6D0842C
	public object .ctor() { }

}

// Namespace: 
private sealed class AddOvfUInt16
{

	// Methods

	// RVA: 0x6D08AE8
	public override object Run(object frame) { }

	// RVA: 0x6D08434
	public object .ctor() { }

}

// Namespace: 
private sealed class AddOvfUInt32
{

	// Methods

	// RVA: 0x6D08D50
	public override object Run(object frame) { }

	// RVA: 0x6D0843C
	public object .ctor() { }

}

// Namespace: 
private sealed class AddOvfUInt64
{

	// Methods

	// RVA: 0x6D08F38
	public override object Run(object frame) { }

	// RVA: 0x6D08444
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class AddOvfInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0804C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D08054
	public override object get_ProducedStack() { }

	// RVA: 0x6D0805C
	public override object get_InstructionName() { }

	// RVA: 0x6D080A0
	private object .ctor() { }

	// RVA: 0x6D080A8
	public static object Create(object type) { }

}

// Namespace: 
private sealed class AndSByte
{

	// Methods

	// RVA: 0x6D0968C
	public override object Run(object frame) { }

	// RVA: 0x6D09644
	public object .ctor() { }

}

// Namespace: 
private sealed class AndInt16
{

	// Methods

	// RVA: 0x6D097A0
	public override object Run(object frame) { }

	// RVA: 0x6D0964C
	public object .ctor() { }

}

// Namespace: 
private sealed class AndInt32
{

	// Methods

	// RVA: 0x6D098B4
	public override object Run(object frame) { }

	// RVA: 0x6D09654
	public object .ctor() { }

}

// Namespace: 
private sealed class AndInt64
{

	// Methods

	// RVA: 0x6D099C4
	public override object Run(object frame) { }

	// RVA: 0x6D0965C
	public object .ctor() { }

}

// Namespace: 
private sealed class AndByte
{

	// Methods

	// RVA: 0x6D09AD8
	public override object Run(object frame) { }

	// RVA: 0x6D09664
	public object .ctor() { }

}

// Namespace: 
private sealed class AndUInt16
{

	// Methods

	// RVA: 0x6D09BE8
	public override object Run(object frame) { }

	// RVA: 0x6D0966C
	public object .ctor() { }

}

// Namespace: 
private sealed class AndUInt32
{

	// Methods

	// RVA: 0x6D09CF8
	public override object Run(object frame) { }

	// RVA: 0x6D09674
	public object .ctor() { }

}

// Namespace: 
private sealed class AndUInt64
{

	// Methods

	// RVA: 0x6D09E0C
	public override object Run(object frame) { }

	// RVA: 0x6D0967C
	public object .ctor() { }

}

// Namespace: 
private sealed class AndBoolean
{

	// Methods

	// RVA: 0x6D09F20
	public override object Run(object frame) { }

	// RVA: 0x6D09684
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class AndInstruction
{

	// Fields
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Int32; // 0x10
	private static object s_Int64; // 0x18
	private static object s_Byte; // 0x20
	private static object s_UInt16; // 0x28
	private static object s_UInt32; // 0x30
	private static object s_UInt64; // 0x38
	private static object s_Boolean; // 0x40

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0911C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D09124
	public override object get_ProducedStack() { }

	// RVA: 0x6D0912C
	public override object get_InstructionName() { }

	// RVA: 0x6D09170
	private object .ctor() { }

	// RVA: 0x6D09178
	public static object Create(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class NewArrayInitInstruction
{

	// Fields
	private readonly object _elementType; // 0x8
	private readonly object _elementCount; // 0x10

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0A0A0
	internal object .ctor(object elementType, object elementCount) { }

	// RVA: 0x6D0A0DC
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0A0E4
	public override object get_ProducedStack() { }

	// RVA: 0x6D0A0EC
	public override object get_InstructionName() { }

	// RVA: 0x6D0A130
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class NewArrayInstruction
{

	// Fields
	private readonly object _elementType; // 0x8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0A1F4
	internal object .ctor(object elementType) { }

	// RVA: 0x6D0A220
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0A228
	public override object get_ProducedStack() { }

	// RVA: 0x6D0A230
	public override object get_InstructionName() { }

	// RVA: 0x6D0A274
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class NewArrayBoundsInstruction
{

	// Fields
	private readonly object _elementType; // 0x8
	private readonly object _rank; // 0x10

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0A428
	internal object .ctor(object elementType, object rank) { }

	// RVA: 0x6D0A464
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0A46C
	public override object get_ProducedStack() { }

	// RVA: 0x6D0A474
	public override object get_InstructionName() { }

	// RVA: 0x6D0A4B8
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class GetArrayItemInstruction
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0A600
	private object .ctor() { }

	// RVA: 0x6D0A608
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0A610
	public override object get_ProducedStack() { }

	// RVA: 0x6D0A618
	public override object get_InstructionName() { }

	// RVA: 0x6D0A65C
	public override object Run(object frame) { }

	// RVA: 0x6D0A730
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class SetArrayItemInstruction
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0A790
	private object .ctor() { }

	// RVA: 0x6D0A798
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0A7A0
	public override object get_InstructionName() { }

	// RVA: 0x6D0A7E4
	public override object Run(object frame) { }

	// RVA: 0x6D0A8C4
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ArrayLengthInstruction
{

	// Fields
	public static readonly object Instance; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0A924
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0A92C
	public override object get_ProducedStack() { }

	// RVA: 0x6D0A934
	public override object get_InstructionName() { }

	// RVA: 0x6D0A978
	private object .ctor() { }

	// RVA: 0x6D0A980
	public override object Run(object frame) { }

	// RVA: 0x6D0AA3C
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal static class ConvertHelper
{

	// Methods

	// RVA: 0x6D0A318
	public static object ToInt32NoNull(object val) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal struct RuntimeLabel
{

	// Fields
	public readonly object Index; // 0xFFFFFFFFFFFFFFF8
	public readonly object StackDepth; // 0xFFFFFFFFFFFFFFFC
	public readonly object ContinuationStackDepth; // 0x0

	// Methods

	// RVA: 0x6D0AA9C
	public object .ctor(object index, object continuationStackDepth, object stackDepth) { }

	// RVA: 0x6D0AAB4
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class BranchLabel
{

	// Fields
	private object _targetIndex; // 0x8
	private object _stackDepth; // 0xC
	private object _continuationStackDepth; // 0x10
	private object _forwardBranchFixups; // 0x18
	private object <LabelIndex>k__BackingField; // 0x20

	// Properties
	internal object LabelIndex { get; set; }
	internal object HasRuntimeLabel { get; }
	internal object TargetIndex { get; }

	// Methods

	// RVA: 0x6D0ABBC
	internal object get_LabelIndex() { }

	// RVA: 0x6D0ABC4
	internal object set_LabelIndex(object value) { }

	// RVA: 0x6D0ABCC
	internal object get_HasRuntimeLabel() { }

	// RVA: 0x6D0ABE0
	internal object get_TargetIndex() { }

	// RVA: 0x6D0ABE8
	internal object ToRuntimeLabel() { }

	// RVA: 0x6D0ABF8
	internal object Mark(object instructions) { }

	// RVA: 0x6D0ADA0
	internal object AddBranch(object instructions, object branchIndex) { }

	// RVA: 0x6D0AD6C
	internal object FixupBranch(object instructions, object branchIndex) { }

	// RVA: 0x6D0AF4C
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class CallInstruction
{

	// Properties
	public abstract object ArgumentCount { get; }
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: -1
	public abstract object get_ArgumentCount() { }

	// RVA: 0x6D0AF68
	public override object get_InstructionName() { }

	// RVA: 0x6D0AFAC
	public static object Create(object info) { }

	// RVA: 0x6D0B01C
	public static object Create(object info, object parameters) { }

	// RVA: 0x6D0B22C
	private static object GetArrayAccessor(object info, object argumentCount) { }

	// RVA: 0x6D0B7FC
	public static object ArrayItemSetter1(object array, object index0, object value) { }

	// RVA: 0x6D0B828
	public static object ArrayItemSetter2(object array, object index0, object index1, object value) { }

	// RVA: 0x6D0B858
	public static object ArrayItemSetter3(object array, object index0, object index1, object index2, object value) { }

	// RVA: 0x6D0B88C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0B8CC
	protected static object TryGetLightLambdaTarget(object instance, object lightLambda) { }

	// RVA: 0x6D0B9F4
	protected object InterpretLambdaInvoke(object targetLambda, object args) { }

	// RVA: 0x6D0BA98
	protected object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class MethodInfoCallInstruction
{

	// Fields
	protected readonly object _target; // 0x8
	protected readonly object _argumentCount; // 0x10

	// Properties
	public override object ArgumentCount { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0BAA0
	public override object get_ArgumentCount() { }

	// RVA: 0x6D0B7C0
	internal object .ctor(object target, object argumentCount) { }

	// RVA: 0x6D0BAA8
	public override object get_ProducedStack() { }

	// RVA: 0x6D0BB7C
	public override object Run(object frame) { }

	// RVA: 0x6D0BF6C
	protected object GetArgs(object frame, object first, object skip) { }

	// RVA: 0x6D0C178
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class ByRefMethodInfoCallInstruction
{

	// Fields
	private readonly object _byrefArgs; // 0x18

	// Properties
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0C220
	internal object .ctor(object target, object argumentCount, object byrefArgs) { }

	// RVA: 0x6D0C264
	public override object get_ProducedStack() { }

	// RVA: 0x6D0C338
	public sealed override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class OffsetInstruction
{

	// Fields
	protected object _offset; // 0x8

	// Properties
	public abstract object Cache { get; }

	// Methods

	// RVA: -1
	public abstract object get_Cache() { }

	// RVA: 0x6D0CAAC
	public object Fixup(object offset) { }

	// RVA: 0x6D0CB58
	public override object ToDebugString(object instructionIndex, object cookie, object labelIndexer, object objects) { }

	// RVA: 0x6D0CC3C
	public override object ToString() { }

	// RVA: 0x6D0CD2C
	protected object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class BranchFalseInstruction
{

	// Fields
	private static object s_cache; // 0x0

	// Properties
	public override object Cache { get; }
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D0CD3C
	public override object get_Cache() { }

	// RVA: 0x6D0CDD4
	public override object get_InstructionName() { }

	// RVA: 0x6D0CE18
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0CE20
	public override object Run(object frame) { }

	// RVA: 0x6D0CEDC
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class BranchTrueInstruction
{

	// Fields
	private static object s_cache; // 0x0

	// Properties
	public override object Cache { get; }
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D0CEEC
	public override object get_Cache() { }

	// RVA: 0x6D0CF84
	public override object get_InstructionName() { }

	// RVA: 0x6D0CFC8
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0CFD0
	public override object Run(object frame) { }

	// RVA: 0x6D0D090
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class CoalescingBranchInstruction
{

	// Fields
	private static object s_cache; // 0x0

	// Properties
	public override object Cache { get; }
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0D0A0
	public override object get_Cache() { }

	// RVA: 0x6D0D138
	public override object get_InstructionName() { }

	// RVA: 0x6D0D17C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0D184
	public override object get_ProducedStack() { }

	// RVA: 0x6D0D18C
	public override object Run(object frame) { }

	// RVA: 0x6D0D1DC
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class BranchInstruction
{

	// Fields
	private static object s_caches; // 0x0
	internal readonly object _hasResult; // 0xC
	internal readonly object _hasValue; // 0xD

	// Properties
	public override object Cache { get; }
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0D1EC
	public override object get_Cache() { }

	// RVA: 0x6D0D498
	internal object .ctor() { }

	// RVA: 0x6D0D4C8
	public object .ctor(object hasResult, object hasValue) { }

	// RVA: 0x6D0D50C
	public override object get_InstructionName() { }

	// RVA: 0x6D0D550
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0D558
	public override object get_ProducedStack() { }

	// RVA: 0x6D0D560
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class IndexedBranchInstruction
{

	// Fields
	internal readonly object _labelIndex; // 0x8

	// Methods

	// RVA: 0x6D0D568
	public object .ctor(object labelIndex) { }

	// RVA: 0x6D0D594
	public object GetLabel(object frame) { }

	// RVA: 0x6D0D600
	public override object ToDebugString(object instructionIndex, object cookie, object labelIndexer, object objects) { }

	// RVA: 0x6D0D700
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class GotoInstruction
{

	// Fields
	private static readonly object s_cache; // 0x0
	private readonly object _hasResult; // 0xC
	private readonly object _hasValue; // 0xD
	private readonly object _labelTargetGetsValue; // 0xE

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0D7A8
	public override object get_InstructionName() { }

	// RVA: 0x6D0D7EC
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0D7F4
	public override object get_ProducedStack() { }

	// RVA: 0x6D0D7FC
	private object .ctor(object targetIndex, object hasResult, object hasValue, object labelTargetGetsValue) { }

	// RVA: 0x6D0D850
	internal static object Create(object labelIndex, object hasResult, object hasValue, object labelTargetGetsValue) { }

	// RVA: 0x6D0D9C0
	public override object Run(object frame) { }

	// RVA: 0x6D0DAC8
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterTryCatchFinallyInstruction
{

	// Fields
	private readonly object _hasFinally; // 0xC
	private object _tryHandler; // 0x10

	// Properties
	internal object Handler { get; }
	public override object ProducedContinuations { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0DB3C
	internal object SetTryHandler(object tryHandler) { }

	// RVA: 0x6D0DB44
	internal object get_Handler() { }

	// RVA: 0x6D0DB4C
	public override object get_ProducedContinuations() { }

	// RVA: 0x6D0DB54
	private object .ctor(object targetIndex, object hasFinally) { }

	// RVA: 0x6D0DB90
	internal static object CreateTryFinally(object labelIndex) { }

	// RVA: 0x6D0DC00
	internal static object CreateTryCatch() { }

	// RVA: 0x6D0DC64
	public override object Run(object frame) { }

	// RVA: 0x6D0E404
	public override object get_InstructionName() { }

	// RVA: 0x6D0E474
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterTryFaultInstruction
{

	// Fields
	private object _tryHandler; // 0x10

	// Properties
	public override object InstructionName { get; }
	public override object ProducedContinuations { get; }
	internal object Handler { get; }

	// Methods

	// RVA: 0x6D0E520
	internal object .ctor(object targetIndex) { }

	// RVA: 0x6D0E54C
	public override object get_InstructionName() { }

	// RVA: 0x6D0E590
	public override object get_ProducedContinuations() { }

	// RVA: 0x6D0E598
	internal object get_Handler() { }

	// RVA: 0x6D0E5A0
	internal object SetTryHandler(object tryHandler) { }

	// RVA: 0x6D0E5A8
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterFinallyInstruction
{

	// Fields
	private static readonly object s_cache; // 0x0

	// Properties
	public override object InstructionName { get; }
	public override object ProducedStack { get; }
	public override object ConsumedContinuations { get; }

	// Methods

	// RVA: 0x6D0E9AC
	private object .ctor(object labelIndex) { }

	// RVA: 0x6D0E9D8
	public override object get_InstructionName() { }

	// RVA: 0x6D0EA1C
	public override object get_ProducedStack() { }

	// RVA: 0x6D0EA24
	public override object get_ConsumedContinuations() { }

	// RVA: 0x6D0EA2C
	internal static object Create(object labelIndex) { }

	// RVA: 0x6D0EB54
	public override object Run(object frame) { }

	// RVA: 0x6D0EC04
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LeaveFinallyInstruction
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0EC78
	private object .ctor() { }

	// RVA: 0x6D0EC80
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0EC88
	public override object get_InstructionName() { }

	// RVA: 0x6D0ECCC
	public override object Run(object frame) { }

	// RVA: 0x6D0ED2C
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterFaultInstruction
{

	// Fields
	private static readonly object s_cache; // 0x0

	// Properties
	public override object InstructionName { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0ED8C
	private object .ctor(object labelIndex) { }

	// RVA: 0x6D0EDB8
	public override object get_InstructionName() { }

	// RVA: 0x6D0EDFC
	public override object get_ProducedStack() { }

	// RVA: 0x6D0EE04
	internal static object Create(object labelIndex) { }

	// RVA: 0x6D0EF2C
	public override object Run(object frame) { }

	// RVA: 0x6D0EFC8
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LeaveFaultInstruction
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object ConsumedContinuations { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0F03C
	private object .ctor() { }

	// RVA: 0x6D0F044
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0F04C
	public override object get_ConsumedContinuations() { }

	// RVA: 0x6D0F054
	public override object get_InstructionName() { }

	// RVA: 0x6D0F098
	public override object Run(object frame) { }

	// RVA: 0x6D0F0C8
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterExceptionFilterInstruction
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Properties
	public override object InstructionName { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0F128
	private object .ctor() { }

	// RVA: 0x6D0F130
	public override object get_InstructionName() { }

	// RVA: 0x6D0F174
	public override object get_ProducedStack() { }

	// RVA: 0x6D0F17C
	public override object Run(object frame) { }

	// RVA: 0x6D0F184
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LeaveExceptionFilterInstruction
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D0F1E4
	private object .ctor() { }

	// RVA: 0x6D0F1EC
	public override object get_InstructionName() { }

	// RVA: 0x6D0F230
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0F238
	public override object Run(object frame) { }

	// RVA: 0x6D0F240
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class EnterExceptionHandlerInstruction
{

	// Fields
	internal static readonly object Void; // 0x0
	internal static readonly object NonVoid; // 0x8
	private readonly object _hasValue; // 0x8

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0F2A0
	private object .ctor(object hasValue) { }

	// RVA: 0x6D0F2CC
	public override object get_InstructionName() { }

	// RVA: 0x6D0F310
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0F318
	public override object get_ProducedStack() { }

	// RVA: 0x6D0F320
	public override object Run(object frame) { }

	// RVA: 0x6D0F328
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LeaveExceptionHandlerInstruction
{

	// Fields
	private static readonly object s_cache; // 0x0
	private readonly object _hasValue; // 0xC

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D0F3B0
	private object .ctor(object labelIndex, object hasValue) { }

	// RVA: 0x6D0F3EC
	public override object get_InstructionName() { }

	// RVA: 0x6D0F430
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0F438
	public override object get_ProducedStack() { }

	// RVA: 0x6D0F440
	internal static object Create(object labelIndex, object hasValue) { }

	// RVA: 0x6D0F570
	public override object Run(object frame) { }

	// RVA: 0x6D0F5E0
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ThrowInstruction
{

	// Fields
	internal static readonly object Throw; // 0x0
	internal static readonly object VoidThrow; // 0x8
	internal static readonly object Rethrow; // 0x10
	internal static readonly object VoidRethrow; // 0x18
	private readonly object _hasResult; // 0x8
	private readonly object _rethrow; // 0x9

	// Properties
	public override object InstructionName { get; }
	public override object ProducedStack { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D0F654
	private object .ctor(object hasResult, object isRethrow) { }

	// RVA: 0x6D0F690
	public override object get_InstructionName() { }

	// RVA: 0x6D0F6D4
	public override object get_ProducedStack() { }

	// RVA: 0x6D0F6DC
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0F6E4
	public override object Run(object frame) { }

	// RVA: 0x6D0F824
	private static object WrapThrownObject(object thrown) { }

	// RVA: 0x6D0F8CC
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class IntSwitchInstruction<T0>
{

	// Fields
	private readonly object _cases; // 0x0

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object cases) { }

	// RVA: -1
	public override object get_InstructionName() { }

	// RVA: -1
	public override object get_ConsumedStack() { }

	// RVA: -1
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StringSwitchInstruction
{

	// Fields
	private readonly object _cases; // 0x8
	private readonly object _nullCase; // 0x10

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D0F99C
	internal object .ctor(object cases, object nullCase) { }

	// RVA: 0x6D0F9D4
	public override object get_InstructionName() { }

	// RVA: 0x6D0FA18
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0FA20
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class DecrementInt16
{

	// Methods

	// RVA: 0x6D10028
	public override object Run(object frame) { }

	// RVA: 0x6D0FFE8
	public object .ctor() { }

}

// Namespace: 
private sealed class DecrementInt32
{

	// Methods

	// RVA: 0x6D100E8
	public override object Run(object frame) { }

	// RVA: 0x6D0FFF0
	public object .ctor() { }

}

// Namespace: 
private sealed class DecrementInt64
{

	// Methods

	// RVA: 0x6D101A4
	public override object Run(object frame) { }

	// RVA: 0x6D0FFF8
	public object .ctor() { }

}

// Namespace: 
private sealed class DecrementUInt16
{

	// Methods

	// RVA: 0x6D10268
	public override object Run(object frame) { }

	// RVA: 0x6D10000
	public object .ctor() { }

}

// Namespace: 
private sealed class DecrementUInt32
{

	// Methods

	// RVA: 0x6D10328
	public override object Run(object frame) { }

	// RVA: 0x6D10008
	public object .ctor() { }

}

// Namespace: 
private sealed class DecrementUInt64
{

	// Methods

	// RVA: 0x6D103EC
	public override object Run(object frame) { }

	// RVA: 0x6D10010
	public object .ctor() { }

}

// Namespace: 
private sealed class DecrementSingle
{

	// Methods

	// RVA: 0x6D104B0
	public override object Run(object frame) { }

	// RVA: 0x6D10018
	public object .ctor() { }

}

// Namespace: 
private sealed class DecrementDouble
{

	// Methods

	// RVA: 0x6D10578
	public override object Run(object frame) { }

	// RVA: 0x6D10020
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class DecrementInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28
	private static object s_Single; // 0x30
	private static object s_Double; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D0FB28
	public override object get_ConsumedStack() { }

	// RVA: 0x6D0FB30
	public override object get_ProducedStack() { }

	// RVA: 0x6D0FB38
	public override object get_InstructionName() { }

	// RVA: 0x6D0FB7C
	private object .ctor() { }

	// RVA: 0x6D0FB84
	public static object Create(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class DefaultValueInstruction
{

	// Fields
	private readonly object _type; // 0x8

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D10640
	internal object .ctor(object type) { }

	// RVA: 0x6D1066C
	public override object get_ProducedStack() { }

	// RVA: 0x6D10674
	public override object get_InstructionName() { }

	// RVA: 0x6D106B8
	public override object Run(object frame) { }

	// RVA: 0x6D10704
	public override object ToString() { }

}

// Namespace: 
private sealed class DivInt16
{

	// Methods

	// RVA: 0x6D10CA8
	public override object Run(object frame) { }

	// RVA: 0x6D10C68
	public object .ctor() { }

}

// Namespace: 
private sealed class DivInt32
{

	// Methods

	// RVA: 0x6D10E0C
	public override object Run(object frame) { }

	// RVA: 0x6D10C70
	public object .ctor() { }

}

// Namespace: 
private sealed class DivInt64
{

	// Methods

	// RVA: 0x6D10F60
	public override object Run(object frame) { }

	// RVA: 0x6D10C78
	public object .ctor() { }

}

// Namespace: 
private sealed class DivUInt16
{

	// Methods

	// RVA: 0x6D110C4
	public override object Run(object frame) { }

	// RVA: 0x6D10C80
	public object .ctor() { }

}

// Namespace: 
private sealed class DivUInt32
{

	// Methods

	// RVA: 0x6D11228
	public override object Run(object frame) { }

	// RVA: 0x6D10C88
	public object .ctor() { }

}

// Namespace: 
private sealed class DivUInt64
{

	// Methods

	// RVA: 0x6D1138C
	public override object Run(object frame) { }

	// RVA: 0x6D10C90
	public object .ctor() { }

}

// Namespace: 
private sealed class DivSingle
{

	// Methods

	// RVA: 0x6D114F0
	public override object Run(object frame) { }

	// RVA: 0x6D10C98
	public object .ctor() { }

}

// Namespace: 
private sealed class DivDouble
{

	// Methods

	// RVA: 0x6D1165C
	public override object Run(object frame) { }

	// RVA: 0x6D10CA0
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class DivInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28
	private static object s_Single; // 0x30
	private static object s_Double; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D107A8
	public override object get_ConsumedStack() { }

	// RVA: 0x6D107B0
	public override object get_ProducedStack() { }

	// RVA: 0x6D107B8
	public override object get_InstructionName() { }

	// RVA: 0x6D107FC
	private object .ctor() { }

	// RVA: 0x6D10804
	public static object Create(object type) { }

}

// Namespace: 
private sealed class EqualBoolean
{

	// Methods

	// RVA: 0x6D12360
	public override object Run(object frame) { }

	// RVA: 0x6D122F8
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualSByte
{

	// Methods

	// RVA: 0x6D12454
	public override object Run(object frame) { }

	// RVA: 0x6D12300
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualInt16
{

	// Methods

	// RVA: 0x6D12548
	public override object Run(object frame) { }

	// RVA: 0x6D12308
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualChar
{

	// Methods

	// RVA: 0x6D1263C
	public override object Run(object frame) { }

	// RVA: 0x6D12310
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualInt32
{

	// Methods

	// RVA: 0x6D12730
	public override object Run(object frame) { }

	// RVA: 0x6D12318
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualInt64
{

	// Methods

	// RVA: 0x6D12824
	public override object Run(object frame) { }

	// RVA: 0x6D12320
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualByte
{

	// Methods

	// RVA: 0x6D12918
	public override object Run(object frame) { }

	// RVA: 0x6D12328
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualUInt16
{

	// Methods

	// RVA: 0x6D12A0C
	public override object Run(object frame) { }

	// RVA: 0x6D12330
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualUInt32
{

	// Methods

	// RVA: 0x6D12B00
	public override object Run(object frame) { }

	// RVA: 0x6D12338
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualUInt64
{

	// Methods

	// RVA: 0x6D12BF4
	public override object Run(object frame) { }

	// RVA: 0x6D12340
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualSingle
{

	// Methods

	// RVA: 0x6D12CE8
	public override object Run(object frame) { }

	// RVA: 0x6D12348
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualDouble
{

	// Methods

	// RVA: 0x6D12DE4
	public override object Run(object frame) { }

	// RVA: 0x6D12350
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualReference
{

	// Methods

	// RVA: 0x6D12EE0
	public override object Run(object frame) { }

	// RVA: 0x6D12358
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualBooleanLiftedToNull
{

	// Methods

	// RVA: 0x6D12F40
	public override object Run(object frame) { }

	// RVA: 0x6D12298
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualSByteLiftedToNull
{

	// Methods

	// RVA: 0x6D1304C
	public override object Run(object frame) { }

	// RVA: 0x6D122A0
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualInt16LiftedToNull
{

	// Methods

	// RVA: 0x6D13158
	public override object Run(object frame) { }

	// RVA: 0x6D122A8
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualCharLiftedToNull
{

	// Methods

	// RVA: 0x6D13264
	public override object Run(object frame) { }

	// RVA: 0x6D122B0
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualInt32LiftedToNull
{

	// Methods

	// RVA: 0x6D13370
	public override object Run(object frame) { }

	// RVA: 0x6D122B8
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualInt64LiftedToNull
{

	// Methods

	// RVA: 0x6D1347C
	public override object Run(object frame) { }

	// RVA: 0x6D122C0
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualByteLiftedToNull
{

	// Methods

	// RVA: 0x6D13588
	public override object Run(object frame) { }

	// RVA: 0x6D122C8
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualUInt16LiftedToNull
{

	// Methods

	// RVA: 0x6D13694
	public override object Run(object frame) { }

	// RVA: 0x6D122D0
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualUInt32LiftedToNull
{

	// Methods

	// RVA: 0x6D137A0
	public override object Run(object frame) { }

	// RVA: 0x6D122D8
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualUInt64LiftedToNull
{

	// Methods

	// RVA: 0x6D138AC
	public override object Run(object frame) { }

	// RVA: 0x6D122E0
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualSingleLiftedToNull
{

	// Methods

	// RVA: 0x6D139B8
	public override object Run(object frame) { }

	// RVA: 0x6D122E8
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualDoubleLiftedToNull
{

	// Methods

	// RVA: 0x6D13AD0
	public override object Run(object frame) { }

	// RVA: 0x6D122F0
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class EqualInstruction
{

	// Fields
	private static object s_reference; // 0x0
	private static object s_Boolean; // 0x8
	private static object s_SByte; // 0x10
	private static object s_Int16; // 0x18
	private static object s_Char; // 0x20
	private static object s_Int32; // 0x28
	private static object s_Int64; // 0x30
	private static object s_Byte; // 0x38
	private static object s_UInt16; // 0x40
	private static object s_UInt32; // 0x48
	private static object s_UInt64; // 0x50
	private static object s_Single; // 0x58
	private static object s_Double; // 0x60
	private static object s_BooleanLiftedToNull; // 0x68
	private static object s_SByteLiftedToNull; // 0x70
	private static object s_Int16LiftedToNull; // 0x78
	private static object s_CharLiftedToNull; // 0x80
	private static object s_Int32LiftedToNull; // 0x88
	private static object s_Int64LiftedToNull; // 0x90
	private static object s_ByteLiftedToNull; // 0x98
	private static object s_UInt16LiftedToNull; // 0xA0
	private static object s_UInt32LiftedToNull; // 0xA8
	private static object s_UInt64LiftedToNull; // 0xB0
	private static object s_SingleLiftedToNull; // 0xB8
	private static object s_DoubleLiftedToNull; // 0xC0

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D117C8
	public override object get_ConsumedStack() { }

	// RVA: 0x6D117D0
	public override object get_ProducedStack() { }

	// RVA: 0x6D117D8
	public override object get_InstructionName() { }

	// RVA: 0x6D1181C
	private object .ctor() { }

	// RVA: 0x6D11824
	public static object Create(object type, object liftedToNull) { }

}

// Namespace: 
private sealed class ExclusiveOrSByte
{

	// Methods

	// RVA: 0x6D14130
	public override object Run(object frame) { }

	// RVA: 0x6D14110
	public object .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrInt16
{

	// Methods

	// RVA: 0x6D14244
	public override object Run(object frame) { }

	// RVA: 0x6D14118
	public object .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrInt32
{

	// Methods

	// RVA: 0x6D14358
	public override object Run(object frame) { }

	// RVA: 0x6D14120
	public object .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrInt64
{

	// Methods

	// RVA: 0x6D14468
	public override object Run(object frame) { }

	// RVA: 0x6D14128
	public object .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrByte
{

	// Methods

	// RVA: 0x6D1457C
	public override object Run(object frame) { }

	// RVA: 0x6D14838
	public object .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrUInt16
{

	// Methods

	// RVA: 0x6D14840
	public override object Run(object frame) { }

	// RVA: 0x6D14A34
	public object .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrUInt32
{

	// Methods

	// RVA: 0x6D14A3C
	public override object Run(object frame) { }

	// RVA: 0x6D14BC4
	public object .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrUInt64
{

	// Methods

	// RVA: 0x6D14BCC
	public override object Run(object frame) { }

	// RVA: 0x6D14D54
	public object .ctor() { }

}

// Namespace: 
private sealed class ExclusiveOrBoolean
{

	// Methods

	// RVA: 0x6D14D5C
	public override object Run(object frame) { }

	// RVA: 0x6D14F70
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class ExclusiveOrInstruction
{

	// Fields
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Int32; // 0x10
	private static object s_Int64; // 0x18
	private static object s_Byte; // 0x20
	private static object s_UInt16; // 0x28
	private static object s_UInt32; // 0x30
	private static object s_UInt64; // 0x38
	private static object s_Boolean; // 0x40

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D13BE8
	public override object get_ConsumedStack() { }

	// RVA: 0x6D13BF0
	public override object get_ProducedStack() { }

	// RVA: 0x6D13BF8
	public override object get_InstructionName() { }

	// RVA: 0x6D13C3C
	private object .ctor() { }

	// RVA: 0x6D13C44
	public static object Create(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class FieldInstruction
{

	// Fields
	protected readonly object _field; // 0x8

	// Methods

	// RVA: 0x6D14F78
	public object .ctor(object field) { }

	// RVA: 0x6D14FAC
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadStaticFieldInstruction
{

	// Properties
	public override object InstructionName { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D15080
	public object .ctor(object field) { }

	// RVA: 0x6D150AC
	public override object get_InstructionName() { }

	// RVA: 0x6D150F0
	public override object get_ProducedStack() { }

	// RVA: 0x6D150F8
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadFieldInstruction
{

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D151C4
	public object .ctor(object field) { }

	// RVA: 0x6D151F0
	public override object get_InstructionName() { }

	// RVA: 0x6D15234
	public override object get_ConsumedStack() { }

	// RVA: 0x6D1523C
	public override object get_ProducedStack() { }

	// RVA: 0x6D15244
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StoreFieldInstruction
{

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D15364
	public object .ctor(object field) { }

	// RVA: 0x6D15390
	public override object get_InstructionName() { }

	// RVA: 0x6D153D4
	public override object get_ConsumedStack() { }

	// RVA: 0x6D153DC
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StoreStaticFieldInstruction
{

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D1546C
	public object .ctor(object field) { }

	// RVA: 0x6D15498
	public override object get_InstructionName() { }

	// RVA: 0x6D154DC
	public override object get_ConsumedStack() { }

	// RVA: 0x6D154E4
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanSByte
{

	// Methods

	// RVA: 0x6D161B0
	public object .ctor(object nullValue) { }

	// RVA: 0x6D16394
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanInt16
{

	// Methods

	// RVA: 0x6D161DC
	public object .ctor(object nullValue) { }

	// RVA: 0x6D16500
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanChar
{

	// Methods

	// RVA: 0x6D16208
	public object .ctor(object nullValue) { }

	// RVA: 0x6D1666C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanInt32
{

	// Methods

	// RVA: 0x6D16234
	public object .ctor(object nullValue) { }

	// RVA: 0x6D167D8
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanInt64
{

	// Methods

	// RVA: 0x6D16260
	public object .ctor(object nullValue) { }

	// RVA: 0x6D16944
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanByte
{

	// Methods

	// RVA: 0x6D1628C
	public object .ctor(object nullValue) { }

	// RVA: 0x6D16AB0
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanUInt16
{

	// Methods

	// RVA: 0x6D162B8
	public object .ctor(object nullValue) { }

	// RVA: 0x6D16C1C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanUInt32
{

	// Methods

	// RVA: 0x6D162E4
	public object .ctor(object nullValue) { }

	// RVA: 0x6D16D88
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanUInt64
{

	// Methods

	// RVA: 0x6D16310
	public object .ctor(object nullValue) { }

	// RVA: 0x6D16EF4
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanSingle
{

	// Methods

	// RVA: 0x6D1633C
	public object .ctor(object nullValue) { }

	// RVA: 0x6D17060
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanDouble
{

	// Methods

	// RVA: 0x6D16368
	public object .ctor(object nullValue) { }

	// RVA: 0x6D171C0
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class GreaterThanInstruction
{

	// Fields
	private readonly object _nullValue; // 0x8
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Char; // 0x10
	private static object s_Int32; // 0x18
	private static object s_Int64; // 0x20
	private static object s_Byte; // 0x28
	private static object s_UInt16; // 0x30
	private static object s_UInt32; // 0x38
	private static object s_UInt64; // 0x40
	private static object s_Single; // 0x48
	private static object s_Double; // 0x50
	private static object s_liftedToNullSByte; // 0x58
	private static object s_liftedToNullInt16; // 0x60
	private static object s_liftedToNullChar; // 0x68
	private static object s_liftedToNullInt32; // 0x70
	private static object s_liftedToNullInt64; // 0x78
	private static object s_liftedToNullByte; // 0x80
	private static object s_liftedToNullUInt16; // 0x88
	private static object s_liftedToNullUInt32; // 0x90
	private static object s_liftedToNullUInt64; // 0x98
	private static object s_liftedToNullSingle; // 0xA0
	private static object s_liftedToNullDouble; // 0xA8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D15554
	public override object get_ConsumedStack() { }

	// RVA: 0x6D1555C
	public override object get_ProducedStack() { }

	// RVA: 0x6D15564
	public override object get_InstructionName() { }

	// RVA: 0x6D155A8
	private object .ctor(object nullValue) { }

	// RVA: 0x6D155D4
	public static object Create(object type, object liftedToNull) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualSByte
{

	// Methods

	// RVA: 0x6D17F7C
	public object .ctor(object nullValue) { }

	// RVA: 0x6D18160
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualInt16
{

	// Methods

	// RVA: 0x6D17FA8
	public object .ctor(object nullValue) { }

	// RVA: 0x6D182CC
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualChar
{

	// Methods

	// RVA: 0x6D17FD4
	public object .ctor(object nullValue) { }

	// RVA: 0x6D18438
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualInt32
{

	// Methods

	// RVA: 0x6D18000
	public object .ctor(object nullValue) { }

	// RVA: 0x6D185A4
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualInt64
{

	// Methods

	// RVA: 0x6D1802C
	public object .ctor(object nullValue) { }

	// RVA: 0x6D18710
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualByte
{

	// Methods

	// RVA: 0x6D18058
	public object .ctor(object nullValue) { }

	// RVA: 0x6D1887C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualUInt16
{

	// Methods

	// RVA: 0x6D18084
	public object .ctor(object nullValue) { }

	// RVA: 0x6D189E8
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualUInt32
{

	// Methods

	// RVA: 0x6D180B0
	public object .ctor(object nullValue) { }

	// RVA: 0x6D18B54
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualUInt64
{

	// Methods

	// RVA: 0x6D180DC
	public object .ctor(object nullValue) { }

	// RVA: 0x6D18CC0
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualSingle
{

	// Methods

	// RVA: 0x6D18108
	public object .ctor(object nullValue) { }

	// RVA: 0x6D18E2C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GreaterThanOrEqualDouble
{

	// Methods

	// RVA: 0x6D18134
	public object .ctor(object nullValue) { }

	// RVA: 0x6D18F8C
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class GreaterThanOrEqualInstruction
{

	// Fields
	private readonly object _nullValue; // 0x8
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Char; // 0x10
	private static object s_Int32; // 0x18
	private static object s_Int64; // 0x20
	private static object s_Byte; // 0x28
	private static object s_UInt16; // 0x30
	private static object s_UInt32; // 0x38
	private static object s_UInt64; // 0x40
	private static object s_Single; // 0x48
	private static object s_Double; // 0x50
	private static object s_liftedToNullSByte; // 0x58
	private static object s_liftedToNullInt16; // 0x60
	private static object s_liftedToNullChar; // 0x68
	private static object s_liftedToNullInt32; // 0x70
	private static object s_liftedToNullInt64; // 0x78
	private static object s_liftedToNullByte; // 0x80
	private static object s_liftedToNullUInt16; // 0x88
	private static object s_liftedToNullUInt32; // 0x90
	private static object s_liftedToNullUInt64; // 0x98
	private static object s_liftedToNullSingle; // 0xA0
	private static object s_liftedToNullDouble; // 0xA8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D17320
	public override object get_ConsumedStack() { }

	// RVA: 0x6D17328
	public override object get_ProducedStack() { }

	// RVA: 0x6D17330
	public override object get_InstructionName() { }

	// RVA: 0x6D17374
	private object .ctor(object nullValue) { }

	// RVA: 0x6D173A0
	public static object Create(object type, object liftedToNull) { }

}

// Namespace: 
private sealed class IncrementInt16
{

	// Methods

	// RVA: 0x6D195EC
	public override object Run(object frame) { }

	// RVA: 0x6D195AC
	public object .ctor() { }

}

// Namespace: 
private sealed class IncrementInt32
{

	// Methods

	// RVA: 0x6D1978C
	public override object Run(object frame) { }

	// RVA: 0x6D195B4
	public object .ctor() { }

}

// Namespace: 
private sealed class IncrementInt64
{

	// Methods

	// RVA: 0x6D198E4
	public override object Run(object frame) { }

	// RVA: 0x6D195BC
	public object .ctor() { }

}

// Namespace: 
private sealed class IncrementUInt16
{

	// Methods

	// RVA: 0x6D19A20
	public override object Run(object frame) { }

	// RVA: 0x6D195C4
	public object .ctor() { }

}

// Namespace: 
private sealed class IncrementUInt32
{

	// Methods

	// RVA: 0x6D19AF0
	public override object Run(object frame) { }

	// RVA: 0x6D195CC
	public object .ctor() { }

}

// Namespace: 
private sealed class IncrementUInt64
{

	// Methods

	// RVA: 0x6D19C2C
	public override object Run(object frame) { }

	// RVA: 0x6D195D4
	public object .ctor() { }

}

// Namespace: 
private sealed class IncrementSingle
{

	// Methods

	// RVA: 0x6D19D68
	public override object Run(object frame) { }

	// RVA: 0x6D195DC
	public object .ctor() { }

}

// Namespace: 
private sealed class IncrementDouble
{

	// Methods

	// RVA: 0x6D19EA8
	public override object Run(object frame) { }

	// RVA: 0x6D195E4
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class IncrementInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28
	private static object s_Single; // 0x30
	private static object s_Double; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D190EC
	public override object get_ConsumedStack() { }

	// RVA: 0x6D190F4
	public override object get_ProducedStack() { }

	// RVA: 0x6D190FC
	public override object get_InstructionName() { }

	// RVA: 0x6D19140
	private object .ctor() { }

	// RVA: 0x6D19148
	public static object Create(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class Instruction
{

	// Properties
	public virtual object ConsumedStack { get; }
	public virtual object ProducedStack { get; }
	public virtual object ConsumedContinuations { get; }
	public virtual object ProducedContinuations { get; }
	public object StackBalance { get; }
	public object ContinuationsBalance { get; }
	public abstract object InstructionName { get; }

	// Methods

	// RVA: 0x6D19FE8
	public virtual object get_ConsumedStack() { }

	// RVA: 0x6D19FF0
	public virtual object get_ProducedStack() { }

	// RVA: 0x6D19FF8
	public virtual object get_ConsumedContinuations() { }

	// RVA: 0x6D1A000
	public virtual object get_ProducedContinuations() { }

	// RVA: 0x6D1A008
	public object get_StackBalance() { }

	// RVA: 0x6D1A074
	public object get_ContinuationsBalance() { }

	// RVA: -1
	public abstract object Run(object frame) { }

	// RVA: -1
	public abstract object get_InstructionName() { }

	// RVA: 0x6D1A0E0
	public override object ToString() { }

	// RVA: 0x6D1A150
	public virtual object ToDebugString(object instructionIndex, object cookie, object labelIndexer, object objects) { }

	// RVA: 0x6D15348
	protected static object NullCheck(object o) { }

	// RVA: 0x6D14FA4
	protected object .ctor() { }

}

// Namespace: 
internal sealed class DebugView
{

	// Fields
	private readonly object _array; // 0x8

	// Methods

	// RVA: 0x6D1A1EC
	public object .ctor(object array) { }

	// RVA: 0x6D1A2A8
	public object GetInstructionViews(object includeDebugCookies) { }

	// RVA: 0x6D1AB64
	private object <GetInstructionViews>b__4_0(object index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal struct InstructionArray
{

	// Fields
	internal readonly object MaxStackDepth; // 0xFFFFFFFFFFFFFFF8
	internal readonly object MaxContinuationDepth; // 0xFFFFFFFFFFFFFFFC
	internal readonly object Instructions; // 0x0
	internal readonly object Objects; // 0x8
	internal readonly object Labels; // 0x10
	internal readonly object DebugCookies; // 0x18

	// Methods

	// RVA: 0x6D1A1CC
	internal object .ctor(object maxStackDepth, object maxContinuationDepth, object instructions, object objects, object labels, object debugCookies) { }

}

// Namespace: 
internal struct InstructionView
{

	// Fields
	private readonly object _index; // 0xFFFFFFFFFFFFFFF8
	private readonly object _stackDepth; // 0xFFFFFFFFFFFFFFFC
	private readonly object _continuationsDepth; // 0x0
	private readonly object _name; // 0x8
	private readonly object _instruction; // 0x10

	// Methods

	// RVA: 0x6D21A48
	internal object GetValue() { }

	// RVA: 0x6D219FC
	public object .ctor(object instruction, object name, object index, object stackDepth, object continuationsDepth) { }

}

// Namespace: 
internal sealed class DebugView
{

	// Methods

	// RVA: 0x6D1A34C
	internal static object GetInstructionViews(object instructions, object objects, object labelIndexer, object debugCookies) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class InstructionList
{

	// Fields
	private readonly object _instructions; // 0x8
	private object _objects; // 0x10
	private object _currentStackDepth; // 0x18
	private object _maxStackDepth; // 0x1C
	private object _currentContinuationsDepth; // 0x20
	private object _maxContinuationDepth; // 0x24
	private object _runtimeLabelCount; // 0x28
	private object _labels; // 0x30
	private object _debugCookies; // 0x38
	private static object s_null; // 0x0
	private static object s_true; // 0x8
	private static object s_false; // 0x10
	private static object s_Ints; // 0x18
	private static object s_loadObjectCached; // 0x20
	private static object s_loadLocal; // 0x28
	private static object s_loadLocalBoxed; // 0x30
	private static object s_loadLocalFromClosure; // 0x38
	private static object s_loadLocalFromClosureBoxed; // 0x40
	private static object s_assignLocal; // 0x48
	private static object s_storeLocal; // 0x50
	private static object s_assignLocalBoxed; // 0x58
	private static object s_storeLocalBoxed; // 0x60
	private static object s_assignLocalToClosure; // 0x68
	private static readonly object s_loadFields; // 0x70
	private static readonly object s_emptyRuntimeLabels; // 0x78

	// Properties
	public object Count { get; }
	public object CurrentStackDepth { get; }
	public object CurrentContinuationsDepth { get; }

	// Methods

	// RVA: 0x6D1ABA4
	public object Emit(object instruction) { }

	// RVA: 0x6D1ACB8
	private object UpdateStackDepth(object instruction) { }

	// RVA: 0x6D1ADC8
	public object UnEmit() { }

	// RVA: 0x6D1AF48
	public object get_Count() { }

	// RVA: 0x6D1AF9C
	public object get_CurrentStackDepth() { }

	// RVA: 0x6D1AFA4
	public object get_CurrentContinuationsDepth() { }

	// RVA: 0x6D1AFAC
	internal object GetInstruction(object index) { }

	// RVA: 0x6D1B018
	public object ToArray() { }

	// RVA: 0x6D1B3E4
	public object EmitLoad(object value) { }

	// RVA: 0x6D1BA80
	public object EmitLoad(object value) { }

	// RVA: 0x6D1B3EC
	public object EmitLoad(object value, object type) { }

	// RVA: 0x6D1BC34
	public object EmitDup() { }

	// RVA: 0x6D1BCA0
	public object EmitPop() { }

	// RVA: 0x6D1BD0C
	internal object SwitchToBoxed(object index, object instructionIndex) { }

	// RVA: 0x6D1BE7C
	public object EmitLoadLocal(object index) { }

	// RVA: 0x6D1C0B4
	public object EmitLoadLocalBoxed(object index) { }

	// RVA: 0x6D1C124
	internal static object LoadLocalBoxed(object index) { }

	// RVA: 0x6D1C374
	public object EmitLoadLocalFromClosure(object index) { }

	// RVA: 0x6D1C5AC
	public object EmitLoadLocalFromClosureBoxed(object index) { }

	// RVA: 0x6D1C7E4
	public object EmitAssignLocal(object index) { }

	// RVA: 0x6D1CA1C
	public object EmitStoreLocal(object index) { }

	// RVA: 0x6D1CC54
	public object EmitAssignLocalBoxed(object index) { }

	// RVA: 0x6D1CCC4
	internal static object AssignLocalBoxed(object index) { }

	// RVA: 0x6D1CF14
	public object EmitStoreLocalBoxed(object index) { }

	// RVA: 0x6D1CF84
	internal static object StoreLocalBoxed(object index) { }

	// RVA: 0x6D1D1D4
	public object EmitAssignLocalToClosure(object index) { }

	// RVA: 0x6D1D40C
	public object EmitStoreLocalToClosure(object index) { }

	// RVA: 0x6D1D47C
	public object EmitInitializeLocal(object index, object type) { }

	// RVA: 0x6D1D634
	internal object EmitInitializeParameter(object index) { }

	// RVA: 0x6D1D700
	internal static object Parameter(object index) { }

	// RVA: 0x6D1D768
	internal static object ParameterBox(object index) { }

	// RVA: 0x6D1D5CC
	internal static object InitReference(object index) { }

	// RVA: 0x6D1D7D0
	internal static object InitImmutableRefBox(object index) { }

	// RVA: 0x6D1D838
	public object EmitNewRuntimeVariables(object count) { }

	// RVA: 0x6D1D8A8
	public object EmitGetArrayItem() { }

	// RVA: 0x6D1D914
	public object EmitSetArrayItem() { }

	// RVA: 0x6D1D980
	public object EmitNewArray(object elementType) { }

	// RVA: 0x6D1D9F0
	public object EmitNewArrayBounds(object elementType, object rank) { }

	// RVA: 0x6D1DA70
	public object EmitNewArrayInit(object elementType, object elementCount) { }

	// RVA: 0x6D1DAF0
	public object EmitAdd(object type, object checked) { }

	// RVA: 0x6D1DB3C
	public object EmitSub(object type, object checked) { }

	// RVA: 0x6D1DB88
	public object EmitMul(object type, object checked) { }

	// RVA: 0x6D1DBD4
	public object EmitDiv(object type) { }

	// RVA: 0x6D1DC04
	public object EmitModulo(object type) { }

	// RVA: 0x6D1DC34
	public object EmitExclusiveOr(object type) { }

	// RVA: 0x6D1DC64
	public object EmitAnd(object type) { }

	// RVA: 0x6D1DC94
	public object EmitOr(object type) { }

	// RVA: 0x6D1DCC4
	public object EmitLeftShift(object type) { }

	// RVA: 0x6D1E154
	public object EmitRightShift(object type) { }

	// RVA: 0x6D1E184
	public object EmitEqual(object type, object liftedToNull) { }

	// RVA: 0x6D1E1B8
	public object EmitNotEqual(object type, object liftedToNull) { }

	// RVA: 0x6D1E1EC
	public object EmitLessThan(object type, object liftedToNull) { }

	// RVA: 0x6D1EDF8
	public object EmitLessThanOrEqual(object type, object liftedToNull) { }

	// RVA: 0x6D1FA04
	public object EmitGreaterThan(object type, object liftedToNull) { }

	// RVA: 0x6D1FA34
	public object EmitGreaterThanOrEqual(object type, object liftedToNull) { }

	// RVA: 0x6D1FA64
	public object EmitNumericConvertChecked(object from, object to, object isLiftedToNull) { }

	// RVA: 0x6D1FAEC
	public object EmitNumericConvertUnchecked(object from, object to, object isLiftedToNull) { }

	// RVA: 0x6D1FB74
	public object EmitConvertToUnderlying(object to, object isLiftedToNull) { }

	// RVA: 0x6D1FBF4
	public object EmitCast(object toType) { }

	// RVA: 0x6D1FC24
	public object EmitCastToEnum(object toType) { }

	// RVA: 0x6D1FC94
	public object EmitCastReferenceToEnum(object toType) { }

	// RVA: 0x6D1FD04
	public object EmitNot(object type) { }

	// RVA: 0x6D1FD34
	public object EmitDefaultValue(object type) { }

	// RVA: 0x6D1FDA4
	public object EmitNew(object constructorInfo, object parameters) { }

	// RVA: 0x6D1FE2C
	public object EmitByRefNew(object constructorInfo, object parameters, object updaters) { }

	// RVA: 0x6D1FEC4
	internal object EmitCreateDelegate(object creator) { }

	// RVA: 0x6D1FF34
	public object EmitTypeEquals() { }

	// RVA: 0x6D1FFA0
	public object EmitArrayLength() { }

	// RVA: 0x6D2000C
	public object EmitNegate(object type) { }

	// RVA: 0x6D2003C
	public object EmitNegateChecked(object type) { }

	// RVA: 0x6D2006C
	public object EmitIncrement(object type) { }

	// RVA: 0x6D20098
	public object EmitDecrement(object type) { }

	// RVA: 0x6D200C8
	public object EmitTypeIs(object type) { }

	// RVA: 0x6D20138
	public object EmitTypeAs(object type) { }

	// RVA: 0x6D201A8
	public object EmitLoadField(object field) { }

	// RVA: 0x6D201D0
	private object GetLoadField(object field) { }

	// RVA: 0x6D2043C
	public object EmitStoreField(object field) { }

	// RVA: 0x6D204E4
	public object EmitCall(object method) { }

	// RVA: 0x6D20568
	public object EmitCall(object method, object parameters) { }

	// RVA: 0x6D2059C
	public object EmitByRefCall(object method, object parameters, object byrefArgs) { }

	// RVA: 0x6D20684
	public object EmitNullableCall(object method, object parameters) { }

	// RVA: 0x6D1B0E0
	private object BuildRuntimeLabels() { }

	// RVA: 0x6D2074C
	public object MakeLabel() { }

	// RVA: 0x6D208D0
	internal object FixupBranch(object branchIndex, object offset) { }

	// RVA: 0x6D209CC
	private object EnsureLabelIndex(object label) { }

	// RVA: 0x6D20A2C
	public object MarkRuntimeLabel() { }

	// RVA: 0x6D20A9C
	public object MarkLabel(object label) { }

	// RVA: 0x6D20AC8
	public object EmitGoto(object label, object hasResult, object hasValue, object labelTargetGetsValue) { }

	// RVA: 0x6D20BA8
	private object EmitBranch(object instruction, object label) { }

	// RVA: 0x6D20C2C
	public object EmitBranch(object label) { }

	// RVA: 0x6D20CF4
	public object EmitBranch(object label, object hasResult, object hasValue) { }

	// RVA: 0x6D20DD4
	public object EmitCoalescingBranch(object leftNotNull) { }

	// RVA: 0x6D20E9C
	public object EmitBranchTrue(object elseLabel) { }

	// RVA: 0x6D20F64
	public object EmitBranchFalse(object elseLabel) { }

	// RVA: 0x6D2102C
	public object EmitThrow() { }

	// RVA: 0x6D21098
	public object EmitThrowVoid() { }

	// RVA: 0x6D21104
	public object EmitRethrow() { }

	// RVA: 0x6D21170
	public object EmitRethrowVoid() { }

	// RVA: 0x6D211DC
	public object EmitEnterTryFinally(object finallyStartLabel) { }

	// RVA: 0x6D21244
	public object EmitEnterTryCatch() { }

	// RVA: 0x6D21270
	public object EmitEnterTryFault(object tryEnd) { }

	// RVA: 0x6D21320
	public object EmitEnterFinally(object finallyStartLabel) { }

	// RVA: 0x6D213D8
	public object EmitLeaveFinally() { }

	// RVA: 0x6D21444
	public object EmitEnterFault(object faultStartLabel) { }

	// RVA: 0x6D214FC
	public object EmitLeaveFault() { }

	// RVA: 0x6D21568
	public object EmitEnterExceptionFilter() { }

	// RVA: 0x6D215D4
	public object EmitLeaveExceptionFilter() { }

	// RVA: 0x6D21640
	public object EmitEnterExceptionHandlerNonVoid() { }

	// RVA: 0x6D216AC
	public object EmitEnterExceptionHandlerVoid() { }

	// RVA: 0x6D21718
	public object EmitLeaveExceptionHandler(object hasValue, object tryExpressionEndLabel) { }

	// RVA: -1
	public object EmitIntSwitch(object cases) { }

	// RVA: 0x6D217E0
	public object EmitStringSwitch(object cases, object nullCase) { }

	// RVA: 0x6D21860
	public object .ctor() { }

	// RVA: 0x6D218E0
	private static object .cctor() { }

}

// Namespace: 
private sealed class <GetStackTraceDebugInfo>d__29
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x20
	public object <>4__this; // 0x28
	private object <frame>5__2; // 0x30

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Linq.Expressions.Interpreter.InterpretedFrameInfo>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6D21F94
	public object .ctor(object <>1__state) { }

	// RVA: 0x6D229EC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6D229F0
	private object MoveNext() { }

	// RVA: 0x6D22B0C
	private object System.Collections.Generic.IEnumerator<System.Linq.Expressions.Interpreter.InterpretedFrameInfo>.get_Current() { }

	// RVA: 0x6D22B18
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6D22B58
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x6D22BC0
	private object System.Collections.Generic.IEnumerable<System.Linq.Expressions.Interpreter.InterpretedFrameInfo>.GetEnumerator() { }

	// RVA: 0x6D22C6C
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class InterpretedFrame
{

	// Fields
	private static object s_currentFrame; // 0xFFFFFFFF80000000
	internal readonly object Interpreter; // 0x8
	internal object _parent; // 0x10
	private readonly object _continuations; // 0x18
	private object _continuationIndex; // 0x20
	private object _pendingContinuation; // 0x24
	private object _pendingValue; // 0x28
	public readonly object Data; // 0x30
	public readonly object Closure; // 0x38
	public object StackIndex; // 0x40
	public object InstructionIndex; // 0x44

	// Properties
	public object Name { get; }
	public object Parent { get; }

	// Methods

	// RVA: 0x6D21A68
	internal object .ctor(object interpreter, object closure) { }

	// RVA: 0x6D21B64
	public object GetDebugInfo(object instructionIndex) { }

	// RVA: 0x6D21D10
	public object get_Name() { }

	// RVA: 0x6D146E8
	public object Push(object value) { }

	// RVA: 0x6D14E84
	public object Push(object value) { }

	// RVA: 0x6D19858
	public object Push(object value) { }

	// RVA: 0x6D14768
	public object Push(object value) { }

	// RVA: 0x6D21D34
	public object Push(object value) { }

	// RVA: 0x6D196BC
	public object Push(object value) { }

	// RVA: 0x6D14964
	public object Push(object value) { }

	// RVA: 0x6D146A0
	public object Pop() { }

	// RVA: 0x6D21E04
	internal object SetStackDepth(object depth) { }

	// RVA: 0x6D21E30
	public object Peek() { }

	// RVA: 0x6D21E74
	public object Dup() { }

	// RVA: 0x6D21F10
	public object get_Parent() { }

	// RVA: 0x6D21F18
	public object GetStackTraceDebugInfo() { }

	// RVA: 0x6D21FCC
	internal object SaveTraceToException(object exception) { }

	// RVA: 0x6D22310
	internal object Enter() { }

	// RVA: 0x6D22384
	internal object Leave(object prevFrame) { }

	// RVA: 0x6D223E0
	internal object IsJumpHappened() { }

	// RVA: 0x6D223F0
	public object RemoveContinuation() { }

	// RVA: 0x6D22400
	public object PushContinuation(object continuation) { }

	// RVA: 0x6D22448
	public object YieldToCurrentContinuation() { }

	// RVA: 0x6D224E0
	public object YieldToPendingContinuation() { }

	// RVA: 0x6D226C8
	internal object PushPendingContinuation() { }

	// RVA: 0x6D227AC
	internal object PopPendingContinuation() { }

	// RVA: 0x6D22878
	public object Goto(object labelIndex, object value, object gotoExceptionHandler) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class Interpreter
{

	// Fields
	internal static readonly object NoValue; // 0x0
	private readonly object _instructions; // 0x8
	internal readonly object _objects; // 0x30
	internal readonly object _labels; // 0x38
	internal readonly object _debugInfos; // 0x40
	private readonly object <Name>k__BackingField; // 0x48
	private readonly object <LocalCount>k__BackingField; // 0x50
	private readonly object <ClosureVariables>k__BackingField; // 0x58

	// Properties
	internal object Name { get; }
	internal object LocalCount { get; }
	internal object ClosureSize { get; }
	internal object Instructions { get; }
	internal object ClosureVariables { get; }

	// Methods

	// RVA: 0x6D22D18
	internal object .ctor(object name, object locals, object instructions, object debugInfos) { }

	// RVA: 0x6D22DA0
	internal object get_Name() { }

	// RVA: 0x6D22DA8
	internal object get_LocalCount() { }

	// RVA: 0x6D22DB0
	internal object get_ClosureSize() { }

	// RVA: 0x6D22E0C
	internal object get_Instructions() { }

	// RVA: 0x6D22E24
	internal object get_ClosureVariables() { }

	// RVA: 0x6D22E2C
	public object Run(object frame) { }

	// RVA: 0x6D22EF4
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__9_0; // 0x8

	// Methods

	// RVA: 0x6D23F84
	private static object .cctor() { }

	// RVA: 0x6D23FE4
	public object .ctor() { }

	// RVA: 0x6D23FEC
	internal object <ValidateJump>b__9_0(object b) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LabelInfo
{

	// Fields
	private readonly object _node; // 0x8
	private object _label; // 0x10
	private object _definitions; // 0x18
	private readonly object _references; // 0x20
	private object _acrossBlockJump; // 0x28

	// Properties
	private object HasDefinitions { get; }
	private object HasMultipleDefinitions { get; }

	// Methods

	// RVA: 0x6D22F70
	internal object .ctor(object node) { }

	// RVA: 0x6D23004
	internal object GetLabel(object compiler) { }

	// RVA: 0x6D230C0
	internal object Reference(object block) { }

	// RVA: 0x6D235F8
	internal object Define(object block) { }

	// RVA: 0x6D23230
	private object ValidateJump(object reference) { }

	// RVA: 0x6D23EA4
	internal object ValidateFinish() { }

	// RVA: 0x6D23064
	private object EnsureLabel(object compiler) { }

	// RVA: 0x6D23BEC
	private object DefinedIn(object scope) { }

	// RVA: 0x6D23220
	private object get_HasDefinitions() { }

	// RVA: 0x6D23CBC
	private object FirstDefinition() { }

	// RVA: 0x6D23928
	private object AddDefinition(object scope) { }

	// RVA: 0x6D23B24
	private object get_HasMultipleDefinitions() { }

	// RVA: -1
	internal static object CommonNode(object first, object second, object parent) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal enum LabelScopeKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Statement;
	public const object Block;
	public const object Switch;
	public const object Lambda;
	public const object Try;
	public const object Catch;
	public const object Finally;
	public const object Filter;
	public const object Expression;
}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LabelScopeInfo
{

	// Fields
	private object _labels; // 0x8
	internal readonly object Kind; // 0x10
	internal readonly object Parent; // 0x18

	// Properties
	internal object CanJumpInto { get; }

	// Methods

	// RVA: 0x6D2400C
	internal object .ctor(object parent, object kind) { }

	// RVA: 0x6D23E94
	internal object get_CanJumpInto() { }

	// RVA: 0x6D238B8
	internal object ContainsTarget(object target) { }

	// RVA: 0x6D24048
	internal object TryGetLabelInfo(object target, object info) { }

	// RVA: 0x6D23A68
	internal object AddLabelInfo(object target, object info) { }

}

// Namespace: 
private sealed class LeftShiftSByte
{

	// Methods

	// RVA: 0x6D24160
	public override object Run(object frame) { }

	// RVA: 0x6D24120
	public object .ctor() { }

}

// Namespace: 
private sealed class LeftShiftInt16
{

	// Methods

	// RVA: 0x6D2429C
	public override object Run(object frame) { }

	// RVA: 0x6D24128
	public object .ctor() { }

}

// Namespace: 
private sealed class LeftShiftInt32
{

	// Methods

	// RVA: 0x6D243D8
	public override object Run(object frame) { }

	// RVA: 0x6D24130
	public object .ctor() { }

}

// Namespace: 
private sealed class LeftShiftInt64
{

	// Methods

	// RVA: 0x6D244FC
	public override object Run(object frame) { }

	// RVA: 0x6D24138
	public object .ctor() { }

}

// Namespace: 
private sealed class LeftShiftByte
{

	// Methods

	// RVA: 0x6D24698
	public override object Run(object frame) { }

	// RVA: 0x6D24140
	public object .ctor() { }

}

// Namespace: 
private sealed class LeftShiftUInt16
{

	// Methods

	// RVA: 0x6D247D4
	public override object Run(object frame) { }

	// RVA: 0x6D24148
	public object .ctor() { }

}

// Namespace: 
private sealed class LeftShiftUInt32
{

	// Methods

	// RVA: 0x6D24910
	public override object Run(object frame) { }

	// RVA: 0x6D24150
	public object .ctor() { }

}

// Namespace: 
private sealed class LeftShiftUInt64
{

	// Methods

	// RVA: 0x6D24AAC
	public override object Run(object frame) { }

	// RVA: 0x6D24158
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class LeftShiftInstruction
{

	// Fields
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Int32; // 0x10
	private static object s_Int64; // 0x18
	private static object s_Byte; // 0x20
	private static object s_UInt16; // 0x28
	private static object s_UInt32; // 0x30
	private static object s_UInt64; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D240C4
	public override object get_ConsumedStack() { }

	// RVA: 0x6D240CC
	public override object get_ProducedStack() { }

	// RVA: 0x6D240D4
	public override object get_InstructionName() { }

	// RVA: 0x6D24118
	private object .ctor() { }

	// RVA: 0x6D1DCF0
	public static object Create(object type) { }

}

// Namespace: 
private sealed class LessThanSByte
{

	// Methods

	// RVA: 0x6D24CC8
	public object .ctor(object nullValue) { }

	// RVA: 0x6D24EAC
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanInt16
{

	// Methods

	// RVA: 0x6D24CF4
	public object .ctor(object nullValue) { }

	// RVA: 0x6D25018
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanChar
{

	// Methods

	// RVA: 0x6D24D20
	public object .ctor(object nullValue) { }

	// RVA: 0x6D25184
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanInt32
{

	// Methods

	// RVA: 0x6D24D4C
	public object .ctor(object nullValue) { }

	// RVA: 0x6D252F0
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanInt64
{

	// Methods

	// RVA: 0x6D24D78
	public object .ctor(object nullValue) { }

	// RVA: 0x6D2545C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanByte
{

	// Methods

	// RVA: 0x6D24DA4
	public object .ctor(object nullValue) { }

	// RVA: 0x6D255C8
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanUInt16
{

	// Methods

	// RVA: 0x6D24DD0
	public object .ctor(object nullValue) { }

	// RVA: 0x6D25734
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanUInt32
{

	// Methods

	// RVA: 0x6D24DFC
	public object .ctor(object nullValue) { }

	// RVA: 0x6D258A0
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanUInt64
{

	// Methods

	// RVA: 0x6D24E28
	public object .ctor(object nullValue) { }

	// RVA: 0x6D25A0C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanSingle
{

	// Methods

	// RVA: 0x6D24E54
	public object .ctor(object nullValue) { }

	// RVA: 0x6D25B78
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanDouble
{

	// Methods

	// RVA: 0x6D24E80
	public object .ctor(object nullValue) { }

	// RVA: 0x6D25CD8
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class LessThanInstruction
{

	// Fields
	private readonly object _nullValue; // 0x8
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Char; // 0x10
	private static object s_Int32; // 0x18
	private static object s_Int64; // 0x20
	private static object s_Byte; // 0x28
	private static object s_UInt16; // 0x30
	private static object s_UInt32; // 0x38
	private static object s_UInt64; // 0x40
	private static object s_Single; // 0x48
	private static object s_Double; // 0x50
	private static object s_liftedToNullSByte; // 0x58
	private static object s_liftedToNullInt16; // 0x60
	private static object s_liftedToNullChar; // 0x68
	private static object s_liftedToNullInt32; // 0x70
	private static object s_liftedToNullInt64; // 0x78
	private static object s_liftedToNullByte; // 0x80
	private static object s_liftedToNullUInt16; // 0x88
	private static object s_liftedToNullUInt32; // 0x90
	private static object s_liftedToNullUInt64; // 0x98
	private static object s_liftedToNullSingle; // 0xA0
	private static object s_liftedToNullDouble; // 0xA8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D24C48
	public override object get_ConsumedStack() { }

	// RVA: 0x6D24C50
	public override object get_ProducedStack() { }

	// RVA: 0x6D24C58
	public override object get_InstructionName() { }

	// RVA: 0x6D24C9C
	private object .ctor(object nullValue) { }

	// RVA: 0x6D1E21C
	public static object Create(object type, object liftedToNull) { }

}

// Namespace: 
private sealed class LessThanOrEqualSByte
{

	// Methods

	// RVA: 0x6D25EB8
	public object .ctor(object nullValue) { }

	// RVA: 0x6D2609C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualInt16
{

	// Methods

	// RVA: 0x6D25EE4
	public object .ctor(object nullValue) { }

	// RVA: 0x6D26208
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualChar
{

	// Methods

	// RVA: 0x6D25F10
	public object .ctor(object nullValue) { }

	// RVA: 0x6D26374
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualInt32
{

	// Methods

	// RVA: 0x6D25F3C
	public object .ctor(object nullValue) { }

	// RVA: 0x6D264E0
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualInt64
{

	// Methods

	// RVA: 0x6D25F68
	public object .ctor(object nullValue) { }

	// RVA: 0x6D2664C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualByte
{

	// Methods

	// RVA: 0x6D25F94
	public object .ctor(object nullValue) { }

	// RVA: 0x6D267B8
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualUInt16
{

	// Methods

	// RVA: 0x6D25FC0
	public object .ctor(object nullValue) { }

	// RVA: 0x6D26924
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualUInt32
{

	// Methods

	// RVA: 0x6D25FEC
	public object .ctor(object nullValue) { }

	// RVA: 0x6D26A90
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualUInt64
{

	// Methods

	// RVA: 0x6D26018
	public object .ctor(object nullValue) { }

	// RVA: 0x6D26BFC
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualSingle
{

	// Methods

	// RVA: 0x6D26044
	public object .ctor(object nullValue) { }

	// RVA: 0x6D26D68
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class LessThanOrEqualDouble
{

	// Methods

	// RVA: 0x6D26070
	public object .ctor(object nullValue) { }

	// RVA: 0x6D26EC8
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class LessThanOrEqualInstruction
{

	// Fields
	private readonly object _nullValue; // 0x8
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Char; // 0x10
	private static object s_Int32; // 0x18
	private static object s_Int64; // 0x20
	private static object s_Byte; // 0x28
	private static object s_UInt16; // 0x30
	private static object s_UInt32; // 0x38
	private static object s_UInt64; // 0x40
	private static object s_Single; // 0x48
	private static object s_Double; // 0x50
	private static object s_liftedToNullSByte; // 0x58
	private static object s_liftedToNullInt16; // 0x60
	private static object s_liftedToNullChar; // 0x68
	private static object s_liftedToNullInt32; // 0x70
	private static object s_liftedToNullInt64; // 0x78
	private static object s_liftedToNullByte; // 0x80
	private static object s_liftedToNullUInt16; // 0x88
	private static object s_liftedToNullUInt32; // 0x90
	private static object s_liftedToNullUInt64; // 0x98
	private static object s_liftedToNullSingle; // 0xA0
	private static object s_liftedToNullDouble; // 0xA8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D25E38
	public override object get_ConsumedStack() { }

	// RVA: 0x6D25E40
	public override object get_ProducedStack() { }

	// RVA: 0x6D25E48
	public override object get_InstructionName() { }

	// RVA: 0x6D25E8C
	private object .ctor(object nullValue) { }

	// RVA: 0x6D1EE28
	public static object Create(object type, object liftedToNull) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ExceptionFilter
{

	// Fields
	public readonly object LabelIndex; // 0x8
	public readonly object StartIndex; // 0xC
	public readonly object EndIndex; // 0x10

	// Methods

	// RVA: 0x6D27028
	internal object .ctor(object labelIndex, object start, object end) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ExceptionHandler
{

	// Fields
	private readonly object _exceptionType; // 0x8
	public readonly object LabelIndex; // 0x10
	public readonly object HandlerStartIndex; // 0x14
	public readonly object HandlerEndIndex; // 0x18
	public readonly object Filter; // 0x20

	// Methods

	// RVA: 0x6D27068
	internal object .ctor(object labelIndex, object handlerStartIndex, object handlerEndIndex, object exceptionType, object filter) { }

	// RVA: 0x6D270C0
	public object Matches(object exceptionType) { }

	// RVA: 0x6D27118
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TryCatchFinallyHandler
{

	// Fields
	internal readonly object TryStartIndex; // 0x8
	internal readonly object TryEndIndex; // 0xC
	internal readonly object FinallyStartIndex; // 0x10
	internal readonly object FinallyEndIndex; // 0x14
	internal readonly object GotoEndTargetIndex; // 0x18
	private readonly object _handlers; // 0x20

	// Properties
	internal object IsFinallyBlockExist { get; }
	internal object Handlers { get; }
	internal object IsCatchBlockExist { get; }

	// Methods

	// RVA: 0x6D27258
	internal object get_IsFinallyBlockExist() { }

	// RVA: 0x6D2726C
	internal object get_Handlers() { }

	// RVA: 0x6D27274
	internal object get_IsCatchBlockExist() { }

	// RVA: 0x6D27284
	internal object .ctor(object tryStart, object tryEnd, object gotoEndTargetIndex, object handlers) { }

	// RVA: 0x6D272DC
	internal object .ctor(object tryStart, object tryEnd, object gotoEndLabelIndex, object finallyStart, object finallyEnd, object handlers) { }

	// RVA: 0x6D27340
	internal object HasHandler(object frame, object exception, object handler, object unwrappedException) { }

	// RVA: 0x6D274E4
	private static object FilterPasses(object frame, object exception, object filter) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TryFaultHandler
{

	// Fields
	internal readonly object TryStartIndex; // 0x8
	internal readonly object TryEndIndex; // 0xC
	internal readonly object FinallyStartIndex; // 0x10
	internal readonly object FinallyEndIndex; // 0x14

	// Methods

	// RVA: 0x6D27830
	internal object .ctor(object tryStart, object tryEnd, object finallyStart, object finallyEnd) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class RethrowException
{

	// Methods

	// RVA: 0x6D2787C
	public object .ctor() { }

}

// Namespace: 
private class DebugInfoComparer
{

	// Methods

	// RVA: 0x6D27BE4
	private object System.Collections.Generic.IComparer<System.Linq.Expressions.Interpreter.DebugInfo>.Compare(object d1, object d2) { }

	// RVA: 0x6D27BDC
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class DebugInfo
{

	// Fields
	public object StartLine; // 0x8
	public object EndLine; // 0xC
	public object Index; // 0x10
	public object FileName; // 0x18
	public object IsClear; // 0x20
	private static readonly object s_debugComparer; // 0x0

	// Methods

	// RVA: 0x6D21BFC
	public static object GetMatchingDebugInfo(object debugInfos, object index) { }

	// RVA: 0x6D2790C
	public override object ToString() { }

	// RVA: 0x6D27904
	public object .ctor() { }

	// RVA: 0x6D27B60
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal struct InterpretedFrameInfo
{

	// Fields
	private readonly object _methodName; // 0xFFFFFFFFFFFFFFF8
	private readonly object _debugInfo; // 0x0

	// Methods

	// RVA: 0x6D22B04
	public object .ctor(object methodName, object info) { }

	// RVA: 0x6D27C6C
	public override object ToString() { }

}

// Namespace: 
private sealed class QuoteVisitor
{

	// Fields
	private readonly object _definedParameters; // 0x8
	public readonly object _hoistedParameters; // 0x10

	// Methods

	// RVA: 0x6D3BA50
	protected internal override object VisitParameter(object node) { }

	// RVA: 0x6D3BAFC
	protected internal override object VisitBlock(object node) { }

	// RVA: 0x6D3C36C
	protected override object VisitCatchBlock(object node) { }

	// RVA: -1
	protected internal override object VisitLambda(object node) { }

	// RVA: 0x6D3BB70
	private object PushParameters(object parameters) { }

	// RVA: 0x6D3BF68
	private object PopParameters(object parameters) { }

	// RVA: 0x6D3C4F8
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__56_1; // 0x8
	public static object <>9__56_0; // 0x10
	public static object <>9__101_0; // 0x18

	// Methods

	// RVA: 0x6D3C5C0
	private static object .cctor() { }

	// RVA: 0x6D3C620
	public object .ctor() { }

	// RVA: 0x6D3C628
	internal object <CompileSwitchExpression>b__56_0(object c) { }

	// RVA: 0x6D3C750
	internal object <CompileSwitchExpression>b__56_1(object t) { }

	// RVA: 0x6D3C7D4
	internal object <CompileNoLabelPush>b__101_0(object this, object e) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LightCompiler
{

	// Fields
	private readonly object _instructions; // 0x8
	private readonly object _locals; // 0x10
	private readonly object _debugInfos; // 0x18
	private readonly object _treeLabels; // 0x20
	private object _labelBlock; // 0x28
	private readonly object _exceptionForRethrowStack; // 0x30
	private readonly object _parent; // 0x38
	private readonly object _guard; // 0x40
	private static readonly object s_emptyLocals; // 0x0

	// Properties
	public object Instructions { get; }

	// Methods

	// RVA: 0x6D27DAC
	public object .ctor() { }

	// RVA: 0x6D27FDC
	private object .ctor(object parent) { }

	// RVA: 0x6D28004
	public object get_Instructions() { }

	// RVA: 0x6D2800C
	public object CompileTop(object node) { }

	// RVA: 0x6D283F0
	private object MakeInterpreter(object lambdaName) { }

	// RVA: 0x6D287B4
	private object CompileConstantExpression(object expr) { }

	// RVA: 0x6D2888C
	private object CompileDefaultExpression(object expr) { }

	// RVA: 0x6D288E8
	private object CompileDefaultExpression(object type) { }

	// RVA: 0x6D28AAC
	private object EnsureAvailableForClosure(object expr) { }

	// RVA: 0x6D28C18
	private object ResolveLocal(object variable) { }

	// RVA: 0x6D28C88
	private object CompileGetVariable(object variable) { }

	// RVA: 0x6D28E4C
	private object EmitCopyValueType(object valueType) { }

	// RVA: 0x6D28CE8
	private object LoadLocalNoValueTypeCopy(object variable) { }

	// RVA: 0x6D28F3C
	private object MaybeMutableValueType(object type) { }

	// RVA: 0x6D28FC4
	private object CompileGetBoxedVariable(object variable) { }

	// RVA: 0x6D29094
	private object CompileSetVariable(object variable, object isVoid) { }

	// RVA: 0x6D292F4
	private object CompileParameterExpression(object expr) { }

	// RVA: 0x6D293CC
	private object CompileBlockExpression(object expr, object asVoid) { }

	// RVA: 0x6D29584
	private object CompileBlockStart(object node) { }

	// RVA: 0x6D29B44
	private object CompileBlockEnd(object locals) { }

	// RVA: 0x6D29E68
	private object CompileIndexExpression(object expr) { }

	// RVA: 0x6D29F8C
	private object EmitIndexGet(object index) { }

	// RVA: 0x6D2A1D8
	private object CompileIndexAssignment(object node, object asVoid) { }

	// RVA: 0x6D2A73C
	private object CompileMemberAssignment(object node, object asVoid) { }

	// RVA: 0x6D2A81C
	private object CompileMemberAssignment(object asVoid, object refMember, object value, object forBinding) { }

	// RVA: 0x6D2AF30
	private object CompileVariableAssignment(object node, object asVoid) { }

	// RVA: 0x6D2B024
	private object CompileAssignBinaryExpression(object expr, object asVoid) { }

	// RVA: 0x6D2B1A4
	private object CompileBinaryExpression(object expr) { }

	// RVA: 0x6D2CAD0
	private object CompileEqual(object left, object right, object liftedToNull) { }

	// RVA: 0x6D2CBBC
	private object CompileNotEqual(object left, object right, object liftedToNull) { }

	// RVA: 0x6D2CCA8
	private object CompileComparison(object node) { }

	// RVA: 0x6D2C71C
	private object CompileArithmetic(object nodeType, object left, object right) { }

	// RVA: 0x6D2CF68
	private object CompileConvertUnaryExpression(object expr) { }

	// RVA: 0x6D2E748
	private object CompileConvertToType(object typeFrom, object typeTo, object isChecked, object isLiftedToNull) { }

	// RVA: 0x6D2EFBC
	private object CompileNotExpression(object node) { }

	// RVA: 0x6D2F08C
	private object CompileUnaryExpression(object expr) { }

	// RVA: 0x6D2F6A0
	private object EmitUnaryMethodCall(object node) { }

	// RVA: 0x6D2F9D8
	private object EmitUnaryBoolCheck(object node) { }

	// RVA: 0x6D2FCA4
	private object CompileAndAlsoBinaryExpression(object expr) { }

	// RVA: 0x6D2FF18
	private object CompileOrElseBinaryExpression(object expr) { }

	// RVA: 0x6D2FD40
	private object CompileLogicalBinaryExpression(object b, object andAlso) { }

	// RVA: 0x6D2FFB4
	private object CompileMethodLogicalBinaryExpression(object expr, object andAlso) { }

	// RVA: 0x6D302EC
	private object CompileLiftedLogicalBinaryExpression(object node, object andAlso) { }

	// RVA: 0x6D30DE4
	private object CompileUnliftedLogicalBinaryExpression(object expr, object andAlso) { }

	// RVA: 0x6D30F9C
	private object CompileConditionalExpression(object expr, object asVoid) { }

	// RVA: 0x6D3132C
	private object CompileLoopExpression(object expr) { }

	// RVA: 0x6D3175C
	private object CompileSwitchExpression(object expr) { }

	// RVA: -1
	private object CompileIntSwitchExpression(object node) { }

	// RVA: 0x6D3232C
	private object CompileStringSwitchExpression(object node) { }

	// RVA: 0x6D32C0C
	private object CompileLabelExpression(object expr) { }

	// RVA: 0x6D32EE0
	private object CompileGotoExpression(object expr) { }

	// RVA: 0x6D315BC
	private object PushLabelBlock(object type) { }

	// RVA: 0x6D31734
	private object PopLabelBlock(object kind) { }

	// RVA: 0x6D331A0
	private object EnsureLabel(object node) { }

	// RVA: 0x6D33160
	private object ReferenceLabel(object node) { }

	// RVA: 0x6D31630
	private object DefineLabel(object node) { }

	// RVA: 0x6D332F4
	private object TryPushLabelBlock(object node) { }

	// RVA: 0x6D339B0
	private object DefineBlockLabels(object node) { }

	// RVA: 0x6D33B04
	private object CheckRethrow() { }

	// RVA: 0x6D33B64
	private object CompileThrowUnaryExpression(object expr, object asVoid) { }

	// RVA: 0x6D33E3C
	private object CompileTryExpression(object expr) { }

	// RVA: 0x6D35388
	private object CompileTryFaultExpression(object expr) { }

	// RVA: 0x6D35880
	private object CompileMethodCallExpression(object expr) { }

	// RVA: 0x6D35930
	private object CompileMethodCallExpression(object object, object method, object arguments) { }

	// RVA: 0x6D361B0
	private object CompileArrayIndexAddress(object array, object index, object argumentIndex) { }

	// RVA: 0x6D29F84
	private object EmitThisForMethodCall(object node) { }

	// RVA: 0x6D3653C
	private static object ShouldWritebackNode(object node) { }

	// RVA: 0x6D2D940
	private object CompileAddress(object node, object index) { }

	// RVA: 0x6D36740
	private object CompileMultiDimArrayAccess(object array, object arguments, object index) { }

	// RVA: 0x6D36E58
	private object CompileNewExpression(object expr) { }

	// RVA: 0x6D37410
	private object CompileMemberExpression(object expr) { }

	// RVA: 0x6D374C4
	private object CompileMember(object from, object member, object forBinding) { }

	// RVA: 0x6D37A48
	private object CompileNewArrayExpression(object expr) { }

	// RVA: 0x6D37F98
	private object CompileDebugInfoExpression(object expr) { }

	// RVA: 0x6D3823C
	private object CompileRuntimeVariablesExpression(object expr) { }

	// RVA: 0x6D385F4
	private object CompileLambdaExpression(object expr) { }

	// RVA: 0x6D388A4
	private object CompileCoalesceBinaryExpression(object expr) { }

	// RVA: 0x6D39244
	private object CompileInvocationExpression(object expr) { }

	// RVA: 0x6D395EC
	private object CompileListInitExpression(object expr) { }

	// RVA: 0x6D3967C
	private object CompileListInit(object initializers) { }

	// RVA: 0x6D39C50
	private object CompileMemberInitExpression(object expr) { }

	// RVA: 0x6D39CE0
	private object CompileMemberInit(object bindings) { }

	// RVA: 0x6D3A3B0
	private static object GetMemberType(object member) { }

	// RVA: 0x6D3A590
	private object CompileQuoteUnaryExpression(object expr) { }

	// RVA: 0x6D3A98C
	private object CompileUnboxUnaryExpression(object expr) { }

	// RVA: 0x6D3AB48
	private object CompileTypeEqualExpression(object expr) { }

	// RVA: 0x6D2F8E0
	private object CompileTypeAsExpression(object node) { }

	// RVA: 0x6D3AE1C
	private object CompileTypeIsExpression(object expr) { }

	// RVA: 0x6D29ACC
	private object Compile(object expr, object asVoid) { }

	// RVA: 0x6D29C34
	private object CompileAsVoid(object expr) { }

	// RVA: 0x6D3B214
	private object CompileNoLabelPush(object expr) { }

	// RVA: 0x6D28394
	private object Compile(object expr) { }

	// RVA: 0x6D3B930
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class ByRefUpdater
{

	// Fields
	public readonly object ArgumentIndex; // 0x8

	// Methods

	// RVA: 0x6D3C7FC
	public object .ctor(object argumentIndex) { }

	// RVA: -1
	public abstract object Update(object frame, object value) { }

	// RVA: 0x6D3C828
	public virtual object UndefineTemps(object instructions, object locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ParameterByRefUpdater
{

	// Fields
	private readonly object _parameter; // 0x10

	// Methods

	// RVA: 0x6D3C82C
	public object .ctor(object parameter, object argumentIndex) { }

	// RVA: 0x6D3C868
	public override object Update(object frame, object value) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ArrayByRefUpdater
{

	// Fields
	private readonly object _array; // 0x10
	private readonly object _index; // 0x20

	// Methods

	// RVA: 0x6D3CB04
	public object .ctor(object array, object index, object argumentIndex) { }

	// RVA: 0x6D3CB58
	public override object Update(object frame, object value) { }

	// RVA: 0x6D3CC94
	public override object UndefineTemps(object instructions, object locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class FieldByRefUpdater
{

	// Fields
	private readonly object _object; // 0x10
	private readonly object _field; // 0x28

	// Methods

	// RVA: 0x6D3CE30
	public object .ctor(object obj, object field, object argumentIndex) { }

	// RVA: 0x6D3CE7C
	public override object Update(object frame, object value) { }

	// RVA: 0x6D3CF44
	public override object UndefineTemps(object instructions, object locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class PropertyByRefUpdater
{

	// Fields
	private readonly object _object; // 0x10
	private readonly object _property; // 0x28

	// Methods

	// RVA: 0x6D3CFF8
	public object .ctor(object obj, object property, object argumentIndex) { }

	// RVA: 0x6D3D044
	public override object Update(object frame, object value) { }

	// RVA: 0x6D3D1D8
	public override object UndefineTemps(object instructions, object locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class IndexMethodByRefUpdater
{

	// Fields
	private readonly object _indexer; // 0x10
	private readonly object _obj; // 0x18
	private readonly object _args; // 0x30

	// Methods

	// RVA: 0x6D3D28C
	public object .ctor(object obj, object args, object indexer, object argumentIndex) { }

	// RVA: 0x6D3D2E8
	public override object Update(object frame, object value) { }

	// RVA: 0x6D3D5BC
	public override object UndefineTemps(object instructions, object locals) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LightDelegateCreator
{

	// Fields
	private readonly object _lambda; // 0x8
	private readonly object <Interpreter>k__BackingField; // 0x10

	// Properties
	internal object Interpreter { get; }

	// Methods

	// RVA: 0x6D3D71C
	internal object .ctor(object interpreter, object lambda) { }

	// RVA: 0x6D3D754
	internal object get_Interpreter() { }

	// RVA: 0x6D3D75C
	public object CreateDelegate() { }

	// RVA: 0x6D3D764
	internal object CreateDelegate(object closure) { }

}

// Namespace: 
private class DebugViewPrinter
{

	// Fields
	private readonly object _interpreter; // 0x8
	private readonly object _tryStart; // 0x10
	private readonly object _handlerEnter; // 0x18
	private readonly object _handlerExit; // 0x20
	private object _indent; // 0x28

	// Methods

	// RVA: 0x6D3DC48
	public object .ctor(object interpreter) { }

	// RVA: 0x6D407BC
	private object Analyze() { }

	// RVA: 0x6D40D90
	private object AddTryStart(object index) { }

	// RVA: 0x6D40E9C
	private object AddHandlerExit(object index) { }

	// RVA: 0x6D40F54
	private object Indent() { }

	// RVA: 0x6D40FA0
	private object Dedent() { }

	// RVA: 0x6D40FEC
	public override object ToString() { }

	// RVA: 0x6D4165C
	private object EmitExits(object sb, object index) { }

}

// Namespace: 
private sealed class <>c__DisplayClass74_0
{

	// Fields
	public object targetMethod; // 0x8
	public object delegateType; // 0x10

	// Methods

	// RVA: 0x6D3EA58
	public object .ctor() { }

	// RVA: 0x6D4179C
	internal object <MakeRunDelegateCtor>b__0(object lambda) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class LightLambda
{

	// Fields
	private readonly object _closure; // 0x8
	private readonly object _interpreter; // 0x10
	private static readonly object _runCache; // 0x0
	private readonly object _delegateCreator; // 0x18

	// Properties
	internal object DebugView { get; }

	// Methods

	// RVA: -1
	internal object Run0() { }

	// RVA: 0x6D3D980
	internal object RunVoid0() { }

	// RVA: -1
	internal static object MakeRun0(object lambda) { }

	// RVA: 0x6D3DB34
	internal static object MakeRunVoid0(object lambda) { }

	// RVA: -1
	internal object Run1(object arg0) { }

	// RVA: -1
	internal object RunVoid1(object arg0) { }

	// RVA: -1
	internal static object MakeRun1(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid1(object lambda) { }

	// RVA: -1
	internal object Run2(object arg0, object arg1) { }

	// RVA: -1
	internal object RunVoid2(object arg0, object arg1) { }

	// RVA: -1
	internal static object MakeRun2(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid2(object lambda) { }

	// RVA: -1
	internal object Run3(object arg0, object arg1, object arg2) { }

	// RVA: -1
	internal object RunVoid3(object arg0, object arg1, object arg2) { }

	// RVA: -1
	internal static object MakeRun3(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid3(object lambda) { }

	// RVA: -1
	internal object Run4(object arg0, object arg1, object arg2, object arg3) { }

	// RVA: -1
	internal object RunVoid4(object arg0, object arg1, object arg2, object arg3) { }

	// RVA: -1
	internal static object MakeRun4(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid4(object lambda) { }

	// RVA: -1
	internal object Run5(object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: -1
	internal object RunVoid5(object arg0, object arg1, object arg2, object arg3, object arg4) { }

	// RVA: -1
	internal static object MakeRun5(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid5(object lambda) { }

	// RVA: -1
	internal object Run6(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5) { }

	// RVA: -1
	internal object RunVoid6(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5) { }

	// RVA: -1
	internal static object MakeRun6(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid6(object lambda) { }

	// RVA: -1
	internal object Run7(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6) { }

	// RVA: -1
	internal object RunVoid7(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6) { }

	// RVA: -1
	internal static object MakeRun7(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid7(object lambda) { }

	// RVA: -1
	internal object Run8(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7) { }

	// RVA: -1
	internal object RunVoid8(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7) { }

	// RVA: -1
	internal static object MakeRun8(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid8(object lambda) { }

	// RVA: -1
	internal object Run9(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8) { }

	// RVA: -1
	internal object RunVoid9(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8) { }

	// RVA: -1
	internal static object MakeRun9(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid9(object lambda) { }

	// RVA: -1
	internal object Run10(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9) { }

	// RVA: -1
	internal object RunVoid10(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9) { }

	// RVA: -1
	internal static object MakeRun10(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid10(object lambda) { }

	// RVA: -1
	internal object Run11(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10) { }

	// RVA: -1
	internal object RunVoid11(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10) { }

	// RVA: -1
	internal static object MakeRun11(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid11(object lambda) { }

	// RVA: -1
	internal object Run12(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11) { }

	// RVA: -1
	internal object RunVoid12(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11) { }

	// RVA: -1
	internal static object MakeRun12(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid12(object lambda) { }

	// RVA: -1
	internal object Run13(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12) { }

	// RVA: -1
	internal object RunVoid13(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12) { }

	// RVA: -1
	internal static object MakeRun13(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid13(object lambda) { }

	// RVA: -1
	internal object Run14(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13) { }

	// RVA: -1
	internal object RunVoid14(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13) { }

	// RVA: -1
	internal static object MakeRun14(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid14(object lambda) { }

	// RVA: -1
	internal object Run15(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13, object arg14) { }

	// RVA: -1
	internal object RunVoid15(object arg0, object arg1, object arg2, object arg3, object arg4, object arg5, object arg6, object arg7, object arg8, object arg9, object arg10, object arg11, object arg12, object arg13, object arg14) { }

	// RVA: -1
	internal static object MakeRun15(object lambda) { }

	// RVA: -1
	internal static object MakeRunVoid15(object lambda) { }

	// RVA: 0x6D3D888
	internal object .ctor(object delegateCreator, object closure) { }

	// RVA: 0x6D3DBB4
	internal object get_DebugView() { }

	// RVA: 0x6D3DD58
	private static object GetRunDelegateCtor(object delegateType) { }

	// RVA: 0x6D3DF18
	private static object MakeRunDelegateCtor(object delegateType) { }

	// RVA: 0x6D3F6F4
	private object CreateCustomDelegate(object delegateType) { }

	// RVA: 0x6D3D8DC
	internal object MakeDelegate(object delegateType) { }

	// RVA: 0x6D3DAC4
	private object MakeFrame() { }

	// RVA: -1
	internal object RunVoidRef2(object arg0, object arg1) { }

	// RVA: 0x6D40250
	public object Run(object arguments) { }

	// RVA: 0x6D40558
	public object RunVoid(object arguments) { }

	// RVA: 0x6D40728
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal interface IBoxableInstruction
{

	// Methods

	// RVA: -1
	public abstract object BoxIfIndexMatches(object index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class LocalAccessInstruction
{

	// Fields
	internal readonly object _index; // 0x8

	// Methods

	// RVA: 0x6D41804
	protected object .ctor(object index) { }

	// RVA: 0x6D41830
	public override object ToDebugString(object instructionIndex, object cookie, object labelIndexer, object objects) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadLocalInstruction
{

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D41A00
	internal object .ctor(object index) { }

	// RVA: 0x6D41A2C
	public override object get_ProducedStack() { }

	// RVA: 0x6D41A34
	public override object get_InstructionName() { }

	// RVA: 0x6D41A78
	public override object Run(object frame) { }

	// RVA: 0x6D41B1C
	public object BoxIfIndexMatches(object index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadLocalBoxedInstruction
{

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D41BBC
	internal object .ctor(object index) { }

	// RVA: 0x6D41BE8
	public override object get_ProducedStack() { }

	// RVA: 0x6D41BF0
	public override object get_InstructionName() { }

	// RVA: 0x6D41C34
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadLocalFromClosureInstruction
{

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D41DE8
	internal object .ctor(object index) { }

	// RVA: 0x6D41E14
	public override object get_ProducedStack() { }

	// RVA: 0x6D41E1C
	public override object get_InstructionName() { }

	// RVA: 0x6D41E60
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadLocalFromClosureBoxedInstruction
{

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D41FE4
	internal object .ctor(object index) { }

	// RVA: 0x6D42010
	public override object get_ProducedStack() { }

	// RVA: 0x6D42018
	public override object get_InstructionName() { }

	// RVA: 0x6D4205C
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class AssignLocalInstruction
{

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D42118
	internal object .ctor(object index) { }

	// RVA: 0x6D42144
	public override object get_ConsumedStack() { }

	// RVA: 0x6D4214C
	public override object get_ProducedStack() { }

	// RVA: 0x6D42154
	public override object get_InstructionName() { }

	// RVA: 0x6D42198
	public override object Run(object frame) { }

	// RVA: 0x6D42230
	public object BoxIfIndexMatches(object index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StoreLocalInstruction
{

	// Properties
	public override object ConsumedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D422D0
	internal object .ctor(object index) { }

	// RVA: 0x6D422FC
	public override object get_ConsumedStack() { }

	// RVA: 0x6D42304
	public override object get_InstructionName() { }

	// RVA: 0x6D42348
	public override object Run(object frame) { }

	// RVA: 0x6D423E0
	public object BoxIfIndexMatches(object index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class AssignLocalBoxedInstruction
{

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D42480
	internal object .ctor(object index) { }

	// RVA: 0x6D424AC
	public override object get_ConsumedStack() { }

	// RVA: 0x6D424B4
	public override object get_ProducedStack() { }

	// RVA: 0x6D424BC
	public override object get_InstructionName() { }

	// RVA: 0x6D42500
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class StoreLocalBoxedInstruction
{

	// Properties
	public override object ConsumedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4266C
	internal object .ctor(object index) { }

	// RVA: 0x6D42698
	public override object get_ConsumedStack() { }

	// RVA: 0x6D426A0
	public override object get_InstructionName() { }

	// RVA: 0x6D426E4
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class AssignLocalToClosureInstruction
{

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D42858
	internal object .ctor(object index) { }

	// RVA: 0x6D42884
	public override object get_ConsumedStack() { }

	// RVA: 0x6D4288C
	public override object get_ProducedStack() { }

	// RVA: 0x6D42894
	public override object get_InstructionName() { }

	// RVA: 0x6D428D8
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class ValueTypeCopyInstruction
{

	// Fields
	public static readonly object Instruction; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D42A04
	public override object get_ConsumedStack() { }

	// RVA: 0x6D42A0C
	public override object get_ProducedStack() { }

	// RVA: 0x6D42A14
	public override object get_InstructionName() { }

	// RVA: 0x6D42A58
	public override object Run(object frame) { }

	// RVA: 0x6D42AB0
	public object .ctor() { }

	// RVA: 0x6D42AB8
	private static object .cctor() { }

}

// Namespace: 
internal sealed class Reference
{

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D42B44
	internal object .ctor(object index) { }

	// RVA: 0x6D42B70
	public override object Run(object frame) { }

	// RVA: 0x6D42BC4
	public object BoxIfIndexMatches(object index) { }

	// RVA: 0x6D42C64
	public override object get_InstructionName() { }

}

// Namespace: 
internal sealed class ImmutableValue
{

	// Fields
	private readonly object _defaultValue; // 0x10

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D42CA8
	internal object .ctor(object index, object defaultValue) { }

	// RVA: 0x6D42CE4
	public override object Run(object frame) { }

	// RVA: 0x6D42D70
	public object BoxIfIndexMatches(object index) { }

	// RVA: 0x6D42E40
	public override object get_InstructionName() { }

}

// Namespace: 
internal sealed class ImmutableBox
{

	// Fields
	private readonly object _defaultValue; // 0x10

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D42E04
	internal object .ctor(object index, object defaultValue) { }

	// RVA: 0x6D42E84
	public override object Run(object frame) { }

	// RVA: 0x6D42F74
	public override object get_InstructionName() { }

}

// Namespace: 
internal sealed class ImmutableRefBox
{

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D42FB8
	internal object .ctor(object index) { }

	// RVA: 0x6D42FE4
	public override object Run(object frame) { }

	// RVA: 0x6D430C4
	public override object get_InstructionName() { }

}

// Namespace: 
internal sealed class ParameterBox
{

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D43108
	public object .ctor(object index) { }

	// RVA: 0x6D43134
	public override object Run(object frame) { }

	// RVA: 0x6D43230
	public override object get_InstructionName() { }

}

// Namespace: 
internal sealed class Parameter
{

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D43274
	internal object .ctor(object index) { }

	// RVA: 0x6D432A0
	public override object Run(object frame) { }

	// RVA: 0x6D432A8
	public object BoxIfIndexMatches(object index) { }

	// RVA: 0x6D43348
	public override object get_InstructionName() { }

}

// Namespace: 
internal sealed class MutableValue
{

	// Fields
	private readonly object _type; // 0x10

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4338C
	internal object .ctor(object index, object type) { }

	// RVA: 0x6D433C8
	public override object Run(object frame) { }

	// RVA: 0x6D43514
	public object BoxIfIndexMatches(object index) { }

	// RVA: 0x6D435E4
	public override object get_InstructionName() { }

}

// Namespace: 
internal sealed class MutableBox
{

	// Fields
	private readonly object _type; // 0x10

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D435A8
	internal object .ctor(object index, object type) { }

	// RVA: 0x6D43628
	public override object Run(object frame) { }

	// RVA: 0x6D437C4
	public override object get_InstructionName() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class InitializeLocalInstruction
{

	// Methods

	// RVA: 0x6D42B18
	internal object .ctor(object index) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class RuntimeVariablesInstruction
{

	// Fields
	private readonly object _count; // 0x8

	// Properties
	public override object ProducedStack { get; }
	public override object ConsumedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D43808
	public object .ctor(object count) { }

	// RVA: 0x6D43834
	public override object get_ProducedStack() { }

	// RVA: 0x6D4383C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D43844
	public override object get_InstructionName() { }

	// RVA: 0x6D43888
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LocalVariable
{

	// Fields
	public readonly object Index; // 0x8
	private object _flags; // 0xC

	// Properties
	public object IsBoxed { get; set; }
	public object InClosure { get; }

	// Methods

	// RVA: 0x6D3CAF8
	public object get_IsBoxed() { }

	// RVA: 0x6D43A80
	public object set_IsBoxed(object value) { }

	// RVA: 0x6D3CAEC
	public object get_InClosure() { }

	// RVA: 0x6D43A94
	internal object .ctor(object index, object closure) { }

	// RVA: 0x6D43AD8
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal struct LocalDefinition
{

	// Fields
	private readonly object <Index>k__BackingField; // 0xFFFFFFFFFFFFFFF8
	private readonly object <Parameter>k__BackingField; // 0x0

	// Properties
	public object Index { get; }
	public object Parameter { get; }

	// Methods

	// RVA: 0x6D43C20
	internal object .ctor(object localIndex, object parameter) { }

	// RVA: 0x6D43C38
	public object get_Index() { }

	// RVA: 0x6D43C48
	public object get_Parameter() { }

	// RVA: 0x6D43C58
	public override object Equals(object obj) { }

	// RVA: 0x6D43DC0
	public override object GetHashCode() { }

}

// Namespace: 
private sealed class VariableScope
{

	// Fields
	public readonly object Start; // 0x8
	public object Stop; // 0xC
	public readonly object Variable; // 0x10
	public readonly object Parent; // 0x18
	public object ChildScopes; // 0x20

	// Methods

	// RVA: 0x6D441E8
	public object .ctor(object variable, object start, object parent) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LocalVariables
{

	// Fields
	private readonly object _variables; // 0x8
	private object _closureVariables; // 0x10
	private object _localCount; // 0x18
	private object _maxLocalCount; // 0x1C

	// Properties
	public object LocalCount { get; }
	internal object ClosureVariables { get; }

	// Methods

	// RVA: 0x6D43EC0
	public object DefineLocal(object variable, object start) { }

	// RVA: 0x6D3CD2C
	public object UndefineLocal(object definition, object end) { }

	// RVA: 0x6D44230
	internal object Box(object variable, object instructions) { }

	// RVA: 0x6D44480
	public object get_LocalCount() { }

	// RVA: 0x6D44488
	public object TryGetLocalOrClosure(object var, object local) { }

	// RVA: 0x6D4459C
	internal object get_ClosureVariables() { }

	// RVA: 0x6D445A4
	internal object AddClosureVariable(object variable) { }

	// RVA: 0x6D446C8
	public object .ctor() { }

}

// Namespace: 
private sealed class ModuloInt16
{

	// Methods

	// RVA: 0x6D44C48
	public override object Run(object frame) { }

	// RVA: 0x6D44C08
	public object .ctor() { }

}

// Namespace: 
private sealed class ModuloInt32
{

	// Methods

	// RVA: 0x6D44DB0
	public override object Run(object frame) { }

	// RVA: 0x6D44C10
	public object .ctor() { }

}

// Namespace: 
private sealed class ModuloInt64
{

	// Methods

	// RVA: 0x6D450FC
	public override object Run(object frame) { }

	// RVA: 0x6D44C18
	public object .ctor() { }

}

// Namespace: 
private sealed class ModuloUInt16
{

	// Methods

	// RVA: 0x6D45264
	public override object Run(object frame) { }

	// RVA: 0x6D44C20
	public object .ctor() { }

}

// Namespace: 
private sealed class ModuloUInt32
{

	// Methods

	// RVA: 0x6D453CC
	public override object Run(object frame) { }

	// RVA: 0x6D44C28
	public object .ctor() { }

}

// Namespace: 
private sealed class ModuloUInt64
{

	// Methods

	// RVA: 0x6D45534
	public override object Run(object frame) { }

	// RVA: 0x6D44C30
	public object .ctor() { }

}

// Namespace: 
private sealed class ModuloSingle
{

	// Methods

	// RVA: 0x6D4569C
	public override object Run(object frame) { }

	// RVA: 0x6D44C38
	public object .ctor() { }

}

// Namespace: 
private sealed class ModuloDouble
{

	// Methods

	// RVA: 0x6D4580C
	public override object Run(object frame) { }

	// RVA: 0x6D44C40
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class ModuloInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28
	private static object s_Single; // 0x30
	private static object s_Double; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D44748
	public override object get_ConsumedStack() { }

	// RVA: 0x6D44750
	public override object get_ProducedStack() { }

	// RVA: 0x6D44758
	public override object get_InstructionName() { }

	// RVA: 0x6D4479C
	private object .ctor() { }

	// RVA: 0x6D447A4
	public static object Create(object type) { }

}

// Namespace: 
private sealed class MulInt16
{

	// Methods

	// RVA: 0x6D45E7C
	public override object Run(object frame) { }

	// RVA: 0x6D45E3C
	public object .ctor() { }

}

// Namespace: 
private sealed class MulInt32
{

	// Methods

	// RVA: 0x6D45FE0
	public override object Run(object frame) { }

	// RVA: 0x6D45E44
	public object .ctor() { }

}

// Namespace: 
private sealed class MulInt64
{

	// Methods

	// RVA: 0x6D46130
	public override object Run(object frame) { }

	// RVA: 0x6D45E4C
	public object .ctor() { }

}

// Namespace: 
private sealed class MulUInt16
{

	// Methods

	// RVA: 0x6D46294
	public override object Run(object frame) { }

	// RVA: 0x6D45E54
	public object .ctor() { }

}

// Namespace: 
private sealed class MulUInt32
{

	// Methods

	// RVA: 0x6D463F8
	public override object Run(object frame) { }

	// RVA: 0x6D45E5C
	public object .ctor() { }

}

// Namespace: 
private sealed class MulUInt64
{

	// Methods

	// RVA: 0x6D4655C
	public override object Run(object frame) { }

	// RVA: 0x6D45E64
	public object .ctor() { }

}

// Namespace: 
private sealed class MulSingle
{

	// Methods

	// RVA: 0x6D466C0
	public override object Run(object frame) { }

	// RVA: 0x6D45E6C
	public object .ctor() { }

}

// Namespace: 
private sealed class MulDouble
{

	// Methods

	// RVA: 0x6D4682C
	public override object Run(object frame) { }

	// RVA: 0x6D45E74
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class MulInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28
	private static object s_Single; // 0x30
	private static object s_Double; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4597C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D45984
	public override object get_ProducedStack() { }

	// RVA: 0x6D4598C
	public override object get_InstructionName() { }

	// RVA: 0x6D459D0
	private object .ctor() { }

	// RVA: 0x6D459D8
	public static object Create(object type) { }

}

// Namespace: 
private sealed class MulOvfInt16
{

	// Methods

	// RVA: 0x6D46D98
	public override object Run(object frame) { }

	// RVA: 0x6D46D68
	public object .ctor() { }

}

// Namespace: 
private sealed class MulOvfInt32
{

	// Methods

	// RVA: 0x6D47000
	public override object Run(object frame) { }

	// RVA: 0x6D46D70
	public object .ctor() { }

}

// Namespace: 
private sealed class MulOvfInt64
{

	// Methods

	// RVA: 0x6D47230
	public override object Run(object frame) { }

	// RVA: 0x6D46D78
	public object .ctor() { }

}

// Namespace: 
private sealed class MulOvfUInt16
{

	// Methods

	// RVA: 0x6D47448
	public override object Run(object frame) { }

	// RVA: 0x6D46D80
	public object .ctor() { }

}

// Namespace: 
private sealed class MulOvfUInt32
{

	// Methods

	// RVA: 0x6D476C4
	public override object Run(object frame) { }

	// RVA: 0x6D46D88
	public object .ctor() { }

}

// Namespace: 
private sealed class MulOvfUInt64
{

	// Methods

	// RVA: 0x6D478AC
	public override object Run(object frame) { }

	// RVA: 0x6D46D90
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class MulOvfInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D46998
	public override object get_ConsumedStack() { }

	// RVA: 0x6D469A0
	public override object get_ProducedStack() { }

	// RVA: 0x6D469A8
	public override object get_InstructionName() { }

	// RVA: 0x6D469EC
	private object .ctor() { }

	// RVA: 0x6D469F4
	public static object Create(object type) { }

}

// Namespace: 
private sealed class NegateInt16
{

	// Methods

	// RVA: 0x6D47E30
	public override object Run(object frame) { }

	// RVA: 0x6D47E08
	public object .ctor() { }

}

// Namespace: 
private sealed class NegateInt32
{

	// Methods

	// RVA: 0x6D47EF0
	public override object Run(object frame) { }

	// RVA: 0x6D47E10
	public object .ctor() { }

}

// Namespace: 
private sealed class NegateInt64
{

	// Methods

	// RVA: 0x6D47FAC
	public override object Run(object frame) { }

	// RVA: 0x6D47E18
	public object .ctor() { }

}

// Namespace: 
private sealed class NegateSingle
{

	// Methods

	// RVA: 0x6D48070
	public override object Run(object frame) { }

	// RVA: 0x6D47E20
	public object .ctor() { }

}

// Namespace: 
private sealed class NegateDouble
{

	// Methods

	// RVA: 0x6D48134
	public override object Run(object frame) { }

	// RVA: 0x6D47E28
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NegateInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_Single; // 0x18
	private static object s_Double; // 0x20

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D47A90
	public override object get_ConsumedStack() { }

	// RVA: 0x6D47A98
	public override object get_ProducedStack() { }

	// RVA: 0x6D47AA0
	public override object get_InstructionName() { }

	// RVA: 0x6D47AE4
	private object .ctor() { }

	// RVA: 0x6D47AEC
	public static object Create(object type) { }

}

// Namespace: 
private sealed class NegateCheckedInt32
{

	// Methods

	// RVA: 0x6D484A0
	public override object Run(object frame) { }

	// RVA: 0x6D48490
	public object .ctor() { }

}

// Namespace: 
private sealed class NegateCheckedInt16
{

	// Methods

	// RVA: 0x6D485E4
	public override object Run(object frame) { }

	// RVA: 0x6D48488
	public object .ctor() { }

}

// Namespace: 
private sealed class NegateCheckedInt64
{

	// Methods

	// RVA: 0x6D48748
	public override object Run(object frame) { }

	// RVA: 0x6D48498
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NegateCheckedInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D481F8
	public override object get_ConsumedStack() { }

	// RVA: 0x6D48200
	public override object get_ProducedStack() { }

	// RVA: 0x6D48208
	public override object get_InstructionName() { }

	// RVA: 0x6D4824C
	private object .ctor() { }

	// RVA: 0x6D48254
	public static object Create(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class NewInstruction
{

	// Fields
	protected readonly object _constructor; // 0x8
	protected readonly object _argumentCount; // 0x10

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D48874
	public object .ctor(object constructor, object argumentCount) { }

	// RVA: 0x6D488B0
	public override object get_ConsumedStack() { }

	// RVA: 0x6D488B8
	public override object get_ProducedStack() { }

	// RVA: 0x6D488C0
	public override object get_InstructionName() { }

	// RVA: 0x6D48904
	public override object Run(object frame) { }

	// RVA: 0x6D48A78
	protected object GetArgs(object frame, object first) { }

	// RVA: 0x6D48C7C
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class ByRefNewInstruction
{

	// Fields
	private readonly object _byrefArgs; // 0x18

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D48E30
	internal object .ctor(object target, object argumentCount, object byrefArgs) { }

	// RVA: 0x6D48E74
	public override object get_InstructionName() { }

	// RVA: 0x6D48EB8
	public sealed override object Run(object frame) { }

}

// Namespace: 
private sealed class NotEqualBoolean
{

	// Methods

	// RVA: 0x6D49DD8
	public override object Run(object frame) { }

	// RVA: 0x6D49D70
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualSByte
{

	// Methods

	// RVA: 0x6D49ED0
	public override object Run(object frame) { }

	// RVA: 0x6D49D78
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt16
{

	// Methods

	// RVA: 0x6D49FC8
	public override object Run(object frame) { }

	// RVA: 0x6D49D80
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualChar
{

	// Methods

	// RVA: 0x6D4A0C0
	public override object Run(object frame) { }

	// RVA: 0x6D49D88
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt32
{

	// Methods

	// RVA: 0x6D4A1B8
	public override object Run(object frame) { }

	// RVA: 0x6D49D90
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt64
{

	// Methods

	// RVA: 0x6D4A2B0
	public override object Run(object frame) { }

	// RVA: 0x6D49D98
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualByte
{

	// Methods

	// RVA: 0x6D4A3A8
	public override object Run(object frame) { }

	// RVA: 0x6D49DA0
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt16
{

	// Methods

	// RVA: 0x6D4A4A0
	public override object Run(object frame) { }

	// RVA: 0x6D49DA8
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt32
{

	// Methods

	// RVA: 0x6D4A598
	public override object Run(object frame) { }

	// RVA: 0x6D49DB0
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt64
{

	// Methods

	// RVA: 0x6D4A690
	public override object Run(object frame) { }

	// RVA: 0x6D49DB8
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualSingle
{

	// Methods

	// RVA: 0x6D4A788
	public override object Run(object frame) { }

	// RVA: 0x6D49DC0
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualDouble
{

	// Methods

	// RVA: 0x6D4A888
	public override object Run(object frame) { }

	// RVA: 0x6D49DC8
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualReference
{

	// Methods

	// RVA: 0x6D4A988
	public override object Run(object frame) { }

	// RVA: 0x6D49DD0
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualSByteLiftedToNull
{

	// Methods

	// RVA: 0x6D4A9E8
	public override object Run(object frame) { }

	// RVA: 0x6D49D18
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt16LiftedToNull
{

	// Methods

	// RVA: 0x6D4AAF4
	public override object Run(object frame) { }

	// RVA: 0x6D49D20
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualCharLiftedToNull
{

	// Methods

	// RVA: 0x6D4AC00
	public override object Run(object frame) { }

	// RVA: 0x6D49D28
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt32LiftedToNull
{

	// Methods

	// RVA: 0x6D4AD0C
	public override object Run(object frame) { }

	// RVA: 0x6D49D30
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualInt64LiftedToNull
{

	// Methods

	// RVA: 0x6D4AE18
	public override object Run(object frame) { }

	// RVA: 0x6D49D38
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualByteLiftedToNull
{

	// Methods

	// RVA: 0x6D4AF24
	public override object Run(object frame) { }

	// RVA: 0x6D49D40
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt16LiftedToNull
{

	// Methods

	// RVA: 0x6D4B030
	public override object Run(object frame) { }

	// RVA: 0x6D49D48
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt32LiftedToNull
{

	// Methods

	// RVA: 0x6D4B13C
	public override object Run(object frame) { }

	// RVA: 0x6D49D50
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualUInt64LiftedToNull
{

	// Methods

	// RVA: 0x6D4B248
	public override object Run(object frame) { }

	// RVA: 0x6D49D58
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualSingleLiftedToNull
{

	// Methods

	// RVA: 0x6D4B354
	public override object Run(object frame) { }

	// RVA: 0x6D49D60
	public object .ctor() { }

}

// Namespace: 
private sealed class NotEqualDoubleLiftedToNull
{

	// Methods

	// RVA: 0x6D4B46C
	public override object Run(object frame) { }

	// RVA: 0x6D49D68
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NotEqualInstruction
{

	// Fields
	private static object s_reference; // 0x0
	private static object s_Boolean; // 0x8
	private static object s_SByte; // 0x10
	private static object s_Int16; // 0x18
	private static object s_Char; // 0x20
	private static object s_Int32; // 0x28
	private static object s_Int64; // 0x30
	private static object s_Byte; // 0x38
	private static object s_UInt16; // 0x40
	private static object s_UInt32; // 0x48
	private static object s_UInt64; // 0x50
	private static object s_Single; // 0x58
	private static object s_Double; // 0x60
	private static object s_SByteLiftedToNull; // 0x68
	private static object s_Int16LiftedToNull; // 0x70
	private static object s_CharLiftedToNull; // 0x78
	private static object s_Int32LiftedToNull; // 0x80
	private static object s_Int64LiftedToNull; // 0x88
	private static object s_ByteLiftedToNull; // 0x90
	private static object s_UInt16LiftedToNull; // 0x98
	private static object s_UInt32LiftedToNull; // 0xA0
	private static object s_UInt64LiftedToNull; // 0xA8
	private static object s_SingleLiftedToNull; // 0xB0
	private static object s_DoubleLiftedToNull; // 0xB8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D49238
	public override object get_ConsumedStack() { }

	// RVA: 0x6D49240
	public override object get_ProducedStack() { }

	// RVA: 0x6D49248
	public override object get_InstructionName() { }

	// RVA: 0x6D4928C
	private object .ctor() { }

	// RVA: 0x6D49294
	public static object Create(object type, object liftedToNull) { }

}

// Namespace: 
private sealed class NotBoolean
{

	// Methods

	// RVA: 0x6D4BAF4
	public override object Run(object frame) { }

	// RVA: 0x6D4BAAC
	public object .ctor() { }

}

// Namespace: 
private sealed class NotInt64
{

	// Methods

	// RVA: 0x6D4BBB4
	public override object Run(object frame) { }

	// RVA: 0x6D4BAB4
	public object .ctor() { }

}

// Namespace: 
private sealed class NotInt32
{

	// Methods

	// RVA: 0x6D4BC78
	public override object Run(object frame) { }

	// RVA: 0x6D4BABC
	public object .ctor() { }

}

// Namespace: 
private sealed class NotInt16
{

	// Methods

	// RVA: 0x6D4BD34
	public override object Run(object frame) { }

	// RVA: 0x6D4BAC4
	public object .ctor() { }

}

// Namespace: 
private sealed class NotUInt64
{

	// Methods

	// RVA: 0x6D4BDF4
	public override object Run(object frame) { }

	// RVA: 0x6D4BACC
	public object .ctor() { }

}

// Namespace: 
private sealed class NotUInt32
{

	// Methods

	// RVA: 0x6D4BEB8
	public override object Run(object frame) { }

	// RVA: 0x6D4BAD4
	public object .ctor() { }

}

// Namespace: 
private sealed class NotUInt16
{

	// Methods

	// RVA: 0x6D4BF7C
	public override object Run(object frame) { }

	// RVA: 0x6D4BADC
	public object .ctor() { }

}

// Namespace: 
private sealed class NotByte
{

	// Methods

	// RVA: 0x6D4C038
	public override object Run(object frame) { }

	// RVA: 0x6D4BAE4
	public object .ctor() { }

}

// Namespace: 
private sealed class NotSByte
{

	// Methods

	// RVA: 0x6D4C0F4
	public override object Run(object frame) { }

	// RVA: 0x6D4BAEC
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NotInstruction
{

	// Fields
	public static object s_Boolean; // 0x0
	public static object s_Int64; // 0x8
	public static object s_Int32; // 0x10
	public static object s_Int16; // 0x18
	public static object s_UInt64; // 0x20
	public static object s_UInt32; // 0x28
	public static object s_UInt16; // 0x30
	public static object s_Byte; // 0x38
	public static object s_SByte; // 0x40

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4B584
	private object .ctor() { }

	// RVA: 0x6D4B58C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D4B594
	public override object get_ProducedStack() { }

	// RVA: 0x6D4B59C
	public override object get_InstructionName() { }

	// RVA: 0x6D4B5E0
	public static object Create(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class NullCheckInstruction
{

	// Fields
	public static readonly object Instance; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4C1B4
	private object .ctor() { }

	// RVA: 0x6D4C1BC
	public override object get_ConsumedStack() { }

	// RVA: 0x6D4C1C4
	public override object get_ProducedStack() { }

	// RVA: 0x6D4C1CC
	public override object get_InstructionName() { }

	// RVA: 0x6D4C210
	public override object Run(object frame) { }

	// RVA: 0x6D4C280
	private static object .cctor() { }

}

// Namespace: 
internal sealed class Unchecked
{

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4C664
	public override object get_InstructionName() { }

	// RVA: 0x6D4C6A8
	public object .ctor(object from, object to, object isLiftedToNull) { }

	// RVA: 0x6D4C6E8
	protected override object Convert(object obj) { }

	// RVA: 0x6D4CB24
	private object ConvertInt32(object obj) { }

	// RVA: 0x6D4CD8C
	private object ConvertInt64(object obj) { }

	// RVA: 0x6D4D01C
	private object ConvertUInt64(object obj) { }

	// RVA: 0x6D4D2B0
	private object ConvertDouble(object obj) { }

}

// Namespace: 
internal sealed class Checked
{

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4D5D8
	public override object get_InstructionName() { }

	// RVA: 0x6D4D61C
	public object .ctor(object from, object to, object isLiftedToNull) { }

	// RVA: 0x6D4D65C
	protected override object Convert(object obj) { }

	// RVA: 0x6D4DA98
	private object ConvertInt32(object obj) { }

	// RVA: 0x6D4DD48
	private object ConvertInt64(object obj) { }

	// RVA: 0x6D4E038
	private object ConvertUInt64(object obj) { }

	// RVA: 0x6D4E328
	private object ConvertDouble(object obj) { }

}

// Namespace: 
internal sealed class ToUnderlying
{

	// Properties
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4E6E0
	public override object get_InstructionName() { }

	// RVA: 0x6D4E724
	public object .ctor(object to, object isLiftedToNull) { }

	// RVA: 0x6D4E760
	protected override object Convert(object obj) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NumericConvertInstruction
{

	// Fields
	internal readonly object _from; // 0x8
	internal readonly object _to; // 0xC
	private readonly object _isLiftedToNull; // 0x10

	// Properties
	public override object InstructionName { get; }
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }

	// Methods

	// RVA: 0x6D4C2E0
	protected object .ctor(object from, object to, object isLiftedToNull) { }

	// RVA: 0x6D4C320
	public sealed override object Run(object frame) { }

	// RVA: -1
	protected abstract object Convert(object obj) { }

	// RVA: 0x6D4C46C
	public override object get_InstructionName() { }

	// RVA: 0x6D4C4B0
	public override object get_ConsumedStack() { }

	// RVA: 0x6D4C4B8
	public override object get_ProducedStack() { }

	// RVA: 0x6D4C4C0
	public override object ToString() { }

}

// Namespace: 
private sealed class OrSByte
{

	// Methods

	// RVA: 0x6D4EF78
	public override object Run(object frame) { }

	// RVA: 0x6D4EF30
	public object .ctor() { }

}

// Namespace: 
private sealed class OrInt16
{

	// Methods

	// RVA: 0x6D4F08C
	public override object Run(object frame) { }

	// RVA: 0x6D4EF38
	public object .ctor() { }

}

// Namespace: 
private sealed class OrInt32
{

	// Methods

	// RVA: 0x6D4F1A0
	public override object Run(object frame) { }

	// RVA: 0x6D4EF40
	public object .ctor() { }

}

// Namespace: 
private sealed class OrInt64
{

	// Methods

	// RVA: 0x6D4F2B0
	public override object Run(object frame) { }

	// RVA: 0x6D4EF48
	public object .ctor() { }

}

// Namespace: 
private sealed class OrByte
{

	// Methods

	// RVA: 0x6D4F3C4
	public override object Run(object frame) { }

	// RVA: 0x6D4EF50
	public object .ctor() { }

}

// Namespace: 
private sealed class OrUInt16
{

	// Methods

	// RVA: 0x6D4F4D4
	public override object Run(object frame) { }

	// RVA: 0x6D4EF58
	public object .ctor() { }

}

// Namespace: 
private sealed class OrUInt32
{

	// Methods

	// RVA: 0x6D4F5E4
	public override object Run(object frame) { }

	// RVA: 0x6D4EF60
	public object .ctor() { }

}

// Namespace: 
private sealed class OrUInt64
{

	// Methods

	// RVA: 0x6D4F6F8
	public override object Run(object frame) { }

	// RVA: 0x6D4EF68
	public object .ctor() { }

}

// Namespace: 
private sealed class OrBoolean
{

	// Methods

	// RVA: 0x6D4F80C
	public override object Run(object frame) { }

	// RVA: 0x6D4EF70
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class OrInstruction
{

	// Fields
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Int32; // 0x10
	private static object s_Int64; // 0x18
	private static object s_Byte; // 0x20
	private static object s_UInt16; // 0x28
	private static object s_UInt32; // 0x30
	private static object s_UInt64; // 0x38
	private static object s_Boolean; // 0x40

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4EA08
	public override object get_ConsumedStack() { }

	// RVA: 0x6D4EA10
	public override object get_ProducedStack() { }

	// RVA: 0x6D4EA18
	public override object get_InstructionName() { }

	// RVA: 0x6D4EA5C
	private object .ctor() { }

	// RVA: 0x6D4EA64
	public static object Create(object type) { }

}

// Namespace: 
private sealed class RightShiftSByte
{

	// Methods

	// RVA: 0x6D4FE94
	public override object Run(object frame) { }

	// RVA: 0x6D4FE54
	public object .ctor() { }

}

// Namespace: 
private sealed class RightShiftInt16
{

	// Methods

	// RVA: 0x6D4FFB0
	public override object Run(object frame) { }

	// RVA: 0x6D4FE5C
	public object .ctor() { }

}

// Namespace: 
private sealed class RightShiftInt32
{

	// Methods

	// RVA: 0x6D500CC
	public override object Run(object frame) { }

	// RVA: 0x6D4FE64
	public object .ctor() { }

}

// Namespace: 
private sealed class RightShiftInt64
{

	// Methods

	// RVA: 0x6D501D4
	public override object Run(object frame) { }

	// RVA: 0x6D4FE6C
	public object .ctor() { }

}

// Namespace: 
private sealed class RightShiftByte
{

	// Methods

	// RVA: 0x6D502F4
	public override object Run(object frame) { }

	// RVA: 0x6D4FE74
	public object .ctor() { }

}

// Namespace: 
private sealed class RightShiftUInt16
{

	// Methods

	// RVA: 0x6D50410
	public override object Run(object frame) { }

	// RVA: 0x6D4FE7C
	public object .ctor() { }

}

// Namespace: 
private sealed class RightShiftUInt32
{

	// Methods

	// RVA: 0x6D5052C
	public override object Run(object frame) { }

	// RVA: 0x6D4FE84
	public object .ctor() { }

}

// Namespace: 
private sealed class RightShiftUInt64
{

	// Methods

	// RVA: 0x6D5064C
	public override object Run(object frame) { }

	// RVA: 0x6D4FE8C
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class RightShiftInstruction
{

	// Fields
	private static object s_SByte; // 0x0
	private static object s_Int16; // 0x8
	private static object s_Int32; // 0x10
	private static object s_Int64; // 0x18
	private static object s_Byte; // 0x20
	private static object s_UInt16; // 0x28
	private static object s_UInt32; // 0x30
	private static object s_UInt64; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D4F994
	public override object get_ConsumedStack() { }

	// RVA: 0x6D4F99C
	public override object get_ProducedStack() { }

	// RVA: 0x6D4F9A4
	public override object get_InstructionName() { }

	// RVA: 0x6D4F9E8
	private object .ctor() { }

	// RVA: 0x6D4F9F0
	public static object Create(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class RuntimeVariables
{

	// Fields
	private readonly object _boxes; // 0x8

	// Methods

	// RVA: 0x6D5076C
	private object .ctor(object boxes) { }

	// RVA: 0x6D43A18
	internal static object Create(object boxes) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadObjectInstruction
{

	// Fields
	private readonly object _value; // 0x8

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D50798
	internal object .ctor(object value) { }

	// RVA: 0x6D507C4
	public override object get_ProducedStack() { }

	// RVA: 0x6D507CC
	public override object get_InstructionName() { }

	// RVA: 0x6D50810
	public override object Run(object frame) { }

	// RVA: 0x6D508A4
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class LoadCachedObjectInstruction
{

	// Fields
	private readonly object _index; // 0x8

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D5096C
	internal object .ctor(object index) { }

	// RVA: 0x6D50998
	public override object get_ProducedStack() { }

	// RVA: 0x6D509A0
	public override object get_InstructionName() { }

	// RVA: 0x6D509E4
	public override object Run(object frame) { }

	// RVA: 0x6D50AB4
	public override object ToDebugString(object instructionIndex, object cookie, object labelIndexer, object objects) { }

	// RVA: 0x6D50C2C
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class PopInstruction
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D50CA8
	private object .ctor() { }

	// RVA: 0x6D50CB0
	public override object get_ConsumedStack() { }

	// RVA: 0x6D50CB8
	public override object get_InstructionName() { }

	// RVA: 0x6D50CFC
	public override object Run(object frame) { }

	// RVA: 0x6D50D2C
	private static object .cctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class DupInstruction
{

	// Fields
	internal static readonly object Instance; // 0x0

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D50D8C
	private object .ctor() { }

	// RVA: 0x6D50D94
	public override object get_ProducedStack() { }

	// RVA: 0x6D50D9C
	public override object get_InstructionName() { }

	// RVA: 0x6D50DE0
	public override object Run(object frame) { }

	// RVA: 0x6D50E10
	private static object .cctor() { }

}

// Namespace: 
private sealed class SubInt16
{

	// Methods

	// RVA: 0x6D51370
	public override object Run(object frame) { }

	// RVA: 0x6D51330
	public object .ctor() { }

}

// Namespace: 
private sealed class SubInt32
{

	// Methods

	// RVA: 0x6D514D4
	public override object Run(object frame) { }

	// RVA: 0x6D51338
	public object .ctor() { }

}

// Namespace: 
private sealed class SubInt64
{

	// Methods

	// RVA: 0x6D51624
	public override object Run(object frame) { }

	// RVA: 0x6D51340
	public object .ctor() { }

}

// Namespace: 
private sealed class SubUInt16
{

	// Methods

	// RVA: 0x6D51788
	public override object Run(object frame) { }

	// RVA: 0x6D51348
	public object .ctor() { }

}

// Namespace: 
private sealed class SubUInt32
{

	// Methods

	// RVA: 0x6D518EC
	public override object Run(object frame) { }

	// RVA: 0x6D51350
	public object .ctor() { }

}

// Namespace: 
private sealed class SubUInt64
{

	// Methods

	// RVA: 0x6D51A50
	public override object Run(object frame) { }

	// RVA: 0x6D51358
	public object .ctor() { }

}

// Namespace: 
private sealed class SubSingle
{

	// Methods

	// RVA: 0x6D51BB4
	public override object Run(object frame) { }

	// RVA: 0x6D51360
	public object .ctor() { }

}

// Namespace: 
private sealed class SubDouble
{

	// Methods

	// RVA: 0x6D51D20
	public override object Run(object frame) { }

	// RVA: 0x6D51368
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class SubInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28
	private static object s_Single; // 0x30
	private static object s_Double; // 0x38

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D50E70
	public override object get_ConsumedStack() { }

	// RVA: 0x6D50E78
	public override object get_ProducedStack() { }

	// RVA: 0x6D50E80
	public override object get_InstructionName() { }

	// RVA: 0x6D50EC4
	private object .ctor() { }

	// RVA: 0x6D50ECC
	public static object Create(object type) { }

}

// Namespace: 
private sealed class SubOvfInt16
{

	// Methods

	// RVA: 0x6D5228C
	public override object Run(object frame) { }

	// RVA: 0x6D5225C
	public object .ctor() { }

}

// Namespace: 
private sealed class SubOvfInt32
{

	// Methods

	// RVA: 0x6D524F4
	public override object Run(object frame) { }

	// RVA: 0x6D52264
	public object .ctor() { }

}

// Namespace: 
private sealed class SubOvfInt64
{

	// Methods

	// RVA: 0x6D52724
	public override object Run(object frame) { }

	// RVA: 0x6D5226C
	public object .ctor() { }

}

// Namespace: 
private sealed class SubOvfUInt16
{

	// Methods

	// RVA: 0x6D52924
	public override object Run(object frame) { }

	// RVA: 0x6D52274
	public object .ctor() { }

}

// Namespace: 
private sealed class SubOvfUInt32
{

	// Methods

	// RVA: 0x6D52B5C
	public override object Run(object frame) { }

	// RVA: 0x6D5227C
	public object .ctor() { }

}

// Namespace: 
private sealed class SubOvfUInt64
{

	// Methods

	// RVA: 0x6D52D44
	public override object Run(object frame) { }

	// RVA: 0x6D52284
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class SubOvfInstruction
{

	// Fields
	private static object s_Int16; // 0x0
	private static object s_Int32; // 0x8
	private static object s_Int64; // 0x10
	private static object s_UInt16; // 0x18
	private static object s_UInt32; // 0x20
	private static object s_UInt64; // 0x28

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D51E8C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D51E94
	public override object get_ProducedStack() { }

	// RVA: 0x6D51E9C
	public override object get_InstructionName() { }

	// RVA: 0x6D51EE0
	private object .ctor() { }

	// RVA: 0x6D51EE8
	public static object Create(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class CreateDelegateInstruction
{

	// Fields
	private readonly object _creator; // 0x8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D52F28
	internal object .ctor(object delegateCreator) { }

	// RVA: 0x6D52F54
	public override object get_ConsumedStack() { }

	// RVA: 0x6D52F90
	public override object get_ProducedStack() { }

	// RVA: 0x6D52F98
	public override object get_InstructionName() { }

	// RVA: 0x6D52FDC
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TypeIsInstruction
{

	// Fields
	private readonly object _type; // 0x8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D531A8
	internal object .ctor(object type) { }

	// RVA: 0x6D531D4
	public override object get_ConsumedStack() { }

	// RVA: 0x6D531DC
	public override object get_ProducedStack() { }

	// RVA: 0x6D531E4
	public override object get_InstructionName() { }

	// RVA: 0x6D53228
	public override object Run(object frame) { }

	// RVA: 0x6D532C0
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TypeAsInstruction
{

	// Fields
	private readonly object _type; // 0x8

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D53348
	internal object .ctor(object type) { }

	// RVA: 0x6D53374
	public override object get_ConsumedStack() { }

	// RVA: 0x6D5337C
	public override object get_ProducedStack() { }

	// RVA: 0x6D53384
	public override object get_InstructionName() { }

	// RVA: 0x6D533C8
	public override object Run(object frame) { }

	// RVA: 0x6D53468
	public override object ToString() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class TypeEqualsInstruction
{

	// Fields
	public static readonly object Instance; // 0x0

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D534F0
	public override object get_ConsumedStack() { }

	// RVA: 0x6D534F8
	public override object get_ProducedStack() { }

	// RVA: 0x6D53500
	public override object get_InstructionName() { }

	// RVA: 0x6D53544
	private object .ctor() { }

	// RVA: 0x6D5354C
	public override object Run(object frame) { }

	// RVA: 0x6D535B8
	private static object .cctor() { }

}

// Namespace: 
private sealed class HasValue
{

	// Methods

	// RVA: 0x6D53B88
	public override object Run(object frame) { }

	// RVA: 0x6D53A50
	public object .ctor() { }

}

// Namespace: 
private sealed class GetValue
{

	// Methods

	// RVA: 0x6D53BD8
	public override object Run(object frame) { }

	// RVA: 0x6D53A58
	public object .ctor() { }

}

// Namespace: 
private sealed class GetValueOrDefault
{

	// Fields
	private readonly object _defaultValueType; // 0x8

	// Methods

	// RVA: 0x6D53A70
	public object .ctor(object mi) { }

	// RVA: 0x6D53C68
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class GetValueOrDefault1
{

	// Properties
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D53CE4
	public override object get_ConsumedStack() { }

	// RVA: 0x6D53CEC
	public override object Run(object frame) { }

	// RVA: 0x6D53AD4
	public object .ctor() { }

}

// Namespace: 
private sealed class EqualsClass
{

	// Properties
	public override object ConsumedStack { get; }

	// Methods

	// RVA: 0x6D53D4C
	public override object get_ConsumedStack() { }

	// RVA: 0x6D53D54
	public override object Run(object frame) { }

	// RVA: 0x6D53A60
	public object .ctor() { }

}

// Namespace: 
private sealed class ToStringClass
{

	// Methods

	// RVA: 0x6D53E60
	public override object Run(object frame) { }

	// RVA: 0x6D53ADC
	public object .ctor() { }

}

// Namespace: 
private sealed class GetHashCodeClass
{

	// Methods

	// RVA: 0x6D53F0C
	public override object Run(object frame) { }

	// RVA: 0x6D53A68
	public object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class NullableMethodCallInstruction
{

	// Fields
	private static object s_hasValue; // 0x0
	private static object s_value; // 0x8
	private static object s_equals; // 0x10
	private static object s_getHashCode; // 0x18
	private static object s_getValueOrDefault1; // 0x20
	private static object s_toString; // 0x28

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D53618
	public override object get_ConsumedStack() { }

	// RVA: 0x6D53620
	public override object get_ProducedStack() { }

	// RVA: 0x6D53628
	public override object get_InstructionName() { }

	// RVA: 0x6D5366C
	private object .ctor() { }

	// RVA: 0x6D53674
	public static object Create(object method, object argCount, object mi) { }

	// RVA: 0x6D53AE4
	public static object CreateGetValue() { }

}

// Namespace: 
private sealed class CastInstructionT<T0>
{

	// Methods

	// RVA: -1
	public override object Run(object frame) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class Ref
{

	// Methods

	// RVA: 0x6D548B0
	public object .ctor(object t) { }

	// RVA: 0x6D54A98
	protected override object ConvertNull(object frame) { }

}

// Namespace: 
private sealed class Value
{

	// Methods

	// RVA: 0x6D54884
	public object .ctor(object t) { }

	// RVA: 0x6D54AC0
	protected override object ConvertNull(object frame) { }

}

// Namespace: 
private abstract class CastInstructionNoT
{

	// Fields
	private readonly object _t; // 0x8

	// Methods

	// RVA: 0x6D54858
	protected object .ctor(object t) { }

	// RVA: 0x6D54774
	public static object Create(object t) { }

	// RVA: 0x6D548DC
	public override object Run(object frame) { }

	// RVA: -1
	protected abstract object ConvertNull(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal abstract class CastInstruction
{

	// Fields
	private static object s_Boolean; // 0x0
	private static object s_Byte; // 0x8
	private static object s_Char; // 0x10
	private static object s_DateTime; // 0x18
	private static object s_Decimal; // 0x20
	private static object s_Double; // 0x28
	private static object s_Int16; // 0x30
	private static object s_Int32; // 0x38
	private static object s_Int64; // 0x40
	private static object s_SByte; // 0x48
	private static object s_Single; // 0x50
	private static object s_String; // 0x58
	private static object s_UInt16; // 0x60
	private static object s_UInt32; // 0x68
	private static object s_UInt64; // 0x70

	// Properties
	public override object ConsumedStack { get; }
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D53F90
	public override object get_ConsumedStack() { }

	// RVA: 0x6D53F98
	public override object get_ProducedStack() { }

	// RVA: 0x6D53FA0
	public override object get_InstructionName() { }

	// RVA: 0x6D53FE4
	public static object Create(object t) { }

	// RVA: 0x6D54850
	protected object .ctor() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class CastToEnumInstruction
{

	// Fields
	private readonly object _t; // 0x8

	// Methods

	// RVA: 0x6D54B00
	public object .ctor(object t) { }

	// RVA: 0x6D54B2C
	public override object Run(object frame) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class CastReferenceToEnumInstruction
{

	// Fields
	private readonly object _t; // 0x8

	// Methods

	// RVA: 0x6D54BE0
	public object .ctor(object t) { }

	// RVA: 0x6D54C0C
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class ExpressionQuoter
{

	// Fields
	private readonly object _variables; // 0x8
	private readonly object _frame; // 0x10
	private readonly object _shadowedVars; // 0x18

	// Methods

	// RVA: 0x6D552D4
	internal object .ctor(object hoistedVariables, object frame) { }

	// RVA: -1
	protected internal override object VisitLambda(object node) { }

	// RVA: 0x6D5536C
	protected internal override object VisitBlock(object node) { }

	// RVA: 0x6D5555C
	protected override object VisitCatchBlock(object node) { }

	// RVA: 0x6D55770
	protected internal override object VisitParameter(object node) { }

	// RVA: 0x6D55870
	private object GetBox(object variable) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal sealed class QuoteInstruction
{

	// Fields
	private readonly object _operand; // 0x8
	private readonly object _hoistedVariables; // 0x10

	// Properties
	public override object ProducedStack { get; }
	public override object InstructionName { get; }

	// Methods

	// RVA: 0x6D55128
	public object .ctor(object operand, object hoistedVariables) { }

	// RVA: 0x6D55160
	public override object get_ProducedStack() { }

	// RVA: 0x6D55168
	public override object get_InstructionName() { }

	// RVA: 0x6D551AC
	public override object Run(object frame) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__1_0; // 0x8

	// Methods

	// RVA: 0x6D559F4
	private static object .cctor() { }

	// RVA: 0x6D55A54
	public object .ctor() { }

	// RVA: 0x6D55A5C
	internal object <MakeDelegate>b__1_0(object t) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal static class DelegateHelpers
{

	// Methods

	// RVA: 0x6D3EA60
	internal static object MakeDelegate(object types) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal static class ScriptingRuntimeHelpers
{

	// Methods

	// RVA: 0x6D44F04
	public static object Int32ToObject(object i) { }

	// RVA: 0x6D55A80
	internal static object GetPrimitiveDefaultValue(object type) { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal static class ExceptionHelpers
{

	// Methods

	// RVA: 0x6D3D1B4
	public static object UnwrapAndRethrow(object exception) { }

}

// Namespace: 
private sealed class <GetEnumeratorWorker>d__7
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	public object <>4__this; // 0x0
	private object <i>5__2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey,TValue>>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<TKey,TValue>>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Linq.Expressions.Interpreter
internal class HybridReferenceDictionary<T0, T1>
{

	// Fields
	private object _keysAndValues; // 0x0
	private object _dict; // 0x0

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: -1
	public object TryGetValue(object key, object value) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object GetEnumeratorWorker() { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: System.Runtime.CompilerServices
public static class RuntimeOps
{

	// Methods

	// RVA: 0x6D55E2C
	public static object ExpandoTryGetValue(object expando, object indexClass, object index, object name, object ignoreCase, object value) { }

	// RVA: 0x6D55FD4
	public static object ExpandoTrySetValue(object expando, object indexClass, object index, object value, object name, object ignoreCase) { }

	// RVA: 0x6D56568
	public static object ExpandoTryDeleteValue(object expando, object indexClass, object index, object name, object ignoreCase) { }

	// RVA: 0x6D56A20
	public static object ExpandoCheckVersion(object expando, object version) { }

	// RVA: 0x6D56A78
	public static object ExpandoPromoteClass(object expando, object oldClass, object newClass) { }

}

// Namespace: System.Runtime.CompilerServices
public class CallSite
{

	// Fields
	internal readonly object _binder; // 0x8
	internal object _match; // 0x10

	// Properties
	public object Binder { get; }

	// Methods

	// RVA: 0x6D56C50
	internal object .ctor(object binder) { }

	// RVA: 0x6D56C7C
	public object get_Binder() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__20_0; // 0x0
	public static object <>9__20_1; // 0x0
	public static object <>9__21_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateCustomUpdateDelegate>b__20_0(object p) { }

	// RVA: -1
	internal object <CreateCustomUpdateDelegate>b__20_1(object p) { }

	// RVA: -1
	internal object <CreateCustomNoMatchDelegate>b__21_0(object p) { }

}

// Namespace: System.Runtime.CompilerServices
public class CallSite<T0>
{

	// Fields
	public object Target; // 0x0
	internal object Rules; // 0x0
	private static object s_cachedUpdate; // 0x0
	private static object s_cachedNoMatch; // 0x0

	// Properties
	public object Update { get; }

	// Methods

	// RVA: -1
	public object get_Update() { }

	// RVA: -1
	private object .ctor(object binder) { }

	// RVA: -1
	private object .ctor() { }

	// RVA: -1
	internal object CreateMatchMaker() { }

	// RVA: -1
	public static object Create(object binder) { }

	// RVA: -1
	private object GetUpdateDelegate() { }

	// RVA: -1
	private object GetUpdateDelegate(object addr) { }

	// RVA: -1
	internal object AddRule(object newRule) { }

	// RVA: -1
	internal object MoveRule(object i) { }

	// RVA: -1
	internal object MakeUpdateDelegate() { }

	// RVA: -1
	private object CreateCustomUpdateDelegate(object invoke) { }

	// RVA: -1
	private object CreateCustomNoMatchDelegate(object invoke) { }

	// RVA: -1
	private static object Convert(object arg, object type) { }

}

// Namespace: 
private sealed class LambdaSignature<T0>
{

	// Fields
	private static object s_instance; // 0x0
	internal readonly object Parameters; // 0x0
	internal readonly object ReturnLabel; // 0x0

	// Properties
	internal static object Instance { get; }

	// Methods

	// RVA: -1
	internal static object get_Instance() { }

	// RVA: -1
	private object .ctor() { }

}

// Namespace: System.Runtime.CompilerServices
public abstract class CallSiteBinder
{

	// Fields
	internal object Cache; // 0x8
	private static readonly object <UpdateLabel>k__BackingField; // 0x0

	// Properties
	public static object UpdateLabel { get; }

	// Methods

	// RVA: 0x6D56C84
	protected object .ctor() { }

	// RVA: 0x6D56C8C
	public static object get_UpdateLabel() { }

	// RVA: -1
	public abstract object Bind(object args, object parameters, object returnLabel) { }

	// RVA: -1
	public virtual object BindDelegate(object site, object args) { }

	// RVA: -1
	internal object BindCore(object site, object args) { }

	// RVA: -1
	protected object CacheTarget(object target) { }

	// RVA: -1
	private static object Stitch(object binding, object signature) { }

	// RVA: -1
	internal object GetRuleCache() { }

	// RVA: 0x6D56D08
	private static object .cctor() { }

}

// Namespace: System.Runtime.CompilerServices
public static class CallSiteOps
{

	// Methods

	// RVA: -1
	public static object CreateMatchmaker(object site) { }

	// RVA: 0x6D56DA0
	public static object SetNotMatched(object site) { }

	// RVA: 0x6D56DC8
	public static object GetMatch(object site) { }

	// RVA: 0x6D56DE8
	public static object ClearMatch(object site) { }

	// RVA: -1
	public static object AddRule(object site, object rule) { }

	// RVA: -1
	public static object UpdateRules(object this, object matched) { }

	// RVA: -1
	public static object GetRules(object site) { }

	// RVA: -1
	public static object GetRuleCache(object site) { }

	// RVA: -1
	public static object MoveRule(object cache, object rule, object i) { }

	// RVA: -1
	public static object GetCachedRules(object cache) { }

	// RVA: -1
	public static object Bind(object binder, object site, object args) { }

}

// Namespace: System.Runtime.CompilerServices
public interface IRuntimeVariables
{
}

// Namespace: 
private class Enumerator
{

	// Fields
	private readonly object _builder; // 0x0
	private readonly object _version; // 0x0
	private object _index; // 0x0
	private object _current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object builder) { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: System.Runtime.CompilerServices
public sealed class ReadOnlyCollectionBuilder<T0>
{

	// Fields
	private object _items; // 0x0
	private object _size; // 0x0
	private object _version; // 0x0

	// Properties
	public object Capacity { set; }
	public object Count { get; }
	public object Item { get; set; }
	private object System.Collections.Generic.ICollection<T>.IsReadOnly { get; }
	private object System.Collections.IList.IsReadOnly { get; }
	private object System.Collections.IList.IsFixedSize { get; }
	private object System.Collections.IList.Item { get; set; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object set_Capacity(object value) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object IndexOf(object item) { }

	// RVA: -1
	public object Insert(object index, object item) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IList.get_IsReadOnly() { }

	// RVA: -1
	private object System.Collections.IList.Add(object value) { }

	// RVA: -1
	private object System.Collections.IList.Contains(object value) { }

	// RVA: -1
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: -1
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: -1
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: -1
	private object System.Collections.IList.Remove(object value) { }

	// RVA: -1
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: -1
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	public object ToArray() { }

	// RVA: -1
	public object ToReadOnlyCollection() { }

	// RVA: -1
	private object EnsureCapacity(object min) { }

	// RVA: -1
	private static object IsCompatibleObject(object value) { }

	// RVA: -1
	private static object ValidateNullValue(object value, object argument) { }

}

// Namespace: System.Runtime.CompilerServices
public class RuleCache<T0>
{

	// Fields
	private object _rules; // 0x0
	private readonly object _cacheLock; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor() { }

	// RVA: -1
	internal object GetRules() { }

	// RVA: -1
	internal object MoveRule(object rule, object i) { }

	// RVA: -1
	internal object AddRule(object newRule) { }

	// RVA: -1
	private static object AddOrInsert(object rules, object item) { }

}

// Namespace: System.Runtime.CompilerServices
internal sealed class TrueReadOnlyCollection<T0>
{

	// Methods

	// RVA: -1
	public object .ctor(object list) { }

}

// Namespace: System.Runtime.CompilerServices
public class StrongBox<T0>
{

	// Fields
	public object Value; // 0x0

	// Properties
	private object System.Runtime.CompilerServices.IStrongBox.Value { get; set; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object value) { }

	// RVA: -1
	private object System.Runtime.CompilerServices.IStrongBox.get_Value() { }

	// RVA: -1
	private object System.Runtime.CompilerServices.IStrongBox.set_Value(object value) { }

}

// Namespace: System.Runtime.CompilerServices
public interface IStrongBox
{

	// Properties
	public abstract object Value { get; set; }

	// Methods

	// RVA: -1
	public abstract object get_Value() { }

	// RVA: -1
	public abstract object set_Value(object value) { }

}

// Namespace: System.Dynamic
public abstract class BinaryOperationBinder
{

	// Fields
	private readonly object <Operation>k__BackingField; // 0x10

	// Properties
	public object Operation { get; }

	// Methods

	// RVA: 0x6D56E0C
	public object get_Operation() { }

	// RVA: 0x6D56E14
	public object FallbackBinaryOperation(object target, object arg) { }

	// RVA: -1
	public abstract object FallbackBinaryOperation(object target, object arg, object errorSuggestion) { }

	// RVA: 0x6D56E70
	public sealed override object Bind(object target, object args) { }

}

// Namespace: 
private struct AndNode
{

	// Fields
	internal object Depth; // 0xFFFFFFFFFFFFFFF8
	internal object Node; // 0x0
}

// Namespace: 
private sealed class TestBuilder
{

	// Fields
	private readonly object _unique; // 0x8
	private readonly object _tests; // 0x10

	// Methods

	// RVA: 0x6D57950
	internal object Append(object restrictions) { }

	// RVA: 0x6D57B68
	internal object ToExpression() { }

	// RVA: 0x6D57A14
	private object Push(object node, object depth) { }

	// RVA: 0x6D57C60
	public object .ctor() { }

}

// Namespace: 
private sealed class MergedRestriction
{

	// Fields
	internal readonly object Left; // 0x8
	internal readonly object Right; // 0x10

	// Methods

	// RVA: 0x6D57100
	internal object .ctor(object left, object right) { }

	// RVA: 0x6D57D64
	internal override object GetExpression() { }

}

// Namespace: 
private sealed class CustomRestriction
{

	// Fields
	private readonly object _expression; // 0x8

	// Methods

	// RVA: 0x6D578E0
	internal object .ctor(object expression) { }

	// RVA: 0x6D57F5C
	public override object Equals(object obj) { }

	// RVA: 0x6D57FD8
	public override object GetHashCode() { }

	// RVA: 0x6D58034
	internal override object GetExpression() { }

}

// Namespace: 
private sealed class TypeRestriction
{

	// Fields
	private readonly object _expression; // 0x8
	private readonly object _type; // 0x10

	// Methods

	// RVA: 0x6D57274
	internal object .ctor(object parameter, object type) { }

	// RVA: 0x6D5803C
	public override object Equals(object obj) { }

	// RVA: 0x6D58110
	public override object GetHashCode() { }

	// RVA: 0x6D581B0
	internal override object GetExpression() { }

}

// Namespace: 
private sealed class InstanceRestriction
{

	// Fields
	private readonly object _expression; // 0x8
	private readonly object _instance; // 0x10

	// Methods

	// RVA: 0x6D57734
	internal object .ctor(object parameter, object instance) { }

	// RVA: 0x6D5821C
	public override object Equals(object obj) { }

	// RVA: 0x6D582DC
	public override object GetHashCode() { }

	// RVA: 0x6D58350
	internal override object GetExpression() { }

}

// Namespace: 
private sealed class BindingRestrictionsProxy
{
}

// Namespace: System.Dynamic
public abstract class BindingRestrictions
{

	// Fields
	public static readonly object Empty; // 0x0

	// Methods

	// RVA: 0x6D56F84
	private object .ctor() { }

	// RVA: -1
	internal abstract object GetExpression() { }

	// RVA: 0x6D56F8C
	public object Merge(object restrictions) { }

	// RVA: 0x6D5717C
	public static object GetTypeRestriction(object expression, object type) { }

	// RVA: 0x6D572F0
	internal static object GetTypeRestriction(object obj) { }

	// RVA: 0x6D575FC
	public static object GetInstanceRestriction(object expression, object instance) { }

	// RVA: 0x6D577B0
	public object ToExpression() { }

	// RVA: 0x6D577F0
	private static object .cctor() { }

}

// Namespace: System.Dynamic
public abstract class ConvertBinder
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x10

	// Properties
	public object Type { get; }

	// Methods

	// RVA: 0x6D586DC
	public object get_Type() { }

	// RVA: 0x6D586E4
	public object FallbackConvert(object target) { }

	// RVA: -1
	public abstract object FallbackConvert(object target, object errorSuggestion) { }

	// RVA: 0x6D58730
	public sealed override object Bind(object target, object args) { }

}

// Namespace: System.Dynamic
public abstract class CreateInstanceBinder
{

	// Methods

	// RVA: 0x6D58814
	public object FallbackCreateInstance(object target, object args) { }

	// RVA: -1
	public abstract object FallbackCreateInstance(object target, object args, object errorSuggestion) { }

	// RVA: 0x6D58870
	public sealed override object Bind(object target, object args) { }

}

// Namespace: System.Dynamic
public abstract class DeleteIndexBinder
{

	// Methods

	// RVA: 0x6D58958
	public sealed override object Bind(object target, object args) { }

	// RVA: 0x6D58A3C
	public object FallbackDeleteIndex(object target, object indexes) { }

	// RVA: -1
	public abstract object FallbackDeleteIndex(object target, object indexes, object errorSuggestion) { }

}

// Namespace: System.Dynamic
public abstract class DeleteMemberBinder
{

	// Fields
	private readonly object <Name>k__BackingField; // 0x10
	private readonly object <IgnoreCase>k__BackingField; // 0x18

	// Properties
	public object Name { get; }
	public object IgnoreCase { get; }

	// Methods

	// RVA: 0x6D58A98
	public object get_Name() { }

	// RVA: 0x6D58AA0
	public object get_IgnoreCase() { }

	// RVA: 0x6D58AA8
	public object FallbackDeleteMember(object target) { }

	// RVA: -1
	public abstract object FallbackDeleteMember(object target, object errorSuggestion) { }

	// RVA: 0x6D58AF4
	public sealed override object Bind(object target, object args) { }

}

// Namespace: System.Dynamic
public class DynamicMetaObject
{

	// Fields
	public static readonly object EmptyMetaObjects; // 0x0
	private static readonly object s_noValueSentinel; // 0x8
	private readonly object _value; // 0x8
	private readonly object <Expression>k__BackingField; // 0x10
	private readonly object <Restrictions>k__BackingField; // 0x18

	// Properties
	public object Expression { get; }
	public object Restrictions { get; }
	public object Value { get; }
	public object HasValue { get; }
	public object RuntimeType { get; }
	public object LimitType { get; }

	// Methods

	// RVA: 0x6D58BD8
	public object .ctor(object expression, object restrictions) { }

	// RVA: 0x6D58CAC
	public object .ctor(object expression, object restrictions, object value) { }

	// RVA: 0x6D58CD4
	public object get_Expression() { }

	// RVA: 0x6D58CDC
	public object get_Restrictions() { }

	// RVA: 0x6D574DC
	public object get_Value() { }

	// RVA: 0x6D57588
	public object get_HasValue() { }

	// RVA: 0x6D58CE4
	public object get_RuntimeType() { }

	// RVA: 0x6D576D0
	public object get_LimitType() { }

	// RVA: 0x6D58E60
	public virtual object BindConvert(object binder) { }

	// RVA: 0x6D58EF8
	public virtual object BindGetMember(object binder) { }

	// RVA: 0x6D58F74
	public virtual object BindSetMember(object binder, object value) { }

	// RVA: 0x6D59000
	public virtual object BindDeleteMember(object binder) { }

	// RVA: 0x6D59098
	public virtual object BindGetIndex(object binder, object indexes) { }

	// RVA: 0x6D59124
	public virtual object BindSetIndex(object binder, object indexes, object value) { }

	// RVA: 0x6D591B8
	public virtual object BindDeleteIndex(object binder, object indexes) { }

	// RVA: 0x6D59260
	public virtual object BindInvokeMember(object binder, object args) { }

	// RVA: 0x6D592EC
	public virtual object BindInvoke(object binder, object args) { }

	// RVA: 0x6D59378
	public virtual object BindCreateInstance(object binder, object args) { }

	// RVA: 0x6D59420
	public virtual object BindUnaryOperation(object binder) { }

	// RVA: 0x6D5949C
	public virtual object BindBinaryOperation(object binder, object arg) { }

	// RVA: 0x6D59544
	public virtual object GetDynamicMemberNames() { }

	// RVA: 0x6D5964C
	public static object Create(object value, object expression) { }

	// RVA: 0x6D59908
	private static object .cctor() { }

}

// Namespace: System.Dynamic
public abstract class DynamicMetaObjectBinder
{

	// Properties
	public virtual object ReturnType { get; }
	internal virtual object IsStandardBinder { get; }

	// Methods

	// RVA: 0x6D59A48
	protected object .ctor() { }

	// RVA: 0x6D59AD0
	public virtual object get_ReturnType() { }

	// RVA: 0x6D59B70
	public sealed override object Bind(object args, object parameters, object returnLabel) { }

	// RVA: 0x6D5A2E4
	private static object CreateArgumentMetaObjects(object args, object parameters) { }

	// RVA: -1
	public abstract object Bind(object target, object args) { }

	// RVA: 0x6D5A4F8
	public object GetUpdateExpression(object type) { }

	// RVA: 0x6D5A604
	internal virtual object get_IsStandardBinder() { }

}

// Namespace: System.Dynamic
internal class ExpandoClass
{

	// Fields
	private readonly object _keys; // 0x8
	private readonly object _hashCode; // 0x10
	private object _transitions; // 0x18
	internal static readonly object Empty; // 0x0

	// Properties
	internal object Keys { get; }

	// Methods

	// RVA: 0x6D5A60C
	internal object .ctor() { }

	// RVA: 0x6D5A718
	internal object .ctor(object keys, object hashCode) { }

	// RVA: 0x6D5A754
	internal object FindNewClass(object newKey) { }

	// RVA: 0x6D5AC20
	private object GetTransitionList(object hashCode) { }

	// RVA: 0x6D5AD6C
	internal object GetValueIndex(object name, object caseInsensitive, object obj) { }

	// RVA: 0x6D5AFF4
	internal object GetValueIndexCaseSensitive(object name) { }

	// RVA: 0x6D5AE08
	private object GetValueIndexCaseInsensitive(object name, object obj) { }

	// RVA: 0x6D5B140
	internal object get_Keys() { }

	// RVA: 0x6D5B148
	private static object .cctor() { }

}

// Namespace: 
private sealed class KeyCollectionDebugView
{
}

// Namespace: 
private sealed class <GetEnumerator>d__15
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <i>5__2; // 0x20
	private object <n>5__3; // 0x24

	// Properties
	private object System.Collections.Generic.IEnumerator<System.String>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6D5CF04
	public object .ctor(object <>1__state) { }

	// RVA: 0x6D5CF30
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6D5CF34
	private object MoveNext() { }

	// RVA: 0x6D5D150
	private object System.Collections.Generic.IEnumerator<System.String>.get_Current() { }

	// RVA: 0x6D5D158
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6D5D198
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private class KeyCollection
{

	// Fields
	private readonly object _expando; // 0x8
	private readonly object _expandoVersion; // 0x10
	private readonly object _expandoCount; // 0x14
	private readonly object _expandoData; // 0x18

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }

	// Methods

	// RVA: 0x6D5B4B4
	internal object .ctor(object expando) { }

	// RVA: 0x6D5C6BC
	private object CheckVersion() { }

	// RVA: 0x6D5C73C
	public object Add(object item) { }

	// RVA: 0x6D5C76C
	public object Clear() { }

	// RVA: 0x6D5C79C
	public object Contains(object item) { }

	// RVA: 0x6D5C9A0
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x6D5CD50
	public object get_Count() { }

	// RVA: 0x6D5CDD4
	public object get_IsReadOnly() { }

	// RVA: 0x6D5CDDC
	public object Remove(object item) { }

	// RVA: 0x6D5CE0C
	public object GetEnumerator() { }

	// RVA: 0x6D5CE88
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class ValueCollectionDebugView
{
}

// Namespace: 
private sealed class <GetEnumerator>d__15
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <data>5__2; // 0x20
	private object <i>5__3; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6D5DAB0
	public object .ctor(object <>1__state) { }

	// RVA: 0x6D5DB48
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6D5DB4C
	private object MoveNext() { }

	// RVA: 0x6D5DD28
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6D5DD30
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6D5DD70
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private class ValueCollection
{

	// Fields
	private readonly object _expando; // 0x8
	private readonly object _expandoVersion; // 0x10
	private readonly object _expandoCount; // 0x14
	private readonly object _expandoData; // 0x18

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }

	// Methods

	// RVA: 0x6D5D1A0
	internal object .ctor(object expando) { }

	// RVA: 0x6D5D2BC
	private object CheckVersion() { }

	// RVA: 0x6D5D33C
	public object Add(object item) { }

	// RVA: 0x6D5D36C
	public object Clear() { }

	// RVA: 0x6D5D39C
	public object Contains(object item) { }

	// RVA: 0x6D5D5BC
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x6D5D988
	public object get_Count() { }

	// RVA: 0x6D5DA0C
	public object get_IsReadOnly() { }

	// RVA: 0x6D5DA14
	public object Remove(object item) { }

	// RVA: 0x6D5DA44
	public object GetEnumerator() { }

	// RVA: 0x6D5DADC
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <>c__DisplayClass3_0
{

	// Fields
	public object binder; // 0x8
	public object args; // 0x10

	// Methods

	// RVA: 0x6D5ED98
	public object .ctor() { }

	// RVA: 0x6D5F9C0
	internal object <BindInvokeMember>b__0(object value) { }

}

// Namespace: 
private sealed class <GetDynamicMemberNames>d__6
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	private object <>l__initialThreadId; // 0x18
	public object <>4__this; // 0x20
	private object <expandoData>5__2; // 0x28
	private object <klass>5__3; // 0x30
	private object <i>5__4; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<System.String>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6D5F824
	public object .ctor(object <>1__state) { }

	// RVA: 0x6D5FA28
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6D5FA2C
	private object MoveNext() { }

	// RVA: 0x6D5FC30
	private object System.Collections.Generic.IEnumerator<System.String>.get_Current() { }

	// RVA: 0x6D5FC38
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6D5FC78
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x6D5FC80
	private object System.Collections.Generic.IEnumerable<System.String>.GetEnumerator() { }

	// RVA: 0x6D5FD2C
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private class MetaExpando
{

	// Properties
	public object Value { get; }

	// Methods

	// RVA: 0x6D5DD78
	public object .ctor(object expression, object value) { }

	// RVA: 0x6D5DE54
	private object BindGetOrInvokeMember(object binder, object name, object ignoreCase, object fallback, object fallbackInvoke) { }

	// RVA: 0x6D5EAF8
	public override object BindGetMember(object binder) { }

	// RVA: 0x6D5EC20
	public override object BindInvokeMember(object binder, object args) { }

	// RVA: 0x6D5EDFC
	public override object BindSetMember(object binder, object value) { }

	// RVA: 0x6D5F3BC
	public override object BindDeleteMember(object binder) { }

	// RVA: 0x6D5F7A8
	public override object GetDynamicMemberNames() { }

	// RVA: 0x6D5E7A8
	private object AddDynamicTestAndDefer(object binder, object klass, object originalClass, object succeeds) { }

	// RVA: 0x6D5F294
	private object GetClassEnsureIndex(object name, object caseInsensitive, object obj, object klass, object index) { }

	// RVA: 0x6D5E5D8
	private object GetLimitedSelf() { }

	// RVA: 0x6D5F85C
	private object GetRestrictions() { }

	// RVA: 0x6D5E56C
	public object get_Value() { }

}

// Namespace: 
private class ExpandoData
{

	// Fields
	internal static object Empty; // 0x0
	internal readonly object Class; // 0x8
	private readonly object _dataArray; // 0x10
	private object _version; // 0x18

	// Properties
	internal object Item { get; set; }
	internal object Version { get; }
	internal object Length { get; }

	// Methods

	// RVA: 0x6D5D114
	internal object get_Item(object index) { }

	// RVA: 0x6D5FDD8
	internal object set_Item(object index, object value) { }

	// RVA: 0x6D5FE5C
	internal object get_Version() { }

	// RVA: 0x6D5FE64
	internal object get_Length() { }

	// RVA: 0x6D5FE88
	private object .ctor() { }

	// RVA: 0x6D5FFC0
	internal object .ctor(object klass, object data, object version) { }

	// RVA: 0x6D60000
	internal object UpdateClass(object newClass) { }

	// RVA: 0x6D6025C
	private static object GetAlignedSize(object len) { }

	// RVA: 0x6D60268
	private static object .cctor() { }

}

// Namespace: 
private sealed class <GetExpandoEnumerator>d__51
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x20
	public object version; // 0x28
	public object data; // 0x30
	private object <i>5__2; // 0x38

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6D602C4
	public object .ctor(object <>1__state) { }

	// RVA: 0x6D602F0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6D602F4
	private object MoveNext() { }

	// RVA: 0x6D60520
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.get_Current() { }

	// RVA: 0x6D6052C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6D6056C
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: System.Dynamic
public sealed class ExpandoObject
{

	// Fields
	private static readonly object s_expandoTryGetValue; // 0x0
	private static readonly object s_expandoTrySetValue; // 0x8
	private static readonly object s_expandoTryDeleteValue; // 0x10
	private static readonly object s_expandoPromoteClass; // 0x18
	private static readonly object s_expandoCheckVersion; // 0x20
	internal readonly object LockObject; // 0x8
	private object _data; // 0x10
	private object _count; // 0x18
	internal static readonly object Uninitialized; // 0x28
	private object _propertyChanged; // 0x20

	// Properties
	internal object Class { get; }
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.Keys { get; }
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.Values { get; }
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.Item { get; set; }
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.Count { get; }
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.IsReadOnly { get; }

	// Methods

	// RVA: 0x6D5B1A4
	public object .ctor() { }

	// RVA: 0x6D55E48
	internal object TryGetValue(object indexClass, object index, object name, object ignoreCase, object value) { }

	// RVA: 0x6D5600C
	internal object TrySetValue(object indexClass, object index, object value, object name, object ignoreCase, object add) { }

	// RVA: 0x6D56624
	internal object TryDeleteValue(object indexClass, object index, object name, object ignoreCase, object deleteValue) { }

	// RVA: 0x6D5B070
	internal object IsDeletedMember(object index) { }

	// RVA: 0x6D56A54
	internal object get_Class() { }

	// RVA: 0x6D5B248
	private object PromoteClassCore(object oldClass, object newClass) { }

	// RVA: 0x6D56A94
	internal object PromoteClass(object oldClass, object newClass) { }

	// RVA: 0x6D5B2A0
	private object System.Dynamic.IDynamicMetaObjectProvider.GetMetaObject(object parameter) { }

	// RVA: 0x6D5B310
	private object TryAddMember(object key, object value) { }

	// RVA: 0x6D5B398
	private object TryGetValueForKey(object key, object value) { }

	// RVA: 0x6D5B3B0
	private object ExpandoContainsKey(object key) { }

	// RVA: 0x6D5B450
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.get_Keys() { }

	// RVA: 0x6D5B5D0
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.get_Values() { }

	// RVA: 0x6D5B638
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.get_Item(object key) { }

	// RVA: 0x6D5B6A8
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.set_Item(object key, object value) { }

	// RVA: 0x6D5B730
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.Add(object key, object value) { }

	// RVA: 0x6D5B7B8
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.ContainsKey(object key) { }

	// RVA: 0x6D5B8EC
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.Remove(object key) { }

	// RVA: 0x6D5B998
	private object System.Collections.Generic.IDictionary<System.String,System.Object>.TryGetValue(object key, object value) { }

	// RVA: 0x6D5B9B0
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.get_Count() { }

	// RVA: 0x6D5B9B8
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.get_IsReadOnly() { }

	// RVA: 0x6D5B9C0
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.Add(object item) { }

	// RVA: 0x6D5BA74
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.Clear() { }

	// RVA: 0x6D5BD04
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.Contains(object item) { }

	// RVA: 0x6D5BDAC
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.CopyTo(object array, object arrayIndex) { }

	// RVA: 0x6D5C22C
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.Remove(object item) { }

	// RVA: 0x6D5C2A0
	private object System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<System.String,System.Object>>.GetEnumerator() { }

	// RVA: 0x6D5C3D8
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x6D5C344
	private object GetExpandoEnumerator(object data, object version) { }

	// RVA: 0x6D5C47C
	private static object .cctor() { }

}

// Namespace: System.Dynamic
public abstract class GetIndexBinder
{

	// Methods

	// RVA: 0x6D605D4
	public sealed override object Bind(object target, object args) { }

	// RVA: 0x6D606C8
	public object FallbackGetIndex(object target, object indexes) { }

	// RVA: -1
	public abstract object FallbackGetIndex(object target, object indexes, object errorSuggestion) { }

}

// Namespace: System.Dynamic
public abstract class GetMemberBinder
{

	// Fields
	private readonly object <Name>k__BackingField; // 0x10
	private readonly object <IgnoreCase>k__BackingField; // 0x18

	// Properties
	public sealed override object ReturnType { get; }
	public object Name { get; }
	public object IgnoreCase { get; }
	internal sealed override object IsStandardBinder { get; }

	// Methods

	// RVA: 0x6D60724
	protected object .ctor(object name, object ignoreCase) { }

	// RVA: 0x6D607CC
	public sealed override object get_ReturnType() { }

	// RVA: 0x6D6086C
	public object get_Name() { }

	// RVA: 0x6D60874
	public object get_IgnoreCase() { }

	// RVA: 0x6D5EBD4
	public object FallbackGetMember(object target) { }

	// RVA: -1
	public abstract object FallbackGetMember(object target, object errorSuggestion) { }

	// RVA: 0x6D6087C
	public sealed override object Bind(object target, object args) { }

	// RVA: 0x6D609B8
	internal sealed override object get_IsStandardBinder() { }

}

// Namespace: System.Dynamic
public interface IDynamicMetaObjectProvider
{

	// Methods

	// RVA: -1
	public abstract object GetMetaObject(object parameter) { }

}

// Namespace: System.Dynamic
public abstract class InvokeBinder
{

	// Methods

	// RVA: 0x6D609C0
	public object FallbackInvoke(object target, object args) { }

	// RVA: -1
	public abstract object FallbackInvoke(object target, object args, object errorSuggestion) { }

	// RVA: 0x6D60A1C
	public sealed override object Bind(object target, object args) { }

}

// Namespace: System.Dynamic
public abstract class InvokeMemberBinder
{

	// Fields
	private readonly object <Name>k__BackingField; // 0x10
	private readonly object <IgnoreCase>k__BackingField; // 0x18

	// Properties
	public object Name { get; }
	public object IgnoreCase { get; }

	// Methods

	// RVA: 0x6D60B10
	public object get_Name() { }

	// RVA: 0x6D60B18
	public object get_IgnoreCase() { }

	// RVA: 0x6D60B20
	public sealed override object Bind(object target, object args) { }

	// RVA: 0x6D5EDA0
	public object FallbackInvokeMember(object target, object args) { }

	// RVA: -1
	public abstract object FallbackInvokeMember(object target, object args, object errorSuggestion) { }

	// RVA: -1
	public abstract object FallbackInvoke(object target, object args, object errorSuggestion) { }

}

// Namespace: System.Dynamic
public abstract class SetIndexBinder
{

	// Methods

	// RVA: 0x6D60C14
	public sealed override object Bind(object target, object args) { }

	// RVA: 0x6D60DC8
	public object FallbackSetIndex(object target, object indexes, object value) { }

	// RVA: -1
	public abstract object FallbackSetIndex(object target, object indexes, object value, object errorSuggestion) { }

}

// Namespace: System.Dynamic
public abstract class SetMemberBinder
{

	// Fields
	private readonly object <Name>k__BackingField; // 0x10
	private readonly object <IgnoreCase>k__BackingField; // 0x18

	// Properties
	public sealed override object ReturnType { get; }
	public object Name { get; }
	public object IgnoreCase { get; }
	internal sealed override object IsStandardBinder { get; }

	// Methods

	// RVA: 0x6D60E2C
	protected object .ctor(object name, object ignoreCase) { }

	// RVA: 0x6D60ED4
	public sealed override object get_ReturnType() { }

	// RVA: 0x6D60F74
	public object get_Name() { }

	// RVA: 0x6D60F7C
	public object get_IgnoreCase() { }

	// RVA: 0x6D60F84
	public sealed override object Bind(object target, object args) { }

	// RVA: 0x6D610A8
	internal sealed override object get_IsStandardBinder() { }

	// RVA: 0x6D610B0
	public object FallbackSetMember(object target, object value) { }

	// RVA: -1
	public abstract object FallbackSetMember(object target, object value, object errorSuggestion) { }

}

// Namespace: System.Dynamic
public abstract class UnaryOperationBinder
{

	// Methods

	// RVA: 0x6D6110C
	public object FallbackUnaryOperation(object target) { }

	// RVA: -1
	public abstract object FallbackUnaryOperation(object target, object errorSuggestion) { }

	// RVA: 0x6D61158
	public sealed override object Bind(object target, object args) { }

}

// Namespace: 
private sealed class Entry
{

	// Fields
	internal readonly object _hash; // 0x0
	internal readonly object _key; // 0x0
	internal readonly object _value; // 0x0

	// Methods

	// RVA: -1
	internal object .ctor(object hash, object key, object value) { }

}

// Namespace: System.Dynamic.Utils
internal sealed class CacheDict<T0, T1>
{

	// Fields
	private readonly object _mask; // 0x0
	private readonly object _entries; // 0x0

	// Properties
	internal object Item { set; }

	// Methods

	// RVA: -1
	internal object .ctor(object size) { }

	// RVA: -1
	private static object AlignSize(object size) { }

	// RVA: -1
	internal object TryGetValue(object key, object value) { }

	// RVA: -1
	internal object Add(object key, object value) { }

	// RVA: -1
	internal object set_Item(object key, object value) { }

}

// Namespace: System.Dynamic.Utils
internal static class CollectionExtensions
{

	// Methods

	// RVA: -1
	public static object AddFirst(object list, object item) { }

	// RVA: -1
	public static object AddLast(object array, object item) { }

	// RVA: -1
	public static object RemoveFirst(object array) { }

	// RVA: -1
	public static object RemoveLast(object array) { }

	// RVA: -1
	public static object ToReadOnly(object enumerable) { }

}

// Namespace: System.Dynamic.Utils
internal static class ContractUtils
{

	// Properties
	public static object Unreachable { get; }

	// Methods

	// RVA: 0x6D6125C
	public static object get_Unreachable() { }

	// RVA: 0x6D6097C
	public static object Requires(object precondition, object paramName) { }

	// RVA: 0x6D5D938
	public static object RequiresNotNull(object value, object paramName) { }

	// RVA: 0x6D612D4
	public static object RequiresNotNull(object value, object paramName, object index) { }

	// RVA: -1
	public static object RequiresNotNullItems(object array, object arrayName) { }

	// RVA: 0x6D61330
	private static object GetParamName(object paramName, object index) { }

	// RVA: -1
	public static object RequiresArrayRange(object array, object offset, object count, object offsetName, object countName) { }

}

// Namespace: System.Dynamic.Utils
internal static class EmptyReadOnlyCollection<T0>
{

	// Fields
	public static readonly object Instance; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: System.Dynamic.Utils
internal static class ExpressionUtils
{

	// Methods

	// RVA: -1
	public static object ReturnReadOnly(object collection) { }

	// RVA: -1
	public static object ReturnObject(object collectionOrT) { }

	// RVA: 0x6D613CC
	public static object ValidateArgumentTypes(object method, object nodeKind, object arguments, object methodParamName) { }

	// RVA: 0x6D61848
	public static object ValidateArgumentCount(object method, object nodeKind, object count, object pis) { }

	// RVA: 0x6D61908
	public static object ValidateOneArgument(object method, object nodeKind, object arguments, object pi, object methodParamName, object argumentParamName, object index) { }

	// RVA: 0x6D622C4
	public static object RequiresCanRead(object expression, object paramName) { }

	// RVA: 0x6D61BF8
	public static object RequiresCanRead(object expression, object paramName, object idx) { }

	// RVA: 0x6D6212C
	public static object TryQuote(object parameterType, object argument) { }

	// RVA: 0x6D61794
	internal static object GetParametersForValidation(object method, object nodeKind) { }

	// RVA: -1
	internal static object SameElements(object replacement, object current) { }

	// RVA: -1
	private static object SameElementsInCollection(object replacement, object current) { }

	// RVA: 0x6D625D8
	public static object ValidateArgumentCount(object lambda) { }

}

// Namespace: System.Dynamic.Utils
internal static class ExpressionVisitorUtils
{

	// Methods

	// RVA: 0x6D626EC
	public static object VisitBlockExpressions(object visitor, object block) { }

	// RVA: 0x6D6296C
	public static object VisitParameters(object visitor, object nodes, object callerName) { }

	// RVA: 0x6D62DEC
	public static object VisitArguments(object visitor, object nodes) { }

}

// Namespace: System.Dynamic.Utils
internal static class TypeExtensions
{

	// Fields
	private static readonly object s_paramInfoCache; // 0x0

	// Methods

	// RVA: 0x6D63268
	public static object GetAnyStaticMethodValidated(object type, object name, object types) { }

	// RVA: 0x6D63318
	private static object MatchesArgumentTypes(object mi, object argTypes) { }

	// RVA: 0x6D634C4
	public static object GetReturnType(object mi) { }

	// RVA: 0x6D635BC
	public static object GetTypeCode(object type) { }

	// RVA: 0x6D62448
	internal static object GetParametersCached(object method) { }

	// RVA: 0x6D63644
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x6D68414
	private static object .cctor() { }

	// RVA: 0x6D68474
	public object .ctor() { }

	// RVA: 0x6D6847C
	internal object <.cctor>b__44_0(object i) { }

	// RVA: 0x6D684CC
	internal object <.cctor>b__44_1(object i) { }

}

// Namespace: System.Dynamic.Utils
internal static class TypeUtils
{

	// Fields
	private static readonly object s_arrayAssignableInterfaces; // 0x0

	// Methods

	// RVA: 0x6D636D8
	public static object GetNonNullableType(object type) { }

	// RVA: 0x6D638C0
	public static object GetNullableType(object type) { }

	// RVA: 0x6D637C8
	public static object IsNullableType(object type) { }

	// RVA: 0x6D63A50
	public static object IsNullableOrReferenceType(object type) { }

	// RVA: 0x6D63AE8
	public static object IsBool(object type) { }

	// RVA: 0x6D63BA4
	public static object IsNumeric(object type) { }

	// RVA: 0x6D63D24
	public static object IsInteger(object type) { }

	// RVA: 0x6D63EA4
	public static object IsArithmetic(object type) { }

	// RVA: 0x6D64024
	public static object IsUnsignedInt(object type) { }

	// RVA: 0x6D64198
	public static object IsIntegerOrBool(object type) { }

	// RVA: 0x6D6430C
	public static object IsNumericOrBool(object type) { }

	// RVA: 0x6D643C8
	public static object IsValidInstanceType(object member, object instanceType) { }

	// RVA: 0x6D64944
	public static object HasIdentityPrimitiveOrNullableConversionTo(object source, object dest) { }

	// RVA: 0x6D64F24
	public static object HasReferenceConversionTo(object source, object dest) { }

	// RVA: 0x6D656C4
	private static object StrictHasReferenceConversionTo(object source, object dest, object skipNonArray) { }

	// RVA: 0x6D65B40
	private static object HasArrayToInterfaceConversion(object source, object dest) { }

	// RVA: 0x6D65EB8
	private static object HasInterfaceToArrayConversion(object source, object dest) { }

	// RVA: 0x6D66280
	private static object IsCovariant(object t) { }

	// RVA: 0x6D662DC
	private static object IsContravariant(object t) { }

	// RVA: 0x6D66338
	private static object IsInvariant(object t) { }

	// RVA: 0x6D66398
	private static object IsDelegate(object t) { }

	// RVA: 0x6D651E0
	public static object IsLegalExplicitVariantDelegateConversion(object source, object dest) { }

	// RVA: 0x6D64DBC
	public static object IsConvertible(object type) { }

	// RVA: 0x6D66474
	public static object HasReferenceEquality(object left, object right) { }

	// RVA: 0x6D665AC
	public static object HasBuiltInEqualityOperator(object left, object right) { }

	// RVA: 0x6D66890
	public static object IsImplicitlyConvertibleTo(object source, object destination) { }

	// RVA: 0x6D66F94
	public static object GetUserDefinedCoercionMethod(object convertFrom, object convertToType) { }

	// RVA: 0x6D67358
	private static object FindConversionOperator(object methods, object typeFrom, object typeTo) { }

	// RVA: 0x6D66AAC
	private static object IsImplicitNumericConversion(object source, object destination) { }

	// RVA: 0x6D66228
	private static object IsImplicitReferenceConversion(object source, object destination) { }

	// RVA: 0x6D66D48
	private static object IsImplicitBoxingConversion(object source, object destination) { }

	// RVA: 0x6D66ED4
	private static object IsImplicitNullableConversion(object source, object destination) { }

	// RVA: 0x6D676D4
	public static object FindGenericType(object definition, object type) { }

	// RVA: 0x6D67D14
	public static object GetBooleanOperator(object type, object name) { }

	// RVA: 0x6D67F4C
	public static object GetNonRefType(object type) { }

	// RVA: 0x6D5F8E4
	public static object AreEquivalent(object t1, object t2) { }

	// RVA: 0x6D61F5C
	public static object AreReferenceAssignable(object dest, object src) { }

	// RVA: 0x6D622CC
	public static object IsSameOrSubclass(object type, object subType) { }

	// RVA: 0x6D67FB8
	public static object ValidateType(object type, object paramName) { }

	// RVA: 0x6D61E34
	public static object ValidateType(object type, object paramName, object allowByRef, object allowPointer) { }

	// RVA: 0x6D68028
	public static object ValidateType(object type, object paramName, object index) { }

	// RVA: 0x6D68168
	public static object GetInvokeMethod(object delegateType) { }

	// RVA: 0x6D681D0
	private static object .cctor() { }

}

// Namespace: System.Collections.Generic
internal struct ArrayBuilder<T0>
{

	// Fields
	private object _array; // 0x0
	private object _count; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object ToArray() { }

	// RVA: -1
	public object UncheckedAdd(object item) { }

}

// Namespace: System.Collections.Generic
internal sealed class BitHelper
{

	// Fields
	private readonly object _length; // 0x8
	private readonly object _arrayPtr; // 0x10
	private readonly object _array; // 0x18
	private readonly object _useStackAlloc; // 0x20

	// Methods

	// RVA: 0x6D6851C
	internal object .ctor(object bitArrayPtr, object length) { }

	// RVA: 0x6D68560
	internal object .ctor(object bitArray, object length) { }

	// RVA: 0x6D6859C
	internal object MarkBit(object bitPosition) { }

	// RVA: 0x6D68628
	internal object IsMarked(object bitPosition) { }

	// RVA: 0x6D686BC
	internal static object ToIntArrayLength(object n) { }

}

// Namespace: 
internal struct ElementCount
{

	// Fields
	internal object uniqueCount; // 0x0
	internal object unfoundCount; // 0x0
}

// Namespace: 
internal struct Slot
{

	// Fields
	internal object hashCode; // 0x0
	internal object next; // 0x0
	internal object value; // 0x0
}

// Namespace: 
public struct Enumerator
{

	// Fields
	private object _set; // 0x0
	private object _index; // 0x0
	private object _version; // 0x0
	private object _current; // 0x0

	// Properties
	public object Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object set) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

}

// Namespace: System.Collections.Generic
public class HashSet<T0>
{

	// Fields
	private const object Lower31BitMask;
	private const object StackAllocThreshold;
	private const object ShrinkThreshold;
	private const object CapacityName;
	private const object ElementsName;
	private const object ComparerName;
	private const object VersionName;
	private object _buckets; // 0x0
	private object _slots; // 0x0
	private object _count; // 0x0
	private object _lastIndex; // 0x0
	private object _freeList; // 0x0
	private object _comparer; // 0x0
	private object _version; // 0x0
	private object _siInfo; // 0x0

	// Properties
	public object Count { get; }
	private object System.Collections.Generic.ICollection<T>.IsReadOnly { get; }
	public object Comparer { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object .ctor(object comparer) { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object .ctor(object collection) { }

	// RVA: -1
	public object .ctor(object collection, object comparer) { }

	// RVA: -1
	protected object .ctor(object info, object context) { }

	// RVA: -1
	private object CopyFrom(object source) { }

	// RVA: -1
	public object .ctor(object capacity, object comparer) { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<T>.Add(object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	private object System.Collections.Generic.ICollection<T>.get_IsReadOnly() { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public virtual object GetObjectData(object info, object context) { }

	// RVA: -1
	public virtual object OnDeserialization(object sender) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object UnionWith(object other) { }

	// RVA: -1
	public object SetEquals(object other) { }

	// RVA: -1
	public object CopyTo(object array) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex, object count) { }

	// RVA: -1
	public object RemoveWhere(object match) { }

	// RVA: -1
	public object get_Comparer() { }

	// RVA: -1
	public object TrimExcess() { }

	// RVA: -1
	private object Initialize(object capacity) { }

	// RVA: -1
	private object IncreaseCapacity() { }

	// RVA: -1
	private object SetCapacity(object newSize) { }

	// RVA: -1
	private object AddIfNotPresent(object value) { }

	// RVA: -1
	private object AddValue(object index, object hashCode, object value) { }

	// RVA: -1
	private object ContainsAllElements(object other) { }

	// RVA: -1
	private object InternalIndexOf(object item) { }

	// RVA: -1
	private object CheckUniqueAndUnfoundElements(object other, object returnIfUnfound) { }

	// RVA: -1
	private static object AreEqualityComparersEqual(object set1, object set2) { }

	// RVA: -1
	private object InternalGetHashCode(object item) { }

}

// Namespace: System.Collections.Generic
internal sealed class ICollectionDebugView<T0>
{
}

// Namespace: System.Threading
public enum LockRecursionPolicy
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoRecursion;
	public const object SupportsRecursion;
}

// Namespace: System.Threading
internal class ReaderWriterCount
{

	// Fields
	public object lockID; // 0x8
	public object readercount; // 0x10
	public object writercount; // 0x14
	public object upgradecount; // 0x18
	public object next; // 0x20

	// Methods

	// RVA: 0x6D686D0
	public object .ctor() { }

}

// Namespace: 
private struct TimeoutTracker
{

	// Fields
	private object m_total; // 0xFFFFFFFFFFFFFFF8
	private object m_start; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object RemainingMilliseconds { get; }
	public object IsExpired { get; }

	// Methods

	// RVA: 0x6D689F0
	public object .ctor(object millisecondsTimeout) { }

	// RVA: 0x6D6A288
	public object get_RemainingMilliseconds() { }

	// RVA: 0x6D6901C
	public object get_IsExpired() { }

}

// Namespace: System.Threading
public class ReaderWriterLockSlim
{

	// Fields
	private object fIsReentrant; // 0x8
	private object myLock; // 0xC
	private object numWriteWaiters; // 0x10
	private object numReadWaiters; // 0x14
	private object numWriteUpgradeWaiters; // 0x18
	private object numUpgradeWaiters; // 0x1C
	private object fNoWaiters; // 0x20
	private object upgradeLockOwnerId; // 0x24
	private object writeLockOwnerId; // 0x28
	private object writeEvent; // 0x30
	private object readEvent; // 0x38
	private object upgradeEvent; // 0x40
	private object waitUpgradeEvent; // 0x48
	private static object s_nextLockID; // 0x0
	private object lockID; // 0x50
	private static object t_rwc; // 0xFFFFFFFF80000000
	private object fUpgradeThreadHoldingRead; // 0x58
	private object owners; // 0x5C
	private object fDisposed; // 0x60

	// Properties
	public object IsReadLockHeld { get; }
	public object IsUpgradeableReadLockHeld { get; }
	public object IsWriteLockHeld { get; }
	public object RecursiveReadCount { get; }
	public object RecursiveUpgradeCount { get; }
	public object RecursiveWriteCount { get; }
	public object WaitingReadCount { get; }
	public object WaitingUpgradeCount { get; }
	public object WaitingWriteCount { get; }

	// Methods

	// RVA: 0x6D686D8
	private object InitializeThreadCounts() { }

	// RVA: 0x6D686E4
	public object .ctor() { }

	// RVA: 0x6D68760
	public object .ctor(object recursionPolicy) { }

	// RVA: 0x6D687F0
	private static object IsRWEntryEmpty(object rwc) { }

	// RVA: 0x6D68838
	private object IsRwHashEntryChanged(object lrwc) { }

	// RVA: 0x6D68864
	private object GetThreadRWCount(object dontAllocate) { }

	// RVA: 0x6D689B0
	public object EnterReadLock() { }

	// RVA: 0x6D689B8
	public object TryEnterReadLock(object millisecondsTimeout) { }

	// RVA: 0x6D68A90
	private object TryEnterReadLock(object timeout) { }

	// RVA: 0x6D68A94
	private object TryEnterReadLockCore(object timeout) { }

	// RVA: 0x6D693F4
	public object EnterWriteLock() { }

	// RVA: 0x6D693FC
	public object TryEnterWriteLock(object millisecondsTimeout) { }

	// RVA: 0x6D69434
	private object TryEnterWriteLock(object timeout) { }

	// RVA: 0x6D69438
	private object TryEnterWriteLockCore(object timeout) { }

	// RVA: 0x6D69934
	public object EnterUpgradeableReadLock() { }

	// RVA: 0x6D6993C
	public object TryEnterUpgradeableReadLock(object millisecondsTimeout) { }

	// RVA: 0x6D69974
	private object TryEnterUpgradeableReadLock(object timeout) { }

	// RVA: 0x6D69978
	private object TryEnterUpgradeableReadLockCore(object timeout) { }

	// RVA: 0x6D69D78
	public object ExitReadLock() { }

	// RVA: 0x6D69F38
	public object ExitWriteLock() { }

	// RVA: 0x6D6A0A8
	public object ExitUpgradeableReadLock() { }

	// RVA: 0x6D69140
	private object LazyCreateEvent(object waitEvent, object makeAutoResetEvent) { }

	// RVA: 0x6D69274
	private object WaitOnEvent(object waitEvent, object numWaiters, object timeout, object isWriteWaiter) { }

	// RVA: 0x6D69F04
	private object ExitAndWakeUpAppropriateWaiters() { }

	// RVA: 0x6D6A3EC
	private object ExitAndWakeUpAppropriateWaitersPreferringWriters() { }

	// RVA: 0x6D6A4BC
	private object ExitAndWakeUpAppropriateReadWaiters() { }

	// RVA: 0x6D69908
	private object IsWriterAcquired() { }

	// RVA: 0x6D69918
	private object SetWriterAcquired() { }

	// RVA: 0x6D6A098
	private object ClearWriterAcquired() { }

	// RVA: 0x6D6A268
	private object SetWritersWaiting() { }

	// RVA: 0x6D6A584
	private object ClearWritersWaiting() { }

	// RVA: 0x6D6A278
	private object SetUpgraderWaiting() { }

	// RVA: 0x6D6A594
	private object ClearUpgraderWaiting() { }

	// RVA: 0x6D69928
	private object GetNumReaders() { }

	// RVA: 0x6D6A5A4
	private object EnterMyLock() { }

	// RVA: 0x6D6A5E8
	private object EnterMyLockSpin() { }

	// RVA: 0x6D68FF8
	private object ExitMyLock() { }

	// RVA: 0x6D69088
	private static object SpinWait(object SpinCount) { }

	// RVA: 0x6D6A720
	public object Dispose() { }

	// RVA: 0x6D6A728
	private object Dispose(object disposing) { }

	// RVA: 0x6D6A930
	public object get_IsReadLockHeld() { }

	// RVA: 0x6D6A9D8
	public object get_IsUpgradeableReadLockHeld() { }

	// RVA: 0x6D6A9F4
	public object get_IsWriteLockHeld() { }

	// RVA: 0x6D6AA10
	public object get_RecursiveReadCount() { }

	// RVA: 0x6D6AAA8
	public object get_RecursiveUpgradeCount() { }

	// RVA: 0x6D6AB88
	public object get_RecursiveWriteCount() { }

	// RVA: 0x6D6AC68
	public object get_WaitingReadCount() { }

	// RVA: 0x6D6AC70
	public object get_WaitingUpgradeCount() { }

	// RVA: 0x6D6AC78
	public object get_WaitingWriteCount() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=120
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=256
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=1024
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 0270BFF41CB170C33C20788C368CB1B5A66B0FD0B98D638A827B783537583821; // 0x0
	internal static readonly object 09FDC69AA887AC8D36E0C8284C7B1D53E580E4880B72A67FF80D7E38317115D9; // 0x400
	internal static readonly object 0F4764044BF2E91EFEFAF3D4F1E81C10A2B7F0F45305489925CFC01198CF45B5; // 0x800
	internal static readonly object 15A0E7628178B3FE6546E9B60F35E2B1C4864E020B16376866F38F72C74B45A9; // 0xC00
	internal static readonly object 4CF8DC711CD3210D673D86981355E2609233025ED22E4DC7A1F9B8E75ADE35F4; // 0x1000
	internal static readonly object 783FB0A44BE7670EB6EC170CF7F16BB2B6F23F4964B87B60C4EB506C7C6A286D; // 0x1400
	internal static readonly object 914FCE8DC82DA59038745B264F743222527FBAE2E4A28E71C89760B7E3DBBA67; // 0x1800
	internal static readonly object 93631B0726F6FE6629DAA743EE51B49F4477ED07391B68EEEA0672A4A90018AA; // 0x1878
	internal static readonly object C2D8E5EED6CBEBD8625FC18F81486A7733C04F9B0129FFBE974C68B90308B4F2; // 0x1978
	internal static readonly object C40A9A77EE05E10AF16DA9D1781A2053159EA8570ADA03637BB5FE3D076C9F89; // 0x1A78
	internal static readonly object E8058399671D13082C35B6B3CE7F9E282507EDD458CCFDD3BAD9F35D90016F62; // 0x1E78
}

