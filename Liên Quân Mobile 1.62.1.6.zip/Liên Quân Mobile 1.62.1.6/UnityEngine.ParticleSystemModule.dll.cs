// Namespace: 
internal class <Module>
{
}

// Namespace: 
public struct MainModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object randomizeRotationDirection { get; set; }
	public object duration { get; set; }
	public object loop { get; set; }
	public object prewarm { get; set; }
	public object startDelay { get; set; }
	public object startDelayMultiplier { get; set; }
	public object startLifetime { get; set; }
	public object startLifetimeMultiplier { get; set; }
	public object startSpeed { get; set; }
	public object startSpeedMultiplier { get; set; }
	public object startSize3D { get; set; }
	public object startSize { get; set; }
	public object startSizeMultiplier { get; set; }
	public object startSizeX { get; set; }
	public object startSizeXMultiplier { get; set; }
	public object startSizeY { get; set; }
	public object startSizeYMultiplier { get; set; }
	public object startSizeZ { get; set; }
	public object startSizeZMultiplier { get; set; }
	public object startRotation3D { get; set; }
	public object startRotation { get; set; }
	public object startRotationMultiplier { get; set; }
	public object startRotationX { get; set; }
	public object startRotationXMultiplier { get; set; }
	public object startRotationY { get; set; }
	public object startRotationYMultiplier { get; set; }
	public object startRotationZ { get; set; }
	public object startRotationZMultiplier { get; set; }
	public object flipRotation { get; set; }
	public object startColor { get; set; }
	public object gravityModifier { get; set; }
	public object gravityModifierMultiplier { get; set; }
	public object simulationSpace { get; set; }
	public object customSimulationSpace { get; set; }
	public object simulationSpeed { get; set; }
	public object useUnscaledTime { get; set; }
	public object scalingMode { get; set; }
	public object playOnAwake { get; set; }
	public object maxParticles { get; set; }
	public object emitterVelocityMode { get; set; }
	public object stopAction { get; set; }

	// Methods

	// RVA: 0x743C59C
	public object get_randomizeRotationDirection() { }

	// RVA: 0x743C68C
	public object set_randomizeRotationDirection(object value) { }

	// RVA: 0x743C464
	internal object .ctor(object particleSystem) { }

	// RVA: 0x743C7C0
	public object get_duration() { }

	// RVA: 0x743C8B0
	public object set_duration(object value) { }

	// RVA: 0x743C9DC
	public object get_loop() { }

	// RVA: 0x743CACC
	public object set_loop(object value) { }

	// RVA: 0x743CBF8
	public object get_prewarm() { }

	// RVA: 0x743CCE8
	public object set_prewarm(object value) { }

	// RVA: 0x743CE14
	public object get_startDelay() { }

	// RVA: 0x743CF54
	public object set_startDelay(object value) { }

	// RVA: 0x743D074
	public object get_startDelayMultiplier() { }

	// RVA: 0x743D164
	public object set_startDelayMultiplier(object value) { }

	// RVA: 0x743D290
	public object get_startLifetime() { }

	// RVA: 0x743D3D0
	public object set_startLifetime(object value) { }

	// RVA: 0x743B6F4
	public object get_startLifetimeMultiplier() { }

	// RVA: 0x743B7A0
	public object set_startLifetimeMultiplier(object value) { }

	// RVA: 0x743D658
	public object get_startSpeed() { }

	// RVA: 0x743D798
	public object set_startSpeed(object value) { }

	// RVA: 0x743B40C
	public object get_startSpeedMultiplier() { }

	// RVA: 0x743B4B8
	public object set_startSpeedMultiplier(object value) { }

	// RVA: 0x743DA20
	public object get_startSize3D() { }

	// RVA: 0x743DB10
	public object set_startSize3D(object value) { }

	// RVA: 0x743DC3C
	public object get_startSize() { }

	// RVA: 0x743DD7C
	public object set_startSize(object value) { }

	// RVA: 0x743B580
	public object get_startSizeMultiplier() { }

	// RVA: 0x743B62C
	public object set_startSizeMultiplier(object value) { }

	// RVA: 0x743E004
	public object get_startSizeX() { }

	// RVA: 0x743E144
	public object set_startSizeX(object value) { }

	// RVA: 0x743E264
	public object get_startSizeXMultiplier() { }

	// RVA: 0x743E354
	public object set_startSizeXMultiplier(object value) { }

	// RVA: 0x743E480
	public object get_startSizeY() { }

	// RVA: 0x743E5C0
	public object set_startSizeY(object value) { }

	// RVA: 0x743E6E0
	public object get_startSizeYMultiplier() { }

	// RVA: 0x743E7D0
	public object set_startSizeYMultiplier(object value) { }

	// RVA: 0x743E8FC
	public object get_startSizeZ() { }

	// RVA: 0x743EA3C
	public object set_startSizeZ(object value) { }

	// RVA: 0x743EB5C
	public object get_startSizeZMultiplier() { }

	// RVA: 0x743EC4C
	public object set_startSizeZMultiplier(object value) { }

	// RVA: 0x743ED78
	public object get_startRotation3D() { }

	// RVA: 0x743EE68
	public object set_startRotation3D(object value) { }

	// RVA: 0x743EF94
	public object get_startRotation() { }

	// RVA: 0x743F0D4
	public object set_startRotation(object value) { }

	// RVA: 0x743F1F4
	public object get_startRotationMultiplier() { }

	// RVA: 0x743F2E4
	public object set_startRotationMultiplier(object value) { }

	// RVA: 0x743F410
	public object get_startRotationX() { }

	// RVA: 0x743F550
	public object set_startRotationX(object value) { }

	// RVA: 0x743F670
	public object get_startRotationXMultiplier() { }

	// RVA: 0x743F760
	public object set_startRotationXMultiplier(object value) { }

	// RVA: 0x743F88C
	public object get_startRotationY() { }

	// RVA: 0x743F9CC
	public object set_startRotationY(object value) { }

	// RVA: 0x743FAEC
	public object get_startRotationYMultiplier() { }

	// RVA: 0x743FBDC
	public object set_startRotationYMultiplier(object value) { }

	// RVA: 0x743FD08
	public object get_startRotationZ() { }

	// RVA: 0x743FE48
	public object set_startRotationZ(object value) { }

	// RVA: 0x743FF68
	public object get_startRotationZMultiplier() { }

	// RVA: 0x7440058
	public object set_startRotationZMultiplier(object value) { }

	// RVA: 0x743C5EC
	public object get_flipRotation() { }

	// RVA: 0x743C6F0
	public object set_flipRotation(object value) { }

	// RVA: 0x74402EC
	public object get_startColor() { }

	// RVA: 0x744045C
	public object set_startColor(object value) { }

	// RVA: 0x744058C
	public object get_gravityModifier() { }

	// RVA: 0x74406CC
	public object set_gravityModifier(object value) { }

	// RVA: 0x743B868
	public object get_gravityModifierMultiplier() { }

	// RVA: 0x743B914
	public object set_gravityModifierMultiplier(object value) { }

	// RVA: 0x743B9DC
	public object get_simulationSpace() { }

	// RVA: 0x74409F4
	public object set_simulationSpace(object value) { }

	// RVA: 0x7440B20
	public object get_customSimulationSpace() { }

	// RVA: 0x7440C10
	public object set_customSimulationSpace(object value) { }

	// RVA: 0x7440D3C
	public object get_simulationSpeed() { }

	// RVA: 0x743B1BC
	public object set_simulationSpeed(object value) { }

	// RVA: 0x7440EF4
	public object get_useUnscaledTime() { }

	// RVA: 0x7440FE4
	public object set_useUnscaledTime(object value) { }

	// RVA: 0x7441110
	public object get_scalingMode() { }

	// RVA: 0x7441200
	public object set_scalingMode(object value) { }

	// RVA: 0x743B040
	public object get_playOnAwake() { }

	// RVA: 0x743B0FC
	public object set_playOnAwake(object value) { }

	// RVA: 0x7441494
	public object get_maxParticles() { }

	// RVA: 0x7441584
	public object set_maxParticles(object value) { }

	// RVA: 0x74416B0
	public object get_emitterVelocityMode() { }

	// RVA: 0x74417A0
	public object set_emitterVelocityMode(object value) { }

	// RVA: 0x74418CC
	public object get_stopAction() { }

	// RVA: 0x74419BC
	public object set_stopAction(object value) { }

	// RVA: 0x743C810
	private static object get_duration_Injected(object _unity_self) { }

	// RVA: 0x743C914
	private static object set_duration_Injected(object _unity_self, object value) { }

	// RVA: 0x743CA2C
	private static object get_loop_Injected(object _unity_self) { }

	// RVA: 0x743CB30
	private static object set_loop_Injected(object _unity_self, object value) { }

	// RVA: 0x743CC48
	private static object get_prewarm_Injected(object _unity_self) { }

	// RVA: 0x743CD4C
	private static object set_prewarm_Injected(object _unity_self, object value) { }

	// RVA: 0x743CE84
	private static object get_startDelay_Injected(object _unity_self, object ret) { }

	// RVA: 0x743CFB8
	private static object set_startDelay_Injected(object _unity_self, object value) { }

	// RVA: 0x743D0C4
	private static object get_startDelayMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743D1C8
	private static object set_startDelayMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743D300
	private static object get_startLifetime_Injected(object _unity_self, object ret) { }

	// RVA: 0x743D434
	private static object set_startLifetime_Injected(object _unity_self, object value) { }

	// RVA: 0x743D4F0
	private static object get_startLifetimeMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743D590
	private static object set_startLifetimeMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743D6C8
	private static object get_startSpeed_Injected(object _unity_self, object ret) { }

	// RVA: 0x743D7FC
	private static object set_startSpeed_Injected(object _unity_self, object value) { }

	// RVA: 0x743D8B8
	private static object get_startSpeedMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743D958
	private static object set_startSpeedMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743DA70
	private static object get_startSize3D_Injected(object _unity_self) { }

	// RVA: 0x743DB74
	private static object set_startSize3D_Injected(object _unity_self, object value) { }

	// RVA: 0x743DCAC
	private static object get_startSize_Injected(object _unity_self, object ret) { }

	// RVA: 0x743DDE0
	private static object set_startSize_Injected(object _unity_self, object value) { }

	// RVA: 0x743DE9C
	private static object get_startSizeMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743DF3C
	private static object set_startSizeMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743E074
	private static object get_startSizeX_Injected(object _unity_self, object ret) { }

	// RVA: 0x743E1A8
	private static object set_startSizeX_Injected(object _unity_self, object value) { }

	// RVA: 0x743E2B4
	private static object get_startSizeXMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743E3B8
	private static object set_startSizeXMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743E4F0
	private static object get_startSizeY_Injected(object _unity_self, object ret) { }

	// RVA: 0x743E624
	private static object set_startSizeY_Injected(object _unity_self, object value) { }

	// RVA: 0x743E730
	private static object get_startSizeYMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743E834
	private static object set_startSizeYMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743E96C
	private static object get_startSizeZ_Injected(object _unity_self, object ret) { }

	// RVA: 0x743EAA0
	private static object set_startSizeZ_Injected(object _unity_self, object value) { }

	// RVA: 0x743EBAC
	private static object get_startSizeZMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743ECB0
	private static object set_startSizeZMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743EDC8
	private static object get_startRotation3D_Injected(object _unity_self) { }

	// RVA: 0x743EECC
	private static object set_startRotation3D_Injected(object _unity_self, object value) { }

	// RVA: 0x743F004
	private static object get_startRotation_Injected(object _unity_self, object ret) { }

	// RVA: 0x743F138
	private static object set_startRotation_Injected(object _unity_self, object value) { }

	// RVA: 0x743F244
	private static object get_startRotationMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743F348
	private static object set_startRotationMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743F480
	private static object get_startRotationX_Injected(object _unity_self, object ret) { }

	// RVA: 0x743F5B4
	private static object set_startRotationX_Injected(object _unity_self, object value) { }

	// RVA: 0x743F6C0
	private static object get_startRotationXMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743F7C4
	private static object set_startRotationXMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743F8FC
	private static object get_startRotationY_Injected(object _unity_self, object ret) { }

	// RVA: 0x743FA30
	private static object set_startRotationY_Injected(object _unity_self, object value) { }

	// RVA: 0x743FB3C
	private static object get_startRotationYMultiplier_Injected(object _unity_self) { }

	// RVA: 0x743FC40
	private static object set_startRotationYMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x743FD78
	private static object get_startRotationZ_Injected(object _unity_self, object ret) { }

	// RVA: 0x743FEAC
	private static object set_startRotationZ_Injected(object _unity_self, object value) { }

	// RVA: 0x743FFB8
	private static object get_startRotationZMultiplier_Injected(object _unity_self) { }

	// RVA: 0x74400BC
	private static object set_startRotationZMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7440184
	private static object get_flipRotation_Injected(object _unity_self) { }

	// RVA: 0x7440224
	private static object set_flipRotation_Injected(object _unity_self, object value) { }

	// RVA: 0x7440374
	private static object get_startColor_Injected(object _unity_self, object ret) { }

	// RVA: 0x74404C0
	private static object set_startColor_Injected(object _unity_self, object value) { }

	// RVA: 0x74405FC
	private static object get_gravityModifier_Injected(object _unity_self, object ret) { }

	// RVA: 0x7440730
	private static object set_gravityModifier_Injected(object _unity_self, object value) { }

	// RVA: 0x74407EC
	private static object get_gravityModifierMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744088C
	private static object set_gravityModifierMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7440954
	private static object get_simulationSpace_Injected(object _unity_self) { }

	// RVA: 0x7440A58
	private static object set_simulationSpace_Injected(object _unity_self, object value) { }

	// RVA: 0x7440B70
	private static object get_customSimulationSpace_Injected(object _unity_self) { }

	// RVA: 0x7440C74
	private static object set_customSimulationSpace_Injected(object _unity_self, object value) { }

	// RVA: 0x7440D8C
	private static object get_simulationSpeed_Injected(object _unity_self) { }

	// RVA: 0x7440E2C
	private static object set_simulationSpeed_Injected(object _unity_self, object value) { }

	// RVA: 0x7440F44
	private static object get_useUnscaledTime_Injected(object _unity_self) { }

	// RVA: 0x7441048
	private static object set_useUnscaledTime_Injected(object _unity_self, object value) { }

	// RVA: 0x7441160
	private static object get_scalingMode_Injected(object _unity_self) { }

	// RVA: 0x7441264
	private static object set_scalingMode_Injected(object _unity_self, object value) { }

	// RVA: 0x744132C
	private static object get_playOnAwake_Injected(object _unity_self) { }

	// RVA: 0x74413CC
	private static object set_playOnAwake_Injected(object _unity_self, object value) { }

	// RVA: 0x74414E4
	private static object get_maxParticles_Injected(object _unity_self) { }

	// RVA: 0x74415E8
	private static object set_maxParticles_Injected(object _unity_self, object value) { }

	// RVA: 0x7441700
	private static object get_emitterVelocityMode_Injected(object _unity_self) { }

	// RVA: 0x7441804
	private static object set_emitterVelocityMode_Injected(object _unity_self, object value) { }

	// RVA: 0x744191C
	private static object get_stopAction_Injected(object _unity_self) { }

	// RVA: 0x7441A20
	private static object set_stopAction_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct EmissionModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object rateOverTime { get; set; }
	public object rateOverTimeMultiplier { get; set; }
	public object rateOverDistance { get; set; }
	public object rateOverDistanceMultiplier { get; set; }
	public object burstCount { get; set; }

	// Methods

	// RVA: 0x743C46C
	internal object .ctor(object particleSystem) { }

	// RVA: 0x743B288
	public object get_enabled() { }

	// RVA: 0x743B344
	public object set_enabled(object value) { }

	// RVA: 0x7441C94
	public object get_rateOverTime() { }

	// RVA: 0x7441DD4
	public object set_rateOverTime(object value) { }

	// RVA: 0x7441EF4
	public object get_rateOverTimeMultiplier() { }

	// RVA: 0x7441FE4
	public object set_rateOverTimeMultiplier(object value) { }

	// RVA: 0x7442110
	public object get_rateOverDistance() { }

	// RVA: 0x7442250
	public object set_rateOverDistance(object value) { }

	// RVA: 0x7442370
	public object get_rateOverDistanceMultiplier() { }

	// RVA: 0x7442460
	public object set_rateOverDistanceMultiplier(object value) { }

	// RVA: 0x744258C
	public object SetBursts(object bursts) { }

	// RVA: 0x74426AC
	public object SetBursts(object bursts, object size) { }

	// RVA: 0x7442ADC
	public object GetBursts(object bursts) { }

	// RVA: 0x7442950
	public object SetBurst(object index, object burst) { }

	// RVA: 0x7442CB8
	public object GetBurst(object index) { }

	// RVA: 0x7442C68
	public object get_burstCount() { }

	// RVA: 0x74428EC
	public object set_burstCount(object value) { }

	// RVA: 0x7441B2C
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7441BCC
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x7441D04
	private static object get_rateOverTime_Injected(object _unity_self, object ret) { }

	// RVA: 0x7441E38
	private static object set_rateOverTime_Injected(object _unity_self, object value) { }

	// RVA: 0x7441F44
	private static object get_rateOverTimeMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7442048
	private static object set_rateOverTimeMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7442180
	private static object get_rateOverDistance_Injected(object _unity_self, object ret) { }

	// RVA: 0x74422B4
	private static object set_rateOverDistance_Injected(object _unity_self, object value) { }

	// RVA: 0x74423C0
	private static object get_rateOverDistanceMultiplier_Injected(object _unity_self) { }

	// RVA: 0x74424C4
	private static object set_rateOverDistanceMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7442D50
	private static object SetBurst_Injected(object _unity_self, object index, object burst) { }

	// RVA: 0x7442E34
	private static object GetBurst_Injected(object _unity_self, object index, object ret) { }

	// RVA: 0x7442F2C
	private static object get_burstCount_Injected(object _unity_self) { }

	// RVA: 0x7442FCC
	private static object set_burstCount_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct ShapeModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object shapeType { get; set; }
	public object randomDirectionAmount { get; set; }
	public object sphericalDirectionAmount { get; set; }
	public object randomPositionAmount { get; set; }
	public object alignToDirection { get; set; }
	public object radius { get; set; }
	public object radiusMode { get; set; }
	public object radiusSpread { get; set; }
	public object radiusSpeed { get; set; }
	public object radiusSpeedMultiplier { get; set; }
	public object radiusThickness { get; set; }
	public object angle { get; set; }
	public object length { get; set; }
	public object boxThickness { get; set; }
	public object meshShapeType { get; set; }
	public object mesh { get; set; }
	public object meshRenderer { get; set; }
	public object skinnedMeshRenderer { get; set; }
	public object useMeshMaterialIndex { get; set; }
	public object meshMaterialIndex { get; set; }
	public object useMeshColors { get; set; }
	public object normalOffset { get; set; }
	public object arc { get; set; }
	public object arcMode { get; set; }
	public object arcSpread { get; set; }
	public object arcSpeed { get; set; }
	public object arcSpeedMultiplier { get; set; }
	public object donutRadius { get; set; }
	public object position { get; set; }
	public object rotation { get; set; }
	public object scale { get; set; }

	// Methods

	// RVA: 0x743C478
	internal object .ctor(object particleSystem) { }

	// RVA: 0x74430D8
	public object get_enabled() { }

	// RVA: 0x74431C8
	public object set_enabled(object value) { }

	// RVA: 0x74432F4
	public object get_shapeType() { }

	// RVA: 0x74433E4
	public object set_shapeType(object value) { }

	// RVA: 0x7443510
	public object get_randomDirectionAmount() { }

	// RVA: 0x7443600
	public object set_randomDirectionAmount(object value) { }

	// RVA: 0x744372C
	public object get_sphericalDirectionAmount() { }

	// RVA: 0x744381C
	public object set_sphericalDirectionAmount(object value) { }

	// RVA: 0x7443948
	public object get_randomPositionAmount() { }

	// RVA: 0x7443A38
	public object set_randomPositionAmount(object value) { }

	// RVA: 0x7443B64
	public object get_alignToDirection() { }

	// RVA: 0x7443C54
	public object set_alignToDirection(object value) { }

	// RVA: 0x7443D80
	public object get_radius() { }

	// RVA: 0x7443E70
	public object set_radius(object value) { }

	// RVA: 0x7443F9C
	public object get_radiusMode() { }

	// RVA: 0x744408C
	public object set_radiusMode(object value) { }

	// RVA: 0x74441B8
	public object get_radiusSpread() { }

	// RVA: 0x74442A8
	public object set_radiusSpread(object value) { }

	// RVA: 0x74443D4
	public object get_radiusSpeed() { }

	// RVA: 0x7444514
	public object set_radiusSpeed(object value) { }

	// RVA: 0x7444634
	public object get_radiusSpeedMultiplier() { }

	// RVA: 0x7444724
	public object set_radiusSpeedMultiplier(object value) { }

	// RVA: 0x7444850
	public object get_radiusThickness() { }

	// RVA: 0x7444940
	public object set_radiusThickness(object value) { }

	// RVA: 0x7444A6C
	public object get_angle() { }

	// RVA: 0x7444B5C
	public object set_angle(object value) { }

	// RVA: 0x7444C88
	public object get_length() { }

	// RVA: 0x7444D78
	public object set_length(object value) { }

	// RVA: 0x7444EA4
	public object get_boxThickness() { }

	// RVA: 0x7444FCC
	public object set_boxThickness(object value) { }

	// RVA: 0x74450FC
	public object get_meshShapeType() { }

	// RVA: 0x74451EC
	public object set_meshShapeType(object value) { }

	// RVA: 0x7445318
	public object get_mesh() { }

	// RVA: 0x7445408
	public object set_mesh(object value) { }

	// RVA: 0x7445534
	public object get_meshRenderer() { }

	// RVA: 0x7445624
	public object set_meshRenderer(object value) { }

	// RVA: 0x7445750
	public object get_skinnedMeshRenderer() { }

	// RVA: 0x7445840
	public object set_skinnedMeshRenderer(object value) { }

	// RVA: 0x744596C
	public object get_useMeshMaterialIndex() { }

	// RVA: 0x7445A5C
	public object set_useMeshMaterialIndex(object value) { }

	// RVA: 0x7445B88
	public object get_meshMaterialIndex() { }

	// RVA: 0x7445C78
	public object set_meshMaterialIndex(object value) { }

	// RVA: 0x7445DA4
	public object get_useMeshColors() { }

	// RVA: 0x7445E94
	public object set_useMeshColors(object value) { }

	// RVA: 0x7445FC0
	public object get_normalOffset() { }

	// RVA: 0x74460B0
	public object set_normalOffset(object value) { }

	// RVA: 0x74461DC
	public object get_arc() { }

	// RVA: 0x74462CC
	public object set_arc(object value) { }

	// RVA: 0x74463F8
	public object get_arcMode() { }

	// RVA: 0x74464E8
	public object set_arcMode(object value) { }

	// RVA: 0x7446614
	public object get_arcSpread() { }

	// RVA: 0x7446704
	public object set_arcSpread(object value) { }

	// RVA: 0x7446830
	public object get_arcSpeed() { }

	// RVA: 0x7446970
	public object set_arcSpeed(object value) { }

	// RVA: 0x7446A90
	public object get_arcSpeedMultiplier() { }

	// RVA: 0x7446B80
	public object set_arcSpeedMultiplier(object value) { }

	// RVA: 0x7446CAC
	public object get_donutRadius() { }

	// RVA: 0x7446D9C
	public object set_donutRadius(object value) { }

	// RVA: 0x7446EC8
	public object get_position() { }

	// RVA: 0x7446FF0
	public object set_position(object value) { }

	// RVA: 0x7447120
	public object get_rotation() { }

	// RVA: 0x7447248
	public object set_rotation(object value) { }

	// RVA: 0x7447378
	public object get_scale() { }

	// RVA: 0x74474A0
	public object set_scale(object value) { }

	// RVA: 0x7443128
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x744322C
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x7443344
	private static object get_shapeType_Injected(object _unity_self) { }

	// RVA: 0x7443448
	private static object set_shapeType_Injected(object _unity_self, object value) { }

	// RVA: 0x7443560
	private static object get_randomDirectionAmount_Injected(object _unity_self) { }

	// RVA: 0x7443664
	private static object set_randomDirectionAmount_Injected(object _unity_self, object value) { }

	// RVA: 0x744377C
	private static object get_sphericalDirectionAmount_Injected(object _unity_self) { }

	// RVA: 0x7443880
	private static object set_sphericalDirectionAmount_Injected(object _unity_self, object value) { }

	// RVA: 0x7443998
	private static object get_randomPositionAmount_Injected(object _unity_self) { }

	// RVA: 0x7443A9C
	private static object set_randomPositionAmount_Injected(object _unity_self, object value) { }

	// RVA: 0x7443BB4
	private static object get_alignToDirection_Injected(object _unity_self) { }

	// RVA: 0x7443CB8
	private static object set_alignToDirection_Injected(object _unity_self, object value) { }

	// RVA: 0x7443DD0
	private static object get_radius_Injected(object _unity_self) { }

	// RVA: 0x7443ED4
	private static object set_radius_Injected(object _unity_self, object value) { }

	// RVA: 0x7443FEC
	private static object get_radiusMode_Injected(object _unity_self) { }

	// RVA: 0x74440F0
	private static object set_radiusMode_Injected(object _unity_self, object value) { }

	// RVA: 0x7444208
	private static object get_radiusSpread_Injected(object _unity_self) { }

	// RVA: 0x744430C
	private static object set_radiusSpread_Injected(object _unity_self, object value) { }

	// RVA: 0x7444444
	private static object get_radiusSpeed_Injected(object _unity_self, object ret) { }

	// RVA: 0x7444578
	private static object set_radiusSpeed_Injected(object _unity_self, object value) { }

	// RVA: 0x7444684
	private static object get_radiusSpeedMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7444788
	private static object set_radiusSpeedMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x74448A0
	private static object get_radiusThickness_Injected(object _unity_self) { }

	// RVA: 0x74449A4
	private static object set_radiusThickness_Injected(object _unity_self, object value) { }

	// RVA: 0x7444ABC
	private static object get_angle_Injected(object _unity_self) { }

	// RVA: 0x7444BC0
	private static object set_angle_Injected(object _unity_self, object value) { }

	// RVA: 0x7444CD8
	private static object get_length_Injected(object _unity_self) { }

	// RVA: 0x7444DDC
	private static object set_length_Injected(object _unity_self, object value) { }

	// RVA: 0x7444F08
	private static object get_boxThickness_Injected(object _unity_self, object ret) { }

	// RVA: 0x7445040
	private static object set_boxThickness_Injected(object _unity_self, object value) { }

	// RVA: 0x744514C
	private static object get_meshShapeType_Injected(object _unity_self) { }

	// RVA: 0x7445250
	private static object set_meshShapeType_Injected(object _unity_self, object value) { }

	// RVA: 0x7445368
	private static object get_mesh_Injected(object _unity_self) { }

	// RVA: 0x744546C
	private static object set_mesh_Injected(object _unity_self, object value) { }

	// RVA: 0x7445584
	private static object get_meshRenderer_Injected(object _unity_self) { }

	// RVA: 0x7445688
	private static object set_meshRenderer_Injected(object _unity_self, object value) { }

	// RVA: 0x74457A0
	private static object get_skinnedMeshRenderer_Injected(object _unity_self) { }

	// RVA: 0x74458A4
	private static object set_skinnedMeshRenderer_Injected(object _unity_self, object value) { }

	// RVA: 0x74459BC
	private static object get_useMeshMaterialIndex_Injected(object _unity_self) { }

	// RVA: 0x7445AC0
	private static object set_useMeshMaterialIndex_Injected(object _unity_self, object value) { }

	// RVA: 0x7445BD8
	private static object get_meshMaterialIndex_Injected(object _unity_self) { }

	// RVA: 0x7445CDC
	private static object set_meshMaterialIndex_Injected(object _unity_self, object value) { }

	// RVA: 0x7445DF4
	private static object get_useMeshColors_Injected(object _unity_self) { }

	// RVA: 0x7445EF8
	private static object set_useMeshColors_Injected(object _unity_self, object value) { }

	// RVA: 0x7446010
	private static object get_normalOffset_Injected(object _unity_self) { }

	// RVA: 0x7446114
	private static object set_normalOffset_Injected(object _unity_self, object value) { }

	// RVA: 0x744622C
	private static object get_arc_Injected(object _unity_self) { }

	// RVA: 0x7446330
	private static object set_arc_Injected(object _unity_self, object value) { }

	// RVA: 0x7446448
	private static object get_arcMode_Injected(object _unity_self) { }

	// RVA: 0x744654C
	private static object set_arcMode_Injected(object _unity_self, object value) { }

	// RVA: 0x7446664
	private static object get_arcSpread_Injected(object _unity_self) { }

	// RVA: 0x7446768
	private static object set_arcSpread_Injected(object _unity_self, object value) { }

	// RVA: 0x74468A0
	private static object get_arcSpeed_Injected(object _unity_self, object ret) { }

	// RVA: 0x74469D4
	private static object set_arcSpeed_Injected(object _unity_self, object value) { }

	// RVA: 0x7446AE0
	private static object get_arcSpeedMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7446BE4
	private static object set_arcSpeedMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7446CFC
	private static object get_donutRadius_Injected(object _unity_self) { }

	// RVA: 0x7446E00
	private static object set_donutRadius_Injected(object _unity_self, object value) { }

	// RVA: 0x7446F2C
	private static object get_position_Injected(object _unity_self, object ret) { }

	// RVA: 0x7447064
	private static object set_position_Injected(object _unity_self, object value) { }

	// RVA: 0x7447184
	private static object get_rotation_Injected(object _unity_self, object ret) { }

	// RVA: 0x74472BC
	private static object set_rotation_Injected(object _unity_self, object value) { }

	// RVA: 0x74473DC
	private static object get_scale_Injected(object _unity_self, object ret) { }

	// RVA: 0x7447514
	private static object set_scale_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct CollisionModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }

	// Methods

	// RVA: 0x743C514
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7447614
	public object get_enabled() { }

	// RVA: 0x7447704
	public object set_enabled(object value) { }

	// RVA: 0x7447664
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7447768
	private static object set_enabled_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct TriggerModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }

	// Methods

	// RVA: 0x743C520
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7447874
	public object get_enabled() { }

	// RVA: 0x7447964
	public object set_enabled(object value) { }

	// RVA: 0x74478C4
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x74479C8
	private static object set_enabled_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct SubEmittersModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object subEmittersCount { get; }

	// Methods

	// RVA: 0x743C52C
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7447AD4
	public object get_enabled() { }

	// RVA: 0x7447BC4
	public object set_enabled(object value) { }

	// RVA: 0x7447CF0
	public object get_subEmittersCount() { }

	// RVA: 0x7447DE0
	public object GetSubEmitterSystem(object index) { }

	// RVA: 0x7447B24
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7447C28
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x7447D40
	private static object get_subEmittersCount_Injected(object _unity_self) { }

	// RVA: 0x7447E44
	private static object GetSubEmitterSystem_Injected(object _unity_self, object index) { }

}

// Namespace: 
public struct TextureSheetAnimationModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object flipU { get; set; }
	public object flipV { get; set; }
	public object useRandomRow { get; set; }
	public object enabled { get; set; }
	public object mode { get; set; }
	public object numTilesX { get; set; }
	public object numTilesY { get; set; }
	public object animation { get; set; }
	public object rowMode { get; set; }
	public object frameOverTime { get; set; }
	public object frameOverTimeMultiplier { get; set; }
	public object startFrame { get; set; }
	public object startFrameMultiplier { get; set; }
	public object cycleCount { get; set; }
	public object rowIndex { get; set; }
	public object uvChannelMask { get; set; }

	// Methods

	// RVA: 0x7447F48
	public object get_flipU() { }

	// RVA: 0x744811C
	public object set_flipU(object value) { }

	// RVA: 0x744828C
	public object get_flipV() { }

	// RVA: 0x74483FC
	public object set_flipV(object value) { }

	// RVA: 0x74484FC
	public object set_useRandomRow(object value) { }

	// RVA: 0x7448678
	public object get_useRandomRow() { }

	// RVA: 0x743C538
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7448784
	public object get_enabled() { }

	// RVA: 0x7448874
	public object set_enabled(object value) { }

	// RVA: 0x74489A0
	public object get_mode() { }

	// RVA: 0x7448A90
	public object set_mode(object value) { }

	// RVA: 0x7448BBC
	public object get_numTilesX() { }

	// RVA: 0x7448CAC
	public object set_numTilesX(object value) { }

	// RVA: 0x7448DD8
	public object get_numTilesY() { }

	// RVA: 0x7448EC8
	public object set_numTilesY(object value) { }

	// RVA: 0x7448FF4
	public object get_animation() { }

	// RVA: 0x74490E4
	public object set_animation(object value) { }

	// RVA: 0x74486E0
	public object get_rowMode() { }

	// RVA: 0x744858C
	public object set_rowMode(object value) { }

	// RVA: 0x7449378
	public object get_frameOverTime() { }

	// RVA: 0x74494B8
	public object set_frameOverTime(object value) { }

	// RVA: 0x74495D8
	public object get_frameOverTimeMultiplier() { }

	// RVA: 0x74496C8
	public object set_frameOverTimeMultiplier(object value) { }

	// RVA: 0x74497F4
	public object get_startFrame() { }

	// RVA: 0x7449934
	public object set_startFrame(object value) { }

	// RVA: 0x7449A54
	public object get_startFrameMultiplier() { }

	// RVA: 0x7449B44
	public object set_startFrameMultiplier(object value) { }

	// RVA: 0x7449C70
	public object get_cycleCount() { }

	// RVA: 0x7449D60
	public object set_cycleCount(object value) { }

	// RVA: 0x7449E8C
	public object get_rowIndex() { }

	// RVA: 0x7449F7C
	public object set_rowIndex(object value) { }

	// RVA: 0x744A0A8
	public object get_uvChannelMask() { }

	// RVA: 0x744A198
	public object set_uvChannelMask(object value) { }

	// RVA: 0x74487D4
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x74488D8
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x74489F0
	private static object get_mode_Injected(object _unity_self) { }

	// RVA: 0x7448AF4
	private static object set_mode_Injected(object _unity_self, object value) { }

	// RVA: 0x7448C0C
	private static object get_numTilesX_Injected(object _unity_self) { }

	// RVA: 0x7448D10
	private static object set_numTilesX_Injected(object _unity_self, object value) { }

	// RVA: 0x7448E28
	private static object get_numTilesY_Injected(object _unity_self) { }

	// RVA: 0x7448F2C
	private static object set_numTilesY_Injected(object _unity_self, object value) { }

	// RVA: 0x7449044
	private static object get_animation_Injected(object _unity_self) { }

	// RVA: 0x7449148
	private static object set_animation_Injected(object _unity_self, object value) { }

	// RVA: 0x7449210
	private static object get_rowMode_Injected(object _unity_self) { }

	// RVA: 0x74492B0
	private static object set_rowMode_Injected(object _unity_self, object value) { }

	// RVA: 0x74493E8
	private static object get_frameOverTime_Injected(object _unity_self, object ret) { }

	// RVA: 0x744951C
	private static object set_frameOverTime_Injected(object _unity_self, object value) { }

	// RVA: 0x7449628
	private static object get_frameOverTimeMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744972C
	private static object set_frameOverTimeMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7449864
	private static object get_startFrame_Injected(object _unity_self, object ret) { }

	// RVA: 0x7449998
	private static object set_startFrame_Injected(object _unity_self, object value) { }

	// RVA: 0x7449AA4
	private static object get_startFrameMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7449BA8
	private static object set_startFrameMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7449CC0
	private static object get_cycleCount_Injected(object _unity_self) { }

	// RVA: 0x7449DC4
	private static object set_cycleCount_Injected(object _unity_self, object value) { }

	// RVA: 0x7449EDC
	private static object get_rowIndex_Injected(object _unity_self) { }

	// RVA: 0x7449FE0
	private static object set_rowIndex_Injected(object _unity_self, object value) { }

	// RVA: 0x744A0F8
	private static object get_uvChannelMask_Injected(object _unity_self) { }

	// RVA: 0x744A1FC
	private static object set_uvChannelMask_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct Particle
{

	// Fields
	private object m_Position; // 0xFFFFFFFFFFFFFFF8
	private object m_Velocity; // 0x4
	private object m_AnimatedVelocity; // 0x10
	private object m_InitialVelocity; // 0x1C
	private object m_AxisOfRotation; // 0x28
	private object m_Rotation; // 0x34
	private object m_AngularVelocity; // 0x40
	private object m_StartSize; // 0x4C
	private object m_StartColor; // 0x58
	private object m_RandomSeed; // 0x5C
	private object m_ParentRandomSeed; // 0x60
	private object m_Lifetime; // 0x64
	private object m_StartLifetime; // 0x68
	private object m_MeshIndex; // 0x6C
	private object m_EmitAccumulator0; // 0x70
	private object m_EmitAccumulator1; // 0x74
	private object m_Flags; // 0x78

	// Properties
	public object lifetime { set; }
	public object position { set; }
	public object velocity { set; }
	public object remainingLifetime { set; }
	public object startLifetime { set; }
	public object startColor { set; }
	public object randomSeed { set; }
	public object startSize { set; }
	public object rotation3D { set; }
	public object angularVelocity3D { set; }

	// Methods

	// RVA: 0x743AE7C
	public object set_lifetime(object value) { }

	// RVA: 0x743AE64
	public object set_position(object value) { }

	// RVA: 0x743AE70
	public object set_velocity(object value) { }

	// RVA: 0x744A2C4
	public object set_remainingLifetime(object value) { }

	// RVA: 0x743AE84
	public object set_startLifetime(object value) { }

	// RVA: 0x743AF00
	public object set_startColor(object value) { }

	// RVA: 0x743AF08
	public object set_randomSeed(object value) { }

	// RVA: 0x743AE8C
	public object set_startSize(object value) { }

	// RVA: 0x743AE98
	public object set_rotation3D(object value) { }

	// RVA: 0x743AECC
	public object set_angularVelocity3D(object value) { }

}

// Namespace: 
public struct Burst
{

	// Fields
	private object m_Time; // 0xFFFFFFFFFFFFFFF8
	private object m_Count; // 0x0
	private object m_RepeatCount; // 0x20
	private object m_RepeatInterval; // 0x24
	private object m_InvProbability; // 0x28

	// Properties
	public object count { set; }

	// Methods

	// RVA: 0x744A380
	public object set_count(object value) { }

}

// Namespace: 
public struct MinMaxCurve
{

	// Fields
	private object m_Mode; // 0xFFFFFFFFFFFFFFF8
	private object m_CurveMultiplier; // 0xFFFFFFFFFFFFFFFC
	private object m_CurveMin; // 0x0
	private object m_CurveMax; // 0x8
	private object m_ConstantMin; // 0x10
	private object m_ConstantMax; // 0x14

	// Properties
	public object mode { get; set; }
	public object curveMultiplier { get; }
	public object curveMax { get; }
	public object curveMin { get; }
	public object constantMax { get; set; }
	public object constantMin { get; set; }
	public object constant { set; }

	// Methods

	// RVA: 0x744A39C
	public object .ctor(object constant) { }

	// RVA: 0x744A3C4
	public object .ctor(object multiplier, object curve) { }

	// RVA: 0x744A3F4
	public object .ctor(object multiplier, object min, object max) { }

	// RVA: 0x744A424
	public object .ctor(object min, object max) { }

	// RVA: 0x744A45C
	public object get_mode() { }

	// RVA: 0x744A46C
	public object set_mode(object value) { }

	// RVA: 0x744A47C
	public object get_curveMultiplier() { }

	// RVA: 0x744A48C
	public object get_curveMax() { }

	// RVA: 0x744A49C
	public object get_curveMin() { }

	// RVA: 0x744A4AC
	public object get_constantMax() { }

	// RVA: 0x744A4BC
	public object set_constantMax(object value) { }

	// RVA: 0x744A4CC
	public object get_constantMin() { }

	// RVA: 0x744A4DC
	public object set_constantMin(object value) { }

	// RVA: 0x744A4EC
	public object set_constant(object value) { }

	// RVA: 0x744A4FC
	public object Evaluate(object time) { }

	// RVA: 0x744A504
	public object Evaluate(object time, object lerpFactor) { }

	// RVA: 0x744A65C
	public static object op_Implicit(object constant) { }

}

// Namespace: 
public struct MinMaxGradient
{

	// Fields
	private object m_Mode; // 0xFFFFFFFFFFFFFFF8
	private object m_GradientMin; // 0x0
	private object m_GradientMax; // 0x8
	private object m_ColorMin; // 0x10
	private object m_ColorMax; // 0x20

	// Properties
	public object mode { get; set; }
	public object gradientMax { get; set; }
	public object gradientMin { get; set; }
	public object colorMax { get; set; }
	public object colorMin { get; set; }
	public object color { get; }

	// Methods

	// RVA: 0x744A670
	public object .ctor(object color) { }

	// RVA: 0x744A6A8
	public object .ctor(object gradient) { }

	// RVA: 0x744A6E4
	public object get_mode() { }

	// RVA: 0x744A6F4
	public object set_mode(object value) { }

	// RVA: 0x744A704
	public object get_gradientMax() { }

	// RVA: 0x744A714
	public object set_gradientMax(object value) { }

	// RVA: 0x744A724
	public object get_gradientMin() { }

	// RVA: 0x744A734
	public object set_gradientMin(object value) { }

	// RVA: 0x744A744
	public object get_colorMax() { }

	// RVA: 0x744A75C
	public object set_colorMax(object value) { }

	// RVA: 0x744A774
	public object get_colorMin() { }

	// RVA: 0x744A78C
	public object set_colorMin(object value) { }

	// RVA: 0x744A7A4
	public object get_color() { }

	// RVA: 0x744A7BC
	public object Evaluate(object time) { }

	// RVA: 0x744A7C4
	public object Evaluate(object time, object lerpFactor) { }

	// RVA: 0x744A948
	public static object op_Implicit(object color) { }

	// RVA: 0x744A96C
	public static object op_Implicit(object gradient) { }

}

// Namespace: 
public struct EmitParams
{

	// Fields
	private object m_Particle; // 0xFFFFFFFFFFFFFFF8
	private object m_PositionSet; // 0x7C
	private object m_VelocitySet; // 0x7D
	private object m_AxisOfRotationSet; // 0x7E
	private object m_RotationSet; // 0x7F
	private object m_AngularVelocitySet; // 0x80
	private object m_StartSizeSet; // 0x81
	private object m_StartColorSet; // 0x82
	private object m_RandomSeedSet; // 0x83
	private object m_StartLifetimeSet; // 0x84
	private object m_MeshIndexSet; // 0x85
	private object m_ApplyShapeToPosition; // 0x86
}

// Namespace: 
public struct VelocityOverLifetimeModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object x { get; set; }
	public object y { get; set; }
	public object z { get; set; }
	public object xMultiplier { get; set; }
	public object yMultiplier { get; set; }
	public object zMultiplier { get; set; }
	public object speedModifier { get; set; }
	public object speedModifierMultiplier { get; set; }
	public object space { get; set; }

	// Methods

	// RVA: 0x743C484
	internal object .ctor(object particleSystem) { }

	// RVA: 0x744AACC
	public object get_enabled() { }

	// RVA: 0x744ABBC
	public object set_enabled(object value) { }

	// RVA: 0x744ACE8
	public object get_x() { }

	// RVA: 0x744AE28
	public object set_x(object value) { }

	// RVA: 0x744AF48
	public object get_y() { }

	// RVA: 0x744B088
	public object set_y(object value) { }

	// RVA: 0x744B1A8
	public object get_z() { }

	// RVA: 0x744B2E8
	public object set_z(object value) { }

	// RVA: 0x744B408
	public object get_xMultiplier() { }

	// RVA: 0x744B4F8
	public object set_xMultiplier(object value) { }

	// RVA: 0x744B624
	public object get_yMultiplier() { }

	// RVA: 0x744B714
	public object set_yMultiplier(object value) { }

	// RVA: 0x744B840
	public object get_zMultiplier() { }

	// RVA: 0x744B930
	public object set_zMultiplier(object value) { }

	// RVA: 0x744BA5C
	public object get_speedModifier() { }

	// RVA: 0x744BB9C
	public object set_speedModifier(object value) { }

	// RVA: 0x744BCBC
	public object get_speedModifierMultiplier() { }

	// RVA: 0x744BDAC
	public object set_speedModifierMultiplier(object value) { }

	// RVA: 0x744BED8
	public object get_space() { }

	// RVA: 0x744BFC8
	public object set_space(object value) { }

	// RVA: 0x744AB1C
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x744AC20
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x744AD58
	private static object get_x_Injected(object _unity_self, object ret) { }

	// RVA: 0x744AE8C
	private static object set_x_Injected(object _unity_self, object value) { }

	// RVA: 0x744AFB8
	private static object get_y_Injected(object _unity_self, object ret) { }

	// RVA: 0x744B0EC
	private static object set_y_Injected(object _unity_self, object value) { }

	// RVA: 0x744B218
	private static object get_z_Injected(object _unity_self, object ret) { }

	// RVA: 0x744B34C
	private static object set_z_Injected(object _unity_self, object value) { }

	// RVA: 0x744B458
	private static object get_xMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744B55C
	private static object set_xMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744B674
	private static object get_yMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744B778
	private static object set_yMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744B890
	private static object get_zMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744B994
	private static object set_zMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744BACC
	private static object get_speedModifier_Injected(object _unity_self, object ret) { }

	// RVA: 0x744BC00
	private static object set_speedModifier_Injected(object _unity_self, object value) { }

	// RVA: 0x744BD0C
	private static object get_speedModifierMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744BE10
	private static object set_speedModifierMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744BF28
	private static object get_space_Injected(object _unity_self) { }

	// RVA: 0x744C02C
	private static object set_space_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct LimitVelocityOverLifetimeModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object limitX { get; set; }
	public object limitXMultiplier { get; set; }
	public object limitY { get; set; }
	public object limitYMultiplier { get; set; }
	public object limitZ { get; set; }
	public object limitZMultiplier { get; set; }
	public object limit { get; set; }
	public object limitMultiplier { get; set; }
	public object dampen { get; set; }
	public object separateAxes { get; set; }
	public object space { get; set; }
	public object drag { get; set; }
	public object dragMultiplier { get; set; }
	public object multiplyDragByParticleSize { get; set; }
	public object multiplyDragByParticleVelocity { get; set; }

	// Methods

	// RVA: 0x743C490
	internal object .ctor(object particleSystem) { }

	// RVA: 0x744C138
	public object get_enabled() { }

	// RVA: 0x744C228
	public object set_enabled(object value) { }

	// RVA: 0x744C354
	public object get_limitX() { }

	// RVA: 0x744C494
	public object set_limitX(object value) { }

	// RVA: 0x744C5B4
	public object get_limitXMultiplier() { }

	// RVA: 0x744C6A4
	public object set_limitXMultiplier(object value) { }

	// RVA: 0x744C7D0
	public object get_limitY() { }

	// RVA: 0x744C910
	public object set_limitY(object value) { }

	// RVA: 0x744CA30
	public object get_limitYMultiplier() { }

	// RVA: 0x744CB20
	public object set_limitYMultiplier(object value) { }

	// RVA: 0x744CC4C
	public object get_limitZ() { }

	// RVA: 0x744CD8C
	public object set_limitZ(object value) { }

	// RVA: 0x744CEAC
	public object get_limitZMultiplier() { }

	// RVA: 0x744CF9C
	public object set_limitZMultiplier(object value) { }

	// RVA: 0x744D0C8
	public object get_limit() { }

	// RVA: 0x744D208
	public object set_limit(object value) { }

	// RVA: 0x744D328
	public object get_limitMultiplier() { }

	// RVA: 0x744D418
	public object set_limitMultiplier(object value) { }

	// RVA: 0x744D544
	public object get_dampen() { }

	// RVA: 0x744D634
	public object set_dampen(object value) { }

	// RVA: 0x744D760
	public object get_separateAxes() { }

	// RVA: 0x744D850
	public object set_separateAxes(object value) { }

	// RVA: 0x744D97C
	public object get_space() { }

	// RVA: 0x744DA6C
	public object set_space(object value) { }

	// RVA: 0x744DB98
	public object get_drag() { }

	// RVA: 0x744DCD8
	public object set_drag(object value) { }

	// RVA: 0x744DDF8
	public object get_dragMultiplier() { }

	// RVA: 0x744DEE8
	public object set_dragMultiplier(object value) { }

	// RVA: 0x744E014
	public object get_multiplyDragByParticleSize() { }

	// RVA: 0x744E104
	public object set_multiplyDragByParticleSize(object value) { }

	// RVA: 0x744E230
	public object get_multiplyDragByParticleVelocity() { }

	// RVA: 0x744E320
	public object set_multiplyDragByParticleVelocity(object value) { }

	// RVA: 0x744C188
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x744C28C
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x744C3C4
	private static object get_limitX_Injected(object _unity_self, object ret) { }

	// RVA: 0x744C4F8
	private static object set_limitX_Injected(object _unity_self, object value) { }

	// RVA: 0x744C604
	private static object get_limitXMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744C708
	private static object set_limitXMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744C840
	private static object get_limitY_Injected(object _unity_self, object ret) { }

	// RVA: 0x744C974
	private static object set_limitY_Injected(object _unity_self, object value) { }

	// RVA: 0x744CA80
	private static object get_limitYMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744CB84
	private static object set_limitYMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744CCBC
	private static object get_limitZ_Injected(object _unity_self, object ret) { }

	// RVA: 0x744CDF0
	private static object set_limitZ_Injected(object _unity_self, object value) { }

	// RVA: 0x744CEFC
	private static object get_limitZMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744D000
	private static object set_limitZMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744D138
	private static object get_limit_Injected(object _unity_self, object ret) { }

	// RVA: 0x744D26C
	private static object set_limit_Injected(object _unity_self, object value) { }

	// RVA: 0x744D378
	private static object get_limitMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744D47C
	private static object set_limitMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744D594
	private static object get_dampen_Injected(object _unity_self) { }

	// RVA: 0x744D698
	private static object set_dampen_Injected(object _unity_self, object value) { }

	// RVA: 0x744D7B0
	private static object get_separateAxes_Injected(object _unity_self) { }

	// RVA: 0x744D8B4
	private static object set_separateAxes_Injected(object _unity_self, object value) { }

	// RVA: 0x744D9CC
	private static object get_space_Injected(object _unity_self) { }

	// RVA: 0x744DAD0
	private static object set_space_Injected(object _unity_self, object value) { }

	// RVA: 0x744DC08
	private static object get_drag_Injected(object _unity_self, object ret) { }

	// RVA: 0x744DD3C
	private static object set_drag_Injected(object _unity_self, object value) { }

	// RVA: 0x744DE48
	private static object get_dragMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744DF4C
	private static object set_dragMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744E064
	private static object get_multiplyDragByParticleSize_Injected(object _unity_self) { }

	// RVA: 0x744E168
	private static object set_multiplyDragByParticleSize_Injected(object _unity_self, object value) { }

	// RVA: 0x744E280
	private static object get_multiplyDragByParticleVelocity_Injected(object _unity_self) { }

	// RVA: 0x744E384
	private static object set_multiplyDragByParticleVelocity_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct InheritVelocityModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object mode { get; set; }
	public object curve { get; set; }
	public object curveMultiplier { get; set; }

	// Methods

	// RVA: 0x743C49C
	internal object .ctor(object particleSystem) { }

	// RVA: 0x744E490
	public object get_enabled() { }

	// RVA: 0x744E580
	public object set_enabled(object value) { }

	// RVA: 0x744E6AC
	public object get_mode() { }

	// RVA: 0x744E79C
	public object set_mode(object value) { }

	// RVA: 0x744E8C8
	public object get_curve() { }

	// RVA: 0x744EA08
	public object set_curve(object value) { }

	// RVA: 0x744EB28
	public object get_curveMultiplier() { }

	// RVA: 0x744EC18
	public object set_curveMultiplier(object value) { }

	// RVA: 0x744E4E0
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x744E5E4
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x744E6FC
	private static object get_mode_Injected(object _unity_self) { }

	// RVA: 0x744E800
	private static object set_mode_Injected(object _unity_self, object value) { }

	// RVA: 0x744E938
	private static object get_curve_Injected(object _unity_self, object ret) { }

	// RVA: 0x744EA6C
	private static object set_curve_Injected(object _unity_self, object value) { }

	// RVA: 0x744EB78
	private static object get_curveMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744EC7C
	private static object set_curveMultiplier_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct ForceOverLifetimeModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object x { get; set; }
	public object y { get; set; }
	public object z { get; set; }
	public object xMultiplier { get; set; }
	public object yMultiplier { get; set; }
	public object zMultiplier { get; set; }
	public object space { get; set; }
	public object randomized { get; set; }

	// Methods

	// RVA: 0x743C4A8
	internal object .ctor(object particleSystem) { }

	// RVA: 0x744ED88
	public object get_enabled() { }

	// RVA: 0x744EE78
	public object set_enabled(object value) { }

	// RVA: 0x744EFA4
	public object get_x() { }

	// RVA: 0x744F0E4
	public object set_x(object value) { }

	// RVA: 0x744F204
	public object get_y() { }

	// RVA: 0x744F344
	public object set_y(object value) { }

	// RVA: 0x744F464
	public object get_z() { }

	// RVA: 0x744F5A4
	public object set_z(object value) { }

	// RVA: 0x744F6C4
	public object get_xMultiplier() { }

	// RVA: 0x744F7B4
	public object set_xMultiplier(object value) { }

	// RVA: 0x744F8E0
	public object get_yMultiplier() { }

	// RVA: 0x744F9D0
	public object set_yMultiplier(object value) { }

	// RVA: 0x744FAFC
	public object get_zMultiplier() { }

	// RVA: 0x744FBEC
	public object set_zMultiplier(object value) { }

	// RVA: 0x744FD18
	public object get_space() { }

	// RVA: 0x744FE08
	public object set_space(object value) { }

	// RVA: 0x744FF34
	public object get_randomized() { }

	// RVA: 0x7450024
	public object set_randomized(object value) { }

	// RVA: 0x744EDD8
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x744EEDC
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x744F014
	private static object get_x_Injected(object _unity_self, object ret) { }

	// RVA: 0x744F148
	private static object set_x_Injected(object _unity_self, object value) { }

	// RVA: 0x744F274
	private static object get_y_Injected(object _unity_self, object ret) { }

	// RVA: 0x744F3A8
	private static object set_y_Injected(object _unity_self, object value) { }

	// RVA: 0x744F4D4
	private static object get_z_Injected(object _unity_self, object ret) { }

	// RVA: 0x744F608
	private static object set_z_Injected(object _unity_self, object value) { }

	// RVA: 0x744F714
	private static object get_xMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744F818
	private static object set_xMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744F930
	private static object get_yMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744FA34
	private static object set_yMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744FB4C
	private static object get_zMultiplier_Injected(object _unity_self) { }

	// RVA: 0x744FC50
	private static object set_zMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x744FD68
	private static object get_space_Injected(object _unity_self) { }

	// RVA: 0x744FE6C
	private static object set_space_Injected(object _unity_self, object value) { }

	// RVA: 0x744FF84
	private static object get_randomized_Injected(object _unity_self) { }

	// RVA: 0x7450088
	private static object set_randomized_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct ColorOverLifetimeModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object color { get; set; }

	// Methods

	// RVA: 0x743C4B4
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7450194
	public object get_enabled() { }

	// RVA: 0x7450284
	public object set_enabled(object value) { }

	// RVA: 0x74503B0
	public object get_color() { }

	// RVA: 0x7450520
	public object set_color(object value) { }

	// RVA: 0x74501E4
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x74502E8
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x7450438
	private static object get_color_Injected(object _unity_self, object ret) { }

	// RVA: 0x7450584
	private static object set_color_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct ColorBySpeedModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object color { get; set; }
	public object range { get; set; }

	// Methods

	// RVA: 0x743C4C0
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7450694
	public object get_enabled() { }

	// RVA: 0x7450784
	public object set_enabled(object value) { }

	// RVA: 0x74508B0
	public object get_color() { }

	// RVA: 0x7450A20
	public object set_color(object value) { }

	// RVA: 0x7450B50
	public object get_range() { }

	// RVA: 0x7450C68
	public object set_range(object value) { }

	// RVA: 0x74506E4
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x74507E8
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x7450938
	private static object get_color_Injected(object _unity_self, object ret) { }

	// RVA: 0x7450A84
	private static object set_color_Injected(object _unity_self, object value) { }

	// RVA: 0x7450BAC
	private static object get_range_Injected(object _unity_self, object ret) { }

	// RVA: 0x7450CD8
	private static object set_range_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct SizeOverLifetimeModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object size { get; set; }
	public object x { get; set; }
	public object xMultiplier { get; set; }
	public object y { get; set; }
	public object yMultiplier { get; set; }
	public object z { get; set; }
	public object zMultiplier { get; set; }
	public object separateAxes { get; set; }

	// Methods

	// RVA: 0x743C4CC
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7450DD4
	public object get_enabled() { }

	// RVA: 0x7450EC4
	public object set_enabled(object value) { }

	// RVA: 0x7450FF0
	public object get_size() { }

	// RVA: 0x7451130
	public object set_size(object value) { }

	// RVA: 0x7451250
	public object get_x() { }

	// RVA: 0x7451390
	public object set_x(object value) { }

	// RVA: 0x74514B0
	public object get_xMultiplier() { }

	// RVA: 0x74515A0
	public object set_xMultiplier(object value) { }

	// RVA: 0x74516CC
	public object get_y() { }

	// RVA: 0x745180C
	public object set_y(object value) { }

	// RVA: 0x745192C
	public object get_yMultiplier() { }

	// RVA: 0x7451A1C
	public object set_yMultiplier(object value) { }

	// RVA: 0x7451B48
	public object get_z() { }

	// RVA: 0x7451C88
	public object set_z(object value) { }

	// RVA: 0x7451DA8
	public object get_zMultiplier() { }

	// RVA: 0x7451E98
	public object set_zMultiplier(object value) { }

	// RVA: 0x7451FC4
	public object get_separateAxes() { }

	// RVA: 0x74520B4
	public object set_separateAxes(object value) { }

	// RVA: 0x7450E24
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7450F28
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x7451060
	private static object get_size_Injected(object _unity_self, object ret) { }

	// RVA: 0x7451194
	private static object set_size_Injected(object _unity_self, object value) { }

	// RVA: 0x74512C0
	private static object get_x_Injected(object _unity_self, object ret) { }

	// RVA: 0x74513F4
	private static object set_x_Injected(object _unity_self, object value) { }

	// RVA: 0x7451500
	private static object get_xMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7451604
	private static object set_xMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x745173C
	private static object get_y_Injected(object _unity_self, object ret) { }

	// RVA: 0x7451870
	private static object set_y_Injected(object _unity_self, object value) { }

	// RVA: 0x745197C
	private static object get_yMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7451A80
	private static object set_yMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7451BB8
	private static object get_z_Injected(object _unity_self, object ret) { }

	// RVA: 0x7451CEC
	private static object set_z_Injected(object _unity_self, object value) { }

	// RVA: 0x7451DF8
	private static object get_zMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7451EFC
	private static object set_zMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7452014
	private static object get_separateAxes_Injected(object _unity_self) { }

	// RVA: 0x7452118
	private static object set_separateAxes_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct SizeBySpeedModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object size { get; set; }
	public object sizeMultiplier { get; set; }
	public object x { get; set; }
	public object xMultiplier { get; set; }
	public object y { get; set; }
	public object yMultiplier { get; set; }
	public object z { get; set; }
	public object zMultiplier { get; set; }
	public object separateAxes { get; set; }
	public object range { get; set; }

	// Methods

	// RVA: 0x743C4D8
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7452224
	public object get_enabled() { }

	// RVA: 0x7452314
	public object set_enabled(object value) { }

	// RVA: 0x7452440
	public object get_size() { }

	// RVA: 0x7452580
	public object set_size(object value) { }

	// RVA: 0x74526A0
	public object get_sizeMultiplier() { }

	// RVA: 0x7452790
	public object set_sizeMultiplier(object value) { }

	// RVA: 0x74528BC
	public object get_x() { }

	// RVA: 0x74529FC
	public object set_x(object value) { }

	// RVA: 0x7452B1C
	public object get_xMultiplier() { }

	// RVA: 0x7452C0C
	public object set_xMultiplier(object value) { }

	// RVA: 0x7452D38
	public object get_y() { }

	// RVA: 0x7452E78
	public object set_y(object value) { }

	// RVA: 0x7452F98
	public object get_yMultiplier() { }

	// RVA: 0x7453088
	public object set_yMultiplier(object value) { }

	// RVA: 0x74531B4
	public object get_z() { }

	// RVA: 0x74532F4
	public object set_z(object value) { }

	// RVA: 0x7453414
	public object get_zMultiplier() { }

	// RVA: 0x7453504
	public object set_zMultiplier(object value) { }

	// RVA: 0x7453630
	public object get_separateAxes() { }

	// RVA: 0x7453720
	public object set_separateAxes(object value) { }

	// RVA: 0x745384C
	public object get_range() { }

	// RVA: 0x7453964
	public object set_range(object value) { }

	// RVA: 0x7452274
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7452378
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x74524B0
	private static object get_size_Injected(object _unity_self, object ret) { }

	// RVA: 0x74525E4
	private static object set_size_Injected(object _unity_self, object value) { }

	// RVA: 0x74526F0
	private static object get_sizeMultiplier_Injected(object _unity_self) { }

	// RVA: 0x74527F4
	private static object set_sizeMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x745292C
	private static object get_x_Injected(object _unity_self, object ret) { }

	// RVA: 0x7452A60
	private static object set_x_Injected(object _unity_self, object value) { }

	// RVA: 0x7452B6C
	private static object get_xMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7452C70
	private static object set_xMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7452DA8
	private static object get_y_Injected(object _unity_self, object ret) { }

	// RVA: 0x7452EDC
	private static object set_y_Injected(object _unity_self, object value) { }

	// RVA: 0x7452FE8
	private static object get_yMultiplier_Injected(object _unity_self) { }

	// RVA: 0x74530EC
	private static object set_yMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7453224
	private static object get_z_Injected(object _unity_self, object ret) { }

	// RVA: 0x7453358
	private static object set_z_Injected(object _unity_self, object value) { }

	// RVA: 0x7453464
	private static object get_zMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7453568
	private static object set_zMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7453680
	private static object get_separateAxes_Injected(object _unity_self) { }

	// RVA: 0x7453784
	private static object set_separateAxes_Injected(object _unity_self, object value) { }

	// RVA: 0x74538A8
	private static object get_range_Injected(object _unity_self, object ret) { }

	// RVA: 0x74539D4
	private static object set_range_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct RotationOverLifetimeModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object x { get; set; }
	public object xMultiplier { get; set; }
	public object y { get; set; }
	public object yMultiplier { get; set; }
	public object z { get; set; }
	public object zMultiplier { get; set; }
	public object separateAxes { get; set; }

	// Methods

	// RVA: 0x743C4E4
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7453AD0
	public object get_enabled() { }

	// RVA: 0x7453BC0
	public object set_enabled(object value) { }

	// RVA: 0x7453CEC
	public object get_x() { }

	// RVA: 0x7453E2C
	public object set_x(object value) { }

	// RVA: 0x7453F4C
	public object get_xMultiplier() { }

	// RVA: 0x745403C
	public object set_xMultiplier(object value) { }

	// RVA: 0x7454168
	public object get_y() { }

	// RVA: 0x74542A8
	public object set_y(object value) { }

	// RVA: 0x74543C8
	public object get_yMultiplier() { }

	// RVA: 0x74544B8
	public object set_yMultiplier(object value) { }

	// RVA: 0x74545E4
	public object get_z() { }

	// RVA: 0x7454724
	public object set_z(object value) { }

	// RVA: 0x7454844
	public object get_zMultiplier() { }

	// RVA: 0x7454934
	public object set_zMultiplier(object value) { }

	// RVA: 0x7454A60
	public object get_separateAxes() { }

	// RVA: 0x7454B50
	public object set_separateAxes(object value) { }

	// RVA: 0x7453B20
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7453C24
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x7453D5C
	private static object get_x_Injected(object _unity_self, object ret) { }

	// RVA: 0x7453E90
	private static object set_x_Injected(object _unity_self, object value) { }

	// RVA: 0x7453F9C
	private static object get_xMultiplier_Injected(object _unity_self) { }

	// RVA: 0x74540A0
	private static object set_xMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x74541D8
	private static object get_y_Injected(object _unity_self, object ret) { }

	// RVA: 0x745430C
	private static object set_y_Injected(object _unity_self, object value) { }

	// RVA: 0x7454418
	private static object get_yMultiplier_Injected(object _unity_self) { }

	// RVA: 0x745451C
	private static object set_yMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7454654
	private static object get_z_Injected(object _unity_self, object ret) { }

	// RVA: 0x7454788
	private static object set_z_Injected(object _unity_self, object value) { }

	// RVA: 0x7454894
	private static object get_zMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7454998
	private static object set_zMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7454AB0
	private static object get_separateAxes_Injected(object _unity_self) { }

	// RVA: 0x7454BB4
	private static object set_separateAxes_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct RotationBySpeedModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }
	public object x { get; set; }
	public object xMultiplier { get; set; }
	public object y { get; set; }
	public object yMultiplier { get; set; }
	public object z { get; set; }
	public object zMultiplier { get; set; }
	public object separateAxes { get; set; }
	public object range { get; set; }

	// Methods

	// RVA: 0x743C4F0
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7454CC0
	public object get_enabled() { }

	// RVA: 0x7454DB0
	public object set_enabled(object value) { }

	// RVA: 0x7454EDC
	public object get_x() { }

	// RVA: 0x745501C
	public object set_x(object value) { }

	// RVA: 0x745513C
	public object get_xMultiplier() { }

	// RVA: 0x745522C
	public object set_xMultiplier(object value) { }

	// RVA: 0x7455358
	public object get_y() { }

	// RVA: 0x7455498
	public object set_y(object value) { }

	// RVA: 0x74555B8
	public object get_yMultiplier() { }

	// RVA: 0x74556A8
	public object set_yMultiplier(object value) { }

	// RVA: 0x74557D4
	public object get_z() { }

	// RVA: 0x7455914
	public object set_z(object value) { }

	// RVA: 0x7455A34
	public object get_zMultiplier() { }

	// RVA: 0x7455B24
	public object set_zMultiplier(object value) { }

	// RVA: 0x7455C50
	public object get_separateAxes() { }

	// RVA: 0x7455D40
	public object set_separateAxes(object value) { }

	// RVA: 0x7455E6C
	public object get_range() { }

	// RVA: 0x7455F84
	public object set_range(object value) { }

	// RVA: 0x7454D10
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7454E14
	private static object set_enabled_Injected(object _unity_self, object value) { }

	// RVA: 0x7454F4C
	private static object get_x_Injected(object _unity_self, object ret) { }

	// RVA: 0x7455080
	private static object set_x_Injected(object _unity_self, object value) { }

	// RVA: 0x745518C
	private static object get_xMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7455290
	private static object set_xMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x74553C8
	private static object get_y_Injected(object _unity_self, object ret) { }

	// RVA: 0x74554FC
	private static object set_y_Injected(object _unity_self, object value) { }

	// RVA: 0x7455608
	private static object get_yMultiplier_Injected(object _unity_self) { }

	// RVA: 0x745570C
	private static object set_yMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7455844
	private static object get_z_Injected(object _unity_self, object ret) { }

	// RVA: 0x7455978
	private static object set_z_Injected(object _unity_self, object value) { }

	// RVA: 0x7455A84
	private static object get_zMultiplier_Injected(object _unity_self) { }

	// RVA: 0x7455B88
	private static object set_zMultiplier_Injected(object _unity_self, object value) { }

	// RVA: 0x7455CA0
	private static object get_separateAxes_Injected(object _unity_self) { }

	// RVA: 0x7455DA4
	private static object set_separateAxes_Injected(object _unity_self, object value) { }

	// RVA: 0x7455EC8
	private static object get_range_Injected(object _unity_self, object ret) { }

	// RVA: 0x7455FF4
	private static object set_range_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct ExternalForcesModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }

	// Methods

	// RVA: 0x743C4FC
	internal object .ctor(object particleSystem) { }

	// RVA: 0x74560F0
	public object get_enabled() { }

	// RVA: 0x74561E0
	public object set_enabled(object value) { }

	// RVA: 0x7456140
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7456244
	private static object set_enabled_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct NoiseModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }

	// Methods

	// RVA: 0x743C508
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7456350
	public object get_enabled() { }

	// RVA: 0x7456440
	public object set_enabled(object value) { }

	// RVA: 0x74563A0
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x74564A4
	private static object set_enabled_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct LightsModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }

	// Methods

	// RVA: 0x743C544
	internal object .ctor(object particleSystem) { }

	// RVA: 0x74565B0
	public object get_enabled() { }

	// RVA: 0x74566A0
	public object set_enabled(object value) { }

	// RVA: 0x7456600
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7456704
	private static object set_enabled_Injected(object _unity_self, object value) { }

}

// Namespace: 
public struct TrailModule
{

	// Fields
	internal object m_ParticleSystem; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object enabled { get; set; }

	// Methods

	// RVA: 0x743C550
	internal object .ctor(object particleSystem) { }

	// RVA: 0x7456810
	public object get_enabled() { }

	// RVA: 0x7456900
	public object set_enabled(object value) { }

	// RVA: 0x7456860
	private static object get_enabled_Injected(object _unity_self) { }

	// RVA: 0x7456964
	private static object set_enabled_Injected(object _unity_self, object value) { }

}

// Namespace: UnityEngine
public sealed class ParticleSystem
{

	// Properties
	public object playOnAwake { get; set; }
	public object playbackSpeed { set; }
	public object enableEmission { get; set; }
	public object startSpeed { get; set; }
	public object startSize { get; set; }
	public object startLifetime { get; set; }
	public object gravityModifier { get; set; }
	public object simulationSpace { get; }
	public object isPlaying { get; }
	public object isEmitting { get; }
	public object isStopped { get; }
	public object isPaused { get; }
	public object particleCount { get; }
	public object time { get; set; }
	public object randomSeed { get; set; }
	public object useAutoRandomSeed { get; set; }
	public object main { get; }
	public object emission { get; }
	public object shape { get; }
	public object velocityOverLifetime { get; }
	public object limitVelocityOverLifetime { get; }
	public object inheritVelocity { get; }
	public object forceOverLifetime { get; }
	public object colorOverLifetime { get; }
	public object colorBySpeed { get; }
	public object sizeOverLifetime { get; }
	public object sizeBySpeed { get; }
	public object rotationOverLifetime { get; }
	public object rotationBySpeed { get; }
	public object externalForces { get; }
	public object noise { get; }
	public object collision { get; }
	public object trigger { get; }
	public object subEmitters { get; }
	public object textureSheetAnimation { get; }
	public object lights { get; }
	public object trails { get; }

	// Methods

	// RVA: 0x743AD20
	public object Emit(object position, object velocity, object size, object lifetime, object color) { }

	// RVA: 0x743AF74
	public object Emit(object particle) { }

	// RVA: 0x743AFD8
	public object get_playOnAwake() { }

	// RVA: 0x743B090
	public object set_playOnAwake(object value) { }

	// RVA: 0x743B160
	public object set_playbackSpeed(object value) { }

	// RVA: 0x743B220
	public object get_enableEmission() { }

	// RVA: 0x743B2D8
	public object set_enableEmission(object value) { }

	// RVA: 0x743B3A8
	public object get_startSpeed() { }

	// RVA: 0x743B45C
	public object set_startSpeed(object value) { }

	// RVA: 0x743B51C
	public object get_startSize() { }

	// RVA: 0x743B5D0
	public object set_startSize(object value) { }

	// RVA: 0x743B690
	public object get_startLifetime() { }

	// RVA: 0x743B744
	public object set_startLifetime(object value) { }

	// RVA: 0x743B804
	public object get_gravityModifier() { }

	// RVA: 0x743B8B8
	public object set_gravityModifier(object value) { }

	// RVA: 0x743B978
	public object get_simulationSpace() { }

	// RVA: 0x743BA2C
	public object get_isPlaying() { }

	// RVA: 0x743BA7C
	public object get_isEmitting() { }

	// RVA: 0x743BACC
	public object get_isStopped() { }

	// RVA: 0x743BB1C
	public object get_isPaused() { }

	// RVA: 0x743BB6C
	public object get_particleCount() { }

	// RVA: 0x743BBBC
	public object get_time() { }

	// RVA: 0x743BC0C
	public object set_time(object value) { }

	// RVA: 0x743BC70
	public object get_randomSeed() { }

	// RVA: 0x743BCC0
	public object set_randomSeed(object value) { }

	// RVA: 0x743BD24
	public object get_useAutoRandomSeed() { }

	// RVA: 0x743BD74
	public object set_useAutoRandomSeed(object value) { }

	// RVA: 0x743BDD8
	public object Simulate(object t, object withChildren, object restart, object fixedTimeStep) { }

	// RVA: 0x743BE6C
	public object Simulate(object t, object withChildren, object restart) { }

	// RVA: 0x743BEF4
	public object Play(object withChildren) { }

	// RVA: 0x743BF58
	public object Play() { }

	// RVA: 0x743BFB0
	public object Pause(object withChildren) { }

	// RVA: 0x743C014
	public object Pause() { }

	// RVA: 0x743C06C
	public object Stop(object withChildren, object stopBehavior) { }

	// RVA: 0x743C0D8
	public object Stop(object withChildren) { }

	// RVA: 0x743C144
	public object Stop() { }

	// RVA: 0x743C1A4
	public object Clear(object withChildren) { }

	// RVA: 0x743C208
	public object IsAlive(object withChildren) { }

	// RVA: 0x743C26C
	public object IsAlive() { }

	// RVA: 0x743C2C4
	public object Emit(object count) { }

	// RVA: 0x743C328
	private object Emit_Internal(object count) { }

	// RVA: 0x743C38C
	public object Emit(object emitParams, object count) { }

	// RVA: 0x743AF10
	private object EmitOld_Internal(object particle) { }

	// RVA: 0x743B03C
	public object get_main() { }

	// RVA: 0x743B284
	public object get_emission() { }

	// RVA: 0x743C474
	public object get_shape() { }

	// RVA: 0x743C480
	public object get_velocityOverLifetime() { }

	// RVA: 0x743C48C
	public object get_limitVelocityOverLifetime() { }

	// RVA: 0x743C498
	public object get_inheritVelocity() { }

	// RVA: 0x743C4A4
	public object get_forceOverLifetime() { }

	// RVA: 0x743C4B0
	public object get_colorOverLifetime() { }

	// RVA: 0x743C4BC
	public object get_colorBySpeed() { }

	// RVA: 0x743C4C8
	public object get_sizeOverLifetime() { }

	// RVA: 0x743C4D4
	public object get_sizeBySpeed() { }

	// RVA: 0x743C4E0
	public object get_rotationOverLifetime() { }

	// RVA: 0x743C4EC
	public object get_rotationBySpeed() { }

	// RVA: 0x743C4F8
	public object get_externalForces() { }

	// RVA: 0x743C504
	public object get_noise() { }

	// RVA: 0x743C510
	public object get_collision() { }

	// RVA: 0x743C51C
	public object get_trigger() { }

	// RVA: 0x743C528
	public object get_subEmitters() { }

	// RVA: 0x743C534
	public object get_textureSheetAnimation() { }

	// RVA: 0x743C540
	public object get_lights() { }

	// RVA: 0x743C54C
	public object get_trails() { }

	// RVA: 0x743C558
	public object .ctor() { }

	// RVA: 0x743C3F8
	private object Emit_Injected(object emitParams, object count) { }

}

// Namespace: UnityEngine
public enum ParticleSystemRenderMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Billboard;
	public const object Stretch;
	public const object HorizontalBillboard;
	public const object VerticalBillboard;
	public const object Mesh;
	public const object None;
}

// Namespace: UnityEngine
public enum ParticleSystemSortMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Distance;
	public const object OldestInFront;
	public const object YoungestInFront;
	public const object Depth;
}

// Namespace: UnityEngine
public enum ParticleSystemRenderSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object View;
	public const object World;
	public const object Local;
	public const object Facing;
	public const object Velocity;
}

// Namespace: UnityEngine
public enum ParticleSystemCurveMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Constant;
	public const object Curve;
	public const object TwoCurves;
	public const object TwoConstants;
}

// Namespace: UnityEngine
public enum ParticleSystemGradientMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Color;
	public const object Gradient;
	public const object TwoColors;
	public const object TwoGradients;
	public const object RandomColor;
}

// Namespace: UnityEngine
public enum ParticleSystemShapeType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Sphere;
	public const object SphereShell;
	public const object Hemisphere;
	public const object HemisphereShell;
	public const object Cone;
	public const object Box;
	public const object Mesh;
	public const object ConeShell;
	public const object ConeVolume;
	public const object ConeVolumeShell;
	public const object Circle;
	public const object CircleEdge;
	public const object SingleSidedEdge;
	public const object MeshRenderer;
	public const object SkinnedMeshRenderer;
	public const object BoxShell;
	public const object BoxEdge;
	public const object Donut;
	public const object Rectangle;
	public const object Sprite;
	public const object SpriteRenderer;
}

// Namespace: UnityEngine
public enum ParticleSystemMeshShapeType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Vertex;
	public const object Edge;
	public const object Triangle;
}

// Namespace: UnityEngine
public enum ParticleSystemAnimationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Grid;
	public const object Sprites;
}

// Namespace: UnityEngine
public enum ParticleSystemAnimationType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object WholeSheet;
	public const object SingleRow;
}

// Namespace: UnityEngine
public enum ParticleSystemAnimationRowMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Custom;
	public const object Random;
	public const object MeshIndex;
}

// Namespace: UnityEngine
public enum ParticleSystemSimulationSpace
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Local;
	public const object World;
	public const object Custom;
}

// Namespace: UnityEngine
public enum ParticleSystemStopBehavior
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object StopEmittingAndClear;
	public const object StopEmitting;
}

// Namespace: UnityEngine
public enum ParticleSystemScalingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Hierarchy;
	public const object Local;
	public const object Shape;
}

// Namespace: UnityEngine
public enum ParticleSystemStopAction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Disable;
	public const object Destroy;
	public const object Callback;
}

// Namespace: UnityEngine
public enum ParticleSystemEmitterVelocityMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Transform;
	public const object Rigidbody;
	public const object Custom;
}

// Namespace: UnityEngine
public enum ParticleSystemInheritVelocityMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Initial;
	public const object Current;
}

// Namespace: UnityEngine
public enum ParticleSystemShapeMultiModeValue
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Random;
	public const object Loop;
	public const object PingPong;
	public const object BurstSpread;
}

// Namespace: UnityEngine
public sealed class ParticleSystemRenderer
{

	// Properties
	public object alignment { get; set; }
	public object renderMode { get; set; }
	public object sortMode { get; set; }
	public object lengthScale { get; set; }
	public object velocityScale { get; set; }
	public object cameraVelocityScale { get; set; }
	public object normalDirection { get; set; }
	public object sortingFudge { get; set; }
	public object minParticleSize { get; set; }
	public object maxParticleSize { get; set; }
	public object pivot { get; set; }
	public object flip { get; set; }
	public object maskInteraction { get; set; }
	public object trailMaterial { get; set; }
	public object mesh { get; set; }
	public object meshCount { get; }

	// Methods

	// RVA: 0x7456A2C
	public object get_alignment() { }

	// RVA: 0x7456A7C
	public object set_alignment(object value) { }

	// RVA: 0x7456AE0
	public object get_renderMode() { }

	// RVA: 0x7456B30
	public object set_renderMode(object value) { }

	// RVA: 0x7456B94
	public object get_sortMode() { }

	// RVA: 0x7456BE4
	public object set_sortMode(object value) { }

	// RVA: 0x7456C48
	public object get_lengthScale() { }

	// RVA: 0x7456C98
	public object set_lengthScale(object value) { }

	// RVA: 0x7456CFC
	public object get_velocityScale() { }

	// RVA: 0x7456D4C
	public object set_velocityScale(object value) { }

	// RVA: 0x7456DB0
	public object get_cameraVelocityScale() { }

	// RVA: 0x7456E00
	public object set_cameraVelocityScale(object value) { }

	// RVA: 0x7456E64
	public object get_normalDirection() { }

	// RVA: 0x7456EB4
	public object set_normalDirection(object value) { }

	// RVA: 0x7456F18
	public object get_sortingFudge() { }

	// RVA: 0x7456F68
	public object set_sortingFudge(object value) { }

	// RVA: 0x7456FCC
	public object get_minParticleSize() { }

	// RVA: 0x745701C
	public object set_minParticleSize(object value) { }

	// RVA: 0x7457080
	public object get_maxParticleSize() { }

	// RVA: 0x74570D0
	public object set_maxParticleSize(object value) { }

	// RVA: 0x7457134
	public object get_pivot() { }

	// RVA: 0x74571FC
	public object set_pivot(object value) { }

	// RVA: 0x7448000
	public object get_flip() { }

	// RVA: 0x7448210
	public object set_flip(object value) { }

	// RVA: 0x745739C
	public object get_maskInteraction() { }

	// RVA: 0x74573EC
	public object set_maskInteraction(object value) { }

	// RVA: 0x7457450
	public object get_trailMaterial() { }

	// RVA: 0x74574A0
	public object set_trailMaterial(object value) { }

	// RVA: 0x7457504
	public object get_mesh() { }

	// RVA: 0x7457554
	public object set_mesh(object value) { }

	// RVA: 0x74575B8
	public object GetMeshes(object meshes) { }

	// RVA: 0x745761C
	public object get_meshCount() { }

	// RVA: 0x7457198
	private object get_pivot_Injected(object ret) { }

	// RVA: 0x7457270
	private object set_pivot_Injected(object value) { }

	// RVA: 0x74572D4
	private object get_flip_Injected(object ret) { }

	// RVA: 0x7457338
	private object set_flip_Injected(object value) { }

}

// Namespace: UnityEngine.Rendering
public enum UVChannelFlags
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UV0;
	public const object UV1;
	public const object UV2;
	public const object UV3;
}

