// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.Playables
public class PlayableDirector
{

	// Fields
	private object played; // 0x10
	private object paused; // 0x18
	private object stopped; // 0x20

	// Properties
	public object state { get; }
	public object extrapolationMode { get; set; }
	public object playableAsset { get; }
	public object playableGraph { get; }
	public object playOnAwake { set; }
	public object timeUpdateMode { get; set; }
	public object time { get; set; }
	public object duration { get; }

	// Methods

	// RVA: 0x73F5CF8
	public object get_state() { }

	// RVA: 0x73F5D98
	public object set_extrapolationMode(object value) { }

	// RVA: 0x73F5E60
	public object get_extrapolationMode() { }

	// RVA: 0x73F5F00
	public object get_playableAsset() { }

	// RVA: 0x73F6020
	public object get_playableGraph() { }

	// RVA: 0x73F60D8
	public object set_playOnAwake(object value) { }

	// RVA: 0x73F61A0
	internal object Play(object frameRate) { }

	// RVA: 0x73F6280
	public object SetGenericBinding(object key, object value) { }

	// RVA: 0x73F6358
	public object set_timeUpdateMode(object value) { }

	// RVA: 0x73F63BC
	public object get_timeUpdateMode() { }

	// RVA: 0x73F640C
	public object set_time(object value) { }

	// RVA: 0x73F6470
	public object get_time() { }

	// RVA: 0x73F64C0
	public object get_duration() { }

	// RVA: 0x73F6510
	public object Evaluate() { }

	// RVA: 0x73F6210
	private object PlayOnFrame(object frameRate) { }

	// RVA: 0x73F65C4
	public object Play() { }

	// RVA: 0x73F6614
	public object Stop() { }

	// RVA: 0x73F6664
	public object Pause() { }

	// RVA: 0x73F66B4
	public object Resume() { }

	// RVA: 0x73F6704
	public object RebuildGraph() { }

	// RVA: 0x73F6754
	public object SetReferenceValue(object id, object value) { }

	// RVA: 0x73F6828
	public object GetReferenceValue(object id, object idValid) { }

	// RVA: 0x73F68FC
	public object GetGenericBinding(object key) { }

	// RVA: 0x73F5D48
	private object GetPlayState() { }

	// RVA: 0x73F5DFC
	private object SetWrapMode(object mode) { }

	// RVA: 0x73F5EB0
	private object GetWrapMode() { }

	// RVA: 0x73F607C
	private object GetGraphHandle() { }

	// RVA: 0x73F613C
	private object SetPlayOnAwake(object on) { }

	// RVA: 0x73F62EC
	private object Internal_SetGenericBinding(object key, object value) { }

	// RVA: 0x73F5FD0
	private object Internal_GetPlayableAsset() { }

	// RVA: 0x73F69C4
	private object SendOnPlayableDirectorPlay() { }

	// RVA: 0x73F69E4
	private object SendOnPlayableDirectorPause() { }

	// RVA: 0x73F6A04
	private object SendOnPlayableDirectorStop() { }

	// RVA: 0x73F6560
	private object PlayOnFrame_Injected(object frameRate) { }

	// RVA: 0x73F67BC
	private object SetReferenceValue_Injected(object id, object value) { }

	// RVA: 0x73F6890
	private object GetReferenceValue_Injected(object id, object idValid) { }

	// RVA: 0x73F6960
	private object GetGraphHandle_Injected(object ret) { }

}

