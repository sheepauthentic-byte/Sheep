// Namespace: 
internal class <Module>
{
}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0xF92970
	private static object Get() { }

	// RVA: 0xF92A3C
	public object .ctor() { }

}

// Namespace: AutoOpt.Utilities
public static class UnityExtension
{

	// Methods

	// RVA: 0xF92B78
	public static object FindChild(object gameObj, object name, object onlyFindActive) { }

	// RVA: 0xF92FB4
	public static object CompareName(object obj, object name) { }

}

// Namespace: AutoOpt.Core
public static class ConstVars
{
}

// Namespace: AutoOpt.Core
public static class Package
{

	// Fields
	public const object PackageName;
	public const object PackagePath;

	// Methods

	// RVA: 0xF93020
	public static object GetPackageAssetPath(object relativePath) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=89
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=553
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 9CC54BE6FEA53DA912884F2DAD3A6D335CD1657A961510A0A83068056837040A; // 0x0
	internal static readonly object B5AD94513B16E4D922731AC9A3D1E5A9961033799357C1D1B94427E548F7C1F3; // 0x229
}

