// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.TextCore.Text
public class Character
{

	// Methods

	// RVA: 0x74A068C
	public object .ctor() { }

	// RVA: 0x74A06D0
	public object .ctor(object unicode, object fontAsset, object glyph) { }

	// RVA: 0x74A075C
	internal object .ctor(object unicode, object glyphIndex) { }

}

// Namespace: UnityEngine.TextCore.Text
internal static class ColorUtilities
{

	// Methods

	// RVA: 0x74A07A8
	internal static object CompareColors(object a, object b) { }

	// RVA: 0x74A07B8
	internal static object MultiplyColors(object c1, object c2) { }

}

// Namespace: UnityEngine.TextCore.Text
public enum TextFontWeight
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Thin;
	public const object ExtraLight;
	public const object Light;
	public const object Regular;
	public const object Medium;
	public const object SemiBold;
	public const object Bold;
	public const object Heavy;
	public const object Black;
}

// Namespace: UnityEngine.TextCore.Text
public struct FontWeightPair
{

	// Fields
	public object regularTypeface; // 0xFFFFFFFFFFFFFFF8
	public object italicTypeface; // 0x0
}

// Namespace: UnityEngine.TextCore.Text
public struct FontAssetCreationEditorSettings
{

	// Fields
	public object sourceFontFileGUID; // 0xFFFFFFFFFFFFFFF8
	public object faceIndex; // 0x0
	public object pointSizeSamplingMode; // 0x4
	public object pointSize; // 0x8
	public object padding; // 0xC
	public object paddingMode; // 0x10
	public object packingMode; // 0x14
	public object atlasWidth; // 0x18
	public object atlasHeight; // 0x1C
	public object characterSetSelectionMode; // 0x20
	public object characterSequence; // 0x28
	public object referencedFontAssetGUID; // 0x30
	public object referencedTextAssetGUID; // 0x38
	public object fontStyle; // 0x40
	public object fontStyleModifier; // 0x44
	public object renderMode; // 0x48
	public object includeFontFeatures; // 0x4C
}

// Namespace: UnityEngine.TextCore.Text
public enum AtlasPopulationMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Static;
	public const object Dynamic;
	public const object DynamicOS;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__151_0; // 0x8
	public static object <>9__152_0; // 0x10

	// Methods

	// RVA: 0x74ACB80
	private static object .cctor() { }

	// RVA: 0x74ACBE0
	public object .ctor() { }

	// RVA: 0x74ACBE8
	internal object <SortCharacterTable>b__151_0(object c) { }

	// RVA: 0x74ACC08
	internal object <SortGlyphTable>b__152_0(object c) { }

}

// Namespace: UnityEngine.TextCore.Text
public class FontAsset
{

	// Fields
	internal object m_SourceFontFileGUID; // 0x30
	private object m_SourceFontFile; // 0x38
	private object m_SourceFontFilePath; // 0x40
	private object m_AtlasPopulationMode; // 0x48
	internal object InternalDynamicOS; // 0x4C
	internal object m_FaceInfo; // 0x50
	private object m_FamilyNameHashCode; // 0xB0
	private object m_StyleNameHashCode; // 0xB4
	internal object m_GlyphTable; // 0xB8
	internal object m_GlyphLookupDictionary; // 0xC0
	internal object m_CharacterTable; // 0xC8
	internal object m_CharacterLookupDictionary; // 0xD0
	internal object m_AtlasTexture; // 0xD8
	internal object m_AtlasTextures; // 0xE0
	internal object m_AtlasTextureIndex; // 0xE8
	private object m_IsMultiAtlasTexturesEnabled; // 0xEC
	private object m_ClearDynamicDataOnBuild; // 0xED
	internal object m_AtlasWidth; // 0xF0
	internal object m_AtlasHeight; // 0xF4
	internal object m_AtlasPadding; // 0xF8
	internal object m_AtlasRenderMode; // 0xFC
	private object m_UsedGlyphRects; // 0x100
	private object m_FreeGlyphRects; // 0x108
	internal object m_FontFeatureTable; // 0x110
	internal object m_FallbackFontAssetTable; // 0x118
	internal object m_fontAssetCreationEditorSettings; // 0x120
	private object m_FontWeightTable; // 0x178
	internal object m_RegularStyleWeight; // 0x180
	internal object m_RegularStyleSpacing; // 0x184
	internal object m_BoldStyleWeight; // 0x188
	internal object m_BoldStyleSpacing; // 0x18C
	internal object m_ItalicStyleSlant; // 0x190
	internal object m_TabMultiple; // 0x191
	internal object IsFontAssetLookupTablesDirty; // 0x192
	private static object k_ReadFontAssetDefinitionMarker; // 0x0
	private static object k_AddSynthesizedCharactersMarker; // 0x8
	private static object k_TryAddCharacterMarker; // 0x10
	private static object k_TryAddCharactersMarker; // 0x18
	private static object k_UpdateGlyphAdjustmentRecordsMarker; // 0x20
	private static object k_UpdateDiacriticalMarkAdjustmentRecordsMarker; // 0x28
	private static object k_ClearFontAssetDataMarker; // 0x30
	private static object k_UpdateFontAssetDataMarker; // 0x38
	private static object k_TryAddGlyphMarker; // 0x40
	private static object s_DefaultMaterialSuffix; // 0x48
	private static object k_SearchedFontAssetLookup; // 0x50
	private static object k_FontAssets_FontFeaturesUpdateQueue; // 0x58
	private static object k_FontAssets_FontFeaturesUpdateQueueLookup; // 0x60
	private static object k_FontAssets_AtlasTexturesUpdateQueue; // 0x68
	private static object k_FontAssets_AtlasTexturesUpdateQueueLookup; // 0x70
	private object m_GlyphsToRender; // 0x198
	private object m_GlyphsRendered; // 0x1A0
	private object m_GlyphIndexList; // 0x1A8
	private object m_GlyphIndexListNewlyAdded; // 0x1B0
	internal object m_GlyphsToAdd; // 0x1B8
	internal object m_GlyphsToAddLookup; // 0x1C0
	internal object m_CharactersToAdd; // 0x1C8
	internal object m_CharactersToAddLookup; // 0x1D0
	internal object s_MissingCharacterList; // 0x1D8
	internal object m_MissingUnicodesFromFontFile; // 0x1E0
	internal static object k_GlyphIndexArray; // 0x78

	// Properties
	public object sourceFontFile { get; set; }
	public object atlasPopulationMode { get; set; }
	public object faceInfo { get; set; }
	internal object familyNameHashCode { get; set; }
	internal object styleNameHashCode { get; set; }
	public object glyphTable { get; set; }
	public object glyphLookupTable { get; }
	public object characterTable { get; set; }
	public object characterLookupTable { get; }
	public object atlasTexture { get; }
	public object atlasTextures { get; set; }
	public object atlasTextureCount { get; }
	public object isMultiAtlasTexturesEnabled { get; set; }
	internal object clearDynamicDataOnBuild { get; set; }
	public object atlasWidth { get; set; }
	public object atlasHeight { get; set; }
	public object atlasPadding { get; set; }
	public object atlasRenderMode { get; set; }
	internal object usedGlyphRects { get; set; }
	internal object freeGlyphRects { get; set; }
	public object fontFeatureTable { get; set; }
	public object fallbackFontAssetTable { get; set; }
	public object fontAssetCreationEditorSettings { get; set; }
	public object fontWeightTable { get; set; }
	public object regularStyleWeight { get; set; }
	public object regularStyleSpacing { get; set; }
	public object boldStyleWeight { get; set; }
	public object boldStyleSpacing { get; set; }
	public object italicStyleSlant { get; set; }
	public object tabMultiple { get; set; }

	// Methods

	// RVA: 0x74A0A54
	public object get_sourceFontFile() { }

	// RVA: 0x74A0A5C
	internal object set_sourceFontFile(object value) { }

	// RVA: 0x74A0A64
	public object get_atlasPopulationMode() { }

	// RVA: 0x74A0A6C
	public object set_atlasPopulationMode(object value) { }

	// RVA: 0x74A0A74
	public object get_faceInfo() { }

	// RVA: 0x74A0A90
	public object set_faceInfo(object value) { }

	// RVA: 0x74A0A9C
	internal object get_familyNameHashCode() { }

	// RVA: 0x74A0AE0
	internal object set_familyNameHashCode(object value) { }

	// RVA: 0x74A0AE8
	internal object get_styleNameHashCode() { }

	// RVA: 0x74A0B2C
	internal object set_styleNameHashCode(object value) { }

	// RVA: 0x74A0B34
	public object get_glyphTable() { }

	// RVA: 0x74A0B3C
	internal object set_glyphTable(object value) { }

	// RVA: 0x74A0B44
	public object get_glyphLookupTable() { }

	// RVA: 0x74A100C
	public object get_characterTable() { }

	// RVA: 0x74A1014
	internal object set_characterTable(object value) { }

	// RVA: 0x74A101C
	public object get_characterLookupTable() { }

	// RVA: 0x74A1058
	public object get_atlasTexture() { }

	// RVA: 0x74A112C
	public object get_atlasTextures() { }

	// RVA: 0x74A1134
	public object set_atlasTextures(object value) { }

	// RVA: 0x74A113C
	public object get_atlasTextureCount() { }

	// RVA: 0x74A1148
	public object get_isMultiAtlasTexturesEnabled() { }

	// RVA: 0x74A1150
	public object set_isMultiAtlasTexturesEnabled(object value) { }

	// RVA: 0x74A1158
	internal object get_clearDynamicDataOnBuild() { }

	// RVA: 0x74A1160
	internal object set_clearDynamicDataOnBuild(object value) { }

	// RVA: 0x74A1168
	public object get_atlasWidth() { }

	// RVA: 0x74A1170
	internal object set_atlasWidth(object value) { }

	// RVA: 0x74A1178
	public object get_atlasHeight() { }

	// RVA: 0x74A1180
	internal object set_atlasHeight(object value) { }

	// RVA: 0x74A1188
	public object get_atlasPadding() { }

	// RVA: 0x74A1190
	internal object set_atlasPadding(object value) { }

	// RVA: 0x74A1198
	public object get_atlasRenderMode() { }

	// RVA: 0x74A11A0
	internal object set_atlasRenderMode(object value) { }

	// RVA: 0x74A11A8
	internal object get_usedGlyphRects() { }

	// RVA: 0x74A11B0
	internal object set_usedGlyphRects(object value) { }

	// RVA: 0x74A11B8
	internal object get_freeGlyphRects() { }

	// RVA: 0x74A11C0
	internal object set_freeGlyphRects(object value) { }

	// RVA: 0x74A11C8
	public object get_fontFeatureTable() { }

	// RVA: 0x74A11D0
	internal object set_fontFeatureTable(object value) { }

	// RVA: 0x74A11D8
	public object get_fallbackFontAssetTable() { }

	// RVA: 0x74A11E0
	public object set_fallbackFontAssetTable(object value) { }

	// RVA: 0x74A11E8
	public object get_fontAssetCreationEditorSettings() { }

	// RVA: 0x74A120C
	public object set_fontAssetCreationEditorSettings(object value) { }

	// RVA: 0x74A1218
	public object get_fontWeightTable() { }

	// RVA: 0x74A1220
	internal object set_fontWeightTable(object value) { }

	// RVA: 0x74A1228
	public object get_regularStyleWeight() { }

	// RVA: 0x74A1230
	public object set_regularStyleWeight(object value) { }

	// RVA: 0x74A1238
	public object get_regularStyleSpacing() { }

	// RVA: 0x74A1240
	public object set_regularStyleSpacing(object value) { }

	// RVA: 0x74A1248
	public object get_boldStyleWeight() { }

	// RVA: 0x74A1250
	public object set_boldStyleWeight(object value) { }

	// RVA: 0x74A1258
	public object get_boldStyleSpacing() { }

	// RVA: 0x74A1260
	public object set_boldStyleSpacing(object value) { }

	// RVA: 0x74A1268
	public object get_italicStyleSlant() { }

	// RVA: 0x74A1270
	public object set_italicStyleSlant(object value) { }

	// RVA: 0x74A1278
	public object get_tabMultiple() { }

	// RVA: 0x74A1280
	public object set_tabMultiple(object value) { }

	// RVA: 0x74A1288
	public static object CreateFontAsset(object familyName, object styleName, object pointSize) { }

	// RVA: 0x74A1658
	public static object CreateFontAsset(object fontFilePath, object faceIndex, object samplingPointSize, object atlasPadding, object renderMode, object atlasWidth, object atlasHeight) { }

	// RVA: 0x74A14B4
	private static object CreateFontAsset(object fontFilePath, object faceIndex, object samplingPointSize, object atlasPadding, object renderMode, object atlasWidth, object atlasHeight, object atlasPopulationMode, object enableMultiAtlasSupport) { }

	// RVA: 0x74A1C30
	public static object CreateFontAsset(object font) { }

	// RVA: 0x74A1D18
	public static object CreateFontAsset(object font, object samplingPointSize, object atlasPadding, object renderMode, object atlasWidth, object atlasHeight, object atlasPopulationMode, object enableMultiAtlasSupport) { }

	// RVA: 0x74A1DD8
	private static object CreateFontAsset(object font, object faceIndex, object samplingPointSize, object atlasPadding, object renderMode, object atlasWidth, object atlasHeight, object atlasPopulationMode, object enableMultiAtlasSupport) { }

	// RVA: 0x74A1718
	private static object CreateFontAssetInstance(object font, object atlasPadding, object renderMode, object atlasWidth, object atlasHeight, object atlasPopulationMode, object enableMultiAtlasSupport) { }

	// RVA: 0x74A2044
	private object Awake() { }

	// RVA: 0x74A2048
	private object OnDestroy() { }

	// RVA: 0x74A0B80
	public object ReadFontAssetDefinition() { }

	// RVA: 0x74A21CC
	internal object InitializeDictionaryLookupTables() { }

	// RVA: 0x74A244C
	internal object InitializeGlyphLookupDictionary() { }

	// RVA: 0x74A279C
	internal object InitializeCharacterLookupDictionary() { }

	// RVA: 0x74A2984
	internal object InitializeLigatureSubstitutionLookupDictionary() { }

	// RVA: 0x74A2E08
	internal object InitializeGlyphPaidAdjustmentRecordsLookupDictionary() { }

	// RVA: 0x74A3090
	internal object InitializeMarkToBaseAdjustmentRecordsLookupDictionary() { }

	// RVA: 0x74A32B8
	internal object InitializeMarkToMarkAdjustmentRecordsLookupDictionary() { }

	// RVA: 0x74A2210
	internal object AddSynthesizedCharactersAndFaceMetrics() { }

	// RVA: 0x74A3690
	private object AddSynthesizedCharacter(object unicode, object isFontFaceLoaded, object addImmediately) { }

	// RVA: 0x74A3948
	internal object AddCharacterToLookupCache(object unicode, object character) { }

	// RVA: 0x74A34E8
	private object LoadFontFace() { }

	// RVA: 0x74A39BC
	internal object SortCharacterTable() { }

	// RVA: 0x74A3B0C
	internal object SortGlyphTable() { }

	// RVA: 0x74A3C5C
	internal object SortFontFeatureTable() { }

	// RVA: 0x74A42EC
	internal object SortAllTables() { }

	// RVA: 0x74A4358
	public object HasCharacter(object character) { }

	// RVA: 0x74A43C8
	public object HasCharacter(object character, object searchFallbacks, object tryAddCharacter) { }

	// RVA: 0x74A43D0
	public object HasCharacter(object character, object searchFallbacks, object tryAddCharacter) { }

	// RVA: 0x74A558C
	private object HasCharacter_Internal(object character, object searchFallbacks, object tryAddCharacter) { }

	// RVA: 0x74A57DC
	public object HasCharacters(object text, object missingCharacters) { }

	// RVA: 0x74A5A10
	public object HasCharacters(object text, object missingCharacters, object searchFallbacks, object tryAddCharacter) { }

	// RVA: 0x74A5F54
	public object HasCharacters(object text) { }

	// RVA: 0x74A604C
	public static object GetCharacters(object fontAsset) { }

	// RVA: 0x74A618C
	public static object GetCharactersArray(object fontAsset) { }

	// RVA: 0x74A62CC
	internal object GetGlyphIndex(object unicode) { }

	// RVA: 0x74A63FC
	internal static object RegisterFontAssetForFontFeatureUpdate(object fontAsset) { }

	// RVA: 0x74A6630
	internal static object UpdateFontFeaturesForFontAssetsInQueue() { }

	// RVA: 0x74A68AC
	internal static object RegisterAtlasTextureForApply(object texture) { }

	// RVA: 0x74A6A7C
	internal static object UpdateAtlasTexturesInQueue() { }

	// RVA: 0x74A6C44
	internal static object UpdateFontAssetsInUpdateQueue() { }

	// RVA: 0x74A6CB4
	public object TryAddCharacters(object unicodes, object includeFontFeatures) { }

	// RVA: 0x74A6CD8
	public object TryAddCharacters(object unicodes, object missingUnicodes, object includeFontFeatures) { }

	// RVA: 0x74A8610
	public object TryAddCharacters(object characters, object includeFontFeatures) { }

	// RVA: 0x74A8634
	public object TryAddCharacters(object characters, object missingCharacters, object includeFontFeatures) { }

	// RVA: 0x74A986C
	internal object TryAddGlyphInternal(object glyphIndex, object glyph) { }

	// RVA: 0x74A4758
	internal object TryAddCharacterInternal(object unicode, object character, object shouldGetFontFeatures) { }

	// RVA: 0x74AA67C
	internal object TryGetCharacter_and_QueueRenderToTexture(object unicode, object character, object shouldGetFontFeatures) { }

	// RVA: 0x74AAF34
	internal object TryAddGlyphsToAtlasTextures() { }

	// RVA: 0x74A7F44
	private object TryAddGlyphsToNewAtlasTexture() { }

	// RVA: 0x74AA3BC
	private object SetupNewAtlasTexture() { }

	// RVA: 0x74A6848
	private object UpdateAllFontFeatures() { }

	// RVA: 0x74AAF38
	internal object UpdateGlyphAdjustmentRecords() { }

	// RVA: 0x74AB700
	internal object UpdateGlyphAdjustmentRecords(object glyphIndexes) { }

	// RVA: 0x74ABC30
	internal object UpdateGlyphAdjustmentRecords(object glyphIndexes) { }

	// RVA: 0x74ABC34
	internal object UpdateGlyphAdjustmentRecords(object newGlyphIndexes, object allGlyphIndexes) { }

	// RVA: -1
	private object CopyListDataToArray(object srcList, object dstArray) { }

	// RVA: 0x74ABC38
	public object ClearFontAssetData(object setAtlasSizeToZero) { }

	// RVA: 0x74AC2EC
	internal object ClearFontAssetDataInternal(object clearFontFeatures) { }

	// RVA: 0x74AC314
	internal object UpdateFontAssetData() { }

	// RVA: 0x74ABD84
	internal object ClearFontAssetTables(object clearFontFeatures) { }

	// RVA: 0x74AC07C
	internal object ClearAtlasTextures(object setAtlasSizeToZero) { }

	// RVA: 0x74A20E8
	private object DestroyAtlasTextures() { }

	// RVA: 0x74AC598
	public object .ctor() { }

	// RVA: 0x74AC818
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal static class FontAssetUtilities
{

	// Fields
	private static object k_SearchedAssets; // 0x0

	// Methods

	// RVA: 0x74ACC2C
	internal static object GetCharacterFromFontAsset(object unicode, object sourceFontAsset, object includeFallbacks, object fontStyle, object fontWeight, object isAlternativeTypeface) { }

	// RVA: 0x74ACD30
	private static object GetCharacterFromFontAsset_Internal(object unicode, object sourceFontAsset, object includeFallbacks, object fontStyle, object fontWeight, object isAlternativeTypeface) { }

	// RVA: 0x74AD2A8
	public static object GetCharacterFromFontAssets(object unicode, object sourceFontAsset, object fontAssets, object includeFallbacks, object fontStyle, object fontWeight, object isAlternativeTypeface) { }

	// RVA: 0x74AD480
	public static object GetSpriteCharacterFromSpriteAsset(object unicode, object spriteAsset, object includeFallbacks) { }

	// RVA: 0x74AD7E0
	private static object GetSpriteCharacterFromSpriteAsset_Internal(object unicode, object spriteAsset, object includeFallbacks) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__25_0; // 0x8
	public static object <>9__25_1; // 0x10
	public static object <>9__26_0; // 0x18
	public static object <>9__26_1; // 0x20
	public static object <>9__27_0; // 0x28
	public static object <>9__27_1; // 0x30

	// Methods

	// RVA: 0x74AD9F4
	private static object .cctor() { }

	// RVA: 0x74ADA54
	public object .ctor() { }

	// RVA: 0x74ADA5C
	internal object <SortGlyphPairAdjustmentRecords>b__25_0(object s) { }

	// RVA: 0x74ADAA0
	internal object <SortGlyphPairAdjustmentRecords>b__25_1(object s) { }

	// RVA: 0x74ADAE4
	internal object <SortMarkToBaseAdjustmentRecords>b__26_0(object s) { }

	// RVA: 0x74ADAF0
	internal object <SortMarkToBaseAdjustmentRecords>b__26_1(object s) { }

	// RVA: 0x74ADAFC
	internal object <SortMarkToMarkAdjustmentRecords>b__27_0(object s) { }

	// RVA: 0x74ADB08
	internal object <SortMarkToMarkAdjustmentRecords>b__27_1(object s) { }

}

// Namespace: UnityEngine.TextCore.Text
public class FontFeatureTable
{

	// Fields
	internal object m_MultipleSubstitutionRecords; // 0x8
	internal object m_LigatureSubstitutionRecords; // 0x10
	internal object m_GlyphPairAdjustmentRecords; // 0x18
	internal object m_MarkToBaseAdjustmentRecords; // 0x20
	internal object m_MarkToMarkAdjustmentRecords; // 0x28
	internal object m_LigatureSubstitutionRecordLookup; // 0x30
	internal object m_GlyphPairAdjustmentRecordLookup; // 0x38
	internal object m_MarkToBaseAdjustmentRecordLookup; // 0x40
	internal object m_MarkToMarkAdjustmentRecordLookup; // 0x48

	// Methods

	// RVA: 0x74AB4A4
	internal object .ctor() { }

	// RVA: 0x74A3CBC
	public object SortGlyphPairAdjustmentRecords() { }

	// RVA: 0x74A3ECC
	public object SortMarkToBaseAdjustmentRecords() { }

	// RVA: 0x74A40DC
	public object SortMarkToMarkAdjustmentRecords() { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct Extents
{

	// Fields
	public object min; // 0xFFFFFFFFFFFFFFF8
	public object max; // 0x0

	// Methods

	// RVA: 0x74ADB14
	public override object ToString() { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct LineInfo
{

	// Fields
	internal object controlCharacterCount; // 0xFFFFFFFFFFFFFFF8
	public object characterCount; // 0xFFFFFFFFFFFFFFFC
	public object visibleCharacterCount; // 0x0
	public object spaceCount; // 0x4
	public object visibleSpaceCount; // 0x8
	public object wordCount; // 0xC
	public object firstCharacterIndex; // 0x10
	public object firstVisibleCharacterIndex; // 0x14
	public object lastCharacterIndex; // 0x18
	public object lastVisibleCharacterIndex; // 0x1C
	public object length; // 0x20
	public object lineHeight; // 0x24
	public object ascender; // 0x28
	public object baseline; // 0x2C
	public object descender; // 0x30
	public object maxAdvance; // 0x34
	public object width; // 0x38
	public object marginLeft; // 0x3C
	public object marginRight; // 0x40
	public object alignment; // 0x44
	public object lineExtents; // 0x48
}

// Namespace: UnityEngine.TextCore.Text
internal struct LinkInfo
{

	// Fields
	public object hashCode; // 0xFFFFFFFFFFFFFFF8
	public object linkIdFirstCharacterIndex; // 0xFFFFFFFFFFFFFFFC
	public object linkIdLength; // 0x0
	public object linkTextfirstCharacterIndex; // 0x4
	public object linkTextLength; // 0x8
	internal object linkId; // 0x10
	private object m_LinkIdString; // 0x18
	private object m_LinkTextString; // 0x20

	// Methods

	// RVA: 0x74ADF4C
	internal object SetLinkId(object text, object startIndex, object length) { }

	// RVA: 0x74AE060
	public object GetLinkText(object textInfo) { }

	// RVA: 0x74AE188
	public object GetLinkId() { }

}

// Namespace: UnityEngine.TextCore.Text
internal static class MaterialManager
{

	// Fields
	private static object s_FallbackMaterials; // 0x0

	// Methods

	// RVA: 0x74AE238
	public static object GetFallbackMaterial(object sourceMaterial, object targetMaterial) { }

	// RVA: 0x74AE988
	public static object GetFallbackMaterial(object fontAsset, object sourceMaterial, object atlasIndex) { }

	// RVA: 0x74AE6D8
	private static object CopyMaterialPresetProperties(object source, object destination) { }

	// RVA: 0x74AEC24
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct MaterialReference
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object fontAsset; // 0x0
	public object spriteAsset; // 0x8
	public object material; // 0x10
	public object isDefaultMaterial; // 0x18
	public object isFallbackMaterial; // 0x19
	public object fallbackMaterial; // 0x20
	public object padding; // 0x28
	public object referenceCount; // 0x2C

	// Methods

	// RVA: 0x74AECF0
	public object .ctor(object index, object fontAsset, object spriteAsset, object material, object padding) { }

	// RVA: 0x74AEE40
	public static object AddMaterialReference(object material, object fontAsset, object materialReferences, object materialReferenceIndexLookup) { }

	// RVA: 0x74AF068
	public static object AddMaterialReference(object material, object spriteAsset, object materialReferences, object materialReferenceIndexLookup) { }

}

// Namespace: UnityEngine.TextCore.Text
internal class MaterialReferenceManager
{

	// Fields
	private static object s_Instance; // 0x0
	private object m_FontMaterialReferenceLookup; // 0x8
	private object m_FontAssetReferenceLookup; // 0x10
	private object m_SpriteAssetReferenceLookup; // 0x18
	private object m_ColorGradientReferenceLookup; // 0x20

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: 0x74AF224
	public static object get_instance() { }

	// RVA: 0x74AF408
	public static object AddFontAsset(object fontAsset) { }

	// RVA: 0x74AF498
	private object AddFontAssetInternal(object fontAsset) { }

	// RVA: 0x74AF700
	public static object AddSpriteAsset(object hashCode, object spriteAsset) { }

	// RVA: 0x74AF798
	private object AddSpriteAssetInternal(object hashCode, object spriteAsset) { }

	// RVA: 0x74AF89C
	public static object AddFontMaterial(object hashCode, object material) { }

	// RVA: 0x74AF960
	private object AddFontMaterialInternal(object hashCode, object material) { }

	// RVA: 0x74AF9D4
	public static object AddColorGradientPreset(object hashCode, object spriteAsset) { }

	// RVA: 0x74AFAE0
	private object AddColorGradientPreset_Internal(object hashCode, object spriteAsset) { }

	// RVA: 0x74AFB9C
	public static object TryGetFontAsset(object hashCode, object fontAsset) { }

	// RVA: 0x74AFC70
	private object TryGetFontAssetInternal(object hashCode, object fontAsset) { }

	// RVA: 0x74AFCE8
	public static object TryGetSpriteAsset(object hashCode, object spriteAsset) { }

	// RVA: 0x74AFDBC
	private object TryGetSpriteAssetInternal(object hashCode, object spriteAsset) { }

	// RVA: 0x74AFE34
	public static object TryGetColorGradientPreset(object hashCode, object gradientPreset) { }

	// RVA: 0x74AFF08
	private object TryGetColorGradientPresetInternal(object hashCode, object gradientPreset) { }

	// RVA: 0x74AFF80
	public static object TryGetMaterial(object hashCode, object material) { }

	// RVA: 0x74B0054
	private object TryGetMaterialInternal(object hashCode, object material) { }

	// RVA: 0x74AF2B0
	public object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal enum VertexSortingOrder
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Reverse;
}

// Namespace: UnityEngine.TextCore.Text
internal struct MeshInfo
{

	// Fields
	private static readonly object k_DefaultColor; // 0x0
	private static readonly object k_DefaultNormal; // 0xFFFFFFFFFFFFFFF4
	private static readonly object k_DefaultTangent; // 0x0
	private static readonly object k_DefaultBounds; // 0x10
	public object mesh; // 0xFFFFFFFFFFFFFFF8
	public object vertexCount; // 0x0
	public object vertices; // 0x8
	public object normals; // 0x10
	public object tangents; // 0x18
	public object uvs0; // 0x20
	public object uvs2; // 0x28
	public object colors32; // 0x30
	public object triangles; // 0x38
	public object material; // 0x40

	// Methods

	// RVA: 0x74B0108
	public object .ctor(object size) { }

	// RVA: 0x74B0680
	internal object ResizeMeshInfo(object size) { }

	// RVA: 0x74B0888
	internal object Clear(object uploadChanges) { }

	// RVA: 0x74B08F8
	internal object ClearUnusedVertices() { }

	// RVA: 0x74B0978
	internal object SortGeometry(object order) { }

	// RVA: 0x74B0A40
	internal object SwapVertexData(object src, object dst) { }

	// RVA: 0x74B0F40
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__37_0; // 0x8
	public static object <>9__38_0; // 0x10

	// Methods

	// RVA: 0x74B28E4
	private static object .cctor() { }

	// RVA: 0x74B2944
	public object .ctor() { }

	// RVA: 0x74B294C
	internal object <SortGlyphTable>b__37_0(object item) { }

	// RVA: 0x74B2970
	internal object <SortCharacterTable>b__38_0(object c) { }

}

// Namespace: UnityEngine.TextCore.Text
public class SpriteAsset
{

	// Fields
	internal object m_NameLookup; // 0x30
	internal object m_GlyphIndexLookup; // 0x38
	internal object m_FaceInfo; // 0x40
	internal object m_SpriteAtlasTexture; // 0xA0
	private object m_SpriteCharacterTable; // 0xA8
	internal object m_SpriteCharacterLookup; // 0xB0
	private object m_SpriteGlyphTable; // 0xB8
	internal object m_SpriteGlyphLookup; // 0xC0
	public object fallbackSpriteAssets; // 0xC8
	internal object m_IsSpriteAssetLookupTablesDirty; // 0xD0
	private static object k_searchedSpriteAssets; // 0x0

	// Properties
	public object faceInfo { get; set; }
	public object spriteSheet { get; set; }
	public object spriteCharacterTable { get; set; }
	public object spriteCharacterLookupTable { get; set; }
	public object spriteGlyphTable { get; set; }

	// Methods

	// RVA: 0x74B0FB8
	public object get_faceInfo() { }

	// RVA: 0x74B0FD4
	internal object set_faceInfo(object value) { }

	// RVA: 0x74B0FE0
	public object get_spriteSheet() { }

	// RVA: 0x74B0FE8
	internal object set_spriteSheet(object value) { }

	// RVA: 0x74B0FF0
	public object get_spriteCharacterTable() { }

	// RVA: 0x74B15C0
	internal object set_spriteCharacterTable(object value) { }

	// RVA: 0x74AD7A4
	public object get_spriteCharacterLookupTable() { }

	// RVA: 0x74B15C8
	internal object set_spriteCharacterLookupTable(object value) { }

	// RVA: 0x74B15D0
	public object get_spriteGlyphTable() { }

	// RVA: 0x74B15D8
	internal object set_spriteGlyphTable(object value) { }

	// RVA: 0x74B15E0
	private object Awake() { }

	// RVA: 0x74B1030
	public object UpdateLookupTables() { }

	// RVA: 0x74B15EC
	public object GetSpriteIndexFromHashcode(object hashCode) { }

	// RVA: 0x74B1688
	public object GetSpriteIndexFromUnicode(object unicode) { }

	// RVA: 0x74B174C
	public object GetSpriteIndexFromName(object name) { }

	// RVA: 0x74B1808
	public static object SearchForSpriteByUnicode(object spriteAsset, object unicode, object includeFallbacks, object spriteIndex) { }

	// RVA: 0x74B1A90
	private static object SearchForSpriteByUnicodeInternal(object spriteAssets, object unicode, object includeFallbacks, object spriteIndex) { }

	// RVA: 0x74B1C64
	private static object SearchForSpriteByUnicodeInternal(object spriteAsset, object unicode, object includeFallbacks, object spriteIndex) { }

	// RVA: 0x74B1DAC
	public static object SearchForSpriteByHashCode(object spriteAsset, object hashCode, object includeFallbacks, object spriteIndex, object textSettings) { }

	// RVA: 0x74B2250
	private static object SearchForSpriteByHashCodeInternal(object spriteAssets, object hashCode, object searchFallbacks, object spriteIndex) { }

	// RVA: 0x74B2430
	private static object SearchForSpriteByHashCodeInternal(object spriteAsset, object hashCode, object searchFallbacks, object spriteIndex) { }

	// RVA: 0x74B2558
	public object SortGlyphTable() { }

	// RVA: 0x74B26A4
	internal object SortCharacterTable() { }

	// RVA: 0x74B27F4
	internal object SortGlyphAndCharacterTables() { }

	// RVA: 0x74B2818
	public object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
public class SpriteCharacter
{

	// Fields
	private object m_Name; // 0x28

	// Properties
	public object name { get; }

	// Methods

	// RVA: 0x74B15E4
	public object get_name() { }

	// RVA: 0x74B2990
	public object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
public class SpriteGlyph
{

	// Fields
	public object sprite; // 0x40

	// Methods

	// RVA: 0x74B29BC
	public object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
public abstract class TextAsset
{

	// Fields
	internal object m_Version; // 0x10
	internal object m_InstanceID; // 0x18
	internal object m_HashCode; // 0x1C
	internal object m_Material; // 0x20
	internal object m_MaterialHashCode; // 0x28

	// Properties
	public object version { get; set; }
	public object instanceID { get; }
	public object hashCode { get; set; }
	public object material { get; set; }
	public object materialHashCode { get; set; }

	// Methods

	// RVA: 0x74B29C4
	public object get_version() { }

	// RVA: 0x74B29CC
	internal object set_version(object value) { }

	// RVA: 0x74A65F0
	public object get_instanceID() { }

	// RVA: 0x74AF5EC
	public object get_hashCode() { }

	// RVA: 0x74B29D4
	public object set_hashCode(object value) { }

	// RVA: 0x74B29DC
	public object get_material() { }

	// RVA: 0x74B29E4
	public object set_material(object value) { }

	// RVA: 0x74AF634
	public object get_materialHashCode() { }

	// RVA: 0x74B29EC
	public object set_materialHashCode(object value) { }

	// RVA: 0x74AC810
	protected object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
public enum ColorGradientMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Single;
	public const object HorizontalGradient;
	public const object VerticalGradient;
	public const object FourCornersGradient;
}

// Namespace: UnityEngine.TextCore.Text
public class TextColorGradient
{

	// Fields
	public object colorMode; // 0x10
	public object topLeft; // 0x14
	public object topRight; // 0x24
	public object bottomLeft; // 0x34
	public object bottomRight; // 0x44
	private const object k_DefaultColorMode;
	private static readonly object k_DefaultColor; // 0x0

	// Methods

	// RVA: 0x74B29F4
	public object .ctor() { }

	// RVA: 0x74B2A9C
	public object .ctor(object color) { }

	// RVA: 0x74B2B0C
	public object .ctor(object color0, object color1, object color2, object color3) { }

	// RVA: 0x74B2BB4
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore.Text
public enum TextElementType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Character;
	public const object Sprite;
}

// Namespace: UnityEngine.TextCore.Text
public abstract class TextElement
{

	// Fields
	protected object m_ElementType; // 0x8
	internal object m_Unicode; // 0xC
	internal object m_TextAsset; // 0x10
	internal object m_Glyph; // 0x18
	internal object m_GlyphIndex; // 0x20
	internal object m_Scale; // 0x24

	// Properties
	public object elementType { get; }
	public object unicode { get; set; }
	public object textAsset { get; set; }
	public object glyph { get; set; }
	public object glyphIndex { get; set; }
	public object scale { get; set; }

	// Methods

	// RVA: 0x74B2C04
	public object get_elementType() { }

	// RVA: 0x74A34E0
	public object get_unicode() { }

	// RVA: 0x74A073C
	public object set_unicode(object value) { }

	// RVA: 0x74AD2A0
	public object get_textAsset() { }

	// RVA: 0x74A0744
	public object set_textAsset(object value) { }

	// RVA: 0x74B2C0C
	public object get_glyph() { }

	// RVA: 0x74A074C
	public object set_glyph(object value) { }

	// RVA: 0x74A2444
	public object get_glyphIndex() { }

	// RVA: 0x74A0754
	public object set_glyphIndex(object value) { }

	// RVA: 0x74B2C14
	public object get_scale() { }

	// RVA: 0x74A06C8
	public object set_scale(object value) { }

	// RVA: 0x74A06C0
	protected object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct TextVertex
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object uv; // 0x4
	public object uv2; // 0x14
	public object color; // 0x1C
}

// Namespace: UnityEngine.TextCore.Text
internal struct TextElementInfo
{

	// Fields
	public object character; // 0xFFFFFFFFFFFFFFF8
	public object index; // 0xFFFFFFFFFFFFFFFC
	public object elementType; // 0x0
	public object stringLength; // 0x4
	public object textElement; // 0x8
	public object alternativeGlyph; // 0x10
	public object fontAsset; // 0x18
	public object spriteAsset; // 0x20
	public object spriteIndex; // 0x28
	public object material; // 0x30
	public object materialReferenceIndex; // 0x38
	public object isUsingAlternateTypeface; // 0x3C
	public object pointSize; // 0x40
	public object lineNumber; // 0x44
	public object pageNumber; // 0x48
	public object vertexIndex; // 0x4C
	public object vertexTopLeft; // 0x50
	public object vertexBottomLeft; // 0x78
	public object vertexTopRight; // 0xA0
	public object vertexBottomRight; // 0xC8
	public object topLeft; // 0xF0
	public object bottomLeft; // 0xFC
	public object topRight; // 0x108
	public object bottomRight; // 0x114
	public object origin; // 0x120
	public object ascender; // 0x124
	public object baseLine; // 0x128
	public object descender; // 0x12C
	internal object adjustedAscender; // 0x130
	internal object adjustedDescender; // 0x134
	internal object adjustedHorizontalAdvance; // 0x138
	public object xAdvance; // 0x13C
	public object aspectRatio; // 0x140
	public object scale; // 0x144
	public object color; // 0x148
	public object underlineColor; // 0x14C
	public object underlineVertexIndex; // 0x150
	public object strikethroughColor; // 0x154
	public object strikethroughVertexIndex; // 0x158
	public object highlightColor; // 0x15C
	public object highlightState; // 0x160
	public object style; // 0x174
	public object isVisible; // 0x178

	// Methods

	// RVA: 0x74B2C58
	public override object ToString() { }

}

// Namespace: UnityEngine.TextCore.Text
internal class TextGenerationSettings
{

	// Fields
	public object text; // 0x8
	public object screenRect; // 0x10
	public object margins; // 0x20
	public object scale; // 0x30
	public object fontAsset; // 0x38
	public object material; // 0x40
	public object spriteAsset; // 0x48
	public object styleSheet; // 0x50
	public object fontStyle; // 0x58
	public object textSettings; // 0x60
	public object textAlignment; // 0x68
	public object overflowMode; // 0x6C
	public object wordWrap; // 0x70
	public object wordWrappingRatio; // 0x74
	public object color; // 0x78
	public object fontColorGradient; // 0x88
	public object fontColorGradientPreset; // 0x90
	public object tintSprites; // 0x98
	public object overrideRichTextColors; // 0x99
	public object shouldConvertToLinearSpace; // 0x9A
	public object fontSize; // 0x9C
	public object autoSize; // 0xA0
	public object fontSizeMin; // 0xA4
	public object fontSizeMax; // 0xA8
	public object enableKerning; // 0xAC
	public object richText; // 0xAD
	public object isRightToLeft; // 0xAE
	public object extraPadding; // 0xB0
	public object parseControlCharacters; // 0xB4
	public object isOrthographic; // 0xB5
	public object tagNoParsing; // 0xB6
	public object characterSpacing; // 0xB8
	public object wordSpacing; // 0xBC
	public object lineSpacing; // 0xC0
	public object paragraphSpacing; // 0xC4
	public object lineSpacingMax; // 0xC8
	public object textWrappingMode; // 0xCC
	public object maxVisibleCharacters; // 0xD0
	public object maxVisibleWords; // 0xD4
	public object maxVisibleLines; // 0xD8
	public object firstVisibleCharacter; // 0xDC
	public object useMaxVisibleDescender; // 0xE0
	public object fontWeight; // 0xE4
	public object pageToDisplay; // 0xE8
	public object horizontalMapping; // 0xEC
	public object verticalMapping; // 0xF0
	public object uvLineOffset; // 0xF4
	public object geometrySortingOrder; // 0xF8
	public object inverseYAxis; // 0xFC
	public object charWidthMaxAdj; // 0x100
	internal object inputSource; // 0x104

	// Methods

	// RVA: 0x74B4360
	public object Equals(object other) { }

	// RVA: 0x74B4800
	public override object Equals(object obj) { }

	// RVA: 0x74B492C
	public override object GetHashCode() { }

	// RVA: 0x74B4E08
	public static object op_Equality(object left, object right) { }

	// RVA: 0x74B4E10
	public override object ToString() { }

	// RVA: 0x74B68C8
	public object .ctor() { }

}

// Namespace: 
public sealed class MissingCharacterEventCallback
{

	// Methods

	// RVA: 0x74CDAD8
	public object .ctor(object object, object method) { }

	// RVA: 0x74CDB70
	public virtual object Invoke(object unicode, object stringIndex, object text, object fontAsset) { }

}

// Namespace: 
protected struct SpecialCharacter
{

	// Fields
	public object character; // 0xFFFFFFFFFFFFFFF8
	public object fontAsset; // 0x0
	public object material; // 0x8
	public object materialIndex; // 0x10

	// Methods

	// RVA: 0x74CDBC0
	public object .ctor(object character, object materialIndex) { }

}

// Namespace: UnityEngine.TextCore.Text
internal class TextGenerator
{

	// Fields
	private static object s_TextGenerator; // 0x0
	private object m_TextBackingArray; // 0x8
	internal object m_TextProcessingArray; // 0x18
	internal object m_InternalTextProcessingArraySize; // 0x20
	protected object m_VertexBufferAutoSizeReduction; // 0x24
	private object m_HtmlTag; // 0x28
	internal object m_HighlightState; // 0x30
	protected object m_IsIgnoringAlignment; // 0x44
	protected static object m_IsTextTruncated; // 0x8
	private static object OnMissingCharacter; // 0x10
	private object m_RectTransformCorners; // 0x48
	private object m_MarginWidth; // 0x50
	private object m_MarginHeight; // 0x54
	private object m_PreferredWidth; // 0x58
	private object m_PreferredHeight; // 0x5C
	private object m_CurrentFontAsset; // 0x60
	private object m_CurrentMaterial; // 0x68
	private object m_CurrentMaterialIndex; // 0x70
	private object m_MaterialReferenceStack; // 0x78
	private object m_Padding; // 0xD0
	private object m_CurrentSpriteAsset; // 0xD8
	private object m_TotalCharacterCount; // 0xE0
	private object m_FontSize; // 0xE4
	private object m_FontScaleMultiplier; // 0xE8
	private object m_CurrentFontSize; // 0xEC
	private object m_SizeStack; // 0xF0
	protected object m_TextStyleStacks; // 0x110
	protected object m_TextStyleStackDepth; // 0x118
	private object m_FontStyleInternal; // 0x11C
	private object m_FontStyleStack; // 0x120
	private object m_FontWeightInternal; // 0x12C
	private object m_FontWeightStack; // 0x130
	private object m_LineJustification; // 0x150
	private object m_LineJustificationStack; // 0x158
	private object m_BaselineOffset; // 0x178
	private object m_BaselineOffsetStack; // 0x180
	private object m_FontColor32; // 0x1A0
	private object m_HtmlColor; // 0x1A4
	private object m_UnderlineColor; // 0x1A8
	private object m_StrikethroughColor; // 0x1AC
	private object m_ColorStack; // 0x1B0
	private object m_UnderlineColorStack; // 0x1D0
	private object m_StrikethroughColorStack; // 0x1F0
	private object m_HighlightColorStack; // 0x210
	private object m_HighlightStateStack; // 0x230
	private object m_ItalicAngleStack; // 0x260
	private object m_ColorGradientPreset; // 0x280
	private object m_ColorGradientStack; // 0x288
	private object m_ColorGradientPresetIsTinted; // 0x2B0
	private object m_ActionStack; // 0x2B8
	private object m_LineOffset; // 0x2D8
	private object m_LineHeight; // 0x2DC
	private object m_IsDrivenLineSpacing; // 0x2E0
	private object m_CSpacing; // 0x2E4
	private object m_MonoSpacing; // 0x2E8
	private object m_XAdvance; // 0x2EC
	private object m_TagLineIndent; // 0x2F0
	private object m_TagIndent; // 0x2F4
	private object m_IndentStack; // 0x2F8
	private object m_TagNoParsing; // 0x318
	private object m_CharacterCount; // 0x31C
	private object m_FirstCharacterOfLine; // 0x320
	private object m_LastCharacterOfLine; // 0x324
	private object m_FirstVisibleCharacterOfLine; // 0x328
	private object m_LastVisibleCharacterOfLine; // 0x32C
	private object m_MaxLineAscender; // 0x330
	private object m_MaxLineDescender; // 0x334
	private object m_LineNumber; // 0x338
	private object m_LineVisibleCharacterCount; // 0x33C
	private object m_LineVisibleSpaceCount; // 0x340
	private object m_FirstOverflowCharacterIndex; // 0x344
	private object m_PageNumber; // 0x348
	private object m_MarginLeft; // 0x34C
	private object m_MarginRight; // 0x350
	private object m_Width; // 0x354
	private object m_MeshExtents; // 0x358
	private object m_MaxCapHeight; // 0x368
	private object m_MaxAscender; // 0x36C
	private object m_MaxDescender; // 0x370
	private object m_IsNewPage; // 0x374
	private object m_IsNonBreakingSpace; // 0x375
	private object m_SavedWordWrapState; // 0x378
	private object m_SavedLineState; // 0x710
	private object m_SavedEllipsisState; // 0xAA8
	private object m_SavedLastValidState; // 0xE40
	private object m_SavedSoftLineBreakState; // 0x11D8
	private object m_TextElementType; // 0x1570
	private object m_isTextLayoutPhase; // 0x1571
	private object m_SpriteIndex; // 0x1574
	private object m_SpriteColor; // 0x1578
	private object m_CachedTextElement; // 0x1580
	private object m_HighlightColor; // 0x1588
	private object m_CharWidthAdjDelta; // 0x158C
	private object m_MaxFontSize; // 0x1590
	private object m_MinFontSize; // 0x1594
	private object m_AutoSizeIterationCount; // 0x1598
	private object m_AutoSizeMaxIterationCount; // 0x159C
	private object m_IsAutoSizePointSizeSet; // 0x15A0
	private object m_StartOfLineAscender; // 0x15A4
	private object m_LineSpacingDelta; // 0x15A8
	private object m_MaterialReferences; // 0x15B0
	private object m_SpriteCount; // 0x15B8
	private object m_StyleStack; // 0x15C0
	private object m_EllipsisInsertionCandidateStack; // 0x15E0
	private object m_SpriteAnimationId; // 0x1998
	private object m_ItalicAngle; // 0x199C
	private object m_FXScale; // 0x19A0
	private object m_FXRotation; // 0x19AC
	private object m_LastBaseGlyphIndex; // 0x19BC
	private object m_PageAscender; // 0x19C0
	private object m_XmlAttribute; // 0x19C8
	private object m_AttributeParameterValues; // 0x19D0
	private object m_MaterialReferenceIndexLookup; // 0x19D8
	private object m_IsCalculatingPreferredValues; // 0x19E0
	private object m_DefaultSpriteAsset; // 0x19E8
	private object m_TintSprite; // 0x19F0
	protected object m_Ellipsis; // 0x19F8
	protected object m_Underline; // 0x1A18
	private object m_InternalTextElementInfo; // 0x1A38

	// Properties
	public static object isTextTruncated { get; }

	// Methods

	// RVA: 0x74BE6D0
	private static object GetTextGenerator() { }

	// RVA: 0x74BEDC8
	public static object GenerateText(object settings, object textInfo) { }

	// RVA: 0x74BF254
	public static object GetPreferredValues(object settings, object textInfo) { }

	// RVA: 0x74BF5A0
	public static object get_isTextTruncated() { }

	// RVA: 0x74BF04C
	private object Prepare(object generationSettings, object textInfo) { }

	// RVA: 0x74B6944
	private object GenerateTextMesh(object generationSettings, object textInfo) { }

	// RVA: 0x74C1EC0
	private object SaveWordWrappingState(object state, object index, object count, object textInfo) { }

	// RVA: 0x74C2160
	protected object RestoreWordWrappingState(object state, object textInfo) { }

	// RVA: 0x74C23FC
	protected object ValidateHtmlTag(object chars, object startIndex, object endIndex, object generationSettings, object textInfo) { }

	// RVA: 0x74C6F2C
	private object SaveGlyphVertexInfo(object padding, object stylePadding, object vertexColor, object generationSettings, object textInfo) { }

	// RVA: 0x74C7D8C
	private object SaveSpriteVertexInfo(object vertexColor, object generationSettings, object textInfo) { }

	// RVA: 0x74C87F4
	private object DrawUnderlineMesh(object start, object end, object startScale, object endScale, object maxScale, object sdfScale, object underlineColor, object generationSettings, object textInfo) { }

	// RVA: 0x74C968C
	private object DrawTextHighlight(object start, object end, object highlightColor, object generationSettings, object textInfo) { }

	// RVA: 0x74C9C84
	private static object ClearMesh(object updateMesh, object textInfo) { }

	// RVA: 0x74C0630
	internal object SetArraySizes(object textProcessingArray, object generationSettings, object textInfo) { }

	// RVA: 0x74C9E80
	internal object GetTextElement(object generationSettings, object unicode, object fontAsset, object fontStyle, object fontWeight, object isUsingAlternativeTypeface) { }

	// RVA: 0x74BF694
	private object ComputeMarginSize(object rect, object margins) { }

	// RVA: 0x74BF5EC
	protected object GetSpecialCharacters(object generationSettings) { }

	// RVA: 0x74C9CB0
	protected object GetEllipsisSpecialCharacter(object generationSettings) { }

	// RVA: 0x74C95E8
	protected object GetUnderlineSpecialCharacter(object generationSettings) { }

	// RVA: 0x74BF418
	private object GetPreferredValuesInternal(object generationSettings, object textInfo) { }

	// RVA: 0x74CA290
	protected virtual object CalculatePreferredValues(object fontSize, object marginSize, object isTextAutoSizingEnabled, object textWrapMode, object generationSettings, object textInfo) { }

	// RVA: 0x74BF708
	private object PopulateTextBackingArray(object sourceText) { }

	// RVA: 0x74CD348
	private object PopulateTextBackingArray(object sourceText, object start, object length) { }

	// RVA: 0x74BF724
	private object PopulateTextProcessingArray(object generationSettings) { }

	// RVA: 0x74CD470
	private object InsertNewLine(object i, object baseScale, object currentElementScale, object currentEmScale, object boldSpacingAdjustment, object characterSpacingAdjustment, object width, object lineGap, object isMaxVisibleDescenderSet, object maxVisibleDescender, object generationSettings, object textInfo) { }

	// RVA: 0x74CA1F0
	protected object DoMissingGlyphCallback(object unicode, object stringIndex, object fontAsset, object textInfo) { }

	// RVA: 0x74C6EB0
	private object ClearMarkupTagAttributes() { }

	// RVA: 0x74BE75C
	public object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal enum TextAlignment
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TopLeft;
	public const object TopCenter;
	public const object TopRight;
	public const object TopJustified;
	public const object TopFlush;
	public const object TopGeoAligned;
	public const object MiddleLeft;
	public const object MiddleCenter;
	public const object MiddleRight;
	public const object MiddleJustified;
	public const object MiddleFlush;
	public const object MiddleGeoAligned;
	public const object BottomLeft;
	public const object BottomCenter;
	public const object BottomRight;
	public const object BottomJustified;
	public const object BottomFlush;
	public const object BottomGeoAligned;
	public const object BaselineLeft;
	public const object BaselineCenter;
	public const object BaselineRight;
	public const object BaselineJustified;
	public const object BaselineFlush;
	public const object BaselineGeoAligned;
	public const object MidlineLeft;
	public const object MidlineCenter;
	public const object MidlineRight;
	public const object MidlineJustified;
	public const object MidlineFlush;
	public const object MidlineGeoAligned;
	public const object CaplineLeft;
	public const object CaplineCenter;
	public const object CaplineRight;
	public const object CaplineJustified;
	public const object CaplineFlush;
	public const object CaplineGeoAligned;
}

// Namespace: UnityEngine.TextCore.Text
public enum FontStyles
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Bold;
	public const object Italic;
	public const object Underline;
	public const object LowerCase;
	public const object UpperCase;
	public const object SmallCaps;
	public const object Strikethrough;
	public const object Superscript;
	public const object Subscript;
	public const object Highlight;
}

// Namespace: UnityEngine.TextCore.Text
internal enum TextOverflowMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Overflow;
	public const object Ellipsis;
	public const object Masking;
	public const object Truncate;
	public const object ScrollRect;
	public const object Page;
	public const object Linked;
}

// Namespace: UnityEngine.TextCore.Text
internal enum TextureMapping
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Character;
	public const object Line;
	public const object Paragraph;
	public const object MatchAspect;
}

// Namespace: UnityEngine.TextCore.Text
internal enum TextWrappingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoWrap;
	public const object Normal;
	public const object PreserveWhitespace;
	public const object PreserveWhitespaceNoWrap;
}

// Namespace: UnityEngine.TextCore.Text
internal enum TextInputSource
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TextInputBox;
	public const object SetText;
	public const object SetTextArray;
	public const object TextString;
}

// Namespace: UnityEngine.TextCore.Text
internal struct RichTextTagAttribute
{

	// Fields
	public object nameHashCode; // 0xFFFFFFFFFFFFFFF8
	public object valueHashCode; // 0xFFFFFFFFFFFFFFFC
	public object valueType; // 0x0
	public object valueStartIndex; // 0x4
	public object valueLength; // 0x8
	public object unitType; // 0xC
}

// Namespace: UnityEngine.TextCore.Text
internal struct TextProcessingElement
{

	// Fields
	public object elementType; // 0xFFFFFFFFFFFFFFF8
	public object unicode; // 0xFFFFFFFFFFFFFFFC
	public object stringIndex; // 0x0
	public object length; // 0x4
}

// Namespace: UnityEngine.TextCore.Text
internal struct TextBackingContainer
{

	// Fields
	private object m_Array; // 0xFFFFFFFFFFFFFFF8
	private object m_Count; // 0x0

	// Properties
	public object Capacity { get; }
	public object Count { get; set; }
	public object Item { get; set; }

	// Methods

	// RVA: 0x74CDDEC
	public object get_Capacity() { }

	// RVA: 0x74CDE34
	public object get_Count() { }

	// RVA: 0x74CDE44
	public object set_Count(object value) { }

	// RVA: 0x74CDE54
	public object get_Item(object index) { }

	// RVA: 0x74CDECC
	public object set_Item(object index, object value) { }

	// RVA: 0x74CE000
	public object .ctor(object size) { }

	// RVA: 0x74CDF90
	public object Resize(object size) { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct CharacterSubstitution
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object unicode; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x74CE130
	public object .ctor(object index, object unicode) { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct Offset
{

	// Fields
	private object m_Left; // 0xFFFFFFFFFFFFFFF8
	private object m_Right; // 0xFFFFFFFFFFFFFFFC
	private object m_Top; // 0x0
	private object m_Bottom; // 0x4
	private static readonly object k_ZeroOffset; // 0x0

	// Properties
	public object left { get; }
	public object right { get; }
	public object top { get; }
	public object bottom { get; }
	public static object zero { get; }

	// Methods

	// RVA: 0x74CE140
	public object get_left() { }

	// RVA: 0x74CE150
	public object get_right() { }

	// RVA: 0x74CE160
	public object get_top() { }

	// RVA: 0x74CE170
	public object get_bottom() { }

	// RVA: 0x74CE180
	public static object get_zero() { }

	// RVA: 0x74CE204
	public object .ctor(object left, object right, object top, object bottom) { }

	// RVA: 0x74CE21C
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x74CE244
	public static object op_Multiply(object a, object b) { }

	// RVA: 0x74CE258
	public override object GetHashCode() { }

	// RVA: 0x74CE338
	public override object Equals(object obj) { }

	// RVA: 0x74CE428
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct HighlightState
{

	// Fields
	public object color; // 0xFFFFFFFFFFFFFFF8
	public object padding; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x74CE474
	public object .ctor(object color, object padding) { }

	// RVA: 0x74CE494
	public static object op_Equality(object lhs, object rhs) { }

	// RVA: 0x74CE590
	public static object op_Inequality(object lhs, object rhs) { }

	// RVA: 0x74CE678
	public override object GetHashCode() { }

	// RVA: 0x74CE768
	public override object Equals(object obj) { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct WordWrapState
{

	// Fields
	public object previousWordBreak; // 0xFFFFFFFFFFFFFFF8
	public object totalCharacterCount; // 0xFFFFFFFFFFFFFFFC
	public object visibleCharacterCount; // 0x0
	public object visibleSpaceCount; // 0x4
	public object visibleSpriteCount; // 0x8
	public object visibleLinkCount; // 0xC
	public object firstCharacterIndex; // 0x10
	public object firstVisibleCharacterIndex; // 0x14
	public object lastCharacterIndex; // 0x18
	public object lastVisibleCharIndex; // 0x1C
	public object lineNumber; // 0x20
	public object maxCapHeight; // 0x24
	public object maxAscender; // 0x28
	public object maxDescender; // 0x2C
	public object maxLineAscender; // 0x30
	public object maxLineDescender; // 0x34
	public object startOfLineAscender; // 0x38
	public object xAdvance; // 0x3C
	public object preferredWidth; // 0x40
	public object preferredHeight; // 0x44
	public object previousLineScale; // 0x48
	public object pageAscender; // 0x4C
	public object wordCount; // 0x50
	public object fontStyle; // 0x54
	public object fontScale; // 0x58
	public object fontScaleMultiplier; // 0x5C
	public object italicAngle; // 0x60
	public object currentFontSize; // 0x64
	public object baselineOffset; // 0x68
	public object lineOffset; // 0x6C
	public object textInfo; // 0x70
	public object lineInfo; // 0x78
	public object vertexColor; // 0xD8
	public object underlineColor; // 0xDC
	public object strikethroughColor; // 0xE0
	public object highlightColor; // 0xE4
	public object highlightState; // 0xE8
	public object basicStyleStack; // 0xFC
	public object italicAngleStack; // 0x108
	public object colorStack; // 0x128
	public object underlineColorStack; // 0x148
	public object strikethroughColorStack; // 0x168
	public object highlightColorStack; // 0x188
	public object highlightStateStack; // 0x1A8
	public object colorGradientStack; // 0x1D8
	public object sizeStack; // 0x200
	public object indentStack; // 0x220
	public object fontWeightStack; // 0x240
	public object styleStack; // 0x260
	public object baselineStack; // 0x280
	public object actionStack; // 0x2A0
	public object materialReferenceStack; // 0x2C0
	public object lineJustificationStack; // 0x318
	public object lastBaseGlyphIndex; // 0x338
	public object spriteAnimationId; // 0x33C
	public object currentFontAsset; // 0x340
	public object currentSpriteAsset; // 0x348
	public object currentMaterial; // 0x350
	public object currentMaterialIndex; // 0x358
	public object meshExtents; // 0x35C
	public object tagNoParsing; // 0x36C
	public object isNonBreakingSpace; // 0x36D
	public object isDrivenLineSpacing; // 0x36E
	public object fxScale; // 0x370
	public object fxRotation; // 0x37C
}

// Namespace: UnityEngine.TextCore.Text
internal static class TextGeneratorUtilities
{

	// Fields
	public static readonly object largePositiveVector2; // 0x0
	public static readonly object largeNegativeVector2; // 0x8

	// Methods

	// RVA: 0x74CE8A4
	public static object Approximately(object a, object b) { }

	// RVA: 0x74CE8D4
	public static object HexCharsToColor(object hexChars, object tagCount) { }

	// RVA: 0x74CEF70
	public static object HexCharsToColor(object hexChars, object startIndex, object length) { }

	// RVA: 0x74CEF48
	public static object HexToInt(object hex) { }

	// RVA: 0x74CF1F4
	public static object ConvertToFloat(object chars, object startIndex, object length) { }

	// RVA: 0x74CF27C
	public static object ConvertToFloat(object chars, object startIndex, object length, object lastIndex) { }

	// RVA: 0x74CF3FC
	public static object PackUV(object x, object y, object scale) { }

	// RVA: -1
	public static object ResizeInternalArray(object array) { }

	// RVA: -1
	public static object ResizeInternalArray(object array, object size) { }

	// RVA: 0x74CF458
	internal static object InsertOpeningTextStyle(object style, object charBuffer, object writeIndex, object textStyleStackDepth, object textStyleStacks, object generationSettings) { }

	// RVA: 0x74CFAFC
	internal static object InsertClosingTextStyle(object style, object charBuffer, object writeIndex, object textStyleStackDepth, object textStyleStacks, object generationSettings) { }

	// RVA: 0x74CFC10
	public static object ReplaceOpeningStyleTag(object sourceText, object srcIndex, object srcOffset, object charBuffer, object writeIndex, object textStyleStackDepth, object textStyleStacks, object generationSettings) { }

	// RVA: 0x74D00AC
	private static object ReplaceOpeningStyleTag(object sourceText, object srcIndex, object srcOffset, object charBuffer, object writeIndex, object textStyleStackDepth, object textStyleStacks, object generationSettings) { }

	// RVA: 0x74D0360
	public static object ReplaceClosingStyleTag(object charBuffer, object writeIndex, object textStyleStackDepth, object textStyleStacks, object generationSettings) { }

	// RVA: 0x74D0490
	internal static object InsertOpeningStyleTag(object style, object charBuffer, object writeIndex, object textStyleStackDepth, object textStyleStacks, object generationSettings) { }

	// RVA: 0x74D057C
	internal static object InsertClosingStyleTag(object charBuffer, object writeIndex, object textStyleStackDepth, object textStyleStacks, object generationSettings) { }

	// RVA: 0x74CF574
	private static object InsertTextStyleInTextProcessingArray(object charBuffer, object writeIndex, object styleDefinition, object textStyleStackDepth, object textStyleStacks, object generationSettings) { }

	// RVA: 0x74CFEC4
	public static object GetStyle(object generationSetting, object hashCode) { }

	// RVA: 0x74D020C
	public static object GetStyleHashCode(object text, object index, object closeIndex) { }

	// RVA: 0x74CFD70
	public static object GetStyleHashCode(object text, object index, object closeIndex) { }

	// RVA: 0x74D067C
	public static object GetUTF16(object text, object i) { }

	// RVA: 0x74D0BA4
	public static object GetUTF16(object text, object i) { }

	// RVA: 0x74D0778
	public static object GetUTF32(object text, object i) { }

	// RVA: 0x74D0CA0
	public static object GetUTF32(object text, object i) { }

	// RVA: 0x74D0E2C
	public static object FillCharacterVertexBuffers(object i, object convertToLinearSpace, object generationSettings, object textInfo) { }

	// RVA: 0x74D17AC
	public static object FillSpriteVertexBuffers(object i, object convertToLinearSpace, object generationSettings, object textInfo) { }

	// RVA: 0x74D1D6C
	public static object AdjustLineOffset(object startIndex, object endIndex, object offset, object textInfo) { }

	// RVA: 0x74D1E6C
	public static object ResizeLineExtents(object size, object textInfo) { }

	// RVA: 0x74D2070
	public static object LegacyStyleToNewStyle(object fontStyle) { }

	// RVA: 0x74D2080
	public static object LegacyAlignmentToNewAlignment(object anchor) { }

	// RVA: 0x74D20A4
	public static object ConvertToUTF32(object highSurrogate, object lowSurrogate) { }

	// RVA: 0x74D20B8
	public static object GetMarkupTagHashCode(object styleDefinition, object readIndex) { }

	// RVA: 0x74D0904
	public static object GetMarkupTagHashCode(object styleDefinition, object readIndex) { }

	// RVA: 0x74D0B18
	public static object ToUpperASCIIFast(object c) { }

	// RVA: 0x74D2230
	public static object ToUpperASCIIFast(object c) { }

	// RVA: 0x74D22B8
	public static object ToUpperFast(object c) { }

	// RVA: 0x74D2344
	public static object GetAttributeParameters(object chars, object startIndex, object length, object parameters) { }

	// RVA: 0x74D2444
	public static object IsBaseGlyph(object c) { }

	// RVA: 0x74D25C4
	public static object MinAlpha(object c1, object c2) { }

	// RVA: 0x74D1510
	internal static object GammaToLinear(object c) { }

	// RVA: 0x74D25D0
	private static object GammaToLinear(object value) { }

	// RVA: 0x74D26A8
	public static object IsValidUTF16(object text, object index) { }

	// RVA: 0x74D2784
	public static object IsValidUTF32(object text, object index) { }

	// RVA: 0x74D2910
	internal static object IsHangul(object c) { }

	// RVA: 0x74D29A4
	internal static object IsCJK(object c) { }

	// RVA: 0x74D2B0C
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal class TextHandle
{

	// Fields
	private object m_PreferredSize; // 0x8
	private object m_TextInfo; // 0x10
	private static object m_LayoutTextInfo; // 0x0
	private object m_PreviousGenerationSettingsHash; // 0x18
	protected object textGenerationSettings; // 0x20
	protected static object s_LayoutSettings; // 0x8
	private object isDirty; // 0x28

	// Properties
	internal object textInfo { get; }
	internal static object layoutTextInfo { get; }

	// Methods

	// RVA: 0x74D2B74
	public object .ctor() { }

	// RVA: 0x74D2BE4
	internal object get_textInfo() { }

	// RVA: 0x74D2D98
	internal static object get_layoutTextInfo() { }

	// RVA: 0x74D2E98
	public object IsDirty() { }

	// RVA: 0x74D2F1C
	public object GetCursorPositionFromStringIndexUsingCharacterHeight(object index, object inverseYAxis) { }

	// RVA: 0x74D31F8
	public object GetCursorPositionFromStringIndexUsingLineHeight(object index, object useXAdvance, object inverseYAxis) { }

	// RVA: 0x74D355C
	public object GetCursorIndexFromPosition(object position, object inverseYAxis) { }

	// RVA: 0x74D3ED8
	public object LineDownCharacterPosition(object originalPos) { }

	// RVA: 0x74D4318
	public object LineUpCharacterPosition(object originalPos) { }

	// RVA: 0x74D3730
	public object FindNearestLine(object position) { }

	// RVA: 0x74D38A0
	public object FindNearestCharacterOnLine(object position, object line, object visibleOnly) { }

	// RVA: 0x74D4810
	public object FindIntersectingLink(object position, object inverseYAxis) { }

	// RVA: 0x74D467C
	private static object PointIntersectRectangle(object m, object a, object b, object c, object d) { }

	// RVA: 0x74D4734
	private static object DistanceToLine(object a, object b, object point) { }

	// RVA: 0x74D4D20
	public object GetLineNumber(object index) { }

	// RVA: 0x74D4EBC
	public object GetLineHeight(object lineNumber) { }

	// RVA: 0x74D5058
	public object GetLineHeightFromCharacterIndex(object index) { }

	// RVA: 0x74D51F8
	public object GetCharacterHeightFromIndex(object index) { }

	// RVA: 0x74D539C
	public object IsElided() { }

	// RVA: 0x74D5488
	public object Substring(object startIndex, object length) { }

	// RVA: 0x74D56E8
	public object IndexOf(object value, object startIndex) { }

	// RVA: 0x74D58A8
	public object LastIndexOf(object value, object startIndex) { }

	// RVA: 0x74D5A24
	protected object ComputeTextWidth(object tgs) { }

	// RVA: 0x74D5B14
	protected object ComputeTextHeight(object tgs) { }

	// RVA: 0x74D5A9C
	protected object UpdatePreferredValues(object tgs) { }

	// RVA: 0x74D5B90
	protected object Update(object tgs) { }

	// RVA: 0x74D5D54
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct PageInfo
{

	// Fields
	public object firstCharacterIndex; // 0xFFFFFFFFFFFFFFF8
	public object lastCharacterIndex; // 0xFFFFFFFFFFFFFFFC
	public object ascender; // 0x0
	public object baseLine; // 0x4
	public object descender; // 0x8
}

// Namespace: UnityEngine.TextCore.Text
internal struct WordInfo
{

	// Fields
	public object firstCharacterIndex; // 0xFFFFFFFFFFFFFFF8
	public object lastCharacterIndex; // 0xFFFFFFFFFFFFFFFC
	public object characterCount; // 0x0
}

// Namespace: UnityEngine.TextCore.Text
internal class TextInfo
{

	// Fields
	private static object s_InfinityVectorPositive; // 0x0
	private static object s_InfinityVectorNegative; // 0x8
	public object characterCount; // 0x8
	public object spriteCount; // 0xC
	public object spaceCount; // 0x10
	public object wordCount; // 0x14
	public object linkCount; // 0x18
	public object lineCount; // 0x1C
	public object pageCount; // 0x20
	public object materialCount; // 0x24
	public object textElementInfo; // 0x28
	public object wordInfo; // 0x30
	public object linkInfo; // 0x38
	public object lineInfo; // 0x40
	public object pageInfo; // 0x48
	public object meshInfo; // 0x50
	public object isDirty; // 0x58
	public object hasMultipleColors; // 0x59

	// Methods

	// RVA: 0x74D2C5C
	public object .ctor() { }

	// RVA: 0x74D5DD0
	internal object Clear() { }

	// RVA: 0x74D5E64
	internal object ClearMeshInfo(object updateMesh) { }

	// RVA: 0x74D5F30
	internal object ClearLineInfo() { }

	// RVA: 0x74D60C8
	internal object ClearPageInfo() { }

	// RVA: -1
	internal static object Resize(object array, object size) { }

	// RVA: -1
	internal static object Resize(object array, object size, object isBlockAllocated) { }

	// RVA: 0x74D61CC
	private static object .cctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal enum MarkupTag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BOLD;
	public const object SLASH_BOLD;
	public const object ITALIC;
	public const object SLASH_ITALIC;
	public const object UNDERLINE;
	public const object SLASH_UNDERLINE;
	public const object STRIKETHROUGH;
	public const object SLASH_STRIKETHROUGH;
	public const object MARK;
	public const object SLASH_MARK;
	public const object SUBSCRIPT;
	public const object SLASH_SUBSCRIPT;
	public const object SUPERSCRIPT;
	public const object SLASH_SUPERSCRIPT;
	public const object COLOR;
	public const object SLASH_COLOR;
	public const object ALPHA;
	public const object A;
	public const object SLASH_A;
	public const object SIZE;
	public const object SLASH_SIZE;
	public const object SPRITE;
	public const object NO_BREAK;
	public const object SLASH_NO_BREAK;
	public const object STYLE;
	public const object SLASH_STYLE;
	public const object FONT;
	public const object SLASH_FONT;
	public const object SLASH_MATERIAL;
	public const object LINK;
	public const object SLASH_LINK;
	public const object FONT_WEIGHT;
	public const object SLASH_FONT_WEIGHT;
	public const object NO_PARSE;
	public const object SLASH_NO_PARSE;
	public const object POSITION;
	public const object SLASH_POSITION;
	public const object VERTICAL_OFFSET;
	public const object SLASH_VERTICAL_OFFSET;
	public const object SPACE;
	public const object SLASH_SPACE;
	public const object PAGE;
	public const object SLASH_PAGE;
	public const object ALIGN;
	public const object SLASH_ALIGN;
	public const object WIDTH;
	public const object SLASH_WIDTH;
	public const object GRADIENT;
	public const object SLASH_GRADIENT;
	public const object CHARACTER_SPACE;
	public const object SLASH_CHARACTER_SPACE;
	public const object MONOSPACE;
	public const object SLASH_MONOSPACE;
	public const object CLASS;
	public const object INDENT;
	public const object SLASH_INDENT;
	public const object LINE_INDENT;
	public const object SLASH_LINE_INDENT;
	public const object MARGIN;
	public const object SLASH_MARGIN;
	public const object MARGIN_LEFT;
	public const object MARGIN_RIGHT;
	public const object LINE_HEIGHT;
	public const object SLASH_LINE_HEIGHT;
	public const object ACTION;
	public const object SLASH_ACTION;
	public const object SCALE;
	public const object SLASH_SCALE;
	public const object ROTATE;
	public const object SLASH_ROTATE;
	public const object TABLE;
	public const object SLASH_TABLE;
	public const object TH;
	public const object SLASH_TH;
	public const object TR;
	public const object SLASH_TR;
	public const object TD;
	public const object SLASH_TD;
	public const object LOWERCASE;
	public const object SLASH_LOWERCASE;
	public const object ALLCAPS;
	public const object SLASH_ALLCAPS;
	public const object UPPERCASE;
	public const object SLASH_UPPERCASE;
	public const object SMALLCAPS;
	public const object SLASH_SMALLCAPS;
	public const object LIGA;
	public const object SLASH_LIGA;
	public const object FRAC;
	public const object SLASH_FRAC;
	public const object NAME;
	public const object INDEX;
	public const object TINT;
	public const object ANIM;
	public const object MATERIAL;
	public const object HREF;
	public const object ANGLE;
	public const object PADDING;
	public const object FAMILYNAME;
	public const object STYLENAME;
	public const object RED;
	public const object GREEN;
	public const object BLUE;
	public const object YELLOW;
	public const object ORANGE;
	public const object BLACK;
	public const object WHITE;
	public const object PURPLE;
	public const object BR;
	public const object CR;
	public const object ZWSP;
	public const object ZWJ;
	public const object NBSP;
	public const object SHY;
	public const object LEFT;
	public const object RIGHT;
	public const object CENTER;
	public const object JUSTIFIED;
	public const object FLUSH;
	public const object NONE;
	public const object PLUS;
	public const object MINUS;
	public const object PX;
	public const object PLUS_PX;
	public const object MINUS_PX;
	public const object EM;
	public const object PLUS_EM;
	public const object MINUS_EM;
	public const object PCT;
	public const object PLUS_PCT;
	public const object MINUS_PCT;
	public const object PERCENTAGE;
	public const object PLUS_PERCENTAGE;
	public const object MINUS_PERCENTAGE;
	public const object TRUE;
	public const object FALSE;
	public const object INVALID;
	public const object NOTDEF;
	public const object NORMAL;
	public const object DEFAULT;
	public const object REGULAR;
}

// Namespace: UnityEngine.TextCore.Text
internal enum TagValueType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object NumericalValue;
	public const object StringValue;
	public const object ColorValue;
}

// Namespace: UnityEngine.TextCore.Text
internal enum TagUnitType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Pixels;
	public const object FontUnits;
	public const object Percentage;
}

// Namespace: UnityEngine.TextCore.Text
internal enum TextProcessingElementType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Undefined;
	public const object TextCharacterElement;
	public const object TextMarkupElement;
}

// Namespace: UnityEngine.TextCore.Text
internal struct FontStyleStack
{

	// Fields
	public object bold; // 0xFFFFFFFFFFFFFFF8
	public object italic; // 0xFFFFFFFFFFFFFFF9
	public object underline; // 0xFFFFFFFFFFFFFFFA
	public object strikethrough; // 0xFFFFFFFFFFFFFFFB
	public object highlight; // 0xFFFFFFFFFFFFFFFC
	public object superscript; // 0xFFFFFFFFFFFFFFFD
	public object subscript; // 0xFFFFFFFFFFFFFFFE
	public object uppercase; // 0xFFFFFFFFFFFFFFFF
	public object lowercase; // 0x0
	public object smallcaps; // 0x1

	// Methods

	// RVA: 0x74D623C
	public object Clear() { }

	// RVA: 0x74D6254
	public object Add(object style) { }

	// RVA: 0x74D64BC
	public object Remove(object style) { }

}

// Namespace: UnityEngine.TextCore.Text
internal struct TextProcessingStack<T0>
{

	// Fields
	public object itemStack; // 0x0
	public object index; // 0x0
	private object m_DefaultItem; // 0x0
	private object m_Capacity; // 0x0
	private object m_RolloverSize; // 0x0
	private object m_Count; // 0x0

	// Properties
	public object Count { get; }
	public object current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object stack) { }

	// RVA: -1
	public object .ctor(object capacity) { }

	// RVA: -1
	public object .ctor(object capacity, object rolloverSize) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_current() { }

	// RVA: -1
	internal static object SetDefault(object stack, object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object SetDefault(object item) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Remove() { }

	// RVA: -1
	public object Push(object item) { }

	// RVA: -1
	public object Pop() { }

	// RVA: -1
	public object Peek() { }

	// RVA: -1
	public object CurrentItem() { }

}

// Namespace: 
private struct FontAssetRef
{

	// Fields
	public object nameHashCode; // 0xFFFFFFFFFFFFFFF8
	public object familyNameHashCode; // 0xFFFFFFFFFFFFFFFC
	public object styleNameHashCode; // 0x0
	public object familyNameAndStyleHashCode; // 0x8
	public readonly object fontAsset; // 0x10

	// Methods

	// RVA: 0x74D6D24
	public object .ctor(object nameHashCode, object familyNameHashCode, object styleNameHashCode, object fontAsset) { }

}

// Namespace: UnityEngine.TextCore.Text
internal class TextResourceManager
{

	// Fields
	private static readonly object s_FontAssetReferences; // 0x0
	private static readonly object s_FontAssetNameReferenceLookup; // 0x8
	private static readonly object s_FontAssetFamilyNameAndStyleReferenceLookup; // 0x10
	private static readonly object s_FontAssetRemovalList; // 0x18
	private static readonly object k_RegularStyleHashCode; // 0x20

	// Methods

	// RVA: 0x74D6768
	internal static object AddFontAsset(object fontAsset) { }

	// RVA: 0x74D6D44
	private static object .cctor() { }

}

// Namespace: 
private struct FontReferenceMap
{

	// Fields
	public object font; // 0xFFFFFFFFFFFFFFF8
	public object fontAsset; // 0x0

	// Methods

	// RVA: 0x74D7D24
	public object .ctor(object font, object fontAsset) { }

}

// Namespace: UnityEngine.TextCore.Text
public class TextSettings
{

	// Fields
	protected object m_Version; // 0x10
	protected object m_DefaultFontAsset; // 0x18
	protected object m_DefaultFontAssetPath; // 0x20
	protected object m_FallbackFontAssets; // 0x28
	protected object m_MatchMaterialPreset; // 0x30
	protected object m_MissingCharacterUnicode; // 0x34
	protected object m_ClearDynamicDataOnBuild; // 0x38
	protected object m_DefaultSpriteAsset; // 0x40
	protected object m_DefaultSpriteAssetPath; // 0x48
	protected object m_FallbackSpriteAssets; // 0x50
	protected object m_MissingSpriteCharacterUnicode; // 0x58
	protected object m_DefaultStyleSheet; // 0x60
	protected object m_StyleSheetsResourcePath; // 0x68
	protected object m_DefaultColorGradientPresetsPath; // 0x70
	protected object m_UnicodeLineBreakingRules; // 0x78
	private object m_UseModernHangulLineBreakingRules; // 0x80
	protected object m_DisplayWarnings; // 0x81
	internal object m_FontLookup; // 0x88
	private object m_FontReferences; // 0x90

	// Properties
	public object version { get; set; }
	public object defaultFontAsset { get; set; }
	public object defaultFontAssetPath { get; set; }
	public object fallbackFontAssets { get; set; }
	public object matchMaterialPreset { get; set; }
	public object missingCharacterUnicode { get; set; }
	public object clearDynamicDataOnBuild { get; set; }
	public object defaultSpriteAsset { get; set; }
	public object defaultSpriteAssetPath { get; set; }
	public object fallbackSpriteAssets { get; set; }
	public object missingSpriteCharacterUnicode { get; set; }
	public object defaultStyleSheet { get; set; }
	public object styleSheetsResourcePath { get; set; }
	public object defaultColorGradientPresetsPath { get; set; }
	public object lineBreakingRules { get; set; }
	public object useModernHangulLineBreakingRules { get; set; }
	public object displayWarnings { get; set; }

	// Methods

	// RVA: 0x74D7038
	public object get_version() { }

	// RVA: 0x74D7040
	internal object set_version(object value) { }

	// RVA: 0x74D7048
	public object get_defaultFontAsset() { }

	// RVA: 0x74D7050
	public object set_defaultFontAsset(object value) { }

	// RVA: 0x74D7058
	public object get_defaultFontAssetPath() { }

	// RVA: 0x74D7060
	public object set_defaultFontAssetPath(object value) { }

	// RVA: 0x74D7068
	public object get_fallbackFontAssets() { }

	// RVA: 0x74D7070
	public object set_fallbackFontAssets(object value) { }

	// RVA: 0x74D7078
	public object get_matchMaterialPreset() { }

	// RVA: 0x74D7080
	public object set_matchMaterialPreset(object value) { }

	// RVA: 0x74D7088
	public object get_missingCharacterUnicode() { }

	// RVA: 0x74D7090
	public object set_missingCharacterUnicode(object value) { }

	// RVA: 0x74D7098
	public object get_clearDynamicDataOnBuild() { }

	// RVA: 0x74D70A0
	public object set_clearDynamicDataOnBuild(object value) { }

	// RVA: 0x74D70A8
	public object get_defaultSpriteAsset() { }

	// RVA: 0x74D70B0
	public object set_defaultSpriteAsset(object value) { }

	// RVA: 0x74D70B8
	public object get_defaultSpriteAssetPath() { }

	// RVA: 0x74D70C0
	public object set_defaultSpriteAssetPath(object value) { }

	// RVA: 0x74D70C8
	public object get_fallbackSpriteAssets() { }

	// RVA: 0x74D70D0
	public object set_fallbackSpriteAssets(object value) { }

	// RVA: 0x74D70D8
	public object get_missingSpriteCharacterUnicode() { }

	// RVA: 0x74D70E0
	public object set_missingSpriteCharacterUnicode(object value) { }

	// RVA: 0x74D70E8
	public object get_defaultStyleSheet() { }

	// RVA: 0x74D70F0
	public object set_defaultStyleSheet(object value) { }

	// RVA: 0x74D70F8
	public object get_styleSheetsResourcePath() { }

	// RVA: 0x74D7100
	public object set_styleSheetsResourcePath(object value) { }

	// RVA: 0x74D7108
	public object get_defaultColorGradientPresetsPath() { }

	// RVA: 0x74D7110
	public object set_defaultColorGradientPresetsPath(object value) { }

	// RVA: 0x74D7118
	public object get_lineBreakingRules() { }

	// RVA: 0x74D7634
	public object set_lineBreakingRules(object value) { }

	// RVA: 0x74D763C
	public object get_useModernHangulLineBreakingRules() { }

	// RVA: 0x74D7644
	public object set_useModernHangulLineBreakingRules(object value) { }

	// RVA: 0x74D764C
	public object get_displayWarnings() { }

	// RVA: 0x74D7654
	public object set_displayWarnings(object value) { }

	// RVA: 0x74D765C
	protected object InitializeFontReferenceLookup() { }

	// RVA: 0x74D78F8
	protected object GetCachedFontAssetInternal(object font) { }

	// RVA: 0x74D7D2C
	public object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
public static class TextShaderUtilities
{

	// Fields
	public static object ID_MainTex; // 0x0
	public static object ID_FaceTex; // 0x4
	public static object ID_FaceColor; // 0x8
	public static object ID_FaceDilate; // 0xC
	public static object ID_Shininess; // 0x10
	public static object ID_OutlineOffset1; // 0x14
	public static object ID_OutlineOffset2; // 0x18
	public static object ID_OutlineOffset3; // 0x1C
	public static object ID_OutlineMode; // 0x20
	public static object ID_IsoPerimeter; // 0x24
	public static object ID_Softness; // 0x28
	public static object ID_UnderlayColor; // 0x2C
	public static object ID_UnderlayOffsetX; // 0x30
	public static object ID_UnderlayOffsetY; // 0x34
	public static object ID_UnderlayDilate; // 0x38
	public static object ID_UnderlaySoftness; // 0x3C
	public static object ID_UnderlayOffset; // 0x40
	public static object ID_UnderlayIsoPerimeter; // 0x44
	public static object ID_WeightNormal; // 0x48
	public static object ID_WeightBold; // 0x4C
	public static object ID_OutlineTex; // 0x50
	public static object ID_OutlineWidth; // 0x54
	public static object ID_OutlineSoftness; // 0x58
	public static object ID_OutlineColor; // 0x5C
	public static object ID_Outline2Color; // 0x60
	public static object ID_Outline2Width; // 0x64
	public static object ID_Padding; // 0x68
	public static object ID_GradientScale; // 0x6C
	public static object ID_ScaleX; // 0x70
	public static object ID_ScaleY; // 0x74
	public static object ID_PerspectiveFilter; // 0x78
	public static object ID_Sharpness; // 0x7C
	public static object ID_TextureWidth; // 0x80
	public static object ID_TextureHeight; // 0x84
	public static object ID_BevelAmount; // 0x88
	public static object ID_GlowColor; // 0x8C
	public static object ID_GlowOffset; // 0x90
	public static object ID_GlowPower; // 0x94
	public static object ID_GlowOuter; // 0x98
	public static object ID_GlowInner; // 0x9C
	public static object ID_LightAngle; // 0xA0
	public static object ID_EnvMap; // 0xA4
	public static object ID_EnvMatrix; // 0xA8
	public static object ID_EnvMatrixRotation; // 0xAC
	public static object ID_MaskCoord; // 0xB0
	public static object ID_ClipRect; // 0xB4
	public static object ID_MaskSoftnessX; // 0xB8
	public static object ID_MaskSoftnessY; // 0xBC
	public static object ID_VertexOffsetX; // 0xC0
	public static object ID_VertexOffsetY; // 0xC4
	public static object ID_UseClipRect; // 0xC8
	public static object ID_StencilID; // 0xCC
	public static object ID_StencilOp; // 0xD0
	public static object ID_StencilComp; // 0xD4
	public static object ID_StencilReadMask; // 0xD8
	public static object ID_StencilWriteMask; // 0xDC
	public static object ID_ShaderFlags; // 0xE0
	public static object ID_ScaleRatio_A; // 0xE4
	public static object ID_ScaleRatio_B; // 0xE8
	public static object ID_ScaleRatio_C; // 0xEC
	public static object Keyword_Bevel; // 0xF0
	public static object Keyword_Glow; // 0xF8
	public static object Keyword_Underlay; // 0x100
	public static object Keyword_Ratios; // 0x108
	public static object Keyword_MASK_SOFT; // 0x110
	public static object Keyword_MASK_HARD; // 0x118
	public static object Keyword_MASK_TEX; // 0x120
	public static object Keyword_Outline; // 0x128
	public static object ShaderTag_ZTestMode; // 0x130
	public static object ShaderTag_CullMode; // 0x138
	private static object m_clamp; // 0x140
	public static object isInitialized; // 0x144
	private static object k_ShaderRef_MobileSDF; // 0x148
	private static object k_ShaderRef_MobileBitmap; // 0x150

	// Properties
	internal static object ShaderRef_MobileSDF { get; }
	internal static object ShaderRef_MobileBitmap { get; }

	// Methods

	// RVA: 0x74D7E78
	internal static object get_ShaderRef_MobileSDF() { }

	// RVA: 0x74D8118
	internal static object get_ShaderRef_MobileBitmap() { }

	// RVA: 0x74D83B8
	private static object .cctor() { }

	// RVA: 0x74D8540
	internal static object GetShaderPropertyIDs() { }

}

// Namespace: UnityEngine.TextCore.Text
public class TextStyle
{

	// Fields
	internal static object k_NormalStyle; // 0x0
	private object m_Name; // 0x8
	private object m_HashCode; // 0x10
	private object m_OpeningDefinition; // 0x18
	private object m_ClosingDefinition; // 0x20
	private object m_OpeningTagArray; // 0x28
	private object m_ClosingTagArray; // 0x30
	internal object m_OpeningTagUnicodeArray; // 0x38
	internal object m_ClosingTagUnicodeArray; // 0x40

	// Properties
	public object hashCode { get; }
	public object styleOpeningTagArray { get; }
	public object styleClosingTagArray { get; }

	// Methods

	// RVA: 0x74CF564
	public object get_hashCode() { }

	// RVA: 0x74CF56C
	public object get_styleOpeningTagArray() { }

	// RVA: 0x74CFC08
	public object get_styleClosingTagArray() { }

	// RVA: 0x74D9030
	internal object .ctor(object styleName, object styleOpeningDefinition, object styleClosingDefinition) { }

	// RVA: 0x74D9080
	public object RefreshStyle() { }

}

// Namespace: UnityEngine.TextCore.Text
public class TextStyleSheet
{

	// Fields
	private object m_StyleList; // 0x10
	private object m_StyleLookupDictionary; // 0x18

	// Properties
	internal object styles { get; }

	// Methods

	// RVA: 0x74D92A4
	internal object get_styles() { }

	// RVA: 0x74D92AC
	private object Reset() { }

	// RVA: 0x74D0A7C
	public object GetStyle(object hashCode) { }

	// RVA: 0x74D968C
	public object GetStyle(object name) { }

	// RVA: 0x74D9750
	public object RefreshStyles() { }

	// RVA: 0x74D92B0
	private object LoadStyleDictionaryInternal() { }

	// RVA: 0x74D9754
	public object .ctor() { }

}

// Namespace: UnityEngine.TextCore.Text
internal static class TextUtilities
{

	// Methods

	// RVA: 0x74D97D8
	internal static object ToUpperFast(object c) { }

	// RVA: 0x74D6EF0
	public static object GetHashCodeCaseInSensitive(object s) { }

	// RVA: 0x74D9864
	internal static object UintToString(object unicodes) { }

}

// Namespace: UnityEngine.TextCore.Text
public class UnicodeLineBreakingRules
{

	// Fields
	private static object s_Instance; // 0x0
	private object m_UnicodeLineBreakingRules; // 0x8
	private object m_LeadingCharacters; // 0x10
	private object m_FollowingCharacters; // 0x18
	private object m_UseModernHangulLineBreakingRules; // 0x20
	private static object s_LeadingCharactersLookup; // 0x8
	private static object s_FollowingCharactersLookup; // 0x10

	// Properties
	public object leadingCharacters { get; }
	public object followingCharacters { get; }
	internal object leadingCharactersLookup { get; }
	internal object followingCharactersLookup { get; }
	public object useModernHangulLineBreakingRules { get; }

	// Methods

	// RVA: 0x74D996C
	public object get_leadingCharacters() { }

	// RVA: 0x74D9974
	public object get_followingCharacters() { }

	// RVA: 0x74D997C
	internal object get_leadingCharactersLookup() { }

	// RVA: 0x74D9D68
	internal object get_followingCharactersLookup() { }

	// RVA: 0x74D9E44
	public object get_useModernHangulLineBreakingRules() { }

	// RVA: 0x74D71D4
	internal static object LoadLineBreakingRules() { }

	// RVA: 0x74D9A58
	internal static object LoadLineBreakingRules(object leadingRules, object followingRules) { }

	// RVA: 0x74D9E4C
	private static object GetCharacters(object file) { }

	// RVA: 0x74D71CC
	public object .ctor() { }

	// RVA: 0x74D9F70
	private static object .cctor() { }

}

