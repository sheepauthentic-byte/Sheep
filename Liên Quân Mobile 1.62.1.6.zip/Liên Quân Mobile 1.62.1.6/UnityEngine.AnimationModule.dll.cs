// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public sealed class SharedBetweenAnimatorsAttribute
{
}

// Namespace: UnityEngine
public abstract class StateMachineBehaviour
{

	// Methods

	// RVA: 0x73336AC
	public virtual object OnStateEnter(object animator, object stateInfo, object layerIndex) { }

	// RVA: 0x73336B0
	public virtual object OnStateUpdate(object animator, object stateInfo, object layerIndex) { }

	// RVA: 0x73336B4
	public virtual object OnStateExit(object animator, object stateInfo, object layerIndex) { }

	// RVA: 0x73336B8
	public virtual object OnStateMove(object animator, object stateInfo, object layerIndex) { }

	// RVA: 0x73336BC
	public virtual object OnStateIK(object animator, object stateInfo, object layerIndex) { }

	// RVA: 0x73336C0
	public virtual object OnStateMachineEnter(object animator, object stateMachinePathHash) { }

	// RVA: 0x73336C4
	public virtual object OnStateMachineExit(object animator, object stateMachinePathHash) { }

	// RVA: 0x73336C8
	public virtual object OnStateEnter(object animator, object stateInfo, object layerIndex, object controller) { }

	// RVA: 0x73336CC
	public virtual object OnStateUpdate(object animator, object stateInfo, object layerIndex, object controller) { }

	// RVA: 0x73336D0
	public virtual object OnStateExit(object animator, object stateInfo, object layerIndex, object controller) { }

	// RVA: 0x73336D4
	public virtual object OnStateMove(object animator, object stateInfo, object layerIndex, object controller) { }

	// RVA: 0x73336D8
	public virtual object OnStateIK(object animator, object stateInfo, object layerIndex, object controller) { }

	// RVA: 0x73336DC
	public virtual object OnStateMachineEnter(object animator, object stateMachinePathHash, object controller) { }

	// RVA: 0x73336E0
	public virtual object OnStateMachineExit(object animator, object stateMachinePathHash, object controller) { }

	// RVA: 0x73336E4
	protected object .ctor() { }

}

// Namespace: UnityEngine
public enum PlayMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object StopSameLayer;
	public const object StopAll;
}

// Namespace: UnityEngine
public enum QueueMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CompleteOthers;
	public const object PlayNow;
}

// Namespace: UnityEngine
public enum AnimationCullingType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AlwaysAnimate;
	public const object BasedOnRenderers;
	public const object BasedOnClipBounds;
	public const object BasedOnUserBounds;
}

// Namespace: UnityEngine
internal enum AnimationEventSource
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NoSource;
	public const object Legacy;
	public const object Animator;
}

// Namespace: 
private sealed class Enumerator
{

	// Fields
	private object m_Outer; // 0x8
	private object m_CurrentIndex; // 0x10

	// Properties
	public object Current { get; }

	// Methods

	// RVA: 0x7334620
	internal object .ctor(object outer) { }

	// RVA: 0x7334C14
	public object get_Current() { }

	// RVA: 0x7334C8C
	public object MoveNext() { }

	// RVA: 0x7334D00
	public object Reset() { }

}

// Namespace: UnityEngine
public sealed class Animation
{

	// Properties
	public object clip { get; set; }
	public object playAutomatically { get; set; }
	public object wrapMode { set; }
	public object isPlaying { get; }
	public object Item { get; }
	public object animatePhysics { get; set; }
	public object cullingType { get; set; }

	// Methods

	// RVA: 0x73336EC
	public object get_clip() { }

	// RVA: 0x733373C
	public object set_clip(object value) { }

	// RVA: 0x73337A0
	public object get_playAutomatically() { }

	// RVA: 0x73337F0
	public object set_playAutomatically(object value) { }

	// RVA: 0x7333854
	public object set_wrapMode(object value) { }

	// RVA: 0x73338B8
	public object Stop() { }

	// RVA: 0x7333908
	public object Stop(object name) { }

	// RVA: 0x733396C
	private object StopNamed(object name) { }

	// RVA: 0x73339D0
	public object Rewind() { }

	// RVA: 0x7333A20
	public object Sample() { }

	// RVA: 0x7333A70
	public object get_isPlaying() { }

	// RVA: 0x7333AC0
	public object IsPlaying(object name) { }

	// RVA: 0x7333B24
	public object get_Item(object name) { }

	// RVA: 0x7333BEC
	public object Play() { }

	// RVA: 0x7333C44
	public object Play(object mode) { }

	// RVA: 0x7333CA8
	private object PlayDefaultAnimation(object mode) { }

	// RVA: 0x7333D0C
	public object Play(object animation) { }

	// RVA: 0x7333D78
	public object Play(object animation, object mode) { }

	// RVA: 0x7333DE4
	public object CrossFade(object animation) { }

	// RVA: 0x7333E48
	public object CrossFade(object animation, object fadeLength) { }

	// RVA: 0x7333EC8
	public object CrossFade(object animation, object fadeLength, object mode) { }

	// RVA: 0x7333F48
	public object CrossFadeQueued(object animation) { }

	// RVA: 0x7333FB0
	public object CrossFadeQueued(object animation, object fadeLength) { }

	// RVA: 0x733401C
	public object CrossFadeQueued(object animation, object fadeLength, object queue) { }

	// RVA: 0x73340A4
	public object CrossFadeQueued(object animation, object fadeLength, object queue, object mode) { }

	// RVA: 0x7334138
	public object PlayQueued(object animation) { }

	// RVA: 0x73341AC
	public object PlayQueued(object animation, object queue) { }

	// RVA: 0x7334220
	public object PlayQueued(object animation, object queue, object mode) { }

	// RVA: 0x73342A0
	public object AddClip(object clip, object newName) { }

	// RVA: 0x7334308
	public object AddClip(object clip, object newName, object firstFrame, object lastFrame) { }

	// RVA: 0x7334398
	public object AddClip(object clip, object newName, object firstFrame, object lastFrame, object addLoopFrame) { }

	// RVA: 0x7334434
	public object RemoveClip(object clip) { }

	// RVA: 0x7334498
	public object RemoveClip(object clipName) { }

	// RVA: 0x73344FC
	private object RemoveClipNamed(object clipName) { }

	// RVA: 0x7334560
	public object GetClipCount() { }

	// RVA: 0x73345B0
	public object GetEnumerator() { }

	// RVA: 0x7333B88
	internal object GetState(object name) { }

	// RVA: 0x7334654
	internal object GetStateAtIndex(object index) { }

	// RVA: 0x73346B8
	internal object GetStateCount() { }

	// RVA: 0x7334708
	public object GetClip(object name) { }

	// RVA: 0x7334830
	public object SetAnimUpdateCull(object enable) { }

	// RVA: 0x733489C
	public object SetAnimUpdateCull(object enable, object updateIntervalForSkipAlwaysAnim) { }

	// RVA: 0x7334908
	public static object SetAnimCullTotalSwitch(object enable, object updateIntervalForSkipAlwaysAnim) { }

	// RVA: 0x733496C
	public static object SetAnimCullVisionSwitch(object enable) { }

	// RVA: 0x73349BC
	public object get_animatePhysics() { }

	// RVA: 0x7334A0C
	public object set_animatePhysics(object value) { }

	// RVA: 0x7334A70
	public object get_cullingType() { }

	// RVA: 0x7334AC0
	public object set_cullingType(object value) { }

	// RVA: 0x7334B24
	public static object SetAnimationJobsEnabled(object enable) { }

	// RVA: 0x7334B74
	public static object SetBatchedTransformMaskChangeEnabled(object enable) { }

	// RVA: 0x7334BC4
	public static object SetValidationJobsEnabled(object enable) { }

}

// Namespace: UnityEngine
public sealed class AnimationState
{

	// Properties
	public object enabled { get; set; }
	public object weight { get; }
	public object wrapMode { get; set; }
	public object time { get; set; }
	public object normalizedTime { get; set; }
	public object speed { get; set; }
	public object length { get; }
	public object clip { get; }
	public object name { get; set; }

	// Methods

	// RVA: 0x7334D0C
	public object get_enabled() { }

	// RVA: 0x7334D5C
	public object set_enabled(object value) { }

	// RVA: 0x7334DC0
	public object get_weight() { }

	// RVA: 0x7334E10
	public object get_wrapMode() { }

	// RVA: 0x7334E60
	public object set_wrapMode(object value) { }

	// RVA: 0x7334EC4
	public object get_time() { }

	// RVA: 0x7334F14
	public object set_time(object value) { }

	// RVA: 0x7334F78
	public object get_normalizedTime() { }

	// RVA: 0x7334FC8
	public object set_normalizedTime(object value) { }

	// RVA: 0x733502C
	public object get_speed() { }

	// RVA: 0x733507C
	public object set_speed(object value) { }

	// RVA: 0x73350E0
	public object get_length() { }

	// RVA: 0x73347E0
	public object get_clip() { }

	// RVA: 0x7335130
	public object get_name() { }

	// RVA: 0x7335180
	public object set_name(object value) { }

	// RVA: 0x73351E4
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class AnimationEvent
{

	// Fields
	internal object m_Time; // 0x8
	internal object m_FunctionName; // 0x10
	internal object m_StringParameter; // 0x18
	internal object m_ObjectReferenceParameter; // 0x20
	internal object m_FloatParameter; // 0x28
	internal object m_IntParameter; // 0x2C
	internal object m_MessageOptions; // 0x30
	internal object m_Source; // 0x34
	internal object m_StateSender; // 0x38
	internal object m_AnimatorStateInfo; // 0x40
	internal object m_AnimatorClipInfo; // 0x64

	// Properties
	public object stringParameter { set; }
	public object intParameter { set; }
	public object functionName { get; set; }
	public object time { set; }

	// Methods

	// RVA: 0x7335228
	public object .ctor() { }

	// RVA: 0x7335294
	public object set_stringParameter(object value) { }

	// RVA: 0x733529C
	public object set_intParameter(object value) { }

	// RVA: 0x73352A4
	public object get_functionName() { }

	// RVA: 0x73352AC
	public object set_functionName(object value) { }

	// RVA: 0x73352B4
	public object set_time(object value) { }

}

// Namespace: UnityEngine
public sealed class AnimationClip
{

	// Properties
	public object length { get; }
	public object frameRate { get; set; }
	public object wrapMode { get; }
	public object legacy { get; set; }
	public object empty { get; }
	public object hasGenericRootTransform { get; }
	public object hasMotionCurves { get; }
	public object hasRootCurves { get; }
	internal object hasRootMotion { get; }
	public object events { get; set; }

	// Methods

	// RVA: 0x73352BC
	public object .ctor() { }

	// RVA: 0x7335408
	private static object Internal_CreateAnimationClip(object self) { }

	// RVA: 0x7335458
	public object SampleAnimation(object go, object time) { }

	// RVA: 0x7335554
	internal static object SampleAnimation(object go, object clip, object inTime, object wrapMode) { }

	// RVA: 0x73355D4
	public object get_length() { }

	// RVA: 0x7335624
	public object get_frameRate() { }

	// RVA: 0x7335674
	public object set_frameRate(object value) { }

	// RVA: 0x7335504
	public object get_wrapMode() { }

	// RVA: 0x73356D8
	public object get_legacy() { }

	// RVA: 0x7335728
	public object set_legacy(object value) { }

	// RVA: 0x733578C
	public object get_empty() { }

	// RVA: 0x73357DC
	public object get_hasGenericRootTransform() { }

	// RVA: 0x733582C
	public object get_hasMotionCurves() { }

	// RVA: 0x733587C
	public object get_hasRootCurves() { }

	// RVA: 0x73358CC
	internal object get_hasRootMotion() { }

	// RVA: 0x733591C
	public object AddEvent(object evt) { }

	// RVA: 0x73359CC
	private object AddEventInternal(object evt) { }

	// RVA: 0x7335A30
	public object get_events() { }

	// RVA: 0x7335B2C
	public object set_events(object value) { }

	// RVA: 0x7335B90
	private object SetEventsInternal(object value) { }

	// RVA: 0x7335ADC
	private object GetEventsInternal() { }

}

// Namespace: UnityEngine
public enum AvatarTarget
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Root;
	public const object Body;
	public const object LeftFoot;
	public const object RightFoot;
	public const object LeftHand;
	public const object RightHand;
}

// Namespace: UnityEngine
public enum AvatarIKGoal
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LeftFoot;
	public const object RightFoot;
	public const object LeftHand;
	public const object RightHand;
}

// Namespace: UnityEngine
public enum AvatarIKHint
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LeftKnee;
	public const object RightKnee;
	public const object LeftElbow;
	public const object RightElbow;
}

// Namespace: UnityEngine
public enum AnimatorControllerParameterType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Float;
	public const object Int;
	public const object Bool;
	public const object Trigger;
}

// Namespace: UnityEngine
internal enum StateInfoIndex
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object CurrentState;
	public const object NextState;
	public const object ExitState;
	public const object InterruptedState;
}

// Namespace: UnityEngine
public enum AnimatorRecorderMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Offline;
	public const object Playback;
	public const object Record;
}

// Namespace: UnityEngine
public enum AnimatorCullingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AlwaysAnimate;
	public const object CullUpdateTransforms;
	public const object CullCompletely;
}

// Namespace: UnityEngine
public enum AnimatorUpdateMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object AnimatePhysics;
	public const object UnscaledTime;
}

// Namespace: UnityEngine
public struct AnimatorClipInfo
{

	// Fields
	private object m_ClipInstanceID; // 0xFFFFFFFFFFFFFFF8
	private object m_Weight; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object clip { get; }
	public object weight { get; }

	// Methods

	// RVA: 0x7335BF4
	public object get_clip() { }

	// RVA: 0x7335D0C
	public object get_weight() { }

	// RVA: 0x7335C58
	private static object InstanceIDToAnimationClipPPtr(object instanceID) { }

}

// Namespace: UnityEngine
public struct AnimatorStateInfo
{

	// Fields
	private object m_Name; // 0xFFFFFFFFFFFFFFF8
	private object m_Path; // 0xFFFFFFFFFFFFFFFC
	private object m_FullPath; // 0x0
	private object m_NormalizedTime; // 0x4
	private object m_Length; // 0x8
	private object m_Speed; // 0xC
	private object m_SpeedMultiplier; // 0x10
	private object m_Tag; // 0x14
	private object m_Loop; // 0x18

	// Properties
	public object fullPathHash { get; }
	public object nameHash { get; }
	public object shortNameHash { get; }
	public object normalizedTime { get; }
	public object length { get; }
	public object speed { get; }
	public object speedMultiplier { get; }
	public object loop { get; }

	// Methods

	// RVA: 0x7335D1C
	public object IsName(object name) { }

	// RVA: 0x7335ECC
	public object get_fullPathHash() { }

	// RVA: 0x7335EDC
	public object get_nameHash() { }

	// RVA: 0x7335EEC
	public object get_shortNameHash() { }

	// RVA: 0x7335EFC
	public object get_normalizedTime() { }

	// RVA: 0x7335F0C
	public object get_length() { }

	// RVA: 0x7335F1C
	public object get_speed() { }

	// RVA: 0x7335F2C
	public object get_speedMultiplier() { }

	// RVA: 0x7335F3C
	public object get_loop() { }

}

// Namespace: UnityEngine
public struct AnimatorTransitionInfo
{

	// Fields
	private object m_FullPath; // 0xFFFFFFFFFFFFFFF8
	private object m_UserName; // 0xFFFFFFFFFFFFFFFC
	private object m_Name; // 0x0
	private object m_HasFixedDuration; // 0x4
	private object m_Duration; // 0x8
	private object m_NormalizedTime; // 0xC
	private object m_AnyState; // 0x10
	private object m_TransitionType; // 0x14
}

// Namespace: UnityEngine
public struct MatchTargetWeightMask
{

	// Fields
	private object m_PositionXYZWeight; // 0xFFFFFFFFFFFFFFF8
	private object m_RotationWeight; // 0x4
}

// Namespace: UnityEngine
public class Animator
{

	// Properties
	public object isOptimizable { get; }
	public object isHuman { get; }
	public object hasRootMotion { get; }
	internal object isRootPositionOrRotationControlledByCurves { get; }
	public object humanScale { get; }
	public object isInitialized { get; }
	public object deltaPosition { get; }
	public object deltaRotation { get; }
	public object velocity { get; }
	public object angularVelocity { get; }
	public object rootPosition { get; set; }
	public object rootRotation { get; set; }
	public object applyRootMotion { get; set; }
	public object linearVelocityBlending { get; set; }
	public object animatePhysics { get; set; }
	public object updateMode { get; set; }
	public object hasTransformHierarchy { get; }
	internal object allowConstantClipSamplingOptimization { get; set; }
	public object gravityWeight { get; }
	public object bodyPosition { get; set; }
	internal object bodyPositionInternal { get; set; }
	public object bodyRotation { get; set; }
	internal object bodyRotationInternal { get; set; }
	public object stabilizeFeet { get; set; }
	public object layerCount { get; }
	public object parameters { get; }
	public object parameterCount { get; }
	public object feetPivotActive { get; set; }
	public object pivotWeight { get; }
	public object pivotPosition { get; }
	public object isMatchingTarget { get; }
	public object speed { get; set; }
	public object targetPosition { get; }
	public object targetRotation { get; }
	public object avatarRoot { get; }
	public object cullingMode { get; set; }
	public object playbackTime { get; set; }
	public object recorderStartTime { get; set; }
	public object recorderStopTime { get; set; }
	public object recorderMode { get; }
	public object runtimeAnimatorController { get; set; }
	public object hasBoundPlayables { get; }
	public object avatar { get; set; }
	public object playableGraph { get; }
	public object layersAffectMassCenter { get; set; }
	public object leftFeetBottomHeight { get; }
	public object rightFeetBottomHeight { get; }
	internal object supportsOnAnimatorMove { get; }
	public object logWarnings { get; set; }
	public object fireEvents { get; set; }
	public object keepAnimatorControllerStateOnDisable { get; set; }
	public object keepAnimatorStateOnDisable { get; set; }
	public object writeDefaultValuesOnDisable { get; set; }

	// Methods

	// RVA: 0x7335FC8
	public object get_isOptimizable() { }

	// RVA: 0x7336018
	public object get_isHuman() { }

	// RVA: 0x7336068
	public object get_hasRootMotion() { }

	// RVA: 0x73360B8
	internal object get_isRootPositionOrRotationControlledByCurves() { }

	// RVA: 0x7336108
	public object get_humanScale() { }

	// RVA: 0x7336158
	public object get_isInitialized() { }

	// RVA: 0x73361A8
	public object GetFloat(object name) { }

	// RVA: 0x7336270
	public object GetFloat(object id) { }

	// RVA: 0x7336338
	public object SetFloat(object name, object value) { }

	// RVA: 0x7336428
	public object SetFloat(object name, object value, object dampTime, object deltaTime) { }

	// RVA: 0x7336550
	public object SetFloat(object id, object value) { }

	// RVA: 0x7336640
	public object SetFloat(object id, object value, object dampTime, object deltaTime) { }

	// RVA: 0x7336768
	public object GetBool(object name) { }

	// RVA: 0x7336830
	public object GetBool(object id) { }

	// RVA: 0x73368F8
	public object SetBool(object name, object value) { }

	// RVA: 0x73369D0
	public object SetBool(object id, object value) { }

	// RVA: 0x7336AA8
	public object GetInteger(object name) { }

	// RVA: 0x7336B70
	public object GetInteger(object id) { }

	// RVA: 0x7336C38
	public object SetInteger(object name, object value) { }

	// RVA: 0x7336D10
	public object SetInteger(object id, object value) { }

	// RVA: 0x7336DE8
	public object SetTrigger(object name) { }

	// RVA: 0x7336EB0
	public object SetTrigger(object id) { }

	// RVA: 0x7336F78
	public object ResetTrigger(object name) { }

	// RVA: 0x7337040
	public object ResetTrigger(object id) { }

	// RVA: 0x7337108
	public object IsParameterControlledByCurve(object name) { }

	// RVA: 0x73371D0
	public object IsParameterControlledByCurve(object id) { }

	// RVA: 0x7337298
	public object get_deltaPosition() { }

	// RVA: 0x7337360
	public object get_deltaRotation() { }

	// RVA: 0x7337424
	public object get_velocity() { }

	// RVA: 0x73374EC
	public object get_angularVelocity() { }

	// RVA: 0x73375B4
	public object get_rootPosition() { }

	// RVA: 0x733767C
	public object set_rootPosition(object value) { }

	// RVA: 0x7337754
	public object get_rootRotation() { }

	// RVA: 0x7337818
	public object set_rootRotation(object value) { }

	// RVA: 0x73378F0
	public object get_applyRootMotion() { }

	// RVA: 0x7337940
	public object set_applyRootMotion(object value) { }

	// RVA: 0x73379A4
	public object get_linearVelocityBlending() { }

	// RVA: 0x73379F4
	public object set_linearVelocityBlending(object value) { }

	// RVA: 0x7337A58
	public object get_animatePhysics() { }

	// RVA: 0x7337B10
	public object set_animatePhysics(object value) { }

	// RVA: 0x7337AC0
	public object get_updateMode() { }

	// RVA: 0x7337B84
	public object set_updateMode(object value) { }

	// RVA: 0x7337BE8
	public object get_hasTransformHierarchy() { }

	// RVA: 0x7337C38
	internal object get_allowConstantClipSamplingOptimization() { }

	// RVA: 0x7337C88
	internal object set_allowConstantClipSamplingOptimization(object value) { }

	// RVA: 0x7337CEC
	public object get_gravityWeight() { }

	// RVA: 0x7337D3C
	public object get_bodyPosition() { }

	// RVA: 0x7337F00
	public object set_bodyPosition(object value) { }

	// RVA: 0x7337E9C
	internal object get_bodyPositionInternal() { }

	// RVA: 0x7337F78
	internal object set_bodyPositionInternal(object value) { }

	// RVA: 0x73380B4
	public object get_bodyRotation() { }

	// RVA: 0x7338174
	public object set_bodyRotation(object value) { }

	// RVA: 0x7338114
	internal object get_bodyRotationInternal() { }

	// RVA: 0x73381F0
	internal object set_bodyRotationInternal(object value) { }

	// RVA: 0x733832C
	public object GetIKPosition(object goal) { }

	// RVA: 0x73383A0
	private object GetGoalPosition(object goal) { }

	// RVA: 0x7338480
	public object SetIKPosition(object goal, object goalPosition) { }

	// RVA: 0x7338508
	private object SetGoalPosition(object goal, object goalPosition) { }

	// RVA: 0x73385E0
	public object GetIKRotation(object goal) { }

	// RVA: 0x7338650
	private object GetGoalRotation(object goal) { }

	// RVA: 0x733872C
	public object SetIKRotation(object goal, object goalRotation) { }

	// RVA: 0x73387B8
	private object SetGoalRotation(object goal, object goalRotation) { }

	// RVA: 0x7338890
	public object GetIKPositionWeight(object goal) { }

	// RVA: 0x73388FC
	private object GetGoalWeightPosition(object goal) { }

	// RVA: 0x7338960
	public object SetIKPositionWeight(object goal, object value) { }

	// RVA: 0x73389C4
	private object SetGoalWeightPosition(object goal, object value) { }

	// RVA: 0x7338A3C
	public object GetIKRotationWeight(object goal) { }

	// RVA: 0x7338AA8
	private object GetGoalWeightRotation(object goal) { }

	// RVA: 0x7338B0C
	public object SetIKRotationWeight(object goal, object value) { }

	// RVA: 0x7338B70
	private object SetGoalWeightRotation(object goal, object value) { }

	// RVA: 0x7338BE8
	public object GetIKHintPosition(object hint) { }

	// RVA: 0x7338C5C
	private object GetHintPosition(object hint) { }

	// RVA: 0x7338D3C
	public object SetIKHintPosition(object hint, object hintPosition) { }

	// RVA: 0x7338DC4
	private object SetHintPosition(object hint, object hintPosition) { }

	// RVA: 0x7338E9C
	public object GetIKHintPositionWeight(object hint) { }

	// RVA: 0x7338F08
	private object GetHintWeightPosition(object hint) { }

	// RVA: 0x7338F6C
	public object SetIKHintPositionWeight(object hint, object value) { }

	// RVA: 0x7338FD0
	private object SetHintWeightPosition(object hint, object value) { }

	// RVA: 0x7339048
	public object SetLookAtPosition(object lookAtPosition) { }

	// RVA: 0x73390C0
	private object SetLookAtPositionInternal(object lookAtPosition) { }

	// RVA: 0x7339198
	public object SetLookAtWeight(object weight) { }

	// RVA: 0x7339298
	public object SetLookAtWeight(object weight, object bodyWeight) { }

	// RVA: 0x7339300
	public object SetLookAtWeight(object weight, object bodyWeight, object headWeight) { }

	// RVA: 0x7339374
	public object SetLookAtWeight(object weight, object bodyWeight, object headWeight, object eyesWeight) { }

	// RVA: 0x73393EC
	public object SetLookAtWeight(object weight, object bodyWeight, object headWeight, object eyesWeight, object clampWeight) { }

	// RVA: 0x73391FC
	private object SetLookAtWeightInternal(object weight, object bodyWeight, object headWeight, object eyesWeight, object clampWeight) { }

	// RVA: 0x7339470
	public object SetBoneLocalRotation(object humanBoneId, object rotation) { }

	// RVA: 0x7339578
	private object SetBoneLocalRotationInternal(object humanBoneId, object rotation) { }

	// RVA: 0x7339650
	private object GetBehaviour(object type) { }

	// RVA: -1
	public object GetBehaviour() { }

	// RVA: -1
	private static object ConvertStateMachineBehaviour(object rawObjects) { }

	// RVA: -1
	public object GetBehaviours() { }

	// RVA: 0x73396B4
	internal object InternalGetBehaviours(object type) { }

	// RVA: 0x7339718
	public object GetBehaviours(object fullPathHash, object layerIndex) { }

	// RVA: 0x73397F8
	internal object InternalGetBehavioursByKey(object fullPathHash, object layerIndex, object type) { }

	// RVA: 0x7339878
	public object get_stabilizeFeet() { }

	// RVA: 0x73398C8
	public object set_stabilizeFeet(object value) { }

	// RVA: 0x733992C
	public object get_layerCount() { }

	// RVA: 0x733997C
	public object GetLayerName(object layerIndex) { }

	// RVA: 0x73399E0
	public object GetLayerIndex(object layerName) { }

	// RVA: 0x7339A44
	public object GetLayerWeight(object layerIndex) { }

	// RVA: 0x7339AA8
	public object SetLayerWeight(object layerIndex, object weight) { }

	// RVA: 0x7339B20
	private object GetAnimatorStateInfo(object layerIndex, object stateInfoIndex, object info) { }

	// RVA: 0x7339BA0
	public object GetCurrentAnimatorStateInfo(object layerIndex) { }

	// RVA: 0x7339C28
	public object GetNextAnimatorStateInfo(object layerIndex) { }

	// RVA: 0x7339CB0
	private object GetAnimatorTransitionInfo(object layerIndex, object info) { }

	// RVA: 0x7339D1C
	public object GetAnimatorTransitionInfo(object layerIndex) { }

	// RVA: 0x7339D94
	internal object GetAnimatorClipInfoCount(object layerIndex, object current) { }

	// RVA: 0x7339E00
	public object GetCurrentAnimatorClipInfoCount(object layerIndex) { }

	// RVA: 0x7339E6C
	public object GetNextAnimatorClipInfoCount(object layerIndex) { }

	// RVA: 0x7339ED8
	public object GetCurrentAnimatorClipInfo(object layerIndex) { }

	// RVA: 0x7339F3C
	public object GetNextAnimatorClipInfo(object layerIndex) { }

	// RVA: 0x7339FA0
	public object GetCurrentAnimatorClipInfo(object layerIndex, object clips) { }

	// RVA: 0x733A064
	private object GetAnimatorClipInfoInternal(object layerIndex, object isCurrent, object clips) { }

	// RVA: 0x733A0E4
	public object SetAnimUpdateCull(object enable) { }

	// RVA: 0x733A148
	public static object DumpAnimatorProfileInfo(object cleanRecord) { }

	// RVA: 0x733A198
	public object IsCurrentFrameSkipUpdate() { }

	// RVA: 0x733A1E8
	public static object SetAnimCullTotalSwitch(object enable, object updateIntervalForSkipAlwaysAnim) { }

	// RVA: 0x733A24C
	public static object SetAnimCullVisionSwitch(object enable) { }

	// RVA: 0x733A29C
	public object DisableAlwaysAnimOpt() { }

	// RVA: 0x733A2EC
	public static object StartProfileAnimatorInfo() { }

	// RVA: 0x733A32C
	public static object EndProfileAnimatorInfo() { }

	// RVA: 0x733A36C
	public object SetAnimatorStatePlayingTime(object layerIndex, object isCurrent, object normalizedTime) { }

	// RVA: 0x733A3EC
	public object GetNextAnimatorClipInfo(object layerIndex, object clips) { }

	// RVA: 0x733A4B0
	public object IsInTransition(object layerIndex) { }

	// RVA: 0x733A514
	public object get_parameters() { }

	// RVA: 0x733A564
	public object get_parameterCount() { }

	// RVA: 0x733A5B4
	private object GetParameterInternal(object index) { }

	// RVA: 0x733A618
	public object GetParameter(object index) { }

	// RVA: 0x733A6FC
	public object get_feetPivotActive() { }

	// RVA: 0x733A74C
	public object set_feetPivotActive(object value) { }

	// RVA: 0x733A7B0
	public object get_pivotWeight() { }

	// RVA: 0x733A800
	public object get_pivotPosition() { }

	// RVA: 0x733A8C8
	private object MatchTarget(object matchPosition, object matchRotation, object targetBodyPart, object weightMask, object startNormalizedTime, object targetNormalizedTime, object completeMatch) { }

	// RVA: 0x733AA04
	public object MatchTarget(object matchPosition, object matchRotation, object targetBodyPart, object weightMask, object startNormalizedTime) { }

	// RVA: 0x733AAA0
	public object MatchTarget(object matchPosition, object matchRotation, object targetBodyPart, object weightMask, object startNormalizedTime, object targetNormalizedTime) { }

	// RVA: 0x733AB3C
	public object MatchTarget(object matchPosition, object matchRotation, object targetBodyPart, object weightMask, object startNormalizedTime, object targetNormalizedTime, object completeMatch) { }

	// RVA: 0x733ABDC
	public object InterruptMatchTarget() { }

	// RVA: 0x733AC34
	public object InterruptMatchTarget(object completeMatch) { }

	// RVA: 0x733AC98
	public object get_isMatchingTarget() { }

	// RVA: 0x733ACE8
	public object get_speed() { }

	// RVA: 0x733AD38
	public object set_speed(object value) { }

	// RVA: 0x733AD9C
	public object ForceStateNormalizedTime(object normalizedTime) { }

	// RVA: 0x733AE90
	public object CrossFadeInFixedTime(object stateName, object fixedTransitionDuration) { }

	// RVA: 0x733AFE0
	public object CrossFadeInFixedTime(object stateName, object fixedTransitionDuration, object layer) { }

	// RVA: 0x733B098
	public object CrossFadeInFixedTime(object stateName, object fixedTransitionDuration, object layer, object fixedTimeOffset) { }

	// RVA: 0x733B154
	public object CrossFadeInFixedTime(object stateName, object fixedTransitionDuration, object layer, object fixedTimeOffset, object normalizedTransitionTime) { }

	// RVA: 0x733B21C
	public object CrossFadeInFixedTime(object stateHashName, object fixedTransitionDuration, object layer, object fixedTimeOffset) { }

	// RVA: 0x733B2AC
	public object CrossFadeInFixedTime(object stateHashName, object fixedTransitionDuration, object layer) { }

	// RVA: 0x733B320
	public object CrossFadeInFixedTime(object stateHashName, object fixedTransitionDuration) { }

	// RVA: 0x733AF44
	public object CrossFadeInFixedTime(object stateHashName, object fixedTransitionDuration, object layer, object fixedTimeOffset, object normalizedTransitionTime) { }

	// RVA: 0x733B390
	public object WriteDefaultValues() { }

	// RVA: 0x733B3E0
	public object CrossFade(object stateName, object normalizedTransitionDuration, object layer, object normalizedTimeOffset) { }

	// RVA: 0x733B564
	public object CrossFade(object stateName, object normalizedTransitionDuration, object layer) { }

	// RVA: 0x733B620
	public object CrossFade(object stateName, object normalizedTransitionDuration) { }

	// RVA: 0x733B49C
	public object CrossFade(object stateName, object normalizedTransitionDuration, object layer, object normalizedTimeOffset, object normalizedTransitionTime) { }

	// RVA: 0x733B6D8
	public object CrossFade(object stateHashName, object normalizedTransitionDuration, object layer, object normalizedTimeOffset, object normalizedTransitionTime) { }

	// RVA: 0x733B774
	public object CrossFade(object stateHashName, object normalizedTransitionDuration, object layer, object normalizedTimeOffset) { }

	// RVA: 0x733B804
	public object CrossFade(object stateHashName, object normalizedTransitionDuration, object layer) { }

	// RVA: 0x733B87C
	public object CrossFade(object stateHashName, object normalizedTransitionDuration) { }

	// RVA: 0x733B8F0
	public object PlayInFixedTime(object stateName, object layer) { }

	// RVA: 0x733BA48
	public object PlayInFixedTime(object stateName) { }

	// RVA: 0x733B998
	public object PlayInFixedTime(object stateName, object layer, object fixedTime) { }

	// RVA: 0x733BAEC
	public object PlayInFixedTime(object stateNameHash, object layer, object fixedTime) { }

	// RVA: 0x733BB6C
	public object PlayInFixedTime(object stateNameHash, object layer) { }

	// RVA: 0x733BBE8
	public object PlayInFixedTime(object stateNameHash) { }

	// RVA: 0x733BC48
	public object Play(object stateName, object layer) { }

	// RVA: 0x733BDA0
	public object Play(object stateName) { }

	// RVA: 0x733BCF0
	public object Play(object stateName, object layer, object normalizedTime) { }

	// RVA: 0x733AE10
	public object Play(object stateNameHash, object layer, object normalizedTime) { }

	// RVA: 0x733BE44
	public object Play(object stateNameHash, object layer) { }

	// RVA: 0x733BEC0
	public object Play(object stateNameHash) { }

	// RVA: 0x733BF20
	public object SetTarget(object targetIndex, object targetNormalizedTime) { }

	// RVA: 0x733BF98
	public object get_targetPosition() { }

	// RVA: 0x733C060
	public object get_targetRotation() { }

	// RVA: 0x733C124
	public object IsControlled(object transform) { }

	// RVA: 0x733C12C
	internal object IsBoneTransform(object transform) { }

	// RVA: 0x733C190
	public object get_avatarRoot() { }

	// RVA: 0x733C1E0
	public object GetBoneTransform(object humanBoneId) { }

	// RVA: 0x733C614
	internal object GetBoneTransformInternal(object humanBoneId) { }

	// RVA: 0x733C678
	public object get_cullingMode() { }

	// RVA: 0x733C6C8
	public object set_cullingMode(object value) { }

	// RVA: 0x733C72C
	public object StartPlayback() { }

	// RVA: 0x733C77C
	public object StopPlayback() { }

	// RVA: 0x733C7CC
	public object get_playbackTime() { }

	// RVA: 0x733C81C
	public object set_playbackTime(object value) { }

	// RVA: 0x733C880
	public object StartRecording(object frameCount) { }

	// RVA: 0x733C8E4
	public object StopRecording() { }

	// RVA: 0x733C934
	public object get_recorderStartTime() { }

	// RVA: 0x733C9D4
	public object set_recorderStartTime(object value) { }

	// RVA: 0x733C984
	private object GetRecorderStartTime() { }

	// RVA: 0x733C9D8
	public object get_recorderStopTime() { }

	// RVA: 0x733CA78
	public object set_recorderStopTime(object value) { }

	// RVA: 0x733CA28
	private object GetRecorderStopTime() { }

	// RVA: 0x733CA7C
	public object get_recorderMode() { }

	// RVA: 0x733CACC
	public object get_runtimeAnimatorController() { }

	// RVA: 0x733CB1C
	public object set_runtimeAnimatorController(object value) { }

	// RVA: 0x733CB80
	public object get_hasBoundPlayables() { }

	// RVA: 0x733CBD0
	internal object ClearInternalControllerPlayable() { }

	// RVA: 0x733CC20
	public object HasState(object layerIndex, object stateID) { }

	// RVA: 0x7335DCC
	public static object StringToHash(object name) { }

	// RVA: 0x733C524
	public object get_avatar() { }

	// RVA: 0x733CC8C
	public object set_avatar(object value) { }

	// RVA: 0x733CCF0
	internal object GetStats() { }

	// RVA: 0x733CD40
	public object get_playableGraph() { }

	// RVA: 0x733CD9C
	private object GetCurrentGraph(object graph) { }

	// RVA: 0x7337DA0
	private object CheckIfInIKPass() { }

	// RVA: 0x733CE50
	private object IsInIKPass() { }

	// RVA: 0x73363B0
	private object SetFloatString(object name, object value) { }

	// RVA: 0x73365C8
	private object SetFloatID(object id, object value) { }

	// RVA: 0x733620C
	private object GetFloatString(object name) { }

	// RVA: 0x73362D4
	private object GetFloatID(object id) { }

	// RVA: 0x7336964
	private object SetBoolString(object name, object value) { }

	// RVA: 0x7336A3C
	private object SetBoolID(object id, object value) { }

	// RVA: 0x73367CC
	private object GetBoolString(object name) { }

	// RVA: 0x7336894
	private object GetBoolID(object id) { }

	// RVA: 0x7336CA4
	private object SetIntegerString(object name, object value) { }

	// RVA: 0x7336D7C
	private object SetIntegerID(object id, object value) { }

	// RVA: 0x7336B0C
	private object GetIntegerString(object name) { }

	// RVA: 0x7336BD4
	private object GetIntegerID(object id) { }

	// RVA: 0x7336E4C
	private object SetTriggerString(object name) { }

	// RVA: 0x7336F14
	private object SetTriggerID(object id) { }

	// RVA: 0x7336FDC
	private object ResetTriggerString(object name) { }

	// RVA: 0x73370A4
	private object ResetTriggerID(object id) { }

	// RVA: 0x733716C
	private object IsParameterControlledByCurveString(object name) { }

	// RVA: 0x7337234
	private object IsParameterControlledByCurveID(object id) { }

	// RVA: 0x73364BC
	private object SetFloatStringDamp(object name, object value, object dampTime, object deltaTime) { }

	// RVA: 0x73366D4
	private object SetFloatIDDamp(object id, object value, object dampTime, object deltaTime) { }

	// RVA: 0x733CEA0
	public object get_layersAffectMassCenter() { }

	// RVA: 0x733CEF0
	public object set_layersAffectMassCenter(object value) { }

	// RVA: 0x733CF54
	public object get_leftFeetBottomHeight() { }

	// RVA: 0x733CFA4
	public object get_rightFeetBottomHeight() { }

	// RVA: 0x733CFF4
	internal object get_supportsOnAnimatorMove() { }

	// RVA: 0x733D044
	internal object OnUpdateModeChanged() { }

	// RVA: 0x733D094
	internal object OnCullingModeChanged() { }

	// RVA: 0x733D0E4
	internal object WriteDefaultPose() { }

	// RVA: 0x733D134
	public object Update(object deltaTime) { }

	// RVA: 0x733D198
	public object Rebind() { }

	// RVA: 0x733D1F0
	private object Rebind(object writeDefaultValues) { }

	// RVA: 0x733D254
	public object ApplyBuiltinRootMotion() { }

	// RVA: 0x733D2A4
	internal object EvaluateController() { }

	// RVA: 0x733D2FC
	private object EvaluateController(object deltaTime) { }

	// RVA: 0x733D360
	internal object GetCurrentStateName(object layerIndex) { }

	// RVA: 0x733D438
	internal object GetNextStateName(object layerIndex) { }

	// RVA: 0x733D3CC
	private object GetAnimatorStateName(object layerIndex, object current) { }

	// RVA: 0x733D4A4
	internal object ResolveHash(object hash) { }

	// RVA: 0x733CE00
	public object get_logWarnings() { }

	// RVA: 0x733D508
	public object set_logWarnings(object value) { }

	// RVA: 0x733D56C
	public object get_fireEvents() { }

	// RVA: 0x733D5BC
	public object set_fireEvents(object value) { }

	// RVA: 0x733D620
	public object get_keepAnimatorControllerStateOnDisable() { }

	// RVA: 0x733D6C0
	public object set_keepAnimatorControllerStateOnDisable(object value) { }

	// RVA: 0x733D670
	public object get_keepAnimatorStateOnDisable() { }

	// RVA: 0x733D724
	public object set_keepAnimatorStateOnDisable(object value) { }

	// RVA: 0x733D788
	public object get_writeDefaultValuesOnDisable() { }

	// RVA: 0x733D7D8
	public object set_writeDefaultValuesOnDisable(object value) { }

	// RVA: 0x733D83C
	public object GetVector(object name) { }

	// RVA: 0x733D88C
	public object GetVector(object id) { }

	// RVA: 0x733D8DC
	public object SetVector(object name, object value) { }

	// RVA: 0x733D8E0
	public object SetVector(object id, object value) { }

	// RVA: 0x733D8E4
	public object GetQuaternion(object name) { }

	// RVA: 0x733D934
	public object GetQuaternion(object id) { }

	// RVA: 0x733D984
	public object SetQuaternion(object name, object value) { }

	// RVA: 0x733D988
	public object SetQuaternion(object id, object value) { }

	// RVA: 0x733D98C
	public object .ctor() { }

	// RVA: 0x73372FC
	private object get_deltaPosition_Injected(object ret) { }

	// RVA: 0x73373C0
	private object get_deltaRotation_Injected(object ret) { }

	// RVA: 0x7337488
	private object get_velocity_Injected(object ret) { }

	// RVA: 0x7337550
	private object get_angularVelocity_Injected(object ret) { }

	// RVA: 0x7337618
	private object get_rootPosition_Injected(object ret) { }

	// RVA: 0x73376F0
	private object set_rootPosition_Injected(object value) { }

	// RVA: 0x73377B4
	private object get_rootRotation_Injected(object ret) { }

	// RVA: 0x733788C
	private object set_rootRotation_Injected(object value) { }

	// RVA: 0x7337FEC
	private object get_bodyPositionInternal_Injected(object ret) { }

	// RVA: 0x7338050
	private object set_bodyPositionInternal_Injected(object value) { }

	// RVA: 0x7338264
	private object get_bodyRotationInternal_Injected(object ret) { }

	// RVA: 0x73382C8
	private object set_bodyRotationInternal_Injected(object value) { }

	// RVA: 0x7338414
	private object GetGoalPosition_Injected(object goal, object ret) { }

	// RVA: 0x7338574
	private object SetGoalPosition_Injected(object goal, object goalPosition) { }

	// RVA: 0x73386C0
	private object GetGoalRotation_Injected(object goal, object ret) { }

	// RVA: 0x7338824
	private object SetGoalRotation_Injected(object goal, object goalRotation) { }

	// RVA: 0x7338CD0
	private object GetHintPosition_Injected(object hint, object ret) { }

	// RVA: 0x7338E30
	private object SetHintPosition_Injected(object hint, object hintPosition) { }

	// RVA: 0x7339134
	private object SetLookAtPositionInternal_Injected(object lookAtPosition) { }

	// RVA: 0x73395E4
	private object SetBoneLocalRotationInternal_Injected(object humanBoneId, object rotation) { }

	// RVA: 0x733A864
	private object get_pivotPosition_Injected(object ret) { }

	// RVA: 0x733A968
	private object MatchTarget_Injected(object matchPosition, object matchRotation, object targetBodyPart, object weightMask, object startNormalizedTime, object targetNormalizedTime, object completeMatch) { }

	// RVA: 0x733BFFC
	private object get_targetPosition_Injected(object ret) { }

	// RVA: 0x733C0C0
	private object get_targetRotation_Injected(object ret) { }

}

// Namespace: UnityEngine
public class AnimatorControllerParameter
{

	// Fields
	internal object m_Name; // 0x8
	internal object m_Type; // 0x10
	internal object m_DefaultFloat; // 0x14
	internal object m_DefaultInt; // 0x18
	internal object m_DefaultBool; // 0x1C

	// Properties
	public object name { get; }
	public object nameHash { get; }
	public object type { get; }
	public object defaultFloat { get; }
	public object defaultInt { get; }
	public object defaultBool { get; }

	// Methods

	// RVA: 0x733DA5C
	public object get_name() { }

	// RVA: 0x733DA64
	public object get_nameHash() { }

	// RVA: 0x733DAB4
	public object get_type() { }

	// RVA: 0x733DABC
	public object get_defaultFloat() { }

	// RVA: 0x733DAC4
	public object get_defaultInt() { }

	// RVA: 0x733DACC
	public object get_defaultBool() { }

	// RVA: 0x733DAD4
	public override object Equals(object o) { }

	// RVA: 0x733DBD0
	public override object GetHashCode() { }

	// RVA: 0x733DC1C
	public object .ctor() { }

}

// Namespace: 
internal sealed class OnOverrideControllerDirtyCallback
{

	// Methods

	// RVA: 0x733E904
	public object .ctor(object object, object method) { }

	// RVA: 0x733E998
	public virtual object Invoke() { }

}

// Namespace: UnityEngine
public class AnimatorOverrideController
{

	// Fields
	internal object OnOverrideControllerDirty; // 0x10

	// Properties
	public object runtimeAnimatorController { get; set; }
	public object Item { set; }
	public object Item { set; }
	public object overridesCount { get; }

	// Methods

	// RVA: 0x733DC7C
	public object .ctor() { }

	// RVA: 0x733DE28
	public object .ctor(object controller) { }

	// RVA: 0x733DDC4
	private static object Internal_Create(object self, object controller) { }

	// RVA: 0x733DEEC
	public object get_runtimeAnimatorController() { }

	// RVA: 0x733DF3C
	public object set_runtimeAnimatorController(object value) { }

	// RVA: 0x733DFA0
	public object set_Item(object name, object value) { }

	// RVA: 0x733E00C
	private object Internal_SetClipByName(object name, object clip) { }

	// RVA: 0x733E078
	public object set_Item(object clip, object value) { }

	// RVA: 0x733E0EC
	private object SetClip(object originalClip, object overrideClip, object notify) { }

	// RVA: 0x733E16C
	private object SendNotification() { }

	// RVA: 0x733E1BC
	private object GetOriginalClip(object index) { }

	// RVA: 0x733E220
	private object GetOverrideClip(object originalClip) { }

	// RVA: 0x733E284
	public object get_overridesCount() { }

	// RVA: 0x733E2D4
	public object GetOverrides(object overrides) { }

	// RVA: 0x733E5B0
	public object ApplyOverrides(object overrides) { }

	// RVA: 0x733E878
	internal static object OnInvalidateOverrideController(object controller) { }

}

// Namespace: UnityEngine
public enum HumanBodyBones
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Hips;
	public const object LeftUpperLeg;
	public const object RightUpperLeg;
	public const object LeftLowerLeg;
	public const object RightLowerLeg;
	public const object LeftFoot;
	public const object RightFoot;
	public const object Spine;
	public const object Chest;
	public const object UpperChest;
	public const object Neck;
	public const object Head;
	public const object LeftShoulder;
	public const object RightShoulder;
	public const object LeftUpperArm;
	public const object RightUpperArm;
	public const object LeftLowerArm;
	public const object RightLowerArm;
	public const object LeftHand;
	public const object RightHand;
	public const object LeftToes;
	public const object RightToes;
	public const object LeftEye;
	public const object RightEye;
	public const object Jaw;
	public const object LeftThumbProximal;
	public const object LeftThumbIntermediate;
	public const object LeftThumbDistal;
	public const object LeftIndexProximal;
	public const object LeftIndexIntermediate;
	public const object LeftIndexDistal;
	public const object LeftMiddleProximal;
	public const object LeftMiddleIntermediate;
	public const object LeftMiddleDistal;
	public const object LeftRingProximal;
	public const object LeftRingIntermediate;
	public const object LeftRingDistal;
	public const object LeftLittleProximal;
	public const object LeftLittleIntermediate;
	public const object LeftLittleDistal;
	public const object RightThumbProximal;
	public const object RightThumbIntermediate;
	public const object RightThumbDistal;
	public const object RightIndexProximal;
	public const object RightIndexIntermediate;
	public const object RightIndexDistal;
	public const object RightMiddleProximal;
	public const object RightMiddleIntermediate;
	public const object RightMiddleDistal;
	public const object RightRingProximal;
	public const object RightRingIntermediate;
	public const object RightRingDistal;
	public const object RightLittleProximal;
	public const object RightLittleIntermediate;
	public const object RightLittleDistal;
	public const object LastBone;
}

// Namespace: UnityEngine
public class Avatar
{

	// Properties
	public object isValid { get; }
	public object isHuman { get; }
	public object humanDescription { get; }

	// Methods

	// RVA: 0x733E9AC
	private object .ctor() { }

	// RVA: 0x733C574
	public object get_isValid() { }

	// RVA: 0x733C5C4
	public object get_isHuman() { }

	// RVA: 0x733EA34
	public object get_humanDescription() { }

	// RVA: 0x733EAB0
	private object get_humanDescription_Injected(object ret) { }

}

// Namespace: UnityEngine
public struct SkeletonBone
{

	// Fields
	public object name; // 0xFFFFFFFFFFFFFFF8
	internal object parentName; // 0x0
	public object position; // 0x8
	public object rotation; // 0x14
	public object scale; // 0x24
}

// Namespace: UnityEngine
public struct HumanLimit
{

	// Fields
	private object m_Min; // 0xFFFFFFFFFFFFFFF8
	private object m_Max; // 0x4
	private object m_Center; // 0x10
	private object m_AxisLength; // 0x1C
	private object m_UseDefaultValues; // 0x20
}

// Namespace: UnityEngine
public struct HumanBone
{

	// Fields
	private object m_BoneName; // 0xFFFFFFFFFFFFFFF8
	private object m_HumanName; // 0x0
	public object limit; // 0x8
}

// Namespace: UnityEngine
public struct HumanDescription
{

	// Fields
	public object human; // 0xFFFFFFFFFFFFFFF8
	public object skeleton; // 0x0
	internal object m_ArmTwist; // 0x8
	internal object m_ForeArmTwist; // 0xC
	internal object m_UpperLegTwist; // 0x10
	internal object m_LegTwist; // 0x14
	internal object m_ArmStretch; // 0x18
	internal object m_LegStretch; // 0x1C
	internal object m_FeetSpacing; // 0x20
	internal object m_GlobalScale; // 0x24
	internal object m_RootMotionBoneName; // 0x28
	internal object m_HasTranslationDoF; // 0x30
	internal object m_HasExtraRoot; // 0x31
	internal object m_SkeletonHasParents; // 0x32
}

// Namespace: UnityEngine
public enum AvatarMaskBodyPart
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Root;
	public const object Body;
	public const object Head;
	public const object LeftLeg;
	public const object RightLeg;
	public const object LeftArm;
	public const object RightArm;
	public const object LeftFingers;
	public const object RightFingers;
	public const object LeftFootIK;
	public const object RightFootIK;
	public const object LeftHandIK;
	public const object RightHandIK;
	public const object LastBodyPart;
}

// Namespace: UnityEngine
public sealed class AvatarMask
{

	// Properties
	public object transformCount { get; }

	// Methods

	// RVA: 0x733F16C
	public object .ctor() { }

	// RVA: 0x733F230
	private static object Internal_Create(object self) { }

	// RVA: 0x733F280
	public object GetHumanoidBodyPartActive(object index) { }

	// RVA: 0x733F2E4
	public object get_transformCount() { }

	// RVA: 0x733F334
	public object AddTransformPath(object transform, object recursive) { }

	// RVA: 0x733F3A0
	public object GetTransformPath(object index) { }

	// RVA: 0x733F404
	private object GetTransformWeight(object index) { }

	// RVA: 0x733F468
	private object SetTransformWeight(object index, object weight) { }

	// RVA: 0x733F4E0
	public object GetTransformActive(object index) { }

	// RVA: 0x733F544
	public object SetTransformActive(object index, object value) { }

}

// Namespace: UnityEngine
public class HumanTrait
{

	// Methods

	// RVA: 0x7339528
	internal static object GetBoneIndexFromMono(object humanId) { }

}

// Namespace: UnityEngine
public class Motion
{

	// Fields
	private readonly object <isAnimatorMotion>k__BackingField; // 0x10

	// Properties
	public object isLooping { get; }

	// Methods

	// RVA: 0x7335380
	protected object .ctor() { }

	// RVA: 0x733F5C0
	public object get_isLooping() { }

}

// Namespace: UnityEngine
public class RuntimeAnimatorController
{

	// Properties
	public object animationClips { get; }

	// Methods

	// RVA: 0x733DD3C
	protected object .ctor() { }

	// RVA: 0x733F610
	public object get_animationClips() { }

}

// Namespace: UnityEngine.Animations
public static class AnimationPlayableBinding
{

	// Methods

	// RVA: 0x733F660
	public static object Create(object name, object key) { }

	// RVA: 0x733F798
	private static object CreateAnimationOutput(object graph, object name) { }

}

// Namespace: UnityEngine.Animations
public class DiscreteEvaluationAttribute
{
}

// Namespace: UnityEngine.Animations
public interface IAnimationWindowPreview
{

	// Methods

	// RVA: -1
	public abstract object UpdatePreviewGraph(object graph) { }

}

// Namespace: UnityEngine.Animations
public class NotKeyableAttribute
{
}

// Namespace: UnityEngine.Animations
public struct AnimationAdditiveMixerPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x733F944
	internal object .ctor(object handle) { }

	// RVA: 0x733FA68
	public object GetHandle() { }

	// RVA: 0x733FA80
	public object Equals(object other) { }

	// RVA: 0x733FC20
	private static object .cctor() { }

}

// Namespace: UnityEngine.Animations
public struct AnimationClipPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x733FCC0
	public static object Create(object graph, object clip) { }

	// RVA: 0x733FCFC
	private static object CreateHandle(object graph, object clip) { }

	// RVA: 0x733FDFC
	internal object .ctor(object handle) { }

	// RVA: 0x733FF84
	public object GetHandle() { }

	// RVA: 0x733FF9C
	public static object op_Implicit(object playable) { }

	// RVA: 0x733FFD0
	public static object op_Explicit(object playable) { }

	// RVA: 0x7340058
	public object Equals(object other) { }

	// RVA: 0x7340160
	public object GetAnimationClip() { }

	// RVA: 0x7340250
	public object SetApplyFootIK(object value) { }

	// RVA: 0x734037C
	public object SetCacheDefaultPos(object value) { }

	// RVA: 0x73404A8
	public object SetApplyPlayableIK(object value) { }

	// RVA: 0x73405D4
	internal object SetRemoveStartOffset(object value) { }

	// RVA: 0x7340700
	internal object SetOverrideLoopTime(object value) { }

	// RVA: 0x734082C
	internal object SetLoopTime(object value) { }

	// RVA: 0x733FF18
	private static object CreateHandleInternal(object graph, object clip, object handle) { }

	// RVA: 0x73401B0
	private static object GetAnimationClipInternal(object handle) { }

	// RVA: 0x73402B4
	private static object SetApplyFootIKInternal(object handle, object value) { }

	// RVA: 0x73403E0
	private static object SetCacheDefaultPosInternal(object handle, object value) { }

	// RVA: 0x734050C
	private static object SetApplyPlayableIKInternal(object handle, object value) { }

	// RVA: 0x7340638
	private static object SetRemoveStartOffsetInternal(object handle, object value) { }

	// RVA: 0x7340764
	private static object SetOverrideLoopTimeInternal(object handle, object value) { }

	// RVA: 0x7340890
	private static object SetLoopTimeInternal(object handle, object value) { }

	// RVA: 0x7340958
	private static object CreateHandleInternal_Injected(object graph, object clip, object handle) { }

}

// Namespace: UnityEngine.Animations
public struct AnimationHumanStream
{

	// Fields
	private object stream; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: UnityEngine.Animations
public struct AnimationLayerMixerPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x73409C4
	public static object Create(object graph, object inputCount) { }

	// RVA: 0x7340AC8
	public static object Create(object graph, object inputCount, object singleLayerOptimization) { }

	// RVA: 0x7340B74
	private static object CreateHandle(object graph, object inputCount) { }

	// RVA: 0x7340D24
	internal object .ctor(object handle, object singleLayerOptimization) { }

	// RVA: 0x7340FC0
	public object GetHandle() { }

	// RVA: 0x7340FD8
	public static object op_Implicit(object playable) { }

	// RVA: 0x734105C
	public object Equals(object other) { }

	// RVA: 0x73411FC
	public object SetLayerAdditive(object layerIndex, object value) { }

	// RVA: 0x7341444
	public object SetLayerMaskFromAvatarMask(object layerIndex, object mask) { }

	// RVA: 0x7340EA4
	private static object CreateHandleInternal(object graph, object handle) { }

	// RVA: 0x73413D0
	private static object SetLayerAdditiveInternal(object handle, object layerIndex, object value) { }

	// RVA: 0x7340F54
	private static object SetSingleLayerOptimizationInternal(object handle, object value) { }

	// RVA: 0x7341698
	private static object SetLayerMaskFromAvatarMaskInternal(object handle, object layerIndex, object mask) { }

	// RVA: 0x7341770
	private static object .cctor() { }

	// RVA: 0x734170C
	private static object CreateHandleInternal_Injected(object graph, object handle) { }

}

// Namespace: UnityEngine.Animations
public struct AnimationMixerPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x7341814
	public static object Create(object graph, object inputCount, object normalizeWeights) { }

	// RVA: 0x7341910
	public static object Create(object graph, object inputCount) { }

	// RVA: 0x73419B4
	private static object CreateHandle(object graph, object inputCount) { }

	// RVA: 0x7341B64
	internal object .ctor(object handle) { }

	// RVA: 0x7341D38
	public object GetHandle() { }

	// RVA: 0x7341D50
	public static object op_Implicit(object playable) { }

	// RVA: 0x7341DD4
	public object Equals(object other) { }

	// RVA: 0x7341C80
	private static object CreateHandleInternal(object graph, object handle) { }

	// RVA: 0x7341FD8
	private static object .cctor() { }

	// RVA: 0x7341F74
	private static object CreateHandleInternal_Injected(object graph, object handle) { }

}

// Namespace: UnityEngine.Animations
internal struct AnimationMotionXToDeltaPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x7342078
	public static object Create(object graph) { }

	// RVA: 0x734210C
	private static object CreateHandle(object graph) { }

	// RVA: 0x73422AC
	private object .ctor(object handle) { }

	// RVA: 0x7342480
	public object GetHandle() { }

	// RVA: 0x7342498
	public static object op_Implicit(object playable) { }

	// RVA: 0x734251C
	public object Equals(object other) { }

	// RVA: 0x73426BC
	public object SetAbsoluteMotion(object value) { }

	// RVA: 0x73423C8
	private static object CreateHandleInternal(object graph, object handle) { }

	// RVA: 0x7342774
	private static object SetAbsoluteMotionInternal(object handle, object value) { }

	// RVA: 0x73428F4
	private static object .cctor() { }

	// RVA: 0x7342890
	private static object CreateHandleInternal_Injected(object graph, object handle) { }

}

// Namespace: UnityEngine.Animations
internal struct AnimationOffsetPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x7342994
	public static object Create(object graph, object position, object rotation, object inputCount) { }

	// RVA: 0x7342A90
	private static object CreateHandle(object graph, object position, object rotation, object inputCount) { }

	// RVA: 0x7342C74
	internal object .ctor(object handle) { }

	// RVA: 0x7342E60
	public object GetHandle() { }

	// RVA: 0x7342E78
	public static object op_Implicit(object playable) { }

	// RVA: 0x7342EFC
	public object Equals(object other) { }

	// RVA: 0x7342D90
	private static object CreateHandleInternal(object graph, object position, object rotation, object handle) { }

	// RVA: 0x7343104
	private static object .cctor() { }

	// RVA: 0x7343084
	private static object CreateHandleInternal_Injected(object graph, object position, object rotation, object handle) { }

}

// Namespace: UnityEngine.Animations
public static class AnimationPlayableExtensions
{

	// Methods

	// RVA: -1
	public static object SetAnimatedProperties(object playable, object clip) { }

	// RVA: 0x73431A4
	internal static object SetAnimatedPropertiesInternal(object playable, object animatedProperties) { }

}

// Namespace: UnityEngine.Animations
internal static class AnimationPlayableGraphExtensions
{

	// Methods

	// RVA: 0x7343208
	internal static object InternalCreateAnimationOutput(object graph, object name, object handle) { }

}

// Namespace: UnityEngine.Animations
public struct AnimationPlayableOutput
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public static object Null { get; }

	// Methods

	// RVA: 0x733F7DC
	public static object Create(object graph, object name, object target) { }

	// RVA: 0x73432F4
	internal object .ctor(object handle) { }

	// RVA: 0x7343274
	public static object get_Null() { }

	// RVA: 0x734347C
	public object GetHandle() { }

	// RVA: 0x733F910
	public static object op_Implicit(object output) { }

	// RVA: 0x7343494
	public static object op_Explicit(object output) { }

	// RVA: 0x734351C
	public object GetTarget() { }

	// RVA: 0x7343410
	public object SetTarget(object value) { }

	// RVA: 0x734356C
	private static object InternalGetTarget(object handle) { }

	// RVA: 0x734360C
	private static object InternalSetTarget(object handle, object target) { }

}

// Namespace: UnityEngine.Animations
internal struct AnimationPosePlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x73436D4
	internal object .ctor(object handle) { }

	// RVA: 0x73437F8
	public object GetHandle() { }

	// RVA: 0x7343810
	public object Equals(object other) { }

	// RVA: 0x7343998
	private static object .cctor() { }

}

// Namespace: UnityEngine.Animations
internal struct AnimationRemoveScalePlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x7343A38
	public static object Create(object graph, object inputCount) { }

	// RVA: 0x7343ADC
	private static object CreateHandle(object graph, object inputCount) { }

	// RVA: 0x7343C8C
	internal object .ctor(object handle) { }

	// RVA: 0x7343E60
	public object GetHandle() { }

	// RVA: 0x7343E78
	public static object op_Implicit(object playable) { }

	// RVA: 0x7343EFC
	public object Equals(object other) { }

	// RVA: 0x7343DA8
	private static object CreateHandleInternal(object graph, object handle) { }

	// RVA: 0x73440E8
	private static object .cctor() { }

	// RVA: 0x7344084
	private static object CreateHandleInternal_Injected(object graph, object handle) { }

}

// Namespace: UnityEngine.Animations
public struct AnimationScriptPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x7344188
	internal object .ctor(object handle) { }

	// RVA: 0x73442AC
	public object GetHandle() { }

	// RVA: 0x73442C4
	public object Equals(object other) { }

	// RVA: 0x7344464
	private static object .cctor() { }

}

// Namespace: UnityEngine.Animations
public struct AnimationStream
{

	// Fields
	private object m_AnimatorBindingsVersion; // 0xFFFFFFFFFFFFFFF8
	private object constant; // 0x0
	private object input; // 0x8
	private object output; // 0x10
	private object workspace; // 0x18
	private object inputStreamAccessor; // 0x20
	private object animationHandleBinder; // 0x28
}

// Namespace: UnityEngine.Animations
public struct AnimatorControllerPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8
	private static readonly object m_NullPlayable; // 0x0

	// Methods

	// RVA: 0x7344504
	public static object Create(object graph, object controller) { }

	// RVA: 0x734462C
	private static object CreateHandle(object graph, object controller) { }

	// RVA: 0x73447D4
	internal object .ctor(object handle) { }

	// RVA: 0x7344BD0
	public object GetHandle() { }

	// RVA: 0x7344964
	public object SetHandle(object handle) { }

	// RVA: 0x7344BF0
	public object Equals(object other) { }

	// RVA: 0x73448AC
	private static object CreateHandleInternal(object graph, object controller, object handle) { }

	// RVA: 0x7344DFC
	private static object .cctor() { }

	// RVA: 0x7344D90
	private static object CreateHandleInternal_Injected(object graph, object controller, object handle) { }

}

// Namespace: UnityEngine.Animations
public struct ConstraintSource
{

	// Fields
	private object m_SourceTransform; // 0xFFFFFFFFFFFFFFF8
	private object m_Weight; // 0x0
}

// Namespace: UnityEngine.Animations
public interface IConstraint
{
}

// Namespace: UnityEngine.Animations
internal interface IConstraintInternal
{
}

// Namespace: UnityEngine.Animations
public sealed class LookAtConstraint
{

	// Properties
	public object weight { get; set; }
	public object roll { get; set; }
	public object constraintActive { get; set; }
	public object locked { get; set; }
	public object rotationAtRest { get; set; }
	public object rotationOffset { get; set; }
	public object worldUpObject { get; set; }
	public object useUpObject { get; set; }
	public object sourceCount { get; }

	// Methods

	// RVA: 0x7344F64
	private object .ctor() { }

	// RVA: 0x7344FBC
	private static object Internal_Create(object self) { }

	// RVA: 0x734500C
	public object get_weight() { }

	// RVA: 0x734505C
	public object set_weight(object value) { }

	// RVA: 0x73450C0
	public object get_roll() { }

	// RVA: 0x7345110
	public object set_roll(object value) { }

	// RVA: 0x7345174
	public object get_constraintActive() { }

	// RVA: 0x73451C4
	public object set_constraintActive(object value) { }

	// RVA: 0x7345228
	public object get_locked() { }

	// RVA: 0x7345278
	public object set_locked(object value) { }

	// RVA: 0x73452DC
	public object get_rotationAtRest() { }

	// RVA: 0x73453A4
	public object set_rotationAtRest(object value) { }

	// RVA: 0x734547C
	public object get_rotationOffset() { }

	// RVA: 0x7345544
	public object set_rotationOffset(object value) { }

	// RVA: 0x734561C
	public object get_worldUpObject() { }

	// RVA: 0x734566C
	public object set_worldUpObject(object value) { }

	// RVA: 0x73456D0
	public object get_useUpObject() { }

	// RVA: 0x7345720
	public object set_useUpObject(object value) { }

	// RVA: 0x7345784
	public object get_sourceCount() { }

	// RVA: 0x73457D4
	private static object GetSourceCountInternal(object self) { }

	// RVA: 0x7345824
	public object GetSources(object sources) { }

	// RVA: 0x7345888
	public object SetSources(object sources) { }

	// RVA: 0x7345938
	private static object SetSourcesInternal(object self, object sources) { }

	// RVA: 0x734599C
	public object AddSource(object source) { }

	// RVA: 0x7345A70
	public object RemoveSource(object index) { }

	// RVA: 0x7345C5C
	private object RemoveSourceInternal(object index) { }

	// RVA: 0x7345CC0
	public object GetSource(object index) { }

	// RVA: 0x7345D2C
	private object GetSourceInternal(object index) { }

	// RVA: 0x7345E04
	public object SetSource(object index, object source) { }

	// RVA: 0x7345E74
	private object SetSourceInternal(object index, object source) { }

	// RVA: 0x7345ADC
	private object ValidateSourceIndex(object index) { }

	// RVA: 0x7345340
	private object get_rotationAtRest_Injected(object ret) { }

	// RVA: 0x7345418
	private object set_rotationAtRest_Injected(object value) { }

	// RVA: 0x73454E0
	private object get_rotationOffset_Injected(object ret) { }

	// RVA: 0x73455B8
	private object set_rotationOffset_Injected(object value) { }

	// RVA: 0x7345A0C
	private object AddSource_Injected(object source) { }

	// RVA: 0x7345D98
	private object GetSourceInternal_Injected(object index, object ret) { }

	// RVA: 0x7345EDC
	private object SetSourceInternal_Injected(object index, object source) { }

}

