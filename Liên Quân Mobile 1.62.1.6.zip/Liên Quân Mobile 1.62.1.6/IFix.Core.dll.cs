// Namespace: 
internal class <Module>
{
}

// Namespace: IFix.Core
public class IDTagAttribute
{

	// Fields
	public object ID; // 0x8

	// Methods

	// RVA: 0x3687CA4
	public object .ctor(object id) { }

}

// Namespace: 
private sealed class <readMethod>c__AnonStorey0
{

	// Fields
	internal object genericArgInfos; // 0x8

	// Methods

	// RVA: 0x3688C94
	public object .ctor() { }

	// RVA: 0x368CDA4
	internal object <>m__0(object m) { }

}

// Namespace: 
private sealed class <Load>c__AnonStorey1
{

	// Fields
	internal object nativePointers; // 0x8

	// Methods

	// RVA: 0x368CA94
	public object .ctor() { }

}

// Namespace: 
private sealed class <Load>c__AnonStorey2
{

	// Fields
	internal object wrapperManager; // 0x8
	internal object <>f__ref$1; // 0x10

	// Methods

	// RVA: 0x368CA9C
	public object .ctor() { }

	// RVA: 0x368CE58
	internal object <>m__0() { }

	// RVA: 0x368CF48
	internal object <>m__1() { }

}

// Namespace: IFix.Core
public static class PatchManager
{

	// Fields
	private static object removers; // 0x0
	private static object <>f__am$cache0; // 0x8

	// Methods

	// RVA: 0x3687CD0
	private static object readMethod(object reader, object externTypes) { }

	// RVA: 0x3688C9C
	private static object getMapId(object idMapArray, object method) { }

	// RVA: 0x3689050
	private static object readSlotInfo(object reader, object itfMethodToId, object externTypes, object maxId) { }

	// RVA: 0x368950C
	public static object Load(object stream, object checkNew) { }

	// RVA: 0x368CAC8
	public static object Unload(object assembly) { }

	// RVA: 0x368CCC4
	private static object .cctor() { }

	// RVA: 0x368CD54
	private static object <readMethod>m__0(object p) { }

}

// Namespace: IFix.Core
public enum Code
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Conv_I1;
	public const object Ldelem_I;
	public const object Cgt_Un;
	public const object Mul_Ovf;
	public const object Sizeof;
	public const object Stind_I;
	public const object Ldftn;
	public const object Conv_I8;
	public const object Ldarga;
	public const object Shr_Un;
	public const object Readonly;
	public const object Bgt;
	public const object Callvirtvirt;
	public const object Ldloca;
	public const object Endfilter;
	public const object Ldind_I4;
	public const object Ldind_U2;
	public const object Ble;
	public const object Cpobj;
	public const object Conv_Ovf_I4;
	public const object Shl;
	public const object Neg;
	public const object Constrained;
	public const object Stelem_Any;
	public const object Isinst;
	public const object Stelem_I4;
	public const object Sub_Ovf_Un;
	public const object Ldelem_I1;
	public const object Ldc_I8;
	public const object Conv_Ovf_U4_Un;
	public const object Bgt_Un;
	public const object Ldind_I;
	public const object Initblk;
	public const object Bge_Un;
	public const object Ldflda;
	public const object Conv_U2;
	public const object Stloc;
	public const object Conv_U;
	public const object Mkrefany;
	public const object Ldstr;
	public const object Cgt;
	public const object Stind_I2;
	public const object Conv_I2;
	public const object Bne_Un;
	public const object Stind_I1;
	public const object Call;
	public const object Conv_Ovf_I1_Un;
	public const object Blt;
	public const object Stelem_I8;
	public const object Conv_Ovf_I;
	public const object Conv_Ovf_U;
	public const object Stind_R8;
	public const object Ldelem_R4;
	public const object Ldvirtftn;
	public const object Conv_Ovf_U_Un;
	public const object Conv_Ovf_I8;
	public const object Ldind_I1;
	public const object Conv_Ovf_I4_Un;
	public const object Conv_R4;
	public const object Conv_Ovf_U2;
	public const object Ldsfld;
	public const object Conv_Ovf_U1;
	public const object Starg;
	public const object Conv_Ovf_I2_Un;
	public const object Conv_Ovf_I_Un;
	public const object Rethrow;
	public const object Stelem_I2;
	public const object Newanon;
	public const object Conv_R8;
	public const object Conv_I4;
	public const object Arglist;
	public const object Add_Ovf_Un;
	public const object Ldloc;
	public const object Newobj;
	public const object Ldelem_I2;
	public const object Stfld;
	public const object Not;
	public const object Ldind_Ref;
	public const object Conv_Ovf_U1_Un;
	public const object Or;
	public const object Add;
	public const object Ldind_I2;
	public const object Ldelem_Any;
	public const object Ldind_U4;
	public const object Div;
	public const object Stsfld;
	public const object Ldind_I8;
	public const object Throw;
	public const object Castclass;
	public const object Newarr;
	public const object Xor;
	public const object Mul_Ovf_Un;
	public const object Unaligned;
	public const object Br;
	public const object Ldtype;
	public const object Ldtoken;
	public const object Stobj;
	public const object Ldsflda;
	public const object Ldelem_U2;
	public const object Ldelema;
	public const object Ldc_R8;
	public const object Conv_Ovf_I2;
	public const object Break;
	public const object Nop;
	public const object Cpblk;
	public const object Volatile;
	public const object Refanytype;
	public const object Refanyval;
	public const object Conv_Ovf_U2_Un;
	public const object Clt;
	public const object Beq;
	public const object Blt_Un;
	public const object Conv_Ovf_U4;
	public const object Stelem_I1;
	public const object Tail;
	public const object Stind_I8;
	public const object Clt_Un;
	public const object Ldnull;
	public const object Conv_I;
	public const object Stind_Ref;
	public const object Conv_U8;
	public const object Stelem_R8;
	public const object CallExtern;
	public const object Ldelem_U1;
	public const object Stelem_R4;
	public const object Bge;
	public const object Sub;
	public const object Brtrue;
	public const object Pop;
	public const object Ldelem_Ref;
	public const object Div_Un;
	public const object Conv_U1;
	public const object Ldelem_I8;
	public const object Unbox_Any;
	public const object Brfalse;
	public const object Unbox;
	public const object Add_Ovf;
	public const object Ldind_R4;
	public const object Callvirt;
	public const object Ldlen;
	public const object Conv_U4;
	public const object Ldc_R4;
	public const object No;
	public const object Ldc_I4;
	public const object Dup;
	public const object Conv_Ovf_I8_Un;
	public const object StackSpace;
	public const object Stelem_I;
	public const object And;
	public const object Switch;
	public const object Conv_Ovf_U8_Un;
	public const object Initobj;
	public const object Sub_Ovf;
	public const object Leave;
	public const object Jmp;
	public const object Ldind_R8;
	public const object Ldelem_U4;
	public const object Ckfinite;
	public const object Stind_I4;
	public const object Ldelem_R8;
	public const object Rem;
	public const object Box;
	public const object Ldvirtftn2;
	public const object Conv_Ovf_I1;
	public const object Ldarg;
	public const object Stind_R4;
	public const object Ceq;
	public const object Ldfld;
	public const object Ldind_U1;
	public const object Shr;
	public const object Ldelem_I4;
	public const object Rem_Un;
	public const object Ldobj;
	public const object Ret;
	public const object Conv_R_Un;
	public const object Stelem_Ref;
	public const object Ble_Un;
	public const object Endfinally;
	public const object Conv_Ovf_U8;
	public const object Mul;
	public const object Localloc;
}

// Namespace: IFix.Core
public struct Instruction
{

	// Fields
	public object Code; // 0xFFFFFFFFFFFFFFF8
	public object Operand; // 0xFFFFFFFFFFFFFFFC
}

// Namespace: IFix.Core
public enum ExceptionHandlerType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Catch;
	public const object Filter;
	public const object Finally;
	public const object Fault;
}

// Namespace: IFix.Core
public sealed class ExceptionHandler
{

	// Fields
	public object CatchType; // 0x8
	public object CatchTypeId; // 0x10
	public object HandlerEnd; // 0x14
	public object HandlerStart; // 0x18
	public object HandlerType; // 0x1C
	public object TryEnd; // 0x20
	public object TryStart; // 0x24

	// Methods

	// RVA: 0x368CAA4
	public object .ctor() { }

}

// Namespace: IFix.Core
public class AnonymousStorey
{

	// Fields
	private object unmanagedFields; // 0x8
	private object managedFields; // 0x10
	internal object typeId; // 0x18
	protected object virtualMachine; // 0x20
	private object equalMethodId; // 0x28
	private object finalizeMethodId; // 0x2C
	private object getHashCodeMethodId; // 0x30
	private object toStringMethodId; // 0x34

	// Methods

	// RVA: 0x368D01C
	public object .ctor(object fieldNum, object fieldTypes, object typeID, object vTable, object virtualMachine) { }

	// RVA: 0x368D308
	internal object Ldfld(object fieldIndex, object evaluationStackBase, object evaluationStackPointer, object managedStack) { }

	// RVA: 0x368D430
	internal object Stfld(object fieldIndex, object evaluationStackBase, object evaluationStackPointer, object managedStack) { }

	// RVA: 0x368D540
	internal object Get(object fieldIndex, object type, object virtualMachine, object valueTypeClone) { }

	// RVA: 0x368E3E4
	internal object Set(object fieldIndex, object obj, object type, object virtualMachine) { }

	// RVA: 0x368E7AC
	public object ObjectEquals(object obj) { }

	// RVA: 0x368E7B4
	public override object Equals(object obj) { }

	// RVA: 0x368EAA0
	public object ObjectGetHashCode() { }

	// RVA: 0x368EAA8
	public override object GetHashCode() { }

	// RVA: 0x368EC08
	public object ObjectToString() { }

	// RVA: 0x368EC10
	public override object ToString() { }

	// RVA: 0x368ED64
	protected override object Finalize() { }

}

// Namespace: IFix.Core
public class AnonymousStoreyInfo
{

	// Fields
	public object FieldNum; // 0x8
	public object FieldTypes; // 0x10
	public object CtorId; // 0x18
	public object CtorParamNum; // 0x1C
	public object Slots; // 0x20
	public object VTable; // 0x28

	// Methods

	// RVA: 0x368CAB4
	public object .ctor() { }

}

// Namespace: IFix.Core
public enum ValueType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Integer;
	public const object Long;
	public const object Float;
	public const object Double;
	public const object StackReference;
	public const object StaticFieldReference;
	public const object FieldReference;
	public const object ChainFieldReference;
	public const object Object;
	public const object ValueType;
	public const object ArrayReference;
}

// Namespace: IFix.Core
public struct Value
{

	// Fields
	public object Type; // 0xFFFFFFFFFFFFFFF8
	public object Value1; // 0xFFFFFFFFFFFFFFFC
	public object Value2; // 0x0
}

// Namespace: 
private sealed class <Create>c__AnonStorey0
{

	// Fields
	internal object delegateType; // 0x8

	// Methods

	// RVA: 0x368FF34
	public object .ctor() { }

}

// Namespace: 
private sealed class <Create>c__AnonStorey1
{

	// Fields
	internal object methodInfo; // 0x8
	internal object <>f__ref$0; // 0x10

	// Methods

	// RVA: 0x368FF3C
	public object .ctor() { }

	// RVA: 0x36902CC
	internal object <>m__0(object o) { }

}

// Namespace: 
private sealed class <Create>c__AnonStorey2
{

	// Fields
	internal object methodInfo; // 0x8
	internal object <>f__ref$0; // 0x10

	// Methods

	// RVA: 0x368FF44
	public object .ctor() { }

	// RVA: 0x36902FC
	internal object <>m__0(object o) { }

}

// Namespace: IFix.Core
internal class GenericDelegateFactory
{

	// Fields
	private static object genericAction; // 0x0
	private static object genericFunc; // 0x8
	private static object genericDelegateCreatorCache; // 0x10
	private static object <>f__am$cache0; // 0x18
	private static object <>f__am$cache1; // 0x20
	private static object <>f__am$cache2; // 0x28
	private static object <>f__am$cache3; // 0x30
	private static object <>f__am$cache4; // 0x38
	private static object <>f__am$cache5; // 0x40
	private static object <>f__am$cache6; // 0x48

	// Methods

	// RVA: 0x368EED0
	private static object PreventStripping(object obj) { }

	// RVA: 0x368F248
	internal static object Create(object delegateType, object virtualMachine, object methodId, object anonObj) { }

	// RVA: 0x368FF4C
	private static object .cctor() { }

	// RVA: 0x368FFE8
	private static object <Create>m__0(object m) { }

	// RVA: 0x3690068
	private static object <Create>m__1(object m) { }

	// RVA: 0x36900D4
	private static object <Create>m__2(object m) { }

	// RVA: 0x3690154
	private static object <Create>m__3(object m) { }

	// RVA: 0x36901C0
	private static object <Create>m__4(object p) { }

	// RVA: 0x3690274
	private static object <Create>m__5(object x) { }

	// RVA: 0x369027C
	private static object <Create>m__6(object pinfo) { }

}

// Namespace: IFix.Core
internal class GenericDelegate
{

	// Fields
	private object virtualMachine; // 0x8
	private object methodId; // 0x10
	private object anonObj; // 0x18
	private object pushSelf; // 0x20
	private object extraArgNum; // 0x24

	// Methods

	// RVA: 0x368F0F4
	internal object .ctor(object virtualMachine, object methodId, object anonObj) { }

	// RVA: 0x368F148
	public object Action() { }

	// RVA: -1
	public object Action(object p1) { }

	// RVA: -1
	public object Action(object p1, object p2) { }

	// RVA: -1
	public object Action(object p1, object p2, object p3) { }

	// RVA: -1
	public object Action(object p1, object p2, object p3, object p4) { }

	// RVA: -1
	public object Func() { }

	// RVA: -1
	public object Func(object p1) { }

	// RVA: -1
	public object Func(object p1, object p2) { }

	// RVA: -1
	public object Func(object p1, object p2, object p3) { }

	// RVA: -1
	public object Func(object p1, object p2, object p3, object p4) { }

}

// Namespace: Unity.IL2CPP.CompilerServices
internal enum Option
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NullChecks;
	public const object ArrayBoundsChecks;
	public const object DivideByZeroChecks;
}

// Namespace: Unity.IL2CPP.CompilerServices
internal class Il2CppSetOptionAttribute
{

	// Fields
	private object <Option>k__BackingField; // 0x8
	private object <Value>k__BackingField; // 0x10

	// Properties
	private object Option { set; }
	private object Value { set; }

	// Methods

	// RVA: 0x369032C
	internal object .ctor(object option, object value) { }

	// RVA: 0x3690368
	private object set_Option(object value) { }

	// RVA: 0x3690370
	private object set_Value(object value) { }

}

// Namespace: IFix.Core
public class ObjectClone
{

	// Fields
	private object memberwiseClone; // 0x8

	// Methods

	// RVA: 0x3690378
	public object .ctor() { }

	// RVA: 0x369043C
	public object Clone(object obj) { }

}

// Namespace: IFix.Core
internal class ReflectionMethodInvoker
{

	// Fields
	private object paramCount; // 0x8
	private object hasThis; // 0xC
	private object hasReturn; // 0xD
	private object refFlags; // 0x10
	private object outFlags; // 0x18
	private object rawTypes; // 0x20
	private object method; // 0x28
	private object ctor; // 0x30
	private object returnType; // 0x38
	private object isNullableHasValue; // 0x40
	private object isNullableValue; // 0x41

	// Methods

	// RVA: 0x3690464
	public object .ctor(object method) { }

	// RVA: 0x3690B48
	public object Invoke(object virtualMachine, object call, object isInstantiate) { }

}

// Namespace: IFix.Core
internal struct UnmanagedStack
{

	// Fields
	public object Base; // 0xFFFFFFFFFFFFFFF8
	public object Top; // 0x0
}

// Namespace: IFix.Core
internal class ThreadStackInfo
{

	// Fields
	public object UnmanagedStack; // 0x8
	public object ManagedStack; // 0x10
	private object evaluationStackHandler; // 0x18
	private object unmanagedStackHandler; // 0x20
	private static object localSlot; // 0x0

	// Properties
	internal static object Stack { get; }

	// Methods

	// RVA: 0x369187C
	public object .ctor() { }

	// RVA: 0x3691944
	internal static object get_Stack() { }

	// RVA: 0x3691A80
	private static object .cctor() { }

}

// Namespace: IFix.Core
internal static class EvaluationStackOperation
{

	// Methods

	// RVA: 0x3691AD4
	internal static object UnboxPrimitive(object evaluationStackPointer, object obj, object type) { }

	// RVA: 0x36921E4
	internal static object mGet(object isArray, object root, object layer, object fieldIdList, object fieldInfos, object newFieldInfos) { }

	// RVA: 0x36926A8
	internal static object mSet(object isArray, object root, object val, object layer, object fieldIdList, object fieldInfos, object newFieldInfos) { }

	// RVA: 0x368D590
	internal static object ToObject(object evaluationStackBase, object evaluationStackPointer, object managedStack, object type, object virtualMachine, object valueTypeClone) { }

	// RVA: 0x368E430
	public static object PushObject(object evaluationStackBase, object evaluationStackPointer, object managedStack, object obj, object type) { }

	// RVA: 0x3692F04
	public static object UpdateReference(object evaluationStackBase, object evaluationStackPointer, object managedStack, object obj, object virtualMachine, object type) { }

}

// Namespace: IFix.Core
public struct Call
{

	// Fields
	internal object argumentBase; // 0xFFFFFFFFFFFFFFF8
	internal object evaluationStackBase; // 0x0
	internal object managedStack; // 0x8
	internal object currentTop; // 0x10
	internal object topWriteBack; // 0x18

	// Methods

	// RVA: 0x368E900
	public static object Begin() { }

	// RVA: 0x3693488
	internal static object BeginForStack(object stack) { }

	// RVA: 0x36934D8
	public object PushBoolean(object b) { }

	// RVA: 0x368EA6C
	public object GetBoolean(object offset) { }

	// RVA: 0x369355C
	public object PushByte(object b) { }

	// RVA: 0x36935D4
	public object GetByte(object offset) { }

	// RVA: 0x369362C
	public object PushSByte(object sb) { }

	// RVA: 0x369367C
	public object GetSByte(object offset) { }

	// RVA: 0x36936D4
	public object PushInt16(object s) { }

	// RVA: 0x3693724
	public object GetInt16(object offset) { }

	// RVA: 0x369377C
	public object PushChar(object c) { }

	// RVA: 0x36937CC
	public object GetChar(object offset) { }

	// RVA: 0x3693824
	public object PushUInt16(object us) { }

	// RVA: 0x3693874
	public object GetUInt16(object offset) { }

	// RVA: 0x3693584
	public object PushInt32(object i) { }

	// RVA: 0x368EBDC
	public object GetInt32(object offset) { }

	// RVA: 0x3693920
	public object PushUInt32(object ui) { }

	// RVA: 0x3693970
	public object GetUInt32(object offset) { }

	// RVA: 0x36939C8
	public object PushInt64(object i) { }

	// RVA: 0x3693A28
	public object GetInt64(object offset) { }

	// RVA: 0x3693A80
	public object PushUInt64(object i) { }

	// RVA: 0x3693AE0
	public object GetUInt64(object offset) { }

	// RVA: 0x3693B38
	public object PushSingle(object f) { }

	// RVA: 0x3693B98
	public object GetSingle(object offset) { }

	// RVA: 0x3693BF0
	public object PushDouble(object d) { }

	// RVA: 0x3693C50
	public object GetDouble(object offset) { }

	// RVA: 0x3693CA8
	public object PushIntPtr(object i) { }

	// RVA: 0x3693D58
	public object GetIntPtr(object offset) { }

	// RVA: 0x3693DF0
	public object PushUIntPtr(object i) { }

	// RVA: 0x368E9B4
	public object PushObject(object o) { }

	// RVA: 0x3693EA8
	public object PushValueType(object o) { }

	// RVA: 0x3693F68
	public object GetObject(object offset) { }

	// RVA: -1
	public object GetAsType(object offset) { }

	// RVA: 0x3691598
	public object PushObjectAsResult(object obj, object type) { }

	// RVA: 0x3694120
	public object PushRef(object offset) { }

	// RVA: 0x36914C0
	public object UpdateReference(object offset, object obj, object virtualMachine, object type) { }

}

// Namespace: IFix
public class PatchAttribute
{

	// Methods

	// RVA: 0x36941A0
	public object .ctor() { }

}

// Namespace: IFix.Core
public static class Utils
{

	// Fields
	private static object delegateAdptCache; // 0x0

	// Methods

	// RVA: 0x36941A8
	public static object IsAssignable(object delegateMethod, object method) { }

	// RVA: 0x36944DC
	public static object TryAdapterToDelegate(object obj, object delegateType, object perfix) { }

	// RVA: 0x36947D4
	private static object .cctor() { }

}

// Namespace: IFix.Core
internal class RuntimeException
{

	// Fields
	private object <Real>k__BackingField; // 0x88

	// Properties
	public object Real { get; set; }

	// Methods

	// RVA: 0x3694864
	public object .ctor() { }

	// RVA: 0x36948EC
	public object get_Real() { }

	// RVA: 0x36948F4
	public object set_Real(object value) { }

}

// Namespace: IFix.Core
public sealed class ExternInvoker
{

	// Methods

	// RVA: 0x3694C48
	public object .ctor(object object, object method) { }

	// RVA: 0x3694D54
	public virtual object Invoke(object vm, object call, object isInstantiate) { }

}

// Namespace: IFix.Core
internal class FieldAddr
{

	// Fields
	public object Object; // 0x8
	public object FieldIdList; // 0x10

	// Methods

	// RVA: 0x3694D68
	public object .ctor() { }

}

// Namespace: IFix.Core
public class Cleanner
{

	// Fields
	private static object start; // 0x0

	// Methods

	// RVA: 0x3694D70
	public object .ctor() { }

	// RVA: 0x3694D78
	public static object Start() { }

	// RVA: 0x3694E20
	public static object Stop() { }

	// RVA: 0x3694E9C
	protected override object Finalize() { }

	// RVA: 0x36952D4
	private static object .cctor() { }

}

// Namespace: IFix.Core
public class NewFieldInfo
{

	// Fields
	public object Name; // 0x8
	public object DeclaringType; // 0x10
	public object FieldType; // 0x18
	public object MethodId; // 0x20
	private static readonly object staticObjectKey; // 0x0
	private static readonly object stack; // 0x8
	private static readonly object newFieldValues; // 0x10
	private static readonly object objList; // 0x18

	// Methods

	// RVA: 0x368CAAC
	public object .ctor() { }

	// RVA: 0x3695320
	private object SetDefaultValue(object obj) { }

	// RVA: 0x3695030
	public static object Sweep() { }

	// RVA: 0x3692D7C
	public object CheckInit(object virtualMachine, object obj) { }

	// RVA: 0x36955A0
	public object ObjectToIndex(object obj) { }

	// RVA: 0x36953D0
	public object HasInitialize(object obj) { }

	// RVA: 0x36924BC
	public object GetValue(object obj) { }

	// RVA: 0x3692A98
	public object SetValue(object obj, object value) { }

	// RVA: 0x3695644
	private static object .cctor() { }

}

// Namespace: IFix.Core
public class VirtualMachine
{

	// Fields
	internal object objectClone; // 0x8
	private object unmanagedCodes; // 0x10
	private object exceptionHandlers; // 0x18
	private object onDispose; // 0x20
	private object externInvokers; // 0x28
	private object externMethods; // 0x30
	private object externTypes; // 0x38
	private object internStrings; // 0x40
	internal object fieldInfos; // 0x48
	internal object newFieldInfos; // 0x50
	private object anonymousStoreyInfos; // 0x58
	private object overrideCache; // 0x60
	internal object staticFieldTypes; // 0x68
	internal object staticFields; // 0x70
	private object cctors; // 0x78
	private object wrappersManager; // 0x80
	public static object Info; // 0x0
	private static object <>f__mg$cache0; // 0x8

	// Properties
	public object ExceptionHandlers { set; }
	public object ExternTypes { get; set; }
	public object ExternMethods { set; }
	public object InternStrings { set; }
	public object FieldInfos { set; }
	public object NewFieldInfos { set; }
	public object AnonymousStoreyInfos { set; }
	public object StaticFieldTypes { set; }
	public object Cctors { set; }
	public object WrappersManager { set; }

	// Methods

	// RVA: 0x3678EEC
	internal object .ctor(object unmanaged_codes, object on_dispose) { }

	// RVA: 0x3678FE4
	public object set_ExceptionHandlers(object value) { }

	// RVA: 0x3678FEC
	public object get_ExternTypes() { }

	// RVA: 0x3678FF4
	public object set_ExternTypes(object value) { }

	// RVA: 0x3678FFC
	public object set_ExternMethods(object value) { }

	// RVA: 0x3679070
	public object set_InternStrings(object value) { }

	// RVA: 0x3679078
	public object set_FieldInfos(object value) { }

	// RVA: 0x3679080
	public object set_NewFieldInfos(object value) { }

	// RVA: 0x3679088
	public object set_AnonymousStoreyInfos(object value) { }

	// RVA: 0x3679090
	public object set_StaticFieldTypes(object value) { }

	// RVA: 0x367910C
	public object set_Cctors(object value) { }

	// RVA: 0x3679114
	public object set_WrappersManager(object value) { }

	// RVA: 0x367911C
	protected override object Finalize() { }

	// RVA: 0x3679218
	private object checkCctorExecute(object fieldId, object argumentBase, object managedStack, object evaluationStackBase) { }

	// RVA: 0x36793E8
	private object store(object stackBase, object dst, object src, object managedStack) { }

	// RVA: 0x367953C
	private object copy(object stackBase, object dst, object src, object managedStack) { }

	// RVA: 0x36796B0
	public object Execute(object methodIndex, object call, object argsCount, object refCount) { }

	// RVA: 0x36793B8
	public object Execute(object methodIndex, object argumentBase, object managedStack, object evaluationStackBase, object argsCount) { }

	// RVA: 0x3687000
	private object throwRuntimeException(object e, object bWrap) { }

	// RVA: 0x3687074
	private object getExceptionHandler(object methodIndex, object exceptionType, object pc) { }

	// RVA: 0x368719C
	private object arrayGet(object obj, object idx, object val, object managedStack, object evaluationStackBase) { }

	// RVA: 0x3687658
	private object arraySet(object obj, object idx, object val, object managedStack, object evaluationStackBase) { }

	// RVA: 0x3687B18
	public static object _Info(object a) { }

	// RVA: 0x36796F8
	public object Execute(object pc, object argumentBase, object managedStack, object evaluationStackBase, object argsCount, object methodIndex, object refCount, object topWriteBack) { }

	// RVA: 0x3687BE4
	private static object .cctor() { }

}

// Namespace: IFix.Core
public interface WrappersManager
{

	// Methods

	// RVA: -1
	public abstract object CreateDelegate(object type, object id, object anon) { }

	// RVA: -1
	public abstract object CreateBridge(object fieldNum, object fieldTypes, object typeIndex, object vTable, object slots, object virtualMachine) { }

	// RVA: -1
	public abstract object CreateWrapper(object id) { }

	// RVA: -1
	public abstract object InitWrapperArray(object len) { }

}

