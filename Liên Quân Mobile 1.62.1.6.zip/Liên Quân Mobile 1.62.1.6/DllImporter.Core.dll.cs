// Namespace: 
internal class <Module>
{
}

// Namespace: NucleusDrive.InteropServices.Core
public interface DllApi
{

	// Methods

	// RVA: -1
	public abstract object AddDllDirectory(object newDirectory) { }

	// RVA: -1
	public abstract object FreeLibrary(object hModule) { }

}

// Namespace: NucleusDrive.InteropServices.Core
public class DllInfo
{

	// Fields
	private object <mDllMgr>k__BackingField; // 0x8
	private object <mDllName>k__BackingField; // 0x10
	private object mLibrary; // 0x18
	private object mLoadedProcs; // 0x20

	// Properties
	public object mDllMgr { get; set; }
	public object mDllName { get; set; }

	// Methods

	// RVA: 0x101A638
	public object get_mDllMgr() { }

	// RVA: 0x101A640
	private object set_mDllMgr(object value) { }

	// RVA: 0x101A648
	public object get_mDllName() { }

	// RVA: 0x101A650
	private object set_mDllName(object value) { }

	// RVA: 0x101A658
	public object .ctor(object dllMgr, object dllName) { }

	// RVA: 0x101A858
	public object GetProcInfo(object entryPoint, object callingConvention, object charSet) { }

	// RVA: 0x101AA68
	public object Free() { }

}

// Namespace: NucleusDrive.InteropServices.Core
public class DllMgr
{

	// Fields
	private object <mDllApi>k__BackingField; // 0x8
	private object <mModuleBuilder>k__BackingField; // 0x10
	private object mLoadedDlls; // 0x18

	// Properties
	public object mDllApi { get; set; }
	public object mModuleBuilder { get; set; }

	// Methods

	// RVA: 0x101ACE8
	public object get_mDllApi() { }

	// RVA: 0x101ACF0
	private object set_mDllApi(object value) { }

	// RVA: 0x101ACF8
	public object get_mModuleBuilder() { }

	// RVA: 0x101AD00
	private object set_mModuleBuilder(object value) { }

	// RVA: 0x101AD08
	public object .ctor(object dllApi) { }

	// RVA: 0x101AE40
	public object GetDllInfo(object dllName) { }

	// RVA: 0x101AF30
	public object FreeDll(object dllName) { }

	// RVA: 0x101AFCC
	public object FreeAll() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__16_0; // 0x8
	public static object <>9__17_0; // 0x10

	// Methods

	// RVA: 0x101BDEC
	private static object .cctor() { }

	// RVA: 0x101BE4C
	public object .ctor() { }

	// RVA: 0x101BE54
	internal object <GenUnmanagedDelegateType>b__16_0(object p) { }

	// RVA: 0x101BEA0
	internal object <GenCallerDelegate>b__17_0(object p) { }

}

// Namespace: NucleusDrive.InteropServices.Core
public class ProcInfo
{

	// Fields
	private object mDllInfo; // 0x8
	private object mEntryPoint; // 0x10
	private object mCallingConvention; // 0x18
	private object mCharSet; // 0x1C
	private object mNativeDelegateType; // 0x20
	private object mCallerDelegates; // 0x28
	private object mProcAddress; // 0x30
	private object mNativeDelegate; // 0x38

	// Properties
	private object NativeType { get; }

	// Methods

	// RVA: 0x101B184
	private object get_NativeType() { }

	// RVA: 0x101A9BC
	public object .ctor(object dllInfo, object entryPoint, object callingConvention, object charSet) { }

	// RVA: 0x101B268
	public object GetCaller(object requiredDelegateType) { }

	// RVA: 0x101ACA0
	public object Free() { }

	// RVA: 0x101B4BC
	private static object GenUnmanagedDelegateType(object moduleBuilder, object genTypeName, object sourceMethodInfo, object callingConvention, object charSet) { }

	// RVA: 0x101BB68
	private static object GenCallerDelegate(object procInfo, object requiredDelegateType) { }

}

