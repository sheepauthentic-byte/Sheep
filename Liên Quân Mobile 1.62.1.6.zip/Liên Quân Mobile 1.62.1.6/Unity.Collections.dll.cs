// Namespace: 
internal class <Module>
{
}

// Namespace: Microsoft.CodeAnalysis
internal sealed class EmbeddedAttribute
{

	// Methods

	// RVA: 0x7266F14
	public object .ctor() { }

}

// Namespace: System.Runtime.CompilerServices
internal sealed class IsUnmanagedAttribute
{

	// Methods

	// RVA: 0x7266F1C
	public object .ctor() { }

}

// Namespace: 
public sealed class EarlyInitFunction
{

	// Methods

	// RVA: 0x72671D0
	public object .ctor(object object, object method) { }

	// RVA: 0x7267264
	public virtual object Invoke() { }

}

// Namespace: Unity.Jobs
public class EarlyInitHelpers
{

	// Fields
	private static object s_PendingDelegates; // 0x0

	// Methods

	// RVA: 0x7266F24
	private static object .cctor() { }

	// RVA: 0x7266F28
	public static object FlushEarlyInits() { }

	// RVA: 0x72670F4
	public static object JobReflectionDataCreationFailed(object ex) { }

}

// Namespace: Unity.Jobs
internal class DOTSCompilerGeneratedAttribute
{

	// Methods

	// RVA: 0x7267278
	public object .ctor() { }

}

// Namespace: 
public sealed class TryFunction
{

	// Methods

	// RVA: 0x7267C94
	public object .ctor(object object, object method) { }

	// RVA: 0x7267D2C
	public virtual object Invoke(object allocatorState, object block) { }

}

// Namespace: 
public struct AllocatorHandle
{

	// Fields
	public object Index; // 0xFFFFFFFFFFFFFFF8
	public object Version; // 0xFFFFFFFFFFFFFFFA

	// Properties
	internal object TableEntry { get; }
	public object Value { get; }
	public object Handle { get; }
	public object ToAllocator { get; }

	// Methods

	// RVA: 0x72674B0
	internal object get_TableEntry() { }

	// RVA: 0x7267DDC
	internal object Rewind() { }

	// RVA: 0x72678A0
	public static object op_Implicit(object a) { }

	// RVA: 0x7267DE4
	public object get_Value() { }

	// RVA: 0x7267DF4
	public object Try(object block) { }

	// RVA: 0x72676E8
	public object get_Handle() { }

	// RVA: 0x7267F24
	public object get_ToAllocator() { }

	// RVA: 0x7267F34
	public object Dispose() { }

	// RVA: 0x7267FE0
	public override object Equals(object obj) { }

	// RVA: 0x72680E8
	public object Equals(object other) { }

	// RVA: 0x7268108
	public override object GetHashCode() { }

	// RVA: 0x7268118
	public object CompareTo(object other) { }

}

// Namespace: 
public struct Range
{

	// Fields
	public object Pointer; // 0xFFFFFFFFFFFFFFF8
	public object Items; // 0x0
	public object Allocator; // 0x4

	// Methods

	// RVA: 0x7268130
	public object Dispose() { }

}

// Namespace: 
public struct Block
{

	// Fields
	public object Range; // 0xFFFFFFFFFFFFFFF8
	public object BytesPerItem; // 0x8
	public object AllocatedItems; // 0xC
	public object Log2Alignment; // 0x10
	public object Padding0; // 0x11
	public object Padding1; // 0x12
	public object Padding2; // 0x14

	// Properties
	public object Bytes { get; }
	public object AllocatedBytes { get; }
	public object Alignment { get; set; }

	// Methods

	// RVA: 0x7267880
	public object get_Bytes() { }

	// RVA: 0x72682E0
	public object get_AllocatedBytes() { }

	// RVA: 0x7267890
	public object get_Alignment() { }

	// RVA: 0x7268308
	public object set_Alignment(object value) { }

	// RVA: 0x72681BC
	public object Dispose() { }

	// RVA: 0x7268380
	public object TryFree() { }

}

// Namespace: 
public interface IAllocator
{

	// Properties
	public abstract object Handle { get; }

	// Methods

	// RVA: -1
	public abstract object Try(object block) { }

	// RVA: -1
	public abstract object get_Handle() { }

}

// Namespace: 
internal sealed class Try_000000A7$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x72689F0
	public object .ctor(object , object ) { }

	// RVA: 0x7268A88
	public virtual object Invoke(object allocatorState, object block) { }

}

// Namespace: 
internal static class Try_000000A7$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x7268A9C
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x7268BE0
	private static object GetFunctionPointer() { }

	// RVA: 0x7268C48
	public static object Constructor() { }

	// RVA: 0x7267BA0
	public static object Initialize() { }

	// RVA: 0x7268D10
	private static object .cctor() { }

	// RVA: 0x72687DC
	public static object Invoke(object allocatorState, object block) { }

}

// Namespace: 
internal struct StackAllocator
{

	// Fields
	internal object m_handle; // 0xFFFFFFFFFFFFFFF8
	internal object m_storage; // 0x0
	internal object m_top; // 0x20

	// Properties
	public object Handle { get; }

	// Methods

	// RVA: 0x72686AC
	public object get_Handle() { }

	// RVA: 0x72686BC
	public object Try(object block) { }

	// RVA: 0x72685B8
	public static object Try(object allocatorState, object block) { }

	// RVA: 0x726892C
	public object Dispose() { }

	// RVA: 0x7268934
	internal static object Try$BurstManaged(object allocatorState, object block) { }

}

// Namespace: 
internal sealed class Try_000000B5$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x72697B8
	public object .ctor(object , object ) { }

	// RVA: 0x7269850
	public virtual object Invoke(object allocatorState, object block) { }

}

// Namespace: 
internal static class Try_000000B5$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x7269864
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x72699A8
	private static object GetFunctionPointer() { }

	// RVA: 0x7269A10
	public static object Constructor() { }

	// RVA: 0x7267BFC
	public static object Initialize() { }

	// RVA: 0x7269AD8
	private static object .cctor() { }

	// RVA: 0x72695A4
	public static object Invoke(object allocatorState, object block) { }

}

// Namespace: 
internal struct SlabAllocator
{

	// Fields
	internal object m_handle; // 0xFFFFFFFFFFFFFFF8
	internal object Storage; // 0x0
	internal object Log2SlabSizeInBytes; // 0x20
	internal object Occupied; // 0x28
	internal object budgetInBytes; // 0x1028
	internal object allocatedBytes; // 0x1030

	// Properties
	public object Handle { get; }
	internal object SlabSizeInBytes { get; }

	// Methods

	// RVA: 0x7268EA8
	public object get_Handle() { }

	// RVA: 0x7268EB8
	internal object get_SlabSizeInBytes() { }

	// RVA: 0x7268ED8
	public object Try(object block) { }

	// RVA: 0x7268DB4
	public static object Try(object allocatorState, object block) { }

	// RVA: 0x72696F4
	public object Dispose() { }

	// RVA: 0x72696FC
	internal static object Try$BurstManaged(object allocatorState, object block) { }

}

// Namespace: 
internal struct TableEntry
{

	// Fields
	internal object function; // 0xFFFFFFFFFFFFFFF8
	internal object state; // 0x0
}

// Namespace: 
internal struct Array16<T0>
{

	// Fields
	internal object f0; // 0x0
	internal object f1; // 0x0
	internal object f2; // 0x0
	internal object f3; // 0x0
	internal object f4; // 0x0
	internal object f5; // 0x0
	internal object f6; // 0x0
	internal object f7; // 0x0
	internal object f8; // 0x0
	internal object f9; // 0x0
	internal object f10; // 0x0
	internal object f11; // 0x0
	internal object f12; // 0x0
	internal object f13; // 0x0
	internal object f14; // 0x0
	internal object f15; // 0x0
}

// Namespace: 
internal struct Array256<T0>
{

	// Fields
	internal object f0; // 0x0
	internal object f1; // 0x0
	internal object f2; // 0x0
	internal object f3; // 0x0
	internal object f4; // 0x0
	internal object f5; // 0x0
	internal object f6; // 0x0
	internal object f7; // 0x0
	internal object f8; // 0x0
	internal object f9; // 0x0
	internal object f10; // 0x0
	internal object f11; // 0x0
	internal object f12; // 0x0
	internal object f13; // 0x0
	internal object f14; // 0x0
	internal object f15; // 0x0
}

// Namespace: 
internal struct Array4096<T0>
{

	// Fields
	internal object f0; // 0x0
	internal object f1; // 0x0
	internal object f2; // 0x0
	internal object f3; // 0x0
	internal object f4; // 0x0
	internal object f5; // 0x0
	internal object f6; // 0x0
	internal object f7; // 0x0
	internal object f8; // 0x0
	internal object f9; // 0x0
	internal object f10; // 0x0
	internal object f11; // 0x0
	internal object f12; // 0x0
	internal object f13; // 0x0
	internal object f14; // 0x0
	internal object f15; // 0x0
}

// Namespace: 
internal struct Array32768<T0>
{

	// Fields
	internal object f0; // 0x0
	internal object f1; // 0x0
	internal object f2; // 0x0
	internal object f3; // 0x0
	internal object f4; // 0x0
	internal object f5; // 0x0
	internal object f6; // 0x0
	internal object f7; // 0x0

	// Properties
	public object Length { get; }

	// Methods

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object ElementAt(object index) { }

}

// Namespace: 
internal sealed class TableEntry
{

	// Fields
	internal static readonly object Ref; // 0x0

	// Methods

	// RVA: 0x7269ADC
	private static object .cctor() { }

}

// Namespace: 
internal sealed class SharedStatics
{
}

// Namespace: 
internal static class Managed
{

	// Fields
	internal static object TryFunctionDelegates; // 0x0

	// Methods

	// RVA: 0x7269B64
	private static object .cctor() { }

}

// Namespace: Unity.Collections
public static class AllocatorManager
{

	// Fields
	public static readonly object Invalid; // 0x0
	public static readonly object None; // 0x4
	public static readonly object Temp; // 0x8
	public static readonly object TempJob; // 0xC
	public static readonly object Persistent; // 0x10
	public static readonly object AudioKernel; // 0x14
	internal static readonly object NumGlobalScratchAllocators; // 0x18
	internal static readonly object MaxNumGlobalAllocators; // 0x1A
	internal static readonly object GlobalAllocatorBaseIndex; // 0x1C
	internal static readonly object FirstGlobalScratchpadAllocatorIndex; // 0x20

	// Methods

	// RVA: -1
	internal static object AllocateBlock(object t, object sizeOf, object alignOf, object items) { }

	// RVA: -1
	public static object Allocate(object t, object sizeOf, object alignOf, object items) { }

	// RVA: -1
	internal static object Allocate(object t, object u, object items) { }

	// RVA: -1
	internal static object FreeBlock(object t, object block) { }

	// RVA: -1
	internal static object Free(object t, object pointer, object sizeOf, object alignOf, object items) { }

	// RVA: -1
	internal static object Free(object t, object pointer, object items) { }

	// RVA: 0x7267280
	public static object Free(object handle, object pointer) { }

	// RVA: -1
	public static object Free(object handle, object pointer, object items) { }

	// RVA: 0x7267310
	private static object CheckDelegate(object useDelegate) { }

	// RVA: 0x726731C
	private static object UseDelegate() { }

	// RVA: 0x726738C
	private static object allocate_block(object block) { }

	// RVA: 0x726754C
	private static object forward_mono_allocate_block(object block, object error) { }

	// RVA: 0x72676F0
	internal static object LegacyOf(object handle) { }

	// RVA: 0x7267704
	private static object TryLegacy(object block) { }

	// RVA: 0x72678E4
	public static object Try(object block) { }

	// RVA: 0x7267A84
	private static object .cctor() { }

	// RVA: 0x7267B48
	public static object Initialize$StackAllocator_Try_000000A7$BurstDirectCall() { }

	// RVA: 0x7267BA4
	public static object Initialize$SlabAllocator_Try_000000B5$BurstDirectCall() { }

}

// Namespace: Unity.Collections
internal struct ArrayOfArrays<T0>
{

	// Fields
	private object m_backingAllocatorHandle; // 0x0
	private object m_lengthInElements; // 0x0
	private object m_capacityInElements; // 0x0
	private object m_log2BlockSizeInElements; // 0x0
	private object m_blocks; // 0x0
	private object m_block; // 0x0

	// Properties
	private object BlockSizeInElements { get; }
	private object BlockSizeInBytes { get; }
	private object BlockMask { get; }
	public object Length { get; }
	public object Item { get; }

	// Methods

	// RVA: -1
	private object get_BlockSizeInElements() { }

	// RVA: -1
	private object get_BlockSizeInBytes() { }

	// RVA: -1
	private object get_BlockMask() { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object LockfreeAdd(object t) { }

	// RVA: -1
	public object get_Item(object elementIndex) { }

	// RVA: -1
	public object Rewind() { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object RemoveAtSwapBack(object elementIndex) { }

	// RVA: -1
	private object BlockIndexOfElement(object elementIndex) { }

	// RVA: -1
	public object TrimExcess() { }

}

// Namespace: Unity.Collections
internal sealed class Try_000000DF$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x726A3E0
	public object .ctor(object , object ) { }

	// RVA: 0x726A478
	public virtual object Invoke(object state, object block) { }

}

// Namespace: Unity.Collections
internal static class Try_000000DF$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x726A48C
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x726A5D0
	private static object GetFunctionPointer() { }

	// RVA: 0x726A638
	public static object Constructor() { }

	// RVA: 0x726A700
	public static object Initialize() { }

	// RVA: 0x726A704
	private static object .cctor() { }

	// RVA: 0x726A1C4
	public static object Invoke(object state, object block) { }

}

// Namespace: Unity.Collections
internal struct AutoFreeAllocator
{

	// Fields
	private object m_allocated; // 0xFFFFFFFFFFFFFFF8
	private object m_tofree; // 0x18
	private object m_handle; // 0x38
	private object m_backingAllocatorHandle; // 0x3C

	// Properties
	public object Handle { get; }

	// Methods

	// RVA: 0x7269D6C
	public object Update() { }

	// RVA: 0x7269EE8
	public object FreeAll() { }

	// RVA: 0x7269FCC
	public object Dispose() { }

	// RVA: 0x726A09C
	public object Try(object block) { }

	// RVA: 0x7269C78
	internal static object Try(object state, object block) { }

	// RVA: 0x726A314
	public object get_Handle() { }

	// RVA: 0x726A324
	internal static object Try$BurstManaged(object state, object block) { }

}

// Namespace: 
public struct DummyJob
{

	// Methods

	// RVA: 0x726A794
	public object Execute() { }

}

// Namespace: Unity.Collections
public static class CollectionHelper
{

	// Methods

	// RVA: 0x726A708
	public static object Log2Floor(object value) { }

	// RVA: 0x726A740
	public static object Hash(object ptr, object bytes) { }

	// RVA: 0x726A784
	internal static object ShouldDeallocate(object allocator) { }

	// RVA: 0x726A790
	internal static object AssumePositive(object value) { }

}

// Namespace: Unity.Collections
internal struct FixedList
{

	// Methods

	// RVA: -1
	internal static object PaddingBytes() { }

}

// Namespace: Unity.Collections
public struct FixedList32Bytes<T0>
{

	// Fields
	internal object data; // 0x0

	// Properties
	internal object length { get; }
	internal object buffer { get; }
	public object Length { get; }
	internal object LengthInBytes { get; }
	internal object Buffer { get; }

	// Methods

	// RVA: -1
	internal object get_length() { }

	// RVA: -1
	internal object get_buffer() { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	internal object get_LengthInBytes() { }

	// RVA: -1
	internal object get_Buffer() { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

}

// Namespace: Unity.Collections
internal sealed class FixedList32BytesDebugView<T0>
{
}

// Namespace: Unity.Collections
public struct FixedList64Bytes<T0>
{

	// Fields
	internal object data; // 0x0

	// Properties
	internal object length { get; }
	internal object buffer { get; }
	public object Length { get; }
	internal object LengthInBytes { get; }
	internal object Buffer { get; }

	// Methods

	// RVA: -1
	internal object get_length() { }

	// RVA: -1
	internal object get_buffer() { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	internal object get_LengthInBytes() { }

	// RVA: -1
	internal object get_Buffer() { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

}

// Namespace: Unity.Collections
internal sealed class FixedList64BytesDebugView<T0>
{
}

// Namespace: Unity.Collections
public struct FixedList128Bytes<T0>
{

	// Fields
	internal object data; // 0x0

	// Properties
	internal object length { get; }
	internal object buffer { get; }
	public object Length { get; }
	internal object LengthInBytes { get; }
	internal object Buffer { get; }

	// Methods

	// RVA: -1
	internal object get_length() { }

	// RVA: -1
	internal object get_buffer() { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	internal object get_LengthInBytes() { }

	// RVA: -1
	internal object get_Buffer() { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

}

// Namespace: Unity.Collections
internal sealed class FixedList128BytesDebugView<T0>
{
}

// Namespace: Unity.Collections
public struct FixedList512Bytes<T0>
{

	// Fields
	internal object data; // 0x0

	// Properties
	internal object length { get; }
	internal object buffer { get; }
	public object Length { get; }
	internal object LengthInBytes { get; }
	internal object Buffer { get; }

	// Methods

	// RVA: -1
	internal object get_length() { }

	// RVA: -1
	internal object get_buffer() { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	internal object get_LengthInBytes() { }

	// RVA: -1
	internal object get_Buffer() { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

}

// Namespace: Unity.Collections
internal sealed class FixedList512BytesDebugView<T0>
{
}

// Namespace: Unity.Collections
public struct FixedList4096Bytes<T0>
{

	// Fields
	internal object data; // 0x0

	// Properties
	internal object length { get; }
	internal object buffer { get; }
	public object Length { get; }
	internal object LengthInBytes { get; }
	internal object Buffer { get; }
	public object Item { get; set; }

	// Methods

	// RVA: -1
	internal object get_length() { }

	// RVA: -1
	internal object get_buffer() { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	internal object get_LengthInBytes() { }

	// RVA: -1
	internal object get_Buffer() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public object CompareTo(object other) { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

}

// Namespace: Unity.Collections
internal sealed class FixedList4096BytesDebugView<T0>
{
}

// Namespace: Unity.Collections
internal struct FixedBytes16Align8
{

	// Fields
	public object byte0000; // 0xFFFFFFFFFFFFFFF8
	public object byte0008; // 0x0
}

// Namespace: Unity.Collections
internal struct FixedBytes32Align8
{

	// Fields
	internal object offset0000; // 0xFFFFFFFFFFFFFFF8
	internal object offset0016; // 0x8
}

// Namespace: Unity.Collections
internal struct FixedBytes64Align8
{

	// Fields
	internal object offset0000; // 0xFFFFFFFFFFFFFFF8
	internal object offset0016; // 0x8
	internal object offset0032; // 0x18
	internal object offset0048; // 0x28
}

// Namespace: Unity.Collections
internal struct FixedBytes128Align8
{

	// Fields
	internal object offset0000; // 0xFFFFFFFFFFFFFFF8
	internal object offset0016; // 0x8
	internal object offset0032; // 0x18
	internal object offset0048; // 0x28
	internal object offset0064; // 0x38
	internal object offset0080; // 0x48
	internal object offset0096; // 0x58
	internal object offset0112; // 0x68
}

// Namespace: Unity.Collections
internal struct FixedBytes512Align8
{

	// Fields
	internal object offset0000; // 0xFFFFFFFFFFFFFFF8
	internal object offset0016; // 0x8
	internal object offset0032; // 0x18
	internal object offset0048; // 0x28
	internal object offset0064; // 0x38
	internal object offset0080; // 0x48
	internal object offset0096; // 0x58
	internal object offset0112; // 0x68
	internal object offset0128; // 0x78
	internal object offset0144; // 0x88
	internal object offset0160; // 0x98
	internal object offset0176; // 0xA8
	internal object offset0192; // 0xB8
	internal object offset0208; // 0xC8
	internal object offset0224; // 0xD8
	internal object offset0240; // 0xE8
	internal object offset0256; // 0xF8
	internal object offset0272; // 0x108
	internal object offset0288; // 0x118
	internal object offset0304; // 0x128
	internal object offset0320; // 0x138
	internal object offset0336; // 0x148
	internal object offset0352; // 0x158
	internal object offset0368; // 0x168
	internal object offset0384; // 0x178
	internal object offset0400; // 0x188
	internal object offset0416; // 0x198
	internal object offset0432; // 0x1A8
	internal object offset0448; // 0x1B8
	internal object offset0464; // 0x1C8
	internal object offset0480; // 0x1D8
	internal object offset0496; // 0x1E8
}

// Namespace: Unity.Collections
internal struct FixedBytes4096Align8
{

	// Fields
	internal object offset0000; // 0xFFFFFFFFFFFFFFF8
	internal object offset0016; // 0x8
	internal object offset0032; // 0x18
	internal object offset0048; // 0x28
	internal object offset0064; // 0x38
	internal object offset0080; // 0x48
	internal object offset0096; // 0x58
	internal object offset0112; // 0x68
	internal object offset0128; // 0x78
	internal object offset0144; // 0x88
	internal object offset0160; // 0x98
	internal object offset0176; // 0xA8
	internal object offset0192; // 0xB8
	internal object offset0208; // 0xC8
	internal object offset0224; // 0xD8
	internal object offset0240; // 0xE8
	internal object offset0256; // 0xF8
	internal object offset0272; // 0x108
	internal object offset0288; // 0x118
	internal object offset0304; // 0x128
	internal object offset0320; // 0x138
	internal object offset0336; // 0x148
	internal object offset0352; // 0x158
	internal object offset0368; // 0x168
	internal object offset0384; // 0x178
	internal object offset0400; // 0x188
	internal object offset0416; // 0x198
	internal object offset0432; // 0x1A8
	internal object offset0448; // 0x1B8
	internal object offset0464; // 0x1C8
	internal object offset0480; // 0x1D8
	internal object offset0496; // 0x1E8
	internal object offset0512; // 0x1F8
	internal object offset0528; // 0x208
	internal object offset0544; // 0x218
	internal object offset0560; // 0x228
	internal object offset0576; // 0x238
	internal object offset0592; // 0x248
	internal object offset0608; // 0x258
	internal object offset0624; // 0x268
	internal object offset0640; // 0x278
	internal object offset0656; // 0x288
	internal object offset0672; // 0x298
	internal object offset0688; // 0x2A8
	internal object offset0704; // 0x2B8
	internal object offset0720; // 0x2C8
	internal object offset0736; // 0x2D8
	internal object offset0752; // 0x2E8
	internal object offset0768; // 0x2F8
	internal object offset0784; // 0x308
	internal object offset0800; // 0x318
	internal object offset0816; // 0x328
	internal object offset0832; // 0x338
	internal object offset0848; // 0x348
	internal object offset0864; // 0x358
	internal object offset0880; // 0x368
	internal object offset0896; // 0x378
	internal object offset0912; // 0x388
	internal object offset0928; // 0x398
	internal object offset0944; // 0x3A8
	internal object offset0960; // 0x3B8
	internal object offset0976; // 0x3C8
	internal object offset0992; // 0x3D8
	internal object offset1008; // 0x3E8
	internal object offset1024; // 0x3F8
	internal object offset1040; // 0x408
	internal object offset1056; // 0x418
	internal object offset1072; // 0x428
	internal object offset1088; // 0x438
	internal object offset1104; // 0x448
	internal object offset1120; // 0x458
	internal object offset1136; // 0x468
	internal object offset1152; // 0x478
	internal object offset1168; // 0x488
	internal object offset1184; // 0x498
	internal object offset1200; // 0x4A8
	internal object offset1216; // 0x4B8
	internal object offset1232; // 0x4C8
	internal object offset1248; // 0x4D8
	internal object offset1264; // 0x4E8
	internal object offset1280; // 0x4F8
	internal object offset1296; // 0x508
	internal object offset1312; // 0x518
	internal object offset1328; // 0x528
	internal object offset1344; // 0x538
	internal object offset1360; // 0x548
	internal object offset1376; // 0x558
	internal object offset1392; // 0x568
	internal object offset1408; // 0x578
	internal object offset1424; // 0x588
	internal object offset1440; // 0x598
	internal object offset1456; // 0x5A8
	internal object offset1472; // 0x5B8
	internal object offset1488; // 0x5C8
	internal object offset1504; // 0x5D8
	internal object offset1520; // 0x5E8
	internal object offset1536; // 0x5F8
	internal object offset1552; // 0x608
	internal object offset1568; // 0x618
	internal object offset1584; // 0x628
	internal object offset1600; // 0x638
	internal object offset1616; // 0x648
	internal object offset1632; // 0x658
	internal object offset1648; // 0x668
	internal object offset1664; // 0x678
	internal object offset1680; // 0x688
	internal object offset1696; // 0x698
	internal object offset1712; // 0x6A8
	internal object offset1728; // 0x6B8
	internal object offset1744; // 0x6C8
	internal object offset1760; // 0x6D8
	internal object offset1776; // 0x6E8
	internal object offset1792; // 0x6F8
	internal object offset1808; // 0x708
	internal object offset1824; // 0x718
	internal object offset1840; // 0x728
	internal object offset1856; // 0x738
	internal object offset1872; // 0x748
	internal object offset1888; // 0x758
	internal object offset1904; // 0x768
	internal object offset1920; // 0x778
	internal object offset1936; // 0x788
	internal object offset1952; // 0x798
	internal object offset1968; // 0x7A8
	internal object offset1984; // 0x7B8
	internal object offset2000; // 0x7C8
	internal object offset2016; // 0x7D8
	internal object offset2032; // 0x7E8
	internal object offset2048; // 0x7F8
	internal object offset2064; // 0x808
	internal object offset2080; // 0x818
	internal object offset2096; // 0x828
	internal object offset2112; // 0x838
	internal object offset2128; // 0x848
	internal object offset2144; // 0x858
	internal object offset2160; // 0x868
	internal object offset2176; // 0x878
	internal object offset2192; // 0x888
	internal object offset2208; // 0x898
	internal object offset2224; // 0x8A8
	internal object offset2240; // 0x8B8
	internal object offset2256; // 0x8C8
	internal object offset2272; // 0x8D8
	internal object offset2288; // 0x8E8
	internal object offset2304; // 0x8F8
	internal object offset2320; // 0x908
	internal object offset2336; // 0x918
	internal object offset2352; // 0x928
	internal object offset2368; // 0x938
	internal object offset2384; // 0x948
	internal object offset2400; // 0x958
	internal object offset2416; // 0x968
	internal object offset2432; // 0x978
	internal object offset2448; // 0x988
	internal object offset2464; // 0x998
	internal object offset2480; // 0x9A8
	internal object offset2496; // 0x9B8
	internal object offset2512; // 0x9C8
	internal object offset2528; // 0x9D8
	internal object offset2544; // 0x9E8
	internal object offset2560; // 0x9F8
	internal object offset2576; // 0xA08
	internal object offset2592; // 0xA18
	internal object offset2608; // 0xA28
	internal object offset2624; // 0xA38
	internal object offset2640; // 0xA48
	internal object offset2656; // 0xA58
	internal object offset2672; // 0xA68
	internal object offset2688; // 0xA78
	internal object offset2704; // 0xA88
	internal object offset2720; // 0xA98
	internal object offset2736; // 0xAA8
	internal object offset2752; // 0xAB8
	internal object offset2768; // 0xAC8
	internal object offset2784; // 0xAD8
	internal object offset2800; // 0xAE8
	internal object offset2816; // 0xAF8
	internal object offset2832; // 0xB08
	internal object offset2848; // 0xB18
	internal object offset2864; // 0xB28
	internal object offset2880; // 0xB38
	internal object offset2896; // 0xB48
	internal object offset2912; // 0xB58
	internal object offset2928; // 0xB68
	internal object offset2944; // 0xB78
	internal object offset2960; // 0xB88
	internal object offset2976; // 0xB98
	internal object offset2992; // 0xBA8
	internal object offset3008; // 0xBB8
	internal object offset3024; // 0xBC8
	internal object offset3040; // 0xBD8
	internal object offset3056; // 0xBE8
	internal object offset3072; // 0xBF8
	internal object offset3088; // 0xC08
	internal object offset3104; // 0xC18
	internal object offset3120; // 0xC28
	internal object offset3136; // 0xC38
	internal object offset3152; // 0xC48
	internal object offset3168; // 0xC58
	internal object offset3184; // 0xC68
	internal object offset3200; // 0xC78
	internal object offset3216; // 0xC88
	internal object offset3232; // 0xC98
	internal object offset3248; // 0xCA8
	internal object offset3264; // 0xCB8
	internal object offset3280; // 0xCC8
	internal object offset3296; // 0xCD8
	internal object offset3312; // 0xCE8
	internal object offset3328; // 0xCF8
	internal object offset3344; // 0xD08
	internal object offset3360; // 0xD18
	internal object offset3376; // 0xD28
	internal object offset3392; // 0xD38
	internal object offset3408; // 0xD48
	internal object offset3424; // 0xD58
	internal object offset3440; // 0xD68
	internal object offset3456; // 0xD78
	internal object offset3472; // 0xD88
	internal object offset3488; // 0xD98
	internal object offset3504; // 0xDA8
	internal object offset3520; // 0xDB8
	internal object offset3536; // 0xDC8
	internal object offset3552; // 0xDD8
	internal object offset3568; // 0xDE8
	internal object offset3584; // 0xDF8
	internal object offset3600; // 0xE08
	internal object offset3616; // 0xE18
	internal object offset3632; // 0xE28
	internal object offset3648; // 0xE38
	internal object offset3664; // 0xE48
	internal object offset3680; // 0xE58
	internal object offset3696; // 0xE68
	internal object offset3712; // 0xE78
	internal object offset3728; // 0xE88
	internal object offset3744; // 0xE98
	internal object offset3760; // 0xEA8
	internal object offset3776; // 0xEB8
	internal object offset3792; // 0xEC8
	internal object offset3808; // 0xED8
	internal object offset3824; // 0xEE8
	internal object offset3840; // 0xEF8
	internal object offset3856; // 0xF08
	internal object offset3872; // 0xF18
	internal object offset3888; // 0xF28
	internal object offset3904; // 0xF38
	internal object offset3920; // 0xF48
	internal object offset3936; // 0xF58
	internal object offset3952; // 0xF68
	internal object offset3968; // 0xF78
	internal object offset3984; // 0xF88
	internal object offset4000; // 0xF98
	internal object offset4016; // 0xFA8
	internal object offset4032; // 0xFB8
	internal object offset4048; // 0xFC8
	internal object offset4064; // 0xFD8
	internal object offset4080; // 0xFE8
}

// Namespace: Unity.Collections
public static class FixedStringMethods
{

	// Methods

	// RVA: -1
	public static object ConvertToString(object fs) { }

}

// Namespace: Unity.Collections
public interface IUTF8Bytes
{

	// Methods

	// RVA: -1
	public abstract object GetUnsafePtr() { }

}

// Namespace: Unity.Collections
public class GenerateTestsForBurstCompatibilityAttribute
{

	// Fields
	private object <GenericTypeArguments>k__BackingField; // 0x8

	// Properties
	public object GenericTypeArguments { set; }

	// Methods

	// RVA: 0x726A79C
	public object set_GenericTypeArguments(object value) { }

	// RVA: 0x726A7A4
	public object .ctor() { }

}

// Namespace: Unity.Collections
public class ExcludeFromBurstCompatTestingAttribute
{

	// Fields
	private object <Reason>k__BackingField; // 0x8

	// Properties
	public object Reason { set; }

	// Methods

	// RVA: 0x726A7AC
	public object set_Reason(object value) { }

	// RVA: 0x726A7B4
	public object .ctor(object _reason) { }

}

// Namespace: 
internal struct Array
{

	// Methods

	// RVA: 0x726A950
	private static object IsCustom(object allocator) { }

	// RVA: 0x726A95C
	private static object CustomResize(object oldPointer, object oldCount, object newCount, object allocator, object size, object align) { }

	// RVA: 0x726A7E0
	internal static object Resize(object oldPointer, object oldCount, object newCount, object allocator, object size, object align) { }

	// RVA: -1
	internal static object Resize(object oldPointer, object oldCount, object newCount, object allocator) { }

}

// Namespace: 
internal struct Unmanaged
{

	// Methods

	// RVA: 0x72678A8
	internal static object Allocate(object size, object align, object allocator) { }

	// RVA: 0x72678C4
	internal static object Free(object pointer, object allocator) { }

	// RVA: -1
	internal static object Free(object pointer, object allocator) { }

}

// Namespace: Unity.Collections
internal struct Memory
{
}

// Namespace: Unity.Collections
internal struct NativeBitArrayDispose
{

	// Fields
	public object m_BitArrayData; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AA50
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeBitArrayDisposeJob
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AB88
	public object Execute() { }

}

// Namespace: Unity.Collections
internal struct NativeHashMapDispose
{

	// Fields
	internal object m_HashMapData; // 0xFFFFFFFFFFFFFFF8
	internal object m_Allocator; // 0x0

	// Methods

	// RVA: 0x726AB98
	internal object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeHashMapDisposeJob
{

	// Fields
	internal object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AC40
	public object Execute() { }

}

// Namespace: Unity.Collections
public struct KVPair<T0, T1>
{

	// Fields
	internal object m_Data; // 0x0
	internal object m_Index; // 0x0
	internal object m_Next; // 0x0
}

// Namespace: Unity.Collections
public interface IIndexable<T0>
{

	// Properties
	public abstract object Length { get; }

	// Methods

	// RVA: -1
	public abstract object get_Length() { }

}

// Namespace: Unity.Collections
public interface INativeList<T0>
{
}

// Namespace: Unity.Collections
public struct NativeList<T0>
{

	// Fields
	internal object m_ListData; // 0x0

	// Properties
	public object Item { get; set; }
	public object Length { get; }
	public object IsCreated { get; }

	// Methods

	// RVA: -1
	public object .ctor(object allocator) { }

	// RVA: -1
	public object .ctor(object initialCapacity, object allocator) { }

	// RVA: -1
	internal object Initialize(object initialCapacity, object allocator) { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object Add(object value) { }

	// RVA: -1
	public object AddRange(object array) { }

	// RVA: -1
	public object AddRange(object ptr, object count) { }

	// RVA: -1
	public object RemoveAtSwapBack(object index) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	public object get_IsCreated() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public static object op_Implicit(object nativeList) { }

	// RVA: -1
	public object AsArray() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

}

// Namespace: Unity.Collections
internal struct NativeListDispose
{

	// Fields
	public object m_ListData; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AC9C
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeListDisposeJob
{

	// Fields
	internal object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AD44
	public object Execute() { }

}

// Namespace: Unity.Collections
internal sealed class NativeListDebugView<T0>
{
}

// Namespace: Unity.Collections
internal struct NativeQueueDispose
{

	// Fields
	public object m_QueueData; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726ADA0
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeQueueDisposeJob
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AE48
	public object Execute() { }

}

// Namespace: Unity.Collections
internal struct NativeReferenceDispose
{

	// Fields
	internal object m_Data; // 0xFFFFFFFFFFFFFFF8
	internal object m_AllocatorLabel; // 0x0

	// Methods

	// RVA: 0x726AEA4
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeReferenceDisposeJob
{

	// Fields
	internal object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AEF4
	public object Execute() { }

}

// Namespace: Unity.Collections
internal struct NativeRingQueueDispose
{

	// Fields
	public object m_QueueData; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AF24
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeRingQueueDisposeJob
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726AFCC
	public object Execute() { }

}

// Namespace: 
public struct DefaultComparer<T0>
{

	// Methods

	// RVA: -1
	public object Compare(object x, object y) { }

}

// Namespace: Unity.Collections
public static class NativeSortExtension
{

	// Methods

	// RVA: -1
	public static object Sort(object slice) { }

	// RVA: -1
	public static object Sort(object slice, object comp) { }

	// RVA: -1
	private static object IntroSortStruct(object array, object length, object comp) { }

	// RVA: -1
	private static object IntroSortStruct_R(object array, object lo, object _hi, object depth, object comp) { }

	// RVA: -1
	private static object InsertionSortStruct(object array, object lo, object hi, object comp) { }

	// RVA: -1
	private static object PartitionStruct(object array, object lo, object hi, object comp) { }

	// RVA: -1
	private static object HeapSortStruct(object array, object lo, object hi, object comp) { }

	// RVA: -1
	private static object HeapifyStruct(object array, object i, object n, object lo, object comp) { }

	// RVA: -1
	private static object SwapStruct(object array, object lhs, object rhs) { }

	// RVA: -1
	private static object SwapIfGreaterWithItemsStruct(object array, object lhs, object rhs, object comp) { }

}

// Namespace: 
private struct ConstructJobList
{

	// Fields
	public object Container; // 0xFFFFFFFFFFFFFFF8
	public object List; // 0x18

	// Methods

	// RVA: 0x726B228
	public object Execute() { }

}

// Namespace: 
private struct ConstructJob
{

	// Fields
	public object Container; // 0xFFFFFFFFFFFFFFF8
	public object Length; // 0x18

	// Methods

	// RVA: 0x726B254
	public object Execute() { }

}

// Namespace: Unity.Collections
public struct NativeStream
{

	// Fields
	private object m_Stream; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object IsCreated { get; }

	// Methods

	// RVA: 0x726B028
	public object get_IsCreated() { }

	// RVA: 0x726B048
	public object Dispose() { }

	// RVA: 0x726B130
	private object AllocateForEach(object forEachCount) { }

}

// Namespace: Unity.Collections
internal struct NativeStreamDispose
{

	// Fields
	public object m_StreamData; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726B268
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeStreamDisposeJob
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726B2E8
	public object Execute() { }

}

// Namespace: Unity.Collections
internal struct NativeTextDispose
{

	// Fields
	public object m_TextData; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726B330
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct NativeTextDisposeJob
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726B454
	public object Execute() { }

}

// Namespace: Unity.Collections
internal struct Spinner
{

	// Fields
	private object m_Lock; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726B464
	internal object Acquire() { }

	// RVA: 0x726B518
	internal object Release() { }

}

// Namespace: Unity.Collections
internal struct UnmanagedArray<T0>
{

	// Fields
	private object m_pointer; // 0x0
	private object m_length; // 0x0
	private object m_allocator; // 0x0

	// Properties
	public object Item { get; }

	// Methods

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object get_Item(object index) { }

}

// Namespace: 
internal struct Union
{

	// Fields
	internal object m_long; // 0xFFFFFFFFFFFFFFF8

	// Properties
	internal object m_current { get; set; }
	internal object m_allocCount { get; set; }

	// Methods

	// RVA: 0x726C158
	internal object get_m_current() { }

	// RVA: 0x726C170
	internal object set_m_current(object value) { }

	// RVA: 0x726C190
	internal object get_m_allocCount() { }

	// RVA: 0x726C1A8
	internal object set_m_allocCount(object value) { }

}

// Namespace: 
internal struct MemoryBlock
{

	// Fields
	public object m_pointer; // 0xFFFFFFFFFFFFFFF8
	public object m_bytes; // 0x0
	public object m_union; // 0x8

	// Methods

	// RVA: 0x726BF2C
	public object .ctor(object bytes) { }

	// RVA: 0x726B8C0
	public object Rewind() { }

	// RVA: 0x726B85C
	public object Dispose() { }

	// RVA: 0x726BF70
	public object Contains(object ptr) { }

}

// Namespace: Unity.Collections
internal sealed class Try_000009D1$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x726C360
	public object .ctor(object , object ) { }

	// RVA: 0x726C3F8
	public virtual object Invoke(object state, object block) { }

}

// Namespace: Unity.Collections
internal static class Try_000009D1$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x726C40C
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x726C550
	private static object GetFunctionPointer() { }

	// RVA: 0x726C5B8
	public static object Constructor() { }

	// RVA: 0x726C680
	public static object Initialize() { }

	// RVA: 0x726C684
	private static object .cctor() { }

	// RVA: 0x726BFD0
	public static object Invoke(object state, object block) { }

}

// Namespace: Unity.Collections
public struct RewindableAllocator
{

	// Fields
	private object m_spinner; // 0xFFFFFFFFFFFFFFF8
	private object m_handle; // 0xFFFFFFFFFFFFFFFC
	private object m_block; // 0x0
	private object m_last; // 0x10
	private object m_used; // 0x14
	private object m_enableBlockFree; // 0x18
	private object m_reachMaxBlockSize; // 0x19

	// Properties
	public object Handle { get; }

	// Methods

	// RVA: 0x726B6F4
	public object Rewind() { }

	// RVA: 0x726B8D0
	public object Dispose() { }

	// RVA: 0x726B9FC
	private object TryAllocate(object block, object startIndex, object lastIndex, object alignedSize, object alignmentMask) { }

	// RVA: 0x726BC14
	public object Try(object block) { }

	// RVA: 0x726B600
	internal static object Try(object state, object block) { }

	// RVA: 0x726C120
	public object get_Handle() { }

	// RVA: 0x726C130
	internal static object Try$BurstManaged(object state, object block) { }

}

// Namespace: Unity.Collections
public enum ConversionError
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Overflow;
	public const object Encoding;
	public const object CodePoint;
}

// Namespace: 
public struct Rune
{

	// Fields
	public object value; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726C9F0
	public override object Equals(object obj) { }

	// RVA: 0x726CB40
	public override object GetHashCode() { }

}

// Namespace: Unity.Collections
public struct Unicode
{

	// Properties
	public static object ReplacementCharacter { get; }

	// Methods

	// RVA: 0x726C688
	public static object IsValidCodePoint(object codepoint) { }

	// RVA: 0x726C694
	public static object NotTrailer(object b) { }

	// RVA: 0x726C6A4
	public static object get_ReplacementCharacter() { }

	// RVA: 0x726C6AC
	public static object Utf8ToUcs(object rune, object buffer, object index, object capacity) { }

	// RVA: 0x726C86C
	public static object UcsToUtf16(object buffer, object index, object capacity, object rune) { }

	// RVA: 0x726C8F4
	public static object Utf8ToUtf16(object utf8Buffer, object utf8Length, object utf16Buffer, object utf16Length, object utf16Capacity) { }

}

// Namespace: Unity.Collections
internal struct UnsafeQueueBlockHeader
{

	// Fields
	public object m_NextBlock; // 0xFFFFFFFFFFFFFFF8
	public object m_NumItems; // 0x0
}

// Namespace: Unity.Collections
internal struct UnsafeQueueBlockPoolData
{

	// Fields
	internal object m_FirstBlock; // 0xFFFFFFFFFFFFFFF8
	internal object m_NumBlocks; // 0x0
	internal object m_MaxBlocks; // 0x4
	internal object m_AllocLock; // 0x8

	// Methods

	// RVA: 0x726CB50
	public object FreeBlock(object block) { }

}

// Namespace: Unity.Collections
internal struct UnsafeQueueData
{

	// Fields
	public object m_FirstBlock; // 0xFFFFFFFFFFFFFFF8
	public object m_LastBlock; // 0x0
	public object m_MaxItems; // 0x8
	public object m_CurrentRead; // 0xC
	public object m_CurrentWriteBlockTLS; // 0x10

	// Methods

	// RVA: 0x726CC64
	public static object DeallocateQueue(object data, object pool, object allocation) { }

}

// Namespace: Unity.Collections
public struct UnsafeQueue<T0>
{

	// Fields
	internal object m_Buffer; // 0x0
	internal object m_QueuePool; // 0x0
	internal object m_AllocatorLabel; // 0x0

	// Properties
	public object IsCreated { get; }

	// Methods

	// RVA: -1
	internal static object Free(object data) { }

	// RVA: -1
	public object get_IsCreated() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct UnsafeQueueDispose
{

	// Fields
	internal object m_Buffer; // 0xFFFFFFFFFFFFFFF8
	internal object m_QueuePool; // 0x0
	internal object m_AllocatorLabel; // 0x8

	// Methods

	// RVA: 0x726CD04
	public object Dispose() { }

}

// Namespace: Unity.Collections
internal struct UnsafeQueueDisposeJob
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726CE3C
	public object Execute() { }

}

// Namespace: Unity.Collections
internal sealed class Hash64Long_00000A67$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x726EF70
	public object .ctor(object , object ) { }

	// RVA: 0x726F020
	public virtual object Invoke(object input, object dest, object length, object secret) { }

}

// Namespace: Unity.Collections
internal static class Hash64Long_00000A67$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x726F034
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x726F178
	private static object GetFunctionPointer() { }

	// RVA: 0x726F1E0
	public static object Constructor() { }

	// RVA: 0x726F2A8
	public static object Initialize() { }

	// RVA: 0x726F2AC
	private static object .cctor() { }

	// RVA: 0x726DC98
	public static object Invoke(object input, object dest, object length, object secret) { }

}

// Namespace: Unity.Collections
internal sealed class Hash128Long_00000A6E$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x726F3A8
	public object .ctor(object , object ) { }

	// RVA: 0x726F458
	public virtual object Invoke(object input, object dest, object length, object secret, object result) { }

}

// Namespace: Unity.Collections
internal static class Hash128Long_00000A6E$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x726F46C
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x726F5B0
	private static object GetFunctionPointer() { }

	// RVA: 0x726F618
	public static object Constructor() { }

	// RVA: 0x726F6E0
	public static object Initialize() { }

	// RVA: 0x726F6E4
	private static object .cctor() { }

	// RVA: 0x726DFB4
	public static object Invoke(object input, object dest, object length, object secret, object result) { }

}

// Namespace: Unity.Collections
public static class xxHash3
{

	// Methods

	// RVA: 0x726CEE0
	internal static object Avx2HashLongInternalLoop(object acc, object input, object dest, object length, object secret, object isHash64) { }

	// RVA: 0x726D580
	internal static object Avx2ScrambleAcc(object acc, object secret) { }

	// RVA: 0x726D4B0
	internal static object Avx2Accumulate(object acc, object input, object dest, object secret, object nbStripes, object isHash64) { }

	// RVA: 0x726D8B8
	internal static object Avx2Accumulate512(object acc, object input, object dest, object secret) { }

	// RVA: 0x726DC18
	private static object Hash64Long(object input, object dest, object length, object secret) { }

	// RVA: 0x726DF24
	private static object Hash128Long(object input, object dest, object length, object secret, object result) { }

	// RVA: 0x726E13C
	internal static object ToUint4(object ul0, object ul1) { }

	// RVA: 0x726E140
	private static object Read64LE(object addr) { }

	// RVA: 0x726E148
	private static object Write64LE(object addr, object value) { }

	// RVA: 0x726E150
	private static object Mul32To64(object x, object y) { }

	// RVA: 0x726E158
	private static object XorShift64(object v64, object shift) { }

	// RVA: 0x726E164
	private static object Mul128Fold64(object lhs, object rhs) { }

	// RVA: 0x726E194
	private static object Avalanche(object h64) { }

	// RVA: 0x726E1B4
	private static object Mix2Acc(object acc0, object acc1, object secret) { }

	// RVA: 0x726E1F0
	internal static object MergeAcc(object acc, object secret, object start) { }

	// RVA: 0x726E2F8
	private static object DefaultHashLongInternalLoop(object acc, object input, object dest, object length, object secret, object isHash64) { }

	// RVA: 0x726E7C8
	internal static object DefaultAccumulate(object acc, object input, object dest, object secret, object nbStripes, object isHash64) { }

	// RVA: 0x726E948
	internal static object DefaultAccumulate512(object acc, object input, object dest, object secret, object isHash64) { }

	// RVA: 0x726E88C
	internal static object DefaultScrambleAcc(object acc, object secret) { }

	// RVA: 0x726EBA4
	internal static object Hash64Long$BurstManaged(object input, object dest, object length, object secret) { }

	// RVA: 0x726ECFC
	internal static object Hash128Long$BurstManaged(object input, object dest, object length, object secret, object result) { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public struct UnsafeAtomicCounter32
{

	// Fields
	public object Counter; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726F868
	public object .ctor(object ptr) { }

	// RVA: 0x726F878
	public object Reset(object value) { }

	// RVA: 0x726F890
	public object Add(object value) { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public struct UnsafeBitArray
{

	// Fields
	public object Ptr; // 0xFFFFFFFFFFFFFFF8
	public object Length; // 0x0
	public object Capacity; // 0x4
	public object Allocator; // 0x8

	// Properties
	public object IsCreated { get; }

	// Methods

	// RVA: 0x726AA58
	internal static object Free(object data) { }

	// RVA: 0x726F9E4
	public object get_IsCreated() { }

	// RVA: 0x726F948
	public object Dispose() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal sealed class UnsafeBitArrayDebugView
{
}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct HashMapHelper<T0>
{

	// Fields
	internal object Ptr; // 0x0
	internal object Keys; // 0x0
	internal object Next; // 0x0
	internal object Buckets; // 0x0
	internal object Count; // 0x0
	internal object Capacity; // 0x0
	internal object Log2MinGrowth; // 0x0
	internal object BucketCapacity; // 0x0
	internal object AllocatedIndex; // 0x0
	internal object FirstFreeIdx; // 0x0
	internal object SizeOfTValue; // 0x0
	internal object Allocator; // 0x0

	// Properties
	internal object IsCreated { get; }

	// Methods

	// RVA: -1
	internal object get_IsCreated() { }

	// RVA: -1
	internal object Dispose() { }

	// RVA: -1
	internal static object Free(object data) { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public struct UnsafeHashMap<T0, T1>
{

	// Fields
	internal object m_Data; // 0x0

	// Properties
	public object IsCreated { get; }

	// Methods

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object get_IsCreated() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<Unity.Collections.KVPair<TKey,TValue>>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal sealed class UnsafeHashMapDebuggerTypeProxy<T0, T1>
{
}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UnsafeDisposeJob
{

	// Fields
	public object Ptr; // 0xFFFFFFFFFFFFFFF8
	public object Allocator; // 0x0

	// Methods

	// RVA: 0x726FAA0
	public object Execute() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UntypedUnsafeList
{

	// Fields
	internal readonly object Ptr; // 0xFFFFFFFFFFFFFFF8
	internal readonly object m_length; // 0x0
	internal readonly object m_capacity; // 0x4
	internal readonly object Allocator; // 0x8
	internal readonly object padding; // 0xC
}

// Namespace: Unity.Collections.LowLevel.Unsafe
public struct UnsafeList<T0>
{

	// Fields
	public object Ptr; // 0x0
	public object m_length; // 0x0
	public object m_capacity; // 0x0
	public object Allocator; // 0x0
	private readonly object padding; // 0x0

	// Properties
	public object Length { get; }
	public object Capacity { get; }
	public object Item { get; set; }
	public object IsCreated { get; }

	// Methods

	// RVA: -1
	public object get_Length() { }

	// RVA: -1
	public object get_Capacity() { }

	// RVA: -1
	public object get_Item(object index) { }

	// RVA: -1
	public object set_Item(object index, object value) { }

	// RVA: -1
	public object .ctor(object initialCapacity, object allocator, object options) { }

	// RVA: -1
	internal static object Create(object initialCapacity, object allocator, object options) { }

	// RVA: -1
	public static object Destroy(object listData) { }

	// RVA: -1
	public object get_IsCreated() { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Resize(object length, object options) { }

	// RVA: -1
	private object ResizeExact(object allocator, object newCapacity) { }

	// RVA: -1
	private object SetCapacity(object allocator, object capacity) { }

	// RVA: -1
	public object SetCapacity(object capacity) { }

	// RVA: -1
	public object Add(object value) { }

	// RVA: -1
	public object AddRange(object ptr, object count) { }

	// RVA: -1
	public object RemoveAtSwapBack(object index) { }

	// RVA: -1
	public object RemoveRangeSwapBack(object index, object count) { }

	// RVA: -1
	public object RemoveAt(object index) { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<T>.GetEnumerator() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal sealed class UnsafeListTDebugView<T0>
{
}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UnsafeParallelHashMapData
{

	// Fields
	internal object values; // 0xFFFFFFFFFFFFFFF8
	internal object keys; // 0x0
	internal object next; // 0x8
	internal object buckets; // 0x10
	internal object keyCapacity; // 0x18
	internal object bucketCapacityMask; // 0x1C
	internal object allocatedIndexLength; // 0x20

	// Methods

	// RVA: 0x726FBAC
	internal static object DeallocateHashMap(object data, object allocator) { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UnsafeParallelHashMapDataDispose
{

	// Fields
	internal object m_Buffer; // 0xFFFFFFFFFFFFFFF8
	internal object m_AllocatorLabel; // 0x0

	// Methods

	// RVA: 0x726FC40
	public object Dispose() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UnsafeParallelHashMapDataDisposeJob
{

	// Fields
	internal object Data; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x726FD60
	public object Execute() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UnsafeParallelHashMapDisposeJob
{

	// Fields
	public object Data; // 0xFFFFFFFFFFFFFFF8
	public object Allocator; // 0x0

	// Methods

	// RVA: 0x726FDF8
	public object Execute() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public struct UnsafeRingQueue<T0>
{

	// Fields
	public object Ptr; // 0x0
	public object Allocator; // 0x0
	internal readonly object m_Capacity; // 0x0
	internal object m_Filled; // 0x0
	internal object m_Write; // 0x0
	internal object m_Read; // 0x0

	// Properties
	public object IsCreated { get; }

	// Methods

	// RVA: -1
	internal static object Free(object data) { }

	// RVA: -1
	public object get_IsCreated() { }

	// RVA: -1
	public object Dispose() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal sealed class UnsafeRingQueueDebugView<T0>
{
}

// Namespace: 
public struct <Data>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UnsafeStreamBlock
{

	// Fields
	internal object Next; // 0xFFFFFFFFFFFFFFF8
	internal object Data; // 0x0
}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UnsafeStreamRange
{

	// Fields
	internal object Block; // 0xFFFFFFFFFFFFFFF8
	internal object OffsetInFirstBlock; // 0x0
	internal object ElementCount; // 0x4
	internal object LastOffset; // 0x8
	internal object NumberOfBlocks; // 0xC
}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal struct UnsafeStreamBlockData
{

	// Fields
	internal object Allocator; // 0xFFFFFFFFFFFFFFF8
	internal object Blocks; // 0x0
	internal object BlockCount; // 0x8
	internal object Ranges; // 0x10
	internal object RangeCount; // 0x30

	// Methods

	// RVA: 0x726FE90
	internal object Free(object oldBlock) { }

}

// Namespace: 
private struct DisposeJob
{

	// Fields
	public object Container; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x7270150
	public object Execute() { }

}

// Namespace: 
private struct ConstructJobList
{

	// Fields
	public object Container; // 0xFFFFFFFFFFFFFFF8
	public object List; // 0x18

	// Methods

	// RVA: 0x727015C
	public object Execute() { }

}

// Namespace: 
private struct ConstructJob
{

	// Fields
	public object Container; // 0xFFFFFFFFFFFFFFF8
	public object Length; // 0x18

	// Methods

	// RVA: 0x7270188
	public object Execute() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public struct UnsafeStream
{

	// Fields
	internal object m_BlockData; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object IsCreated { get; }

	// Methods

	// RVA: 0x726B134
	internal object AllocateForEach(object forEachCount) { }

	// RVA: 0x726FED0
	public object get_IsCreated() { }

	// RVA: 0x726FEF0
	private object Deallocate() { }

	// RVA: 0x726B09C
	public object Dispose() { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
internal static class UnsafeTextExtensions
{

	// Methods

	// RVA: 0x727019C
	public static object AsUnsafeListOfBytes(object text) { }

	// RVA: 0x72701F4
	public static object AsUnsafeListOfBytesRO(object text) { }

}

// Namespace: Unity.Collections.LowLevel.Unsafe
public struct UnsafeText
{

	// Fields
	internal object m_UntypedListData; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public object IsCreated { get; }
	public object Length { get; }

	// Methods

	// RVA: 0x7270264
	public object get_IsCreated() { }

	// RVA: 0x726B338
	internal static object Free(object data) { }

	// RVA: 0x727038C
	public object Dispose() { }

	// RVA: 0x7270494
	public object GetUnsafePtr() { }

	// RVA: 0x72704A4
	public object get_Length() { }

	// RVA: 0x72705C4
	public override object ToString() { }

}

// Namespace: 
internal class __JobReflectionRegistrationOutput__3315946825
{

	// Methods

	// RVA: 0x72706C4
	public static object CreateJobReflectionData() { }

	// RVA: 0x7270984
	public static object EarlyInit() { }

}

// Namespace: 
internal static class $BurstDirectCallInitializer
{

	// Methods

	// RVA: 0x7270988
	private static object Initialize() { }

}

