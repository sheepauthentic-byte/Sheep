// Namespace: 
internal class <Module>
{
}

// Namespace: 
public class Delay
{

	// Fields
	public object delayTime; // 0x18
	private object _started; // 0x1C

	// Methods

	// RVA: 0xF3E7AC
	public object OnCreate() { }

	// RVA: 0xF3E7B0
	public object OnPrepare() { }

	// RVA: 0xF3E7B4
	public object OnGet() { }

	// RVA: 0xF3E8CC
	public object OnRecycle() { }

	// RVA: 0xF3E8D4
	private object Start() { }

	// RVA: 0xF3E844
	private object DoStart() { }

	// RVA: 0xF3E964
	private object DelayFunc() { }

	// RVA: 0xF3E994
	public object Restart() { }

	// RVA: 0xF3EA54
	public object .ctor() { }

}

// Namespace: 
public class NcEffectAniBehaviour
{

	// Fields
	protected object m_Timer; // 0x38
	protected object m_OnEndAniGameObject; // 0x40
	protected object m_bEndAnimation; // 0x48
	public object m_OnEndAniFunction; // 0x50

	// Methods

	// RVA: 0xF3EA64
	public object SetCallBackEndAnimation(object callBackGameObj) { }

	// RVA: 0xF3EA6C
	public object SetCallBackEndAnimation(object callBackGameObj, object nameFunction) { }

	// RVA: 0xF3EA78
	public object IsEndAnimation() { }

	// RVA: 0xF3EA80
	protected object InitAnimationTimer() { }

	// RVA: 0xF3EBE4
	public virtual object ResetAnimation() { }

	// RVA: 0xF3ECC8
	public virtual object PauseAnimation() { }

	// RVA: 0xF3ED2C
	public virtual object ResumeAnimation() { }

	// RVA: 0xF3ED98
	public virtual object MoveAnimation(object fElapsedTime) { }

	// RVA: 0xF3EE10
	protected object OnEndAnimation() { }

	// RVA: 0xF3EEEC
	public object .ctor() { }

}

// Namespace: 
public class _RuntimeIntance
{

	// Fields
	public object m_ParentGameObject; // 0x8
	public object m_ChildGameObject; // 0x10

	// Methods

	// RVA: 0xF4153C
	public object .ctor(object parentGameObject, object childGameObject) { }

}

// Namespace: 
public class NcEffectBehaviour
{

	// Fields
	private static object m_bShuttingDown; // 0x0
	private static object m_RootInstance; // 0x8
	public object m_fUserTag; // 0x18
	protected object m_MeshFilter; // 0x20
	protected object m_RuntimeMaterials; // 0x28
	protected object m_renderer; // 0x30

	// Methods

	// RVA: 0xF3EF78
	protected object GetRenderer() { }

	// RVA: 0xF3EF50
	public object .ctor() { }

	// RVA: 0xF3F048
	public static object GetEngineTime() { }

	// RVA: 0xF3F080
	public static object GetEngineDeltaTime() { }

	// RVA: 0xF3F088
	public virtual object GetAnimationState() { }

	// RVA: 0xF3F090
	public static object GetRootInstanceEffect() { }

	// RVA: 0xF3F284
	protected static object SetActive(object target, object bActive) { }

	// RVA: 0xF3F2A4
	protected static object SetActiveRecursively(object target, object bActive) { }

	// RVA: 0xF3F2C4
	protected static object IsActive(object target) { }

	// RVA: 0xF3F2E4
	public static object HideNcDelayActive(object tarObj) { }

	// RVA: 0xF3F308
	public static object PreloadTexture(object tarObj) { }

	// RVA: 0xF3F4D4
	private static object PreloadTexture(object tarObj, object parentPrefabList) { }

	// RVA: 0xF3FC7C
	private static object PreloadPrefab(object tarObj, object parentPrefabList, object bCheckDup) { }

	// RVA: 0xF3FF70
	protected object AddRuntimeMaterial(object addMaterial) { }

	// RVA: 0xF4006C
	public static object AdjustSpeedRuntime(object target, object fSpeedRate) { }

	// RVA: 0xF40168
	public static object GetMaterialColorName(object mat) { }

	// RVA: 0xF402F0
	protected object DisableEmit() { }

	// RVA: 0xF3F230
	public static object IsSafe() { }

	// RVA: 0xF40424
	protected object CreateEditorGameObject(object srcGameObj) { }

	// RVA: 0xF4042C
	public object CreateGameObject(object name) { }

	// RVA: 0xF40504
	public object CreateGameObject(object original) { }

	// RVA: 0xF405EC
	public object CreateGameObject(object prefabObj, object position, object rotation) { }

	// RVA: 0xF4073C
	public object CreateGameObject(object parentObj, object prefabObj) { }

	// RVA: 0xF40B18
	public object CreateGameObject(object parentObj, object parentTrans, object prefabObj) { }

	// RVA: 0xF40950
	protected object ChangeParent(object newParent, object child, object bKeepingLocalTransform, object addTransform) { }

	// RVA: 0xF40F34
	protected object UpdateMeshColors(object color) { }

	// RVA: 0xF4132C
	protected virtual object OnDestroy() { }

	// RVA: 0xF414E4
	public object OnApplicationQuit() { }

	// RVA: 0xF41534
	public virtual object OnUpdateEffectSpeed(object fSpeedRate, object bRuntime) { }

	// RVA: 0xF41538
	public virtual object OnUpdateToolData() { }

}

// Namespace: 
public class NcTimerTool
{

	// Fields
	protected object m_bEnable; // 0x8
	private object m_fLastEngineTime; // 0xC
	private object m_fCurrentTime; // 0x10
	private object m_fLastTime; // 0x14
	private object m_fTimeScale; // 0x18
	private object m_nSmoothCount; // 0x1C
	private object m_nSmoothIndex; // 0x20
	private object m_fSmoothRate; // 0x24
	private object m_fSmoothTimes; // 0x28
	private object m_fLastSmoothDeltaTime; // 0x30

	// Methods

	// RVA: 0xF41574
	public static object GetEngineTime() { }

	// RVA: 0xF415AC
	public static object GetEngineDeltaTime() { }

	// RVA: 0xF415B4
	private object InitSmoothTime() { }

	// RVA: 0xF41698
	private object UpdateSmoothTime(object fDeltaTime) { }

	// RVA: 0xF417C8
	public object IsUpdateTimer() { }

	// RVA: 0xF41824
	private object UpdateTimer() { }

	// RVA: 0xF419C4
	public object GetTime() { }

	// RVA: 0xF419C8
	public object GetDeltaTime() { }

	// RVA: 0xF41A34
	public object GetSmoothDeltaTime() { }

	// RVA: 0xF41AAC
	public object IsEnable() { }

	// RVA: 0xF3EB74
	public object Start() { }

	// RVA: 0xF3EC60
	public object Reset(object fElapsedTime) { }

	// RVA: 0xF3ED04
	public object Pause() { }

	// RVA: 0xF3ED6C
	public object Resume() { }

	// RVA: 0xF41AB4
	public object SetTimeScale(object fTimeScale) { }

	// RVA: 0xF41ABC
	protected virtual object GetTimeScale() { }

	// RVA: 0xF3EB54
	public object .ctor() { }

}

// Namespace: 
public class NcTransformTool
{

	// Fields
	public object m_vecPos; // 0x8
	public object m_vecRot; // 0x14
	public object m_vecRotHint; // 0x24
	public object m_vecScale; // 0x30

	// Methods

	// RVA: 0xF41AC4
	public object .ctor() { }

	// RVA: 0xF40D30
	public object .ctor(object val) { }

	// RVA: 0xF41B74
	public static object GetZeroVector() { }

	// RVA: 0xF41BC4
	public static object GetUnitVector() { }

	// RVA: 0xF41BD4
	public static object GetIdenQuaternion() { }

	// RVA: 0xF41C24
	public static object InitLocalTransform(object dst) { }

	// RVA: 0xF41CF4
	public static object InitWorldTransform(object dst) { }

	// RVA: 0xF41DB4
	public static object InitWorldScale(object dst) { }

	// RVA: 0xF41EAC
	public static object CopyLocalTransform(object src, object dst) { }

	// RVA: 0xF41F2C
	public static object CopyLossyToLocalScale(object srcLossyScale, object dst) { }

	// RVA: 0xF40ECC
	public object CopyToLocalTransform(object dst) { }

	// RVA: 0xF42034
	public object CopyToTransform(object dst) { }

	// RVA: 0xF42098
	public object AddLocalTransform(object val) { }

	// RVA: 0xF41B08
	public object SetLocalTransform(object val) { }

	// RVA: 0xF421C0
	public object IsLocalEquals(object val) { }

	// RVA: 0xF40DA4
	public object AddTransform(object val) { }

	// RVA: 0xF42304
	public object SetTransform(object val) { }

	// RVA: 0xF42370
	public object IsEquals(object val) { }

	// RVA: 0xF424B4
	public object SetTransform(object val) { }

	// RVA: 0xF424F8
	public static object GetTransformScaleMeanValue(object srcTrans) { }

	// RVA: 0xF42564
	public static object GetTransformScaleMeanVector(object srcTrans) { }

}

// Namespace: 
public enum EaseType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Linear;
	public const object EaseInQuad;
	public const object EaseOutQuad;
	public const object EaseInOutQuad;
	public const object EaseInCubic;
	public const object EaseOutCubic;
	public const object EaseInOutCubic;
	public const object EaseInQuart;
	public const object EaseOutQuart;
	public const object EaseInOutQuart;
	public const object EaseInQuint;
	public const object EaseOutQuint;
	public const object EaseInOutQuint;
	public const object EaseInSine;
	public const object EaseOutSine;
	public const object EaseInOutSine;
	public const object EaseInExpo;
	public const object EaseOutExpo;
	public const object EaseInOutExpo;
	public const object EaseInCirc;
	public const object EaseOutCirc;
	public const object EaseInOutCirc;
}

// Namespace: 
public sealed class ToVector3<T0>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object v) { }

	// RVA: -1
	public virtual object BeginInvoke(object v, object callback, object object) { }

	// RVA: -1
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class Function
{

	// Methods

	// RVA: 0xF43008
	public object .ctor(object object, object method) { }

	// RVA: 0xF44310
	public virtual object Invoke(object a, object b, object c, object d) { }

	// RVA: 0xF44324
	public virtual object BeginInvoke(object a, object b, object c, object d, object callback, object object) { }

	// RVA: 0xF44414
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
private sealed class <NewBezier>d__16<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object nodes; // 0x0
	public object <>3__nodes; // 0x0
	private object steps; // 0x0
	public object <>3__steps; // 0x0
	private object toVector3; // 0x0
	public object <>3__toVector3; // 0x0
	private object ease; // 0x0
	public object <>3__ease; // 0x0
	private object maxStep; // 0x0
	public object <>3__maxStep; // 0x0
	private object <points>5__2; // 0x0
	private object <>7__wrap2; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.Vector3>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<UnityEngine.Vector3>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<UnityEngine.Vector3>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <NewCatmullRom>d__20<T0>
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	private object <>l__initialThreadId; // 0x0
	private object nodes; // 0x0
	public object <>3__nodes; // 0x0
	private object toVector3; // 0x0
	public object <>3__toVector3; // 0x0
	private object loop; // 0x0
	public object <>3__loop; // 0x0
	private object slices; // 0x0
	public object <>3__slices; // 0x0
	private object <last>5__2; // 0x0
	private object <current>5__3; // 0x0
	private object <previous>5__4; // 0x0
	private object <start>5__5; // 0x0
	private object <end>5__6; // 0x0
	private object <next>5__7; // 0x0
	private object <stepCount>5__8; // 0x0
	private object <step>5__9; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<UnityEngine.Vector3>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<UnityEngine.Vector3>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerable<UnityEngine.Vector3>.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <NewCounter>d__6
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x10
	private object start; // 0x14
	public object <>3__start; // 0x18
	private object step; // 0x1C
	public object <>3__step; // 0x20
	private object end; // 0x24
	public object <>3__end; // 0x28
	private object <i>5__2; // 0x2C

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Single>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xF42744
	public object .ctor(object <>1__state) { }

	// RVA: 0xF44448
	private object System.IDisposable.Dispose() { }

	// RVA: 0xF4444C
	private object MoveNext() { }

	// RVA: 0xF444BC
	private object System.Collections.Generic.IEnumerator<System.Single>.get_Current() { }

	// RVA: 0xF444C4
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xF44504
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0xF4456C
	private object System.Collections.Generic.IEnumerable<System.Single>.GetEnumerator() { }

	// RVA: 0xF44620
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <NewEase>d__9
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object end; // 0x18
	public object start; // 0x24
	public object driver; // 0x30
	public object ease; // 0x38
	public object total; // 0x40
	private object <distance>5__2; // 0x44
	private object <>7__wrap2; // 0x50

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xF42A64
	public object .ctor(object <>1__state) { }

	// RVA: 0xF446D4
	private object System.IDisposable.Dispose() { }

	// RVA: 0xF447D8
	private object MoveNext() { }

	// RVA: 0xF44C70
	private object <>m__Finally1() { }

	// RVA: 0xF44D90
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xF44D98
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xF44DD8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <NewTimer>d__3
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	private object <>l__initialThreadId; // 0x10
	private object duration; // 0x14
	public object <>3__duration; // 0x18
	private object <elapsedTime>5__2; // 0x1C

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Single>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xF42678
	public object .ctor(object <>1__state) { }

	// RVA: 0xF44DE0
	private object System.IDisposable.Dispose() { }

	// RVA: 0xF44DE4
	private object MoveNext() { }

	// RVA: 0xF44EA4
	private object System.Collections.Generic.IEnumerator<System.Single>.get_Current() { }

	// RVA: 0xF44EAC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xF44EEC
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0xF44F54
	private object System.Collections.Generic.IEnumerable<System.Single>.GetEnumerator() { }

	// RVA: 0xF45008
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
public class NgInterpolate
{

	// Methods

	// RVA: 0xF425D8
	private static object Identity(object v) { }

	// RVA: 0xF425DC
	private static object TransformDotPosition(object t) { }

	// RVA: 0xF425FC
	private static object NewTimer(object duration) { }

	// RVA: 0xF426B0
	private static object NewCounter(object start, object end, object step) { }

	// RVA: 0xF4277C
	public static object NewEase(object ease, object start, object end, object duration) { }

	// RVA: 0xF42944
	public static object NewEase(object ease, object start, object end, object slices) { }

	// RVA: 0xF42888
	private static object NewEase(object ease, object start, object end, object total, object driver) { }

	// RVA: 0xF42A90
	private static object Ease(object ease, object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF42B64
	public static object Ease(object type) { }

	// RVA: 0xF430A0
	public static object NewBezier(object ease, object nodes, object duration) { }

	// RVA: 0xF431BC
	public static object NewBezier(object ease, object nodes, object slices) { }

	// RVA: 0xF432E0
	public static object NewBezier(object ease, object points, object duration) { }

	// RVA: 0xF433FC
	public static object NewBezier(object ease, object points, object slices) { }

	// RVA: -1
	private static object NewBezier(object ease, object nodes, object toVector3, object maxStep, object steps) { }

	// RVA: 0xF43520
	private static object Bezier(object ease, object points, object elapsedTime, object duration) { }

	// RVA: 0xF436A8
	public static object NewCatmullRom(object nodes, object slices, object loop) { }

	// RVA: 0xF43764
	public static object NewCatmullRom(object points, object slices, object loop) { }

	// RVA: -1
	private static object NewCatmullRom(object nodes, object toVector3, object slices, object loop) { }

	// RVA: 0xF43820
	private static object CatmullRom(object previous, object start, object end, object next, object elapsedTime, object duration) { }

	// RVA: 0xF438D8
	private static object Linear(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF438F0
	private static object EaseInQuad(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43910
	private static object EaseOutQuad(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43938
	private static object EaseInOutQuad(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF4399C
	private static object EaseInCubic(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF439C0
	private static object EaseOutCubic(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF439F4
	private static object EaseInOutCubic(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43A5C
	private static object EaseInQuart(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43A84
	private static object EaseOutQuart(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43AB8
	private static object EaseInOutQuart(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43B24
	private static object EaseInQuint(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43B50
	private static object EaseOutQuint(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43B8C
	private static object EaseInOutQuint(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43C04
	private static object EaseInSine(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43CA4
	private static object EaseOutSine(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43D40
	private static object EaseInOutSine(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43DEC
	private static object EaseInExpo(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43E8C
	private static object EaseOutExpo(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF43F2C
	private static object EaseInOutExpo(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF44034
	private static object EaseInCirc(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF440D4
	private static object EaseOutCirc(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF44178
	private static object EaseInOutCirc(object start, object distance, object elapsedTime, object duration) { }

	// RVA: 0xF44268
	public object .ctor() { }

}

// Namespace: 
private class NcComparerCurve
{

	// Fields
	protected static object m_fEqualRange; // 0x0
	protected static object m_fHDiv; // 0x4

	// Methods

	// RVA: 0xF49794
	public object Compare(object a, object b) { }

	// RVA: 0xF494B4
	public static object GetSortGroup(object info) { }

	// RVA: 0xF494AC
	public object .ctor() { }

	// RVA: 0xF499AC
	private static object .cctor() { }

}

// Namespace: 
public enum APPLY_TYPE
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NONE;
	public const object POSITION;
	public const object ROTATION;
	public const object SCALE;
	public const object MATERIAL_COLOR;
	public const object TEXTUREUV;
	public const object MESH_COLOR;
}

// Namespace: 
public class NcInfoCurve
{

	// Fields
	protected const object m_fOverDraw;
	public object m_bEnabled; // 0x8
	public object m_CurveName; // 0x10
	public object m_AniCurve; // 0x18
	public static object m_TypeName; // 0x0
	public object m_ApplyType; // 0x20
	public object m_bApplyOption; // 0x28
	public object m_bRecursively; // 0x30
	public object m_fValueScale; // 0x34
	public object m_FromColor; // 0x38
	public object m_ToColor; // 0x48
	public object m_nTag; // 0x58
	public object m_nSortGroup; // 0x5C
	public object m_OriginalValue; // 0x60
	public object m_BeforeValue; // 0x70
	public object m_ChildOriginalColorValues; // 0x80
	public object m_ChildBeforeColorValues; // 0x88

	// Methods

	// RVA: 0xF49A00
	public object IsEnabled() { }

	// RVA: 0xF49A08
	public object SetEnabled(object bEnable) { }

	// RVA: 0xF49A10
	public object GetCurveName() { }

	// RVA: 0xF485CC
	public object GetClone() { }

	// RVA: 0xF49A18
	public object CopyTo(object target) { }

	// RVA: 0xF49B8C
	public object GetValueCount() { }

	// RVA: 0xF49BB4
	public object GetValueName(object nIndex) { }

	// RVA: 0xF49F28
	public object SetDefaultValueScale() { }

	// RVA: 0xF49F58
	public object GetFixedDrawRange() { }

	// RVA: 0xF49F8C
	public object GetVariableDrawRange() { }

	// RVA: 0xF4A1EC
	public object GetEditRange() { }

	// RVA: 0xF4A200
	public object NormalizeCurveTime() { }

	// RVA: 0xF48ED0
	public object .ctor() { }

	// RVA: 0xF4A418
	private static object .cctor() { }

}

// Namespace: 
public class NcCurveAnimation
{

	// Fields
	public object m_CurveInfoList; // 0x58
	public object m_fDelayTime; // 0x60
	public object m_fDurationTime; // 0x64
	public object m_bAutoDestruct; // 0x68
	public object m_bLoop; // 0x69
	protected object m_fStartTime; // 0x6C
	protected object m_fElapsedRate; // 0x70
	protected object m_Transform; // 0x78
	protected object m_ColorName; // 0x80
	protected object m_MainMaterial; // 0x88
	protected object m_ChildColorNames; // 0x90
	protected object m_ChildRenderers; // 0x98
	protected object m_MainMeshFilter; // 0xA0
	protected object m_ChildMeshFilters; // 0xA8
	protected object m_NcUvAnimation; // 0xB0
	protected object m_vPosInit; // 0xB8
	protected object m_vScaleInit; // 0xC4
	protected object m_vTextureInit; // 0xD0
	protected object m_qtRotInit; // 0xD8

	// Methods

	// RVA: 0xF450BC
	public override object GetAnimationState() { }

	// RVA: 0xF45154
	public override object ResetAnimation() { }

	// RVA: 0xF46EA0
	public object GetRepeatedRate() { }

	// RVA: 0xF46EA8
	private object Awake() { }

	// RVA: 0xF46EAC
	private object _RecordInitParam() { }

	// RVA: 0xF472DC
	private object Start() { }

	// RVA: 0xF47558
	private object LateUpdate() { }

	// RVA: 0xF451CC
	private object InitAnimation(object isNeedReset) { }

	// RVA: 0xF45EBC
	private object UpdateAnimation(object fElapsedRate) { }

	// RVA: 0xF47974
	private object ChangeMeshColor(object mFilter, object tarColor) { }

	// RVA: 0xF47D54
	private object SetChildMaterialColor(object curveInfo, object fValue, object arrayIndex) { }

	// RVA: 0xF48208
	private object GetChildNextColorValue(object curveInfo, object nIndex, object fValue, object arrayIndex) { }

	// RVA: 0xF47BB4
	private object GetNextValue(object curveInfo, object nIndex, object fValue) { }

	// RVA: 0xF47C7C
	private object GetNextScale(object curveInfo, object nIndex, object fValue) { }

	// RVA: 0xF48320
	public object GetElapsedRate() { }

	// RVA: 0xF48328
	public object CopyTo(object target, object bCurveOnly) { }

	// RVA: 0xF4876C
	public object AppendTo(object target, object bCurveOnly) { }

	// RVA: 0xF48A18
	public object GetCurveInfo(object nIndex) { }

	// RVA: 0xF48AA8
	public object GetCurveInfo(object curveName) { }

	// RVA: 0xF48C20
	public object SetCurveInfo(object nIndex, object newInfo) { }

	// RVA: 0xF48D00
	public object AddCurveInfo() { }

	// RVA: 0xF48FCC
	public object AddCurveInfo(object addCurveInfo) { }

	// RVA: 0xF4916C
	public object DeleteCurveInfo(object nIndex) { }

	// RVA: 0xF49220
	public object ClearAllCurveInfo() { }

	// RVA: 0xF49290
	public object GetCurveInfoCount() { }

	// RVA: 0xF492E8
	public object SortCurveInfo() { }

	// RVA: 0xF495AC
	public object CheckInvalidOption() { }

	// RVA: 0xF49688
	public object CheckInvalidOption(object nSrcIndex) { }

	// RVA: 0xF4970C
	public override object OnUpdateEffectSpeed(object fSpeedRate, object bRuntime) { }

	// RVA: 0xF477EC
	public static object Ng_GetMaterialColorName(object mat) { }

	// RVA: 0xF49720
	public object .ctor() { }

}

// Namespace: 
public class NcDelayActive
{

	// Fields
	public object NotAvailable; // 0x38
	public object m_fDelayTime; // 0x40
	public object m_bActiveRecursively; // 0x44
	protected object m_fAliveTime; // 0x48
	public object m_fParentDelayTime; // 0x4C
	protected object m_bAddedInvoke; // 0x50
	protected object m_fStartedTime; // 0x54

	// Methods

	// RVA: 0xF4A594
	public object GetParentDelayTime(object bCheckStarted) { }

	// RVA: 0xF4A59C
	public object .ctor() { }

}

// Namespace: 
public enum TEXTURE_TYPE
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TileTexture;
	public const object TrimTexture;
	public const object SpriteFactory;
}

// Namespace: 
public enum PLAYMODE
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object DEFAULT;
	public const object INVERSE;
	public const object PINGPONG;
	public const object RANDOM;
	public const object SELECT;
}

// Namespace: 
public class NcSpriteAnimation
{

	// Fields
	public object m_TextureType; // 0x58
	public object m_PlayMode; // 0x5C
	public object m_fDelayTime; // 0x60
	public object m_nStartFrame; // 0x64
	public object m_nFrameCount; // 0x68
	public object m_nSelectFrame; // 0x6C
	public object m_bLoop; // 0x70
	public object m_nLoopStartFrame; // 0x74
	public object m_nLoopFrameCount; // 0x78
	public object m_nLoopingCount; // 0x7C
	public object m_bAutoDestruct; // 0x80
	public object m_fFps; // 0x84
	public object m_nTilingX; // 0x88
	public object m_nTilingY; // 0x8C
	protected object m_NcSpriteFactoryPrefab; // 0x90
	private object m_NcSpriteFactoryPrefabRenderer; // 0x98
	protected object m_NcSpriteFactoryCom; // 0xA0
	public object m_NcSpriteFrameInfos; // 0xA8
	public object m_fUvScale; // 0xB0
	public object m_nSpriteFactoryIndex; // 0xB4
	public object m_MeshType; // 0xB8
	public object m_AlignType; // 0xBC
	public object m_bTrimCenterAlign; // 0xC0
	protected object m_bCreateBuiltInPlane; // 0xC1
	public object m_bBuildSpriteObj; // 0xC2
	public object m_bNeedRebuildAlphaChannel; // 0xC3
	public object m_curveAlphaWeight; // 0xC8
	protected object m_size; // 0xD0
	protected object m_Renderer; // 0xD8
	protected object m_fStartTime; // 0xE0
	protected object m_nLastIndex; // 0xE4
	protected object m_nLastSeqIndex; // 0xE8
	protected object m_bInPartLoop; // 0xEC
	protected object m_bBreakLoop; // 0xED
	protected object m_MeshUVsByTileTexture; // 0xF0
	private object m_inited; // 0xF8
	private object m_gotten; // 0xF9
	private object m_enabled; // 0xFA

	// Properties
	public object NcSpriteFactoryPrefab { get; set; }

	// Methods

	// RVA: 0xF4A608
	public object set_NcSpriteFactoryPrefab(object value) { }

	// RVA: 0xF4A6E8
	public object get_NcSpriteFactoryPrefab() { }

	// RVA: 0xF4A6F0
	public override object GetAnimationState() { }

	// RVA: 0xF4A770
	public object GetDurationTime() { }

	// RVA: 0xF4A798
	public object GetShowIndex() { }

	// RVA: 0xF4A7A8
	public object SetBreakLoop() { }

	// RVA: 0xF4A7B4
	public object IsInPartLoop() { }

	// RVA: 0xF4A7BC
	public override object ResetAnimation() { }

	// RVA: 0xF4A8AC
	private object SetEnable(object bEnable) { }

	// RVA: 0xF4A980
	public object SetSelectFrame(object nSelFrame) { }

	// RVA: 0xF4AD1C
	public object IsEmptyFrame() { }

	// RVA: 0xF4AD70
	public object GetMaxFrameCount() { }

	// RVA: 0xF4ADA8
	public object GetValidFrameCount() { }

	// RVA: 0xF4ADF0
	public object OnCreate() { }

	// RVA: 0xF4B124
	public object OnPrepare() { }

	// RVA: 0xF4B128
	public object OnGet() { }

	// RVA: 0xF4B508
	public object OnRecycle() { }

	// RVA: 0xF4B510
	private object Awake() { }

	// RVA: 0xF4B434
	private object ResetLocalValue() { }

	// RVA: 0xF4A97C
	private object Start() { }

	// RVA: 0xF4B514
	private object Update() { }

	// RVA: 0xF4BCE0
	public object SetSpriteFactoryIndex(object nSpriteFactoryIndex, object bRunImmediate) { }

	// RVA: 0xF4C0A0
	private object GetPartLoopFrameIndex(object nSeqIndex) { }

	// RVA: 0xF4C0E8
	private object GetPartLoopCount(object nSeqIndex) { }

	// RVA: 0xF4C11C
	private object CalcPartLoopInfo(object nSeqIndex, object nLoopCount) { }

	// RVA: 0xF4BAD4
	private object UpdateEndAnimation() { }

	// RVA: 0xF4A988
	private object SetIndex(object nSeqIndex) { }

	// RVA: 0xF4CA34
	private object UpdateSpriteTexture(object nSelIndex, object bShowEffect) { }

	// RVA: 0xF4CA8C
	private object UpdateFactoryTexture(object nSelIndex, object bShowEffect) { }

	// RVA: 0xF4D140
	public object UpdateFactoryMaterial() { }

	// RVA: 0xF4CE98
	private object CreateBuiltInPlane(object nSelIndex) { }

	// RVA: 0xF4D074
	private object UpdateBuiltInPlane(object nSelIndex) { }

	// RVA: 0xF4C4DC
	private object UpdateMeshUVsByTileTexture(object uv) { }

	// RVA: 0xF4DDFC
	public override object OnUpdateEffectSpeed(object fSpeedRate, object bRuntime) { }

	// RVA: 0xF4DE18
	public object .ctor() { }

}

// Namespace: 
public class NcFrameInfo
{

	// Fields
	public object m_nFrameIndex; // 0x8
	public object m_bEmptyFrame; // 0xC
	public object m_nTexWidth; // 0x10
	public object m_nTexHeight; // 0x14
	public object m_TextureUvOffset; // 0x18
	public object m_FrameUvOffset; // 0x28
	public object m_FrameScale; // 0x38
	public object m_scaleFactor; // 0x40

	// Methods

	// RVA: 0xF4FEEC
	public object .ctor() { }

}

// Namespace: 
public class NcSpriteNode
{

	// Fields
	public object m_bIncludedAtlas; // 0x8
	public object m_TextureGUID; // 0x10
	public object m_TextureName; // 0x18
	public object m_fMaxTextureAlpha; // 0x20
	public object m_SpriteName; // 0x28
	public object m_FrameInfos; // 0x30
	public object m_nTilingX; // 0x38
	public object m_nTilingY; // 0x3C
	public object m_nStartFrame; // 0x40
	public object m_nFrameCount; // 0x44
	public object m_bLoop; // 0x48
	public object m_nLoopStartFrame; // 0x4C
	public object m_nLoopFrameCount; // 0x50
	public object m_nLoopingCount; // 0x54
	public object m_fFps; // 0x58
	public object m_fTime; // 0x5C
	public object m_nNextSpriteIndex; // 0x60
	public object m_nTestMode; // 0x64
	public object m_fTestSpeed; // 0x68
	public object m_bEffectInstantiate; // 0x6C
	public object m_EffectPrefab; // 0x70
	public object m_nEffectFrame; // 0x78
	public object m_bEffectOnlyFirst; // 0x7C
	public object m_bEffectDetach; // 0x7D
	public object m_fEffectSpeed; // 0x80
	public object m_fEffectScale; // 0x84
	public object m_EffectPos; // 0x88
	public object m_EffectRot; // 0x94
	public object m_AudioClip; // 0xA0
	public object m_nSoundFrame; // 0xA8
	public object m_bSoundOnlyFirst; // 0xAC
	public object m_bSoundLoop; // 0xAD
	public object m_fSoundVolume; // 0xB0
	public object m_fSoundPitch; // 0xB4

	// Methods

	// RVA: 0xF4E72C
	public object GetClone() { }

	// RVA: 0xF4FEF4
	public object GetStartFrame() { }

	// RVA: 0xF4FF40
	public object SetEmpty() { }

	// RVA: 0xF4F820
	public object IsEmptyTexture() { }

	// RVA: 0xF4DF54
	public object IsUnused() { }

	// RVA: 0xF4E458
	public object .ctor() { }

}

// Namespace: 
public enum MESH_TYPE
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BuiltIn_Plane;
	public const object BuiltIn_TwosidePlane;
}

// Namespace: 
public enum ALIGN_TYPE
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object TOP;
	public const object CENTER;
	public const object BOTTOM;
}

// Namespace: 
public enum SPRITE_TYPE
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NcSpriteTexture;
	public const object NcSpriteAnimation;
}

// Namespace: 
public enum SHOW_TYPE
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NONE;
	public const object ALL;
	public const object SPRITE;
	public const object ANIMATION;
	public const object EFFECT;
}

// Namespace: 
public class NcSpriteFactory
{

	// Fields
	public object m_SpriteType; // 0x38
	public object m_SpriteList; // 0x40
	public object m_nCurrentIndex; // 0x48
	public object m_nMaxAtlasTextureSize; // 0x4C
	public object m_bNeedRebuild; // 0x50
	public object m_nBuildStartIndex; // 0x54
	public object m_bTrimBlack; // 0x58
	public object m_bTrimAlpha; // 0x59
	public object m_fUvScale; // 0x5C
	public object m_fTextureRatio; // 0x60
	public object m_CurrentEffect; // 0x68
	protected object m_bEndSprite; // 0x70
	public object m_ShowType; // 0x74
	public object m_bShowEffect; // 0x78
	public object m_bTestMode; // 0x79
	public object m_bSequenceMode; // 0x7A
	protected object m_bbInstance; // 0x7B

	// Methods

	// RVA: 0xF4DEAC
	public object IsUnused(object nNodeIndex) { }

	// RVA: 0xF4C010
	public object GetSpriteNode(object nIndex) { }

	// RVA: 0xF4DF64
	public object GetSpriteNode(object spriteName) { }

	// RVA: 0xF4E11C
	public object GetSpriteNodeIndex(object spriteName) { }

	// RVA: 0xF4E1E0
	public object SetSpriteNode(object nIndex, object newInfo) { }

	// RVA: 0xF4E2C0
	public object AddSpriteNode() { }

	// RVA: 0xF4E57C
	public object AddSpriteNode(object addSpriteNode) { }

	// RVA: 0xF4E734
	public object DeleteSpriteNode(object nIndex) { }

	// RVA: 0xF4E7F0
	public object MoveSpriteNode(object nSrcIndex, object nTarIndex) { }

	// RVA: 0xF4E8D0
	public object ClearAllSpriteNode() { }

	// RVA: 0xF4D4BC
	public object GetSpriteNodeCount() { }

	// RVA: 0xF4E948
	public object GetCurrentSpriteNode() { }

	// RVA: 0xF4E9C4
	public object GetSpriteUvRect(object nStriteIndex, object nFrameIndex) { }

	// RVA: 0xF4D4AC
	public object IsValidFactory() { }

	// RVA: 0xF4EB6C
	private object Awake() { }

	// RVA: 0xF4EB78
	public object SetSprite(object nNodeIndex) { }

	// RVA: 0xF4EE40
	public object SetSprite(object spriteName) { }

	// RVA: 0xF4EB80
	public object SetSprite(object nNodeIndex, object bRunImmediate) { }

	// RVA: 0xF4F6B0
	public object GetCurrentSpriteIndex() { }

	// RVA: 0xF4F6B8
	public object IsEndSprite() { }

	// RVA: 0xF4F374
	private object CreateEffectObject() { }

	// RVA: 0xF4F948
	public object CreateSpriteEffect(object nSrcSpriteIndex, object parentTrans) { }

	// RVA: 0xF4F878
	private object DestroyEffectObject() { }

	// RVA: 0xF4FDF4
	private object CreateSoundObject(object ncSpriteNode) { }

	// RVA: 0xF4EFD0
	public object OnChangingSprite(object nOldNodeIndex, object nNewNodeIndex) { }

	// RVA: 0xF4B844
	public object OnAnimationStartFrame(object spriteCom) { }

	// RVA: 0xF4CB0C
	public object OnAnimationChangingFrame(object spriteCom, object nOldIndex, object nNewIndex, object nLoopCount) { }

	// RVA: 0xF4B848
	public object OnAnimationLastFrame(object spriteCom, object nLoopCount) { }

	// RVA: 0xF4FE90
	public override object OnUpdateEffectSpeed(object fSpeedRate, object bRuntime) { }

	// RVA: 0xF4D514
	public static object CreatePlane(object meshFilter, object fUvScale, object ncSpriteFrameInfo, object bTrimCenterAlign, object alignType, object m_MeshType) { }

	// RVA: 0xF4DB14
	public static object UpdatePlane(object meshFilter, object fUvScale, object ncSpriteFrameInfo, object bTrimCenterAlign, object alignType) { }

	// RVA: 0xF4DD00
	public static object UpdateMeshUVs(object meshFilter, object uv) { }

	// RVA: 0xF4FE94
	public object .ctor() { }

}

// Namespace: 
public class NcSpriteTexture
{

	// Fields
	public object m_NcSpriteFactoryPrefab; // 0x38
	protected object m_NcSpriteFactoryCom; // 0x40
	public object m_NcSpriteFrameInfos; // 0x48
	public object m_fUvScale; // 0x50
	public object m_nSpriteFactoryIndex; // 0x54
	public object m_nFrameIndex; // 0x58
	public object m_MeshType; // 0x5C
	public object m_AlignType; // 0x60
	protected object m_EffectObject; // 0x68

	// Methods

	// RVA: 0xF4FF98
	private object Awake() { }

	// RVA: 0xF501BC
	private object Start() { }

	// RVA: 0xF4F0A4
	public object SetSpriteFactoryIndex(object nSpriteFactoryIndex, object nFrameIndex, object bRunImmediate) { }

	// RVA: 0xF501C4
	private object UpdateSpriteTexture(object bShowEffect) { }

	// RVA: 0xF50454
	public object UpdateSpriteMaterial() { }

	// RVA: 0xF507D4
	public override object OnUpdateEffectSpeed(object fSpeedRate, object bRuntime) { }

	// RVA: 0xF507D8
	public override object OnUpdateToolData() { }

	// RVA: 0xF507DC
	public object .ctor() { }

}

// Namespace: 
public class NcUvAnimation
{

	// Fields
	public object m_fScrollSpeedX; // 0x58
	public object m_fScrollSpeedY; // 0x5C
	public object m_fTilingX; // 0x60
	public object m_fTilingY; // 0x64
	public object m_fOffsetX; // 0x68
	public object m_fOffsetY; // 0x6C
	public object m_bUseSmoothDeltaTime; // 0x70
	public object m_bFixedTileSize; // 0x71
	public object m_bRepeat; // 0x72
	public object m_bAutoDestruct; // 0x73
	protected object m_OriginalScale; // 0x74
	protected object m_OriginalTiling; // 0x80
	protected object m_EndOffset; // 0x88
	protected object m_RepeatOffset; // 0x90
	protected object m_Renderer; // 0x98
	protected object m_RendererLike; // 0xA0
	protected object m_Material; // 0xB0
	private object m_inited; // 0xB8
	private object m_gotten; // 0xB9
	private object <ExternalMaterial>k__BackingField; // 0xBA
	protected object m_rendererLike; // 0xC0

	// Properties
	public object Mat { get; set; }
	public object ExternalMaterial { get; set; }

	// Methods

	// RVA: 0xF50814
	public object get_Mat() { }

	// RVA: 0xF5081C
	public object set_Mat(object value) { }

	// RVA: 0xF50824
	public object get_ExternalMaterial() { }

	// RVA: 0xF5082C
	public object set_ExternalMaterial(object value) { }

	// RVA: 0xF50834
	public object SetFixedTileSize(object bFixedTileSize) { }

	// RVA: 0xF5083C
	public override object GetAnimationState() { }

	// RVA: 0xF50894
	public override object ResetAnimation() { }

	// RVA: 0xF50970
	protected object GetRendererLike() { }

	// RVA: 0xF50AA8
	private object ResetRenderer() { }

	// RVA: 0xF50AEC
	public object OnCreate() { }

	// RVA: 0xF50CD8
	public object OnPrepare() { }

	// RVA: 0xF50CDC
	public object OnGet() { }

	// RVA: 0xF50D54
	public object OnRecycle() { }

	// RVA: 0xF508D0
	private object Start() { }

	// RVA: 0xF50D5C
	private object Update() { }

	// RVA: 0xF51394
	public override object OnUpdateEffectSpeed(object fSpeedRate, object bRuntime) { }

	// RVA: 0xF513A4
	public override object OnUpdateToolData() { }

	// RVA: 0xF513F0
	public object .ctor() { }

}

// Namespace: 
public class FXMakerGrayscaleEffect
{

	// Fields
	public object textureRamp; // 0x28
	public object rampOffset; // 0x30

	// Methods

	// RVA: 0xF51468
	private object OnRenderImage(object source, object destination) { }

	// RVA: 0xF51664
	public object .ctor() { }

}

// Namespace: 
public class FXMakerImageEffectBase
{

	// Fields
	public object shader; // 0x18
	private object m_Material; // 0x20

	// Properties
	protected object material { get; }

	// Methods

	// RVA: 0xF51674
	protected object Start() { }

	// RVA: 0xF51560
	protected object get_material() { }

	// RVA: 0xF51788
	protected object OnDisable() { }

	// RVA: 0xF5166C
	public object .ctor() { }

}

// Namespace: 
public class CameraFovFixed
{

	// Fields
	public object cam; // 0x18
	public object fieldOfView; // 0x20
	public object axis; // 0x24
	private object halfWidth; // 0x30

	// Methods

	// RVA: 0xF518A4
	private object Start() { }

	// RVA: 0xF51A4C
	private object OnValidate() { }

	// RVA: 0xF51AC0
	private object LateUpdate() { }

	// RVA: 0xF51C78
	public object .ctor() { }

}

// Namespace: 
public class RandomRotation
{

	// Fields
	public object rotationMaxX; // 0x18
	public object rotationMaxY; // 0x1C
	public object rotationMaxZ; // 0x20

	// Methods

	// RVA: 0xF51C8C
	private object Update() { }

	// RVA: 0xF51D20
	public object OnCreate() { }

	// RVA: 0xF51D24
	public object OnPrepare() { }

	// RVA: 0xF51D28
	public object OnGet() { }

	// RVA: 0xF51D2C
	public object OnRecycle() { }

	// RVA: 0xF51D30
	public object .ctor() { }

}

// Namespace: 
public class RandomScale
{

	// Fields
	private object bGetted; // 0x18
	public object minScale; // 0x1C
	public object maxScale; // 0x20

	// Methods

	// RVA: 0xF51D40
	private object Start() { }

	// RVA: 0xF51E40
	public object OnCreate() { }

	// RVA: 0xF51E44
	public object OnPrepare() { }

	// RVA: 0xF51DC0
	public object OnGet() { }

	// RVA: 0xF51E48
	public object OnRecycle() { }

	// RVA: 0xF51E50
	public object .ctor() { }

}

// Namespace: 
public class RotateThis
{

	// Fields
	public object rotationSpeedX; // 0x18
	public object rotationSpeedY; // 0x1C
	public object rotationSpeedZ; // 0x20

	// Methods

	// RVA: 0xF51E64
	private object Update() { }

	// RVA: 0xF51EF8
	public object OnCreate() { }

	// RVA: 0xF51EFC
	public object OnPrepare() { }

	// RVA: 0xF51F00
	public object OnGet() { }

	// RVA: 0xF51F04
	public object OnRecycle() { }

	// RVA: 0xF51F08
	public object .ctor() { }

}

// Namespace: 
public class WorldSpaceBillboard
{

	// Fields
	private object trans_; // 0x18
	private object cameraTrans_; // 0x20
	private object forward; // 0x28
	public object DisableFollowCamera; // 0x34
	public object OnCameraY; // 0x35
	private object justEnable; // 0x36
	public object LookAtCamera; // 0x37

	// Methods

	// RVA: 0xF51F18
	protected object Awake() { }

	// RVA: 0xF51F68
	protected object OnEnable() { }

	// RVA: 0xF51F74
	private object OnDisable() { }

	// RVA: 0xF51F78
	public object SetCameraTransform(object customCameraTrans) { }

	// RVA: 0xF51F80
	public object LateUpdate() { }

	// RVA: 0xF51F5C
	private object UpdateCamera(object Enable) { }

	// RVA: 0xF51FCC
	public object LookCamera() { }

	// RVA: 0xF52240
	public static object HandleCustomScript(object particleGameObject, object _3DImageCamera) { }

	// RVA: 0xF52308
	public object .ctor() { }

}

// Namespace: 
public class TrailPoolHelper
{

	// Methods

	// RVA: 0xF52310
	public object .ctor() { }

}

// Namespace: 
public class TrailReset
{

	// Methods

	// RVA: 0xF52318
	public object .ctor() { }

}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0xF52320
	private static object Get() { }

	// RVA: 0xF523F0
	public object .ctor() { }

}

// Namespace: PMSceneProfilerHelper.M
public class ScenePerformanceComponent
{

	// Fields
	private object mStandardSceneDrawCall; // 0x18
	private object mStandardSceneTris; // 0x1C
	private object mStandardSceneVerts; // 0x20
	private object mIfergodic; // 0x24
	private object mIfwait; // 0x25
	private object mIfwaitSecond; // 0x26
	private object mIfReplaceMaterial; // 0x27
	private object mSecondIfergodic; // 0x28
	private object mMainCameraRef; // 0x30
	private object mCameraControl; // 0x38
	private object mIfPicture; // 0x39
	private object mMbounds; // 0x3C
	public object SIfStandard; // 0x54
	public object CameraPosition; // 0x58
	public object TheAreaNumber; // 0x60
	public object TheNumber; // 0x68
	private object mIndexTwo; // 0x6C
	private object mIndex; // 0x70
	private object mLvNumnber; // 0x74
	private object m1; // 0x78
	private object m2; // 0x84
	private object m3; // 0x90
	private object m4; // 0x9C
	private object mTLogList; // 0xA8
	private object mTLogListLast; // 0xB0

	// Methods

	// RVA: 0xF5252C
	public object .ctor() { }

}

// Namespace: MainThread.RenderingModule.SceneProfile
public class ReplaceShader
{

	// Fields
	private static object sN; // 0x0

	// Methods

	// RVA: 0xF52674
	public object .ctor() { }

}

// Namespace: MainThread.RenderingModule.SceneProfile
internal class WriteInExcel
{

	// Fields
	public static object ExcelName; // 0x0

	// Methods

	// RVA: 0xF5267C
	public object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Generic
public class VersionInformation
{

	// Fields
	public object Name; // 0x8
	public object Major; // 0x10
	public object Minor; // 0x14
	public object Patch; // 0x18

	// Methods

	// RVA: 0xF52684
	public object .ctor(object name, object major, object minor, object patch) { }

	// RVA: 0xF526DC
	public override object ToString() { }

	// RVA: 0xF52880
	public object Match(object other, object looseMatch) { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class SmokePlume
{

	// Fields
	public object TimeBetweenPoints; // 0x88
	public object ConstantForce; // 0x8C
	public object RandomForceScale; // 0x98
	public object MaxNumberOfPoints; // 0x9C
	public object HostTransform; // 0xA0
	private object _timeSincePoint; // 0xA8

	// Methods

	// RVA: 0xF52948
	protected object OnEnable() { }

	// RVA: 0xF52980
	protected override object OnStartEmit() { }

	// RVA: 0xF52988
	protected override object Reset() { }

	// RVA: 0xF52BB0
	protected override object Update() { }

	// RVA: 0xF52C88
	protected override object InitialiseNewPoint(object newPoint) { }

	// RVA: 0xF52D3C
	protected override object UpdateTrail(object trail, object deltaTime) { }

	// RVA: 0xF530F0
	protected override object GetMaxNumberOfPoints() { }

	// RVA: 0xF530F8
	public object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class SmokeTrail
{

	// Fields
	public object MinVertexDistance; // 0x88
	public object MaxNumberOfPoints; // 0x8C
	private object _lastPosition; // 0x90
	private object _distanceMoved; // 0x9C
	public object RandomForceScale; // 0xA0

	// Methods

	// RVA: 0xF53194
	protected object OnEnable() { }

	// RVA: 0xF531EC
	protected override object Update() { }

	// RVA: 0xF53380
	protected override object OnStartEmit() { }

	// RVA: 0xF533C4
	protected override object Reset() { }

	// RVA: 0xF533FC
	protected override object InitialiseNewPoint(object newPoint) { }

	// RVA: 0xF534B0
	protected override object OnTranslate(object t) { }

	// RVA: 0xF534D0
	protected override object GetMaxNumberOfPoints() { }

	// RVA: 0xF534D8
	public object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class SmokeTrailPoint
{

	// Fields
	public object RandomVec; // 0x2C

	// Methods

	// RVA: 0xF534F8
	public override object Update(object deltaTime) { }

	// RVA: 0xF52C80
	public object .ctor() { }

}

// Namespace: 
private class ControlPoint
{

	// Fields
	public object p; // 0x8
	public object forward; // 0x14

	// Methods

	// RVA: 0xF557EC
	public object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class SmoothSmokePlume
{

	// Fields
	public object MaxControlPoints; // 0x88
	public object PointsBetweenControlPoints; // 0x8C
	public object ConstantForce; // 0x90
	public object RandomForceScale; // 0x9C
	public object TimeBetweenPoints; // 0xA0
	public object MaxDistance; // 0xA4
	public object HostTransform; // 0xA8
	private object _controlPoints; // 0xB0
	private object _trailPointsCache; // 0xB8
	private object _trailPointID; // 0xC0
	private object _controlPointsCache; // 0xC8
	private object _controlPointID; // 0xD0
	private object _timeSincePoint; // 0xD4
	private object _prePosition; // 0xD8
	private object _hideLayer; // 0xE4

	// Methods

	// RVA: 0xF53554
	protected object OnEnable() { }

	// RVA: 0xF536A8
	protected override object Update() { }

	// RVA: 0xF53FE0
	protected override object hasMove() { }

	// RVA: 0xF53FE8
	protected override object InitialiseNewPoint(object newPoint) { }

	// RVA: 0xF5409C
	protected override object OnStartEmit() { }

	// RVA: 0xF542A0
	private object GetCacheSmokePoint() { }

	// RVA: 0xF5430C
	private object GetCacheControlPoint() { }

	// RVA: 0xF538C8
	private object InitControlPoints() { }

	// RVA: 0xF54364
	protected override object UpdateTrail(object trail, object deltaTime) { }

	// RVA: 0xF55434
	protected override object Reset() { }

	// RVA: 0xF55658
	protected override object OnTranslate(object t) { }

	// RVA: 0xF53C64
	private object AddControlPoint(object position) { }

	// RVA: 0xF55744
	protected override object GetMaxNumberOfPoints() { }

	// RVA: 0xF552B0
	public object GetPointAlongCurve(object curveStart, object curveStartHandle, object curveEnd, object curveEndHandle, object t, object crease) { }

	// RVA: 0xF55750
	public object .ctor() { }

}

// Namespace: 
private class ControlPoint
{

	// Fields
	public object p; // 0x8
	public object forward; // 0x14

	// Methods

	// RVA: 0xF56B8C
	public object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class SmoothTrail
{

	// Fields
	public object MinControlPointDistance; // 0x88
	public object MaxControlPoints; // 0x8C
	public object PointsBetweenControlPoints; // 0x90
	private object _lastPosition; // 0x94
	private object _distanceMoved; // 0xA0
	private object _controlPoints; // 0xA8

	// Methods

	// RVA: 0xF557F4
	protected object OnEnable() { }

	// RVA: 0xF5592C
	protected override object Update() { }

	// RVA: 0xF567E8
	protected override object OnStartEmit() { }

	// RVA: 0xF56FF4
	protected override object UpdateTrail(object trail, object deltaTime) { }

	// RVA: 0xF57F30
	protected override object Reset() { }

	// RVA: 0xF58198
	protected override object OnTranslate(object t) { }

	// RVA: 0xF55D78
	private object AddControlPoint(object position) { }

	// RVA: 0xF5829C
	protected override object GetMaxNumberOfPoints() { }

	// RVA: 0xF57DAC
	public object GetPointAlongCurve(object curveStart, object curveStartHandle, object curveEnd, object curveEndHandle, object t, object crease) { }

	// RVA: 0xF582A8
	public object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class Trail
{

	// Fields
	public object MinVertexDistance; // 0x88
	public object MaxNumberOfPoints; // 0x8C
	private object _lastPosition; // 0x90
	private object _distanceMoved; // 0x9C
	private object _hideLayer; // 0xA0

	// Methods

	// RVA: 0xF582F8
	public object OnEnable() { }

	// RVA: 0xF583A0
	protected override object Update() { }

	// RVA: 0xF5852C
	protected override object UpdateTrail(object trail, object deltaTime) { }

	// RVA: 0xF5862C
	protected override object OnStartEmit() { }

	// RVA: 0xF58670
	protected override object Reset() { }

	// RVA: 0xF5869C
	protected override object OnTranslate(object t) { }

	// RVA: 0xF586BC
	protected override object GetMaxNumberOfPoints() { }

	// RVA: 0xF586C4
	public object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public abstract class TrailRenderer_Base
{

	// Fields
	public object TrailData; // 0x18
	private object _activeTrail; // 0x20
	private object _fadingTrails; // 0x28
	protected object _t; // 0x30
	public object Emit; // 0x38
	public object OptStaticMesh; // 0x39
	private object regenerateFrameCount; // 0x3C
	protected object _emit; // 0x40
	protected object _noDecay; // 0x41
	private object _matToTrailList; // 0x48
	private object _toClean; // 0x50
	private object _hasRenderer; // 0x58
	private object GlobalTrailRendererCount; // 0x5C
	private object prevPosition; // 0x60
	private object prevRot; // 0x6C
	public object distDelta; // 0x7C
	public object angleDelta; // 0x80
	protected object changeRegenerateFrameCount; // 0x84

	// Methods

	// RVA: 0xF586F0
	protected virtual object Awake() { }

	// RVA: 0xF5583C
	protected virtual object Start() { }

	// RVA: 0xF58A4C
	protected virtual object LateUpdate() { }

	// RVA: 0xF5608C
	protected virtual object Update() { }

	// RVA: 0xF5A160
	private static object GetGameObjectPath(object transform) { }

	// RVA: 0xF59D30
	protected object AnyElement(object InPoints) { }

	// RVA: 0xF5A260
	protected virtual object OnDestroy() { }

	// RVA: 0xF5A500
	protected virtual object OnStopEmit() { }

	// RVA: 0xF5A504
	protected virtual object OnStartEmit() { }

	// RVA: 0xF5A508
	protected virtual object OnTranslate(object t) { }

	// RVA: -1
	protected abstract object GetMaxNumberOfPoints() { }

	// RVA: 0xF57F68
	protected virtual object Reset() { }

	// RVA: 0xF5A580
	protected virtual object InitialiseNewPoint(object newPoint) { }

	// RVA: 0xF5A584
	protected virtual object UpdateTrail(object trail, object deltaTime) { }

	// RVA: 0xF56B9C
	protected object AddPoint(object newPoint, object pos) { }

	// RVA: 0xF5A588
	protected virtual object hasMove() { }

	// RVA: 0xF58FE0
	private object GenerateMesh(object trail) { }

	// RVA: 0xF58D80
	private object DrawMesh(object trailMesh, object trailMaterial) { }

	// RVA: 0xF58EC4
	private object UpdatePoints(object line, object deltaTime) { }

	// RVA: 0xF5A824
	protected virtual object UpdatePoint(object pCTrailPoint, object deltaTime) { }

	// RVA: 0xF59F6C
	private object CheckEmitChange() { }

	// RVA: 0xF5A738
	private object NumberOfActivePoints(object line) { }

	// RVA: 0xF5A828
	protected object ToggleSizeInputStyle() { }

	// RVA: 0xF5A854
	protected object ToggleColorInputStyle() { }

	// RVA: 0xF5A880
	public object LifeDecayEnabled(object enabled) { }

	// RVA: 0xF5A88C
	public object Translate(object t) { }

	// RVA: 0xF5AA9C
	public object CreateTrail(object from, object to, object distanceBetweenPoints) { }

	// RVA: 0xF55840
	public object ClearSystem(object emitState) { }

	// RVA: 0xF5AFA8
	public object ClearTrail() { }

	// RVA: 0xF5B00C
	public object NumSegments() { }

	// RVA: 0xF582DC
	protected object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class PCTrail
{

	// Fields
	public object Points; // 0x8
	public object Mesh; // 0x10
	public object verticies; // 0x18
	public object normals; // 0x20
	public object uvs; // 0x28
	public object colors; // 0x30
	public object indicies; // 0x38
	public object activePointCount; // 0x40
	public object IsActiveTrail; // 0x44
	public object IsHide; // 0x45
	public object NumPoints; // 0x48

	// Methods

	// RVA: 0xF588B4
	public object .ctor(object numPoints) { }

	// RVA: 0xF59E08
	public object Dispose() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class PCTrailPoint
{

	// Fields
	public object Forward; // 0x8
	public object Position; // 0x14
	public object PointNumber; // 0x20
	private object _timeActive; // 0x24
	private object _distance; // 0x28

	// Methods

	// RVA: 0xF5B06C
	public virtual object Update(object deltaTime) { }

	// RVA: 0xF5B07C
	public object TimeActive() { }

	// RVA: 0xF5B084
	public object SetTimeActive(object time) { }

	// RVA: 0xF5B08C
	public object SetDistanceFromStart(object distance) { }

	// RVA: 0xF5B094
	public object GetDistanceFromStart() { }

	// RVA: 0xF56B94
	public object .ctor() { }

}

// Namespace: PigeonCoopToolkit.Effects.Trails
public class PCTrailRendererData
{

	// Fields
	public object TrailMaterial; // 0x8
	public object Lifetime; // 0x10
	public object UsingSimpleSize; // 0x14
	public object SimpleSizeOverLifeStart; // 0x18
	public object SimpleSizeOverLifeEnd; // 0x1C
	public object SizeOverLife; // 0x20
	public object UsingSimpleColor; // 0x28
	public object SimpleColorOverLifeStart; // 0x2C
	public object SimpleColorOverLifeEnd; // 0x3C
	public object ColorOverLife; // 0x50
	public object StretchSizeToFit; // 0x58
	public object StretchColorToFit; // 0x59
	public object MaterialTileLength; // 0x5C
	public object UseForwardOverride; // 0x60
	public object ForwardOverride; // 0x64
	public object ForwardOverrideRelative; // 0x70

	// Methods

	// RVA: 0xF5A50C
	public object .ctor() { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=1456
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=2287
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 2E97792B9A1AC170770EB84789C679BAD4F0F5944507EC0741B7EA591195EA92; // 0x0
	internal static readonly object CCB62FC7146E675C577DA7A3589C94A578D011E515B95631D958043449712EB0; // 0x5B0
}

