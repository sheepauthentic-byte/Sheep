// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
internal sealed class AssetFileNameExtensionAttribute
{

	// Fields
	private readonly object <preferredExtension>k__BackingField; // 0x8
	private readonly object <otherExtensions>k__BackingField; // 0x10

	// Methods

	// RVA: 0x74980B4
	public object .ctor(object preferredExtension, object otherExtensions) { }

}

// Namespace: UnityEngine
internal class ThreadAndSerializationSafeAttribute
{

	// Methods

	// RVA: 0x74980EC
	public object .ctor() { }

}

// Namespace: UnityEngine
internal class WritableAttribute
{

	// Methods

	// RVA: 0x74980F4
	public object .ctor() { }

}

// Namespace: UnityEngine
internal class RejectDragAndDropMaterial
{

	// Methods

	// RVA: 0x74980FC
	public object .ctor() { }

}

// Namespace: UnityEngine
internal class UnityEngineModuleAssembly
{

	// Methods

	// RVA: 0x7498104
	public object .ctor() { }

}

// Namespace: UnityEngine
internal sealed class NativeClassAttribute
{

	// Fields
	private object <QualifiedNativeName>k__BackingField; // 0x8
	private object <Declaration>k__BackingField; // 0x10

	// Properties
	private object QualifiedNativeName { set; }
	private object Declaration { set; }

	// Methods

	// RVA: 0x749810C
	private object set_QualifiedNativeName(object value) { }

	// RVA: 0x7498114
	private object set_Declaration(object value) { }

	// RVA: 0x749811C
	public object .ctor(object qualifiedCppName) { }

	// RVA: 0x7498190
	public object .ctor(object qualifiedCppName, object declaration) { }

}

// Namespace: UnityEngine
internal sealed class UnityString
{

	// Methods

	// RVA: 0x74981C8
	public static object Format(object fmt, object args) { }

}

// Namespace: UnityEngine.Bindings
internal class VisibleToOtherModulesAttribute
{

	// Methods

	// RVA: 0x7498294
	public object .ctor() { }

	// RVA: 0x749829C
	public object .ctor(object modules) { }

}

// Namespace: UnityEngine.Bindings
internal class NativeConditionalAttribute
{

	// Fields
	private object <Condition>k__BackingField; // 0x8
	private object <StubReturnStatement>k__BackingField; // 0x10
	private object <Enabled>k__BackingField; // 0x18

	// Properties
	public object Condition { set; }
	public object StubReturnStatement { set; }
	public object Enabled { set; }

	// Methods

	// RVA: 0x74982A4
	public object set_Condition(object value) { }

	// RVA: 0x74982AC
	public object set_StubReturnStatement(object value) { }

	// RVA: 0x74982B4
	public object set_Enabled(object value) { }

	// RVA: 0x74982BC
	public object .ctor(object condition) { }

	// RVA: 0x74982F0
	public object .ctor(object condition, object stubReturnStatement) { }

}

// Namespace: UnityEngine.Bindings
internal class NativeHeaderAttribute
{

	// Fields
	private object <Header>k__BackingField; // 0x8

	// Properties
	public object Header { set; }

	// Methods

	// RVA: 0x7498330
	public object set_Header(object value) { }

	// RVA: 0x7498338
	public object .ctor() { }

	// RVA: 0x7498340
	public object .ctor(object header) { }

}

// Namespace: UnityEngine.Bindings
internal class NativeNameAttribute
{

	// Fields
	private object <Name>k__BackingField; // 0x8

	// Properties
	public object Name { set; }

	// Methods

	// RVA: 0x749845C
	public object set_Name(object value) { }

	// RVA: 0x7498464
	public object .ctor(object name) { }

}

// Namespace: UnityEngine.Bindings
internal sealed class NativeWritableSelfAttribute
{

	// Fields
	private object <WritableSelf>k__BackingField; // 0x8

	// Properties
	public object WritableSelf { set; }

	// Methods

	// RVA: 0x7498580
	public object set_WritableSelf(object value) { }

	// RVA: 0x7498588
	public object .ctor() { }

}

// Namespace: UnityEngine.Bindings
internal class NativeMethodAttribute
{

	// Fields
	private object <Name>k__BackingField; // 0x8
	private object <IsThreadSafe>k__BackingField; // 0x10
	private object <IsFreeFunction>k__BackingField; // 0x11
	private object <ThrowsException>k__BackingField; // 0x12
	private object <HasExplicitThis>k__BackingField; // 0x13

	// Properties
	public object Name { set; }
	public object IsThreadSafe { set; }
	public object IsFreeFunction { set; }
	public object ThrowsException { set; }
	public object HasExplicitThis { set; }

	// Methods

	// RVA: 0x74985B4
	public object set_Name(object value) { }

	// RVA: 0x74985BC
	public object set_IsThreadSafe(object value) { }

	// RVA: 0x74985C4
	public object set_IsFreeFunction(object value) { }

	// RVA: 0x74985CC
	public object set_ThrowsException(object value) { }

	// RVA: 0x74985D4
	public object set_HasExplicitThis(object value) { }

	// RVA: 0x74985DC
	public object .ctor() { }

	// RVA: 0x74985E4
	public object .ctor(object name) { }

	// RVA: 0x7498700
	public object .ctor(object name, object isFreeFunction) { }

	// RVA: 0x7498728
	public object .ctor(object name, object isFreeFunction, object isThreadSafe) { }

}

// Namespace: UnityEngine.Bindings
internal enum TargetType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Function;
	public const object Field;
}

// Namespace: UnityEngine.Bindings
internal class NativePropertyAttribute
{

	// Fields
	private object <TargetType>k__BackingField; // 0x14

	// Properties
	public object TargetType { set; }

	// Methods

	// RVA: 0x7498760
	public object set_TargetType(object value) { }

	// RVA: 0x7498768
	public object .ctor() { }

	// RVA: 0x7498770
	public object .ctor(object name) { }

	// RVA: 0x7498774
	public object .ctor(object name, object isFree, object targetType) { }

	// RVA: 0x74987AC
	public object .ctor(object name, object isFree, object targetType, object isThreadSafe) { }

}

// Namespace: UnityEngine.Bindings
internal enum CodegenOptions
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object Custom;
	public const object Force;
}

// Namespace: UnityEngine.Bindings
internal class NativeAsStructAttribute
{

	// Methods

	// RVA: 0x74987EC
	public object .ctor() { }

}

// Namespace: UnityEngine.Bindings
internal class NativeTypeAttribute
{

	// Fields
	private object <Header>k__BackingField; // 0x8
	private object <IntermediateScriptingStructName>k__BackingField; // 0x10
	private object <CodegenOptions>k__BackingField; // 0x18

	// Properties
	public object Header { set; }
	public object IntermediateScriptingStructName { set; }
	public object CodegenOptions { set; }

	// Methods

	// RVA: 0x74987F4
	public object set_Header(object value) { }

	// RVA: 0x74987FC
	public object set_IntermediateScriptingStructName(object value) { }

	// RVA: 0x7498804
	public object set_CodegenOptions(object value) { }

	// RVA: 0x749880C
	public object .ctor() { }

	// RVA: 0x7498834
	public object .ctor(object codegenOptions) { }

	// RVA: 0x7498860
	public object .ctor(object header) { }

	// RVA: 0x7498980
	public object .ctor(object codegenOptions, object intermediateStructName) { }

}

// Namespace: UnityEngine.Bindings
internal class NotNullAttribute
{

	// Fields
	private object <Exception>k__BackingField; // 0x8

	// Properties
	public object Exception { set; }

	// Methods

	// RVA: 0x74989BC
	public object set_Exception(object value) { }

	// RVA: 0x74989C4
	public object .ctor(object exception) { }

}

// Namespace: UnityEngine.Bindings
internal class UnmarshalledAttribute
{

	// Methods

	// RVA: 0x74989F0
	public object .ctor() { }

}

// Namespace: UnityEngine.Bindings
internal class FreeFunctionAttribute
{

	// Methods

	// RVA: 0x74989F8
	public object .ctor() { }

	// RVA: 0x7498A24
	public object .ctor(object name) { }

	// RVA: 0x7498A4C
	public object .ctor(object name, object isThreadSafe) { }

}

// Namespace: UnityEngine.Bindings
internal class ThreadSafeAttribute
{

	// Methods

	// RVA: 0x7498A7C
	public object .ctor() { }

}

// Namespace: UnityEngine.Bindings
internal enum StaticAccessorType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Dot;
	public const object Arrow;
	public const object DoubleColon;
	public const object ArrowWithDefaultReturnIfNull;
}

// Namespace: UnityEngine.Bindings
internal class StaticAccessorAttribute
{

	// Fields
	private object <Name>k__BackingField; // 0x8
	private object <Type>k__BackingField; // 0x10

	// Properties
	public object Name { set; }
	public object Type { set; }

	// Methods

	// RVA: 0x7498AA8
	public object set_Name(object value) { }

	// RVA: 0x7498AB0
	public object set_Type(object value) { }

	// RVA: 0x7498AB8
	internal object .ctor(object name) { }

	// RVA: 0x7498AE4
	public object .ctor(object name, object type) { }

}

// Namespace: UnityEngine.Bindings
internal class NativeThrowsAttribute
{

	// Fields
	private object <ThrowsException>k__BackingField; // 0x8

	// Properties
	public object ThrowsException { set; }

	// Methods

	// RVA: 0x7498B20
	public object set_ThrowsException(object value) { }

	// RVA: 0x7498B28
	public object .ctor() { }

}

// Namespace: UnityEngine.Bindings
internal class IgnoreAttribute
{

	// Fields
	private object <DoesNotContributeToSize>k__BackingField; // 0x8

	// Properties
	public object DoesNotContributeToSize { set; }

	// Methods

	// RVA: 0x7498B54
	public object set_DoesNotContributeToSize(object value) { }

	// RVA: 0x7498B5C
	public object .ctor() { }

}

// Namespace: UnityEngine.Bindings
internal class PreventReadOnlyInstanceModificationAttribute
{

	// Methods

	// RVA: 0x7498B64
	public object .ctor() { }

}

// Namespace: UnityEngine.Scripting
internal class UsedByNativeCodeAttribute
{

	// Fields
	private object <Name>k__BackingField; // 0x8

	// Properties
	public object Name { set; }

	// Methods

	// RVA: 0x7498B6C
	public object .ctor() { }

	// RVA: 0x7498B74
	public object .ctor(object name) { }

	// RVA: 0x7498BA0
	public object set_Name(object value) { }

}

// Namespace: UnityEngine.Scripting
internal class RequiredByNativeCodeAttribute
{

	// Fields
	private object <Name>k__BackingField; // 0x8
	private object <Optional>k__BackingField; // 0x10
	private object <GenerateProxy>k__BackingField; // 0x11

	// Properties
	public object Name { set; }
	public object Optional { set; }
	public object GenerateProxy { set; }

	// Methods

	// RVA: 0x7498BA8
	public object .ctor() { }

	// RVA: 0x7498BB0
	public object .ctor(object name) { }

	// RVA: 0x7498BDC
	public object set_Name(object value) { }

	// RVA: 0x7498BE4
	public object set_Optional(object value) { }

	// RVA: 0x7498BEC
	public object set_GenerateProxy(object value) { }

}

