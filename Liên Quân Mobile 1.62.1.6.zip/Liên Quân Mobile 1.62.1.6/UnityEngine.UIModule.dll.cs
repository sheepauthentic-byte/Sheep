// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public interface ICanvasRaycastFilter
{

	// Methods

	// RVA: -1
	public abstract object IsRaycastLocationValid(object sp, object eventCamera) { }

}

// Namespace: UnityEngine
public sealed class CanvasGroup
{

	// Properties
	public object alpha { get; set; }
	public object interactable { get; set; }
	public object blocksRaycasts { get; set; }
	public object ignoreParentGroups { get; set; }

	// Methods

	// RVA: 0x769AFF0
	public object get_alpha() { }

	// RVA: 0x769B040
	public object set_alpha(object value) { }

	// RVA: 0x769B0A4
	public object get_interactable() { }

	// RVA: 0x769B0F4
	public object set_interactable(object value) { }

	// RVA: 0x769B158
	public object get_blocksRaycasts() { }

	// RVA: 0x769B1A8
	public object set_blocksRaycasts(object value) { }

	// RVA: 0x769B20C
	public object get_ignoreParentGroups() { }

	// RVA: 0x769B25C
	public object set_ignoreParentGroups(object value) { }

	// RVA: 0x769B2C0
	public object IsRaycastLocationValid(object sp, object eventCamera) { }

}

// Namespace: UnityEngine
public sealed class CanvasRenderer
{

	// Fields
	private object <isMask>k__BackingField; // 0x10

	// Properties
	public object hasPopInstruction { set; }
	public object materialCount { get; set; }
	public object popMaterialCount { set; }
	public object absoluteDepth { get; }
	public object hasMoved { get; }
	public object cullTransparentMesh { get; set; }
	public object cull { get; set; }
	public object clippingSoftness { set; }

	// Methods

	// RVA: 0x769B310
	public object set_hasPopInstruction(object value) { }

	// RVA: 0x769B374
	public object get_materialCount() { }

	// RVA: 0x769B3C4
	public object set_materialCount(object value) { }

	// RVA: 0x769B428
	public object set_popMaterialCount(object value) { }

	// RVA: 0x769B48C
	public object get_absoluteDepth() { }

	// RVA: 0x769B4DC
	public object get_hasMoved() { }

	// RVA: 0x769B52C
	public object get_cullTransparentMesh() { }

	// RVA: 0x769B57C
	public object set_cullTransparentMesh(object value) { }

	// RVA: 0x769B5E0
	public object get_cull() { }

	// RVA: 0x769B630
	public object set_cull(object value) { }

	// RVA: 0x769B694
	public object SetColor(object color) { }

	// RVA: 0x769B76C
	public object GetColor() { }

	// RVA: 0x769B830
	public object EnableRectClipping(object rect) { }

	// RVA: 0x769B908
	public object set_clippingSoftness(object value) { }

	// RVA: 0x769B9DC
	public object DisableRectClipping() { }

	// RVA: 0x769BA2C
	public object SetMaterial(object material, object index) { }

	// RVA: 0x769BA98
	public object GetMaterial(object index) { }

	// RVA: 0x769BAFC
	public object SetPopMaterial(object material, object index) { }

	// RVA: 0x769BB68
	public object SetTexture(object texture) { }

	// RVA: 0x769BBCC
	public object SetAlphaTexture(object texture) { }

	// RVA: 0x769BC30
	public object SetMesh(object mesh) { }

	// RVA: 0x769BC94
	public object Clear() { }

	// RVA: 0x769BCE4
	public object SetMaterial(object material, object texture) { }

	// RVA: 0x769BE60
	public object GetMaterial() { }

	// RVA: 0x769BEB8
	public static object SplitUIVertexStreams(object verts, object positions, object colors, object uv0S, object uv1S, object uv2S, object uv3S, object normals, object tangents, object indices) { }

	// RVA: 0x769C0B8
	public static object CreateUIVertexStream(object verts, object positions, object colors, object uv0S, object uv1S, object uv2S, object uv3S, object normals, object tangents, object indices) { }

	// RVA: 0x769C210
	public static object AddUIVertexStream(object verts, object positions, object colors, object uv0S, object uv1S, object uv2S, object uv3S, object normals, object tangents) { }

	// RVA: 0x769C054
	private static object SplitIndicesStreamsInternal(object verts, object indices) { }

	// RVA: 0x769BFB0
	private static object SplitUIVertexStreamsInternal(object verts, object positions, object colors, object uv0S, object uv1S, object uv2S, object uv3S, object normals, object tangents) { }

	// RVA: 0x769C164
	private static object CreateUIVertexStreamInternal(object verts, object positions, object colors, object uv0S, object uv1S, object uv2S, object uv3S, object normals, object tangents, object indices) { }

	// RVA: 0x769B708
	private object SetColor_Injected(object color) { }

	// RVA: 0x769B7CC
	private object GetColor_Injected(object ret) { }

	// RVA: 0x769B8A4
	private object EnableRectClipping_Injected(object rect) { }

	// RVA: 0x769B978
	private object set_clippingSoftness_Injected(object value) { }

}

// Namespace: UnityEngine
public sealed class RectTransformUtility
{

	// Fields
	private static readonly object s_Corners; // 0x0

	// Methods

	// RVA: 0x769C2B4
	public static object PixelAdjustPoint(object point, object elementTransform, object canvas) { }

	// RVA: 0x769C3FC
	public static object PixelAdjustRect(object rectTransform, object canvas) { }

	// RVA: 0x769C52C
	private static object PointInRectangle(object screenPoint, object rect, object cam, object offset) { }

	// RVA: 0x769C670
	public static object RectangleContainsScreenPoint(object rect, object screenPoint, object cam) { }

	// RVA: 0x769C750
	public static object RectangleContainsScreenPoint(object rect, object screenPoint, object cam, object offset) { }

	// RVA: 0x769C898
	public static object ScreenPointToWorldPointInRectangle(object rect, object screenPoint, object cam, object worldPoint) { }

	// RVA: 0x769CE88
	public static object ScreenPointToLocalPointInRectangle(object rect, object screenPoint, object cam, object localPoint) { }

	// RVA: 0x769CC9C
	public static object ScreenPointToRay(object cam, object screenPos) { }

	// RVA: 0x769CF98
	public static object WorldToScreenPoint(object cam, object worldPoint) { }

	// RVA: 0x769D08C
	public static object CalculateRelativeRectTransformBounds(object root, object child) { }

	// RVA: 0x769D548
	public static object CalculateRelativeRectTransformBounds(object trans) { }

	// RVA: 0x769D5D8
	public static object FlipLayoutOnAxis(object rect, object axis, object keepPositioning, object recursive) { }

	// RVA: 0x769D8F0
	public static object FlipLayoutAxes(object rect, object keepPositioning, object recursive) { }

	// RVA: 0x769DBA4
	private static object GetTransposed(object input) { }

	// RVA: 0x769DBB4
	private static object .cctor() { }

	// RVA: 0x769C37C
	private static object PixelAdjustPoint_Injected(object point, object elementTransform, object canvas, object ret) { }

	// RVA: 0x769C4C0
	private static object PixelAdjustRect_Injected(object rectTransform, object canvas, object ret) { }

	// RVA: 0x769C5F0
	private static object PointInRectangle_Injected(object screenPoint, object rect, object cam, object offset) { }

}

// Namespace: UnityEngine
public enum RenderMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ScreenSpaceOverlay;
	public const object ScreenSpaceCamera;
	public const object WorldSpace;
}

// Namespace: UnityEngine
public enum AdditionalCanvasShaderChannels
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object TexCoord1;
	public const object TexCoord2;
	public const object TexCoord3;
	public const object Normal;
	public const object Tangent;
}

// Namespace: 
public sealed class WillRenderCanvases
{

	// Methods

	// RVA: 0x769EF0C
	public object .ctor(object object, object method) { }

	// RVA: 0x769EFA0
	public virtual object Invoke() { }

}

// Namespace: UnityEngine
public sealed class Canvas
{

	// Fields
	private static object preWillRenderCanvases; // 0x0
	private static object willRenderCanvases; // 0x8
	private static object <externBeginRenderOverlays>k__BackingField; // 0x10
	private static object <externRenderOverlaysBefore>k__BackingField; // 0x18
	private static object <externEndRenderOverlays>k__BackingField; // 0x20

	// Properties
	public object renderMode { get; set; }
	public object isRootCanvas { get; }
	public object pixelRect { get; }
	public object scaleFactor { get; set; }
	public object referencePixelsPerUnit { get; set; }
	public object pixelPerfect { get; set; }
	public object renderOrder { get; }
	public object overrideSorting { get; set; }
	public object sortingOrder { get; set; }
	public object targetDisplay { get; }
	public object sortingLayerID { get; set; }
	public object additionalShaderChannels { get; set; }
	public object sortingLayerName { get; set; }
	public object rootCanvas { get; }
	public object renderingDisplaySize { get; }
	internal static object externBeginRenderOverlays { get; set; }
	internal static object externRenderOverlaysBefore { get; set; }
	internal static object externEndRenderOverlays { get; set; }
	public object worldCamera { get; set; }

	// Methods

	// RVA: 0x769DC28
	public static object add_preWillRenderCanvases(object value) { }

	// RVA: 0x769DCE8
	public static object remove_preWillRenderCanvases(object value) { }

	// RVA: 0x769DDA8
	public static object add_willRenderCanvases(object value) { }

	// RVA: 0x769DE6C
	public static object remove_willRenderCanvases(object value) { }

	// RVA: 0x769DF30
	public object get_renderMode() { }

	// RVA: 0x769DF80
	public object set_renderMode(object value) { }

	// RVA: 0x769DFE4
	public object get_isRootCanvas() { }

	// RVA: 0x769E034
	public object get_pixelRect() { }

	// RVA: 0x769E0F8
	public object get_scaleFactor() { }

	// RVA: 0x769E148
	public object set_scaleFactor(object value) { }

	// RVA: 0x769E1AC
	public object get_referencePixelsPerUnit() { }

	// RVA: 0x769E1FC
	public object set_referencePixelsPerUnit(object value) { }

	// RVA: 0x769E260
	public object get_pixelPerfect() { }

	// RVA: 0x769E2B0
	public object set_pixelPerfect(object value) { }

	// RVA: 0x769E314
	public object get_renderOrder() { }

	// RVA: 0x769E364
	public object get_overrideSorting() { }

	// RVA: 0x769E3B4
	public object set_overrideSorting(object value) { }

	// RVA: 0x769E418
	public object get_sortingOrder() { }

	// RVA: 0x769E468
	public object set_sortingOrder(object value) { }

	// RVA: 0x769E4CC
	public object get_targetDisplay() { }

	// RVA: 0x769E51C
	public object get_sortingLayerID() { }

	// RVA: 0x769E56C
	public object set_sortingLayerID(object value) { }

	// RVA: 0x769E5D0
	public object get_additionalShaderChannels() { }

	// RVA: 0x769E620
	public object set_additionalShaderChannels(object value) { }

	// RVA: 0x769E684
	public object get_sortingLayerName() { }

	// RVA: 0x769E6D4
	public object set_sortingLayerName(object value) { }

	// RVA: 0x769E738
	public object get_rootCanvas() { }

	// RVA: 0x769E788
	public object get_renderingDisplaySize() { }

	// RVA: 0x769E848
	internal static object get_externBeginRenderOverlays() { }

	// RVA: 0x769E894
	internal static object set_externBeginRenderOverlays(object value) { }

	// RVA: 0x769E8EC
	internal static object get_externRenderOverlaysBefore() { }

	// RVA: 0x769E938
	internal static object set_externRenderOverlaysBefore(object value) { }

	// RVA: 0x769E990
	internal static object get_externEndRenderOverlays() { }

	// RVA: 0x769E9DC
	internal static object set_externEndRenderOverlays(object value) { }

	// RVA: 0x769EA34
	internal static object SetExternalCanvasEnabled(object enabled) { }

	// RVA: 0x769EA84
	public object get_worldCamera() { }

	// RVA: 0x769EAD4
	public object set_worldCamera(object value) { }

	// RVA: 0x769EB38
	public static object GetDefaultCanvasMaterial() { }

	// RVA: 0x769EB78
	public static object GetETC1SupportedCanvasMaterial() { }

	// RVA: 0x769EBB8
	public static object ForceUpdateCanvases() { }

	// RVA: 0x769EC60
	private static object SendPreWillRenderCanvases() { }

	// RVA: 0x769ECC8
	private static object SendWillRenderCanvases() { }

	// RVA: 0x769ED30
	private static object BeginRenderExtraOverlays(object displayIndex) { }

	// RVA: 0x769EDAC
	private static object RenderExtraOverlaysBefore(object displayIndex, object sortingOrder) { }

	// RVA: 0x769EE30
	private static object EndRenderExtraOverlays(object displayIndex) { }

	// RVA: 0x769EEAC
	public object .ctor() { }

	// RVA: 0x769E094
	private object get_pixelRect_Injected(object ret) { }

	// RVA: 0x769E7E4
	private object get_renderingDisplaySize_Injected(object ret) { }

}

// Namespace: 
public enum SampleType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Layout;
	public const object Render;
}

// Namespace: UnityEngine
public static class UISystemProfilerApi
{

	// Methods

	// RVA: 0x769EFB4
	public static object BeginSample(object type) { }

	// RVA: 0x769F004
	public static object EndSample(object type) { }

	// RVA: 0x769F054
	public static object AddMarker(object name, object obj) { }

}

