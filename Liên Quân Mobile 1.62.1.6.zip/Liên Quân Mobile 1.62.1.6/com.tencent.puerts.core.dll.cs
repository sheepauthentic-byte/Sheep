// Namespace: 
internal class <Module>
{
}

// Namespace: Puerts
public class ArrayBuffer
{

	// Fields
	public object Bytes; // 0x8
	public object Count; // 0x10

	// Methods

	// RVA: 0xFE19BC
	public object .ctor(object bytes) { }

	// RVA: 0xFE19F4
	public object .ctor(object bytes, object count) { }

	// RVA: 0xFE1A48
	public object .ctor(object ptr, object length) { }

	// RVA: 0xFE1B38
	public object .ctor(object ptr, object length, object notuse) { }

}

// Namespace: Puerts
public abstract class Backend
{

	// Fields
	protected object env; // 0x8

	// Methods

	// RVA: 0xFE1B3C
	public object .ctor(object env) { }

}

// Namespace: Puerts
public class BackendV8
{

	// Methods

	// RVA: 0xFE1B68
	public object .ctor(object env) { }

}

// Namespace: Puerts
public class BackendNodeJS
{

	// Methods

	// RVA: 0xFE1B94
	public object .ctor(object env) { }

}

// Namespace: Puerts
public class BackendQuickJS
{

	// Methods

	// RVA: 0xFE1BC0
	public object .ctor(object env) { }

}

// Namespace: Puerts
public sealed class JSFunctionCallback
{

	// Methods

	// RVA: 0xFE1C94
	public object .ctor(object object, object method) { }

	// RVA: 0xFE1D2C
	public virtual object Invoke(object isolate, object info, object self, object argumentsLen) { }

}

// Namespace: Puerts
public sealed class JSConstructorCallback
{

	// Methods

	// RVA: 0xFE1DDC
	public object .ctor(object object, object method) { }

	// RVA: 0xFE1E74
	public virtual object Invoke(object isolate, object info, object argumentsLen) { }

}

// Namespace: Puerts
public enum BackendType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object V8;
	public const object Node;
	public const object QuickJS;
}

// Namespace: Puerts
public class JsEnv
{

	// Fields
	public static object jsEnvs; // 0x0
	internal readonly object Idx; // 0x8
	internal readonly object GeneralGetterManager; // 0x10
	internal readonly object GeneralSetterManager; // 0x18
	internal readonly object TypeManager; // 0x20
	internal readonly object genericDelegateFactory; // 0x28
	internal readonly object jsObjectFactory; // 0x30
	internal readonly object JSObjectValueGetter; // 0x38
	internal object ModuleExecutor; // 0x40
	internal object isolate; // 0x48
	internal object objectPool; // 0x50
	private readonly object loader; // 0x58
	private object loaderCanCheckESM; // 0x60
	public object Backend; // 0x68
	protected object debugPort; // 0x70
	internal object OnDispose; // 0x78
	public object OnJSErrorEmitted; // 0x80
	public static object TypeFromJs; // 0x8
	public static object IsGetTypeFromJsLogError; // 0x10
	public static object UsePuertsWebSocket; // 0x11
	private readonly object callbacks; // 0x88
	private readonly object constructorCallbacks; // 0x90
	private object tickHandler; // 0x98
	private object waitDebugerTaskSource; // 0xA0
	private object disposed; // 0xA8
	private object funcRefCount; // 0xB0
	private object JSObjRefCount; // 0xB8
	private object pendingRemovedList; // 0xC0
	private object pendingRemovedJsObjList; // 0xC8

	// Properties
	internal object TypeRegister { get; }
	public object Isolate { get; }
	public object Index { get; }

	// Methods

	// RVA: 0xFE1E88
	internal object get_TypeRegister() { }

	// RVA: 0xFE1F08
	public object get_Isolate() { }

	// RVA: 0xFE1F10
	public object .ctor(object loader, object debugPort, object backend, object externalRuntime, object externalContext) { }

	// RVA: -1
	public object ExecuteModule(object specifier, object exportee) { }

	// RVA: 0xFE65A4
	public object ExecuteModule(object specifier) { }

	// RVA: 0xFE695C
	public object ClearModuleCache(object path) { }

	// RVA: 0xFE6AA8
	public object AddRegisterInfoGetter(object type, object getter) { }

	// RVA: 0xFE6BE0
	internal object InvokeCallback(object isolate, object callbackIdx, object info, object self, object paramLen) { }

	// RVA: 0xFE5D2C
	internal object AddCallback(object callback) { }

	// RVA: 0xFE6CAC
	internal object AddCallbackSlow(object callback) { }

	// RVA: 0xFE6DB8
	internal object ReleaseCallback(object callbackIdx) { }

	// RVA: 0xFE6E28
	internal object InvokeConstructor(object isolate, object callbackIdx, object info, object paramLen) { }

	// RVA: 0xFE7038
	internal object AddConstructor(object callback) { }

	// RVA: 0xFE7158
	internal object JsReleaseObject(object objectID) { }

	// RVA: 0xFE72B8
	private object GetLoader(object isolate, object info, object self, object paramLen) { }

	// RVA: 0xFE76D4
	internal object ToGenericDelegate(object ptr) { }

	// RVA: 0xFE7928
	public object get_Index() { }

	// RVA: 0xFE7930
	private object RegisterTickHandler(object isolate, object info, object self, object paramLen) { }

	// RVA: 0xFE7BF8
	private object GetTypeFromJs(object isolate, object info, object self, object paramLen) { }

	// RVA: 0xFE87C8
	private object GetGenericMethod(object isolate, object info, object self, object paramLen) { }

	// RVA: 0xFE9018
	private object CreateFunction(object isolate, object info, object self, object paramLen) { }

	// RVA: 0xFE99B8
	private object LoadType(object isolate, object info, object self, object paramLen) { }

	// RVA: 0xFE9BC4
	private object GetNestedTypes(object isolate, object info, object self, object paramLen) { }

	// RVA: -1
	public object UsingAction() { }

	// RVA: -1
	public object UsingAction() { }

	// RVA: -1
	public object UsingAction() { }

	// RVA: -1
	public object UsingAction() { }

	// RVA: -1
	public object UsingFunc() { }

	// RVA: -1
	public object UsingFunc() { }

	// RVA: -1
	public object UsingFunc() { }

	// RVA: -1
	public object UsingFunc() { }

	// RVA: 0xFE9E28
	public object Tick() { }

	// RVA: 0xFEAA40
	protected override object Finalize() { }

	// RVA: 0xFE686C
	public object Dispose() { }

	// RVA: 0xFEAB98
	protected virtual object Dispose(object dispose) { }

	// RVA: 0xFEA134
	internal object CheckLiveness(object shouldThrow) { }

	// RVA: 0xFEAF80
	internal object IncFuncRef(object nativeJsFuncPtr) { }

	// RVA: 0xFEB11C
	internal object DecFuncRef(object nativeJsFuncPtr) { }

	// RVA: 0xFEB28C
	internal object IncJSObjRef(object nativeJSObjectPtr) { }

	// RVA: 0xFEB428
	internal object DecJSObjRef(object nativeJSObjectPtr) { }

	// RVA: 0xFEA1A4
	internal object ReleasePendingJSFunctions() { }

	// RVA: 0xFEA580
	internal object ReleasePendingJSObjects() { }

	// RVA: 0xFEB900
	private static object .cctor() { }

	// RVA: 0xFEB998
	private object <CreateFunction>b__57_0(object m) { }

}

// Namespace: 
private class Node
{

	// Fields
	public object Creator; // 0x8
	public object Branchs; // 0x10

	// Methods

	// RVA: 0xFEBC14
	public object .ctor() { }

}

// Namespace: Puerts
internal class DelegateCreatorTree
{

	// Fields
	private readonly object root; // 0x8

	// Methods

	// RVA: 0xFEBA0C
	private object FindNode(object types, object createIfNotExisted) { }

	// RVA: 0xFEBC94
	public object Add(object creator, object types) { }

	// RVA: 0xFEBCD0
	public object Find(object types) { }

	// RVA: 0xFEBCF0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__13_1; // 0x8
	public static object <>9__13_2; // 0x10
	public static object <>9__13_3; // 0x18
	public static object <>9__13_4; // 0x20
	public static object <>9__13_0; // 0x28

	// Methods

	// RVA: 0xFEDC3C
	private static object .cctor() { }

	// RVA: 0xFEDC9C
	public object .ctor() { }

	// RVA: 0xFEDCA4
	internal object <Create>b__13_1(object m) { }

	// RVA: 0xFEDD24
	internal object <Create>b__13_2(object m) { }

	// RVA: 0xFEDD8C
	internal object <Create>b__13_3(object m) { }

	// RVA: 0xFEDE0C
	internal object <Create>b__13_4(object m) { }

	// RVA: 0xFEDE74
	internal object <Create>b__13_0(object pinfo) { }

}

// Namespace: 
private sealed class <>c__DisplayClass13_0
{

	// Fields
	public object methodInfo; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0xFEDC2C
	public object .ctor() { }

	// RVA: 0xFEDEC0
	internal object <Create>b__5(object dt, object ptr) { }

}

// Namespace: 
private sealed class <>c__DisplayClass13_1
{

	// Fields
	public object methodInfo; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0xFEDC34
	public object .ctor() { }

	// RVA: 0xFEDF08
	internal object <Create>b__6(object dt, object ptr) { }

}

// Namespace: Puerts
internal class GenericDelegateFactory
{

	// Fields
	private readonly object jsEnv; // 0x8
	private object genericAction; // 0x10
	private object genericFunc; // 0x18
	private object genericDelegateCreatorCache; // 0x20
	private object nativePtrToGenericDelegate; // 0x28
	private object ActionCreatorTree; // 0x30
	private object FuncCreatorTree; // 0x38

	// Methods

	// RVA: 0xFE3E54
	internal object .ctor(object jsEnv) { }

	// RVA: 0xFEBDBC
	private static object PreventStripping(object obj) { }

	// RVA: 0xFEC17C
	private static object .cctor() { }

	// RVA: 0xFE76F4
	internal object ToGenericDelegate(object ptr) { }

	// RVA: 0xFEB654
	public object RemoveGenericDelegate(object ptr) { }

	// RVA: 0xFEAD78
	public object CloseAll() { }

	// RVA: 0xFEB598
	internal object IsJsFunctionAlive(object ptr) { }

	// RVA: 0xFECD9C
	private object CreateDelegate(object type, object genericDelegate, object method) { }

	// RVA: 0xFED20C
	internal object Create(object delegateType, object nativeJsFuncPtr) { }

	// RVA: -1
	public object RegisterAction() { }

	// RVA: -1
	public object RegisterAction() { }

	// RVA: -1
	public object RegisterAction() { }

	// RVA: -1
	public object RegisterAction() { }

	// RVA: -1
	public object RegisterFunc() { }

	// RVA: -1
	public object RegisterFunc() { }

	// RVA: -1
	public object RegisterFunc() { }

	// RVA: -1
	public object RegisterFunc() { }

	// RVA: -1
	private object <RegisterAction>b__16_0(object type, object ptr) { }

	// RVA: -1
	private object <RegisterAction>b__17_0(object type, object ptr) { }

	// RVA: -1
	private object <RegisterAction>b__18_0(object type, object ptr) { }

	// RVA: -1
	private object <RegisterAction>b__19_0(object type, object ptr) { }

	// RVA: -1
	private object <RegisterFunc>b__20_0(object type, object ptr) { }

	// RVA: -1
	private object <RegisterFunc>b__21_0(object type, object ptr) { }

	// RVA: -1
	private object <RegisterFunc>b__22_0(object type, object ptr) { }

	// RVA: -1
	private object <RegisterFunc>b__23_0(object type, object ptr) { }

}

// Namespace: Puerts
public class GenericDelegate
{

	// Fields
	private object jsEnv; // 0x8
	private object nativeJsFuncPtr; // 0x10
	private object isolate; // 0x18
	private object firstKey; // 0x20
	private object firstValue; // 0x28
	private object bindTo; // 0x30
	private object stacktrace; // 0x38

	// Methods

	// RVA: 0xFEDF50
	internal object getJsFuncPtr() { }

	// RVA: 0xFE6538
	internal object .ctor(object nativeJsFuncPtr, object jsEnv, object stacktrace) { }

	// RVA: 0xFECD54
	internal object Close() { }

	// RVA: 0xFEDF58
	private object CheckLiveness(object shouldThrow) { }

	// RVA: 0xFEE080
	private object CheckThread() { }

	// RVA: 0xFEE084
	protected override object Finalize() { }

	// RVA: 0xFECED0
	public object TryGetDelegate(object key, object value) { }

	// RVA: 0xFECFD8
	public object AddDelegate(object key, object value) { }

	// RVA: 0xFEBE94
	public object Action() { }

	// RVA: -1
	public object Action(object p1) { }

	// RVA: -1
	public object Action(object p1, object p2) { }

	// RVA: -1
	public object Action(object p1, object p2, object p3) { }

	// RVA: -1
	public object Action(object p1, object p2, object p3, object p4) { }

	// RVA: -1
	public object Action(object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: -1
	public object Func() { }

	// RVA: -1
	public object Func(object p1) { }

	// RVA: -1
	public object Func(object p1, object p2) { }

	// RVA: -1
	public object Func(object p1, object p2, object p3) { }

	// RVA: -1
	public object Func(object p1, object p2, object p3, object p4) { }

}

// Namespace: Puerts
internal class JSObjectFactory
{

	// Fields
	private object nativePtrToJSObject; // 0x8

	// Methods

	// RVA: 0xFEE214
	public object GetOrCreateJSObject(object ptr, object jsEnv) { }

	// RVA: 0xFEB808
	public object RemoveJSObject(object ptr) { }

	// RVA: 0xFEB74C
	internal object IsJsObjectAlive(object ptr) { }

	// RVA: 0xFE3F6C
	public object .ctor() { }

}

// Namespace: Puerts
public class JSObject
{

	// Fields
	private readonly object jsEnv; // 0x8
	private object nativeJsObjectPtr; // 0x10

	// Methods

	// RVA: 0xFEE458
	public object getJsObjPtr() { }

	// RVA: 0xFEE408
	internal object .ctor(object nativeJsObjectPtr, object jsEnv) { }

	// RVA: -1
	public object Get(object key) { }

	// RVA: 0xFEE460
	protected override object Finalize() { }

}

// Namespace: Puerts
public class MonoPInvokeCallbackAttribute
{

	// Fields
	private object type; // 0x8

	// Methods

	// RVA: 0xFEE5BC
	public object .ctor(object t) { }

}

// Namespace: Puerts
public sealed class V8FunctionCallback
{

	// Methods

	// RVA: 0xFE5C94
	public object .ctor(object object, object method) { }

	// RVA: 0xFEE6A8
	public virtual object Invoke(object isolate, object info, object self, object paramLen, object data) { }

}

// Namespace: Puerts
public sealed class JsFunctionFinalizeCallback
{

	// Methods

	// RVA: 0xFE982C
	public object .ctor(object object, object method) { }

	// RVA: 0xFEE73C
	public virtual object Invoke(object isolate, object data) { }

}

// Namespace: Puerts
public sealed class V8ConstructorCallback
{

	// Methods

	// RVA: 0xFEE810
	public object .ctor(object object, object method) { }

	// RVA: 0xFEE8A8
	public virtual object Invoke(object isolate, object info, object paramLen, object data) { }

}

// Namespace: Puerts
public sealed class V8DestructorCallback
{

	// Methods

	// RVA: 0xFE5B58
	public object .ctor(object object, object method) { }

	// RVA: 0xFEE93C
	public virtual object Invoke(object self, object data) { }

}

// Namespace: Puerts
public enum JsValueType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Invalid;
	public const object NullOrUndefined;
	public const object BigInt;
	public const object Number;
	public const object String;
	public const object Boolean;
	public const object NativeObject;
	public const object JsObject;
	public const object Array;
	public const object Function;
	public const object Date;
	public const object ArrayBuffer;
	public const object Unknow;
	public const object Any;
}

// Namespace: Puerts
public class PuertsDLL
{

	// Fields
	private static object s_tempNativeStringBuffer; // 0xFFFFFFFF80000000

	// Methods

	// RVA: 0xFEE950
	protected static extern object _GetApiLevel() { }

	// RVA: 0xFEE954
	public static extern object GetLibVersion() { }

	// RVA: 0xFE385C
	public static object GetApiLevel() { }

	// RVA: 0xFE5B54
	public static extern object GetLibBackend(object isolate) { }

	// RVA: 0xFE3948
	public static extern object CreateJSEngine(object backendType) { }

	// RVA: 0xFE3944
	public static extern object CreateJSEngineWithExternalEnv(object backendType, object externalRuntime, object externalContext) { }

	// RVA: 0xFEAF7C
	public static extern object DestroyJSEngine(object isolate) { }

	// RVA: 0xFEE958
	public static extern object SetGlobalFunction(object isolate, object name, object v8FunctionCallback, object data) { }

	// RVA: 0xFE5E4C
	public static object SetGlobalFunction(object isolate, object name, object v8FunctionCallback, object data) { }

	// RVA: 0xFEE9A8
	private static object GetTempNativeStringBuff(object strlen) { }

	// RVA: 0xFEEA7C
	private static object GetStringFromNative(object str, object strlen) { }

	// RVA: 0xFEEB78
	public static extern object GetLastExceptionInfo(object isolate, object strlen) { }

	// RVA: 0xFE64B8
	public static object GetLastExceptionInfo(object isolate) { }

	// RVA: 0xFEEB7C
	public static extern object SetGeneralDestructor(object isolate, object generalDestructor) { }

	// RVA: 0xFE5BF0
	public static object SetGeneralDestructor(object isolate, object generalDestructor) { }

	// RVA: 0xFE6A60
	public static extern object ClearModuleCache(object isolate, object path) { }

	// RVA: 0xFEEB80
	public static extern object _RegisterClass(object isolate, object BaseTypeId, object fullName, object constructor, object destructor, object data) { }

	// RVA: 0xFEEBF4
	public static object RegisterClass(object isolate, object BaseTypeId, object fullName, object constructor, object destructor, object data) { }

	// RVA: 0xFEED0C
	public static extern object RegisterStruct(object isolate, object BaseTypeId, object fullName, object constructor, object destructor, object data, object size) { }

	// RVA: 0xFEED90
	public static object RegisterStruct(object isolate, object BaseTypeId, object fullName, object constructor, object destructor, object data, object size) { }

	// RVA: 0xFEEEB8
	public static extern object RegisterFunction(object isolate, object classID, object name, object isStatic, object callback, object data) { }

	// RVA: 0xFEEF30
	public static object RegisterFunction(object isolate, object classID, object name, object isStatic, object callback, object data) { }

	// RVA: 0xFEF014
	public static extern object RegisterProperty(object isolate, object classID, object name, object isStatic, object getter, object getterData, object setter, object setterData, object dontDelete) { }

	// RVA: 0xFEF0BC
	public static object RegisterProperty(object isolate, object classID, object name, object isStatic, object getter, object getterData, object setter, object setterData, object dontDelete) { }

	// RVA: 0xFE64B4
	public static extern object GetJSObjectValueGetter(object isolate) { }

	// RVA: 0xFE6958
	public static extern object GetModuleExecutor(object isolate) { }

	// RVA: 0xFE9BC0
	public static extern object ReturnClass(object isolate, object info, object classID) { }

	// RVA: 0xFEF1EC
	public static extern object ReturnObject(object isolate, object info, object classID, object self) { }

	// RVA: 0xFEF1F0
	public static extern object ReturnNumber(object isolate, object info, object number) { }

	// RVA: 0xFEF1F4
	public static extern object __ReturnString(object isolate, object info, object ptr, object length) { }

	// RVA: 0xFEF1F8
	public static object ReturnString(object isolate, object info, object ptr, object length) { }

	// RVA: 0xFEF268
	public static object ReturnString(object isolate, object info, object str) { }

	// RVA: 0xFEF314
	public static extern object ReturnBigInt(object isolate, object info, object number) { }

	// RVA: 0xFEF318
	public static extern object ReturnBoolean(object isolate, object info, object b) { }

	// RVA: 0xFEF264
	public static extern object ReturnNull(object isolate, object info) { }

	// RVA: 0xFEF31C
	public static extern object ReturnFunction(object isolate, object info, object JSFunction) { }

	// RVA: 0xFEF320
	private static extern object ReturnCSharpFunctionCallback(object isolate, object info, object v8FunctionCallback, object data) { }

	// RVA: 0xFE8F6C
	public static object ReturnCSharpFunctionCallback(object isolate, object info, object v8FunctionCallback, object data) { }

	// RVA: 0xFEF324
	private static extern object ReturnCSharpFunctionCallback2(object isolate, object info, object v8FunctionCallback, object JsFunctionFinalize, object data) { }

	// RVA: 0xFE98C4
	public static object ReturnCSharpFunctionCallback2(object isolate, object info, object v8FunctionCallback, object JsFunctionFinalize, object data) { }

	// RVA: 0xFEF328
	public static extern object ReturnJSObject(object isolate, object info, object JSObject) { }

	// RVA: 0xFE7BB4
	public static extern object GetArgumentValue(object isolate, object info, object index) { }

	// RVA: 0xFE7BB8
	public static extern object GetJsValueType(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF32C
	public static extern object GetNumberFromValue(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF330
	public static extern object GetStringFromValue(object isolate, object value, object len, object isByRef) { }

	// RVA: 0xFE81A0
	public static object GetStringFromValue(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF334
	public static extern object GetBooleanFromValue(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF350
	public static extern object ValueIsBigInt(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF36C
	public static extern object GetBigIntFromValue(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF370
	public static object GetBigIntFromValueChecked(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF3C4
	public static extern object GetObjectFromValue(object isolate, object value, object isByRef) { }

	// RVA: 0xFE86E0
	public static extern object GetTypeIdFromValue(object isolate, object value, object isByRef) { }

	// RVA: 0xFE7BBC
	public static extern object GetFunctionFromValue(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF3C8
	public static extern object GetJSObjectFromValue(object isolate, object value, object isByRef) { }

	// RVA: 0xFEF3CC
	public static extern object SetNumberToOutValue(object isolate, object value, object number) { }

	// RVA: 0xFEF3D0
	protected static extern object __SetStringToOutValue(object isolate, object value, object str) { }

	// RVA: 0xFEF418
	public static object SetStringToOutValue(object isolate, object value, object str) { }

	// RVA: 0xFEF46C
	public static extern object SetBooleanToOutValue(object isolate, object value, object b) { }

	// RVA: 0xFEF470
	public static extern object SetBigIntToOutValue(object isolate, object value, object bigInt) { }

	// RVA: 0xFEF474
	public static extern object SetObjectToOutValue(object isolate, object value, object classId, object ptr) { }

	// RVA: 0xFEF468
	public static extern object SetNullToOutValue(object isolate, object value) { }

	// RVA: 0xFE7BC0
	public static extern object ThrowException(object isolate, object message) { }

	// RVA: 0xFEF478
	public static extern object PushNullForJSFunction(object function) { }

	// RVA: 0xFEF47C
	public static extern object PushBooleanForJSFunction(object function, object b) { }

	// RVA: 0xFEF480
	public static extern object PushBigIntForJSFunction(object function, object l) { }

	// RVA: 0xFEF484
	public static extern object __PushStringForJSFunction(object function, object str) { }

	// RVA: 0xFEF4BC
	public static object PushStringForJSFunction(object function, object str) { }

	// RVA: 0xFEF4FC
	public static extern object PushNumberForJSFunction(object function, object d) { }

	// RVA: 0xFEF500
	public static extern object PushObjectForJSFunction(object function, object classId, object objectId) { }

	// RVA: 0xFEF504
	public static extern object PushJSFunctionForJSFunction(object function, object JSFunction) { }

	// RVA: 0xFEF508
	public static extern object PushJSObjectForJSFunction(object function, object JSObject) { }

	// RVA: 0xFEA97C
	public static extern object InvokeJSFunction(object function, object hasResult) { }

	// RVA: 0xFEF50C
	public static extern object GetFunctionLastExceptionInfo(object function, object len) { }

	// RVA: 0xFEB748
	public static extern object ReleaseJSFunction(object isolate, object function) { }

	// RVA: 0xFEB8FC
	public static extern object ReleaseJSObject(object isolate, object obj) { }

	// RVA: 0xFEA980
	public static object GetFunctionLastExceptionInfo(object function) { }

	// RVA: 0xFEF510
	public static extern object GetResultType(object resultInfo) { }

	// RVA: 0xFEF514
	public static extern object GetNumberFromResult(object resultInfo) { }

	// RVA: 0xFEF518
	public static extern object GetStringFromResult(object resultInfo, object len) { }

	// RVA: 0xFEF51C
	public static object GetStringFromResult(object resultInfo) { }

	// RVA: 0xFEF548
	public static extern object GetBooleanFromResult(object resultInfo) { }

	// RVA: 0xFEF564
	public static extern object ResultIsBigInt(object resultInfo) { }

	// RVA: 0xFEF580
	public static extern object GetBigIntFromResult(object resultInfo) { }

	// RVA: 0xFEF584
	public static object GetBigIntFromResultCheck(object resultInfo) { }

	// RVA: 0xFEF5BC
	public static extern object GetObjectFromResult(object resultInfo) { }

	// RVA: 0xFEF5C0
	public static extern object GetTypeIdFromResult(object resultInfo) { }

	// RVA: 0xFEF5C4
	public static extern object GetFunctionFromResult(object resultInfo) { }

	// RVA: 0xFEF5C8
	public static extern object GetJSObjectFromResult(object resultInfo) { }

	// RVA: 0xFEF5CC
	public static extern object ResetResult(object resultInfo) { }

	// RVA: 0xFE65A0
	public static extern object CreateInspector(object isolate, object port) { }

	// RVA: 0xFEA95C
	public static extern object InspectorTick(object isolate) { }

	// RVA: 0xFEA978
	public static extern object LogicTick(object isolate) { }

	// RVA: 0xFEF5D0
	public static extern object ReturnArrayBuffer(object isolate, object info, object bytes, object Length) { }

	// RVA: 0xFEF5E0
	public static extern object SetArrayBufferToOutValue(object isolate, object value, object bytes, object length) { }

	// RVA: 0xFEF5F0
	public static extern object PushArrayBufferForJSFunction(object function, object bytes, object length) { }

	// RVA: 0xFEF600
	public static extern object GetArrayBufferFromValue(object isolate, object value, object length, object isOut) { }

	// RVA: 0xFEF604
	public static extern object GetArrayBufferFromResult(object function, object length) { }

	// RVA: 0xFEF608
	public static extern object GetJSStackTrace(object isolate, object len) { }

	// RVA: 0xFECD28
	public static object GetJSStackTrace(object isolate) { }

}

// Namespace: Puerts
internal class StaticCallbacks
{

	// Methods

	// RVA: 0xFEF68C
	internal static object JsEnvCallbackWrap(object isolate, object info, object self, object paramLen, object data) { }

	// RVA: 0xFEF938
	internal static object FunctionFinalizeCallback(object isolate, object data) { }

	// RVA: 0xFEFB90
	internal static object GeneralDestructor(object self, object data) { }

	// RVA: 0xFEFD80
	internal static object ConstructorWrap(object isolate, object info, object paramLen, object data) { }

	// RVA: 0xFEFFC0
	internal static object ReturnTrue(object isolate, object info, object self, object paramLen, object data) { }

}

// Namespace: Puerts
public struct ArgHelper
{

	// Methods

	// RVA: -1
	public static object GetParams(object jsEnvIdx, object isolate, object info, object start, object end, object v8Value) { }

	// RVA: 0xFEFFD8
	public static object IsMatchParams(object jsEnvIdx, object isolate, object info, object expectJsType, object expectCsType, object start, object end, object v8Value, object arg, object argValueType) { }

	// RVA: 0xFF00B0
	public static object IsMatch(object jsEnvIdx, object isolate, object expectJsType, object expectCsType, object isByRef, object isOut, object v8Value, object arg, object argValueType) { }

}

// Namespace: Puerts
public struct ResultHelper
{

	// Methods

	// RVA: -1
	public static object Set(object jsEnvIdx, object isolate, object info, object result) { }

}

// Namespace: Puerts
public sealed class GeneralGetter
{

	// Methods

	// RVA: 0xFF0E54
	public object .ctor(object object, object method) { }

	// RVA: 0xFF0EEC
	public virtual object Invoke(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

}

// Namespace: 
private sealed class <>c__DisplayClass20_0
{

	// Fields
	public object jvt; // 0x8

	// Methods

	// RVA: 0xFF3028
	public object .ctor() { }

	// RVA: 0xFF3E50
	internal object <MakeNullableTranslateFunc>b__0(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

}

// Namespace: 
private sealed class <>c__DisplayClass21_0
{

	// Fields
	public object type; // 0x8
	public object fixTypeGetter; // 0x10

	// Methods

	// RVA: 0xFF326C
	public object .ctor() { }

	// RVA: 0xFF3FA4
	internal object <MakeTranslateFunc>b__0(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF4270
	internal object <MakeTranslateFunc>b__1(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

}

// Namespace: Puerts
public class GeneralGetterManager
{

	// Fields
	private object generalGetterMap; // 0x8
	private object nullableTypeGeneralGetterMap; // 0x10
	private static object primitiveTypeMap; // 0x0

	// Methods

	// RVA: 0xFE3FEC
	internal object .ctor() { }

	// RVA: 0xFF0F00
	private static object CharTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF108C
	private static object SbyteTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF121C
	private static object ByteTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF13A8
	private static object ShortTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF1538
	private static object UshortTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF16C4
	private static object IntTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF1858
	private static object UintTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF19E4
	private static object LongTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF1EDC
	private static object UlongTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF23D4
	private static object DoubleTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF254C
	private static object FloatTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF26CC
	private static object BooleanTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF2844
	private static object StringTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF2934
	private static object ArrayBufferTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF2A24
	private object JSObjectTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF2C7C
	private object GenericDelegateTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF0628
	internal object AnyTranslator(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: 0xFF2F28
	private object MakeNullableTranslateFunc(object jvt) { }

	// RVA: 0xFF3030
	private object MakeTranslateFunc(object type) { }

	// RVA: 0xFF3274
	public object GetTranslateFunc(object type) { }

	// RVA: 0xFF34EC
	public object GetSelf(object jsEnvIdx, object Self) { }

	// RVA: 0xFF3630
	public static object GetJsTypeMask(object type) { }

	// RVA: 0xFF3A84
	private static object .cctor() { }

}

// Namespace: Puerts
public sealed class GeneralSetter
{

	// Methods

	// RVA: 0xFF53DC
	public object .ctor(object object, object method) { }

	// RVA: 0xFF5474
	public virtual object Invoke(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__21_0; // 0x8
	public static object <>9__21_1; // 0x10

	// Methods

	// RVA: 0xFF732C
	private static object .cctor() { }

	// RVA: 0xFF738C
	public object .ctor() { }

	// RVA: 0xFF7394
	internal object <MakeTranslateFunc>b__21_0(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF7650
	internal object <MakeTranslateFunc>b__21_1(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

}

// Namespace: Puerts
public class GeneralSetterManager
{

	// Fields
	private object generalSetterMap; // 0x8

	// Methods

	// RVA: 0xFE4CF4
	public object .ctor() { }

	// RVA: 0xFF5488
	private static object VoidTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF548C
	private static object CharTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF561C
	private static object SbyteTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF57AC
	private static object ByteTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF593C
	private static object ShortTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF5ACC
	private static object UshortTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF5C5C
	private static object IntTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF5DEC
	private static object UintTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF5F7C
	private static object LongTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF610C
	private static object UlongTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF629C
	private static object DoubleTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF6434
	private static object FloatTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF65CC
	private static object BooleanTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF675C
	private static object StringTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF68E0
	private static object ArrayBufferTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF6A78
	private static object RawStringTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF6C28
	private static object GenericDelegateTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF6D70
	private static object JSObjectTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFE7374
	internal object AnyTranslator(object jsEnvIdx, object isolate, object setValueApi, object holder, object obj) { }

	// RVA: 0xFF70D0
	private object MakeTranslateFunc(object type) { }

	// RVA: 0xFF6F48
	public object GetTranslateFunc(object type) { }

}

// Namespace: Puerts
public static class NativeValueApi
{

	// Fields
	public static object GetValueFromArgument; // 0x0
	public static object GetValueFromResult; // 0x8
	public static object SetValueToResult; // 0x10
	public static object SetValueToByRefArgument; // 0x18
	public static object SetValueToArgument; // 0x20

	// Methods

	// RVA: 0xFF79E4
	private static object .cctor() { }

}

// Namespace: Puerts
public interface ISetValueToJs
{

	// Methods

	// RVA: -1
	public abstract object SetNativeObject(object isolate, object holder, object classID, object self) { }

	// RVA: -1
	public abstract object SetJSObject(object isolate, object holder, object JSObject) { }

	// RVA: -1
	public abstract object SetFunction(object isolate, object holder, object JSFunction) { }

	// RVA: -1
	public abstract object SetNumber(object isolate, object holder, object number) { }

	// RVA: -1
	public abstract object SetString(object isolate, object holder, object str) { }

	// RVA: -1
	public abstract object SetBigInt(object isolate, object holder, object number) { }

	// RVA: -1
	public abstract object SetBoolean(object isolate, object holder, object b) { }

	// RVA: -1
	public abstract object SetNull(object isolate, object holder) { }

	// RVA: -1
	public abstract object SetArrayBuffer(object isolate, object holder, object arrayBuffer) { }

	// RVA: -1
	public abstract object SetRawString(object isolate, object holder, object rawString) { }

}

// Namespace: Puerts
public interface IGetValueFromJs
{

	// Methods

	// RVA: -1
	public abstract object GetJsValueType(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetNumber(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetString(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetBoolean(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetBigInt(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetNativeObject(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetTypeId(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetJSObject(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetFunction(object isolate, object holder, object isByRef) { }

	// RVA: -1
	public abstract object GetArrayBuffer(object isolate, object holder, object isByRef) { }

}

// Namespace: Puerts
public class GetValueFromResultImpl
{

	// Methods

	// RVA: 0xFF7B68
	public object GetBigInt(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7BA4
	public object GetBoolean(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7BC4
	public object GetFunction(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7BCC
	public object GetJSObject(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7BD4
	public object GetJsValueType(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7BDC
	public object GetNumber(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7BE4
	public object GetNativeObject(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7BEC
	public object GetTypeId(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7BF4
	public object GetString(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7C24
	public object GetArrayBuffer(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7B48
	public object .ctor() { }

}

// Namespace: Puerts
public class GetValueFromArgumentImpl
{

	// Methods

	// RVA: 0xFF7CAC
	public object GetBigInt(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7D0C
	public object GetBoolean(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7D34
	public object GetFunction(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7D44
	public object GetJSObject(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7D54
	public object GetJsValueType(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7D64
	public object GetNumber(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7D74
	public object GetNativeObject(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7D84
	public object GetTypeId(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7D94
	public object GetString(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7DCC
	public object GetArrayBuffer(object isolate, object holder, object isByRef) { }

	// RVA: 0xFF7B40
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass10_0
{

	// Fields
	public object isolate; // 0x8
	public object holder; // 0x10

	// Methods

	// RVA: 0xFF8124
	public object .ctor() { }

	// RVA: 0xFF812C
	internal object <SetRawString>b__0(object ptr, object length) { }

}

// Namespace: Puerts
public class SetValueToResultImpl
{

	// Methods

	// RVA: 0xFF7E6C
	public object SetArrayBuffer(object isolate, object holder, object arrayBuffer) { }

	// RVA: 0xFF7EA0
	public object SetBigInt(object isolate, object holder, object number) { }

	// RVA: 0xFF7EB0
	public object SetBoolean(object isolate, object holder, object b) { }

	// RVA: 0xFF7EC0
	public object SetNull(object isolate, object holder) { }

	// RVA: 0xFF7ECC
	public object SetNumber(object isolate, object holder, object number) { }

	// RVA: 0xFF7ED8
	public object SetNativeObject(object isolate, object holder, object classID, object self) { }

	// RVA: 0xFF7EEC
	public object SetFunction(object isolate, object holder, object JSFunction) { }

	// RVA: 0xFF7EFC
	public object SetJSObject(object isolate, object holder, object JSObject) { }

	// RVA: 0xFF7F0C
	public object SetString(object isolate, object holder, object str) { }

	// RVA: 0xFF7FB8
	public object SetRawString(object isolate, object holder, object rawString) { }

	// RVA: 0xFF7B50
	public object .ctor() { }

}

// Namespace: Puerts
public class SetValueToByRefArgumentImpl
{

	// Methods

	// RVA: 0xFF81AC
	public object SetArrayBuffer(object isolate, object holder, object arrayBuffer) { }

	// RVA: 0xFF81E0
	public object SetBigInt(object isolate, object holder, object number) { }

	// RVA: 0xFF81F0
	public object SetBoolean(object isolate, object holder, object b) { }

	// RVA: 0xFF8200
	public object SetNull(object isolate, object holder) { }

	// RVA: 0xFF820C
	public object SetNumber(object isolate, object holder, object number) { }

	// RVA: 0xFF8218
	public object SetNativeObject(object isolate, object holder, object classID, object self) { }

	// RVA: 0xFF822C
	public object SetFunction(object isolate, object holder, object JSFunction) { }

	// RVA: 0xFF8280
	public object SetJSObject(object isolate, object holder, object JSObject) { }

	// RVA: 0xFF82D4
	public object SetString(object isolate, object holder, object str) { }

	// RVA: 0xFF8338
	public object SetRawString(object isolate, object holder, object code) { }

	// RVA: 0xFF7B58
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass10_0
{

	// Fields
	public object holder; // 0x8

	// Methods

	// RVA: 0xFF85B4
	public object .ctor() { }

	// RVA: 0xFF85BC
	internal object <SetRawString>b__0(object ptr, object length) { }

}

// Namespace: Puerts
public class SetValueToArgumentImpl
{

	// Methods

	// RVA: 0xFF838C
	public object SetArrayBuffer(object isolate, object holder, object arrayBuffer) { }

	// RVA: 0xFF83B4
	public object SetBigInt(object isolate, object holder, object number) { }

	// RVA: 0xFF83C0
	public object SetBoolean(object isolate, object holder, object b) { }

	// RVA: 0xFF83CC
	public object SetNull(object isolate, object holder) { }

	// RVA: 0xFF83D4
	public object SetNumber(object isolate, object holder, object number) { }

	// RVA: 0xFF83DC
	public object SetNativeObject(object isolate, object holder, object classID, object self) { }

	// RVA: 0xFF83EC
	public object SetFunction(object isolate, object holder, object JSFunction) { }

	// RVA: 0xFF83F8
	public object SetJSObject(object isolate, object holder, object JSObject) { }

	// RVA: 0xFF8404
	public object SetString(object isolate, object holder, object str) { }

	// RVA: 0xFF8450
	public object SetRawString(object isolate, object holder, object rawString) { }

	// RVA: 0xFF7B60
	public object .ctor() { }

}

// Namespace: Puerts
internal class ReferenceEqualsComparer
{

	// Methods

	// RVA: 0xFF86A4
	public object Equals(object o1, object o2) { }

	// RVA: 0xFF86B0
	public object GetHashCode(object obj) { }

	// RVA: 0xFF86BC
	public object .ctor() { }

}

// Namespace: 
private struct Slot
{

	// Fields
	public object next; // 0xFFFFFFFFFFFFFFF8
	public object obj; // 0x0

	// Methods

	// RVA: 0xFF8910
	public object .ctor(object next, object obj) { }

}

// Namespace: Puerts
public class ObjectPool
{

	// Fields
	private const object SHIFT_BIT;
	private const object LIST_END;
	private const object ALLOCED;
	private object list; // 0x8
	private object freelist; // 0x10
	private object count; // 0x14
	private object reverseMap; // 0x18

	// Methods

	// RVA: 0xFE394C
	public object .ctor() { }

	// RVA: 0xFF87AC
	private object ExtendCapacity() { }

	// RVA: 0xFE6F1C
	public object FindOrAddObject(object obj) { }

	// RVA: 0xFF7638
	public object AddBoxedValueType(object obj) { }

	// RVA: 0xFF8888
	private object Add(object obj) { }

	// RVA: 0xFF86C4
	private object AddToFreeList(object obj) { }

	// RVA: 0xFF2ECC
	public object Get(object index) { }

	// RVA: 0xFE7178
	public object Remove(object index) { }

}

// Namespace: 
public sealed class PushFunc
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object jsEnvIdx, object isolate, object setValueApi, object function, object o) { }

}

// Namespace: 
public sealed class GetFunc
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

}

// Namespace: Puerts
public static class StaticTranslate<T0>
{

	// Fields
	public static object Set; // 0x0
	private static object Setter; // 0x0
	public static object Get; // 0x0
	private static object Getter; // 0x0

	// Methods

	// RVA: -1
	private static object DefaultPush(object jsEnvIdx, object isolate, object setValueApi, object function, object o) { }

	// RVA: -1
	private static object DefaultGetResult(object jsEnvIdx, object isolate, object getValueApi, object value, object isByRef) { }

	// RVA: -1
	public static object ReplaceDefault(object pushFunc, object getFunc) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Puerts
public static class PrimitiveTypeTranslate
{

	// Methods

	// RVA: 0xFF5530
	public static object PushChar(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF0F8C
	public static object GetChar(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF56C0
	public static object PushSByte(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF1118
	public static object GetSByte(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF5850
	public static object PushByte(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF12A8
	public static object GetByte(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF59E0
	public static object PushInt16(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF1434
	public static object GetInt16(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF5B70
	public static object PushUInt16(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF15C4
	public static object GetUInt16(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF5D00
	public static object PushInt32(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF1750
	public static object GetInt32(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF5E90
	public static object PushUInt32(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF18E4
	public static object GetUInt32(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF6020
	public static object PushInt64(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF1A84
	public static object GetInt64(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF61B0
	public static object PushUInt64(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF1F7C
	public static object GetUInt64(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF6340
	public static object PushDouble(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF2460
	public static object GetDouble(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF64D8
	public static object PushFloat(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF25D8
	public static object GetFloat(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF6670
	public static object PushBoolean(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF2758
	public static object GetBoolean(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF67F4
	public static object PushString(object jsEnvIdx, object isolate, object setValueApi, object holder, object i) { }

	// RVA: 0xFF2848
	public static object GetString(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFF698C
	public static object PushArrayBuffer(object jsEnvIdx, object isolate, object setValueApi, object holder, object arrayBuffer) { }

	// RVA: 0xFF2938
	public static object GetArrayBuffer(object jsEnvIdx, object isolate, object getValueApi, object holder, object isByRef) { }

	// RVA: 0xFEC180
	internal static object Init() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__13_0; // 0x8
	public static object <>9__14_0; // 0x10
	public static object <>9__14_1; // 0x18

	// Methods

	// RVA: 0xFF8EA8
	private static object .cctor() { }

	// RVA: 0xFF8F08
	public object .ctor() { }

	// RVA: 0xFF8F10
	internal object <GetNameWithoutNamespace>b__13_0(object x) { }

	// RVA: 0xFF8F98
	internal object <GetFriendlyName>b__14_0(object x) { }

	// RVA: 0xFF9020
	internal object <GetFriendlyName>b__14_1(object x) { }

}

// Namespace: Puerts
public static class TypeExtensions
{

	// Fields
	private static object AQNSimplify; // 0x0

	// Methods

	// RVA: 0xFF3A64
	internal static object IsValueType(object type) { }

	// RVA: 0xFF3A44
	internal static object IsAbstract(object type) { }

	// RVA: 0xFF8A88
	internal static object IsClass(object type) { }

	// RVA: 0xFF8AA8
	private static object GetNameWithoutNamespace(object type) { }

	// RVA: 0xFF4574
	public static object GetFriendlyName(object type, object genericArguments) { }

	// RVA: 0xFF8D30
	public static object AssemblyQualifiedNameSimplified(object type) { }

	// RVA: 0xFF8E14
	private static object .cctor() { }

}

// Namespace: Puerts
internal class TypeManager
{

	// Fields
	internal object RegisterInfoManager; // 0x8
	internal object TypeRegister; // 0x10
	private object arrayTypeId; // 0x18
	private readonly object typeIdMap; // 0x20
	private readonly object typeMap; // 0x28
	private readonly object jsEnv; // 0x30
	internal readonly object assemblies; // 0x38

	// Methods

	// RVA: 0xFE6BBC
	internal object AddRegisterInfoGetter(object type, object getter) { }

	// RVA: 0xFE3A38
	public object .ctor(object jsEnv) { }

	// RVA: 0xFE5F08
	internal object InitArrayTypeId() { }

	// RVA: 0xFF929C
	private object AddAssemblieByName(object assembliesUsorted, object name) { }

	// RVA: 0xFE81D0
	internal object GetType(object className, object isQualifiedName) { }

	// RVA: 0xFF9B74
	public object GetTypeId(object isolate, object type, object isFirst) { }

	// RVA: 0xFF2EBC
	public object IsArray(object typeId) { }

	// RVA: 0xFE9BA0
	public object GetTypeId(object isolate, object type) { }

	// RVA: 0xFE86E4
	public object GetType(object typeId) { }

}

// Namespace: Puerts
internal class PropertyMethods
{

	// Fields
	public object Getter; // 0x8
	public object Setter; // 0x10

	// Methods

	// RVA: 0xFFBB3C
	public object .ctor() { }

}

// Namespace: Puerts
internal class SlowBindingRegister
{

	// Fields
	public object registerInfo; // 0x8
	public object RegisterInfoManager; // 0x10
	public object slowBindingMethodGroup; // 0x18
	public object slowBindingProperties; // 0x20
	public object slowBindingFields; // 0x28
	public object needFillSlowBindingMethod; // 0x30
	public object needFillSlowBindingProperty; // 0x38

	// Methods

	// RVA: 0xFFBB44
	public object .ctor() { }

	// RVA: 0xFFBCB4
	internal object AddMethod(object methodKey, object method) { }

	// RVA: 0xFFC900
	internal object AddField(object fieldInfo) { }

}

// Namespace: 
private sealed class <>c__DisplayClass1_0
{

	// Fields
	public object translateFunc; // 0x8
	public object jsEnv; // 0x10
	public object field; // 0x18

	// Methods

	// RVA: 0xFFF56C
	public object .ctor() { }

	// RVA: 0xFFF57C
	internal object <GenFieldGetter>b__0(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0xFFF680
	internal object <GenFieldGetter>b__1(object isolate, object info, object self, object argumentsLen) { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object field; // 0x8
	public object typeMask; // 0x10
	public object translateFunc; // 0x18
	public object jsEnv; // 0x20

	// Methods

	// RVA: 0xFFF574
	public object .ctor() { }

	// RVA: 0xFFF7C8
	internal object <GenFieldSetter>b__0(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0xFFFD8C
	internal object <GenFieldSetter>b__1(object isolate, object info, object self, object argumentsLen) { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_1
{

	// Fields
	public object value; // 0x8
	public object isolate; // 0x10
	public object valuePtr; // 0x18
	public object CS$<>8__locals1; // 0x20

	// Methods

	// RVA: 0xFFFAFC
	public object .ctor() { }

	// RVA: 0x10000FC
	internal object <GenFieldSetter>b__2() { }

}

// Namespace: 
private sealed class <>c__DisplayClass2_2
{

	// Fields
	public object value; // 0x8
	public object isolate; // 0x10
	public object valuePtr; // 0x18
	public object CS$<>8__locals2; // 0x20

	// Methods

	// RVA: 0x10000F4
	public object .ctor() { }

	// RVA: 0x10001D4
	internal object <GenFieldSetter>b__3() { }

}

// Namespace: 
internal class FunctionCallbackFactory
{

	// Methods

	// RVA: 0xFFF4FC
	public static object EmptyConstructor(object isolate, object info, object paramLen, object data) { }

	// RVA: 0xFFF050
	public static object GenFieldGetter(object jsEnv, object type, object field) { }

	// RVA: 0xFFF1FC
	public static object GenFieldSetter(object jsEnv, object type, object field) { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_0
{

	// Fields
	public object <>4__this; // 0x8
	public object type; // 0x10
	public object translateFunc; // 0x18

	// Methods

	// RVA: 0xFFDE88
	public object .ctor() { }

	// RVA: 0x10002AC
	internal object <RegisterType>b__0(object isolate1, object info, object self, object argumentsLen) { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_1
{

	// Fields
	public object translateFunc1; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0xFFE70C
	public object .ctor() { }

	// RVA: 0x1000380
	internal object <RegisterType>b__1(object isolate1, object info, object self, object argumentsLen) { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_2
{

	// Fields
	public object kv; // 0x8
	public object CS$<>8__locals2; // 0x20

	// Methods

	// RVA: 0xFFEFC8
	public object .ctor() { }

	// RVA: 0x100047C
	internal object <RegisterType>b__2(object m) { }

}

// Namespace: 
private sealed class <>c__DisplayClass12_0
{

	// Fields
	public object <>4__this; // 0x8
	public object hasNoParametersCtor; // 0x10

	// Methods

	// RVA: 0xFFF460
	public object .ctor() { }

	// RVA: 0x1000530
	internal object <RegisterConstructor>b__0(object m) { }

}

// Namespace: 
private sealed class <>c__DisplayClass7_0
{

	// Fields
	public object <>4__this; // 0x8
	public object isolate; // 0x10

	// Methods

	// RVA: 0xFFCAC4
	public object .ctor() { }

	// RVA: 0x1000614
	internal object <InitArrayTypeId>b__0(object isolate1, object info, object self, object argumentsLen) { }

	// RVA: 0x1000A08
	internal object <InitArrayTypeId>b__1(object isolate1, object info, object self, object argumentsLen) { }

}

// Namespace: Puerts
internal class TypeRegister
{

	// Fields
	private object jsEnv; // 0x8
	private object RegisterInfoManager; // 0x10
	private readonly object callbackWrap; // 0x18
	private readonly object returnTrue; // 0x20
	private readonly object constructorWrap; // 0x28

	// Methods

	// RVA: 0xFF90A8
	public object .ctor(object jsEnv, object RegisterInfoManager) { }

	// RVA: 0xFF975C
	internal object InitArrayTypeId(object csArrayTypeId) { }

	// RVA: 0xFFCACC
	private object ArrayLength(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0xFFCCC4
	private object FastArrayGet(object isolate, object info, object self, object obj, object index) { }

	// RVA: 0xFFD450
	private object FastArraySet(object isolate, object info, object self, object obj, object index, object value) { }

	// RVA: 0xFF9D9C
	internal object RegisterType(object type, object baseTypeId, object includeNoPublic) { }

	// RVA: 0xFFDE90
	private object RegisterConstructor(object type, object registerInfo, object baseTypeId, object flag) { }

}

// Namespace: 
public sealed class GetValueForCheck
{

	// Methods

	// RVA: 0xFFFB04
	public object .ctor(object object, object method) { }

	// RVA: 0x1001F58
	public virtual object Invoke() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__8_0; // 0x8
	public static object <>9__8_2; // 0x10
	public static object <>9__8_3; // 0x18
	public static object <>9__8_6; // 0x20
	public static object <>9__8_5; // 0x28
	public static object <>9__8_4; // 0x30
	public static object <>9__8_7; // 0x38
	public static object <>9__8_8; // 0x40
	public static object <>9__8_10; // 0x48
	public static object <>9__9_0; // 0x50
	public static object <>9__9_2; // 0x58
	public static object <>9__9_3; // 0x60
	public static object <>9__9_6; // 0x68
	public static object <>9__9_5; // 0x70
	public static object <>9__9_4; // 0x78
	public static object <>9__9_8; // 0x80
	public static object <>9__9_9; // 0x88
	public static object <>9__9_11; // 0x90

	// Methods

	// RVA: 0x1001F6C
	private static object .cctor() { }

	// RVA: 0x1001FCC
	public object .ctor() { }

	// RVA: 0x1001FD4
	internal object <GetMethodAndOverrideMethodByName>b__8_0(object m) { }

	// RVA: 0x1002054
	internal object <GetMethodAndOverrideMethodByName>b__8_2(object m) { }

	// RVA: 0x10020A0
	internal object <GetMethodAndOverrideMethodByName>b__8_3(object i) { }

	// RVA: 0x100217C
	internal object <GetMethodAndOverrideMethodByName>b__8_4(object i) { }

	// RVA: 0x10022B4
	internal object <GetMethodAndOverrideMethodByName>b__8_5(object m) { }

	// RVA: 0x1002408
	internal object <GetMethodAndOverrideMethodByName>b__8_6(object o) { }

	// RVA: 0x1002454
	internal object <GetMethodAndOverrideMethodByName>b__8_7(object m) { }

	// RVA: 0x10024D4
	internal object <GetMethodAndOverrideMethodByName>b__8_8(object m) { }

	// RVA: 0x100256C
	internal object <GetMethodAndOverrideMethodByName>b__8_10(object o) { }

	// RVA: 0x10025B8
	internal object <GetMethodAndOverrideMethod>b__9_0(object m) { }

	// RVA: 0x1002604
	internal object <GetMethodAndOverrideMethod>b__9_2(object m) { }

	// RVA: 0x1002650
	internal object <GetMethodAndOverrideMethod>b__9_3(object i) { }

	// RVA: 0x100272C
	internal object <GetMethodAndOverrideMethod>b__9_4(object i) { }

	// RVA: 0x1002864
	internal object <GetMethodAndOverrideMethod>b__9_5(object m) { }

	// RVA: 0x10029B8
	internal object <GetMethodAndOverrideMethod>b__9_6(object o) { }

	// RVA: 0x1002A04
	internal object <GetMethodAndOverrideMethod>b__9_8(object m) { }

	// RVA: 0x1002A9C
	internal object <GetMethodAndOverrideMethod>b__9_9(object m) { }

	// RVA: 0x1002BBC
	internal object <GetMethodAndOverrideMethod>b__9_11(object o) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object type; // 0x8
	public object errorMethods; // 0x10
	public object matchTypes; // 0x18
	public object <>9__9; // 0x20

	// Methods

	// RVA: 0x10018FC
	public object .ctor() { }

	// RVA: 0x1002C08
	internal object <GetMethodAndOverrideMethodByName>b__1(object m) { }

	// RVA: 0x1002CE0
	internal object <GetMethodAndOverrideMethodByName>b__9(object m) { }

}

// Namespace: 
private sealed class <>c__DisplayClass9_0
{

	// Fields
	public object type; // 0x8
	public object methodNames; // 0x10
	public object errorMethods; // 0x18
	public object matchTypes; // 0x20
	public object <>9__7; // 0x28
	public object <>9__10; // 0x30

	// Methods

	// RVA: 0x1001904
	public object .ctor() { }

	// RVA: 0x1002EDC
	internal object <GetMethodAndOverrideMethod>b__1(object m) { }

	// RVA: 0x1002FB4
	internal object <GetMethodAndOverrideMethod>b__7(object m) { }

	// RVA: 0x1003054
	internal object <GetMethodAndOverrideMethod>b__10(object m) { }

}

// Namespace: Puerts
public static class Utils
{

	// Methods

	// RVA: 0xFE6CA0
	public static object TwoIntToLong(object b, object a) { }

	// RVA: 0xFEFFC8
	public static object LongToTwoInt(object c, object b, object a) { }

	// RVA: 0x1000E1C
	public static object GetObjectPtr(object jsEnvIdx, object type, object obj) { }

	// RVA: 0x1000F9C
	public static object GetSelf(object jsEnvIdx, object self) { }

	// RVA: 0xFFC410
	public static object IsSupportedMethod(object method) { }

	// RVA: 0x10010E0
	public static object GetMethodAndOverrideMethodByName(object type, object name) { }

	// RVA: 0xFFE714
	public static object GetMethodAndOverrideMethod(object type, object flag) { }

	// RVA: 0x100190C
	private static object IsVirtualMethod(object memberInfo) { }

	// RVA: 0x1001980
	private static object IsObsoleteError(object memberInfo) { }

	// RVA: 0x1001AC8
	private static object IsMatchParameters(object typeList, object pTypes) { }

	// RVA: 0xFFFB98
	public static object IsJsValueTypeMatchType(object jsType, object csType, object csTypeMask, object valueGetter, object value) { }

}

// Namespace: Puerts
public class DynamicBinderBridge
{
}

// Namespace: 
private sealed class <>c__DisplayClass2_0
{

	// Fields
	public object env; // 0x8

	// Methods

	// RVA: 0x1005344
	public object .ctor() { }

	// RVA: 0x100534C
	internal object <DynamicInvoke>b__0(object m) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object isolate; // 0x8
	public object jsEnvIdx; // 0x10
	public object value; // 0x18
	public object translateFunc; // 0x20
	public object valuePtr; // 0x28

	// Methods

	// RVA: 0x10055F8
	public object .ctor() { }

	// RVA: 0x1005600
	internal object <DynamicSet>b__0() { }

}

// Namespace: Puerts
public static class DynamicBinder
{

	// Methods

	// RVA: 0xFE5FE0
	public static object RegisterDynamicBinder(object jsEnv) { }

	// RVA: 0x10048F0
	private static object GetDynamicInfo(object isolate, object info, object env, object instance, object type, object memberName) { }

	// RVA: 0x10032D0
	public static object DynamicInvoke(object isolate, object info, object self, object paramLen, object data) { }

	// RVA: 0x10037F4
	public static object DynamicGet(object isolate, object info, object self, object paramLen, object data) { }

	// RVA: 0x1003EF8
	public static object DynamicSet(object isolate, object info, object self, object paramLen, object data) { }

	// RVA: 0x1005064
	private static object GetType(object jsEnv, object className) { }

}

// Namespace: Puerts
public class GenericMethodWrap
{

	// Fields
	private object memberName; // 0x8
	private object env; // 0x10
	private object definitionType; // 0x18
	private object genericArguments; // 0x20
	protected object reflectionWrap; // 0x28

	// Methods

	// RVA: 0x10056CC
	public object .ctor(object memberName, object env, object definitionType, object genericArguments) { }

	// RVA: 0x1005718
	public object Invoke(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0x1006030
	private object <Invoke>b__6_0(object item) { }

	// RVA: 0x1006104
	private object <Invoke>b__6_1(object item) { }

	// RVA: 0x100615C
	private object <Invoke>b__6_2(object m) { }

}

// Namespace: Puerts
public class LazyAPINative
{
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__8_0; // 0x8

	// Methods

	// RVA: 0x1008774
	private static object .cctor() { }

	// RVA: 0x10087D4
	public object .ctor() { }

	// RVA: 0x10087DC
	internal object <RegisterAPI>b__8_0(object x) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object jsEnv; // 0x8

	// Methods

	// RVA: 0x1008018
	public object .ctor() { }

	// RVA: 0x1008860
	internal object <RegisterLazyAPI>b__0() { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object jsEnv; // 0x8

	// Methods

	// RVA: 0x10083C8
	public object .ctor() { }

	// RVA: 0x100896C
	internal object <RegisterAPI>b__1(object m) { }

}

// Namespace: Puerts
public static class LazyAPI
{

	// Fields
	private static readonly object enabledJsEnvs; // 0x0
	private static readonly object callbacksE; // 0x8
	private static readonly object sw; // 0x10

	// Methods

	// RVA: 0x1007BC8
	public static object IsReflectionAPIEnabled(object e) { }

	// RVA: 0x1007C7C
	public static object RegisterLazyAPI(object jsEnv) { }

	// RVA: 0x1006240
	private static object SetEnabled(object isolate, object info, object self, object paramLen, object data) { }

	// RVA: 0x10065A0
	private static object ClearAllAPI(object isolate, object info, object self, object paramLen, object data) { }

	// RVA: 0x1008020
	private static object Invoke(object thiz, object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0x10067C0
	private static object RegisterAPI(object isolate, object info, object self, object paramLen, object data) { }

	// RVA: 0x1008418
	private static object AddCallbackExt(object callback, object envIdx) { }

	// RVA: 0x1007974
	private static object JsEnvCallbackWrapExt(object isolate, object info, object self, object paramLen, object data) { }

	// RVA: 0x1008658
	private static object .cctor() { }

}

// Namespace: Puerts
public class LazyMembersWrap
{

	// Fields
	protected object memberName; // 0x8
	protected object jsEnv; // 0x10
	protected object definitionType; // 0x18
	protected object flag; // 0x20

	// Methods

	// RVA: 0x10089E0
	public object .ctor(object memberName, object jsEnv, object definitionType) { }

}

// Namespace: 
private sealed class <>c__DisplayClass5_0
{

	// Fields
	public object translateFunc; // 0x8
	public object <>4__this; // 0x10
	public object field; // 0x18

	// Methods

	// RVA: 0x1008D94
	public object .ctor() { }

	// RVA: 0x1008DA4
	internal object <GenFieldGetter>b__0(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0x1008EBC
	internal object <GenFieldGetter>b__1(object isolate, object info, object self, object argumentsLen) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object field; // 0x8
	public object typeMask; // 0x10
	public object translateFunc; // 0x18
	public object <>4__this; // 0x20

	// Methods

	// RVA: 0x1008D9C
	public object .ctor() { }

	// RVA: 0x1009030
	internal object <GenFieldSetter>b__0(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0x1009340
	internal object <GenFieldSetter>b__1(object isolate, object info, object self, object argumentsLen) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_1
{

	// Fields
	public object value; // 0x8
	public object isolate; // 0x10
	public object valuePtr; // 0x18
	public object CS$<>8__locals1; // 0x20

	// Methods

	// RVA: 0x1009338
	public object .ctor() { }

	// RVA: 0x100969C
	internal object <GenFieldSetter>b__2() { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_2
{

	// Fields
	public object value; // 0x8
	public object isolate; // 0x10
	public object valuePtr; // 0x18
	public object CS$<>8__locals2; // 0x20

	// Methods

	// RVA: 0x1009694
	public object .ctor() { }

	// RVA: 0x1009788
	internal object <GenFieldSetter>b__3() { }

}

// Namespace: Puerts
public class LazyFieldWrap
{

	// Fields
	private object Getter; // 0x28
	private object Setter; // 0x30

	// Methods

	// RVA: 0x10083D0
	public object .ctor(object memberName, object jsEnv, object definitionType) { }

	// RVA: 0x1008184
	public object InvokeSetter(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0x10082AC
	public object InvokeGetter(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0x1008A28
	private object GenFieldGetter(object type, object field) { }

	// RVA: 0x1008BA0
	private object GenFieldSetter(object type, object field) { }

}

// Namespace: Puerts
public struct JSCallInfo
{

	// Fields
	public object Isolate; // 0xFFFFFFFFFFFFFFF8
	public object Info; // 0x0
	public object Self; // 0x8
	public object Length; // 0x10
	public object JsTypes; // 0x18
	public object Values; // 0x20
	public object NativePtrs; // 0x28

	// Methods

	// RVA: 0x10098B0
	public object .ctor(object isolate, object info, object self, object len, object argsStart) { }

}

// Namespace: 
private sealed class <>c__DisplayClass12_0
{

	// Fields
	public object jsCallInfo; // 0x8
	public object <>4__this; // 0x40
	public object i; // 0x48
	public object <>9__0; // 0x50

	// Methods

	// RVA: 0x100A2B0
	public object .ctor() { }

	// RVA: 0x100A9D4
	internal object <IsMatch>b__0() { }

}

// Namespace: Puerts
public class Parameters
{

	// Fields
	internal readonly object paramLength; // 0x8
	private readonly object jsEnv; // 0x10
	private object hasParamsArray; // 0x18
	private object paramJSTypeMasks; // 0x20
	internal object optionalParamPos; // 0x28
	private object paramTypes; // 0x30
	private object args; // 0x38
	private object paramIsByRef; // 0x40
	private object isOut; // 0x48
	private object argsTranslateFuncs; // 0x50
	private object byRefValueSetFuncs; // 0x58

	// Methods

	// RVA: 0x1009A34
	public object .ctor(object parameterInfos, object jsEnv) { }

	// RVA: 0x1009F90
	public object IsMatch(object jsCallInfo) { }

	// RVA: 0x100A2B8
	public object GetArguments(object callInfo) { }

	// RVA: 0x100A76C
	public object FillByRefParameters(object callInfo, object argsWithNewRef) { }

	// RVA: 0x100A99C
	public object ClearArguments() { }

}

// Namespace: Puerts
public class OverloadReflectionWrap
{

	// Fields
	private object jsEnv; // 0x8
	internal object parameters; // 0x10
	private object methodInfo; // 0x18
	private object constructorInfo; // 0x20
	private object type; // 0x28
	private object resultSetter; // 0x30
	private object extensionMethod; // 0x38

	// Methods

	// RVA: 0x10053C0
	public object .ctor(object methodBase, object jsEnv, object extensionMethod) { }

	// RVA: 0x100ABA4
	public object .ctor(object type, object jsEnv) { }

	// RVA: 0x100AC50
	public object IsMatch(object jsCallInfo) { }

	// RVA: 0x100AC9C
	public object InvokeWithTarget(object jsCallInfo, object target) { }

	// RVA: 0x100B314
	public object Invoke(object jsCallInfo) { }

	// RVA: 0x100B9D8
	public object Construct(object callInfo) { }

}

// Namespace: Puerts
public class DelegateConstructWrap
{

	// Fields
	private object delegateType; // 0x8
	private object translateFunc; // 0x10
	private object jsEnvIdx; // 0x18

	// Methods

	// RVA: 0x100BB40
	public object .ctor(object delegateType, object jsEnv) { }

	// RVA: 0x100BBB4
	public object Construct(object isolate, object info, object argumentsLen) { }

}

// Namespace: Puerts
public class MethodReflectionWrap
{

	// Fields
	private object name; // 0x8
	private object overloads; // 0x10

	// Methods

	// RVA: 0x1005AEC
	public object .ctor(object name, object overloads) { }

	// RVA: 0x1005B24
	public object Invoke(object isolate, object info, object self, object argumentsLen) { }

	// RVA: 0x100BEE0
	public object Construct(object isolate, object info, object argumentsLen) { }

}

// Namespace: Puerts
public struct MethodKey
{

	// Fields
	public object Name; // 0xFFFFFFFFFFFFFFF8
	public object IsStatic; // 0x0
	public object IsExtension; // 0x1
}

// Namespace: Puerts
public interface ILoader
{
}

// Namespace: Puerts
public interface IRawString
{

	// Methods

	// RVA: -1
	public abstract object Marshaling(object setRawString) { }

}

// Namespace: Puerts
public interface IRawFileLoader
{
}

// Namespace: Puerts
public interface IModuleChecker
{
}

// Namespace: Puerts
public interface IByteCodeLoader
{
}

// Namespace: Puerts
public interface IResolvableLoader
{
}

// Namespace: Puerts
public interface IBuiltinLoadedListener
{

	// Methods

	// RVA: -1
	public abstract object OnBuiltinLoaded(object env) { }

}

// Namespace: Puerts
public class DefaultLoader
{

	// Fields
	private object root; // 0x8

	// Methods

	// RVA: 0x100C2F0
	public object .ctor() { }

	// RVA: 0x100C350
	public object .ctor(object root) { }

	// RVA: 0x100C3B8
	private object PathToUse(object filepath) { }

	// RVA: 0x100C4D8
	public object FileExists(object filepath) { }

	// RVA: 0x100C588
	public object ReadFile(object filepath, object debugpath) { }

}

// Namespace: Puerts
public class PathHelper
{

	// Fields
	private static object SLASH; // 0x0
	private static object DOT; // 0x2
	internal static object JSCode; // 0x8

	// Methods

	// RVA: 0x100C6E8
	public static object IsRelative(object filepath) { }

	// RVA: 0x100C7C4
	public static object Dirname(object filepath) { }

	// RVA: 0x100C910
	protected static object posixNormalize(object path, object allowAboveRoot) { }

	// RVA: 0x100CC18
	protected static object decode(object s) { }

	// RVA: 0x100CD08
	public static object normalize(object p) { }

	// RVA: 0x100CEE0
	private static object .cctor() { }

}

// Namespace: Puerts
public enum BindingMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FastBinding;
	public const object LazyBinding;
	public const object SlowBinding;
	public const object DontBinding;
}

// Namespace: Puerts
public interface TypedValue
{

	// Properties
	public abstract object Target { get; }

	// Methods

	// RVA: -1
	public abstract object get_Target() { }

}

// Namespace: Puerts
public class Any<T0>
{

	// Fields
	private object mTarget; // 0x0

	// Properties
	public object Target { get; }

	// Methods

	// RVA: -1
	public object .ctor(object i) { }

	// RVA: -1
	public object get_Target() { }

}

// Namespace: Puerts
public class ByteValue
{

	// Methods

	// RVA: 0x100CF58
	public object .ctor(object i) { }

}

// Namespace: Puerts
public class SByteValue
{

	// Methods

	// RVA: 0x100CFB8
	public object .ctor(object i) { }

}

// Namespace: Puerts
public class CharValue
{

	// Methods

	// RVA: 0x100D018
	public object .ctor(object i) { }

}

// Namespace: Puerts
public class Int16Value
{

	// Methods

	// RVA: 0x100D078
	public object .ctor(object i) { }

}

// Namespace: Puerts
public class UInt16Value
{

	// Methods

	// RVA: 0x100D0D8
	public object .ctor(object i) { }

}

// Namespace: Puerts
public class Int32Value
{

	// Methods

	// RVA: 0x100D138
	public object .ctor(object i) { }

}

// Namespace: Puerts
public class UInt32Value
{

	// Methods

	// RVA: 0x100D198
	public object .ctor(object i) { }

}

// Namespace: Puerts
public class Int64Value
{

	// Methods

	// RVA: 0x100D1F8
	public object .ctor(object i) { }

	// RVA: 0x100D258
	public object .ctor(object str) { }

}

// Namespace: Puerts
public class UInt64Value
{

	// Methods

	// RVA: 0x100D2C0
	public object .ctor(object i) { }

	// RVA: 0x100D320
	public object .ctor(object str) { }

}

// Namespace: Puerts
public class FloatValue
{

	// Methods

	// RVA: 0x100D388
	public object .ctor(object i) { }

}

// Namespace: Puerts
public class DoubleValue
{

	// Methods

	// RVA: 0x100D3F0
	public object .ctor(object i) { }

}

// Namespace: Puerts.TypeMapping
public enum MemberType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Constructor;
	public const object Method;
	public const object Property;
}

// Namespace: Puerts.TypeMapping
public class MemberRegisterInfo
{

	// Fields
	public object Name; // 0x8
	public object IsStatic; // 0x10
	public object MemberType; // 0x14
	public object UseBindingMode; // 0x18
	public object Constructor; // 0x20
	public object Method; // 0x28
	public object PropertyGetter; // 0x30
	public object PropertySetter; // 0x38

	// Methods

	// RVA: 0x100D458
	public object .ctor() { }

}

// Namespace: Puerts.TypeMapping
public class RegisterInfo
{

	// Fields
	public object BlittableCopy; // 0x8
	public object Members; // 0x10

	// Methods

	// RVA: 0x100D460
	public object .ctor() { }

}

// Namespace: Puerts.TypeMapping
internal class RegisterInfoManager
{

	// Fields
	private object RegisterInfoGetters; // 0x8
	protected object _DefaultBindingMode; // 0x10

	// Properties
	public object DefaultBindingMode { get; }

	// Methods

	// RVA: 0x100D468
	public object get_DefaultBindingMode() { }

	// RVA: 0x100D470
	internal object Add(object type, object RegisterInfoGetter) { }

	// RVA: 0x100D52C
	internal object TryGetValue(object key, object value) { }

	// RVA: 0x100D5A0
	internal object Remove(object type) { }

	// RVA: 0x100D60C
	public object .ctor() { }

}

