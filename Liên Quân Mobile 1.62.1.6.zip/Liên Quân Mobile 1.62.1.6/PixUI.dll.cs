// Namespace: 
internal class <Module>
{
}

// Namespace: com.pixui
public class BorderCmd
{

	// Fields
	public object border; // 0x58
	public object radius; // 0x88

	// Methods

	// RVA: 0x3CFA3A8
	public object Set(object mat, object rect, object border, object radius) { }

	// RVA: 0x3CFA3E4
	public override object ToString() { }

	// RVA: 0x3CFA59C
	public object .ctor() { }

}

// Namespace: com.pixui
public class BorderImageCmd
{

	// Fields
	public object asset; // 0x58
	public object color; // 0x60
	public object slice; // 0x64
	public object srcUVRegion; // 0x7C
	public object widths; // 0x8C

	// Methods

	// RVA: 0x3CFA694
	public object Set(object asset, object mat, object drawRect, object uv, object slice, object color, object widths) { }

	// RVA: 0x3CFA7D8
	public object .ctor() { }

}

// Namespace: com.pixui
public class BoxShadowCmd
{

	// Fields
	public object radius; // 0x58
	public object color; // 0x78
	public object blur; // 0x7C

	// Methods

	// RVA: 0x3CFA854
	public object .ctor() { }

	// RVA: 0x3CFA8DC
	public object Set(object mat, object size, object radius, object color, object blur) { }

}

// Namespace: com.pixui
public class ClipCmd
{

	// Methods

	// RVA: 0x3CFA9FC
	public object Set(object localMat, object rect) { }

	// RVA: 0x3CFAA18
	public override object ToString() { }

	// RVA: 0x3CFAAF4
	public object .ctor() { }

}

// Namespace: com.pixui
public class ContainerCmd
{

	// Fields
	public object childCount; // 0x58

	// Methods

	// RVA: 0x3CFAB70
	public object .ctor() { }

}

// Namespace: com.pixui
public class ContentImageCmd
{

	// Fields
	public object asset; // 0x58
	public object attachment; // 0x60
	public object color; // 0x64
	public object radius; // 0x68
	public object repeat; // 0x88
	public object slice; // 0x8C
	public object srcUVRegion; // 0xA4
	public object widths; // 0xB4

	// Methods

	// RVA: 0x3CFABEC
	public object Set(object asset, object mat, object drawRect, object sourceRegion, object repeat, object attachment, object slice, object color, object radius, object widths) { }

	// RVA: 0x3CFAD48
	public override object ToString() { }

	// RVA: 0x3CFB050
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__6<T0>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__6_1; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <Reg>b__6_1(object cmd) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0<T0>
{

	// Fields
	public object type; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <Reg>b__0() { }

}

// Namespace: 
private static class Helper
{

	// Fields
	public static readonly object _cacheDict; // 0x0
	public static readonly object _nameDict; // 0x8
	public static readonly object _tagNameDict; // 0x10

	// Methods

	// RVA: 0x3CFBB98
	private static object InitTagNameDict() { }

	// RVA: 0x3CFC004
	private static object .cctor() { }

	// RVA: -1
	private static object Reg(object type) { }

	// RVA: 0x3CFB34C
	public static object GetName(object type) { }

	// RVA: 0x3CFBAD0
	public static object GetTagName(object tagType) { }

	// RVA: 0x3CFC268
	public static object GetCmd(object type) { }

	// RVA: 0x3CFB474
	public static object Release(object cmd) { }

}

// Namespace: com.pixui
public class DrawCmd
{

	// Fields
	public object container; // 0x8
	public object rect; // 0x10
	public object widget; // 0x20
	public object id; // 0x28
	public object index; // 0x2C
	public object localMat; // 0x30
	public object type; // 0x48
	public object m_DebugName; // 0x50

	// Methods

	// RVA: 0x3CFB0CC
	public object Clear() { }

	// RVA: 0x3CFB0DC
	public object Emit(object factory) { }

	// RVA: 0x3CFB254
	public object GetDrawCmdName() { }

	// RVA: 0x3CFB25C
	public static object GetDrawCmdName(object type) { }

	// RVA: -1
	public static object Get(object type) { }

	// RVA: 0x3CFB3F4
	public static object Release(object cmd) { }

	// RVA: 0x3CFA4C8
	public override object ToString() { }

	// RVA: 0x3CFB554
	public object SetDebugInfo(object debugInfo, object window) { }

	// RVA: 0x3CFA618
	public object .ctor() { }

}

// Namespace: com.pixui
public enum DrawType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unknown;
	public const object GradientImage;
	public const object BorderImage;
	public const object ContentImage;
	public const object Text;
	public const object Border;
	public const object Line;
	public const object Rect;
	public const object Clip;
	public const object Group;
	public const object TextShadow;
	public const object Window;
	public const object Slot;
	public const object RenderLayer;
	public const object BoxShadow;
	public const object Count;
}

// Namespace: com.pixui
public class GradientImageCmd
{

	// Fields
	public object asset; // 0x58
	public object radius; // 0x60

	// Methods

	// RVA: 0x3CFC338
	public object Set(object asset, object mat, object drawRect, object radius) { }

	// RVA: 0x3CFC424
	public object .ctor() { }

}

// Namespace: com.pixui
public class GroupCmd
{

	// Fields
	public object size; // 0x5C

	// Methods

	// RVA: 0x3CFC4A0
	public object Set(object localMat, object size) { }

	// RVA: 0x3CFC4BC
	public object .ctor() { }

}

// Namespace: com.pixui
public class LineCmd
{

	// Fields
	public object color; // 0x58
	public object endPos; // 0x5C
	public object lineType; // 0x64
	public object startPos; // 0x68
	public object width; // 0x70

	// Methods

	// RVA: 0x3CFC538
	public object Set(object localMat, object width, object lineType, object color, object startPos, object endPos) { }

	// RVA: 0x3CFC660
	public override object ToString() { }

	// RVA: 0x3CFC8C8
	public object .ctor() { }

}

// Namespace: com.pixui
public class RectCmd
{

	// Fields
	public object color; // 0x58
	public object radius; // 0x5C

	// Methods

	// RVA: 0x3CFC944
	public object Set(object mat, object rect, object color, object radius) { }

	// RVA: 0x3CFCA38
	public override object ToString() { }

	// RVA: 0x3CFCB10
	public object .ctor() { }

}

// Namespace: com.pixui
public class RenderLayerCmd
{

	// Fields
	public object size; // 0x5C

	// Methods

	// RVA: 0x3CFCB8C
	public object Set(object localMat, object size) { }

	// RVA: 0x3CFCBA8
	public object .ctor() { }

}

// Namespace: com.pixui
public class SlotCmd
{

	// Fields
	public object handle; // 0x5C
	public object name; // 0x60

	// Methods

	// RVA: 0x3CFCC24
	public object Set(object slotHandle, object mat, object rect) { }

	// RVA: 0x3CFCCFC
	public override object ToString() { }

	// RVA: 0x3CFCED0
	public object .ctor() { }

}

// Namespace: com.pixui
public class TextCmd
{

	// Fields
	public object color; // 0x58
	public object fontInfo; // 0x60
	public object text; // 0x68
	public object spacing; // 0x78
	public object strokeWidth; // 0x7C
	public object strokeColor; // 0x80
	public object blur; // 0x84
	public object shadowColor; // 0x88
	public object shadowOffsetX; // 0x8C
	public object shadowOffsetY; // 0x90

	// Methods

	// RVA: 0x3CFCF4C
	public object Set(object mat, object text, object rect, object fontInfo, object color, object spacing) { }

	// RVA: 0x3CFD064
	public object SetStroke(object strokeWdith, object strokeColor) { }

	// RVA: 0x3CFD070
	public object SetShadow(object offsetX, object offsetY, object blur, object shadowColor) { }

	// RVA: 0x3CFD0E4
	public override object ToString() { }

	// RVA: 0x3CFD324
	public object .ctor() { }

}

// Namespace: com.pixui
public class TextShadowCmd
{

	// Fields
	public object positionX; // 0x58
	public object positionY; // 0x5C
	public object blur; // 0x60
	public object color; // 0x64

	// Methods

	// RVA: 0x3CFD3A0
	public object .ctor() { }

	// RVA: 0x3CFD428
	public object Set(object positionX, object positionY, object color, object blur) { }

	// RVA: 0x3CFD43C
	public override object ToString() { }

}

// Namespace: com.pixui
public class WindowCmd
{

	// Methods

	// RVA: 0x3CFD63C
	public object .ctor() { }

}

// Namespace: 
public class Options
{

	// Fields
	public object enableDefaultFont; // 0x8
	public object defaultFontName; // 0x10
	public object defaultFontSize; // 0x18
	public object getFont; // 0x20
	public object getShader; // 0x28
	public object onOpenChildWindow; // 0x30
	public object onLoadDataSyncThreaded; // 0x38
	public object onReleaseDataSyncThreaded; // 0x40
	public object onLoadDataAsyncThreaded; // 0x48
	public object onLoadDataAsync; // 0x50
	public object onLoadDataSync; // 0x58
	public object logLevel; // 0x60
	public object luaRPCPost; // 0x68
	public object onLoadComplete; // 0x70
	public object onScriptInit; // 0x78
	public object onScriptShutdown; // 0x80
	public object onWindowAlert; // 0x88
	public object onWindowConfirm; // 0x90
	public object sendMessage; // 0x98
	public object writeablePath; // 0xA0
	public object writeLog; // 0xA8
	public object shouldOverrideImageLoading; // 0xB0
	public object shouldOverrideSlotAttachmentLoad; // 0xB8
	public object onInternalError; // 0xC0
	public object enableWidgetPrefably; // 0xC8
	public object uguiWorkingColorSpace; // 0xCC
	public object getDefaultMountRoot; // 0xD0
	public object onRenderElementCreated; // 0xD8
	public object onRenderElementDestroying; // 0xE0
	public object onRenderElementEnable; // 0xE8
	public object onRenderElementPaint; // 0xF0
	public object getLocalFilePath; // 0xF8
	public object canResolveFilePath; // 0x100
	public object openFile; // 0x108
	public object closeFile; // 0x110
	public object readFile; // 0x118
	public object seekFile; // 0x120
	public object invalidChar; // 0x128
	public object useGeometryBorder; // 0x12A

	// Methods

	// RVA: 0x3D0179C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__13_0; // 0x8
	public static object <>9__13_1; // 0x10
	public static object <>9__13_2; // 0x18
	public static object <>9__13_3; // 0x20

	// Methods

	// RVA: 0x3D01AD8
	private static object .cctor() { }

	// RVA: 0x3D01B38
	public object .ctor() { }

	// RVA: 0x3D01B40
	internal object <Init>b__13_0(object windowId, object handle, object src) { }

	// RVA: 0x3D01BF0
	internal object <Init>b__13_1(object windowId, object handle) { }

	// RVA: 0x3D01C88
	internal object <Init>b__13_2(object windowId, object handle, object slot) { }

	// RVA: 0x3D01D68
	internal object <Init>b__13_3(object windowId, object handle, object slot) { }

}

// Namespace: 
private sealed class <>c__DisplayClass45_0
{

	// Fields
	public object windowId; // 0x8

	// Methods

	// RVA: 0x3D0075C
	public object .ctor() { }

	// RVA: 0x3D01E1C
	internal object <RemoveWindow>b__0() { }

}

// Namespace: com.pixui
public static class PixUI
{

	// Fields
	private static object _mainThreadId; // 0x0
	private static object _root; // 0x8
	private static object _stashingSlotRoot; // 0x10
	private static object _slotAttachmentMgr; // 0x18
	private static object _isInit; // 0x20
	private static object _disposing; // 0x21
	private static object emptyWindowList; // 0x28

	// Methods

	// RVA: 0x3CFD6B8
	public static object IsReady() { }

	// RVA: 0x3CFD734
	public static object GetRootObj() { }

	// RVA: 0x3CFD7B0
	public static object Init(object options) { }

	// RVA: 0x3CFEC00
	public static object Shutdown() { }

	// RVA: 0x3CFEFA0
	public static object GetWindowRoot(object windowId) { }

	// RVA: 0x3CFF28C
	public static object GetManagedVersion() { }

	// RVA: 0x3CFF2D0
	public static object GetNativeVersion() { }

	// RVA: 0x3CFF2EC
	public static object GetUserAgent() { }

	// RVA: 0x3CFF308
	public static object SendMessage(object windowId, object msg) { }

	// RVA: 0x3CFF4C0
	internal static object getDefaultMountRoot() { }

	// RVA: 0x3CFF96C
	private static object CreateWindow(object root, object windowId, object parentWndId) { }

	// RVA: 0x3CFFE84
	public static object LoadUrl(object root, object url, object parentWndId) { }

	// RVA: 0x3D000D4
	public static object LoadUrl(object windowId, object root, object url, object parentWndId) { }

	// RVA: 0x3D00354
	public static object CreateWindow(object root) { }

	// RVA: 0x3CFF0B0
	public static object GetWindow(object windowId) { }

	// RVA: 0x3D004B0
	public static object RemoveWindow(object windowId, object immediately) { }

	// RVA: 0x3D00AB8
	public static object ClearWindows(object isImmediately) { }

	// RVA: 0x3D00EF8
	public static object ConfirmExternalImage(object windowId, object url, object textureId, object drawableAsset, object error) { }

	// RVA: 0x3D01188
	public static object Repaint(object windowId) { }

	// RVA: 0x3D01364
	public static object GetSlotAttachmentByHandle(object windowId, object handle) { }

	// RVA: 0x3D01490
	public static object WaitForSocketsCloseDone(object timeoutMS, object callback) { }

	// RVA: 0x3D01700
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__6_0; // 0x8

	// Methods

	// RVA: 0x3D03A84
	private static object .cctor() { }

	// RVA: 0x3D03AE4
	public object .ctor() { }

	// RVA: 0x3D03AEC
	internal object <Clear>b__6_0(object t) { }

}

// Namespace: 
private sealed class <>c__DisplayClass13_0
{

	// Fields
	public object asset; // 0x8

	// Methods

	// RVA: 0x3D03564
	public object .ctor() { }

	// RVA: 0x3D03B70
	internal object <CreateTexture>b__0(object _) { }

}

// Namespace: com.pixui
public class PxAssetMgr
{

	// Fields
	private readonly object m_Assets; // 0x8
	private const object m_LinearGradientSchema;
	private object m_LinearGradientRegex; // 0x10
	private static object s_PixelFormatToUnityFormat; // 0x0

	// Methods

	// RVA: 0x3D01EAC
	public object GetAsset(object id) { }

	// RVA: 0x3D01114
	public object AddAsset(object id, object asset) { }

	// RVA: 0x3D01F08
	public object RemoveAsset(object id) { }

	// RVA: 0x3D020B0
	public object Clear() { }

	// RVA: 0x3D02238
	internal object InternalImageLoader(object windowId, object url, object textureId) { }

	// RVA: 0x3D02A20
	public static object TryGetUnityPixelFormatFromPixelFormat(object format, object unityFormat) { }

	// RVA: 0x3D02AD4
	private static object GetBitsPerBlock(object format) { }

	// RVA: 0x3D02B44
	private static object GetBlockSize(object format) { }

	// RVA: 0x3D02BFC
	private static object CalcTextureGpuSize(object format, object width, object height, object gpuWidth, object gpuHeight, object gpuDataSize) { }

	// RVA: 0x3D02DD0
	public object CreateTexture(object url, object textureId, object width, object height, object flag, object format, object ptr, object dataSize) { }

	// RVA: 0x3D03800
	public object .ctor() { }

	// RVA: 0x3D038CC
	private static object .cctor() { }

}

// Namespace: 
public sealed class OnRelease
{

	// Methods

	// RVA: 0x3D03640
	public object .ctor(object object, object method) { }

	// RVA: 0x3D04048
	public virtual object Invoke(object asset) { }

}

// Namespace: com.pixui
public abstract class PxDrawableAsset
{

	// Fields
	private object <id>k__BackingField; // 0x8
	private object <url>k__BackingField; // 0x10
	private object onRelease; // 0x18
	private object _disposed; // 0x20
	private object <flipVertical>k__BackingField; // 0x21

	// Properties
	public object id { get; set; }
	private object url { set; }
	public object flipVertical { get; set; }
	public abstract object width { get; }
	public abstract object height { get; }

	// Methods

	// RVA: 0x3D03C64
	public object get_id() { }

	// RVA: 0x3D03C6C
	private object set_id(object value) { }

	// RVA: 0x3D03C74
	private object set_url(object value) { }

	// RVA: 0x3D0375C
	public object add_onRelease(object value) { }

	// RVA: 0x3D03C7C
	public object remove_onRelease(object value) { }

	// RVA: 0x3D03D20
	public object get_flipVertical() { }

	// RVA: 0x3D03D28
	public object set_flipVertical(object value) { }

	// RVA: 0x3D03D30
	public object .ctor(object url, object id) { }

	// RVA: -1
	public abstract object get_width() { }

	// RVA: -1
	public abstract object get_height() { }

	// RVA: 0x3D03D6C
	protected virtual object OnDispose() { }

	// RVA: 0x3D0203C
	public object Dispose() { }

}

// Namespace: com.pixui
public class PxDrawableMaterial
{

	// Fields
	private object <material>k__BackingField; // 0x28
	private object <size>k__BackingField; // 0x30

	// Properties
	public object material { get; }
	public object size { get; }
	public override object width { get; }
	public override object height { get; }

	// Methods

	// RVA: 0x3D0405C
	public object get_material() { }

	// RVA: 0x3D04064
	public object get_size() { }

	// RVA: 0x3D0406C
	public override object get_width() { }

	// RVA: 0x3D04074
	public override object get_height() { }

}

// Namespace: com.pixui
public class PxDrawableTexture
{

	// Fields
	private object <texture>k__BackingField; // 0x28
	private object m_Width; // 0x30
	private object m_Height; // 0x34
	private object m_SpriteRect; // 0x38
	protected object m_TextureWithRepeat; // 0x48
	private object <premultipliedAlpha>k__BackingField; // 0x50

	// Properties
	public object texture { get; set; }
	public object premultipliedAlpha { get; set; }
	public override object width { get; }
	public override object height { get; }
	public object spriteRect { get; }

	// Methods

	// RVA: 0x3D0407C
	public object get_texture() { }

	// RVA: 0x3D04084
	private object set_texture(object value) { }

	// RVA: 0x3D0408C
	public object get_premultipliedAlpha() { }

	// RVA: 0x3D04094
	public object set_premultipliedAlpha(object value) { }

	// RVA: 0x3D0409C
	public object .ctor(object url, object id, object texture, object width, object height) { }

	// RVA: 0x3D040F4
	public object .ctor(object url, object id, object texture) { }

	// RVA: 0x3D041F4
	public override object get_width() { }

	// RVA: 0x3D04200
	public override object get_height() { }

	// RVA: 0x3D0420C
	public object get_spriteRect() { }

	// RVA: 0x3D04218
	protected virtual object OnCreateTextureVariant() { }

	// RVA: 0x3D04220
	public object UseRepeatVariant() { }

	// RVA: 0x3D04474
	protected override object OnDispose() { }

}

// Namespace: com.pixui
public class PxDrawableTexture2D
{

	// Properties
	public object texture2D { get; }

	// Methods

	// RVA: 0x3D04540
	public object get_texture2D() { }

	// RVA: 0x3D035E8
	public object .ctor(object url, object id, object texture2D, object width, object height) { }

	// RVA: 0x3D045AC
	protected override object OnCreateTextureVariant() { }

	// RVA: 0x3D04808
	public object Update(object ptr, object dataSize) { }

}

// Namespace: com.pixui
public class PxDrawableLinearGradient
{

	// Fields
	private object <angle>k__BackingField; // 0x24
	private object <gradient>k__BackingField; // 0x28

	// Properties
	public object angle { get; set; }
	public object gradient { get; set; }
	public override object width { get; }
	public override object height { get; }

	// Methods

	// RVA: 0x3D04984
	public object get_angle() { }

	// RVA: 0x3D0498C
	private object set_angle(object value) { }

	// RVA: 0x3D04994
	public object get_gradient() { }

	// RVA: 0x3D0499C
	private object set_gradient(object value) { }

	// RVA: 0x3D029CC
	public object .ctor(object url, object id, object angle, object gradient) { }

	// RVA: 0x3D049A4
	public override object get_width() { }

	// RVA: 0x3D049B0
	public override object get_height() { }

}

// Namespace: 
public enum ThreadSafety
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MainThreadOnly;
	public const object ThreadSafe;
}

// Namespace: 
public sealed class OnReturn
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object success, object result, object error, object code) { }

}

// Namespace: 
public struct AsyncTask<T0>
{

	// Fields
	private readonly object m_Action; // 0x0
	private readonly object m_ThreadSafety; // 0x0

	// Properties
	public object action { get; }
	public object threadSafety { get; }

	// Methods

	// RVA: -1
	public object get_action() { }

	// RVA: -1
	public object get_threadSafety() { }

	// RVA: -1
	public object .ctor(object action, object threadSafety) { }

}

// Namespace: 
public struct SyncTask<T0>
{

	// Fields
	private readonly object m_Action; // 0x0
	private readonly object m_ThreadSafety; // 0x0

	// Properties
	public object action { get; }
	public object threadSafety { get; }

	// Methods

	// RVA: -1
	public object get_action() { }

	// RVA: -1
	public object get_threadSafety() { }

	// RVA: -1
	public object .ctor(object action, object threadSafety) { }

}

// Namespace: 
private class PendingTask
{

	// Fields
	private object m_Event; // 0x8
	private object m_Action; // 0x10

	// Methods

	// RVA: 0x3D052E4
	public object .ctor(object action) { }

	// RVA: 0x3D0535C
	public object Wait(object timeoutMs) { }

	// RVA: 0x3D053B0
	public object Confirm() { }

	// RVA: 0x3D04D48
	public object Perform() { }

	// RVA: 0x3D04F44
	public object Drop() { }

}

// Namespace: 
private sealed class <>c__DisplayClass16_0<T0>
{

	// Fields
	public object result; // 0x0
	public object task; // 0x0
	public object pendding; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <RunTaskBlocking>b__0() { }

}

// Namespace: 
private sealed class <>c__DisplayClass17_0<T0>
{

	// Fields
	public object task; // 0x0
	public object onReturn; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <RunTaskNonBlocking>b__0() { }

}

// Namespace: com.pixui
public class PxAsyncTaskDispatcher
{

	// Fields
	private object m_PenddingLock; // 0x18
	private object m_Penddings; // 0x20
	private object m_PendingCount; // 0x28
	private object m_Executings; // 0x30
	private static object s_MainThread; // 0x0

	// Methods

	// RVA: 0x3D049BC
	private object Awake() { }

	// RVA: 0x3D04A3C
	private object PerformPenddings() { }

	// RVA: 0x3D04D64
	private object DropPenddings() { }

	// RVA: 0x3D04F68
	private object Update() { }

	// RVA: 0x3D04F6C
	private object OnDestroy() { }

	// RVA: 0x3D04F70
	public object IsCurrentOnUnityThread() { }

	// RVA: 0x3D04FCC
	private object RunInMainThread(object task) { }

	// RVA: -1
	public object RunTaskBlocking(object task) { }

	// RVA: -1
	public object RunTaskNonBlocking(object task, object onReturn) { }

	// RVA: 0x3D05218
	public object .ctor() { }

}

// Namespace: com.pixui
public class PxBaseManager<T0>
{

	// Fields
	private static object s_Current; // 0x0

	// Properties
	public static object current { get; }

	// Methods

	// RVA: -1
	public static object get_current() { }

	// RVA: -1
	protected virtual object Awake() { }

	// RVA: -1
	protected virtual object OnDestroy() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__4_2; // 0x8
	public static object <>9__4_3; // 0x10
	public static object <>9__9_0; // 0x18

	// Methods

	// RVA: 0x3D066D4
	private static object .cctor() { }

	// RVA: 0x3D06734
	public object .ctor() { }

	// RVA: 0x3D0673C
	internal object <.ctor>b__4_2(object t) { }

	// RVA: 0x3D06810
	internal object <.ctor>b__4_3(object t) { }

	// RVA: 0x3D06914
	internal object <Clear>b__9_0(object t) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object type; // 0x8

	// Methods

	// RVA: 0x3D06508
	public object .ctor() { }

	// RVA: 0x3D06970
	internal object <.ctor>b__1() { }

}

// Namespace: com.pixui
public class PxCacheMgr
{

	// Fields
	private readonly object _cacheDict; // 0x8
	private readonly object _removeList; // 0x10
	private object _cacheObj; // 0x18
	private object _checkTimer; // 0x20

	// Methods

	// RVA: 0x3D053D4
	public object .ctor() { }

	// RVA: 0x3D055B0
	public object Init() { }

	// RVA: 0x3D057EC
	public object GetWidget(object type) { }

	// RVA: 0x3D05884
	public object ReleaseWidget(object widget) { }

	// RVA: 0x3D0597C
	public object Check() { }

	// RVA: 0x3D06074
	public object Clear() { }

	// RVA: 0x3D061FC
	private object <.ctor>b__4_0(object type) { }

	// RVA: 0x3D06510
	private object <.ctor>b__4_4(object t) { }

}

// Namespace: com.pixui
public static class PxConfig
{

	// Fields
	public static object userAgent; // 0x0
	public static object logPath; // 0x8
	public static object cachePath; // 0x10
	public static object writeablePath; // 0x18
	public static object defaultFontSize; // 0x20
	public static object defaultFontName; // 0x28
	public static object logLevel; // 0x30
	public static object clickModal; // 0x38
	public static object widgetExpireTime; // 0x40
	public static object widgetCheckTime; // 0x44
	public static object widgetCacheTime; // 0x48
	public static object layerMaskName; // 0x50
	public static object useGeometryBorder; // 0x58
	public static object enableWidgetPrefably; // 0x59
	public static object traceFrameStat; // 0x5A
	public static object uguiWorkingColorSpace; // 0x5C
	public static object invalidChar; // 0x60
	public static object enableDefaultFont; // 0x62

	// Properties
	public static object deviceSize { get; }

	// Methods

	// RVA: 0x3D06A00
	public static object get_deviceSize() { }

	// RVA: 0x3CFE2D4
	public static object Init() { }

	// RVA: 0x3D01890
	public static object GetWriteablePath() { }

	// RVA: 0x3D0356C
	public static object ShouldCreateTextureByLinear(object isSourceSRGB) { }

	// RVA: 0x3D06A34
	private static object .cctor() { }

}

// Namespace: com.pixui
public static class PxContext
{

	// Fields
	private static readonly object _windowDict; // 0x0
	private static readonly object _windowList; // 0x8
	private static object _zombieWindows; // 0x10
	private static readonly object _windowPriorityDict; // 0x18
	private static readonly object _sid; // 0x20
	private static object _currentWndId; // 0x28
	private static object m_LoadMgr; // 0x30
	private static object m_AsyncTaskDispatcher; // 0x38
	private static readonly object _cacheMgr; // 0x40
	private static object _root; // 0x48
	private static object m_WidgetProvider; // 0x50
	private static object _mMaterialManager; // 0x58
	private static object _gamepadMgr; // 0x60
	private static object _endFrameTasks; // 0x68
	private static object _onSocketsCloseDoneDelegates; // 0x70

	// Properties
	public static object widgetProvider { get; }

	// Methods

	// RVA: 0x3D06ACC
	public static object NewId() { }

	// RVA: 0x3D06B54
	public static object GetRoot() { }

	// RVA: 0x3D06BD0
	public static object get_widgetProvider() { }

	// RVA: 0x3CFE588
	public static object Init(object root) { }

	// RVA: 0x3D091D0
	private static object onGamepadDisconnect(object index, object name) { }

	// RVA: 0x3D091D8
	private static object onGampadConnect(object index, object name) { }

	// RVA: 0x3D08898
	private static object InitProviders() { }

	// RVA: 0x3CFEEA4
	public static object Shutdown() { }

	// RVA: 0x3D00C68
	public static object ClearWindows() { }

	// RVA: 0x3D09220
	public static object RemoveWindow(object id) { }

	// RVA: 0x3D00764
	public static object RemoveWindow(object window) { }

	// RVA: 0x3D00004
	public static object NewWindowId() { }

	// RVA: 0x3D09314
	public static object CreateWindow(object windowId, object mount) { }

	// RVA: 0x3CFF43C
	public static object GetWindow(object windowId) { }

	// RVA: 0x3D09524
	public static object SetWindowPriority(object wnd, object value) { }

	// RVA: 0x3D0984C
	public static object GetCurrentWindow() { }

	// RVA: 0x3D098C4
	private static object ClearZombieWindows() { }

	// RVA: 0x3D09D34
	public static object Update(object detatime) { }

	// RVA: 0x3D0A0D8
	public static object LoadData(object windowId, object url, object buf) { }

	// RVA: 0x3D0A398
	public static object ReleaseData(object windowId, object url, object seqId, object buf) { }

	// RVA: 0x3D0A5C8
	public static object LoadDataInplace(object windowId, object ptr2Str, object loaderId, object callbackId) { }

	// RVA: 0x3D0A848
	public static object LoadDataAsync(object windowId, object loaderId, object callbackId, object url) { }

	// RVA: 0x3D0AAC0
	public static object GetWidget(object type) { }

	// RVA: 0x3CFEB48
	public static object AddToRoot(object go) { }

	// RVA: 0x3D0ABB8
	public static object ReleaseWidget(object widget) { }

	// RVA: 0x3D00958
	public static object CallEndFrame(object action) { }

	// RVA: 0x3D0AC9C
	public static object SetTimeout(object seconds, object onTimer) { }

	// RVA: 0x3D0576C
	public static object SetInterval(object seconds, object onTimer) { }

	// RVA: 0x3D0AD1C
	public static object StartCoroutine(object handler) { }

	// RVA: 0x3D015CC
	internal static object WaitForSocketsCloseDone(object timeoutMS, object callback) { }

	// RVA: 0x3D0AD8C
	private static object .cctor() { }

}

// Namespace: com.pixui
public class PxFont
{

	// Fields
	private object <deltaY>k__BackingField; // 0x8
	private object <font>k__BackingField; // 0x10
	private object <fontName>k__BackingField; // 0x18
	private object <fontSize>k__BackingField; // 0x20
	private object <style>k__BackingField; // 0x24
	private object m_FontScaleFactor; // 0x28
	private object m_Disposed; // 0x2C
	private object onRelease; // 0x30
	private object <ascent>k__BackingField; // 0x38
	private object <descent>k__BackingField; // 0x3C
	private object <lineHeight>k__BackingField; // 0x40

	// Properties
	public object deltaY { get; set; }
	public object font { get; set; }
	public object fontName { get; set; }
	public object fontSize { get; set; }
	public object style { get; set; }
	public object ascent { get; set; }
	public object descent { get; set; }
	public object lineHeight { get; set; }

	// Methods

	// RVA: 0x3D0AFE0
	public object get_deltaY() { }

	// RVA: 0x3D0AFE8
	private object set_deltaY(object value) { }

	// RVA: 0x3D0AFF0
	public object get_font() { }

	// RVA: 0x3D0AFF8
	private object set_font(object value) { }

	// RVA: 0x3D0B000
	public object get_fontName() { }

	// RVA: 0x3D0B008
	private object set_fontName(object value) { }

	// RVA: 0x3D0B010
	public object get_fontSize() { }

	// RVA: 0x3D0B018
	private object set_fontSize(object value) { }

	// RVA: 0x3D0B020
	public object get_style() { }

	// RVA: 0x3D0B028
	private object set_style(object value) { }

	// RVA: 0x3D0B030
	public object add_onRelease(object value) { }

	// RVA: 0x3D0B0D4
	public object remove_onRelease(object value) { }

	// RVA: 0x3D0B178
	public object get_ascent() { }

	// RVA: 0x3D0B180
	private object set_ascent(object value) { }

	// RVA: 0x3D0B188
	public object get_descent() { }

	// RVA: 0x3D0B190
	private object set_descent(object value) { }

	// RVA: 0x3D0B198
	public object get_lineHeight() { }

	// RVA: 0x3D0B1A0
	private object set_lineHeight(object value) { }

	// RVA: 0x3D0B1A8
	public object .ctor(object fontName, object fontSize, object style, object font) { }

	// RVA: 0x3D0B29C
	public object GetWidth(object textPtr, object textLen, object pixelPerUnits) { }

	// RVA: 0x3D0B478
	public override object ToString() { }

	// RVA: 0x3D0B6B0
	public object GetCharWidth(object cp, object pixelsPerUnit) { }

	// RVA: 0x3D0B970
	public object GetCharWidth(object ch, object pixelsPerUnit) { }

	// RVA: 0x3D0BBA8
	public object Dispose() { }

}

// Namespace: 
private sealed class <>c__DisplayClass17_0
{

	// Fields
	public object backendFont; // 0x8

	// Methods

	// RVA: 0x3D0C510
	public object .ctor() { }

	// RVA: 0x3D0CB50
	internal object <CreateFont>b__0() { }

}

// Namespace: com.pixui
public class PxFontMgr
{

	// Fields
	private readonly object m_FontsDict; // 0x28
	private object m_Window; // 0x30
	private object m_LastPixelsPerUnit; // 0x38
	private object m_FontIdSeq; // 0x3C
	private object onLoadFont; // 0x40
	private object m_EnableDefaultFont; // 0x48

	// Properties
	public object enableDefaultFont { get; set; }
	private object pixelsPerUnit { get; }

	// Methods

	// RVA: 0x3D0BBD4
	public object add_onLoadFont(object value) { }

	// RVA: 0x3D0BC88
	public object remove_onLoadFont(object value) { }

	// RVA: 0x3D0BD3C
	public object get_enableDefaultFont() { }

	// RVA: 0x3D0BD44
	public object set_enableDefaultFont(object value) { }

	// RVA: 0x3D0BD4C
	private object get_pixelsPerUnit() { }

	// RVA: 0x3D0BE2C
	public object Attach(object window) { }

	// RVA: 0x3D0BE34
	public object GetFontDict() { }

	// RVA: 0x3D0BE3C
	public object GetFont(object fontId) { }

	// RVA: 0x3D0BEC0
	private object LoadUserFont(object fontName, object fontSize, object style) { }

	// RVA: 0x3D0C004
	public object CreateFont(object fontName, object fontSize, object style, object fm) { }

	// RVA: 0x3D0C518
	public object DeleteFont(object fontId) { }

	// RVA: 0x3D0C674
	public object GetTextWidth(object textPtr, object textLen, object textId, object fontId) { }

	// RVA: 0x3D0C7B8
	public static object GetStyle(object style, object weight) { }

	// RVA: 0x3D0C83C
	public object GetCharWidth(object windowId, object cp, object fontId) { }

	// RVA: 0x3D0C9C8
	private object OnScaleFactorChanged() { }

	// RVA: 0x3D0CA20
	private object OnRectTransformDimensionsChange() { }

	// RVA: 0x3D0CA94
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x3D12AA8
	private static object .cctor() { }

	// RVA: 0x3D12B08
	public object .ctor() { }

	// RVA: 0x3D12B10
	internal object <.cctor>b__2_0(object s) { }

	// RVA: 0x3D12B68
	internal object <.cctor>b__2_1(object s) { }

	// RVA: 0x3D12BC0
	internal object <.cctor>b__2_2(object getString) { }

	// RVA: 0x3D12CFC
	internal object <.cctor>b__2_3(object getString) { }

	// RVA: 0x3D12D04
	internal object <.cctor>b__2_4(object getString) { }

	// RVA: 0x3D12E40
	internal object <.cctor>b__2_5(object getString) { }

}

// Namespace: 
private sealed class <>c__DisplayClass3_0
{

	// Fields
	public object lg; // 0x8
	public object getString; // 0x10

	// Methods

	// RVA: 0x3D12AA0
	public object .ctor() { }

	// RVA: 0x3D12F7C
	internal object <LogInfo>b__0() { }

}

// Namespace: 
private static class Helper
{

	// Fields
	private static readonly object _tagDict; // 0x0
	private static readonly object _logDict; // 0x8

	// Methods

	// RVA: 0x3D126C8
	private static object .cctor() { }

	// RVA: 0x3D0D894
	public static object LogInfo(object lg, object ll, object getString) { }

}

// Namespace: 
private sealed class <>c__DisplayClass31_0
{

	// Fields
	public object windowId; // 0x8

	// Methods

	// RVA: 0x3D0FCEC
	public object .ctor() { }

	// RVA: 0x3D13074
	internal object <OnWindowClose>b__0() { }

}

// Namespace: 
private sealed class <>c__DisplayClass40_0
{

	// Fields
	public object windowId; // 0x8
	public object url; // 0x10
	public object textureId; // 0x18

	// Methods

	// RVA: 0x3D106B0
	public object .ctor() { }

	// RVA: 0x3D130FC
	internal object <ShouldOverrideImageLoading>b__0(object result, object error) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object strPtr; // 0x8

	// Methods

	// RVA: 0x3D0D88C
	public object .ctor() { }

	// RVA: 0x3D13188
	internal object <LogInfo>b__0() { }

}

// Namespace: com.pixui
public static class PxFunctional
{

	// Fields
	private static readonly object _drawDict; // 0x0

	// Methods

	// RVA: 0x3D0CBE0
	private static object .cctor() { }

	// RVA: 0x3D0D1D0
	public static object MemoryAlloc(object size) { }

	// RVA: 0x3D0D2E0
	public static object MemoryFree(object ptr) { }

	// RVA: 0x3D0D3F0
	public static object LoadData(object windowId, object urlPtr, object buf) { }

	// RVA: 0x3D0D49C
	public static object ReleaseData(object windowId, object urlPtr, object seqId, object buf) { }

	// RVA: 0x3D0D550
	public static object LoadDataInplace(object windowId, object url, object loaderId, object callbackId) { }

	// RVA: 0x3D0D674
	public static object LoadDataAsync(object windowId, object loaderId, object callbackId, object urlPtr) { }

	// RVA: 0x3D0D794
	public static object LogInfo(object lg, object ll, object strPtr) { }

	// RVA: 0x3D0D9E4
	public static object FreeDataUrl(object windowId, object img, object ptr) { }

	// RVA: 0x3D0DBB4
	public static object GetDataUrl(object windowId, object img, object type) { }

	// RVA: 0x3D0DD88
	public static object Pt2Px(object pt) { }

	// RVA: 0x3D0DEAC
	public static object RecvMessage(object windowId, object msgPtr) { }

	// RVA: 0x3D0E114
	public static object LuaRPCPost(object msgPtr) { }

	// RVA: 0x3D0E1C0
	public static object CreateFont(object windowId, object fontNamePtr, object fontSize, object weight, object decoration, object style, object fm) { }

	// RVA: 0x3D0E3B0
	public static object DeleteFont(object windowId, object fontId) { }

	// RVA: 0x3D0E4E4
	public static object GetTextWidth(object windowId, object textPtr, object textLen, object textId, object fontId) { }

	// RVA: 0x3D0E64C
	public static object CreateTexture(object windowId, object urlPtr, object textureId, object width, object height, object flag, object format, object rawData, object dataSize) { }

	// RVA: 0x3D0E818
	public static object GetTextureSize(object windowId, object textureId, object size) { }

	// RVA: 0x3D0E9B4
	public static object UpdateTexture(object windowId, object textureId, object format, object rawData, object dataSize) { }

	// RVA: 0x3D0EB18
	public static object DeleteTexture(object windowId, object textureId) { }

	// RVA: 0x3D0EC4C
	public static object ActivateInput(object windowId, object type, object defaultTextPtr, object hintTextPtr) { }

	// RVA: 0x3D0EDA0
	public static object DeativateInput(object windowId) { }

	// RVA: 0x3D0EED0
	public static object SetCursor(object windowId, object cursor) { }

	// RVA: 0x3D0EED4
	public static object OnScriptInit(object windowId) { }

	// RVA: 0x3D0F0CC
	public static object OnScriptShutdown(object windowId) { }

	// RVA: 0x3D0F2B0
	public static object OnLoadComplete(object windowId, object urlPtr, object errCode) { }

	// RVA: 0x3D0F504
	public static object OpenChildWindow(object windowId, object urlPtr) { }

	// RVA: 0x3D0F840
	public static object GetOpener(object wndId) { }

	// RVA: 0x3D0F96C
	public static object SetWindowPass(object windowId, object value) { }

	// RVA: 0x3D0FAA0
	public static object SetWindowPriority(object windowId, object value) { }

	// RVA: 0x3D0FBF8
	public static object OnWindowClose(object windowId) { }

	// RVA: 0x3D0FCF4
	public static object OnWindowAlert(object windowId, object msgPtr) { }

	// RVA: 0x3D0FE00
	public static object OnWindowConfirm(object windowId, object msgPtr) { }

	// RVA: 0x3D0FF28
	public static object OnWindowMoveBy(object windowId, object x, object y) { }

	// RVA: 0x3D10070
	public static object OnWindowMoveTo(object windowId, object x, object y) { }

	// RVA: 0x3D101B8
	public static object OnWindowResizeBy(object windowId, object width, object height) { }

	// RVA: 0x3D10300
	public static object OnWindowResizeTo(object windowId, object width, object height) { }

	// RVA: 0x3D10448
	public static object OnWindowScrollBy(object windowId, object x, object y) { }

	// RVA: 0x3D1044C
	public static object OnWindowScrollTo(object windowId, object x, object y) { }

	// RVA: 0x3D10450
	public static object ShouldOverrideImageLoading(object windowId, object url, object textureId) { }

	// RVA: 0x3D106B8
	public static object SendCmds(object windowId) { }

	// RVA: 0x3D10824
	public static object SendCmds(object window, object itemBuffer) { }

	// RVA: 0x3D1091C
	public static object ShowModal(object windowId, object v) { }

	// RVA: 0x3D10A50
	public static object PushGroup(object window, object bufferPtr) { }

	// RVA: 0x3D10B40
	public static object PopGroup(object window, object bufferPtr) { }

	// RVA: 0x3D10B60
	public static object PushClip(object window, object bufferPtr) { }

	// RVA: 0x3D10C50
	public static object PopClip(object window, object bufferPtr) { }

	// RVA: 0x3D10C70
	public static object PushRenderLayer(object window, object bufferPtr) { }

	// RVA: 0x3D10D54
	public static object PopRenderLayer(object window, object bufferPtr) { }

	// RVA: 0x3D10D74
	private static object DrawBoxShadow(object window, object bufferPtr) { }

	// RVA: 0x3D10F2C
	public static object DrawText(object window, object bufferPtr) { }

	// RVA: 0x3D1127C
	public static object DrawTextShadow(object window, object bufferPtr) { }

	// RVA: 0x3D1135C
	public static object DrawBorder(object window, object bufferPtr) { }

	// RVA: 0x3D1148C
	public static object DrawRect(object window, object bufferPtr) { }

	// RVA: 0x3D11214
	private static object MultiSubDrawHash(object window, object id) { }

	// RVA: 0x3D11698
	public static object DrawLine(object window, object bufferPtr) { }

	// RVA: 0x3D117E0
	public static object DrawImage(object window, object bufferPtr) { }

	// RVA: 0x3D11DC0
	public static object PushSlot(object window, object bufferPtr) { }

	// RVA: 0x3D11F4C
	public static object PopSlot(object window, object bufferPtr) { }

	// RVA: 0x3D11F6C
	public static object CreateSlot(object windowId, object handle, object src) { }

	// RVA: 0x3D120E0
	public static object DeleteSlot(object windowId, object handle) { }

	// RVA: 0x3D12230
	public static object GetCharWidth(object windowId, object cp, object fontId) { }

	// RVA: 0x3D12380
	public static object OnInternalError(object windowId, object error, object msgPtr) { }

	// RVA: 0x3D12520
	public static object QueryCapability(object caps) { }

}

// Namespace: com.pixui
public class PxGamepadMgr
{

	// Fields
	private object onGampadConnect; // 0x8
	private object onGampadDisconnect; // 0x10

	// Methods

	// RVA: 0x3D09064
	public object add_onGampadConnect(object value) { }

	// RVA: 0x3D13218
	public object remove_onGampadConnect(object value) { }

	// RVA: 0x3D09118
	public object add_onGampadDisconnect(object value) { }

	// RVA: 0x3D132CC
	public object remove_onGampadDisconnect(object value) { }

	// RVA: 0x3D091CC
	public object Init() { }

	// RVA: 0x3D0905C
	public object .ctor() { }

}

// Namespace: com.pixui
public struct PxInterface
{

	// Fields
	public object MemoryAlloc; // 0xFFFFFFFFFFFFFFF8
	public object MemoryFree; // 0x0
	public object LoadData; // 0x8
	public object ReleaseData; // 0x10
	public object LoadDataAsync; // 0x18
	public object LogInfo; // 0x20
	public object Pt2Px; // 0x28
	public object RecvMessage; // 0x30
	public object LuaRPCPost; // 0x38
	public object CreateFont; // 0x40
	public object DeleteFont; // 0x48
	public object GetTextWidth; // 0x50
	public object CreateTexture; // 0x58
	public object GetTextureSize; // 0x60
	public object UpdateTexture; // 0x68
	public object DeleteTexture; // 0x70
	public object SendCmds; // 0x78
	public object ShowModal; // 0x80
	public object ActivateInput; // 0x88
	public object DeativateInput; // 0x90
	public object SetCursor; // 0x98
	public object OnScriptInit; // 0xA0
	public object OnLoadComplete; // 0xA8
	public object OpenChildWindow; // 0xB0
	public object GetOpener; // 0xB8
	public object SetWindowPass; // 0xC0
	public object SetWindowPriority; // 0xC8
	public object OnWindowClose; // 0xD0
	public object OnWindowAlert; // 0xD8
	public object OnWindowConfirm; // 0xE0
	public object OnWindowMoveBy; // 0xE8
	public object OnWindowMoveTo; // 0xF0
	public object OnWindowResizeBy; // 0xF8
	public object OnWindowResizeTo; // 0x100
	public object OnWindowScrollBy; // 0x108
	public object OnWindowScrollTo; // 0x110
	public object ShouldOverrideImageLoading; // 0x118
	public object CreateSlot; // 0x120
	public object DeleteSlot; // 0x128
	public object GetCharWidth; // 0x130
	public object OnInternalError; // 0x138
	public object QueryCapability; // 0x140
	public object OnScriptShutdown; // 0x148
	public object GetDataUrl; // 0x150
	public object FreeDataUrl; // 0x158
	public object GetClipboardText; // 0x160
	public object ReleaseClipboardText; // 0x168
	public object SetClipboardText; // 0x170
	public object LoadDataInplace; // 0x178
	public object OnSocketsCloseDone; // 0x180

	// Methods

	// RVA: 0x3D06C4C
	public static object Get() { }

}

// Namespace: 
public sealed class MemoryAllocDelegate
{

	// Methods

	// RVA: 0x3D13FAC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D15D54
	public virtual object Invoke(object size) { }

}

// Namespace: 
public sealed class MemoryFreeDelegate
{

	// Methods

	// RVA: 0x3D14044
	public object .ctor(object object, object method) { }

	// RVA: 0x3D15DD8
	public virtual object Invoke(object ptr) { }

}

// Namespace: 
public sealed class LoadDataDelegate
{

	// Methods

	// RVA: 0x3D140DC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D15E9C
	public virtual object Invoke(object windowId, object urlPtr, object buf) { }

}

// Namespace: 
public sealed class ReleaseDataDelegate
{

	// Methods

	// RVA: 0x3D14174
	public object .ctor(object object, object method) { }

	// RVA: 0x3D15F58
	public virtual object Invoke(object windowId, object urlPtr, object seqId, object buf) { }

}

// Namespace: 
public sealed class LoadDataSyncDelegate
{

	// Methods

	// RVA: 0x3D1420C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16044
	public virtual object Invoke(object windowId, object loaderId, object callbackId, object urlPtr) { }

}

// Namespace: 
public sealed class LogInfoDelegate
{

	// Methods

	// RVA: 0x3D142A4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D160F0
	public virtual object Invoke(object lg, object level, object strPtr) { }

}

// Namespace: 
public sealed class Pt2PxDelegate
{

	// Methods

	// RVA: 0x3D1433C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16188
	public virtual object Invoke(object pt) { }

}

// Namespace: 
public sealed class RecvMessageDelegate
{

	// Methods

	// RVA: 0x3D143D4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1621C
	public virtual object Invoke(object windowId, object msgPtr) { }

}

// Namespace: 
public sealed class LuaRPCPostDelegate
{

	// Methods

	// RVA: 0x3D1446C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D162A0
	public virtual object Invoke(object msgPtr) { }

}

// Namespace: 
public sealed class CreateFontDelegate
{

	// Methods

	// RVA: 0x3D14504
	public object .ctor(object object, object method) { }

	// RVA: 0x3D163B4
	public virtual object Invoke(object windowId, object fontNamePtr, object fontSize, object weight, object decoration, object style, object fm) { }

}

// Namespace: 
public sealed class DeleteFontDelegate
{

	// Methods

	// RVA: 0x3D1459C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1644C
	public virtual object Invoke(object windowId, object fontId) { }

}

// Namespace: 
public sealed class GetTextWidthDelegate
{

	// Methods

	// RVA: 0x3D14634
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1653C
	public virtual object Invoke(object windowId, object textPtr, object textLen, object textId, object fontId) { }

}

// Namespace: 
public sealed class CreateTextureDelegate
{

	// Methods

	// RVA: 0x3D146CC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16680
	public virtual object Invoke(object windowId, object urlPtr, object textureId, object width, object height, object flag, object format, object rawData, object dataSize) { }

}

// Namespace: 
public sealed class GetTextureSizeDelegate
{

	// Methods

	// RVA: 0x3D14764
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16740
	public virtual object Invoke(object windowId, object textureId, object size) { }

}

// Namespace: 
public sealed class UpdateTextureDelegate
{

	// Methods

	// RVA: 0x3D147FC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16814
	public virtual object Invoke(object windowId, object textureId, object format, object rawData, object dataSize) { }

}

// Namespace: 
public sealed class DeleteTextureDelegate
{

	// Methods

	// RVA: 0x3D14894
	public object .ctor(object object, object method) { }

	// RVA: 0x3D168A8
	public virtual object Invoke(object windowId, object textureId) { }

}

// Namespace: 
public sealed class SendCmdsDelegate
{

	// Methods

	// RVA: 0x3D1492C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1692C
	public virtual object Invoke(object windowId) { }

}

// Namespace: 
public sealed class ShowModalDelegate
{

	// Methods

	// RVA: 0x3D149C4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D169C0
	public virtual object Invoke(object windowId, object v) { }

}

// Namespace: 
public sealed class ActivateInputDelegate
{

	// Methods

	// RVA: 0x3D14A5C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16AAC
	public virtual object Invoke(object windowId, object type, object defaultTextPtr, object hintTextPtr) { }

}

// Namespace: 
public sealed class DeativateInputDelegate
{

	// Methods

	// RVA: 0x3D14AF4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16B5C
	public virtual object Invoke(object windowId) { }

}

// Namespace: 
public sealed class SetCursorDelegate
{

	// Methods

	// RVA: 0x3D14B8C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16BF0
	public virtual object Invoke(object windowId, object cursor) { }

}

// Namespace: 
public sealed class OnScriptInitDelegate
{

	// Methods

	// RVA: 0x3D14C24
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16C74
	public virtual object Invoke(object windowId) { }

}

// Namespace: 
public sealed class OnLoadCompleteDelegate
{

	// Methods

	// RVA: 0x3D14CBC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16D20
	public virtual object Invoke(object windowId, object urlPtr, object errCode) { }

}

// Namespace: 
public sealed class OpenChildWindowDelegate
{

	// Methods

	// RVA: 0x3D14D54
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16DC8
	public virtual object Invoke(object windowId, object urlPtr) { }

}

// Namespace: 
public sealed class GetOpenerDelegate
{

	// Methods

	// RVA: 0x3D14DEC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16E60
	public virtual object Invoke(object windowId) { }

}

// Namespace: 
public sealed class SetWindowPassDelegate
{

	// Methods

	// RVA: 0x3D14E84
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16EF4
	public virtual object Invoke(object windowId, object v) { }

}

// Namespace: 
public sealed class SetWindowPriorityDelegate
{

	// Methods

	// RVA: 0x3D14F1C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D16F88
	public virtual object Invoke(object windowId, object v) { }

}

// Namespace: 
public sealed class OnWindowCloseDelegate
{

	// Methods

	// RVA: 0x3D14FB4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1700C
	public virtual object Invoke(object windowId) { }

}

// Namespace: 
public sealed class OnWindowAlertDelegate
{

	// Methods

	// RVA: 0x3D1504C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D170A0
	public virtual object Invoke(object windowId, object msgPtr) { }

}

// Namespace: 
public sealed class OnWindowConfirmDelegate
{

	// Methods

	// RVA: 0x3D150E4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17160
	public virtual object Invoke(object windowId, object msgPtr) { }

}

// Namespace: 
public sealed class OnWindowMoveByDelegate
{

	// Methods

	// RVA: 0x3D1517C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1720C
	public virtual object Invoke(object windowId, object x, object y) { }

}

// Namespace: 
public sealed class OnWindowMoveToDelegate
{

	// Methods

	// RVA: 0x3D15214
	public object .ctor(object object, object method) { }

	// RVA: 0x3D172B8
	public virtual object Invoke(object windowId, object x, object y) { }

}

// Namespace: 
public sealed class OnWindowResizeByDelegate
{

	// Methods

	// RVA: 0x3D152AC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17364
	public virtual object Invoke(object windowId, object width, object height) { }

}

// Namespace: 
public sealed class OnWindowResizeToDelegate
{

	// Methods

	// RVA: 0x3D15344
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17410
	public virtual object Invoke(object windowId, object width, object height) { }

}

// Namespace: 
public sealed class OnWindowScrollByDelegate
{

	// Methods

	// RVA: 0x3D153DC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D174BC
	public virtual object Invoke(object windowId, object x, object y) { }

}

// Namespace: 
public sealed class OnWindowScrollToDelegate
{

	// Methods

	// RVA: 0x3D15474
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17568
	public virtual object Invoke(object windowId, object x, object y) { }

}

// Namespace: 
public sealed class ShouldOverrideImageLoadingDelegate
{

	// Methods

	// RVA: 0x3D1550C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17674
	public virtual object Invoke(object windowId, object url, object textureId) { }

}

// Namespace: 
public sealed class CreateSlotDelegate
{

	// Methods

	// RVA: 0x3D155A4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17758
	public virtual object Invoke(object windowId, object id, object src) { }

}

// Namespace: 
public sealed class DeleteSlotDelegate
{

	// Methods

	// RVA: 0x3D1563C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D177EC
	public virtual object Invoke(object windowId, object id) { }

}

// Namespace: 
public sealed class GetCharWidthDelegate
{

	// Methods

	// RVA: 0x3D156D4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D178B0
	public virtual object Invoke(object windowId, object cp, object fontId) { }

}

// Namespace: 
public sealed class OnInternalErrorDelegate
{

	// Methods

	// RVA: 0x3D1576C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1795C
	public virtual object Invoke(object windowId, object error, object msgPtr) { }

}

// Namespace: 
public sealed class QueryCapabilityDelegate
{

	// Methods

	// RVA: 0x3D15804
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17A08
	public virtual object Invoke(object capsPtr) { }

}

// Namespace: 
public sealed class OnScriptShutdownDelegate
{

	// Methods

	// RVA: 0x3D158AC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17A8C
	public virtual object Invoke(object windowId) { }

}

// Namespace: 
public sealed class GetDataUrlDelegate
{

	// Methods

	// RVA: 0x3D15944
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17B50
	public virtual object Invoke(object wndId, object image, object type) { }

}

// Namespace: 
public sealed class FreeDataUrlDelegate
{

	// Methods

	// RVA: 0x3D159DC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17BFC
	public virtual object Invoke(object wndId, object image, object ptr) { }

}

// Namespace: 
public sealed class GetClipboardTextDelegate
{

	// Methods

	// RVA: 0x3D15A74
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17C78
	public virtual object Invoke() { }

}

// Namespace: 
public sealed class ReleaseClipboardTextDelegate
{

	// Methods

	// RVA: 0x3D15B08
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17CFC
	public virtual object Invoke(object text) { }

}

// Namespace: 
public sealed class SetClipboardTextDelegate
{

	// Methods

	// RVA: 0x3D15BA0
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17D80
	public virtual object Invoke(object text) { }

}

// Namespace: 
public sealed class LoadDataInplaceDelegate
{

	// Methods

	// RVA: 0x3D15C38
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17E6C
	public virtual object Invoke(object windowId, object url, object loaderId, object callbackId) { }

}

// Namespace: 
public sealed class OnSocketsCloseDoneDelegate
{

	// Methods

	// RVA: 0x3D17EF0
	public object .ctor(object object, object method) { }

	// RVA: 0x3D17F88
	public virtual object Invoke(object callbackId) { }

}

// Namespace: com.pixui
public static class PxDelegates
{
}

// Namespace: com.pixui
public static class PxSafetyImpl
{

	// Methods

	// RVA: 0x3D17FF4
	public static object MemoryAlloc(object size) { }

	// RVA: 0x3D18190
	public static object MemoryFree(object ptr) { }

	// RVA: 0x3D18340
	public static object LoadData(object windowId, object urlPtr, object buf) { }

	// RVA: 0x3D18548
	public static object ReleaseData(object windowId, object urlPtr, object seqId, object buf) { }

	// RVA: 0x3D18754
	public static object LoadDataAsync(object windowId, object loaderId, object callbackId, object urlPtr) { }

	// RVA: 0x3D188F0
	public static object LogInfo(object lg, object level, object strPtr) { }

	// RVA: 0x3D18A80
	public static object GetDataUrl(object wndId, object image, object type) { }

	// RVA: 0x3D18C14
	public static object FreeDataUrl(object wndId, object image, object ptr) { }

	// RVA: 0x3D18D8C
	public static object Pt2Px(object pt) { }

	// RVA: 0x3D18EF4
	public static object RecvMessage(object windowId, object msgPtr) { }

	// RVA: 0x3D19050
	public static object LuaRPCPost(object msgPtr) { }

	// RVA: 0x3D19258
	public static object CreateFont(object windowId, object fontNamePtr, object fontSize, object weight, object decoration, object style, object fm) { }

	// RVA: 0x3D19400
	public static object DeleteFont(object windowId, object fontId) { }

	// RVA: 0x3D1959C
	public static object GetTextWidth(object windowId, object textPtr, object textLen, object textId, object fontId) { }

	// RVA: 0x3D19794
	public static object CreateTexture(object windowId, object urlPtr, object textureId, object width, object height, object flag, object format, object rawData, object dataSize) { }

	// RVA: 0x3D19978
	public static object GetTextureSize(object windowId, object textureId, object size) { }

	// RVA: 0x3D19B18
	public static object UpdateTexture(object windowId, object textureId, object format, object rawData, object dataSize) { }

	// RVA: 0x3D19CAC
	public static object DeleteTexture(object windowId, object textureId) { }

	// RVA: 0x3D19E08
	public static object SendCmds(object windowId) { }

	// RVA: 0x3D19F68
	public static object ShowModal(object windowId, object v) { }

	// RVA: 0x3D1A0EC
	public static object ActivateInput(object windowId, object type, object defaultTextPtr, object hintTextPtr) { }

	// RVA: 0x3D1A278
	public static object DeativateInput(object windowId) { }

	// RVA: 0x3D1A3D0
	public static object SetCursor(object windowId, object cursor) { }

	// RVA: 0x3D1A50C
	public static object OnScriptInit(object windowId) { }

	// RVA: 0x3D1A678
	public static object OnLoadComplete(object windowId, object urlPtr, object errCode) { }

	// RVA: 0x3D1A7F8
	public static object OpenChildWindow(object windowId, object urlPtr) { }

	// RVA: 0x3D1A968
	public static object GetOpener(object windowId) { }

	// RVA: 0x3D1AAD4
	public static object SetWindowPass(object windowId, object v) { }

	// RVA: 0x3D1AC38
	public static object SetWindowPriority(object windowId, object v) { }

	// RVA: 0x3D1AD94
	public static object OnWindowClose(object windowId) { }

	// RVA: 0x3D1AEF0
	public static object OnWindowAlert(object windowId, object msgPtr) { }

	// RVA: 0x3D1B05C
	public static object OnWindowConfirm(object windowId, object msgPtr) { }

	// RVA: 0x3D1B1DC
	public static object OnWindowMoveBy(object windowId, object x, object y) { }

	// RVA: 0x3D1B364
	public static object OnWindowMoveTo(object windowId, object x, object y) { }

	// RVA: 0x3D1B4EC
	public static object OnWindowResizeBy(object windowId, object width, object height) { }

	// RVA: 0x3D1B674
	public static object OnWindowResizeTo(object windowId, object width, object height) { }

	// RVA: 0x3D1B7DC
	public static object OnWindowScrollBy(object windowId, object x, object y) { }

	// RVA: 0x3D1B910
	public static object OnWindowScrollTo(object windowId, object x, object y) { }

	// RVA: 0x3D1BA88
	public static object ShouldOverrideImageLoading(object windowId, object url, object textureId) { }

	// RVA: 0x3D1BC24
	public static object CreateSlot(object windowId, object id, object src) { }

	// RVA: 0x3D1BD9C
	public static object DeleteSlot(object windowId, object id) { }

	// RVA: 0x3D1BF20
	public static object GetCharWidth(object windowId, object cp, object fontId) { }

	// RVA: 0x3D1C0B4
	public static object OnInternalError(object windowId, object error, object msgPtr) { }

	// RVA: 0x3D1C224
	public static object QueryCapability(object caps) { }

	// RVA: 0x3D1C378
	public static object OnScriptShutdown(object windowId) { }

	// RVA: 0x3D1C4CC
	public static object GetClipboardText() { }

	// RVA: 0x3D1C62C
	public static object ReleaseClipboardText(object text) { }

	// RVA: 0x3D1C790
	public static object SetClipboardText(object text) { }

	// RVA: 0x3D1C928
	public static object LoadDataInplace(object windowId, object url, object loaderId, object callbackId) { }

}

// Namespace: com.pixui
public class LoadDataSyncResult
{

	// Fields
	private object <nativeBuffer>k__BackingField; // 0x8
	private object <managedBuffer>k__BackingField; // 0x18

	// Properties
	public object nativeBuffer { get; set; }
	private object managedBuffer { set; }

	// Methods

	// RVA: 0x3D1CA5C
	public object get_nativeBuffer() { }

	// RVA: 0x3D1CA68
	private object set_nativeBuffer(object value) { }

	// RVA: 0x3D1CA70
	private object set_managedBuffer(object value) { }

	// RVA: 0x3D1CA78
	private object .ctor() { }

	// RVA: 0x3D1CA80
	public static object FromNative(object ptr, object size) { }

}

// Namespace: com.pixui
public sealed class LoadDataSyncThreaded
{

	// Methods

	// RVA: 0x3D1CBAC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1CC44
	public virtual object Invoke(object windowId, object url, object seqId, object task) { }

}

// Namespace: com.pixui
public sealed class ReleaseDataSyncThreaded
{

	// Methods

	// RVA: 0x3D1CD18
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1CDB0
	public virtual object Invoke(object windowId, object url, object seqId, object buf, object task) { }

}

// Namespace: com.pixui
public sealed class LoadDataAsyncThreaded
{

	// Methods

	// RVA: 0x3D1CE60
	public object .ctor(object object, object method) { }

	// RVA: 0x3D1CEF8
	public virtual object Invoke(object windowId, object url, object task) { }

}

// Namespace: 
private sealed class <>c__DisplayClass5_0
{

	// Fields
	public object loaderId; // 0x8
	public object callbackId; // 0xC

	// Methods

	// RVA: 0x3D1CFBC
	public object .ctor() { }

	// RVA: 0x3D1D1F4
	internal object <LoadDataInplace>b__0(object ptr, object size) { }

}

// Namespace: 
private sealed class <>c__DisplayClass7_0
{

	// Fields
	public object loaderId; // 0x8
	public object callbackId; // 0xC
	public object url; // 0x10

	// Methods

	// RVA: 0x3D1D1D0
	public object .ctor() { }

	// RVA: 0x3D1D260
	internal object <ShouldAcceptDataLoad>b__0(object success, object result, object error, object code) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object loaderId; // 0x8
	public object callbackId; // 0xC

	// Methods

	// RVA: 0x3D1D1E4
	public object .ctor() { }

	// RVA: 0x3D1D388
	internal object <LoadDataAsyncThreaded>b__0(object ptr, object size, object code) { }

}

// Namespace: com.pixui
public class PxLoadMgr
{

	// Fields
	private object m_AsyncTaskDispatcher; // 0x18
	private static object s_MainThread; // 0x0

	// Methods

	// RVA: 0x3D1CF0C
	private object Awake() { }

	// RVA: 0x3D0A2A8
	public object LoadDataSyncThreaded(object windowId, object url, object seqId) { }

	// RVA: 0x3D0A4E4
	public object ReleaseDataSyncThreaded(object windowId, object url, object seqId, object buf) { }

	// RVA: 0x3D0A67C
	public object LoadDataInplace(object windowId, object url, object loaderId, object callbackId) { }

	// RVA: 0x3D1CFB0
	private object InternalLoadDataSync(object windowId, object url, object task) { }

	// RVA: 0x3D1CFC4
	private object ShouldAcceptDataLoad(object windowId, object loaderId, object callbackId, object url) { }

	// RVA: 0x3D0A8F4
	public object LoadDataAsyncThreaded(object windowId, object loaderId, object callbackId, object url) { }

	// RVA: 0x3D1D1D8
	private object InternalLoadDataAsync(object windowId, object url, object task) { }

	// RVA: 0x3D1D1EC
	public object .ctor() { }

}

// Namespace: 
public enum Level
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Info;
	public const object Warning;
	public const object Error;
	public const object Count;
}

// Namespace: com.pixui
public static class PxLogger
{

	// Fields
	public static object level; // 0x0

	// Methods

	// RVA: 0x3D1D3C4
	public static object Init(object v) { }

	// RVA: 0x3D00244
	public static object Info(object s) { }

	// RVA: 0x3D12BC8
	public static object Info(object getString) { }

	// RVA: 0x3CFFD74
	public static object Warn(object s) { }

	// RVA: 0x3D12D0C
	public static object Warn(object getString) { }

	// RVA: 0x3CFFC64
	public static object Error(object s) { }

	// RVA: 0x3D12E48
	public static object Error(object getString) { }

	// RVA: 0x3D1D41C
	private static object Write(object level, object s) { }

}

// Namespace: com.pixui
public class PxMaterialManager
{

	// Fields
	private object m_Pools; // 0x18

	// Properties
	public object keys { get; }

	// Methods

	// RVA: 0x3D1D598
	public object get_keys() { }

	// RVA: 0x3D1D5F4
	public object QueryPool(object t) { }

	// RVA: -1
	public object QueryPool() { }

	// RVA: -1
	private object RequestPool() { }

	// RVA: -1
	public object Request(object key) { }

	// RVA: -1
	public object Migrate(object lastKey, object newKey) { }

	// RVA: -1
	public object Return(object key) { }

	// RVA: 0x3D1D678
	public object .ctor() { }

}

// Namespace: com.pixui
public static class PxMemory
{

	// Methods

	// RVA: 0x3D0D258
	public static object Alloc(object size) { }

	// RVA: 0x3D0D368
	public static object Free(object ptr) { }

}

// Namespace: 
public interface IPlatformUtils
{
}

// Namespace: 
private class CommonPlatform
{

	// Methods

	// RVA: 0x3D1D990
	public object .ctor() { }

}

// Namespace: 
private class AndroidPlatform
{

	// Methods

	// RVA: 0x3D1D970
	public object .ctor() { }

}

// Namespace: 
private class IOSPlatform
{

	// Methods

	// RVA: 0x3D1D978
	public object .ctor() { }

}

// Namespace: 
private class WindowsPlatform
{

	// Methods

	// RVA: 0x3D1D980
	public object .ctor() { }

}

// Namespace: 
private class MacPlatform
{

	// Methods

	// RVA: 0x3D1D988
	public object .ctor() { }

}

// Namespace: com.pixui
public static class PxPlatform
{

	// Fields
	public static readonly object isEditor; // 0x0
	public static readonly object isMobile; // 0x1
	public static readonly object isWindows; // 0x2
	public static readonly object isOSX; // 0x3
	public static readonly object isIPhone; // 0x4
	public static readonly object isAndroid; // 0x5
	public static readonly object platformUtils; // 0x8

	// Methods

	// RVA: 0x3D1D714
	private static object .cctor() { }

}

// Namespace: com.pixui
public enum ELogLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object em_ll_log;
	public const object em_ll_debug;
	public const object em_ll_warning;
	public const object em_ll_error;
	public const object em_ll_count;
}

// Namespace: com.pixui
public enum ELogGroup
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object em_lg_html;
	public const object em_lg_lua;
}

// Namespace: com.pixui
public enum EKeyboardType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object em_Keyboard_Default;
	public const object em_Keyboard_Number;
	public const object em_Keyboard_Password;
	public const object em_Keyboard_MultiLine;
}

// Namespace: com.pixui
public enum EPixelFormat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object em_pf_rgba32;
	public const object em_pf_rgb24;
	public const object em_pf_etc1_rgb;
	public const object em_pf_etc2_rgba;
	public const object em_pf_bc1_rgb;
	public const object em_pf_bc3_rgba;
	public const object em_pf_bc7_rgba;
	public const object em_pf_astc_4x4;
	public const object em_pf_astc_5x5;
	public const object em_pf_astc_6x6;
	public const object em_pf_astc_8x8;
	public const object em_pf_astc_10x10;
	public const object em_pf_astc_12x12;
	public const object em_pf_count;
	public const object em_pf_invalid;
}

// Namespace: com.pixui
public enum MouseButton
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object MB_None;
	public const object MB_Left;
	public const object MB_Middle;
	public const object MB_Right;
	public const object MB_Count;
}

// Namespace: com.pixui
public enum FontStyle
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object fontStyleNormal;
	public const object fontStyleItalic;
}

// Namespace: com.pixui
public enum EErrCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object em_ec_ok;
	public const object em_ec_notinit;
	public const object em_ec_handle_invalid;
	public const object em_ec_err_intervalfun;
	public const object em_ec_err_intervalid;
	public const object em_ec_err_timeoutfun;
	public const object em_ec_err_timeoutid;
	public const object em_ec_err_notopenpage;
	public const object em_ec_paint_lock;
	public const object em_ec_url;
	public const object em_ec_container;
	public const object em_ec_loadpageurl;
	public const object em_ec_delegate_event;
	public const object em_ec_data_err;
}

// Namespace: com.pixui
public enum BorderStyle
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object border_style_none;
	public const object border_style_hidden;
	public const object border_style_dotted;
	public const object border_style_dashed;
	public const object border_style_solid;
	public const object border_style_double;
	public const object border_style_groove;
	public const object border_style_ridge;
	public const object border_style_inset;
	public const object border_style_outset;
}

// Namespace: com.pixui
public enum BackgroundAttachment
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object background_attachment_scroll;
	public const object background_attachment_fixed;
}

// Namespace: com.pixui
public enum BackgroundRepeat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object background_repeat_repeat;
	public const object background_repeat_repeat_x;
	public const object background_repeat_repeat_y;
	public const object background_repeat_no_repeat;
}

// Namespace: com.pixui
public enum BorderImageRepeat
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object image_stretch;
	public const object image_repeat;
	public const object image_round;
}

// Namespace: com.pixui
public enum BorderImageModel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object image_fill;
	public const object image_border;
}

// Namespace: com.pixui
public enum CmdBufferType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object cmd_buffer_none;
	public const object cmd_buffer_push_group;
	public const object cmd_buffer_pop_group;
	public const object cmd_buffer_push_clip;
	public const object cmd_buffer_pop_clip;
	public const object cmd_buffer_draw_text;
	public const object cmd_buffer_draw_text_shadow;
	public const object cmd_buffer_draw_border;
	public const object cmd_buffer_draw_rect;
	public const object cmd_buffer_draw_image;
	public const object cmd_buffer_draw_line;
	public const object cmd_buffer_push_slot;
	public const object cmd_buffer_push_render_layer;
	public const object cmd_buffer_pop_render_layer;
	public const object cmd_buffer_pop_slot;
	public const object cmd_buffer_draw_box_shadow;
	public const object cmd_buffer_count;
}

// Namespace: com.pixui
public enum ETouchPhase
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object em_touch_phase_began;
	public const object em_touch_phase_moved;
	public const object em_touch_phase_stationary;
	public const object em_touch_phase_ended;
	public const object em_touch_phase_canceld;
}

// Namespace: com.pixui
public struct NativeMemoryUsage
{

	// Fields
	public object jsMem; // 0xFFFFFFFFFFFFFFF8
	public object taskCount; // 0xC8
	public object assetCount; // 0xCC
	public object elemCount; // 0xD0
	public object textCount; // 0xD4
	public object tagCount; // 0xD8
	public object propCount; // 0xDC
}

// Namespace: com.pixui
public struct JSMemoryUsage
{

	// Fields
	public object malloc_size; // 0xFFFFFFFFFFFFFFF8
	public object malloc_limit; // 0x0
	public object memory_used_size; // 0x8
	public object malloc_count; // 0x10
	public object memory_used_count; // 0x18
	public object atom_count; // 0x20
	public object atom_size; // 0x28
	public object str_count; // 0x30
	public object str_size; // 0x38
	public object obj_count; // 0x40
	public object obj_size; // 0x48
	public object prop_count; // 0x50
	public object prop_size; // 0x58
	public object shape_count; // 0x60
	public object shape_size; // 0x68
	public object js_func_count; // 0x70
	public object js_func_size; // 0x78
	public object js_func_code_size; // 0x80
	public object js_func_pc2line_count; // 0x88
	public object js_func_pc2line_size; // 0x90
	public object c_func_count; // 0x98
	public object array_count; // 0xA0
	public object fast_array_count; // 0xA8
	public object fast_array_elements; // 0xB0
	public object binary_object_count; // 0xB8
	public object binary_object_size; // 0xC0
}

// Namespace: com.pixui
public struct NativeBuffer
{

	// Fields
	public object ptr; // 0xFFFFFFFFFFFFFFF8
	public object size; // 0x0

	// Methods

	// RVA: 0x3D1D998
	public override object GetHashCode() { }

	// RVA: 0x3D1DA48
	public override object ToString() { }

}

// Namespace: com.pixui
public struct NativeString
{

	// Fields
	public object ptr; // 0xFFFFFFFFFFFFFFF8
	public object size; // 0x0
	public object hashCode; // 0x4

	// Methods

	// RVA: 0x3D1DB20
	public override object GetHashCode() { }

	// RVA: 0x3D1DB30
	public override object ToString() { }

}

// Namespace: com.pixui
public struct WindowInfo
{

	// Fields
	public object memory; // 0xFFFFFFFFFFFFFFF8
	public object buffer; // 0xE0
	public object tag; // 0xF0
	public object useAtlas; // 0xF4
}

// Namespace: com.pixui
public struct NativeColor
{

	// Fields
	public object blue; // 0xFFFFFFFFFFFFFFF8
	public object green; // 0xFFFFFFFFFFFFFFF9
	public object red; // 0xFFFFFFFFFFFFFFFA
	public object alpha; // 0xFFFFFFFFFFFFFFFB

	// Methods

	// RVA: 0x3D1DCD4
	public override object GetHashCode() { }

	// RVA: 0x3D1DDE8
	public override object ToString() { }

	// RVA: 0x3D1DFA8
	public object Equals(object other) { }

}

// Namespace: com.pixui
public struct NativeMatrix
{

	// Fields
	public object a; // 0xFFFFFFFFFFFFFFF8
	public object b; // 0xFFFFFFFFFFFFFFFC
	public object c; // 0x0
	public object d; // 0x4
	public object e; // 0x8
	public object f; // 0xC

	// Properties
	public object translateX { get; }
	public object translateY { get; }

	// Methods

	// RVA: 0x3CFA7C4
	public static object op_Implicit(object mat) { }

	// RVA: 0x3D1E038
	public override object GetHashCode() { }

	// RVA: 0x3D1E0F0
	public override object ToString() { }

	// RVA: 0x3D1E330
	public object get_translateX() { }

	// RVA: 0x3D1E340
	public object get_translateY() { }

}

// Namespace: com.pixui
public struct NativePoint
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x3D1E350
	public override object GetHashCode() { }

	// RVA: 0x3D1E3F8
	public override object ToString() { }

}

// Namespace: com.pixui
public struct NativeSize
{

	// Fields
	public object width; // 0xFFFFFFFFFFFFFFF8
	public object height; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x3D1E548
	public override object GetHashCode() { }

	// RVA: 0x3D1E5F0
	public override object ToString() { }

}

// Namespace: com.pixui
public struct NativeRect
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object width; // 0x0
	public object height; // 0x4

	// Methods

	// RVA: 0x3D1E740
	public override object GetHashCode() { }

	// RVA: 0x3D1E7F0
	public override object ToString() { }

}

// Namespace: com.pixui
public struct NativeLine
{

	// Fields
	public object width; // 0xFFFFFFFFFFFFFFF8
	public object line_type; // 0xFFFFFFFFFFFFFFFC
	public object color; // 0x0

	// Methods

	// RVA: 0x3D1E9B0
	public override object GetHashCode() { }

	// RVA: 0x3D1EB14
	public override object ToString() { }

}

// Namespace: com.pixui
public struct NativeBorder
{

	// Fields
	public object leftLine; // 0xFFFFFFFFFFFFFFF8
	public object rightLine; // 0x4
	public object topLine; // 0x10
	public object bottomLine; // 0x1C

	// Methods

	// RVA: 0x3D1EC10
	public override object GetHashCode() { }

	// RVA: 0x3D1ED10
	public override object ToString() { }

}

// Namespace: com.pixui
public struct FontMetrics
{

	// Fields
	public object height; // 0xFFFFFFFFFFFFFFF8
	public object ascent; // 0xFFFFFFFFFFFFFFFA
	public object descent; // 0xFFFFFFFFFFFFFFFC
	public object x_height; // 0xFFFFFFFFFFFFFFFE
	public object draw_spaces; // 0x0

	// Methods

	// RVA: 0x3D1EEF0
	public override object GetHashCode() { }

	// RVA: 0x3D1EFB8
	public override object ToString() { }

}

// Namespace: com.pixui
public struct NativeBorderWidth
{

	// Fields
	public object left; // 0xFFFFFFFFFFFFFFF8
	public object top; // 0xFFFFFFFFFFFFFFFC
	public object right; // 0x0
	public object bottom; // 0x4

	// Methods

	// RVA: 0x3D1F1CC
	public override object GetHashCode() { }

	// RVA: 0x3D1F27C
	public override object ToString() { }

}

// Namespace: com.pixui
public struct NativeRadiuses
{

	// Fields
	public object topLeftX; // 0xFFFFFFFFFFFFFFF8
	public object topLeftY; // 0xFFFFFFFFFFFFFFFC
	public object topRightX; // 0x0
	public object topRightY; // 0x4
	public object bottomRightX; // 0x8
	public object bottomRightY; // 0xC
	public object bottomLeftX; // 0x10
	public object bottomLeftY; // 0x14

	// Methods

	// RVA: 0x3D1F43C
	public override object GetHashCode() { }

	// RVA: 0x3D1F610
	public override object ToString() { }

	// RVA: 0x3D1F8D0
	public object Equals(object other) { }

	// RVA: 0x3D1F9C0
	public override object Equals(object other) { }

}

// Namespace: com.pixui
public struct ImageSlice
{

	// Fields
	public object repeat; // 0xFFFFFFFFFFFFFFF8
	public object model; // 0xFFFFFFFFFFFFFFFC
	public object slice_top_x; // 0x0
	public object slice_top_y; // 0x4
	public object slice_bottom_x; // 0x8
	public object slice_bottom_y; // 0xC

	// Methods

	// RVA: 0x3D1FA7C
	public override object GetHashCode() { }

	// RVA: 0x3D1FB34
	public override object ToString() { }

}

// Namespace: com.pixui
public struct CmdBufferList
{

	// Fields
	public object ptr; // 0xFFFFFFFFFFFFFFF8
	public object size; // 0x0

	// Methods

	// RVA: 0x3D1FD9C
	public override object GetHashCode() { }

	// RVA: 0x3D1FE4C
	public override object ToString() { }

}

// Namespace: com.pixui
public struct CmdBufferItem
{

	// Fields
	public object type; // 0xFFFFFFFFFFFFFFF8
	public object buffer; // 0x0

	// Methods

	// RVA: 0x3D1FF18
	public override object GetHashCode() { }

	// RVA: 0x3D1FFC8
	public override object ToString() { }

}

// Namespace: com.pixui
public struct PushGroupBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object localMat; // 0xFFFFFFFFFFFFFFFC
	public object globalMat; // 0x14
	public object globalIvMat; // 0x2C
	public object size; // 0x44
	public object debugInfo; // 0x50

	// Methods

	// RVA: 0x3D20094
	public override object GetHashCode() { }

	// RVA: 0x3D201D4
	public override object ToString() { }

}

// Namespace: com.pixui
public struct PushClipBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object localMat; // 0xFFFFFFFFFFFFFFFC
	public object globalMat; // 0x14
	public object globalIvMat; // 0x2C
	public object rect; // 0x44
	public object debugInfo; // 0x58

	// Methods

	// RVA: 0x3D20414
	public override object GetHashCode() { }

	// RVA: 0x3D2055C
	public override object ToString() { }

}

// Namespace: com.pixui
public struct DrawTextBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object fontId; // 0xFFFFFFFFFFFFFFFC
	public object mat; // 0x0
	public object textPtr; // 0x18
	public object text; // 0x20
	public object color; // 0x30
	public object rect; // 0x34
	public object spacing; // 0x44
	public object strokeWidth; // 0x48
	public object strokeColor; // 0x4C
	public object debugInfo; // 0x50

	// Methods

	// RVA: 0x3D2079C
	public override object GetHashCode() { }

	// RVA: 0x3D2089C
	public override object ToString() { }

}

// Namespace: com.pixui
public struct DrawTextShadowBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object mat; // 0xFFFFFFFFFFFFFFFC
	public object color; // 0x14
	public object blur; // 0x18
	public object debugInfo; // 0x20

	// Methods

	// RVA: 0x3D20B48
	public override object GetHashCode() { }

	// RVA: 0x3D20C40
	public override object ToString() { }

}

// Namespace: com.pixui
public struct DrawBorderBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object mat; // 0xFFFFFFFFFFFFFFFC
	public object rect; // 0x14
	public object border; // 0x24
	public object radius; // 0x54
	public object debugInfo; // 0x78

	// Methods

	// RVA: 0x3D20E44
	public override object GetHashCode() { }

	// RVA: 0x3D20F8C
	public override object ToString() { }

}

// Namespace: com.pixui
public struct DrawRectBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object mat; // 0xFFFFFFFFFFFFFFFC
	public object rect; // 0x14
	public object color; // 0x24
	public object mask; // 0x28
	public object radius; // 0x2C
	public object debugInfo; // 0x50

	// Methods

	// RVA: 0x3D211F4
	public override object GetHashCode() { }

	// RVA: 0x3D21314
	public override object ToString() { }

}

// Namespace: com.pixui
public struct DrawImageBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object assetId; // 0xFFFFFFFFFFFFFFFC
	public object mat; // 0x0
	public object pos; // 0x18
	public object size; // 0x28
	public object repeat; // 0x38
	public object attachment; // 0x3C
	public object slice; // 0x40
	public object color; // 0x58
	public object radius; // 0x5C
	public object widths; // 0x7C
	public object debugInfo; // 0x90

	// Methods

	// RVA: 0x3D215B0
	public override object GetHashCode() { }

	// RVA: 0x3D21678
	public override object ToString() { }

}

// Namespace: com.pixui
public struct DrawLineBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object mat; // 0xFFFFFFFFFFFFFFFC
	public object width; // 0x14
	public object line_type; // 0x18
	public object color; // 0x1C
	public object begin_pt; // 0x20
	public object end_pt; // 0x28
	public object debugInfo; // 0x30

	// Methods

	// RVA: 0x3D21AC0
	public override object GetHashCode() { }

	// RVA: 0x3D21BC8
	public override object ToString() { }

}

// Namespace: com.pixui
public struct PushSlotBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object handle; // 0xFFFFFFFFFFFFFFFC
	public object mat; // 0x0
	public object rect; // 0x18
	public object debugInfo; // 0x28

	// Methods

	// RVA: 0x3D21EA0
	public override object GetHashCode() { }

	// RVA: 0x3D21F98
	public override object ToString() { }

}

// Namespace: com.pixui
public struct DrawBoxShadowBuffer
{

	// Fields
	public object id; // 0xFFFFFFFFFFFFFFF8
	public object mat; // 0xFFFFFFFFFFFFFFFC
	public object pos; // 0x14
	public object radius; // 0x24
	public object blur; // 0x44
	public object color; // 0x48
	public object inset; // 0x4C
	public object debugInfo; // 0x50

	// Methods

	// RVA: 0x3D22260
	public override object GetHashCode() { }

}

// Namespace: com.pixui
public enum EKeyCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Backspace;
	public const object Tab;
	public const object Enter;
	public const object Pause;
	public const object CapsLock;
	public const object Esc;
	public const object Space;
	public const object PageUp;
	public const object PageDown;
	public const object End;
	public const object Home;
	public const object Left;
	public const object Up;
	public const object Right;
	public const object Down;
	public const object PrintScreen;
	public const object Insert;
	public const object Delete;
	public const object Key0;
	public const object Key1;
	public const object Key2;
	public const object Key3;
	public const object Key4;
	public const object Key5;
	public const object Key6;
	public const object Key7;
	public const object Key8;
	public const object Key9;
	public const object KeyA;
	public const object KeyB;
	public const object KeyC;
	public const object KeyD;
	public const object KeyE;
	public const object KeyF;
	public const object KeyG;
	public const object KeyH;
	public const object KeyI;
	public const object KeyJ;
	public const object KeyK;
	public const object KeyL;
	public const object KeyM;
	public const object KeyN;
	public const object KeyO;
	public const object KeyP;
	public const object KeyQ;
	public const object KeyR;
	public const object KeyS;
	public const object KeyT;
	public const object KeyU;
	public const object KeyV;
	public const object KeyW;
	public const object KeyX;
	public const object KeyY;
	public const object KeyZ;
	public const object CommandKeyLeft;
	public const object CommandKeyRight;
	public const object MenuKeyRight;
	public const object PadNum0;
	public const object PadNum1;
	public const object PadNum2;
	public const object PadNum3;
	public const object PadNum4;
	public const object PadNum5;
	public const object PadNum6;
	public const object PadNum7;
	public const object PadNum8;
	public const object PadNum9;
	public const object PadMultiply;
	public const object PadPlus;
	public const object PadEnter;
	public const object PadMinus;
	public const object PadDecimal;
	public const object PadDivide;
	public const object F1;
	public const object F2;
	public const object F3;
	public const object F4;
	public const object F5;
	public const object F6;
	public const object F7;
	public const object F8;
	public const object F9;
	public const object F10;
	public const object F11;
	public const object F12;
	public const object F13;
	public const object F14;
	public const object F15;
	public const object F16;
	public const object F17;
	public const object F18;
	public const object F19;
	public const object F20;
	public const object PadClear;
	public const object PadEquals;
	public const object NumLock;
	public const object ScrollLock;
	public const object Shift;
	public const object RightShift;
	public const object Ctrl;
	public const object RightCtrl;
	public const object Alt;
	public const object RightAlt;
	public const object VolumeDown;
	public const object VolumeUp;
	public const object Next;
	public const object Previous;
	public const object Stop;
	public const object PlayPause;
	public const object Mute;
	public const object Semicolon;
	public const object EqualSign;
	public const object Comma;
	public const object Dash;
	public const object Period;
	public const object ForwardSlash;
	public const object GraveAccent;
	public const object OpenBracket;
	public const object Backslash;
	public const object CloseBracket;
	public const object SingleQuote;
	public const object Function;
}

// Namespace: com.pixui
public enum GamepadKey
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object GamepadA;
	public const object GamepadB;
	public const object GamepadX;
	public const object GamepadY;
	public const object GamepadThumbL;
	public const object GamepadThumbR;
	public const object GamepadShoulderL;
	public const object GamepadShoulderR;
	public const object GamepadLeftTrigger;
	public const object GamepadRightTrigger;
	public const object GamepadUp;
	public const object GamepadDown;
	public const object GamepadLeft;
	public const object GamepadRight;
	public const object GamepadBack;
	public const object GamepadShare;
	public const object GamepadOption;
	public const object GamepadLeftStickUp;
	public const object GamepadLeftStickDown;
	public const object GamepadLeftStickRight;
	public const object GamepadLeftStickLeft;
	public const object GamepadRightStickUp;
	public const object GamepadRightStickDown;
	public const object GamepadRightStickRight;
	public const object GamepadRightStickLeft;
	public const object GamepadLeftX;
	public const object GamepadLeftY;
	public const object GamepadRightX;
	public const object GamepadRightY;
	public const object GamepadLeftTriggerAxis;
	public const object GamepadRightTriggerAxis;
}

// Namespace: com.pixui
public struct VMPtr
{

	// Fields
	public object runtime; // 0xFFFFFFFFFFFFFFF8
	public object context; // 0x0
}

// Namespace: com.pixui
public struct DebugInfo
{

	// Fields
	public object elementType; // 0xFFFFFFFFFFFFFFF8
	public object szClassName; // 0x0
	public object szId; // 0x8
}

// Namespace: com.pixui
public enum ElementType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Element;
	public const object Tag;
	public const object Div;
	public const object Script;
	public const object Body;
	public const object Html;
	public const object Head;
	public const object Image;
	public const object Text;
	public const object Style;
	public const object List;
	public const object Listitem;
	public const object Input;
	public const object Link;
	public const object Comment;
	public const object Video;
	public const object Audio;
	public const object BR;
	public const object Meta;
	public const object TextField;
	public const object Canvas;
	public const object Lottie;
	public const object Slot;
}

// Namespace: com.pixui
public struct Capability
{

	// Fields
	public object supportPixelFormat; // 0xFFFFFFFFFFFFFFF8
	public object supportRetainFrame; // 0xFFFFFFFFFFFFFFFC
	public object supportDrawTextWithLetterSpace; // 0xFFFFFFFFFFFFFFFD
	public object supportTextShape; // 0xFFFFFFFFFFFFFFFE
	public object supportDrawTextWithEmoji; // 0xFFFFFFFFFFFFFFFF
	public object supportLoadExternalFile; // 0x0
	public object supportPremultipliedAlphaImageDrawing; // 0x1
	public object isImageBlendsInLinearSpace; // 0x2
}

// Namespace: com.pixui
public static class PxProxy
{

	// Fields
	public static object onLoadDataSyncThreaded; // 0x0
	public static object onLoadDataAsyncThreaded; // 0x8
	public static object onReleaseDataSyncThreaded; // 0x10
	public static object onLoadDataAsync; // 0x18
	public static object onLoadDataSync; // 0x20
	public static object sendMessage; // 0x28
	public static object luaRPCPost; // 0x30
	public static object getFont; // 0x38
	public static object getShader; // 0x40
	public static object writeLog; // 0x48
	public static object onScriptInit; // 0x50
	public static object onScriptShutdown; // 0x58
	public static object onLoadComplete; // 0x60
	public static object onOpenChildWindow; // 0x68
	public static object onWindowAlert; // 0x70
	public static object onWindowConfirm; // 0x78
	public static object shouldOverrideImageLoading; // 0x80
	public static object onSlotCreated; // 0x88
	public static object onSlotDelete; // 0x90
	public static object onSlotStashing; // 0x98
	public static object onSlotPaint; // 0xA0
	public static object onInternalError; // 0xA8
	public static object getDefaultMountRoot; // 0xB0
	public static object onRenderElementCreated; // 0xB8
	public static object onRenderElementDestroying; // 0xC0
	public static object onRenderElementEnable; // 0xC8
	public static object onRenderElementPaint; // 0xD0
	public static object getLocalFilePath; // 0xD8
	public static object canResolveFilePath; // 0xE0
	public static object openFile; // 0xE8
	public static object closeFile; // 0xF0
	public static object readFile; // 0xF8
	public static object seekFile; // 0x100
}

// Namespace: com.pixui
public class PxRoot
{

	// Fields
	private object m_Inited; // 0x28

	// Methods

	// RVA: 0x3D2241C
	protected override object Awake() { }

	// RVA: 0x3D2246C
	private object Update() { }

	// RVA: 0x3D22558
	private object OnApplicationPause(object pause) { }

	// RVA: 0x3D225E4
	public object .ctor() { }

}

// Namespace: com.pixui
public sealed class OnSlotAttachmentLoadComplete
{

	// Methods

	// RVA: 0x3D226F8
	public object .ctor(object object, object method) { }

	// RVA: 0x3D227A0
	public virtual object Invoke(object result) { }

}

// Namespace: com.pixui
public sealed class ShouldOverrideAttachmentLoadDelegate
{

	// Methods

	// RVA: 0x3D22ACC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D22BD8
	public virtual object Invoke(object attachment, object onComplete) { }

}

// Namespace: com.pixui
public sealed class OnSlotAttachmentParentBeforeChangeDelegate
{

	// Methods

	// RVA: 0x3D22C88
	public object .ctor(object object, object method) { }

	// RVA: 0x3D22D38
	public virtual object Invoke(object slotAttachment, object newParent) { }

}

// Namespace: com.pixui
public sealed class OnSlotAttachmentParentAfterChangeDelegate
{

	// Methods

	// RVA: 0x3D22DD8
	public object .ctor(object object, object method) { }

	// RVA: 0x3D22E80
	public virtual object Invoke(object slotAttachment) { }

}

// Namespace: com.pixui
public sealed class OnSlotAttachmentAttachDelegate
{

	// Methods

	// RVA: 0x3D2316C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D23288
	public virtual object Invoke(object attachment) { }

}

// Namespace: com.pixui
public sealed class OnSlotAttachmentDetachDelegate
{

	// Methods

	// RVA: 0x3D23574
	public object .ctor(object object, object method) { }

	// RVA: 0x3D23690
	public virtual object Invoke(object attachment) { }

}

// Namespace: com.pixui
public sealed class OnSlotAttachmentDestroyDelegate
{

	// Methods

	// RVA: 0x3D23730
	public object .ctor(object object, object method) { }

	// RVA: 0x3D237D8
	public virtual object Invoke(object result) { }

}

// Namespace: com.pixui
public sealed class AttachmentRootRedirectDelegate
{

	// Methods

	// RVA: 0x3D23AD8
	public object .ctor(object object, object method) { }

	// RVA: 0x3D23BF4
	public virtual object Invoke(object att) { }

}

// Namespace: 
private class PatternLoader
{

	// Fields
	private object m_Pattern; // 0x8
	private object m_Dispatcher; // 0x10

	// Methods

	// RVA: 0x3D2422C
	public object .ctor(object pattern, object dispatcher) { }

	// RVA: 0x3D243E4
	public object Match(object url) { }

	// RVA: 0x3D24408
	public object Dispatch(object m, object attachment, object onComplete) { }

}

// Namespace: 
public enum Status
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Init;
	public const object Pendding;
	public const object Mounted;
	public const object Fail;
}

// Namespace: 
private sealed class <>c__DisplayClass47_0
{

	// Fields
	public object <>4__this; // 0x8
	public object go; // 0x10
	public object storeActive; // 0x18

	// Methods

	// RVA: 0x3D257D8
	public object .ctor() { }

	// RVA: 0x3D2597C
	internal object <MountGameObject>b__0() { }

}

// Namespace: 
public class Attachment
{

	// Fields
	private object <windowId>k__BackingField; // 0x8
	private object <src>k__BackingField; // 0x10
	private object <handle>k__BackingField; // 0x18
	private object <status>k__BackingField; // 0x1C
	private object <timeout>k__BackingField; // 0x20
	private object <acceptTime>k__BackingField; // 0x24
	private object m_BindingSlot; // 0x28
	private object m_LastBindingSlot; // 0x30
	private object m_MountGameObject; // 0x38
	private object m_Disposed; // 0x40
	private object m_Mgr; // 0x48
	private object m_TimeoutTimer; // 0x50
	private object <rootRedirect>k__BackingField; // 0x58
	public object onBeforeParentChange; // 0x60
	public object onAfterParentChange; // 0x68
	public object onDestroy; // 0x70
	public object onAttach; // 0x78
	public object onDetach; // 0x80

	// Properties
	public object windowId { get; set; }
	public object src { get; set; }
	public object handle { get; set; }
	public object status { get; set; }
	private object timeout { set; }
	private object acceptTime { set; }
	public object rootRedirect { get; }

	// Methods

	// RVA: 0x3D24CB4
	public object get_windowId() { }

	// RVA: 0x3D24CBC
	private object set_windowId(object value) { }

	// RVA: 0x3D24CC4
	public object get_src() { }

	// RVA: 0x3D24CCC
	private object set_src(object value) { }

	// RVA: 0x3D24CD4
	public object get_handle() { }

	// RVA: 0x3D24CDC
	private object set_handle(object value) { }

	// RVA: 0x3D24CE4
	public object get_status() { }

	// RVA: 0x3D24CEC
	private object set_status(object value) { }

	// RVA: 0x3D24CF4
	private object set_timeout(object value) { }

	// RVA: 0x3D24CFC
	private object set_acceptTime(object value) { }

	// RVA: 0x3D24D04
	public object get_rootRedirect() { }

	// RVA: 0x3D248D4
	public object .ctor(object mgr, object windowId, object handle, object src) { }

	// RVA: 0x3D24D0C
	private object OnMountConfirm(object sucess) { }

	// RVA: 0x3D24DF4
	internal object Attach(object slot) { }

	// RVA: 0x3D25638
	internal object Detach() { }

	// RVA: 0x3D24E00
	private object UpdateBinding(object force) { }

	// RVA: 0x3D24C58
	public object Dispose() { }

	// RVA: 0x3D24928
	internal object Accept(object timeoutSeconds) { }

	// RVA: 0x3D25644
	public object MountGameObject(object go) { }

	// RVA: 0x3D257E0
	public object GetMountingGameObject() { }

	// RVA: 0x3D257E8
	public object GetRedirectRoot() { }

	// RVA: 0x3D258A8
	private object <Accept>b__46_0() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__7_2; // 0x8
	public static object <>9__7_0; // 0x10
	public static object <>9__7_3; // 0x18
	public static object <>9__7_1; // 0x20

	// Methods

	// RVA: 0x3D25D9C
	private static object .cctor() { }

	// RVA: 0x3D25DFC
	public object .ctor() { }

	// RVA: 0x3D25E04
	internal object <CreateBuiltInPatternLoaders>b__7_0(object m, object attachment, object onComplete) { }

	// RVA: 0x3D26154
	internal object <CreateBuiltInPatternLoaders>b__7_2(object go) { }

	// RVA: 0x3D261DC
	internal object <CreateBuiltInPatternLoaders>b__7_1(object m, object attachment, object onComplete) { }

	// RVA: 0x3D26604
	internal object <CreateBuiltInPatternLoaders>b__7_3(object go) { }

}

// Namespace: 
private sealed class <>c__DisplayClass12_0
{

	// Fields
	public object attachment; // 0x8

	// Methods

	// RVA: 0x3D248CC
	public object .ctor() { }

	// RVA: 0x3D2668C
	internal object <Create>b__0(object go) { }

}

// Namespace: com.pixui
public class PxSlotMgr
{

	// Fields
	private object m_AttachmentLoaders; // 0x8
	private object m_PatternLoaders; // 0x10
	private object m_Attachments; // 0x18
	private object m_StashingRoot; // 0x20

	// Methods

	// RVA: 0x3D23C08
	public object add_shouldOverrideAttachmentLoad(object value) { }

	// RVA: 0x3D23D8C
	public object remove_shouldOverrideAttachmentLoad(object value) { }

	// RVA: 0x3D23DF8
	private static object CreateBuiltInPatternLoaders() { }

	// RVA: 0x3D242B0
	private object PatternLoaderDispatcher(object attachment, object onComplete) { }

	// RVA: 0x3D24424
	public object .ctor(object stashingRoot) { }

	// RVA: 0x3D24634
	public object Create(object windowId, object attachmentHandle, object src) { }

	// RVA: 0x3D24AAC
	public object Get(object id) { }

	// RVA: 0x3D24B30
	public object Delete(object id) { }

}

// Namespace: 
public class Provider
{

	// Fields
	private readonly object m_Impl; // 0x8
	private readonly object m_Name; // 0x10
	private readonly object m_Prototype; // 0x18
	private object m_Prefab; // 0x20
	private object m_CanPrefably; // 0x28
	private object m_PrefabRoot; // 0x30

	// Properties
	public object name { get; }

	// Methods

	// RVA: 0x3D268A4
	public object get_name() { }

	// RVA: 0x3D268AC
	public object .ctor(object name, object prototype, object widgetImpl, object prefabRoot) { }

	// RVA: 0x3D269EC
	public object Instantiate() { }

}

// Namespace: 
public class IncompleteProviderImpl
{

	// Fields
	private object m_Self; // 0x8
	private object m_Prototype; // 0x10

	// Methods

	// RVA: 0x3D26F84
	public object .ctor(object self, object prototype) { }

	// RVA: -1
	public object By() { }

	// RVA: 0x3D26FBC
	public object By(object implType) { }

}

// Namespace: 
public class IncompleteProviderDeclare
{

	// Fields
	private object m_Self; // 0x8
	private object m_DrawType; // 0x10

	// Methods

	// RVA: 0x3D2682C
	internal object .ctor(object self, object drawType) { }

	// RVA: 0x3D26F18
	public object Declare(object type) { }

	// RVA: -1
	public object Declare() { }

}

// Namespace: com.pixui
public class PxWidgetProvider
{

	// Fields
	private object m_WidgetProvider; // 0x8
	private object m_PrefabRoot; // 0x10

	// Methods

	// RVA: 0x3D266AC
	public object .ctor(object prefabRoot) { }

	// RVA: 0x3D267BC
	public object Impl(object drawType) { }

	// RVA: 0x3D26868
	public object GetProvider(object drawType) { }

}

// Namespace: 
private class FrameStat
{

	// Fields
	public object stayFrameCount; // 0x8
	public object sw; // 0x10
	public object beginFrame; // 0x18
	public object escapeFrame; // 0x1C
	public object stageTime; // 0x20
	public object staying; // 0x28

	// Methods

	// RVA: 0x3D27F98
	public object .ctor() { }

}

// Namespace: 
public sealed class OnWindowScriptInitDelegate
{

	// Methods

	// RVA: 0x3D2A474
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2A590
	public virtual object Invoke(object wnd) { }

}

// Namespace: 
public sealed class OnWindowScriptShutdownDelegate
{

	// Methods

	// RVA: 0x3D2A87C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2A998
	public virtual object Invoke(object wnd) { }

}

// Namespace: 
public sealed class OnWindowTickDelegate
{

	// Methods

	// RVA: 0x3D2AC84
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2ADA0
	public virtual object Invoke(object wnd) { }

}

// Namespace: 
public sealed class OnWindowShutdownDelegate
{

	// Methods

	// RVA: 0x3D2B08C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2B1A8
	public virtual object Invoke(object wnd) { }

}

// Namespace: 
public struct DebugNamePoolKey
{

	// Fields
	public object tagType; // 0xFFFFFFFFFFFFFFF8
	public object drawType; // 0x0
	public object szId; // 0x8

	// Methods

	// RVA: 0x3D2B1BC
	public object Equals(object other) { }

	// RVA: 0x3D2B22C
	public override object GetHashCode() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__64_0; // 0x8

	// Methods

	// RVA: 0x3D2B2C4
	private static object .cctor() { }

	// RVA: 0x3D2B324
	public object .ctor() { }

	// RVA: 0x3D2B32C
	internal object <.ctor>b__64_0(object fontName, object fontStyle, object fontSize) { }

}

// Namespace: com.pixui
public class PxWindow
{

	// Fields
	private readonly object _assetMgr; // 0x8
	private readonly object m_CmdList; // 0x10
	private readonly object m_ContainerStack; // 0x18
	private readonly object _factory; // 0x20
	private readonly object _fontMgr; // 0x28
	private readonly object _mount; // 0x30
	private object _ptr; // 0x38
	private readonly object _ui; // 0x40
	private readonly object _windowCmd; // 0x48
	private object _winInfo; // 0x50
	private object _position; // 0x58
	private object _size; // 0x60
	private object _id; // 0x68
	private object _parentId; // 0x6C
	private object _enableRaycastTarget; // 0x70
	private object m_Url; // 0x78
	private object onMoveTo; // 0x80
	private object onResizeTo; // 0x88
	private object onMessageFromJS; // 0x90
	private object onLoadCompleted; // 0x98
	private object onLoadDataAsync; // 0xA0
	private object onLoadDataSync; // 0xA8
	private object m_Stat; // 0xB0
	private object onWindowScriptInit; // 0xB8
	private object onWindowScriptShutdown; // 0xC0
	private object onWindowTick; // 0xC8
	private object onWindowShutdown; // 0xD0
	private object m_CStringCache; // 0xD8
	private object m_DebugNamePool; // 0xE0
	private object <IsActive>k__BackingField; // 0xE8
	private object m_Disposed; // 0xE9

	// Properties
	private object url { set; }
	public object showDebugName { get; }
	internal object cstringCache { get; }
	internal object debugNamePool { get; }
	public object Id { get; }
	public object IsActive { get; set; }
	public object IsExists { get; }
	public object ParentId { get; set; }
	public object assetMgr { get; }

	// Methods

	// RVA: 0x3D271D0
	private object set_url(object value) { }

	// RVA: 0x3D271D8
	public object add_onWindowScriptInit(object value) { }

	// RVA: 0x3D2727C
	public object remove_onWindowScriptInit(object value) { }

	// RVA: 0x3D27320
	public object add_onWindowScriptShutdown(object value) { }

	// RVA: 0x3D273C4
	public object remove_onWindowScriptShutdown(object value) { }

	// RVA: 0x3D27468
	public object add_onWindowTick(object value) { }

	// RVA: 0x3D2750C
	public object remove_onWindowTick(object value) { }

	// RVA: 0x3D275B0
	public object add_onWindowShutdown(object value) { }

	// RVA: 0x3D27654
	public object remove_onWindowShutdown(object value) { }

	// RVA: 0x3D276F8
	public object get_showDebugName() { }

	// RVA: 0x3D277C4
	internal object get_cstringCache() { }

	// RVA: 0x3D27854
	internal object get_debugNamePool() { }

	// RVA: 0x3D278E4
	public object .ctor(object id, object mount) { }

	// RVA: 0x3D28014
	public object get_Id() { }

	// RVA: 0x3D2801C
	public object get_IsActive() { }

	// RVA: 0x3D28024
	private object set_IsActive(object value) { }

	// RVA: 0x3D24DC8
	public object get_IsExists() { }

	// RVA: 0x3D2802C
	public object get_ParentId() { }

	// RVA: 0x3D28034
	public object set_ParentId(object value) { }

	// RVA: 0x3D2803C
	public object get_assetMgr() { }

	// RVA: 0x3D28044
	public override object ToString() { }

	// RVA: 0x3D28108
	public object GetPtr() { }

	// RVA: 0x3D28110
	public object GetInfo() { }

	// RVA: 0x3D27F74
	public object GetDisplay() { }

	// RVA: 0x3D28118
	public object GetMount() { }

	// RVA: 0x3D28120
	public object SetActive(object v) { }

	// RVA: 0x3D28128
	public object ShowModal(object v) { }

	// RVA: 0x3D2814C
	public object EnableEventHandler(object v) { }

	// RVA: 0x3D281F0
	public object MoveBy(object v) { }

	// RVA: 0x3D28200
	public object MoveTo(object v) { }

	// RVA: 0x3D28368
	public object ResizeBy(object v) { }

	// RVA: 0x3D28378
	public object ResizeTo(object v) { }

	// RVA: 0x3D285EC
	public object OnScriptInit() { }

	// RVA: 0x3D28898
	public object OnScriptShutdown() { }

	// RVA: 0x3D28988
	public object OnLoadComplete(object v) { }

	// RVA: 0x3D28BA4
	public object ActiveKeyboard(object type, object defaultTextPtr, object hintTextPtr) { }

	// RVA: 0x3D28DC0
	public object DeativateKeyboard() { }

	// RVA: 0x3D28EB8
	public object Dispose() { }

	// RVA: 0x3D29064
	public object RemoveCmd(object index) { }

	// RVA: -1
	public object AddCmd(object cmd) { }

	// RVA: 0x3D290F8
	public object GetCmd(object index) { }

	// RVA: -1
	public object GetCmd(object index) { }

	// RVA: 0x3D2918C
	public object GetContainer() { }

	// RVA: 0x3D291E8
	public object PushContainer(object cmd) { }

	// RVA: 0x3D2926C
	public object PopContainer() { }

	// RVA: 0x3D292C8
	public object LoadPageFromData(object data, object baseUrl) { }

	// RVA: 0x3D293E0
	public object LoadUrl(object url) { }

	// RVA: 0x3D29470
	public object GetFont(object fontId) { }

	// RVA: 0x3D29494
	public object CreateFont(object fontName, object fontSize, object style, object fm) { }

	// RVA: 0x3D294B8
	public object DeleteFont(object fontId) { }

	// RVA: 0x3D294DC
	public object GetTextWidth(object textPtr, object textLen, object textId, object fontId) { }

	// RVA: 0x3D29500
	public object CreateTexture(object url, object textureId, object width, object height, object flag, object format, object ptr, object dataSize) { }

	// RVA: 0x3D29530
	public object UpdateTexture(object textureId, object format, object ptr, object dataSize) { }

	// RVA: 0x3D29624
	public object DeleteTexture(object textureId) { }

	// RVA: 0x3D29600
	public object GetAsset(object id) { }

	// RVA: 0x3D284F0
	public object UpdateSize(object size) { }

	// RVA: 0x3D2964C
	public object Update(object dt) { }

	// RVA: 0x3D29AD8
	public object GetCharWidth(object windowId, object cp, object fontId) { }

	// RVA: 0x3D29AFC
	public object OnKeyBoardInput(object text, object isEnd, object bLostFocus, object bReplace) { }

	// RVA: 0x3D29C94
	public object OnKey(object keyCode, object modifiers, object keyDown) { }

	// RVA: 0x3D29D6C
	public object OnMouseEvent(object position, object scroll, object button, object press) { }

	// RVA: 0x3D29DF8
	public object OnTouchEvent(object position, object pointerId, object phase) { }

	// RVA: 0x3D29E5C
	public object OnMessageFromJS(object msg) { }

	// RVA: 0x3D29F34
	internal object OnLoadDataAsync(object url, object callback) { }

	// RVA: 0x3D2A068
	internal object OnLoadDataSync(object url, object callback) { }

}

// Namespace: com.pixui
public enum PathType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Fill;
	public const object ConvexFill;
	public const object Stroke;
	public const object Triangles;
}

// Namespace: com.pixui
public enum FillType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Texture;
	public const object Stencil;
	public const object Text;
}

// Namespace: com.pixui
public enum GradientType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Linear;
	public const object Radial;
	public const object Conic;
}

// Namespace: com.pixui
public class VGHelper
{

	// Methods

	// RVA: 0x3D2B450
	public static object GetPointer(object funDelegate) { }

	// RVA: 0x3D2B4D8
	public static object TransformPoint(object dx, object dy, object t, object sx, object sy) { }

	// RVA: 0x3D2B520
	public static object ToMatrix(object paint) { }

	// RVA: 0x3D2B534
	public static object UpdateVertex(object vtx, object x, object y, object uv, object innercol, object outercol) { }

	// RVA: 0x3D2B64C
	public static object GetCall(object ctx, object offset) { }

	// RVA: 0x3D2B674
	public static object GetUniform(object ctx, object offset) { }

	// RVA: 0x3D2B698
	public static object GetSubMeshCount(object ctx) { }

}

// Namespace: com.pixui
public sealed class FlushCallbackDelegate
{

	// Methods

	// RVA: 0x3D2B79C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2B834
	public virtual object Invoke(object ctx) { }

}

// Namespace: com.pixui
public sealed class TextureCreateCallbackDelegate
{

	// Methods

	// RVA: 0x3D2B934
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2B9CC
	public virtual object Invoke(object ctx, object type, object width, object height, object flags, object data) { }

}

// Namespace: com.pixui
public sealed class TextureUpdateCallbackDelegate
{

	// Methods

	// RVA: 0x3D2BAE0
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2BB78
	public virtual object Invoke(object ctx, object image, object x, object y, object w, object h, object data) { }

}

// Namespace: com.pixui
public sealed class TextureDeleteCallbackDelegate
{

	// Methods

	// RVA: 0x3D2BC24
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2BCBC
	public virtual object Invoke(object ctx, object image) { }

}

// Namespace: com.pixui
public sealed class TextureGetSizeCallbackDelegate
{

	// Methods

	// RVA: 0x3D2BD90
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2BE28
	public virtual object Invoke(object ctx, object image, object w, object h) { }

}

// Namespace: com.pixui
public sealed class FontGetTextGlyCallbackDelegate
{

	// Methods

	// RVA: 0x3D2BEFC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D2BF94
	public virtual object Invoke(object text, object len, object fontProp, object outVertex) { }

}

// Namespace: com.pixui
public class VGRender
{

	// Fields
	private static object MAIN_TEX_ID; // 0x0
	private static object DEFAULT_CLEAR_COLOR; // 0x4
	private static object DEFALT_MATRIX; // 0x14
	private static object s_commandBuffer; // 0x58
	private static object s_imageDic; // 0x60
	private static object s_curRenderTexture; // 0x68
	private static object s_curRenderTextureID; // 0x70
	private static object s_mesh; // 0x78
	private static object s_meshIndex; // 0x80
	private static object s_verts; // 0x88
	private static object s_uvs; // 0x90
	private static object s_matBlock; // 0x98
	private static object s_shader; // 0xA0
	private static object s_matDic; // 0xA8
	private static object s_triangles; // 0xB0
	private static object s_tiranglePoints; // 0xB8
	private static object s_charOffset; // 0xC0
	private static object s_viewSize; // 0xC8
	private static object s_extent; // 0xD8
	private static object s_scissorExtScale; // 0xE8
	private static object s_col; // 0xF8
	private static object s_Colors; // 0x108
	private static object s_Stops; // 0x110

	// Methods

	// RVA: 0x3D2C018
	public static object TextureCreateCallback(object ctx, object type, object width, object height, object flags, object data) { }

	// RVA: 0x3D2C2D8
	public static object TextureUpdateCallback(object ctx, object image, object x, object y, object w, object h, object data) { }

	// RVA: 0x3D2C668
	public static object TextureDeleteCallback(object ctx, object image) { }

	// RVA: 0x3D2C9C4
	public static object TextureGetSizeCallback(object ctx, object image, object w, object h) { }

	// RVA: 0x3D2CC90
	public static object FontGetTextGlyCallback(object text, object len, object fontProp, object outVertex) { }

	// RVA: 0x3D2E0E4
	private static object DoFill(object call, object pass, object type, object gradientType) { }

	// RVA: 0x3D2E5FC
	private static object FillTriangles(object offset, object count) { }

	// RVA: 0x3D2E998
	private static object FillFans(object offset, object count) { }

	// RVA: 0x3D2ED28
	private static object SetUniforms(object ctx, object offset, object outType, object gradientType, object isFontImage, object type) { }

	// RVA: 0x3D2F868
	private static object ProcessStroke(object ctx, object call) { }

	// RVA: 0x3D2F99C
	private static object ProcessConvexFill(object ctx, object call) { }

	// RVA: 0x3D2FB60
	private static object ProcessFill(object ctx, object call) { }

	// RVA: 0x3D2FD7C
	private static object ProcessTriangles(object ctx, object call) { }

	// RVA: 0x3D2D8B8
	public static object RenderFlush(object ptr) { }

	// RVA: 0x3D2E028
	private static object GetVGTexture(object image) { }

	// RVA: 0x3D2E1FC
	private static object GetVGMat(object call, object type, object gradintType) { }

	// RVA: 0x3D2FFF0
	public static object Init() { }

	// RVA: 0x3D309AC
	public static object Dispose() { }

	// RVA: 0x3D30EB4
	private static object .cctor() { }

}

// Namespace: com.pixui
public class VGRenderTexture
{

	// Properties
	public override object width { get; }
	public override object height { get; }

	// Methods

	// RVA: 0x3D2DFFC
	public object .ctor(object url, object id, object tx) { }

	// RVA: 0x3D30FD0
	public override object get_width() { }

	// RVA: 0x3D31024
	public override object get_height() { }

	// RVA: 0x3D31078
	public object FreeDataUrl(object ptr) { }

	// RVA: 0x3D31100
	public object GetDataUrl(object type) { }

}

// Namespace: 
public struct __Internal
{

	// Fields
	internal object r; // 0xFFFFFFFFFFFFFFF8
	internal object g; // 0xFFFFFFFFFFFFFFFC
	internal object b; // 0x0
	internal object a; // 0x4
}

// Namespace: com.pixui
public class NVGcolor
{
}

// Namespace: 
public struct <xform>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct __Internal
{

	// Fields
	internal object fontSize; // 0xFFFFFFFFFFFFFFF8
	internal object letterSpacing; // 0xFFFFFFFFFFFFFFFC
	internal object fontBlur; // 0x0
	internal object textAlign; // 0x4
	internal object fontId; // 0x8
	internal object xOffset; // 0xC
	internal object yOffset; // 0x10
	internal object invscale; // 0x14
	internal object xform; // 0x18
	internal object innerColor; // 0x30
	internal object outerColor; // 0x40
}

// Namespace: com.pixui
public class BackendFontStyle
{
}

// Namespace: 
public struct <innercol>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <outercol>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct __Internal
{

	// Fields
	internal object x; // 0xFFFFFFFFFFFFFFF8
	internal object y; // 0xFFFFFFFFFFFFFFFC
	internal object innercol; // 0x0
	internal object outercol; // 0x4
	internal object u; // 0x8
	internal object v; // 0xC
}

// Namespace: com.pixui
public class NVGvertex
{
}

// Namespace: 
public struct __Internal
{

	// Fields
	internal object srcRGB; // 0xFFFFFFFFFFFFFFF8
	internal object dstRGB; // 0xFFFFFFFFFFFFFFFC
	internal object srcAlpha; // 0x0
	internal object dstAlpha; // 0x4
}

// Namespace: com.pixui
public class UnityNVGblend
{
}

// Namespace: 
public struct __Internal
{

	// Fields
	internal object type; // 0xFFFFFFFFFFFFFFF8
	internal object image; // 0xFFFFFFFFFFFFFFFC
	internal object isFontImage; // 0x0
	internal object pathOffset; // 0x4
	internal object pathCount; // 0x8
	internal object triangleOffset; // 0xC
	internal object triangleCount; // 0x10
	internal object uniformOffset; // 0x14
	internal object blendFunc; // 0x18
}

// Namespace: com.pixui
public class UnityNVGcall
{
}

// Namespace: 
public struct __Internal
{

	// Fields
	internal object fillOffset; // 0xFFFFFFFFFFFFFFF8
	internal object fillCount; // 0xFFFFFFFFFFFFFFFC
	internal object strokeOffset; // 0x0
	internal object strokeCount; // 0x4
}

// Namespace: com.pixui
public class UnityNVGpath
{
}

// Namespace: 
public struct <colors>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <controlEnd>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <controlStart>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <extent>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <paintMat>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <scissorExt>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <scissorMat>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <scissorScale>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct <stops>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct __Internal
{

	// Fields
	internal object imageID; // 0xFFFFFFFFFFFFFFF8
	internal object scissorMat; // 0xFFFFFFFFFFFFFFFC
	internal object paintMat; // 0x3C
	internal object innerCol; // 0x7C
	internal object outerCol; // 0x8C
	internal object scissorExt; // 0x9C
	internal object scissorScale; // 0xA4
	internal object extent; // 0xAC
	internal object radius; // 0xB4
	internal object feather; // 0xB8
	internal object strokeMult; // 0xBC
	internal object strokeThr; // 0xC0
	internal object texType; // 0xC4
	internal object type; // 0xC8
	internal object gradientType; // 0xCC
	internal object controlStart; // 0xD0
	internal object controlEnd; // 0xDC
	internal object stopCount; // 0xE8
	internal object stops; // 0xEC
	internal object colors; // 0x10C
}

// Namespace: com.pixui
public class UnityNVGfragUniforms
{
}

// Namespace: 
public struct <view>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct __Internal
{

	// Fields
	internal object view; // 0xFFFFFFFFFFFFFFF8
	internal object ntextures; // 0x0
	internal object ctextures; // 0x4
	internal object textureId; // 0x8
	internal object fragSize; // 0xC
	internal object flags; // 0x10
	internal object calls; // 0x18
	internal object ccalls; // 0x20
	internal object ncalls; // 0x24
	internal object paths; // 0x28
	internal object cpaths; // 0x30
	internal object npaths; // 0x34
	internal object verts; // 0x38
	internal object cverts; // 0x40
	internal object nverts; // 0x44
	internal object uniforms; // 0x48
	internal object cuniforms; // 0x50
	internal object nuniforms; // 0x54
	internal object cache; // 0x58
	internal object flushCb; // 0x60
	internal object textCreateCb; // 0x68
	internal object textUpdateCb; // 0x70
	internal object textDeleteCb; // 0x78
	internal object textGetSizeCb; // 0x80
}

// Namespace: com.pixui
public class UnityNVGcontext
{
}

// Namespace: com.pixui
public static class PxDlls
{

	// Fields
	public static object isInited; // 0x0

	// Methods

	// RVA: 0x3D31670
	public static extern object GetVersion() { }

	// RVA: 0x3D31674
	public static extern object DispatchCallback(object loaderId, object callbackId, object errCode, object buf) { }

	// RVA: 0x3D31678
	public static extern object GetUserAgent() { }

	// RVA: 0x3D3167C
	public static extern object InitPlugin(object callbacks, object writeablePath) { }

	// RVA: 0x3D31718
	public static extern object ShutdownPlugin() { }

	// RVA: 0x3D22554
	public static extern object TickPlugin(object delta) { }

	// RVA: 0x3D22550
	public static extern object FrameStart() { }

	// RVA: 0x3D3171C
	public static extern object BeginProfile(object name) { }

	// RVA: 0x3D31744
	public static extern object EndProfile() { }

	// RVA: 0x3D31748
	public static extern object SetHttpCacheEnable(object enableHttpCache) { }

	// RVA: 0x3D27F20
	public static extern object CreateWindow(object windowId) { }

	// RVA: 0x3D29060
	public static extern object DestroyWindow(object windowPtr) { }

	// RVA: 0x3D3174C
	public static extern object SendMessage(object windowPtr, object msg) { }

	// RVA: 0x3D31784
	public static extern object OnRpcMessage(object windowPtr, object msg) { }

	// RVA: 0x3D317BC
	public static extern object OnPandoraMessage(object windowPtr, object msg) { }

	// RVA: 0x3D317F4
	public static extern object OnPandoraData(object windowPtr, object msg, object len) { }

	// RVA: 0x3D3183C
	public static extern object SetScreenSize(object windowPtr, object screenWidth, object screenHeight) { }

	// RVA: 0x3D27F70
	public static extern object SetResolution(object windowPtr, object winWidth, object winHeight) { }

	// RVA: 0x3D29648
	public static extern object UpdateResolution(object windowPtr, object winWidth, object winHeight) { }

	// RVA: 0x3D31840
	public static extern object UpdateMemory(object windowPtr) { }

	// RVA: 0x3D29390
	public static extern object LoadPageFromData(object windowPtr, object pData, object nDataSize, object baseUrl) { }

	// RVA: 0x3D29438
	public static extern object LoadUrl(object windowPtr, object url) { }

	// RVA: 0x3D27F6C
	public static extern object GetWindowInfo(object windowPtr) { }

	// RVA: 0x3D29AD4
	public static extern object PaintWindow(object windowPtr) { }

	// RVA: 0x3D31844
	public static extern object GetWindowVM(object windowPtr, object vmPtr) { }

	// RVA: 0x3D31860
	public static extern object UpdateWindow(object windowPtr, object deltaTime) { }

	// RVA: 0x3D29C28
	public static extern object OnKeyBoardInput(object windowPtr, object text, object isEnd, object bLostFocus, object bReplace) { }

	// RVA: 0x3D29D50
	public static extern object OnKeyEvent(object windowPtr, object emKey, object modifiers, object bDown) { }

	// RVA: 0x3D31864
	public static extern object CreateScriptGlobal(object windowPtr, object name) { }

	// RVA: 0x3D3189C
	public static extern object SetScriptGlobalNumber(object windowPtr, object name, object key, object num) { }

	// RVA: 0x3D31908
	public static extern object SetScriptGlobalString(object windowPtr, object name, object key, object str) { }

	// RVA: 0x3D31980
	public static extern object SetScriptGlobalBoolean(object windowPtr, object name, object key, object v) { }

	// RVA: 0x3D319E4
	public static extern object GetScriptGlobalNumber(object windowPtr, object name, object key) { }

	// RVA: 0x3D31A54
	public static extern object GetScriptGlobalString(object windowPtr, object name, object key) { }

	// RVA: 0x3D31ABC
	public static extern object GetScriptGlobalBoolean(object windowPtr, object name, object key) { }

	// RVA: 0x3D31B28
	public static extern object ConfirmExternalImage(object windowId, object url, object textureId, object valid) { }

	// RVA: 0x3D31B78
	public static extern object UseSourceMap(object useSourceMap) { }

	// RVA: 0x3D225DC
	public static extern object EnterBackground() { }

	// RVA: 0x3D225E0
	public static extern object EnterForeground() { }

	// RVA: 0x3D31B7C
	public static extern object InitVG(object flushCb, object createTextureCb, object updateTextureCb, object deleteTexrtureCb, object getTextureSizeCb, object getTextGlyphCb) { }

	// RVA: 0x3D25D98
	public static extern object Repaint(object windowPtr) { }

	// RVA: 0x3D31B80
	public static extern object DoBuffer(object windowPtr, object buf, object len, object name, object isModule) { }

	// RVA: 0x3D31BE0
	public static extern object GetAttachmentHandleById(object windowPtr, object id) { }

	// RVA: 0x3D31C24
	public static extern object LoadFile(object filePath, object buf) { }

	// RVA: 0x3D31C64
	public static extern object UnloadFile(object buf) { }

	// RVA: 0x3D31C80
	public static extern object InvalidateFontCharCache(object windowPtr) { }

	// RVA: 0x3D24DD8
	public static extern object OnSlotAttachmentMounted(object windowPtr, object handle, object success) { }

	// RVA: 0x3D27F24
	public static extern object SetDefaultFont(object windowPtr, object fontName, object fontSize) { }

	// RVA: 0x3D31C9C
	public static extern object InitVideoDelegate(object fileOpen, object fileClose, object fileRead, object fileSeek) { }

	// RVA: 0x3D29E40
	public static extern object OnTouchEvent(object windowPtr, object nXpos, object nYpos, object nTouchPoint, object emTouchPhase) { }

	// RVA: 0x3D29DDC
	public static extern object OnMouseEvent(object windowPtr, object nXpos, object nYpos, object nZpos, object nWpos, object emBtnEvent, object bDown) { }

	// RVA: 0x3D31CA0
	public static extern object OnGamepadEvent(object windowPtr, object emKey, object nIndex, object fAxis, object bDown) { }

	// RVA: 0x3D31CBC
	public static extern object OnGamepadConnected(object index, object name) { }

	// RVA: 0x3D31CF4
	public static extern object OnGamepadDisconnected(object index) { }

	// RVA: 0x3D31CF8
	public static extern object WaitForSocketsCloseDone(object timeoutMS, object callbackId) { }

}

// Namespace: com.pixui
public struct BorderMaterialLabel
{

	// Fields
	public object size; // 0xFFFFFFFFFFFFFFF8
	public object radiusLT; // 0x0
	public object radiusRT; // 0x8
	public object radiusLB; // 0x10
	public object radiusRB; // 0x18
	public object edgeL; // 0x20
	public object edgeT; // 0x38
	public object edgeR; // 0x50
	public object edgeB; // 0x68

	// Methods

	// RVA: 0x3D31CFC
	public object .ctor(object size, object radiusLT, object radiusRT, object radiusLB, object radiusRB, object edgeL, object edgeT, object edgeR, object edgeB) { }

	// RVA: 0x3D322E4
	public object Equals(object other) { }

	// RVA: 0x3D32618
	public override object GetHashCode() { }

	// RVA: 0x3D32A74
	public object SyncToMaterial(object mat) { }

	// RVA: 0x3D32B50
	public object CreateMaterial() { }

}

// Namespace: com.pixui
public struct BoxShadowMaterialLabel
{

	// Fields
	public object size; // 0xFFFFFFFFFFFFFFF8
	public object radiusLT; // 0x0
	public object radiusRT; // 0x8
	public object radiusRB; // 0x10
	public object radiusLB; // 0x18
	public object blur; // 0x20

	// Methods

	// RVA: 0x3D32BE0
	public object .ctor(object size, object radiusLT, object radiusRT, object radiusRB, object radiusLB, object blur) { }

	// RVA: 0x3D32C28
	public object SyncToMaterial(object mat) { }

	// RVA: 0x3D32D30
	public object CreateMaterial() { }

	// RVA: 0x3D32DC0
	public object Equals(object other) { }

	// RVA: 0x3D32F48
	public override object GetHashCode() { }

}

// Namespace: com.pixui
public interface IPxGraphicCustomMaterialProvider
{

	// Methods

	// RVA: -1
	public abstract object UpdateMaterial() { }

	// RVA: -1
	public abstract object GetModifiedMaterial(object mat) { }

}

// Namespace: com.pixui
public abstract class PxGraphicCustomMaterialProvider<T0>
{

	// Fields
	protected object m_FirstRequest; // 0x0
	protected object m_LastMaterialLabel; // 0x0

	// Methods

	// RVA: -1
	protected abstract object GetMaterialLabel() { }

	// RVA: -1
	public object UpdateMaterial() { }

	// RVA: -1
	public object GetModifiedMaterial(object mat) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	protected object .ctor() { }

}

// Namespace: 
protected class MaterialProvider
{

	// Fields
	protected readonly object m_Host; // 0x60

	// Methods

	// RVA: 0x3D3310C
	public object .ctor(object host) { }

	// RVA: 0x3D33C08
	protected override object GetMaterialLabel() { }

}

// Namespace: com.pixui
public class PxBackgroundImage
{

	// Fields
	private object m_RadiusLT; // 0xD8
	private object m_RadiusRT; // 0xE0
	private object m_RadiusLB; // 0xE8
	private object m_RadiusRB; // 0xF0
	protected object m_Texture; // 0xF8
	protected object m_SrcRect; // 0x100
	protected object m_SpriteRect; // 0x110
	private object m_RepeatX; // 0x120
	private object m_RepeatY; // 0x121
	private object m_AlreadyPremuliplyAlpha; // 0x122
	private object m_MaterialProvider; // 0x128

	// Properties
	public override object customMaterialProivder { get; }
	public object radiusLT { get; set; }
	public object radiusRT { get; set; }
	public object radiusLB { get; set; }
	public object radiusRB { get; set; }
	public object repeatX { get; set; }
	public object repeatY { get; set; }
	public object alreadyPremuliplyAlpha { get; set; }
	public object spriteRect { get; set; }
	public object texture { get; set; }
	public object srcRect { get; set; }
	public override object mainTexture { get; }

	// Methods

	// RVA: 0x3D33050
	public override object get_customMaterialProivder() { }

	// RVA: 0x3D3316C
	public object get_radiusLT() { }

	// RVA: 0x3D33174
	public object set_radiusLT(object value) { }

	// RVA: 0x3D332A4
	public object get_radiusRT() { }

	// RVA: 0x3D332AC
	public object set_radiusRT(object value) { }

	// RVA: 0x3D3336C
	public object get_radiusLB() { }

	// RVA: 0x3D33374
	public object set_radiusLB(object value) { }

	// RVA: 0x3D33434
	public object get_radiusRB() { }

	// RVA: 0x3D3343C
	public object set_radiusRB(object value) { }

	// RVA: 0x3D334FC
	public object get_repeatX() { }

	// RVA: 0x3D33504
	public object set_repeatX(object value) { }

	// RVA: 0x3D3355C
	public object get_repeatY() { }

	// RVA: 0x3D33564
	public object set_repeatY(object value) { }

	// RVA: 0x3D335BC
	public object get_alreadyPremuliplyAlpha() { }

	// RVA: 0x3D335C4
	public object set_alreadyPremuliplyAlpha(object value) { }

	// RVA: 0x3D3361C
	public object get_spriteRect() { }

	// RVA: 0x3D33630
	public object set_spriteRect(object value) { }

	// RVA: 0x3D336B0
	public object get_texture() { }

	// RVA: 0x3D336B8
	public object set_texture(object value) { }

	// RVA: 0x3D3378C
	public object get_srcRect() { }

	// RVA: 0x3D337A0
	public object set_srcRect(object value) { }

	// RVA: 0x3D33820
	public override object get_mainTexture() { }

	// RVA: 0x3D33954
	public object .ctor() { }

	// RVA: 0x3D33234
	private object ClampRadius(object value) { }

	// RVA: 0x3D339BC
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x3D33B58
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x3D33BC0
	protected object hasRadius(object radiusLT, object radiusRT, object radiusLB, object radiusRB) { }

}

// Namespace: 
public enum BorderStyle
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object border_style_none;
	public const object border_style_hidden;
	public const object border_style_dotted;
	public const object border_style_dashed;
	public const object border_style_solid;
	public const object border_style_double;
	public const object border_style_groove;
	public const object border_style_ridge;
	public const object border_style_inset;
	public const object border_style_outset;
}

// Namespace: 
public struct Edge
{

	// Fields
	public object color; // 0xFFFFFFFFFFFFFFF8
	public object style; // 0x8
	public object width; // 0xC
	public static readonly object Default; // 0x0

	// Properties
	public object compuatedWidth { get; }

	// Methods

	// RVA: 0x3D34A08
	public object get_compuatedWidth() { }

	// RVA: 0x3D34A38
	public override object Equals(object o) { }

	// RVA: 0x3D32518
	public object Equals(object other) { }

	// RVA: 0x3D329A4
	public override object GetHashCode() { }

	// RVA: 0x3D34CF4
	private static object .cctor() { }

}

// Namespace: com.pixui
public abstract class PxBorder
{

	// Fields
	protected object m_RadiusLT; // 0xD8
	protected object m_RadiusRT; // 0xE0
	protected object m_RadiusLB; // 0xE8
	protected object m_RadiusRB; // 0xF0
	protected object m_EdgeL; // 0xF8
	protected object m_EdgeT; // 0x110
	protected object m_EdgeR; // 0x128
	protected object m_EdgeB; // 0x140
	private object m_LastHash; // 0x158
	private object m_Hash; // 0x15C
	private object m_HashInvalidate; // 0x160

	// Properties
	public object radiusLT { get; set; }
	public object radiusRT { get; set; }
	public object radiusLB { get; set; }
	public object radiusRB { get; set; }
	public object edgeL { get; set; }
	public object edgeT { get; set; }
	public object edgeR { get; set; }
	public object edgeB { get; set; }

	// Methods

	// RVA: 0x3D33D30
	public object get_radiusLT() { }

	// RVA: 0x3D33D38
	public object set_radiusLT(object value) { }

	// RVA: 0x3D33E1C
	public object get_radiusRT() { }

	// RVA: 0x3D33E24
	public object set_radiusRT(object value) { }

	// RVA: 0x3D33EA4
	public object get_radiusLB() { }

	// RVA: 0x3D33EAC
	public object set_radiusLB(object value) { }

	// RVA: 0x3D33F2C
	public object get_radiusRB() { }

	// RVA: 0x3D33F34
	public object set_radiusRB(object value) { }

	// RVA: 0x3D33FB4
	public object get_edgeL() { }

	// RVA: 0x3D33FC8
	public object set_edgeL(object value) { }

	// RVA: 0x3D3421C
	public object get_edgeT() { }

	// RVA: 0x3D34230
	public object set_edgeT(object value) { }

	// RVA: 0x3D343B4
	public object get_edgeR() { }

	// RVA: 0x3D343CC
	public object set_edgeR(object value) { }

	// RVA: 0x3D34550
	public object get_edgeB() { }

	// RVA: 0x3D34564
	public object set_edgeB(object value) { }

	// RVA: 0x3D346E8
	public object .ctor() { }

	// RVA: 0x3D347B8
	protected override object Start() { }

	// RVA: 0x3D3414C
	private object ClampEdge(object value, object axis) { }

	// RVA: 0x3D33DB8
	private object ClampRadius(object value) { }

	// RVA: 0x3D347E8
	private object UpdateHash() { }

	// RVA: 0x3D34940
	private object Update() { }

	// RVA: 0x3D33E10
	private object Invalidete() { }

	// RVA: 0x3D349D0
	protected override object OnRectTransformDimensionsChange() { }

	// RVA: 0x3D349DC
	protected override object OnEnable() { }

}

// Namespace: com.pixui
public class PxBorderGEO
{

	// Properties
	private object edgeExtend { get; }
	private object tolerance { get; }

	// Methods

	// RVA: 0x3D34D54
	private object get_edgeExtend() { }

	// RVA: 0x3D34E84
	private object get_tolerance() { }

	// RVA: 0x3D34FB4
	private static object PopulateBorder(object vh, object width, object edgeL, object edge, object edgeR, object radiusL, object radiusR, object tolerance, object extendWidth, object matrix) { }

	// RVA: 0x3D36064
	private static object TransposeXY(object radius) { }

	// RVA: 0x3D36074
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x3D36628
	public object .ctor() { }

}

// Namespace: 
private class MaterialProvider
{

	// Fields
	private readonly object m_Host; // 0x98

	// Methods

	// RVA: 0x3D367B4
	public object .ctor(object host) { }

	// RVA: 0x3D36AB4
	protected override object GetMaterialLabel() { }

}

// Namespace: com.pixui
public class PxBorderGPU
{

	// Fields
	private object m_MaterialProvider; // 0x168

	// Properties
	public override object customMaterialProivder { get; }

	// Methods

	// RVA: 0x3D366F8
	public override object get_customMaterialProivder() { }

	// RVA: 0x3D36814
	protected override object OnEnable() { }

	// RVA: 0x3D36864
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x3D369E4
	public object .ctor() { }

}

// Namespace: 
protected class MaterialProvider
{

	// Fields
	protected readonly object m_Host; // 0x38

	// Methods

	// RVA: 0x3D36C60
	public object .ctor(object host) { }

	// RVA: 0x3D37104
	protected override object GetMaterialLabel() { }

}

// Namespace: com.pixui
public class PxBoxShadow
{

	// Fields
	protected object m_RadiusLT; // 0xD8
	protected object m_RadiusRT; // 0xE0
	protected object m_RadiusLB; // 0xE8
	protected object m_RadiusRB; // 0xF0
	private object m_Blur; // 0xF8
	private object m_MaterialProvider; // 0x100

	// Properties
	public override object customMaterialProivder { get; }
	public object radiusLT { get; set; }
	public object radiusRT { get; set; }
	public object radiusLB { get; set; }
	public object radiusRB { get; set; }
	public object blur { get; set; }

	// Methods

	// RVA: 0x3D36BA4
	public override object get_customMaterialProivder() { }

	// RVA: 0x3D36CC0
	public object get_radiusLT() { }

	// RVA: 0x3D36CC8
	public object set_radiusLT(object value) { }

	// RVA: 0x3D36D2C
	public object get_radiusRT() { }

	// RVA: 0x3D36D34
	public object set_radiusRT(object value) { }

	// RVA: 0x3D36D98
	public object get_radiusLB() { }

	// RVA: 0x3D36DA0
	public object set_radiusLB(object value) { }

	// RVA: 0x3D36E04
	public object get_radiusRB() { }

	// RVA: 0x3D36E0C
	public object set_radiusRB(object value) { }

	// RVA: 0x3D36E70
	public object get_blur() { }

	// RVA: 0x3D36E78
	public object set_blur(object value) { }

	// RVA: 0x3D36EE8
	public object .ctor() { }

	// RVA: 0x3D36F1C
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x3D3709C
	protected override object OnRectTransformDimensionsChange() { }

}

// Namespace: com.pixui
public abstract class PxCustomGraphic
{

	// Fields
	protected object m_CustomMaterial; // 0xD0
	private static object s_UIDefaultMaterial; // 0x0

	// Properties
	public override object material { get; set; }
	public virtual object customMaterialProivder { get; }
	public override object defaultMaterial { get; }

	// Methods

	// RVA: 0x3D37170
	public override object set_material(object value) { }

	// RVA: 0x3D371B8
	public override object get_material() { }

	// RVA: 0x3D372D8
	public virtual object get_customMaterialProivder() { }

	// RVA: 0x3D33994
	public object .ctor() { }

	// RVA: 0x3D372E0
	public override object get_defaultMaterial() { }

	// RVA: 0x3D37598
	public override object GetModifiedMaterial(object baseMaterial) { }

	// RVA: 0x3D37740
	protected override object UpdateMaterial() { }

	// RVA: 0x3D37870
	protected override object OnDestroy() { }

	// RVA: 0x3D379C0
	public override object SetClipRect(object clipRect, object validRect) { }

}

// Namespace: com.pixui
public class PxFlipEffect
{

	// Fields
	private object m_Vert; // 0x20
	private object m_Hori; // 0x21

	// Properties
	public object vert { get; set; }
	public object hori { get; set; }

	// Methods

	// RVA: 0x3D37B34
	public object get_vert() { }

	// RVA: 0x3D37B3C
	public object set_vert(object value) { }

	// RVA: 0x3D37C3C
	public object get_hori() { }

	// RVA: 0x3D37C44
	public object set_hori(object value) { }

	// RVA: 0x3D37D44
	public override object ModifyMesh(object vh) { }

	// RVA: 0x3D38044
	public object .ctor() { }

}

// Namespace: com.pixui
public class PxImage
{

	// Methods

	// RVA: 0x3D3804C
	public object .ctor() { }

}

// Namespace: com.pixui
public class PxImageMask
{

	// Fields
	private object m_MaskTexture; // 0x88

	// Properties
	public object maskTexture { get; set; }

	// Methods

	// RVA: 0x3D380D4
	public object get_maskTexture() { }

	// RVA: 0x3D380DC
	public object set_maskTexture(object value) { }

	// RVA: 0x3D38194
	public object .ctor() { }

}

// Namespace: com.pixui
public class PxLine
{

	// Fields
	private object m_BeginPoint; // 0xD8
	private object m_EndPoint; // 0xE0
	private object m_Width; // 0xE8

	// Properties
	public object beginPoint { get; set; }
	public object endPoint { get; set; }
	public object width { get; set; }

	// Methods

	// RVA: 0x3D3819C
	public object get_beginPoint() { }

	// RVA: 0x3D381A4
	public object set_beginPoint(object value) { }

	// RVA: 0x3D381AC
	public object get_endPoint() { }

	// RVA: 0x3D381B4
	public object set_endPoint(object value) { }

	// RVA: 0x3D381BC
	public object get_width() { }

	// RVA: 0x3D381C4
	public object set_width(object value) { }

	// RVA: 0x3D381CC
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x3D384B4
	public object .ctor() { }

}

// Namespace: 
public enum Direction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ToRight;
	public const object ToLeft;
	public const object ToTop;
	public const object ToBottom;
}

// Namespace: com.pixui
public class PxLinearGradientEffect
{

	// Fields
	private object m_Gradient; // 0x20
	private object m_Direction; // 0x28
	private object m_uvRect; // 0x2C
	private object m_Color; // 0x3C
	private object m_Keyframes; // 0x50

	// Properties
	public object direction { get; set; }
	public object gradient { get; set; }
	public object uvRect { get; set; }
	public object color { get; set; }

	// Methods

	// RVA: 0x3D384DC
	public object get_direction() { }

	// RVA: 0x3D384E4
	public object set_direction(object value) { }

	// RVA: 0x3D38930
	public object get_gradient() { }

	// RVA: 0x3D38938
	public object set_gradient(object value) { }

	// RVA: 0x3D38A40
	public object get_uvRect() { }

	// RVA: 0x3D38A4C
	public object set_uvRect(object value) { }

	// RVA: 0x3D38B80
	public object get_color() { }

	// RVA: 0x3D38B8C
	public object set_color(object value) { }

	// RVA: 0x3D385EC
	private object CalcKeyframes() { }

	// RVA: 0x3D38CE4
	public override object ModifyMesh(object vh) { }

	// RVA: 0x3D39934
	public object .ctor() { }

}

// Namespace: com.pixui
public interface IMaterialPoolLabel
{

	// Methods

	// RVA: -1
	public abstract object SyncToMaterial(object mat) { }

	// RVA: -1
	public abstract object CreateMaterial() { }

}

// Namespace: com.pixui
public class MaterialPoolEntry
{

	// Fields
	public object material; // 0x8
	public object refCount; // 0x10

	// Methods

	// RVA: 0x3D39950
	public object .ctor() { }

}

// Namespace: com.pixui
public class MaterialPoolLabelAttribute
{

	// Fields
	private object <name>k__BackingField; // 0x8

	// Properties
	public object name { get; set; }

	// Methods

	// RVA: 0x3D39958
	public object get_name() { }

	// RVA: 0x3D39960
	private object set_name(object value) { }

	// RVA: 0x3D39968
	public object .ctor(object name) { }

}

// Namespace: com.pixui
public interface IMaterialPool
{

	// Properties
	public abstract object entries { get; }

	// Methods

	// RVA: -1
	public abstract object get_entries() { }

}

// Namespace: com.pixui
public class MaterialPool<T0>
{

	// Fields
	private object m_LabelId; // 0x0
	private object m_Materials; // 0x0
	private object m_Disposed; // 0x0
	private object m_Name; // 0x0

	// Properties
	public object name { get; }
	public object entries { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object get_name() { }

	// RVA: -1
	private object CreateMaterial(object key) { }

	// RVA: -1
	public object Request(object key) { }

	// RVA: -1
	public object Migrate(object oldKey, object newKey) { }

	// RVA: -1
	public object Return(object key) { }

	// RVA: -1
	public object Dispose() { }

	// RVA: -1
	private object OnDispose() { }

	// RVA: -1
	public object get_entries() { }

}

// Namespace: 
protected class MaterialProvider
{

	// Fields
	protected readonly object m_Host; // 0x60

	// Methods

	// RVA: 0x3D39A50
	public object .ctor(object host) { }

	// RVA: 0x3D3E120
	protected override object GetMaterialLabel() { }

}

// Namespace: 
public enum RepeatMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Stretch;
	public const object Repeat;
	public const object Round;
}

// Namespace: com.pixui
public class PxSlicedImage
{

	// Fields
	protected object m_Texture; // 0xD8
	private object m_SrcRect; // 0xE0
	private object m_SpriteRect; // 0xF0
	private object m_Border; // 0x100
	private object m_BorderWidth; // 0x110
	private object m_RepeatMode; // 0x120
	private object m_FillCenter; // 0x124
	private object m_PremultipliedAlpha; // 0x125
	private object m_MaterialProvider; // 0x128
	private static object s_VertScratch; // 0x0
	private static object s_UVScratch; // 0x8

	// Properties
	public override object customMaterialProivder { get; }
	public virtual object texture { get; set; }
	public object srcRect { get; set; }
	public object spriteRect { get; set; }
	public object border { get; set; }
	public object borderWidth { get; set; }
	public object repeatMode { get; set; }
	public object fillCenter { get; set; }
	public override object mainTexture { get; }
	public object premultipiedAlpha { get; set; }
	private object hasBorder { get; }
	private object outerUVRect { get; }
	private object innerUVRect { get; }

	// Methods

	// RVA: 0x3D39994
	public override object get_customMaterialProivder() { }

	// RVA: 0x3D39AB0
	public virtual object get_texture() { }

	// RVA: 0x3D39AB8
	public virtual object set_texture(object value) { }

	// RVA: 0x3D39B8C
	public object get_srcRect() { }

	// RVA: 0x3D39B98
	public object set_srcRect(object value) { }

	// RVA: 0x3D39C10
	public object get_spriteRect() { }

	// RVA: 0x3D39C1C
	public object set_spriteRect(object value) { }

	// RVA: 0x3D39C94
	public object get_border() { }

	// RVA: 0x3D39CA8
	public object set_border(object value) { }

	// RVA: 0x3D39D50
	public object get_borderWidth() { }

	// RVA: 0x3D39D64
	public object set_borderWidth(object value) { }

	// RVA: 0x3D39E0C
	public object get_repeatMode() { }

	// RVA: 0x3D39E14
	public object set_repeatMode(object value) { }

	// RVA: 0x3D39E6C
	public object get_fillCenter() { }

	// RVA: 0x3D39E74
	public object set_fillCenter(object value) { }

	// RVA: 0x3D39ECC
	public override object get_mainTexture() { }

	// RVA: 0x3D39FC0
	public object get_premultipiedAlpha() { }

	// RVA: 0x3D39FC8
	public object set_premultipiedAlpha(object value) { }

	// RVA: 0x3D3A020
	public object .ctor() { }

	// RVA: 0x3D3A064
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x3D3C978
	private object get_hasBorder() { }

	// RVA: 0x3D3CAB4
	private object get_outerUVRect() { }

	// RVA: 0x3D3CAC8
	private object get_innerUVRect() { }

	// RVA: 0x3D3CD8C
	protected virtual object AddQuad(object vertexHelper, object posMin, object posMax, object color, object uvMin, object uvMax) { }

	// RVA: 0x3D3A110
	private object GenerateSlicedSprite(object toFill) { }

	// RVA: 0x3D3BF38
	private object GenerateRoundSprite(object toFill) { }

	// RVA: 0x3D3A70C
	private object GenerateRepeatSprite(object toFill) { }

	// RVA: 0x3D3CEF4
	private object GenerateTiledSprite(object toFill) { }

	// RVA: 0x3D3DF14
	public override object SetNativeSize() { }

	// RVA: 0x3D3E094
	private static object .cctor() { }

}

// Namespace: 
private class Utf8Buffer
{

	// Fields
	private object _ptr; // 0x8
	private object _index; // 0x10
	private object _capacity; // 0x14

	// Properties
	public object ptr { get; }
	public object size { get; }
	public object isEmpty { get; }

	// Methods

	// RVA: 0x3D410B0
	public object get_ptr() { }

	// RVA: 0x3D410B8
	public object get_size() { }

	// RVA: 0x3D40C58
	public object get_isEmpty() { }

	// RVA: 0x3D3E908
	public object Realloc(object newCapacity) { }

	// RVA: 0x3D40CA4
	public object Free() { }

	// RVA: 0x3D3ED58
	public object Write(object str) { }

	// RVA: 0x3D3EA00
	public object Write(object src, object size) { }

	// RVA: 0x3D410CC
	private static object ZeroCheck(object lhs, object rhs, object ret) { }

	// RVA: 0x3D3ECAC
	public object Equals(object other) { }

	// RVA: 0x3D410C0
	private static object MemoryCopy(object dst, object src, object size) { }

	// RVA: 0x3D411BC
	private static object MemoryCompare(object src, object dst, object size) { }

	// RVA: 0x3D3E750
	public object .ctor() { }

}

// Namespace: 
private static class FontUpdateTracker
{

	// Fields
	private static object s_Tracked; // 0x0

	// Methods

	// RVA: 0x3D3F1B0
	public static object Track(object t) { }

	// RVA: 0x3D411E0
	private static object RebuildForFont(object f) { }

	// RVA: 0x3D3EF68
	public static object Untrack(object t) { }

	// RVA: 0x3D4135C
	private static object .cctor() { }

}

// Namespace: com.pixui
public sealed class PxText
{

	// Fields
	private object m_DisplayUtf8; // 0xD8
	private object m_Font; // 0xE0
	private object m_FontSize; // 0xE8
	private object m_FontStyle; // 0xEC
	private object m_Alignment; // 0xF0
	private object m_Spacing; // 0xF4
	private object m_DisableFontTextureRebuiltCallback; // 0xF8
	private object m_TextGenerator; // 0x100

	// Properties
	public object font { get; set; }
	public object fontStyle { get; set; }
	public object fontSize { get; set; }
	public object alignment { get; set; }
	public object spacing { get; set; }
	public override object mainTexture { get; }
	private object pixelsPerUnit { get; }
	public override object defaultMaterial { get; }

	// Methods

	// RVA: 0x3D3E6A0
	public object .ctor() { }

	// RVA: 0x3D3E75C
	public object SetText(object csStr) { }

	// RVA: 0x3D3EAF4
	public object SetText(object nativeStr) { }

	// RVA: 0x3D3ED9C
	protected override object OnDestroy() { }

	// RVA: 0x3D3EE58
	public object get_font() { }

	// RVA: 0x3D3EE60
	public object set_font(object value) { }

	// RVA: 0x3D3F434
	public object get_fontStyle() { }

	// RVA: 0x3D3F43C
	public object set_fontStyle(object value) { }

	// RVA: 0x3D3F494
	public object get_fontSize() { }

	// RVA: 0x3D3F49C
	public object set_fontSize(object value) { }

	// RVA: 0x3D3F4F4
	public object get_alignment() { }

	// RVA: 0x3D3F4FC
	public object set_alignment(object value) { }

	// RVA: 0x3D3F510
	public object get_spacing() { }

	// RVA: 0x3D3F518
	public object set_spacing(object value) { }

	// RVA: 0x3D3F570
	public object GetText() { }

	// RVA: 0x3D3F840
	public override object get_mainTexture() { }

	// RVA: 0x3D3FAA4
	private object get_pixelsPerUnit() { }

	// RVA: 0x3D3FB80
	private object GetCharacterInfo(object ch, object fontSize, object bakeChatacter, object info) { }

	// RVA: 0x3D3FCC0
	protected override object OnPopulateMesh(object vh) { }

	// RVA: 0x3D3EA44
	public object Clear() { }

	// RVA: 0x3D40D44
	protected override object OnEnable() { }

	// RVA: 0x3D40DDC
	protected override object OnDisable() { }

	// RVA: 0x3D40E48
	protected override object UpdateGeometry() { }

	// RVA: 0x3D40EF8
	public object FontTextureChanged() { }

	// RVA: 0x3D410A8
	public override object get_defaultMaterial() { }

}

// Namespace: 
public struct CurveScope
{

	// Fields
	private object vh; // 0xFFFFFFFFFFFFFFF8
	private object <index>k__BackingField; // 0x0
	private object <count>k__BackingField; // 0x4

	// Properties
	public object index { get; set; }
	public object count { get; set; }

	// Methods

	// RVA: 0x3D4218C
	public object get_index() { }

	// RVA: 0x3D4219C
	private object set_index(object value) { }

	// RVA: 0x3D421AC
	public object get_count() { }

	// RVA: 0x3D421BC
	private object set_count(object value) { }

	// RVA: 0x3D41C2C
	public object .ctor(object vh) { }

	// RVA: 0x3D4210C
	public object End() { }

	// RVA: 0x3D42250
	public object Quad() { }

	// RVA: 0x3D41B24
	public object Close(object otherScope) { }

}

// Namespace: com.pixui
public static class VG
{

	// Methods

	// RVA: 0x3D413EC
	public static object Ellipse(object ab, object x) { }

	// RVA: 0x3D41454
	public static object Ellipse(object center, object ab, object x) { }

	// RVA: 0x3D414C0
	public static object FindArcSplitPoint(object center, object ab, object splitLine0, object splitLine1) { }

	// RVA: 0x3D415D8
	public static object PopulateArcStroke(object vh, object center, object radius, object x0, object x2, object innerColor, object outerColor, object tolerance, object stroke, object outterUV, object innerUV) { }

	// RVA: 0x3D419F0
	public static object PopulateArc(object vh, object center, object radius, object x0, object x2, object color, object tolerance, object uv, object fallbackPoint) { }

	// RVA: 0x3D41C6C
	public static object TessellateArc(object vh, object center, object radius, object x0, object x2, object color, object tolerance, object uv) { }

}

// Namespace: com.pixui
public struct UIDefaultMaterialLabel
{

	// Fields
	public object mainTexture; // 0xFFFFFFFFFFFFFFF8
	public object uvOffset; // 0x0
	public object uvScale; // 0x8
	public object spriteOffset; // 0x10
	public object spriteScale; // 0x18
	public object radiusLT; // 0x20
	public object radiusRT; // 0x28
	public object radiusLB; // 0x30
	public object radiusRB; // 0x38
	public object repeatX; // 0x40
	public object repeatY; // 0x41
	public object alreadyPremuliplyAlpha; // 0x42

	// Properties
	public object mainTextureId { get; }

	// Methods

	// RVA: 0x3D4232C
	public object get_mainTextureId() { }

	// RVA: 0x3D3E294
	public object .ctor(object size, object texture, object uvOffset, object uvScale, object spriteOffset, object spriteScale, object radiusLT, object radiusRT, object radiusLB, object radiusRB, object repeatX, object repeatY, object alreadyPremuliplyAlpha) { }

	// RVA: 0x3D42374
	public object SyncToMaterial(object mat) { }

	// RVA: 0x3D4252C
	public object CreateMaterial() { }

	// RVA: 0x3D425BC
	public object Equals(object other) { }

	// RVA: 0x3D42798
	public override object GetHashCode() { }

}

// Namespace: com.pixui
public class BackgroundImageUI
{

	// Fields
	protected object m_Image; // 0x78
	protected object m_FlipEffect; // 0x80

	// Methods

	// RVA: 0x3D429E0
	protected override object Awake() { }

	// RVA: 0x3D42BB4
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D42C5C
	public object SetColor(object color) { }

	// RVA: 0x3D434F8
	private static object NeedToUseRepeatWrapMode(object srcRect) { }

	// RVA: 0x3D42D24
	public object SetAsset(object asset, object srcUVRegion) { }

	// RVA: 0x3D4353C
	public object .ctor() { }

}

// Namespace: com.pixui
public class BorderImageUI
{

	// Fields
	protected object m_Image; // 0x78
	protected object m_FlipEffect; // 0x80

	// Methods

	// RVA: 0x3D435E0
	protected override object Awake() { }

	// RVA: 0x3D439C4
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D43A90
	public object SetColor(object color) { }

	// RVA: 0x3D445A4
	private static object NeedToUseRepeatWrapMode(object srcRect) { }

	// RVA: 0x3D43B78
	public object SetAsset(object asset, object slice, object widths, object srcUVRegion) { }

	// RVA: 0x3D445E8
	public override object OnActive() { }

	// RVA: 0x3D445F0
	public override object OnDeactive() { }

	// RVA: 0x3D445F8
	public object .ctor() { }

}

// Namespace: com.pixui
public class BorderUI
{

	// Fields
	protected object m_Border; // 0x78

	// Methods

	// RVA: 0x3D4469C
	protected override object Awake() { }

	// RVA: 0x3D44848
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D448F8
	private object SetBorder(object border, object radiuses, object width, object height) { }

	// RVA: 0x3D44C5C
	public override object OnActive() { }

	// RVA: 0x3D44D1C
	public override object OnDeactive() { }

	// RVA: 0x3D44DDC
	public object .ctor() { }

}

// Namespace: com.pixui
public class BoxShadowUI
{

	// Fields
	protected object m_BoxShadow; // 0x78
	private object m_FlipEffect; // 0x80

	// Methods

	// RVA: 0x3D44E80
	protected override object Awake() { }

	// RVA: 0x3D4506C
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D45124
	public object SetColor(object color) { }

	// RVA: 0x3D45238
	public object SetShape(object radius, object blur) { }

	// RVA: 0x3D45380
	public override object OnActive() { }

	// RVA: 0x3D453C0
	public override object OnDeactive() { }

	// RVA: 0x3D45400
	public object .ctor() { }

}

// Namespace: com.pixui
public class ClipUI
{

	// Fields
	protected object m_Image; // 0x78
	protected object m_Mask; // 0x80

	// Methods

	// RVA: 0x3D454A4
	protected override object Awake() { }

	// RVA: 0x3D45720
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D457C0
	private object SetMask(object mat, object rect) { }

	// RVA: 0x3D45914
	public object .ctor() { }

}

// Namespace: com.pixui
public class GradientImageUI
{

	// Fields
	protected object m_Shape; // 0x78
	protected object m_GradientEffect; // 0x80
	protected object m_FlipEffect; // 0x88

	// Methods

	// RVA: 0x3D459B8
	protected override object Awake() { }

	// RVA: 0x3D45C20
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D46068
	public object .ctor() { }

}

// Namespace: com.pixui
public class GroupUI
{

	// Methods

	// RVA: 0x3D4610C
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D46114
	public object .ctor() { }

}

// Namespace: com.pixui
public class LineUI
{

	// Fields
	protected object m_Line; // 0x78

	// Methods

	// RVA: 0x3D461B8
	protected override object Awake() { }

	// RVA: 0x3D4630C
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D464E8
	public object SetLine(object width, object color, object startPos, object endPos, object isClear, object isDirty) { }

	// RVA: 0x3D466B0
	public override object OnActive() { }

	// RVA: 0x3D466F0
	public override object OnDeactive() { }

	// RVA: 0x3D46730
	public object .ctor() { }

}

// Namespace: com.pixui
public class MountUI
{

	// Fields
	private object m_Window; // 0x28
	private object m_WindowId; // 0x30
	private object m_ShowDebugName; // 0x34
	private object m_TraceFrameStat; // 0x35
	private object m_TraceFrameThreshold; // 0x38

	// Properties
	public object window { get; }
	public object windowId { get; }
	public object showDebugName { get; set; }
	public object traceFrameStat { get; set; }
	public object traceFrameThreshold { get; set; }

	// Methods

	// RVA: 0x3D467D4
	public object get_window() { }

	// RVA: 0x3D467DC
	public object get_windowId() { }

	// RVA: 0x3D467E4
	public object get_showDebugName() { }

	// RVA: 0x3D467EC
	public object set_showDebugName(object value) { }

	// RVA: 0x3D46890
	public object get_traceFrameStat() { }

	// RVA: 0x3D46898
	public object set_traceFrameStat(object value) { }

	// RVA: 0x3D468A0
	public object get_traceFrameThreshold() { }

	// RVA: 0x3D468A8
	public object set_traceFrameThreshold(object value) { }

	// RVA: 0x3D468B0
	public object Init(object windowId) { }

	// RVA: 0x3D46978
	protected override object Awake() { }

	// RVA: 0x3D469F0
	protected override object Start() { }

	// RVA: 0x3D46A90
	protected override object OnEnable() { }

	// RVA: 0x3D46B30
	protected override object OnDisable() { }

	// RVA: 0x3D46B70
	public object GetSize() { }

	// RVA: 0x3D46BA8
	public object SetSize(object v) { }

	// RVA: 0x3D46C8C
	public object SetPosition(object v) { }

	// RVA: 0x3D46D70
	public object GetPosition() { }

	// RVA: 0x3D46D9C
	protected override object OnDestroy() { }

	// RVA: 0x3D46E24
	private object Update() { }

	// RVA: 0x3D46E60
	public object .ctor() { }

}

// Namespace: com.pixui
public class PrefabableAttribute
{

	// Fields
	private object m_CanPrefably; // 0x8

	// Properties
	public object canPrefably { get; }

	// Methods

	// RVA: 0x3D46EEC
	public object get_canPrefably() { }

	// RVA: 0x3D46EF4
	public object .ctor(object enable) { }

	// RVA: 0x3D46F20
	public object .ctor() { }

}

// Namespace: com.pixui
public class RectUI
{

	// Fields
	protected object m_Shape; // 0x78
	private object m_FlipEffect; // 0x80

	// Methods

	// RVA: 0x3D46F4C
	protected override object Awake() { }

	// RVA: 0x3D47138
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D471EC
	public object SetColor(object color) { }

	// RVA: 0x3D47300
	public object SetShape(object radius) { }

	// RVA: 0x3D47418
	public override object OnActive() { }

	// RVA: 0x3D47458
	public override object OnDeactive() { }

	// RVA: 0x3D47498
	public object .ctor() { }

}

// Namespace: com.pixui
public class RenderLayerUI
{

	// Fields
	protected object m_Canvas; // 0x78
	protected object m_Raycaster; // 0x80

	// Methods

	// RVA: 0x3D4753C
	protected override object Awake() { }

	// RVA: 0x3D476DC
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D47740
	public override object SetParent(object parent) { }

	// RVA: 0x3D478DC
	public object .ctor() { }

}

// Namespace: 
protected struct RenderSortKey
{

	// Fields
	public object sortingLayerID; // 0xFFFFFFFFFFFFFFF8
	public object sortingOrder; // 0xFFFFFFFFFFFFFFFC
	public object renderQueue; // 0x0

	// Methods

	// RVA: 0x3D48700
	public object CompareTo(object other) { }

}

// Namespace: com.pixui
public class SlotUI
{

	// Fields
	protected object handle; // 0x78
	protected object m_OverrideSortingOrder; // 0x7C
	protected object m_IsAttachmentDirty; // 0x7D
	protected static object s_CachedRenderersResult; // 0x0
	protected static object s_RenderBatches; // 0x8
	protected static object s_ListPool; // 0x10

	// Properties
	public object overrideSortingOrder { get; set; }

	// Methods

	// RVA: 0x3D47980
	public object get_overrideSortingOrder() { }

	// RVA: 0x3D47988
	public object set_overrideSortingOrder(object value) { }

	// RVA: 0x3D47990
	public override object OnInit() { }

	// RVA: 0x3D479B8
	public object InvalidateAttachment() { }

	// RVA: 0x3D479C4
	protected virtual object SortingPaint(object baseSortingOrder) { }

	// RVA: 0x3D4813C
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D48224
	protected override object OnInvisible() { }

	// RVA: 0x3D482DC
	public override object AddChild(object child) { }

	// RVA: 0x3D48528
	public virtual object OnAttachmentDidMount(object go) { }

	// RVA: 0x3D4852C
	public virtual object OnAttachmentWillMount(object go) { }

	// RVA: 0x3D48530
	public virtual object OnAttachmentDidUnmount(object go) { }

	// RVA: 0x3D48534
	public virtual object OnAttachmentWillUnmount(object go) { }

	// RVA: 0x3D48538
	public object .ctor() { }

	// RVA: 0x3D485D0
	private static object .cctor() { }

}

// Namespace: com.pixui
public class TextUI
{

	// Fields
	protected object m_Text; // 0x78
	protected object m_Shadow; // 0x80
	protected object m_Outline; // 0x88
	protected object m_StrokeWith; // 0x90
	protected object m_StrokeColor; // 0x94

	// Methods

	// RVA: 0x3D487B8
	protected override object Awake() { }

	// RVA: 0x3D48958
	protected override object OnPaint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: 0x3D49084
	private object SetStroke(object strokeWidth, object strokeColor) { }

	// RVA: 0x3D48E70
	public object SetFont(object fontInfo) { }

	// RVA: 0x3D48F70
	public object SetColor(object color) { }

	// RVA: 0x3D48A64
	public object SetText(object text) { }

	// RVA: 0x3D48B48
	public object SetShadow(object offset, object blur, object color) { }

	// RVA: 0x3D492AC
	public object SetShadow(object v) { }

	// RVA: 0x3D493E8
	public override object OnActive() { }

	// RVA: 0x3D49428
	public override object OnDeactive() { }

	// RVA: 0x3D49520
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__18_0; // 0x8
	public static object <>9__18_1; // 0x10

	// Methods

	// RVA: 0x3D4B788
	private static object .cctor() { }

	// RVA: 0x3D4B7E8
	public object .ctor() { }

	// RVA: 0x3D4B7F0
	internal object <Check>b__18_0(object t) { }

	// RVA: 0x3D4B810
	internal object <Check>b__18_1(object v) { }

}

// Namespace: com.pixui
public class WidgetFactory
{

	// Fields
	private readonly object _checkTimer; // 0x8
	private readonly object _widgetActiveDict; // 0x10
	private readonly object _widgetDrawList; // 0x18
	private readonly object _widgetInactiveDict; // 0x20
	private readonly object _widgetItemList; // 0x28
	private readonly object _widgetReleaseList; // 0x30
	private readonly object _widgetTempList; // 0x38
	private readonly object _window; // 0x40

	// Methods

	// RVA: 0x3D495C4
	public object .ctor(object window) { }

	// RVA: 0x3D49960
	public object AddToDrawingList(object widget) { }

	// RVA: 0x3D49A80
	public object Get(object cmd) { }

	// RVA: 0x3D49DD4
	private object GetActive(object cmd) { }

	// RVA: 0x3D49E70
	private object GetInactive(object cmd) { }

	// RVA: 0x3D49F68
	private object Create(object cmd) { }

	// RVA: 0x3D4A104
	private object SetActive(object widget, object v) { }

	// RVA: 0x3D4A5F4
	private object Check() { }

	// RVA: 0x3D4AF9C
	public object Paint(object enableRaycastTarget) { }

	// RVA: 0x3D4B4B0
	public object Clear() { }

}

// Namespace: 
public class PropertySet
{

	// Fields
	public readonly object vals; // 0x8

	// Methods

	// RVA: 0x3D4C428
	public object Test(object index, object value) { }

	// RVA: 0x3D4C284
	public object Reset(object index) { }

	// RVA: 0x3D4C208
	public object Clear() { }

	// RVA: 0x3D4CAD4
	public object .ctor() { }

}

// Namespace: com.pixui
public class WidgetUI
{

	// Fields
	public readonly object properties; // 0x28
	public readonly object watch; // 0x30
	public object childCount; // 0x38
	public object id; // 0x3C
	public object index; // 0x40
	public object isActive; // 0x44
	public object isPaint; // 0x45
	public object isVisible; // 0x46
	public object parent; // 0x48
	public object siblingIndex; // 0x50
	public object type; // 0x54
	public object window; // 0x58
	public object cachedScale; // 0x60
	protected object m_Reuseable; // 0x6C
	private static object s_DrawTypes; // 0x0

	// Properties
	public object reuseable { get; }
	public object IsExpired { get; }

	// Methods

	// RVA: 0x3D4B818
	public object get_reuseable() { }

	// RVA: 0x3D4B820
	public object MarkNoReuseable() { }

	// RVA: 0x3D4AED8
	public object get_IsExpired() { }

	// RVA: -1
	public static object Create(object type) { }

	// RVA: 0x3D4B85C
	public static object Create(object type) { }

	// RVA: 0x3D4BA44
	public static object Delete(object go) { }

	// RVA: 0x3D4BBA4
	public static object GetTypes() { }

	// RVA: 0x3D4BC20
	protected override object Awake() { }

	// RVA: 0x3D4BD10
	public virtual object OnInit() { }

	// RVA: 0x3D4BD14
	public virtual object SetCmd(object cmd) { }

	// RVA: 0x3D4BD18
	public virtual object SetIdentity() { }

	// RVA: 0x3D4A374
	public object SetVisible(object v) { }

	// RVA: 0x3D4C144
	protected virtual object OnVisible() { }

	// RVA: 0x3D4C148
	protected virtual object OnInvisible() { }

	// RVA: 0x3D4C14C
	public virtual object Paint(object baseSortingOrder, object enableRaycastTarget) { }

	// RVA: 0x3D4C1A8
	protected virtual object OnPaint(object baseSortingOrder, object enableRaycastTarget) { }

	// RVA: 0x3D4C1B0
	public virtual object SetParent(object parent) { }

	// RVA: 0x3D4BF0C
	public object SetDirty() { }

	// RVA: 0x3D4C240
	public object SetDirty(object index) { }

	// RVA: 0x3D4C2C0
	public object SetMatrix(object mat) { }

	// RVA: 0x3D4C508
	public virtual object SetSize(object w, object h) { }

	// RVA: 0x3D4C684
	public virtual object SetName(object name) { }

	// RVA: 0x3D4C74C
	public virtual object AddChild(object child) { }

	// RVA: 0x3D4BF88
	public object SetSiblingIndex() { }

	// RVA: 0x3D4C8CC
	public virtual object Clear() { }

	// RVA: 0x3D4C8D4
	public virtual object OnActive() { }

	// RVA: 0x3D4C8E4
	public virtual object OnDeactive() { }

	// RVA: 0x3D4C944
	public object .ctor() { }

	// RVA: 0x3D4CB74
	private static object .cctor() { }

}

// Namespace: com.pixui
public class WidgetUI<T0>
{

	// Fields
	private static readonly object s_DefaultName; // 0x0
	public object cmd; // 0x0

	// Methods

	// RVA: -1
	private static object WidgetName() { }

	// RVA: -1
	protected override object Awake() { }

	// RVA: -1
	public override object SetCmd(object cmd) { }

	// RVA: -1
	public override object Paint(object baseSortingOrder, object enabledRaycastTarget) { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: com.pixui
public class WindowUI
{

	// Fields
	private object m_Content; // 0x78
	private object m_PointerInput; // 0x80
	private object m_KeyboardInput; // 0x88
	private object m_GamepadInput; // 0x90
	private object m_Modal; // 0x98
	private const object k_ScrollScaleFactor;
	private object m_LastScreenSize; // 0xA0

	// Properties
	public object keyboardInput { get; }

	// Methods

	// RVA: 0x3D4CC88
	public object get_keyboardInput() { }

	// RVA: 0x3D4CC90
	protected override object Awake() { }

	// RVA: 0x3D4EF94
	private object OnGamepadEventInput(object controllerIndex, object keyCode, object value, object pressed) { }

	// RVA: 0x3D4F03C
	private object onClickModal(object eventData) { }

	// RVA: 0x3D4F11C
	public object GetContent() { }

	// RVA: 0x3D4F124
	public object TransformScreenPointToPxPoint(object screenPoint) { }

	// RVA: 0x3D4F13C
	public object TransformScreenPointToClientPoint(object screenPoint) { }

	// RVA: 0x3D4F404
	public object ContainsPoint(object v) { }

	// RVA: 0x3D4F4BC
	private object GetUICamera() { }

	// RVA: 0x3D4F61C
	public object SetData(object window, object mount) { }

	// RVA: 0x3D4F9B0
	public object GetScreenSize() { }

	// RVA: 0x3D4FBD0
	public object ShowModal(object active) { }

	// RVA: 0x3D4FC88
	public override object Clear() { }

	// RVA: 0x3D4FCDC
	private object OnRectTransformDimensionsChange() { }

	// RVA: 0x3D4FE10
	public object UpdateScreenSize(object force) { }

	// RVA: 0x3D4FEC8
	protected override object OnTransformParentChanged() { }

	// RVA: 0x3D4FFC0
	protected override object OnCanvasHierarchyChanged() { }

	// RVA: 0x3D500B8
	private static object IsTouchPointer(object eventData) { }

	// RVA: 0x3D500E0
	private object OnPointerUpHandler(object eventData) { }

	// RVA: 0x3D5023C
	private object OnPointerDownHandler(object eventData) { }

	// RVA: 0x3D50504
	private object OnPointerMoveHandler(object eventData) { }

	// RVA: 0x3D5060C
	private object OnScrollHandler(object eventData) { }

	// RVA: 0x3D507B4
	private object OnKeyboardInput(object text) { }

	// RVA: 0x3D50868
	private object OnKeyboardInputEnd(object text) { }

	// RVA: 0x3D508D0
	private object OnKey(object eventData) { }

	// RVA: 0x3D5035C
	private object OnFocus() { }

	// RVA: 0x3D509A4
	internal object OnPageLoadComplete() { }

	// RVA: 0x3D50C08
	public object .ctor() { }

	// RVA: 0x3D50CA4
	private object <Awake>b__8_0(object controllerIndex, object keyCode, object value) { }

	// RVA: 0x3D50D48
	private object <Awake>b__8_1(object controllerIndex, object keyCode, object pressed) { }

}

// Namespace: com.pixui
public class AtlasConst
{

	// Fields
	public static object MESH_NAME; // 0x0
	public static object BACKGROUND_SHADER_NAME; // 0x8
	public static object BORDER_SHADER_NAME; // 0x10
	public static object INVALID_ATLAS_ELEMENT_KEY; // 0x18
	public static object INVALID_TEXTURE_ID; // 0x1C
	public static object RECT_UV; // 0x20
	public static object COLOR_WHITE; // 0x30
	public static object EMPTY_RADIUS; // 0x34
	public static object EMPTY_BORDER; // 0x54
	public static object EMPTY_SIZE; // 0x84
	public static object DEFALT_MATRIX; // 0x8C
	public static object PROPERTY_VIEW_SIZE; // 0xD0
	public static object PROPERTY_RECT_BOX; // 0xD8
	public static object PROPERTY_SRC_RECT; // 0xE0
	public static object PROPERTY_ROUNDED_RADIUS_TOP; // 0xE8
	public static object PROPERTY_ROUNDED_RADIUS_BOTTOM; // 0xF0
	public static object PROPERTY_BORDER_WIDTH; // 0xF8
	public static object PROPERTY_BORDER_LEFT_COLOR; // 0x100
	public static object PROPERTY_BORDER_TOP_COLOR; // 0x108
	public static object PROPERTY_BORDER_RIGHT_COLOR; // 0x110
	public static object PROPERTY_BORDER_BOTTOM_COLOR; // 0x118

	// Methods

	// RVA: 0x3D50DE0
	private static object .cctor() { }

}

// Namespace: com.pixui
public class AtlasElement
{

	// Fields
	public object rect; // 0x8
	public object uvs; // 0x18
	public object slice; // 0x28
	public object radiusTop; // 0x38
	public object radiusBottom; // 0x48
	public object borderWidth; // 0x58
	public object colorL; // 0x68
	public object colorT; // 0x6C
	public object colorR; // 0x70
	public object colorB; // 0x74
	public object imageID; // 0x78
	public object key; // 0x7C
	public object type; // 0x80

	// Methods

	// RVA: 0x3D510A8
	public object Set(object key, object type, object rect, object radius, object border, object image) { }

	// RVA: 0x3D512DC
	public object .ctor() { }

}

// Namespace: com.pixui
public class AtlasHelper
{

	// Methods

	// RVA: 0x3D512E4
	private static object GetHashKey(object type, object radiuses, object border, object size, object image) { }

	// RVA: 0x3D51360
	public static object GetHashKey(object bufferPtr, object type) { }

}

// Namespace: com.pixui
public class AtlasManager
{

	// Fields
	private object m_ID; // 0x8
	private object m_WindowID; // 0xC
	private object m_Window; // 0x10
	private object m_ElementDic; // 0x18
	private object m_PendingElementDic; // 0x20
	private object m_Painter; // 0x28
	private object m_Atlas; // 0x30
	private object m_AtlasAsset; // 0x38
	private object m_Packer; // 0x40
	private object DEFAULT_ATLASE_SIZE; // 0x48
	private object MAX_ATLASE_SIZE; // 0x4C
	private object m_IsLimited; // 0x50

	// Methods

	// RVA: 0x3D51584
	public object GetID() { }

	// RVA: 0x3D5158C
	public object IsLimited() { }

	// RVA: 0x3D51594
	public object .ctor(object wnd) { }

	// RVA: 0x3D51AA8
	public object ContainsKey(object key) { }

	// RVA: 0x3D51B4C
	public object GetElement(object key) { }

	// RVA: 0x3D51BF8
	public object GenAtlasCmd(object key) { }

	// RVA: 0x3D51D50
	public object Make() { }

	// RVA: 0x3D5377C
	public object Dispose() { }

	// RVA: 0x3D5384C
	private object ReleaseLastAtlas() { }

	// RVA: 0x3D53A24
	private object ResizeAtlasTexture() { }

	// RVA: 0x3D51864
	private object CreateAtlasTexture(object wnd) { }

	// RVA: 0x3D53CFC
	private object GetElementData(object key, object bufferPtr, object type) { }

	// RVA: 0x3D53EA4
	private object RefreshAllElementPosition() { }

	// RVA: 0x3D54310
	private object PackElement(object key, object bufferPtr, object type) { }

	// RVA: 0x3D54510
	private object GetCmd(object key, object bufferPtr, object type, object atlasAsset) { }

	// RVA: 0x3D547A0
	public object GenerateCmd(object key, object bufferPtr, object type) { }

}

// Namespace: com.pixui
public class AtlasPainter
{

	// Fields
	private object m_Buffer; // 0x8
	private object m_Mesh; // 0x10
	private object m_PropertyBlock; // 0x18
	private object m_Verts; // 0x20
	private object m_UVs; // 0x28
	private object m_Indeces; // 0x30
	private object m_Offset; // 0x38
	private object m_SubMeshOffset; // 0x3C
	private object m_Size; // 0x40
	private object mShaderTextID; // 0x44
	private object m_Window; // 0x48
	private object m_RenderTarget; // 0x50

	// Methods

	// RVA: 0x3D5182C
	public object .ctor(object wnd) { }

	// RVA: 0x3D54958
	public object Init() { }

	// RVA: 0x3D54B64
	public object Resize(object value) { }

	// RVA: 0x3D51A10
	public object SetRenderTarget(object rt) { }

	// RVA: 0x3D52064
	public object Paint(object elementDic) { }

	// RVA: 0x3D53A20
	public object Dispose() { }

	// RVA: 0x3D54C10
	private object ClearDrawcallState() { }

	// RVA: 0x3D54C88
	private object ClearAllState() { }

}

// Namespace: com.pixui
public enum AtlasElementType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Background;
	public const object Border;
}

// Namespace: com.pixui
public class AtlasTexture
{

	// Fields
	private static object m_IncreasedID; // 0x0

	// Properties
	public override object width { get; }
	public override object height { get; }

	// Methods

	// RVA: 0x3D53C68
	public object .ctor(object url, object id, object tx) { }

	// RVA: 0x3D54DA4
	public override object get_width() { }

	// RVA: 0x3D54DF8
	public override object get_height() { }

}

// Namespace: com.pixui
public abstract class BasePacker
{

	// Fields
	protected object m_MaxSize; // 0x8
	protected object m_AtlasSize; // 0xC

	// Methods

	// RVA: 0x3D54E4C
	public virtual object Initialize(object defaultSize, object maxSize) { }

	// RVA: 0x3D54E54
	public virtual object Expand() { }

	// RVA: 0x3D54E5C
	public virtual object Add(object key, object width, object height) { }

	// RVA: 0x3D54E64
	public virtual object GetPosition(object key) { }

	// RVA: 0x3D54EB0
	public object GetSize() { }

	// RVA: 0x3D54EB8
	public virtual object Dispose() { }

	// RVA: 0x3D54EBC
	protected object .ctor() { }

}

// Namespace: com.pixui
public class SimplePacker
{

	// Fields
	private object m_OffsetX; // 0x10
	private object m_OffsetY; // 0x14
	private object m_LastMaxHeight; // 0x18
	private object m_ElementDic; // 0x20

	// Methods

	// RVA: 0x3D54EC4
	public override object Initialize(object defaultSize, object maxSize) { }

	// RVA: 0x3D54F5C
	public override object Expand() { }

	// RVA: 0x3D55048
	public override object Add(object key, object width, object height) { }

	// RVA: 0x3D5519C
	public override object GetPosition(object key) { }

	// RVA: 0x3D55258
	public override object Dispose() { }

	// RVA: 0x3D5185C
	public object .ctor() { }

}

// Namespace: 
public enum MaterialType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Background;
	public const object Border;
}

// Namespace: com.pixui
public class PxAtlas
{

	// Fields
	private static object s_AtlasManagerDict; // 0x0
	private static object s_BackgroundMaterial; // 0x8
	private static object s_BorderMaterial; // 0x10
	private static object s_IsInitial; // 0x18
	private static object s_IsBgShaderLoaded; // 0x19
	private static object s_IsBorderShaderLoaded; // 0x1A

	// Methods

	// RVA: 0x3D552B4
	public static object Initialize() { }

	// RVA: 0x3D55388
	public static object Shutdown() { }

	// RVA: 0x3D55594
	public static object GenerateCmd(object wnd, object bufferPtr, object type) { }

	// RVA: 0x3D55BEC
	public static object MakeAtlas(object wnd) { }

	// RVA: 0x3D55B78
	private static object GetHashKey(object bufferPtr, object type) { }

	// RVA: 0x3D55B7C
	private static object IsValidKey(object key) { }

	// RVA: 0x3D55A7C
	private static object IsValid(object bufferPtr, object type) { }

	// RVA: 0x3D55794
	public static object GetManager(object wnd) { }

	// RVA: 0x3D55E04
	public static object RemoveManager(object wnd) { }

	// RVA: 0x3D54B6C
	public static object GetMaterial(object type) { }

}

// Namespace: com.pixui
public static class Extensions
{

	// Methods

	// RVA: -1
	public static object ForEach(object list, object func) { }

	// RVA: -1
	public static object ForEach(object list, object func) { }

	// RVA: 0x3D51F8C
	public static object IsEmpty(object list) { }

	// RVA: -1
	public static object Get(object dict, object key) { }

	// RVA: 0x3D55F08
	public static object Remove(object str, object target) { }

	// RVA: 0x3D55F84
	public static object IsNullOrEmpty(object str) { }

}

// Namespace: 
public class Node
{

	// Fields
	public object list; // 0x0
	public object next; // 0x0
	public object prev; // 0x0
	public object value; // 0x0

	// Properties
	public object IsLast { get; }

	// Methods

	// RVA: -1
	public object get_IsLast() { }

	// RVA: -1
	public object Set(object list, object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public override object ToString() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__3_0() { }

	// RVA: -1
	internal object <.cctor>b__3_1(object t) { }

}

// Namespace: 
private static class Helper
{

	// Fields
	private static readonly object _objCache; // 0x0

	// Methods

	// RVA: -1
	public static object Get(object list, object value) { }

	// RVA: -1
	public static object Release(object v) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: com.pixui
public class LinkedList<T0>
{

	// Fields
	private object _first; // 0x0
	private object _last; // 0x0
	private object <Count>k__BackingField; // 0x0

	// Properties
	public object Count { get; set; }
	public object First { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	private object set_Count(object value) { }

	// RVA: -1
	public object get_First() { }

	// RVA: -1
	public object AddLast(object v) { }

	// RVA: -1
	public object Remove(object node) { }

	// RVA: -1
	public override object ToString() { }

}

// Namespace: com.pixui
public class ListPool<T0>
{

	// Fields
	private object m_Pool; // 0x0

	// Methods

	// RVA: -1
	public object Claim() { }

	// RVA: -1
	public object Release(object list) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
public class Item
{

	// Fields
	public object key; // 0x0
	public object value; // 0x0

	// Methods

	// RVA: -1
	public object Set(object key, object value) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public override object ToString() { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <.cctor>b__3_0() { }

	// RVA: -1
	internal object <.cctor>b__3_1(object t) { }

}

// Namespace: 
private static class Helper
{

	// Fields
	private static readonly object _objCache; // 0x0

	// Methods

	// RVA: -1
	public static object Get(object key, object value) { }

	// RVA: -1
	public static object Release(object item) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: com.pixui
public class LRUCache<T0, T1>
{

	// Fields
	private readonly object _dict; // 0x0
	private readonly object _list; // 0x0
	private object _capacity; // 0x0

	// Properties
	public object Count { get; }
	public object Capacity { get; }

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Capacity() { }

	// RVA: -1
	public object Shrink() { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object Get(object key) { }

	// RVA: -1
	public override object ToString() { }

}

// Namespace: 
public class Options
{

	// Fields
	public object onCreate; // 0x0
	public object onGet; // 0x0
	public object onRelease; // 0x0
	public object onRemove; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

}

// Namespace: com.pixui
public class ObjectPool<T0>
{

	// Fields
	private readonly object _onCreate; // 0x0
	private readonly object _onGet; // 0x0
	private readonly object _onRelease; // 0x0
	private readonly object _onRemove; // 0x0
	private readonly object _stack; // 0x0

	// Properties
	public object Count { get; }
	public object Values { get; }

	// Methods

	// RVA: -1
	public object .ctor(object opt) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_Values() { }

	// RVA: -1
	public object Get() { }

	// RVA: -1
	public object Release(object t) { }

	// RVA: -1
	public object Remove(object t) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public override object ToString() { }

}

// Namespace: com.pixui
public class PxBehaviour
{

	// Fields
	private object m_RectTransform; // 0x18
	private object m_Canvas; // 0x20
	private static object s_ListPool; // 0x0

	// Properties
	public object rectTransform { get; }
	public object canvas { get; }

	// Methods

	// RVA: 0x3D4BCA0
	public object get_rectTransform() { }

	// RVA: 0x3D4B3F8
	public object get_canvas() { }

	// RVA: 0x3D55F8C
	private object CacheCanvas() { }

	// RVA: 0x3D5007C
	protected virtual object OnCanvasHierarchyChanged() { }

	// RVA: 0x3D4FF84
	protected virtual object OnTransformParentChanged() { }

	// RVA: 0x3D4BC9C
	protected virtual object Awake() { }

	// RVA: 0x3D561B0
	protected virtual object Start() { }

	// RVA: 0x3D561B4
	protected virtual object OnEnable() { }

	// RVA: 0x3D561B8
	protected virtual object OnDisable() { }

	// RVA: 0x3D561BC
	protected virtual object OnDestroy() { }

	// RVA: 0x3D4CB6C
	public object .ctor() { }

	// RVA: 0x3D561C0
	private static object .cctor() { }

}

// Namespace: 
public class Token
{

	// Fields
	public static readonly object Empty; // 0x0
	public readonly object behaviour; // 0x8
	public readonly object handler; // 0x10
	public object enabled; // 0x18

	// Methods

	// RVA: 0x3D563BC
	private object .ctor() { }

	// RVA: 0x3D562E4
	public object .ctor(object behaviour, object handler) { }

	// RVA: 0x3D563EC
	private static object .cctor() { }

}

// Namespace: 
private sealed class <While>d__1
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object predicate; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x3D56390
	public object .ctor(object <>1__state) { }

	// RVA: 0x3D56458
	private object System.IDisposable.Dispose() { }

	// RVA: 0x3D5645C
	private object MoveNext() { }

	// RVA: 0x3D564E0
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x3D564E8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x3D56528
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: com.pixui
public static class PxCoroutine
{

	// Methods

	// RVA: 0x3D56250
	public static object StartCoroutine(object behaviour, object handler) { }

	// RVA: 0x3D56324
	public static object While(object predicate) { }

}

// Namespace: com.pixui
public class PxGamepadInput
{

	// Fields
	private object onGamepadValueAction; // 0x18
	private object onGamepadButtonAction; // 0x20

	// Methods

	// RVA: 0x3D4EE2C
	public object add_onGamepadValueAction(object value) { }

	// RVA: 0x3D56530
	public object remove_onGamepadValueAction(object value) { }

	// RVA: 0x3D4EEE0
	public object add_onGamepadButtonAction(object value) { }

	// RVA: 0x3D565E4
	public object remove_onGamepadButtonAction(object value) { }

	// RVA: 0x3D56698
	public object .ctor() { }

}

// Namespace: com.pixui
public static class PxHash
{

	// Methods

	// RVA: -1
	public static object Get(object v1) { }

	// RVA: -1
	public static object Get(object v1, object v2) { }

	// RVA: -1
	public static object Get(object v1, object v2, object v3) { }

	// RVA: -1
	public static object Get(object v1, object v2, object v3, object v4) { }

	// RVA: -1
	public static object Get(object v1, object v2, object v3, object v4, object v5) { }

	// RVA: -1
	public static object Get(object v1, object v2, object v3, object v4, object v5, object v6) { }

	// RVA: -1
	public static object Get(object v1, object v2, object v3, object v4, object v5, object v6, object v7) { }

	// RVA: -1
	public static object Get(object v1, object v2, object v3, object v4, object v5, object v6, object v7, object v8, object v9, object v10, object v11) { }

}

// Namespace: 
public sealed class OnTextInput
{

	// Methods

	// RVA: 0x3D4EA48
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5824C
	public virtual object Invoke(object text) { }

}

// Namespace: 
public sealed class OnDidEndEdit
{

	// Methods

	// RVA: 0x3D4EB94
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5831C
	public virtual object Invoke(object text) { }

}

// Namespace: 
public sealed class OnCancelEdit
{

	// Methods

	// RVA: 0x3D583EC
	public object .ctor(object object, object method) { }

	// RVA: 0x3D58494
	public virtual object Invoke(object text) { }

}

// Namespace: 
public sealed class OnKey
{

	// Methods

	// RVA: 0x3D4ECE0
	public object .ctor(object object, object method) { }

	// RVA: 0x3D58548
	public virtual object Invoke(object eventData) { }

}

// Namespace: com.pixui
public class PxKeyboardInput
{

	// Fields
	private object m_Keyboard; // 0x18
	private object m_Active; // 0x20
	private object m_LastText; // 0x28
	private object onTextInput; // 0x30
	private object onDidEndEdit; // 0x38
	private object onCancelEdit; // 0x40
	private object onKey; // 0x48
	private static readonly object s_KeycodeToPxKeyCode; // 0x0
	private static readonly object s_PxKeyCodeToKeycode; // 0x8

	// Methods

	// RVA: 0x3D4EAF0
	public object add_onTextInput(object value) { }

	// RVA: 0x3D566A0
	public object remove_onTextInput(object value) { }

	// RVA: 0x3D4EC3C
	public object add_onDidEndEdit(object value) { }

	// RVA: 0x3D56744
	public object remove_onDidEndEdit(object value) { }

	// RVA: 0x3D567E8
	public object add_onCancelEdit(object value) { }

	// RVA: 0x3D5688C
	public object remove_onCancelEdit(object value) { }

	// RVA: 0x3D4ED88
	public object add_onKey(object value) { }

	// RVA: 0x3D56930
	public object remove_onKey(object value) { }

	// RVA: 0x3D569D4
	private object Awake() { }

	// RVA: 0x3D56D74
	public object IsAllowActivateKeyboard(object keyboardType, object defaultText, object hintText) { }

	// RVA: 0x3D56D84
	public object ActivateKeyboard(object keyboardType, object defaultText, object hintText) { }

	// RVA: 0x3D50A60
	public object Deactivate() { }

	// RVA: 0x3D56FD0
	protected object OnDestroy() { }

	// RVA: 0x3D56FD4
	private object Update() { }

	// RVA: 0x3D57124
	private object OnUpdateSelected(object eventData) { }

	// RVA: 0x3D572F4
	private static object InitKeyCodeToKeycode() { }

	// RVA: 0x3D57538
	public static object TranslateKeyCode(object emKey) { }

	// RVA: 0x3D57600
	public static object TranslateKeyCode(object emKey) { }

	// RVA: 0x3D576C8
	public static object TranslateKeyModifiers(object modifiers) { }

	// RVA: 0x3D57704
	public static object TranslateKeyModifiers(object modifiers) { }

	// RVA: 0x3D5773C
	public object .ctor() { }

	// RVA: 0x3D57744
	private static object .cctor() { }

}

// Namespace: com.pixui
public static class PxMarshal
{

	// Methods

	// RVA: 0x3D5855C
	public static object GetString(object ptr) { }

}

// Namespace: com.pixui
public static class PxMath
{

	// Methods

	// RVA: 0x3D586A8
	public static object Rotate(object pt, object center, object angle) { }

}

// Namespace: 
public struct Decomposition
{

	// Fields
	public object angle; // 0xFFFFFFFFFFFFFFF8
	public object remainderA; // 0xFFFFFFFFFFFFFFFC
	public object remainderB; // 0x0
	public object remainderC; // 0x4
	public object remainderD; // 0x8
	public object scaleX; // 0xC
	public object scaleY; // 0x10
	public object translateX; // 0x14
	public object translateY; // 0x18
}

// Namespace: 
private class Mathf
{

	// Fields
	public static readonly object Rad2Deg; // 0x0
	public static readonly object Deg2Rad; // 0x4

	// Methods

	// RVA: 0x3D59C30
	internal static object Atan2(object y, object x) { }

	// RVA: 0x3D58DA4
	internal static object Cos(object radian) { }

	// RVA: 0x3D58E0C
	internal static object Sin(object radian) { }

	// RVA: 0x3D58A84
	internal static object Sqrt(object v) { }

	// RVA: 0x3D59D08
	private static object .cctor() { }

}

// Namespace: com.pixui
public struct PxMatrix
{

	// Fields
	public static readonly object Zero; // 0x0
	public static readonly object Identity; // 0x8
	public object a; // 0xFFFFFFFFFFFFFFF8
	public object b; // 0xFFFFFFFFFFFFFFFC
	public object c; // 0x0
	public object d; // 0x4
	public object e; // 0x8
	public object f; // 0xC

	// Methods

	// RVA: 0x3D58984
	public object .ctor(object a, object b, object c, object d, object e, object f) { }

	// RVA: 0x3D589A4
	public object GetScaleX() { }

	// RVA: 0x3D58BE4
	public object GetScaleY() { }

	// RVA: 0x3D58788
	public object Rotate(object angle) { }

	// RVA: 0x3D58F3C
	public object Scale(object sx, object sy) { }

	// RVA: 0x3D58F8C
	public object Translate(object tx, object ty) { }

	// RVA: 0x3D58FDC
	public object FlipX() { }

	// RVA: 0x3D590D4
	public object FlipY() { }

	// RVA: 0x3D58964
	public object Multiply(object pt) { }

	// RVA: 0x3D58E74
	public object Multiply(object mat) { }

	// RVA: 0x3D592E4
	public static object op_Multiply(object lh, object rh) { }

	// RVA: 0x3D59428
	public override object Equals(object obj) { }

	// RVA: 0x3D59534
	public object Equals(object other) { }

	// RVA: 0x3D59614
	public override object GetHashCode() { }

	// RVA: 0x3D596CC
	public override object ToString() { }

	// RVA: 0x3D5990C
	public object Decompose() { }

	// RVA: 0x3D59CA8
	private static object .cctor() { }

}

// Namespace: com.pixui
public static class PxMisc
{

	// Fields
	public static object nativeIdentity; // 0x0
	public static object nativeWhite; // 0x18
	public static object nativeBlack; // 0x1C
	public static object leftTopPt; // 0x20
	public static object centerPt; // 0x28
	public static object validRange; // 0x30

	// Methods

	// RVA: 0x3D59D5C
	public static object ValidtionVal(object v) { }

	// RVA: 0x3D59DF4
	public static object ClampAngle(object angle) { }

	// RVA: 0x3D59E94
	public static object GetEuler(object x, object y, object z) { }

	// RVA: 0x3D5A214
	public static object GetScale(object x, object y, object z) { }

	// RVA: 0x3D5A3FC
	public static object SetTRS(object rectTransform, object v) { }

	// RVA: 0x3D4C478
	public static object SetMatrix(object rectTransform, object mat) { }

	// RVA: 0x3D54BD4
	public static object ToUColor(object color) { }

	// RVA: 0x3D5A5A8
	public static object ToObject(object mat) { }

	// RVA: 0x3D5A4B8
	public static object ToTRS(object mat) { }

	// RVA: 0x3D5A5BC
	public static object ToTRS(object mat) { }

	// RVA: 0x3D5A664
	public static object Translate(object mat, object x, object y) { }

	// RVA: 0x3D55CB0
	public static object IsValid(object slice) { }

	// RVA: 0x3D5A744
	public static object IsValid(object border) { }

	// RVA: 0x3D5A784
	public static object ToVector2(object pt) { }

	// RVA: 0x3D5A788
	public static object ToVector4(object slice) { }

	// RVA: 0x3D5A7A4
	public static object ToVector4(object widths) { }

	// RVA: 0x3D5A7C0
	public static object IsFill(object slice) { }

	// RVA: 0x3D5A7D0
	public static object ToUType(object fontStyle) { }

	// RVA: -1
	public static object CreateComponent(object name) { }

	// RVA: 0x3D5A7E0
	public static object Multiply(object vh, object mat) { }

	// RVA: 0x3D5A93C
	public static object ToTexture2D(object renderTexture) { }

	// RVA: 0x3D5AAC8
	public static object SetParent(object child, object parent, object worldPositionStays) { }

	// RVA: 0x3D4DDA0
	public static object SetParent(object child, object parent, object worldPositionStays) { }

	// RVA: 0x3D5AB48
	public static object SetParent(object child, object parent, object worldPositionStays) { }

	// RVA: 0x3D5ABC8
	public static object SetParent(object child, object parent, object worldPositionStays) { }

	// RVA: 0x3D5AC48
	public static object SetActive(object component, object v) { }

	// RVA: 0x3D5AC94
	public static object GetRectTransform(object go) { }

	// RVA: 0x3D5ACF4
	public static object GetRectTransform(object component) { }

	// RVA: -1
	public static object GetOrAddComponent(object go) { }

	// RVA: -1
	public static object GetOrAddComponent(object component) { }

	// RVA: 0x3D4BEA0
	public static object SetIdentity(object rectTransform) { }

	// RVA: 0x3D4DFE0
	public static object SetIdentity(object rectTransform, object pt) { }

	// RVA: 0x3D4C664
	public static object SetSize(object rectTransform, object w, object h) { }

	// RVA: 0x3D5ADB0
	public static object SetFixedSize(object rectTransform) { }

	// RVA: 0x3D5AFB0
	public static object Ptr2Str(object ptr) { }

	// RVA: 0x3D55CE0
	public static object GetShader(object shaderName) { }

	// RVA: 0x3D5AFB4
	public static object SetKeywordEnum(object self, object name, object id, object kw1, object kw2, object kw3) { }

	// RVA: 0x3D5B0C0
	public static object SetKeywordToggle(object self, object name, object on, object keyword) { }

	// RVA: 0x3D5B188
	private static object .cctor() { }

}

// Namespace: com.pixui
public class PxID
{

	// Fields
	public object sid; // 0x8

	// Methods

	// RVA: 0x3D5B220
	public object NewId() { }

	// RVA: 0x3D5B234
	public object .ctor() { }

}

// Namespace: com.pixui
public static class PxSpaceMapping
{

	// Methods

	// RVA: 0x3D4F3FC
	public static object ToPxSpace(object pos) { }

}

// Namespace: com.pixui
public static class PxUtf8
{

	// Fields
	public static readonly object whiteSquare; // 0x0
	public static readonly object replacement; // 0x2

	// Methods

	// RVA: 0x3D5B23C
	public static object Utf8ToCodePoint(object utf8, object remainBytes, object codePoint) { }

	// RVA: 0x3D5B318
	public static object CodePointToDisplayChar(object codePoint) { }

	// RVA: 0x3D5B3E0
	private static object .cctor() { }

}

// Namespace: com.pixui
public class PxModal
{

	// Fields
	public object cachedRectTransform; // 0x18

	// Methods

	// RVA: 0x3D5B434
	protected object Awake() { }

	// RVA: 0x3D5B4B4
	protected object OnEnable() { }

	// RVA: 0x3D5B704
	private object FindRootCanvas() { }

	// RVA: 0x3D5B4B8
	private object EnsureOverlayFullScreen() { }

	// RVA: 0x3D4FC30
	public object Show(object active) { }

	// RVA: 0x3D5B7E8
	public object .ctor() { }

}

// Namespace: com.pixui
public static class PxPath
{

	// Methods

	// RVA: 0x3D5B7F0
	internal static object NormalizeUrl(object url) { }

}

// Namespace: 
public sealed class OnPointerDownHandler
{

	// Methods

	// RVA: 0x3D4E188
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5C004
	public virtual object Invoke(object eventData) { }

}

// Namespace: 
public sealed class OnPointerUpHandler
{

	// Methods

	// RVA: 0x3D4E348
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5C2F0
	public virtual object Invoke(object eventData) { }

}

// Namespace: 
public sealed class OnDragHandler
{

	// Methods

	// RVA: 0x3D4E6C8
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5C5DC
	public virtual object Invoke(object eventData) { }

}

// Namespace: 
public sealed class OnScrollHandler
{

	// Methods

	// RVA: 0x3D4E508
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5C8C8
	public virtual object Invoke(object eventData) { }

}

// Namespace: 
public sealed class OnPointerClickHandler
{

	// Methods

	// RVA: 0x3D4DE20
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5CBB4
	public virtual object Invoke(object eventData) { }

}

// Namespace: 
public sealed class OnPointerMoveHandler
{

	// Methods

	// RVA: 0x3D4E888
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5CEA0
	public virtual object Invoke(object eventData) { }

}

// Namespace: com.pixui
public class PxPointerInput
{

	// Fields
	private object onPointerDownHandler; // 0x18
	private object onPointerUpHandler; // 0x20
	private object onDragHandler; // 0x28
	private object onScrollHandler; // 0x30
	private object onPointerClickHandler; // 0x38
	private object onPointerMoveHandler; // 0x40

	// Methods

	// RVA: 0x3D4E2A4
	public object add_onPointerDownHandler(object value) { }

	// RVA: 0x3D5B8A4
	public object remove_onPointerDownHandler(object value) { }

	// RVA: 0x3D4E464
	public object add_onPointerUpHandler(object value) { }

	// RVA: 0x3D5B948
	public object remove_onPointerUpHandler(object value) { }

	// RVA: 0x3D4E7E4
	public object add_onDragHandler(object value) { }

	// RVA: 0x3D5B9EC
	public object remove_onDragHandler(object value) { }

	// RVA: 0x3D4E624
	public object add_onScrollHandler(object value) { }

	// RVA: 0x3D5BA90
	public object remove_onScrollHandler(object value) { }

	// RVA: 0x3D4DF3C
	public object add_onPointerClickHandler(object value) { }

	// RVA: 0x3D5BB34
	public object remove_onPointerClickHandler(object value) { }

	// RVA: 0x3D4E9A4
	public object add_onPointerMoveHandler(object value) { }

	// RVA: 0x3D5BBD8
	public object remove_onPointerMoveHandler(object value) { }

	// RVA: 0x3D5BC7C
	public object OnPointerDown(object eventData) { }

	// RVA: 0x3D5BC98
	public object OnPointerUp(object eventData) { }

	// RVA: 0x3D5BCB4
	public object OnDrag(object eventData) { }

	// RVA: 0x3D5BCD0
	public object OnScroll(object eventData) { }

	// RVA: 0x3D5BCEC
	public object OnPointerClick(object eventData) { }

	// RVA: 0x3D5BD08
	public object OnPointerMove(object eventData) { }

	// RVA: 0x3D5BD24
	public object .ctor() { }

}

// Namespace: com.pixui
public class PxReadOnlyAttribute
{

	// Methods

	// RVA: 0x3D5CEB4
	public object .ctor() { }

}

// Namespace: com.pixui
public static class PxShaderUtils
{

	// Methods

	// RVA: 0x3D5CEBC
	public static object SetRadiusMask(object mat, object uvOffset, object uvScale, object radiusLT, object radiusRT, object radiusLB, object radiusRB) { }

	// RVA: 0x3D5D200
	public static object SetBorder(object mat, object size, object stroke, object radiusLT, object radiusRT, object radiusLB, object radiusRB, object colorL, object colorT, object colorR, object colorB) { }

	// RVA: 0x3D5D87C
	public static object CreateMaterial(object shaderName) { }

	// RVA: 0x3D5D904
	public static object CreateMaterial(object shader) { }

}

// Namespace: 
public class Token
{

	// Fields
	public static readonly object Empty; // 0x0
	public object id; // 0x8

	// Methods

	// RVA: 0x3D5EFC8
	private object .ctor() { }

	// RVA: 0x3D5ED04
	public object .ctor(object id) { }

	// RVA: 0x3D4B6D0
	public object Stop() { }

	// RVA: 0x3D5F09C
	private static object .cctor() { }

}

// Namespace: 
public class Invoker
{

	// Fields
	public readonly object onComplete; // 0x8
	public readonly object onTimer; // 0x10

	// Methods

	// RVA: 0x3D5F104
	public object .ctor(object onTimer, object onComplete) { }

	// RVA: 0x3D5F13C
	public object OnTimer() { }

}

// Namespace: 
private class Timer
{

	// Fields
	internal object container; // 0x8
	internal object cycle; // 0x10
	internal object deadline; // 0x14
	internal object delete; // 0x18
	internal object handler; // 0x20
	internal object sn; // 0x28

	// Methods

	// RVA: 0x3D5F83C
	public object .ctor() { }

}

// Namespace: 
private class Wheel
{

	// Fields
	internal readonly object dialSize; // 0x8
	internal readonly object timeRange; // 0xC
	internal readonly object vecDial; // 0x10
	internal object head; // 0x18
	internal object nextWheel; // 0x20

	// Methods

	// RVA: 0x3D5F6A0
	internal object .ctor(object dialSize) { }

	// RVA: 0x3D5F618
	internal object nextDial() { }

	// RVA: 0x3D5F3C4
	internal object add(object delay, object tm) { }

}

// Namespace: 
private sealed class <>c__DisplayClass20_0
{

	// Fields
	public object handler; // 0x8

	// Methods

	// RVA: 0x3D5F834
	public object .ctor() { }

	// RVA: 0x3D5F884
	internal object <add>b__0(object sn) { }

}

// Namespace: 
private static class TimerHelper
{

	// Fields
	private static object nextSn; // 0x0
	private static object wheels; // 0x8
	private static object firstWheel; // 0x10
	private static object pileSecs; // 0x18
	private static object nowTime; // 0x1C
	private static object mapSnTimer; // 0x20
	private static object executeTimers; // 0x28
	private static object cascadeTimers; // 0x30
	private static object inited; // 0x38

	// Methods

	// RVA: 0x3D5F158
	private static object intpow(object n, object m) { }

	// RVA: 0x3D5F1D8
	private static object innerAdd(object deadline, object tm) { }

	// RVA: 0x3D5F530
	private static object innerDel(object tm) { }

	// RVA: 0x3D5F538
	private static object innerDel(object tm, object removeFromMap) { }

	// RVA: 0x3D5F354
	private static object now() { }

	// RVA: 0x3D5DE28
	internal static object tick(object deltaTime) { }

	// RVA: 0x3D5DAC0
	public static object init() { }

	// RVA: 0x3D5F7E0
	private static object fetchSn() { }

	// RVA: 0x3D5EC3C
	internal static object add(object delay, object handler) { }

	// RVA: 0x3D5EE60
	internal static object add(object delay, object cycle, object handler) { }

	// RVA: 0x3D5EFF4
	internal static object del(object sn) { }

	// RVA: 0x3D5E630
	public static object delAll() { }

}

// Namespace: 
private sealed class <>c__DisplayClass3_0
{

	// Fields
	public object invoker; // 0x8

	// Methods

	// RVA: 0x3D5EC34
	public object .ctor() { }

	// RVA: 0x3D5F8BC
	internal object <SetTimeout>b__0(object id) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object invoker; // 0x8

	// Methods

	// RVA: 0x3D5EE58
	public object .ctor() { }

	// RVA: 0x3D5F8F4
	internal object <SetInterval>b__0(object id) { }

}

// Namespace: com.pixui
public static class PxTimer
{

	// Methods

	// RVA: 0x3D5DABC
	public static object Init() { }

	// RVA: 0x3D5DE24
	public static object Tick(object delta) { }

	// RVA: 0x3D5E62C
	public static object Clear() { }

	// RVA: 0x3D5EB10
	public static object SetTimeout(object seconds, object invoker) { }

	// RVA: 0x3D5ED30
	public static object SetInterval(object seconds, object invoker) { }

}

// Namespace: com.pixui
public struct PxTRS
{

	// Fields
	public object translate; // 0xFFFFFFFFFFFFFFF8
	public object angle; // 0x0
	public object scale; // 0x4

	// Methods

	// RVA: 0x3D5A654
	public object .ctor(object tx, object ty, object angle, object sx, object sy) { }

	// RVA: 0x3D5F944
	public override object GetHashCode() { }

}

// Namespace: 
public sealed class OnUpdateSelectedHandler
{

	// Methods

	// RVA: 0x3D56B74
	public object .ctor(object object, object method) { }

	// RVA: 0x3D5FE70
	public virtual object Invoke(object eventData) { }

}

// Namespace: com.pixui
public class PxUpdateSelectedHandler
{

	// Fields
	private object m_ProcessingEvent; // 0x18
	private object m_OnUpdateSelectedHandlers; // 0x20

	// Methods

	// RVA: 0x3D56C1C
	public object add_onUpdateSelectedHandler(object value) { }

	// RVA: 0x3D5F9FC
	public object remove_onUpdateSelectedHandler(object value) { }

	// RVA: 0x3D5FAB0
	public object OnUpdateSelected(object eventData) { }

	// RVA: 0x3D5FCF0
	public object .ctor() { }

}

// Namespace: com.pixui
public class PxUri
{

	// Fields
	private object <url>k__BackingField; // 0x8
	private object <schema>k__BackingField; // 0x10
	private object <userinfo>k__BackingField; // 0x18
	private object <host>k__BackingField; // 0x20
	private object <port>k__BackingField; // 0x28
	private object <path>k__BackingField; // 0x30
	private object <search>k__BackingField; // 0x38
	private object <hash>k__BackingField; // 0x40
	private object <jarUrl>k__BackingField; // 0x48
	private object <jarEntry>k__BackingField; // 0x50
	private static readonly object s_winFileUrlPattern; // 0x0
	private static readonly object s_unixFileUrlPattern; // 0x8
	private static readonly object s_jarUrlPattern; // 0x10
	private static readonly object s_httpOrHttpsUrlPattern; // 0x18
	private static readonly object s_unityUrlPattern; // 0x20
	private static readonly object s_unknownUrlPattern; // 0x28

	// Properties
	public object url { get; set; }
	private object schema { set; }
	private object userinfo { set; }
	private object host { set; }
	private object port { set; }
	public object path { get; set; }
	private object search { set; }
	private object hash { set; }
	private object jarUrl { set; }
	private object jarEntry { set; }

	// Methods

	// RVA: 0x3D5FE84
	public object get_url() { }

	// RVA: 0x3D5FE8C
	private object set_url(object value) { }

	// RVA: 0x3D5FE94
	private object set_schema(object value) { }

	// RVA: 0x3D5FE9C
	private object set_userinfo(object value) { }

	// RVA: 0x3D5FEA4
	private object set_host(object value) { }

	// RVA: 0x3D5FEAC
	private object set_port(object value) { }

	// RVA: 0x3D5FEB4
	public object get_path() { }

	// RVA: 0x3D5FEBC
	private object set_path(object value) { }

	// RVA: 0x3D5FEC4
	private object set_search(object value) { }

	// RVA: 0x3D5FECC
	private object set_hash(object value) { }

	// RVA: 0x3D5FED4
	private object set_jarUrl(object value) { }

	// RVA: 0x3D5FEDC
	private object set_jarEntry(object value) { }

	// RVA: 0x3D5FEE4
	public object .ctor(object url) { }

	// RVA: 0x3D60C60
	private static object Normalize(object url) { }

	// RVA: 0x3D60E3C
	private static object IsJarUrl(object url) { }

	// RVA: 0x3D60C88
	public static object IsFileUrl(object url) { }

	// RVA: 0x3D60ED0
	private static object IsUnityUrl(object url) { }

	// RVA: 0x3D60F34
	private static object IsHttpOrHttpsUrl(object url) { }

	// RVA: 0x3D60FCC
	private static object .cctor() { }

}

// Namespace: com.pixui
public class PxWatch
{

	// Fields
	public object expire; // 0x8
	public object time; // 0xC

	// Properties
	public object isExpired { get; }

	// Methods

	// RVA: 0x3D4CB38
	public object .ctor(object expire) { }

	// RVA: 0x3D4B828
	public object get_isExpired() { }

	// RVA: 0x3D4BF60
	public object Start() { }

}

// Namespace: com.pixui
public class PxVideoFileOpenTask
{

	// Fields
	private object m_Path; // 0x18
	private object m_Mode; // 0x20
	private object m_ResultHandle; // 0x28

	// Methods

	// RVA: 0x3D61190
	public object .ctor(object id, object path, object mode) { }

	// RVA: 0x3D612AC
	public object GetHandle() { }

	// RVA: 0x3D612B4
	public override object Execute() { }

}

// Namespace: com.pixui
public sealed class FileOpenDelegate
{

	// Methods

	// RVA: 0x3D617A4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D6183C
	public virtual object Invoke(object path, object mode) { }

}

// Namespace: com.pixui
public sealed class FileCloseDelegate
{

	// Methods

	// RVA: 0x3D618D4
	public object .ctor(object object, object method) { }

	// RVA: 0x3D6196C
	public virtual object Invoke(object handle) { }

}

// Namespace: com.pixui
public sealed class FileReadDelegate
{

	// Methods

	// RVA: 0x3D61A30
	public object .ctor(object object, object method) { }

	// RVA: 0x3D61AC8
	public virtual object Invoke(object handle, object buf, object size) { }

}

// Namespace: com.pixui
public sealed class FileSeekDelegate
{

	// Methods

	// RVA: 0x3D61B8C
	public object .ctor(object object, object method) { }

	// RVA: 0x3D61C24
	public virtual object Invoke(object handle, object offset, object whence) { }

}

// Namespace: 
private enum ESeekType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object SEEK_SET;
	public const object SEEK_CUR;
	public const object SEEK_END;
	public const object AVSEEK_SIZE;
}

// Namespace: com.pixui
public class PxVideoManager
{

	// Fields
	private static object DEFAULT_BUFFER_SIZE; // 0x0
	private static object m_Buffer; // 0x8
	private static object m_TaskDict; // 0x10
	private static object m_HasTask; // 0x18
	private static object m_VideoStreamDict; // 0x20
	private static object m_ExternalHanldeList; // 0x28
	private static readonly object m_SyncObj; // 0x30
	private static object m_AutoVideoTaskID; // 0x38

	// Methods

	// RVA: 0x3D62F88
	public static object Init() { }

	// RVA: 0x3D630CC
	public static object Dispose() { }

	// RVA: 0x3D614CC
	public static object CreateVideoStream(object path) { }

	// RVA: 0x3D635A8
	public static object GetPointer(object funDelegate) { }

	// RVA: 0x3D63630
	private static object IsExternalHandle(object handle) { }

	// RVA: 0x3D636DC
	public static object ExecuteVideoPendingJob() { }

	// RVA: 0x3D63A54
	private static object GenerateAutoID() { }

	// RVA: 0x3D63AD8
	private static object GetBuffer(object size) { }

	// RVA: 0x3D61C98
	public static object FileOpen(object pathPtr, object mode) { }

	// RVA: 0x3D622B4
	public static object FileClose(object handle) { }

	// RVA: 0x3D626A8
	public static object FileRead(object handle, object buf, object size) { }

	// RVA: 0x3D62B28
	public static object FileSeek(object handle, object offset, object whence) { }

	// RVA: 0x3D63CFC
	private static object .cctor() { }

}

// Namespace: com.pixui
public class PxVideoStream
{

	// Fields
	private object m_FileStream; // 0x8
	private object m_Path; // 0x10
	private object m_Id; // 0x18
	private static object s_AutoId; // 0x0

	// Properties
	public object Id { get; }
	public object FileStream { get; }

	// Methods

	// RVA: 0x3D63D8C
	public object get_Id() { }

	// RVA: 0x3D63D94
	public object get_FileStream() { }

	// RVA: 0x3D634F4
	public object .ctor(object path) { }

	// RVA: 0x3D63408
	public object Dispose() { }

}

// Namespace: com.pixui
public enum PxVideoTaskType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object FileOpen;
}

// Namespace: com.pixui
public class PxVideoTask
{

	// Fields
	private object m_Id; // 0x8
	private object m_Type; // 0xC
	private object m_Event; // 0x10

	// Methods

	// RVA: 0x3D61224
	public object .ctor(object id, object type) { }

	// RVA: 0x3D63C60
	public object WaitForTaskDone() { }

	// RVA: 0x3D63D9C
	public virtual object Execute() { }

	// RVA: 0x3D616EC
	public object Done() { }

	// RVA: 0x3D63CAC
	public object CloseWaitEvent() { }

}

