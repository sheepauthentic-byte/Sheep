// Namespace: 
internal class <Module>
{
}

// Namespace: 
public class hoklog_category_base
{

	// Methods

	// RVA: 0xF964B0
	public object .ctor() { }

}

// Namespace: 
public class hoklog__default
{

	// Methods

	// RVA: 0xF964B8
	public object .ctor() { }

}

// Namespace: 
public class hoklog_game
{

	// Methods

	// RVA: 0xF968C0
	public object .ctor() { }

}

// Namespace: 
public class hoklog_network
{

	// Fields
	public object game; // 0x10

	// Methods

	// RVA: 0xF964E4
	public object .ctor() { }

}

// Namespace: 
public class hoklog_manager
{

	// Methods

	// RVA: 0xF968EC
	public object .ctor() { }

}

// Namespace: 
public class hoklog_portrait
{

	// Methods

	// RVA: 0xF96B2C
	public object .ctor() { }

}

// Namespace: 
public class hoklog_http_upload
{

	// Methods

	// RVA: 0xF96B58
	public object .ctor() { }

}

// Namespace: 
public class hoklog_ping
{

	// Methods

	// RVA: 0xF96B84
	public object .ctor() { }

}

// Namespace: 
public class hoklog_session
{

	// Methods

	// RVA: 0xF96BB0
	public object .ctor() { }

}

// Namespace: 
public class hoklog_inner
{

	// Fields
	public object portrait; // 0x10
	public object http_upload; // 0x18
	public object ping; // 0x20
	public object session; // 0x28

	// Methods

	// RVA: 0xF96918
	public object .ctor() { }

}

// Namespace: 
public class hoklog_settings
{

	// Methods

	// RVA: 0xF96BDC
	public object .ctor() { }

}

// Namespace: 
public class hoklog_log
{

	// Methods

	// RVA: 0xF96C08
	public object .ctor() { }

}

// Namespace: 
public class hoklog_get_file
{

	// Methods

	// RVA: 0xF96C34
	public object .ctor() { }

}

// Namespace: 
public class hoklog_custom
{

	// Fields
	public object settings; // 0x10
	public object log; // 0x18
	public object get_file; // 0x20

	// Methods

	// RVA: 0xF96A3C
	public object .ctor() { }

}

// Namespace: 
public class hoklog_module
{

	// Fields
	public object manager; // 0x10
	public object inner; // 0x18
	public object custom; // 0x20

	// Methods

	// RVA: 0xF96564
	public object .ctor() { }

}

// Namespace: 
public class hoklog_task
{

	// Methods

	// RVA: 0xF9663C
	public object .ctor() { }

}

// Namespace: 
public class hoklog_portrait
{

	// Methods

	// RVA: 0xF96668
	public object .ctor() { }

}

// Namespace: 
public class hoklog_nettools
{

	// Methods

	// RVA: 0xF96C60
	public object .ctor() { }

}

// Namespace: 
public class hoklog_profiler
{

	// Fields
	public object nettools; // 0x10

	// Methods

	// RVA: 0xF96694
	public object .ctor() { }

}

// Namespace: 
public class hoklog_logic
{

	// Methods

	// RVA: 0xF96C8C
	public object .ctor() { }

}

// Namespace: 
public class hoklog_game
{

	// Fields
	public object logic; // 0x10

	// Methods

	// RVA: 0xF96714
	public object .ctor() { }

}

// Namespace: 
public class hoklog_update
{

	// Methods

	// RVA: 0xF96CB8
	public object .ctor() { }

}

// Namespace: 
public class hoklog_version
{

	// Fields
	public object update; // 0x10

	// Methods

	// RVA: 0xF96794
	public object .ctor() { }

}

// Namespace: 
public class hoklog_pandora
{

	// Methods

	// RVA: 0xF96CE4
	public object .ctor() { }

}

// Namespace: 
public class hoklog_sdk
{

	// Fields
	public object pandora; // 0x10

	// Methods

	// RVA: 0xF96814
	public object .ctor() { }

}

// Namespace: 
public class hoklog_console
{

	// Methods

	// RVA: 0xF96894
	public object .ctor() { }

}

// Namespace: 
public class hoklog_category_root
{

	// Fields
	public object _default; // 0x8
	public object network; // 0x10
	public object module; // 0x18
	public object task; // 0x20
	public object portrait; // 0x28
	public object profiler; // 0x30
	public object game; // 0x38
	public object version; // 0x40
	public object sdk; // 0x48
	public object console; // 0x50

	// Methods

	// RVA: 0xF944A4
	public object .ctor() { }

}

// Namespace: 
public class hoklog
{

	// Fields
	private static readonly object category_names; // 0x0
	private static readonly object categories_count; // 0x8
	public readonly object cat; // 0x38

	// Methods

	// RVA: 0xF9443C
	public object .ctor() { }

	// RVA: 0xF94870
	private object .ctor(object child_inst) { }

	// RVA: 0xF948E0
	public static object create_log(object name, object config) { }

	// RVA: 0xF94C04
	public static object get_log_by_name(object log_name) { }

	// RVA: 0xF94E84
	public object verbose(object category, object log_format_content) { }

	// RVA: 0xF94E94
	public object debug(object category, object log_format_content) { }

	// RVA: 0xF94EA4
	public object info(object category, object log_format_content) { }

	// RVA: 0xF94EB4
	public object warning(object category, object log_format_content) { }

	// RVA: 0xF94EC4
	public object error(object category, object log_format_content) { }

	// RVA: 0xF94ED4
	public object fatal(object category, object log_format_content) { }

	// RVA: 0xF94EE4
	public object verbose(object category, object log_format_content, object p1) { }

	// RVA: 0xF94EF8
	public object debug(object category, object log_format_content, object p1) { }

	// RVA: 0xF94F0C
	public object info(object category, object log_format_content, object p1) { }

	// RVA: 0xF94F20
	public object warning(object category, object log_format_content, object p1) { }

	// RVA: 0xF94F34
	public object error(object category, object log_format_content, object p1) { }

	// RVA: 0xF94F48
	public object fatal(object category, object log_format_content, object p1) { }

	// RVA: 0xF94F5C
	public object verbose(object category, object log_format_content, object p1, object p2) { }

	// RVA: 0xF94F74
	public object debug(object category, object log_format_content, object p1, object p2) { }

	// RVA: 0xF94F8C
	public object info(object category, object log_format_content, object p1, object p2) { }

	// RVA: 0xF94FA4
	public object warning(object category, object log_format_content, object p1, object p2) { }

	// RVA: 0xF94FBC
	public object error(object category, object log_format_content, object p1, object p2) { }

	// RVA: 0xF94FD4
	public object fatal(object category, object log_format_content, object p1, object p2) { }

	// RVA: 0xF94FEC
	public object verbose(object category, object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xF95008
	public object debug(object category, object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xF95024
	public object info(object category, object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xF95040
	public object warning(object category, object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xF9505C
	public object error(object category, object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xF95078
	public object fatal(object category, object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xF95094
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF950CC
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF95104
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9513C
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF95174
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF951AC
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF951E4
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF95220
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9525C
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF95298
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF952D4
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF95310
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9534C
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF95390
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF953D4
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF95418
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9545C
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF954A0
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF954E4
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF95528
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9556C
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF955B0
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF955F4
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF95638
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9567C
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF956C8
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF95714
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF95760
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF957AC
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF957F8
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF95844
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xF95894
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xF958E4
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xF95934
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xF95984
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xF959D4
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xF95A24
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xF95A74
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xF95AC4
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xF95B14
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xF95B64
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xF95BB4
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xF95C04
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xF95C58
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xF95CAC
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xF95D00
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xF95D54
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xF95DA8
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xF95DFC
	public object verbose(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xF95E54
	public object debug(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xF95EAC
	public object info(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xF95F04
	public object warning(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xF95F5C
	public object error(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xF95FB4
	public object fatal(object category, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xF9600C
	public object verbose(object category, object log_format_content, object args) { }

	// RVA: 0xF96020
	public object debug(object category, object log_format_content, object args) { }

	// RVA: 0xF96034
	public object info(object category, object log_format_content, object args) { }

	// RVA: 0xF96048
	public object warning(object category, object log_format_content, object args) { }

	// RVA: 0xF9605C
	public object error(object category, object log_format_content, object args) { }

	// RVA: 0xF96070
	public object fatal(object category, object log_format_content, object args) { }

	// RVA: 0xF96084
	private static object .cctor() { }

}

// Namespace: 
public enum enum_Log_switch
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object _default;
	public const object _compr;
	public const object _nolog;
	public const object _compr_debug;
	public const object _compr_all_trace;
}

// Namespace: 
public class bqlog
{

	// Fields
	public static object _nolog_config; // 0x0
	public static object _def_config; // 0x8
	public static object _com_config; // 0x10
	public static object _com_config_debug; // 0x18
	public static object _com_config_all_trace; // 0x20
	public static object _console_config; // 0x28
	public static object _com_config_custom; // 0x30
	private static object fmttime; // 0x38
	private static object fmtlog; // 0x40
	public static object SGameLog; // 0x48
	private static object enlevel; // 0x50
	private static object stack_mask; // 0x54

	// Properties
	public static object stack { get; set; }

	// Methods

	// RVA: 0xF96D10
	public static object ToTimeString() { }

	// RVA: 0xF96E44
	public static object get_log_switch() { }

	// RVA: 0xF96EC0
	public static object set_switch(object level) { }

	// RVA: 0xF97204
	public static object set_switch(object level_string) { }

	// RVA: 0xF9737C
	public static object set_stack(object value) { }

	// RVA: 0xF97408
	public static object get_stack() { }

	// RVA: 0xF97484
	public object .ctor() { }

	// RVA: 0xF9748C
	private static object .cctor() { }

}

// Namespace: 
public enum eLog
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Msg;
	public const object UIProfiler;
	public const object Exception;
	public const object Misc;
	public const object Error;
	public const object TimeProfiler;
	public const object VersionUpdate;
	public const object NewErrorCode;
	public const object AppManager;
	public const object Network;
	public const object Max;
}

// Namespace: 
public enum enLogType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Debug;
	public const object Warning;
	public const object Error;
	public const object Exception;
}

// Namespace: 
public sealed class ILReportException
{

	// Methods

	// RVA: 0xFA06F4
	public object .ctor(object object, object method) { }

	// RVA: 0xFA0800
	public virtual object Invoke(object e, object message) { }

	// RVA: 0xFA0814
	public virtual object BeginInvoke(object e, object message, object callback, object object) { }

	// RVA: 0xFA0870
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public class SGameLog
{

	// Fields
	public static object FrameCount; // 0x0
	public static object iLReportException; // 0x8

	// Methods

	// RVA: 0xF976DC
	public static object ContextFlowControl_ForceConsoleAndWrite2File(object logType, object msg, object logFile) { }

	// RVA: 0xF97774
	public static object Exception(object e, object extraMsg, object context) { }

	// RVA: 0xF978B0
	public static object Assert(object InCondition) { }

	// RVA: 0xF97A58
	public static object Assert(object InCondition, object InFormat) { }

	// RVA: 0xF978BC
	public static object Assert(object InCondition, object InFormat, object InParameters) { }

	// RVA: 0xF97AF8
	public static object CustomLog(object str, object InParameters) { }

	// RVA: 0xF97B94
	public static object verbose(object category, object format, object args) { }

	// RVA: 0xF97C40
	public static object verbose(object category, object msg) { }

	// RVA: 0xF97CE4
	public static object verbose(object category, object msg, object p1) { }

	// RVA: 0xF97DAC
	public static object verbose(object category, object msg, object p1, object p2) { }

	// RVA: 0xF97E84
	public static object verbose(object category, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF97F74
	public static object verbose(object category, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF98074
	public static object verbose(object category, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9818C
	public static object verbose(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF982B8
	public static object verbose(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF983F4
	public static object verbose(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF98540
	public static object debug(object category, object format, object args) { }

	// RVA: 0xF985EC
	public static object debug(object category, object msg) { }

	// RVA: 0xF98690
	public static object debug(object category, object msg, object p1) { }

	// RVA: 0xF98758
	public static object debug(object category, object msg, object p1, object p2) { }

	// RVA: 0xF98830
	public static object debug(object category, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF98920
	public static object debug(object category, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF98A20
	public static object debug(object category, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF98B38
	public static object debug(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF98C64
	public static object debug(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF98DA0
	public static object debug(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF98EEC
	public static object Debug(object msg) { }

	// RVA: 0xF98F84
	public static object DebugFormat(object format, object args) { }

	// RVA: 0xF99044
	public static object info(object category, object format, object args) { }

	// RVA: 0xF990F0
	public static object info(object category, object msg) { }

	// RVA: 0xF99194
	public static object info(object category, object msg, object p1) { }

	// RVA: 0xF9925C
	public static object info(object category, object msg, object p1, object p2) { }

	// RVA: 0xF99334
	public static object info(object category, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF99424
	public static object info(object category, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF99524
	public static object info(object category, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9963C
	public static object info(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF99768
	public static object info(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF998A4
	public static object info(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF999F0
	public static object warning(object msg) { }

	// RVA: 0xF99A88
	public static object warning(object category, object format, object args) { }

	// RVA: 0xF99B34
	public static object warning(object category, object msg) { }

	// RVA: 0xF99BD8
	public static object warning(object category, object msg, object p1) { }

	// RVA: 0xF99CA0
	public static object warning(object category, object msg, object p1, object p2) { }

	// RVA: 0xF99D78
	public static object warning(object category, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF99E68
	public static object warning(object category, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF99F68
	public static object warning(object category, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9A080
	public static object warning(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9A1AC
	public static object warning(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9A2E8
	public static object warning(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF97A60
	public static object Warning(object msg) { }

	// RVA: 0xF9A434
	public static object WarningFormat(object msg, object p1) { }

	// RVA: 0xF9A4E8
	public static object WarningFormat(object context, object msg, object p1) { }

	// RVA: 0xF9A660
	public static object WarningFormat(object logFile, object msg, object p1) { }

	// RVA: 0xF9A714
	public static object WarningFormat(object msg, object p1, object p2) { }

	// RVA: 0xF9A7E0
	public static object WarningFormat(object context, object msg, object p1, object p2) { }

	// RVA: 0xF9A974
	public static object WarningFormat(object logFile, object msg, object p1, object p2) { }

	// RVA: 0xF9AA40
	public static object WarningFormat(object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9AB1C
	public static object WarningFormat(object context, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9ACD4
	public static object WarningFormat(object logFile, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9ADB0
	public static object WarningFormat(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9AEA4
	public static object WarningFormat(object context, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9B078
	public static object WarningFormat(object logFile, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9B16C
	public static object WarningFormat(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9B270
	public static object WarningFormat(object context, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9B468
	public static object WarningFormat(object logFile, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9B56C
	public static object WarningFormat(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9B688
	public static object WarningFormat(object context, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9B8A0
	public static object WarningFormat(object logFile, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9B9BC
	public static object WarningFormat(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9BAE8
	public static object WarningFormat(object context, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9BD1C
	public static object WarningFormat(object logFile, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9BE48
	public static object error(object category, object format, object args) { }

	// RVA: 0xF9BEF4
	public static object error(object category, object msg) { }

	// RVA: 0xF9BF98
	public static object error(object category, object msg, object p1) { }

	// RVA: 0xF9C060
	public static object error(object category, object msg, object p1, object p2) { }

	// RVA: 0xF9C138
	public static object error(object category, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9C228
	public static object error(object category, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9C328
	public static object error(object category, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9C440
	public static object error(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9C56C
	public static object error(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9C6A8
	public static object error(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF9C7F4
	public static object error_ed(object category, object format, object args) { }

	// RVA: 0xF9C8A0
	public static object error_ed(object msg) { }

	// RVA: 0xF9C938
	public static object error_ed(object category, object msg) { }

	// RVA: 0xF9C9DC
	public static object error_ed(object msg, object p1) { }

	// RVA: 0xF9CA90
	public static object error_ed(object category, object msg, object p1) { }

	// RVA: 0xF9CB58
	public static object error_ed(object category, object msg, object p1, object p2) { }

	// RVA: 0xF9CC30
	public static object error_ed(object msg, object p1, object p2) { }

	// RVA: 0xF9CCFC
	public static object error_ed(object category, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9CDEC
	public static object error_ed(object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9CEC8
	public static object error_ed(object category, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9CFC8
	public static object error_ed(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9D0BC
	public static object error_ed(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9D1C0
	public static object error_ed(object category, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9D2D8
	public static object error_ed(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9D3F4
	public static object error_ed(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9D520
	public static object error_ed(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9D64C
	public static object error_ed(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9D788
	public static object error_ed(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF9D8C8
	public static object error_ed(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xF9DA14
	public static object Error(object msg) { }

	// RVA: 0xF9DAAC
	public static object Error(object msg, object context) { }

	// RVA: 0xF9DB84
	public static object ErrorEditor(object msg, object args) { }

	// RVA: 0xF9DC1C
	public static object ErrorFormat(object msg) { }

	// RVA: 0xF9DCB4
	public static object ErrorFormat(object context, object msg) { }

	// RVA: 0xF9DE0C
	public static object ErrorFormat(object logFile, object msg) { }

	// RVA: 0xF9DEA4
	public static object ErrorFormat(object content, object args) { }

	// RVA: 0xF9DF64
	public static object ErrorFormat(object msg, object p1) { }

	// RVA: 0xF9E018
	public static object ErrorFormat(object context, object msg, object p1) { }

	// RVA: 0xF9E190
	public static object ErrorFormat(object logFile, object msg, object p1) { }

	// RVA: 0xF9E244
	public static object ErrorFormat(object msg, object p1, object p2) { }

	// RVA: 0xF9E310
	public static object ErrorFormat(object context, object msg, object p1, object p2) { }

	// RVA: 0xF9E4A4
	public static object ErrorFormat(object logFile, object msg, object p1, object p2) { }

	// RVA: 0xF9E570
	public static object ErrorFormat(object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9E64C
	public static object ErrorFormat(object context, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9E804
	public static object ErrorFormat(object logFile, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9E8E0
	public static object ErrorFormat(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9E9D4
	public static object ErrorFormat(object context, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9EBA8
	public static object ErrorFormat(object logFile, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9EC9C
	public static object ErrorFormat(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9EDA0
	public static object ErrorFormat(object context, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9EF98
	public static object ErrorFormat(object logFile, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xF9F09C
	public static object ErrorFormat(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9F1B8
	public static object ErrorFormat(object context, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9F3D0
	public static object ErrorFormat(object logFile, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xF9F4EC
	public static object ErrorFormat(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9F618
	public static object ErrorFormat(object context, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9F84C
	public static object ErrorFormat(object logFile, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xF9F978
	public static object ErrorInEditor(object msg) { }

	// RVA: 0xF9F97C
	public static object Exception(object content, object args) { }

	// RVA: 0xF9FA3C
	public static object fatal(object category, object format, object args) { }

	// RVA: 0xF9FAE8
	public static object fatal(object category, object msg) { }

	// RVA: 0xF9FB8C
	public static object fatal(object category, object msg, object p1) { }

	// RVA: 0xF9FC54
	public static object fatal(object category, object msg, object p1, object p2) { }

	// RVA: 0xF9FD2C
	public static object fatal(object category, object msg, object p1, object p2, object p3) { }

	// RVA: 0xF9FE1C
	public static object fatal(object category, object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xF9FF1C
	public static object fatal(object category, object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFA0034
	public static object fatal(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFA0160
	public static object fatal(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFA029C
	public static object fatal(object category, object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFA03E8
	public object .ctor() { }

}

// Namespace: 
public static class VersionUpdateLog
{

	// Methods

	// RVA: 0xFA087C
	private static object GetCategory() { }

	// RVA: 0xFA092C
	public static object verbose(object format, object args) { }

	// RVA: 0xFA0A84
	public static object verbose(object msg) { }

	// RVA: 0xFA0BAC
	public static object verbose(object msg, object p1) { }

	// RVA: 0xFA0CF8
	public static object verbose(object msg, object p1, object p2) { }

	// RVA: 0xFA0E54
	public static object verbose(object msg, object p1, object p2, object p3) { }

	// RVA: 0xFA0FC8
	public static object verbose(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFA114C
	public static object verbose(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFA12E8
	public static object verbose(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFA1498
	public static object verbose(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFA1658
	public static object verbose(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFA182C
	public static object debug(object format, object args) { }

	// RVA: 0xFA1984
	public static object debug(object msg) { }

	// RVA: 0xFA1AAC
	public static object debug(object msg, object p1) { }

	// RVA: 0xFA1BF8
	public static object debug(object msg, object p1, object p2) { }

	// RVA: 0xFA1D54
	public static object debug(object msg, object p1, object p2, object p3) { }

	// RVA: 0xFA1EC8
	public static object debug(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFA204C
	public static object debug(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFA21E8
	public static object debug(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFA2398
	public static object debug(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFA2558
	public static object debug(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFA272C
	public static object info(object format, object args) { }

	// RVA: 0xFA2884
	public static object info(object msg) { }

	// RVA: 0xFA29AC
	public static object info(object msg, object p1) { }

	// RVA: 0xFA2AF8
	public static object info(object msg, object p1, object p2) { }

	// RVA: 0xFA2C54
	public static object info(object msg, object p1, object p2, object p3) { }

	// RVA: 0xFA2DC8
	public static object info(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFA2F4C
	public static object info(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFA30E8
	public static object info(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFA3298
	public static object info(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFA3458
	public static object info(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFA362C
	public static object warning(object format, object args) { }

	// RVA: 0xFA3784
	public static object warning(object msg) { }

	// RVA: 0xFA38AC
	public static object warning(object msg, object p1) { }

	// RVA: 0xFA39F8
	public static object warning(object msg, object p1, object p2) { }

	// RVA: 0xFA3B54
	public static object warning(object msg, object p1, object p2, object p3) { }

	// RVA: 0xFA3CC8
	public static object warning(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFA3E4C
	public static object warning(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFA3FE8
	public static object warning(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFA4198
	public static object warning(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFA4358
	public static object warning(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFA452C
	public static object error(object format, object args) { }

	// RVA: 0xFA4684
	public static object error(object msg) { }

	// RVA: 0xFA47AC
	public static object error(object msg, object p1) { }

	// RVA: 0xFA48F8
	public static object error(object msg, object p1, object p2) { }

	// RVA: 0xFA4A54
	public static object error(object msg, object p1, object p2, object p3) { }

	// RVA: 0xFA4BC8
	public static object error(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFA4D4C
	public static object error(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFA4EE8
	public static object error(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFA5098
	public static object error(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFA5258
	public static object error(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFA542C
	public static object fatal(object format, object args) { }

	// RVA: 0xFA5584
	public static object fatal(object msg) { }

	// RVA: 0xFA56AC
	public static object fatal(object msg, object p1) { }

	// RVA: 0xFA57F8
	public static object fatal(object msg, object p1, object p2) { }

	// RVA: 0xFA5954
	public static object fatal(object msg, object p1, object p2, object p3) { }

	// RVA: 0xFA5AC8
	public static object fatal(object msg, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFA5C4C
	public static object fatal(object msg, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFA5DE8
	public static object fatal(object msg, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFA5F98
	public static object fatal(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFA6158
	public static object fatal(object msg, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

}

// Namespace: 
private enum enum_use_high_performance_str_cpy
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object pendding;
	public const object can_use;
	public const object can_not_use;
}

// Namespace: 
internal class utils
{

	// Fields
	private static object can_use_high_performance_str_cpy_; // 0x0

	// Properties
	private static object can_use_high_performance_str_cpy { get; }

	// Methods

	// RVA: 0xFA632C
	public static object align4(object n) { }

	// RVA: 0xFA633C
	public static object align4(object n) { }

	// RVA: 0xFA634C
	public static object memcpy(object dest, object src, object len) { }

	// RVA: 0xFA63C4
	private static object get_can_use_high_performance_str_cpy() { }

	// RVA: 0xFA64E4
	public static object str_memcpy(object dest, object src_str, object len) { }

	// RVA: 0xFA65A4
	private static object str_memcpy_low_performance(object dest, object src_str, object len) { }

	// RVA: 0xFA660C
	private static object str_memcpy_high_performance(object dest, object src_str, object len) { }

	// RVA: 0xFA66CC
	public object .ctor() { }

}

// Namespace: 
private struct MonoScriptData
{

	// Fields
	public object FilePathsData; // 0xFFFFFFFFFFFFFFF8
	public object TypesData; // 0x0
	public object TotalTypes; // 0x8
	public object TotalFiles; // 0xC
	public object IsEditorOnly; // 0x10
}

// Namespace: 
internal class UnitySourceGeneratedAssemblyMonoScriptTypes_v1
{

	// Methods

	// RVA: 0xFA66D4
	private static object Get() { }

	// RVA: 0xFA67A4
	public object .ctor() { }

}

// Namespace: dc
public enum eLog
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Msg;
	public const object UIProfiler;
	public const object Exception;
	public const object Misc;
	public const object Error;
	public const object TimeProfiler;
	public const object Report;
	public const object Max;
}

// Namespace: 
public sealed class RegistFunction
{

	// Methods

	// RVA: 0xFAA868
	public object .ctor(object object, object method) { }

	// RVA: 0xFAA900
	public virtual object Invoke(object slog, object msg) { }

	// RVA: 0xFAA914
	public virtual object BeginInvoke(object slog, object msg, object callback, object object) { }

	// RVA: 0xFAA9D4
	public virtual object EndInvoke(object result) { }

}

// Namespace: dc
public class Log
{

	// Fields
	public static object UseBqLog; // 0x0
	private static object FileReportSystem; // 0x8
	private static object root_path; // 0x10
	private static object m_ThreadListLock; // 0x18
	private static object MsgFun; // 0x20
	public static object LogOutput; // 0x28
	public static object FrameCount; // 0x2C
	public static object DeltaTime; // 0x30
	private static object m_sList; // 0x38
	public static object bEnable; // 0x40
	private static object BootObj; // 0x48
	public static object LogLv; // 0x50
	public static object IsShow; // 0x54

	// Methods

	// RVA: 0xFA68E0
	private static object Console(object level, object log_format_content) { }

	// RVA: 0xFA69F4
	private static object Console(object log_format_content) { }

	// RVA: 0xFA6B04
	private static object Assert(object condition, object info) { }

	// RVA: 0xFA6C44
	private static object logEnabled() { }

	// RVA: 0xFA6DB0
	private static object Debug(object src, object args) { }

	// RVA: 0xFA74DC
	private static object Info(object src, object args) { }

	// RVA: 0xFA7700
	private static object Info(object slog, object src, object args) { }

	// RVA: 0xFA7804
	private static object Warning(object slog, object src, object args) { }

	// RVA: 0xFA78F8
	private static object Warning(object src, object args) { }

	// RVA: 0xFA79EC
	private static object Error(object slog, object src, object args) { }

	// RVA: 0xFA7AF0
	private static object Error(object src, object args) { }

	// RVA: 0xFA7BE4
	private static object Exception(object ex) { }

	// RVA: 0xFA7DAC
	private static object Exception(object src, object args) { }

	// RVA: 0xFA6E9C
	private static object FormatString(object lv, object el, object show_frame, object show_delta, object src, object args) { }

	// RVA: 0xFA75D0
	private static object WriteToFile(object el) { }

	// RVA: 0xFA7E70
	public static object CreateDirectoryRecursive(object path) { }

	// RVA: 0xFA8030
	private static object CreateDirectory(object path) { }

	// RVA: 0xFA8124
	private static object InitReportDir() { }

	// RVA: 0xFA8460
	public static object ReportString(object type, object src, object args) { }

	// RVA: 0xFA886C
	private static object ReportLimit() { }

	// RVA: 0xFA89C4
	public static object ReportFile(object in_path, object is_full_path, object delete) { }

	// RVA: 0xFA8A7C
	public static object ReportFileWithoutLimit(object in_path, object is_full_path, object delete) { }

	// RVA: 0xFA8D40
	public static object ReportStartupFile(object content) { }

	// RVA: 0xFA91C0
	public static object ReportData(object path, object data, object length) { }

	// RVA: 0xFA9A60
	public static object add_MsgFun(object value) { }

	// RVA: 0xFA9B50
	public static object remove_MsgFun(object value) { }

	// RVA: 0xFA9C40
	public static object Init() { }

	// RVA: 0xFAA01C
	public static object ShowLog(object show, object open_src) { }

	// RVA: 0xFA9E10
	public static object InitBqLogConfig() { }

	// RVA: 0xFAA620
	public static object SetLevel(object lv) { }

	// RVA: 0xFAA6AC
	public object .ctor() { }

	// RVA: 0xFAA6B4
	private static object .cctor() { }

}

// Namespace: 
public class ReportData
{

	// Fields
	public object Path; // 0x8
	public object Data; // 0x10
	public object Delete; // 0x18

	// Methods

	// RVA: 0xFAA9E0
	public object .ctor() { }

}

// Namespace: dc
public class File_Report_System
{

	// Fields
	private object run; // 0x8
	private object exit_tick; // 0x10
	private object ReportDataList; // 0x18
	private object TaskThread; // 0x20

	// Methods

	// RVA: 0xFA94CC
	public object Report(object path, object data, object length) { }

	// RVA: 0xFAA9E8
	public object Update() { }

	// RVA: 0xFA83E0
	public object .ctor() { }

}

// Namespace: dc
public class IntUtils
{

	// Methods

	// RVA: 0xFAAEF4
	public static object HasFlag(object a, object b) { }

	// RVA: 0xFAAF00
	public static object InsertFlag(object a, object b) { }

	// RVA: 0xFAAF14
	public static object RemoveFlag(object a, object b) { }

	// RVA: 0xFAAF28
	public static object ToHexString(object value) { }

	// RVA: 0xFAB004
	public static object upper_power_of_two(object v) { }

	// RVA: 0xFAB024
	public static object FloatEqual(object fFirst, object fSecond, object fOffset) { }

	// RVA: 0xFAB034
	public static object FloatEqualZERO(object fValue, object fOffset) { }

	// RVA: 0xFAB044
	public object .ctor() { }

}

// Namespace: dc
public enum eLogOutputType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Console;
	public const object File;
}

// Namespace: dc
public class Log2FileScript
{

	// Fields
	private object m_IsWrite2File; // 0x18
	private object m_OtherWriteToFile; // 0x19
	private object m_WriteToConsole; // 0x1A
	private object m_LogCountLimit; // 0x1C
	private object m_LogSizeLimit; // 0x20
	private object m_Log; // 0x24
	private object m_Warning; // 0x25
	private object m_Error; // 0x26
	private object m_Exceptioin; // 0x27
	private object m_LogLevel; // 0x28
	private object m_Log2File; // 0x30

	// Properties
	public object IsWrite2File { get; set; }

	// Methods

	// RVA: 0xFAB04C
	private object Awake() { }

	// RVA: 0xFAB9DC
	private object OnDestroy() { }

	// RVA: 0xFABBEC
	private object Update() { }

	// RVA: 0xFABC80
	private object OnReceivedLog(object logString, object stackTrace, object type) { }

	// RVA: 0xFAC08C
	private object OnReceivedLog(object type, object logString) { }

	// RVA: 0xFAC0AC
	private object HandleLog(object objs) { }

	// RVA: 0xFAC5A8
	public object get_IsWrite2File() { }

	// RVA: 0xFAC5B0
	public object set_IsWrite2File(object value) { }

	// RVA: 0xFAC5C4
	public object .ctor() { }

}

// Namespace: dc
public class Log2FileThread
{

	// Fields
	private object m_Enable; // 0x8
	private object m_OutPath; // 0x10
	private object root_path; // 0x18
	private object m_Time; // 0x20
	private object m_Disposed; // 0x28
	private object m_TaskThread; // 0x30
	private object m_ThreadListLock; // 0x38
	private object m_AppendList; // 0x40
	private object m_RunList; // 0x48
	private object m_LogLimit; // 0x50
	private object m_LogSizeLimit; // 0x54

	// Methods

	// RVA: 0xFAB9D0
	public object SetLimit(object count, object size) { }

	// RVA: 0xFAB398
	public object Setup() { }

	// RVA: 0xFABBB4
	public object Dispose() { }

	// RVA: 0xFAC250
	public object Push(object msg) { }

	// RVA: 0xFABCFC
	public object Push(object slog, object msg) { }

	// RVA: 0xFAC5EC
	private object Tick() { }

	// RVA: 0xFAB2C8
	public object .ctor() { }

}

// Namespace: dc
public enum eLogLevel
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object LV_DEBUG;
	public const object LV_INFO;
	public const object LV_WARNING;
	public const object LV_ERROR;
	public const object LV_EXCEPTION;
	public const object LV_BATTLE;
	public const object LV_MAX;
}

// Namespace: bq
public static class BqConfig
{

	// Fields
	public static object BqHost; // 0x0
	public static object BqPort; // 0x8
	public static readonly object BqHosts; // 0x10
	public static readonly object BqPorts; // 0x18
	public static readonly object BqNotes; // 0x20

	// Methods

	// RVA: 0xFACCA4
	private static object .cctor() { }

}

// Namespace: bq
public class CCSAdapter
{

	// Fields
	private object m_inited; // 0x8

	// Methods

	// RVA: 0xFACEF0
	public object Init() { }

	// RVA: 0xFAD104
	public object Init(object hosts, object connect_interval) { }

	// RVA: 0xFADA4C
	public object Uninit() { }

	// RVA: 0xFADCCC
	public static object GetHost() { }

	// RVA: 0xFAD078
	public static object GetPort() { }

	// RVA: 0xFADD48
	public object .ctor() { }

}

// Namespace: bq
public class CCSUpdater
{

	// Fields
	private static object m_instance; // 0x0
	private object m_updateJobs; // 0x18
	private object m_updateInversal; // 0x20
	private object m_updateCount; // 0x24

	// Methods

	// RVA: 0xFAD8C4
	public static object Init() { }

	// RVA: 0xFADBA8
	public static object Uninit() { }

	// RVA: 0xFADDEC
	public static object AddUpdateJob(object callback) { }

	// RVA: 0xFADF28
	public static object RemoveUpdateJob(object callback) { }

	// RVA: 0xFAE068
	private object OnApplicationPause(object pause) { }

	// RVA: 0xFAE0F0
	private object Update() { }

	// RVA: 0xFAE388
	private object OnApplicationQuit() { }

	// RVA: 0xFAE4C0
	public object .ctor() { }

}

// Namespace: bq
public class MGUISingleton<T0>
{

	// Fields
	private static object _instance; // 0x0
	private object m_cacheUseGUILayout; // 0x0

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: -1
	public static object get_instance() { }

	// RVA: -1
	public static object Open() { }

	// RVA: -1
	public static object Close() { }

	// RVA: -1
	public object ToggleUseGUILayout(object on) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: bq
public class Singleton<T0>
{

	// Fields
	private static object s_lock; // 0x0
	private static object s_instance; // 0x0

	// Properties
	public static object instance { get; }

	// Methods

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	public static object get_instance() { }

	// RVA: -1
	public static object CreateInstance() { }

	// RVA: -1
	protected virtual object OnInit() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: bq
internal class custom_module_execute_gm
{

	// Methods

	// RVA: 0xFAE4D0
	public override object get_name() { }

	// RVA: 0xFAE514
	public override object wether_to_accept(object cmd) { }

	// RVA: 0xFAE56C
	public override object on_execute_task(object task_id, object cmd, object cmd_data, object error_info) { }

	// RVA: 0xFAE7AC
	public object .ctor() { }

}

// Namespace: 
private enum pref_type
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object type_string;
	public const object type_int;
	public const object type_float;
	public const object count;
}

// Namespace: 
private class PrefData
{

	// Fields
	public object key; // 0x8
	public object type; // 0x10
	public object data; // 0x18

	// Methods

	// RVA: 0xFAF6C0
	public object .ctor() { }

}

// Namespace: 
private class PrefsDataWrapper
{

	// Fields
	public object Items; // 0x8

	// Methods

	// RVA: 0xFAF6C8
	public object .ctor() { }

}

// Namespace: 
private class RemoveKeysWrapper
{

	// Fields
	public object Items; // 0x8

	// Methods

	// RVA: 0xFAF6D0
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_0
{

	// Fields
	public object key; // 0x8

	// Methods

	// RVA: 0xFAF328
	public object .ctor() { }

	// RVA: 0xFAF6D8
	internal object <remove_prefs>b__0() { }

}

// Namespace: 
private sealed class <>c__DisplayClass12_0
{

	// Fields
	public object cmd_data; // 0x8

	// Methods

	// RVA: 0xFAF330
	public object .ctor() { }

	// RVA: 0xFAF6E4
	internal object <clear_prefs>b__0() { }

}

// Namespace: 
private sealed class <>c__DisplayClass9_0
{

	// Fields
	public object data; // 0x8
	public object <>4__this; // 0x10

	// Methods

	// RVA: 0xFAF320
	public object .ctor() { }

	// RVA: 0xFAF7B4
	internal object <add_prefs>b__0() { }

}

// Namespace: bq
public class custom_module_playerprefs
{

	// Fields
	private const object cmd_add_prefs;
	private const object cmd_remove_prefs;
	private const object cmd_clear_prefs;

	// Methods

	// RVA: 0xFAE850
	public override object get_name() { }

	// RVA: 0xFAE894
	public override object wether_to_accept(object cmd) { }

	// RVA: 0xFAE950
	public override object on_execute_task(object task_id, object cmd, object cmd_data, object error_info) { }

	// RVA: 0xFAEB34
	private object add_prefs(object cmd_data) { }

	// RVA: 0xFAEE88
	private object remove_prefs(object cmd_data) { }

	// RVA: 0xFAF25C
	private object clear_prefs(object cmd_data) { }

	// RVA: 0xFAF338
	private object add_prefs(object type, object key, object data_str) { }

	// RVA: 0xFAF61C
	public object .ctor() { }

}

// Namespace: bq
public static class PortraitAdapter
{

	// Methods

	// RVA: 0xFAD428
	public static object UploadBasic() { }

}

// Namespace: bq
public class CategoryNode
{

	// Fields
	public object mHash; // 0x8
	public object mIndex; // 0xC
	public object mCate; // 0x10
	public object mDeep; // 0x18
	public object mNoFilter; // 0x1C
	public object mNodes; // 0x20

	// Methods

	// RVA: 0xFAF7F8
	public object Draw(object cset, object parentCate, object style, object size) { }

	// RVA: 0xFAFBFC
	public object SetFilter(object cset, object check) { }

	// RVA: 0xFAFDA4
	public object HaveNoFilter() { }

	// RVA: 0xFAFF18
	public object IsFilter(object log) { }

	// RVA: 0xFB00E4
	public object .ctor() { }

}

// Namespace: bq
public class CategorySetting
{

	// Fields
	public object mCategoryRoot; // 0x8
	public object mIsFilter; // 0x10
	public object mAllHashs; // 0x18
	public object mAllCategorys; // 0x20
	public object mLogger; // 0x28

	// Methods

	// RVA: 0xFB0188
	public object Initialize(object logger_) { }

	// RVA: 0xFB0984
	public object get_all_hashes() { }

	// RVA: 0xFB09E0
	public object get_all_categories() { }

	// RVA: 0xFB05A8
	public object FindNode(object cate, object parent) { }

	// RVA: 0xFB0714
	public object AddNode(object index, object cate, object parent) { }

	// RVA: 0xFB0A3C
	public object HaveNoFilter() { }

	// RVA: 0xFB0A4C
	public object IsNoFilter(object log) { }

	// RVA: 0xFB0B08
	public object Draw(object style, object size) { }

	// RVA: 0xFB0C80
	public object .ctor() { }

}

// Namespace: bq
public class CategoryMgr
{

	// Fields
	public object mCateSetList; // 0x8

	// Methods

	// RVA: 0xFB0D90
	public object Initialize() { }

	// RVA: 0xFB0DEC
	public object GetLoggerName(object logger_id) { }

	// RVA: 0xFB0EC8
	public object HaveNoFilter() { }

	// RVA: 0xFB1074
	public object IsNoFilter(object log) { }

	// RVA: 0xFB113C
	public object Draw(object style, object size) { }

	// RVA: 0xFB13EC
	public object .ctor() { }

}

// Namespace: bq
public class CtrlCheck
{

	// Fields
	private object mLastClickTime; // 0x8
	private object mNumOfCircleToShow; // 0xC
	private object mGestureLength; // 0x10
	private object mGestureCount; // 0x14
	private object mGestureDetector; // 0x18
	private object mGestureSum; // 0x20
	public object mDownPos; // 0x28
	private object mIsDown; // 0x30
	private object mMousePosition; // 0x34

	// Methods

	// RVA: 0xFB14AC
	public object IsDwon() { }

	// RVA: 0xFB14B4
	public object IsDoubleClickDone() { }

	// RVA: 0xFB167C
	public object IsGestureDone() { }

	// RVA: 0xFB1EA8
	public object IsMulFingleDone() { }

	// RVA: 0xFB1EC8
	public object GetDownPos() { }

	// RVA: 0xFB20B8
	public object GetDrag() { }

	// RVA: 0xFB227C
	public object .ctor() { }

}

// Namespace: bq
public class Images
{

	// Fields
	public object mClearImage; // 0x8
	public object mCollapseImage; // 0x10
	public object mClearOnNewSceneImage; // 0x18
	public object mShowTimeImage; // 0x20
	public object mShowSceneImage; // 0x28
	public object mUserImage; // 0x30
	public object mShowMemoryImage; // 0x38
	public object mSoftwareImage; // 0x40
	public object mDateImage; // 0x48
	public object mShowFpsImage; // 0x50
	public object mInfoImage; // 0x58
	public object mSaveLogsImage; // 0x60
	public object mSearchImage; // 0x68
	public object mCopyImage; // 0x70
	public object mCloseImage; // 0x78
	public object mFolderImage; // 0x80
	public object mFolderImage1; // 0x88
	public object mFolderImage2; // 0x90
	public object mFileImage; // 0x98
	public object mBuildFromImage; // 0xA0
	public object mSystemInfoImage; // 0xA8
	public object mGraphicsInfoImage; // 0xB0
	public object mBackImage; // 0xB8
	public object mVerboseImage; // 0xC0
	public object mDebugImage; // 0xC8
	public object mLogImage; // 0xD0
	public object mWarningImage; // 0xD8
	public object mErrorImage; // 0xE0
	public object mFatalImage; // 0xE8
	public object mBarImage; // 0xF0
	public object mButtonActiveImage; // 0xF8
	public object mEventLogImage; // 0x100
	public object mOddLogImage; // 0x108
	public object mSelectedImage; // 0x110
	public object mReporterScrollerSkin; // 0x118

	// Methods

	// RVA: 0xFB2390
	public object .ctor() { }

}

// Namespace: bq
public class RFileInfo
{

	// Fields
	public object mDInfo; // 0x8
	public object mFInfo; // 0x10
	public object mName; // 0x18
	public object mIsReport; // 0x20

	// Methods

	// RVA: 0xFB2398
	public object .ctor(object name, object d, object f) { }

}

// Namespace: bq
public class FilePageInfo
{

	// Fields
	public object startIndex_log; // 0x8
	public object reflash; // 0xC
	public object selectedLine; // 0x10
	public object lineText; // 0x18
	public object searchText; // 0x20
	public object searchResult; // 0x28
	public object scrollPosition; // 0x30
	public object mSearchLines; // 0x38
	public object vSearchLines; // 0x40
	public object browerFiles; // 0x48
	public object fileInfo; // 0x50

	// Methods

	// RVA: 0xFB23D8
	public object .ctor() { }

}

// Namespace: bq
public class ReporterFileList
{

	// Fields
	public object mImageList; // 0x8
	private object mPlaceContent; // 0x10
	private object mCloseContent; // 0x18
	private object mFolderContent; // 0x20
	private object mFileContent; // 0x28
	private object mSearchContent; // 0x30
	private object mStyle; // 0x38
	public object maxSize; // 0x40
	private object mAlpha; // 0x44
	private object mCurrentLog; // 0x48
	private object mSelectedFile; // 0x50
	private object mFilePageMap; // 0x58
	private object mFilePageList; // 0x60
	private object toolRect; // 0x68
	private object toolBarRect; // 0x78
	private object fileListRect; // 0x88
	private object logToolsRect; // 0x98
	private object logRect; // 0xA8
	private object buttomRect; // 0xB8
	private object stackRectTopLeft; // 0xC8
	private object detailRect; // 0xD0
	private object toolbarScrollPosition; // 0xE0
	private object toolbarOldDrag; // 0xE8
	private object mOldDragList; // 0xEC
	private object startIndex; // 0xF0
	private object logsHeigthRat; // 0xF4
	private object mInit; // 0xF8
	private object mScrollPosition; // 0xFC
	private object mCurrFilePage; // 0x108
	private object logsRate; // 0x110
	private object mOldDragLogTool; // 0x114
	private object dragTool; // 0x118
	private object mOldDragLog; // 0x11C

	// Methods

	// RVA: 0xFB2530
	public object Initialize(object ImageList, object Style, object IsInSandBox) { }

	// RVA: 0xFB27D0
	private object FillFolderInfo(object path) { }

	// RVA: 0xFB31E4
	public object OnGUIDraw() { }

	// RVA: 0xFB3564
	private object DrawToolBar() { }

	// RVA: 0xFB723C
	private object ReadAllLines(object path) { }

	// RVA: 0xFB3C54
	private object DrawFileList() { }

	// RVA: 0xFB54F8
	private object DrawLogToos() { }

	// RVA: 0xFB7538
	private object DrawFilePageInfo() { }

	// RVA: 0xFB6360
	private object DrawLog() { }

	// RVA: 0xFB7A1C
	public object .ctor() { }

}

// Namespace: 
public sealed class dCallBackFun
{

	// Methods

	// RVA: 0xFB7CD4
	public object .ctor(object object, object method) { }

	// RVA: 0xFB7D68
	public virtual object Invoke() { }

	// RVA: 0xFB7D7C
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0xFB7DD4
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public sealed class dCallBackFunArg
{

	// Methods

	// RVA: 0xFB80B8
	public object .ctor(object object, object method) { }

	// RVA: 0xFB81D4
	public virtual object Invoke(object param) { }

	// RVA: 0xFB81E8
	public virtual object BeginInvoke(object param, object callback, object object) { }

	// RVA: 0xFB8238
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq
public class RGmCommon
{

	// Fields
	public object mCB; // 0x8
	public object mCBArg; // 0x10
	public object mParam; // 0x18
	public object mKey; // 0x20
	public object mPage; // 0x28

	// Methods

	// RVA: 0xFB7BF0
	public object .ctor(object page, object key, object cb) { }

	// RVA: 0xFB7C30
	public object .ctor(object page, object key, object cb, object param) { }

}

// Namespace: bq
public class ReporterGmList
{

	// Fields
	public object mImageList; // 0x8
	private object mPlaceContent; // 0x10
	private object mCloseContent; // 0x18
	private object mStyle; // 0x20
	public object maxSize; // 0x28
	private object mGmCommonMap; // 0x30
	private object mGmPageMap; // 0x38
	private object mGmPageList; // 0x40
	private object toolRect; // 0x48
	private object toolBarRect; // 0x58
	private object fileListRect; // 0x68
	private object logToolsRect; // 0x78
	private object logRect; // 0x88
	private object buttomRect; // 0x98
	private object stackRectTopLeft; // 0xA8
	private object detailRect; // 0xB0
	private object toolbarScrollPosition; // 0xC0
	private object toolbarOldDrag; // 0xC8
	private object mOldDragList; // 0xCC
	private object startIndex; // 0xD0
	private object logsHeigthRat; // 0xD4
	private object mInit; // 0xD8
	private object mScrollPosition; // 0xDC
	private object logsRate; // 0xE4
	private object mOldDragLogTool; // 0xE8
	private object dragTool; // 0xEC
	private object currPageInxed; // 0xF0
	private object mOldDragLog; // 0xF4
	private object scrollPosition; // 0xF8
	private object startIndex_log; // 0x100

	// Methods

	// RVA: 0xFB8244
	public object Initialize(object ImageList, object Style) { }

	// RVA: 0xFB8368
	public static object RegisterGmCommon(object page, object common, object cb, object arg) { }

	// RVA: 0xFB874C
	public static object RegisterGmCommon(object page, object common, object cb) { }

	// RVA: 0xFAE700
	public static object CallGmCommon(object common) { }

	// RVA: 0xFB8BDC
	private object CallGmCommon_(object common) { }

	// RVA: 0xFB8434
	private object RegisterGmCommon_(object page, object common, object cb, object arg) { }

	// RVA: 0xFB8810
	private object RegisterGmCommon_(object page, object common, object cb) { }

	// RVA: 0xFB8D24
	public object OnGUIDraw() { }

	// RVA: 0xFB90A4
	private object DrawToolBar() { }

	// RVA: 0xFB96F8
	private object DrawPageButtons() { }

	// RVA: 0xFBA3E8
	private object DrawSplitLine() { }

	// RVA: 0xFBA6DC
	private object DrawGmButtons() { }

	// RVA: 0xFBB1AC
	public object .ctor() { }

}

// Namespace: bq
public class ReporterGUI
{

	// Fields
	private object mReporter; // 0x18

	// Methods

	// RVA: 0xFBB38C
	private object Awake() { }

	// RVA: 0xFBB408
	private object OnGUI() { }

	// RVA: 0xFBBA3C
	public object .ctor() { }

}

// Namespace: bq
public class ReporterStyle
{

	// Fields
	public object mBarStyle; // 0x8
	public object mCollapesStyle; // 0x10
	public object mButtonActiveStyle; // 0x18
	public object mNonStyle; // 0x20
	public object mLowerLeftFontStyle; // 0x28
	public object mBackStyle; // 0x30
	public object mStackStyle; // 0x38
	public object mSettingStyle; // 0x40
	public object mEvenLogStyle; // 0x48
	public object mOddLogStyle; // 0x50
	public object mLogButtonStyle; // 0x58
	public object mSelectedLogStyle; // 0x60
	public object mSelectedLogFontStyle; // 0x68
	public object mStackLabelStyle; // 0x70
	public object mScrollerStyle; // 0x78
	public object mSearchStyle; // 0x80
	public object mSliderBackStyle; // 0x88
	public object mSliderThumbStyle; // 0x90
	public object mToolbarScrollerSkin; // 0x98
	public object mLogScrollerSkin; // 0xA0
	public object mGraphScrollerSkin; // 0xA8
	public object mToggleSkin; // 0xB0

	// Methods

	// RVA: 0xFBBA44
	public object InitializeStyle(object size, object images) { }

	// RVA: 0xFBCFD4
	public object .ctor() { }

}

// Namespace: bq
public class Sample
{

	// Fields
	public object mTime; // 0x8
	public object mLoadedScene; // 0xC
	public object mMemory; // 0x10
	public object mFps; // 0x14
	public object mFpsText; // 0x18

	// Methods

	// RVA: 0xFBCFDC
	public static object MemSize() { }

	// RVA: 0xFBCFE4
	public object GetSceneName() { }

	// RVA: 0xFBD08C
	public object .ctor() { }

}

// Namespace: bq
public class SampleManager
{

	// Fields
	public static object mScenes; // 0x0
	public object mCurrentScene; // 0x8
	private object mSamples; // 0x10

	// Methods

	// RVA: 0xFBD094
	public object addSample(object fps, object fpsText, object gcTotalMemory) { }

	// RVA: 0xFBD2B0
	public object GetSamples() { }

	// RVA: 0xFBD2B8
	public object CreateScenes() { }

	// RVA: 0xFBD380
	public object .ctor() { }

}

// Namespace: 
public enum ReportView
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Logs;
	public const object Set;
	public const object FileList;
	public const object GM;
}

// Namespace: bq
public class Settings
{

	// Fields
	public object mCurrentView; // 0x8
	private object mScreenRect; // 0xC
	public object mSize; // 0x1C
	private object mBackContent; // 0x28
	public object mIsShow; // 0x30
	public object mIsClearOnNewSceneLoaded; // 0x31
	public object mIsShowTime; // 0x32
	public object mIsShowScene; // 0x33
	public object mIsShowMemory; // 0x34
	public object mIsShowFps; // 0x35
	public object mIsShowGraph; // 0x36
	public object mIsShowClearOnNewSceneLoadedButton; // 0x37
	public object mIsShowTimeButton; // 0x38
	public object mIsShowSceneButton; // 0x39
	public object mIsShowMemButton; // 0x3A
	public object mIsShowFpsButton; // 0x3B
	public object mIsShowSearchText; // 0x3C
	public object mIsShowCopyButton; // 0x3D
	public object mIsCollapse; // 0x3E
	private object toolbarScrollPosition; // 0x40

	// Methods

	// RVA: 0xFBD440
	public object Initialize(object images) { }

	// RVA: 0xFBD980
	public object Save() { }

	// RVA: 0xFBDE04
	public object Draw(object styles) { }

	// RVA: 0xFBE2F0
	public object .ctor() { }

}

// Namespace: 
private class BianqueConfig
{

	// Fields
	public object BqHost; // 0x8
	public object BqPort; // 0x10

	// Methods

	// RVA: 0xFC01D0
	public object .ctor() { }

}

// Namespace: bq
public static class LogReportHelper
{

	// Fields
	private static object s_bqlogRootPath; // 0x0
	private static object s_bqGateInfo; // 0x8

	// Methods

	// RVA: 0xFBE3A4
	public static object ReportLogs(object daysSinceNow) { }

	// RVA: 0xFBE95C
	private static object ReportBqLogs(object daysSinceNow, object relativeFolderPath) { }

	// RVA: 0xFBEFC8
	public static object BqLogRootPath() { }

	// RVA: 0xFBF1C8
	public static object GetFileInfoListOfLastDays(object folderPath, object daysSinceNow) { }

	// RVA: 0xFBF5B4
	public static object SortFileInfoByDate(object files) { }

	// RVA: 0xFBF740
	public static object GetGateInfo() { }

	// RVA: 0xFBFB78
	private static object LoadBianqueConfig() { }

	// RVA: 0xFBFF98
	private static object FindMatchBianqueGate(object host, object port) { }

	// RVA: 0xFC00E0
	private static object BinqueConfigLocalFilePath() { }

	// RVA: 0xFC0164
	private static object .cctor() { }

}

// Namespace: bq
public struct CacheStringInfo
{

	// Fields
	public object content; // 0xFFFFFFFFFFFFFFF8
	public object tick; // 0x0
}

// Namespace: bq
internal enum en_ring_type
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object call_back;
	public const object ring_buffer;
	public const object ring_file;
}

// Namespace: bq
public class LogImp
{

	// Fields
	public object mLoggerId; // 0x8
	public object mCount; // 0x10
	public object mHash; // 0x14
	public object mLogType; // 0x18
	public object mCondition; // 0x20
	public object mStacktrace; // 0x30
	public object mSampleId; // 0x40
	public object mCategoryIndex; // 0x44

	// Methods

	// RVA: 0xFC026C
	public object CreateCopy() { }

	// RVA: 0xFC02F4
	public object GetMemoryUsage() { }

	// RVA: 0xFC0344
	public object .ctor() { }

}

// Namespace: bq
public class LogLevelButtonUI
{

	// Fields
	public object mNumOfLogs; // 0x8
	public object mNumOfCollapsedLogs; // 0xC
	public object mShow; // 0x10
	public object mLogContent; // 0x18
	public object track; // 0x20
	public object level; // 0x24

	// Methods

	// RVA: 0xFC035C
	public object .ctor(object texture) { }

	// RVA: 0xFC0418
	public object GuiDraw(object size, object style) { }

}

// Namespace: 
public sealed class type_console_callback
{

	// Methods

	// RVA: 0xFC4A8C
	public object .ctor(object object, object method) { }

	// RVA: 0xFC4B24
	public virtual object Invoke(object logger_id, object category_idx, object log_level, object content) { }

	// RVA: 0xFC4B38
	public virtual object BeginInvoke(object logger_id, object category_idx, object log_level, object content, object callback, object object) { }

	// RVA: 0xFC4C4C
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq
public class LogImpMgr
{

	// Fields
	public object mLogs; // 0x8
	public object mCollapsedLogs; // 0x10
	public object mCurrentLog; // 0x18
	public object mLogCBList; // 0x20
	public object mCachedString; // 0x28
	public object mLogsDic; // 0x30
	public object mThreadTempPool; // 0x38
	public object mThreadedLogs; // 0x40
	public object mLogLevelUIList; // 0x48
	public object mSelectedLog; // 0x50
	public object mFilterText; // 0x58
	public object mLogsMemUsage; // 0x60
	public object mGraphMemUsage; // 0x64
	public object mGcTotalMemory; // 0x68
	public object mFps; // 0x6C
	public object mFpsText; // 0x70
	public object mScrollPosition; // 0x78
	private static object mIsInit; // 0x0
	private object use_ring_type; // 0x80
	private static object isOpenConsoleLog; // 0x1
	private object bCapture; // 0x88
	private object sb; // 0x90
	private object cell; // 0x98

	// Properties
	public object TotalMemUsage { get; }

	// Methods

	// RVA: 0xFC11AC
	public object Clear() { }

	// RVA: 0xFC1628
	public object Init() { }

	// RVA: 0xFC1894
	public object UnInit() { }

	// RVA: 0xFC17B8
	public static object set_appenders_enable(object enable) { }

	// RVA: 0xFC1980
	public object AddLogCallback(object cb) { }

	// RVA: 0xFC1AA0
	public object RemoveLogCallback(object cb) { }

	// RVA: 0xFC1B0C
	public object CreateLogLevelUI(object texture) { }

	// RVA: 0xFC1578
	private object GetUI(object level) { }

	// RVA: 0xFC1CF0
	public object DrawLogLevelUI(object size, object style) { }

	// RVA: 0xFC2004
	public object IsShowLevel(object log_type) { }

	// RVA: 0xFC20BC
	public object IsNoFileter(object log) { }

	// RVA: 0xFC0C8C
	public object CalculateCurrentLog() { }

	// RVA: 0xFC2310
	public object get_TotalMemUsage() { }

	// RVA: 0xFC231C
	public object process_thread_log(object gameObject, object maxSize) { }

	// RVA: 0xFC252C
	public object AddLog(object gameObject, object maxSize, object log) { }

	// RVA: 0xFC30D8
	public object CaptureLogThread(object condition, object stacktrace, object type) { }

	// RVA: 0xFC10E0
	private static object CaptureLogCB_Wrapper(object logger_id, object category_idx, object log_level, object content) { }

	// RVA: 0xFC38F8
	public object CaptureLogCB(object logger_id, object category_idx, object log_level, object content) { }

	// RVA: 0xFC3D00
	private object AddToThreadLogPool(object log) { }

	// RVA: 0xFC4040
	public object Update() { }

	// RVA: 0xFC42E0
	public object SaveLogsToDevice() { }

	// RVA: 0xFC46F0
	public object .ctor() { }

}

// Namespace: bq
public class MultiKeyDictionary<T0, T1, T2>
{

	// Properties
	public object Item { get; }

	// Methods

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object ContainsKey(object key1, object key2) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: bq
public class http_send_info
{

	// Fields
	public object url; // 0x8
	public object task_id; // 0x10
	public object session; // 0x18
	public object token; // 0x20
	public object file_infos; // 0x28

	// Methods

	// RVA: 0xFC4C58
	public object .ctor() { }

}

// Namespace: 
private sealed class <SendFile>d__3
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <request>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xFC5184
	public object .ctor(object <>1__state) { }

	// RVA: 0xFC5458
	private object System.IDisposable.Dispose() { }

	// RVA: 0xFC545C
	private object MoveNext() { }

	// RVA: 0xFC5C48
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xFC5C50
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xFC5C90
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: bq
public class UploadFile
{

	// Fields
	private object http_send_info_; // 0x18

	// Methods

	// RVA: 0xFC4C60
	private object Start() { }

	// RVA: 0xFC4EE4
	private object HttpCallback(object task_id, object url, object session, object token, object file_infos) { }

	// RVA: 0xFC5118
	private object SendFile() { }

	// RVA: 0xFC51B0
	private object Update() { }

	// RVA: 0xFC5304
	private object OnApplicationQuit() { }

	// RVA: 0xFC53D8
	public object .ctor() { }

}

// Namespace: bq
public class Reporter
{

	// Fields
	private object eventSystem; // 0x18
	private static object mIsCreate; // 0x0
	public object mImageList; // 0x20
	private object mPlaceContent; // 0x28
	private object mCloseContent; // 0x30
	private object mClearContent; // 0x38
	private object mCollapseContent; // 0x40
	private object mCopyContent; // 0x48
	private object mSettingContent; // 0x50
	private object mSaveLogsContent; // 0x58
	private object mFileListContent1; // 0x60
	private object mFileListContent2; // 0x68
	private object mSearchContent; // 0x70
	private object mShowTimeContent; // 0x78
	private object mShowSceneContent; // 0x80
	private object mShowMemoryContent; // 0x88
	private object mShowFpsContent; // 0x90
	private object mVerboseContent; // 0x98
	private object mDebugContent; // 0xA0
	private object mLogContent; // 0xA8
	private object mWarningContent; // 0xB0
	private object mErrorContent; // 0xB8
	private object mFatalContent; // 0xC0
	private object mStyle; // 0xC8
	private object mFileList; // 0xD0
	public object maxSize; // 0xD8
	private object mAlpha; // 0xDC
	public object Initialized; // 0xE0
	private object toolRect; // 0xE4
	private object toolBarRect; // 0xF4
	private object logsRect; // 0x104
	private object stackToolRect; // 0x114
	private object stackRect; // 0x124
	private object buttomRect; // 0x134
	private object stackRectTopLeft; // 0x144
	private object detailRect; // 0x14C
	private object scrollPosition2; // 0x15C
	private object toolbarScrollPosition; // 0x164
	private object toolbarOldDrag; // 0x16C
	private object oldDrag; // 0x170
	private object oldDrag2; // 0x174
	private object startIndex; // 0x178
	private object countRect; // 0x17C
	private object timeRect; // 0x18C
	private object timeLabelRect; // 0x19C
	private object sceneRect; // 0x1AC
	private object sceneLabelRect; // 0x1BC
	private object memoryRect; // 0x1CC
	private object memoryLabelRect; // 0x1DC
	private object fpsRect; // 0x1EC
	private object fpsLabelRect; // 0x1FC
	private object tempContent; // 0x210
	private object logsHeigthRat; // 0x218
	private object tempRect; // 0x21C
	private object dragTool; // 0x22C
	private object mOldStackTool; // 0x230
	private object frames; // 0x234
	private object firstTime; // 0x238
	private object lastUpdate; // 0x23C
	private const object requiredFrames;
	private const object updateInterval;

	// Methods

	// RVA: 0xFC5C98
	private object Awake() { }

	// RVA: 0xFC5E28
	private object getEventSystem() { }

	// RVA: 0xFC6B94
	private object OnDestroy() { }

	// RVA: 0xFC6C44
	private object OnEnable() { }

	// RVA: 0xFC6E80
	private object OnDisable() { }

	// RVA: 0xFC5FD4
	public object Initialize() { }

	// RVA: 0xFC6D14
	private object Clear() { }

	// RVA: 0xFBB428
	public object OnGUIDraw() { }

	// RVA: 0xFCB85C
	private object Close() { }

	// RVA: 0xFC71D8
	private object DrawToolBar() { }

	// RVA: 0xFC83AC
	private object DrawLogs() { }

	// RVA: 0xFCA334
	private object DrawStackTool() { }

	// RVA: 0xFCA6A0
	private object DrawStack() { }

	// RVA: 0xFCBAAC
	private object CalculateStartIndex() { }

	// RVA: 0xFC6F64
	private object DoShow() { }

	// RVA: 0xFCBC24
	private object Update() { }

	// RVA: 0xFCC1E0
	private object _OnLevelWasLoaded(object _null1, object _null2) { }

	// RVA: 0xFCC3D8
	private object Save() { }

	// RVA: 0xFCC474
	private object OnApplicationQuit() { }

	// RVA: 0xFCC590
	public object .ctor() { }

}

// Namespace: bq
public class ReporterMessageReceiver
{

	// Fields
	private object mReporter; // 0x18

	// Methods

	// RVA: 0xFCC7EC
	private object Start() { }

	// RVA: 0xFCC858
	private object OnPreStart() { }

	// RVA: 0xFCCA38
	private object OnHideReporter() { }

	// RVA: 0xFCCA3C
	private object OnShowReporter() { }

	// RVA: 0xFCCA40
	private object OnLog(object log) { }

	// RVA: 0xFCCA44
	public object .ctor() { }

}

// Namespace: bq
public enum TailInvokeFuncType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Profile_SysMem;
	public const object Profile_MonoUsedSize;
	public const object Profile_FPS;
	public const object Profile_Min_FPS;
	public const object Profile_Avg_FPS;
	public const object Profile_Less5FPSCount;
	public const object Profile_Less10FPSCount;
	public const object Profile_Less18FPSCount;
	public const object Profile_Less25FPSCount;
	public const object Profile_FPS25To30Count;
	public const object Profile_FPS30Count;
	public const object Profile_FPS40to45Count;
	public const object Profile_FPS45to50Count;
	public const object Profile_FPS50to55Count;
	public const object Profile_FPS55to60Count;
	public const object Profile_FPSBig60Count;
	public const object Profile_FPS3Less20Count;
	public const object Profile_FPS3Less40Count;
	public const object Profile_Abnormal_FPS;
	public const object Profile_Abnormal_4FPS;
	public const object Profile_FPSMode;
	public const object Profile_CanUse60FPSMode;
	public const object Profile_IsEnableOutLine;
	public const object Profile_IsHighResolution;
	public const object Profile_EnginePlayerLoopDt;
	public const object Profile_EnginePlayerRenderDt;
	public const object Profile_EngineCamera3DCullDt;
	public const object Profile_EngineCamera3DDrawDt;
	public const object Profile_EngineCamera2DCullDt;
	public const object Profile_EngineCamera2DDrawDt;
	public const object Profile_EngineMonoUpdateDt;
	public const object Profile_EngineMonoLateUpdateDt;
	public const object Profile_EngineDirectorUpdateAnimationDt;
	public const object Profile_EngineAnimationUpdateDt;
	public const object Profile_EngineMeshSkinDt;
	public const object Profile_EngineWaitForPresentDt;
	public const object Profile_EngineParticleSystemDt;
	public const object Profile_EngineWillRenderCanvasesDt;
	public const object Profile_EngineUpdateCanvasRectTransformDt;
	public const object Profile_EnginePlayerEndOfFrameDt;
	public const object Profile_EngineGfxWorkerDt;
	public const object Profile_EngineDrawCallCnt;
	public const object Profile_EngineTriangleCnt;
	public const object Profile_EngineVertexCnt;
	public const object Profile_EngineSetPassCallCnt;
	public const object Profile_EngineParticleSystemCnt;
	public const object Profile_EngineParticleCnt;
	public const object Profile_EngineAnimationCnt;
	public const object Profile_EngineAnimatorCnt;
	public const object Profile_EngineMonoUpdateCnt;
	public const object Profile_EngineMonoLateUpdateCnt;
	public const object Profile_EngineCanvasUpdateCnt;
	public const object Profile_EngineCanvasBatchDrawCnt;
	public const object Profile_EngineObjectCnt;
}

// Namespace: bq
public enum TailType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Zero;
	public const object Log;
	public const object Image;
	public const object Profiler;
}

// Namespace: bq
public class Tail
{

	// Fields
	private object inited; // 0x8
	public object type; // 0xC
	public object open_; // 0x10
	public object interval_; // 0x14

	// Methods

	// RVA: 0xFCCA4C
	public object TailSwitch(object interval, object open) { }

	// RVA: 0xFCCAC0
	public virtual object Init() { }

	// RVA: 0xFCCAC4
	public virtual object Update(object mono) { }

	// RVA: 0xFCCAC8
	public object .ctor() { }

}

// Namespace: 
private sealed class <CaptureByRect>d__2
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0xFCCBD8
	public object .ctor(object <>1__state) { }

	// RVA: 0xFCCC04
	private object System.IDisposable.Dispose() { }

	// RVA: 0xFCCC08
	private object MoveNext() { }

	// RVA: 0xFCCE84
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0xFCCE8C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0xFCCECC
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: bq
internal class TailScreenShot
{

	// Methods

	// RVA: 0xFCCAD0
	public object .ctor() { }

	// RVA: 0xFCCAFC
	public override object Update(object mono) { }

	// RVA: 0xFCCB7C
	private object CaptureByRect() { }

}

// Namespace: bq
public class TailManager
{

	// Fields
	private object businessDelegateMap; // 0x8
	private object TailList; // 0x10

	// Methods

	// RVA: 0xFCCED4
	public object Init() { }

	// RVA: 0xFCD438
	private static object TailSwitchCallback(object type, object interval, object open) { }

	// RVA: 0xFCD4FC
	public object TailSwitch(object type, object interval, object open) { }

	// RVA: 0xFCD5E8
	public object Update(object mono) { }

	// RVA: -1
	public object InvoveBusinessFunc(object type) { }

	// RVA: -1
	public object SetTailInvokeFunc(object type, object func) { }

	// RVA: 0xFCD7B0
	public object ResetTailInvokeFunc(object type) { }

	// RVA: 0xFCD864
	public object .ctor() { }

}

// Namespace: 
private class ProfileData
{

	// Fields
	public object Time; // 0x8
	public object FPS; // 0x10
	public object SysMem; // 0x14
	public object MonoUsedSize; // 0x18

	// Methods

	// RVA: 0xFCDE94
	public object .ctor() { }

}

// Namespace: bq
public class TailProfiler
{

	// Fields
	private object cacheBufferLenth; // 0x18
	private object lastUpdateTime; // 0x1C
	private object dataBuffer; // 0x20
	private object bufferIndex; // 0x28

	// Methods

	// RVA: 0xFCD330
	public object .ctor() { }

	// RVA: 0xFCD96C
	public override object Init() { }

	// RVA: 0xFCDE9C
	public override object Update(object mono) { }

	// RVA: 0xFCDF64
	private object FillProfileData() { }

	// RVA: 0xFCE10C
	private object ConvertProfileDatasToBytes() { }

	// RVA: 0xFCE440
	private object GetCurrentUTC0Stamp() { }

}

// Namespace: bq
public class SettingsGUI
{

	// Fields
	private const object WATCH_PREF_NAME;
	private object setting_keys; // 0x20
	private object m_mainText; // 0x28
	private object m_inputText; // 0x30
	private object m_lastUpdate; // 0x38
	private object m_updateInversal; // 0x3C
	private object m_sizeUnit; // 0x40
	private object m_scrollPos; // 0x44

	// Methods

	// RVA: 0xFCE52C
	private object Start() { }

	// RVA: 0xFCE658
	private object OnDestroy() { }

	// RVA: 0xFCE890
	private object OnGUI() { }

	// RVA: 0xFCEE60
	private object CheckIfNeedUpdate() { }

	// RVA: 0xFCF17C
	private object UpdateSetting() { }

	// RVA: 0xFCEEA8
	private object AddKeys(object content) { }

	// RVA: 0xFCEFE4
	private object RemoveKeys(object content) { }

	// RVA: 0xFCF120
	private object RemoveAll() { }

	// RVA: 0xFCE5D0
	private object ReadPref() { }

	// RVA: 0xFCE65C
	private object SavePref() { }

	// RVA: 0xFCFEB0
	public object .ctor() { }

}

// Namespace: 
public sealed class type_http_callback
{

	// Methods

	// RVA: 0xFC4D78
	public object .ctor(object object, object method) { }

	// RVA: 0xFD3CDC
	public virtual object Invoke(object task_id, object url, object session, object token, object file_infos) { }

	// RVA: 0xFD3CF0
	public virtual object BeginInvoke(object task_id, object url, object session, object token, object file_infos, object callback, object object) { }

	// RVA: 0xFD3DD4
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
public class file_info
{

	// Fields
	public object file_path; // 0x8
	public object file_data; // 0x10

	// Methods

	// RVA: 0xFD1BE0
	public object .ctor() { }

}

// Namespace: bq
public class ccs
{

	// Fields
	private static object http_callback; // 0x0
	private static object tail_switch_callback; // 0x8
	private static object sha256_managed; // 0x10
	private static object settings_lock; // 0x18
	private static object setting_update_callbacks; // 0x20
	private static object updated_setting_keys; // 0x28
	private static object wait_for_callback_setting_keys; // 0x30
	private static object cached_settings_bool; // 0x38
	private static object cached_settings_integer; // 0x40
	private static object cached_settings_decimal; // 0x48
	private static object cached_settings_string; // 0x50
	private static object wrapper_log; // 0x58

	// Methods

	// RVA: 0xFD0B98
	public static object init(object hosts, object connect_interval) { }

	// RVA: 0xFD1048
	public static object uninit() { }

	// RVA: 0xFD13F0
	public static object connect(object hosts, object connect_interval) { }

	// RVA: 0xFD1430
	public static object on_pause(object pause) { }

	// RVA: 0xFD1438
	public static object drop() { }

	// RVA: 0xFD1440
	public static object crash_test() { }

	// RVA: 0xFD1448
	public static object update_portrait(object name, object value, object moment_send) { }

	// RVA: 0xFD14E0
	public static object update_portrait(object name, object value, object moment_send) { }

	// RVA: 0xFD1528
	public static object update_portrait(object name, object value, object moment_send) { }

	// RVA: 0xFD1578
	public static object get_portrait_string(object name) { }

	// RVA: 0xFD165C
	public static object set_download_pause(object on) { }

	// RVA: 0xFCBAA4
	public static object print_portrait() { }

	// RVA: 0xFD1664
	public static object send_to_http_server(object task_id, object file_paths, object file_datas) { }

	// RVA: 0xFBF574
	public static object file_to_report_server(object file_path, object delete_on_finish) { }

	// RVA: 0xFD1A74
	public static object get_current_gate_info(object host, object port) { }

	// RVA: 0xFD1B04
	public static object get_bq_id() { }

	// RVA: 0xFC4E10
	public static object set_http_callback(object callback) { }

	// RVA: 0xFD004C
	private static object _native_http_callback_wrapper(object task_id, object url, object session, object token, object file_count, object file_path, object file_data, object data_length) { }

	// RVA: 0xFD1C0C
	public static object share_file(object file_path) { }

	// RVA: 0xFD1C3C
	public static object send_to_report_server(object table, object data) { }

	// RVA: 0xFD1CC0
	public static object on_mono_update() { }

	// RVA: 0xFD0514
	public static object _native_tail_switch_callback(object type, object interval, object open) { }

	// RVA: 0xFCD364
	public static object set_tail_switch_callback(object callback) { }

	// RVA: 0xFCCD98
	public static object tail_data_to_server(object type, object data) { }

	// RVA: 0xFD2120
	public static object get_ts_file_path(object ts_check_path, object version) { }

	// RVA: 0xFD21C4
	public static object use_bq_js_last_version() { }

	// RVA: 0xFD21CC
	public static object toggle_res_collect(object on) { }

	// RVA: 0xFD21D4
	public static object toggle_res_upload(object on) { }

	// RVA: 0xFD21DC
	public static object mark_res_load(object res_id) { }

	// RVA: 0xFD21E4
	public static object mark_res_load(object res_path) { }

	// RVA: 0xFD2278
	public static object res_path_hash(object res_path) { }

	// RVA: 0xFD2354
	public static object set_res_inversal(object sec) { }

	// RVA: 0xFD235C
	public static object set_max_upload_once(object num) { }

	// RVA: 0xFD0CE8
	private static object init_settings() { }

	// RVA: 0xFD1160
	private static object uninit_settings() { }

	// RVA: 0xFD061C
	private static object _native_setting_update_callback_wrapper(object char_key) { }

	// RVA: 0xFD23CC
	public static object register_setting_update_callback(object callback) { }

	// RVA: 0xFD2880
	public static object unregister_setting_update_callback(object callback) { }

	// RVA: 0xFD1D28
	private static object on_setting_update_by_mono() { }

	// RVA: 0xFD26D8
	private static object whether_exist_setting_update_callback(object callback) { }

	// RVA: 0xFCF658
	public static object get_settings_value_type(object settings_key) { }

	// RVA: 0xFCDAB4
	public static object get_settings_value_integer(object settings_key, object default_value, object use_cache) { }

	// RVA: 0xFBE5B0
	public static object get_settings_value_bool(object settings_key, object default_value, object use_cache) { }

	// RVA: 0xFCF6B4
	public static object get_settings_value_decimal(object settings_key, object default_value, object use_cache) { }

	// RVA: 0xFCFA90
	public static object get_settings_value_string(object settings_key, object default_value, object use_cache) { }

	// RVA: 0xFD2B68
	public static object has_settings_key(object settings_key) { }

	// RVA: 0xFD2C94
	public static object get_last_init_time_ms() { }

	// RVA: 0xFD2D30
	public static object get_first_init_time_ms() { }

	// RVA: 0xFD2DCC
	public static object get_time_ms_since_init() { }

	// RVA: 0xFD2E68
	public static object get_time_ms_since_first_init() { }

	// RVA: 0xFD2F04
	public static object print_all_settings() { }

	// RVA: 0xFD396C
	public object .ctor() { }

	// RVA: 0xFD3974
	private static object .cctor() { }

}

// Namespace: bq
internal class lib_def
{

	// Fields
	public const object lib_log_name;
	public const object lib_ccs_name;

	// Methods

	// RVA: 0xFD3DE0
	public object .ctor() { }

}

// Namespace: bq
public class ccs_utils
{

	// Methods

	// RVA: 0xFD1BE8
	public static object strlen(object str) { }

	// RVA: 0xFD2364
	public static object convert_to_string(object data) { }

	// RVA: 0xFD1B78
	public static object convert_to_string(object data) { }

	// RVA: 0xFD3DE8
	public object .ctor() { }

}

// Namespace: bq
public class category_log
{

	// Methods

	// RVA: 0xFD3DF0
	protected object .ctor() { }

	// RVA: 0xFD3E78
	public object .ctor(object child_inst) { }

	// RVA: 0xFD3EE4
	public object get_categories_count() { }

	// RVA: 0xFD3F38
	public object get_categories_name_array() { }

}

// Namespace: 
public class CollectInfo
{

	// Fields
	public object Hash; // 0x8
	public object Time; // 0x10
	public object Log; // 0x18
	public object Trace; // 0x20
	public object Author; // 0x28

	// Methods

	// RVA: 0xFD5CFC
	public object .ctor(object hash, object trace, object log, object time, object author) { }

}

// Namespace: bq
public class error_log_record
{

	// Fields
	private object FilePath; // 0x8
	private object mCollectInfo; // 0x10
	private object DelayList; // 0x18
	private object m_TaskThread; // 0x20
	private object m_Enable; // 0x28
	private object record_err_log; // 0x29

	// Methods

	// RVA: 0xFD3F40
	public object svn_blame(object Value, object filePath, object line_num) { }

	// RVA: 0xFD3F84
	private object extract_stringInparentheses(object input) { }

	// RVA: 0xFD4064
	public object record_error(object log_format_content, object level, object ignore) { }

	// RVA: 0xFD4068
	public object record_read() { }

	// RVA: 0xFD4770
	public object record_write(object Key, object Value) { }

	// RVA: 0xFD54D4
	public object record_write() { }

	// RVA: 0xFD5964
	public object tick() { }

	// RVA: 0xFD5BA4
	private object OnDestroy() { }

	// RVA: 0xFD5BD8
	public object .ctor() { }

}

// Namespace: 
public sealed class type_console_callback
{

	// Methods

	// RVA: 0xFDE410
	public object .ctor(object object, object method) { }

	// RVA: 0xFDE4A8
	public virtual object Invoke(object log_id, object category_idx, object log_level, object content) { }

	// RVA: 0xFDE4BC
	public virtual object BeginInvoke(object log_id, object category_idx, object log_level, object content, object callback, object object) { }

	// RVA: 0xFDE5D0
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq
public class log
{

	// Fields
	private static object default_category_; // 0x0
	private object log_id_; // 0x8
	private object name_; // 0x10
	private object merged_log_level_bitmap_; // 0x18
	private object categories_mask_array_; // 0x20
	private object print_stack_level_bitmap_; // 0x28
	protected object categories_name_array_; // 0x30
	private static object console_callbacks_; // 0x8
	private static object console_callbacks_lock_; // 0x10

	// Methods

	// RVA: 0xFD6188
	protected static object get_log_by_id(object log_id) { }

	// RVA: 0xFD6550
	private object is_enable_for(object category, object level) { }

	// RVA: 0xFD6598
	private static object get_str_len(object str) { }

	// RVA: 0xFD65B4
	public static object get_version() { }

	// RVA: 0xFD6650
	public static object enable_auto_crash_handle() { }

	// RVA: 0xFD6658
	public static object get_file_base_dir(object is_in_sandbox) { }

	// RVA: 0xFD671C
	public static object create_log(object name, object config) { }

	// RVA: 0xFD6B5C
	public static object get_log_by_name(object log_name) { }

	// RVA: 0xFD6DF0
	public static object force_flush_all_logs() { }

	// RVA: 0xFD6DFC
	public static object uninit() { }

	// RVA: 0xFD6E04
	public static object register_console_callback(object callback) { }

	// RVA: 0xFD7134
	public static object unregister_console_callback(object callback) { }

	// RVA: 0xFD5DD0
	private static object _native_console_callback_wrapper(object log_id, object category_idx, object log_level, object content, object length) { }

	// RVA: 0xFD7338
	public static object set_console_buffer_enable(object enable) { }

	// RVA: 0xFD7340
	public static object fetch_and_remove_console_buffer(object on_console_callback) { }

	// RVA: 0xFD6024
	private static object _native_console_buffer_fetch_callback_wrapper(object pass_through_param, object log_id, object category_idx, object log_level, object content, object length) { }

	// RVA: 0xFD7544
	public static object console(object level, object content) { }

	// RVA: 0xFD75E8
	internal static object is_stack_trace_enable_for(object log, object level) { }

	// RVA: 0xFD6460
	protected object .ctor() { }

	// RVA: 0xFD7614
	public object .ctor(object rhs) { }

	// RVA: 0xFD7848
	public object reset_config(object name, object config) { }

	// RVA: 0xFD7994
	public object set_appenders_enable(object appender_name, object enable) { }

	// RVA: 0xFD7A40
	public object force_flush() { }

	// RVA: 0xFD7A48
	public object get_id() { }

	// RVA: 0xFD7A50
	public object is_valid() { }

	// RVA: 0xFD7A60
	public object get_name() { }

	// RVA: 0xFD7A68
	public object take_snapshot(object use_gmt_time) { }

	// RVA: 0xFD7AF0
	public override object Equals(object obj) { }

	// RVA: 0xFD7B94
	public override object GetHashCode() { }

	// RVA: 0xFD7BA0
	protected object do_log(object category, object level, object log_format_content) { }

	// RVA: 0xFD7FE0
	public object verbose(object log_format_content) { }

	// RVA: 0xFD8058
	public object debug(object log_format_content) { }

	// RVA: 0xFD80D0
	public object info(object log_format_content) { }

	// RVA: 0xFD8148
	public object warning(object log_format_content) { }

	// RVA: 0xFD81C0
	public object error(object log_format_content) { }

	// RVA: 0xFD8238
	public object fatal(object log_format_content) { }

	// RVA: 0xFD82B0
	protected object do_log(object category, object level, object log_format_content, object p1) { }

	// RVA: 0xFD8674
	public object verbose(object log_format_content, object p1) { }

	// RVA: 0xFD86FC
	public object debug(object log_format_content, object p1) { }

	// RVA: 0xFD8784
	public object info(object log_format_content, object p1) { }

	// RVA: 0xFD880C
	public object warning(object log_format_content, object p1) { }

	// RVA: 0xFD8894
	public object error(object log_format_content, object p1) { }

	// RVA: 0xFD891C
	public object fatal(object log_format_content, object p1) { }

	// RVA: 0xFD89A4
	protected object do_log(object category, object level, object log_format_content, object p1, object p2) { }

	// RVA: 0xFD8B30
	public object verbose(object log_format_content, object p1, object p2) { }

	// RVA: 0xFD8BC0
	public object debug(object log_format_content, object p1, object p2) { }

	// RVA: 0xFD8C50
	public object info(object log_format_content, object p1, object p2) { }

	// RVA: 0xFD8CE0
	public object warning(object log_format_content, object p1, object p2) { }

	// RVA: 0xFD8D70
	public object error(object log_format_content, object p1, object p2) { }

	// RVA: 0xFD8E00
	public object fatal(object log_format_content, object p1, object p2) { }

	// RVA: 0xFD8E90
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xFD9030
	public object verbose(object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xFD90D0
	public object debug(object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xFD9170
	public object info(object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xFD9210
	public object warning(object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xFD92B0
	public object error(object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xFD9350
	public object fatal(object log_format_content, object p1, object p2, object p3) { }

	// RVA: 0xFD93F0
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFD95B0
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFD9664
	public object debug(object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFD9718
	public object info(object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFD97CC
	public object warning(object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFD9880
	public object error(object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFD9934
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4) { }

	// RVA: 0xFD99E8
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFD9BC8
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFD9C8C
	public object debug(object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFD9D50
	public object info(object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFD9E14
	public object warning(object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFD9ED8
	public object error(object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFD9F9C
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4, object p5) { }

	// RVA: 0xFDA060
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFDA264
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFDA32C
	public object debug(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFDA3F4
	public object info(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFDA4BC
	public object warning(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFDA584
	public object error(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFDA64C
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6) { }

	// RVA: 0xFDA714
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFDA938
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFDAA08
	public object debug(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFDAAD8
	public object info(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFDABA8
	public object warning(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFDAC78
	public object error(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFDAD48
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7) { }

	// RVA: 0xFDAE18
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFDB07C
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFDB160
	public object debug(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFDB244
	public object info(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFDB328
	public object warning(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFDB40C
	public object error(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFDB4F0
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8) { }

	// RVA: 0xFDB5D4
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xFDB860
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xFDB96C
	public object debug(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xFDBA78
	public object info(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xFDBB84
	public object warning(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xFDBC90
	public object error(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xFDBD9C
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9) { }

	// RVA: 0xFDBEA8
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xFDC158
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xFDC278
	public object debug(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xFDC398
	public object info(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xFDC4B8
	public object warning(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xFDC5D8
	public object error(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xFDC6F8
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10) { }

	// RVA: 0xFDC818
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xFDCAFC
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xFDCC2C
	public object debug(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xFDCD5C
	public object info(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xFDCE8C
	public object warning(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xFDCFBC
	public object error(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xFDD0EC
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11) { }

	// RVA: 0xFDD21C
	protected object do_log(object category, object level, object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xFDD524
	public object verbose(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xFDD65C
	public object debug(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xFDD790
	public object info(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xFDD8C4
	public object warning(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xFDD9F8
	public object error(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xFDDB2C
	public object fatal(object log_format_content, object p1, object p2, object p3, object p4, object p5, object p6, object p7, object p8, object p9, object p10, object p11, object p12) { }

	// RVA: 0xFDDC60
	protected object do_log(object category, object level, object log_format_content, object ps) { }

	// RVA: 0xFDDEEC
	public object verbose(object log_format_content, object args) { }

	// RVA: 0xFDDF74
	public object debug(object log_format_content, object args) { }

	// RVA: 0xFDDFFC
	public object info(object log_format_content, object args) { }

	// RVA: 0xFDE084
	public object warning(object log_format_content, object args) { }

	// RVA: 0xFDE10C
	public object error(object log_format_content, object args) { }

	// RVA: 0xFDE194
	public object fatal(object log_format_content, object args) { }

	// RVA: 0xFDE21C
	private static object .cctor() { }

}

// Namespace: 
public enum appender_decode_result
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object success;
	public const object eof;
	public const object failed_invalid_handle;
	public const object failed_decode_error;
	public const object failed_io_error;
}

// Namespace: bq.tools
public class log_decoder
{

	// Fields
	private object decode_text_; // 0x8
	private object result_; // 0x10
	private object handle_; // 0x14

	// Methods

	// RVA: 0xFDE5DC
	public object .ctor(object log_file_absolute_path) { }

	// RVA: 0xFDE8A4
	protected override object Finalize() { }

	// RVA: 0xFDE978
	public object decode() { }

	// RVA: 0xFDEA6C
	public object get_last_decode_result() { }

	// RVA: 0xFDEA74
	public object get_last_decoded_log_item() { }

}

// Namespace: bq.impl
internal class ccs_invoker
{

	// Fields
	private const object LIB_NAME;

	// Methods

	// RVA: 0xFDEA7C
	public static extern object __init(object hosts, object connect_interval) { }

	// RVA: 0xFDEA98
	public static extern object __uninit() { }

	// RVA: 0xFDEAB4
	public static extern object __register_wrapper_callbacks(object on_task_callback, object on_session_open_callback, object on_session_close_callback) { }

	// RVA: 0xFDEB04
	public static extern object __register_http_callbacks(object on_http_callback) { }

	// RVA: 0xFDEB18
	public static extern object __connect(object hosts, object connect_interval) { }

	// RVA: 0xFDEB1C
	public static extern object __on_pause(object pause) { }

	// RVA: 0xFDEB20
	public static extern object __drop() { }

	// RVA: 0xFDEB24
	public static extern object __update_portrait_integer(object portrait_name, object portrait_value, object moment_send) { }

	// RVA: 0xFDEB28
	public static extern object __update_portrait_string(object portrait_name, object portrait_value, object moment_send) { }

	// RVA: 0xFDEB2C
	public static extern object __update_portrait_decimal(object portrait_name, object portrait_value, object moment_send) { }

	// RVA: 0xFDEB30
	public static extern object __get_portrait_string(object portrait_name) { }

	// RVA: 0xFDEB34
	public static extern object __release_portrait_string(object portrait_value) { }

	// RVA: 0xFDEB38
	public static extern object __print_portait() { }

	// RVA: 0xFDEB3C
	public static extern object __send_to_session_server(object cmd_name, object cmd_json_data) { }

	// RVA: 0xFDEB40
	public static extern object __set_http_server_url(object url) { }

	// RVA: 0xFDEB44
	public static extern object __send_to_http_server(object task_id, object file_count, object file_names, object file_datas, object file_lengths) { }

	// RVA: 0xFDEB48
	public static extern object __file_to_report_server(object file_path, object delete_on_finish) { }

	// RVA: 0xFDEB4C
	public static extern object __get_current_gate_info(object out_host_ptr, object out_port_ptr) { }

	// RVA: 0xFDEB50
	public static extern object __get_bq_id(object out_value_ptr) { }

	// RVA: 0xFDEB54
	public static extern object __release_string_def(object str) { }

	// RVA: 0xFDEB70
	public static extern object __register_setting_update_callback(object onSettingUpdateCallback) { }

	// RVA: 0xFDEB84
	public static extern object __get_settings_value_type(object settings_key_utf8) { }

	// RVA: 0xFDEB88
	public static extern object __get_settings_value_integer(object settings_key_utf8, object out_value_ptr) { }

	// RVA: 0xFDEBA4
	public static extern object __get_settings_value_string_utf8(object settings_key_utf8, object out_value_ptr) { }

	// RVA: 0xFDEBC0
	public static extern object __get_settings_value_decimal(object settings_key_utf8, object out_value_ptr) { }

	// RVA: 0xFDEBDC
	public static extern object __get_settings_value_bool(object settings_key_utf8, object out_value_ptr) { }

	// RVA: 0xFDEBF8
	public static extern object __has_settings_key(object settings_key_utf8) { }

	// RVA: 0xFDEC14
	public static extern object __toggle_res_collect(object on) { }

	// RVA: 0xFDEC18
	public static extern object __toggle_res_upload(object on) { }

	// RVA: 0xFDEC1C
	public static extern object __mark_res_load(object res_id) { }

	// RVA: 0xFDEC20
	public static extern object __set_download_pause(object pause) { }

	// RVA: 0xFDEC24
	public static extern object __set_res_inversal(object sec) { }

	// RVA: 0xFDEC28
	public static extern object __set_res_max_upload_once(object num) { }

	// RVA: 0xFDEC2C
	public static extern object __share_file(object share_path) { }

	// RVA: 0xFDEC48
	public static extern object __crash_test() { }

	// RVA: 0xFDEC64
	public static extern object __send_to_report_server(object table, object data, object length) { }

	// RVA: 0xFDEC80
	public static extern object __register_tail_switch_callbacks(object on_tail_callback) { }

	// RVA: 0xFDEC94
	public static extern object __tail_data_to_server(object type, object data, object length) { }

	// RVA: 0xFDECB0
	public static extern object __get_ts_file_path(object ts_check_path, object version) { }

	// RVA: 0xFDECB4
	public static extern object __use_bq_js_last_version() { }

	// RVA: 0xFDECB8
	public object .ctor() { }

}

// Namespace: bq.impl
public abstract class custom_module_base
{

	// Methods

	// RVA: -1
	public abstract object get_name() { }

	// RVA: -1
	public abstract object wether_to_accept(object cmd) { }

	// RVA: -1
	public abstract object on_execute_task(object task_id, object cmd, object cmd_data, object error_info) { }

	// RVA: 0xFDECC0
	public virtual object on_register() { }

	// RVA: 0xFDECC4
	public virtual object on_session_open() { }

	// RVA: 0xFDECC8
	public virtual object on_session_close() { }

	// RVA: 0xFDECCC
	public virtual object on_setting_update(object key) { }

	// RVA: 0xFDECD0
	protected object send_to_session_server(object cmd, object cmd_data) { }

	// RVA: 0xFDED44
	protected object send_to_http_server(object task_id, object file_paths, object file_datas) { }

	// RVA: 0xFDEDC0
	protected object update_portrait(object name, object value) { }

	// RVA: 0xFDEE30
	protected object update_portrait(object name, object value) { }

	// RVA: 0xFDEEA0
	protected object update_portrait(object name, object value) { }

	// RVA: 0xFDEF18
	protected object .ctor() { }

}

// Namespace: bq.impl
public abstract class custom_module<T0>
{

	// Fields
	private static readonly object _instance; // 0x0

	// Methods

	// RVA: -1
	public static object instance() { }

	// RVA: -1
	public static object register_module() { }

	// RVA: -1
	protected object .ctor() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: bq.impl
internal class custom_modules_manager
{

	// Fields
	private object lock_; // 0x8
	private object modules_; // 0x10
	private static readonly object _instance; // 0x0
	private object task_cb; // 0x18
	private object session_open_cb; // 0x20
	private object session_close_cb; // 0x28

	// Methods

	// RVA: 0xFDF408
	public static object instance() { }

	// RVA: 0xFDF484
	private object .ctor() { }

	// RVA: 0xFDF538
	public object init() { }

	// RVA: 0xFDFA5C
	public object uninit() { }

	// RVA: 0xFDFB84
	public object register_module(object module) { }

	// RVA: 0xFDEFA8
	private static object g_on_task_callback(object task_id, object cmd, object cmd_data, object error_info_buffer, object error_info_buffer_size) { }

	// RVA: 0xFDFDBC
	private object on_task_callback(object task_id, object cmd, object cmd_data, object error_info_buffer, object error_info_buffer_size) { }

	// RVA: 0xFDF0FC
	private static object g_on_session_open_callback() { }

	// RVA: 0xFE00D0
	private object on_session_open_callback() { }

	// RVA: 0xFDF210
	private static object g_on_session_close_callback() { }

	// RVA: 0xFE0254
	private object on_session_close_callback() { }

	// RVA: 0xFDF32C
	private static object g_on_setting_update_callback(object char_key) { }

	// RVA: 0xFE03D8
	private object on_setting_update_callback(object char_key) { }

	// RVA: 0xFE0584
	private static object .cctor() { }

}

// Namespace: bq.impl
internal struct log_context
{

	// Fields
	private object format_size_; // 0xFFFFFFFFFFFFFFF8
	private object params_size_; // 0xFFFFFFFFFFFFFFFC
	private object total_size_; // 0x0
	private object category_; // 0x8
	private object level_; // 0x10
	private object handle_; // 0x14
	private object log_params_addr_; // 0x20
	private object format_str_; // 0x28
	private object log_; // 0x48

	// Methods

	// RVA: 0xFD7CF0
	public object .ctor(object log, object category, object level, object format_str, object params_size) { }

	// RVA: 0xFD7EB8
	public object begin_copy() { }

	// RVA: 0xFE06B0
	public object get_params_data_addr() { }

	// RVA: 0xFD7FB0
	public object end_copy() { }

}

// Namespace: bq.impl
public class log_invoker
{

	// Fields
	private const object LIB_NAME;

	// Methods

	// RVA: 0xFD664C
	public static extern object __api_get_log_version() { }

	// RVA: 0xFD6654
	public static extern object __api_enable_auto_crash_handler() { }

	// RVA: 0xFD6AD0
	public static extern object __api_create_log(object log_name_utf8, object config_content_utf8, object category_count, object category_names_array_utf8) { }

	// RVA: 0xFD7978
	public static extern object __api_log_reset_config(object log_name_utf8, object config_content_utf8) { }

	// RVA: 0xFE0690
	public static extern object __api_log_buffer_alloc(object log_id, object length) { }

	// RVA: 0xFE06C0
	public static extern object __api_log_buffer_commit(object log_id, object write_handle_ptr) { }

	// RVA: 0xFD7A3C
	public static extern object __api_set_appenders_enable(object log_id, object appender_name, object enable) { }

	// RVA: 0xFD6DE8
	public static extern object __api_get_logs_count() { }

	// RVA: 0xFD6DEC
	public static extern object __api_get_log_id_by_index(object index) { }

	// RVA: 0xFD6508
	public static extern object __api_get_log_name_by_id(object log_id, object name_ptr) { }

	// RVA: 0xFD6530
	public static extern object __api_get_log_categories_count(object log_id) { }

	// RVA: 0xFD6534
	public static extern object __api_get_log_category_name_by_index(object log_id, object category_index, object category_name_ptr) { }

	// RVA: 0xFD6524
	public static extern object __api_get_log_merged_log_level_bitmap_by_log_id(object log_id) { }

	// RVA: 0xFD6528
	public static extern object __api_get_log_category_masks_array_by_log_id(object log_id) { }

	// RVA: 0xFD652C
	public static extern object __api_get_log_print_stack_level_bitmap_by_log_id(object log_id) { }

	// RVA: 0xFD75E4
	public static extern object __api_log_device_console(object level, object content) { }

	// RVA: 0xFD6DF8
	public static extern object __api_force_flush(object log_id) { }

	// RVA: 0xFD6718
	public static extern object __api_get_file_base_dir(object is_in_sandbox) { }

	// RVA: 0xFDE8A0
	public static extern object __api_log_decoder_create(object log_file_path_utf8, object out_handle) { }

	// RVA: 0xFDEA68
	public static extern object __api_log_decoder_decode(object handle, object out_decoded_log_text) { }

	// RVA: 0xFDE938
	public static extern object __api_log_decoder_destroy(object handle) { }

	// RVA: 0xFE06F8
	public static extern object __api_log_decode(object in_file, object out_file) { }

	// RVA: 0xFD7120
	public static extern object __api_register_console_callbacks(object on_console_callback) { }

	// RVA: 0xFD7324
	public static extern object __api_unregister_console_callbacks(object on_console_callback) { }

	// RVA: 0xFD733C
	public static extern object __api_set_console_buffer_enable(object enable) { }

	// RVA: 0xFD7514
	public static extern object __api_fetch_and_remove_console_buffer(object on_console_callback, object pass_through_param) { }

	// RVA: 0xFD7AE8
	public static extern object __api_take_snapshot_string(object log_id, object use_gmt_time, object out_snapshot_string) { }

	// RVA: 0xFD7AEC
	public static extern object __api_release_snapshot_string(object log_id, object snapshot_string) { }

	// RVA: 0xFD6E00
	public static extern object __api_uninit() { }

	// RVA: 0xFE0714
	public object .ctor() { }

}

// Namespace: bq.impl
public struct param_wrapper
{

	// Fields
	private object type_; // 0xFFFFFFFFFFFFFFF8
	private object pod_value_; // 0x0
	private object string_value_; // 0x8
	private object storage_size_; // 0x10
	private object aligned_size_; // 0x14

	// Properties
	public object storage_size { get; }
	public object aligned_size { get; }
	public object string_value { get; }

	// Methods

	// RVA: 0xFE07CC
	public object get_storage_size() { }

	// RVA: 0xFE07DC
	public object get_aligned_size() { }

	// RVA: 0xFE07EC
	public object get_string_value() { }

	// RVA: 0xFD841C
	public object write(object addr) { }

	// RVA: 0xFE0804
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE061C
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0824
	public static object create_wrapper(object obj) { }

	// RVA: 0xFE0890
	public static object create_wrapper(object obj) { }

	// RVA: 0xFE0A5C
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0A7C
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE09C4
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE09E4
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0A9C
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0A04
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0ABC
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0A24
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0ADC
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0AF8
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0A40
	public static object op_Implicit(object obj) { }

	// RVA: 0xFE0B1C
	public static object op_Implicit(object obj) { }

}

// Namespace: bq.impl
public class utf8_encoder
{

	// Methods

	// RVA: 0xFDE690
	public static object get_utf8_array(object s) { }

	// RVA: 0xFD699C
	public static object alloc_utf8_fixed_str(object s) { }

	// RVA: 0xFD6AD4
	public static object release_utf8_fixed_str(object s) { }

	// RVA: 0xFE0B94
	public object .ctor() { }

}

// Namespace: bq.def
public sealed class MonoPInvokeCallbackAttribute
{

	// Methods

	// RVA: 0xFE0B9C
	public object .ctor(object t) { }

}

// Namespace: bq.def
public enum enum_task_ack
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object success;
	public const object pending;
	public const object ignore;
	public const object error;
	public const object unrecognized;
}

// Namespace: bq.def
public enum enum_json_value_type
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object t_boolean;
	public const object t_decimal;
	public const object t_integral;
	public const object t_string;
	public const object t_array;
	public const object t_object;
	public const object t_null;
}

// Namespace: bq.def
public sealed class type_func_ptr_custom_modules_manager_on_task_callback
{

	// Methods

	// RVA: 0xFDF7F4
	public object .ctor(object object, object method) { }

	// RVA: 0xFE0C80
	public virtual object Invoke(object task_id, object cmd, object cmd_data, object error_info_buffer, object error_info_buffer_size) { }

	// RVA: 0xFE0C94
	public virtual object BeginInvoke(object task_id, object cmd, object cmd_data, object error_info_buffer, object error_info_buffer_size, object callback, object object) { }

	// RVA: 0xFE0D94
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq.def
public sealed class type_func_ptr_on_session_open_callback
{

	// Methods

	// RVA: 0xFDF88C
	public object .ctor(object object, object method) { }

	// RVA: 0xFE0E20
	public virtual object Invoke() { }

	// RVA: 0xFE0E34
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0xFE0E8C
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq.def
public sealed class type_func_ptr_on_session_closed_callback
{

	// Methods

	// RVA: 0xFDF920
	public object .ctor(object object, object method) { }

	// RVA: 0xFE0EF0
	public virtual object Invoke() { }

	// RVA: 0xFE0F04
	public virtual object BeginInvoke(object callback, object object) { }

	// RVA: 0xFE0F5C
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq.def
public sealed class type_func_ptr_on_http_callback
{

	// Methods

	// RVA: 0xFE1070
	public object .ctor(object object, object method) { }

	// RVA: 0xFE1108
	public virtual object Invoke(object task_id, object url, object session, object token, object file_count, object file_path, object file_data, object data_length) { }

	// RVA: 0xFE1124
	public virtual object BeginInvoke(object task_id, object url, object session, object token, object file_count, object file_path, object file_data, object data_length, object callback, object object) { }

	// RVA: 0xFE1220
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq.def
public sealed class type_func_ptr_on_setting_update_callback
{

	// Methods

	// RVA: 0xFDF9B4
	public object .ctor(object object, object method) { }

	// RVA: 0xFE12C4
	public virtual object Invoke(object key) { }

	// RVA: 0xFE12D8
	public virtual object BeginInvoke(object key, object callback, object object) { }

	// RVA: 0xFE1328
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq.def
public sealed class type_func_ptr_on_tail_switch_callback
{

	// Methods

	// RVA: 0xFE13CC
	public object .ctor(object object, object method) { }

	// RVA: 0xFE1464
	public virtual object Invoke(object type, object interval, object open) { }

	// RVA: 0xFE1478
	public virtual object BeginInvoke(object type, object interval, object open, object callback, object object) { }

	// RVA: 0xFE156C
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq.def
public class log_category_base
{

	// Fields
	protected object index; // 0x8

	// Methods

	// RVA: 0xFE1578
	public static object get_index(object category) { }

	// RVA: 0xFDE31C
	public object .ctor() { }

}

// Namespace: bq.def
public enum enum_buffer_result_code
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object success;
	public const object err_empty_ring_buffer;
	public const object err_not_enough_space;
	public const object err_alloc_failed_by_race_condition;
	public const object err_alloc_size_invalid;
	public const object err_buffer_not_inited;
	public const object result_code_count;
}

// Namespace: bq.def
public enum log_level
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object verbose;
	public const object debug;
	public const object info;
	public const object warning;
	public const object error;
	public const object fatal;
	public const object log_level_max;
}

// Namespace: bq.def
internal enum log_arg_type_enum
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object unsupported_type;
	public const object null_type;
	public const object pointer_type;
	public const object bool_type;
	public const object char_type;
	public const object char16_type;
	public const object char32_type;
	public const object int8_type;
	public const object uint8_type;
	public const object int16_type;
	public const object uint16_type;
	public const object int32_type;
	public const object uint32_type;
	public const object int64_type;
	public const object uint64_type;
	public const object float_type;
	public const object double_type;
	public const object string_utf8_type;
	public const object string_utf16_type;
}

// Namespace: bq.def
public struct _log_api_ring_buffer_write_handle
{

	// Fields
	public object data_ptr; // 0xFFFFFFFFFFFFFFF8
	public object result_code; // 0x0
}

// Namespace: bq.def
internal struct _log_api_ring_buffer_read_handle
{

	// Fields
	public object data_ptr; // 0xFFFFFFFFFFFFFFF8
	public object result_code; // 0x0
}

// Namespace: bq.def
internal struct _log_api_console_log_data_head
{

	// Fields
	public object log_id; // 0xFFFFFFFFFFFFFFF8
	public object category_idx; // 0x0
	public object level; // 0x4
	public object log_len; // 0x8
	public object log_str; // 0xC
}

// Namespace: bq.def
internal struct _log_head_def
{

	// Fields
	public object timestamp_epoch; // 0xFFFFFFFFFFFFFFF8
	public object category_idx; // 0x0
	public object level; // 0x4
	public object log_format_str_type; // 0x5
	public object log_args_offset; // 0x6
	public object ext_info_offset; // 0xA
	public object dummy; // 0xE
}

// Namespace: bq.def
public struct _api_string_def
{

	// Fields
	public object str; // 0xFFFFFFFFFFFFFFF8
	public object len; // 0x0
}

// Namespace: bq.def
public class log_console_item
{

	// Fields
	public object log_id; // 0x8
	public object category_idx; // 0x10
	public object level; // 0x14
	public object log_str; // 0x18

	// Methods

	// RVA: 0xFE1598
	public object .ctor() { }

}

// Namespace: bq.def
public sealed class type_func_ptr_console_callback
{

	// Methods

	// RVA: 0xFD7088
	public object .ctor(object object, object method) { }

	// RVA: 0xFE1660
	public virtual object Invoke(object log_id, object category_idx, object log_level, object content, object length) { }

	// RVA: 0xFE1674
	public virtual object BeginInvoke(object log_id, object category_idx, object log_level, object content, object length, object callback, object object) { }

	// RVA: 0xFE1788
	public virtual object EndInvoke(object result) { }

}

// Namespace: bq.def
public sealed class type_func_ptr_console_buffer_fetch_callback
{

	// Methods

	// RVA: 0xFD747C
	public object .ctor(object object, object method) { }

	// RVA: 0xFE1864
	public virtual object Invoke(object pass_through_param, object log_id, object category_idx, object log_level, object content, object length) { }

	// RVA: 0xFE1878
	public virtual object BeginInvoke(object pass_through_param, object log_id, object category_idx, object log_level, object content, object length, object callback, object object) { }

	// RVA: 0xFE19B0
	public virtual object EndInvoke(object result) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=3429
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=3765
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 431E58BDD599317844F4EA5F21A3C0DD9C6C0C56AADE309B85C881149E3C60BF; // 0x0
	internal static readonly object 6AAA118F565589A3853FE355B541E41050ED89682A416BED314CFFE967535F2A; // 0xEB5
	internal static readonly object 7D1AD61986FDC2C659FC47776C5E4D727D737B626157F87F4DFE83587853210C; // 0x1C20
}

