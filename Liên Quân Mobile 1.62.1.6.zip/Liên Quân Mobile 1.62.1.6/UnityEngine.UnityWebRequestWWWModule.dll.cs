// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public class WWW
{

	// Fields
	private object _uwr; // 0x8
	private object _responseHeaders; // 0x10

	// Properties
	public object bytes { get; }
	public object error { get; }
	public object isDone { get; }
	public object responseHeaders { get; }
	public object text { get; }
	public object texture { get; }
	public object url { get; }
	public override object keepWaiting { get; }

	// Methods

	// RVA: 0x76F3678
	public static object EscapeURL(object s) { }

	// RVA: 0x76F36A8
	public static object EscapeURL(object s, object e) { }

	// RVA: 0x76F36B0
	public static object UnEscapeURL(object s) { }

	// RVA: 0x76F36E0
	public static object UnEscapeURL(object s, object e) { }

	// RVA: 0x76F36E8
	public object .ctor(object url) { }

	// RVA: 0x76F3734
	public object .ctor(object url, object form) { }

	// RVA: 0x76F37B0
	public object .ctor(object url, object postData) { }

	// RVA: 0x76F3950
	public object .ctor(object url, object postData, object headers) { }

	// RVA: 0x76F3C58
	public object get_bytes() { }

	// RVA: 0x76F3E24
	public object get_error() { }

	// RVA: 0x76F3F90
	public object get_isDone() { }

	// RVA: 0x76F3FB4
	public object get_responseHeaders() { }

	// RVA: 0x76F41CC
	public object get_text() { }

	// RVA: 0x76F4274
	private object CreateTextureFromDownloadedData(object markNonReadable) { }

	// RVA: 0x76F43A0
	public object get_texture() { }

	// RVA: 0x76F43A8
	public object get_url() { }

	// RVA: 0x76F43CC
	public override object get_keepWaiting() { }

	// RVA: 0x76F43F0
	public object Dispose() { }

	// RVA: 0x76F3D04
	private object WaitUntilDoneIfPossible() { }

}

