// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public enum WindZoneMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Directional;
	public const object Spherical;
}

// Namespace: UnityEngine
public class WindZone
{

	// Properties
	public object mode { get; set; }
	public object radius { get; set; }
	public object windMain { get; set; }
	public object windTurbulence { get; set; }
	public object windPulseMagnitude { get; set; }
	public object windPulseFrequency { get; set; }

	// Methods

	// RVA: 0x76F76B0
	public object get_mode() { }

	// RVA: 0x76F7700
	public object set_mode(object value) { }

	// RVA: 0x76F7764
	public object get_radius() { }

	// RVA: 0x76F77B4
	public object set_radius(object value) { }

	// RVA: 0x76F7818
	public object get_windMain() { }

	// RVA: 0x76F7868
	public object set_windMain(object value) { }

	// RVA: 0x76F78CC
	public object get_windTurbulence() { }

	// RVA: 0x76F791C
	public object set_windTurbulence(object value) { }

	// RVA: 0x76F7980
	public object get_windPulseMagnitude() { }

	// RVA: 0x76F79D0
	public object set_windPulseMagnitude(object value) { }

	// RVA: 0x76F7A34
	public object get_windPulseFrequency() { }

	// RVA: 0x76F7A84
	public object set_windPulseFrequency(object value) { }

	// RVA: 0x76F7AE8
	public object .ctor() { }

}

