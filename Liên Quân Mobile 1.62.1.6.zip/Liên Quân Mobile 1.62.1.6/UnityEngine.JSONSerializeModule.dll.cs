// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public static class JsonUtility
{

	// Methods

	// RVA: 0x743A6AC
	private static object ToJsonInternal(object obj, object prettyPrint) { }

	// RVA: 0x743A710
	private static object FromJsonInternal(object json, object objectToOverwrite, object type) { }

	// RVA: 0x743A77C
	public static object ToJson(object obj) { }

	// RVA: 0x743A784
	public static object ToJson(object obj, object prettyPrint) { }

	// RVA: -1
	public static object FromJson(object json) { }

	// RVA: 0x743A91C
	public static object FromJson(object json, object type) { }

	// RVA: 0x743AB44
	public static object FromJsonOverwrite(object json, object objectToOverwrite) { }

}

