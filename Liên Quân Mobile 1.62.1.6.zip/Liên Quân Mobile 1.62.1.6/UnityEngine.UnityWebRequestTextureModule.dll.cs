// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine.Networking
public sealed class DownloadHandlerTexture
{

	// Fields
	private object m_NativeData; // 0x10
	private object mNonReadable; // 0x20

	// Properties
	public object texture { get; }

	// Methods

	// RVA: 0x76F33BC
	private static object Create(object obj, object readable, object savePath) { }

	// RVA: 0x76F3428
	private object InternalCreateTexture(object readable, object savePath) { }

	// RVA: 0x76F3488
	public object .ctor(object readable) { }

	// RVA: 0x76F352C
	public object .ctor(object readable, object savePath) { }

	// RVA: 0x76F359C
	protected override object GetNativeData() { }

	// RVA: 0x76F35A8
	public override object Dispose() { }

	// RVA: 0x76F35D8
	public object get_texture() { }

	// RVA: 0x76F3628
	private object InternalGetTextureNative() { }

}

