// Namespace: 
internal interface IActivationFactory
{

	// Methods

	// RVA: -1
	public override object ActivateInstance() { }

}

// Namespace: System
internal class __Il2CppComObject
{

	// Methods

	// RVA: 0x7893E5C
	protected override object Finalize() { }

}

// Namespace: System
internal sealed class __Il2CppComDelegate
{

	// Methods

	// RVA: 0x7893EA0
	protected override object Finalize() { }

}

