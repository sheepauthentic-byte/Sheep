// Namespace: 
internal class <Module>
{
}

// Namespace: 
public sealed class AudioConfigurationChangeHandler
{

	// Methods

	// RVA: 0x73471CC
	public object .ctor(object object, object method) { }

	// RVA: 0x7347264
	public virtual object Invoke(object deviceWasChanged) { }

}

// Namespace: 
public static class Mobile
{

	// Fields
	private static object <muteState>k__BackingField; // 0x0
	private static object _stopAudioOutputOnMute; // 0x1
	private static object OnMuteStateChanged; // 0x8

	// Properties
	public static object muteState { get; set; }
	public static object stopAudioOutputOnMute { get; }

	// Methods

	// RVA: 0x7347278
	public static object get_muteState() { }

	// RVA: 0x73472C4
	private static object set_muteState(object value) { }

	// RVA: 0x734731C
	public static object get_stopAudioOutputOnMute() { }

	// RVA: 0x7347368
	internal static object InvokeOnMuteStateChanged(object mute) { }

	// RVA: 0x73475B4
	internal static object InvokeIsStopAudioOutputOnMuteEnabled() { }

	// RVA: 0x7347574
	public static object StartAudioOutput() { }

	// RVA: 0x7347534
	public static object StopAudioOutput() { }

}

// Namespace: UnityEngine
public sealed class AudioSettings
{

	// Fields
	private static object OnAudioConfigurationChanged; // 0x0
	private static object OnAudioSystemShuttingDown; // 0x8
	private static object OnAudioSystemStartedUp; // 0x10

	// Methods

	// RVA: 0x7346F90
	internal static object InvokeOnAudioConfigurationChanged(object deviceWasChanged) { }

	// RVA: 0x734700C
	internal static object InvokeOnAudioSystemShuttingDown() { }

	// RVA: 0x7347074
	internal static object InvokeOnAudioSystemStartedUp() { }

	// RVA: 0x73470DC
	internal static object StartAudioOutput() { }

	// RVA: 0x734711C
	internal static object StopAudioOutput() { }

}

// Namespace: 
public sealed class PCMReaderCallback
{

	// Methods

	// RVA: 0x7348458
	public object .ctor(object object, object method) { }

	// RVA: 0x7348500
	public virtual object Invoke(object data) { }

}

// Namespace: 
public sealed class PCMSetPositionCallback
{

	// Methods

	// RVA: 0x7348584
	public object .ctor(object object, object method) { }

	// RVA: 0x734861C
	public virtual object Invoke(object position) { }

}

// Namespace: UnityEngine
public sealed class AudioClip
{

	// Fields
	private object m_PCMReaderCallback; // 0x10
	private object m_PCMSetPositionCallback; // 0x18

	// Properties
	public object length { get; }
	public object samples { get; }
	public object channels { get; }
	public object frequency { get; }

	// Methods

	// RVA: 0x7347600
	private object .ctor() { }

	// RVA: 0x7347690
	private static object GetData(object clip, object data, object numSamples, object samplesOffset) { }

	// RVA: 0x7347710
	private static object SetData(object clip, object data, object numsamples, object samplesOffset) { }

	// RVA: 0x7347790
	private static object Construct_Internal() { }

	// RVA: 0x73477D0
	private object GetName() { }

	// RVA: 0x7347820
	private object CreateUserSound(object name, object lengthSamples, object channels, object frequency, object stream) { }

	// RVA: 0x73478BC
	public object get_length() { }

	// RVA: 0x734790C
	public object get_samples() { }

	// RVA: 0x734795C
	public object get_channels() { }

	// RVA: 0x73479AC
	public object get_frequency() { }

	// RVA: 0x73479FC
	public object GetData(object data, object offsetSamples) { }

	// RVA: 0x7347BB8
	public object SetData(object data, object offsetSamples) { }

	// RVA: 0x7347E08
	public static object Create(object name, object lengthSamples, object channels, object frequency, object stream) { }

	// RVA: 0x7347E14
	public static object Create(object name, object lengthSamples, object channels, object frequency, object stream, object pcmreadercallback, object pcmsetpositioncallback) { }

	// RVA: 0x73480F0
	private object add_m_PCMReaderCallback(object value) { }

	// RVA: 0x7348238
	private object remove_m_PCMReaderCallback(object value) { }

	// RVA: 0x7348194
	private object add_m_PCMSetPositionCallback(object value) { }

	// RVA: 0x73482DC
	private object remove_m_PCMSetPositionCallback(object value) { }

	// RVA: 0x7348380
	private object InvokePCMReaderCallback_Internal(object data) { }

	// RVA: 0x734839C
	private object InvokePCMSetPositionCallback_Internal(object position) { }

}

// Namespace: UnityEngine
public class AudioBehaviour
{

	// Methods

	// RVA: 0x7348630
	public object .ctor() { }

}

// Namespace: UnityEngine
public sealed class AudioListener
{
}

// Namespace: UnityEngine
public sealed class AudioSource
{

	// Properties
	public object volume { get; set; }
	public object pitch { get; set; }
	public object clip { get; set; }
	public object playOnAwake { set; }
	public object spatialBlend { set; }
	public object minDistance { set; }

	// Methods

	// RVA: 0x7348638
	private static object GetPitch(object source) { }

	// RVA: 0x7348688
	private static object SetPitch(object source, object pitch) { }

	// RVA: 0x73486EC
	private static object PlayHelper(object source, object delay) { }

	// RVA: 0x7348750
	private static object PlayOneShotHelper(object source, object clip, object volumeScale) { }

	// RVA: 0x73487C8
	public object get_volume() { }

	// RVA: 0x7348818
	public object set_volume(object value) { }

	// RVA: 0x734887C
	public object get_pitch() { }

	// RVA: 0x73488CC
	public object set_pitch(object value) { }

	// RVA: 0x7348930
	public object get_clip() { }

	// RVA: 0x7348980
	public object set_clip(object value) { }

	// RVA: 0x73489E4
	public object Play() { }

	// RVA: 0x7348A3C
	public object PlayOneShot(object clip) { }

	// RVA: 0x7348A44
	public object PlayOneShot(object clip, object volumeScale) { }

	// RVA: 0x7348B64
	public static object PlayClipAtPoint(object clip, object position, object volume) { }

	// RVA: 0x7348ED4
	public object set_playOnAwake(object value) { }

	// RVA: 0x7348E70
	public object set_spatialBlend(object value) { }

	// RVA: 0x7348F38
	public object set_minDistance(object value) { }

	// RVA: 0x7348F9C
	public object .ctor() { }

}

// Namespace: UnityEngine.Audio
public struct AudioClipPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x7348FA4
	public static object Create(object graph, object clip, object looping) { }

	// RVA: 0x73490EC
	private static object CreateHandle(object graph, object clip, object looping) { }

	// RVA: 0x7349208
	internal object .ctor(object handle) { }

	// RVA: 0x73493AC
	public object GetHandle() { }

	// RVA: 0x73493C4
	public static object op_Implicit(object playable) { }

	// RVA: 0x73493F8
	public static object op_Explicit(object playable) { }

	// RVA: 0x7349480
	public object Equals(object other) { }

	// RVA: 0x7349588
	internal object SetVolume(object value) { }

	// RVA: 0x73496DC
	internal object SetStereoPan(object value) { }

	// RVA: 0x7349830
	internal object SetSpatialBlend(object value) { }

	// RVA: 0x7349984
	public object Seek(object startTime, object startDelay, object duration) { }

	// RVA: 0x7349670
	private static object SetVolumeInternal(object hdl, object volume) { }

	// RVA: 0x73497C4
	private static object SetStereoPanInternal(object hdl, object stereoPan) { }

	// RVA: 0x7349918
	private static object SetSpatialBlendInternal(object hdl, object spatialBlend) { }

	// RVA: 0x7349B70
	private static object SetStartDelayInternal(object hdl, object delay) { }

	// RVA: 0x7349BD4
	private static object SetPauseDelayInternal(object hdl, object delay) { }

	// RVA: 0x7349324
	private static object InternalCreateAudioClipPlayable(object graph, object clip, object looping, object handle) { }

}

// Namespace: UnityEngine.Audio
public struct AudioMixerPlayable
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x7349C40
	public static object Create(object graph, object inputCount, object normalizeInputVolumes) { }

	// RVA: 0x7349C7C
	private static object CreateHandle(object graph, object inputCount, object normalizeInputVolumes) { }

	// RVA: 0x7349D9C
	internal object .ctor(object handle) { }

	// RVA: 0x7349F2C
	public object GetHandle() { }

	// RVA: 0x7349F44
	public static object op_Implicit(object playable) { }

	// RVA: 0x7349F78
	public object Equals(object other) { }

	// RVA: 0x7349EB8
	private static object CreateAudioMixerPlayableInternal(object graph, object normalizeInputVolumes, object handle) { }

}

// Namespace: UnityEngine.Audio
public static class AudioPlayableBinding
{

	// Methods

	// RVA: 0x734A080
	public static object Create(object name, object key) { }

	// RVA: 0x734A1B8
	private static object CreateAudioOutput(object graph, object name) { }

}

// Namespace: UnityEngine.Audio
internal static class AudioPlayableGraphExtensions
{

	// Methods

	// RVA: 0x734A364
	internal static object InternalCreateAudioOutput(object graph, object name, object handle) { }

}

// Namespace: UnityEngine.Audio
public struct AudioPlayableOutput
{

	// Fields
	private object m_Handle; // 0xFFFFFFFFFFFFFFF8

	// Properties
	public static object Null { get; }

	// Methods

	// RVA: 0x734A1FC
	public static object Create(object graph, object name, object target) { }

	// RVA: 0x734A450
	internal object .ctor(object handle) { }

	// RVA: 0x734A3D0
	public static object get_Null() { }

	// RVA: 0x734A5D8
	public object GetHandle() { }

	// RVA: 0x734A330
	public static object op_Implicit(object output) { }

	// RVA: 0x734A5F0
	public static object op_Explicit(object output) { }

	// RVA: 0x734A56C
	public object SetTarget(object value) { }

	// RVA: 0x734A740
	public object SetEvaluateOnSeek(object value) { }

	// RVA: 0x734A678
	private static object InternalSetTarget(object output, object target) { }

	// RVA: 0x734A7A4
	private static object InternalSetEvaluateOnSeek(object output, object value) { }

}

// Namespace: 
public sealed class SampleFramesHandler
{

	// Methods

	// RVA: 0x734ABB8
	public object .ctor(object object, object method) { }

	// RVA: 0x734ACC4
	public virtual object Invoke(object provider, object sampleFrameCount) { }

}

// Namespace: UnityEngine.Experimental.Audio
public class AudioSampleProvider
{

	// Fields
	private object sampleFramesAvailable; // 0x8
	private object sampleFramesOverflow; // 0x10

	// Methods

	// RVA: 0x734A86C
	private object InvokeSampleFramesAvailable(object sampleFrameCount) { }

	// RVA: 0x734A890
	private object InvokeSampleFramesOverflow(object droppedSampleFrameCount) { }

}

