// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngine
public enum FontStyle
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Bold;
	public const object Italic;
	public const object BoldAndItalic;
}

// Namespace: UnityEngine
public enum TextGenerationError
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object CustomSizeOnNonDynamicFont;
	public const object CustomStyleOnNonDynamicFont;
	public const object NoFont;
}

// Namespace: UnityEngine
public struct TextGenerationSettings
{

	// Fields
	public object font; // 0xFFFFFFFFFFFFFFF8
	public object color; // 0x0
	public object fontSize; // 0x10
	public object lineSpacing; // 0x14
	public object richText; // 0x18
	public object scaleFactor; // 0x1C
	public object fontStyle; // 0x20
	public object textAnchor; // 0x24
	public object alignByGeometry; // 0x28
	public object resizeTextForBestFit; // 0x29
	public object resizeTextMinSize; // 0x2C
	public object resizeTextMaxSize; // 0x30
	public object updateBounds; // 0x34
	public object verticalOverflow; // 0x38
	public object horizontalOverflow; // 0x3C
	public object generationExtents; // 0x40
	public object pivot; // 0x48
	public object generateOutOfBounds; // 0x50

	// Methods

	// RVA: 0x74DA00C
	private object CompareColors(object left, object right) { }

	// RVA: 0x74DA194
	private object CompareVector2(object left, object right) { }

	// RVA: 0x74DA39C
	public object Equals(object other) { }

}

// Namespace: UnityEngine
public class TextGenerator
{

	// Fields
	internal object m_Ptr; // 0x8
	protected object m_LastString; // 0x10
	protected object m_LastSettings; // 0x18
	protected object m_HasGenerated; // 0x78
	protected object m_LastValid; // 0x7C
	protected static object m_Verts; // 0x0
	protected readonly object m_Characters; // 0x80
	protected readonly object m_Lines; // 0x88
	protected object m_CachedVerts; // 0x90
	protected object m_CachedCharacters; // 0x91
	protected object m_CachedLines; // 0x92

	// Properties
	public object characterCountVisible { get; }
	public object verts { get; }
	public object characters { get; }
	public object lines { get; }
	public object rectExtents { get; }
	public object characterCount { get; }
	public object lineCount { get; }

	// Methods

	// RVA: 0x74DA62C
	public object .ctor() { }

	// RVA: 0x74DA634
	public object .ctor(object initialCapacity) { }

	// RVA: 0x74DA79C
	protected override object Finalize() { }

	// RVA: 0x74DA8CC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x74DA9F0
	public object get_characterCountVisible() { }

	// RVA: 0x74DAAA0
	protected object ValidatedSettings(object settings) { }

	// RVA: 0x74DAE34
	public object Invalidate() { }

	// RVA: 0x74DAE3C
	public object GetCharacters(object characters) { }

	// RVA: 0x74DAF04
	public object GetLines(object lines) { }

	// RVA: 0x74DAFCC
	public object GetVertices(object vertices) { }

	// RVA: 0x74DB094
	public object GetPreferredWidth(object str, object settings) { }

	// RVA: 0x74DB2DC
	public object GetPreferredHeight(object str, object settings) { }

	// RVA: 0x74DB3DC
	public object PopulateWithErrors(object str, object settings, object context) { }

	// RVA: 0x74DB198
	public object Populate(object str, object settings) { }

	// RVA: 0x74DB634
	private object PopulateWithError(object str, object settings) { }

	// RVA: 0x74DB700
	private object PopulateAlways(object str, object settings) { }

	// RVA: 0x74DBAF8
	public object get_verts() { }

	// RVA: 0x74DBBD8
	public object get_characters() { }

	// RVA: 0x74DBC54
	public object get_lines() { }

	// RVA: 0x74DB27C
	public object get_rectExtents() { }

	// RVA: 0x74DAA50
	public object get_characterCount() { }

	// RVA: 0x74DBD34
	public object get_lineCount() { }

	// RVA: 0x74DA75C
	private static object Internal_Create() { }

	// RVA: 0x74DA9A0
	private static object Internal_Destroy(object ptr) { }

	// RVA: 0x74DBD84
	internal object Populate_Internal(object str, object font, object color, object fontSize, object scaleFactor, object lineSpacing, object style, object richText, object resizeTextForBestFit, object resizeTextMinSize, object resizeTextMaxSize, object verticalOverFlow, object horizontalOverflow, object updateBounds, object anchor, object extentsX, object extentsY, object pivotX, object pivotY, object generateOutOfBounds, object alignByGeometry, object error) { }

	// RVA: 0x74DB920
	internal object Populate_Internal(object str, object font, object color, object fontSize, object scaleFactor, object lineSpacing, object style, object richText, object resizeTextForBestFit, object resizeTextMinSize, object resizeTextMaxSize, object verticalOverFlow, object horizontalOverflow, object updateBounds, object anchor, object extents, object pivot, object generateOutOfBounds, object alignByGeometry, object error) { }

	// RVA: 0x74DB030
	private object GetVerticesInternal(object vertices) { }

	// RVA: 0x74DAEA0
	private object GetCharactersInternal(object characters) { }

	// RVA: 0x74DAF68
	private object GetLinesInternal(object lines) { }

	// RVA: 0x74DBFCC
	private static object .cctor() { }

	// RVA: 0x74DBCD0
	private object get_rectExtents_Injected(object ret) { }

	// RVA: 0x74DBEC0
	private object Populate_Internal_Injected(object str, object font, object color, object fontSize, object scaleFactor, object lineSpacing, object style, object richText, object resizeTextForBestFit, object resizeTextMinSize, object resizeTextMaxSize, object verticalOverFlow, object horizontalOverflow, object updateBounds, object anchor, object extentsX, object extentsY, object pivotX, object pivotY, object generateOutOfBounds, object alignByGeometry, object error) { }

}

// Namespace: UnityEngine
public enum TextAnchor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object UpperLeft;
	public const object UpperCenter;
	public const object UpperRight;
	public const object MiddleLeft;
	public const object MiddleCenter;
	public const object MiddleRight;
	public const object LowerLeft;
	public const object LowerCenter;
	public const object LowerRight;
}

// Namespace: UnityEngine
public enum HorizontalWrapMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Wrap;
	public const object Overflow;
}

// Namespace: UnityEngine
public enum VerticalWrapMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Truncate;
	public const object Overflow;
}

// Namespace: UnityEngine
public sealed class TextMesh
{

	// Properties
	public object text { get; set; }
	public object font { set; }
	public object fontSize { get; set; }
	public object anchor { set; }
	public object characterSize { set; }
	public object color { set; }

	// Methods

	// RVA: 0x74DC060
	public object get_text() { }

	// RVA: 0x74DC0B0
	public object set_text(object value) { }

	// RVA: 0x74DC114
	public object set_font(object value) { }

	// RVA: 0x74DC178
	public object get_fontSize() { }

	// RVA: 0x74DC1C8
	public object set_fontSize(object value) { }

	// RVA: 0x74DC22C
	public object set_anchor(object value) { }

	// RVA: 0x74DC290
	public object set_characterSize(object value) { }

	// RVA: 0x74DC2F4
	public object set_color(object value) { }

	// RVA: 0x74DC368
	private object set_color_Injected(object value) { }

}

// Namespace: UnityEngine
public struct CharacterInfo
{

	// Fields
	public object index; // 0xFFFFFFFFFFFFFFF8
	public object uv; // 0xFFFFFFFFFFFFFFFC
	public object vert; // 0xC
	public object width; // 0x1C
	public object size; // 0x20
	public object style; // 0x24
	public object flipped; // 0x28

	// Properties
	public object advance { get; }
	public object minY { get; }
	public object maxY { get; }
	public object minX { get; }
	public object maxX { get; }
	internal object uvBottomLeftUnFlipped { get; }
	internal object uvBottomRightUnFlipped { get; }
	internal object uvTopRightUnFlipped { get; }
	internal object uvTopLeftUnFlipped { get; }
	public object uvBottomLeft { get; }
	public object uvBottomRight { get; }
	public object uvTopRight { get; }
	public object uvTopLeft { get; }

	// Methods

	// RVA: 0x74DC440
	public object get_advance() { }

	// RVA: 0x74DC620
	public object get_minY() { }

	// RVA: 0x74DC670
	public object get_maxY() { }

	// RVA: 0x74DC6B0
	public object get_minX() { }

	// RVA: 0x74DC6F0
	public object get_maxX() { }

	// RVA: 0x74DC740
	internal object get_uvBottomLeftUnFlipped() { }

	// RVA: 0x74DC750
	internal object get_uvBottomRightUnFlipped() { }

	// RVA: 0x74DC770
	internal object get_uvTopRightUnFlipped() { }

	// RVA: 0x74DC798
	internal object get_uvTopLeftUnFlipped() { }

	// RVA: 0x74DC7B8
	public object get_uvBottomLeft() { }

	// RVA: 0x74DC7C8
	public object get_uvBottomRight() { }

	// RVA: 0x74DC818
	public object get_uvTopRight() { }

	// RVA: 0x74DC840
	public object get_uvTopLeft() { }

}

// Namespace: UnityEngine
public struct UICharInfo
{

	// Fields
	public object cursorPos; // 0xFFFFFFFFFFFFFFF8
	public object charWidth; // 0x0
}

// Namespace: UnityEngine
public struct UILineInfo
{

	// Fields
	public object startCharIdx; // 0xFFFFFFFFFFFFFFF8
	public object height; // 0xFFFFFFFFFFFFFFFC
	public object topY; // 0x0
	public object leading; // 0x4
}

// Namespace: UnityEngine
public struct UIVertex
{

	// Fields
	public object position; // 0xFFFFFFFFFFFFFFF8
	public object normal; // 0x4
	public object tangent; // 0x10
	public object color; // 0x20
	public object uv0; // 0x24
	public object uv1; // 0x2C
	public object uv2; // 0x34
	public object uv3; // 0x3C
	private static readonly object s_DefaultColor; // 0x0
	private static readonly object s_DefaultTangent; // 0xFFFFFFFFFFFFFFF4
	public static object simpleVert; // 0x4

	// Methods

	// RVA: 0x74DC890
	private static object .cctor() { }

}

// Namespace: 
public sealed class FontTextureRebuildCallback
{

	// Methods

	// RVA: 0x74DD6CC
	public object .ctor(object object, object method) { }

	// RVA: 0x74DD760
	public virtual object Invoke() { }

}

// Namespace: UnityEngine
public sealed class Font
{

	// Fields
	private static object textureRebuilt; // 0x0
	private object m_FontTextureRebuildCallback; // 0x10

	// Properties
	public object material { get; }
	public object dynamic { get; }
	public object ascent { get; }
	public object fontSize { get; }
	public object characterInfo { get; set; }
	public object lineHeight { get; }

	// Methods

	// RVA: 0x74DC9EC
	public static object add_textureRebuilt(object value) { }

	// RVA: 0x74DCABC
	public static object remove_textureRebuilt(object value) { }

	// RVA: 0x74DCB8C
	public object get_material() { }

	// RVA: 0x74DADE4
	public object get_dynamic() { }

	// RVA: 0x74DCBDC
	public object get_ascent() { }

	// RVA: 0x74DCC2C
	public object get_fontSize() { }

	// RVA: 0x74DCC7C
	public object get_characterInfo() { }

	// RVA: 0x74DCCCC
	public object set_characterInfo(object value) { }

	// RVA: 0x74DCD30
	public object get_lineHeight() { }

	// RVA: 0x74DCD80
	public object .ctor() { }

	// RVA: 0x74DCEB0
	private object .ctor(object names, object size) { }

	// RVA: 0x74DCFE8
	public static object CreateDynamicFontFromOSFont(object fontname, object size) { }

	// RVA: 0x74DD130
	internal static object InvokeTextureRebuilt_Internal(object font) { }

	// RVA: 0x74DD1D4
	public object HasCharacter(object c) { }

	// RVA: 0x74DD238
	private object HasCharacter(object c) { }

	// RVA: 0x74DD29C
	public static object GetPathsToOSFonts() { }

	// RVA: 0x74DCE4C
	private static object Internal_CreateFont(object self, object name) { }

	// RVA: 0x74DCF7C
	private static object Internal_CreateDynamicFont(object self, object _names, object size) { }

	// RVA: 0x74DD2DC
	public object GetCharacterInfo(object ch, object info, object size, object style) { }

	// RVA: 0x74DD364
	public object GetCharacterInfo(object ch, object info, object size) { }

	// RVA: 0x74DD3EC
	public object RequestCharactersInTexture(object characters, object size, object style) { }

	// RVA: 0x74DD46C
	public object RequestCharactersInTexture(object characters, object size) { }

	// RVA: 0x74DD4E0
	public object ExpandFontTextureSize(object width, object height) { }

	// RVA: 0x74DD5D4
	public static object SetCustomFontPath(object path) { }

	// RVA: 0x74DD624
	public static object AddCustomFontName(object name) { }

	// RVA: 0x74DD554
	private object ExpandFontTextureSize_Injected(object width, object height, object ret) { }

}

