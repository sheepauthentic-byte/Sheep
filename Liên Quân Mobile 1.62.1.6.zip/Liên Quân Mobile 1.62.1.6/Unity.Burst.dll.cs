// Namespace: 
internal class <Module>
{
}

// Namespace: Unity.Burst
public enum OptimizeFor
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Performance;
	public const object Size;
	public const object FastCompilation;
	public const object Balanced;
}

// Namespace: Unity.Burst
public enum FloatMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object Strict;
	public const object Deterministic;
	public const object Fast;
}

// Namespace: Unity.Burst
public enum FloatPrecision
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Standard;
	public const object High;
	public const object Medium;
	public const object Low;
}

// Namespace: Unity.Burst
public class BurstCompileAttribute
{

	// Fields
	private object <FloatMode>k__BackingField; // 0x8
	private object <FloatPrecision>k__BackingField; // 0xC
	internal object _compileSynchronously; // 0x10
	internal object _disableSafetyChecks; // 0x12
	private object <OptimizeFor>k__BackingField; // 0x14
	private object <Options>k__BackingField; // 0x18

	// Properties
	public object FloatMode { set; }
	public object FloatPrecision { set; }
	public object CompileSynchronously { set; }
	public object DisableSafetyChecks { set; }
	public object OptimizeFor { set; }
	internal object Options { set; }

	// Methods

	// RVA: 0x725E074
	public object set_FloatMode(object value) { }

	// RVA: 0x725E07C
	public object set_FloatPrecision(object value) { }

	// RVA: 0x725E084
	public object set_CompileSynchronously(object value) { }

	// RVA: 0x725E0F8
	public object set_DisableSafetyChecks(object value) { }

	// RVA: 0x725E16C
	public object set_OptimizeFor(object value) { }

	// RVA: 0x725E174
	internal object set_Options(object value) { }

	// RVA: 0x725E17C
	public object .ctor() { }

	// RVA: 0x725E184
	public object .ctor(object floatPrecision, object floatMode) { }

}

// Namespace: 
internal class StaticTypeReinitAttribute
{

	// Fields
	public readonly object reinitType; // 0x8

	// Methods

	// RVA: 0x725F080
	public object .ctor(object toReinit) { }

}

// Namespace: 
private sealed class IsBurstEnabledDelegate
{

	// Methods

	// RVA: 0x725F644
	public object .ctor(object object, object method) { }

	// RVA: 0x725F7C8
	public virtual object Invoke() { }

}

// Namespace: 
internal sealed class IsBurstEnabled_00000145$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x725F85C
	public object .ctor(object , object ) { }

	// RVA: 0x725F8F0
	public virtual object Invoke() { }

}

// Namespace: 
internal static class IsBurstEnabled_00000145$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x725F904
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x725FA44
	private static object GetFunctionPointer() { }

	// RVA: 0x725FAAC
	public static object Constructor() { }

	// RVA: 0x725F07C
	public static object Initialize() { }

	// RVA: 0x725FBA0
	private static object .cctor() { }

	// RVA: 0x725F21C
	public static object Invoke() { }

}

// Namespace: 
internal static class BurstCompilerHelper
{

	// Fields
	private static readonly object IsBurstEnabledImpl; // 0x0
	public static readonly object IsBurstGenerated; // 0x8

	// Methods

	// RVA: 0x725F134
	private static object IsBurstEnabled() { }

	// RVA: 0x725F47C
	private static object DiscardedMethod(object value) { }

	// RVA: 0x725F484
	private static object IsCompiledByBurst(object del) { }

	// RVA: 0x725F4FC
	private static object .cctor() { }

	// RVA: 0x725F6D8
	internal static object IsBurstEnabled$BurstManaged() { }

}

// Namespace: 
private class FakeDelegate
{

	// Fields
	private readonly object <Method>k__BackingField; // 0x8

	// Properties
	public object Method { get; }

	// Methods

	// RVA: 0x725E410
	public object .ctor(object method) { }

	// RVA: 0x725FBA4
	public object get_Method() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__22_0; // 0x8

	// Methods

	// RVA: 0x725FBAC
	private static object .cctor() { }

	// RVA: 0x725FC0C
	public object .ctor() { }

	// RVA: 0x725FC14
	internal object <Compile>b__22_0(object s) { }

}

// Namespace: 
private struct <>c__DisplayClass17_0
{

	// Fields
	public object managedMethodHandle; // 0xFFFFFFFFFFFFFFF8
	public object delegateTypeHandle; // 0x0
}

// Namespace: Unity.Burst
public static class BurstCompiler
{

	// Fields
	internal static object _IsEnabled; // 0x0
	public static readonly object Options; // 0x8
	internal static object OnCompileILPPMethod2; // 0x10
	private static readonly object DummyMethodInfo; // 0x18

	// Properties
	public static object IsEnabled { get; }

	// Methods

	// RVA: 0x725E1BC
	public static object get_IsEnabled() { }

	// RVA: 0x725E284
	public static object CompileILPPMethod2(object burstMethodHandle) { }

	// RVA: 0x725EAD0
	public static object GetILPPMethodFunctionPointer2(object ilppMethod, object managedMethodHandle, object delegateTypeHandle) { }

	// RVA: 0x725E43C
	private static object Compile(object delegateObj, object methodInfo, object isFunctionPointer, object isILPostProcessing, object deterministicCompilation) { }

	// RVA: 0x725EE74
	private static object DummyMethod() { }

	// RVA: 0x725EE78
	private static object .cctor() { }

	// RVA: 0x725EC48
	internal static object <GetILPPMethodFunctionPointer2>g__GetManagedFallbackDelegate|17_0(object managedFallbackDelegate, object gcHandle, object ) { }

	// RVA: 0x725F024
	public static object Initialize$BurstCompilerHelper_IsBurstEnabled_00000145$BurstDirectCall() { }

}

// Namespace: Unity.Burst
public sealed class BurstCompilerOptions
{

	// Fields
	internal static readonly object ForceDisableBurstCompilation; // 0x0
	private static readonly object ForceBurstCompilationSynchronously; // 0x1
	internal static readonly object IsSecondaryUnityProcess; // 0x2
	private object _enableBurstCompilation; // 0x8
	private object _enableBurstSafetyChecks; // 0x9
	private readonly object <IsGlobal>k__BackingField; // 0xA
	private object <OptionsChanged>k__BackingField; // 0x10

	// Properties
	private object IsGlobal { get; }
	public object EnableBurstCompilation { get; set; }
	public object EnableBurstSafetyChecks { set; }
	internal object OptionsChanged { get; }

	// Methods

	// RVA: 0x725EFBC
	internal object .ctor(object isGlobal) { }

	// RVA: 0x725FE04
	private object get_IsGlobal() { }

	// RVA: 0x725FE0C
	public object get_EnableBurstCompilation() { }

	// RVA: 0x725FCB8
	public object set_EnableBurstCompilation(object value) { }

	// RVA: 0x725FDD8
	public object set_EnableBurstSafetyChecks(object value) { }

	// RVA: 0x725FE34
	internal object get_OptionsChanged() { }

	// RVA: 0x725FE3C
	private static object TryGetAttribute(object member, object attribute) { }

	// RVA: 0x725FEDC
	private static object GetBurstCompileAttribute(object memberInfo) { }

	// RVA: 0x725ED34
	internal static object HasBurstCompileAttribute(object member) { }

	// RVA: 0x725FE14
	private object OnOptionsChanged() { }

	// RVA: 0x725FE30
	private object MaybeTriggerRecompilation() { }

	// RVA: 0x72603DC
	private static object .cctor() { }

	// RVA: 0x726055C
	private static object CheckIsSecondaryUnityProcess() { }

}

// Namespace: 
internal class PreserveAttribute
{

	// Methods

	// RVA: 0x72606A0
	public object .ctor() { }

}

// Namespace: Unity.Burst
public static class BurstRuntime
{

	// Methods

	// RVA: 0x7260564
	internal static object RuntimeLog(object message, object logType, object fileName, object lineNumber) { }

	// RVA: 0x726057C
	internal static object PreventRequiredAttributeStrip() { }

	// RVA: 0x7260688
	internal static object Log(object message, object logType, object fileName, object lineNumber) { }

}

// Namespace: 
internal class PreserveAttribute
{

	// Methods

	// RVA: 0x72654D4
	public object .ctor() { }

}

// Namespace: 
private enum NumberBufferKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Integer;
	public const object Float;
}

// Namespace: 
private struct NumberBuffer
{

	// Fields
	private readonly object _buffer; // 0xFFFFFFFFFFFFFFF8
	public object Kind; // 0x0
	public object DigitsCount; // 0x4
	public object Scale; // 0x8
	public readonly object IsNegative; // 0xC

	// Methods

	// RVA: 0x7261EDC
	public object .ctor(object kind, object buffer, object digitsCount, object scale, object isNegative) { }

	// RVA: 0x726553C
	public object GetDigitsPointer() { }

}

// Namespace: 
public enum NumberFormatKind
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object General;
	public const object Decimal;
	public const object DecimalForceSigned;
	public const object Hexadecimal;
}

// Namespace: 
public struct FormatOptions
{

	// Fields
	public object Kind; // 0xFFFFFFFFFFFFFFF8
	public object AlignAndSize; // 0xFFFFFFFFFFFFFFF9
	public object Specifier; // 0xFFFFFFFFFFFFFFFA
	public object Lowercase; // 0xFFFFFFFFFFFFFFFB

	// Properties
	public object Uppercase { get; }

	// Methods

	// RVA: 0x7262844
	public object .ctor(object kind, object alignAndSize, object specifier, object lowercase) { }

	// RVA: 0x7261E8C
	public object get_Uppercase() { }

	// RVA: 0x7261E74
	public object GetBase() { }

	// RVA: 0x72655CC
	public override object ToString() { }

}

// Namespace: 
public struct <m_blocks>e__FixedBuffer
{

	// Fields
	public object FixedElementField; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public struct tBigInt
{

	// Fields
	public object m_length; // 0xFFFFFFFFFFFFFFF8
	public object m_blocks; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x72658CC
	public object GetLength() { }

	// RVA: 0x7264DDC
	public object GetBlock(object idx) { }

	// RVA: 0x7264DE8
	public object IsZero() { }

	// RVA: 0x7264DAC
	public object SetU64(object val) { }

	// RVA: 0x7263610
	public object SetU32(object val) { }

}

// Namespace: 
public enum CutoffMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unique;
	public const object TotalLength;
	public const object FractionLength;
}

// Namespace: 
public struct tFloatUnion32
{

	// Fields
	public object m_floatingPoint; // 0xFFFFFFFFFFFFFFF8
	public object m_integer; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x72652E4
	public object IsNegative() { }

	// RVA: 0x72652CC
	public object GetExponent() { }

	// RVA: 0x72652D8
	public object GetMantissa() { }

}

// Namespace: 
public struct tFloatUnion64
{

	// Fields
	public object m_floatingPoint; // 0xFFFFFFFFFFFFFFF8
	public object m_integer; // 0xFFFFFFFFFFFFFFF8

	// Methods

	// RVA: 0x7265308
	public object IsNegative() { }

	// RVA: 0x72652F0
	public object GetExponent() { }

	// RVA: 0x72652FC
	public object GetMantissa() { }

}

// Namespace: Unity.Burst
internal static class BurstString
{

	// Fields
	private static readonly object SplitByColon; // 0x0
	private static readonly object logTable; // 0x8
	private static readonly object g_PowerOf10_U32; // 0x10
	private static readonly object InfinityString; // 0x18
	private static readonly object NanString; // 0x20

	// Methods

	// RVA: 0x72606A8
	public static object CopyFixedString(object dest, object destLength, object src, object srcLength) { }

	// RVA: 0x72606CC
	public static object Format(object dest, object destIndex, object destLength, object src, object srcLength, object formatOptionsRaw) { }

	// RVA: 0x7260970
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7260CA8
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7260FE0
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7261244
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x72614E8
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7261660
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7261748
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x72615D0
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7261984
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7261C04
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7261CD4
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x7261DA4
	public static object Format(object dest, object destIndex, object destLength, object value, object formatOptionsRaw) { }

	// RVA: 0x72617D8
	private static object ConvertUnsignedIntegerToString(object dest, object destIndex, object destLength, object value, object options) { }

	// RVA: 0x72622B8
	private static object GetLengthIntegerToString(object value, object basis, object zeroPadding) { }

	// RVA: 0x7261A54
	private static object ConvertIntegerToString(object dest, object destIndex, object destLength, object value, object options) { }

	// RVA: 0x7261EF0
	private static object FormatNumber(object dest, object destIndex, object destLength, object number, object nMaxDigits, object options) { }

	// RVA: 0x72622E4
	private static object FormatDecimalOrHexadecimal(object dest, object destIndex, object destLength, object number, object zeroPadding, object outputPositiveSign) { }

	// RVA: 0x7261E9C
	private static object ValueToIntegerChar(object value, object uppercase) { }

	// RVA: 0x72608A8
	private static object AlignRight(object dest, object destIndex, object destLength, object align, object length) { }

	// RVA: 0x7260860
	private static object AlignLeft(object dest, object destIndex, object destLength, object align, object length) { }

	// RVA: 0x72624D4
	private static object GetLengthForFormatGeneral(object number, object nMaxDigits) { }

	// RVA: 0x7262640
	private static object FormatGeneral(object dest, object destIndex, object destLength, object number, object nMaxDigits, object expChar) { }

	// RVA: 0x7262388
	private static object RoundNumber(object number, object pos, object isCorrectlyRounded) { }

	// RVA: 0x7262858
	private static object ShouldRoundUp(object dig, object i, object isCorrectlyRounded) { }

	// RVA: 0x7262874
	private static object LogBase2(object val) { }

	// RVA: 0x7262A20
	private static object BigInt_Compare(object lhs, object rhs) { }

	// RVA: 0x7262A80
	private static object BigInt_Add(object pResult, object lhs, object rhs) { }

	// RVA: 0x7262C44
	private static object BigInt_Add_internal(object pResult, object pLarge, object pSmall) { }

	// RVA: 0x7262CEC
	private static object BigInt_Multiply(object pResult, object lhs, object rhs) { }

	// RVA: 0x7262F40
	private static object BigInt_Multiply_internal(object pResult, object pLarge, object pSmall) { }

	// RVA: 0x726302C
	private static object BigInt_Multiply(object pResult, object lhs, object rhs) { }

	// RVA: 0x7263090
	private static object BigInt_Multiply2(object pResult, object input) { }

	// RVA: 0x72630F0
	private static object BigInt_Multiply2(object pResult) { }

	// RVA: 0x7263148
	private static object BigInt_Multiply10(object pResult) { }

	// RVA: 0x72631A0
	private static object g_PowerOf10_Big(object i) { }

	// RVA: 0x7263404
	private static object BigInt_Pow10(object pResult, object exponent) { }

	// RVA: 0x7263628
	private static object BigInt_MultiplyPow10(object pResult, object input, object exponent) { }

	// RVA: 0x72638C4
	private static object BigInt_Pow2(object pResult, object exponent) { }

	// RVA: 0x7263958
	private static object BigInt_DivideWithRemainder_MaxQuotient9(object pDividend, object divisor) { }

	// RVA: 0x7263B24
	private static object BigInt_ShiftLeft(object pResult, object shift) { }

	// RVA: 0x7263CC0
	private static object Dragon4(object mantissa, object exponent, object mantissaHighBitIdx, object hasUnequalMargins, object cutoffMode, object cutoffNumber, object pOutBuffer, object bufferSize, object pOutExponent) { }

	// RVA: 0x7264DF8
	private static object FormatInfinityNaN(object dest, object destIndex, object destLength, object mantissa, object isNegative, object formatOptions) { }

	// RVA: 0x7260A00
	private static object ConvertFloatToString(object dest, object destIndex, object destLength, object value, object formatOptions) { }

	// RVA: 0x7260D38
	private static object ConvertDoubleToString(object dest, object destIndex, object destLength, object value, object formatOptions) { }

	// RVA: 0x7265314
	private static object .cctor() { }

}

// Namespace: Unity.Burst
public struct FunctionPointer<T0>
{

	// Fields
	private readonly object _ptr; // 0x0

	// Properties
	public object Invoke { get; }

	// Methods

	// RVA: -1
	public object .ctor(object ptr) { }

	// RVA: -1
	public object get_Invoke() { }

}

// Namespace: Unity.Burst
public class NoAliasAttribute
{

	// Methods

	// RVA: 0x7265988
	public object .ctor() { }

}

// Namespace: Unity.Burst
public struct SharedStatic<T0>
{

	// Fields
	private readonly object _buffer; // 0x0

	// Properties
	public object Data { get; }

	// Methods

	// RVA: -1
	private object .ctor(object buffer) { }

	// RVA: -1
	public object get_Data() { }

	// RVA: -1
	public static object GetOrCreateUnsafe(object alignment, object hashCode, object subHashCode) { }

}

// Namespace: 
internal class PreserveAttribute
{

	// Methods

	// RVA: 0x72659E4
	public object .ctor() { }

}

// Namespace: Unity.Burst
internal static class SharedStatic
{

	// Methods

	// RVA: 0x7265990
	public static object GetOrCreateSharedStaticInternal(object getHashCode64, object getSubHashCode64, object sizeOf, object alignment) { }

}

// Namespace: Unity.Burst.Intrinsics
public static class Common
{

	// Methods

	// RVA: 0x72659EC
	public static object umul128(object x, object y, object high) { }

}

// Namespace: Unity.Burst.Intrinsics
internal sealed class BurstTargetCpuAttribute
{
}

// Namespace: Unity.Burst.Intrinsics
internal class V64DebugView
{
}

// Namespace: Unity.Burst.Intrinsics
internal class V128DebugView
{
}

// Namespace: Unity.Burst.Intrinsics
internal class V256DebugView
{
}

// Namespace: Unity.Burst.Intrinsics
public struct v128
{

	// Fields
	public object Byte0; // 0xFFFFFFFFFFFFFFF8
	public object Byte1; // 0xFFFFFFFFFFFFFFF9
	public object Byte2; // 0xFFFFFFFFFFFFFFFA
	public object Byte3; // 0xFFFFFFFFFFFFFFFB
	public object Byte4; // 0xFFFFFFFFFFFFFFFC
	public object Byte5; // 0xFFFFFFFFFFFFFFFD
	public object Byte6; // 0xFFFFFFFFFFFFFFFE
	public object Byte7; // 0xFFFFFFFFFFFFFFFF
	public object Byte8; // 0x0
	public object Byte9; // 0x1
	public object Byte10; // 0x2
	public object Byte11; // 0x3
	public object Byte12; // 0x4
	public object Byte13; // 0x5
	public object Byte14; // 0x6
	public object Byte15; // 0x7
	public object SByte0; // 0xFFFFFFFFFFFFFFF8
	public object SByte1; // 0xFFFFFFFFFFFFFFF9
	public object SByte2; // 0xFFFFFFFFFFFFFFFA
	public object SByte3; // 0xFFFFFFFFFFFFFFFB
	public object SByte4; // 0xFFFFFFFFFFFFFFFC
	public object SByte5; // 0xFFFFFFFFFFFFFFFD
	public object SByte6; // 0xFFFFFFFFFFFFFFFE
	public object SByte7; // 0xFFFFFFFFFFFFFFFF
	public object SByte8; // 0x0
	public object SByte9; // 0x1
	public object SByte10; // 0x2
	public object SByte11; // 0x3
	public object SByte12; // 0x4
	public object SByte13; // 0x5
	public object SByte14; // 0x6
	public object SByte15; // 0x7
	public object UShort0; // 0xFFFFFFFFFFFFFFF8
	public object UShort1; // 0xFFFFFFFFFFFFFFFA
	public object UShort2; // 0xFFFFFFFFFFFFFFFC
	public object UShort3; // 0xFFFFFFFFFFFFFFFE
	public object UShort4; // 0x0
	public object UShort5; // 0x2
	public object UShort6; // 0x4
	public object UShort7; // 0x6
	public object SShort0; // 0xFFFFFFFFFFFFFFF8
	public object SShort1; // 0xFFFFFFFFFFFFFFFA
	public object SShort2; // 0xFFFFFFFFFFFFFFFC
	public object SShort3; // 0xFFFFFFFFFFFFFFFE
	public object SShort4; // 0x0
	public object SShort5; // 0x2
	public object SShort6; // 0x4
	public object SShort7; // 0x6
	public object UInt0; // 0xFFFFFFFFFFFFFFF8
	public object UInt1; // 0xFFFFFFFFFFFFFFFC
	public object UInt2; // 0x0
	public object UInt3; // 0x4
	public object SInt0; // 0xFFFFFFFFFFFFFFF8
	public object SInt1; // 0xFFFFFFFFFFFFFFFC
	public object SInt2; // 0x0
	public object SInt3; // 0x4
	public object ULong0; // 0xFFFFFFFFFFFFFFF8
	public object ULong1; // 0x0
	public object SLong0; // 0xFFFFFFFFFFFFFFF8
	public object SLong1; // 0x0
	public object Float0; // 0xFFFFFFFFFFFFFFF8
	public object Float1; // 0xFFFFFFFFFFFFFFFC
	public object Float2; // 0x0
	public object Float3; // 0x4
	public object Double0; // 0xFFFFFFFFFFFFFFF8
	public object Double1; // 0x0
	public object Lo64; // 0xFFFFFFFFFFFFFFF8
	public object Hi64; // 0x0
}

// Namespace: Unity.Burst.Intrinsics
public struct v256
{

	// Fields
	public object Byte0; // 0xFFFFFFFFFFFFFFF8
	public object Byte1; // 0xFFFFFFFFFFFFFFF9
	public object Byte2; // 0xFFFFFFFFFFFFFFFA
	public object Byte3; // 0xFFFFFFFFFFFFFFFB
	public object Byte4; // 0xFFFFFFFFFFFFFFFC
	public object Byte5; // 0xFFFFFFFFFFFFFFFD
	public object Byte6; // 0xFFFFFFFFFFFFFFFE
	public object Byte7; // 0xFFFFFFFFFFFFFFFF
	public object Byte8; // 0x0
	public object Byte9; // 0x1
	public object Byte10; // 0x2
	public object Byte11; // 0x3
	public object Byte12; // 0x4
	public object Byte13; // 0x5
	public object Byte14; // 0x6
	public object Byte15; // 0x7
	public object Byte16; // 0x8
	public object Byte17; // 0x9
	public object Byte18; // 0xA
	public object Byte19; // 0xB
	public object Byte20; // 0xC
	public object Byte21; // 0xD
	public object Byte22; // 0xE
	public object Byte23; // 0xF
	public object Byte24; // 0x10
	public object Byte25; // 0x11
	public object Byte26; // 0x12
	public object Byte27; // 0x13
	public object Byte28; // 0x14
	public object Byte29; // 0x15
	public object Byte30; // 0x16
	public object Byte31; // 0x17
	public object SByte0; // 0xFFFFFFFFFFFFFFF8
	public object SByte1; // 0xFFFFFFFFFFFFFFF9
	public object SByte2; // 0xFFFFFFFFFFFFFFFA
	public object SByte3; // 0xFFFFFFFFFFFFFFFB
	public object SByte4; // 0xFFFFFFFFFFFFFFFC
	public object SByte5; // 0xFFFFFFFFFFFFFFFD
	public object SByte6; // 0xFFFFFFFFFFFFFFFE
	public object SByte7; // 0xFFFFFFFFFFFFFFFF
	public object SByte8; // 0x0
	public object SByte9; // 0x1
	public object SByte10; // 0x2
	public object SByte11; // 0x3
	public object SByte12; // 0x4
	public object SByte13; // 0x5
	public object SByte14; // 0x6
	public object SByte15; // 0x7
	public object SByte16; // 0x8
	public object SByte17; // 0x9
	public object SByte18; // 0xA
	public object SByte19; // 0xB
	public object SByte20; // 0xC
	public object SByte21; // 0xD
	public object SByte22; // 0xE
	public object SByte23; // 0xF
	public object SByte24; // 0x10
	public object SByte25; // 0x11
	public object SByte26; // 0x12
	public object SByte27; // 0x13
	public object SByte28; // 0x14
	public object SByte29; // 0x15
	public object SByte30; // 0x16
	public object SByte31; // 0x17
	public object UShort0; // 0xFFFFFFFFFFFFFFF8
	public object UShort1; // 0xFFFFFFFFFFFFFFFA
	public object UShort2; // 0xFFFFFFFFFFFFFFFC
	public object UShort3; // 0xFFFFFFFFFFFFFFFE
	public object UShort4; // 0x0
	public object UShort5; // 0x2
	public object UShort6; // 0x4
	public object UShort7; // 0x6
	public object UShort8; // 0x8
	public object UShort9; // 0xA
	public object UShort10; // 0xC
	public object UShort11; // 0xE
	public object UShort12; // 0x10
	public object UShort13; // 0x12
	public object UShort14; // 0x14
	public object UShort15; // 0x16
	public object SShort0; // 0xFFFFFFFFFFFFFFF8
	public object SShort1; // 0xFFFFFFFFFFFFFFFA
	public object SShort2; // 0xFFFFFFFFFFFFFFFC
	public object SShort3; // 0xFFFFFFFFFFFFFFFE
	public object SShort4; // 0x0
	public object SShort5; // 0x2
	public object SShort6; // 0x4
	public object SShort7; // 0x6
	public object SShort8; // 0x8
	public object SShort9; // 0xA
	public object SShort10; // 0xC
	public object SShort11; // 0xE
	public object SShort12; // 0x10
	public object SShort13; // 0x12
	public object SShort14; // 0x14
	public object SShort15; // 0x16
	public object UInt0; // 0xFFFFFFFFFFFFFFF8
	public object UInt1; // 0xFFFFFFFFFFFFFFFC
	public object UInt2; // 0x0
	public object UInt3; // 0x4
	public object UInt4; // 0x8
	public object UInt5; // 0xC
	public object UInt6; // 0x10
	public object UInt7; // 0x14
	public object SInt0; // 0xFFFFFFFFFFFFFFF8
	public object SInt1; // 0xFFFFFFFFFFFFFFFC
	public object SInt2; // 0x0
	public object SInt3; // 0x4
	public object SInt4; // 0x8
	public object SInt5; // 0xC
	public object SInt6; // 0x10
	public object SInt7; // 0x14
	public object ULong0; // 0xFFFFFFFFFFFFFFF8
	public object ULong1; // 0x0
	public object ULong2; // 0x8
	public object ULong3; // 0x10
	public object SLong0; // 0xFFFFFFFFFFFFFFF8
	public object SLong1; // 0x0
	public object SLong2; // 0x8
	public object SLong3; // 0x10
	public object Float0; // 0xFFFFFFFFFFFFFFF8
	public object Float1; // 0xFFFFFFFFFFFFFFFC
	public object Float2; // 0x0
	public object Float3; // 0x4
	public object Float4; // 0x8
	public object Float5; // 0xC
	public object Float6; // 0x10
	public object Float7; // 0x14
	public object Double0; // 0xFFFFFFFFFFFFFFF8
	public object Double1; // 0x0
	public object Double2; // 0x8
	public object Double3; // 0x10
	public object Lo128; // 0xFFFFFFFFFFFFFFF8
	public object Hi128; // 0x8

	// Methods

	// RVA: 0x7265A28
	public object .ctor(object v) { }

	// RVA: 0x7265A44
	public object .ctor(object lo, object hi) { }

}

// Namespace: Unity.Burst.Intrinsics
public struct v64
{

	// Fields
	public object Byte0; // 0xFFFFFFFFFFFFFFF8
	public object Byte1; // 0xFFFFFFFFFFFFFFF9
	public object Byte2; // 0xFFFFFFFFFFFFFFFA
	public object Byte3; // 0xFFFFFFFFFFFFFFFB
	public object Byte4; // 0xFFFFFFFFFFFFFFFC
	public object Byte5; // 0xFFFFFFFFFFFFFFFD
	public object Byte6; // 0xFFFFFFFFFFFFFFFE
	public object Byte7; // 0xFFFFFFFFFFFFFFFF
	public object SByte0; // 0xFFFFFFFFFFFFFFF8
	public object SByte1; // 0xFFFFFFFFFFFFFFF9
	public object SByte2; // 0xFFFFFFFFFFFFFFFA
	public object SByte3; // 0xFFFFFFFFFFFFFFFB
	public object SByte4; // 0xFFFFFFFFFFFFFFFC
	public object SByte5; // 0xFFFFFFFFFFFFFFFD
	public object SByte6; // 0xFFFFFFFFFFFFFFFE
	public object SByte7; // 0xFFFFFFFFFFFFFFFF
	public object UShort0; // 0xFFFFFFFFFFFFFFF8
	public object UShort1; // 0xFFFFFFFFFFFFFFFA
	public object UShort2; // 0xFFFFFFFFFFFFFFFC
	public object UShort3; // 0xFFFFFFFFFFFFFFFE
	public object SShort0; // 0xFFFFFFFFFFFFFFF8
	public object SShort1; // 0xFFFFFFFFFFFFFFFA
	public object SShort2; // 0xFFFFFFFFFFFFFFFC
	public object SShort3; // 0xFFFFFFFFFFFFFFFE
	public object UInt0; // 0xFFFFFFFFFFFFFFF8
	public object UInt1; // 0xFFFFFFFFFFFFFFFC
	public object SInt0; // 0xFFFFFFFFFFFFFFF8
	public object SInt1; // 0xFFFFFFFFFFFFFFFC
	public object ULong0; // 0xFFFFFFFFFFFFFFF8
	public object SLong0; // 0xFFFFFFFFFFFFFFF8
	public object Float0; // 0xFFFFFFFFFFFFFFF8
	public object Float1; // 0xFFFFFFFFFFFFFFFC
	public object Double0; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
public static class Avx
{

	// Methods

	// RVA: 0x7265F04
	public static object mm256_load_ps(object ptr) { }

	// RVA: 0x7265F10
	public static object mm256_store_ps(object ptr, object val) { }

	// RVA: 0x7265F1C
	public static object mm256_loadu_si256(object ptr) { }

	// RVA: 0x7265F28
	public static object mm256_storeu_si256(object ptr, object v) { }

	// RVA: 0x7265F34
	public static object mm256_set1_epi32(object a) { }

}

// Namespace: 
public static class Avx2
{

	// Properties
	public static object IsAvx2Supported { get; }

	// Methods

	// RVA: 0x7265F40
	public static object get_IsAvx2Supported() { }

	// RVA: 0x7265F48
	public static object mm256_xor_si256(object a, object b) { }

	// RVA: 0x7265F6C
	public static object mm256_add_epi64(object a, object b) { }

	// RVA: 0x7265F90
	public static object mm256_mul_epu32(object a, object b) { }

	// RVA: 0x7265FD8
	public static object mm256_slli_epi64(object a, object imm8) { }

	// RVA: 0x726629C
	public static object mm256_srli_epi64(object a, object imm8) { }

	// RVA: 0x72664F0
	public static object mm256_shuffle_epi32(object a, object imm8) { }

}

// Namespace: 
public static class Sse
{

	// Properties
	public static object IsSseSupported { get; }

	// Methods

	// RVA: 0x7265EF4
	public static object get_IsSseSupported() { }

	// RVA: 0x7266650
	public static object SHUFFLE(object d, object c, object b, object a) { }

}

// Namespace: 
public static class Sse2
{

	// Methods

	// RVA: 0x7265F84
	public static object add_epi64(object a, object b) { }

	// RVA: 0x7265FCC
	public static object mul_epu32(object a, object b) { }

	// RVA: 0x72661A0
	public static object slli_epi64(object a, object imm8) { }

	// RVA: 0x7266414
	public static object srli_epi64(object a, object imm8) { }

	// RVA: 0x7265F60
	public static object xor_si128(object a, object b) { }

	// RVA: 0x72665C4
	public static object shuffle_epi32(object a, object imm8) { }

}

// Namespace: Unity.Burst.Intrinsics
internal sealed class DoSetCSRTrampoline_00000129$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x72666D4
	public object .ctor(object , object ) { }

	// RVA: 0x726676C
	public virtual object Invoke(object bits) { }

}

// Namespace: Unity.Burst.Intrinsics
internal static class DoSetCSRTrampoline_00000129$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x7266780
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x72668C0
	private static object GetFunctionPointer() { }

	// RVA: 0x7266928
	public static object Constructor() { }

	// RVA: 0x7266A1C
	public static object Initialize() { }

	// RVA: 0x7266A20
	private static object .cctor() { }

	// RVA: 0x7265AE8
	public static object Invoke(object bits) { }

}

// Namespace: Unity.Burst.Intrinsics
internal sealed class DoGetCSRTrampoline_0000012A$PostfixBurstDelegate
{

	// Methods

	// RVA: 0x7266A8C
	public object .ctor(object , object ) { }

	// RVA: 0x7266B20
	public virtual object Invoke() { }

}

// Namespace: Unity.Burst.Intrinsics
internal static class DoGetCSRTrampoline_0000012A$BurstDirectCall
{

	// Fields
	private static object Pointer; // 0x0
	private static object DeferredCompilation; // 0x8

	// Methods

	// RVA: 0x7266B34
	private static object GetFunctionPointerDiscard(object ) { }

	// RVA: 0x7266C74
	private static object GetFunctionPointer() { }

	// RVA: 0x7266CDC
	public static object Constructor() { }

	// RVA: 0x7266DD0
	public static object Initialize() { }

	// RVA: 0x7266DD4
	private static object .cctor() { }

	// RVA: 0x7265D28
	public static object Invoke() { }

}

// Namespace: Unity.Burst.Intrinsics
public static class X86
{

	// Methods

	// RVA: 0x7265A5C
	private static object BurstIntrinsicSetCSRFromManaged(object _) { }

	// RVA: 0x7265A60
	private static object BurstIntrinsicGetCSRFromManaged() { }

	// RVA: 0x7265A68
	private static object DoSetCSRTrampoline(object bits) { }

	// RVA: 0x7265CC0
	private static object DoGetCSRTrampoline() { }

	// RVA: 0x7265EF0
	internal static object DoSetCSRTrampoline$BurstManaged(object bits) { }

	// RVA: 0x7265EFC
	internal static object DoGetCSRTrampoline$BurstManaged() { }

}

// Namespace: Unity.Burst.CompilerServices
public class AssumeRangeAttribute
{

	// Methods

	// RVA: 0x7266DD8
	public object .ctor(object min, object max) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=3
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=32
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=256
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 07DB995E8ED2CFB0AB71EBA69F3A3EC07D5C6AC10C0C64F33E94ED2949B348AA; // 0x0
	internal static readonly object C69994AC61B52FBCEA582D6CCCD595C12E00BDB18F0C6F593FB6B393CAEDB08C; // 0x100
	internal static readonly object D0067CAD9A63E0813759A2BB841051CA73570C0DA2E08E840A8EB45DB6A7A010; // 0x120
	internal static readonly object D5B592C05DC25B5032553F1B27F4139BE95E881F73DB33B02B05AB20C3F9981E; // 0x128
}

// Namespace: 
internal static class $BurstDirectCallInitializer
{

	// Methods

	// RVA: 0x7266DE0
	private static object Initialize() { }

}

