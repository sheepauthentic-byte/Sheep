// Namespace: 
internal class <Module>
{
}

// Namespace: 
public class PreDLCTest
{

	// Methods

	// RVA: 0x6BE2330
	private object Start() { }

	// RVA: 0x6BE238C
	private object Update() { }

	// RVA: 0x6BE23E8
	public object .ctor() { }

}

// Namespace: 
public interface ITreeNode
{
}

// Namespace: 
public class CustomTreeNode
{

	// Fields
	private object m_customType; // 0x8
	private object m_customValue; // 0x10

	// Methods

	// RVA: 0x6BE35A8
	public object .ctor(object type, object value) { }

}

// Namespace: 
public class AnalyseResourceNode
{

	// Fields
	public object Parent; // 0x8
	public object Children; // 0x10
	public object bOutput; // 0x18
	public object Node; // 0x20

	// Methods

	// RVA: 0x6BE35E0
	public object .ctor(object TreeNode, object ParentNode) { }

}

// Namespace: 
public class RecordAnalyseResourceTree
{

	// Fields
	public static object bOpenRecordAnalyseResourceTree; // 0x0
	private static object start; // 0x1
	public static readonly object AddActor; // 0x8
	public static readonly object AnalyseActor; // 0x10
	public static readonly object AddDynamicActor; // 0x18
	public static readonly object AnalyseDynamicActor; // 0x20
	public static readonly object AddStaticActor; // 0x28
	public static readonly object AnalyseStaticActor; // 0x30
	public static readonly object AddAge; // 0x38
	public static readonly object AnalyseAge; // 0x40
	public static readonly object AddSkillId; // 0x48
	public static readonly object AnalyseSkillId; // 0x50
	public static readonly object AddSkillCombineId; // 0x58
	public static readonly object AnalyseSkillCombineId; // 0x60
	public static readonly object AddExtraSkill; // 0x68
	public static readonly object AnalyseExtraSkill; // 0x70
	public static readonly object AddBluePrint; // 0x78
	public static readonly object AnalyseBluePrint; // 0x80
	public static readonly object ParentNodeNames; // 0x88
	public static readonly object ChildNodeNames; // 0x90
	private static object m_root; // 0x98
	private static object m_resroot; // 0xA0
	private static object m_ageroot; // 0xA8
	private static object m_blueprintroot; // 0xB0
	private static object m_treeStack; // 0xB8
	private static object m_treeResStack; // 0xC0
	private static object m_respathset; // 0xC8

	// Methods

	// RVA: 0x6BE23F0
	private static object .cctor() { }

}

// Namespace: CommonLibs.FileModule
public class EncoderMagicConfig
{

	// Fields
	public static readonly object mMagicNoEncryptAndNoCompress; // 0x0
	public static readonly object mMagicOnlyEncrypt; // 0x8
	public static readonly object mMagicOnlyCompress; // 0x10
	public static readonly object mMagicComressAndEncrypt; // 0x18

	// Methods

	// RVA: 0x6BE3684
	public static object BytesEqual(object left, object right) { }

	// RVA: 0x6BE37D8
	public static object BytesOneHeader(object bytes) { }

	// RVA: 0x6BE3948
	public static object BytesCompressHeader(object bytes) { }

	// RVA: 0x6BE3A50
	public static object BytesEncryptHeader(object bytes) { }

	// RVA: 0x6BE3B58
	private static object .cctor() { }

}

// Namespace: 
public sealed class ConstructCompressStreamDelegate
{

	// Methods

	// RVA: 0x6BE5064
	public object .ctor(object object, object method) { }

	// RVA: 0x6BE5170
	public virtual object Invoke(object inStream, object compressedStream) { }

}

// Namespace: 
public sealed class ReleasePooledCompressStreamDelegate
{

	// Methods

	// RVA: 0x6BE545C
	public object .ctor(object object, object method) { }

	// RVA: 0x6BE5578
	public virtual object Invoke(object pooledCompressStream) { }

}

// Namespace: 
public class KnowLengthBytesStream
{

	// Fields
	private readonly object m_inStream; // 0x20
	private object m_cryptoStream; // 0x28
	private object m_finalStream; // 0x30
	private object m_origLength; // 0x38
	private object m_closed; // 0x40
	private object m_pooledCompressStream; // 0x48

	// Properties
	public object InStream { get; }
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x6BE498C
	public object .ctor(object inStream, object resNameWithoutExt, object origLength, object isCompress, object isEncrypt) { }

	// RVA: 0x6BE558C
	public override object Close() { }

	// RVA: 0x6BE5850
	public override object Flush() { }

	// RVA: 0x6BE58E4
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x6BE59A8
	public object get_InStream() { }

	// RVA: 0x6BE5A08
	public override object Seek(object offset, object origin) { }

	// RVA: 0x6BE5BA8
	public override object SetLength(object value) { }

	// RVA: 0x6BE5C34
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x6BE5CD8
	public override object get_CanRead() { }

	// RVA: 0x6BE5D38
	public override object get_CanSeek() { }

	// RVA: 0x6BE5D98
	public override object get_CanWrite() { }

	// RVA: 0x6BE5DF4
	public override object get_Length() { }

	// RVA: 0x6BE5E54
	public override object get_Position() { }

	// RVA: 0x6BE5ED8
	public override object set_Position(object value) { }

}

// Namespace: CommonLibs.FileModule
public class ResDReader
{

	// Fields
	public static readonly object mIV; // 0x0
	public static readonly object mRawKeys; // 0x8
	private static object __aesProvider; // 0xFFFFFFFF80000000
	public static object IsCheckLocalResource; // 0x10
	public static object IsDecodeBytesStrongCheck; // 0x11
	public static object DecodeBytesCheckFailed; // 0x18
	private static object s_constructCompressStreamDelegate; // 0x20
	private static object s_releaseCompressStreamDelegate; // 0x28

	// Properties
	private static object m_aesProvider { get; }

	// Methods

	// RVA: 0x6BE3CBC
	public static object GetStrUpperHash(object inAssetName) { }

	// RVA: 0x6BE3DB0
	public static object GetMixedKey(object resName) { }

	// RVA: 0x6BE4024
	private static object get_m_aesProvider() { }

	// RVA: 0x6BE41D4
	public static object TryGetBytesStream(object inStream, object resNameWithoutExt) { }

	// RVA: 0x6BE47D4
	private static object RestoreInputStream(object inStream, object strongCheck) { }

	// RVA: 0x6BE4B5C
	public static object InitDelegates(object constructCompressStreamDelegate, object releasePooledCompressStreamDelegate) { }

	// RVA: 0x6BE4C28
	private static object .cctor() { }

}

// Namespace: 
public class ZipArchiveEntry
{

	// Fields
	private object <Archive>k__BackingField; // 0x8
	internal object _ZipEntry; // 0x10

	// Properties
	public object Archive { get; set; }
	public object UncompressedLength { get; }

	// Methods

	// RVA: 0x6BE677C
	public object get_Archive() { }

	// RVA: 0x6BE6784
	internal object set_Archive(object value) { }

	// RVA: 0x6BE678C
	public object get_UncompressedLength() { }

	// RVA: 0x6BE67B0
	public object Open() { }

	// RVA: 0x6BE6564
	public object .ctor() { }

}

// Namespace: 
public class EntryInputStreamWrapper
{

	// Fields
	private object baseInputStream; // 0x20
	private object _Length; // 0x28

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x6BE68F8
	public object .ctor(object inputStream) { }

	// RVA: 0x6BE6968
	public override object get_CanRead() { }

	// RVA: 0x6BE69B4
	public override object get_CanSeek() { }

	// RVA: 0x6BE6A00
	public override object get_CanWrite() { }

	// RVA: 0x6BE6A4C
	public override object get_Length() { }

	// RVA: 0x6BE6A54
	public override object get_Position() { }

	// RVA: 0x6BE6AA4
	public override object set_Position(object value) { }

	// RVA: 0x6BE6AFC
	public override object Flush() { }

	// RVA: 0x6BE6B4C
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x6BE6BBC
	public override object Seek(object offset, object origin) { }

	// RVA: 0x6BE6C24
	public override object SetLength(object value) { }

	// RVA: 0x6BE6C2C
	public override object Write(object buffer, object offset, object count) { }

}

// Namespace: 
public enum ZipArchiveMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Read;
	public const object Create;
}

// Namespace: 
private class DirEntryFilter
{

	// Fields
	public object DirName; // 0x8
	public object Delegate; // 0x10

	// Methods

	// RVA: 0x6BE6224
	public object .ctor() { }

	// RVA: 0x6BE6C9C
	public object Match(object entry) { }

}

// Namespace: LibZip
public class ZipArchive
{

	// Fields
	private object _ZipFile; // 0x8
	private object _DirFilter; // 0x10

	// Methods

	// RVA: 0x6BE5F64
	public static object Open(object name, object mode) { }

	// RVA: 0x6BE6150
	private object .ctor() { }

	// RVA: 0x6BE603C
	public object .ctor(object name) { }

	// RVA: 0x6BE62B0
	public object GetEntry(object name) { }

	// RVA: 0x6BE62D4
	public object GetEntry(object name, object start, object count) { }

	// RVA: 0x6BE656C
	private object UnloadEntry(object predicate) { }

	// RVA: 0x6BE6754
	public object UnloadDir(object dirName) { }

}

// Namespace: ResCore
public interface ResProtocol
{

	// Methods

	// RVA: -1
	public abstract object GetEditorABRoot() { }

	// RVA: -1
	public abstract object AssetPathToResourcePath(object path) { }

	// RVA: -1
	public abstract object IsExtraStorageLimited() { }

	// RVA: -1
	public abstract object GetDLCRoot() { }

	// RVA: -1
	public abstract object GetUpdateRoot() { }

	// RVA: -1
	public abstract object GetPuertsAudioRoot() { }

	// RVA: -1
	public abstract object StartCoroutine(object iter) { }

	// RVA: -1
	public abstract object OnResourceVersionChanged(object version, object svnRev) { }

	// RVA: -1
	public abstract object OnDLCServerVersionChanged(object dlcVersion) { }

	// RVA: -1
	public abstract object CreatePufferProxy() { }

	// RVA: -1
	public abstract object CreatePufferBridge() { }

}

// Namespace: ResCore
public class ResCoreModule
{

	// Fields
	internal object resourceManager; // 0x8
	internal object DLCDownloaderMgr; // 0x10
	private object <resProtocol>k__BackingField; // 0x18
	private static object _instance; // 0x0

	// Properties
	public object resProtocol { get; set; }
	public static object instacne { get; }
	public object IsEditor { get; }

	// Methods

	// RVA: 0x6BE6DCC
	public object get_resProtocol() { }

	// RVA: 0x6BE6DD4
	public object set_resProtocol(object value) { }

	// RVA: 0x6BE6DDC
	public object .ctor(object proto) { }

	// RVA: 0x6BE73D4
	public static object get_instacne() { }

	// RVA: 0x6BE745C
	public object get_IsEditor() { }

	// RVA: 0x6BE7510
	public object GetEditorABRoot() { }

	// RVA: 0x6BE7634
	public object AssetPathToResourcePath(object path) { }

	// RVA: 0x6BE7754
	public object IsExtraStorageLimited() { }

	// RVA: 0x6BE787C
	public object GetDLCRoot() { }

	// RVA: 0x6BE79A4
	public object GetUpdateRoot() { }

	// RVA: 0x6BE7ACC
	public object GetPuertsAudioRoot() { }

	// RVA: 0x6BE7BF4
	public object StartCoroutine(object iter) { }

	// RVA: 0x6BE7D14
	public object OnResourceVersionChanged(object version, object svnRev) { }

	// RVA: 0x6BE7E4C
	public object OnDLCServerVersionChanged(object dlcVersion) { }

	// RVA: 0x6BE7F6C
	public object CreatePufferProxy() { }

	// RVA: 0x6BE8094
	public object CreatePufferBridge() { }

	// RVA: 0x6BE81BC
	public object IsUse7z() { }

}

// Namespace: ResCore
public class CBinaryObject
{

	// Fields
	public object m_data; // 0x8
	private object _stream; // 0x10
	private object _streamReader; // 0x18
	private object _binaryReader; // 0x20

	// Properties
	public object m_stream { get; }
	public object SReader { get; }
	public object BReader { get; }

	// Methods

	// RVA: -1
	public static object CreateThreadSafe() { }

	// RVA: 0x6BE821C
	public object get_m_stream() { }

	// RVA: 0x6BE8360
	public object get_SReader() { }

	// RVA: 0x6BE8434
	public object get_BReader() { }

	// RVA: 0x6BE8508
	public object SetFileStream(object stream) { }

	// RVA: 0x6BE8588
	public object Release() { }

	// RVA: 0x6BE867C
	public object .ctor() { }

}

// Namespace: ResCore
public enum enFileOperation
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ReadFile;
	public const object WriteFile;
	public const object DeleteFile;
	public const object CreateDirectory;
	public const object DeleteDirectory;
}

// Namespace: 
public sealed class DelegateOnOperateFileFail
{

	// Methods

	// RVA: 0x6BEEAE8
	public object .ctor(object object, object method) { }

	// RVA: 0x6BEEC74
	public virtual object Invoke(object fullPath, object fileOperation) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0

	// Methods

	// RVA: 0x6BEEC88
	private static object .cctor() { }

	// RVA: 0x6BEECE8
	public object .ctor() { }

	// RVA: 0x6BEECF0
	internal object <.cctor>b__74_0(object <p0>, object <p1>) { }

}

// Namespace: ResCore
public static class CFileManager
{

	// Fields
	private static object s_cachePath; // 0x0
	private static object s_md5Provider; // 0x8
	public static object s_delegateOnOperateFileFail; // 0x10
	public static object bJustExtractedIFS; // 0x18
	private static object _ApkInternalPathLabel; // 0x20
	private static object _ObbInternalPathLabel; // 0x28
	private static object _AssetPackArchiveList; // 0x30
	private static object _dataPath; // 0x38

	// Properties
	public static object InternalRootPath { get; }

	// Methods

	// RVA: 0x6BE8684
	public static object IsFileExist(object filePath) { }

	// RVA: 0x6BE8A50
	private static object _IsFileExist_System(object filePath) { }

	// RVA: 0x6BE8C44
	public static object GetFileNameWithoutExtension(object fullPath) { }

	// RVA: 0x6BE8E68
	public static object IsFileExistRelPath(object relPath) { }

	// RVA: 0x6BE945C
	public static object IsDirectoryExist(object directory) { }

	// RVA: 0x6BE94C0
	public static object CreateDirRecursive(object directory) { }

	// RVA: 0x6BE9824
	public static object CreateDirectory(object directory) { }

	// RVA: 0x6BE9B80
	public static object DeleteDirectory(object directory) { }

	// RVA: 0x6BEA15C
	public static object GetFileLength(object filePath) { }

	// RVA: 0x6BEA498
	private static object _ReadFile(object filePath) { }

	// RVA: 0x6BEAAD8
	public static object ReadFile(object filePath) { }

	// RVA: 0x6BEAE24
	public static object WriteFile(object filePath, object data) { }

	// RVA: 0x6BEB1CC
	public static object WriteFile(object filePath, object data, object offset, object length) { }

	// RVA: 0x6BEB6A8
	public static object UnCheckedSafeDeleteFile(object filePath) { }

	// RVA: 0x6BEB0EC
	public static object DeleteFile(object filePath) { }

	// RVA: 0x6BEBC58
	public static object CopyFile(object srcFile, object dstFile) { }

	// RVA: 0x6BEBCCC
	public static object CopyOrReplaceFile(object srcFile, object dstFile) { }

	// RVA: 0x6BEBEC0
	public static object GetFileMd5(object filePath) { }

	// RVA: 0x6BEC028
	public static object GetMd5(object str) { }

	// RVA: 0x6BE91A8
	public static object CombinePath(object path1, object path2) { }

	// RVA: 0x6BEC18C
	public static object CombinePaths(object values) { }

	// RVA: 0x6BEC370
	public static object GetCachePath() { }

	// RVA: 0x6BEC4E0
	public static object CalcFileCRC(object fileFullpath, object length) { }

	// RVA: 0x6BEC9C8
	public static object FreeCrcBuffer() { }

	// RVA: 0x6BECB14
	public static object GetOpenningVideoPath() { }

	// RVA: 0x6BECD80
	public static object GetCachePath(object fileName) { }

	// RVA: 0x6BECE30
	public static object GetUpdateableResourceDir(object strRelativePath, object onlyExternal) { }

	// RVA: 0x6BE8D08
	public static object GetFullName(object fullPath) { }

	// RVA: 0x6BED368
	public static object DeletePathLastComponent(object path) { }

	// RVA: 0x6BED400
	public static object GetPathLastComponent(object path) { }

	// RVA: 0x6BE8DD0
	public static object EraseExtension(object fullName) { }

	// RVA: 0x6BED494
	public static object GetExtension(object fullName) { }

	// RVA: 0x6BED574
	public static object ClearDirectory(object fullPath) { }

	// RVA: 0x6BED724
	public static object ClearDirectory(object fullPath, object fileExtensionFilter, object folderFilter) { }

	// RVA: 0x6BEDA8C
	public static object GetIFSExtractPath() { }

	// RVA: 0x6BEDB50
	public static object OpenFileRead(object filepath) { }

	// RVA: 0x6BEDDE8
	public static object Rel2FullPathInExt(object filePath) { }

	// RVA: 0x6BEDF10
	public static object Rel2FullPathInExtraExt(object filePath) { }

	// RVA: 0x6BE92C8
	public static object get_InternalRootPath() { }

	// RVA: 0x6BE93C4
	public static object InternalAssetPackRootPath() { }

	// RVA: 0x6BEE038
	public static object Rel2FullPathInInt(object filePath) { }

	// RVA: 0x6BEE0E8
	public static object Rel2FullPathInAssetPack(object filePath) { }

	// RVA: 0x6BE878C
	public static object IsInternalPath(object filepath) { }

	// RVA: 0x6BEE198
	public static object LoadApkArchive() { }

	// RVA: 0x6BE72F8
	public static object Init() { }

	// RVA: 0x6BEE370
	private static object _ModifyAndroidInternalPath(object filepath) { }

	// RVA: 0x6BEE53C
	private static object _getAndroidZipArchive(object filepath) { }

	// RVA: 0x6BE8914
	private static object _IsFileExist_Internal(object filepath) { }

	// RVA: 0x6BEABE0
	private static object _ReadFile_Internal(object filepath) { }

	// RVA: 0x6BEDC68
	private static object _OpenFileRead_Internal(object filepath) { }

	// RVA: 0x6BEE8E0
	private static object .cctor() { }

}

// Namespace: ResCore
public static class CRC64
{

	// Fields
	private static readonly object s_CRC64Table; // 0x0
	private static object _threadCrcBuffer; // 0xFFFFFFFF80000000

	// Properties
	private static object _CrcBuffer { get; }

	// Methods

	// RVA: 0x6BEECF4
	private static object get__CrcBuffer() { }

	// RVA: 0x6BECA60
	public static object FreeCrcBuffer() { }

	// RVA: 0x6BEC784
	public static object Compute(object fs) { }

	// RVA: 0x6BEEE20
	private static object .cctor() { }

}

// Namespace: ResCore
public enum enResourceState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unload;
	public const object Loading;
	public const object Loaded;
	public const object MismatchName;
}

// Namespace: ResCore
public enum enResourceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object BattleScene;
	public const object Numeric;
	public const object Sound;
	public const object UIForm;
	public const object UIPrefab;
	public const object UI3DImage;
	public const object UISprite;
	public const object Streaming;
	public const object ActorInfo;
	public const object AGE;
	public const object UIAnimation;
	public const object TextResource;
	public const object UIShader;
	public const object Unknown;
}

// Namespace: ResCore
public enum EResourceType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ParticleResource;
	public const object MeshResource;
	public const object SceneResource;
}

// Namespace: 
private sealed class <LoadAsync>d__25
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <req>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6BEF670
	public object .ctor(object <>1__state) { }

	// RVA: 0x6BF17D0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6BF17D4
	private object MoveNext() { }

	// RVA: 0x6BF198C
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6BF1994
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6BF19D4
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <LoadFromAssetBundleAsync>d__34
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object resourcePackerInfo; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6BF0C5C
	public object .ctor(object <>1__state) { }

	// RVA: 0x6BF19DC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6BF19E0
	private object MoveNext() { }

	// RVA: 0x6BF1C10
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6BF1C18
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6BF1C58
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: ResCore
public class CResource
{

	// Fields
	public object m_key; // 0x8
	public object m_fullPathInResources; // 0x10
	public object m_fileFullPathInResources; // 0x18
	public object m_resourceType; // 0x20
	public object m_state; // 0x24
	public object m_contentType; // 0x28
	public object m_content; // 0x30
	public object m_isAbandon; // 0x38
	public object m_unloadBelongedAssetBundleAfterLoaded; // 0x39
	public object m_isParticle; // 0x3A
	public object m_isPersistant; // 0x3B
	private object m_referenceCount; // 0x3C
	public object m_resourceRequest; // 0x40

	// Properties
	public object m_data { get; }
	public object RefCount { get; }

	// Methods

	// RVA: 0x6BEEEB8
	public object get_m_data() { }

	// RVA: 0x6BEF018
	public object get_RefCount() { }

	// RVA: 0x6BEF078
	public static object GetResourceHash(object path) { }

	// RVA: 0x6BEF130
	public static object GetResourceKey(object relativePath) { }

	// RVA: 0x6BEF190
	public static object GetLoadHashFromResourceHash(object resHash) { }

	// RVA: 0x6BEF1F0
	public object .ctor(object keyHash, object fullPathInResources, object contentType, object resourceType, object unloadBelongedAssetBundleAfterLoaded) { }

	// RVA: 0x6BEF258
	public static object AssetPathToResourcePath(object pathName) { }

	// RVA: 0x6BEF328
	public object Load() { }

	// RVA: 0x6BEF5CC
	public object LoadAsync() { }

	// RVA: 0x6BEF69C
	private object _TryLoadBinStream() { }

	// RVA: 0x6BEF85C
	private object _TryLoadBinBytes() { }

	// RVA: 0x6BEFA1C
	public object LoadBin() { }

	// RVA: 0x6BEFE44
	private static object __FindEntryHelper(object pkg, object path) { }

	// RVA: 0x6BF00C0
	public object LoadFromZipPackage(object rInfo) { }

	// RVA: 0x6BF0468
	public object LoadFromAssetBundle(object resourcePackerInfo, object inbLogError) { }

	// RVA: 0x6BF0BA4
	public object LoadFromAssetBundleAsync(object resourcePackerInfo) { }

	// RVA: 0x6BF0C88
	public static object LoadObjectFromAssetBundleAsync(object assetKey, object bundle, object contentType, object fullPathInResources) { }

	// RVA: 0x6BF0DD4
	public virtual object FinishLoad(object content, object loadAsync) { }

	// RVA: 0x6BF0F74
	public object Unload() { }

	// RVA: 0x6BF105C
	public object Increase() { }

	// RVA: 0x6BF10C4
	public object Decrease(object instanceID) { }

}

// Namespace: ResCore
public enum CheckMode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Async;
	public const object Sync;
	public const object Parallel;
	public const object AsyncParallel;
}

// Namespace: ResCore
public class ZipCrcData
{

	// Fields
	public object Path; // 0x8
	public object CalcCrc; // 0x10
	public object TargetCrc; // 0x18

	// Methods

	// RVA: 0x6BF1C60
	public object .ctor() { }

}

// Namespace: ResCore
public class ZipCrcDataGroup
{

	// Fields
	public readonly object CrcDataList; // 0x8
	public object CrcCostTime; // 0x10
	public object CrcCheckCount; // 0x18
	public object CrcCheckFinish; // 0x1C
	public object ErrorCount; // 0x20

	// Methods

	// RVA: 0x6BF1C68
	public object .ctor() { }

}

// Namespace: ResCore
public class DatabinCrcData
{

	// Fields
	public object Path; // 0x8
	public object CalcCrc; // 0x10
	public object TargetCrc; // 0x18

	// Methods

	// RVA: 0x6BF1CE8
	public object .ctor() { }

}

// Namespace: ResCore
public class DatabinCrcDataGroup
{

	// Fields
	public readonly object CrcDataList; // 0x8
	public object CrcCostTime; // 0x10
	public object CrcCheckCount; // 0x18
	public object CrcCheckFinish; // 0x1C
	public object ErrorCount; // 0x20

	// Methods

	// RVA: 0x6BF1CF0
	public object .ctor() { }

}

// Namespace: 
public enum ReqType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NormalReq;
	public const object AsyncReq;
}

// Namespace: 
public sealed class Callback
{

	// Methods

	// RVA: 0x6BF236C
	public object .ctor(object object, object method) { }

	// RVA: 0x6BF2488
	public virtual object Invoke(object req) { }

}

// Namespace: ResCore
public class AsyncLoadReq
{

	// Fields
	private object <path>k__BackingField; // 0x8
	private object <canceled>k__BackingField; // 0x10
	public object isAsync; // 0x11
	private object <isLoaded>k__BackingField; // 0x12
	public object LoadedCallback; // 0x18
	public object loadFinishCallback; // 0x20
	public object content; // 0x28
	public object instance; // 0x30
	public object container; // 0x38
	public object param1; // 0x40
	public object param2; // 0x48
	public object flags; // 0x50
	public object reqSeq; // 0x54
	public object reqType; // 0x58
	public object res; // 0x60

	// Properties
	public object path { get; set; }
	public object canceled { get; set; }
	public object isLoaded { get; set; }

	// Methods

	// RVA: 0x6BF1D70
	public object get_path() { }

	// RVA: 0x6BF1D78
	public object set_path(object value) { }

	// RVA: 0x6BF1D80
	public object get_canceled() { }

	// RVA: 0x6BF1D88
	private object set_canceled(object value) { }

	// RVA: 0x6BF1D90
	public object get_isLoaded() { }

	// RVA: 0x6BF1D98
	private object set_isLoaded(object value) { }

	// RVA: 0x6BF1DA0
	public object .ctor() { }

	// RVA: 0x6BF1DA8
	public object .ctor(object _path, object cb, object _param) { }

	// RVA: 0x6BF1DF8
	public object Cancel() { }

	// RVA: 0x6BF1E5C
	public virtual object OnLoaded() { }

	// RVA: 0x6BF1EDC
	public virtual object OnLoadFinish() { }

	// RVA: 0x6BF1F5C
	public object Clear() { }

	// RVA: 0x6BF1FD8
	public object OnResourceLoadComplete() { }

}

// Namespace: 
public sealed class OnResourceLoaded
{

	// Methods

	// RVA: 0x6BF4DF0
	public object .ctor(object object, object method) { }

	// RVA: 0x6BF9AC8
	public virtual object Invoke(object resource) { }

}

// Namespace: 
public class LoadingResourceTask
{

	// Fields
	public object resource; // 0x8
	public object finishCallback; // 0x10
	public object requests; // 0x18
	public object bIncreaseThreadPriority; // 0x20
	public object reqType; // 0x24

	// Methods

	// RVA: 0x6BF505C
	public object .ctor(object _resource, object loadedCallback) { }

	// RVA: 0x6BF9ADC
	public object HasRequestAndAllCanceled() { }

}

// Namespace: 
private class LoadingResourcePackTask
{

	// Fields
	public object resPack; // 0x8
	public object bIncreaseThreadPriority; // 0x10
	public object asyncLoadAssetBundleTaskEnumerator; // 0x18

	// Methods

	// RVA: 0x6BF71FC
	public object .ctor(object _resPack, object _bIncreaseThreadPriority) { }

}

// Namespace: 
private sealed class <>c__DisplayClass12_0
{

	// Fields
	public object ifsExtractPath; // 0x8

	// Methods

	// RVA: 0x6BFAB38
	public object .ctor() { }

	// RVA: 0x6BFAC08
	internal object <ParallelCrcXor>b__0(object info) { }

}

// Namespace: 
private class CRCValueUpdater
{

	// Fields
	private object _crcValue; // 0x8
	public object ErrorCount; // 0x10
	public object HeadMisMatchCount; // 0x14
	private object m_infoSetList; // 0x18
	private object m_crcXorAction; // 0x20
	private object _thread; // 0x28

	// Properties
	public object CRCValue { get; }

	// Methods

	// RVA: 0x6BF350C
	public object get_CRCValue() { }

	// RVA: 0x6BF3864
	public object .ctor(object toCalSets) { }

	// RVA: 0x6BF3A80
	public object Start() { }

	// RVA: 0x6BF9BFC
	private object _Start() { }

	// RVA: 0x6BFA668
	private object SyncCrcXor(object verifitionInfoList) { }

	// RVA: 0x6BFA9B4
	private object ParallelCrcXor(object verifitionInfoList) { }

	// RVA: 0x6BFAB40
	private static object CalcZipCRCAndHeader(object fileFullpath, object headMatch) { }

	// RVA: 0x6BFA854
	private static object CheckZipPackerCrcXor(object verificationInfo, object ifsExtractPath, object headMatch) { }

	// RVA: 0x6BF349C
	public object WaitForReady() { }

}

// Namespace: 
public struct ZipCRCCheckResult
{

	// Fields
	public object CRCValue; // 0xFFFFFFFFFFFFFFF8
	public object HeadMisMatchCount; // 0x0
	public object ErrorCount; // 0x4
}

// Namespace: 
public struct DatabinCRCCheckResult
{

	// Fields
	public object ErrorCount; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: 
private sealed class <>c__DisplayClass78_0
{

	// Fields
	public object req; // 0x8
	public object resource; // 0x10

	// Methods

	// RVA: 0x6BF4DE8
	public object .ctor() { }

	// RVA: 0x6BFAC5C
	internal object <GetResourceAsync>b__0(object loadedRes) { }

}

// Namespace: 
private sealed class <InitResourcePackinfoSets>d__11
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object mergeLanguage; // 0x20
	private object <infoSet>5__2; // 0x28
	private object <iter>5__3; // 0x30

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6BF2B1C
	public object .ctor(object <>1__state) { }

	// RVA: 0x6BFAE14
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6BFAE18
	private object MoveNext() { }

	// RVA: 0x6BFBF80
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6BFBF88
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6BFBFC8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <InitResourceVerificationInfoSets>d__12
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6BF2BEC
	public object .ctor(object <>1__state) { }

	// RVA: 0x6BFBFD0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6BFBFD4
	private object MoveNext() { }

	// RVA: 0x6BFC390
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6BFC398
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6BFC3D8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <LoadResidentAssetBundles_help>d__72
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object resourcePackerInfoSet; // 0x18
	private object <i>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6BF44C0
	public object .ctor(object <>1__state) { }

	// RVA: 0x6BFC3E0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6BFC3E4
	private object MoveNext() { }

	// RVA: 0x6BFC670
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6BFC678
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6BFC6B8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <UpdateLoadingTaskCoroutineEntry>d__118
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <headTask>5__2; // 0x20
	private object <numTask>5__3; // 0x28
	private object <resource>5__4; // 0x30
	private object <resPack>5__5; // 0x38
	private object <iterator>5__6; // 0x40

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6BF9394
	public object .ctor(object <>1__state) { }

	// RVA: 0x6BFC6C0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6BFC6C4
	private object MoveNext() { }

	// RVA: 0x6BFD580
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6BFD588
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6BFD5C8
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: ResCore
public class CResourceManager
{

	// Fields
	public static readonly object VersionFileName; // 0x0
	private object m_resourceInfoassetBundle; // 0x8
	private object m_resourceVerificationInfoSetBundle; // 0x10
	private object m_resourceVerificationInfoSet; // 0x18
	private object m_lastLoadedLanguage; // 0x20
	private object m_resourcePackerInfoSetList; // 0x28
	private object m_resourcePackerInfoSet_Lan; // 0x30
	private object m_cachedResourceMap; // 0x38
	private object m_clearUnusedAssets; // 0x40
	private object m_collectGarbage; // 0x41
	private static object _simulatorAssetBundle; // 0x8
	public object DisableParallelAsyncLoading; // 0x42
	public object EnableNtfCrc; // 0x43
	public object CheckMode; // 0x44
	public readonly object ZipCrcDataGroupList; // 0x48
	public readonly object DatabinCrcDataGroupList; // 0x50
	private object m_loadingTask; // 0x58
	private object m_resPackWaitingList; // 0x60
	private object m_resPackLoadingList; // 0x68
	public object m_IsLoadingCoroutine; // 0x70
	private object m_backgroundLoadingPriority; // 0x74
	private object m_standAloneRes; // 0x78
	private static object s_UseAsianGamesFiles; // 0xC
	private object _zipCRCValue; // 0x80
	private object m_databinCrcErrorCount; // 0x88
	private object _CRCValueUpdater; // 0x90
	public static object isBattleState; // 0xD
	public static object s_isLogError; // 0xE

	// Properties
	public static object instance { get; }
	public static object IsSimuatorAssetBudle { get; }
	public object IsReady { get; }
	public static object UseAsianGamesFiles { get; set; }
	public object ZipCRCValue { get; }
	public object ZipCRCCheckValue { get; }
	public object DatabinCRCCheckValue { get; }

	// Methods

	// RVA: 0x6BF249C
	private object GetFileStream(object fileFullPath) { }

	// RVA: 0x6BF255C
	public object ReadVersion(object version, object SVNRevision, object readFromAppOnly) { }

	// RVA: 0x6BED2A4
	public static object EditorABRoot() { }

	// RVA: 0x6BF299C
	public static object get_instance() { }

	// RVA: 0x6BF125C
	public static object GetInstance() { }

	// RVA: 0x6BF2A64
	public object InitResourcePackinfoSets(object mergeLanguage) { }

	// RVA: 0x6BF2B48
	public object InitResourceVerificationInfoSets() { }

	// RVA: 0x6BED25C
	public static object get_IsSimuatorAssetBudle() { }

	// RVA: 0x6BF2C18
	public object get_IsReady() { }

	// RVA: 0x6BF2CB8
	private static object UnloadZipPackage_helper(object set) { }

	// RVA: 0x6BF2F24
	public object UnloadAllZipPackages() { }

	// RVA: 0x6BF3044
	public static object get_UseAsianGamesFiles() { }

	// RVA: 0x6BF30F0
	public static object set_UseAsianGamesFiles(object value) { }

	// RVA: 0x6BE70B4
	public object Init() { }

	// RVA: 0x6BF3248
	public object CustomUpdate() { }

	// RVA: 0x6BF3378
	public object get_ZipCRCValue() { }

	// RVA: 0x6BF356C
	public object get_ZipCRCCheckValue() { }

	// RVA: 0x6BF35F4
	public object get_DatabinCRCCheckValue() { }

	// RVA: 0x6BF3654
	public object IsCrcConfigExist() { }

	// RVA: 0x6BF3754
	public object CheckCrcXor() { }

	// RVA: 0x6BF3CC8
	public object CheckDatabinCrcXor(object databinCrcDic) { }

	// RVA: 0x6BF43A4
	public object IsResourceHashConflict(object hashKey, object resourceName) { }

	// RVA: 0x6BF441C
	private static object LoadResidentAssetBundles_help(object resourcePackerInfoSet) { }

	// RVA: 0x6BF44EC
	public object GetFromCache(object resourceKey, object resourceType) { }

	// RVA: 0x6BF4600
	public object GetResourceBelongABs(object abs, object fullPathInResources, object withDependencies) { }

	// RVA: 0x6BF4724
	public object GetResourceAsync(object req, object resourceContentType, object resourceType, object needCached, object unloadBelongedAssetBundleAfterLoaded, object bIncreaseThreadPriority) { }

	// RVA: 0x6BF51E4
	public object GetResource(object fullPathInResources, object resourceContentType, object resourceType, object needCached, object unloadBelongedAssetBundleAfterLoaded, object isLogError, object ignoreLocal) { }

	// RVA: 0x6BF5708
	public object cacheResource(object resource) { }

	// RVA: 0x6BF582C
	public object MarkResourceAsPersistant(object fullPathInResources, object inPersistant) { }

	// RVA: 0x6BF12F4
	public object RemoveCachedResource(object fullPathInResources, object cleanupDelegate) { }

	// RVA: 0x6BF5918
	public object RemoveLoadErrorCachedResource(object fullPathInResources, object cleanupDelegate) { }

	// RVA: 0x6BF5A54
	public object UnloadAsset(object assetToUnload) { }

	// RVA: 0x6BF5AC0
	public object RemoveCachedResources(object resourceType, object clearImmediately) { }

	// RVA: 0x6BF5F84
	public object RemoveCachedResources(object resourceTypes, object clearImmediately) { }

	// RVA: 0x6BF60A0
	public object RemoveStandAloneAssetBundle() { }

	// RVA: 0x6BF64E0
	private static object Helper_UnloadAssetBundlesByTag(object set, object tag, object tags) { }

	// RVA: 0x6BF6700
	public object UnloadAssetBundlesByTag(object tag, object tags) { }

	// RVA: 0x6BF5F0C
	public object UnloadUnusedAssets(object gc) { }

	// RVA: 0x6BF32C4
	private object ExecuteUnloadUnusedAssets() { }

	// RVA: 0x6BF6844
	private static object UnloadUnusedAssetBundles_Help(object infoSetList) { }

	// RVA: 0x6BF5E60
	private object UnloadUnusedAssetBundles() { }

	// RVA: 0x6BF6B30
	private static object GetResourceBelongedPackerInfo_Help(object resourceKeyHash, object infoSetList, object pkgType) { }

	// RVA: 0x6BF144C
	public object GetResourceBelongedPackerInfo(object fullPathInResources, object pkgType) { }

	// RVA: 0x6BF6C44
	public object LoadAssetBundleAsync(object fullPathInResources, object resourceContentType, object resourceType, object bIncreaseThreadPriority) { }

	// RVA: 0x6BF75FC
	public static object LoadAssetBundle(object resourcePackerInfo) { }

	// RVA: 0x6BF78F0
	public object MarkFileInApp(object fullPathInIFS, object inApp) { }

	// RVA: 0x6BF7B90
	private static object GetResourcePackerInfo_Help(object fullPathInIFS, object infoSetList) { }

	// RVA: 0x6BF7A18
	public object GetResourcePackerInfo(object fullPathInIFS) { }

	// RVA: 0x6BF7D54
	private static object GetResourceBelongPacker(object resourcePackerInfoSetList, object fullPathInResources, object pkgType) { }

	// RVA: 0x6BF7E94
	public static object IsBattleResourceReady(object strResName, object pkgType, object ext) { }

	// RVA: 0x6BF8084
	public object IsResourceShouldExist(object strResPath, object ext, object pkgType) { }

	// RVA: 0x6BF8164
	private static object UpdateFileExsit(object info) { }

	// RVA: 0x6BF8468
	private static object IsResourceFileReady_help(object resourcePackerInfoSetList, object resourcePath, object pkgType, object flags, object ext) { }

	// RVA: 0x6BF7FDC
	public object IsResourceFileReady(object resourcePath, object pkgType, object flags, object ext) { }

	// RVA: 0x6BF88B0
	private object IsResourceFileReady_help(object resourcePath, object pkgType, object flags, object ext) { }

	// RVA: 0x6BF8B10
	public object GetStandAloneUIResource(object fullPathInResources, object assetBundleRelativePath) { }

	// RVA: 0x6BF8FB0
	public object LoadResourceFromInfoSet(object resource, object infoSetList) { }

	// RVA: 0x6BF4FC4
	private object LoadResource(object resource) { }

	// RVA: 0x6BF91A0
	private static object SetResourceLoadingBeginTime(object packer, object time) { }

	// RVA: 0x6BF7238
	private object PushWaitingResPackTaskToLoadingResPackTask() { }

	// RVA: 0x6BF31A4
	private object UpdateLoadingTaskCoroutineEntry() { }

	// RVA: 0x6BF93C0
	public object GetBelongedABFileMD5(object fullPath, object abPath) { }

	// RVA: 0x6BF6F9C
	public static object GetResourceBelongedPackerInfo(object resource, object infoSetList, object pkgType) { }

	// RVA: 0x6BF4F0C
	private object GetResourceBelongedPackerInfo(object resource) { }

	// RVA: 0x6BE6F38
	public object .ctor() { }

	// RVA: 0x6BF9770
	private static object .cctor() { }

}

// Namespace: ResCore
public struct stResourceInfo
{

	// Fields
	public object m_hashCode; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: ResCore
internal enum enAssetPKGLoadState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unload;
	public const object Loading;
	public const object Loaded;
}

// Namespace: ResCore
public enum enBundleFlag
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object KeepInResources;
	public const object UnCompress;
	public const object Resident;
	public const object ForceBuild;
	public const object LZ4Compress;
	public const object Encrypte;
	public const object ForceInIFS;
	public const object __IsInAppRunTime__;
	public const object ZstdCompress;
	public const object NotEncodeBytes;
	public const object StandAlone;
	public const object SplitSceneHDTexture;
}

// Namespace: ResCore
public enum enPkgType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object AssetBundle;
	public const object BinaryGroup;
	public const object ZipPackage;
	public const object UnKown;
}

// Namespace: 
internal class ZipPackage
{

	// Fields
	public object stream; // 0x8
	public object zipFile; // 0x10

	// Methods

	// RVA: 0x6BFFE2C
	public object .ctor(object fullPath) { }

}

// Namespace: 
private enum ELoadABResult
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object E_LABR_Success;
	public const object E_LABR_NoExist;
	public const object E_LABR_Fail;
	public const object E_LABR_NULL;
}

// Namespace: 
private sealed class <ASyncLoadAssetBundle>d__67
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object loaded; // 0x20
	private object <assetBundleFullPath>5__2; // 0x28
	private object <wwwLoopCount>5__3; // 0x30
	private object <loadBeginTime>5__4; // 0x34
	private object <timePassed>5__5; // 0x38
	private object <timeOut>5__6; // 0x3C
	private object <m_Request>5__7; // 0x40
	private object <>7__wrap7; // 0x48
	private object <itDependency>5__9; // 0x60

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6BFFF90
	public object .ctor(object <>1__state) { }

	// RVA: 0x6BFFFBC
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6C00040
	private object MoveNext() { }

	// RVA: 0x6C00B48
	private object <>m__Finally1() { }

	// RVA: 0x6C00CA4
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6C00CAC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6C00CEC
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <ASyncLoadAssetBundleParallel>d__68
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	public object loaded; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6C00CF4
	public object .ctor(object <>1__state) { }

	// RVA: 0x6C00D20
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6C00D24
	private object MoveNext() { }

	// RVA: 0x6C00E00
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6C00E08
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6C00E48
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: ResCore
public class CResourcePackerInfo
{

	// Fields
	public static readonly object s_NoTypeTreeTag; // 0x0
	internal object m_assetBundleState; // 0x8
	public object m_useASyncLoadingData; // 0xC
	internal object m_assetBundleRequest; // 0x10
	internal object m_assetBundleRequestBeginTime; // 0x18
	internal object m_assetBundleFullPath; // 0x20
	internal object m_asyncWWWLoopCount; // 0x28
	private object m_internalRefPKGObj; // 0x30
	public object m_pathInIFS; // 0x38
	public object m_crcxor; // 0x40
	public object m_tag; // 0x48
	public object m_resourceInfos; // 0x50
	public object m_fileExtMap; // 0x58
	public object m_flags; // 0x60
	private object m_configFlags; // 0x62
	public object m_children; // 0x68
	public object m_loadingBeginTime; // 0x70
	private object m_referenceCount; // 0x74
	private object m_dependencies; // 0x78
	private object <pkgType>k__BackingField; // 0x80

	// Properties
	public object m_isAssetBundle { get; }
	internal object m_assetBundle { get; set; }
	internal object m_zipPackage { get; set; }
	public object isFileInApp { get; set; }
	public object HasDependices { get; }
	public object selfAndAllDependencies { get; }
	public object pkgType { get; set; }

	// Methods

	// RVA: 0x6BF1558
	public object get_m_isAssetBundle() { }

	// RVA: 0x6BF0ADC
	internal object get_m_assetBundle() { }

	// RVA: 0x6BFD5D0
	internal object set_m_assetBundle(object value) { }

	// RVA: 0x6BF03A0
	internal object get_m_zipPackage() { }

	// RVA: 0x6BF2EBC
	internal object set_m_zipPackage(object value) { }

	// RVA: 0x6BF83CC
	public object get_isFileInApp() { }

	// RVA: 0x6BF7B08
	public object set_isFileInApp(object value) { }

	// RVA: 0x6BFD6A8
	public object get_HasDependices() { }

	// RVA: 0x6BF87B4
	public object get_selfAndAllDependencies() { }

	// RVA: 0x6BFD894
	public object AddDependency(object dep) { }

	// RVA: 0x6BFD710
	private object GetdirectAndInDirectDependencies(object infos) { }

	// RVA: 0x6BFDB10
	public object get_pkgType() { }

	// RVA: 0x6BFDB18
	internal object set_pkgType(object value) { }

	// RVA: 0x6BFC57C
	public object IsResident() { }

	// RVA: 0x6BF8EA4
	public object .ctor(object inPkgType) { }

	// RVA: 0x6BFD638
	public object HasFlag(object flag) { }

	// RVA: 0x6BFDB20
	public object ParseFromAsset(object asset) { }

	// RVA: 0x6BFE090
	private object _TryGetAssetbundleMD5FromDir(object assetsRootPath) { }

	// RVA: 0x6BFE200
	private static object _TryLoadPKGFromDir(object assetBundleFullPath, object pkgType, object pkgObject) { }

	// RVA: 0x6BFB888
	internal static object _LoadPKGHelper(object pathInIFS, object pkgType, object pkgObj) { }

	// RVA: 0x6BF76A4
	public object LoadPKG() { }

	// RVA: 0x6BFEC70
	public object LoadAssetBundle(object loaded) { }

	// RVA: 0x6BF94A8
	public object GetAssetbundleMD5WithoutDependency() { }

	// RVA: 0x6BFF278
	private static object LoadZipPageFromFile(object fullPath) { }

	// RVA: 0x6BFE53C
	internal static object CreatePKGFromFile(object assetBundleFullPath, object pkgType, object checkFileExsit) { }

	// RVA: 0x6BFD2D8
	public object ASyncLoadAssetBundle(object loaded) { }

	// RVA: 0x6BF92CC
	public object ASyncLoadAssetBundleParallel(object loaded) { }

	// RVA: 0x6BFF318
	private object WaitingASyncLoadAssetBundleParallel(object loaded) { }

	// RVA: 0x6BFF3D4
	private object WaitingASyncLoadAssetBundleParallelImpl(object loaded) { }

	// RVA: 0x6BFD3A0
	public object Increase(object loaded) { }

	// RVA: 0x6BF15C0
	public object Decrease(object loaded) { }

	// RVA: 0x6BF61E8
	public object UnloadAssetBundle(object force) { }

	// RVA: 0x6BF6A74
	public object IsAssetBundleLoaded() { }

	// RVA: 0x6BFFC30
	public object AddToResourceMap(object map) { }

	// RVA: 0x6BFFDC0
	private static object .cctor() { }

}

// Namespace: ResCore
public class CResourcePackerInfoSet
{

	// Fields
	public static object s_resourceIFSFileName; // 0x0
	public static object s_resourceIFSFileList; // 0x8
	public static object s_resourceIFSFileListJson; // 0x10
	public static object s_resourcePackerInfoSetFileNameNoExt; // 0x18
	public static object s_resourcePackerInfoSetFileName; // 0x20
	public object m_version; // 0x8
	public object m_svnrevision; // 0x10
	public object m_resourcePackerInfosAll; // 0x18
	private object m_resourceMapAssetBundle; // 0x20
	private object m_resourceMapZipPackage; // 0x28
	private object m_resourceMapBinaryGroup; // 0x30
	public static object s_stringCache; // 0x28

	// Methods

	// RVA: 0x6C00E50
	public static object GetResourcePackerInfoSetFileName_Lan(object lang, object ext) { }

	// RVA: 0x6C00EF8
	public object .ctor() { }

	// RVA: 0x6C00FF0
	public object Dispose(object isForce) { }

	// RVA: 0x6C01200
	private object GetResourceBelongBundlePath(object fullPathInResources, object pkgType) { }

	// RVA: 0x6C0144C
	public object GetABFromResoucePackInfo(object abs, object resourceinfo, object withDependencies) { }

	// RVA: 0x6C0165C
	public object GetResourceBelongABs(object abs, object fullPathInResources, object withDependencies) { }

	// RVA: 0x6C01708
	public object ParseFromAsset(object asset, object version, object svnRevision) { }

	// RVA: 0x6C01D90
	public object CreateResourceMap() { }

	// RVA: 0x6C012B4
	public object GetResourceBelongedPackerInfo(object resourceKeyHash, object pkgType) { }

	// RVA: 0x6C02280
	private static object .cctor() { }

}

// Namespace: ResCore
public class CZipVerificationInfo
{

	// Fields
	public object PathInIFS; // 0x8
	public object CrcXor; // 0x10
	public object LocalCrcXor; // 0x18
	public object IsHeadMatch; // 0x20

	// Methods

	// RVA: 0x6C023C8
	public object .ctor() { }

}

// Namespace: ResCore
public class CDatabinVerificationInfo
{

	// Fields
	public object PathInIFS; // 0x8
	public object CrcXor; // 0x10

	// Methods

	// RVA: 0x6C023D0
	public object .ctor() { }

}

// Namespace: ResCore
public class CResourceVerificationInfoSet
{

	// Fields
	private object <ZipVerificationInfoList>k__BackingField; // 0x8
	private object <DatabinVerificationInfoDic>k__BackingField; // 0x10

	// Properties
	public object ZipVerificationInfoList { get; set; }
	public object DatabinVerificationInfoDic { get; set; }

	// Methods

	// RVA: 0x6C023D8
	public object get_ZipVerificationInfoList() { }

	// RVA: 0x6C023E0
	private object set_ZipVerificationInfoList(object value) { }

	// RVA: 0x6C023E8
	public object get_DatabinVerificationInfoDic() { }

	// RVA: 0x6C023F0
	private object set_DatabinVerificationInfoDic(object value) { }

	// RVA: 0x6C023F8
	public object .ctor() { }

	// RVA: 0x6C024C4
	public object ParseFromAsset(object runTimeResourceVerificationInfoSet) { }

	// RVA: 0x6C02870
	public object Dispose() { }

}

// Namespace: 
public enum ResOpt
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ResLoad;
	public const object ResLoadAsync;
	public const object ABLoad;
	public const object ABLoadAsync;
	public const object Instantiate;
	public const object AtlasBuild;
	public const object ScriptAdd;
	public const object AssetLoad;
}

// Namespace: ResCore
public static class CStatistics
{

	// Fields
	public static object LoadNtf; // 0x0

	// Methods

	// RVA: 0x6C00BA4
	public static object RecordResOpt(object path, object resOpt) { }

}

// Namespace: ResCore
public class DLCVersion
{

	// Fields
	public static object s_VersionBundle; // 0x0
	public static object s_VersionFile; // 0x8
	public object BuildVersion; // 0x10

	// Methods

	// RVA: 0x6C0295C
	public object .ctor() { }

	// RVA: 0x6C02964
	private static object .cctor() { }

}

// Namespace: ResCore
public class ResFileList
{

	// Fields
	public static object s_ResFileListSaveFileName; // 0x0
	public static readonly object PathFilePath; // 0x8

	// Methods

	// RVA: 0x6C029FC
	private static object .cctor() { }

}

// Namespace: ResCore
public class RunTimeResourceItem
{

	// Fields
	public object HashCode; // 0x8
	public object Extension; // 0x10

	// Methods

	// RVA: 0x6C02A84
	public object .ctor() { }

}

// Namespace: ResCore
public class RunTimeResourcePackerInfo
{

	// Fields
	public object PathInIFS; // 0x8
	public object pkgType; // 0x10
	public object CrcXor; // 0x18
	public object Tag; // 0x20
	public object Flags; // 0x28
	public object ResourceInfos; // 0x30

	// Properties
	public object ePkgType { get; }

	// Methods

	// RVA: 0x6C02A8C
	public object get_ePkgType() { }

	// RVA: 0x6C02AEC
	public object .ctor() { }

}

// Namespace: ResCore
public class PackinfoMapItem
{

	// Fields
	public object parentIdx; // 0x8
	public object childIdx; // 0xC

	// Methods

	// RVA: 0x6C02AF4
	public object .ctor() { }

}

// Namespace: ResCore
public class RunTimeResourcePackerInfoSet
{

	// Fields
	public static object s_resourcePackerInfoSetFileNameABPath; // 0x0
	private object Version; // 0x10
	private object SVNRevision; // 0x18
	public object SetName; // 0x20
	public object AllResourcePackInfo; // 0x28
	public object AllParentIdexToChild; // 0x30

	// Methods

	// RVA: 0x6C02AFC
	public static object AssetPathForSet(object name) { }

	// RVA: 0x6C02B8C
	public object SetVersion(object v) { }

	// RVA: 0x6C02BF4
	public object SetSVNRevision(object v) { }

	// RVA: 0x6C02C5C
	public object .ctor() { }

	// RVA: 0x6C02C64
	private static object .cctor() { }

}

// Namespace: ResCore
public class RunTimeZipVerificationInfo
{

	// Fields
	public object PathInIFS; // 0x8
	public object CrcXor; // 0x10

	// Methods

	// RVA: 0x6C02CE0
	public object .ctor() { }

}

// Namespace: ResCore
public class RunTimeDatabinVerificationInfo
{

	// Fields
	public object PathInIFS; // 0x8
	public object CrcXor; // 0x10

	// Methods

	// RVA: 0x6C02CE8
	public object .ctor() { }

}

// Namespace: ResCore
public class RunTimeResourceVerificationInfoSet
{

	// Fields
	public static readonly object s_resourceVerificationInfoSetFileNameABPath; // 0x0
	public static readonly object s_resourceVerificationInfoSetFileNameNoExt; // 0x8
	private object Version; // 0x10
	private object SVNRevision; // 0x18
	public object AllZipVerificationInfo; // 0x20
	public object AllDatabinVerificationInfo; // 0x28

	// Methods

	// RVA: 0x6C02CF0
	public static object AssetPathForSet(object name) { }

	// RVA: 0x6C02D80
	public object SetVersion(object v) { }

	// RVA: 0x6C02DE8
	public object SetSVNRevision(object v) { }

	// RVA: 0x6C02E50
	public object .ctor() { }

	// RVA: 0x6C02E58
	private static object .cctor() { }

}

// Namespace: ResCore
public class ResVersion
{

	// Fields
	public static object s_ResVersionSaveFileName; // 0x0

	// Methods

	// RVA: 0x6C02EF0
	private static object .cctor() { }

}

// Namespace: 
private struct File
{

	// Fields
	public object Stream; // 0xFFFFFFFFFFFFFFF8
	public object Position; // 0x0
}

// Namespace: ResCore
public class WeakFileStream
{

	// Fields
	private object mPath; // 0x20
	private object mFile; // 0x28

	// Properties
	public override object CanRead { get; }
	public override object CanSeek { get; }
	public override object CanWrite { get; }
	public override object Length { get; }
	public override object Position { get; set; }

	// Methods

	// RVA: 0x6BFFED8
	public object .ctor(object path) { }

	// RVA: 0x6C02F5C
	public override object get_CanRead() { }

	// RVA: 0x6C03290
	public override object get_CanSeek() { }

	// RVA: 0x6C03330
	public override object get_CanWrite() { }

	// RVA: 0x6C033D0
	public override object get_Length() { }

	// RVA: 0x6C03470
	public override object get_Position() { }

	// RVA: 0x6C03514
	public override object set_Position(object value) { }

	// RVA: 0x6C035C4
	public override object Flush() { }

	// RVA: 0x6C03668
	public override object Read(object buffer, object offset, object count) { }

	// RVA: 0x6C0373C
	public override object Seek(object offset, object origin) { }

	// RVA: 0x6C03804
	public override object SetLength(object value) { }

	// RVA: 0x6C038B4
	public override object Write(object buffer, object offset, object count) { }

	// RVA: 0x6C02FFC
	private object GetFileStream(object create) { }

	// RVA: 0x6C03988
	public object Halt() { }

	// RVA: 0x6C03BC4
	protected override object Dispose(object disposing) { }

}

// Namespace: ResCore
public enum LogFilter
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ResourceBuilder;
	public const object SvnTools;
	public const object RuntimeTools;
	public const object BuildHelper;
	public const object GameBuilder;
	public const object TextureTools;
	public const object Misc;
	public const object AnimationTools;
}

// Namespace: 
public enum eLogLevelMask
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Info;
	public const object Warning;
	public const object Error;
	public const object Asset;
	public const object NonFinalErr;
	public const object Exception;
	public const object All;
}

// Namespace: 
public sealed class LogHandlerDelegate
{

	// Methods

	// RVA: 0x6C0421C
	public object .ctor(object object, object method) { }

	// RVA: 0x6C042B4
	public virtual object Invoke(object inLogLevel, object inFormat, object inArgs) { }

}

// Namespace: ResCore
public static class LogHelper
{

	// Fields
	public static object LogMask; // 0x0
	public static object LogHandler; // 0x8
	private static object DefaultLogSb; // 0x10

	// Methods

	// RVA: 0x6C03E24
	private static object _LogImpl(object inLogLevel, object inFormat, object inArgs) { }

	// RVA: 0x6C03F40
	public static object ReportCriticalException(object e, object inMessage) { }

	// RVA: 0x6C04108
	private static object .cctor() { }

}

// Namespace: ResCore
public interface IProfiler
{
}

// Namespace: ResCore
public static class ResProfiler
{

	// Fields
	public static object ProfilerImp; // 0x0
}

// Namespace: ResCore
public static class StringHelper
{

	// Fields
	private static object s_pathSep; // 0x0

	// Methods

	// RVA: 0x6C042C8
	private static object _JavaHashCode(object s, object len, object off) { }

	// RVA: 0x6C043D4
	public static object FileNameHashCodeIgnoreCaseEraseExt(object path) { }

	// RVA: 0x6C044F0
	public static object JavaHashCodeIgnoreCaseEraseExt(object s) { }

	// RVA: 0x6C045EC
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c__11<T0>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__11_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <SetString>b__11_0(object x) { }

}

// Namespace: ResCore.PreDLC
internal class JSONObject
{

	// Fields
	protected object _datastore; // 0x8
	protected object _path; // 0x10
	private object _root; // 0x18

	// Methods

	// RVA: 0x6C0468C
	public object .ctor(object path) { }

	// RVA: 0x6C04720
	protected object GetString(object key, object defaultValue) { }

	// RVA: 0x6C04914
	protected object GetString(object key, object deslist) { }

	// RVA: -1
	protected object GetString(object key, object deslist) { }

	// RVA: 0x6C04C54
	protected object SetString(object key, object value) { }

	// RVA: 0x6C04E10
	protected object SetString(object key, object value) { }

	// RVA: -1
	protected object SetString(object key, object value) { }

	// RVA: 0x6C0483C
	protected object HasKey(object key) { }

	// RVA: 0x6C04D3C
	protected object RemoveKey(object key) { }

	// RVA: 0x6C05110
	public virtual object Serialize() { }

	// RVA: 0x6C0516C
	public virtual object Deserialize() { }

	// RVA: 0x6C051C8
	public object Save(object path) { }

	// RVA: 0x6C0546C
	public override object ToString() { }

	// RVA: 0x6C055C8
	public object Load(object path) { }

	// RVA: 0x6C0575C
	public object Parse(object contents) { }

	// RVA: 0x6C05B60
	public object Delete(object path) { }

	// RVA: 0x6C05CF8
	public object Exists(object path) { }

}

// Namespace: 
private enum TOKEN
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object NONE;
	public const object CURLY_OPEN;
	public const object CURLY_CLOSE;
	public const object SQUARED_OPEN;
	public const object SQUARED_CLOSE;
	public const object COLON;
	public const object COMMA;
	public const object STRING;
	public const object NUMBER;
	public const object TRUE;
	public const object FALSE;
	public const object NULL;
}

// Namespace: 
private sealed class Parser
{

	// Fields
	private object json; // 0x8

	// Properties
	private object PeekChar { get; }
	private object NextChar { get; }
	private object NextWord { get; }
	private object NextToken { get; }

	// Methods

	// RVA: 0x6C0625C
	private object .ctor(object jsonString) { }

	// RVA: 0x6C062D4
	private object get_PeekChar() { }

	// RVA: 0x6C063C0
	private object get_NextChar() { }

	// RVA: 0x6C064AC
	private object get_NextWord() { }

	// RVA: 0x6C06668
	private object get_NextToken() { }

	// RVA: 0x6C05E10
	public static object Parse(object jsonString) { }

	// RVA: 0x6C06AD0
	public object Dispose() { }

	// RVA: 0x6C06B4C
	private object ParseObject() { }

	// RVA: 0x6C07128
	private object ParseArray() { }

	// RVA: 0x6C06A64
	private object ParseValue() { }

	// RVA: 0x6C0733C
	private object ParseByToken(object token) { }

	// RVA: 0x6C06D44
	private object ParseString() { }

	// RVA: 0x6C074A8
	private object ParseNumber() { }

	// RVA: 0x6C06924
	private object EatWhitespace() { }

}

// Namespace: 
private sealed class Serializer
{

	// Fields
	private object builder; // 0x8

	// Methods

	// RVA: 0x6C075F4
	private object .ctor() { }

	// RVA: 0x6C06068
	public static object Serialize(object obj) { }

	// RVA: 0x6C07664
	private object SerializeValue(object value) { }

	// RVA: 0x6C08098
	private object SerializeObject(object obj) { }

	// RVA: 0x6C07C84
	private object SerializeArray(object array) { }

	// RVA: 0x6C078B8
	private object SerializeString(object str) { }

	// RVA: 0x6C08648
	private object SerializeOther(object value) { }

}

// Namespace: ResCore.PreDLC
public static class Json
{

	// Fields
	private static object numberFormat; // 0x0

	// Methods

	// RVA: 0x6C05AEC
	public static object Deserialize(object json) { }

	// RVA: 0x6C05568
	public static object Serialize(object obj) { }

	// RVA: 0x6C06190
	private static object .cctor() { }

}

// Namespace: ResCore.PreDLC
internal class PreDLCRecord
{

	// Fields
	public object ItemList; // 0x20
	public object DLCList; // 0x28
	public object version; // 0x30

	// Methods

	// RVA: 0x6C088A4
	public object .ctor(object path) { }

	// RVA: 0x6C089DC
	public override object Serialize() { }

	// RVA: 0x6C08AF8
	public override object Deserialize() { }

}

// Namespace: ResCore.PreDLC
internal class CacheInfo
{

	// Fields
	public object TotalSize; // 0x8
	public object DownloadedSize; // 0x10
	public object ItemSizes; // 0x18

	// Methods

	// RVA: 0x6C08C2C
	public object .ctor() { }

}

// Namespace: ResCore.PreDLC
public class PreDLCConfigHelper
{

	// Fields
	private object _idx; // 0x8
	private object _record; // 0x10
	private object _puffer; // 0x18
	private object _cacheInfos; // 0x20
	private object _IsChangeAndNeedSave; // 0x28
	private object _SaveCountDown; // 0x2C

	// Methods

	// RVA: 0x6C08CAC
	public object .ctor(object resDir) { }

	// RVA: 0x6C08DDC
	public object GetPreDLCDownloadState() { }

	// RVA: 0x6C08F88
	public object MarkDLCDownloaded(object id) { }

	// RVA: 0x6C09150
	public object SaveRecord() { }

	// RVA: 0x6C09224
	private object _SaveRecord() { }

	// RVA: 0x6C0979C
	internal object Update() { }

	// RVA: 0x6C09830
	public object IsNeedToSyncToDLC(object appVersion) { }

	// RVA: 0x6C09A10
	public object GetDownloadedFileListForCopy(object appVersion) { }

	// RVA: 0x6C09E20
	private object GetDLCConfig(object id) { }

	// RVA: 0x6C0A068
	internal object GetDLCDownloadPercentage(object id) { }

	// RVA: 0x6C0A214
	internal object GetDLCDownloadedSize(object id) { }

	// RVA: 0x6C0ABA0
	internal object GetDLCTotalSizeByIDs(object ids) { }

	// RVA: 0x6C0A12C
	internal object GetDLCSize(object id) { }

	// RVA: 0x6C0AC88
	private object GetCache(object ids) { }

	// RVA: 0x6C0A5E4
	private object GetCache(object id) { }

	// RVA: 0x6C0AA60
	private object IsSameAsInDLC(object item) { }

	// RVA: 0x6C0B630
	public object GetDLCDownloadList(object id, object list, object fixedSize) { }

	// RVA: 0x6C0BB8C
	public object UnloadConfig() { }

	// RVA: 0x6C0BCA8
	public object LoadConfig(object resDir, object isforce) { }

	// RVA: 0x6C0C194
	internal object SetPuffer(object puffer) { }

}

// Namespace: ResCore.PreDLC
public class PreDLCDownloader
{

	// Fields
	private object _paths; // 0x8
	private object _callbacks; // 0x10
	private object _totalSizeToDownload; // 0x18
	private object _progressSize; // 0x20
	private object <ID>k__BackingField; // 0x28
	private object <TaskID>k__BackingField; // 0x30
	private object <FixedSize>k__BackingField; // 0x38

	// Properties
	public object ProgressSize { get; }
	public object Percent { get; }
	public object ID { get; set; }
	public object TaskID { get; set; }
	public object Paths { get; set; }
	internal object FixedSize { set; }

	// Methods

	// RVA: 0x6C0C1FC
	public object get_ProgressSize() { }

	// RVA: 0x6C0C25C
	public object get_Percent() { }

	// RVA: 0x6C0C384
	public object get_ID() { }

	// RVA: 0x6C0C38C
	public object set_ID(object value) { }

	// RVA: 0x6C0C394
	public object get_TaskID() { }

	// RVA: 0x6C0C39C
	internal object set_TaskID(object value) { }

	// RVA: 0x6C0C3A4
	public object get_Paths() { }

	// RVA: 0x6C0C404
	internal object set_Paths(object value) { }

	// RVA: 0x6C0C46C
	internal object set_FixedSize(object value) { }

	// RVA: 0x6C0C474
	public object NotifyStop() { }

	// RVA: 0x6C0C988
	private object _NotifyStop() { }

	// RVA: 0x6C0CAA4
	public object .ctor(object id, object paths, object callbacks) { }

	// RVA: 0x6C0CB68
	private object ResCore.DLC.DLCDownloadRequest.OnSetupTasks(object session) { }

	// RVA: 0x6C0CF10
	private object ResCore.DLC.DLCDownloadRequest.OnTaskProgress(object task, object nowSize, object totalSize) { }

	// RVA: 0x6C0D064
	private object ResCore.DLC.DLCDownloadRequest.OnTaskFinish(object task) { }

	// RVA: 0x6C0D18C
	private object ResCore.DLC.DLCDownloadRequest.OnError(object task, object errInfo) { }

	// RVA: 0x6C0D2CC
	private object ResCore.DLC.DLCDownloadRequest.OnTaskStop(object task, object isForce) { }

}

// Namespace: ResCore.PreDLC
public enum PufferInitStage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object DownResSnapshot;
	public const object UpdateFileList;
	public const object GetResURL;
	public const object GETFILELIST;
}

// Namespace: ResCore.PreDLC
public enum PufferRestoreStage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object StartRestore;
	public const object LoadLocalFilelist;
	public const object CheckFilelistMd5;
	public const object RestoreEnd;
}

// Namespace: ResCore.PreDLC
public enum PufferBatchDownloadType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PBT_BatchTask;
	public const object PBT_FileTask;
	public const object PBT_FileTask_Retry;
}

// Namespace: 
public enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Normal;
	public const object Update;
	public const object Delete;
	public const object Add;
}

// Namespace: ResCore.PreDLC
public class PufferFileInfo
{
}

// Namespace: ResCore.PreDLC
public interface IPufferCallBackBridge
{

	// Methods

	// RVA: -1
	public abstract object OnInitReturn(object isSuccess, object errorCode) { }

	// RVA: -1
	public abstract object OnInitProgress(object stage, object nowSize, object totalSize) { }

	// RVA: -1
	public abstract object OnDownloadReturn(object taskId, object fileid, object isSuccess, object errorCode) { }

	// RVA: -1
	public abstract object OnDownloadProgress(object taskId, object nowSize, object totalSize) { }

	// RVA: -1
	public abstract object OnDownloadBatchReturn(object batchTaskId, object fileid, object isSuccess, object errorCode, object batchType, object strRet) { }

	// RVA: -1
	public abstract object OnDownloadBatchProgress(object batchTaskId, object nowSize, object totalSize) { }

	// RVA: -1
	public abstract object OnPufferFileListItem(object fileName, object st) { }

	// RVA: -1
	public abstract object OnRestoreReturn(object isSuccess, object errorCode) { }

	// RVA: -1
	public abstract object OnRestoreProgress(object stage, object nowSize, object totalSize) { }

}

// Namespace: ResCore.PreDLC
public interface IPufferBridge
{

	// Methods

	// RVA: -1
	public abstract object Init(object callbackProxy, object productId, object serverUrl, object resDir, object maxDownloadSpeed, object maxDownTask, object maxDownloadsPerTask) { }

	// RVA: -1
	public abstract object UnInit() { }

	// RVA: -1
	public abstract object Update() { }

	// RVA: -1
	public abstract object GetFileId(object filePath) { }

	// RVA: -1
	public abstract object IsFileReady(object fileId) { }

	// RVA: -1
	public abstract object IsBatchDirReady(object dir, object blSubDir, object nTotal, object nReady, object nNotReady) { }

	// RVA: -1
	public abstract object GetFileSizeCompressed(object fileId) { }

	// RVA: -1
	public abstract object GetBatchDirSizeCompressed(object dir, object blSubDir) { }

	// RVA: -1
	public abstract object GetFileMd5(object fileId) { }

	// RVA: -1
	public abstract object RemoveFile(object fileId) { }

	// RVA: -1
	public abstract object GetBatchDirFileCount(object dir, object blSubDir, object nTotal) { }

	// RVA: -1
	public abstract object GetCurrentSpeed() { }

	// RVA: -1
	public abstract object SetTaskPriority(object taskId, object priority) { }

	// RVA: -1
	public abstract object SetDLMaxTask(object maxTask) { }

	// RVA: -1
	public abstract object SetDLMaxSpeed(object maxSpeed) { }

	// RVA: -1
	public abstract object DownloadFile(object fileId, object forceDownload, object priority) { }

	// RVA: -1
	public abstract object DownloadBatchList(object lst, object forceSync, object priority) { }

	// RVA: -1
	public abstract object DownloadBatchDir(object dir, object blSubDir, object forceSync, object priority) { }

	// RVA: -1
	public abstract object RemoveTask(object taskID) { }

	// RVA: -1
	public abstract object PauseTask(object taskId) { }

	// RVA: -1
	public abstract object ResumeTask(object taskId) { }

	// RVA: -1
	public abstract object StartRestoreFiles(object priority) { }

}

// Namespace: 
private sealed class <SyncDownloadedStateToDLC>d__24
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	public object <>4__this; // 0x10
	private object <list>5__2; // 0x18
	private object <StepLength>5__3; // 0x20
	private object <lastIndex>5__4; // 0x24
	private object <i>5__5; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Single>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6C0DD0C
	public object .ctor(object <>1__state) { }

	// RVA: 0x6C11D34
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6C11D38
	private object MoveNext() { }

	// RVA: 0x6C13064
	private object System.Collections.Generic.IEnumerator<System.Single>.get_Current() { }

	// RVA: 0x6C1306C
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6C130AC
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: ResCore.PreDLC
public class PreDLCManager
{

	// Fields
	private static object _instance; // 0x0
	public static object PreDLCUseRevision; // 0x8
	public static object PreDLCStartDate; // 0x10
	public static object PreDLCStartMaxVersion; // 0x18
	private object _puffer; // 0x8
	private object _pendingList; // 0x10
	private object _loadingList; // 0x18
	private object _isPufferInited; // 0x20
	private object _isConfigLoaded; // 0x21
	private object _productId; // 0x24
	private object _serverUrl; // 0x28
	private object _resDir; // 0x30
	private static object MaxDownloadTask; // 0x20
	private object _configLoader; // 0x38
	private object _configHelper; // 0x40
	private object _OnActiveDownloadCB; // 0x48
	private object _isEnableDownload; // 0x50
	private object _isNeedSyncToDLC; // 0x51

	// Properties
	public static object instance { get; }
	public object IsConfigLoaded { get; }

	// Methods

	// RVA: 0x6C0C5D4
	public static object get_instance() { }

	// RVA: 0x6C0D3E0
	public object get_IsConfigLoaded() { }

	// RVA: 0x6C0D440
	public object Init(object productId, object serverUrl, object resDir, object appVersion) { }

	// RVA: 0x6C0DAC4
	private static object GetVersionNumber(object versionStr) { }

	// RVA: 0x6C0DC68
	public object SyncDownloadedStateToDLC() { }

	// RVA: 0x6C0CCD0
	public object AddDownloadList(object downloader) { }

	// RVA: 0x6C0C6EC
	public object RemoveDownloadList(object downloader) { }

	// RVA: 0x6C0DD38
	public object Update() { }

	// RVA: 0x6C0E5A4
	public object ActiveDownload(object OnInit) { }

	// RVA: 0x6C0DEC0
	private object DownloadNext() { }

	// RVA: 0x6C0E7FC
	private object CloseDownloader(object cur, object isSuccess, object msg) { }

	// RVA: 0x6C0EAA8
	public object DeactiveDownload() { }

	// RVA: 0x6C0EFDC
	public object GetDLCDownloadPercentage(object id) { }

	// RVA: 0x6C0F354
	public object GetDLCDownloadedSize(object id, object onlyDeletable) { }

	// RVA: 0x6C0F470
	public object GetDLCDownloadedSizeByIDs(object ids, object onlyDeletable) { }

	// RVA: 0x6C0F64C
	public object GetDLCSize(object id) { }

	// RVA: 0x6C0F6F0
	public object GetDLCTotalSizeByIDs(object ids) { }

	// RVA: 0x6C0F794
	public object Clear() { }

	// RVA: 0x6C105C0
	private object ResCore.PreDLC.IPufferCallBackBridge.OnInitReturn(object isSuccess, object errorCode) { }

	// RVA: 0x6C109B0
	private object LoadConfig(object isSuccess, object errorCode, object isForce) { }

	// RVA: 0x6C10BF8
	private object ResCore.PreDLC.IPufferCallBackBridge.OnInitProgress(object stage, object nowSize, object totalSize) { }

	// RVA: 0x6C10D5C
	private object ResCore.PreDLC.IPufferCallBackBridge.OnDownloadReturn(object taskId, object fileid, object isSuccess, object errorCode) { }

	// RVA: 0x6C11334
	private object ResCore.PreDLC.IPufferCallBackBridge.OnDownloadProgress(object taskId, object nowSize, object totalSize) { }

	// RVA: 0x6C11560
	private object ResCore.PreDLC.IPufferCallBackBridge.OnDownloadBatchReturn(object batchTaskId, object fileid, object isSuccess, object errorCode, object batchType, object strRet) { }

	// RVA: 0x6C1184C
	private object ResCore.PreDLC.IPufferCallBackBridge.OnDownloadBatchProgress(object batchTaskId, object nowSize, object totalSize) { }

	// RVA: 0x6C11A70
	private object ResCore.PreDLC.IPufferCallBackBridge.OnPufferFileListItem(object fileName, object st) { }

	// RVA: 0x6C11BA4
	private object ResCore.PreDLC.IPufferCallBackBridge.OnRestoreReturn(object isSuccess, object errorCode) { }

	// RVA: 0x6C11C40
	private object ResCore.PreDLC.IPufferCallBackBridge.OnRestoreProgress(object stage, object nowSize, object totalSize) { }

	// RVA: 0x6C1107C
	private object GetDownloaderByTaskId(object taskId) { }

	// RVA: 0x6C0F09C
	private object GetDownloaderById(object id) { }

	// RVA: 0x6C0D348
	public object .ctor() { }

	// RVA: 0x6C11CE4
	private static object .cctor() { }

}

// Namespace: ResCore.DLC
public enum DLCDownloadState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Downloading;
	public const object InQueue;
	public const object UnStart;
	public const object Dowloaded;
	public const object Invalid;
}

// Namespace: ResCore.DLC
public enum DLCDownloadedCustomStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object True;
	public const object False;
}

// Namespace: ResCore.DLC
public interface DLCDownloaderMgr
{

	// Properties
	public abstract object AllDLCIDs { get; }

	// Methods

	// RVA: -1
	public abstract object IsDLCDownloaded(object id, object defaultValue) { }

	// RVA: -1
	public abstract object DownLoadDLC(object id, object insertToHead) { }

	// RVA: -1
	public abstract object UpdateCRCAndSave() { }

	// RVA: -1
	public abstract object get_AllDLCIDs() { }

}

// Namespace: ResCore.DLC
public interface IDLCCreaterFilter
{

	// Methods

	// RVA: -1
	public abstract object IsConfigNeed(object id) { }

	// RVA: -1
	public abstract object IsConfigDeletable(object id) { }

}

// Namespace: ResCore.DLC
internal class DefaultDLCCreateFilter
{

	// Methods

	// RVA: 0x6C13114
	public object IsConfigDeletable(object id) { }

	// RVA: 0x6C13178
	public object IsConfigNeed(object id) { }

	// RVA: 0x6C131E4
	public object .ctor() { }

}

// Namespace: 
public sealed class DLCDownloadedNextChange
{

	// Methods

	// RVA: 0x6C2098C
	public object .ctor(object object, object method) { }

	// RVA: 0x6C20A24
	public virtual object Invoke(object id) { }

}

// Namespace: 
private sealed class <>c__DisplayClass137_0
{

	// Fields
	public object pufferstarted; // 0x8
	public object OnInit; // 0x10

	// Methods

	// RVA: 0x6C20A38
	public object .ctor() { }

	// RVA: 0x6C20A40
	internal object <WaitForDLCActived>b__0(object s, object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass138_0
{

	// Fields
	public object <>4__this; // 0x8
	public object OnInit; // 0x10

	// Methods

	// RVA: 0x6C20A64
	public object .ctor() { }

	// RVA: 0x6C20A6C
	internal object <ActiveDownload>b__0(object isSuccess, object errorCode) { }

}

// Namespace: 
private sealed class <PreCheckDLCItem>d__114
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	public object <>4__this; // 0x10
	public object maxStep; // 0x18
	private object <count>5__2; // 0x1C
	private object <i>5__3; // 0x20
	private object <iter>5__4; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Single>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6C20BEC
	public object .ctor(object <>1__state) { }

	// RVA: 0x6C20C18
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6C20C1C
	private object MoveNext() { }

	// RVA: 0x6C211C4
	private object System.Collections.Generic.IEnumerator<System.Single>.get_Current() { }

	// RVA: 0x6C211CC
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6C2120C
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private sealed class <WaitForDLCActived>d__137
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0xC
	public object OnInit; // 0x10
	public object <>4__this; // 0x18
	private object <>8__1; // 0x20
	public object shouldWaitForDLCActive; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Single>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6C21274
	public object .ctor(object <>1__state) { }

	// RVA: 0x6C212A0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6C212A4
	private object MoveNext() { }

	// RVA: 0x6C21568
	private object System.Collections.Generic.IEnumerator<System.Single>.get_Current() { }

	// RVA: 0x6C21570
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6C215B0
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: ResCore.DLC
public class DLCDownloaderMgrImp
{

	// Fields
	private object _downloadLimits; // 0x8
	private object _pufferProductId; // 0x10
	private object _pufferServerUrl; // 0x18
	private object _pufferIsAuditVersion; // 0x20
	private object _random; // 0x28
	private static object DownloadStateProcessedFinished; // 0x0
	private object _delegates; // 0x30
	private object OnDLCDownloadedNextChange; // 0x38
	private object _dlcConfigMgr; // 0x40
	private object _downloadedDLCIDS; // 0x48
	public static object s_dlcCRCFileName; // 0x8
	private object m_dlcCRCFilePath; // 0x50
	private object m_dlcCRCTmpFilePath; // 0x58
	public object optimizeRecordResCrc; // 0x60
	private object _downloadedFiles; // 0x68
	private object _delayCRCCheckPath; // 0x70
	private object m_hadDelayCRCCheckPath; // 0x78
	private object _dLCDownloaderQueue; // 0x80
	private object _currentDownloadingItem; // 0x88
	private object _DLCdownloadSession; // 0x90
	private object _DLCDownloaderCreater; // 0x98
	private object _DLCDownloadedCustomerFilter; // 0xA0
	private object _isBackGround; // 0xA8
	private object _bgDLCDownloaderDelegate; // 0xB0
	public object UpdateDLCIds; // 0xB8
	public object CurrentDownloadedDLCIds; // 0xC0
	public object UninstallReinstall; // 0xC8
	private object _isPausing; // 0xC9
	private object _preProcessDLCIDs; // 0xD0
	private object _processedItems; // 0xD8
	private object _preProcessIter; // 0xE0
	private object _downloadedSize; // 0xE8
	private const object Seperator;
	public object CurrentDLCFilesName; // 0xF0
	public object LastDLCFilesName; // 0xF8
	public object ResVersion; // 0x100
	public object CurrentResVersion; // 0x108
	public object LastResVersion; // 0x110

	// Properties
	public object BuildType { get; }
	public static object instance { get; }
	public object ServerVersion { get; }
	public object LocalVersion { get; }
	public object AllDLCIDs { get; }
	public object CurrentDownloadingID { get; }
	public object DownloadingCount { get; }
	public object DownloadSpeed { get; }
	public object DownloadedCount { get; }
	public object TotalSize { get; }
	public object DownloadedSize { get; }

	// Methods

	// RVA: 0x6C131EC
	public static object add_DownloadStateProcessedFinished(object value) { }

	// RVA: 0x6C132D8
	public static object remove_DownloadStateProcessedFinished(object value) { }

	// RVA: 0x6C133C4
	public object add_OnDLCDownloadedNextChange(object value) { }

	// RVA: 0x6C13468
	public object remove_OnDLCDownloadedNextChange(object value) { }

	// RVA: 0x6C1350C
	public object get_BuildType() { }

	// RVA: 0x6C1286C
	public static object get_instance() { }

	// RVA: 0x6C0B4D8
	public static object GetInstance() { }

	// RVA: 0x6C13584
	public object get_ServerVersion() { }

	// RVA: 0x6C13624
	public object get_LocalVersion() { }

	// RVA: 0x6C136C4
	public object get_AllDLCIDs() { }

	// RVA: 0x6C13738
	public object IsVersionUnMatched() { }

	// RVA: 0x6C13988
	private object UpdatePreProcessDownloadState() { }

	// RVA: 0x6C13DC0
	public object IsPrePocessFinished() { }

	// RVA: 0x6C13EE0
	private object InitPreProcessDLCDownloadState() { }

	// RVA: 0x6C13FB4
	public object AddDLCConfig(object cfg) { }

	// RVA: 0x6C14034
	public object GetDLCConfig(object id) { }

	// RVA: 0x6C140B4
	public object IsDLCDownloaded(object id, object defaultValue) { }

	// RVA: 0x6C14268
	public object IsDLCHasDownloaded(object id) { }

	// RVA: 0x6C1432C
	public object IsDLCSHasDownloaded(object ids) { }

	// RVA: 0x6C14438
	public object IsDLCItemDownload(object item) { }

	// RVA: 0x6C0B5B0
	public object GetDLCItem(object path) { }

	// RVA: 0x6C145A0
	public object get_CurrentDownloadingID() { }

	// RVA: 0x6C146CC
	public object get_DownloadingCount() { }

	// RVA: 0x6C14760
	public object IsAllDLCDownloaded(object filter) { }

	// RVA: 0x6C14AB0
	public object GetDLCDownloadPercentage(object id) { }

	// RVA: 0x6C15040
	public object IsValidDLC(object id) { }

	// RVA: 0x6C150C0
	private object GetDLCItem(object dlcID, object resPath) { }

	// RVA: 0x6C1528C
	public object GetDownloadState(object id) { }

	// RVA: 0x6C15410
	public object get_DownloadSpeed() { }

	// RVA: 0x6C15488
	public object GetDLCSize(object id) { }

	// RVA: 0x6C15624
	public object GetDLCTotalSizeByIDs(object ids) { }

	// RVA: 0x6C15AA8
	public object GetDLCDownloadedSize(object id, object onlyDeletable) { }

	// RVA: 0x6C15DDC
	public object GetDLCDownloadedSizeByIDs(object ids, object onlyDeletable, object canDelet, object showLog) { }

	// RVA: 0x6C164C0
	public object GetFileSizeByResPath(object resPath) { }

	// RVA: 0x6C16550
	public object DeletAllDownloadedFiles() { }

	// RVA: 0x6C1675C
	private object CreateDownloader(object id) { }

	// RVA: 0x6C168F0
	public object Pause(object pause) { }

	// RVA: 0x6C16BA8
	public object get_DownloadedCount() { }

	// RVA: 0x6C16C40
	public object get_TotalSize() { }

	// RVA: 0x6C16CB4
	public object get_DownloadedSize() { }

	// RVA: 0x6C14E98
	public object GetDLCItemSize(object dlcItem, object usePufferSize) { }

	// RVA: 0x6C16D14
	public object IsPausing() { }

	// RVA: 0x6C16D8C
	public object Update(object isBackGround) { }

	// RVA: 0x6C17344
	public object GetDLCDownloadingPriority(object id) { }

	// RVA: 0x6C17434
	public object SetAsNextDownloading(object id) { }

	// RVA: 0x6C17A20
	public object IncreasePriority(object id, object increase) { }

	// RVA: 0x6C17C80
	public object CancelDLCDownloading(object id) { }

	// RVA: 0x6C185C0
	public object CancelAllDownloadQueue(object filter) { }

	// RVA: 0x6C18B30
	public object CancelAllDLCQueue(object cancleAllIDs) { }

	// RVA: 0x6C128D0
	internal object CheckFileCRC(object fileFullPath, object dlcItemCrc, object saveToTmpCrcFile, object isByPredlc) { }

	// RVA: 0x6C19614
	public object AddDelegate(object dLCDownloaderDelegate) { }

	// RVA: 0x6C19694
	public object RemoveDelegate(object dLCDownloaderDelegate) { }

	// RVA: 0x6C19714
	public object SetBackGroundDownloadDeletate(object bgDelegate) { }

	// RVA: 0x6C1977C
	private object RemoveDownloadingByID(object id) { }

	// RVA: 0x6C198BC
	public object DownloadDLCs(object ids) { }

	// RVA: 0x6C19A14
	public object DownLoadDLCTop(object id) { }

	// RVA: 0x6C19D4C
	public object InsertMid(object cnt, object id) { }

	// RVA: 0x6C19F20
	public object InsertMid(object cnt, object ids) { }

	// RVA: 0x6C1A024
	public object TryAddToQueue(object id) { }

	// RVA: 0x6C1A2A4
	public object ReplaceDownloadQueue(object newQueue) { }

	// RVA: 0x6C176E4
	public object DownLoadDLC(object id, object insertToHead) { }

	// RVA: 0x6C1A370
	public object PreDownloadDlc(object id) { }

	// RVA: 0x6C1A644
	public object MoveDLCIdsToHead(object checkIds, object list) { }

	// RVA: 0x6C1A6FC
	private object MoveDLCIdsInQueue(object downloadQueue, object checkIds, object list, object moveIndex) { }

	// RVA: 0x6C17524
	private object ChangeDLCIdSiteInDownloaderQueue(object downloadQueue, object id, object changeIndex) { }

	// RVA: 0x6C1AFA0
	public object InsertDLCIdsThatAreNotInQueueInToHeader(object list) { }

	// RVA: 0x6C1B094
	public object HasAnyDownloading() { }

	// RVA: 0x6C1B130
	public object GetAllDownloadingDLCs() { }

	// RVA: 0x6C1B190
	public object ClearAllDownloading() { }

	// RVA: 0x6C0FB38
	public object ClearDownloadedDLCByID(object id) { }

	// RVA: 0x6C1B5B8
	public object PreCheckDLCItem(object maxStep) { }

	// RVA: 0x6C1B684
	private object IsDLCItemNeedDownload(object item, object savedCRC) { }

	// RVA: 0x6C1B7E4
	private object UpdateItemDownloadState(object item) { }

	// RVA: 0x6C1BB90
	private object UpdateDLCDownloadState(object dlc) { }

	// RVA: 0x6C1BE80
	private object ReadHashAndCRC() { }

	// RVA: 0x6C1C3E0
	private object ReadHashAndCRCFromTmpFile(object renameTmpFile) { }

	// RVA: 0x6C18D8C
	private object SaveHashAndCRC() { }

	// RVA: 0x6C19260
	private object AppendDLCHashAndCRCToTmpFile(object hash, object crc) { }

	// RVA: 0x6C1C93C
	public object IsSameDLCVersion() { }

	// RVA: 0x6C1C9A0
	public object GetDLCVersion() { }

	// RVA: 0x6C1D198
	public object IsPufferReady() { }

	// RVA: 0x6C1D228
	public object ReadUpdateIds(object pufferVersion) { }

	// RVA: 0x6C1E714
	public object WriteUpdateIds(object fileName) { }

	// RVA: 0x6C1B244
	public object UpdateUpdateIds(object id, object delete) { }

	// RVA: 0x6C1ECB4
	public object UpdateCRCAndSave() { }

	// RVA: 0x6C13B10
	private object UpdateDLCDownloadState(object id) { }

	// RVA: 0x6C1EF48
	public object InitEnv(object pufferProductId, object pufferURL, object isAuditVersion, object limits, object creater, object filter, object downloadedFilter, object resVersion) { }

	// RVA: 0x6C1F6BC
	public object WaitForDLCActived(object OnInit, object shouldWaitForDLCActive) { }

	// RVA: 0x6C1F790
	public object ActiveDownload(object OnInit) { }

	// RVA: 0x6C1FA8C
	public object IsActive() { }

	// RVA: 0x6C1662C
	public object DeactiveDownload() { }

	// RVA: 0x6C1FAF4
	private object _OnPufferInit(object isSuccess, object errorCode) { }

	// RVA: 0x6C1FC4C
	public object SetDLMaxSpeed(object maxSpeed) { }

	// RVA: 0x6C1FCCC
	public object SetDLMaxTask(object maxTask) { }

	// RVA: 0x6C1FD4C
	public object OnDLCDownloadStart(object id) { }

	// RVA: 0x6C1FEA4
	public object OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0x6C17F04
	public object OnDownloadError(object id, object error) { }

	// RVA: 0x6C20030
	public object OnFileDownloadFinished(object id, object filepath, object dlcItemFinished) { }

	// RVA: 0x6C1890C
	public object OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0x6C183C4
	public object OnDownloadCanceled(object id) { }

	// RVA: 0x6C16F80
	private object ProcessNextDownload() { }

	// RVA: 0x6C12D50
	public object OnDLCDownloadFinished(object id) { }

	// RVA: 0x6C16A50
	public object OnDownloadPause(object pause) { }

	// RVA: 0x6C2060C
	public object .ctor() { }

	// RVA: 0x6C207C0
	private static object .cctor() { }

	// RVA: 0x6C2082C
	private object <IsDLCSHasDownloaded>b__55_0(object id) { }

}

// Namespace: ResCore.DLC
public interface IDLCDownloader
{

	// Properties
	public abstract object ID { get; }
	public abstract object Percent { get; }
	public abstract object ProgressSize { get; }

	// Methods

	// RVA: -1
	public abstract object get_ID() { }

	// RVA: -1
	public abstract object get_Percent() { }

	// RVA: -1
	public abstract object get_ProgressSize() { }

	// RVA: -1
	public abstract object NotifyStop() { }

}

// Namespace: 
public sealed class CreaterDelegate
{

	// Methods

	// RVA: 0x6C231F0
	public object .ctor(object object, object method) { }

	// RVA: 0x6C23288
	public virtual object Invoke(object id) { }

}

// Namespace: ResCore.DLC
public class DLCDownloader
{

	// Fields
	private object _downloadingItem; // 0x8
	private object _allItemsToDownload; // 0x10
	public object _callbacks; // 0x18
	private object _totalSizeToDownload; // 0x20
	private object _progressSize; // 0x28
	private object _isDLCItemDownload; // 0x30
	private object <ID>k__BackingField; // 0x38

	// Properties
	public object ProgressSize { get; }
	public object Percent { get; }
	public object ID { get; set; }

	// Methods

	// RVA: 0x6C21618
	public object get_ProgressSize() { }

	// RVA: 0x6C21720
	public object get_Percent() { }

	// RVA: 0x6C218EC
	public object get_ID() { }

	// RVA: 0x6C218F4
	public object set_ID(object value) { }

	// RVA: 0x6C218FC
	public object .ctor(object id, object items, object isDLCItemDownloadFunc, object callbacks) { }

	// RVA: 0x6C219AC
	public object OnSetupTasks(object puffer) { }

	// RVA: 0x6C224E8
	public object OnTaskFinish(object task) { }

	// RVA: 0x6C227B8
	public object OnTaskProgress(object task, object nowSize, object totalSize) { }

	// RVA: 0x6C22AE0
	public object OnTaskStop(object task, object isForce) { }

	// RVA: 0x6C22CC0
	public object NotifyStop() { }

	// RVA: 0x6C22EE8
	public object OnError(object task, object errInfo) { }

}

// Namespace: ResCore.DLC
public interface DLCDownloaderDelegate
{

	// Methods

	// RVA: -1
	public abstract object OnDownloadCanceled(object id) { }

	// RVA: -1
	public abstract object OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: -1
	public abstract object OnDownloadError(object id, object error) { }

	// RVA: -1
	public abstract object OnFileDownloadFinished(object id, object filepath, object dlcItemFinished) { }

	// RVA: -1
	public abstract object OnDLCDownloadFinished(object id) { }

	// RVA: -1
	public abstract object OnDLCDownloadStart(object id) { }

	// RVA: -1
	public abstract object OnDownlodingCountChanged(object currentCount) { }

	// RVA: -1
	public abstract object OnDownloadPause(object pause) { }

}

// Namespace: ResCore.DLC
internal class DLCDownloaderDelegateList
{

	// Fields
	private object _delegates; // 0x8

	// Methods

	// RVA: 0x6C2329C
	public object .ctor() { }

	// RVA: 0x6C23320
	public object AddDelegate(object d) { }

	// RVA: 0x6C23488
	public object RemoveDelegate(object d) { }

	// RVA: 0x6C23538
	public object OnDLCDownloadFinished(object id) { }

	// RVA: 0x6C2378C
	public object OnDownloadError(object id, object error) { }

	// RVA: 0x6C23A0C
	public object OnDownloadProgress(object id, object downloadedSize, object totalSize) { }

	// RVA: 0x6C23CB4
	public object OnDownlodingCountChanged(object currentCount) { }

	// RVA: 0x6C23E50
	public object OnDownloadCanceled(object id) { }

	// RVA: 0x6C23FE8
	public object OnFileDownloadFinished(object id, object filepath, object dlcItemFinished) { }

	// RVA: 0x6C24290
	public object OnDLCDownloadStart(object id) { }

	// RVA: 0x6C2442C
	public object OnDownloadPause(object pause) { }

}

// Namespace: ResCore.DLC
public interface DLCDownloadRequest
{

	// Methods

	// RVA: -1
	public abstract object OnSetupTasks(object session) { }

	// RVA: -1
	public abstract object OnTaskProgress(object task, object nowSize, object totalSize) { }

	// RVA: -1
	public abstract object OnTaskFinish(object task) { }

	// RVA: -1
	public abstract object OnError(object task, object errInfo) { }

	// RVA: -1
	public abstract object OnTaskStop(object task, object isForce) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__1_0; // 0x8

	// Methods

	// RVA: 0x6C25038
	private static object .cctor() { }

	// RVA: 0x6C25098
	public object .ctor() { }

	// RVA: 0x6C250A0
	internal object <.ctor>b__1_0(object err, object v, object s) { }

}

// Namespace: ResCore.DLC
internal class VersionDownloadReq
{

	// Fields
	private object _InitCB; // 0x8

	// Methods

	// RVA: 0x6C24680
	public object .ctor(object cb) { }

	// RVA: 0x6C247B4
	private object tryGetVersion() { }

	// RVA: 0x6C24B84
	public object OnError(object task, object errInfo) { }

	// RVA: 0x6C24C20
	public object OnSetupTasks(object puffer) { }

	// RVA: 0x6C24CFC
	public object OnTaskFinish(object task) { }

	// RVA: 0x6C24E28
	public object OnTaskProgress(object task, object nowSize, object totalSize) { }

	// RVA: 0x6C24EA4
	public object OnTaskStop(object task, object isForce) { }

}

// Namespace: 
public sealed class OnInitCB
{

	// Methods

	// RVA: 0x6C2A7C8
	public object .ctor(object object, object method) { }

	// RVA: 0x6C2A860
	public virtual object Invoke(object isSuccess, object errorCode) { }

}

// Namespace: 
public sealed class OnInitProgressDelegate
{

	// Methods

	// RVA: 0x6C2A90C
	public object .ctor(object object, object method) { }

	// RVA: 0x6C2A9A4
	public virtual object Invoke(object stage, object nowSize, object totalSize) { }

}

// Namespace: 
private sealed class CallTaskFuncDel
{

	// Methods

	// RVA: 0x6C27664
	public object .ctor(object object, object method) { }

	// RVA: 0x6C2AC90
	public virtual object Invoke(object task) { }

}

// Namespace: 
private enum PufferStatus
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object eS_UnStart;
	public const object eS_Downloading;
	public const object eS_Finish;
}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__48_0; // 0x8
	public static object <>9__48_1; // 0x10

	// Methods

	// RVA: 0x6C2ACA4
	private static object .cctor() { }

	// RVA: 0x6C2AD04
	public object .ctor() { }

	// RVA: 0x6C2AD0C
	internal object <_TriggerStorageLimitErrorForAllTask>b__48_0(object task) { }

	// RVA: 0x6C2AD30
	internal object <_TriggerStorageLimitErrorForAllTask>b__48_1(object task) { }

}

// Namespace: 
private sealed class <RequestVersionFileInNextFrame>d__23
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6C26778
	public object .ctor(object <>1__state) { }

	// RVA: 0x6C2ADC0
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6C2ADC4
	private object MoveNext() { }

	// RVA: 0x6C2AE38
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6C2AE40
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6C2AE80
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: ResCore.DLC
public class DLCFileDownloadSession
{

	// Fields
	private object _imp; // 0x8
	private object _cb; // 0x10
	private object _isVersionRequested; // 0x18
	public object ServerVersion; // 0x20
	public object _IsValid; // 0x28
	private object _InitCB; // 0x30
	public object InitProgress; // 0x38
	public object _MaxDownloadTasks; // 0x3C
	public object Speed; // 0x40
	private object _BeginTime; // 0x48
	private object _PendingTaskToRmv; // 0x50
	public object OnInitProgressCB; // 0x58
	private object _DownloadCounter; // 0x60
	private object _DownloadSize; // 0x68
	private object _CurrentDownloading; // 0x70
	private object _PendingQueueTasks; // 0x78
	private object _Status; // 0x80

	// Properties
	public object IsVersionRequested { get; }
	public object IsInited { get; }
	public object MaxDownloadTasks { get; }

	// Methods

	// RVA: 0x6C251E8
	public object .ctor(object cb, object imp) { }

	// RVA: 0x6C25338
	public object get_IsVersionRequested() { }

	// RVA: 0x6C25440
	public object get_IsInited() { }

	// RVA: 0x6C2549C
	public object get_MaxDownloadTasks() { }

	// RVA: 0x6C255A4
	public object UnInit() { }

	// RVA: 0x6C25734
	public object IsFileReady(object filepath) { }

	// RVA: 0x6C220D0
	public object GetCompressFileSize(object filePath) { }

	// RVA: 0x6C259E0
	public object IsFileExistInServer(object filepath) { }

	// RVA: 0x6C25AFC
	public object MoveAllDownloadingTasksToPending() { }

	// RVA: 0x6C25EEC
	public object Init(object initCB, object limits, object productId, object serverUrl, object isAuditVersion) { }

	// RVA: 0x6C26198
	private object RequestVersionFile() { }

	// RVA: 0x6C265FC
	private object RequestVersionFileInNextFrame() { }

	// RVA: 0x6C267A4
	private object OnVersionGet(object errorInfo, object v, object isStoped) { }

	// RVA: 0x6C26C38
	public object OnInitReturn(object isSuccess, object errorCode) { }

	// RVA: 0x6C2700C
	private object _ResetSpeedCache() { }

	// RVA: 0x6C27134
	private object _CalSpeed() { }

	// RVA: 0x6C27340
	public object Start() { }

	// RVA: 0x6C273C4
	public object Stop() { }

	// RVA: 0x6C274B0
	public object ForceStopAllTasks() { }

	// RVA: 0x6C27A04
	public object Update() { }

	// RVA: 0x6C28288
	private object _CheckAndWriteCacheFile() { }

	// RVA: 0x6C27BF4
	private object _Schedule() { }

	// RVA: 0x6C283EC
	private object _DownloadFile(object task) { }

	// RVA: 0x6C288B4
	public object OnInitProgress(object stage, object nowSize, object totalSize) { }

	// RVA: 0x6C28B40
	public static object IsExtraStorageLimited() { }

	// RVA: 0x6C27780
	private object _CallOnAllTask(object del) { }

	// RVA: 0x6C28CD8
	private object _TriggerStorageLimitErrorForAllTask() { }

	// RVA: 0x6C25D7C
	private object _PushPendingTask(object task) { }

	// RVA: 0x6C28FA4
	public object OnDownloadReturn(object taskId, object fileid, object isSuccess, object errorCode) { }

	// RVA: 0x6C29938
	public object OnDownloadProgress(object taskId, object nowSize, object totalSize) { }

	// RVA: 0x6C26364
	public object StartDownloadReq(object req) { }

	// RVA: 0x6C221EC
	public object GetOrCreateTask(object filepath) { }

	// RVA: 0x6C29E28
	private object _GetTask(object filepath) { }

	// RVA: 0x6C2A094
	public object SetDLMaxSpeed(object maxSpeed) { }

	// RVA: 0x6C2A278
	public object SetDLMaxTask(object maxTask) { }

	// RVA: 0x6C2A45C
	private object <ForceStopAllTasks>b__32_0(object task) { }

}

// Namespace: 
public enum ErrorType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object eErrT_None;
	public const object eErrT_FileNotExistInExtra;
	public const object eErrT_CreateDownloadFail;
	public const object eErrT_StorageLimit;
	public const object eErrT_PufferInternalError;
	public const object eRrrT_Size;
	public const object eRrrT_ExceedMaxDLCNum;
	public const object eRrrT_FileCorrepted;
	public const object eErrT_PreDLCInternalError;
	public const object eErrT_Cnt;
}

// Namespace: ResCore.DLC
public class DLCErrorInfo
{

	// Fields
	public object ErrType; // 0x8
	public object PufferErrCode; // 0xC
	public object msg; // 0x10

	// Methods

	// RVA: 0x6C224E0
	public object .ctor() { }

}

// Namespace: 
public enum Status
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object eS_None;
	public const object eS_Waiting;
	public const object eS_Downloading;
	public const object eS_Done;
	public const object es_Error;
	public const object es_FileNotExist;
	public const object es_Cnt;
}

// Namespace: ResCore.DLC
public class DLCFileDownloadTask
{

	// Fields
	private object <FileFullPath>k__BackingField; // 0x8
	private object <CurStatus>k__BackingField; // 0x10
	public object TaskID; // 0x18
	private object _Reqs; // 0x20
	private object <NowSize>k__BackingField; // 0x28
	private object <TotalSize>k__BackingField; // 0x30

	// Properties
	public object FileFullPath { get; set; }
	public object CurStatus { get; set; }
	public object NowSize { get; set; }
	public object TotalSize { get; set; }

	// Methods

	// RVA: 0x6C2AE88
	public object get_FileFullPath() { }

	// RVA: 0x6C2AE90
	public object set_FileFullPath(object value) { }

	// RVA: 0x6C2AE98
	public object get_CurStatus() { }

	// RVA: 0x6C2AEA0
	public object set_CurStatus(object value) { }

	// RVA: 0x6C2AEA8
	public object get_NowSize() { }

	// RVA: 0x6C2AEB0
	public object set_NowSize(object value) { }

	// RVA: 0x6C2AEB8
	public object get_TotalSize() { }

	// RVA: 0x6C2AEC0
	public object set_TotalSize(object value) { }

	// RVA: 0x6C29B78
	public object OnProgress(object nowSize, object totalSize) { }

	// RVA: 0x6C28634
	public object OnError(object errInfo) { }

	// RVA: 0x6C2963C
	public object OnFinish() { }

	// RVA: 0x6C2A55C
	public object OnStop(object isForce) { }

	// RVA: 0x6C22340
	public object AddReq(object req) { }

	// RVA: 0x6C29FF8
	public object .ctor(object filePath) { }

}

// Namespace: ResCore.DLC
public class DownloadLimits
{

	// Fields
	public object MaxThreadCnt; // 0x8
	public object MaxLinkCnt; // 0xC
	public object MaxSpeed; // 0x10
	public object ExtraDownloadInSingleGame; // 0x14

	// Methods

	// RVA: 0x6C2AF94
	public object .ctor() { }

}

// Namespace: ResCore.DLC
public enum InitStage
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object DownResSnapshot;
	public const object UpdateFileList;
	public const object GetResURL;
}

// Namespace: ResCore.DLC
public interface IPufferCallBackProxy
{

	// Methods

	// RVA: -1
	public abstract object OnInitReturn(object isSuccess, object errorCode) { }

	// RVA: -1
	public abstract object OnInitProgress(object stage, object nowSize, object totalSize) { }

	// RVA: -1
	public abstract object OnDownloadReturn(object taskId, object fileid, object isSuccess, object errorCode) { }

	// RVA: -1
	public abstract object OnDownloadProgress(object taskId, object nowSize, object totalSize) { }

}

// Namespace: ResCore.DLC
public interface IPufferProxy
{

	// Methods

	// RVA: -1
	public abstract object Init(object pufferCallback, object limits, object productId, object serverUrl, object isAuditVersion) { }

	// RVA: -1
	public abstract object UnInit() { }

	// RVA: -1
	public abstract object Update() { }

	// RVA: -1
	public abstract object DownloadFile(object filepath, object forceDownload, object priority) { }

	// RVA: -1
	public abstract object RemoveTask(object taskID) { }

	// RVA: -1
	public abstract object IsFileReady(object filepath) { }

	// RVA: -1
	public abstract object IsFileExistInServer(object filepath) { }

	// RVA: -1
	public abstract object GetCompressFileSize(object filePath) { }

	// RVA: -1
	public abstract object SetDLMaxSpeed(object maxSpeed) { }

	// RVA: -1
	public abstract object SetDLMaxTask(object maxTask) { }

}

// Namespace: ResCore.DLC
public class DLCItem
{

	// Fields
	public object ResPath; // 0x8
	public object CRC; // 0x10
	public object Size; // 0x18
	internal object deletable; // 0x20

	// Methods

	// RVA: 0x6C2AFB8
	public object .ctor() { }

}

// Namespace: ResCore.DLC
public class SDLCConfig
{

	// Fields
	public object ID; // 0x8
	public object ResList; // 0x10

	// Methods

	// RVA: 0x6C2AFC8
	public object .ctor() { }

}

// Namespace: ResCore.DLC
public abstract class DLCConfig
{

	// Properties
	public abstract object ID { get; }
	public abstract object ResList { get; }

	// Methods

	// RVA: -1
	public abstract object get_ID() { }

	// RVA: -1
	public abstract object get_ResList() { }

	// RVA: 0x6C2AFD0
	public object .ctor() { }

}

// Namespace: ResCore.DLC
public class GenericDLCConfig
{

	// Fields
	private object _id; // 0x8
	private object _items; // 0x10

	// Properties
	public override object ID { get; }
	public override object ResList { get; }

	// Methods

	// RVA: 0x6C2AFD8
	public object .ctor(object id, object items) { }

	// RVA: 0x6C2B014
	public override object get_ID() { }

	// RVA: 0x6C2B11C
	public override object get_ResList() { }

}

// Namespace: 
private sealed class <GetDLCItems>d__26
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18
	private object <iter>5__2; // 0x20

	// Properties
	private object System.Collections.Generic.IEnumerator<ResCore.DLC.DLCItem>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x6C2B8A8
	public object .ctor(object <>1__state) { }

	// RVA: 0x6C2D278
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6C2D27C
	private object MoveNext() { }

	// RVA: 0x6C2D3A8
	private object System.Collections.Generic.IEnumerator<ResCore.DLC.DLCItem>.get_Current() { }

	// RVA: 0x6C2D3B0
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6C2D3F0
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: ResCore.DLC
public class DLCConfigMgr
{

	// Fields
	public static readonly object s_DLCConfigRoot; // 0x0
	public static readonly object s_ConfigIdexFileName; // 0x8
	public static readonly object s_ConfigAssetBundlePath; // 0x10
	public static readonly object s_DLCVersionFileName; // 0x18
	public static readonly object s_DLCVersionAssetBundlePath; // 0x20
	public static readonly object s_PreDLCConfigRoot; // 0x28
	public static readonly object s_PreDLCConfigIndexFileName; // 0x30
	public static readonly object s_PreDLCConfigAssetBundlePath; // 0x38
	public static readonly object s_PreDLCVersionFileName; // 0x40
	public static readonly object s_PreDLCVersionAssetBundlePath; // 0x48
	public object Version; // 0x8
	public object LocalRevsion; // 0x10
	public object BuildType; // 0x18
	private object _pufferSizes; // 0x20
	private object _pathToItems; // 0x28
	private object _idToConfig; // 0x30
	private object _allDLCIDs; // 0x38
	private object _allPreDLCIDs; // 0x40
	private object _TotalSize; // 0x48

	// Properties
	public object TotalDLCSize { get; }
	public object PufferSizes { get; }
	public object AllDLCIDs { get; }

	// Methods

	// RVA: 0x6C2B254
	public object get_TotalDLCSize() { }

	// RVA: 0x6C2B2B0
	public object .ctor() { }

	// RVA: 0x6C2B498
	public object GetDLCItem(object path) { }

	// RVA: 0x6C2B654
	public object IsValidDLC(object id) { }

	// RVA: 0x6C2108C
	public object GetDLCItemCount() { }

	// RVA: 0x6C21124
	public object GetDLCItems() { }

	// RVA: 0x6C2B8D4
	public object GetDLCConfig(object id) { }

	// RVA: 0x6C2BAC0
	public object get_PufferSizes() { }

	// RVA: 0x6C2150C
	public object get_AllDLCIDs() { }

	// RVA: 0x6C2BCD4
	public object ReleaseDLC(object id) { }

	// RVA: 0x6C2BD34
	public object AddDLCConfig(object cfg) { }

	// RVA: 0x6C2C094
	public object InitFromFile(object onlyLoadHead, object filter) { }

	// RVA: 0x6C2D094
	private static object .cctor() { }

}

// Namespace: ResCore.DLC
public enum DLCBuildType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Full;
	public const object OnlyLobbyShow;
	public const object Performance;
	public const object AutoPerformance;
	public const object Competition;
	public const object FullHero;
}

// Namespace: ResCore.DLC
public class DLCIndex
{

	// Fields
	public object SAllDLCItems; // 0x10
	public object SAllDLCConfigs; // 0x18
	private object _configs; // 0x20
	public object BuildRevision; // 0x28
	public object AppVersion; // 0x30
	public object BuildType; // 0x38
	public object ExcuteInEditor; // 0x3C

	// Properties
	public object AllDLCConfigs { get; }

	// Methods

	// RVA: 0x6C2CB64
	public object Init() { }

	// RVA: 0x6C2D038
	public object get_AllDLCConfigs() { }

	// RVA: 0x6C2D4D4
	private object .ctor() { }

}

// Namespace: ResCore.DLC
public abstract class ResUpdateStage
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=16
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=2048
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 596B8EE87E91B2A27F90AE294A02A3642C8F1EC7FEF822A929FCFF2B23A27452; // 0x0
	internal static readonly object 68576F4AA917C7ABD140C9A7AFE26EB9A2B72691E1FBA3DEDB5F63F7B5E3726A; // 0x4
	internal static readonly object 6E98C290DBF21872023CE58A0E75E40EA524D2D78568E8532171B14571299CBE; // 0x14
	internal static readonly object 7B7944F80F5ADE5FDF54FA590297B43F9CED21DA848E06C3BD539888340224FC; // 0x18
	internal static readonly object 9510833BE85D6E7BDB0A990BB21B3E1C205A015F87BC5382489CDAF427C2AA8B; // 0x1C
	internal static readonly object C0661A1999F50F4F95ED62AEE6EB8D11662C894C53268B36051D49F31E5FF3BC; // 0x81C
}

// Namespace: IFix
public class ILFixDynamicMethodWrapper
{

	// Fields
	private object virtualMachine; // 0x8
	private object methodId; // 0x10
	private object anonObj; // 0x18
	public static object wrapperArray; // 0x0

	// Methods

	// RVA: 0x6C2D5A4
	public object .ctor(object virtualMachine, object methodId, object anonObj) { }

	// RVA: 0x6C22E4C
	public object __Gen_Wrap_0(object P0) { }

	// RVA: 0x6C2D5E8
	public object __Gen_Wrap_1() { }

	// RVA: 0x6C2D6B0
	public object __Gen_Wrap_2() { }

	// RVA: 0x6C22018
	public object __Gen_Wrap_3(object P0, object P1) { }

	// RVA: 0x6C236D4
	public object __Gen_Wrap_4(object P0, object P1) { }

	// RVA: 0x6C2D740
	public object __Gen_Wrap_5(object P0, object P1) { }

	// RVA: 0x6C2D7F8
	public object __Gen_Wrap_6(object P0, object P1) { }

	// RVA: 0x6C24AA8
	public object __Gen_Wrap_7(object P0) { }

	// RVA: 0x6C2D8B0
	public object __Gen_Wrap_8(object P0, object P1, object P2) { }

	// RVA: 0x6C2D97C
	public object __Gen_Wrap_9(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C2DA9C
	public object __Gen_Wrap_10(object P0, object P1) { }

	// RVA: 0x6C25850
	public object __Gen_Wrap_11(object P0, object P1) { }

	// RVA: 0x6C25394
	public object __Gen_Wrap_12(object P0) { }

	// RVA: 0x6C2DB64
	public object __Gen_Wrap_13(object P0, object P1, object P2) { }

	// RVA: 0x6C254F8
	public object __Gen_Wrap_14(object P0) { }

	// RVA: 0x6C2DC40
	public object __Gen_Wrap_15(object P0) { }

	// RVA: 0x6C2DD1C
	public object __Gen_Wrap_16() { }

	// RVA: 0x6C2DDE4
	public object __Gen_Wrap_17(object P0, object P1) { }

	// RVA: 0x6C2DED4
	public object __Gen_Wrap_18(object P0, object P1) { }

	// RVA: 0x6C2DFC4
	public object __Gen_Wrap_19(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C2E0BC
	public object __Gen_Wrap_20(object P0) { }

	// RVA: 0x6C2E198
	public object __Gen_Wrap_21(object P0, object P1, object P2) { }

	// RVA: 0x6C2E274
	public object __Gen_Wrap_22(object P0, object P1) { }

	// RVA: 0x6C2E32C
	public object __Gen_Wrap_23(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C2E414
	public object __Gen_Wrap_24(object P0) { }

	// RVA: 0x6C2E4C0
	public object __Gen_Wrap_25() { }

	// RVA: 0x6C2E588
	public object __Gen_Wrap_26(object P0, object P1, object P2) { }

	// RVA: 0x6C2E694
	public object __Gen_Wrap_27(object P0, object P1) { }

	// RVA: 0x6C21674
	public object __Gen_Wrap_28(object P0) { }

	// RVA: 0x6C2E784
	public object __Gen_Wrap_29(object P0, object P1) { }

	// RVA: 0x6C2E874
	public object __Gen_Wrap_30(object P0, object P1, object P2) { }

	// RVA: 0x6C2E940
	public object __Gen_Wrap_31(object P0) { }

	// RVA: 0x6C2EA1C
	public object __Gen_Wrap_32(object P0) { }

	// RVA: 0x6C2EAF8
	public object __Gen_Wrap_33(object P0) { }

	// RVA: 0x6C2EBD4
	public object __Gen_Wrap_34(object P0) { }

	// RVA: 0x6C2ECB0
	public object __Gen_Wrap_35(object P0) { }

	// RVA: 0x6C2B070
	public object __Gen_Wrap_36(object P0) { }

	// RVA: 0x6C2ED8C
	public object __Gen_Wrap_37(object P0, object P1) { }

	// RVA: 0x6C2EE44
	public object __Gen_Wrap_38(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C2EF3C
	public object __Gen_Wrap_39() { }

	// RVA: 0x6C2F004
	public object __Gen_Wrap_40(object P0, object P1) { }

	// RVA: 0x6C28C38
	public object __Gen_Wrap_41() { }

	// RVA: 0x6C2F0F8
	public object __Gen_Wrap_42(object P0, object P1) { }

	// RVA: 0x6C2309C
	public object __Gen_Wrap_43(object P0, object P1, object P2) { }

	// RVA: 0x6C2F1E8
	public object __Gen_Wrap_44(object P0, object P1) { }

	// RVA: 0x6C2F2B0
	public object __Gen_Wrap_45(object P0, object P1) { }

	// RVA: 0x6C2F378
	public object __Gen_Wrap_46(object P0) { }

	// RVA: 0x6C2F424
	public object __Gen_Wrap_47(object P0, object P1) { }

	// RVA: 0x6C2F530
	public object __Gen_Wrap_48(object P0, object P1) { }

	// RVA: 0x6C2669C
	public object __Gen_Wrap_49(object P0) { }

	// RVA: 0x6C2F620
	public object __Gen_Wrap_50(object P0, object P1) { }

	// RVA: 0x6C2F710
	public object __Gen_Wrap_51(object P0) { }

	// RVA: 0x6C2F7EC
	public object __Gen_Wrap_52(object P0) { }

	// RVA: 0x6C22BF4
	public object __Gen_Wrap_53(object P0, object P1, object P2) { }

	// RVA: 0x6C2F8C8
	public object __Gen_Wrap_54(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C2F9E8
	public object __Gen_Wrap_55(object P0, object P1) { }

	// RVA: 0x6C2FAD8
	public object __Gen_Wrap_56() { }

	// RVA: 0x6C2FBA0
	public object __Gen_Wrap_57(object P0, object P1, object P2) { }

	// RVA: 0x6C2FCAC
	public object __Gen_Wrap_58(object P0, object P1, object P2) { }

	// RVA: 0x6C2FDB8
	public object __Gen_Wrap_59(object P0, object P1, object P2) { }

	// RVA: 0x6C2FEC4
	public object __Gen_Wrap_60(object P0, object P1) { }

	// RVA: 0x6C245C8
	public object __Gen_Wrap_61(object P0, object P1) { }

	// RVA: 0x6C2FF8C
	public object __Gen_Wrap_62(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C300EC
	public object __Gen_Wrap_63(object P0, object P1, object P2) { }

	// RVA: 0x6C301F8
	public object __Gen_Wrap_64(object P0, object P1, object P2) { }

	// RVA: 0x6C30330
	public object __Gen_Wrap_65(object P0, object P1, object P2) { }

	// RVA: 0x6C30468
	public object __Gen_Wrap_66(object P0) { }

	// RVA: 0x6C30514
	public object __Gen_Wrap_67(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C305FC
	public object __Gen_Wrap_68(object P0) { }

	// RVA: 0x6C30698
	public object __Gen_Wrap_69(object P0, object P1) { }

	// RVA: 0x6C30788
	public object __Gen_Wrap_70(object P0) { }

	// RVA: 0x6C30864
	public object __Gen_Wrap_71(object P0, object P1) { }

	// RVA: 0x6C3091C
	public object __Gen_Wrap_72(object P0) { }

	// RVA: 0x6C309F8
	public object __Gen_Wrap_73(object P0) { }

	// RVA: 0x6C30AD4
	public object __Gen_Wrap_74(object P0) { }

	// RVA: 0x6C30BB0
	public object __Gen_Wrap_75(object P0, object P1) { }

	// RVA: 0x6C30CA4
	public object __Gen_Wrap_76(object P0, object P1, object P2) { }

	// RVA: 0x6C30DAC
	public object __Gen_Wrap_77(object P0) { }

	// RVA: 0x6C30E48
	public object __Gen_Wrap_78(object P0, object P1, object P2) { }

	// RVA: 0x6C30F24
	public object __Gen_Wrap_79(object P0, object P1, object P2) { }

	// RVA: 0x6C26B50
	public object __Gen_Wrap_80(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C31030
	public object __Gen_Wrap_81(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C31128
	public object __Gen_Wrap_82(object P0, object P1, object P2) { }

	// RVA: 0x6C311F4
	public object __Gen_Wrap_83(object P0) { }

	// RVA: 0x6C31290
	public object __Gen_Wrap_84(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0x6C313FC
	public object __Gen_Wrap_85(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7) { }

	// RVA: 0x6C3157C
	public object __Gen_Wrap_86(object P0, object P1, object P2) { }

	// RVA: 0x6C31648
	public object __Gen_Wrap_87(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0x6C31744
	public object __Gen_Wrap_88(object P0, object P1) { }

	// RVA: 0x6C31834
	public object __Gen_Wrap_89(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0x6C31940
	public object __Gen_Wrap_90(object P0, object P1, object P2) { }

	// RVA: 0x6C31A1C
	public object __Gen_Wrap_91(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C31B14
	public object __Gen_Wrap_92(object P0, object P1, object P2) { }

	// RVA: 0x6C31C20
	public object __Gen_Wrap_93(object P0, object P1, object P2) { }

	// RVA: 0x6C31D58
	public object __Gen_Wrap_94(object P0, object P1) { }

	// RVA: 0x6C31E94
	public object __Gen_Wrap_95(object P0, object P1) { }

	// RVA: 0x6C31F84
	public object __Gen_Wrap_96() { }

	// RVA: 0x6C3204C
	public object __Gen_Wrap_97() { }

	// RVA: 0x6C32114
	public object __Gen_Wrap_98(object P0, object P1) { }

	// RVA: 0x6C32204
	public object __Gen_Wrap_99(object P0, object P1, object P2) { }

	// RVA: 0x6C322D0
	public object __Gen_Wrap_100(object P0, object P1, object P2) { }

	// RVA: 0x6C3239C
	public object __Gen_Wrap_101(object P0, object P1) { }

	// RVA: 0x6C32454
	public object __Gen_Wrap_102(object P0, object P1, object P2) { }

	// RVA: 0x6C32530
	public object __Gen_Wrap_103(object P0, object P1, object P2) { }

	// RVA: 0x6C325FC
	public object __Gen_Wrap_104(object P0, object P1, object P2) { }

	// RVA: 0x6C32724
	public object __Gen_Wrap_105(object P0, object P1, object P2) { }

	// RVA: 0x6C32800
	public object __Gen_Wrap_106(object P0) { }

	// RVA: 0x6C328AC
	public object __Gen_Wrap_107(object P0) { }

	// RVA: 0x6C32958
	public object __Gen_Wrap_108(object P0) { }

	// RVA: 0x6C32A34
	public object __Gen_Wrap_109(object P0) { }

	// RVA: 0x6C32B10
	public object __Gen_Wrap_110(object P0) { }

	// RVA: 0x6C32BEC
	public object __Gen_Wrap_111(object P0, object P1) { }

	// RVA: 0x6C2BBF8
	public object __Gen_Wrap_112(object P0) { }

	// RVA: 0x6C2B704
	public object __Gen_Wrap_113(object P0, object P1) { }

	// RVA: 0x6C32CDC
	public object __Gen_Wrap_114(object P0, object P1) { }

	// RVA: 0x6C2D3F8
	public object __Gen_Wrap_115(object P0) { }

	// RVA: 0x6C2B9D0
	public object __Gen_Wrap_116(object P0, object P1) { }

	// RVA: 0x6C32DCC
	public object __Gen_Wrap_117() { }

	// RVA: 0x6C2B564
	public object __Gen_Wrap_118(object P0, object P1) { }

	// RVA: 0x6C32E94
	public object __Gen_Wrap_119(object P0, object P1) { }

	// RVA: 0x6C32F84
	public object __Gen_Wrap_120(object P0, object P1) { }

	// RVA: 0x6C3304C
	public object __Gen_Wrap_121(object P0, object P1) { }

	// RVA: 0x6C25918
	public object __Gen_Wrap_122(object P0, object P1) { }

	// RVA: 0x6C3313C
	public object __Gen_Wrap_123(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C21840
	public object __Gen_Wrap_124(object P0) { }

	// RVA: 0x6C3329C
	public object __Gen_Wrap_125(object P0) { }

	// RVA: 0x6C33378
	public object __Gen_Wrap_126() { }

	// RVA: 0x6C229F8
	public object __Gen_Wrap_127(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C33440
	public object __Gen_Wrap_128(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0x6C3353C
	public object __Gen_Wrap_129(object P0, object P1, object P2) { }

	// RVA: 0x6C33608
	public object __Gen_Wrap_130(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0x6C33714
	public object __Gen_Wrap_131(object P0, object P1, object P2) { }

	// RVA: 0x6C2BB1C
	public object __Gen_Wrap_132(object P0) { }

	// RVA: 0x6C337F0
	public object __Gen_Wrap_133(object P0, object P1, object P2) { }

	// RVA: 0x6C338CC
	public object __Gen_Wrap_134(object P0, object P1, object P2) { }

	// RVA: 0x6C339A8
	public object __Gen_Wrap_135(object P0, object P1) { }

	// RVA: 0x6C23940
	public object __Gen_Wrap_136(object P0, object P1, object P2) { }

	// RVA: 0x6C33A70
	public object __Gen_Wrap_137(object P0) { }

	// RVA: 0x6C33B0C
	public object __Gen_Wrap_138(object P0, object P1, object P2) { }

	// RVA: 0x6C33BD8
	public object __Gen_Wrap_139(object P0) { }

	// RVA: 0x6C33CB4
	public object __Gen_Wrap_140(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C33D9C
	public object __Gen_Wrap_141(object P0, object P1) { }

	// RVA: 0x6C33E8C
	public object __Gen_Wrap_142(object P0, object P1, object P2) { }

	// RVA: 0x6C33F68
	public object __Gen_Wrap_143(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C26F40
	public object __Gen_Wrap_144(object P0, object P1, object P2) { }

	// RVA: 0x6C34050
	public object __Gen_Wrap_145(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C34138
	public object __Gen_Wrap_146(object P0, object P1) { }

	// RVA: 0x6C29540
	public object __Gen_Wrap_147(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0x6C29A90
	public object __Gen_Wrap_148(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C34228
	public object __Gen_Wrap_149(object P0, object P1, object P2, object P3, object P4, object P5, object P6) { }

	// RVA: 0x6C34354
	public object __Gen_Wrap_150(object P0, object P1, object P2) { }

	// RVA: 0x6C34420
	public object __Gen_Wrap_151(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C34508
	public object __Gen_Wrap_152(object P0) { }

	// RVA: 0x6C345B4
	public object __Gen_Wrap_153(object P0) { }

	// RVA: 0x6C34660
	public object __Gen_Wrap_154(object P0, object P1, object P2) { }

	// RVA: 0x6C3476C
	public object __Gen_Wrap_155(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0x6C34878
	public object __Gen_Wrap_156(object P0, object P1) { }

	// RVA: 0x6C287EC
	public object __Gen_Wrap_157(object P0, object P1) { }

	// RVA: 0x6C34968
	public object __Gen_Wrap_158(object P0, object P1) { }

	// RVA: 0x6C34A30
	public object __Gen_Wrap_159(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C34B28
	public object __Gen_Wrap_160(object P0, object P1, object P2) { }

	// RVA: 0x6C34BF4
	public object __Gen_Wrap_161(object P0, object P1, object P2) { }

	// RVA: 0x6C34CD0
	public object __Gen_Wrap_162(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0x6C2B7CC
	public object __Gen_Wrap_163(object P0) { }

	// RVA: 0x6C34DCC
	public object __Gen_Wrap_164(object P0, object P1) { }

	// RVA: 0x6C34EBC
	public object __Gen_Wrap_165(object P0, object P1) { }

	// RVA: 0x6C2CA98
	public object __Gen_Wrap_166(object P0, object P1, object P2) { }

	// RVA: 0x6C34F84
	public object __Gen_Wrap_167(object P0, object P1, object P2, object P3, object P4, object P5, object P6, object P7, object P8) { }

	// RVA: 0x6C350DC
	public object __Gen_Wrap_168(object P0, object P1) { }

	// RVA: 0x6C26070
	public object __Gen_Wrap_169(object P0, object P1, object P2, object P3, object P4, object P5) { }

	// RVA: 0x6C35194
	public object __Gen_Wrap_170(object P0, object P1, object P2) { }

	// RVA: 0x6C2A1B0
	public object __Gen_Wrap_171(object P0, object P1) { }

	// RVA: 0x6C2A394
	public object __Gen_Wrap_172(object P0, object P1) { }

	// RVA: 0x6C23BCC
	public object __Gen_Wrap_173(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C241A8
	public object __Gen_Wrap_174(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C29D38
	public object __Gen_Wrap_175(object P0, object P1) { }

	// RVA: 0x6C28A58
	public object __Gen_Wrap_176(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C2AEC8
	public object __Gen_Wrap_177(object P0, object P1, object P2) { }

	// RVA: 0x6C2B178
	public object __Gen_Wrap_178(object P0) { }

	// RVA: 0x6C352A0
	public object __Gen_Wrap_179(object P0, object P1, object P2) { }

	// RVA: 0x6C353AC
	public object __Gen_Wrap_180(object P0, object P1, object P2, object P3) { }

	// RVA: 0x6C35494
	public object __Gen_Wrap_181(object P0) { }

	// RVA: 0x6C35570
	public object __Gen_Wrap_182(object P0, object P1, object P2, object P3, object P4) { }

	// RVA: 0x6C3566C
	public object __Gen_Wrap_183(object P0) { }

	// RVA: 0x6C35718
	private static object .cctor() { }

}

// Namespace: IFix
public class ILFixInterfaceBridge
{

	// Fields
	private object methodId_0; // 0x38
	private object methodId_1; // 0x3C
	private object methodId_2; // 0x40
	private object methodId_3; // 0x44
	private object methodId_4; // 0x48
	private object methodId_5; // 0x4C
	private object methodId_6; // 0x50

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Object>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }
	private object System.Collections.Generic.IEnumerator<System.Single>.Current { get; }
	private object System.Collections.Generic.IEnumerator<ResCore.DLC.DLCItem>.Current { get; }

	// Methods

	// RVA: 0x6C3578C
	private object System.IDisposable.Dispose() { }

	// RVA: 0x6C3580C
	private object MoveNext() { }

	// RVA: 0x6C3589C
	private object System.Collections.Generic.IEnumerator<System.Object>.get_Current() { }

	// RVA: 0x6C35954
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x6C359D4
	private object System.Collections.IEnumerator.get_Current() { }

	// RVA: 0x6C35A8C
	private object System.Collections.Generic.IEnumerator<System.Single>.get_Current() { }

	// RVA: 0x6C35B1C
	private object System.Collections.Generic.IEnumerator<ResCore.DLC.DLCItem>.get_Current() { }

	// RVA: 0x6C35BD4
	public object .ctor(object fieldNum, object fieldTypes, object typeIndex, object vTable, object methodIdArray, object virtualMachine) { }

	// RVA: 0x6C35C9C
	public object RefAsyncBuilderStartMethod() { }

}

// Namespace: IFix
public class WrappersManagerImpl
{

	// Fields
	private object virtualMachine; // 0x8

	// Methods

	// RVA: 0x6C35CA0
	public object .ctor(object virtualMachine) { }

	// RVA: 0x6C35CCC
	public static object GetPatch(object id) { }

	// RVA: 0x6C35D74
	public static object IsPatched(object id) { }

	// RVA: 0x6C35E6C
	public object CreateDelegate(object type, object id, object anon) { }

	// RVA: 0x6C35F40
	public object CreateWrapper(object id) { }

	// RVA: 0x6C35FB8
	public object InitWrapperArray(object len) { }

	// RVA: 0x6C36078
	public object CreateBridge(object fieldNum, object fieldTypes, object typeIndex, object vTable, object slots, object virtualMachine) { }

}

// Namespace: IFix
public enum IDMAP0
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object PreDLCTest-Start0;
	public const object PreDLCTest-Update0;
	public const object RecordAnalyseResourceTree-get_LoadingResAutoSaveRootPath0;
	public const object RecordAnalyseResourceTree-Start0;
	public const object RecordAnalyseResourceTree-End0;
	public const object RecordAnalyseResourceTree-BeginAddTreeDepth0;
	public const object RecordAnalyseResourceTree-BeginAddResTreeDepth0;
	public const object RecordAnalyseResourceTree-BeginAddResTreeDepth1;
	public const object RecordAnalyseResourceTree-BeginAddResTreeDepth2;
	public const object RecordAnalyseResourceTree-EndAddTreeDepth0;
	public const object RecordAnalyseResourceTree-EndAddResTreeDepth0;
	public const object RecordAnalyseResourceTree-AddCustomNode0;
	public const object RecordAnalyseResourceTree-AddCustomTreeResNode0;
	public const object RecordAnalyseResourceTree-PrintTxt0;
	public const object RecordAnalyseResourceTree-AddAgeInfo0;
	public const object RecordAnalyseResourceTree-AddBluePrintInfo0;
	public const object RecordAnalyseResourceTree-AnalyseResourceNode-GetTypeString0;
	public const object RecordAnalyseResourceTree-AnalyseResourceNode-GetValueString0;
	public const object RecordAnalyseResourceTree-GenerateTxtRecursive0;
	public const object RecordAnalyseResourceTree-GenerateTxt0;
	public const object RecordAnalyseResourceTree-SaveTxtToFile0;
	public const object RecordAnalyseResourceTree-ChildCopy2AllNode0;
	public const object RecordAnalyseResourceTree-ReapportionTreeNode-GetTypeString0;
	public const object RecordAnalyseResourceTree-ReapportionTreeNode-GetValueString0;
	public const object RecordAnalyseResourceTree-FindChildNode0;
	public const object RecordAnalyseResourceTree-ReapportionFatherSonNode0;
	public const object RecordAnalyseResourceTree-AnalyseResourceNodeSortFunc0;
	public const object RecordAnalyseResourceTree-Sort0;
	public const object RecordAnalyseResourceTree-PrintResInfo0;
	public const object RecordAnalyseResourceTree-PrintAgeAndBlueInfo0;
	public const object RecordAnalyseResourceTree-CustomTreeNode-GetTypeString0;
	public const object RecordAnalyseResourceTree-CustomTreeNode-GetValueString0;
	public const object RecordAnalyseResourceTree-CustomTreeResNode-GetTypeString0;
	public const object RecordAnalyseResourceTree-CustomTreeResNode-GetValueString0;
	public const object CommonLibs-FileModule-EncoderMagicConfig-BytesEqual0;
	public const object CommonLibs-FileModule-EncoderMagicConfig-BytesOneHeader0;
	public const object CommonLibs-FileModule-EncoderMagicConfig-BytesCompressHeader0;
	public const object CommonLibs-FileModule-EncoderMagicConfig-BytesEncryptHeader0;
	public const object CommonLibs-FileModule-ResDReader-GetHashCode0;
	public const object CommonLibs-FileModule-ResDReader-GetStrUpperHash0;
	public const object CommonLibs-FileModule-ResDReader-GetMixedKey0;
	public const object CommonLibs-FileModule-ResDReader-get_m_aesProvider0;
	public const object CommonLibs-FileModule-ResDReader-RestoreInputStream0;
	public const object CommonLibs-FileModule-ResDReader-TryGetBytesStream0;
	public const object CommonLibs-FileModule-ResDReader-InitDelegates0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-Close0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-Flush0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-Read0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-get_InStream0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-Seek0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-SetLength0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-Write0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-get_CanRead0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-get_CanSeek0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-get_CanWrite0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-get_Length0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-get_Position0;
	public const object CommonLibs-FileModule-ResDReader-KnowLengthBytesStream-set_Position0;
	public const object ResCore-ResCoreModule-get_instacne0;
	public const object ResCore-ResCoreModule-get_IsEditor0;
	public const object ResCore-ResCoreModule-ResourcePathToAssetPath0;
	public const object ResCore-ResCoreModule-GetEditorABRoot0;
	public const object ResCore-ResCoreModule-AssetPathToResourcePath0;
	public const object ResCore-ResCoreModule-GetExternalStorageAvailableSize0;
	public const object ResCore-ResCoreModule-IsExtraStorageLimited0;
	public const object ResCore-ResCoreModule-GetDLCRoot0;
	public const object ResCore-ResCoreModule-GetUpdateRoot0;
	public const object ResCore-ResCoreModule-GetPuertsAudioRoot0;
	public const object ResCore-ResCoreModule-StartCoroutine0;
	public const object ResCore-ResCoreModule-OnResourceVersionChanged0;
	public const object ResCore-ResCoreModule-OnDLCServerVersionChanged0;
	public const object ResCore-ResCoreModule-CreatePufferProxy0;
	public const object ResCore-ResCoreModule-CreatePufferBridge0;
	public const object ResCore-ResCoreModule-IsUse7z0;
	public const object ResCore-CBinaryObject-get_m_stream0;
	public const object ResCore-CBinaryObject-get_SReader0;
	public const object ResCore-CBinaryObject-get_BReader0;
	public const object ResCore-CBinaryObject-SetFileStream0;
	public const object ResCore-CBinaryObject-Release0;
	public const object ResCore-CFileManager-IsInternalPath0;
	public const object ResCore-CFileManager-_ModifyAndroidInternalPath0;
	public const object ResCore-CFileManager-_getAndroidZipArchive0;
	public const object ResCore-CFileManager-_IsFileExist_Internal0;
	public const object ResCore-CFileManager-_IsFileExist_System0;
	public const object ResCore-CFileManager-IsFileExist0;
	public const object ResCore-CFileManager-GetFullName0;
	public const object ResCore-CFileManager-EraseExtension0;
	public const object ResCore-CFileManager-GetFileNameWithoutExtension0;
	public const object ResCore-CFileManager-CombinePath0;
	public const object ResCore-CFileManager-get_InternalRootPath0;
	public const object ResCore-CFileManager-InternalAssetPackRootPath0;
	public const object ResCore-CFileManager-IsFileExistRelPath0;
	public const object ResCore-CFileManager-GetFileSize0;
	public const object ResCore-CFileManager-IsDirectoryExist0;
	public const object ResCore-CFileManager-CreateDirectory0;
	public const object ResCore-CFileManager-CreateDirRecursive0;
	public const object ResCore-CFileManager-DeleteDirectory0;
	public const object ResCore-CFileManager-GetFileLength0;
	public const object ResCore-CStatistics-RecordResOpt0;
	public const object ResCore-CFileManager-_ReadFile0;
	public const object ResCore-CFileManager-_ReadFile_Internal0;
	public const object ResCore-CFileManager-ReadFile0;
	public const object ResCore-CFileManager-UnCheckedSafeDeleteFile0;
	public const object ResCore-CFileManager-DeleteFile0;
	public const object ResCore-CFileManager-WriteFile0;
	public const object ResCore-CFileManager-WriteFile1;
	public const object ResCore-CFileManager-WriteText0;
	public const object ResCore-CFileManager-CopyFile0;
	public const object ResCore-CFileManager-CopyOrReplaceFile0;
	public const object ResCore-CFileManager-CopyDirectory0;
	public const object ResCore-CFileManager-GetFileMd50;
	public const object ResCore-CFileManager-GetMd50;
	public const object ResCore-CFileManager-GetMd51;
	public const object ResCore-CFileManager-CombinePaths0;
	public const object ResCore-CFileManager-GetLocalPathHeader0;
	public const object ResCore-CFileManager-GetStreamingAssetsPathWithHeader0;
	public const object ResCore-CFileManager-GetCachePath0;
	public const object ResCore-CRC64-get__CrcBuffer0;
	public const object ResCore-CRC64-Compute0;
	public const object ResCore-CFileManager-CalcFileCRC0;
	public const object ResCore-CRC32-get_CrcBuffer0;
	public const object ResCore-CRC32-Compute0;
	public const object ResCore-CFileManager-CalcFileCRC320;
	public const object ResCore-CRC64-FreeCrcBuffer0;
	public const object ResCore-CFileManager-FreeCrcBuffer0;
	public const object ResCore-CFileManager-GetOpenningVideoPath0;
	public const object ResCore-CFileManager-GetCachePath1;
	public const object ResCore-CFileManager-GetCachePathWithHeader0;
	public const object ResCore-CResourceManager-get_IsSimuatorAssetBudle0;
	public const object ResCore-CResourceManager-EditorABRoot0;
	public const object ResCore-CFileManager-GetUpdateableResourceDir0;
	public const object ResCore-CFileManager-DeletPathFirstComponent0;
	public const object ResCore-CFileManager-GetPathFirstPathComponent0;
	public const object ResCore-CFileManager-DeletePathLastComponent0;
	public const object ResCore-CFileManager-GetPathLastComponent0;
	public const object ResCore-CFileManager-GetExtension0;
	public const object ResCore-CFileManager-GetFullDirectory0;
	public const object ResCore-CFileManager-ClearDirectory0;
	public const object ResCore-CFileManager-ClearDirectory1;
	public const object ResCore-CFileManager-GetExtraIFSExtractPath0;
	public const object ResCore-CFileManager-GetIFSExtractPath0;
	public const object ResCore-CFileManager-_OpenFileRead_Internal0;
	public const object ResCore-CFileManager-OpenFileRead0;
	public const object ResCore-CFileManager-Rel2FullPathInExt0;
	public const object ResCore-CFileManager-Rel2FullPathInExtraExt0;
	public const object ResCore-CFileManager-Rel2FullPathInInt0;
	public const object ResCore-CFileManager-Rel2FullPathInAssetPack0;
	public const object ResCore-CFileManager-LoadApkArchive0;
	public const object ResCore-CFileManager-Init0;
	public const object ResCore-CFileManager-get_dataPath0;
	public const object ResCore-CRC32-FreeCrcBuffer0;
	public const object ResCore-CRC64-Compute1;
	public const object ResCore-CRC64-ComputeCrcFromString0;
	public const object ResCore-CRC64-ComputeCrc0;
	public const object ResCore-CResource-get_m_data0;
	public const object ResCore-CResource-get_RefCount0;
	public const object ResCore-StringHelper-_JavaHashCode0;
	public const object ResCore-StringHelper-FileNameHashCodeIgnoreCaseEraseExt0;
	public const object ResCore-StringHelper-JavaHashCodeIgnoreCaseEraseExt0;
	public const object ResCore-CResource-GetResourceHash0;
	public const object ResCore-CResource-GetResourceKey0;
	public const object ResCore-CResource-CobineResourceHash0;
	public const object ResCore-CResource-GetLoadHashFromResourceHash0;
	public const object ResCore-CResource-AssetPathToResourcePath0;
	public const object ResCore-CResource-ResourcePathEnsureExt0;
	public const object ResCore-CResource-Load0;
	public const object ResCore-CResource-LoadBindataAssetInEditor0;
	public const object ResCore-CResource-LoadAsync0;
	public const object ResCore-CResource-Load1;
	public const object ResCore-CResource-_TryLoadBinStream0;
	public const object ResCore-CResource-_TryLoadBinBytes0;
	public const object ResCore-CResource-LoadBin0;
	public const object ResCore-CResource-__FindEntryHelper0;
	public const object ResCore-CResourcePackerInfo-get_m_zipPackage0;
	public const object ResCore-CResource-LoadFromZipPackage0;
	public const object ResCore-CResourcePackerInfo-get_m_assetBundle0;
	public const object ResCore-CResource-LoadFromAssetBundle0;
	public const object ResCore-CResource-LoadObjectFromAssetBundleAsync0;
	public const object ResCore-CResource-FinishLoad0;
	public const object ResCore-CResource-LoadFromAssetBundleAsync0;
	public const object ResCore-CResource-Unload0;
	public const object ResCore-CResource-Increase0;
	public const object ResCore-CResourceManager-get_instance0;
	public const object ResCore-CResourceManager-GetInstance0;
	public const object ResCore-CResourceManager-RemoveCachedResource0;
	public const object ResCore-CResourcePackerInfoSet-GetResourceBelongedPackerInfo0;
	public const object ResCore-CResourceManager-GetResourceBelongedPackerInfo_Help0;
	public const object ResCore-CResourceManager-GetResourceBelongedPackerInfo0;
	public const object ResCore-CResourcePackerInfo-get_m_isAssetBundle0;
	public const object ResCore-CResourcePackerInfo-get_HasDependices0;
	public const object ResCore-CResourcePackerInfo-HasFlag0;
	public const object ResCore-CResourcePackerInfo-IsResident0;
	public const object ResCore-CResourcePackerInfo-set_m_assetBundle0;
	public const object ResCore-CResourcePackerInfo-UnloadAssetBundle0;
	public const object ResCore-CResourcePackerInfo-Decrease0;
	public const object ResCore-CResource-Decrease0;
	public const object ResCore-AsyncLoadReq-Cancel0;
	public const object ResCore-AsyncLoadReq-OnLoaded0;
	public const object ResCore-AsyncLoadReq-OnLoadFinish0;
	public const object ResCore-AsyncLoadReq-Clear0;
	public const object ResCore-AsyncLoadReq-OnResourceLoadComplete0;
	public const object ResCore-CResourceManager-GetFileStream0;
	public const object ResCore-CResourceManager-ReadVersion0;
	public const object ResCore-CResourcePackerInfo-IsAssetBundleLoaded0;
	public const object ResCore-CResourcePackerInfoSet-Dispose0;
	public const object ResCore-CResourceManager-ResetResourcePackinfoSets0;
	public const object ResCore-CResourcePackerInfo-LoadZipPageFromFile0;
	public const object ResCore-CResourcePackerInfo-CreatePKGFromFile0;
	public const object ResCore-CResourcePackerInfo-_TryLoadPKGFromDir0;
	public const object ResCore-CResourcePackerInfo-_LoadPKGHelper0;
	public const object ResCore-RunTimeResourcePackerInfoSet-AssetPathForSet0;
	public const object ResCore-RunTimeResourcePackerInfo-get_ePkgType0;
	public const object ResCore-CResourcePackerInfo-ParseFromAsset0;
	public const object ResCore-CResourcePackerInfo-AddDependency0;
	public const object ResCore-CResourcePackerInfoSet-ParseFromAsset0;
	public const object ResCore-CResourcePackerInfo-AddToResourceMap0;
	public const object ResCore-CResourcePackerInfoSet-CreateResourceMap0;
	public const object ResCore-CResourcePackerInfo-LoadAssetBundle0;
	public const object ResCore-CResourcePackerInfo-LoadPKG0;
	public const object ResCore-CResourceManager-LoadAssetBundle0;
	public const object ResCore-CResourceManager-LoadResidentAssetBundles_help0;
	public const object ResCore-CResourcePackerInfoSet-GetResourcePackerInfoSetFileName_Lan0;
	public const object ResCore-CResourceManager-InitResourcePackinfoSets0;
	public const object ResCore-CResourceVerificationInfoSet-Dispose0;
	public const object ResCore-RunTimeResourceVerificationInfoSet-AssetPathForSet0;
	public const object ResCore-CResourceVerificationInfoSet-ParseFromAsset0;
	public const object ResCore-CResourceManager-InitResourceVerificationInfoSets0;
	public const object ResCore-CResourceManager-FullPathOfAssets0;
	public const object ResCore-CResourceManager-set_IsSimuatorAssetBudle0;
	public const object ResCore-CResourceManager-get_IsReady0;
	public const object ResCore-WeakFileStream-Halt0;
	public const object ResCore-CResourcePackerInfo-set_m_zipPackage0;
	public const object ResCore-CResourceManager-UnloadZipPackage_helper0;
	public const object ResCore-CResourceManager-UnloadAllZipPackages0;
	public const object ResCore-CResourceManager-get_HasDeferredResource0;
	public const object ResCore-CResourceManager-get_UseAsianGamesFiles0;
	public const object ResCore-CResourceManager-set_UseAsianGamesFiles0;
	public const object ResCore-CResourcePackerInfo-WaitingASyncLoadAssetBundleParallelImpl0;
	public const object ResCore-CResourcePackerInfo-WaitingASyncLoadAssetBundleParallel0;
	public const object ResCore-CResourcePackerInfo-ASyncLoadAssetBundleParallel0;
	public const object ResCore-CResourceManager-PushWaitingResPackTaskToLoadingResPackTask0;
	public const object ResCore-CResourceManager-LoadingResourceTask-HasRequestAndAllCanceled0;
	public const object ResCore-CResourceManager-GetResourceBelongedPackerInfo1;
	public const object ResCore-CResourceManager-GetResourceBelongedPackerInfo2;
	public const object ResCore-CResourcePackerInfo-GetdirectAndInDirectDependencies0;
	public const object ResCore-CResourcePackerInfo-get_selfAndAllDependencies0;
	public const object ResCore-CResourceManager-SetResourceLoadingBeginTime0;
	public const object ResCore-CResourcePackerInfo-ASyncLoadAssetBundle0;
	public const object ResCore-CResourcePackerInfo-Increase0;
	public const object ResCore-CResourceManager-UpdateLoadingTaskCoroutineEntry0;
	public const object ResCore-CResourceManager-Init0;
	public const object ResCore-CResourceManager-ExecuteUnloadUnusedAssets0;
	public const object ResCore-CResourceManager-CustomUpdate0;
	public const object ResCore-CResourceManager-GetCachedResourceMap0;
	public const object ResCore-CResourceManager-UnLoadResourcePackerInfoSetAssetbundle0;
	public const object ResCore-CResourceManager-CRCValueUpdater-WaitForReady0;
	public const object ResCore-CResourceManager-CRCValueUpdater-get_CRCValue0;
	public const object ResCore-CResourceManager-get_ZipCRCValue0;
	public const object ResCore-CResourceManager-get_ZipCRCCheckValue0;
	public const object ResCore-CResourceManager-get_DatabinCRCCheckValue0;
	public const object ResCore-CResourceManager-IsCrcConfigExist0;
	public const object ResCore-CResourceManager-CRCValueUpdater-CalcZipCRCAndHeader0;
	public const object ResCore-CResourceManager-CRCValueUpdater-CheckZipPackerCrcXor0;
	public const object ResCore-CResourceManager-CRCValueUpdater-SyncCrcXor0;
	public const object ResCore-CResourceManager-CRCValueUpdater-_Start0;
	public const object ResCore-CResourceManager-CRCValueUpdater-ParallelCrcXor0;
	public const object ResCore-CResourceManager-CRCValueUpdater-Start0;
	public const object ResCore-CResourceManager-CheckCrcXor0;
	public const object ResCore-CResourceManager-CheckDatabinCrcXor0;
	public const object ResCore-CResourceManager-APHashIgnoreCase0;
	public const object ResCore-CResourceManager-IsResourceHashConflict0;
	public const object ResCore-CResourceManager-CheckCachedResource0;
	public const object ResCore-CResourceManager-GetFromCache0;
	public const object ResCore-CResourcePackerInfoSet-GetResourceBelongBundlePath0;
	public const object ResCore-CResourcePackerInfoSet-GetABFromResoucePackInfo0;
	public const object ResCore-CResourcePackerInfoSet-GetResourceBelongABs0;
	public const object ResCore-CResourceManager-GetResourceBelongABs0;
	public const object ResCore-LogHelper-_LogImpl0;
	public const object ResCore-LogHelper-ReportCriticalException0;
	public const object ResCore-CResourceManager-LoadResourceFromInfoSet0;
	public const object ResCore-CResourceManager-LoadResource0;
	public const object ResCore-CResourceManager-GetResourceAsync0;
	public const object ResCore-CResourceManager-GetResource0;
	public const object ResCore-CResourceManager-cacheResource0;
	public const object ResCore-CResourceManager-MarkResourceAsPersistant0;
	public const object ResCore-CResourceManager-RemoveLoadErrorCachedResource0;
	public const object ResCore-CResourceManager-UnloadAsset0;
	public const object ResCore-CResourceManager-UnloadUnusedAssetBundles_Help0;
	public const object ResCore-CResourceManager-UnloadUnusedAssetBundles0;
	public const object ResCore-CResourceManager-UnloadUnusedAssets0;
	public const object ResCore-CResourceManager-RemoveCachedResources0;
	public const object ResCore-CResourceManager-RemoveCachedResources1;
	public const object ResCore-CResourceManager-RemoveStandAloneAssetBundle0;
	public const object ResCore-CResourceManager-UnloadBelongedAssetbundle0;
	public const object ResCore-CResourceManager-Helper_UnloadAssetBundlesByTag0;
	public const object ResCore-CResourceManager-UnloadAssetBundlesByTag0;
	public const object ResCore-CResourceManager-GetResourcePackerInfo_Help0;
	public const object ResCore-CResourceManager-GetResourcePackerInfo0;
	public const object ResCore-CResourceManager-LoadAssetBundle1;
	public const object ResCore-CResourceManager-LoadAssetBundleAsync0;
	public const object ResCore-CResourceManager-GetResourceContentType0;
	public const object ResCore-CResourcePackerInfo-set_isFileInApp0;
	public const object ResCore-CResourceManager-MarkFileInApp0;
	public const object ResCore-CResourceManager-GetResourceBelongPacker0;
	public const object ResCore-CResourcePackerInfo-get_isFileInApp0;
	public const object ResCore-CResourceManager-UpdateFileExsit0;
	public const object ResCore-CResourceManager-IsResourceFileReady_help0;
	public const object ResCore-CResourceManager-IsResourceFileReady_help1;
	public const object ResCore-CResourceManager-IsResourceFileReady0;
	public const object ResCore-CResourceManager-IsBattleResourceReady0;
	public const object ResCore-CResourceManager-IsResourceShouldExist0;
	public const object ResCore-CResourceManager-GetStandAloneUIResource0;
	public const object ResCore-CResourceManager-LoadSingleResourceAsync0;
	public const object ResCore-CResourcePackerInfo-_TryGetAssetbundleMD5FromDir0;
	public const object ResCore-CResourcePackerInfo-GetAssetbundleMD5WithoutDependency0;
	public const object ResCore-CResourceManager-GetBelongedABFileMD50;
	public const object ResCore-CResourceManager-CRCValueUpdater-CheckZipPackerCrcXor1;
	public const object ResCore-CResourcePackerInfo-get_IsConfigFileInApp0;
	public const object ResCore-CResourcePackerInfo-IsStandAlone0;
	public const object ResCore-CResourcePackerInfo-IsForceInIFS0;
	public const object ResCore-CResourcePackerInfo-IsUnCompress0;
	public const object ResCore-CResourcePackerInfo-IsKeepInResources0;
	public const object ResCore-CResourcePackerInfo-AddResourceInfo0;
	public const object ResCore-CResourcePackerInfo-CreateABFromMemoryImmediate0;
	public const object ResCore-CResourcePackerInfo-CreateABFromFile0;
	public const object ResCore-CResourcePackerInfo-IsAssetBundleInLoading0;
	public const object ResCore-CResourcePackerInfoSet-GetResourceIFSFileName_Lan0;
	public const object ResCore-CResourcePackerInfoSet-LanguageFromSetName0;
	public const object ResCore-CResourcePackerInfoSet-_AddResourcePackerInfoAll0;
	public const object ResCore-CResourcePackerInfoSet-AddResourcePackerInfo0;
	public const object ResCore-ResFileList-get_SavedPath0;
	public const object ResCore-ResFileList-ReadFromStream0;
	public const object ResCore-ResFileList-ReadLastSaveResFileList0;
	public const object ResCore-ResFileList-WriteHelp0;
	public const object ResCore-ResFileList-SaveToFile0;
	public const object ResCore-ResFileList-ReadFromFile0;
	public const object ResCore-RunTimeResourcePackerInfoSet-SetVersion0;
	public const object ResCore-RunTimeResourcePackerInfoSet-SetSVNRevision0;
	public const object ResCore-RunTimeResourceVerificationInfoSet-SetVersion0;
	public const object ResCore-RunTimeResourceVerificationInfoSet-SetSVNRevision0;
	public const object ResCore-ResVersion-get_SavedPath0;
	public const object ResCore-ResVersion-ReadFromStream0;
	public const object ResCore-ResVersion-ReadLastSavedResVersion0;
	public const object ResCore-ResVersion-SaveToFile0;
	public const object ResCore-ResVersion-ReadFromFile0;
	public const object ResCore-WeakFileStream-GetFileStream0;
	public const object ResCore-WeakFileStream-get_CanRead0;
	public const object ResCore-WeakFileStream-get_CanSeek0;
	public const object ResCore-WeakFileStream-get_CanWrite0;
	public const object ResCore-WeakFileStream-get_Length0;
	public const object ResCore-WeakFileStream-get_Position0;
	public const object ResCore-WeakFileStream-set_Position0;
	public const object ResCore-WeakFileStream-Flush0;
	public const object ResCore-WeakFileStream-Read0;
	public const object ResCore-WeakFileStream-Seek0;
	public const object ResCore-WeakFileStream-SetLength0;
	public const object ResCore-WeakFileStream-Write0;
	public const object ResCore-WeakFileStream-Dispose0;
	public const object ResCore-LogHelper-DefaultLog0;
	public const object ResCore-LogHelper-LogError0;
	public const object ResCore-LogHelper-Log0;
	public const object ResCore-LogHelper-Assert0;
	public const object ResCore-LogHelper-Assert1;
	public const object ResCore-LogHelper-LogErrorIfNotFinal0;
	public const object ResCore-LogHelper-LogWarning0;
	public const object ResCore-LogHelper-ReportCriticalException1;
	public const object ResCore-LogHelper-Trace0;
	public const object ResCore-LogHelper-Trace1;
	public const object ResCore-ResProfiler-LoadingBeginSample0;
	public const object ResCore-ResProfiler-LoadingEndSample0;
	public const object ResCore-ResProfiler-LoadingBeginSample1;
	public const object ResCore-ResProfiler-LoadingEndSample1;
	public const object ResCore-ResProfiler-BeginSample0;
	public const object ResCore-ResProfiler-EndSample0;
	public const object ResCore-ResProfiler-ProfilerUtilityBeginUISample0;
	public const object ResCore-ResProfiler-ProfilerUtilityEndUISample0;
	public const object ResCore-StringHelper-JavaHashCodeIgnoreCase0;
	public const object ResCore-StringHelper-RemoveExtension0;
	public const object ResCore-StringHelper-GetFileName0;
	public const object ResCore-StringHelper-GetFileExtensionWithoutDot0;
	public const object ResCore-StringHelper-GetFileExtensionWithDot0;
	public const object ResCore-StringHelper-StringIgnoreCaseEqualityComparer-System.Collections.Generic.IEqualityComparer<System.String>.Equals0;
	public const object ResCore-StringHelper-StringIgnoreCaseEqualityComparer-System.Collections.Generic.IEqualityComparer<System.String>.GetHashCode0;
	public const object ResCore-PreDLC-JSONObject-HasKey0;
	public const object ResCore-PreDLC-JSONObject-GetUint0;
	public const object ResCore-PreDLC-JSONObject-RemoveKey0;
	public const object ResCore-PreDLC-JSONObject-SetUint0;
	public const object ResCore-PreDLC-JSONObject-GetString0;
	public const object ResCore-PreDLC-JSONObject-GetString1;
	public const object ResCore-PreDLC-JSONObject-SetString0;
	public const object ResCore-PreDLC-JSONObject-SetString1;
	public const object ResCore-PreDLC-JSONObject-GetBool0;
	public const object ResCore-PreDLC-JSONObject-SetBool0;
	public const object ResCore-PreDLC-JSONObject-Serialize0;
	public const object ResCore-PreDLC-JSONObject-SetObject0;
	public const object ResCore-PreDLC-JSONObject-Deserialize0;
	public const object ResCore-PreDLC-JSONObject-Save0;
	public const object ResCore-PreDLC-Json-Serializer-SerializeString0;
	public const object ResCore-PreDLC-Json-Serializer-SerializeArray0;
	public const object ResCore-PreDLC-Json-Serializer-SerializeObject0;
	public const object ResCore-PreDLC-Json-Serializer-SerializeOther0;
	public const object ResCore-PreDLC-Json-Serializer-SerializeValue0;
	public const object ResCore-PreDLC-Json-Serializer-Serialize0;
	public const object ResCore-PreDLC-Json-Serialize0;
	public const object ResCore-PreDLC-JSONObject-ToString0;
	public const object ResCore-PreDLC-Json-Parser-get_PeekChar0;
	public const object ResCore-PreDLC-Json-Parser-EatWhitespace0;
	public const object ResCore-PreDLC-Json-Parser-get_NextChar0;
	public const object ResCore-PreDLC-Json-Parser-get_NextWord0;
	public const object ResCore-PreDLC-Json-Parser-get_NextToken0;
	public const object ResCore-PreDLC-Json-Parser-ParseString0;
	public const object ResCore-PreDLC-Json-Parser-ParseNumber0;
	public const object ResCore-PreDLC-Json-Parser-ParseObject0;
	public const object ResCore-PreDLC-Json-Parser-ParseArray0;
	public const object ResCore-PreDLC-Json-Parser-ParseByToken0;
	public const object ResCore-PreDLC-Json-Parser-ParseValue0;
	public const object ResCore-PreDLC-Json-Parser-Parse0;
	public const object ResCore-PreDLC-Json-Deserialize0;
	public const object ResCore-PreDLC-JSONObject-Parse0;
	public const object ResCore-PreDLC-JSONObject-Load0;
	public const object ResCore-PreDLC-JSONObject-Delete0;
	public const object ResCore-PreDLC-JSONObject-Exists0;
	public const object ResCore-PreDLC-Json-Parser-Dispose0;
	public const object ResCore-PreDLC-PreDLCRecord-Serialize0;
	public const object ResCore-PreDLC-PreDLCRecord-Deserialize0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetPreDLCDownloadState0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-IsDLCDownloaded0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-SaveRecord0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-MarkDLCDownloaded0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-_SaveRecord0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-Update0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-IsNeedToSyncToDLC0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetDownloadedFileListForCopy0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetDownloadedFileListForCopy1;
	public const object ResCore-DLC-DLCIndex-get_AllDLCConfigs0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-PrintAll0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetDLCConfig0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_instance0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetInstance0;
	public const object ResCore-DLC-DLCConfigMgr-GetDLCItem0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCItem0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-IsSameAsInDLC0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetCache0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetDLCSize0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetDLCDownloadedSize0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetDLCDownloadPercentage0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetCache1;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetDLCTotalSizeByIDs0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-GetDLCDownloadList0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-UnloadConfig0;
	public const object ResCore-DLC-DLCIndex-Init0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-LoadConfig0;
	public const object ResCore-PreDLC-PreDLCConfigHelper-SetPuffer0;
	public const object ResCore-PreDLC-PreDLCDownloader-get_ProgressSize0;
	public const object ResCore-PreDLC-PreDLCDownloader-get_Percent0;
	public const object ResCore-PreDLC-PreDLCDownloader-get_Paths0;
	public const object ResCore-PreDLC-PreDLCDownloader-set_Paths0;
	public const object ResCore-PreDLC-PreDLCManager-get_instance0;
	public const object ResCore-PreDLC-PreDLCManager-RemoveDownloadList0;
	public const object ResCore-PreDLC-PreDLCDownloader-_NotifyStop0;
	public const object ResCore-PreDLC-PreDLCDownloader-NotifyStop0;
	public const object ResCore-PreDLC-PreDLCManager-AddDownloadList0;
	public const object ResCore-PreDLC-PreDLCDownloader-ResCore.DLC.DLCDownloadRequest.OnSetupTasks0;
	public const object ResCore-PreDLC-PreDLCDownloader-ResCore.DLC.DLCDownloadRequest.OnTaskProgress0;
	public const object ResCore-PreDLC-PreDLCDownloader-ResCore.DLC.DLCDownloadRequest.OnTaskFinish0;
	public const object ResCore-PreDLC-PreDLCDownloader-ResCore.DLC.DLCDownloadRequest.OnError0;
	public const object ResCore-PreDLC-PreDLCDownloader-ResCore.DLC.DLCDownloadRequest.OnTaskStop0;
	public const object ResCore-PreDLC-PreDLCManager-get_IsConfigLoaded0;
	public const object ResCore-PreDLC-PreDLCManager-GetVersionNumber0;
	public const object ResCore-PreDLC-PreDLCManager-Init0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-SaveHashAndCRC0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-AppendDLCHashAndCRCToTmpFile0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-CheckFileCRC0;
	public const object ResCore-DLC-DLCConfigMgr-GetDLCConfig0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCConfig0;
	public const object ResCore-DLC-DLCConfigMgr-IsValidDLC0;
	public const object ResCore-DLC-DLCFileDownloadSession-get_IsInited0;
	public const object ResCore-DLC-DLCFileDownloadSession-IsFileReady0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsDLCItemNeedDownload0;
	public const object ResCore-DLC-DLCFileDownloadSession-IsFileExistInServer0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-UpdateItemDownloadState0;
	public const object ResCore-DLC-DLCConfigMgr-get_PufferSizes0;
	public const object ResCore-DLC-DLCFileDownloadSession-GetCompressFileSize0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCItemSize0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-UpdateDLCDownloadState0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCSize0;
	public const object ResCore-DLC-DLCConfigMgr-ReleaseDLC0;
	public const object ResCore-DLC-DLCConfigMgr-get_AllDLCIDs0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_AllDLCIDs0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsPrePocessFinished0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-UpdateDLCDownloadState1;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsDLCDownloaded0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_CurrentDownloadingID0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDownloadState0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-OnDownloadError0;
	public const object ResCore-DLC-DLCFileDownloadSession-_PushPendingTask0;
	public const object ResCore-DLC-DLCFileDownloadSession-MoveAllDownloadingTasksToPending0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-OnDownloadPause0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-OnDownloadPause0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-Pause0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-OnDownloadError0;
	public const object ResCore-DLC-DLCFileDownloadTask-OnStop0;
	public const object ResCore-DLC-DLCFileDownloadSession-_CallOnAllTask0;
	public const object ResCore-DLC-DLCFileDownloadSession-ForceStopAllTasks0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_DownloadingCount0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-OnDownlodingCountChanged0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-OnDownlodingCountChanged0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-RemoveDownloadingByID0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-OnDownloadCanceled0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-OnDownloadCanceled0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-CancelDLCDownloading0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-WriteUpdateIds0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-UpdateUpdateIds0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ClearDownloadedDLCByID0;
	public const object ResCore-PreDLC-PreDLCManager-DeactiveDownload0;
	public const object ResCore-PreDLC-PreDLCManager-ActiveDownload0;
	public const object ResCore-PreDLC-PreDLCManager-Clear0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-OnDLCDownloadFinished0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-OnDLCDownloadFinished0;
	public const object ResCore-PreDLC-PreDLCManager-SyncDownloadedStateToDLC0;
	public const object ResCore-PreDLC-PreDLCManager-CloseDownloader0;
	public const object ResCore-PreDLC-PreDLCManager-DownloadNext0;
	public const object ResCore-PreDLC-PreDLCManager-Update0;
	public const object ResCore-PreDLC-PreDLCManager-GetDownloaderById0;
	public const object ResCore-PreDLC-PreDLCManager-GetDLCDownloadPercentage0;
	public const object ResCore-PreDLC-PreDLCManager-GetDLCDownloadedSize0;
	public const object ResCore-PreDLC-PreDLCManager-GetDLCDownloadedSizeByIDs0;
	public const object ResCore-PreDLC-PreDLCManager-GetDLCSize0;
	public const object ResCore-PreDLC-PreDLCManager-GetDLCTotalSizeByIDs0;
	public const object ResCore-PreDLC-PreDLCManager-CancelDLCDownloading0;
	public const object ResCore-PreDLC-PreDLCManager-LoadConfig0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnInitReturn0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnInitProgress0;
	public const object ResCore-PreDLC-PreDLCManager-GetDownloaderByTaskId0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnDownloadReturn0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnDownloadProgress0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnDownloadBatchReturn0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnDownloadBatchProgress0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnPufferFileListItem0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnRestoreReturn0;
	public const object ResCore-PreDLC-PreDLCManager-ResCore.PreDLC.IPufferCallBackBridge.OnRestoreProgress0;
	public const object ResCore-DLC-DefaultDLCCreateFilter-IsConfigDeletable0;
	public const object ResCore-DLC-DefaultDLCCreateFilter-IsConfigNeed0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_BuildType0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_ServerVersion0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_LocalVersion0;
	public const object ResCore-DLC-DLCFileDownloadSession-get_IsVersionRequested0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsVersionUnMatched0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-UpdatePreProcessDownloadState0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-InitPreProcessDLCDownloadState0;
	public const object ResCore-DLC-DLCConfigMgr-AddDLCConfig0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-AddDLCConfig0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsDLCHasDownloaded0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsDLCSHasDownloaded0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsDLCItemDownload0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsAllDLCDownloaded0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCDownloadPercentage0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsValidDLC0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCItem1;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_DownloadSpeed0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCTotalSizeByIDs0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCDownloadedSize0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCDownloadedSizeByIDs0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetFileSizeByResPath0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsActive0;
	public const object ResCore-DLC-DLCFileDownloadSession-_ResetSpeedCache0;
	public const object ResCore-DLC-DLCFileDownloadSession-Stop0;
	public const object ResCore-DLC-DLCFileDownloadSession-UnInit0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-DeactiveDownload0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-DeletAllDownloadedFiles0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-CreateDownloader0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_DownloadedCount0;
	public const object ResCore-DLC-DLCConfigMgr-get_TotalDLCSize0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_TotalSize0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-get_DownloadedSize0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsPausing0;
	public const object ResCore-DLC-DLCFileDownloadSession-get_MaxDownloadTasks0;
	public const object ResCore-DLC-DLCFileDownloadSession-_DownloadFile0;
	public const object ResCore-DLC-DLCFileDownloadTask-OnError0;
	public const object ResCore-DLC-DLCFileDownloadSession-_Schedule0;
	public const object ResCore-DLC-DLCFileDownloadSession-_CheckAndWriteCacheFile0;
	public const object ResCore-DLC-DLCFileDownloadSession-_CalSpeed0;
	public const object ResCore-DLC-DLCFileDownloadSession-Update0;
	public const object ResCore-DLC-DLCFileDownloadSession-IsExtraStorageLimited0;
	public const object ResCore-DLC-DLCFileDownloadSession-StartDownloadReq0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ProcessNextDownload0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-Update0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCDownloadingPriority0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ChangeDLCIdSiteInDownloaderQueue0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-DownLoadDLCTop0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-InsertMid0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-PreDownloadDlc0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-DownLoadDLC0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-SetAsNextDownloading0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IncreasePriority0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-CancelAllDownloadQueue0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-CancelAllDLCQueue0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-AddDelegate0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-AddDelegate0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-RemoveDelegate0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-RemoveDelegate0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-SetBackGroundDownloadDeletate0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-DownloadDLCs0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-InsertMid1;
	public const object ResCore-DLC-DLCDownloaderMgrImp-TryAddToQueue0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ReplaceDownloadQueue0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-MoveDLCIdsInQueue0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-MoveDLCIdsToHead0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-InsertDLCIdsThatAreNotInQueueInToHeader0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-HasAnyDownloading0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetAllDownloadingDLCs0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ClearAllDownloading0;
	public const object ResCore-DLC-DLCConfigMgr-GetDLCItemCount0;
	public const object ResCore-DLC-DLCConfigMgr-GetDLCItems0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-PreCheckDLCItem0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ReadHashAndCRCFromTmpFile0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ReadHashAndCRC0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsSameDLCVersion0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-GetDLCVersion0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-IsPufferReady0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ReadUpdateIds0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-UpdateCRCAndSave0;
	public const object ResCore-DLC-DLCConfigMgr-InitFromFile0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-InitEnv0;
	public const object ResCore-DLC-DLCFileDownloadSession-Start0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-_OnPufferInit0;
	public const object ResCore-DLC-DLCFileDownloadSession-Init0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-ActiveDownload0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-WaitForDLCActived0;
	public const object ResCore-DLC-DLCFileDownloadSession-SetDLMaxSpeed0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-SetDLMaxSpeed0;
	public const object ResCore-DLC-DLCFileDownloadSession-SetDLMaxTask0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-SetDLMaxTask0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-OnDLCDownloadStart0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-OnDLCDownloadStart0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-OnDownloadProgress0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-OnDownloadProgress0;
	public const object ResCore-DLC-DLCDownloaderDelegateList-OnFileDownloadFinished0;
	public const object ResCore-DLC-DLCDownloaderMgrImp-OnFileDownloadFinished0;
	public const object ResCore-DLC-DLCDownloader-get_ProgressSize0;
	public const object ResCore-DLC-DLCDownloader-get_Percent0;
	public const object ResCore-DLC-DLCFileDownloadSession-_GetTask0;
	public const object ResCore-DLC-DLCFileDownloadSession-GetOrCreateTask0;
	public const object ResCore-DLC-DLCFileDownloadTask-AddReq0;
	public const object ResCore-DLC-DLCDownloader-OnSetupTasks0;
	public const object ResCore-DLC-DLCDownloader-OnTaskFinish0;
	public const object ResCore-DLC-DLCDownloader-OnTaskProgress0;
	public const object ResCore-DLC-DLCDownloader-NotifyStop0;
	public const object ResCore-DLC-DLCDownloader-OnTaskStop0;
	public const object ResCore-DLC-DLCDownloader-OnError0;
	public const object ResCore-DLC-FileListDownloadReq-OnError0;
	public const object ResCore-DLC-FileListDownloadReq-OnSetupTasks0;
	public const object ResCore-DLC-FileListDownloadReq-OnTaskFinish0;
	public const object ResCore-DLC-FileListDownloadReq-OnTaskProgress0;
	public const object ResCore-DLC-FileListDownloadReq-OnTaskStop0;
	public const object ResCore-DLC-VersionDownloadReq-tryGetVersion0;
	public const object ResCore-DLC-VersionDownloadReq-OnError0;
	public const object ResCore-DLC-VersionDownloadReq-OnSetupTasks0;
	public const object ResCore-DLC-VersionDownloadReq-OnTaskFinish0;
	public const object ResCore-DLC-VersionDownloadReq-OnTaskProgress0;
	public const object ResCore-DLC-VersionDownloadReq-OnTaskStop0;
	public const object ResCore-DLC-DLCFileDownloadSession-RequestVersionFileInNextFrame0;
	public const object ResCore-DLC-DLCFileDownloadSession-OnVersionGet0;
	public const object ResCore-DLC-DLCFileDownloadSession-RequestVersionFile0;
	public const object ResCore-DLC-DLCFileDownloadSession-OnInitReturn0;
	public const object ResCore-DLC-DLCFileDownloadSession-OnInitProgress0;
	public const object ResCore-DLC-DLCFileDownloadSession-_TriggerStorageLimitErrorForAllTask0;
	public const object ResCore-DLC-DLCFileDownloadTask-OnFinish0;
	public const object ResCore-DLC-DLCFileDownloadSession-OnDownloadReturn0;
	public const object ResCore-DLC-DLCFileDownloadTask-OnProgress0;
	public const object ResCore-DLC-DLCFileDownloadSession-OnDownloadProgress0;
	public const object ResCore-DLC-GenericDLCConfig-get_ID0;
	public const object ResCore-DLC-GenericDLCConfig-get_ResList0;
	public const object ResCore-DLC-DLCConfigMgr-CreateDLCConfigOnRunTime0;
	public const object ResCore-DLC-DLCConfigMgr-AddPreDLCID0;
	public const object ResCore-DLC-DLCConfigMgr-AddPreDLCConfig0;
	public const object ResCore-DLC-ResUpdateMgr-get_TotalDownloadedSize0;
	public const object ResCore-DLC-ResUpdateMgr-get_DownloadSpeed0;
	public const object ResCore-DLC-ResUpdateMgr-Pause0;
	public const object ResCore-DLC-ResUpdateStage-OnStageEnter0;
	public const object ResCore-DLC-ResUpdateMgr-Init0;
	public const object ResCore-DLC-ResUpdateMgr-UnInit0;
	public const object ResCore-DLC-ResUpdateStage-OnStageLeave0;
	public const object ResCore-DLC-ResUpdateMgr-StartDownloadResFiles0;
	public const object ResCore-DLC-ResUpdateStage-Update0;
	public const object ResCore-DLC-ResUpdateMgr-Update0;
	public const object ResCore-DLC-ResUpdateStage-GetVersionNumber0;
	public const object ResCore-DLC-ResUpdateInitStage-get_NextStage0;
	public const object ResCore-DLC-ResUpdateInitStage-OnInitProgressDelegate0;
	public const object ResCore-DLC-ResUpdateInitStage-OnPufferInitCB0;
	public const object ResCore-DLC-ResUpdateInitStage-OnStageEnter0;
	public const object ResCore-DLC-VersionDownloadStage-get_NextStage0;
	public const object ResCore-DLC-VersionDownloadStage-OnGetVersion0;
	public const object ResCore-DLC-VersionDownloadStage-OnStageEnter0;
	public const object ResCore-DLC-FileListStage-get_NextStage0;
	public const object ResCore-DLC-FileListStage-EnumNeedUpdateResItem0;
	public const object ResCore-DLC-FileListStage-OnGetFileList0;
	public const object ResCore-DLC-FileListStage-ProcessLanguageDiffList0;
	public const object ResCore-DLC-FileListStage-OnStageEnter0;
	public const object ResCore-DLC-ResItemUpdateStage-OnStageEnter0;
	public const object ResCore-DLC-ResItemUpdateStage-get_NextStage0;
	public const object ResCore-DLC-ResItemUpdateStage-SaveOldFileList0;
	public const object ResCore-DLC-ResItemUpdateStage-OnDownloadCanceled0;
	public const object ResCore-DLC-ResItemUpdateStage-OnDownloadProgress0;
	public const object ResCore-DLC-ResItemUpdateStage-OnDownloadError0;
	public const object ResCore-DLC-ResItemUpdateStage-OnFileDownloadFinished0;
	public const object ResCore-DLC-ResItemUpdateStage-ProcessPatchZip0;
	public const object ResCore-DLC-ResItemUpdateStage-OnDLCDownloadFinished0;
	public const object ResCore-DLC-ResItemUpdateStage-OnDLCDownloadStart0;
	public const object ResCore-DLC-ResItemUpdateStage-OnDownlodingCountChanged0;
	public const object ResCore-DLC-ResItemUpdateStage-OnDownloadPause0;
}

