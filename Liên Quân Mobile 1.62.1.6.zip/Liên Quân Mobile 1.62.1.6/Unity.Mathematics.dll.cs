// Namespace: 
internal class <Module>
{
}

// Namespace: Unity.IL2CPP.CompilerServices
internal class Il2CppEagerStaticClassConstructionAttribute
{

	// Methods

	// RVA: 0x7270B7C
	public object .ctor() { }

}

// Namespace: 
internal struct LongDoubleUnion
{

	// Fields
	public object longValue; // 0xFFFFFFFFFFFFFFF8
	public object doubleValue; // 0xFFFFFFFFFFFFFFF8
}

// Namespace: Unity.Mathematics
public static class math
{

	// Methods

	// RVA: 0x7270B84
	public static object hash(object v) { }

	// RVA: 0x7270BD8
	public static object hash(object v) { }

	// RVA: 0x7270C0C
	public static object float3(object x, object y, object z) { }

	// RVA: 0x7270C10
	public static object hash(object v) { }

	// RVA: 0x7270C58
	public static object hash(object v) { }

	// RVA: 0x7270CE4
	public static object float4(object x, object y, object z, object w) { }

	// RVA: 0x7270CE8
	public static object float4(object xyz, object w) { }

	// RVA: 0x7270CEC
	public static object hash(object v) { }

	// RVA: 0x7270D4C
	public static object float4x4(object c0, object c1, object c2, object c3) { }

	// RVA: 0x7270D68
	public static object hash(object v) { }

	// RVA: 0x7270E6C
	public static object hash(object v) { }

	// RVA: 0x7270E9C
	public static object hash(object v) { }

	// RVA: 0x7270EDC
	public static object hash(object v) { }

	// RVA: 0x7270F34
	public static object asuint(object x) { }

	// RVA: 0x7270F38
	public static object asuint(object x) { }

	// RVA: 0x7270F40
	public static object asuint(object x) { }

	// RVA: 0x7270F44
	public static object asuint(object x) { }

	// RVA: 0x7270F4C
	public static object asuint(object x) { }

	// RVA: 0x7270F5C
	public static object asuint(object x) { }

	// RVA: 0x7270F70
	public static object asuint(object x) { }

	// RVA: 0x7270F8C
	public static object asfloat(object x) { }

	// RVA: 0x7270F94
	public static object asfloat(object x) { }

	// RVA: 0x7270FA4
	public static object asfloat(object x) { }

	// RVA: 0x7270FB8
	public static object min(object x, object y) { }

	// RVA: 0x7270FC4
	public static object min(object x, object y) { }

	// RVA: 0x7270FEC
	public static object min(object x, object y) { }

	// RVA: 0x7270FF8
	public static object min(object x, object y) { }

	// RVA: 0x7271014
	public static object min(object x, object y) { }

	// RVA: 0x7271044
	public static object min(object x, object y) { }

	// RVA: 0x7271088
	public static object min(object x, object y) { }

	// RVA: 0x72710E0
	public static object max(object x, object y) { }

	// RVA: 0x72710EC
	public static object max(object x, object y) { }

	// RVA: 0x7271114
	public static object max(object x, object y) { }

	// RVA: 0x7271120
	public static object max(object x, object y) { }

	// RVA: 0x727112C
	public static object max(object x, object y) { }

	// RVA: 0x7271148
	public static object max(object x, object y) { }

	// RVA: 0x7271178
	public static object max(object x, object y) { }

	// RVA: 0x72711BC
	public static object max(object x, object y) { }

	// RVA: 0x7271214
	public static object lerp(object start, object end, object t) { }

	// RVA: 0x7271224
	public static object lerp(object start, object end, object t) { }

	// RVA: 0x7271240
	public static object lerp(object start, object end, object t) { }

	// RVA: 0x7271268
	public static object lerp(object start, object end, object t) { }

	// RVA: 0x72712A0
	public static object clamp(object valueToClamp, object lowerBound, object upperBound) { }

	// RVA: 0x72712B4
	public static object clamp(object valueToClamp, object lowerBound, object upperBound) { }

	// RVA: 0x72712E4
	public static object clamp(object valueToClamp, object lowerBound, object upperBound) { }

	// RVA: 0x7271328
	public static object clamp(object valueToClamp, object lowerBound, object upperBound) { }

	// RVA: 0x727139C
	public static object saturate(object x) { }

	// RVA: 0x72713CC
	public static object saturate(object x) { }

	// RVA: 0x7271414
	public static object abs(object x) { }

	// RVA: 0x7271420
	public static object abs(object x) { }

	// RVA: 0x7271428
	public static object abs(object x) { }

	// RVA: 0x7271434
	public static object abs(object x) { }

	// RVA: 0x7271444
	public static object dot(object x, object y) { }

	// RVA: 0x7271454
	public static object dot(object x, object y) { }

	// RVA: 0x727146C
	public static object dot(object x, object y) { }

	// RVA: 0x727148C
	public static object tan(object x) { }

	// RVA: 0x727150C
	public static object atan2(object y, object x) { }

	// RVA: 0x727157C
	public static object atan2(object y, object x) { }

	// RVA: 0x7271608
	public static object cos(object x) { }

	// RVA: 0x7271670
	public static object cos(object x) { }

	// RVA: 0x7271780
	public static object cos(object x) { }

	// RVA: 0x7271800
	public static object acos(object x) { }

	// RVA: 0x7271868
	public static object sin(object x) { }

	// RVA: 0x72718D0
	public static object sin(object x) { }

	// RVA: 0x72719E0
	public static object sin(object x) { }

	// RVA: 0x7271A60
	public static object asin(object x) { }

	// RVA: 0x7271AE0
	public static object floor(object x) { }

	// RVA: 0x7271B60
	public static object ceil(object x) { }

	// RVA: 0x7271BE0
	public static object frac(object x) { }

	// RVA: 0x7271C68
	public static object pow(object x, object y) { }

	// RVA: 0x7271CDC
	public static object exp2(object x) { }

	// RVA: 0x7271D54
	public static object log(object x) { }

	// RVA: 0x7271DBC
	public static object log2(object x) { }

	// RVA: 0x7271E2C
	public static object sqrt(object x) { }

	// RVA: 0x7271EAC
	public static object rsqrt(object x) { }

	// RVA: 0x7271F14
	public static object normalize(object x) { }

	// RVA: 0x7271F94
	public static object normalize(object x) { }

	// RVA: 0x727202C
	public static object normalizesafe(object x, object defaultvalue) { }

	// RVA: 0x72720F0
	public static object length(object x) { }

	// RVA: 0x7272174
	public static object length(object x) { }

	// RVA: 0x7272204
	public static object lengthsq(object x) { }

	// RVA: 0x727221C
	public static object cross(object x, object y) { }

	// RVA: 0x7272244
	public static object all(object x) { }

	// RVA: 0x727225C
	public static object select(object falseValue, object trueValue, object test) { }

	// RVA: 0x7272280
	public static object select(object falseValue, object trueValue, object test) { }

	// RVA: 0x7272294
	public static object select(object falseValue, object trueValue, object test) { }

	// RVA: 0x72722B0
	public static object sincos(object x, object s, object c) { }

	// RVA: 0x7272538
	public static object lzcnt(object x) { }

	// RVA: 0x7272574
	public static object lzcnt(object x) { }

	// RVA: 0x72725B0
	public static object tzcnt(object x) { }

	// RVA: 0x72725EC
	public static object tzcnt(object x) { }

	// RVA: 0x7272628
	public static object ceilpow2(object x) { }

	// RVA: 0x7272648
	public static object ceillog2(object x) { }

	// RVA: 0x7272680
	public static object radians(object x) { }

	// RVA: 0x7272694
	public static object csum(object x) { }

	// RVA: 0x72726A0
	public static object csum(object x) { }

	// RVA: 0x72726B0
	public static object csum(object x) { }

	// RVA: 0x72726C8
	public static object float3x3(object rotation) { }

	// RVA: 0x7272880
	public static object mul(object a, object b) { }

	// RVA: 0x72728B4
	public static object mul(object a, object b) { }

	// RVA: 0x7272958
	public static object quaternion(object value) { }

	// RVA: 0x727295C
	public static object mul(object a, object b) { }

	// RVA: 0x72729E8
	public static object mul(object q, object v) { }

	// RVA: 0x7272A64
	public static object hash(object q) { }

	// RVA: 0x7272AC4
	public static object uint2(object x, object y) { }

	// RVA: 0x7272AD0
	public static object hash(object v) { }

	// RVA: 0x7272B00
	public static object uint3(object x, object y, object z) { }

	// RVA: 0x7272B10
	public static object hash(object v) { }

	// RVA: 0x7272B50
	public static object uint4(object x, object y, object z, object w) { }

	// RVA: 0x7272B68
	public static object hash(object v) { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct bool3
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFF9
	public object z; // 0xFFFFFFFFFFFFFFFA

	// Methods

	// RVA: 0x7272BC0
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x7272BE0
	public object .ctor(object v) { }

	// RVA: 0x7272C00
	public static object op_Implicit(object v) { }

	// RVA: 0x7272C18
	public static object op_BitwiseAnd(object lhs, object rhs) { }

	// RVA: 0x7272C2C
	public object Equals(object rhs) { }

	// RVA: 0x7272CA4
	public override object Equals(object o) { }

	// RVA: 0x7272E44
	public override object GetHashCode() { }

	// RVA: 0x7272F04
	public override object ToString() { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct float2
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC

	// Properties
	public object Item { get; set; }

	// Methods

	// RVA: 0x727309C
	public object .ctor(object x, object y) { }

	// RVA: 0x72730AC
	public object .ctor(object v) { }

	// RVA: 0x72730C4
	public object .ctor(object v) { }

	// RVA: 0x72730EC
	public static object op_Implicit(object v) { }

	// RVA: 0x72730F8
	public static object op_Implicit(object v) { }

	// RVA: 0x7273108
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7273114
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7273120
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7273130
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x727313C
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x7273148
	public static object op_Subtraction(object lhs, object rhs) { }

	// RVA: 0x7273154
	public static object op_Subtraction(object lhs, object rhs) { }

	// RVA: 0x7273160
	public static object op_Division(object lhs, object rhs) { }

	// RVA: 0x727316C
	public static object op_Division(object lhs, object rhs) { }

	// RVA: 0x7273178
	public static object op_Division(object lhs, object rhs) { }

	// RVA: 0x7273188
	public object get_Item(object index) { }

	// RVA: 0x727319C
	public object set_Item(object index, object value) { }

	// RVA: 0x72731B0
	public object Equals(object rhs) { }

	// RVA: 0x72731F8
	public override object Equals(object o) { }

	// RVA: 0x7273360
	public override object GetHashCode() { }

	// RVA: 0x72733C0
	public override object ToString() { }

	// RVA: 0x7273510
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7273640
	public static object op_Implicit(object v) { }

	// RVA: 0x7273644
	public static object op_Implicit(object v) { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct float3
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public static readonly object zero; // 0x0

	// Properties
	public object yxxy { get; }
	public object zzyz { get; }
	public object xyz { get; }
	public object yzx { get; }
	public object xy { get; }
	public object Item { get; }

	// Methods

	// RVA: 0x7273648
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x7273660
	public object .ctor(object xy, object z) { }

	// RVA: 0x7273678
	public object .ctor(object v) { }

	// RVA: 0x7273690
	public object .ctor(object v) { }

	// RVA: 0x72736B0
	public static object op_Implicit(object v) { }

	// RVA: 0x72736BC
	public static object op_Implicit(object v) { }

	// RVA: 0x72736CC
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x72736DC
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x72736EC
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7273700
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x7273710
	public static object op_Subtraction(object lhs, object rhs) { }

	// RVA: 0x7273720
	public static object op_Division(object lhs, object rhs) { }

	// RVA: 0x7273730
	public static object op_LessThan(object lhs, object rhs) { }

	// RVA: 0x7273754
	public static object op_LessThanOrEqual(object lhs, object rhs) { }

	// RVA: 0x7273778
	public static object op_GreaterThanOrEqual(object lhs, object rhs) { }

	// RVA: 0x727379C
	public static object op_UnaryNegation(object val) { }

	// RVA: 0x72737AC
	public object get_yxxy() { }

	// RVA: 0x72737CC
	public object get_zzyz() { }

	// RVA: 0x72737EC
	public object get_xyz() { }

	// RVA: 0x7273804
	public object get_yzx() { }

	// RVA: 0x727381C
	public object get_xy() { }

	// RVA: 0x727382C
	public object get_Item(object index) { }

	// RVA: 0x7273840
	public object Equals(object rhs) { }

	// RVA: 0x72738A0
	public override object Equals(object o) { }

	// RVA: 0x7273A28
	public override object GetHashCode() { }

	// RVA: 0x7273AB0
	public override object ToString() { }

	// RVA: 0x7273C48
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7273DB0
	public static object op_Implicit(object v) { }

	// RVA: 0x7273DB4
	public static object op_Implicit(object v) { }

}

// Namespace: Unity.Mathematics
public struct float3x3
{

	// Fields
	public object c0; // 0xFFFFFFFFFFFFFFF8
	public object c1; // 0x4
	public object c2; // 0x10
	public static readonly object identity; // 0x0

	// Methods

	// RVA: 0x7273DB8
	public object .ctor(object m00, object m01, object m02, object m10, object m11, object m12, object m20, object m21, object m22) { }

	// RVA: 0x7273DF0
	public object Equals(object rhs) { }

	// RVA: 0x7273F28
	public override object Equals(object o) { }

	// RVA: 0x7274054
	public override object GetHashCode() { }

	// RVA: 0x7274154
	public override object ToString() { }

	// RVA: 0x727474C
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x72727A4
	public object .ctor(object q) { }

	// RVA: 0x7274E00
	private static object .cctor() { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct float4
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public object w; // 0x4
	public static readonly object zero; // 0x0

	// Properties
	public object xxzz { get; }
	public object xyxy { get; }
	public object xyzx { get; }
	public object yyww { get; }
	public object yzxy { get; }
	public object yzxz { get; }
	public object zxyy { get; }
	public object zxyz { get; }
	public object zwzw { get; }
	public object wwwx { get; }
	public object wwww { get; }
	public object xyz { get; set; }
	public object yxw { get; }
	public object zwx { get; }
	public object wzy { get; }
	public object xy { get; set; }
	public object zw { get; set; }

	// Methods

	// RVA: 0x7274E5C
	public object .ctor(object x, object y, object z, object w) { }

	// RVA: 0x7274E74
	public object .ctor(object xy, object z, object w) { }

	// RVA: 0x7274E8C
	public object .ctor(object xy, object zw) { }

	// RVA: 0x7274EA4
	public object .ctor(object xyz, object w) { }

	// RVA: 0x7274EBC
	public object .ctor(object xyzw) { }

	// RVA: 0x7274ED4
	public object .ctor(object v) { }

	// RVA: 0x7274EEC
	public object .ctor(object v) { }

	// RVA: 0x7274F0C
	public static object op_Implicit(object v) { }

	// RVA: 0x7274F1C
	public static object op_Implicit(object v) { }

	// RVA: 0x7274F30
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7274F44
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7274F58
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7274F70
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x7274F84
	public static object op_Subtraction(object lhs, object rhs) { }

	// RVA: 0x7274F98
	public static object op_Division(object lhs, object rhs) { }

	// RVA: 0x7274FAC
	public static object op_UnaryNegation(object val) { }

	// RVA: 0x7274FC0
	public object get_xxzz() { }

	// RVA: 0x7274FE8
	public object get_xyxy() { }

	// RVA: 0x7275008
	public object get_xyzx() { }

	// RVA: 0x7275028
	public object get_yyww() { }

	// RVA: 0x7275050
	public object get_yzxy() { }

	// RVA: 0x7275070
	public object get_yzxz() { }

	// RVA: 0x7275090
	public object get_zxyy() { }

	// RVA: 0x72750B0
	public object get_zxyz() { }

	// RVA: 0x72750D0
	public object get_zwzw() { }

	// RVA: 0x72750F0
	public object get_wwwx() { }

	// RVA: 0x7275118
	public object get_wwww() { }

	// RVA: 0x7275140
	public object get_xyz() { }

	// RVA: 0x7275158
	public object set_xyz(object value) { }

	// RVA: 0x7275170
	public object get_yxw() { }

	// RVA: 0x7275188
	public object get_zwx() { }

	// RVA: 0x72751A0
	public object get_wzy() { }

	// RVA: 0x72751B8
	public object get_xy() { }

	// RVA: 0x72751C8
	public object set_xy(object value) { }

	// RVA: 0x72751D8
	public object get_zw() { }

	// RVA: 0x72751E8
	public object set_zw(object value) { }

	// RVA: 0x72751F8
	public object Equals(object rhs) { }

	// RVA: 0x7275270
	public override object Equals(object o) { }

	// RVA: 0x7275418
	public override object GetHashCode() { }

	// RVA: 0x72754C8
	public override object ToString() { }

	// RVA: 0x7275840
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x7275B98
	public static object op_Implicit(object v) { }

	// RVA: 0x7275B9C
	public static object op_Implicit(object v) { }

}

// Namespace: Unity.Mathematics
public struct float4x4
{

	// Fields
	public object c0; // 0xFFFFFFFFFFFFFFF8
	public object c1; // 0x8
	public object c2; // 0x18
	public object c3; // 0x28
	public static readonly object identity; // 0x0

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x7275BA0
	public object .ctor(object c0, object c1, object c2, object c3) { }

	// RVA: 0x7275BDC
	public object .ctor(object m00, object m01, object m02, object m03, object m10, object m11, object m12, object m13, object m20, object m21, object m22, object m23, object m30, object m31, object m32, object m33) { }

	// RVA: 0x7275C44
	public object get_Item(object index) { }

	// RVA: 0x7275C58
	public object Equals(object rhs) { }

	// RVA: 0x7275E70
	public override object Equals(object o) { }

	// RVA: 0x727600C
	public override object GetHashCode() { }

	// RVA: 0x727622C
	public override object ToString() { }

	// RVA: 0x7276BA4
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x72774FC
	public static object op_Implicit(object m) { }

	// RVA: 0x72775D0
	public static object op_Implicit(object m) { }

	// RVA: 0x7277638
	public static object TRS(object translation, object rotation, object scale) { }

	// RVA: 0x7277768
	private static object .cctor() { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct int2
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public static readonly object zero; // 0x0

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x72777D8
	public object .ctor(object x, object y) { }

	// RVA: 0x72777E8
	public object .ctor(object v) { }

	// RVA: 0x72777F8
	public static object op_Implicit(object v) { }

	// RVA: 0x7277804
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7277818
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x7277830
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x7277844
	public object get_Item(object index) { }

	// RVA: 0x7277858
	public object Equals(object rhs) { }

	// RVA: 0x72778A8
	public override object Equals(object o) { }

	// RVA: 0x7277A10
	public override object GetHashCode() { }

	// RVA: 0x7277A78
	public override object ToString() { }

	// RVA: 0x7277BC8
	public object ToString(object format, object formatProvider) { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct int3
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public static readonly object zero; // 0x0

	// Properties
	public object xy { get; }

	// Methods

	// RVA: 0x7277CF8
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x7277D10
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x7277D2C
	public static object op_Subtraction(object lhs, object rhs) { }

	// RVA: 0x7277D48
	public object get_xy() { }

	// RVA: 0x7277D58
	public object Equals(object rhs) { }

	// RVA: 0x7277DC0
	public override object Equals(object o) { }

	// RVA: 0x7277F48
	public override object GetHashCode() { }

	// RVA: 0x7277FD8
	public override object ToString() { }

	// RVA: 0x7278170
	public object ToString(object format, object formatProvider) { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct int4
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public object w; // 0x4

	// Properties
	public object Item { get; }

	// Methods

	// RVA: 0x72782D8
	public object .ctor(object x, object y, object z, object w) { }

	// RVA: 0x72782F0
	public object .ctor(object v) { }

	// RVA: 0x7278308
	public object .ctor(object v) { }

	// RVA: 0x7278330
	public static object op_Implicit(object v) { }

	// RVA: 0x7278340
	public static object op_Explicit(object v) { }

	// RVA: 0x7278344
	public static object op_RightShift(object x, object n) { }

	// RVA: 0x7278368
	public object get_Item(object index) { }

	// RVA: 0x727837C
	public object Equals(object rhs) { }

	// RVA: 0x7278404
	public override object Equals(object o) { }

	// RVA: 0x72785AC
	public override object GetHashCode() { }

	// RVA: 0x7278664
	public override object ToString() { }

	// RVA: 0x72789DC
	public object ToString(object format, object formatProvider) { }

}

// Namespace: Unity.Mathematics
public struct quaternion
{

	// Fields
	public object value; // 0xFFFFFFFFFFFFFFF8
	public static readonly object identity; // 0x0

	// Methods

	// RVA: 0x7278D34
	public static object op_Implicit(object q) { }

	// RVA: 0x7278D38
	public static object op_Implicit(object q) { }

	// RVA: 0x7278D3C
	public object .ctor(object x, object y, object z, object w) { }

	// RVA: 0x7278D54
	public object .ctor(object value) { }

	// RVA: 0x7278D6C
	public static object EulerXYZ(object xyz) { }

	// RVA: 0x7278E24
	public static object EulerXYZ(object x, object y, object z) { }

	// RVA: 0x7278EDC
	public object Equals(object x) { }

	// RVA: 0x7278F54
	public override object Equals(object x) { }

	// RVA: 0x72790FC
	public override object GetHashCode() { }

	// RVA: 0x72791AC
	public override object ToString() { }

	// RVA: 0x7279524
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x727987C
	private static object .cctor() { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct uint2
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC

	// Methods

	// RVA: 0x72798D0
	public object .ctor(object x, object y) { }

	// RVA: 0x72798E0
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x72798F8
	public static object op_BitwiseAnd(object lhs, object rhs) { }

	// RVA: 0x727990C
	public object Equals(object rhs) { }

	// RVA: 0x727995C
	public override object Equals(object o) { }

	// RVA: 0x7279AC4
	public override object GetHashCode() { }

	// RVA: 0x7279B2C
	public override object ToString() { }

	// RVA: 0x7279C7C
	public object ToString(object format, object formatProvider) { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct uint3
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0

	// Methods

	// RVA: 0x7279DAC
	public object .ctor(object x, object y, object z) { }

	// RVA: 0x7279DC4
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x7279DE0
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x7279DFC
	public static object op_BitwiseAnd(object lhs, object rhs) { }

	// RVA: 0x7279E14
	public static object op_ExclusiveOr(object lhs, object rhs) { }

	// RVA: 0x7279E20
	public object Equals(object rhs) { }

	// RVA: 0x7279E88
	public override object Equals(object o) { }

	// RVA: 0x727A010
	public override object GetHashCode() { }

	// RVA: 0x727A0A0
	public override object ToString() { }

	// RVA: 0x727A238
	public object ToString(object format, object formatProvider) { }

}

// Namespace: 
internal sealed class DebuggerProxy
{
}

// Namespace: Unity.Mathematics
public struct uint4
{

	// Fields
	public object x; // 0xFFFFFFFFFFFFFFF8
	public object y; // 0xFFFFFFFFFFFFFFFC
	public object z; // 0x0
	public object w; // 0x4
	public static readonly object zero; // 0x0

	// Properties
	public object zw { get; }

	// Methods

	// RVA: 0x727A3A0
	public object .ctor(object x, object y, object z, object w) { }

	// RVA: 0x727A3B8
	public static object op_Multiply(object lhs, object rhs) { }

	// RVA: 0x727A3E4
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x727A410
	public object get_zw() { }

	// RVA: 0x727A420
	public object Equals(object rhs) { }

	// RVA: 0x727A4A8
	public override object Equals(object o) { }

	// RVA: 0x727A650
	public override object GetHashCode() { }

	// RVA: 0x727A708
	public override object ToString() { }

	// RVA: 0x727AA80
	public object ToString(object format, object formatProvider) { }

}

