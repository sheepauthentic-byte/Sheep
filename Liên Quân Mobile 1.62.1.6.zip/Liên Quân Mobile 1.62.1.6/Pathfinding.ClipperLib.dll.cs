// Namespace: 
internal class <Module>
{
}

// Namespace: Pathfinding.ClipperLib
public class PolyTree
{

	// Fields
	internal object m_AllPolys; // 0x30

	// Methods

	// RVA: 0x3CE4288
	public object .ctor() { }

	// RVA: 0x3CE43CC
	protected override object Finalize() { }

	// RVA: 0x3CE445C
	public object Clear() { }

}

// Namespace: Pathfinding.ClipperLib
public class PolyNode
{

	// Fields
	internal object m_Parent; // 0x8
	internal object m_polygon; // 0x10
	internal object m_Index; // 0x18
	internal object m_Childs; // 0x20
	private object <IsOpen>k__BackingField; // 0x28

	// Properties
	public object ChildCount { get; }
	public object Contour { get; }
	public object Childs { get; }
	public object IsOpen { set; }

	// Methods

	// RVA: 0x3CE4304
	public object .ctor() { }

	// RVA: 0x3CE4568
	public object get_ChildCount() { }

	// RVA: 0x3CE45BC
	public object get_Contour() { }

	// RVA: 0x3CE45C4
	internal object AddChild(object Child) { }

	// RVA: 0x3CE46E8
	public object get_Childs() { }

	// RVA: 0x3CE46F0
	public object set_IsOpen(object value) { }

}

// Namespace: Pathfinding.ClipperLib
internal struct Int128
{

	// Fields
	private object hi; // 0xFFFFFFFFFFFFFFF8
	private object lo; // 0x0

	// Methods

	// RVA: 0x3CE46F8
	public object .ctor(object _lo) { }

	// RVA: 0x3CE4710
	public object .ctor(object _hi, object _lo) { }

	// RVA: 0x3CE4720
	public override object Equals(object obj) { }

	// RVA: 0x3CE4888
	public override object GetHashCode() { }

	// RVA: 0x3CE48FC
	public static object Int128Mul(object lhs, object rhs) { }

	// RVA: 0x3CE4970
	public static object op_Equality(object val1, object val2) { }

	// RVA: 0x3CE4A2C
	public static object op_GreaterThan(object val1, object val2) { }

	// RVA: 0x3CE4A44
	public static object op_LessThan(object val1, object val2) { }

	// RVA: 0x3CE4A5C
	public static object op_Addition(object lhs, object rhs) { }

	// RVA: 0x3CE4A68
	public static object op_Subtraction(object lhs, object rhs) { }

	// RVA: 0x3CE4958
	public static object op_UnaryNegation(object val) { }

	// RVA: 0x3CE4A8C
	public static object op_Division(object lhs, object rhs) { }

}

// Namespace: Pathfinding.ClipperLib
public struct IntPoint
{

	// Fields
	public object X; // 0xFFFFFFFFFFFFFFF8
	public object Y; // 0x0

	// Methods

	// RVA: 0x3CE4CE4
	public object .ctor(object X, object Y) { }

	// RVA: 0x3CE4CF4
	public object .ctor(object pt) { }

	// RVA: 0x3CE4D04
	public override object Equals(object obj) { }

	// RVA: 0x3CE4E6C
	public override object GetHashCode() { }

	// RVA: 0x3CE4F4C
	public static object op_Equality(object a, object b) { }

	// RVA: 0x3CE4F5C
	public static object op_Inequality(object a, object b) { }

}

// Namespace: Pathfinding.ClipperLib
public enum ClipType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ctIntersection;
	public const object ctUnion;
	public const object ctDifference;
	public const object ctXor;
}

// Namespace: Pathfinding.ClipperLib
public enum PolyType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object ptSubject;
	public const object ptClip;
}

// Namespace: Pathfinding.ClipperLib
public enum PolyFillType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object pftEvenOdd;
	public const object pftNonZero;
	public const object pftPositive;
	public const object pftNegative;
}

// Namespace: Pathfinding.ClipperLib
internal enum EdgeSide
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object esLeft;
	public const object esRight;
}

// Namespace: Pathfinding.ClipperLib
internal enum Direction
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object dRightToLeft;
	public const object dLeftToRight;
}

// Namespace: Pathfinding.ClipperLib
internal class TEdge
{

	// Fields
	public object Bot; // 0x8
	public object Curr; // 0x18
	public object Top; // 0x28
	public object Delta; // 0x38
	public object Dx; // 0x48
	public object PolyTyp; // 0x50
	public object Side; // 0x54
	public object WindDelta; // 0x58
	public object WindCnt; // 0x5C
	public object WindCnt2; // 0x60
	public object OutIdx; // 0x64
	public object Next; // 0x68
	public object Prev; // 0x70
	public object NextInLML; // 0x78
	public object NextInAEL; // 0x80
	public object PrevInAEL; // 0x88
	public object NextInSEL; // 0x90
	public object PrevInSEL; // 0x98

	// Methods

	// RVA: 0x3CE4F6C
	public object .ctor() { }

}

// Namespace: Pathfinding.ClipperLib
internal class IntersectNode
{

	// Fields
	public object Edge1; // 0x8
	public object Edge2; // 0x10
	public object Pt; // 0x18
	public object Next; // 0x28

	// Methods

	// RVA: 0x3CE4F74
	public object .ctor() { }

}

// Namespace: Pathfinding.ClipperLib
internal class LocalMinima
{

	// Fields
	public object Y; // 0x8
	public object LeftBound; // 0x10
	public object RightBound; // 0x18
	public object Next; // 0x20

	// Methods

	// RVA: 0x3CE4F7C
	public object .ctor() { }

}

// Namespace: Pathfinding.ClipperLib
internal class Scanbeam
{

	// Fields
	public object Y; // 0x8
	public object Next; // 0x10

	// Methods

	// RVA: 0x3CE4F84
	public object .ctor() { }

}

// Namespace: Pathfinding.ClipperLib
internal class OutRec
{

	// Fields
	public object Idx; // 0x8
	public object IsHole; // 0xC
	public object IsOpen; // 0xD
	public object FirstLeft; // 0x10
	public object Pts; // 0x18
	public object BottomPt; // 0x20
	public object PolyNode; // 0x28

	// Methods

	// RVA: 0x3CE4F8C
	public object .ctor() { }

}

// Namespace: Pathfinding.ClipperLib
internal class OutPt
{

	// Fields
	public object Idx; // 0x8
	public object Pt; // 0x10
	public object Next; // 0x20
	public object Prev; // 0x28

	// Methods

	// RVA: 0x3CE4F94
	public object .ctor() { }

}

// Namespace: Pathfinding.ClipperLib
internal class Join
{

	// Fields
	public object OutPt1; // 0x8
	public object OutPt2; // 0x10
	public object OffPt; // 0x18

	// Methods

	// RVA: 0x3CE4F9C
	public object .ctor() { }

}

// Namespace: Pathfinding.ClipperLib
public class ClipperBase
{

	// Fields
	protected const object horizontal;
	protected const object Skip;
	protected const object Unassigned;
	protected const object tolerance;
	internal const object loRange;
	internal const object hiRange;
	internal object m_MinimaList; // 0x8
	internal object m_CurrentLM; // 0x10
	internal object m_edges; // 0x18
	internal object m_UseFullRange; // 0x20
	internal object m_HasOpenPaths; // 0x21
	private object <PreserveCollinear>k__BackingField; // 0x22

	// Properties
	public object PreserveCollinear { get; set; }

	// Methods

	// RVA: 0x3CE4FA4
	internal object .ctor() { }

	// RVA: 0x3CE5030
	public object get_PreserveCollinear() { }

	// RVA: 0x3CE5038
	public object set_PreserveCollinear(object value) { }

	// RVA: 0x3CE5040
	internal static object IsHorizontal(object e) { }

	// RVA: 0x3CE5068
	internal object PointOnLineSegment(object pt, object linePt1, object linePt2, object UseFullRange) { }

	// RVA: 0x3CE52A4
	internal object PointOnPolygon(object pt, object pp, object UseFullRange) { }

	// RVA: 0x3CE5334
	internal object PointInPolygon(object pt, object pp, object UseFullRange) { }

	// RVA: 0x3CE54E8
	internal static object SlopesEqual(object e1, object e2, object UseFullRange) { }

	// RVA: 0x3CE56A8
	protected static object SlopesEqual(object pt1, object pt2, object pt3, object UseFullRange) { }

	// RVA: 0x3CE5830
	public virtual object Clear() { }

	// RVA: 0x3CE5A10
	private object DisposeLocalMinimaList() { }

	// RVA: 0x3CE5A24
	private object RangeTest(object Pt, object useFullRange) { }

	// RVA: 0x3CE5B08
	private object InitEdge(object e, object eNext, object ePrev, object pt) { }

	// RVA: 0x3CE5B34
	private object InitEdge2(object e, object polyType) { }

	// RVA: 0x3CE5C2C
	public object AddPath(object pg, object polyType, object Closed) { }

	// RVA: 0x3CE6F5C
	public object AddPolygon(object pg, object polyType) { }

	// RVA: 0x3CE6870
	internal object Pt2IsBetweenPt1AndPt3(object pt1, object pt2, object pt3) { }

	// RVA: 0x3CE681C
	private object RemoveEdge(object e) { }

	// RVA: 0x3CE6F64
	private object GetLastHorz(object Edge) { }

	// RVA: 0x3CE6B88
	private object SharedVertWithPrevAtTop(object Edge) { }

	// RVA: 0x3CE6FBC
	private object SharedVertWithNextIsBot(object Edge) { }

	// RVA: 0x3CE709C
	private object MoreBelow(object Edge) { }

	// RVA: 0x3CE712C
	private object JustBeforeLocMin(object Edge) { }

	// RVA: 0x3CE7180
	private object MoreAbove(object Edge) { }

	// RVA: 0x3CE68EC
	private object AllHorizontal(object Edge) { }

	// RVA: 0x3CE5BD8
	private object SetDx(object e) { }

	// RVA: 0x3CE7254
	private object DoMinimaLML(object E1, object E2, object IsClosed) { }

	// RVA: 0x3CE74E0
	private object DescendToMin(object E) { }

	// RVA: 0x3CE6944
	private object AscendToMax(object E, object Appending, object IsClosed) { }

	// RVA: 0x3CE6C28
	private object AddBoundsToLML(object E, object Closed) { }

	// RVA: 0x3CE7458
	private object InsertLocalMinima(object newLm) { }

	// RVA: 0x3CE7708
	protected object PopLocalMinima() { }

	// RVA: 0x3CE74B4
	private object ReverseHorizontal(object e) { }

	// RVA: 0x3CE771C
	protected virtual object Reset() { }

}

// Namespace: Pathfinding.ClipperLib
public class Clipper
{

	// Fields
	public const object ioReverseSolution;
	public const object ioStrictlySimple;
	public const object ioPreserveCollinear;
	private object m_PolyOuts; // 0x28
	private object m_ClipType; // 0x30
	private object m_Scanbeam; // 0x38
	private object m_ActiveEdges; // 0x40
	private object m_SortedEdges; // 0x48
	private object m_IntersectNodes; // 0x50
	private object m_ExecuteLocked; // 0x58
	private object m_ClipFillType; // 0x5C
	private object m_SubjFillType; // 0x60
	private object m_Joins; // 0x68
	private object m_GhostJoins; // 0x70
	private object m_UsingPolyTree; // 0x78
	private object <ReverseSolution>k__BackingField; // 0x79
	private object <StrictlySimple>k__BackingField; // 0x7A
	private static object <>f__am$cacheE; // 0x0
	private static object <>f__am$cacheF; // 0x8

	// Properties
	public object ReverseSolution { get; set; }
	public object StrictlySimple { get; set; }

	// Methods

	// RVA: 0x3CE77A4
	public object .ctor(object InitOptions) { }

	// RVA: 0x3CE7924
	public override object Clear() { }

	// RVA: 0x3CE7A44
	protected override object Reset() { }

	// RVA: 0x3CE7C48
	public object get_ReverseSolution() { }

	// RVA: 0x3CE7C50
	public object set_ReverseSolution(object value) { }

	// RVA: 0x3CE7C58
	public object get_StrictlySimple() { }

	// RVA: 0x3CE7C60
	public object set_StrictlySimple(object value) { }

	// RVA: 0x3CE7B04
	private object InsertScanbeam(object Y) { }

	// RVA: 0x3CE7C68
	public object Execute(object clipType, object solution, object subjFillType, object clipFillType) { }

	// RVA: 0x3CE85B8
	public object Execute(object clipType, object polytree, object subjFillType, object clipFillType) { }

	// RVA: 0x3CE8B28
	internal object FixHoleLinkage(object outRec) { }

	// RVA: 0x3CE7DA4
	private object ExecuteInternal() { }

	// RVA: 0x3CE8B90
	private object PopScanbeam() { }

	// RVA: 0x3CE7994
	private object DisposeAllPolyPts() { }

	// RVA: 0x3CEA014
	private object DisposeOutRec(object index) { }

	// RVA: 0x3CEA0E8
	private object DisposeOutPts(object pp) { }

	// RVA: 0x3CEA110
	private object AddJoin(object Op1, object Op2, object OffPt) { }

	// RVA: 0x3CEA298
	private object AddGhostJoin(object Op, object OffPt) { }

	// RVA: 0x3CE8BBC
	private object InsertLocalMinimaIntoAEL(object botY) { }

	// RVA: 0x3CEA410
	private object InsertEdgeIntoAEL(object edge, object startEdge) { }

	// RVA: 0x3CEB5E4
	private object E2InsertsBeforeE1(object e1, object e2) { }

	// RVA: 0x3CEB768
	private object IsEvenOddFillType(object edge) { }

	// RVA: 0x3CEB7A4
	private object IsEvenOddAltFillType(object edge) { }

	// RVA: 0x3CEA770
	private object IsContributing(object edge) { }

	// RVA: 0x3CEA510
	private object SetWindingCount(object edge) { }

	// RVA: 0x3CEAE34
	private object AddEdgeToSEL(object edge) { }

	// RVA: 0x3CEB7E0
	private object CopyAELToSEL() { }

	// RVA: 0x3CEB800
	private object SwapPositionsInAEL(object edge1, object edge2) { }

	// RVA: 0x3CEB8FC
	private object SwapPositionsInSEL(object edge1, object edge2) { }

	// RVA: 0x3CEBA18
	private object AddLocalMaxPoly(object e1, object e2, object pt) { }

	// RVA: 0x3CEABE0
	private object AddLocalMinPoly(object e1, object e2, object pt) { }

	// RVA: 0x3CEBE04
	private object CreateOutRec() { }

	// RVA: 0x3CEA990
	private object AddOutPt(object e, object pt) { }

	// RVA: 0x3CEAE88
	private object HorzSegmentsOverlap(object Pt1a, object Pt1b, object Pt2a, object Pt2b) { }

	// RVA: 0x3CEBFB0
	private object SetHoleState(object e, object outRec) { }

	// RVA: 0x3CEC0AC
	private object GetDx(object pt1, object pt2) { }

	// RVA: 0x3CEC0D4
	private object FirstIsBottomPt(object btmPt1, object btmPt2) { }

	// RVA: 0x3CEC41C
	private object GetBottomPt(object pp) { }

	// RVA: 0x3CEC534
	private object GetLowermostRec(object outRec1, object outRec2) { }

	// RVA: 0x3CEC650
	private object Param1RightOfParam2(object outRec1, object outRec2) { }

	// RVA: 0x3CEC688
	private object GetOutRec(object idx) { }

	// RVA: 0x3CEBAC4
	private object AppendPolygon(object e1, object e2) { }

	// RVA: 0x3CE96B4
	private object ReversePolyPtLinks(object pp) { }

	// RVA: 0x3CEC760
	private static object SwapSides(object edge1, object edge2) { }

	// RVA: 0x3CEC7A0
	private static object SwapPolyIndexes(object edge1, object edge2) { }

	// RVA: 0x3CEAF14
	private object IntersectEdges(object e1, object e2, object pt, object protect) { }

	// RVA: 0x3CEC7E0
	private object DeleteFromAEL(object e) { }

	// RVA: 0x3CEC844
	private object DeleteFromSEL(object e) { }

	// RVA: 0x3CEC8A8
	private object UpdateEdgeIntoAEL(object e) { }

	// RVA: 0x3CE900C
	private object ProcessHorizontals(object isTopOfScanbeam) { }

	// RVA: 0x3CED008
	private object GetHorzDirection(object HorzEdge, object Dir, object Left, object Right) { }

	// RVA: 0x3CED050
	private object PrepareHorzJoins(object horzEdge, object isTopOfScanbeam) { }

	// RVA: 0x3CEC9FC
	private object ProcessHorizontal(object horzEdge, object isTopOfScanbeam) { }

	// RVA: 0x3CED30C
	private object GetNextInAEL(object e, object Direction) { }

	// RVA: 0x3CED35C
	private object IsMaxima(object e, object Y) { }

	// RVA: 0x3CED388
	private object IsIntermediate(object e, object Y) { }

	// RVA: 0x3CED268
	private object GetMaximaPair(object e) { }

	// RVA: 0x3CE908C
	private object ProcessIntersections(object botY, object topY) { }

	// RVA: 0x3CED3C8
	private object BuildIntersectList(object botY, object topY) { }

	// RVA: 0x3CEDDD4
	private object EdgesAdjacent(object inode) { }

	// RVA: 0x3CED804
	private object FixupIntersectionOrder() { }

	// RVA: 0x3CED8E8
	private object ProcessIntersectList() { }

	// RVA: 0x3CEDE80
	internal static object Round(object value) { }

	// RVA: 0x3CEB6F4
	private static object TopX(object edge, object currentY) { }

	// RVA: 0x3CEDD00
	private object InsertIntersectNode(object e1, object e2, object pt) { }

	// RVA: 0x3CEDE30
	private object SwapIntersectNodes(object int1, object int2) { }

	// RVA: 0x3CED95C
	private object IntersectPoint(object edge1, object edge2, object ip) { }

	// RVA: 0x3CED94C
	private object DisposeIntersectNodes() { }

	// RVA: 0x3CE9208
	private object ProcessEdgesAtTopOfScanbeam(object topY) { }

	// RVA: 0x3CEDEB0
	private object DoMaxima(object e) { }

	// RVA: 0x3CEE0E0
	public static object Orientation(object poly) { }

	// RVA: 0x3CEE280
	private object PointCount(object pts) { }

	// RVA: 0x3CE824C
	private object BuildResult(object polyg) { }

	// RVA: 0x3CE8624
	private object BuildResult2(object polytree) { }

	// RVA: 0x3CE9B44
	private object FixupOutPolygon(object outRec) { }

	// RVA: 0x3CEE2BC
	private object DupOutPt(object outPt, object InsertAfter) { }

	// RVA: 0x3CEE3A0
	private object GetOverlap(object a1, object a2, object b1, object b2, object Left, object Right) { }

	// RVA: 0x3CEE4E0
	private object JoinHorz(object op1, object op1b, object op2, object op2b, object Pt, object DiscardLeft) { }

	// RVA: 0x3CEE8A4
	private object JoinPoints(object j, object p1, object p2) { }

	// RVA: 0x3CEEF34
	private object Poly2ContainsPoly1(object outPt1, object outPt2, object UseFullRange) { }

	// RVA: 0x3CEF078
	private object FixupFirstLefts1(object OldOutRec, object NewOutRec) { }

	// RVA: 0x3CEF1AC
	private object FixupFirstLefts2(object OldOutRec, object NewOutRec) { }

	// RVA: 0x3CE96F4
	private object JoinCommonEdges() { }

	// RVA: 0x3CEF350
	private object UpdateOutPtIdxs(object outrec) { }

	// RVA: 0x3CE9D2C
	private object DoSimplePolygons() { }

	// RVA: 0x3CEE0FC
	public static object Area(object poly) { }

	// RVA: 0x3CE9620
	private object Area(object outRec) { }

}

// Namespace: Pathfinding.ClipperLib
internal class ClipperException
{

	// Methods

	// RVA: 0x3CEF39C
	public object .ctor(object description) { }

}

