// Namespace: 
internal class <Module>
{
}

// Namespace: Microsoft.CodeAnalysis
internal sealed class EmbeddedAttribute
{

	// Methods

	// RVA: 0x3C3E598
	public object .ctor() { }

}

// Namespace: System.Runtime.CompilerServices
internal sealed class IsReadOnlyAttribute
{

	// Methods

	// RVA: 0x3C3E5A0
	public object .ctor() { }

}

// Namespace: System.Runtime.CompilerServices
internal sealed class NullableAttribute
{

	// Fields
	public readonly object NullableFlags; // 0x8

	// Methods

	// RVA: 0x3C3E5A8
	public object .ctor(object ) { }

	// RVA: 0x3C3E634
	public object .ctor(object ) { }

}

// Namespace: System.Runtime.CompilerServices
internal sealed class NullableContextAttribute
{

	// Fields
	public readonly object Flag; // 0x8

	// Methods

	// RVA: 0x3C3E660
	public object .ctor(object ) { }

}

// Namespace: System.Diagnostics.CodeAnalysis
internal sealed class NotNullAttribute
{

	// Methods

	// RVA: 0x3C3E68C
	public object .ctor() { }

}

// Namespace: System.Diagnostics.CodeAnalysis
internal sealed class NotNullWhenAttribute
{

	// Fields
	private readonly object <ReturnValue>k__BackingField; // 0x8

	// Methods

	// RVA: 0x3C3E694
	public object .ctor(object returnValue) { }

}

// Namespace: Newtonsoft.Json
public enum ConstructorHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object AllowNonPublicDefaultConstructor;
}

// Namespace: Newtonsoft.Json
public enum DateFormatHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object IsoDateFormat;
	public const object MicrosoftDateFormat;
}

// Namespace: Newtonsoft.Json
public enum DateParseHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object DateTime;
	public const object DateTimeOffset;
}

// Namespace: Newtonsoft.Json
public enum DateTimeZoneHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Local;
	public const object Utc;
	public const object Unspecified;
	public const object RoundtripKind;
}

// Namespace: 
private class Entry
{

	// Fields
	internal readonly object Value; // 0x8
	internal readonly object HashCode; // 0x10
	internal object Next; // 0x18

	// Methods

	// RVA: 0x3C3ED90
	internal object .ctor(object value, object hashCode, object next) { }

}

// Namespace: Newtonsoft.Json
public class DefaultJsonNameTable
{

	// Fields
	private static readonly object HashCodeRandomizer; // 0x0
	private object _count; // 0x8
	private object _entries; // 0x10
	private object _mask; // 0x18

	// Methods

	// RVA: 0x3C3E6C0
	private static object .cctor() { }

	// RVA: 0x3C3E714
	public object .ctor() { }

	// RVA: 0x3C3E790
	public override object Get(object key, object start, object length) { }

	// RVA: 0x3C3EA80
	public object Add(object key) { }

	// RVA: 0x3C3EC68
	private object AddEntry(object str, object hashCode) { }

	// RVA: 0x3C3EDD4
	private object Grow() { }

	// RVA: 0x3C3E984
	private static object TextEquals(object str1, object str2, object str2Start, object str2Length) { }

}

// Namespace: Newtonsoft.Json
public enum DefaultValueHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Include;
	public const object Ignore;
	public const object Populate;
	public const object IgnoreAndPopulate;
}

// Namespace: Newtonsoft.Json
public enum FloatFormatHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object String;
	public const object Symbol;
	public const object DefaultValue;
}

// Namespace: Newtonsoft.Json
public enum FloatParseHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Double;
	public const object Decimal;
}

// Namespace: Newtonsoft.Json
public enum Formatting
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Indented;
}

// Namespace: Newtonsoft.Json
public interface IArrayPool<T0>
{

	// Methods

	// RVA: -1
	public abstract object Rent(object minimumLength) { }

	// RVA: -1
	public abstract object Return(object array) { }

}

// Namespace: Newtonsoft.Json
public interface IJsonLineInfo
{

	// Properties
	public abstract object LineNumber { get; }
	public abstract object LinePosition { get; }

	// Methods

	// RVA: -1
	public abstract object HasLineInfo() { }

	// RVA: -1
	public abstract object get_LineNumber() { }

	// RVA: -1
	public abstract object get_LinePosition() { }

}

// Namespace: Newtonsoft.Json
public sealed class JsonArrayAttribute
{
}

// Namespace: Newtonsoft.Json
public sealed class JsonConstructorAttribute
{
}

// Namespace: Newtonsoft.Json
public abstract class JsonContainerAttribute
{

	// Fields
	private object <ItemConverterType>k__BackingField; // 0x8
	private object <ItemConverterParameters>k__BackingField; // 0x10
	private object <NamingStrategyInstance>k__BackingField; // 0x18
	internal object _isReference; // 0x20
	internal object _itemIsReference; // 0x22
	internal object _itemReferenceLoopHandling; // 0x24
	internal object _itemTypeNameHandling; // 0x2C
	private object _namingStrategyType; // 0x38
	private object _namingStrategyParameters; // 0x40

	// Properties
	public object ItemConverterType { get; }
	public object ItemConverterParameters { get; }
	public object NamingStrategyType { get; }
	public object NamingStrategyParameters { get; }
	internal object NamingStrategyInstance { get; set; }

	// Methods

	// RVA: 0x3C3EF30
	public object get_ItemConverterType() { }

	// RVA: 0x3C3EF38
	public object get_ItemConverterParameters() { }

	// RVA: 0x3C3EF40
	public object get_NamingStrategyType() { }

	// RVA: 0x3C3EF48
	public object get_NamingStrategyParameters() { }

	// RVA: 0x3C3EF50
	internal object get_NamingStrategyInstance() { }

	// RVA: 0x3C3EF58
	internal object set_NamingStrategyInstance(object value) { }

}

// Namespace: Newtonsoft.Json
public static class JsonConvert
{

	// Fields
	private static object <DefaultSettings>k__BackingField; // 0x0
	public static readonly object True; // 0x8
	public static readonly object False; // 0x10
	public static readonly object Null; // 0x18
	public static readonly object Undefined; // 0x20
	public static readonly object PositiveInfinity; // 0x28
	public static readonly object NegativeInfinity; // 0x30
	public static readonly object NaN; // 0x38

	// Properties
	public static object DefaultSettings { get; }

	// Methods

	// RVA: 0x3C3EF60
	public static object get_DefaultSettings() { }

	// RVA: 0x3C3EFDC
	public static object ToString(object value) { }

	// RVA: 0x3C3F054
	public static object ToString(object value) { }

	// RVA: 0x3C3F248
	internal static object ToString(object value, object floatFormatHandling, object quoteChar, object nullable) { }

	// RVA: 0x3C3F430
	private static object EnsureFloatFormat(object value, object text, object floatFormatHandling, object quoteChar, object nullable) { }

	// RVA: 0x3C3F598
	internal static object ToString(object value, object floatFormatHandling, object quoteChar, object nullable) { }

	// RVA: 0x3C3F34C
	private static object EnsureDecimalPlace(object value, object text) { }

	// RVA: 0x3C3F698
	private static object EnsureDecimalPlace(object text) { }

	// RVA: 0x3C3F720
	public static object ToString(object value) { }

	// RVA: 0x3C3F128
	public static object ToString(object value) { }

	// RVA: 0x3C3F894
	public static object ToString(object value, object delimiter) { }

	// RVA: 0x3C3F900
	public static object ToString(object value, object delimiter, object stringEscapeHandling) { }

	// RVA: 0x3C3F9E4
	public static object SerializeObject(object value) { }

	// RVA: 0x3C3FAB4
	public static object SerializeObject(object value, object type, object settings) { }

	// RVA: 0x3C3FB78
	private static object SerializeObjectInternal(object value, object type, object jsonSerializer) { }

	// RVA: 0x3C40110
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json
public abstract class JsonConverter
{

	// Properties
	public virtual object CanRead { get; }
	public virtual object CanWrite { get; }

	// Methods

	// RVA: -1
	public abstract object WriteJson(object writer, object value, object serializer) { }

	// RVA: -1
	public abstract object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: -1
	public abstract object CanConvert(object objectType) { }

	// RVA: 0x3C40230
	public virtual object get_CanRead() { }

	// RVA: 0x3C40238
	public virtual object get_CanWrite() { }

	// RVA: 0x3C40240
	protected object .ctor() { }

}

// Namespace: Newtonsoft.Json
public sealed class JsonConverterAttribute
{

	// Fields
	private readonly object _converterType; // 0x8
	private readonly object <ConverterParameters>k__BackingField; // 0x10

	// Properties
	public object ConverterType { get; }
	public object ConverterParameters { get; }

	// Methods

	// RVA: 0x3C40248
	public object get_ConverterType() { }

	// RVA: 0x3C40250
	public object get_ConverterParameters() { }

}

// Namespace: Newtonsoft.Json
public class JsonConverterCollection
{

	// Methods

	// RVA: 0x3C40258
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json
public sealed class JsonDictionaryAttribute
{
}

// Namespace: Newtonsoft.Json
public class JsonException
{

	// Methods

	// RVA: 0x3C402B0
	public object .ctor() { }

	// RVA: 0x3C40338
	public object .ctor(object message) { }

	// RVA: 0x3C403A4
	public object .ctor(object message, object innerException) { }

	// RVA: 0x3C40420
	public object .ctor(object info, object context) { }

}

// Namespace: Newtonsoft.Json
public class JsonExtensionDataAttribute
{

	// Fields
	private object <WriteData>k__BackingField; // 0x8
	private object <ReadData>k__BackingField; // 0x9

	// Properties
	public object WriteData { get; }
	public object ReadData { get; }

	// Methods

	// RVA: 0x3C404A4
	public object get_WriteData() { }

	// RVA: 0x3C404AC
	public object get_ReadData() { }

}

// Namespace: Newtonsoft.Json
public sealed class JsonIgnoreAttribute
{
}

// Namespace: Newtonsoft.Json
public abstract class JsonNameTable
{

	// Methods

	// RVA: -1
	public abstract object Get(object key, object start, object length) { }

	// RVA: 0x3C3E788
	protected object .ctor() { }

}

// Namespace: Newtonsoft.Json
public sealed class JsonObjectAttribute
{

	// Fields
	private object _memberSerialization; // 0x48
	internal object _missingMemberHandling; // 0x4C
	internal object _itemRequired; // 0x54
	internal object _itemNullValueHandling; // 0x5C

	// Properties
	public object MemberSerialization { get; }

	// Methods

	// RVA: 0x3C404B4
	public object get_MemberSerialization() { }

}

// Namespace: Newtonsoft.Json
internal enum JsonContainerType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Object;
	public const object Array;
	public const object Constructor;
}

// Namespace: Newtonsoft.Json
internal struct JsonPosition
{

	// Fields
	private static readonly object SpecialCharacters; // 0x0
	internal object Type; // 0xFFFFFFFFFFFFFFF8
	internal object Position; // 0xFFFFFFFFFFFFFFFC
	internal object PropertyName; // 0x0
	internal object HasIndex; // 0x8

	// Methods

	// RVA: 0x3C4056C
	public object .ctor(object type) { }

	// RVA: 0x3C4067C
	internal object CalculateLength() { }

	// RVA: 0x3C40734
	internal object WriteTo(object sb, object writer, object buffer) { }

	// RVA: 0x3C405EC
	internal static object TypeHasIndex(object type) { }

	// RVA: 0x3C409A4
	internal static object BuildPath(object positions, object currentPosition) { }

	// RVA: 0x3C40D18
	internal static object FormatMessage(object lineInfo, object path, object message) { }

	// RVA: 0x3C410A0
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json
public sealed class JsonPropertyAttribute
{

	// Fields
	internal object _nullValueHandling; // 0x8
	internal object _defaultValueHandling; // 0x10
	internal object _referenceLoopHandling; // 0x18
	internal object _objectCreationHandling; // 0x20
	internal object _typeNameHandling; // 0x28
	internal object _isReference; // 0x30
	internal object _order; // 0x34
	internal object _required; // 0x3C
	internal object _itemIsReference; // 0x44
	internal object _itemReferenceLoopHandling; // 0x48
	internal object _itemTypeNameHandling; // 0x50
	private object <ItemConverterType>k__BackingField; // 0x58
	private object <ItemConverterParameters>k__BackingField; // 0x60
	private object <NamingStrategyType>k__BackingField; // 0x68
	private object <NamingStrategyParameters>k__BackingField; // 0x70
	private object <PropertyName>k__BackingField; // 0x78

	// Properties
	public object ItemConverterType { get; }
	public object ItemConverterParameters { get; }
	public object NamingStrategyType { get; }
	public object NamingStrategyParameters { get; }
	public object PropertyName { get; }

	// Methods

	// RVA: 0x3C41138
	public object get_ItemConverterType() { }

	// RVA: 0x3C41140
	public object get_ItemConverterParameters() { }

	// RVA: 0x3C41148
	public object get_NamingStrategyType() { }

	// RVA: 0x3C41150
	public object get_NamingStrategyParameters() { }

	// RVA: 0x3C41158
	public object get_PropertyName() { }

}

// Namespace: 
protected internal enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object Complete;
	public const object Property;
	public const object ObjectStart;
	public const object Object;
	public const object ArrayStart;
	public const object Array;
	public const object Closed;
	public const object PostValue;
	public const object ConstructorStart;
	public const object Constructor;
	public const object Error;
	public const object Finished;
}

// Namespace: Newtonsoft.Json
public abstract class JsonReader
{

	// Fields
	private object _tokenType; // 0x8
	private object _value; // 0x10
	internal object _quoteChar; // 0x18
	internal object _currentState; // 0x1C
	private object _currentPosition; // 0x20
	private object _culture; // 0x38
	private object _dateTimeZoneHandling; // 0x40
	private object _maxDepth; // 0x44
	private object _hasExceededMaxDepth; // 0x4C
	internal object _dateParseHandling; // 0x50
	internal object _floatParseHandling; // 0x54
	private object _dateFormatString; // 0x58
	private object _stack; // 0x60
	private object <CloseInput>k__BackingField; // 0x68
	private object <SupportMultipleContent>k__BackingField; // 0x69

	// Properties
	protected object CurrentState { get; }
	public object CloseInput { get; set; }
	public object SupportMultipleContent { get; set; }
	public object DateTimeZoneHandling { get; set; }
	public object DateParseHandling { get; set; }
	public object FloatParseHandling { get; set; }
	public object DateFormatString { get; set; }
	public object MaxDepth { get; set; }
	public virtual object TokenType { get; }
	public virtual object Value { get; }
	public virtual object ValueType { get; }
	public virtual object Depth { get; }
	public virtual object Path { get; }
	public object Culture { get; set; }

	// Methods

	// RVA: 0x3C41160
	protected object get_CurrentState() { }

	// RVA: 0x3C41168
	public object get_CloseInput() { }

	// RVA: 0x3C41170
	public object set_CloseInput(object value) { }

	// RVA: 0x3C41178
	public object get_SupportMultipleContent() { }

	// RVA: 0x3C41180
	public object set_SupportMultipleContent(object value) { }

	// RVA: 0x3C41188
	public object get_DateTimeZoneHandling() { }

	// RVA: 0x3C41190
	public object set_DateTimeZoneHandling(object value) { }

	// RVA: 0x3C411F4
	public object get_DateParseHandling() { }

	// RVA: 0x3C411FC
	public object set_DateParseHandling(object value) { }

	// RVA: 0x3C41260
	public object get_FloatParseHandling() { }

	// RVA: 0x3C41268
	public object set_FloatParseHandling(object value) { }

	// RVA: 0x3C412CC
	public object get_DateFormatString() { }

	// RVA: 0x3C412D4
	public object set_DateFormatString(object value) { }

	// RVA: 0x3C412DC
	public object get_MaxDepth() { }

	// RVA: 0x3C412E4
	public object set_MaxDepth(object value) { }

	// RVA: 0x3C413A8
	public virtual object get_TokenType() { }

	// RVA: 0x3C413B0
	public virtual object get_Value() { }

	// RVA: 0x3C413B8
	public virtual object get_ValueType() { }

	// RVA: 0x3C413CC
	public virtual object get_Depth() { }

	// RVA: 0x3C4146C
	public virtual object get_Path() { }

	// RVA: 0x3C4159C
	public object get_Culture() { }

	// RVA: 0x3C41618
	public object set_Culture(object value) { }

	// RVA: 0x3C41620
	internal object GetPosition(object depth) { }

	// RVA: 0x3C416C0
	protected object .ctor() { }

	// RVA: 0x3C4175C
	private object Push(object value) { }

	// RVA: 0x3C41BD4
	private object Pop() { }

	// RVA: 0x3C41D28
	private object Peek() { }

	// RVA: -1
	public abstract object Read() { }

	// RVA: 0x3C41D30
	public virtual object ReadAsInt32() { }

	// RVA: 0x3C4253C
	internal object ReadInt32String(object s) { }

	// RVA: 0x3C42794
	public virtual object ReadAsString() { }

	// RVA: 0x3C42BB0
	public virtual object ReadAsBytes() { }

	// RVA: 0x3C435B4
	internal object ReadArrayIntoByteArray() { }

	// RVA: 0x3C4375C
	private object ReadArrayElementIntoByteArrayReportDone(object buffer) { }

	// RVA: 0x3C43A18
	public virtual object ReadAsDouble() { }

	// RVA: 0x3C43DDC
	internal object ReadDoubleString(object s) { }

	// RVA: 0x3C44034
	public virtual object ReadAsBoolean() { }

	// RVA: 0x3C44478
	internal object ReadBooleanString(object s) { }

	// RVA: 0x3C44670
	public virtual object ReadAsDecimal() { }

	// RVA: 0x3C44BC0
	internal object ReadDecimalString(object s) { }

	// RVA: 0x3C44EC0
	public virtual object ReadAsDateTime() { }

	// RVA: 0x3C4525C
	internal object ReadDateTimeString(object s) { }

	// RVA: 0x3C455E0
	public virtual object ReadAsDateTimeOffset() { }

	// RVA: 0x3C45964
	internal object ReadDateTimeOffsetString(object s) { }

	// RVA: 0x3C4354C
	internal object ReaderReadAndAssert() { }

	// RVA: 0x3C45CB4
	internal object CreateUnexpectedEndException() { }

	// RVA: 0x3C43200
	internal object ReadIntoWrappedTypeObject() { }

	// RVA: 0x3C45D90
	public object Skip() { }

	// RVA: 0x3C43750
	protected object SetToken(object newToken) { }

	// RVA: 0x3C45EB0
	protected object SetToken(object newToken, object value) { }

	// RVA: 0x3C42314
	protected object SetToken(object newToken, object value, object updateIndex) { }

	// RVA: 0x3C45FD8
	internal object SetPostValueState(object updateIndex) { }

	// RVA: 0x3C41B18
	private object UpdateScopeWithFinishedValue() { }

	// RVA: 0x3C45EB8
	private object ValidateEnd(object endToken) { }

	// RVA: 0x3C46104
	protected object SetStateBasedOnCurrent() { }

	// RVA: 0x3C46024
	private object SetFinished() { }

	// RVA: 0x3C46054
	private object GetTypeForCloseToken(object token) { }

	// RVA: 0x3C46240
	private object System.IDisposable.Dispose() { }

	// RVA: 0x3C462DC
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x3C46334
	public virtual object Close() { }

	// RVA: 0x3C46348
	internal object ReadAndAssert() { }

	// RVA: 0x3C46460
	internal object ReadForTypeAndAssert(object contract, object hasConverter) { }

	// RVA: 0x3C464B8
	internal object ReadForType(object contract, object hasConverter) { }

	// RVA: 0x3C468B0
	internal object ReadAndMoveToContent() { }

	// RVA: 0x3C46954
	internal object MoveToContent() { }

	// RVA: 0x3C421C4
	private object GetContentToken() { }

}

// Namespace: Newtonsoft.Json
public class JsonReaderException
{

	// Fields
	private readonly object <LineNumber>k__BackingField; // 0x84
	private readonly object <LinePosition>k__BackingField; // 0x88
	private readonly object <Path>k__BackingField; // 0x90

	// Methods

	// RVA: 0x3C469F4
	public object .ctor() { }

	// RVA: 0x3C46A7C
	public object .ctor(object info, object context) { }

	// RVA: 0x3C46B00
	public object .ctor(object message, object path, object lineNumber, object linePosition, object innerException) { }

	// RVA: 0x3C41B34
	internal static object Create(object reader, object message) { }

	// RVA: 0x3C42268
	internal static object Create(object reader, object message, object ex) { }

	// RVA: 0x3C46B9C
	internal static object Create(object lineInfo, object path, object message, object ex) { }

}

// Namespace: Newtonsoft.Json
public sealed class JsonRequiredAttribute
{
}

// Namespace: Newtonsoft.Json
public class JsonSerializationException
{

	// Fields
	private readonly object <LineNumber>k__BackingField; // 0x84
	private readonly object <LinePosition>k__BackingField; // 0x88
	private readonly object <Path>k__BackingField; // 0x90

	// Methods

	// RVA: 0x3C46E3C
	public object .ctor() { }

	// RVA: 0x3C46EC4
	public object .ctor(object message) { }

	// RVA: 0x3C46F30
	public object .ctor(object message, object innerException) { }

	// RVA: 0x3C46FAC
	public object .ctor(object info, object context) { }

	// RVA: 0x3C47030
	public object .ctor(object message, object path, object lineNumber, object linePosition, object innerException) { }

	// RVA: 0x3C463C0
	internal static object Create(object reader, object message) { }

	// RVA: 0x3C470CC
	internal static object Create(object reader, object message, object ex) { }

	// RVA: 0x3C47178
	internal static object Create(object lineInfo, object path, object message, object ex) { }

}

// Namespace: Newtonsoft.Json
public class JsonSerializer
{

	// Fields
	internal object _typeNameHandling; // 0x8
	internal object _typeNameAssemblyFormatHandling; // 0xC
	internal object _preserveReferencesHandling; // 0x10
	internal object _referenceLoopHandling; // 0x14
	internal object _missingMemberHandling; // 0x18
	internal object _objectCreationHandling; // 0x1C
	internal object _nullValueHandling; // 0x20
	internal object _defaultValueHandling; // 0x24
	internal object _constructorHandling; // 0x28
	internal object _metadataPropertyHandling; // 0x2C
	internal object _converters; // 0x30
	internal object _contractResolver; // 0x38
	internal object _traceWriter; // 0x40
	internal object _equalityComparer; // 0x48
	internal object _serializationBinder; // 0x50
	internal object _context; // 0x58
	private object _referenceResolver; // 0x68
	private object _formatting; // 0x70
	private object _dateFormatHandling; // 0x78
	private object _dateTimeZoneHandling; // 0x80
	private object _dateParseHandling; // 0x88
	private object _floatFormatHandling; // 0x90
	private object _floatParseHandling; // 0x98
	private object _stringEscapeHandling; // 0xA0
	private object _culture; // 0xA8
	private object _maxDepth; // 0xB0
	private object _maxDepthSet; // 0xB8
	private object _checkAdditionalContent; // 0xB9
	private object _dateFormatString; // 0xC0
	private object _dateFormatStringSet; // 0xC8
	private object Error; // 0xD0

	// Properties
	public virtual object ReferenceResolver { set; }
	public virtual object SerializationBinder { set; }
	public virtual object TraceWriter { get; set; }
	public virtual object EqualityComparer { set; }
	public virtual object TypeNameHandling { set; }
	public virtual object TypeNameAssemblyFormatHandling { set; }
	public virtual object PreserveReferencesHandling { set; }
	public virtual object ReferenceLoopHandling { set; }
	public virtual object MissingMemberHandling { set; }
	public virtual object NullValueHandling { get; set; }
	public virtual object DefaultValueHandling { set; }
	public virtual object ObjectCreationHandling { set; }
	public virtual object ConstructorHandling { set; }
	public virtual object MetadataPropertyHandling { get; set; }
	public virtual object Converters { get; }
	public virtual object ContractResolver { get; set; }
	public virtual object Context { get; set; }
	public virtual object Formatting { get; }
	public virtual object CheckAdditionalContent { get; }

	// Methods

	// RVA: 0x3C47418
	public virtual object add_Error(object value) { }

	// RVA: 0x3C474CC
	public virtual object remove_Error(object value) { }

	// RVA: 0x3C47580
	public virtual object set_ReferenceResolver(object value) { }

	// RVA: 0x3C475F4
	public virtual object set_SerializationBinder(object value) { }

	// RVA: 0x3C47668
	public virtual object get_TraceWriter() { }

	// RVA: 0x3C47670
	public virtual object set_TraceWriter(object value) { }

	// RVA: 0x3C47678
	public virtual object set_EqualityComparer(object value) { }

	// RVA: 0x3C47680
	public virtual object set_TypeNameHandling(object value) { }

	// RVA: 0x3C476E4
	public virtual object set_TypeNameAssemblyFormatHandling(object value) { }

	// RVA: 0x3C47748
	public virtual object set_PreserveReferencesHandling(object value) { }

	// RVA: 0x3C477AC
	public virtual object set_ReferenceLoopHandling(object value) { }

	// RVA: 0x3C47810
	public virtual object set_MissingMemberHandling(object value) { }

	// RVA: 0x3C47874
	public virtual object get_NullValueHandling() { }

	// RVA: 0x3C4787C
	public virtual object set_NullValueHandling(object value) { }

	// RVA: 0x3C478E0
	public virtual object set_DefaultValueHandling(object value) { }

	// RVA: 0x3C47944
	public virtual object set_ObjectCreationHandling(object value) { }

	// RVA: 0x3C479A8
	public virtual object set_ConstructorHandling(object value) { }

	// RVA: 0x3C47A0C
	public virtual object get_MetadataPropertyHandling() { }

	// RVA: 0x3C47A14
	public virtual object set_MetadataPropertyHandling(object value) { }

	// RVA: 0x3C47A78
	public virtual object get_Converters() { }

	// RVA: 0x3C47B30
	public virtual object get_ContractResolver() { }

	// RVA: 0x3C47B38
	public virtual object set_ContractResolver(object value) { }

	// RVA: 0x3C47C1C
	public virtual object get_Context() { }

	// RVA: 0x3C47C28
	public virtual object set_Context(object value) { }

	// RVA: 0x3C47C30
	public virtual object get_Formatting() { }

	// RVA: 0x3C47C70
	public virtual object get_CheckAdditionalContent() { }

	// RVA: 0x3C47CB0
	public object .ctor() { }

	// RVA: 0x3C47DFC
	public static object Create() { }

	// RVA: 0x3C47E50
	public static object Create(object settings) { }

	// RVA: 0x3C48ACC
	public static object CreateDefault() { }

	// RVA: 0x3C3FB44
	public static object CreateDefault(object settings) { }

	// RVA: 0x3C47EC0
	private static object ApplySerializerSettings(object serializer, object settings) { }

	// RVA: -1
	public object Deserialize(object reader) { }

	// RVA: 0x3C48F34
	public object Deserialize(object reader, object objectType) { }

	// RVA: 0x3C48F90
	internal virtual object DeserializeInternal(object reader, object objectType) { }

	// RVA: 0x3C492C8
	private object SetupReader(object reader, object previousCulture, object previousDateTimeZoneHandling, object previousDateParseHandling, object previousFloatParseHandling, object previousMaxDepth, object previousDateFormatString) { }

	// RVA: 0x3C49964
	private object ResetReader(object reader, object previousCulture, object previousDateTimeZoneHandling, object previousDateParseHandling, object previousFloatParseHandling, object previousMaxDepth, object previousDateFormatString) { }

	// RVA: 0x3C400AC
	public object Serialize(object jsonWriter, object value, object objectType) { }

	// RVA: 0x3C49C88
	public object Serialize(object jsonWriter, object value) { }

	// RVA: 0x3C498A8
	private object CreateTraceJsonReader(object reader) { }

	// RVA: 0x3C49CE8
	internal virtual object SerializeInternal(object jsonWriter, object value, object objectType) { }

	// RVA: 0x3C4A840
	internal object GetReferenceResolver() { }

	// RVA: 0x3C4A8BC
	internal object GetMatchingConverter(object type) { }

	// RVA: 0x3C4A8C4
	internal static object GetMatchingConverter(object converters, object objectType) { }

	// RVA: 0x3C4AAA8
	internal object OnError(object e) { }

}

// Namespace: Newtonsoft.Json
public class JsonSerializerSettings
{

	// Fields
	internal static readonly object DefaultContext; // 0x0
	internal static readonly object DefaultCulture; // 0x10
	internal object _formatting; // 0x8
	internal object _dateFormatHandling; // 0x10
	internal object _dateTimeZoneHandling; // 0x18
	internal object _dateParseHandling; // 0x20
	internal object _floatFormatHandling; // 0x28
	internal object _floatParseHandling; // 0x30
	internal object _stringEscapeHandling; // 0x38
	internal object _culture; // 0x40
	internal object _checkAdditionalContent; // 0x48
	internal object _maxDepth; // 0x4C
	internal object _maxDepthSet; // 0x54
	internal object _dateFormatString; // 0x58
	internal object _dateFormatStringSet; // 0x60
	internal object _typeNameAssemblyFormatHandling; // 0x64
	internal object _defaultValueHandling; // 0x6C
	internal object _preserveReferencesHandling; // 0x74
	internal object _nullValueHandling; // 0x7C
	internal object _objectCreationHandling; // 0x84
	internal object _missingMemberHandling; // 0x8C
	internal object _referenceLoopHandling; // 0x94
	internal object _context; // 0xA0
	internal object _constructorHandling; // 0xB8
	internal object _typeNameHandling; // 0xC0
	internal object _metadataPropertyHandling; // 0xC8
	private object <Converters>k__BackingField; // 0xD0
	private object <ContractResolver>k__BackingField; // 0xD8
	private object <EqualityComparer>k__BackingField; // 0xE0
	private object <ReferenceResolverProvider>k__BackingField; // 0xE8
	private object <TraceWriter>k__BackingField; // 0xF0
	private object <SerializationBinder>k__BackingField; // 0xF8
	private object <Error>k__BackingField; // 0x100

	// Properties
	public object ReferenceLoopHandling { get; }
	public object MissingMemberHandling { get; }
	public object ObjectCreationHandling { get; }
	public object NullValueHandling { get; }
	public object DefaultValueHandling { get; }
	public object Converters { get; }
	public object PreserveReferencesHandling { get; }
	public object TypeNameHandling { get; }
	public object MetadataPropertyHandling { get; }
	public object TypeNameAssemblyFormatHandling { get; }
	public object ConstructorHandling { get; }
	public object ContractResolver { get; }
	public object EqualityComparer { get; }
	public object ReferenceResolverProvider { get; }
	public object TraceWriter { get; }
	public object SerializationBinder { get; }
	public object Error { get; }
	public object Context { get; }

	// Methods

	// RVA: 0x3C48D10
	public object get_ReferenceLoopHandling() { }

	// RVA: 0x3C48D50
	public object get_MissingMemberHandling() { }

	// RVA: 0x3C48D90
	public object get_ObjectCreationHandling() { }

	// RVA: 0x3C48DD0
	public object get_NullValueHandling() { }

	// RVA: 0x3C48E10
	public object get_DefaultValueHandling() { }

	// RVA: 0x3C4AACC
	public object get_Converters() { }

	// RVA: 0x3C48CD0
	public object get_PreserveReferencesHandling() { }

	// RVA: 0x3C48C10
	public object get_TypeNameHandling() { }

	// RVA: 0x3C48C50
	public object get_MetadataPropertyHandling() { }

	// RVA: 0x3C48C90
	public object get_TypeNameAssemblyFormatHandling() { }

	// RVA: 0x3C48E50
	public object get_ConstructorHandling() { }

	// RVA: 0x3C4AAD4
	public object get_ContractResolver() { }

	// RVA: 0x3C4AADC
	public object get_EqualityComparer() { }

	// RVA: 0x3C4AAE4
	public object get_ReferenceResolverProvider() { }

	// RVA: 0x3C4AAEC
	public object get_TraceWriter() { }

	// RVA: 0x3C4AAF4
	public object get_SerializationBinder() { }

	// RVA: 0x3C4AAFC
	public object get_Error() { }

	// RVA: 0x3C48E90
	public object get_Context() { }

	// RVA: 0x3C4AB04
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json
public class JsonTextReader
{

	// Fields
	private readonly object _safeAsync; // 0x6A
	private readonly object _reader; // 0x70
	private object _chars; // 0x78
	private object _charsUsed; // 0x80
	private object _charPos; // 0x84
	private object _lineStartPos; // 0x88
	private object _lineNumber; // 0x8C
	private object _isEndOfFile; // 0x90
	private object _stringBuffer; // 0x98
	private object _stringReference; // 0xA8
	private object _arrayPool; // 0xB8
	private object <PropertyNameTable>k__BackingField; // 0xC0

	// Properties
	public object PropertyNameTable { get; set; }
	public object LineNumber { get; }
	public object LinePosition { get; }

	// Methods

	// RVA: 0x3C4AB90
	public object .ctor(object reader) { }

	// RVA: 0x3C4AD04
	public object get_PropertyNameTable() { }

	// RVA: 0x3C4AD0C
	public object set_PropertyNameTable(object value) { }

	// RVA: 0x3C4AD14
	private object EnsureBufferNotEmpty() { }

	// RVA: 0x3C4AD68
	private object SetNewLine(object hasNextChar) { }

	// RVA: 0x3C4ADE4
	private object OnNewLine(object pos) { }

	// RVA: 0x3C4ADF4
	private object ParseString(object quote, object readType) { }

	// RVA: 0x3C4B760
	private object ParseReadString(object quote, object readType) { }

	// RVA: 0x3C4BCA4
	private static object BlockCopyChars(object src, object srcOffset, object dst, object dstOffset, object count) { }

	// RVA: 0x3C4AE48
	private object ShiftBufferIfNeeded() { }

	// RVA: 0x3C4BCB8
	private object ReadData(object append) { }

	// RVA: 0x3C4BDB8
	private object PrepareBufferForReadData(object append, object charsRequired) { }

	// RVA: 0x3C4BCC0
	private object ReadData(object append, object charsRequired) { }

	// RVA: 0x3C4BF6C
	private object EnsureChars(object relativePosition, object append) { }

	// RVA: 0x3C4BFF8
	private object ReadChars(object relativePosition, object append) { }

	// RVA: 0x3C4C06C
	public override object Read() { }

	// RVA: 0x3C4D7A4
	public override object ReadAsInt32() { }

	// RVA: 0x3C4DEA4
	public override object ReadAsDateTime() { }

	// RVA: 0x3C4E6CC
	public override object ReadAsString() { }

	// RVA: 0x3C4E738
	public override object ReadAsBytes() { }

	// RVA: 0x3C4DF68
	private object ReadStringValue(object readType) { }

	// RVA: 0x3C4F3B0
	private object FinishReadQuotedStringValue(object readType) { }

	// RVA: 0x3C4EFF0
	private object CreateUnexpectedCharacterException(object c) { }

	// RVA: 0x3C4FAC4
	public override object ReadAsBoolean() { }

	// RVA: 0x3C4EF88
	private object ProcessValueComma() { }

	// RVA: 0x3C4D868
	private object ReadNumberValue(object readType) { }

	// RVA: 0x3C50280
	private object FinishReadQuotedNumber(object readType) { }

	// RVA: 0x3C5040C
	public override object ReadAsDateTimeOffset() { }

	// RVA: 0x3C50490
	public override object ReadAsDecimal() { }

	// RVA: 0x3C50514
	public override object ReadAsDouble() { }

	// RVA: 0x3C4EE74
	private object HandleNull() { }

	// RVA: 0x3C4F220
	private object ReadFinished() { }

	// RVA: 0x3C4EE08
	private object ReadNullChar() { }

	// RVA: 0x3C4C314
	private object EnsureBuffer() { }

	// RVA: 0x3C4AF38
	private object ReadStringIntoBuffer(object quote) { }

	// RVA: 0x3C50834
	private object FinishReadStringIntoBuffer(object charPos, object initialPosition, object lastWritePosition) { }

	// RVA: 0x3C507E0
	private object WriteCharToBuffer(object writeChar, object lastWritePosition, object writeToPosition) { }

	// RVA: 0x3C50900
	private object ConvertUnicode(object enoughChars) { }

	// RVA: 0x3C5073C
	private object ParseUnicode() { }

	// RVA: 0x3C50A60
	private object ReadNumberIntoBuffer() { }

	// RVA: 0x3C50AF8
	private object ReadNumberCharIntoBuffer(object currentChar, object charPos) { }

	// RVA: 0x3C50C90
	private object ClearRecentString() { }

	// RVA: 0x3C4CD10
	private object ParsePostValue(object ignoreComments) { }

	// RVA: 0x3C4CAC4
	private object ParseObject() { }

	// RVA: 0x3C50C9C
	private object ParseProperty() { }

	// RVA: 0x3C50FE4
	private object ValidIdentifierChar(object value) { }

	// RVA: 0x3C5105C
	private object ParseUnquotedProperty() { }

	// RVA: 0x3C5114C
	private object ReadUnquotedPropertyReportIfDone(object currentChar, object initialPosition) { }

	// RVA: 0x3C4C37C
	private object ParseValue() { }

	// RVA: 0x3C4F204
	private object ProcessLineFeed() { }

	// RVA: 0x3C4F138
	private object ProcessCarriageReturn(object append) { }

	// RVA: 0x3C4D108
	private object EatWhitespace() { }

	// RVA: 0x3C51674
	private object ParseConstructor() { }

	// RVA: 0x3C4F718
	private object ParseNumber(object readType) { }

	// RVA: 0x3C51BB4
	private object ParseReadNumber(object readType, object firstChar, object initialPosition) { }

	// RVA: 0x3C52E70
	private object ThrowReaderError(object message, object ex) { }

	// RVA: 0x3C52F98
	private static object BigIntegerParse(object number, object culture) { }

	// RVA: 0x3C4D374
	private object ParseComment(object setToken) { }

	// RVA: 0x3C53020
	private object EndComment(object setToken, object initialPosition, object endPosition) { }

	// RVA: 0x3C5308C
	private object MatchValue(object value) { }

	// RVA: 0x3C53154
	private object MatchValue(object enoughChars, object value) { }

	// RVA: 0x3C4F800
	private object MatchValueWithTrailingSeparator(object value) { }

	// RVA: 0x3C53248
	private object IsSeparator(object c) { }

	// RVA: 0x3C51344
	private object ParseTrue() { }

	// RVA: 0x3C505D8
	private object ParseNull() { }

	// RVA: 0x3C51A54
	private object ParseUndefined() { }

	// RVA: 0x3C514DC
	private object ParseFalse() { }

	// RVA: 0x3C4F698
	private object ParseNumberNegativeInfinity(object readType) { }

	// RVA: 0x3C53428
	private object ParseNumberNegativeInfinity(object readType, object matched) { }

	// RVA: 0x3C4F9C4
	private object ParseNumberPositiveInfinity(object readType) { }

	// RVA: 0x3C5368C
	private object ParseNumberPositiveInfinity(object readType, object matched) { }

	// RVA: 0x3C4FA44
	private object ParseNumberNaN(object readType) { }

	// RVA: 0x3C538F0
	private object ParseNumberNaN(object readType, object matched) { }

	// RVA: 0x3C53B54
	public override object Close() { }

	// RVA: 0x3C53BDC
	public object HasLineInfo() { }

	// RVA: 0x3C53BE4
	public object get_LineNumber() { }

	// RVA: 0x3C53C58
	public object get_LinePosition() { }

}

// Namespace: Newtonsoft.Json
internal enum ReadType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Read;
	public const object ReadAsInt32;
	public const object ReadAsInt64;
	public const object ReadAsBytes;
	public const object ReadAsString;
	public const object ReadAsDecimal;
	public const object ReadAsDateTime;
	public const object ReadAsDateTimeOffset;
	public const object ReadAsDouble;
	public const object ReadAsBoolean;
}

// Namespace: Newtonsoft.Json
public class JsonTextWriter
{

	// Fields
	private readonly object _safeAsync; // 0x58
	private readonly object _writer; // 0x60
	private object _base64Encoder; // 0x68
	private object _indentChar; // 0x70
	private object _indentation; // 0x74
	private object _quoteChar; // 0x78
	private object _quoteName; // 0x7A
	private object _charEscapeFlags; // 0x80
	private object _writeBuffer; // 0x88
	private object _arrayPool; // 0x90
	private object _indentChars; // 0x98

	// Properties
	private object Base64Encoder { get; }
	public object QuoteChar { get; }

	// Methods

	// RVA: 0x3C53C64
	private object get_Base64Encoder() { }

	// RVA: 0x3C53CF4
	public object get_QuoteChar() { }

	// RVA: 0x3C3FE94
	public object .ctor(object textWriter) { }

	// RVA: 0x3C53DAC
	public override object Close() { }

	// RVA: 0x3C53F50
	private object CloseBufferAndWriter() { }

	// RVA: 0x3C53FC4
	public override object WriteStartObject() { }

	// RVA: 0x3C54094
	public override object WriteStartArray() { }

	// RVA: 0x3C5411C
	public override object WriteStartConstructor(object name) { }

	// RVA: 0x3C5425C
	protected override object WriteEnd(object token) { }

	// RVA: 0x3C543EC
	public override object WritePropertyName(object name) { }

	// RVA: 0x3C54600
	public override object WritePropertyName(object name, object escape) { }

	// RVA: 0x3C5480C
	internal override object OnStringEscapeHandlingChanged() { }

	// RVA: 0x3C53D34
	private object UpdateCharEscapeFlags() { }

	// RVA: 0x3C54884
	protected override object WriteIndent() { }

	// RVA: 0x3C54A9C
	private object SetIndentChars() { }

	// RVA: 0x3C54BDC
	protected override object WriteValueDelimiter() { }

	// RVA: 0x3C54C30
	protected override object WriteIndentSpace() { }

	// RVA: 0x3C54C84
	private object WriteValueInternal(object value, object token) { }

	// RVA: 0x3C54CDC
	public override object WriteValue(object value) { }

	// RVA: 0x3C54FF4
	public override object WriteNull() { }

	// RVA: 0x3C550E8
	public override object WriteUndefined() { }

	// RVA: 0x3C551DC
	public override object WriteRaw(object json) { }

	// RVA: 0x3C55238
	public override object WriteValue(object value) { }

	// RVA: 0x3C54520
	private object WriteEscapedString(object value, object quote) { }

	// RVA: 0x3C5542C
	public override object WriteValue(object value) { }

	// RVA: 0x3C55560
	public override object WriteValue(object value) { }

	// RVA: 0x3C55690
	public override object WriteValue(object value) { }

	// RVA: 0x3C55738
	public override object WriteValue(object value) { }

	// RVA: 0x3C5585C
	public override object WriteValue(object value) { }

	// RVA: 0x3C55944
	public override object WriteValue(object value) { }

	// RVA: 0x3C55A88
	public override object WriteValue(object value) { }

	// RVA: 0x3C55B70
	public override object WriteValue(object value) { }

	// RVA: 0x3C55CB4
	public override object WriteValue(object value) { }

	// RVA: 0x3C55E1C
	public override object WriteValue(object value) { }

	// RVA: 0x3C55EC4
	public override object WriteValue(object value) { }

	// RVA: 0x3C55F64
	public override object WriteValue(object value) { }

	// RVA: 0x3C56110
	public override object WriteValue(object value) { }

	// RVA: 0x3C561B0
	public override object WriteValue(object value) { }

	// RVA: 0x3C56258
	public override object WriteValue(object value) { }

	// RVA: 0x3C5636C
	public override object WriteValue(object value) { }

	// RVA: 0x3C56618
	private object WriteValueToBuffer(object value) { }

	// RVA: 0x3C5675C
	public override object WriteValue(object value) { }

	// RVA: 0x3C56950
	public override object WriteValue(object value) { }

	// RVA: 0x3C56BC8
	private object WriteValueToBuffer(object value) { }

	// RVA: 0x3C56D68
	public override object WriteValue(object value) { }

	// RVA: 0x3C56EF0
	public override object WriteValue(object value) { }

	// RVA: 0x3C570A8
	public override object WriteValue(object value) { }

	// RVA: 0x3C5726C
	public override object WriteComment(object text) { }

	// RVA: 0x3C553EC
	private object EnsureWriteBuffer() { }

	// RVA: 0x3C55604
	private object WriteIntegerValue(object value) { }

	// RVA: 0x3C55788
	private object WriteIntegerValue(object value, object negative) { }

	// RVA: 0x3C573A8
	private object WriteNumberToBuffer(object value, object negative) { }

	// RVA: 0x3C554D4
	private object WriteIntegerValue(object value) { }

	// RVA: 0x3C575A8
	private object WriteIntegerValue(object value, object negative) { }

	// RVA: 0x3C574B8
	private object WriteNumberToBuffer(object value, object negative) { }

}

// Namespace: Newtonsoft.Json
public enum JsonToken
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object StartObject;
	public const object StartArray;
	public const object StartConstructor;
	public const object PropertyName;
	public const object Comment;
	public const object Raw;
	public const object Integer;
	public const object Float;
	public const object String;
	public const object Boolean;
	public const object Null;
	public const object Undefined;
	public const object EndObject;
	public const object EndArray;
	public const object EndConstructor;
	public const object Date;
	public const object Bytes;
}

// Namespace: 
internal enum State
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Start;
	public const object Property;
	public const object ObjectStart;
	public const object Object;
	public const object ArrayStart;
	public const object Array;
	public const object ConstructorStart;
	public const object Constructor;
	public const object Closed;
	public const object Error;
}

// Namespace: Newtonsoft.Json
public abstract class JsonWriter
{

	// Fields
	private static readonly object StateArray; // 0x0
	internal static readonly object StateArrayTemplate; // 0x8
	private object _stack; // 0x8
	private object _currentPosition; // 0x10
	private object _currentState; // 0x28
	private object _formatting; // 0x2C
	private object <CloseOutput>k__BackingField; // 0x30
	private object <AutoCompleteOnClose>k__BackingField; // 0x31
	private object _dateFormatHandling; // 0x34
	private object _dateTimeZoneHandling; // 0x38
	private object _stringEscapeHandling; // 0x3C
	private object _floatFormatHandling; // 0x40
	private object _dateFormatString; // 0x48
	private object _culture; // 0x50

	// Properties
	public object CloseOutput { get; set; }
	public object AutoCompleteOnClose { get; set; }
	protected internal object Top { get; }
	public object WriteState { get; }
	internal object ContainerPath { get; }
	public object Path { get; }
	public object Formatting { get; set; }
	public object DateFormatHandling { get; set; }
	public object DateTimeZoneHandling { get; set; }
	public object StringEscapeHandling { get; set; }
	public object FloatFormatHandling { get; set; }
	public object DateFormatString { get; set; }
	public object Culture { get; set; }

	// Methods

	// RVA: 0x3C5767C
	internal static object BuildStateArray() { }

	// RVA: 0x3C579F4
	private static object .cctor() { }

	// RVA: 0x3C57C8C
	public object get_CloseOutput() { }

	// RVA: 0x3C57C94
	public object set_CloseOutput(object value) { }

	// RVA: 0x3C57C9C
	public object get_AutoCompleteOnClose() { }

	// RVA: 0x3C57CA4
	public object set_AutoCompleteOnClose(object value) { }

	// RVA: 0x3C54A48
	protected internal object get_Top() { }

	// RVA: 0x3C57CB4
	public object get_WriteState() { }

	// RVA: 0x3C57D64
	internal object get_ContainerPath() { }

	// RVA: 0x3C57E14
	public object get_Path() { }

	// RVA: 0x3C57F44
	public object get_Formatting() { }

	// RVA: 0x3C40048
	public object set_Formatting(object value) { }

	// RVA: 0x3C57F4C
	public object get_DateFormatHandling() { }

	// RVA: 0x3C4A604
	public object set_DateFormatHandling(object value) { }

	// RVA: 0x3C57F54
	public object get_DateTimeZoneHandling() { }

	// RVA: 0x3C4A668
	public object set_DateTimeZoneHandling(object value) { }

	// RVA: 0x3C57F5C
	public object get_StringEscapeHandling() { }

	// RVA: 0x3C4A730
	public object set_StringEscapeHandling(object value) { }

	// RVA: 0x3C57F64
	internal virtual object OnStringEscapeHandlingChanged() { }

	// RVA: 0x3C57F68
	public object get_FloatFormatHandling() { }

	// RVA: 0x3C4A6CC
	public object set_FloatFormatHandling(object value) { }

	// RVA: 0x3C57F70
	public object get_DateFormatString() { }

	// RVA: 0x3C57F78
	public object set_DateFormatString(object value) { }

	// RVA: 0x3C4A7C4
	public object get_Culture() { }

	// RVA: 0x3C57F80
	public object set_Culture(object value) { }

	// RVA: 0x3C53CFC
	protected object .ctor() { }

	// RVA: 0x3C57F88
	internal object UpdateScopeWithFinishedValue() { }

	// RVA: 0x3C57FA4
	private object Push(object value) { }

	// RVA: 0x3C581C0
	private object Pop() { }

	// RVA: 0x3C57CAC
	private object Peek() { }

	// RVA: 0x3C53EAC
	public virtual object Close() { }

	// RVA: 0x3C5834C
	public virtual object WriteStartObject() { }

	// RVA: 0x3C58394
	public virtual object WriteEndObject() { }

	// RVA: 0x3C583A0
	public virtual object WriteStartArray() { }

	// RVA: 0x3C583E8
	public virtual object WriteEndArray() { }

	// RVA: 0x3C583F0
	public virtual object WriteStartConstructor(object name) { }

	// RVA: 0x3C58438
	public virtual object WriteEndConstructor() { }

	// RVA: 0x3C58440
	public virtual object WritePropertyName(object name) { }

	// RVA: 0x3C5844C
	public virtual object WritePropertyName(object name, object escape) { }

	// RVA: 0x3C58498
	public virtual object WriteEnd() { }

	// RVA: 0x3C58618
	public object WriteToken(object reader) { }

	// RVA: 0x3C586AC
	public object WriteToken(object reader, object writeChildren) { }

	// RVA: 0x3C5874C
	public object WriteToken(object token, object value) { }

	// RVA: 0x3C59160
	internal virtual object WriteToken(object reader, object writeChildren, object writeDateConstructorAsDate, object writeComments) { }

	// RVA: 0x3C59638
	private object IsWriteTokenIncomplete(object reader, object writeChildren, object initialDepth) { }

	// RVA: 0x3C59470
	private object CalculateWriteTokenInitialDepth(object reader) { }

	// RVA: 0x3C596D0
	private object CalculateWriteTokenFinalDepth(object reader) { }

	// RVA: 0x3C5952C
	private object WriteConstructorDate(object reader) { }

	// RVA: 0x3C584A0
	private object WriteEnd(object type) { }

	// RVA: 0x3C582B4
	private object AutoCompleteAll() { }

	// RVA: 0x3C5978C
	private object GetCloseTokenForType(object type) { }

	// RVA: 0x3C59834
	private object AutoCompleteClose(object type) { }

	// RVA: 0x3C59950
	private object CalculateLevelsToComplete(object type) { }

	// RVA: 0x3C59AC4
	private object UpdateCurrentState() { }

	// RVA: 0x3C59B80
	protected virtual object WriteEnd(object token) { }

	// RVA: 0x3C59B84
	protected virtual object WriteIndent() { }

	// RVA: 0x3C59B88
	protected virtual object WriteValueDelimiter() { }

	// RVA: 0x3C59B8C
	protected virtual object WriteIndentSpace() { }

	// RVA: 0x3C59B90
	internal object AutoComplete(object tokenBeingWritten) { }

	// RVA: 0x3C59E20
	public virtual object WriteNull() { }

	// RVA: 0x3C59E40
	public virtual object WriteUndefined() { }

	// RVA: 0x3C59E60
	public virtual object WriteRaw(object json) { }

	// RVA: 0x3C59E64
	public virtual object WriteRawValue(object json) { }

	// RVA: 0x3C59ED0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59EF0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59F10
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59F30
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59F50
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59F70
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59F90
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59FB0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59FD0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C59FF0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A010
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A030
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A050
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A070
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A090
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A0B0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A0D0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A0F0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A110
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A1BC
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A268
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A314
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A3C0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A47C
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A538
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A5EC
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A698
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A744
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A7F0
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A89C
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5A948
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5AA08
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5AAB4
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5AB74
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5AC38
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5ACE4
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5AD4C
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C54E90
	public virtual object WriteValue(object value) { }

	// RVA: 0x3C5C534
	public virtual object WriteComment(object text) { }

	// RVA: 0x3C5C53C
	private object System.IDisposable.Dispose() { }

	// RVA: 0x3C5C5D8
	protected virtual object Dispose(object disposing) { }

	// RVA: 0x3C5AF0C
	internal static object WriteValue(object writer, object typeCode, object value) { }

	// RVA: 0x3C5C62C
	private static object ResolveConvertibleValue(object convertible, object typeCode, object value) { }

	// RVA: 0x3C5AE34
	private static object CreateUnsupportedTypeException(object writer, object value) { }

	// RVA: 0x3C5C824
	protected object SetWriteState(object token, object value) { }

	// RVA: 0x3C5839C
	internal object InternalWriteEnd(object container) { }

	// RVA: 0x3C54514
	internal object InternalWritePropertyName(object name) { }

	// RVA: 0x3C55234
	internal object InternalWriteRaw() { }

	// RVA: 0x3C5404C
	internal object InternalWriteStart(object token, object container) { }

	// RVA: 0x3C54E74
	internal object InternalWriteValue(object token) { }

	// RVA: 0x3C573A0
	internal object InternalWriteComment() { }

}

// Namespace: Newtonsoft.Json
public class JsonWriterException
{

	// Fields
	private readonly object <Path>k__BackingField; // 0x88

	// Methods

	// RVA: 0x3C5CAE4
	public object .ctor() { }

	// RVA: 0x3C5CAEC
	public object .ctor(object info, object context) { }

	// RVA: 0x3C5CAF4
	public object .ctor(object message, object path, object innerException) { }

	// RVA: 0x3C5CB24
	internal static object Create(object writer, object message, object ex) { }

	// RVA: 0x3C5CBF8
	internal static object Create(object path, object message, object ex) { }

}

// Namespace: Newtonsoft.Json
public enum MemberSerialization
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OptOut;
	public const object OptIn;
	public const object Fields;
}

// Namespace: Newtonsoft.Json
public enum MetadataPropertyHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object ReadAhead;
	public const object Ignore;
}

// Namespace: Newtonsoft.Json
public enum MissingMemberHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Ignore;
	public const object Error;
}

// Namespace: Newtonsoft.Json
public enum NullValueHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Include;
	public const object Ignore;
}

// Namespace: Newtonsoft.Json
public enum ObjectCreationHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Auto;
	public const object Reuse;
	public const object Replace;
}

// Namespace: Newtonsoft.Json
public enum PreserveReferencesHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Objects;
	public const object Arrays;
	public const object All;
}

// Namespace: Newtonsoft.Json
public enum ReferenceLoopHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Error;
	public const object Ignore;
	public const object Serialize;
}

// Namespace: Newtonsoft.Json
public enum Required
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object AllowNull;
	public const object Always;
	public const object DisallowNull;
}

// Namespace: Newtonsoft.Json
public enum StringEscapeHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Default;
	public const object EscapeNonAscii;
	public const object EscapeHtml;
}

// Namespace: Newtonsoft.Json
public enum TypeNameAssemblyFormatHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Simple;
	public const object Full;
}

// Namespace: Newtonsoft.Json
public enum TypeNameHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Objects;
	public const object Arrays;
	public const object All;
	public const object Auto;
}

// Namespace: Newtonsoft.Json
public enum WriteState
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Error;
	public const object Closed;
	public const object Object;
	public const object Array;
	public const object Constructor;
	public const object Property;
	public const object Start;
}

// Namespace: Newtonsoft.Json.Utilities
internal class Base64Encoder
{

	// Fields
	private readonly object _charsLine; // 0x8
	private readonly object _writer; // 0x10
	private object _leftOverBytes; // 0x18
	private object _leftOverBytesCount; // 0x20

	// Methods

	// RVA: 0x3C5CCB4
	public object .ctor(object writer) { }

	// RVA: 0x3C5CDC8
	private object ValidateEncode(object buffer, object index, object count) { }

	// RVA: 0x3C5CEAC
	public object Encode(object buffer, object index, object count) { }

	// RVA: 0x3C5D2C0
	private object StoreLeftOverBytes(object buffer, object index, object count) { }

	// RVA: 0x3C5D178
	private object FulfillFromLeftover(object buffer, object index, object count) { }

	// RVA: 0x3C5D3E0
	public object Flush() { }

	// RVA: 0x3C5D250
	private object WriteChars(object chars, object index, object count) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class BidirectionalDictionary<T0, T1>
{

	// Fields
	private readonly object _firstToSecond; // 0x0
	private readonly object _secondToFirst; // 0x0
	private readonly object _duplicateFirstErrorMessage; // 0x0
	private readonly object _duplicateSecondErrorMessage; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object firstEqualityComparer, object secondEqualityComparer, object duplicateFirstErrorMessage, object duplicateSecondErrorMessage) { }

	// RVA: -1
	public object Set(object first, object second) { }

	// RVA: -1
	public object TryGetByFirst(object first, object second) { }

	// RVA: -1
	public object TryGetBySecond(object second, object first) { }

}

// Namespace: 
private static class EmptyArrayContainer<T0>
{

	// Fields
	public static readonly object Empty; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class CollectionUtils
{

	// Methods

	// RVA: -1
	public static object IsNullOrEmpty(object collection) { }

	// RVA: -1
	public static object AddRange(object initial, object collection) { }

	// RVA: 0x3C5D4C0
	public static object IsDictionaryType(object type) { }

	// RVA: 0x3C5D7E8
	public static object ResolveEnumerableCollectionConstructor(object collectionType, object collectionItemType) { }

	// RVA: 0x3C5D928
	public static object ResolveEnumerableCollectionConstructor(object collectionType, object collectionItemType, object constructorArgumentType) { }

	// RVA: -1
	public static object IndexOf(object collection, object predicate) { }

	// RVA: -1
	public static object Contains(object list, object value, object comparer) { }

	// RVA: -1
	public static object IndexOfReference(object list, object item) { }

	// RVA: -1
	public static object FastReverse(object list) { }

	// RVA: 0x3C5DD94
	private static object GetDimensions(object values, object dimensionsCount) { }

	// RVA: 0x3C5E1A8
	private static object CopyFromJaggedToMultidimensionalArray(object values, object multidimensionalArray, object indices) { }

	// RVA: 0x3C5E4CC
	private static object JaggedArrayGetValue(object values, object indices) { }

	// RVA: 0x3C5E6D4
	public static object ToMultidimensionalArray(object values, object type, object rank) { }

	// RVA: -1
	public static object ArrayEmpty() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal interface IWrappedCollection
{

	// Properties
	public abstract object UnderlyingCollection { get; }

	// Methods

	// RVA: -1
	public abstract object get_UnderlyingCollection() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class CollectionWrapper<T0>
{

	// Fields
	private readonly object _list; // 0x0
	private readonly object _genericCollection; // 0x0
	private object _syncRoot; // 0x0

	// Properties
	public virtual object Count { get; }
	public virtual object IsReadOnly { get; }
	private object System.Collections.IList.IsFixedSize { get; }
	private object System.Collections.IList.Item { get; set; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	public object UnderlyingCollection { get; }

	// Methods

	// RVA: -1
	public virtual object Add(object item) { }

	// RVA: -1
	public virtual object Clear() { }

	// RVA: -1
	public virtual object Contains(object item) { }

	// RVA: -1
	public virtual object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public virtual object get_Count() { }

	// RVA: -1
	public virtual object get_IsReadOnly() { }

	// RVA: -1
	public virtual object Remove(object item) { }

	// RVA: -1
	public virtual object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IList.Add(object value) { }

	// RVA: -1
	private object System.Collections.IList.Contains(object value) { }

	// RVA: -1
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: -1
	private object System.Collections.IList.RemoveAt(object index) { }

	// RVA: -1
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: -1
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: -1
	private object System.Collections.IList.Remove(object value) { }

	// RVA: -1
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: -1
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	private static object VerifyValueType(object value) { }

	// RVA: -1
	private static object IsCompatibleObject(object value) { }

	// RVA: -1
	public object get_UnderlyingCollection() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal enum PrimitiveTypeCode
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Empty;
	public const object Object;
	public const object Char;
	public const object CharNullable;
	public const object Boolean;
	public const object BooleanNullable;
	public const object SByte;
	public const object SByteNullable;
	public const object Int16;
	public const object Int16Nullable;
	public const object UInt16;
	public const object UInt16Nullable;
	public const object Int32;
	public const object Int32Nullable;
	public const object Byte;
	public const object ByteNullable;
	public const object UInt32;
	public const object UInt32Nullable;
	public const object Int64;
	public const object Int64Nullable;
	public const object UInt64;
	public const object UInt64Nullable;
	public const object Single;
	public const object SingleNullable;
	public const object Double;
	public const object DoubleNullable;
	public const object DateTime;
	public const object DateTimeNullable;
	public const object DateTimeOffset;
	public const object DateTimeOffsetNullable;
	public const object Decimal;
	public const object DecimalNullable;
	public const object Guid;
	public const object GuidNullable;
	public const object TimeSpan;
	public const object TimeSpanNullable;
	public const object BigInteger;
	public const object BigIntegerNullable;
	public const object Uri;
	public const object String;
	public const object Bytes;
	public const object DBNull;
}

// Namespace: Newtonsoft.Json.Utilities
internal class TypeInformation
{

	// Fields
	private readonly object <Type>k__BackingField; // 0x8
	private readonly object <TypeCode>k__BackingField; // 0x10

	// Properties
	public object Type { get; }
	public object TypeCode { get; }

	// Methods

	// RVA: 0x3C5E96C
	public object get_Type() { }

	// RVA: 0x3C5E974
	public object get_TypeCode() { }

	// RVA: 0x3C5E97C
	public object .ctor(object type, object typeCode) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal enum ParseResult
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Success;
	public const object Overflow;
	public const object Invalid;
}

// Namespace: 
internal enum ConvertResult
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Success;
	public const object CannotConvertNull;
	public const object NotInstantiableType;
	public const object NoValidConversion;
}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object call; // 0x8

	// Methods

	// RVA: 0x3C5F52C
	public object .ctor() { }

	// RVA: 0x3C63474
	internal object <CreateCastConverter>b__0(object o) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class ConvertUtils
{

	// Fields
	private static readonly object TypeCodeMap; // 0x0
	private static readonly object PrimitiveTypeCodes; // 0x8
	private static readonly object CastConverters; // 0x10

	// Methods

	// RVA: 0x3C5E9B8
	public static object GetTypeCode(object t) { }

	// RVA: 0x3C5EA28
	public static object GetTypeCode(object t, object isEnum) { }

	// RVA: 0x3C5EFB0
	public static object GetTypeInformation(object convertable) { }

	// RVA: 0x3C5F0F0
	public static object IsConvertible(object t) { }

	// RVA: 0x3C5F1D0
	public static object ParseTimeSpan(object input) { }

	// RVA: 0x3C5F298
	private static object CreateCastConverter(object t) { }

	// RVA: 0x3C5F534
	internal static object ToBigInteger(object value) { }

	// RVA: 0x3C5FA5C
	public static object FromBigInteger(object i, object targetType) { }

	// RVA: 0x3C5FF94
	public static object Convert(object initialValue, object culture, object targetType) { }

	// RVA: 0x3C60DE8
	private static object TryConvert(object initialValue, object culture, object targetType, object value) { }

	// RVA: 0x3C6025C
	private static object TryConvertInternal(object initialValue, object culture, object targetType, object value) { }

	// RVA: 0x3C613B0
	public static object ConvertOrCast(object initialValue, object culture, object targetType) { }

	// RVA: 0x3C610E4
	private static object EnsureTypeAssignable(object value, object initialType, object targetType) { }

	// RVA: 0x3C61000
	public static object VersionTryParse(object input, object result) { }

	// RVA: 0x3C60F08
	public static object IsInteger(object value) { }

	// RVA: 0x3C6158C
	public static object Int32TryParse(object chars, object start, object length, object value) { }

	// RVA: 0x3C61728
	public static object Int64TryParse(object chars, object start, object length, object value) { }

	// RVA: 0x3C618A4
	public static object DecimalTryParse(object chars, object start, object length, object value) { }

	// RVA: 0x3C6226C
	public static object TryConvertGuid(object s, object g) { }

	// RVA: 0x3C622D0
	public static object TryHexTextToInt(object text, object start, object end, object value) { }

	// RVA: 0x3C623C4
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal enum ParserTimeZone
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Unspecified;
	public const object Utc;
	public const object LocalWestOfUtc;
	public const object LocalEastOfUtc;
}

// Namespace: Newtonsoft.Json.Utilities
internal struct DateTimeParser
{

	// Fields
	public object Year; // 0xFFFFFFFFFFFFFFF8
	public object Month; // 0xFFFFFFFFFFFFFFFC
	public object Day; // 0x0
	public object Hour; // 0x4
	public object Minute; // 0x8
	public object Second; // 0xC
	public object Fraction; // 0x10
	public object ZoneHour; // 0x14
	public object ZoneMinute; // 0x18
	public object Zone; // 0x1C
	private object _text; // 0x20
	private object _end; // 0x28
	private static readonly object Power10; // 0x0
	private static readonly object Lzyyyy; // 0xFFFFFFFFFFFFFFF8
	private static readonly object Lzyyyy_; // 0xFFFFFFFFFFFFFFFC
	private static readonly object Lzyyyy_MM; // 0x0
	private static readonly object Lzyyyy_MM_; // 0x4
	private static readonly object Lzyyyy_MM_dd; // 0x8
	private static readonly object Lzyyyy_MM_ddT; // 0xC
	private static readonly object LzHH; // 0x10
	private static readonly object LzHH_; // 0x14
	private static readonly object LzHH_mm; // 0x18
	private static readonly object LzHH_mm_; // 0x1C
	private static readonly object LzHH_mm_ss; // 0x20
	private static readonly object Lz_; // 0x24
	private static readonly object Lz_zz; // 0x28

	// Methods

	// RVA: 0x3C637A4
	private static object .cctor() { }

	// RVA: 0x3C63AB4
	public object Parse(object text, object startIndex, object length) { }

	// RVA: 0x3C63CC4
	private object ParseDate(object start) { }

	// RVA: 0x3C63FC4
	private object ParseTimeAndZoneAndWhitespace(object start) { }

	// RVA: 0x3C641FC
	private object ParseTime(object start) { }

	// RVA: 0x3C647DC
	private object ParseZone(object start) { }

	// RVA: 0x3C64090
	private object Parse4Digit(object start, object num) { }

	// RVA: 0x3C64160
	private object Parse2Digit(object start, object num) { }

	// RVA: 0x3C63F68
	private object ParseChar(object start, object ch) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class DateTimeUtils
{

	// Fields
	internal static readonly object InitialJavaScriptDateTicks; // 0x0
	private static readonly object DaysToMonth365; // 0x8
	private static readonly object DaysToMonth366; // 0x10

	// Methods

	// RVA: 0x3C64CB8
	private static object .cctor() { }

	// RVA: 0x3C64DB0
	public static object GetUtcOffset(object d) { }

	// RVA: 0x3C64E44
	public static object ToSerializationMode(object kind) { }

	// RVA: 0x3C64FC4
	internal static object EnsureDateTime(object value, object timeZone) { }

	// RVA: 0x3C65180
	private static object SwitchToLocalTime(object value) { }

	// RVA: 0x3C65298
	private static object SwitchToUtcTime(object value) { }

	// RVA: 0x3C653AC
	private static object ToUniversalTicks(object dateTime, object offset) { }

	// RVA: 0x3C65574
	internal static object ConvertDateTimeToJavaScriptTicks(object dateTime, object offset) { }

	// RVA: 0x3C65640
	private static object UniversalTicksToJavaScriptTicks(object universalTicks) { }

	// RVA: 0x3C656C8
	internal static object ConvertJavaScriptTicksToDateTime(object javaScriptTicks) { }

	// RVA: 0x3C65758
	internal static object TryParseDateTimeIso(object text, object dateTimeZoneHandling, object dt) { }

	// RVA: 0x3C65DC0
	internal static object TryParseDateTimeOffsetIso(object text, object dt) { }

	// RVA: 0x3C65CBC
	private static object CreateDateTime(object dateTimeParser) { }

	// RVA: 0x3C66098
	internal static object TryParseDateTime(object s, object dateTimeZoneHandling, object dateFormatString, object culture, object dt) { }

	// RVA: 0x3C66860
	internal static object TryParseDateTime(object s, object dateTimeZoneHandling, object dateFormatString, object culture, object dt) { }

	// RVA: 0x3C66B58
	internal static object TryParseDateTimeOffset(object s, object dateFormatString, object culture, object dt) { }

	// RVA: 0x3C670B0
	internal static object TryParseDateTimeOffset(object s, object dateFormatString, object culture, object dt) { }

	// RVA: 0x3C6741C
	private static object TryParseMicrosoftDate(object text, object ticks, object offset, object kind) { }

	// RVA: 0x3C6654C
	private static object TryParseDateTimeMicrosoft(object text, object dateTimeZoneHandling, object dt) { }

	// RVA: 0x3C66770
	private static object TryParseDateTimeExact(object text, object dateTimeZoneHandling, object dateFormatString, object culture, object dt) { }

	// RVA: 0x3C66E1C
	private static object TryParseDateTimeOffsetMicrosoft(object text, object dt) { }

	// RVA: 0x3C66FF0
	private static object TryParseDateTimeOffsetExact(object text, object dateFormatString, object culture, object dt) { }

	// RVA: 0x3C67694
	private static object TryReadOffset(object offsetText, object startIndex, object offset) { }

	// RVA: 0x3C67840
	internal static object WriteDateTimeString(object writer, object value, object format, object formatString, object culture) { }

	// RVA: 0x3C67A00
	internal static object WriteDateTimeString(object chars, object start, object value, object offset, object kind, object format) { }

	// RVA: 0x3C681E8
	internal static object WriteDefaultIsoDate(object chars, object start, object dt) { }

	// RVA: 0x3C6899C
	private static object CopyIntToCharArray(object chars, object start, object value, object digits) { }

	// RVA: 0x3C67EFC
	internal static object WriteDateTimeOffset(object chars, object start, object offset, object format) { }

	// RVA: 0x3C68A18
	internal static object WriteDateTimeOffsetString(object writer, object value, object format, object formatString, object culture) { }

	// RVA: 0x3C68760
	private static object GetDateValues(object td, object year, object month, object day) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal interface IWrappedDictionary
{

	// Properties
	public abstract object UnderlyingDictionary { get; }

	// Methods

	// RVA: -1
	public abstract object get_UnderlyingDictionary() { }

}

// Namespace: 
private struct DictionaryEnumerator<T0, T1>
{

	// Fields
	private readonly object _e; // 0x0

	// Properties
	public object Entry { get; }
	public object Key { get; }
	public object Value { get; }
	public object Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object e) { }

	// RVA: -1
	public object get_Entry() { }

	// RVA: -1
	public object get_Key() { }

	// RVA: -1
	public object get_Value() { }

	// RVA: -1
	public object get_Current() { }

	// RVA: -1
	public object MoveNext() { }

	// RVA: -1
	public object Reset() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__29_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <GetEnumerator>b__29_0(object de) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class DictionaryWrapper<T0, T1>
{

	// Fields
	private readonly object _dictionary; // 0x0
	private readonly object _genericDictionary; // 0x0
	private readonly object _readOnlyDictionary; // 0x0
	private object _syncRoot; // 0x0

	// Properties
	internal object GenericDictionary { get; }
	public object Keys { get; }
	public object Values { get; }
	public object Item { get; set; }
	public object Count { get; }
	public object IsReadOnly { get; }
	private object System.Collections.IDictionary.Item { get; set; }
	private object System.Collections.IDictionary.IsFixedSize { get; }
	private object System.Collections.IDictionary.Keys { get; }
	private object System.Collections.IDictionary.Values { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }
	public object UnderlyingDictionary { get; }

	// Methods

	// RVA: -1
	internal object get_GenericDictionary() { }

	// RVA: -1
	public object Add(object key, object value) { }

	// RVA: -1
	public object ContainsKey(object key) { }

	// RVA: -1
	public object get_Keys() { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	public object TryGetValue(object key, object value) { }

	// RVA: -1
	public object get_Values() { }

	// RVA: -1
	public object get_Item(object key) { }

	// RVA: -1
	public object set_Item(object key, object value) { }

	// RVA: -1
	public object Add(object item) { }

	// RVA: -1
	public object Clear() { }

	// RVA: -1
	public object Contains(object item) { }

	// RVA: -1
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: -1
	public object get_Count() { }

	// RVA: -1
	public object get_IsReadOnly() { }

	// RVA: -1
	public object Remove(object item) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IDictionary.Add(object key, object value) { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Item(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.set_Item(object key, object value) { }

	// RVA: -1
	private object System.Collections.IDictionary.GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IDictionary.Contains(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.get_IsFixedSize() { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Keys() { }

	// RVA: -1
	public object Remove(object key) { }

	// RVA: -1
	private object System.Collections.IDictionary.get_Values() { }

	// RVA: -1
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: -1
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: -1
	private object System.Collections.ICollection.get_SyncRoot() { }

	// RVA: -1
	public object get_UnderlyingDictionary() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class DynamicProxy<T0>
{

	// Methods

	// RVA: -1
	public virtual object GetDynamicMemberNames(object instance) { }

	// RVA: -1
	public virtual object TryBinaryOperation(object instance, object binder, object arg, object result) { }

	// RVA: -1
	public virtual object TryConvert(object instance, object binder, object result) { }

	// RVA: -1
	public virtual object TryCreateInstance(object instance, object binder, object args, object result) { }

	// RVA: -1
	public virtual object TryDeleteIndex(object instance, object binder, object indexes) { }

	// RVA: -1
	public virtual object TryDeleteMember(object instance, object binder) { }

	// RVA: -1
	public virtual object TryGetIndex(object instance, object binder, object indexes, object result) { }

	// RVA: -1
	public virtual object TryGetMember(object instance, object binder, object result) { }

	// RVA: -1
	public virtual object TryInvoke(object instance, object binder, object args, object result) { }

	// RVA: -1
	public virtual object TryInvokeMember(object instance, object binder, object args, object result) { }

	// RVA: -1
	public virtual object TrySetIndex(object instance, object binder, object indexes, object value) { }

	// RVA: -1
	public virtual object TrySetMember(object instance, object binder, object value) { }

	// RVA: -1
	public virtual object TryUnaryOperation(object instance, object binder, object result) { }

	// RVA: -1
	public object .ctor() { }

}

// Namespace: 
private sealed class Fallback
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object errorSuggestion) { }

}

// Namespace: 
private sealed class GetBinderAdapter
{

	// Methods

	// RVA: -1
	internal object .ctor(object binder) { }

	// RVA: -1
	public override object FallbackGetMember(object target, object errorSuggestion) { }

}

// Namespace: 
private sealed class <>c__DisplayClass3_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindGetMember>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0
	public object value; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindSetMember>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass5_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindDeleteMember>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindConvert>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass7_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0
	public object args; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindInvokeMember>b__0(object e) { }

	// RVA: -1
	internal object <BindInvokeMember>b__1(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0
	public object args; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindCreateInstance>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass9_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0
	public object args; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindInvoke>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass10_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0
	public object arg; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindBinaryOperation>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindUnaryOperation>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass12_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0
	public object indexes; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindGetIndex>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass13_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0
	public object indexes; // 0x0
	public object value; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindSetIndex>b__0(object e) { }

}

// Namespace: 
private sealed class <>c__DisplayClass14_0
{

	// Fields
	public object binder; // 0x0
	public object <>4__this; // 0x0
	public object indexes; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BindDeleteIndex>b__0(object e) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__18_0; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <GetArgs>b__18_0(object arg) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal sealed class DynamicProxyMetaObject<T0>
{

	// Fields
	private readonly object _proxy; // 0x0

	// Properties
	private static object NoArgs { get; }

	// Methods

	// RVA: -1
	internal object .ctor(object expression, object value, object proxy) { }

	// RVA: -1
	private object IsOverridden(object method) { }

	// RVA: -1
	public override object BindGetMember(object binder) { }

	// RVA: -1
	public override object BindSetMember(object binder, object value) { }

	// RVA: -1
	public override object BindDeleteMember(object binder) { }

	// RVA: -1
	public override object BindConvert(object binder) { }

	// RVA: -1
	public override object BindInvokeMember(object binder, object args) { }

	// RVA: -1
	public override object BindCreateInstance(object binder, object args) { }

	// RVA: -1
	public override object BindInvoke(object binder, object args) { }

	// RVA: -1
	public override object BindBinaryOperation(object binder, object arg) { }

	// RVA: -1
	public override object BindUnaryOperation(object binder) { }

	// RVA: -1
	public override object BindGetIndex(object binder, object indexes) { }

	// RVA: -1
	public override object BindSetIndex(object binder, object indexes, object value) { }

	// RVA: -1
	public override object BindDeleteIndex(object binder, object indexes) { }

	// RVA: -1
	private static object get_NoArgs() { }

	// RVA: -1
	private static object GetArgs(object args) { }

	// RVA: -1
	private static object GetArgArray(object args) { }

	// RVA: -1
	private static object GetArgArray(object args, object value) { }

	// RVA: -1
	private static object Constant(object binder) { }

	// RVA: -1
	private object CallMethodWithResult(object methodName, object binder, object args, object fallback, object fallbackInvoke) { }

	// RVA: -1
	private object BuildCallMethodWithResult(object methodName, object binder, object args, object fallbackResult, object fallbackInvoke) { }

	// RVA: -1
	private object CallMethodReturnLast(object methodName, object binder, object args, object fallback) { }

	// RVA: -1
	private object CallMethodNoResult(object methodName, object binder, object args, object fallback) { }

	// RVA: -1
	private object GetRestrictions() { }

	// RVA: -1
	public override object GetDynamicMemberNames() { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_0<T0>
{

	// Fields
	public object constantValue; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateGet>b__0(object o) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class DynamicReflectionDelegateFactory
{

	// Fields
	private static readonly object <Instance>k__BackingField; // 0x0

	// Properties
	internal static object Instance { get; }

	// Methods

	// RVA: 0x3C68C30
	internal static object get_Instance() { }

	// RVA: 0x3C68CAC
	private static object CreateDynamicMethod(object name, object returnType, object parameterTypes, object owner) { }

	// RVA: 0x3C68DCC
	public override object CreateParameterizedConstructor(object method) { }

	// RVA: -1
	public override object CreateMethodCall(object method) { }

	// RVA: 0x3C69030
	private object GenerateCreateMethodCallIL(object method, object generator, object argsIndex) { }

	// RVA: -1
	public override object CreateDefaultConstructor(object type) { }

	// RVA: 0x3C6A9C8
	private object GenerateCreateDefaultConstructorIL(object type, object generator, object delegateType) { }

	// RVA: -1
	public override object CreateGet(object propertyInfo) { }

	// RVA: 0x3C6AD48
	private object GenerateCreateGetPropertyIL(object propertyInfo, object generator) { }

	// RVA: -1
	public override object CreateGet(object fieldInfo) { }

	// RVA: 0x3C6AF5C
	private object GenerateCreateGetFieldIL(object fieldInfo, object generator) { }

	// RVA: -1
	public override object CreateSet(object fieldInfo) { }

	// RVA: 0x3C6B150
	internal static object GenerateCreateSetFieldIL(object fieldInfo, object generator) { }

	// RVA: -1
	public override object CreateSet(object propertyInfo) { }

	// RVA: 0x3C6B394
	internal static object GenerateCreateSetPropertyIL(object propertyInfo, object generator) { }

	// RVA: 0x3C6B5A4
	public object .ctor() { }

	// RVA: 0x3C6B5B4
	private static object .cctor() { }

}

// Namespace: 
internal static class BinderWrapper
{

	// Fields
	private static object _getCSharpArgumentInfoArray; // 0x0
	private static object _setCSharpArgumentInfoArray; // 0x8
	private static object _getMemberCall; // 0x10
	private static object _setMemberCall; // 0x18
	private static object _init; // 0x20

	// Methods

	// RVA: 0x3C6B780
	private static object Init() { }

	// RVA: 0x3C6B968
	private static object CreateSharpArgumentInfoArray(object values) { }

	// RVA: 0x3C6BD30
	private static object CreateMemberCalls() { }

	// RVA: 0x3C6C294
	public static object GetMember(object name, object context) { }

	// RVA: 0x3C6C488
	public static object SetMember(object name, object context) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class DynamicUtils
{

	// Methods

	// RVA: 0x3C6B614
	public static object GetDynamicMemberNames(object dynamicProvider) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class NoThrowGetBinderMember
{

	// Fields
	private readonly object _innerBinder; // 0x20

	// Methods

	// RVA: 0x3C6C67C
	public object .ctor(object innerBinder) { }

	// RVA: 0x3C6C6C0
	public override object FallbackGetMember(object target, object errorSuggestion) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class NoThrowSetBinderMember
{

	// Fields
	private readonly object _innerBinder; // 0x20

	// Methods

	// RVA: 0x3C6C8C8
	public object .ctor(object innerBinder) { }

	// RVA: 0x3C6C90C
	public override object FallbackSetMember(object target, object value, object errorSuggestion) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class NoThrowExpressionVisitor
{

	// Fields
	internal static readonly object ErrorResult; // 0x0

	// Methods

	// RVA: 0x3C6CAB0
	protected override object VisitConditional(object node) { }

	// RVA: 0x3C6C8C0
	public object .ctor() { }

	// RVA: 0x3C6CBDC
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class EnumInfo
{

	// Fields
	public readonly object IsFlags; // 0x8
	public readonly object Values; // 0x10
	public readonly object Names; // 0x18
	public readonly object ResolvedNames; // 0x20

	// Methods

	// RVA: 0x3C6CC58
	public object .ctor(object isFlags, object values, object names, object resolvedNames) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__3_0; // 0x8

	// Methods

	// RVA: 0x3C6E770
	private static object .cctor() { }

	// RVA: 0x3C6E7D0
	public object .ctor() { }

	// RVA: 0x3C6E7D8
	internal object <InitializeValuesAndNames>b__3_0(object a) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class EnumUtils
{

	// Fields
	private static readonly object ValuesAndNamesPerEnum; // 0x0
	private static object _camelCaseNamingStrategy; // 0x8

	// Methods

	// RVA: 0x3C6CCA8
	private static object InitializeValuesAndNames(object key) { }

	// RVA: 0x3C6D6C4
	public static object TryToString(object enumType, object value, object namingStrategy, object name) { }

	// RVA: 0x3C6D86C
	private static object InternalFlagsFormat(object entry, object result) { }

	// RVA: 0x3C6DAF8
	public static object GetEnumValuesAndNames(object enumType) { }

	// RVA: 0x3C6D2E0
	private static object ToUInt64(object value) { }

	// RVA: 0x3C6DBC8
	public static object ParseEnum(object enumType, object namingStrategy, object value, object disallowNumber) { }

	// RVA: 0x3C6E568
	private static object MatchName(object value, object enumNames, object resolvedNames, object valueIndex, object valueSubstringLength, object comparison) { }

	// RVA: 0x3C6E458
	private static object FindIndexByName(object enumNames, object value, object valueIndex, object valueSubstringLength, object comparison) { }

	// RVA: 0x3C6E64C
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class FSharpFunction
{

	// Fields
	private readonly object _instance; // 0x8
	private readonly object _invoker; // 0x10

	// Methods

	// RVA: 0x3C6E7F8
	public object .ctor(object instance, object invoker) { }

	// RVA: 0x3C6E830
	public object Invoke(object args) { }

}

// Namespace: 
private sealed class <>c__DisplayClass52_0
{

	// Fields
	public object call; // 0x8
	public object invoke; // 0x10

	// Methods

	// RVA: 0x3C6F530
	public object .ctor() { }

	// RVA: 0x3C6F90C
	internal object <CreateFSharpFuncCall>b__0(object target, object args) { }

}

// Namespace: 
private sealed class <>c__DisplayClass55_0<T0, T1>
{

	// Fields
	public object ctorDelegate; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BuildMapCreator>b__0(object args) { }

}

// Namespace: 
private sealed class <>c__55<T0, T1>
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__55_1; // 0x0

	// Methods

	// RVA: -1
	private static object .cctor() { }

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <BuildMapCreator>b__55_1(object kv) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class FSharpUtils
{

	// Fields
	private static readonly object Lock; // 0x0
	private static object _instance; // 0x8
	private object _ofSeq; // 0x8
	private object _mapType; // 0x10
	private object <FSharpCoreAssembly>k__BackingField; // 0x18
	private object <IsUnion>k__BackingField; // 0x20
	private object <GetUnionCases>k__BackingField; // 0x28
	private object <PreComputeUnionTagReader>k__BackingField; // 0x30
	private object <PreComputeUnionReader>k__BackingField; // 0x38
	private object <PreComputeUnionConstructor>k__BackingField; // 0x40
	private object <GetUnionCaseInfoDeclaringType>k__BackingField; // 0x48
	private object <GetUnionCaseInfoName>k__BackingField; // 0x50
	private object <GetUnionCaseInfoTag>k__BackingField; // 0x58
	private object <GetUnionCaseInfoFields>k__BackingField; // 0x60

	// Properties
	public static object Instance { get; }
	private object FSharpCoreAssembly { set; }
	public object IsUnion { get; set; }
	public object GetUnionCases { get; set; }
	public object PreComputeUnionTagReader { get; set; }
	public object PreComputeUnionReader { get; set; }
	public object PreComputeUnionConstructor { get; set; }
	public object GetUnionCaseInfoDeclaringType { get; set; }
	public object GetUnionCaseInfoName { get; set; }
	public object GetUnionCaseInfoTag { get; set; }
	public object GetUnionCaseInfoFields { get; set; }

	// Methods

	// RVA: 0x3C6E864
	private object .ctor(object fsharpCoreAssembly) { }

	// RVA: 0x3C6F260
	public static object get_Instance() { }

	// RVA: 0x3C6F2DC
	private object set_FSharpCoreAssembly(object value) { }

	// RVA: 0x3C6F2E4
	public object get_IsUnion() { }

	// RVA: 0x3C6F2EC
	private object set_IsUnion(object value) { }

	// RVA: 0x3C6F2F4
	public object get_GetUnionCases() { }

	// RVA: 0x3C6F2FC
	private object set_GetUnionCases(object value) { }

	// RVA: 0x3C6F304
	public object get_PreComputeUnionTagReader() { }

	// RVA: 0x3C6F30C
	private object set_PreComputeUnionTagReader(object value) { }

	// RVA: 0x3C6F314
	public object get_PreComputeUnionReader() { }

	// RVA: 0x3C6F31C
	private object set_PreComputeUnionReader(object value) { }

	// RVA: 0x3C6F324
	public object get_PreComputeUnionConstructor() { }

	// RVA: 0x3C6F32C
	private object set_PreComputeUnionConstructor(object value) { }

	// RVA: 0x3C6F334
	public object get_GetUnionCaseInfoDeclaringType() { }

	// RVA: 0x3C6F33C
	private object set_GetUnionCaseInfoDeclaringType(object value) { }

	// RVA: 0x3C6F344
	public object get_GetUnionCaseInfoName() { }

	// RVA: 0x3C6F34C
	private object set_GetUnionCaseInfoName(object value) { }

	// RVA: 0x3C6F354
	public object get_GetUnionCaseInfoTag() { }

	// RVA: 0x3C6F35C
	private object set_GetUnionCaseInfoTag(object value) { }

	// RVA: 0x3C6F364
	public object get_GetUnionCaseInfoFields() { }

	// RVA: 0x3C6F36C
	private object set_GetUnionCaseInfoFields(object value) { }

	// RVA: 0x3C6F374
	public static object EnsureInitialized(object fsharpCoreAssembly) { }

	// RVA: 0x3C6EF30
	private static object GetMethodWithNonPublicFallback(object type, object methodName, object bindingFlags) { }

	// RVA: 0x3C6EFB0
	private static object CreateFSharpFuncCall(object type, object methodName) { }

	// RVA: 0x3C6F538
	public object CreateSeq(object t) { }

	// RVA: 0x3C6F688
	public object CreateMap(object keyType, object valueType) { }

	// RVA: -1
	public object BuildMapCreator() { }

	// RVA: 0x3C6F890
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class ILGeneratorExtensions
{

	// Methods

	// RVA: 0x3C6A354
	public static object PushInstance(object generator, object type) { }

	// RVA: 0x3C6A494
	public static object PushArrayInstance(object generator, object argsIndex, object arrayIndex) { }

	// RVA: 0x3C6A818
	public static object BoxIfNeeded(object generator, object type) { }

	// RVA: 0x3C6A5E0
	public static object UnboxIfNeeded(object generator, object type) { }

	// RVA: 0x3C6A704
	public static object CallMethod(object generator, object methodInfo) { }

	// RVA: 0x3C6A91C
	public static object Return(object generator) { }

}

// Namespace: 
internal class ImmutableCollectionTypeInfo
{

	// Fields
	private object <ContractTypeName>k__BackingField; // 0x8
	private object <CreatedTypeName>k__BackingField; // 0x10
	private object <BuilderTypeName>k__BackingField; // 0x18

	// Properties
	public object ContractTypeName { get; set; }
	public object CreatedTypeName { get; set; }
	public object BuilderTypeName { get; set; }

	// Methods

	// RVA: 0x3C71304
	public object .ctor(object contractTypeName, object createdTypeName, object builderTypeName) { }

	// RVA: 0x3C71344
	public object get_ContractTypeName() { }

	// RVA: 0x3C7134C
	public object set_ContractTypeName(object value) { }

	// RVA: 0x3C71354
	public object get_CreatedTypeName() { }

	// RVA: 0x3C7135C
	public object set_CreatedTypeName(object value) { }

	// RVA: 0x3C71364
	public object get_BuilderTypeName() { }

	// RVA: 0x3C7136C
	public object set_BuilderTypeName(object value) { }

}

// Namespace: 
private sealed class <>c__DisplayClass24_0
{

	// Fields
	public object name; // 0x8

	// Methods

	// RVA: 0x3C70000
	public object .ctor() { }

	// RVA: 0x3C71374
	internal object <TryBuildImmutableForArrayContract>b__0(object d) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__24_1; // 0x8
	public static object <>9__25_1; // 0x10

	// Methods

	// RVA: 0x3C713A0
	private static object .cctor() { }

	// RVA: 0x3C71400
	public object .ctor() { }

	// RVA: 0x3C71408
	internal object <TryBuildImmutableForArrayContract>b__24_1(object m) { }

	// RVA: 0x3C714D4
	internal object <TryBuildImmutableForDictionaryContract>b__25_1(object m) { }

}

// Namespace: 
private sealed class <>c__DisplayClass25_0
{

	// Fields
	public object name; // 0x8

	// Methods

	// RVA: 0x3C706B4
	public object .ctor() { }

	// RVA: 0x3C71714
	internal object <TryBuildImmutableForDictionaryContract>b__0(object d) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class ImmutableCollectionsUtils
{

	// Fields
	private static readonly object ArrayContractImmutableCollectionDefinitions; // 0x0
	private static readonly object DictionaryContractImmutableCollectionDefinitions; // 0x8

	// Methods

	// RVA: 0x3C6F9B0
	internal static object TryBuildImmutableForArrayContract(object underlyingType, object collectionItemType, object createdType, object parameterizedCreator) { }

	// RVA: 0x3C7005C
	internal static object TryBuildImmutableForDictionaryContract(object underlyingType, object keyItemType, object valueItemType, object createdType, object parameterizedCreator) { }

	// RVA: 0x3C706BC
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class BufferUtils
{

	// Methods

	// RVA: 0x3C71740
	public static object RentBuffer(object bufferPool, object minSize) { }

	// RVA: 0x3C71830
	public static object ReturnBuffer(object bufferPool, object buffer) { }

	// RVA: 0x3C71908
	public static object EnsureBufferSize(object bufferPool, object size, object buffer) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class JavaScriptUtils
{

	// Fields
	internal static readonly object SingleQuoteCharEscapeFlags; // 0x0
	internal static readonly object DoubleQuoteCharEscapeFlags; // 0x8
	internal static readonly object HtmlCharEscapeFlags; // 0x10

	// Methods

	// RVA: 0x3C71A84
	private static object .cctor() { }

	// RVA: 0x3C729D8
	public static object GetCharEscapeFlags(object stringEscapeHandling, object quoteChar) { }

	// RVA: 0x3C72ABC
	public static object ShouldEscapeJavaScriptString(object s, object charEscapeFlags) { }

	// RVA: 0x3C72B68
	public static object WriteEscapedJavaScriptString(object writer, object s, object delimiter, object appendDelimiters, object charEscapeFlags, object stringEscapeHandling, object bufferPool, object writeBuffer) { }

	// RVA: 0x3C735B0
	public static object ToEscapedJavaScriptString(object value, object delimiter, object appendDelimiters, object stringEscapeHandling) { }

	// RVA: 0x3C733C0
	private static object FirstCharToEscape(object s, object charEscapeFlags, object stringEscapeHandling) { }

	// RVA: 0x3C73944
	public static object TryGetDateFromConstructorJson(object reader, object dateTime, object errorMessage) { }

	// RVA: 0x3C73F38
	private static object TryGetDateConstructorValue(object reader, object integer, object errorMessage) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class JsonTokenUtils
{

	// Methods

	// RVA: 0x3C74180
	internal static object IsEndToken(object token) { }

	// RVA: 0x3C74190
	internal static object IsStartToken(object token) { }

	// RVA: 0x3C741A0
	internal static object IsPrimitiveToken(object token) { }

}

// Namespace: 
private sealed class <>c__DisplayClass3_0
{

	// Fields
	public object c; // 0x8
	public object method; // 0x10

	// Methods

	// RVA: 0x3C743A4
	public object .ctor() { }

	// RVA: 0x3C74414
	internal object <CreateParameterizedConstructor>b__0(object a) { }

	// RVA: 0x3C74438
	internal object <CreateParameterizedConstructor>b__1(object a) { }

}

// Namespace: 
private sealed class <>c__DisplayClass4_0<T0>
{

	// Fields
	public object c; // 0x0
	public object method; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateMethodCall>b__0(object o, object a) { }

	// RVA: -1
	internal object <CreateMethodCall>b__1(object o, object a) { }

}

// Namespace: 
private sealed class <>c__DisplayClass5_0<T0>
{

	// Fields
	public object type; // 0x0
	public object constructorInfo; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateDefaultConstructor>b__0() { }

	// RVA: -1
	internal object <CreateDefaultConstructor>b__1() { }

}

// Namespace: 
private sealed class <>c__DisplayClass6_0<T0>
{

	// Fields
	public object propertyInfo; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateGet>b__0(object o) { }

}

// Namespace: 
private sealed class <>c__DisplayClass7_0<T0>
{

	// Fields
	public object fieldInfo; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateGet>b__0(object o) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0<T0>
{

	// Fields
	public object fieldInfo; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateSet>b__0(object o, object v) { }

}

// Namespace: 
private sealed class <>c__DisplayClass9_0<T0>
{

	// Fields
	public object propertyInfo; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <CreateSet>b__0(object o, object v) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class LateBoundReflectionDelegateFactory
{

	// Fields
	private static readonly object _instance; // 0x0

	// Properties
	internal static object Instance { get; }

	// Methods

	// RVA: 0x3C741B8
	internal static object get_Instance() { }

	// RVA: 0x3C74234
	public override object CreateParameterizedConstructor(object method) { }

	// RVA: -1
	public override object CreateMethodCall(object method) { }

	// RVA: -1
	public override object CreateDefaultConstructor(object type) { }

	// RVA: -1
	public override object CreateGet(object propertyInfo) { }

	// RVA: -1
	public override object CreateGet(object fieldInfo) { }

	// RVA: -1
	public override object CreateSet(object fieldInfo) { }

	// RVA: -1
	public override object CreateSet(object propertyInfo) { }

	// RVA: 0x3C743AC
	public object .ctor() { }

	// RVA: 0x3C743B4
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class MathUtils
{

	// Methods

	// RVA: 0x3C74464
	public static object IntLength(object i) { }

	// RVA: 0x3C7462C
	public static object IntToHex(object n) { }

	// RVA: 0x3C74648
	public static object ApproxEquals(object d1, object d2) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal sealed class MethodCall<T0, T1>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object target, object args) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class MiscellaneousUtils
{

	// Methods

	// RVA: 0x3C746FC
	public static object ValueEquals(object objA, object objB) { }

	// RVA: 0x3C64ECC
	public static object CreateArgumentOutOfRangeException(object paramName, object actualValue, object message) { }

	// RVA: 0x3C74B18
	public static object ToString(object value) { }

	// RVA: 0x3C74BE0
	public static object ByteArrayCompare(object a1, object a2) { }

	// RVA: 0x3C74CBC
	public static object GetPrefix(object qualifiedName) { }

	// RVA: 0x3C74E08
	public static object GetLocalName(object qualifiedName) { }

	// RVA: 0x3C74D5C
	public static object GetQualifiedNameParts(object qualifiedName, object prefix, object localName) { }

	// RVA: 0x3C74E90
	internal static object GetRegexOptions(object optionsText) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal abstract class ReflectionDelegateFactory
{

	// Methods

	// RVA: -1
	public object CreateGet(object memberInfo) { }

	// RVA: -1
	public object CreateSet(object memberInfo) { }

	// RVA: -1
	public abstract object CreateMethodCall(object method) { }

	// RVA: -1
	public abstract object CreateParameterizedConstructor(object method) { }

	// RVA: -1
	public abstract object CreateDefaultConstructor(object type) { }

	// RVA: -1
	public abstract object CreateGet(object propertyInfo) { }

	// RVA: -1
	public abstract object CreateGet(object fieldInfo) { }

	// RVA: -1
	public abstract object CreateSet(object fieldInfo) { }

	// RVA: -1
	public abstract object CreateSet(object propertyInfo) { }

	// RVA: 0x3C6B5AC
	protected object .ctor() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class ReflectionMember
{

	// Fields
	private object <MemberType>k__BackingField; // 0x8
	private object <Getter>k__BackingField; // 0x10
	private object <Setter>k__BackingField; // 0x18

	// Properties
	public object MemberType { get; set; }
	public object Getter { get; set; }
	public object Setter { get; set; }

	// Methods

	// RVA: 0x3C74F4C
	public object get_MemberType() { }

	// RVA: 0x3C74F54
	public object set_MemberType(object value) { }

	// RVA: 0x3C74F5C
	public object get_Getter() { }

	// RVA: 0x3C74F64
	public object set_Getter(object value) { }

	// RVA: 0x3C74F6C
	public object get_Setter() { }

	// RVA: 0x3C74F74
	public object set_Setter(object value) { }

	// RVA: 0x3C74F7C
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_0
{

	// Fields
	public object ctor; // 0x8

	// Methods

	// RVA: 0x3C75F44
	public object .ctor() { }

	// RVA: 0x3C76618
	internal object <Create>b__0(object args) { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_1
{

	// Fields
	public object call; // 0x8

	// Methods

	// RVA: 0x3C76310
	public object .ctor() { }

	// RVA: 0x3C76644
	internal object <Create>b__1(object target) { }

}

// Namespace: 
private sealed class <>c__DisplayClass11_2
{

	// Fields
	public object call; // 0x8

	// Methods

	// RVA: 0x3C76318
	public object .ctor() { }

	// RVA: 0x3C766C8
	internal object <Create>b__2(object target, object arg) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class ReflectionObject
{

	// Fields
	private readonly object <Creator>k__BackingField; // 0x8
	private readonly object <Members>k__BackingField; // 0x10

	// Properties
	public object Creator { get; }
	public object Members { get; }

	// Methods

	// RVA: 0x3C74F84
	public object get_Creator() { }

	// RVA: 0x3C74F8C
	public object get_Members() { }

	// RVA: 0x3C74F94
	private object .ctor(object creator) { }

	// RVA: 0x3C75024
	public object GetValue(object target, object member) { }

	// RVA: 0x3C7514C
	public object SetValue(object target, object member, object value) { }

	// RVA: 0x3C7527C
	public object GetType(object member) { }

	// RVA: 0x3C75378
	public static object Create(object t, object memberNames) { }

	// RVA: 0x3C75384
	public static object Create(object t, object creator, object memberNames) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__11_0; // 0x8
	public static object <>9__31_0; // 0x10
	public static object <>9__39_0; // 0x18
	public static object <>9__41_0; // 0x20

	// Methods

	// RVA: 0x3C7B7D8
	private static object .cctor() { }

	// RVA: 0x3C7B838
	public object .ctor() { }

	// RVA: 0x3C7B840
	internal object <GetDefaultConstructor>b__11_0(object c) { }

	// RVA: 0x3C7B8C8
	internal object <GetFieldsAndProperties>b__31_0(object m) { }

	// RVA: 0x3C7B914
	internal object <GetMemberInfoFromType>b__39_0(object p) { }

	// RVA: 0x3C7B960
	internal object <GetChildPrivateFields>b__41_0(object f) { }

}

// Namespace: 
private sealed class <>c__DisplayClass31_0
{

	// Fields
	public object memberInfo; // 0x8

	// Methods

	// RVA: 0x3C79FF0
	public object .ctor() { }

	// RVA: 0x3C7B984
	internal object <GetFieldsAndProperties>b__1(object m) { }

}

// Namespace: 
private sealed class <>c__DisplayClass44_0
{

	// Fields
	public object subTypeProperty; // 0x8

	// Methods

	// RVA: 0x3C7B390
	public object .ctor() { }

	// RVA: 0x3C7BA64
	internal object <GetChildPrivateProperties>b__0(object p) { }

	// RVA: 0x3C7BB00
	internal object <GetChildPrivateProperties>b__1(object p) { }

}

// Namespace: 
private sealed class <>c__DisplayClass44_1
{

	// Fields
	public object subTypePropertyDeclaringType; // 0x8
	public object CS$<>8__locals1; // 0x10

	// Methods

	// RVA: 0x3C7B398
	public object .ctor() { }

	// RVA: 0x3C7BC64
	internal object <GetChildPrivateProperties>b__2(object p) { }

}

// Namespace: 
private sealed class <>c__DisplayClass45_0
{

	// Fields
	public object method; // 0x8
	public object methodDeclaringType; // 0x10

	// Methods

	// RVA: 0x3C7B4C8
	public object .ctor() { }

	// RVA: 0x3C7BE4C
	internal object <IsMethodOverridden>b__0(object info) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class ReflectionUtils
{

	// Fields
	public static readonly object EmptyTypes; // 0x0

	// Methods

	// RVA: 0x3C767A0
	private static object .cctor() { }

	// RVA: 0x3C7681C
	public static object IsVirtual(object propertyInfo) { }

	// RVA: 0x3C76984
	public static object GetBaseDefinition(object propertyInfo) { }

	// RVA: 0x3C76AD0
	public static object IsPublic(object property) { }

	// RVA: 0x3C6157C
	public static object GetObjectType(object v) { }

	// RVA: 0x3C76B9C
	public static object GetTypeName(object t, object assemblyFormat, object binder) { }

	// RVA: 0x3C76CB8
	private static object GetFullyQualifiedTypeName(object t, object binder) { }

	// RVA: 0x3C76E34
	private static object RemoveAssemblyDetails(object fullyQualifiedTypeName) { }

	// RVA: 0x3C75E10
	public static object HasDefaultConstructor(object t, object nonPublic) { }

	// RVA: 0x3C7713C
	public static object GetDefaultConstructor(object t) { }

	// RVA: 0x3C76FD4
	public static object GetDefaultConstructor(object t, object nonPublic) { }

	// RVA: 0x3C61008
	public static object IsNullable(object t) { }

	// RVA: 0x3C5EE74
	public static object IsNullableType(object t) { }

	// RVA: 0x3C771C4
	public static object EnsureNotNullableType(object t) { }

	// RVA: 0x3C77260
	public static object EnsureNotByRefType(object t) { }

	// RVA: 0x3C772DC
	public static object IsGenericDefinition(object type, object genericInterfaceDefinition) { }

	// RVA: 0x3C5D770
	public static object ImplementsGenericDefinition(object type, object genericInterfaceDefinition) { }

	// RVA: 0x3C773DC
	public static object ImplementsGenericDefinition(object type, object genericInterfaceDefinition, object implementingType) { }

	// RVA: 0x3C7770C
	public static object InheritsGenericDefinition(object type, object genericClassDefinition) { }

	// RVA: 0x3C77784
	public static object InheritsGenericDefinition(object type, object genericClassDefinition, object implementingType) { }

	// RVA: 0x3C77930
	private static object InheritsGenericDefinitionInternal(object currentType, object genericClassDefinition, object implementingType) { }

	// RVA: 0x3C77AEC
	public static object GetCollectionItemType(object type) { }

	// RVA: 0x3C77DF0
	public static object GetDictionaryKeyValueTypes(object dictionaryType, object keyType, object valueType) { }

	// RVA: 0x3C76320
	public static object GetMemberUnderlyingType(object member) { }

	// RVA: 0x3C780C4
	public static object IsByRefLikeType(object type) { }

	// RVA: 0x3C78744
	public static object IsIndexedProperty(object property) { }

	// RVA: 0x3C7880C
	public static object GetMemberValue(object member, object target) { }

	// RVA: 0x3C78B90
	public static object SetMemberValue(object member, object target, object value) { }

	// RVA: 0x3C75F9C
	public static object CanReadMemberValue(object member, object nonPublic) { }

	// RVA: 0x3C76148
	public static object CanSetMemberValue(object member, object nonPublic, object canSetReadOnly) { }

	// RVA: 0x3C78DEC
	public static object GetFieldsAndProperties(object type, object bindingAttr) { }

	// RVA: 0x3C79FF8
	private static object IsOverridenGenericMember(object memberInfo, object bindingAttr) { }

	// RVA: -1
	public static object GetAttribute(object attributeProvider) { }

	// RVA: -1
	public static object GetAttribute(object attributeProvider, object inherit) { }

	// RVA: -1
	public static object GetAttributes(object attributeProvider, object inherit) { }

	// RVA: 0x3C7822C
	public static object GetAttributes(object attributeProvider, object attributeType, object inherit) { }

	// RVA: 0x3C7A2C8
	public static object SplitFullyQualifiedTypeName(object fullyQualifiedTypeName) { }

	// RVA: 0x3C7A3E4
	private static object GetAssemblyDelimiterIndex(object fullyQualifiedTypeName) { }

	// RVA: 0x3C7A69C
	public static object GetMemberInfoFromType(object targetType, object memberInfo) { }

	// RVA: 0x3C79A5C
	public static object GetFields(object targetType, object bindingAttr) { }

	// RVA: 0x3C7A9CC
	private static object GetChildPrivateFields(object initialFields, object targetType, object bindingAttr) { }

	// RVA: 0x3C79BBC
	public static object GetProperties(object targetType, object bindingAttr) { }

	// RVA: 0x3C7ABFC
	public static object RemoveFlag(object bindingAttr, object flag) { }

	// RVA: 0x3C7AC0C
	private static object GetChildPrivateProperties(object initialProperties, object targetType, object bindingAttr) { }

	// RVA: 0x3C7B3A0
	public static object IsMethodOverridden(object currentType, object methodDeclaringType, object method) { }

	// RVA: 0x3C7B4D0
	public static object GetDefaultValue(object type) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal struct StringBuffer
{

	// Fields
	private object _buffer; // 0xFFFFFFFFFFFFFFF8
	private object _position; // 0x0

	// Properties
	public object Position { get; set; }
	public object IsEmpty { get; }
	public object InternalBuffer { get; }

	// Methods

	// RVA: 0x3C7C224
	public object get_Position() { }

	// RVA: 0x3C7C234
	public object set_Position(object value) { }

	// RVA: 0x3C7C244
	public object get_IsEmpty() { }

	// RVA: 0x3C7C264
	public object .ctor(object bufferPool, object initalSize) { }

	// RVA: 0x3C7C294
	private object .ctor(object buffer) { }

	// RVA: 0x3C7C2DC
	public object Append(object bufferPool, object value) { }

	// RVA: 0x3C7C504
	public object Append(object bufferPool, object buffer, object startIndex, object count) { }

	// RVA: 0x3C7C618
	public object Clear(object bufferPool) { }

	// RVA: 0x3C7C368
	private object EnsureSize(object bufferPool, object appendLength) { }

	// RVA: 0x3C7C7E8
	public override object ToString() { }

	// RVA: 0x3C7C800
	public object ToString(object start, object length) { }

	// RVA: 0x3C7C848
	public object get_InternalBuffer() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal struct StringReference
{

	// Fields
	private readonly object _chars; // 0xFFFFFFFFFFFFFFF8
	private readonly object _startIndex; // 0x0
	private readonly object _length; // 0x4

	// Properties
	public object Item { get; }
	public object Chars { get; }
	public object StartIndex { get; }
	public object Length { get; }

	// Methods

	// RVA: 0x3C6630C
	public object get_Item(object i) { }

	// RVA: 0x3C7CAC8
	public object get_Chars() { }

	// RVA: 0x3C7CAD8
	public object get_StartIndex() { }

	// RVA: 0x3C7CAE8
	public object get_Length() { }

	// RVA: 0x3C66B4C
	public object .ctor(object chars, object startIndex, object length) { }

	// RVA: 0x3C6675C
	public override object ToString() { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class StringReferenceExtensions
{

	// Methods

	// RVA: 0x3C67600
	public static object IndexOf(object s, object c, object startIndex, object length) { }

	// RVA: 0x3C66348
	public static object StartsWith(object s, object text) { }

	// RVA: 0x3C66448
	public static object EndsWith(object s, object text) { }

}

// Namespace: 
private sealed class <>c__DisplayClass14_0<T0>
{

	// Fields
	public object valueSelector; // 0x0
	public object testValue; // 0x0

	// Methods

	// RVA: -1
	public object .ctor() { }

	// RVA: -1
	internal object <ForgivingCaseSensitiveFind>b__0(object s) { }

	// RVA: -1
	internal object <ForgivingCaseSensitiveFind>b__1(object s) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class StringUtils
{

	// Methods

	// RVA: 0x3C66754
	public static object IsNullOrEmpty(object value) { }

	// RVA: 0x3C5F9A0
	public static object FormatWith(object format, object provider, object arg0) { }

	// RVA: 0x3C60D00
	public static object FormatWith(object format, object provider, object arg0, object arg1) { }

	// RVA: 0x3C7CBBC
	public static object FormatWith(object format, object provider, object arg0, object arg1, object arg2) { }

	// RVA: 0x3C7CCD8
	public static object FormatWith(object format, object provider, object arg0, object arg1, object arg2, object arg3) { }

	// RVA: 0x3C7CB18
	private static object FormatWith(object format, object provider, object args) { }

	// RVA: 0x3C7387C
	public static object CreateStringWriter(object capacity) { }

	// RVA: 0x3C734F0
	public static object ToCharAsUnicode(object c, object buffer) { }

	// RVA: -1
	public static object ForgivingCaseSensitiveFind(object source, object valueSelector, object testValue) { }

	// RVA: 0x3C7CE20
	public static object ToCamelCase(object s) { }

	// RVA: 0x3C7D30C
	private static object ToLower(object c) { }

	// RVA: 0x3C7D3D4
	public static object IsHighSurrogate(object c) { }

	// RVA: 0x3C7D45C
	public static object IsLowSurrogate(object c) { }

	// RVA: 0x3C7D4E4
	public static object StartsWith(object source, object value) { }

	// RVA: 0x3C7D540
	public static object EndsWith(object source, object value) { }

	// RVA: 0x3C7A4D0
	public static object Trim(object s, object start, object length) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal struct StructMultiKey<T0, T1>
{

	// Fields
	public readonly object Value1; // 0x0
	public readonly object Value2; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object v1, object v2) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public object Equals(object other) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal class ThreadSafeStore<T0, T1>
{

	// Fields
	private readonly object _concurrentStore; // 0x0
	private readonly object _creator; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object creator) { }

	// RVA: -1
	public object Get(object key) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class TypeExtensions
{

	// Methods

	// RVA: 0x3C75F4C
	public static object MemberType(object memberInfo) { }

	// RVA: 0x3C7D598
	public static object ContainsGenericParameters(object type) { }

	// RVA: 0x3C6131C
	public static object IsInterface(object type) { }

	// RVA: 0x3C6FFAC
	public static object IsGenericType(object type) { }

	// RVA: 0x3C6133C
	public static object IsGenericTypeDefinition(object type) { }

	// RVA: 0x3C77A98
	public static object BaseType(object type) { }

	// RVA: 0x3C70008
	public static object Assembly(object type) { }

	// RVA: 0x3C5EE20
	public static object IsEnum(object type) { }

	// RVA: 0x3C77910
	public static object IsClass(object type) { }

	// RVA: 0x3C7D5EC
	public static object IsSealed(object type) { }

	// RVA: 0x3C61390
	public static object IsAbstract(object type) { }

	// RVA: 0x3C7D60C
	public static object IsVisible(object type) { }

	// RVA: 0x3C6A5C0
	public static object IsValueType(object type) { }

	// RVA: 0x3C6A6E4
	public static object IsPrimitive(object type) { }

	// RVA: 0x3C7D62C
	public static object AssignableToTypeName(object type, object fullTypeName, object searchInterfaces, object match) { }

	// RVA: 0x3C7D83C
	public static object AssignableToTypeName(object type, object fullTypeName, object searchInterfaces) { }

	// RVA: 0x3C7D85C
	public static object ImplementInterface(object type, object interfaceType) { }

}

// Namespace: Newtonsoft.Json.Utilities
internal static class ValidationUtils
{

	// Methods

	// RVA: 0x3C5CD78
	public static object ArgumentNotNull(object value, object parameterName) { }

}

// Namespace: Newtonsoft.Json.Serialization
internal static class CachedAttributeGetter<T0>
{

	// Fields
	private static readonly object TypeAttributeCache; // 0x0

	// Methods

	// RVA: -1
	public static object GetAttribute(object type) { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
public class CamelCaseNamingStrategy
{

	// Methods

	// RVA: 0x3C6E768
	public object .ctor() { }

	// RVA: 0x3C7DCF0
	protected override object ResolvePropertyName(object name) { }

}

// Namespace: 
private sealed class <GetEnumerator>d__2
{

	// Fields
	private object <>1__state; // 0x0
	private object <>2__current; // 0x0
	public object <>4__this; // 0x0
	private object <>7__wrap1; // 0x0

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<System.Object,System.Object>>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: -1
	public object .ctor(object <>1__state) { }

	// RVA: -1
	private object System.IDisposable.Dispose() { }

	// RVA: -1
	private object MoveNext() { }

	// RVA: -1
	private object <>m__Finally1() { }

	// RVA: -1
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<System.Object,System.Object>>.get_Current() { }

	// RVA: -1
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: -1
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
internal class EnumerableDictionaryWrapper<T0, T1>
{

	// Fields
	private readonly object _e; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object e) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__40_0; // 0x8
	public static object <>9__40_1; // 0x10
	public static object <>9__44_0; // 0x18
	public static object <>9__44_1; // 0x20
	public static object <>9__47_0; // 0x28
	public static object <>9__75_0; // 0x30

	// Methods

	// RVA: 0x3C87568
	private static object .cctor() { }

	// RVA: 0x3C875C8
	public object .ctor() { }

	// RVA: 0x3C875D0
	internal object <GetSerializableMembers>b__40_0(object m) { }

	// RVA: 0x3C87688
	internal object <GetSerializableMembers>b__40_1(object m) { }

	// RVA: 0x3C87714
	internal object <GetExtensionDataMemberForType>b__44_0(object baseType) { }

	// RVA: 0x3C87828
	internal object <GetExtensionDataMemberForType>b__44_1(object m) { }

	// RVA: 0x3C87CF8
	internal object <GetAttributeConstructor>b__47_0(object c) { }

	// RVA: 0x3C87DD4
	internal object <CreateProperties>b__75_0(object p) { }

}

// Namespace: 
private sealed class <>c__DisplayClass42_0
{

	// Fields
	public object namingStrategy; // 0x8

	// Methods

	// RVA: 0x3C87E38
	public object .ctor() { }

	// RVA: 0x3C87E40
	internal object <CreateObjectContract>b__0(object s) { }

}

// Namespace: 
private sealed class <>c__DisplayClass45_0
{

	// Fields
	public object getExtensionDataDictionary; // 0x8
	public object member; // 0x10

	// Methods

	// RVA: 0x3C87E94
	public object .ctor() { }

}

// Namespace: 
private sealed class <>c__DisplayClass45_1
{

	// Fields
	public object setExtensionDataDictionary; // 0x8
	public object createExtensionDataDictionary; // 0x10
	public object setExtensionDataDictionaryValue; // 0x18
	public object CS$<>8__locals1; // 0x20

	// Methods

	// RVA: 0x3C87E9C
	public object .ctor() { }

	// RVA: 0x3C87EA4
	internal object <SetExtensionDataDelegates>b__0(object o, object key, object value) { }

}

// Namespace: 
private sealed class <>c__DisplayClass45_2
{

	// Fields
	public object createEnumerableWrapper; // 0x8
	public object CS$<>8__locals2; // 0x10

	// Methods

	// RVA: 0x3C880F4
	public object .ctor() { }

	// RVA: 0x3C880FC
	internal object <SetExtensionDataDelegates>b__1(object o) { }

}

// Namespace: 
private sealed class <>c__DisplayClass62_0
{

	// Fields
	public object namingStrategy; // 0x8

	// Methods

	// RVA: 0x3C88240
	public object .ctor() { }

	// RVA: 0x3C88248
	internal object <CreateDictionaryContract>b__0(object s) { }

}

// Namespace: 
private sealed class <>c__DisplayClass67_0
{

	// Fields
	public object namingStrategy; // 0x8

	// Methods

	// RVA: 0x3C8829C
	public object .ctor() { }

	// RVA: 0x3C882A4
	internal object <CreateDynamicContract>b__0(object s) { }

}

// Namespace: 
private sealed class <>c__DisplayClass80_0
{

	// Fields
	public object shouldSerializeCall; // 0x8

	// Methods

	// RVA: 0x3C882F8
	public object .ctor() { }

	// RVA: 0x3C88300
	internal object <CreateShouldSerializeTest>b__0(object o) { }

}

// Namespace: 
private sealed class <>c__DisplayClass81_0
{

	// Fields
	public object specifiedPropertyGet; // 0x8

	// Methods

	// RVA: 0x3C883D0
	public object .ctor() { }

	// RVA: 0x3C883D8
	internal object <SetIsSpecifiedActions>b__0(object o) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class DefaultContractResolver
{

	// Fields
	private static readonly object _instance; // 0x0
	private static readonly object BlacklistedTypeNames; // 0x8
	private static readonly object BuiltInConverters; // 0x10
	private readonly object _nameTable; // 0x8
	private readonly object _contractCache; // 0x10
	private object <DefaultMembersSearchFlags>k__BackingField; // 0x18
	private object <SerializeCompilerGeneratedMembers>k__BackingField; // 0x1C
	private object <IgnoreSerializableInterface>k__BackingField; // 0x1D
	private object <IgnoreSerializableAttribute>k__BackingField; // 0x1E
	private object <IgnoreIsSpecifiedMembers>k__BackingField; // 0x1F
	private object <IgnoreShouldSerializeMembers>k__BackingField; // 0x20
	private object <NamingStrategy>k__BackingField; // 0x28

	// Properties
	internal static object Instance { get; }
	public object DynamicCodeGeneration { get; }
	public object DefaultMembersSearchFlags { get; set; }
	public object SerializeCompilerGeneratedMembers { get; }
	public object IgnoreSerializableInterface { get; }
	public object IgnoreSerializableAttribute { get; set; }
	public object IgnoreIsSpecifiedMembers { get; }
	public object IgnoreShouldSerializeMembers { get; }
	public object NamingStrategy { get; }

	// Methods

	// RVA: 0x3C7DCF8
	internal static object get_Instance() { }

	// RVA: 0x3C7DD74
	public object get_DynamicCodeGeneration() { }

	// RVA: 0x3C7DDE4
	public object get_DefaultMembersSearchFlags() { }

	// RVA: 0x3C7DDEC
	public object set_DefaultMembersSearchFlags(object value) { }

	// RVA: 0x3C7DDF4
	public object get_SerializeCompilerGeneratedMembers() { }

	// RVA: 0x3C7DDFC
	public object get_IgnoreSerializableInterface() { }

	// RVA: 0x3C7DE04
	public object get_IgnoreSerializableAttribute() { }

	// RVA: 0x3C7DE0C
	public object set_IgnoreSerializableAttribute(object value) { }

	// RVA: 0x3C7DE14
	public object get_IgnoreIsSpecifiedMembers() { }

	// RVA: 0x3C7DE1C
	public object get_IgnoreShouldSerializeMembers() { }

	// RVA: 0x3C7DE24
	public object get_NamingStrategy() { }

	// RVA: 0x3C7DE2C
	public object .ctor() { }

	// RVA: 0x3C7DF44
	public virtual object ResolveContract(object type) { }

	// RVA: 0x3C7E004
	private static object FilterMembers(object member) { }

	// RVA: 0x3C7E1A8
	protected virtual object GetSerializableMembers(object objectType) { }

	// RVA: 0x3C7F188
	private object ShouldSerializeEntityMember(object memberInfo) { }

	// RVA: 0x3C7F344
	protected virtual object CreateObjectContract(object objectType) { }

	// RVA: 0x3C81524
	private static object ThrowUnableToSerializeError(object o, object context) { }

	// RVA: 0x3C8090C
	private object GetExtensionDataMemberForType(object type) { }

	// RVA: 0x3C80B08
	private static object SetExtensionDataDelegates(object contract, object member) { }

	// RVA: 0x3C7FDF4
	private object GetAttributeConstructor(object objectType) { }

	// RVA: 0x3C8045C
	private object GetImmutableConstructor(object objectType, object memberProperties) { }

	// RVA: 0x3C803D4
	private object GetParameterizedConstructor(object objectType) { }

	// RVA: 0x3C8192C
	protected virtual object CreateConstructorParameters(object constructor, object memberProperties) { }

	// RVA: 0x3C8186C
	private object MatchProperty(object properties, object name, object type) { }

	// RVA: 0x3C81C0C
	protected virtual object CreatePropertyFromConstructorParameter(object matchingMemberProperty, object parameterInfo) { }

	// RVA: 0x3C82750
	protected virtual object ResolveContractConverter(object objectType) { }

	// RVA: 0x3C827D8
	private object GetDefaultCreator(object createdType) { }

	// RVA: 0x3C7FB14
	private object InitializeContract(object contract) { }

	// RVA: 0x3C828BC
	private object ResolveCallbackMethods(object contract, object t) { }

	// RVA: 0x3C82A50
	private object GetCallbackMethodsForType(object type, object onSerializing, object onSerialized, object onDeserializing, object onDeserialized, object onError) { }

	// RVA: 0x3C83FA0
	private static object IsConcurrentOrObservableCollection(object t) { }

	// RVA: 0x3C836FC
	private static object ShouldSkipDeserialized(object t) { }

	// RVA: 0x3C835CC
	private static object ShouldSkipSerializing(object t) { }

	// RVA: 0x3C815C4
	private object GetClassHierarchyForType(object type) { }

	// RVA: 0x3C84190
	protected virtual object CreateDictionaryContract(object objectType) { }

	// RVA: 0x3C84858
	protected virtual object CreateArrayContract(object objectType) { }

	// RVA: 0x3C84C90
	protected virtual object CreatePrimitiveContract(object objectType) { }

	// RVA: 0x3C84D08
	protected virtual object CreateLinqContract(object objectType) { }

	// RVA: 0x3C84D80
	protected virtual object CreateISerializableContract(object objectType) { }

	// RVA: 0x3C85018
	protected virtual object CreateDynamicContract(object objectType) { }

	// RVA: 0x3C85294
	protected virtual object CreateStringContract(object objectType) { }

	// RVA: 0x3C8530C
	protected virtual object CreateContract(object objectType) { }

	// RVA: 0x3C85A34
	internal static object IsJsonPrimitiveType(object t) { }

	// RVA: 0x3C85C90
	internal static object IsIConvertible(object t) { }

	// RVA: 0x3C85B04
	internal static object CanConvertToString(object type) { }

	// RVA: 0x3C8382C
	private static object IsValidCallback(object method, object parameters, object attributeType, object currentCallback, object prevAttributeType) { }

	// RVA: 0x3C85EB8
	internal static object GetClrTypeFullName(object type) { }

	// RVA: 0x3C86030
	protected virtual object CreateProperties(object type, object memberSerialization) { }

	// RVA: 0x3C86508
	internal virtual object GetNameTable() { }

	// RVA: 0x3C86510
	protected virtual object CreateMemberValueProvider(object member) { }

	// RVA: 0x3C86628
	protected virtual object CreateProperty(object member, object memberSerialization) { }

	// RVA: 0x3C81F78
	private object SetPropertySettingsFromAttributes(object property, object attributeProvider, object name, object declaringType, object memberSerialization, object allowNonPublicAccess) { }

	// RVA: 0x3C8687C
	private object CreateShouldSerializeTest(object member) { }

	// RVA: 0x3C86B90
	private object SetIsSpecifiedActions(object property, object member, object allowNonPublicAccess) { }

	// RVA: 0x3C86F68
	protected virtual object ResolvePropertyName(object propertyName) { }

	// RVA: 0x3C86FC4
	protected virtual object ResolveExtensionDataName(object extensionDataName) { }

	// RVA: 0x3C8701C
	protected virtual object ResolveDictionaryKey(object dictionaryKey) { }

	// RVA: 0x3C870A4
	public object GetResolvedPropertyName(object propertyName) { }

	// RVA: 0x3C870F0
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
internal class DefaultReferenceResolver
{

	// Fields
	private object _referenceCount; // 0x8

	// Methods

	// RVA: 0x3C88484
	private object GetMappings(object context) { }

	// RVA: 0x3C886B8
	public object ResolveReference(object context, object reference) { }

	// RVA: 0x3C88740
	public object GetReference(object context, object value) { }

	// RVA: 0x3C88848
	public object AddReference(object context, object reference, object value) { }

	// RVA: 0x3C888C0
	public object IsReferenced(object context, object value) { }

	// RVA: 0x3C88944
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
public class DefaultSerializationBinder
{

	// Fields
	internal static readonly object Instance; // 0x0
	private readonly object _typeCache; // 0x8

	// Methods

	// RVA: 0x3C8894C
	public object .ctor() { }

	// RVA: 0x3C88A20
	private object GetTypeFromTypeNameKey(object typeNameKey) { }

	// RVA: 0x3C88ED4
	private object GetGenericTypeFromTypeName(object typeName, object assembly) { }

	// RVA: 0x3C8936C
	private object GetTypeByName(object typeNameKey) { }

	// RVA: 0x3C893E0
	public override object BindToType(object assemblyName, object typeName) { }

	// RVA: 0x3C894AC
	public override object BindToName(object serializedType, object assemblyName, object typeName) { }

	// RVA: 0x3C8957C
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
public class DynamicValueProvider
{

	// Fields
	private readonly object _memberInfo; // 0x8
	private object _getter; // 0x10
	private object _setter; // 0x18

	// Methods

	// RVA: 0x3C895D8
	public object .ctor(object memberInfo) { }

	// RVA: 0x3C89648
	public object SetValue(object target, object value) { }

	// RVA: 0x3C898A4
	public object GetValue(object target) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class ErrorContext
{

	// Fields
	private object <Traced>k__BackingField; // 0x8
	private readonly object <Error>k__BackingField; // 0x10
	private readonly object <OriginalObject>k__BackingField; // 0x18
	private readonly object <Member>k__BackingField; // 0x20
	private readonly object <Path>k__BackingField; // 0x28
	private object <Handled>k__BackingField; // 0x30

	// Properties
	internal object Traced { get; set; }
	public object Error { get; }
	public object Handled { get; }

	// Methods

	// RVA: 0x3C89AF4
	internal object .ctor(object originalObject, object member, object path, object error) { }

	// RVA: 0x3C89B40
	internal object get_Traced() { }

	// RVA: 0x3C89B48
	internal object set_Traced(object value) { }

	// RVA: 0x3C89B50
	public object get_Error() { }

	// RVA: 0x3C89B58
	public object get_Handled() { }

}

// Namespace: Newtonsoft.Json.Serialization
public class ErrorEventArgs
{

	// Fields
	private readonly object <CurrentObject>k__BackingField; // 0x8
	private readonly object <ErrorContext>k__BackingField; // 0x10

	// Methods

	// RVA: 0x3C89B60
	public object .ctor(object currentObject, object errorContext) { }

}

// Namespace: Newtonsoft.Json.Serialization
public interface IAttributeProvider
{
}

// Namespace: Newtonsoft.Json.Serialization
public interface IContractResolver
{

	// Methods

	// RVA: -1
	public abstract object ResolveContract(object type) { }

}

// Namespace: Newtonsoft.Json.Serialization
public interface IReferenceResolver
{

	// Methods

	// RVA: -1
	public abstract object ResolveReference(object context, object reference) { }

	// RVA: -1
	public abstract object GetReference(object context, object value) { }

	// RVA: -1
	public abstract object IsReferenced(object context, object value) { }

	// RVA: -1
	public abstract object AddReference(object context, object reference, object value) { }

}

// Namespace: Newtonsoft.Json.Serialization
public interface ISerializationBinder
{

	// Methods

	// RVA: -1
	public abstract object BindToType(object assemblyName, object typeName) { }

	// RVA: -1
	public abstract object BindToName(object serializedType, object assemblyName, object typeName) { }

}

// Namespace: Newtonsoft.Json.Serialization
public interface ITraceWriter
{

	// Properties
	public abstract object LevelFilter { get; }

	// Methods

	// RVA: -1
	public abstract object get_LevelFilter() { }

	// RVA: -1
	public abstract object Trace(object level, object message, object ex) { }

}

// Namespace: Newtonsoft.Json.Serialization
public interface IValueProvider
{

	// Methods

	// RVA: -1
	public abstract object SetValue(object target, object value) { }

	// RVA: -1
	public abstract object GetValue(object target) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonArrayContract
{

	// Fields
	private readonly object <CollectionItemType>k__BackingField; // 0xB8
	private readonly object <IsMultidimensionalArray>k__BackingField; // 0xC0
	private readonly object _genericCollectionDefinitionType; // 0xC8
	private object _genericWrapperType; // 0xD0
	private object _genericWrapperCreator; // 0xD8
	private object _genericTemporaryCollectionCreator; // 0xE0
	private readonly object <IsArray>k__BackingField; // 0xE8
	private readonly object <ShouldCreateWrapper>k__BackingField; // 0xE9
	private object <CanDeserialize>k__BackingField; // 0xEA
	private readonly object _parameterizedConstructor; // 0xF0
	private object _parameterizedCreator; // 0xF8
	private object _overrideCreator; // 0x100
	private object <HasParameterizedCreator>k__BackingField; // 0x108

	// Properties
	public object CollectionItemType { get; }
	public object IsMultidimensionalArray { get; }
	internal object IsArray { get; }
	internal object ShouldCreateWrapper { get; }
	internal object CanDeserialize { get; set; }
	internal object ParameterizedCreator { get; }
	public object OverrideCreator { get; set; }
	public object HasParameterizedCreator { get; set; }
	internal object HasParameterizedCreatorInternal { get; }

	// Methods

	// RVA: 0x3C89BDC
	public object get_CollectionItemType() { }

	// RVA: 0x3C89BE4
	public object get_IsMultidimensionalArray() { }

	// RVA: 0x3C89BEC
	internal object get_IsArray() { }

	// RVA: 0x3C89BF4
	internal object get_ShouldCreateWrapper() { }

	// RVA: 0x3C89BFC
	internal object get_CanDeserialize() { }

	// RVA: 0x3C89C04
	private object set_CanDeserialize(object value) { }

	// RVA: 0x3C89C0C
	internal object get_ParameterizedCreator() { }

	// RVA: 0x3C89D34
	public object get_OverrideCreator() { }

	// RVA: 0x3C89D3C
	public object set_OverrideCreator(object value) { }

	// RVA: 0x3C89D4C
	public object get_HasParameterizedCreator() { }

	// RVA: 0x3C89D54
	public object set_HasParameterizedCreator(object value) { }

	// RVA: 0x3C89D5C
	internal object get_HasParameterizedCreatorInternal() { }

	// RVA: 0x3C89DF8
	public object .ctor(object underlyingType) { }

	// RVA: 0x3C8B764
	internal object CreateWrapper(object list) { }

	// RVA: 0x3C8BC28
	internal object CreateTemporaryCollection() { }

	// RVA: 0x3C8B580
	private object StoreFSharpListCreatorIfNecessary(object underlyingType) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonContainerContract
{

	// Fields
	private object _itemContract; // 0x88
	private object _finalItemContract; // 0x90
	private object <ItemConverter>k__BackingField; // 0x98
	private object <ItemIsReference>k__BackingField; // 0xA0
	private object <ItemReferenceLoopHandling>k__BackingField; // 0xA4
	private object <ItemTypeNameHandling>k__BackingField; // 0xAC

	// Properties
	internal object ItemContract { get; set; }
	internal object FinalItemContract { get; }
	public object ItemConverter { get; set; }
	public object ItemIsReference { get; set; }
	public object ItemReferenceLoopHandling { get; set; }
	public object ItemTypeNameHandling { get; set; }

	// Methods

	// RVA: 0x3C8BEF0
	internal object get_ItemContract() { }

	// RVA: 0x3C8BEF8
	internal object set_ItemContract(object value) { }

	// RVA: 0x3C8BF48
	internal object get_FinalItemContract() { }

	// RVA: 0x3C8BF50
	public object get_ItemConverter() { }

	// RVA: 0x3C8BF58
	public object set_ItemConverter(object value) { }

	// RVA: 0x3C8BF60
	public object get_ItemIsReference() { }

	// RVA: 0x3C8BF68
	public object set_ItemIsReference(object value) { }

	// RVA: 0x3C8BF70
	public object get_ItemReferenceLoopHandling() { }

	// RVA: 0x3C8BF78
	public object set_ItemReferenceLoopHandling(object value) { }

	// RVA: 0x3C8BF80
	public object get_ItemTypeNameHandling() { }

	// RVA: 0x3C8BF88
	public object set_ItemTypeNameHandling(object value) { }

	// RVA: 0x3C8B3A0
	internal object .ctor(object underlyingType) { }

}

// Namespace: Newtonsoft.Json.Serialization
internal enum JsonContractType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Object;
	public const object Array;
	public const object Primitive;
	public const object String;
	public const object Dictionary;
	public const object Dynamic;
	public const object Serializable;
	public const object Linq;
}

// Namespace: Newtonsoft.Json.Serialization
public sealed class SerializationCallback
{

	// Methods

	// RVA: 0x3C8C4C0
	public object .ctor(object object, object method) { }

	// RVA: 0x3C8C5CC
	public virtual object Invoke(object o, object context) { }

}

// Namespace: Newtonsoft.Json.Serialization
public sealed class SerializationErrorCallback
{

	// Methods

	// RVA: 0x3C8C96C
	public object .ctor(object object, object method) { }

	// RVA: 0x3C8CA78
	public virtual object Invoke(object o, object context, object errorContext) { }

}

// Namespace: Newtonsoft.Json.Serialization
public sealed class ExtensionDataSetter
{

	// Methods

	// RVA: 0x3C8CDD8
	public object .ctor(object object, object method) { }

	// RVA: 0x3C8CEE4
	public virtual object Invoke(object o, object key, object value) { }

}

// Namespace: Newtonsoft.Json.Serialization
public sealed class ExtensionDataGetter
{

	// Methods

	// RVA: 0x3C8D1E4
	public object .ctor(object object, object method) { }

	// RVA: 0x3C8D300
	public virtual object Invoke(object o) { }

}

// Namespace: 
private sealed class <>c__DisplayClass57_0
{

	// Fields
	public object callbackMethodInfo; // 0x8

	// Methods

	// RVA: 0x3C8DEA8
	public object .ctor() { }

	// RVA: 0x3C8DF70
	internal object <CreateSerializationCallback>b__0(object o, object context) { }

}

// Namespace: 
private sealed class <>c__DisplayClass58_0
{

	// Fields
	public object callbackMethodInfo; // 0x8

	// Methods

	// RVA: 0x3C8DF68
	public object .ctor() { }

	// RVA: 0x3C8E084
	internal object <CreateSerializationErrorCallback>b__0(object o, object context, object econtext) { }

}

// Namespace: Newtonsoft.Json.Serialization
public abstract class JsonContract
{

	// Fields
	internal object IsNullable; // 0x8
	internal object IsConvertable; // 0x9
	internal object IsEnum; // 0xA
	internal object NonNullableUnderlyingType; // 0x10
	internal object InternalReadType; // 0x18
	internal object ContractType; // 0x1C
	internal object IsReadOnlyOrFixedSize; // 0x20
	internal object IsSealed; // 0x21
	internal object IsInstantiable; // 0x22
	private object _onDeserializedCallbacks; // 0x28
	private object _onDeserializingCallbacks; // 0x30
	private object _onSerializedCallbacks; // 0x38
	private object _onSerializingCallbacks; // 0x40
	private object _onErrorCallbacks; // 0x48
	private object _createdType; // 0x50
	private readonly object <UnderlyingType>k__BackingField; // 0x58
	private object <IsReference>k__BackingField; // 0x60
	private object <Converter>k__BackingField; // 0x68
	private object <InternalConverter>k__BackingField; // 0x70
	private object <DefaultCreator>k__BackingField; // 0x78
	private object <DefaultCreatorNonPublic>k__BackingField; // 0x80

	// Properties
	public object UnderlyingType { get; }
	public object CreatedType { get; set; }
	public object IsReference { get; set; }
	public object Converter { get; set; }
	public object InternalConverter { get; set; }
	public object OnDeserializedCallbacks { get; }
	public object OnDeserializingCallbacks { get; }
	public object OnSerializedCallbacks { get; }
	public object OnSerializingCallbacks { get; }
	public object OnErrorCallbacks { get; }
	public object DefaultCreator { get; set; }
	public object DefaultCreatorNonPublic { get; set; }

	// Methods

	// RVA: 0x3C8D314
	public object get_UnderlyingType() { }

	// RVA: 0x3C8D31C
	public object get_CreatedType() { }

	// RVA: 0x3C8B4D0
	public object set_CreatedType(object value) { }

	// RVA: 0x3C8D324
	public object get_IsReference() { }

	// RVA: 0x3C8D32C
	public object set_IsReference(object value) { }

	// RVA: 0x3C8D334
	public object get_Converter() { }

	// RVA: 0x3C8D33C
	public object set_Converter(object value) { }

	// RVA: 0x3C8D344
	public object get_InternalConverter() { }

	// RVA: 0x3C8D34C
	internal object set_InternalConverter(object value) { }

	// RVA: 0x3C8D354
	public object get_OnDeserializedCallbacks() { }

	// RVA: 0x3C8D3E4
	public object get_OnDeserializingCallbacks() { }

	// RVA: 0x3C8D474
	public object get_OnSerializedCallbacks() { }

	// RVA: 0x3C8D504
	public object get_OnSerializingCallbacks() { }

	// RVA: 0x3C8D594
	public object get_OnErrorCallbacks() { }

	// RVA: 0x3C8D624
	public object get_DefaultCreator() { }

	// RVA: 0x3C8D62C
	public object set_DefaultCreator(object value) { }

	// RVA: 0x3C8D634
	public object get_DefaultCreatorNonPublic() { }

	// RVA: 0x3C8D63C
	public object set_DefaultCreatorNonPublic(object value) { }

	// RVA: 0x3C8BF90
	internal object .ctor(object underlyingType) { }

	// RVA: 0x3C8D644
	internal object InvokeOnSerializing(object o, object context) { }

	// RVA: 0x3C8D7F0
	internal object InvokeOnSerialized(object o, object context) { }

	// RVA: 0x3C8D95C
	internal object InvokeOnDeserializing(object o, object context) { }

	// RVA: 0x3C8DAC8
	internal object InvokeOnDeserialized(object o, object context) { }

	// RVA: 0x3C8DC34
	internal object InvokeOnError(object o, object context, object errorContext) { }

	// RVA: 0x3C8DDF0
	internal static object CreateSerializationCallback(object callbackMethodInfo) { }

	// RVA: 0x3C8DEB0
	internal static object CreateSerializationErrorCallback(object callbackMethodInfo) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonDictionaryContract
{

	// Fields
	private object <DictionaryKeyResolver>k__BackingField; // 0xB8
	private readonly object <DictionaryKeyType>k__BackingField; // 0xC0
	private readonly object <DictionaryValueType>k__BackingField; // 0xC8
	private object <KeyContract>k__BackingField; // 0xD0
	private readonly object _genericCollectionDefinitionType; // 0xD8
	private object _genericWrapperType; // 0xE0
	private object _genericWrapperCreator; // 0xE8
	private object _genericTemporaryDictionaryCreator; // 0xF0
	private readonly object <ShouldCreateWrapper>k__BackingField; // 0xF8
	private readonly object _parameterizedConstructor; // 0x100
	private object _overrideCreator; // 0x108
	private object _parameterizedCreator; // 0x110
	private object <HasParameterizedCreator>k__BackingField; // 0x118

	// Properties
	public object DictionaryKeyResolver { get; set; }
	public object DictionaryKeyType { get; }
	public object DictionaryValueType { get; }
	internal object KeyContract { get; set; }
	internal object ShouldCreateWrapper { get; }
	internal object ParameterizedCreator { get; }
	public object OverrideCreator { get; set; }
	public object HasParameterizedCreator { get; set; }
	internal object HasParameterizedCreatorInternal { get; }

	// Methods

	// RVA: 0x3C8E1C4
	public object get_DictionaryKeyResolver() { }

	// RVA: 0x3C8E1CC
	public object set_DictionaryKeyResolver(object value) { }

	// RVA: 0x3C8E1D4
	public object get_DictionaryKeyType() { }

	// RVA: 0x3C8E1DC
	public object get_DictionaryValueType() { }

	// RVA: 0x3C8E1E4
	internal object get_KeyContract() { }

	// RVA: 0x3C8E1EC
	internal object set_KeyContract(object value) { }

	// RVA: 0x3C8E1F4
	internal object get_ShouldCreateWrapper() { }

	// RVA: 0x3C8E1FC
	internal object get_ParameterizedCreator() { }

	// RVA: 0x3C8E324
	public object get_OverrideCreator() { }

	// RVA: 0x3C8E32C
	public object set_OverrideCreator(object value) { }

	// RVA: 0x3C8E334
	public object get_HasParameterizedCreator() { }

	// RVA: 0x3C8E33C
	public object set_HasParameterizedCreator(object value) { }

	// RVA: 0x3C8E344
	internal object get_HasParameterizedCreatorInternal() { }

	// RVA: 0x3C8E3E0
	public object .ctor(object underlyingType) { }

	// RVA: 0x3C8F348
	internal object CreateWrapper(object dictionary) { }

	// RVA: 0x3C8F650
	internal object CreateTemporaryDictionary() { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonDynamicContract
{

	// Fields
	private readonly object <Properties>k__BackingField; // 0xB8
	private object <PropertyNameResolver>k__BackingField; // 0xC0
	private readonly object _callSiteGetters; // 0xC8
	private readonly object _callSiteSetters; // 0xD0

	// Properties
	public object Properties { get; }
	public object PropertyNameResolver { get; set; }

	// Methods

	// RVA: 0x3C8F938
	public object get_Properties() { }

	// RVA: 0x3C8F940
	public object get_PropertyNameResolver() { }

	// RVA: 0x3C8F948
	public object set_PropertyNameResolver(object value) { }

	// RVA: 0x3C8F950
	private static object CreateCallSiteGetter(object name) { }

	// RVA: 0x3C8FA78
	private static object CreateCallSiteSetter(object name) { }

	// RVA: 0x3C8FBA0
	public object .ctor(object underlyingType) { }

	// RVA: 0x3C8FEE8
	internal object TryGetMember(object dynamicProvider, object name, object value) { }

	// RVA: 0x3C90018
	internal object TrySetMember(object dynamicProvider, object name, object value) { }

}

// Namespace: Newtonsoft.Json.Serialization
internal class JsonFormatterConverter
{

	// Fields
	private readonly object _reader; // 0x8
	private readonly object _contract; // 0x10
	private readonly object _member; // 0x18

	// Methods

	// RVA: 0x3C90140
	public object .ctor(object reader, object contract, object member) { }

	// RVA: -1
	private object GetTokenValue(object value) { }

	// RVA: 0x3C901F0
	public object Convert(object value, object type) { }

	// RVA: 0x3C90504
	public object ToBoolean(object value) { }

	// RVA: 0x3C90564
	public object ToInt32(object value) { }

	// RVA: 0x3C905C4
	public object ToInt64(object value) { }

	// RVA: 0x3C90624
	public object ToSingle(object value) { }

	// RVA: 0x3C90684
	public object ToString(object value) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonISerializableContract
{

	// Fields
	private object <ISerializableCreator>k__BackingField; // 0xB8

	// Properties
	public object ISerializableCreator { get; set; }

	// Methods

	// RVA: 0x3C906E4
	public object get_ISerializableCreator() { }

	// RVA: 0x3C906EC
	public object set_ISerializableCreator(object value) { }

	// RVA: 0x3C906F4
	public object .ctor(object underlyingType) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonLinqContract
{

	// Methods

	// RVA: 0x3C9071C
	public object .ctor(object underlyingType) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonObjectContract
{

	// Fields
	private object <MemberSerialization>k__BackingField; // 0xB4
	private object <MissingMemberHandling>k__BackingField; // 0xB8
	private object <ItemRequired>k__BackingField; // 0xC0
	private object <ItemNullValueHandling>k__BackingField; // 0xC8
	private readonly object <Properties>k__BackingField; // 0xD0
	private object <ExtensionDataSetter>k__BackingField; // 0xD8
	private object <ExtensionDataGetter>k__BackingField; // 0xE0
	private object <ExtensionDataNameResolver>k__BackingField; // 0xE8
	internal object ExtensionDataIsJToken; // 0xF0
	private object _hasRequiredOrDefaultValueProperties; // 0xF1
	private object _overrideCreator; // 0xF8
	private object _parameterizedCreator; // 0x100
	private object _creatorParameters; // 0x108
	private object _extensionDataValueType; // 0x110

	// Properties
	public object MemberSerialization { get; set; }
	public object MissingMemberHandling { get; set; }
	public object ItemRequired { get; set; }
	public object ItemNullValueHandling { get; set; }
	public object Properties { get; }
	public object CreatorParameters { get; }
	public object OverrideCreator { get; set; }
	internal object ParameterizedCreator { get; set; }
	public object ExtensionDataSetter { get; set; }
	public object ExtensionDataGetter { get; set; }
	public object ExtensionDataValueType { set; }
	public object ExtensionDataNameResolver { get; set; }
	internal object HasRequiredOrDefaultValueProperties { get; }

	// Methods

	// RVA: 0x3C90744
	public object get_MemberSerialization() { }

	// RVA: 0x3C9074C
	public object set_MemberSerialization(object value) { }

	// RVA: 0x3C90754
	public object get_MissingMemberHandling() { }

	// RVA: 0x3C9075C
	public object set_MissingMemberHandling(object value) { }

	// RVA: 0x3C90764
	public object get_ItemRequired() { }

	// RVA: 0x3C9076C
	public object set_ItemRequired(object value) { }

	// RVA: 0x3C90774
	public object get_ItemNullValueHandling() { }

	// RVA: 0x3C9077C
	public object set_ItemNullValueHandling(object value) { }

	// RVA: 0x3C90784
	public object get_Properties() { }

	// RVA: 0x3C9078C
	public object get_CreatorParameters() { }

	// RVA: 0x3C90818
	public object get_OverrideCreator() { }

	// RVA: 0x3C90820
	public object set_OverrideCreator(object value) { }

	// RVA: 0x3C90828
	internal object get_ParameterizedCreator() { }

	// RVA: 0x3C90830
	internal object set_ParameterizedCreator(object value) { }

	// RVA: 0x3C90838
	public object get_ExtensionDataSetter() { }

	// RVA: 0x3C90840
	public object set_ExtensionDataSetter(object value) { }

	// RVA: 0x3C90848
	public object get_ExtensionDataGetter() { }

	// RVA: 0x3C90850
	public object set_ExtensionDataGetter(object value) { }

	// RVA: 0x3C90858
	public object set_ExtensionDataValueType(object value) { }

	// RVA: 0x3C90984
	public object get_ExtensionDataNameResolver() { }

	// RVA: 0x3C9098C
	public object set_ExtensionDataNameResolver(object value) { }

	// RVA: 0x3C90994
	internal object get_HasRequiredOrDefaultValueProperties() { }

	// RVA: 0x3C90E38
	public object .ctor(object underlyingType) { }

	// RVA: 0x3C90EB8
	internal object GetUninitializedObject() { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonPrimitiveContract
{

	// Fields
	private object <TypeCode>k__BackingField; // 0x84
	private static readonly object ReadTypeMap; // 0x0

	// Properties
	internal object TypeCode { get; set; }

	// Methods

	// RVA: 0x3C90FF8
	internal object get_TypeCode() { }

	// RVA: 0x3C91000
	internal object set_TypeCode(object value) { }

	// RVA: 0x3C91008
	public object .ctor(object underlyingType) { }

	// RVA: 0x3C91110
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonProperty
{

	// Fields
	internal object _required; // 0x8
	internal object _hasExplicitDefaultValue; // 0x10
	private object _defaultValue; // 0x18
	private object _hasGeneratedDefaultValue; // 0x20
	private object _propertyName; // 0x28
	internal object _skipPropertyNameEscape; // 0x30
	private object _propertyType; // 0x38
	private object <PropertyContract>k__BackingField; // 0x40
	private object <DeclaringType>k__BackingField; // 0x48
	private object <Order>k__BackingField; // 0x50
	private object <UnderlyingName>k__BackingField; // 0x58
	private object <ValueProvider>k__BackingField; // 0x60
	private object <AttributeProvider>k__BackingField; // 0x68
	private object <Converter>k__BackingField; // 0x70
	private object <Ignored>k__BackingField; // 0x78
	private object <Readable>k__BackingField; // 0x79
	private object <Writable>k__BackingField; // 0x7A
	private object <HasMemberAttribute>k__BackingField; // 0x7B
	private object <IsReference>k__BackingField; // 0x7C
	private object <NullValueHandling>k__BackingField; // 0x80
	private object <DefaultValueHandling>k__BackingField; // 0x88
	private object <ReferenceLoopHandling>k__BackingField; // 0x90
	private object <ObjectCreationHandling>k__BackingField; // 0x98
	private object <TypeNameHandling>k__BackingField; // 0xA0
	private object <ShouldSerialize>k__BackingField; // 0xA8
	private object <ShouldDeserialize>k__BackingField; // 0xB0
	private object <GetIsSpecified>k__BackingField; // 0xB8
	private object <SetIsSpecified>k__BackingField; // 0xC0
	private object <ItemConverter>k__BackingField; // 0xC8
	private object <ItemIsReference>k__BackingField; // 0xD0
	private object <ItemTypeNameHandling>k__BackingField; // 0xD4
	private object <ItemReferenceLoopHandling>k__BackingField; // 0xDC

	// Properties
	internal object PropertyContract { get; set; }
	public object PropertyName { get; set; }
	public object DeclaringType { get; set; }
	public object Order { get; set; }
	public object UnderlyingName { get; set; }
	public object ValueProvider { get; set; }
	public object AttributeProvider { set; }
	public object PropertyType { get; set; }
	public object Converter { get; set; }
	public object Ignored { get; set; }
	public object Readable { get; set; }
	public object Writable { get; set; }
	public object HasMemberAttribute { get; set; }
	public object DefaultValue { get; set; }
	public object Required { get; }
	public object IsReference { get; set; }
	public object NullValueHandling { get; set; }
	public object DefaultValueHandling { get; set; }
	public object ReferenceLoopHandling { get; set; }
	public object ObjectCreationHandling { get; set; }
	public object TypeNameHandling { get; set; }
	public object ShouldSerialize { get; set; }
	public object ShouldDeserialize { get; }
	public object GetIsSpecified { get; set; }
	public object SetIsSpecified { get; set; }
	public object ItemConverter { get; set; }
	public object ItemIsReference { get; set; }
	public object ItemTypeNameHandling { get; set; }
	public object ItemReferenceLoopHandling { get; set; }

	// Methods

	// RVA: 0x3C91474
	internal object get_PropertyContract() { }

	// RVA: 0x3C9147C
	internal object set_PropertyContract(object value) { }

	// RVA: 0x3C91484
	public object get_PropertyName() { }

	// RVA: 0x3C9148C
	public object set_PropertyName(object value) { }

	// RVA: 0x3C91510
	public object get_DeclaringType() { }

	// RVA: 0x3C91518
	public object set_DeclaringType(object value) { }

	// RVA: 0x3C91520
	public object get_Order() { }

	// RVA: 0x3C91528
	public object set_Order(object value) { }

	// RVA: 0x3C91530
	public object get_UnderlyingName() { }

	// RVA: 0x3C91538
	public object set_UnderlyingName(object value) { }

	// RVA: 0x3C91540
	public object get_ValueProvider() { }

	// RVA: 0x3C91548
	public object set_ValueProvider(object value) { }

	// RVA: 0x3C91550
	public object set_AttributeProvider(object value) { }

	// RVA: 0x3C91558
	public object get_PropertyType() { }

	// RVA: 0x3C91560
	public object set_PropertyType(object value) { }

	// RVA: 0x3C91614
	public object get_Converter() { }

	// RVA: 0x3C9161C
	public object set_Converter(object value) { }

	// RVA: 0x3C91624
	public object get_Ignored() { }

	// RVA: 0x3C9162C
	public object set_Ignored(object value) { }

	// RVA: 0x3C91634
	public object get_Readable() { }

	// RVA: 0x3C9163C
	public object set_Readable(object value) { }

	// RVA: 0x3C91644
	public object get_Writable() { }

	// RVA: 0x3C9164C
	public object set_Writable(object value) { }

	// RVA: 0x3C91654
	public object get_HasMemberAttribute() { }

	// RVA: 0x3C9165C
	public object set_HasMemberAttribute(object value) { }

	// RVA: 0x3C91664
	public object get_DefaultValue() { }

	// RVA: 0x3C91680
	public object set_DefaultValue(object value) { }

	// RVA: 0x3C91690
	internal object GetResolvedDefaultValue() { }

	// RVA: 0x3C90DF8
	public object get_Required() { }

	// RVA: 0x3C91760
	public object get_IsReference() { }

	// RVA: 0x3C91768
	public object set_IsReference(object value) { }

	// RVA: 0x3C91770
	public object get_NullValueHandling() { }

	// RVA: 0x3C91778
	public object set_NullValueHandling(object value) { }

	// RVA: 0x3C91780
	public object get_DefaultValueHandling() { }

	// RVA: 0x3C91788
	public object set_DefaultValueHandling(object value) { }

	// RVA: 0x3C91790
	public object get_ReferenceLoopHandling() { }

	// RVA: 0x3C91798
	public object set_ReferenceLoopHandling(object value) { }

	// RVA: 0x3C917A0
	public object get_ObjectCreationHandling() { }

	// RVA: 0x3C917A8
	public object set_ObjectCreationHandling(object value) { }

	// RVA: 0x3C917B0
	public object get_TypeNameHandling() { }

	// RVA: 0x3C917B8
	public object set_TypeNameHandling(object value) { }

	// RVA: 0x3C917C0
	public object get_ShouldSerialize() { }

	// RVA: 0x3C917C8
	public object set_ShouldSerialize(object value) { }

	// RVA: 0x3C917D0
	public object get_ShouldDeserialize() { }

	// RVA: 0x3C917D8
	public object get_GetIsSpecified() { }

	// RVA: 0x3C917E0
	public object set_GetIsSpecified(object value) { }

	// RVA: 0x3C917E8
	public object get_SetIsSpecified() { }

	// RVA: 0x3C917F0
	public object set_SetIsSpecified(object value) { }

	// RVA: 0x3C917F8
	public override object ToString() { }

	// RVA: 0x3C91864
	public object get_ItemConverter() { }

	// RVA: 0x3C9186C
	public object set_ItemConverter(object value) { }

	// RVA: 0x3C91874
	public object get_ItemIsReference() { }

	// RVA: 0x3C9187C
	public object set_ItemIsReference(object value) { }

	// RVA: 0x3C91884
	public object get_ItemTypeNameHandling() { }

	// RVA: 0x3C9188C
	public object set_ItemTypeNameHandling(object value) { }

	// RVA: 0x3C91894
	public object get_ItemReferenceLoopHandling() { }

	// RVA: 0x3C9189C
	public object set_ItemReferenceLoopHandling(object value) { }

	// RVA: 0x3C918A4
	internal object WritePropertyName(object writer) { }

	// RVA: 0x3C91950
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonPropertyCollection
{

	// Fields
	private readonly object _type; // 0x28
	private readonly object _list; // 0x30

	// Methods

	// RVA: 0x3C8FD48
	public object .ctor(object type) { }

	// RVA: 0x3C91958
	protected override object GetKeyForItem(object item) { }

	// RVA: 0x3C91978
	public object AddProperty(object property) { }

	// RVA: 0x3C91CC4
	public object GetClosestMatchProperty(object propertyName) { }

	// RVA: 0x3C91E70
	private object TryGetValue(object key, object item) { }

	// RVA: 0x3C91D64
	public object GetProperty(object propertyName, object comparisonType) { }

}

// Namespace: 
private class ReferenceEqualsEqualityComparer
{

	// Methods

	// RVA: 0x3C927F4
	private object System.Collections.Generic.IEqualityComparer<System.Object>.Equals(object x, object y) { }

	// RVA: 0x3C92800
	private object System.Collections.Generic.IEqualityComparer<System.Object>.GetHashCode(object obj) { }

	// RVA: 0x3C9201C
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
internal abstract class JsonSerializerInternalBase
{

	// Fields
	private object _currentErrorContext; // 0x8
	private object _mappings; // 0x10
	internal readonly object Serializer; // 0x18
	internal readonly object TraceWriter; // 0x20
	protected object InternalSerializer; // 0x28

	// Properties
	internal object DefaultReferenceMappings { get; }

	// Methods

	// RVA: 0x3C91F74
	protected object .ctor(object serializer) { }

	// RVA: 0x3C8859C
	internal object get_DefaultReferenceMappings() { }

	// RVA: 0x3C92024
	protected object ResolvedNullValueHandling(object containerContract, object property) { }

	// RVA: 0x3C920E0
	private object GetErrorContext(object currentObject, object member, object path, object error) { }

	// RVA: 0x3C921D8
	protected object ClearErrorContext() { }

	// RVA: 0x3C9223C
	protected object IsErrorHandled(object currentObject, object contract, object keyValue, object lineInfo, object path, object ex) { }

}

// Namespace: 
internal enum PropertyPresence
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Null;
	public const object Value;
}

// Namespace: 
internal class CreatorPropertyContext
{

	// Fields
	public readonly object Name; // 0x8
	public object Property; // 0x10
	public object ConstructorProperty; // 0x18
	public object Presence; // 0x20
	public object Value; // 0x28
	public object Used; // 0x30

	// Methods

	// RVA: 0x3CA0448
	public object .ctor(object name) { }

}

// Namespace: 
private sealed class <>c__DisplayClass38_0
{

	// Fields
	public object property; // 0x8

	// Methods

	// RVA: 0x3CA0440
	public object .ctor() { }

	// RVA: 0x3CA10C0
	internal object <CreateObjectUsingCreatorWithParameters>b__1(object p) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__38_0; // 0x8
	public static object <>9__38_2; // 0x10
	public static object <>9__42_0; // 0x18
	public static object <>9__42_1; // 0x20

	// Methods

	// RVA: 0x3CA10EC
	private static object .cctor() { }

	// RVA: 0x3CA114C
	public object .ctor() { }

	// RVA: 0x3CA1154
	internal object <CreateObjectUsingCreatorWithParameters>b__38_0(object p) { }

	// RVA: 0x3CA1174
	internal object <CreateObjectUsingCreatorWithParameters>b__38_2(object p) { }

	// RVA: 0x3CA1194
	internal object <PopulateObject>b__42_0(object m) { }

	// RVA: 0x3CA119C
	internal object <PopulateObject>b__42_1(object m) { }

}

// Namespace: Newtonsoft.Json.Serialization
internal class JsonSerializerInternalReader
{

	// Methods

	// RVA: 0x3C9280C
	public object .ctor(object serializer) { }

	// RVA: 0x3C928B4
	private object GetContractSafe(object type) { }

	// RVA: 0x3C92964
	private object GetContract(object type) { }

	// RVA: 0x3C92A4C
	public object Deserialize(object reader, object objectType, object checkAdditionalContent) { }

	// RVA: 0x3C93B10
	private object GetInternalSerializer() { }

	// RVA: 0x3C93B90
	private object CreateJToken(object reader, object contract) { }

	// RVA: 0x3C94010
	private object CreateJObject(object reader) { }

	// RVA: 0x3C93494
	private object CreateValueInternal(object reader, object objectType, object contract, object member, object containerContract, object containerMember, object existingValue) { }

	// RVA: 0x3C960D4
	private static object CoerceEmptyStringToNull(object objectType, object contract, object s) { }

	// RVA: 0x3C9622C
	internal object GetExpectedDescription(object contract) { }

	// RVA: 0x3C92EA0
	private object GetConverter(object contract, object memberConverter, object containerContract, object containerProperty) { }

	// RVA: 0x3C945AC
	private object CreateObject(object reader, object objectType, object contract, object member, object containerContract, object containerMember, object existingValue) { }

	// RVA: 0x3C962F0
	private object ReadMetadataPropertiesToken(object reader, object objectType, object contract, object member, object containerContract, object containerMember, object existingValue, object newValue, object id) { }

	// RVA: 0x3C96B5C
	private object ReadMetadataProperties(object reader, object objectType, object contract, object member, object containerContract, object containerMember, object existingValue, object newValue, object id) { }

	// RVA: 0x3C9A42C
	private object ResolveTypeName(object reader, object objectType, object contract, object member, object containerContract, object containerMember, object qualifiedTypeName) { }

	// RVA: 0x3C9AB1C
	private object EnsureArrayContract(object reader, object objectType, object contract) { }

	// RVA: 0x3C951A4
	private object CreateList(object reader, object objectType, object contract, object member, object existingValue, object id) { }

	// RVA: 0x3C972F0
	private object HasNoDefinedType(object contract) { }

	// RVA: 0x3C95A74
	private object EnsureType(object reader, object value, object culture, object contract, object targetType) { }

	// RVA: 0x3C9BF98
	private object SetPropertyValue(object property, object propertyConverter, object containerContract, object containerProperty, object reader, object target) { }

	// RVA: 0x3C9C580
	private object CalculatePropertyDetails(object property, object propertyConverter, object containerContract, object containerProperty, object reader, object target, object useExistingValue, object currentValue, object propertyContract, object gottenCurrentValue, object ignoredValue) { }

	// RVA: 0x3C9CE6C
	private object AddReference(object reader, object id, object value) { }

	// RVA: 0x3C9CE60
	private object HasFlag(object value, object flag) { }

	// RVA: 0x3C9CCC8
	private object ShouldSetPropertyValue(object property, object contract, object value) { }

	// RVA: 0x3C9ACA0
	private object CreateNewList(object reader, object contract, object createdFromNonDefaultCreator) { }

	// RVA: 0x3C983EC
	private object CreateNewDictionary(object reader, object contract, object createdFromNonDefaultCreator) { }

	// RVA: 0x3C9D2D0
	private object OnDeserializing(object reader, object contract, object value) { }

	// RVA: 0x3C9D588
	private object OnDeserialized(object reader, object contract, object value) { }

	// RVA: 0x3C986B8
	private object PopulateDictionary(object dictionary, object reader, object contract, object containerProperty, object id) { }

	// RVA: 0x3C9B700
	private object PopulateMultidimensionalArray(object list, object reader, object contract, object containerProperty, object id) { }

	// RVA: 0x3C9D840
	private object ThrowUnexpectedEndException(object reader, object contract, object currentObject, object message) { }

	// RVA: 0x3C9B004
	private object PopulateList(object list, object reader, object contract, object containerProperty, object id) { }

	// RVA: 0x3C99BF0
	private object CreateISerializable(object reader, object contract, object member, object id) { }

	// RVA: 0x3C9031C
	internal object CreateISerializableItem(object token, object type, object contract, object member) { }

	// RVA: 0x3C99344
	private object CreateDynamic(object reader, object contract, object member, object id) { }

	// RVA: 0x3C9D9E8
	private object CreateObjectUsingCreatorWithParameters(object reader, object contract, object containerProperty, object creator, object id) { }

	// RVA: 0x3C92F3C
	private object DeserializeConvertable(object converter, object reader, object objectType, object existingValue) { }

	// RVA: 0x3C9F9EC
	private object ResolvePropertyAndCreatorValues(object contract, object containerProperty, object reader, object objectType) { }

	// RVA: 0x3C973F0
	public object CreateNewObject(object reader, object objectContract, object containerMember, object containerProperty, object id, object createdFromNonDefaultCreator) { }

	// RVA: 0x3C976F4
	private object PopulateObject(object newObject, object reader, object contract, object member, object id) { }

	// RVA: 0x3CA0C60
	private object ShouldDeserialize(object reader, object property, object target) { }

	// RVA: 0x3C94454
	private object CheckPropertyName(object reader, object memberName) { }

	// RVA: 0x3CA0A34
	private object SetExtensionData(object contract, object member, object reader, object memberName, object o) { }

	// RVA: 0x3CA0958
	private object ReadExtensionDataValue(object contract, object member, object reader) { }

	// RVA: 0x3CA04B4
	private object EndProcessProperty(object newObject, object reader, object contract, object initialDepth, object property, object presence, object setDefaultValue) { }

	// RVA: 0x3CA0F38
	private object SetPropertyPresence(object reader, object property, object requiredProperties) { }

	// RVA: 0x3C93A20
	private object HandleError(object reader, object readPastError, object initialDepth) { }

}

// Namespace: Newtonsoft.Json.Serialization
internal class JsonSerializerInternalWriter
{

	// Fields
	private object _rootType; // 0x30
	private object _rootLevel; // 0x38
	private readonly object _serializeStack; // 0x40

	// Methods

	// RVA: 0x3CA11A4
	public object .ctor(object serializer) { }

	// RVA: 0x3CA12A8
	public object Serialize(object jsonWriter, object value, object objectType) { }

	// RVA: 0x3CA22F8
	private object GetInternalSerializer() { }

	// RVA: 0x3CA1524
	private object GetContractSafe(object value) { }

	// RVA: 0x3CA2378
	private object GetContract(object value) { }

	// RVA: 0x3CA2480
	private object SerializePrimitive(object writer, object value, object contract, object member, object containerContract, object containerProperty) { }

	// RVA: 0x3CA1AC8
	private object SerializeValue(object writer, object value, object valueContract, object member, object containerContract, object containerProperty) { }

	// RVA: 0x3CA6194
	private object ResolveIsReference(object contract, object property, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA1534
	private object ShouldWriteReference(object value, object property, object valueContract, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA6258
	private object ShouldWriteProperty(object memberValue, object containerContract, object property) { }

	// RVA: 0x3CA63DC
	private object CheckForCircularReference(object writer, object value, object property, object contract, object containerContract, object containerProperty) { }

	// RVA: 0x3CA1788
	private object WriteReference(object writer, object value) { }

	// RVA: 0x3CA686C
	private object GetReference(object writer, object value) { }

	// RVA: 0x3CA6AA8
	internal static object TryConvertToString(object value, object type, object s) { }

	// RVA: 0x3CA46E8
	private object SerializeString(object writer, object value, object contract) { }

	// RVA: 0x3CA6BFC
	private object OnSerializing(object writer, object contract, object value) { }

	// RVA: 0x3CA6E80
	private object OnSerialized(object writer, object contract, object value) { }

	// RVA: 0x3CA3324
	private object SerializeObject(object writer, object value, object contract, object member, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA72F0
	private object CalculatePropertyValues(object writer, object value, object contract, object member, object property, object memberContract, object memberValue) { }

	// RVA: 0x3CA7104
	private object WriteObjectStart(object writer, object value, object contract, object member, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA8340
	private object HasCreatorParameter(object contract, object property) { }

	// RVA: 0x3CA846C
	private object WriteReferenceIdProperty(object writer, object type, object value) { }

	// RVA: 0x3CA2904
	private object WriteTypeProperty(object writer, object type) { }

	// RVA: 0x3CA63D0
	private object HasFlag(object value, object flag) { }

	// RVA: 0x3CA624C
	private object HasFlag(object value, object flag) { }

	// RVA: 0x3CA8748
	private object HasFlag(object value, object flag) { }

	// RVA: 0x3CA2C44
	private object SerializeConvertable(object writer, object converter, object value, object contract, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA3BE4
	private object SerializeList(object writer, object values, object contract, object member, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA440C
	private object SerializeMultidimensionalArray(object writer, object values, object contract, object member, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA8B38
	private object SerializeMultidimensionalArray(object writer, object values, object contract, object member, object initialDepth, object indices) { }

	// RVA: 0x3CA8754
	private object WriteStartArray(object writer, object values, object contract, object member, object containerContract, object containerProperty) { }

	// RVA: 0x3CA5BD0
	private object SerializeISerializable(object writer, object value, object contract, object member, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA5254
	private object SerializeDynamic(object writer, object value, object contract, object member, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA8F2C
	private object ShouldWriteDynamicProperty(object memberValue) { }

	// RVA: 0x3CA264C
	private object ShouldWriteType(object typeNameHandlingFlag, object contract, object member, object containerContract, object containerProperty) { }

	// RVA: 0x3CA47A8
	private object SerializeDictionary(object writer, object values, object contract, object member, object collectionContract, object containerProperty) { }

	// RVA: 0x3CA77C4
	private object GetPropertyName(object writer, object name, object contract, object escape) { }

	// RVA: 0x3CA21FC
	private object HandleError(object writer, object initialDepth) { }

	// RVA: 0x3CA7DC0
	private object ShouldSerialize(object writer, object property, object target) { }

	// RVA: 0x3CA8080
	private object IsSpecified(object writer, object property, object target) { }

}

// Namespace: Newtonsoft.Json.Serialization
internal class JsonSerializerProxy
{

	// Fields
	private readonly object _serializerReader; // 0xD8
	private readonly object _serializerWriter; // 0xE0
	private readonly object _serializer; // 0xE8

	// Properties
	public override object ReferenceResolver { set; }
	public override object TraceWriter { get; set; }
	public override object EqualityComparer { set; }
	public override object Converters { get; }
	public override object DefaultValueHandling { set; }
	public override object ContractResolver { get; set; }
	public override object MissingMemberHandling { set; }
	public override object NullValueHandling { get; set; }
	public override object ObjectCreationHandling { set; }
	public override object ReferenceLoopHandling { set; }
	public override object PreserveReferencesHandling { set; }
	public override object TypeNameHandling { set; }
	public override object MetadataPropertyHandling { get; set; }
	public override object TypeNameAssemblyFormatHandling { set; }
	public override object ConstructorHandling { set; }
	public override object SerializationBinder { set; }
	public override object Context { get; set; }
	public override object Formatting { get; }
	public override object CheckAdditionalContent { get; }

	// Methods

	// RVA: 0x3CA9008
	public override object add_Error(object value) { }

	// RVA: 0x3CA905C
	public override object remove_Error(object value) { }

	// RVA: 0x3CA90B0
	public override object set_ReferenceResolver(object value) { }

	// RVA: 0x3CA9104
	public override object get_TraceWriter() { }

	// RVA: 0x3CA9150
	public override object set_TraceWriter(object value) { }

	// RVA: 0x3CA91A4
	public override object set_EqualityComparer(object value) { }

	// RVA: 0x3CA91F8
	public override object get_Converters() { }

	// RVA: 0x3CA9248
	public override object set_DefaultValueHandling(object value) { }

	// RVA: 0x3CA92A0
	public override object get_ContractResolver() { }

	// RVA: 0x3CA92F0
	public override object set_ContractResolver(object value) { }

	// RVA: 0x3CA9348
	public override object set_MissingMemberHandling(object value) { }

	// RVA: 0x3CA93A0
	public override object get_NullValueHandling() { }

	// RVA: 0x3CA93F0
	public override object set_NullValueHandling(object value) { }

	// RVA: 0x3CA9448
	public override object set_ObjectCreationHandling(object value) { }

	// RVA: 0x3CA94A0
	public override object set_ReferenceLoopHandling(object value) { }

	// RVA: 0x3CA94F8
	public override object set_PreserveReferencesHandling(object value) { }

	// RVA: 0x3CA9550
	public override object set_TypeNameHandling(object value) { }

	// RVA: 0x3CA95A4
	public override object get_MetadataPropertyHandling() { }

	// RVA: 0x3CA95F4
	public override object set_MetadataPropertyHandling(object value) { }

	// RVA: 0x3CA964C
	public override object set_TypeNameAssemblyFormatHandling(object value) { }

	// RVA: 0x3CA96A0
	public override object set_ConstructorHandling(object value) { }

	// RVA: 0x3CA96F8
	public override object set_SerializationBinder(object value) { }

	// RVA: 0x3CA974C
	public override object get_Context() { }

	// RVA: 0x3CA979C
	public override object set_Context(object value) { }

	// RVA: 0x3CA9804
	public override object get_Formatting() { }

	// RVA: 0x3CA9854
	public override object get_CheckAdditionalContent() { }

	// RVA: 0x3CA98A4
	internal object GetInternalSerializer() { }

	// RVA: 0x3CA98C0
	public object .ctor(object serializerReader) { }

	// RVA: 0x3CA9948
	public object .ctor(object serializerWriter) { }

	// RVA: 0x3CA99D0
	internal override object DeserializeInternal(object reader, object objectType) { }

	// RVA: 0x3CA9A0C
	internal override object SerializeInternal(object jsonWriter, object value, object rootType) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class JsonStringContract
{

	// Methods

	// RVA: 0x3CA9A44
	public object .ctor(object underlyingType) { }

}

// Namespace: 
private sealed class <>c__DisplayClass22_0
{

	// Fields
	public object type; // 0x8
	public object defaultConstructor; // 0x10

	// Methods

	// RVA: 0x3CAA980
	public object .ctor() { }

	// RVA: 0x3CAB4E8
	internal object <GetCreator>b__0(object parameters) { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__22_1; // 0x8

	// Methods

	// RVA: 0x3CAB974
	private static object .cctor() { }

	// RVA: 0x3CAB9D4
	public object .ctor() { }

	// RVA: 0x3CAB9DC
	internal object <GetCreator>b__22_1(object param) { }

}

// Namespace: Newtonsoft.Json.Serialization
internal static class JsonTypeReflector
{

	// Fields
	private static object _dynamicCodeGeneration; // 0x0
	private static object _fullyTrusted; // 0x2
	private static readonly object CreatorCache; // 0x8
	private static readonly object AssociatedMetadataTypesCache; // 0x10
	private static object _metadataTypeAttributeReflectionObject; // 0x18

	// Properties
	public static object DynamicCodeGeneration { get; }
	public static object FullyTrusted { get; }
	public static object ReflectionDelegateFactory { get; }

	// Methods

	// RVA: -1
	public static object GetCachedAttribute(object attributeProvider) { }

	// RVA: 0x3CA9ABC
	public static object CanTypeDescriptorConvertString(object type, object typeConverter) { }

	// RVA: 0x3CA9D24
	public static object GetDataContractAttribute(object type) { }

	// RVA: 0x3CA9E10
	public static object GetDataMemberAttribute(object memberInfo) { }

	// RVA: 0x3CAA118
	public static object GetObjectMemberSerialization(object objectType, object ignoreSerializableAttribute) { }

	// RVA: 0x3CAA360
	public static object GetJsonConverter(object attributeProvider) { }

	// RVA: 0x3CAA4BC
	public static object CreateJsonConverterInstance(object converterType, object args) { }

	// RVA: 0x3CAA5E0
	public static object CreateNamingStrategyInstance(object namingStrategyType, object args) { }

	// RVA: 0x3CAA704
	public static object GetContainerNamingStrategy(object containerAttribute) { }

	// RVA: 0x3CAA7E0
	private static object GetCreator(object type) { }

	// RVA: 0x3CAAAD0
	private static object GetAssociatedMetadataType(object type) { }

	// RVA: 0x3CAAB7C
	private static object GetAssociateMetadataTypeFromAttribute(object type) { }

	// RVA: -1
	private static object GetAttribute(object type) { }

	// RVA: -1
	private static object GetAttribute(object memberInfo) { }

	// RVA: 0x3CAAE50
	public static object IsNonSerializable(object provider) { }

	// RVA: 0x3CAA2D8
	public static object IsSerializable(object provider) { }

	// RVA: -1
	public static object GetAttribute(object provider) { }

	// RVA: 0x3CAAED8
	public static object get_DynamicCodeGeneration() { }

	// RVA: 0x3CAB210
	public static object get_FullyTrusted() { }

	// RVA: 0x3CAA988
	public static object get_ReflectionDelegateFactory() { }

	// RVA: 0x3CAB368
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
public abstract class NamingStrategy
{

	// Fields
	private object <ProcessDictionaryKeys>k__BackingField; // 0x8
	private object <ProcessExtensionDataNames>k__BackingField; // 0x9
	private object <OverrideSpecifiedNames>k__BackingField; // 0xA

	// Properties
	public object ProcessDictionaryKeys { get; }
	public object ProcessExtensionDataNames { get; }
	public object OverrideSpecifiedNames { get; }

	// Methods

	// RVA: 0x3CABA40
	public object get_ProcessDictionaryKeys() { }

	// RVA: 0x3CABA48
	public object get_ProcessExtensionDataNames() { }

	// RVA: 0x3CABA50
	public object get_OverrideSpecifiedNames() { }

	// RVA: 0x3CABA58
	public virtual object GetPropertyName(object name, object hasSpecifiedName) { }

	// RVA: 0x3CABAB8
	public virtual object GetExtensionDataName(object name) { }

	// RVA: 0x3CABB14
	public virtual object GetDictionaryKey(object key) { }

	// RVA: -1
	protected abstract object ResolvePropertyName(object name) { }

	// RVA: 0x3CABB70
	public override object GetHashCode() { }

	// RVA: 0x3CABC80
	public override object Equals(object obj) { }

	// RVA: 0x3CABD1C
	protected object Equals(object other) { }

	// RVA: 0x3CABE2C
	protected object .ctor() { }

}

// Namespace: Newtonsoft.Json.Serialization
public sealed class ObjectConstructor<T0>
{

	// Methods

	// RVA: -1
	public object .ctor(object object, object method) { }

	// RVA: -1
	public virtual object Invoke(object args) { }

}

// Namespace: Newtonsoft.Json.Serialization
public sealed class OnErrorAttribute
{
}

// Namespace: Newtonsoft.Json.Serialization
public class ReflectionAttributeProvider
{

	// Fields
	private readonly object _attributeProvider; // 0x8

	// Methods

	// RVA: 0x3CABE34
	public object .ctor(object attributeProvider) { }

}

// Namespace: Newtonsoft.Json.Serialization
public class ReflectionValueProvider
{

	// Fields
	private readonly object _memberInfo; // 0x8

	// Methods

	// RVA: 0x3CABEA4
	public object .ctor(object memberInfo) { }

	// RVA: 0x3CABF14
	public object SetValue(object target, object value) { }

	// RVA: 0x3CAC0CC
	public object GetValue(object target) { }

}

// Namespace: Newtonsoft.Json.Serialization
internal class TraceJsonReader
{

	// Fields
	private readonly object _innerReader; // 0x70
	private readonly object _textWriter; // 0x78
	private readonly object _sw; // 0x80

	// Properties
	public override object Depth { get; }
	public override object Path { get; }
	public override object TokenType { get; }
	public override object Value { get; }
	public override object ValueType { get; }
	private object Newtonsoft.Json.IJsonLineInfo.LineNumber { get; }
	private object Newtonsoft.Json.IJsonLineInfo.LinePosition { get; }

	// Methods

	// RVA: 0x3CAC3B4
	public object .ctor(object innerReader) { }

	// RVA: 0x3CAC524
	public object GetDeserializedJsonMessage() { }

	// RVA: 0x3CAC570
	public override object Read() { }

	// RVA: 0x3CAC67C
	public override object ReadAsInt32() { }

	// RVA: 0x3CAC724
	public override object ReadAsString() { }

	// RVA: 0x3CAC7CC
	public override object ReadAsBytes() { }

	// RVA: 0x3CAC878
	public override object ReadAsDecimal() { }

	// RVA: 0x3CAC920
	public override object ReadAsDouble() { }

	// RVA: 0x3CAC9D4
	public override object ReadAsBoolean() { }

	// RVA: 0x3CACA80
	public override object ReadAsDateTime() { }

	// RVA: 0x3CACB34
	public override object ReadAsDateTimeOffset() { }

	// RVA: 0x3CAC618
	public object WriteCurrentToken() { }

	// RVA: 0x3CACBDC
	public override object get_Depth() { }

	// RVA: 0x3CACC28
	public override object get_Path() { }

	// RVA: 0x3CACC74
	public override object get_TokenType() { }

	// RVA: 0x3CACCC0
	public override object get_Value() { }

	// RVA: 0x3CACD0C
	public override object get_ValueType() { }

	// RVA: 0x3CACD58
	public override object Close() { }

	// RVA: 0x3CACDA8
	private object Newtonsoft.Json.IJsonLineInfo.HasLineInfo() { }

	// RVA: 0x3CACE98
	private object Newtonsoft.Json.IJsonLineInfo.get_LineNumber() { }

	// RVA: 0x3CACF8C
	private object Newtonsoft.Json.IJsonLineInfo.get_LinePosition() { }

}

// Namespace: Newtonsoft.Json.Serialization
internal class TraceJsonWriter
{

	// Fields
	private readonly object _innerWriter; // 0x58
	private readonly object _textWriter; // 0x60
	private readonly object _sw; // 0x68

	// Methods

	// RVA: 0x3CAD080
	public object .ctor(object innerWriter) { }

	// RVA: 0x3CAD2B0
	public object GetSerializedJsonMessage() { }

	// RVA: 0x3CAD2FC
	public override object WriteValue(object value) { }

	// RVA: 0x3CAD3C0
	public override object WriteValue(object value) { }

	// RVA: 0x3CAD534
	public override object WriteValue(object value) { }

	// RVA: 0x3CAD5E8
	public override object WriteValue(object value) { }

	// RVA: 0x3CAD6E4
	public override object WriteValue(object value) { }

	// RVA: 0x3CAD798
	public override object WriteValue(object value) { }

	// RVA: 0x3CAD898
	public override object WriteValue(object value) { }

	// RVA: 0x3CAD94C
	public override object WriteValue(object value) { }

	// RVA: 0x3CADA50
	public override object WriteValue(object value) { }

	// RVA: 0x3CADB1C
	public override object WriteValue(object value) { }

	// RVA: 0x3CADBD0
	public override object WriteValue(object value) { }

	// RVA: 0x3CADCD4
	public override object WriteValue(object value) { }

	// RVA: 0x3CADD98
	public override object WriteValue(object value) { }

	// RVA: 0x3CADEF0
	public override object WriteValue(object value) { }

	// RVA: 0x3CADFA4
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE0AC
	public override object WriteUndefined() { }

	// RVA: 0x3CAE148
	public override object WriteNull() { }

	// RVA: 0x3CAE1E4
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE298
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE398
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE45C
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE5B8
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE66C
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE768
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE81C
	public override object WriteValue(object value) { }

	// RVA: 0x3CAE920
	public override object WriteValue(object value) { }

	// RVA: 0x3CAEAC4
	public override object WriteValue(object value) { }

	// RVA: 0x3CAEB78
	public override object WriteValue(object value) { }

	// RVA: 0x3CAEC74
	public override object WriteValue(object value) { }

	// RVA: 0x3CAED28
	public override object WriteValue(object value) { }

	// RVA: 0x3CAEE28
	public override object WriteValue(object value) { }

	// RVA: 0x3CAEEDC
	public override object WriteValue(object value) { }

	// RVA: 0x3CAEF90
	public override object WriteValue(object value) { }

	// RVA: 0x3CAF094
	public override object WriteValue(object value) { }

	// RVA: 0x3CAF148
	public override object WriteValue(object value) { }

	// RVA: 0x3CAF244
	public override object WriteValue(object value) { }

	// RVA: 0x3CAF2F8
	public override object WriteValue(object value) { }

	// RVA: 0x3CAF3FC
	public override object WriteValue(object value) { }

	// RVA: 0x3CAF528
	public override object WriteValue(object value) { }

	// RVA: 0x3CAF5DC
	public override object WriteValue(object value) { }

	// RVA: 0x3CAF6E0
	public override object WriteComment(object text) { }

	// RVA: 0x3CAF794
	public override object WriteStartArray() { }

	// RVA: 0x3CAF828
	public override object WriteEndArray() { }

	// RVA: 0x3CAF8BC
	public override object WriteStartConstructor(object name) { }

	// RVA: 0x3CAF968
	public override object WriteEndConstructor() { }

	// RVA: 0x3CAF9FC
	public override object WritePropertyName(object name) { }

	// RVA: 0x3CAFAB0
	public override object WritePropertyName(object name, object escape) { }

	// RVA: 0x3CAFB70
	public override object WriteStartObject() { }

	// RVA: 0x3CAFC04
	public override object WriteEndObject() { }

	// RVA: 0x3CAFC98
	public override object WriteRawValue(object json) { }

	// RVA: 0x3CAFD4C
	public override object WriteRaw(object json) { }

	// RVA: 0x3CAFE00
	public override object Close() { }

}

// Namespace: Newtonsoft.Json.Linq
public enum CommentHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Ignore;
	public const object Load;
}

// Namespace: Newtonsoft.Json.Linq
public enum DuplicatePropertyNameHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Replace;
	public const object Ignore;
	public const object Error;
}

// Namespace: Newtonsoft.Json.Linq
public static class Extensions
{

	// Methods

	// RVA: -1
	internal static object Convert(object token) { }

}

// Namespace: Newtonsoft.Json.Linq
public class JArray
{

	// Fields
	private readonly object _values; // 0x48

	// Properties
	protected override object ChildrenTokens { get; }
	public override object Type { get; }
	public override object Item { get; }
	public object Item { get; set; }
	public object IsReadOnly { get; }

	// Methods

	// RVA: 0x3CAFE94
	protected override object get_ChildrenTokens() { }

	// RVA: 0x3CAFE9C
	public override object get_Type() { }

	// RVA: 0x3CAFEA4
	public object .ctor() { }

	// RVA: 0x3CB0008
	public object .ctor(object other) { }

	// RVA: 0x3CB049C
	public object .ctor(object content) { }

	// RVA: 0x3CB058C
	internal override object CloneToken() { }

	// RVA: 0x3CB0650
	public static object Load(object reader, object settings) { }

	// RVA: 0x3CB0C40
	public override object WriteTo(object writer, object converters) { }

	// RVA: 0x3CB0D88
	public override object get_Item(object key) { }

	// RVA: 0x3CB0EDC
	public object get_Item(object index) { }

	// RVA: 0x3CB0F28
	public object set_Item(object index, object value) { }

	// RVA: 0x3CB0F84
	internal override object IndexOfItem(object item) { }

	// RVA: 0x3CB0FF8
	public object IndexOf(object item) { }

	// RVA: 0x3CB1044
	public object Insert(object index, object item) { }

	// RVA: 0x3CB10A4
	public object RemoveAt(object index) { }

	// RVA: 0x3CB10F0
	public object GetEnumerator() { }

	// RVA: 0x3CB11A0
	public object Add(object item) { }

	// RVA: 0x3CB11EC
	public object Clear() { }

	// RVA: 0x3CB1230
	public object Contains(object item) { }

	// RVA: 0x3CB127C
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x3CB12D8
	public object get_IsReadOnly() { }

	// RVA: 0x3CB12E0
	public object Remove(object item) { }

}

// Namespace: Newtonsoft.Json.Linq
public class JConstructor
{

	// Fields
	private object _name; // 0x48
	private readonly object _values; // 0x50

	// Properties
	protected override object ChildrenTokens { get; }
	public object Name { get; }
	public override object Type { get; }
	public override object Item { get; }

	// Methods

	// RVA: 0x3CB132C
	protected override object get_ChildrenTokens() { }

	// RVA: 0x3CB1334
	internal override object IndexOfItem(object item) { }

	// RVA: 0x3CB13A8
	public object get_Name() { }

	// RVA: 0x3CB13B0
	public override object get_Type() { }

	// RVA: 0x3CB13B8
	public object .ctor(object other) { }

	// RVA: 0x3CB1460
	public object .ctor(object name) { }

	// RVA: 0x3CB15F8
	internal override object CloneToken() { }

	// RVA: 0x3CB16D4
	public override object WriteTo(object writer, object converters) { }

	// RVA: 0x3CB1840
	public override object get_Item(object key) { }

	// RVA: 0x3CB1994
	public static object Load(object reader, object settings) { }

}

// Namespace: Newtonsoft.Json.Linq
public abstract class JContainer
{

	// Fields
	internal object _listChanged; // 0x28
	internal object _collectionChanged; // 0x30
	private object _syncRoot; // 0x38
	private object _busy; // 0x40

	// Properties
	protected abstract object ChildrenTokens { get; }
	public override object HasValues { get; }
	public override object First { get; }
	public override object Last { get; }
	private object System.Collections.Generic.IList<Newtonsoft.Json.Linq.JToken>.Item { get; set; }
	private object System.Collections.Generic.ICollection<Newtonsoft.Json.Linq.JToken>.IsReadOnly { get; }
	private object System.Collections.IList.IsFixedSize { get; }
	private object System.Collections.IList.IsReadOnly { get; }
	private object System.Collections.IList.Item { get; set; }
	public object Count { get; }
	private object System.Collections.ICollection.IsSynchronized { get; }
	private object System.Collections.ICollection.SyncRoot { get; }

	// Methods

	// RVA: -1
	protected abstract object get_ChildrenTokens() { }

	// RVA: 0x3CAFF80
	internal object .ctor() { }

	// RVA: 0x3CB0094
	internal object .ctor(object other) { }

	// RVA: 0x3CB20C4
	internal object CheckReentrancy() { }

	// RVA: 0x3CB216C
	protected virtual object OnListChanged(object e) { }

	// RVA: 0x3CB21FC
	protected virtual object OnCollectionChanged(object e) { }

	// RVA: 0x3CB228C
	public override object get_HasValues() { }

	// RVA: 0x3CB238C
	public override object get_First() { }

	// RVA: 0x3CB2534
	public override object get_Last() { }

	// RVA: 0x3CB26DC
	public override object Children() { }

	// RVA: 0x3CB2768
	internal object IsMultiContent(object content) { }

	// RVA: 0x3CB2864
	internal object EnsureParentToken(object item, object skipParentCheck) { }

	// RVA: -1
	internal abstract object IndexOfItem(object item) { }

	// RVA: 0x3CB2A64
	internal virtual object InsertItem(object index, object item, object skipParentCheck) { }

	// RVA: 0x3CB2F7C
	internal virtual object RemoveItemAt(object index) { }

	// RVA: 0x3CB3540
	internal virtual object RemoveItem(object item) { }

	// RVA: 0x3CB35E0
	internal virtual object GetItem(object index) { }

	// RVA: 0x3CB36DC
	internal virtual object SetItem(object index, object item) { }

	// RVA: 0x3CB3E64
	internal virtual object ClearItems() { }

	// RVA: 0x3CB4344
	internal virtual object ReplaceItem(object existing, object replacement) { }

	// RVA: 0x3CB43EC
	internal virtual object ContainsItem(object item) { }

	// RVA: 0x3CB4444
	internal virtual object CopyItemsTo(object array, object arrayIndex) { }

	// RVA: 0x3CB3D7C
	internal static object IsTokenUnchanged(object currentValue, object newValue) { }

	// RVA: 0x3CB4A10
	internal virtual object ValidateToken(object o, object existing) { }

	// RVA: 0x3CB4B54
	public virtual object Add(object content) { }

	// RVA: 0x3CB4C68
	internal object TryAdd(object content) { }

	// RVA: 0x3CB4D7C
	internal object AddAndSkipParentCheck(object token) { }

	// RVA: 0x3CB1BFC
	internal object TryAddInternal(object index, object content, object skipParentCheck) { }

	// RVA: 0x3CB4E90
	internal static object CreateFromContent(object content) { }

	// RVA: 0x3CB5030
	public object RemoveAll() { }

	// RVA: 0x3CB0A94
	internal object ReadTokenFrom(object reader, object options) { }

	// RVA: 0x3CB5074
	internal object ReadContentFrom(object r, object settings) { }

	// RVA: 0x3CB5B40
	private static object ReadProperty(object r, object settings, object lineInfo, object parent) { }

	// RVA: 0x3CB6100
	private object System.Collections.Generic.IList<Newtonsoft.Json.Linq.JToken>.IndexOf(object item) { }

	// RVA: 0x3CB614C
	private object System.Collections.Generic.IList<Newtonsoft.Json.Linq.JToken>.Insert(object index, object item) { }

	// RVA: 0x3CB61AC
	private object System.Collections.Generic.IList<Newtonsoft.Json.Linq.JToken>.RemoveAt(object index) { }

	// RVA: 0x3CB61F8
	private object System.Collections.Generic.IList<Newtonsoft.Json.Linq.JToken>.get_Item(object index) { }

	// RVA: 0x3CB6244
	private object System.Collections.Generic.IList<Newtonsoft.Json.Linq.JToken>.set_Item(object index, object value) { }

	// RVA: 0x3CB62A0
	private object System.Collections.Generic.ICollection<Newtonsoft.Json.Linq.JToken>.Add(object item) { }

	// RVA: 0x3CB62EC
	private object System.Collections.Generic.ICollection<Newtonsoft.Json.Linq.JToken>.Clear() { }

	// RVA: 0x3CB6330
	private object System.Collections.Generic.ICollection<Newtonsoft.Json.Linq.JToken>.Contains(object item) { }

	// RVA: 0x3CB637C
	private object System.Collections.Generic.ICollection<Newtonsoft.Json.Linq.JToken>.CopyTo(object array, object arrayIndex) { }

	// RVA: 0x3CB63D8
	private object System.Collections.Generic.ICollection<Newtonsoft.Json.Linq.JToken>.get_IsReadOnly() { }

	// RVA: 0x3CB63E0
	private object System.Collections.Generic.ICollection<Newtonsoft.Json.Linq.JToken>.Remove(object item) { }

	// RVA: 0x3CB642C
	private object EnsureValue(object value) { }

	// RVA: 0x3CB64EC
	private object System.Collections.IList.Add(object value) { }

	// RVA: 0x3CB6548
	private object System.Collections.IList.Clear() { }

	// RVA: 0x3CB658C
	private object System.Collections.IList.Contains(object value) { }

	// RVA: 0x3CB65D8
	private object System.Collections.IList.IndexOf(object value) { }

	// RVA: 0x3CB6624
	private object System.Collections.IList.Insert(object index, object value) { }

	// RVA: 0x3CB6688
	private object System.Collections.IList.get_IsFixedSize() { }

	// RVA: 0x3CB6690
	private object System.Collections.IList.get_IsReadOnly() { }

	// RVA: 0x3CB6698
	private object System.Collections.IList.Remove(object value) { }

	// RVA: 0x3CB66E4
	private object System.Collections.IList.RemoveAt(object index) { }

	// RVA: 0x3CB6730
	private object System.Collections.IList.get_Item(object index) { }

	// RVA: 0x3CB677C
	private object System.Collections.IList.set_Item(object index, object value) { }

	// RVA: 0x3CB67DC
	private object System.Collections.ICollection.CopyTo(object array, object index) { }

	// RVA: 0x3CB4908
	public object get_Count() { }

	// RVA: 0x3CB6838
	private object System.Collections.ICollection.get_IsSynchronized() { }

	// RVA: 0x3CB6840
	private object System.Collections.ICollection.get_SyncRoot() { }

}

// Namespace: Newtonsoft.Json.Linq
public struct JEnumerable<T0>
{

	// Fields
	public static readonly object Empty; // 0x0
	private readonly object _enumerable; // 0x0

	// Methods

	// RVA: -1
	public object .ctor(object enumerable) { }

	// RVA: -1
	public object GetEnumerator() { }

	// RVA: -1
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: -1
	public object Equals(object other) { }

	// RVA: -1
	public override object Equals(object obj) { }

	// RVA: -1
	public override object GetHashCode() { }

	// RVA: -1
	private static object .cctor() { }

}

// Namespace: 
private sealed class <>c
{

	// Fields
	public static readonly object <>9; // 0x0
	public static object <>9__2_0; // 0x8

	// Methods

	// RVA: 0x3CB96F4
	private static object .cctor() { }

	// RVA: 0x3CB9754
	public object .ctor() { }

	// RVA: 0x3CB975C
	internal object <GetDynamicMemberNames>b__2_0(object p) { }

}

// Namespace: 
private class JObjectDynamicProxy
{

	// Methods

	// RVA: 0x3CB938C
	public override object TryGetMember(object instance, object binder, object result) { }

	// RVA: 0x3CB9454
	public override object TrySetMember(object instance, object binder, object value) { }

	// RVA: 0x3CB9598
	public override object GetDynamicMemberNames(object instance) { }

	// RVA: 0x3CB9334
	public object .ctor() { }

}

// Namespace: 
private sealed class <GetEnumerator>d__63
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x20
	private object <>7__wrap1; // 0x28

	// Properties
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x3CB89CC
	public object .ctor(object <>1__state) { }

	// RVA: 0x3CB977C
	private object System.IDisposable.Dispose() { }

	// RVA: 0x3CB9880
	private object MoveNext() { }

	// RVA: 0x3CB9C9C
	private object <>m__Finally1() { }

	// RVA: 0x3CB9DBC
	private object System.Collections.Generic.IEnumerator<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.get_Current() { }

	// RVA: 0x3CB9DC8
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x3CB9E08
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: Newtonsoft.Json.Linq
public class JObject
{

	// Fields
	private readonly object _properties; // 0x48
	private object PropertyChanged; // 0x50
	private object PropertyChanging; // 0x58

	// Properties
	protected override object ChildrenTokens { get; }
	public override object Type { get; }
	public override object Item { get; }
	public object Item { get; set; }
	private object System.Collections.Generic.IDictionary<System.String,Newtonsoft.Json.Linq.JToken>.Keys { get; }
	private object System.Collections.Generic.IDictionary<System.String,Newtonsoft.Json.Linq.JToken>.Values { get; }
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.IsReadOnly { get; }

	// Methods

	// RVA: 0x3CB68CC
	protected override object get_ChildrenTokens() { }

	// RVA: 0x3CB58D4
	public object .ctor() { }

	// RVA: 0x3CB6970
	public object .ctor(object other) { }

	// RVA: 0x3CB6A5C
	internal override object IndexOfItem(object item) { }

	// RVA: 0x3CB6BEC
	internal override object InsertItem(object index, object item, object skipParentCheck) { }

	// RVA: 0x3CB6C78
	internal override object ValidateToken(object o, object existing) { }

	// RVA: 0x3CB6F84
	internal object InternalPropertyChanged(object childProperty) { }

	// RVA: 0x3CB713C
	internal object InternalPropertyChanging(object childProperty) { }

	// RVA: 0x3CB7198
	internal override object CloneToken() { }

	// RVA: 0x3CB71FC
	public override object get_Type() { }

	// RVA: 0x3CB7204
	public object Properties() { }

	// RVA: 0x3CB5D90
	public object Property(object name, object comparison) { }

	// RVA: 0x3CB7258
	public override object get_Item(object key) { }

	// RVA: 0x3CB73C8
	public object get_Item(object propertyName) { }

	// RVA: 0x3CB7454
	public object set_Item(object propertyName, object value) { }

	// RVA: 0x3CB7738
	public static object Load(object reader, object settings) { }

	// RVA: 0x3CB795C
	public static object Parse(object json) { }

	// RVA: 0x3CB7964
	public static object Parse(object json, object settings) { }

	// RVA: 0x3CB7B5C
	public override object WriteTo(object writer, object converters) { }

	// RVA: 0x3CB769C
	public object Add(object propertyName, object value) { }

	// RVA: 0x3CB7DF8
	public object ContainsKey(object propertyName) { }

	// RVA: 0x3CB7F2C
	private object System.Collections.Generic.IDictionary<System.String,Newtonsoft.Json.Linq.JToken>.get_Keys() { }

	// RVA: 0x3CB7FF8
	public object Remove(object propertyName) { }

	// RVA: 0x3CB80C4
	public object TryGetValue(object propertyName, object value) { }

	// RVA: 0x3CB812C
	private object System.Collections.Generic.IDictionary<System.String,Newtonsoft.Json.Linq.JToken>.get_Values() { }

	// RVA: 0x3CB816C
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.Add(object item) { }

	// RVA: 0x3CB8220
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.Clear() { }

	// RVA: 0x3CB8264
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.Contains(object item) { }

	// RVA: 0x3CB82F4
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.CopyTo(object array, object arrayIndex) { }

	// RVA: 0x3CB87DC
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.get_IsReadOnly() { }

	// RVA: 0x3CB87E4
	private object System.Collections.Generic.ICollection<System.Collections.Generic.KeyValuePair<System.String,Newtonsoft.Json.Linq.JToken>>.Remove(object item) { }

	// RVA: 0x3CB8960
	public object GetEnumerator() { }

	// RVA: 0x3CB89F8
	protected virtual object OnPropertyChanged(object propertyName) { }

	// RVA: 0x3CB8A8C
	protected virtual object OnPropertyChanging(object propertyName) { }

	// RVA: 0x3CB8B20
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties() { }

	// RVA: 0x3CB8BE0
	private object System.ComponentModel.ICustomTypeDescriptor.GetProperties(object attributes) { }

	// RVA: 0x3CB8FC0
	private object System.ComponentModel.ICustomTypeDescriptor.GetAttributes() { }

	// RVA: 0x3CB903C
	private object System.ComponentModel.ICustomTypeDescriptor.GetClassName() { }

	// RVA: 0x3CB9044
	private object System.ComponentModel.ICustomTypeDescriptor.GetComponentName() { }

	// RVA: 0x3CB904C
	private object System.ComponentModel.ICustomTypeDescriptor.GetConverter() { }

	// RVA: 0x3CB90A4
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultEvent() { }

	// RVA: 0x3CB90AC
	private object System.ComponentModel.ICustomTypeDescriptor.GetDefaultProperty() { }

	// RVA: 0x3CB90B4
	private object System.ComponentModel.ICustomTypeDescriptor.GetEditor(object editorBaseType) { }

	// RVA: 0x3CB90BC
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents(object attributes) { }

	// RVA: 0x3CB9138
	private object System.ComponentModel.ICustomTypeDescriptor.GetEvents() { }

	// RVA: 0x3CB91B4
	private object System.ComponentModel.ICustomTypeDescriptor.GetPropertyOwner(object pd) { }

	// RVA: 0x3CB9248
	protected override object GetMetaObject(object parameter) { }

}

// Namespace: 
private sealed class <GetEnumerator>d__1
{

	// Fields
	private object <>1__state; // 0x8
	private object <>2__current; // 0x10
	public object <>4__this; // 0x18

	// Properties
	private object System.Collections.Generic.IEnumerator<Newtonsoft.Json.Linq.JToken>.Current { get; }
	private object System.Collections.IEnumerator.Current { get; }

	// Methods

	// RVA: 0x3CBA9C0
	public object .ctor(object <>1__state) { }

	// RVA: 0x3CBABE8
	private object System.IDisposable.Dispose() { }

	// RVA: 0x3CBABEC
	private object MoveNext() { }

	// RVA: 0x3CBAC4C
	private object System.Collections.Generic.IEnumerator<Newtonsoft.Json.Linq.JToken>.get_Current() { }

	// RVA: 0x3CBAC54
	private object System.Collections.IEnumerator.Reset() { }

	// RVA: 0x3CBAC94
	private object System.Collections.IEnumerator.get_Current() { }

}

// Namespace: 
private class JPropertyList
{

	// Fields
	internal object _token; // 0x8

	// Properties
	public object Count { get; }
	public object IsReadOnly { get; }
	public object Item { get; set; }

	// Methods

	// RVA: 0x3CBA954
	public object GetEnumerator() { }

	// RVA: 0x3CBA9EC
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x3CBAA58
	public object Add(object item) { }

	// RVA: 0x3CBAA60
	public object Clear() { }

	// RVA: 0x3CBAA68
	public object Contains(object item) { }

	// RVA: 0x3CBAA78
	public object CopyTo(object array, object arrayIndex) { }

	// RVA: 0x3CBAAF0
	public object Remove(object item) { }

	// RVA: 0x3CBAB18
	public object get_Count() { }

	// RVA: 0x3CBAB28
	public object get_IsReadOnly() { }

	// RVA: 0x3CBA32C
	public object IndexOf(object item) { }

	// RVA: 0x3CBAB30
	public object Insert(object index, object item) { }

	// RVA: 0x3CBAB40
	public object RemoveAt(object index) { }

	// RVA: 0x3CBAB50
	public object get_Item(object index) { }

	// RVA: 0x3CBAB9C
	public object set_Item(object index, object value) { }

	// RVA: 0x3CB9F0C
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Linq
public class JProperty
{

	// Fields
	private readonly object _content; // 0x48
	private readonly object _name; // 0x50

	// Properties
	protected override object ChildrenTokens { get; }
	public object Name { get; }
	public object Value { get; set; }
	public override object Type { get; }

	// Methods

	// RVA: 0x3CB9E70
	protected override object get_ChildrenTokens() { }

	// RVA: 0x3CB9E78
	public object get_Name() { }

	// RVA: 0x3CB58B0
	public object get_Value() { }

	// RVA: 0x3CB756C
	public object set_Value(object value) { }

	// RVA: 0x3CB9E80
	public object .ctor(object other) { }

	// RVA: 0x3CB9F14
	internal override object GetItem(object index) { }

	// RVA: 0x3CB9F7C
	internal override object SetItem(object index, object item) { }

	// RVA: 0x3CBA194
	internal override object RemoveItem(object item) { }

	// RVA: 0x3CBA244
	internal override object RemoveItemAt(object index) { }

	// RVA: 0x3CBA2F4
	internal override object IndexOfItem(object item) { }

	// RVA: 0x3CBA33C
	internal override object InsertItem(object index, object item, object skipParentCheck) { }

	// RVA: 0x3CBA474
	internal override object ContainsItem(object item) { }

	// RVA: 0x3CBA4A0
	internal override object ClearItems() { }

	// RVA: 0x3CBA550
	internal override object CloneToken() { }

	// RVA: 0x3CBA610
	public override object get_Type() { }

	// RVA: 0x3CB5F88
	internal object .ctor(object name) { }

	// RVA: 0x3CB7CCC
	public object .ctor(object name, object content) { }

	// RVA: 0x3CBA618
	public override object WriteTo(object writer, object converters) { }

	// RVA: 0x3CBA6F4
	public static object Load(object reader, object settings) { }

}

// Namespace: Newtonsoft.Json.Linq
public class JPropertyDescriptor
{

	// Properties
	public override object ComponentType { get; }
	public override object IsReadOnly { get; }
	public override object PropertyType { get; }
	protected override object NameHashCode { get; }

	// Methods

	// RVA: 0x3CB8FB4
	public object .ctor(object name) { }

	// RVA: 0x3CBAC9C
	public override object GetValue(object component) { }

	// RVA: 0x3CBADD0
	public override object SetValue(object component, object value) { }

	// RVA: 0x3CBAF7C
	public override object ShouldSerializeValue(object component) { }

	// RVA: 0x3CBAF84
	public override object get_ComponentType() { }

	// RVA: 0x3CBB024
	public override object get_IsReadOnly() { }

	// RVA: 0x3CBB02C
	public override object get_PropertyType() { }

	// RVA: 0x3CBB0CC
	protected override object get_NameHashCode() { }

}

// Namespace: Newtonsoft.Json.Linq
internal class JPropertyKeyedCollection
{

	// Fields
	private static readonly object Comparer; // 0x0
	private object _dictionary; // 0x10

	// Properties
	public object Keys { get; }

	// Methods

	// RVA: 0x3CB68D4
	public object .ctor() { }

	// RVA: 0x3CBB0D4
	private object AddKey(object key, object item) { }

	// RVA: 0x3CBB21C
	protected override object ClearItems() { }

	// RVA: 0x3CB7E70
	public object Contains(object key) { }

	// RVA: 0x3CBB150
	private object EnsureDictionary() { }

	// RVA: 0x3CBB2A4
	private object GetKeyForItem(object item) { }

	// RVA: 0x3CBB330
	protected override object InsertItem(object index, object item) { }

	// RVA: 0x3CBB470
	protected override object RemoveItem(object index) { }

	// RVA: 0x3CBB62C
	private object RemoveKey(object key) { }

	// RVA: 0x3CBB69C
	protected override object SetItem(object index, object item) { }

	// RVA: 0x3CB6F08
	public object TryGetValue(object key, object value) { }

	// RVA: 0x3CB7F94
	public object get_Keys() { }

	// RVA: 0x3CB6B38
	public object IndexOfReference(object t) { }

	// RVA: 0x3CBBA48
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Linq
public class JRaw
{

	// Methods

	// RVA: 0x3CBBB24
	public object .ctor(object other) { }

	// RVA: 0x3CBBC18
	public object .ctor(object rawJson) { }

	// RVA: 0x3CBBD10
	public static object Create(object reader) { }

	// RVA: 0x3CBC0A8
	internal override object CloneToken() { }

}

// Namespace: Newtonsoft.Json.Linq
public class JsonLoadSettings
{

	// Fields
	private object _commentHandling; // 0x8
	private object _lineInfoHandling; // 0xC
	private object _duplicatePropertyNameHandling; // 0x10

	// Properties
	public object CommentHandling { get; }
	public object LineInfoHandling { get; }
	public object DuplicatePropertyNameHandling { get; }

	// Methods

	// RVA: 0x3CBC10C
	public object get_CommentHandling() { }

	// RVA: 0x3CBC114
	public object get_LineInfoHandling() { }

	// RVA: 0x3CBC11C
	public object get_DuplicatePropertyNameHandling() { }

}

// Namespace: 
private class LineInfoAnnotation
{

	// Fields
	internal readonly object LineNumber; // 0x8
	internal readonly object LinePosition; // 0xC

	// Methods

	// RVA: 0x3CC4AC0
	public object .ctor(object lineNumber, object linePosition) { }

}

// Namespace: Newtonsoft.Json.Linq
public abstract class JToken
{

	// Fields
	private object _parent; // 0x8
	private object _previous; // 0x10
	private object _next; // 0x18
	private object _annotations; // 0x20
	private static readonly object BooleanTypes; // 0x0
	private static readonly object NumberTypes; // 0x8
	private static readonly object BigIntegerTypes; // 0x10
	private static readonly object StringTypes; // 0x18
	private static readonly object GuidTypes; // 0x20
	private static readonly object TimeSpanTypes; // 0x28
	private static readonly object UriTypes; // 0x30
	private static readonly object CharTypes; // 0x38
	private static readonly object DateTimeTypes; // 0x40
	private static readonly object BytesTypes; // 0x48

	// Properties
	public object Parent { get; set; }
	public object Root { get; }
	public abstract object Type { get; }
	public abstract object HasValues { get; }
	public object Next { get; set; }
	public object Previous { get; set; }
	public object Path { get; }
	public virtual object Item { get; }
	public virtual object First { get; }
	public virtual object Last { get; }
	private object Newtonsoft.Json.IJsonLineInfo.LineNumber { get; }
	private object Newtonsoft.Json.IJsonLineInfo.LinePosition { get; }

	// Methods

	// RVA: 0x3CBC124
	public object get_Parent() { }

	// RVA: 0x3CBC12C
	internal object set_Parent(object value) { }

	// RVA: 0x3CB2A4C
	public object get_Root() { }

	// RVA: -1
	internal abstract object CloneToken() { }

	// RVA: -1
	public abstract object get_Type() { }

	// RVA: -1
	public abstract object get_HasValues() { }

	// RVA: 0x3CBC134
	public object get_Next() { }

	// RVA: 0x3CBC13C
	internal object set_Next(object value) { }

	// RVA: 0x3CBC144
	public object get_Previous() { }

	// RVA: 0x3CBC14C
	internal object set_Previous(object value) { }

	// RVA: 0x3CBC154
	public object get_Path() { }

	// RVA: 0x3CB1BF4
	internal object .ctor() { }

	// RVA: 0x3CBC548
	public virtual object get_Item(object key) { }

	// RVA: -1
	public virtual object Value(object key) { }

	// RVA: 0x3CBC5DC
	public virtual object get_First() { }

	// RVA: 0x3CBC670
	public virtual object get_Last() { }

	// RVA: 0x3CBC704
	public virtual object Children() { }

	// RVA: 0x3CB8030
	public object Remove() { }

	// RVA: 0x3CB605C
	public object Replace(object value) { }

	// RVA: -1
	public abstract object WriteTo(object writer, object converters) { }

	// RVA: 0x3CBC780
	public override object ToString() { }

	// RVA: 0x3CBC7E4
	public object ToString(object formatting, object converters) { }

	// RVA: 0x3CBCA5C
	private static object EnsureValue(object value) { }

	// RVA: 0x3CBCB9C
	private static object GetType(object token) { }

	// RVA: 0x3CBCCC8
	private static object ValidateToken(object o, object validTypes, object nullable) { }

	// RVA: 0x3CBCDDC
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBD0F8
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBD440
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBD6BC
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBD9A0
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBDBF0
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBDEF0
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBE140
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBE38C
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBE5DC
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBE8C0
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBEBA4
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBEE88
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBF16C
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBF450
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBF734
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBF984
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBFBD4
	public static object op_Explicit(object value) { }

	// RVA: 0x3CBFE24
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC0074
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC02C4
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC0590
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC07E0
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC0A2C
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC0D10
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC0F60
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC11B0
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC1494
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC1778
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC1A48
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC1D2C
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC2010
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC2314
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC25A8
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC2878
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC2AE0
	public static object op_Explicit(object value) { }

	// RVA: 0x3CC2CD8
	private static object ToBigInteger(object value) { }

	// RVA: 0x3CC2EE8
	private static object ToBigIntegerNullable(object value) { }

	// RVA: 0x3CC30B4
	private object System.Collections.IEnumerable.GetEnumerator() { }

	// RVA: 0x3CC3180
	private object System.Collections.Generic.IEnumerable<Newtonsoft.Json.Linq.JToken>.GetEnumerator() { }

	// RVA: 0x3CC3230
	public object CreateReader() { }

	// RVA: 0x3CC3344
	public object ToObject(object objectType) { }

	// RVA: 0x3CC420C
	public object ToObject(object objectType, object jsonSerializer) { }

	// RVA: 0x3CC4414
	public static object ReadFrom(object reader) { }

	// RVA: 0x3CC449C
	public static object ReadFrom(object reader, object settings) { }

	// RVA: 0x3CB0850
	internal object SetLineInfo(object lineInfo, object settings) { }

	// RVA: 0x3CC4A44
	internal object SetLineInfo(object lineNumber, object linePosition) { }

	// RVA: 0x3CC4D68
	private object Newtonsoft.Json.IJsonLineInfo.HasLineInfo() { }

	// RVA: 0x3CC4DCC
	private object Newtonsoft.Json.IJsonLineInfo.get_LineNumber() { }

	// RVA: 0x3CC4E30
	private object Newtonsoft.Json.IJsonLineInfo.get_LinePosition() { }

	// RVA: 0x3CC4E94
	protected virtual object GetMetaObject(object parameter) { }

	// RVA: 0x3CC4F68
	private object System.Dynamic.IDynamicMetaObjectProvider.GetMetaObject(object parameter) { }

	// RVA: 0x3CC4FB4
	private object System.ICloneable.Clone() { }

	// RVA: 0x3CC4FF4
	public object DeepClone() { }

	// RVA: 0x3CC4AF8
	public object AddAnnotation(object annotation) { }

	// RVA: -1
	public object Annotation() { }

	// RVA: 0x3CB1FFC
	internal object CopyAnnotations(object target, object source) { }

	// RVA: 0x3CC5034
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Linq
public class JTokenReader
{

	// Fields
	private readonly object _root; // 0x70
	private object _initialPath; // 0x78
	private object _parent; // 0x80
	private object _current; // 0x88

	// Properties
	public object CurrentToken { get; }
	private object Newtonsoft.Json.IJsonLineInfo.LineNumber { get; }
	private object Newtonsoft.Json.IJsonLineInfo.LinePosition { get; }
	public override object Path { get; }

	// Methods

	// RVA: 0x3CC52EC
	public object get_CurrentToken() { }

	// RVA: 0x3CC32D4
	public object .ctor(object token) { }

	// RVA: 0x3CC52F4
	public override object Read() { }

	// RVA: 0x3CC54C0
	private object ReadOver(object t) { }

	// RVA: 0x3CC5DC4
	private object ReadToEnd() { }

	// RVA: 0x3CC5E78
	private object GetEndToken(object c) { }

	// RVA: 0x3CC53CC
	private object ReadInto(object c) { }

	// RVA: 0x3CC5DE8
	private object SetEnd(object c) { }

	// RVA: 0x3CC5614
	private object SetToken(object token) { }

	// RVA: 0x3CC6034
	private object SafeToString(object value) { }

	// RVA: 0x3CC607C
	private object Newtonsoft.Json.IJsonLineInfo.HasLineInfo() { }

	// RVA: 0x3CC616C
	private object Newtonsoft.Json.IJsonLineInfo.get_LineNumber() { }

	// RVA: 0x3CC6260
	private object Newtonsoft.Json.IJsonLineInfo.get_LinePosition() { }

	// RVA: 0x3CC6354
	public override object get_Path() { }

}

// Namespace: Newtonsoft.Json.Linq
public enum JTokenType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object None;
	public const object Object;
	public const object Array;
	public const object Constructor;
	public const object Property;
	public const object Comment;
	public const object Integer;
	public const object Float;
	public const object String;
	public const object Boolean;
	public const object Null;
	public const object Undefined;
	public const object Date;
	public const object Raw;
	public const object Bytes;
	public const object Guid;
	public const object Uri;
	public const object TimeSpan;
}

// Namespace: Newtonsoft.Json.Linq
public class JTokenWriter
{

	// Fields
	private object _token; // 0x58
	private object _parent; // 0x60
	private object _value; // 0x68
	private object _current; // 0x70

	// Properties
	public object Token { get; }

	// Methods

	// RVA: 0x3CC6454
	public object get_Token() { }

	// RVA: 0x3CC6470
	public object .ctor() { }

	// RVA: 0x3CC64F8
	public override object Close() { }

	// RVA: 0x3CC6500
	public override object WriteStartObject() { }

	// RVA: 0x3CC6598
	private object AddParent(object container) { }

	// RVA: 0x3CC65E4
	private object RemoveParent() { }

	// RVA: 0x3CC666C
	public override object WriteStartArray() { }

	// RVA: 0x3CC6704
	public override object WriteStartConstructor(object name) { }

	// RVA: 0x3CC67A8
	protected override object WriteEnd(object token) { }

	// RVA: 0x3CC6830
	public override object WritePropertyName(object name) { }

	// RVA: 0x3CC691C
	private object AddValue(object value, object token) { }

	// RVA: 0x3CC69E4
	internal object AddValue(object value, object token) { }

	// RVA: 0x3CC6B78
	public override object WriteValue(object value) { }

	// RVA: 0x3CC6C1C
	public override object WriteNull() { }

	// RVA: 0x3CC6C48
	public override object WriteUndefined() { }

	// RVA: 0x3CC6C74
	public override object WriteRaw(object json) { }

	// RVA: 0x3CC6D40
	public override object WriteComment(object text) { }

	// RVA: 0x3CC6E04
	public override object WriteValue(object value) { }

	// RVA: 0x3CC6E38
	public override object WriteValue(object value) { }

	// RVA: 0x3CC6EC0
	public override object WriteValue(object value) { }

	// RVA: 0x3CC6F48
	public override object WriteValue(object value) { }

	// RVA: 0x3CC6FD0
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7058
	public override object WriteValue(object value) { }

	// RVA: 0x3CC70E8
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7178
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7200
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7288
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7310
	public override object WriteValue(object value) { }

	// RVA: 0x3CC73F8
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7480
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7508
	public override object WriteValue(object value) { }

	// RVA: 0x3CC75CC
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7694
	public override object WriteValue(object value) { }

	// RVA: 0x3CC772C
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7760
	public override object WriteValue(object value) { }

	// RVA: 0x3CC77E8
	public override object WriteValue(object value) { }

	// RVA: 0x3CC7880
	public override object WriteValue(object value) { }

	// RVA: 0x3CC78B4
	internal override object WriteToken(object reader, object writeChildren, object writeDateConstructorAsDate, object writeComments) { }

}

// Namespace: 
private class JValueDynamicProxy
{

	// Methods

	// RVA: 0x3CCB548
	public override object TryConvert(object instance, object binder, object result) { }

	// RVA: 0x3CCB73C
	public override object TryBinaryOperation(object instance, object binder, object arg, object result) { }

	// RVA: 0x3CCAC08
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Linq
public class JValue
{

	// Fields
	private object _valueType; // 0x28
	private object _value; // 0x30

	// Properties
	public override object HasValues { get; }
	public override object Type { get; }
	public object Value { get; }

	// Methods

	// RVA: 0x3CBBC90
	internal object .ctor(object value, object type) { }

	// RVA: 0x3CBBB28
	public object .ctor(object other) { }

	// RVA: 0x3CB4FA8
	public object .ctor(object value) { }

	// RVA: 0x3CC80DC
	public override object get_HasValues() { }

	// RVA: 0x3CC80E4
	private static object CompareBigInteger(object i1, object i2) { }

	// RVA: 0x3CC845C
	internal static object Compare(object valueType, object objA, object objB) { }

	// RVA: 0x3CC8F34
	private static object CompareFloat(object objA, object objB) { }

	// RVA: 0x3CC9078
	private static object Operation(object operation, object objA, object objB, object result) { }

	// RVA: 0x3CC9990
	internal override object CloneToken() { }

	// RVA: 0x3CB59EC
	public static object CreateComment(object value) { }

	// RVA: 0x3CB29A4
	public static object CreateNull() { }

	// RVA: 0x3CB5A98
	public static object CreateUndefined() { }

	// RVA: 0x3CC7BCC
	private static object GetValueType(object current, object value) { }

	// RVA: 0x3CC99F4
	private static object GetStringValueType(object current) { }

	// RVA: 0x3CC9A60
	public override object get_Type() { }

	// RVA: 0x3CC9A68
	public object get_Value() { }

	// RVA: 0x3CC9A70
	public override object WriteTo(object writer, object converters) { }

	// RVA: 0x3CCA708
	private static object ValuesEquals(object v1, object v2) { }

	// RVA: 0x3CCA784
	public object Equals(object other) { }

	// RVA: 0x3CCA7F4
	public override object Equals(object obj) { }

	// RVA: 0x3CCA8D8
	public override object GetHashCode() { }

	// RVA: 0x3CCA928
	public override object ToString() { }

	// RVA: 0x3CCA9AC
	public object ToString(object formatProvider) { }

	// RVA: 0x3CCA9B8
	public object ToString(object format, object formatProvider) { }

	// RVA: 0x3CCAB1C
	protected override object GetMetaObject(object parameter) { }

	// RVA: 0x3CCAC60
	private object System.IComparable.CompareTo(object obj) { }

	// RVA: 0x3CCAD1C
	public object CompareTo(object obj) { }

	// RVA: 0x3CCAD4C
	private object System.IConvertible.GetTypeCode() { }

	// RVA: 0x3CCAE44
	private object System.IConvertible.ToBoolean(object provider) { }

	// RVA: 0x3CCAEC4
	private object System.IConvertible.ToChar(object provider) { }

	// RVA: 0x3CCAF44
	private object System.IConvertible.ToSByte(object provider) { }

	// RVA: 0x3CCAFC4
	private object System.IConvertible.ToByte(object provider) { }

	// RVA: 0x3CCB044
	private object System.IConvertible.ToInt16(object provider) { }

	// RVA: 0x3CCB0C4
	private object System.IConvertible.ToUInt16(object provider) { }

	// RVA: 0x3CCB144
	private object System.IConvertible.ToInt32(object provider) { }

	// RVA: 0x3CCB1C4
	private object System.IConvertible.ToUInt32(object provider) { }

	// RVA: 0x3CCB244
	private object System.IConvertible.ToInt64(object provider) { }

	// RVA: 0x3CCB2C4
	private object System.IConvertible.ToUInt64(object provider) { }

	// RVA: 0x3CCB344
	private object System.IConvertible.ToSingle(object provider) { }

	// RVA: 0x3CCB3C4
	private object System.IConvertible.ToDouble(object provider) { }

	// RVA: 0x3CCB444
	private object System.IConvertible.ToDecimal(object provider) { }

	// RVA: 0x3CCB4C4
	private object System.IConvertible.ToDateTime(object provider) { }

	// RVA: 0x3CCB544
	private object System.IConvertible.ToType(object conversionType, object provider) { }

}

// Namespace: Newtonsoft.Json.Linq
public enum LineInfoHandling
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Ignore;
	public const object Load;
}

// Namespace: Newtonsoft.Json.Converters
public class BinaryConverter
{

	// Fields
	private static object _reflectionObject; // 0x0

	// Methods

	// RVA: 0x3CCBB38
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CCBBDC
	private object GetByteArray(object value) { }

	// RVA: 0x3CCBE44
	private static object EnsureReflectionObject(object t) { }

	// RVA: 0x3CCBFFC
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CCC500
	private object ReadByteArray(object reader) { }

	// RVA: 0x3CCC868
	public override object CanConvert(object objectType) { }

	// RVA: 0x3CCC9AC
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Converters
public class BsonObjectIdConverter
{

	// Methods

	// RVA: 0x3CCC9B4
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CCCAF4
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CCCCB4
	public override object CanConvert(object objectType) { }

	// RVA: 0x3CCCD40
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Converters
public class DataSetConverter
{

	// Methods

	// RVA: 0x3CCCD48
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CCD32C
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CCD6B4
	public override object CanConvert(object valueType) { }

	// RVA: 0x3CCD794
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Converters
public class DataTableConverter
{

	// Methods

	// RVA: 0x3CCD79C
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CCE138
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CCE4C0
	private static object CreateRow(object reader, object dt, object serializer) { }

	// RVA: 0x3CCEC24
	private static object GetColumnDataType(object reader) { }

	// RVA: 0x3CCEE8C
	public override object CanConvert(object valueType) { }

	// RVA: 0x3CCD324
	public object .ctor() { }

}

// Namespace: 
internal class Union
{

	// Fields
	public readonly object TagReader; // 0x8
	public readonly object Cases; // 0x10

	// Methods

	// RVA: 0x3CCFB78
	public object .ctor(object tagReader, object cases) { }

}

// Namespace: 
internal class UnionCase
{

	// Fields
	public readonly object Tag; // 0x8
	public readonly object Name; // 0x10
	public readonly object Fields; // 0x18
	public readonly object FieldReader; // 0x20
	public readonly object Constructor; // 0x28

	// Methods

	// RVA: 0x3CCFBB0
	public object .ctor(object tag, object name, object fields, object fieldReader, object constructor) { }

}

// Namespace: 
private sealed class <>c__DisplayClass8_0
{

	// Fields
	public object tag; // 0x8

	// Methods

	// RVA: 0x3CD022C
	public object .ctor() { }

	// RVA: 0x3CD0F98
	internal object <WriteJson>b__0(object c) { }

}

// Namespace: 
private sealed class <>c__DisplayClass9_0
{

	// Fields
	public object caseName; // 0x8
	public object <>9__0; // 0x10

	// Methods

	// RVA: 0x3CD0A58
	public object .ctor() { }

	// RVA: 0x3CD0FC4
	internal object <ReadJson>b__0(object c) { }

}

// Namespace: Newtonsoft.Json.Converters
public class DiscriminatedUnionConverter
{

	// Fields
	private static readonly object UnionCache; // 0x0
	private static readonly object UnionTypeLookupCache; // 0x8

	// Methods

	// RVA: 0x3CCEF70
	private static object CreateUnionTypeLookup(object t) { }

	// RVA: 0x3CCF1F8
	private static object CreateUnion(object t) { }

	// RVA: 0x3CCFC04
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CD0234
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CD0A60
	public override object CanConvert(object objectType) { }

	// RVA: 0x3CD0E10
	public object .ctor() { }

	// RVA: 0x3CD0E18
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Converters
public class EntityKeyMemberConverter
{

	// Fields
	private static object _reflectionObject; // 0x0

	// Methods

	// RVA: 0x3CD0FF0
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CD1604
	private static object ReadAndAssertProperty(object reader, object propertyName) { }

	// RVA: 0x3CD1744
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CD1500
	private static object EnsureReflectionObject(object objectType) { }

	// RVA: 0x3CD1A64
	public override object CanConvert(object objectType) { }

	// RVA: 0x3CD1AC0
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Converters
public class ExpandoObjectConverter
{

	// Properties
	public override object CanWrite { get; }

	// Methods

	// RVA: 0x3CD1AC8
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CD1ACC
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CD1AD0
	private object ReadValue(object reader) { }

	// RVA: 0x3CD1F08
	private object ReadList(object reader) { }

	// RVA: 0x3CD1C88
	private object ReadObject(object reader) { }

	// RVA: 0x3CD2158
	public override object CanConvert(object objectType) { }

	// RVA: 0x3CD21E4
	public override object get_CanWrite() { }

	// RVA: 0x3CD21EC
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Converters
public class KeyValuePairConverter
{

	// Fields
	private static readonly object ReflectionObjectPerType; // 0x0

	// Methods

	// RVA: 0x3CD21F4
	private static object InitializeReflectionObject(object t) { }

	// RVA: 0x3CD24B0
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CD27D8
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CD2DD0
	public override object CanConvert(object objectType) { }

	// RVA: 0x3CD2F3C
	public object .ctor() { }

	// RVA: 0x3CD2F44
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Converters
public class RegexConverter
{

	// Methods

	// RVA: 0x3CD3024
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CD3570
	private object HasFlag(object options, object flag) { }

	// RVA: 0x3CD3158
	private object WriteBson(object writer, object regex) { }

	// RVA: 0x3CD32EC
	private object WriteJson(object writer, object regex, object serializer) { }

	// RVA: 0x3CD36A4
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CD3A78
	private object ReadRegexString(object reader) { }

	// RVA: 0x3CD3770
	private object ReadRegexObject(object reader, object serializer) { }

	// RVA: 0x3CD3C00
	public override object CanConvert(object objectType) { }

	// RVA: 0x3CD3C98
	private object IsRegex(object objectType) { }

	// RVA: 0x3CD3D24
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XmlDocumentWrapper
{

	// Fields
	private readonly object _document; // 0x20

	// Properties
	public object DocumentElement { get; }

	// Methods

	// RVA: 0x3CD3D2C
	public object .ctor(object document) { }

	// RVA: 0x3CD3D88
	public object CreateComment(object data) { }

	// RVA: 0x3CD3E38
	public object CreateTextNode(object text) { }

	// RVA: 0x3CD3EE8
	public object CreateCDataSection(object data) { }

	// RVA: 0x3CD3F98
	public object CreateWhitespace(object text) { }

	// RVA: 0x3CD4048
	public object CreateSignificantWhitespace(object text) { }

	// RVA: 0x3CD40F8
	public object CreateXmlDeclaration(object version, object encoding, object standalone) { }

	// RVA: 0x3CD41F4
	public object CreateXmlDocumentType(object name, object publicId, object systemId, object internalSubset) { }

	// RVA: 0x3CD42F4
	public object CreateProcessingInstruction(object target, object data) { }

	// RVA: 0x3CD43AC
	public object CreateElement(object elementName) { }

	// RVA: 0x3CD4470
	public object CreateElement(object qualifiedName, object namespaceUri) { }

	// RVA: 0x3CD450C
	public object CreateAttribute(object name, object value) { }

	// RVA: 0x3CD4620
	public object CreateAttribute(object qualifiedName, object namespaceUri, object value) { }

	// RVA: 0x3CD46F0
	public object get_DocumentElement() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XmlElementWrapper
{

	// Fields
	private readonly object _element; // 0x20

	// Properties
	public object IsEmpty { get; }

	// Methods

	// RVA: 0x3CD4440
	public object .ctor(object element) { }

	// RVA: 0x3CD4794
	public object SetAttributeNode(object attribute) { }

	// RVA: 0x3CD48AC
	public object GetPrefixOfNamespace(object namespaceUri) { }

	// RVA: 0x3CD4904
	public object get_IsEmpty() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XmlDeclarationWrapper
{

	// Fields
	private readonly object _declaration; // 0x20

	// Properties
	public object Version { get; }
	public object Encoding { get; }
	public object Standalone { get; }

	// Methods

	// RVA: 0x3CD41C4
	public object .ctor(object declaration) { }

	// RVA: 0x3CD4928
	public object get_Version() { }

	// RVA: 0x3CD494C
	public object get_Encoding() { }

	// RVA: 0x3CD4970
	public object get_Standalone() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XmlDocumentTypeWrapper
{

	// Fields
	private readonly object _documentType; // 0x20

	// Properties
	public object Name { get; }
	public object System { get; }
	public object Public { get; }
	public object InternalSubset { get; }
	public override object LocalName { get; }

	// Methods

	// RVA: 0x3CD42C4
	public object .ctor(object documentType) { }

	// RVA: 0x3CD4994
	public object get_Name() { }

	// RVA: 0x3CD49E0
	public object get_System() { }

	// RVA: 0x3CD4A04
	public object get_Public() { }

	// RVA: 0x3CD4A28
	public object get_InternalSubset() { }

	// RVA: 0x3CD4A4C
	public override object get_LocalName() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XmlNodeWrapper
{

	// Fields
	private readonly object _node; // 0x8
	private object _childNodes; // 0x10
	private object _attributes; // 0x18

	// Properties
	public object WrappedNode { get; }
	public object NodeType { get; }
	public virtual object LocalName { get; }
	public object ChildNodes { get; }
	public object Attributes { get; }
	private object HasAttributes { get; }
	public object ParentNode { get; }
	public object Value { get; set; }
	public object NamespaceUri { get; }

	// Methods

	// RVA: 0x3CD3D5C
	public object .ctor(object node) { }

	// RVA: 0x3CD4A90
	public object get_WrappedNode() { }

	// RVA: 0x3CD4A98
	public object get_NodeType() { }

	// RVA: 0x3CD4AE4
	public virtual object get_LocalName() { }

	// RVA: 0x3CD4B34
	public object get_ChildNodes() { }

	// RVA: 0x3CD50C8
	internal static object WrapNode(object node) { }

	// RVA: 0x3CD526C
	public object get_Attributes() { }

	// RVA: 0x3CD57CC
	private object get_HasAttributes() { }

	// RVA: 0x3CD58D8
	public object get_ParentNode() { }

	// RVA: 0x3CD59C8
	public object get_Value() { }

	// RVA: 0x3CD45CC
	public object set_Value(object value) { }

	// RVA: 0x3CD5A14
	public object AppendChild(object newChild) { }

	// RVA: 0x3CD5AF4
	public object get_NamespaceUri() { }

}

// Namespace: Newtonsoft.Json.Converters
internal interface IXmlDocument
{

	// Properties
	public abstract object DocumentElement { get; }

	// Methods

	// RVA: -1
	public abstract object CreateComment(object text) { }

	// RVA: -1
	public abstract object CreateTextNode(object text) { }

	// RVA: -1
	public abstract object CreateCDataSection(object data) { }

	// RVA: -1
	public abstract object CreateWhitespace(object text) { }

	// RVA: -1
	public abstract object CreateSignificantWhitespace(object text) { }

	// RVA: -1
	public abstract object CreateXmlDeclaration(object version, object encoding, object standalone) { }

	// RVA: -1
	public abstract object CreateXmlDocumentType(object name, object publicId, object systemId, object internalSubset) { }

	// RVA: -1
	public abstract object CreateProcessingInstruction(object target, object data) { }

	// RVA: -1
	public abstract object CreateElement(object elementName) { }

	// RVA: -1
	public abstract object CreateElement(object qualifiedName, object namespaceUri) { }

	// RVA: -1
	public abstract object CreateAttribute(object name, object value) { }

	// RVA: -1
	public abstract object CreateAttribute(object qualifiedName, object namespaceUri, object value) { }

	// RVA: -1
	public abstract object get_DocumentElement() { }

}

// Namespace: Newtonsoft.Json.Converters
internal interface IXmlDeclaration
{

	// Properties
	public abstract object Version { get; }
	public abstract object Encoding { get; }
	public abstract object Standalone { get; }

	// Methods

	// RVA: -1
	public abstract object get_Version() { }

	// RVA: -1
	public abstract object get_Encoding() { }

	// RVA: -1
	public abstract object get_Standalone() { }

}

// Namespace: Newtonsoft.Json.Converters
internal interface IXmlDocumentType
{

	// Properties
	public abstract object Name { get; }
	public abstract object System { get; }
	public abstract object Public { get; }
	public abstract object InternalSubset { get; }

	// Methods

	// RVA: -1
	public abstract object get_Name() { }

	// RVA: -1
	public abstract object get_System() { }

	// RVA: -1
	public abstract object get_Public() { }

	// RVA: -1
	public abstract object get_InternalSubset() { }

}

// Namespace: Newtonsoft.Json.Converters
internal interface IXmlElement
{

	// Properties
	public abstract object IsEmpty { get; }

	// Methods

	// RVA: -1
	public abstract object SetAttributeNode(object attribute) { }

	// RVA: -1
	public abstract object GetPrefixOfNamespace(object namespaceUri) { }

	// RVA: -1
	public abstract object get_IsEmpty() { }

}

// Namespace: Newtonsoft.Json.Converters
internal interface IXmlNode
{

	// Properties
	public abstract object NodeType { get; }
	public abstract object LocalName { get; }
	public abstract object ChildNodes { get; }
	public abstract object Attributes { get; }
	public abstract object ParentNode { get; }
	public abstract object Value { get; }
	public abstract object NamespaceUri { get; }
	public abstract object WrappedNode { get; }

	// Methods

	// RVA: -1
	public abstract object get_NodeType() { }

	// RVA: -1
	public abstract object get_LocalName() { }

	// RVA: -1
	public abstract object get_ChildNodes() { }

	// RVA: -1
	public abstract object get_Attributes() { }

	// RVA: -1
	public abstract object get_ParentNode() { }

	// RVA: -1
	public abstract object get_Value() { }

	// RVA: -1
	public abstract object AppendChild(object newChild) { }

	// RVA: -1
	public abstract object get_NamespaceUri() { }

	// RVA: -1
	public abstract object get_WrappedNode() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XDeclarationWrapper
{

	// Fields
	private readonly object <Declaration>k__BackingField; // 0x10

	// Properties
	internal object Declaration { get; }
	public override object NodeType { get; }
	public object Version { get; }
	public object Encoding { get; }
	public object Standalone { get; }

	// Methods

	// RVA: 0x3CD5B44
	internal object get_Declaration() { }

	// RVA: 0x3CD5B4C
	public object .ctor(object declaration) { }

	// RVA: 0x3CD5BA4
	public override object get_NodeType() { }

	// RVA: 0x3CD5BAC
	public object get_Version() { }

	// RVA: 0x3CD5BD0
	public object get_Encoding() { }

	// RVA: 0x3CD5BF4
	public object get_Standalone() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XDocumentTypeWrapper
{

	// Fields
	private readonly object _documentType; // 0x10

	// Properties
	public object Name { get; }
	public object System { get; }
	public object Public { get; }
	public object InternalSubset { get; }
	public override object LocalName { get; }

	// Methods

	// RVA: 0x3CD5C18
	public object .ctor(object documentType) { }

	// RVA: 0x3CD5C44
	public object get_Name() { }

	// RVA: 0x3CD5C68
	public object get_System() { }

	// RVA: 0x3CD5C8C
	public object get_Public() { }

	// RVA: 0x3CD5CB0
	public object get_InternalSubset() { }

	// RVA: 0x3CD5CD4
	public override object get_LocalName() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XDocumentWrapper
{

	// Properties
	private object Document { get; }
	public override object ChildNodes { get; }
	protected override object HasChildNodes { get; }
	public object DocumentElement { get; }

	// Methods

	// RVA: 0x3CD5D18
	private object get_Document() { }

	// RVA: 0x3CD5D94
	public object .ctor(object document) { }

	// RVA: 0x3CD5DEC
	public override object get_ChildNodes() { }

	// RVA: 0x3CD65C8
	protected override object get_HasChildNodes() { }

	// RVA: 0x3CD6778
	public object CreateComment(object text) { }

	// RVA: 0x3CD680C
	public object CreateTextNode(object text) { }

	// RVA: 0x3CD68A0
	public object CreateCDataSection(object data) { }

	// RVA: 0x3CD6934
	public object CreateWhitespace(object text) { }

	// RVA: 0x3CD69C8
	public object CreateSignificantWhitespace(object text) { }

	// RVA: 0x3CD6A5C
	public object CreateXmlDeclaration(object version, object encoding, object standalone) { }

	// RVA: 0x3CD6B08
	public object CreateXmlDocumentType(object name, object publicId, object systemId, object internalSubset) { }

	// RVA: 0x3CD6BC4
	public object CreateProcessingInstruction(object target, object data) { }

	// RVA: 0x3CD6C94
	public object CreateElement(object elementName) { }

	// RVA: 0x3CD6D64
	public object CreateElement(object qualifiedName, object namespaceUri) { }

	// RVA: 0x3CD6E20
	public object CreateAttribute(object name, object value) { }

	// RVA: 0x3CD6F00
	public object CreateAttribute(object qualifiedName, object namespaceUri, object value) { }

	// RVA: 0x3CD6FC4
	public object get_DocumentElement() { }

	// RVA: 0x3CD7120
	public override object AppendChild(object newChild) { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XTextWrapper
{

	// Properties
	private object Text { get; }
	public override object Value { get; }
	public override object ParentNode { get; }

	// Methods

	// RVA: 0x3CD73D4
	private object get_Text() { }

	// RVA: 0x3CD7450
	public object .ctor(object text) { }

	// RVA: 0x3CD747C
	public override object get_Value() { }

	// RVA: 0x3CD7508
	public override object get_ParentNode() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XCommentWrapper
{

	// Properties
	private object Text { get; }
	public override object Value { get; }
	public override object ParentNode { get; }

	// Methods

	// RVA: 0x3CD7934
	private object get_Text() { }

	// RVA: 0x3CD79B0
	public object .ctor(object text) { }

	// RVA: 0x3CD79DC
	public override object get_Value() { }

	// RVA: 0x3CD7A68
	public override object get_ParentNode() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XProcessingInstructionWrapper
{

	// Properties
	private object ProcessingInstruction { get; }
	public override object LocalName { get; }
	public override object Value { get; }

	// Methods

	// RVA: 0x3CD7B78
	private object get_ProcessingInstruction() { }

	// RVA: 0x3CD6C68
	public object .ctor(object processingInstruction) { }

	// RVA: 0x3CD7BF4
	public override object get_LocalName() { }

	// RVA: 0x3CD7C80
	public override object get_Value() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XContainerWrapper
{

	// Fields
	private object _childNodes; // 0x10

	// Properties
	private object Container { get; }
	public override object ChildNodes { get; }
	protected virtual object HasChildNodes { get; }
	public override object ParentNode { get; }

	// Methods

	// RVA: 0x3CD7D0C
	private object get_Container() { }

	// RVA: 0x3CD5DC0
	public object .ctor(object container) { }

	// RVA: 0x3CD6088
	public override object get_ChildNodes() { }

	// RVA: 0x3CD66E0
	protected virtual object get_HasChildNodes() { }

	// RVA: 0x3CD7D88
	public override object get_ParentNode() { }

	// RVA: 0x3CD7618
	internal static object WrapNode(object node) { }

	// RVA: 0x3CD7248
	public override object AppendChild(object newChild) { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XObjectWrapper
{

	// Fields
	private readonly object _xmlObject; // 0x8

	// Properties
	public object WrappedNode { get; }
	public virtual object NodeType { get; }
	public virtual object LocalName { get; }
	public virtual object ChildNodes { get; }
	public virtual object Attributes { get; }
	public virtual object ParentNode { get; }
	public virtual object Value { get; }
	public virtual object NamespaceUri { get; }

	// Methods

	// RVA: 0x3CD5B78
	public object .ctor(object xmlObject) { }

	// RVA: 0x3CD7E98
	public object get_WrappedNode() { }

	// RVA: 0x3CD7EA0
	public virtual object get_NodeType() { }

	// RVA: 0x3CD7EF0
	public virtual object get_LocalName() { }

	// RVA: 0x3CD7EF8
	public virtual object get_ChildNodes() { }

	// RVA: 0x3CD7F74
	public virtual object get_Attributes() { }

	// RVA: 0x3CD7FF0
	public virtual object get_ParentNode() { }

	// RVA: 0x3CD7FF8
	public virtual object get_Value() { }

	// RVA: 0x3CD8000
	public virtual object AppendChild(object newChild) { }

	// RVA: 0x3CD8040
	public virtual object get_NamespaceUri() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XAttributeWrapper
{

	// Properties
	private object Attribute { get; }
	public override object Value { get; }
	public override object LocalName { get; }
	public override object NamespaceUri { get; }
	public override object ParentNode { get; }

	// Methods

	// RVA: 0x3CD8048
	private object get_Attribute() { }

	// RVA: 0x3CD6ED4
	public object .ctor(object attribute) { }

	// RVA: 0x3CD80C4
	public override object get_Value() { }

	// RVA: 0x3CD8150
	public override object get_LocalName() { }

	// RVA: 0x3CD81F0
	public override object get_NamespaceUri() { }

	// RVA: 0x3CD8290
	public override object get_ParentNode() { }

}

// Namespace: Newtonsoft.Json.Converters
internal class XElementWrapper
{

	// Fields
	private object _attributes; // 0x18

	// Properties
	private object Element { get; }
	public override object Attributes { get; }
	public override object Value { get; }
	public override object LocalName { get; }
	public override object NamespaceUri { get; }
	public object IsEmpty { get; }

	// Methods

	// RVA: 0x3CD83A0
	private object get_Element() { }

	// RVA: 0x3CD6D38
	public object .ctor(object element) { }

	// RVA: 0x3CD841C
	public object SetAttributeNode(object attribute) { }

	// RVA: 0x3CD8530
	public override object get_Attributes() { }

	// RVA: 0x3CD8C18
	private object HasImplicitNamespaceAttribute(object namespaceUri) { }

	// RVA: 0x3CD92E4
	public override object AppendChild(object newChild) { }

	// RVA: 0x3CD9310
	public override object get_Value() { }

	// RVA: 0x3CD939C
	public override object get_LocalName() { }

	// RVA: 0x3CD943C
	public override object get_NamespaceUri() { }

	// RVA: 0x3CD9228
	public object GetPrefixOfNamespace(object namespaceUri) { }

	// RVA: 0x3CD94DC
	public object get_IsEmpty() { }

}

// Namespace: Newtonsoft.Json.Converters
public class XmlNodeConverter
{

	// Fields
	internal static readonly object EmptyChildNodes; // 0x0
	private object <DeserializeRootElementName>k__BackingField; // 0x8
	private object <WriteArrayAttribute>k__BackingField; // 0x10
	private object <OmitRootObject>k__BackingField; // 0x11
	private object <EncodeSpecialCharacters>k__BackingField; // 0x12

	// Properties
	public object DeserializeRootElementName { get; }
	public object WriteArrayAttribute { get; }
	public object OmitRootObject { get; }
	public object EncodeSpecialCharacters { get; }

	// Methods

	// RVA: 0x3CD9568
	public object get_DeserializeRootElementName() { }

	// RVA: 0x3CD9570
	public object get_WriteArrayAttribute() { }

	// RVA: 0x3CD9578
	public object get_OmitRootObject() { }

	// RVA: 0x3CD9580
	public object get_EncodeSpecialCharacters() { }

	// RVA: 0x3CD9588
	public override object WriteJson(object writer, object value, object serializer) { }

	// RVA: 0x3CD9730
	private object WrapXml(object value) { }

	// RVA: 0x3CD984C
	private object PushParentNamespaces(object node, object manager) { }

	// RVA: 0x3CDBFB0
	private object ResolveFullName(object node, object manager) { }

	// RVA: 0x3CDC434
	private object GetPropertyName(object node, object manager) { }

	// RVA: 0x3CDC980
	private object IsArray(object node) { }

	// RVA: 0x3CDCD78
	private object SerializeGroupedNodes(object writer, object node, object manager, object writePropertyName) { }

	// RVA: 0x3CDDB0C
	private object WriteGroupedNodes(object writer, object manager, object writePropertyName, object groupedNodes, object elementNames) { }

	// RVA: 0x3CDDCE4
	private object WriteGroupedNodes(object writer, object manager, object writePropertyName, object node, object elementNames) { }

	// RVA: 0x3CDA05C
	private object SerializeNode(object writer, object node, object manager, object writePropertyName) { }

	// RVA: 0x3CDDE48
	private static object AllSameName(object node) { }

	// RVA: 0x3CDE4A0
	public override object ReadJson(object reader, object objectType, object existingValue, object serializer) { }

	// RVA: 0x3CDFD4C
	private object DeserializeValue(object reader, object document, object manager, object propertyName, object currentNode) { }

	// RVA: 0x3CDEEB0
	private object ReadElement(object reader, object document, object currentNode, object propertyName, object manager) { }

	// RVA: 0x3CE272C
	private object CreateElement(object reader, object document, object currentNode, object elementName, object manager, object elementPrefix, object attributeNameValues) { }

	// RVA: 0x3CE22FC
	private static object AddAttribute(object reader, object document, object currentNode, object propertyName, object attributeName, object manager, object attributePrefix) { }

	// RVA: 0x3CE047C
	private static object ConvertTokenToXmlValue(object reader) { }

	// RVA: 0x3CE16F8
	private object ReadArrayElements(object reader, object document, object propertyName, object currentNode, object manager) { }

	// RVA: 0x3CE31B4
	private object AddJsonArrayAttribute(object element, object document) { }

	// RVA: 0x3CE1B4C
	private object ShouldReadInto(object reader) { }

	// RVA: 0x3CE1BB4
	private object ReadAttributeElements(object reader, object manager) { }

	// RVA: 0x3CE0CF4
	private object CreateInstruction(object reader, object document, object currentNode, object propertyName) { }

	// RVA: 0x3CE1288
	private object CreateDocumentType(object reader, object document, object currentNode) { }

	// RVA: 0x3CE2F18
	private object CreateElement(object elementName, object document, object elementPrefix, object manager) { }

	// RVA: 0x3CDF2F0
	private object DeserializeNode(object reader, object document, object manager, object currentNode) { }

	// RVA: 0x3CE35A0
	private object IsNamespaceAttribute(object attributeName, object prefix) { }

	// RVA: 0x3CDE160
	private object ValueAttributes(object c) { }

	// RVA: 0x3CE36A4
	public override object CanConvert(object valueType) { }

	// RVA: 0x3CE375C
	private object IsXObject(object valueType) { }

	// RVA: 0x3CE383C
	private object IsXmlNode(object valueType) { }

	// RVA: 0x3CE391C
	public object .ctor() { }

	// RVA: 0x3CE3924
	private static object .cctor() { }

}

// Namespace: Newtonsoft.Json.Bson
public class BsonObjectId
{

	// Fields
	private readonly object <Value>k__BackingField; // 0x8

	// Properties
	public object Value { get; }

	// Methods

	// RVA: 0x3CE39B4
	public object get_Value() { }

	// RVA: 0x3CE39BC
	public object .ctor(object value) { }

}

// Namespace: Newtonsoft.Json.Bson
internal abstract class BsonToken
{

	// Fields
	private object <Parent>k__BackingField; // 0x8

	// Properties
	public abstract object Type { get; }
	public object Parent { set; }

	// Methods

	// RVA: -1
	public abstract object get_Type() { }

	// RVA: 0x3CE3AA4
	public object set_Parent(object value) { }

	// RVA: 0x3CE3AAC
	protected object .ctor() { }

}

// Namespace: Newtonsoft.Json.Bson
internal class BsonObject
{

	// Fields
	private readonly object _children; // 0x10

	// Properties
	public override object Type { get; }

	// Methods

	// RVA: 0x3CE3AB4
	public object Add(object name, object token) { }

	// RVA: 0x3CE3C94
	public override object get_Type() { }

}

// Namespace: Newtonsoft.Json.Bson
internal class BsonArray
{

	// Fields
	private readonly object _children; // 0x10

	// Properties
	public override object Type { get; }

	// Methods

	// RVA: 0x3CE3C9C
	public object Add(object token) { }

	// RVA: 0x3CE3DBC
	public override object get_Type() { }

}

// Namespace: Newtonsoft.Json.Bson
internal class BsonValue
{

	// Fields
	private readonly object _value; // 0x10
	private readonly object _type; // 0x18

	// Properties
	public override object Type { get; }

	// Methods

	// RVA: 0x3CE3DC4
	public object .ctor(object value, object type) { }

	// RVA: 0x3CE3E00
	public override object get_Type() { }

}

// Namespace: Newtonsoft.Json.Bson
internal class BsonString
{

	// Fields
	private readonly object <IncludeLength>k__BackingField; // 0x19

	// Methods

	// RVA: 0x3CE3C50
	public object .ctor(object value, object includeLength) { }

}

// Namespace: Newtonsoft.Json.Bson
internal class BsonRegex
{

	// Fields
	private object <Pattern>k__BackingField; // 0x10
	private object <Options>k__BackingField; // 0x18

	// Properties
	public object Pattern { set; }
	public object Options { set; }
	public override object Type { get; }

	// Methods

	// RVA: 0x3CE3E08
	public object set_Pattern(object value) { }

	// RVA: 0x3CE3E10
	public object set_Options(object value) { }

	// RVA: 0x3CE3E18
	public object .ctor(object pattern, object options) { }

	// RVA: 0x3CE3EC4
	public override object get_Type() { }

}

// Namespace: Newtonsoft.Json.Bson
internal class BsonProperty
{

	// Fields
	private object <Name>k__BackingField; // 0x8
	private object <Value>k__BackingField; // 0x10

	// Properties
	public object Name { set; }
	public object Value { set; }

	// Methods

	// RVA: 0x3CE3ECC
	public object set_Name(object value) { }

	// RVA: 0x3CE3ED4
	public object set_Value(object value) { }

	// RVA: 0x3CE3C48
	public object .ctor() { }

}

// Namespace: Newtonsoft.Json.Bson
internal enum BsonType
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Number;
	public const object String;
	public const object Object;
	public const object Array;
	public const object Binary;
	public const object Undefined;
	public const object Oid;
	public const object Boolean;
	public const object Date;
	public const object Null;
	public const object Regex;
	public const object Reference;
	public const object Code;
	public const object Symbol;
	public const object CodeWScope;
	public const object Integer;
	public const object TimeStamp;
	public const object Long;
	public const object MinKey;
	public const object MaxKey;
}

// Namespace: Newtonsoft.Json.Bson
public class BsonWriter
{

	// Fields
	private object _root; // 0x58
	private object _parent; // 0x60
	private object _propertyName; // 0x68

	// Methods

	// RVA: 0x3CE3EDC
	private object AddValue(object value, object type) { }

	// RVA: 0x3CE3F5C
	internal object AddToken(object token) { }

	// RVA: 0x3CE416C
	public object WriteObjectId(object value) { }

	// RVA: 0x3CD357C
	public object WriteRegex(object pattern, object options) { }

}

// Namespace: 
private struct __StaticArrayInitTypeSize=10
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=16
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=20
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=24
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=28
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=36
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=40
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=44
{
}

// Namespace: 
private struct __StaticArrayInitTypeSize=52
{
}

// Namespace: 
internal sealed class <PrivateImplementationDetails>
{

	// Fields
	internal static readonly object 0698228BF899CAEAB9A53E5E6C7099E846C44F56432050D234DDF03AD772F139; // 0x0
	internal static readonly object 19AE20A57B073E3E8DD45C6F6A4E9AB1076EA3EBFFF28E4AEB58B411472CF994; // 0x2C
	internal static readonly object 223D6CA32241C349E421A0164F2341E20CC5B65D5A04AA021CFF71D623895570; // 0x36
	internal static readonly object 33350F5DA385CE1B8749AEC68BA060CD54EE981968522B5EDF62178537A1FEEE; // 0x5E
	internal static readonly object 38809B9974198671140931F729415F3FD75DF68A6398E3486AE3B58554329A63; // 0x72
	internal static readonly object 499E4F5C84E20C7347E10100E0EC90C1945EA21C7C80809E4F7F474179B39DF6; // 0x9A
	internal static readonly object 4EDE3546F1189E450DF4D4A2739BE90BEB3B1708B3B9F406B02E0773A92A10FF; // 0xB6
	internal static readonly object 5857EE4CE98BFABBD62B385C1098507DD0052FF3951043AAD6A1DABD495F18AA; // 0xC6
	internal static readonly object 5ADB7CA81690556AB2A3201A849839FA3562604BB469382C7D6D78AB426283E2; // 0xFA
	internal static readonly object 5DDF815AC046E7D4603FA586D1BDE42118AD4FE9875D64F716BC7D2740EE52C9; // 0x116
	internal static readonly object 605A3F93AE7A97E00C156F977E942027EA532E263A5B440A4219984F803FDD04; // 0x12E
	internal static readonly object 7367A65185E4F747AA29364AB199D01646A010A62129A6BA2E35E929D7294D62; // 0x13E
	internal static readonly object 7439A4C9E30AC42BCC55AD1A2B617E29E7129B6DDAC79C886944B17819262CC1; // 0x162
	internal static readonly object 990F3F1286CC3928725497B2745CFF7BC7C9803B4EB8271611540BA6BF6654B5; // 0x18A
	internal static readonly object A8636D08B42D058EFC34703DD37B6468FCE56138DF242B862C3F1CA138CB3B89; // 0x1B2
	internal static readonly object B1D1BCD1D06B4A563944BE3C67D51F63DF23702E5BE760D7897C6AD1F51C6122; // 0x1C2
	internal static readonly object CAA07D7573596B3356BD202533F0EAFDD05309981F270193A99E300D57587326; // 0x1D6
	internal static readonly object D4B3B8EBA0589FC38724A0D318B46104B07BC528744109ED69ED71604B7EEC1A; // 0x1EA
	internal static readonly object F6EDC1733B068F457C63E03BB041B9AB6BFAD5CD7673D3E0841968D3FBCB12C7; // 0x212
	internal static readonly object FADB218011E7702BB9575D0C32A685DA10B5C72EB809BD9A955DB1C76E4D8315; // 0x23A
	internal static readonly object FCA56C548368F7065472C8C8EE4D63921B4F16BB51181EC202A0C252D5209E6A; // 0x26E
}

