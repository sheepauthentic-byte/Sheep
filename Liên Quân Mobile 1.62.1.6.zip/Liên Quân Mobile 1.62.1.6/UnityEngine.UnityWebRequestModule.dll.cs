// Namespace: 
internal class <Module>
{
}

// Namespace: UnityEngineInternal
internal static class WebRequestUtils
{

	// Fields
	private static object domainRegex; // 0x0

	// Methods

	// RVA: 0x76EB0DC
	internal static object RedirectTo(object baseUri, object redirectUri) { }

	// RVA: 0x76EB1EC
	internal static object MakeInitialUrl(object targetUrl, object localUrl) { }

	// RVA: 0x76EB5F8
	internal static object MakeUriString(object targetUri, object targetUrl, object prependProtocol) { }

	// RVA: 0x76EBA64
	private static object URLDecode(object encoded) { }

	// RVA: 0x76EBC30
	private static object .cctor() { }

}

// Namespace: UnityEngine
public class WWWForm
{

	// Fields
	private object formData; // 0x8
	private object fieldNames; // 0x10
	private object fileNames; // 0x18
	private object types; // 0x20
	private object boundary; // 0x28
	private object containsFiles; // 0x30
	private static object dDash; // 0x0
	private static object crlf; // 0x8
	private static object contentTypeHeader; // 0x10
	private static object dispositionHeader; // 0x18
	private static object endQuote; // 0x20
	private static object fileNameField; // 0x28
	private static object ampersand; // 0x30
	private static object equal; // 0x38

	// Properties
	internal static object DefaultEncoding { get; }
	public object headers { get; }
	public object data { get; }

	// Methods

	// RVA: 0x76EBCC4
	internal static object get_DefaultEncoding() { }

	// RVA: 0x76EBCCC
	public object .ctor() { }

	// RVA: 0x76EBE5C
	public object AddField(object fieldName, object value) { }

	// RVA: 0x76EBEA0
	public object AddField(object fieldName, object value, object e) { }

	// RVA: 0x76EC288
	public object AddField(object fieldName, object i) { }

	// RVA: 0x76EC2E8
	public object AddBinaryData(object fieldName, object contents, object fileName, object mimeType) { }

	// RVA: 0x76EC778
	public object get_headers() { }

	// RVA: 0x76EC928
	public object get_data() { }

	// RVA: 0x76EE25C
	private static object .cctor() { }

}

// Namespace: UnityEngine
internal class WWWTranscoder
{

	// Fields
	private static object ucHexChars; // 0x0
	private static object lcHexChars; // 0x8
	private static object urlEscapeChar; // 0x10
	private static object urlSpace; // 0x18
	private static object dataSpace; // 0x20
	private static object urlForbidden; // 0x28
	private static object qpEscapeChar; // 0x30
	private static object qpSpace; // 0x38
	private static object qpForbidden; // 0x40

	// Methods

	// RVA: 0x76EE624
	private static object Hex2Byte(object b, object offset) { }

	// RVA: 0x76EE71C
	private static object Byte2Hex(object b, object hexChars, object byte0, object byte1) { }

	// RVA: 0x76EE778
	public static object URLEncode(object toEncode) { }

	// RVA: 0x76EE1E8
	public static object DataEncode(object toEncode) { }

	// RVA: 0x76EE09C
	public static object QPEncode(object toEncode, object e) { }

	// RVA: 0x76EE7F0
	public static object Encode(object input, object escapeChar, object space, object forbidden, object uppercase) { }

	// RVA: 0x76EED2C
	private static object ByteArrayContains(object array, object b) { }

	// RVA: 0x76EBBC0
	public static object URLDecode(object toEncode) { }

	// RVA: 0x76EF284
	private static object ByteSubArrayEquals(object array, object index, object comperand) { }

	// RVA: 0x76EEDA8
	public static object Decode(object input, object escapeChar, object space) { }

	// RVA: 0x76EDEA0
	public static object SevenBitClean(object s, object e) { }

	// RVA: 0x76EF328
	public static object SevenBitClean(object input, object inputLength) { }

	// RVA: 0x76EF390
	private static object .cctor() { }

}

// Namespace: UnityEngine.Networking
public class CertificateHandler
{

	// Fields
	internal object m_Ptr; // 0x8

	// Methods

	// RVA: 0x76EF6F8
	private object Release() { }

	// RVA: 0x76EF748
	protected virtual object ValidateCertificate(object certificateData) { }

	// RVA: 0x76EF750
	internal object ValidateCertificateNative(object certificateData) { }

	// RVA: 0x76EF798
	public object Dispose() { }

}

// Namespace: UnityEngine.Networking
public class DownloadHandler
{

	// Fields
	internal object m_Ptr; // 0x8

	// Properties
	public object length { get; }
	public object data { get; }
	public object text { get; }

	// Methods

	// RVA: 0x76EF810
	private object Release() { }

	// RVA: 0x76EF860
	internal object .ctor() { }

	// RVA: 0x76EF868
	protected override object Finalize() { }

	// RVA: 0x76EF91C
	public virtual object Dispose() { }

	// RVA: 0x76EF978
	public object get_length() { }

	// RVA: 0x76EF9C8
	private object GetLength() { }

	// RVA: 0x76EFA18
	public object get_data() { }

	// RVA: 0x76EFA58
	public object get_text() { }

	// RVA: 0x76EFA98
	protected virtual object GetNativeData() { }

	// RVA: 0x76EFAA4
	protected virtual object GetData() { }

	// RVA: 0x76EFBE4
	protected virtual object GetText() { }

	// RVA: 0x76EFCC4
	private object GetTextEncoder() { }

	// RVA: 0x76EFFD0
	private object GetContentType() { }

	// RVA: 0x76F0020
	protected virtual object ReceiveContentLengthHeader(object contentLength) { }

	// RVA: 0x76F0068
	protected virtual object ReceiveContentLength(object contentLength) { }

	// RVA: 0x76F006C
	internal static object InternalGetByteArray(object dh, object length) { }

	// RVA: 0x76EFB44
	internal static object InternalGetByteArray(object dh) { }

	// RVA: 0x76F00D0
	internal static object InternalGetNativeArray(object dh, object nativeArray) { }

	// RVA: 0x76F022C
	internal static object DisposeNativeArray(object data) { }

	// RVA: 0x76F0274
	internal static object CreateNativeArrayForNativeData(object data, object bytes, object length) { }

}

// Namespace: UnityEngine.Networking
public sealed class DownloadHandlerBuffer
{

	// Fields
	private object m_NativeData; // 0x10

	// Methods

	// RVA: 0x76F0314
	private static object Create(object obj) { }

	// RVA: 0x76F0364
	private object InternalCreateBuffer() { }

	// RVA: 0x76F03C4
	public object .ctor() { }

	// RVA: 0x76F042C
	protected override object GetNativeData() { }

	// RVA: 0x76F0434
	public override object Dispose() { }

}

// Namespace: UnityEngine.Networking
public sealed class DownloadHandlerFile
{

	// Methods

	// RVA: 0x76F04D8
	private static object Create(object obj, object path, object append) { }

	// RVA: 0x76F0544
	private object InternalCreateVFS(object path, object append) { }

	// RVA: 0x76F060C
	public object .ctor(object path) { }

	// RVA: 0x76F0640
	protected override object GetNativeData() { }

	// RVA: 0x76F0694
	protected override object GetData() { }

	// RVA: 0x76F06E8
	protected override object GetText() { }

}

// Namespace: UnityEngine.Networking
public class UnityWebRequestAsyncOperation
{

	// Fields
	private object <webRequest>k__BackingField; // 0x18

	// Properties
	internal object webRequest { set; }

	// Methods

	// RVA: 0x76F0778
	internal object set_webRequest(object value) { }

	// RVA: 0x76F0780
	public object .ctor() { }

}

// Namespace: 
internal enum UnityWebRequestMethod
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object Get;
	public const object Post;
	public const object Put;
	public const object Head;
	public const object Custom;
}

// Namespace: 
internal enum UnityWebRequestError
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object OK;
	public const object OKCached;
	public const object Unknown;
	public const object SDKError;
	public const object UnsupportedProtocol;
	public const object MalformattedUrl;
	public const object CannotResolveProxy;
	public const object CannotResolveHost;
	public const object CannotConnectToHost;
	public const object AccessDenied;
	public const object GenericHttpError;
	public const object WriteError;
	public const object ReadError;
	public const object OutOfMemory;
	public const object Timeout;
	public const object HTTPPostError;
	public const object SSLCannotConnect;
	public const object Aborted;
	public const object TooManyRedirects;
	public const object ReceivedNoData;
	public const object SSLNotSupported;
	public const object FailedToSendData;
	public const object FailedToReceiveData;
	public const object SSLCertificateError;
	public const object SSLCipherNotAvailable;
	public const object SSLCACertError;
	public const object UnrecognizedContentEncoding;
	public const object LoginFailed;
	public const object SSLShutdownFailed;
	public const object RedirectLimitInvalid;
	public const object InvalidRedirect;
	public const object CannotModifyRequest;
	public const object HeaderNameContainsInvalidCharacters;
	public const object HeaderValueContainsInvalidCharacters;
	public const object CannotOverrideSystemHeaders;
	public const object AlreadySent;
	public const object InvalidMethod;
	public const object NotImplemented;
	public const object NoInternetConnection;
	public const object DataProcessingError;
	public const object InsecureConnectionNotAllowed;
}

// Namespace: 
public enum Result
{

	// Fields
	public object value__; // 0xFFFFFFFFFFFFFFF8
	public const object InProgress;
	public const object Success;
	public const object ConnectionError;
	public const object ProtocolError;
	public const object DataProcessingError;
}

// Namespace: UnityEngine.Networking
public class UnityWebRequest
{

	// Fields
	internal object m_Ptr; // 0x8
	internal object m_DownloadHandler; // 0x10
	internal object m_UploadHandler; // 0x18
	internal object m_CertificateHandler; // 0x20
	internal object m_Uri; // 0x28
	public const object kHttpVerbGET;
	public const object kHttpVerbHEAD;
	public const object kHttpVerbPOST;
	public const object kHttpVerbPUT;
	public const object kHttpVerbCREATE;
	public const object kHttpVerbDELETE;
	private object <disposeCertificateHandlerOnDispose>k__BackingField; // 0x30
	private object <disposeDownloadHandlerOnDispose>k__BackingField; // 0x31
	private object <disposeUploadHandlerOnDispose>k__BackingField; // 0x32

	// Properties
	public object disposeCertificateHandlerOnDispose { get; set; }
	public object disposeDownloadHandlerOnDispose { get; set; }
	public object disposeUploadHandlerOnDispose { get; set; }
	public object method { set; }
	public object error { get; }
	public object url { get; set; }
	public object responseCode { get; }
	public object isModifiable { get; }
	public object isDone { get; }
	public object isNetworkError { get; }
	public object result { get; }
	public object downloadProgress { get; }
	public object downloadedBytes { get; }
	public object chunkedTransfer { set; }
	public object uploadHandler { get; set; }
	public object downloadHandler { get; set; }
	public object certificateHandler { get; }

	// Methods

	// RVA: 0x76F07C4
	private static object GetWebErrorString(object err) { }

	// RVA: 0x76F0814
	internal static object GetHTTPStatusString(object responseCode) { }

	// RVA: 0x76F0864
	public object get_disposeCertificateHandlerOnDispose() { }

	// RVA: 0x76F086C
	public object set_disposeCertificateHandlerOnDispose(object value) { }

	// RVA: 0x76F0874
	public object get_disposeDownloadHandlerOnDispose() { }

	// RVA: 0x76F087C
	public object set_disposeDownloadHandlerOnDispose(object value) { }

	// RVA: 0x76F0884
	public object get_disposeUploadHandlerOnDispose() { }

	// RVA: 0x76F088C
	public object set_disposeUploadHandlerOnDispose(object value) { }

	// RVA: 0x76F0894
	internal static object Create() { }

	// RVA: 0x76F08D4
	private object Release() { }

	// RVA: 0x76F0924
	internal object InternalDestroy() { }

	// RVA: 0x76F0A10
	private object InternalSetDefaults() { }

	// RVA: 0x76F0A24
	public object .ctor(object url) { }

	// RVA: 0x76F0B84
	public object .ctor(object url, object method) { }

	// RVA: 0x76F0E2C
	public object .ctor(object url, object method, object downloadHandler, object uploadHandler) { }

	// RVA: 0x76F1158
	protected override object Finalize() { }

	// RVA: 0x76F1334
	public object Dispose() { }

	// RVA: 0x76F1254
	private object DisposeHandlers() { }

	// RVA: 0x76F145C
	internal object BeginWebRequest() { }

	// RVA: 0x76F14AC
	public object SendWebRequest() { }

	// RVA: 0x76F09C0
	public object Abort() { }

	// RVA: 0x76F14F8
	private object SetMethod(object methodType) { }

	// RVA: 0x76F155C
	internal object InternalSetMethod(object methodType) { }

	// RVA: 0x76F16B8
	private object SetCustomMethod(object customMethodName) { }

	// RVA: 0x76F171C
	internal object InternalSetCustomMethod(object customMethodName) { }

	// RVA: 0x76F0C68
	public object set_method(object value) { }

	// RVA: 0x76F1828
	private object GetError() { }

	// RVA: 0x76F1878
	public object get_error() { }

	// RVA: 0x76F1B38
	public object get_url() { }

	// RVA: 0x76F0AF0
	public object set_url(object value) { }

	// RVA: 0x76F1B88
	private object GetUrl() { }

	// RVA: 0x76F1CE4
	private object SetUrl(object url) { }

	// RVA: 0x76F1BD8
	private object InternalSetUrl(object url) { }

	// RVA: 0x76F1AE8
	public object get_responseCode() { }

	// RVA: 0x76F1D48
	private object IsExecuting() { }

	// RVA: 0x76F1668
	public object get_isModifiable() { }

	// RVA: 0x76F1D98
	public object get_isDone() { }

	// RVA: 0x76F1E00
	public object get_isNetworkError() { }

	// RVA: 0x76F1A98
	public object get_result() { }

	// RVA: 0x76F1E68
	private object GetDownloadProgress() { }

	// RVA: 0x76F1EB8
	public object get_downloadProgress() { }

	// RVA: 0x76F1F8C
	public object get_downloadedBytes() { }

	// RVA: 0x76F1FDC
	private object SetChunked(object chunked) { }

	// RVA: 0x76F2040
	public object set_chunkedTransfer(object value) { }

	// RVA: 0x76F214C
	internal object InternalSetRequestHeader(object name, object value) { }

	// RVA: 0x76F21B8
	public object SetRequestHeader(object name, object value) { }

	// RVA: 0x76F2348
	public object GetResponseHeader(object name) { }

	// RVA: 0x76F23AC
	internal object GetResponseHeaderKeys() { }

	// RVA: 0x76F23FC
	public object GetResponseHeaders() { }

	// RVA: 0x76F2648
	private object SetUploadHandler(object uh) { }

	// RVA: 0x76F144C
	public object get_uploadHandler() { }

	// RVA: 0x76F1048
	public object set_uploadHandler(object value) { }

	// RVA: 0x76F26AC
	private object SetDownloadHandler(object dh) { }

	// RVA: 0x76F1444
	public object get_downloadHandler() { }

	// RVA: 0x76F0F38
	public object set_downloadHandler(object value) { }

	// RVA: 0x76F1454
	public object get_certificateHandler() { }

	// RVA: 0x76F2710
	public static object Get(object uri) { }

	// RVA: 0x76F27F0
	public static object Post(object uri, object formData) { }

	// RVA: 0x76F2884
	private static object SetupPost(object request, object formData) { }

	// RVA: 0x76F2BB0
	public static object EscapeURL(object s, object e) { }

	// RVA: 0x76F2D30
	public static object UnEscapeURL(object s, object e) { }

}

// Namespace: UnityEngine.Networking
public class UploadHandler
{

	// Fields
	internal object m_Ptr; // 0x8

	// Properties
	public object contentType { set; }

	// Methods

	// RVA: 0x76F2EC4
	private object Release() { }

	// RVA: 0x76F2F14
	internal object .ctor() { }

	// RVA: 0x76F2F1C
	protected override object Finalize() { }

	// RVA: 0x76F2FD0
	public virtual object Dispose() { }

	// RVA: 0x76F302C
	public object set_contentType(object value) { }

	// RVA: 0x76F3074
	internal virtual object SetContentType(object newContentType) { }

	// RVA: 0x76F30D8
	private object InternalSetContentType(object newContentType) { }

}

// Namespace: UnityEngine.Networking
public sealed class UploadHandlerRaw
{

	// Fields
	private object m_Payload; // 0x10

	// Methods

	// RVA: 0x76F3168
	private static object Create(object self, object data, object dataLength) { }

	// RVA: 0x76F2B10
	public object .ctor(object data) { }

	// RVA: 0x76F31D4
	public object .ctor(object data, object transferOwnership) { }

	// RVA: 0x76F32D4
	public override object Dispose() { }

}

